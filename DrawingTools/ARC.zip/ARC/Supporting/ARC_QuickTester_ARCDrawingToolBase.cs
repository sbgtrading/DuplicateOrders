﻿using System.Collections.Generic;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.DrawingTools.ARC.Support
{
	public abstract class ARC_QuickTester_ARCDrawingToolBase : DrawingTool, ARC_QuickTester_IARCLicensed
	{
		public virtual bool ColicensedOnly { get { return false; } }
		public virtual string ProductInfusionSoftTag { get { return ""; } }
		public virtual List<string> ProductBundleInfusionSoftTags { get { return new List<string>(); } }
		public virtual string ProductVersion { get { return ""; } }
		public virtual string ModuleName { get { return ""; } }
	}
}
