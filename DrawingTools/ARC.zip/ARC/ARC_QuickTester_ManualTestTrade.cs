using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools.ARC.Support;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
using Brush = System.Windows.Media.Brush;
using Brushes = System.Windows.Media.Brushes;
using Point = System.Windows.Point;

//This namespace holds Drawing tools in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.DrawingTools.ARC
{
	public sealed class ARC_QuickTester_ManualLongTrade : ARC_QuickTester_ManualTestTrade
	{
		protected override MarketPosition TradeDirection
		{
			get { return MarketPosition.Long; }
		}

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State == State.SetDefaults)
			{
				Name = "Long Trade Marker";
				DisplayOnChartsMenus = false;
			}
		}
	}

	public sealed class ARC_QuickTester_ManualShortTrade : ARC_QuickTester_ManualTestTrade
	{
		protected override MarketPosition TradeDirection
		{
			get { return MarketPosition.Short; }
		}

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State == State.SetDefaults)
			{
				Name = "Short Trade Marker";
				DisplayOnChartsMenus = false;
			}
		}
	}

	public abstract class ARC_QuickTester_ManualTestTrade : ARC_QuickTester_ARCDrawingToolBase
	{
		#region Properties
		private const double CursorSensitivity = 15;
		private ChartAnchor editingAnchor;
		private ChartAnchor mfeAnchor;
		private ChartAnchor maeAnchor;

		public override bool ColicensedOnly { get { return true; } }

		protected double BarWidth
		{
			get
			{
				if (AttachedTo == null)
					return MinimumMarkerSize;

				var chartBars = AttachedTo.ChartObject as ChartBars;
				if (chartBars == null)
				{
					var iChartBars = AttachedTo.ChartObject as Gui.NinjaScript.IChartBars;
					if (iChartBars != null)
						chartBars = iChartBars.ChartBars;
				}

				return chartBars != null && chartBars.Properties.ChartStyle != null ? chartBars.Properties.ChartStyle.BarWidth : MinimumMarkerSize;
			}
		}

		internal static float MinimumMarkerSize { get { return 5f; } }

		protected abstract MarketPosition TradeDirection { get; }

		public override IEnumerable<ChartAnchor> Anchors
		{
			get { return new[] { InitialStopLossAnchor, EntryAnchor, ExitAnchor }; }
		}
		#endregion

		#region Overrides
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State == State.SetDefaults)
			{
				DrawingState = DrawingState.Building;
				ZOrderType = DrawingToolZOrder.AlwaysDrawnLast;

				InitialStopLossAnchor = new ChartAnchor
				{
					IsEditing = true,
					DrawingTool = this,
					DisplayName = "Initial Stop Loss",
					IsBrowsable = true
				};

				EntryAnchor = new ChartAnchor
				{
					IsEditing = true,
					DrawingTool = this,
					DisplayName = "Entry",
					IsBrowsable = true
				};

				ExitAnchor = new ChartAnchor
				{
					IsEditing = true,
					DrawingTool = this,
					DisplayName = "Exit",
					IsBrowsable = true
				};

				MfeBrush = Brushes.Cyan;
				MaeBrush = Brushes.Magenta;
				WinningConnectorBrush = Brushes.Lime;
				LosingConnectorBrush = Brushes.Red;
				StopLossBrush = Brushes.Red;
				StopLossConnectorBrush = Brushes.White;
				EntryMarkerBrush = Brushes.White;
				ExitMarkerBrush = Brushes.Black;
				LabelBrush = Brushes.White;
				Opacity = 100;
			}
			else if (State == State.Configure)
			{
				this.ARC_QuickTester_EnactLicensing(ARC_QuickTester_LicensingContextStep.Configure);
			}
			else if (State == State.Terminated)
			{
				Dispose();
			}
		}

		public override Cursor GetCursor(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, Point point)
		{
			switch (DrawingState)
			{
			case DrawingState.Building: return Cursors.Pen;
			case DrawingState.Moving: return IsLocked ? Cursors.No : Cursors.SizeAll;
			case DrawingState.Editing:
				if (IsLocked)
					return Cursors.No;
				return Cursors.SizeAll;
			default:
				// draw move cursor if cursor is near line path anywhere
				var startPoint = EntryAnchor.GetPoint(chartControl, chartPanel, chartScale);

				var closest = GetClosestAnchor(chartControl, chartPanel, chartScale, CursorSensitivity, point);
				if (closest != null)
				{
					if (IsLocked)
						return Cursors.Arrow;
					if (closest == InitialStopLossAnchor)
						return Cursors.SizeNS;
					return Cursors.SizeAll;
				}

				var endPoint = ExitAnchor.GetPoint(chartControl, chartPanel, chartScale);
				var minPoint = startPoint;
				var maxPoint = endPoint;
				var totalVector = maxPoint - minPoint;
				return MathHelper.IsPointAlongVector(point, minPoint, totalVector, CursorSensitivity) ?
					IsLocked ? Cursors.Arrow : Cursors.SizeAll : null;
			}
		}

		public override Point[] GetSelectionPoints(ChartControl chartControl, ChartScale chartScale)
		{
			var chartPanel = chartControl.ChartPanels[chartScale.PanelIndex];
			var initialStopLossPoint = InitialStopLossAnchor.GetPoint(chartControl, chartPanel, chartScale);
			var startPoint = EntryAnchor.GetPoint(chartControl, chartPanel, chartScale);
			var endPoint = ExitAnchor.GetPoint(chartControl, chartPanel, chartScale);
			return new[] { initialStopLossPoint, startPoint, endPoint };
		}

		public override void OnMouseDown(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
		{
			// If we've created a new trade, take the colors from the manual booster that created it
			var mb = chartPanel.ChartObjects.OfType<ARC_QuickTester>().FirstOrDefault();
			if (mb != null && DrawingState == DrawingState.Building)
				mb.SetManualTradeColors(this);

			this.ARC_QuickTester_SnapToTick(InitialMouseDownAnchor);
			switch (DrawingState)
			{
			case DrawingState.Building:
				this.ARC_QuickTester_SnapToTick(dataPoint);
				if (EntryAnchor.IsEditing)
				{
					PinToBarYRange(dataPoint, chartControl);
					dataPoint.CopyDataValues(EntryAnchor);
					EntryAnchor.IsEditing = false;
					dataPoint.CopyDataValues(InitialStopLossAnchor);
				}
				else if (InitialStopLossAnchor.IsEditing)
				{
					dataPoint.Price = TradeDirection == MarketPosition.Long 
						? Math.Min(dataPoint.Price, EntryAnchor.Price - AttachedTo.Instrument.MasterInstrument.TickSize) 
						: Math.Max(dataPoint.Price, EntryAnchor.Price + AttachedTo.Instrument.MasterInstrument.TickSize);
					dataPoint.SlotIndex = EntryAnchor.SlotIndex;
					dataPoint.Time = EntryAnchor.Time;
					dataPoint.CopyDataValues(InitialStopLossAnchor);
					InitialStopLossAnchor.IsEditing = false;
					dataPoint.CopyDataValues(ExitAnchor);
				}
				else if (ExitAnchor.IsEditing)
				{
					ForceXAxisOrder(EntryAnchor, dataPoint, -1);
					PinToBarYRange(dataPoint, chartControl);
					dataPoint.CopyDataValues(ExitAnchor);
					ExitAnchor.IsEditing = false;
					RefreshExcursionAnchors(chartControl);

					// Initial building done
					DrawingState = DrawingState.Normal;
					IsSelected = false;
				}
				break;
			case DrawingState.Normal:
				// TODO Update to select properly if line is clicked
				var point = dataPoint.GetPoint(chartControl, chartPanel, chartScale);
				editingAnchor = GetClosestAnchor(chartControl, chartPanel, chartScale, CursorSensitivity, point);

				if (editingAnchor != null)
				{
					editingAnchor.IsEditing = true;
					DrawingState = DrawingState.Editing;
					IsSelected = true;
				}
				else
				{
					if (GetCursor(chartControl, chartPanel, chartScale, point) != null)
						DrawingState = DrawingState.Moving;
					else
						// user whiffed.
						IsSelected = false;
				}
				break;
			}

			var ctrlDown = Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl);
			var shiftDown = Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift);
			if (shiftDown && ctrlDown)
				return;

			if (ctrlDown)
			{
				Clipboard.SetText(GetSummary(), TextDataFormat.Text);
			}
			else if (shiftDown)
			{
				var screenShot = chartControl.OwnerChart.GetScreenshot(ShareScreenshotType.Chart);
				ARC_QuickTester_CopyImageLinkToClipboard(chartControl.OwnerChart, screenShot, true).ConfigureAwait(false);
			}
		}

		public override void OnMouseMove(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
		{
			if (IsLocked && DrawingState != DrawingState.Building)
				return;

			if (DrawingState == DrawingState.Building)
			{
				// start anchor will not be editing here because we start building as soon as user clicks, which
				// plops down a start anchor right away
				if (EntryAnchor.IsEditing)
					return;

				this.ARC_QuickTester_SnapToTick(dataPoint);
				if (InitialStopLossAnchor.IsEditing)
				{
					dataPoint.Time = EntryAnchor.Time;
					dataPoint.SlotIndex = EntryAnchor.SlotIndex;
					dataPoint.Price = TradeDirection == MarketPosition.Long 
						? Math.Min(dataPoint.Price, EntryAnchor.Price - AttachedTo.Instrument.MasterInstrument.TickSize) 
						: Math.Max(dataPoint.Price, EntryAnchor.Price + AttachedTo.Instrument.MasterInstrument.TickSize);
					dataPoint.CopyDataValues(InitialStopLossAnchor);
				}
				else if (ExitAnchor.IsEditing)
				{
					PinToBarYRange(dataPoint, chartControl);
					ForceXAxisOrder(EntryAnchor, dataPoint, -1);
					dataPoint.CopyDataValues(ExitAnchor);
					RefreshExcursionAnchors(chartControl);
				}
			}
			else if (DrawingState == DrawingState.Editing && editingAnchor != null)
			{
				this.ARC_QuickTester_SnapToTick(dataPoint);
				if (editingAnchor == InitialStopLossAnchor)
				{
					ForceYAxisOrder(EntryAnchor, dataPoint, TradeDirection == MarketPosition.Long ? 1 : -1);
					InitialStopLossAnchor.MoveAnchorPrice(InitialMouseDownAnchor, dataPoint, chartControl, chartPanel, chartScale, this);
					InitialStopLossAnchor.Price = TradeDirection == MarketPosition.Long 
						? Math.Min(InitialStopLossAnchor.Price, EntryAnchor.Price - AttachedTo.Instrument.MasterInstrument.TickSize) 
						: Math.Max(InitialStopLossAnchor.Price, EntryAnchor.Price + AttachedTo.Instrument.MasterInstrument.TickSize);
					return;
				}

				if (editingAnchor == EntryAnchor)
				{
					ForceXAxisOrder(ExitAnchor, dataPoint, 1);
					InitialStopLossAnchor.MoveAnchorTime(InitialMouseDownAnchor, dataPoint, chartControl, chartPanel, chartScale, this);
				}
				else
				{
					ForceXAxisOrder(EntryAnchor, dataPoint, -1);
				}

				PinToBarYRange(dataPoint, chartControl);
				dataPoint.CopyDataValues(editingAnchor);
				RefreshExcursionAnchors(chartControl);
			}
			else if (DrawingState == DrawingState.Moving)
			{
				foreach (var anchor in Anchors)
				{
					if (anchor == InitialStopLossAnchor)
					{
						InitialStopLossAnchor.MoveAnchorTime(InitialMouseDownAnchor, dataPoint, chartControl, chartPanel, chartScale, this);
						InitialStopLossAnchor.Price = TradeDirection == MarketPosition.Long 
							? Math.Min(dataPoint.Price, EntryAnchor.Price - AttachedTo.Instrument.MasterInstrument.TickSize) 
							: Math.Max(dataPoint.Price, EntryAnchor.Price + AttachedTo.Instrument.MasterInstrument.TickSize);
						continue;
					}

					anchor.MoveAnchor(InitialMouseDownAnchor, dataPoint, chartControl, chartPanel, chartScale, this);
					PinToBarYRange(anchor, chartControl);
				}

				RefreshExcursionAnchors(chartControl);
			}
		}

		public override void OnMouseUp(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
		{
			// simply end whatever moving
			if (DrawingState == DrawingState.Moving || DrawingState == DrawingState.Editing)
				DrawingState = DrawingState.Normal;
			if (editingAnchor != null)
			{
				editingAnchor.IsEditing = false;
				this.ARC_QuickTester_SnapToTick(editingAnchor);
			}
			else
			{
				foreach (var anchor in Anchors) 
					this.ARC_QuickTester_SnapToTick(anchor);
			}

			editingAnchor = null;
		}

		public override bool IsVisibleOnChart(ChartControl chartControl, ChartScale chartScale, DateTime firstTimeOnChart, DateTime lastTimeOnChart)
		{
			if (!this.ARC_QuickTester_IsLicensed())
				return false;

			if (DrawingState == DrawingState.Building)
				return true;

			RefreshAnchorSlotIndexes(chartControl);

			var minTime = Core.Globals.MaxDate;
			var maxTime = Core.Globals.MinDate;

			// check at least one of our anchors is in horizontal time frame
			foreach (var anchor in Anchors)
			{
				if (anchor.Time < minTime)
					minTime = anchor.Time;
				if (anchor.Time > maxTime)
					maxTime = anchor.Time;
			}
			if (minTime > lastTimeOnChart || maxTime < firstTimeOnChart)
				return false;

			// Check if we're also all in Y range
			if (IsAutoScale)
				return true;

			var screenRect = new Rect(new Point(chartControl.PrimaryBars.FromIndex, chartScale.MinValue), new Size(chartControl.PrimaryBars.ToIndex - chartControl.PrimaryBars.FromIndex, chartScale.MaxValue - chartScale.MinValue));
			var csTest = new CohenSutherlandTest(screenRect);
			var entryPoint = new Point(EntryAnchor.SlotIndex, EntryAnchor.Price);
			return csTest.IntersectsLine(entryPoint, new Point(ExitAnchor.SlotIndex, ExitAnchor.Price)) || csTest.IntersectsLine(entryPoint, new Point(InitialStopLossAnchor.SlotIndex, InitialStopLossAnchor.Price));
		}
		#endregion

		internal enum SummaryPart
		{
			Symbol,
			Entry,
			InitialStop,
			Exit,
			Direction,
			Mfe,
			Mae
		}

		internal string GetSummary()
		{
			return GetSummary((SummaryPart[])Enum.GetValues(typeof(SummaryPart)));
		}

		internal string GetSummary(SummaryPart[] stats)
		{
			if (mfeAnchor == null || maeAnchor == null)
				RefreshExcursionAnchors(ChartPanel.ChartControl);

			var parts = new List<string>();
			foreach (var stat in stats)
				switch (stat)
				{
				case SummaryPart.Symbol:
					parts.Add(AttachedTo.Instrument.FullName);
					continue;
				case SummaryPart.InitialStop:
					parts.Add(InitialStopLossAnchor.Price.ToString("R"));
					continue;
				case SummaryPart.Direction:
					parts.Add(TradeDirection.ToString().ToUpper());
					continue;
				case SummaryPart.Mfe:
					parts.Add(mfeAnchor.Price.ToString("R"));
					continue;
				case SummaryPart.Mae:
					parts.Add(maeAnchor.Price.ToString("R"));
					continue;
				case SummaryPart.Entry:
				case SummaryPart.Exit:
					var anchor = stat == SummaryPart.Entry ? EntryAnchor : ExitAnchor;
					parts.Add(anchor.Time.ToString("yyyy-MM-dd HH:mm:sss"));
					parts.Add(anchor.Price.ToString("N"));
					break;
				default:
					throw new ArgumentOutOfRangeException();
				}

			return string.Join("\t", parts.ToArray());
		}

		private void PinToBarYRange(ChartAnchor anchor, ChartControl chartControl)
		{
			var chartBars = chartControl.BarsArray[0].Bars;
			var bar = chartBars.BarsType.IsTimeBased ? chartBars.GetBar(anchor.Time) : (int)anchor.SlotIndex;
			if (bar >= chartBars.BarsSeries.Count)
				return;

			anchor.Price = Math.Min(chartBars.GetHigh(bar), Math.Max(chartBars.GetLow(bar), anchor.Price));
		}

		private void ForceXAxisOrder(ChartAnchor fixedAnchor, ChartAnchor movableAnchor, int expectedCompare)
		{
			var compare = fixedAnchor.Time.CompareTo(movableAnchor.Time);
			if (compare == expectedCompare || compare == 0)
				return;

			movableAnchor.Time = fixedAnchor.Time;
			movableAnchor.SlotIndex = fixedAnchor.SlotIndex;
		}

		private void ForceYAxisOrder(ChartAnchor fixedAnchor, ChartAnchor movableAnchor, int expectedCompare)
		{
			var compare = fixedAnchor.Price.CompareTo(movableAnchor.Price);
			if (compare == expectedCompare || compare == 0)
				return;

			movableAnchor.Price = fixedAnchor.Price;
		}

		private void RefreshExcursionAnchors(ChartControl chartControl)
		{
			var chartBars = chartControl.BarsArray[0].Bars;
			var mfeMaeTimes = new[] { DateTime.MinValue, DateTime.MinValue };
			var mfeMaeBars = new[] { -1, -1 };
			var mfeMaeValues = new[] { double.NaN, double.NaN };
			var entryBar = chartBars.BarsType.IsTimeBased ? chartBars.GetBar(EntryAnchor.Time) : (int)EntryAnchor.SlotIndex;
			var exitBar = chartBars.BarsType.IsTimeBased ? chartBars.GetBar(ExitAnchor.Time) : (int)ExitAnchor.SlotIndex;
			if (entryBar == exitBar)
			{
				mfeMaeBars[0] = mfeMaeBars[1] = entryBar;
				mfeMaeTimes[0] = mfeMaeTimes[1] = chartControl.GetTimeBySlotIndex((int)Math.Ceiling(chartControl.GetSlotIndexByTime(chartBars.GetTime(entryBar))));
				if (ExitAnchor.Price.ApproxCompare(EntryAnchor.Price) == (TradeDirection == MarketPosition.Long ? 1 : -1))
				{
					mfeMaeValues[0] = ExitAnchor.Price;
					mfeMaeValues[1] = EntryAnchor.Price;
				}
				else
				{
					mfeMaeValues[0] = EntryAnchor.Price;
					mfeMaeValues[1] = ExitAnchor.Price;
				}
			}
			else
			{
				for (var bar = entryBar; bar <= Math.Min(chartBars.BarsSeries.Count - 1, exitBar); bar++)
					for (var i = 0; i < 2; i++)
					{
						var seekingMax = (TradeDirection == MarketPosition.Long) == (i == 0);
						var compValue = seekingMax ? chartBars.GetHigh(bar) : chartBars.GetLow(bar);

						if (bar == entryBar)
							compValue = seekingMax ? Math.Min(compValue, EntryAnchor.Price) : Math.Max(compValue, EntryAnchor.Price);
						else if (bar == exitBar)
							compValue = seekingMax ? Math.Min(compValue, ExitAnchor.Price) : Math.Max(compValue, ExitAnchor.Price);

						// If we're time based, we take the first instance of the MFE or MAE. However for renkos we need to take the last instead.
						var compResult = compValue.ApproxCompare(mfeMaeValues[i]);
						if (bar != entryBar && (compResult == (seekingMax ? -1 : 1) || (chartBars.BarsType.BarsPeriod.BarsPeriodType != BarsPeriodType.Renko && compResult == 0)))
							continue;

						mfeMaeBars[i] = bar;
						mfeMaeTimes[i] = chartControl.GetTimeBySlotIndex((int)Math.Ceiling(chartControl.GetSlotIndexByTime(chartBars.GetTime(bar))));
						mfeMaeValues[i] = compValue;
					}
			}

			mfeAnchor = chartBars.BarsType.IsTimeBased
				? new ChartAnchor(mfeMaeTimes[0], mfeMaeValues[0], chartControl)
				: new ChartAnchor(mfeMaeTimes[0], mfeMaeValues[0], mfeMaeBars[0], chartControl);
			maeAnchor = chartBars.BarsType.IsTimeBased
				? new ChartAnchor(mfeMaeTimes[1], mfeMaeValues[1], chartControl)
				: new ChartAnchor(mfeMaeTimes[1], mfeMaeValues[1], mfeMaeBars[1], chartControl);
		}

		internal static async Task ARC_QuickTester_CopyImageLinkToClipboard(Window window, BitmapSource bmp, bool showSuccessPopup)
		{
			const string storageKey = "JPvRhbJLiToAu+0ROGOp3E2zWwnMUoH7jyIp7nGQz7Ry/Xvjn/q05ABUmRYlIQunp1wcovqQeJjP+AStMfgeig==";
			const string storageAccount = "qtscreenshots";
			const string storageContainer = "prod";
			var fileName = Guid.NewGuid().ToString("N") + ".jpg";

			var encoder = new JpegBitmapEncoder();
			encoder.Frames.Add(BitmapFrame.Create(bmp));
			using (var stream = new MemoryStream())
			{
				encoder.Save(stream);
				stream.Seek(0, SeekOrigin.Begin);
				try
				{
					await AzureStorageHelper.UploadBlob(stream, storageAccount, storageContainer, fileName, "image/jpg", storageKey);
				}
				catch (HttpRequestException ex)
				{
					Log("Error Uploading to Server! " + Environment.NewLine + ex.Message, LogLevel.Alert);
					return;
				}
			}

			Clipboard.SetText(AzureStorageHelper.GetBlobUrl(storageAccount, storageContainer, fileName));
			if (showSuccessPopup)
				NTMessageBox.Show(window, "Image Link Copied to Clipboard!", "", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}

		private void RefreshAnchorSlotIndexes(ChartControl chartControl)
		{
			foreach (var anchor in new[] { EntryAnchor, ExitAnchor, mfeAnchor, maeAnchor })
			{
				if (!IsAnchorPlaced(anchor) || anchor.SlotIndex >= 0)
					continue;
				anchor.SlotIndex = chartControl.GetSlotIndexByTime(anchor.Time);
			}
		}

		private bool IsAnchorPlaced(ChartAnchor anchor)
		{
			return anchor != null && anchor.Time > Core.Globals.MinDate + TimeSpan.FromSeconds(1);
		}

		#region Rendering
		private readonly ARC_QuickTester_SolidColorBrushCache brushCache = new ARC_QuickTester_SolidColorBrushCache();

		private const float TextMargin = 3f;

		private void DrawMidpointText(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, string text, ChartAnchor anchor1, ChartAnchor anchor2)
		{
			var startPoint = anchor1.GetPoint(chartControl, chartPanel, chartScale);
			var endPoint = anchor2.GetPoint(chartControl, chartPanel, chartScale);
			var midPoint = new Point((startPoint.X + endPoint.X) / 2, (startPoint.Y + endPoint.Y) / 2);

			// Text rec uses same settings as mini data box
			var textBackgroundDeviceBrush = new DeviceBrush(Application.Current.FindResource("ChartControl.DataBoxBackground") as Brush, RenderTarget);

			var borderBrush = Application.Current.FindResource("BorderThinBrush") as Brush;
			var thicknessResource = Application.Current.FindResource("BorderThinThickness");
			var thickness = thicknessResource as double? ?? 1;
			var lineColor = new Stroke(Brushes.DarkGray, DashStyleHelper.Solid, 1f, 50);
			var textBorderStroke = new Stroke(borderBrush ?? lineColor.Brush, DashStyleHelper.Solid, Convert.ToSingle(thickness)) { RenderTarget = RenderTarget };
			
			var rect = GetTextRect(chartControl, midPoint, text, TextMargin);
			if (textBackgroundDeviceBrush.BrushDX != null)
			{
				RenderTarget.FillRectangle(rect, textBackgroundDeviceBrush.BrushDX);
				textBackgroundDeviceBrush.BrushDX.Dispose();
			}

			RenderTarget.DrawRectangle(rect, textBorderStroke.BrushDX, textBorderStroke.Width, textBorderStroke.StrokeStyle);
			DrawText(chartControl, midPoint, text, Application.Current.FindResource("ChartControl.DataBoxForeground") as Brush);
			textBorderStroke.BrushDX.Dispose();
		}

		private void UpdateProfitText(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale)
		{
			var risk = EntryAnchor.Price - InitialStopLossAnchor.Price;
			var profitString = risk.ApproxCompare(0) == 0 ? "NA" : ((ExitAnchor.Price - EntryAnchor.Price) / risk).ToString("F2") + "R";
			DrawMidpointText(chartControl, chartPanel, chartScale, profitString, EntryAnchor, ExitAnchor);
		}
		
		private void UpdateSlTickText(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale)
		{
			var slTicks = (int)(Math.Abs(EntryAnchor.Price - InitialStopLossAnchor.Price) / AttachedTo.Instrument.MasterInstrument.TickSize);
			var profitString = slTicks.ToString("F0") + " Ticks";
			DrawMidpointText(chartControl, chartPanel, chartScale, profitString, EntryAnchor, InitialStopLossAnchor);
		}

		private void DrawStopLossConnectorLine(Point slMidpoint, Point entryPoint)
		{
			var stroke = new Stroke(brushCache[StopLossConnectorBrush.ARC_QuickTester_GetColor().ARC_QuickTester_WithAlpha(Opacity / 100)], DashStyleHelper.Dot, 5) { RenderTarget = RenderTarget };
			if (stroke.BrushDX == null)
				return;

			RenderTarget.DrawLine(slMidpoint.ToVector2(), entryPoint.ToVector2(), stroke.BrushDX, 3, stroke.StrokeStyle);
			stroke.BrushDX.Dispose();
		}

		private RectangleF GetTextRect(ChartControl chartControl, Point labelCenter, string text, float margin)
		{
			var wpfFont = chartControl.Properties.LabelFont ?? new SimpleFont();
			using (var textFormat = wpfFont.ToDirectWriteTextFormat())
			{
				textFormat.TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading;
				textFormat.WordWrapping = WordWrapping.NoWrap;
				using (var textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, 600, 600))
				{
					// Use measured max width/height
					textLayout.MaxWidth = textLayout.Metrics.Width;
					textLayout.MaxHeight = textLayout.Metrics.Height;

					return new RectangleF((float)(labelCenter.X - textLayout.MaxWidth / 2 - margin),
						(float)(labelCenter.Y - textLayout.MaxHeight / 2 - margin),
						textLayout.MaxWidth + margin * 2f, textLayout.MaxHeight + margin);
				}
			}
		}

		private void DrawText(ChartControl chartControl, Point textCenter, string text, Brush brush)
		{
			var wpfFont = chartControl.Properties.LabelFont ?? new SimpleFont();
			using (var textFormat = wpfFont.ToDirectWriteTextFormat())
			{
				textFormat.TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading;
				textFormat.WordWrapping = WordWrapping.NoWrap;
				// give big values for max width/height, we will trim to actual used
				using (var textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, 600, 600))
				{
					// use measured max width/height
					textLayout.MaxWidth = textLayout.Metrics.Width;
					textLayout.MaxHeight = textLayout.Metrics.Height;

					var placementRect = GetTextRect(chartControl, textCenter, text, TextMargin);

					var textDeviceBrush = new DeviceBrush(brush, RenderTarget);
					if (textDeviceBrush.BrushDX == null)
						return;
					
					RenderTarget.DrawTextLayout(new Vector2(placementRect.X + TextMargin, placementRect.Y + TextMargin), textLayout, textDeviceBrush.BrushDX);
					textDeviceBrush.BrushDX.Dispose();
				}
			}
		}

		public SharpDX.Direct2D1.Brush GetFillDxBrush(ChartControl chartControl, Brush brush, float opacity)
		{
			return brushCache[brush.ARC_QuickTester_GetColor().ARC_QuickTester_WithAlpha(opacity / 100)].ToDxBrush(RenderTarget, opacity / 100);
		}

		public SharpDX.Direct2D1.Brush GetStrokeDxBrush(ChartControl chartControl, Brush brush, float opacity, float thickness, DashStyleHelper style)
		{
			return new Stroke(brushCache[brush.ARC_QuickTester_GetColor().ARC_QuickTester_WithAlpha(opacity / 100)], style, thickness) { RenderTarget = RenderTarget }.BrushDX;
		}

		public override void OnRenderTargetChanged()
		{
			brushCache.Dispose();
		}

		public override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (!this.ARC_QuickTester_IsLicensed())
				return;

			RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;

			var maeMfeAndArrowWidth = (float) Math.Min(Math.Max(BarWidth * 1.75f, 5), 15);

			// Our slot indexes aren't guaranteed to be valid when we reload our chart, this force refreshes them
			RefreshAnchorSlotIndexes(chartControl);

			// Draw our initial stop loss anchor
			if (IsAnchorPlaced(InitialStopLossAnchor))
			{
				var initialStopLossPoint = InitialStopLossAnchor.GetPoint(chartControl, ChartPanel, chartScale);
				if (IsSelected)
				{
					DrawStopLossConnectorLine(initialStopLossPoint, EntryAnchor.GetPoint(chartControl, ChartPanel, chartScale));
					var offset = BarWidth * 2 * (TradeDirection == MarketPosition.Long ? 1 : -1);
					DrawText(chartControl, new Point(initialStopLossPoint.X, initialStopLossPoint.Y + offset), "SL", LabelBrush ?? chartControl.Properties.ChartText);
					UpdateSlTickText(chartControl, ChartPanel, chartScale);
				}
			}

			// Draw entry and exit markers
			if (IsSelected)
			{
				for (var i = 0; i < 2; i++)
				{
					var anchor = i == 0 ? EntryAnchor : ExitAnchor;
					if (!IsAnchorPlaced(anchor))
						continue;

					var labelPoint = anchor.GetPoint(chartControl, ChartPanel, chartScale);
					var offset = BarWidth * 2;
					if (IsAnchorPlaced(EntryAnchor) && IsAnchorPlaced(ExitAnchor) && Math.Round(EntryAnchor.SlotIndex).ApproxCompare(Math.Round(ExitAnchor.SlotIndex)) == 0)
					{
						var compVsOtherAnchor = (i == 0 ? -1 : 1) * EntryAnchor.Price.ApproxCompare(ExitAnchor.Price);
						offset *= compVsOtherAnchor == 0 ? (i == 0 ? 1 : -1) : compVsOtherAnchor;
					}
					else
					{
						offset *= TradeDirection == MarketPosition.Long ? -1 : 1;
					}

					DrawText(chartControl, new Point(labelPoint.X, labelPoint.Y + offset), i == 0 ? "ENTRY" : "EXIT", LabelBrush ?? chartControl.Properties.ChartText);
				}
			}

			var chartBars = chartControl.BarsArray[0].Bars;

			// Draw our trade dir arrow
			if (!IsSelected)
			{
				var markerAnchor = new ChartAnchor();
				EntryAnchor.CopyDataValues(markerAnchor);
				var barIdx = chartBars.BarsType.IsTimeBased ? chartBars.GetBar(EntryAnchor.Time) : (int)EntryAnchor.SlotIndex;
				markerAnchor.Price = TradeDirection == MarketPosition.Long ? chartBars.GetLow(barIdx) : chartBars.GetHigh(barIdx);
				var arrowPoint = markerAnchor.GetPoint(chartControl, ChartPanel, chartScale);
				using (var arrowFillBrush = GetFillDxBrush(chartControl, TradeDirection == MarketPosition.Short ? ShortEntryArrowBrush : LongEntryArrowBrush, Opacity))
					RenderTarget.ARC_QuickTester_DrawArrow(arrowPoint, TradeDirection == MarketPosition.Short, maeMfeAndArrowWidth, null, arrowFillBrush);
			}

			// Skip MFE/MAE and R visuals if we don't have an entry and exit
			if (!IsAnchorPlaced(EntryAnchor) || !IsAnchorPlaced(ExitAnchor))
				return;

			// Refresh our anchors, if they've yet to be drawn in for some reason
			if (!IsAnchorPlaced(mfeAnchor) && !IsAnchorPlaced(maeAnchor))
				RefreshExcursionAnchors(chartControl);

			// Draw our SL line
			using (var slRectBrush = GetFillDxBrush(chartControl, StopLossBrush, Opacity))
			{
				for (var i = Math.Floor(EntryAnchor.SlotIndex); i <= Math.Floor(ExitAnchor.SlotIndex); i += 1)
				{
					var markerAnchor = new ChartAnchor
					{
						Price = InitialStopLossAnchor.Price,
						SlotIndex = i,
						Time = chartControl.GetTimeBySlotIndex(i)
					};
					var width = (float)Math.Min(Math.Max(BarWidth * 1.25f, 3), 10);
					RenderTarget.ARC_QuickTester_DrawDiamond(markerAnchor.GetPoint(chartControl, ChartPanel, chartScale), width, slRectBrush);
				}
			}

			// Draw connector
			var entryPoint = EntryAnchor.GetPoint(chartControl, ChartPanel, chartScale);
			var exitPoint = ExitAnchor.GetPoint(chartControl, ChartPanel, chartScale);
			var brush = (TradeDirection == MarketPosition.Long) == (EntryAnchor.Price < ExitAnchor.Price) ? WinningConnectorBrush : LosingConnectorBrush;
			var connectorStroke = new Stroke(brushCache[brush.ARC_QuickTester_GetColor().ARC_QuickTester_WithAlpha(Opacity / 100)], DashStyleHelper.Solid, 3) { RenderTarget = RenderTarget };
			RenderTarget.DrawLine(entryPoint.ToVector2(), exitPoint.ToVector2(), connectorStroke.BrushDX, connectorStroke.Width, connectorStroke.StrokeStyle);
			UpdateProfitText(chartControl, ChartPanel, chartScale);
			connectorStroke.BrushDX.Dispose();

			// Draw marker dots on our entry and exit
			var entryExitDotRadius = Math.Min(15, BarWidth <= 8 ? (float)BarWidth : (float)BarWidth * 0.75f);
			for (var i = 0; i < 2; i++)
				using (var fillBrush = GetFillDxBrush(chartControl, i == 0 ? EntryMarkerBrush : ExitMarkerBrush, Opacity))
					RenderTarget.ARC_QuickTester_DrawDot((i == 0 ? EntryAnchor : ExitAnchor).GetPoint(chartControl, ChartPanel, chartScale), entryExitDotRadius, fillBrush);

			// If our entry and exits aren't on the same bar, draw MAE and MFE markers
			if (EntryAnchor.Time == ExitAnchor.Time)
				return;

			for (var i = 0; i < 2; i++)
			{
				var anchor = i == 0 ? mfeAnchor : maeAnchor;
				if (anchor == null)
					continue;

				if (anchor.Time == EntryAnchor.Time || anchor.Time == ExitAnchor.Time)
					continue;

				using (var vBrush = GetStrokeDxBrush(chartControl, i == 0 ? MfeBrush : MaeBrush, Opacity, 5, DashStyleHelper.Solid))
					RenderTarget.ARC_QuickTester_DrawV(anchor.GetPoint(chartControl, ChartPanel, chartScale), maeMfeAndArrowWidth, vBrush, (i == 0) == (TradeDirection == MarketPosition.Long));
			}
		}
		#endregion

		[Display(Order = 0)]
		public ChartAnchor EntryAnchor { get; set; }

		[Display(Order = 1)]
		public ChartAnchor InitialStopLossAnchor { get; set; }

		[Display(Order = 2)]
		public ChartAnchor ExitAnchor { get; set; }

		#region Display Parameters
		public const string DisplayParametersGroupName = "Parameters (Display)";

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "MFE Color", GroupName = DisplayParametersGroupName, Order = 0)]
		public Brush MfeBrush { get; set; }

		[Browsable(false)]
		public string MfeBrushSerializable
		{
			get { return Serialize.BrushToString(MfeBrush); }
			set { MfeBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "MAE Color", GroupName = DisplayParametersGroupName, Order = 1)]
		public Brush MaeBrush { get; set; }

		[Browsable(false)]
		public string MaeBrushSerializable
		{
			get { return Serialize.BrushToString(MaeBrush); }
			set { MaeBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Winning Trade Line Color", GroupName = DisplayParametersGroupName, Order = 2)]
		public Brush WinningConnectorBrush { get; set; }

		[Browsable(false)]
		public string WinningConnectorBrushSerializable
		{
			get { return Serialize.BrushToString(WinningConnectorBrush); }
			set { WinningConnectorBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Losing Trade Line Color", GroupName = DisplayParametersGroupName, Order = 3)]
		public Brush LosingConnectorBrush { get; set; }

		[Browsable(false)]
		public string LosingConnectorBrushSerializable
		{
			get { return Serialize.BrushToString(LosingConnectorBrush); }
			set { LosingConnectorBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Stop Loss Color", GroupName = DisplayParametersGroupName, Order = 4)]
		public Brush StopLossBrush { get; set; }

		[Browsable(false)]
		public string StopLossBrushSerializable
		{
			get { return Serialize.BrushToString(StopLossBrush); }
			set { StopLossBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Stop Loss Connector Color", GroupName = DisplayParametersGroupName, Order = 5)]
		public Brush StopLossConnectorBrush { get; set; }

		[Browsable(false)]
		public string StopLossConnectorBrushSerializable
		{
			get { return Serialize.BrushToString(StopLossConnectorBrush); }
			set { StopLossConnectorBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Entry Marker Color", GroupName = DisplayParametersGroupName, Order = 6)]
		public Brush EntryMarkerBrush { get; set; }

		[Browsable(false)]
		public string EntryMarkerBrushSerializable
		{
			get { return Serialize.BrushToString(EntryMarkerBrush); }
			set { EntryMarkerBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Exit Marker Color", GroupName = DisplayParametersGroupName, Order = 7)]
		public Brush ExitMarkerBrush { get; set; }

		[Browsable(false)]
		public string ExitMarkerBrushSerializable
		{
			get { return Serialize.BrushToString(ExitMarkerBrush); }
			set { ExitMarkerBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Label Brush", GroupName = DisplayParametersGroupName, Order = 8)]
		public Brush LabelBrush { get; set; }

		[Browsable(false)]
		public string LabelBrushSerializable
		{
			get { return LabelBrush == null ? "" : Serialize.BrushToString(LabelBrush); }
			set { LabelBrush = string.IsNullOrWhiteSpace(value) ? null : Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Long Entry Arrow Brush", GroupName = DisplayParametersGroupName, Order = 9)]
		public Brush LongEntryArrowBrush { get; set; }

		[Browsable(false)]
		public string LongEntryArrowBrushSerializable
		{
			get { return LongEntryArrowBrush == null ? "" : Serialize.BrushToString(LongEntryArrowBrush); }
			set { LongEntryArrowBrush = string.IsNullOrWhiteSpace(value) ? null : Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Short Entry Arrow Brush", GroupName = DisplayParametersGroupName, Order = 10)]
		public Brush ShortEntryArrowBrush { get; set; }

		[Browsable(false)]
		public string ShortEntryArrowBrushSerializable
		{
			get { return ShortEntryArrowBrush == null ? "" : Serialize.BrushToString(ShortEntryArrowBrush); }
			set { ShortEntryArrowBrush = string.IsNullOrWhiteSpace(value) ? null : Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[Range(1, 100)]
		[Display(Name = "Opacity", GroupName = DisplayParametersGroupName, Order = 9)]
		public float Opacity { get; set; }
		#endregion
	}
}
