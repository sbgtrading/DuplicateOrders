#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace SBG
{
		#region -- TradeManager --
		//==============================================
		public class TradeManager
		{
			public int AlertBar = 0;
			private Instrument instrument;
			private int StartTOD = 0;
			private int StopTOD = 0;
			private int GoFlatTOD = 0;
			private IndicatorBase indi;
			public List<string> Output = new List<string>();
			private string StrategyName = "";
			private string Comment = "";
			private bool ShowHrOfDayTable = false;
			public bool IsInSession = false;
			public int FirstAbarOfSession = 0;
			public TradeManager(IndicatorBase Indi, string strategyName, string comment, Instrument Inst, string sDaysOfWeek, int startAt, int stopAt, int goFlatAt, bool showHrOfDayTable){
				StrategyName = strategyName;
				Comment = comment;
				ShowHrOfDayTable = showHrOfDayTable;
				instrument = Inst;
				indi = Indi;
				StartTOD = startAt;
				StopTOD = stopAt;
				GoFlatTOD = goFlatAt;
				var sU = sDaysOfWeek.ToUpper();
				if(sU=="TODAY") DOW.Add(DateTime.Now.DayOfWeek);
				else{
					if(sU.Contains("M")  || sU.Contains("ALL")) DOW.Add(DayOfWeek.Monday);
					if(sU.Contains("TU") || sU.Contains("ALL")) DOW.Add(DayOfWeek.Tuesday);
					if(sU.Contains("W")  || sU.Contains("ALL")) DOW.Add(DayOfWeek.Wednesday);
					if(sU.Contains("TH") || sU.Contains("ALL")) DOW.Add(DayOfWeek.Thursday);
					if(sU.Contains("F")  || sU.Contains("ALL")) DOW.Add(DayOfWeek.Friday);
					if(sU.Contains("SA") || sU.Contains("ALL")) DOW.Add(DayOfWeek.Saturday);
					if(sU.Contains("SU") || sU.Contains("ALL")) DOW.Add(DayOfWeek.Sunday);
				}
			}
			public List<DayOfWeek> DOW = new List<DayOfWeek>();
			public DateTime DTofLastLong = DateTime.MinValue;
			public DateTime DTofLastShort = DateTime.MinValue;
			public SortedDictionary<int, List<double>> TradeTimes = new SortedDictionary<int, List<double>>(); //this contains the PnL for each timeslice, can be used on chart to assign a quality grade each 30-min time period
			public class info{
				public char Pos = ' ';
				public double EntryPrice = 0;
				public double ExitPrice  = 0;
				public double SL = 0;
				public double TP = 0;
				public double MaxPriceHigh = 0;
				public double MinPriceLow = 0;
				public double PnLPoints   = double.MinValue;
				public DateTime EntryDT   = DateTime.MinValue;
				public DateTime ExitDT    = DateTime.MinValue;
				public string Disposition = "";
				public info (char pos, double ep, DateTime et, double sl, double tp){
					Pos = pos;
					EntryPrice = ep;
					EntryDT = et;
					SL = sl;
					TP = tp;
					MaxPriceHigh = ep;
					MinPriceLow = ep;
					//NinjaTrader.Code.Output.Process(string.Format("{0} - {1}  e{2}  sl{3}  tp{4}",et.ToString(), Pos, ep, SL, TP), PrintTo.OutputTab1);
				}
			}
			public bool ResultsPrinted = false;
			public List<info> Trades = new List<info>();
			private int ToTime(DateTime dt){
				return dt.Hour*100 + dt.Minute;
			}
			public void ExitforEOD(DateTime t0, DateTime t1, double ClosePrice){
				if(Trades.Count==0) return;
				var tt0 = ToTime(t0);
				var tt1 = ToTime(t1);
				if(tt1 < GoFlatTOD && tt0 >= GoFlatTOD || t0.Day!=t1.Day){
					foreach(var trade in Trades.Where(k=>k.PnLPoints==double.MinValue)){
						trade.ExitPrice = ClosePrice;
						trade.ExitDT = t1;
						trade.Disposition = "EOD";
						if(trade.Pos == 'L')      trade.PnLPoints = trade.ExitPrice - trade.EntryPrice;
						else if(trade.Pos == 'S') trade.PnLPoints = trade.EntryPrice - trade.ExitPrice;
						montecarlo.AddToTODList(trade.EntryDT, trade.PnLPoints);
					}
				}
			}
			public void ExitforSLTP(DateTime t0, double H, double L, bool PermitEntryExitOnSameBar){
				if(Trades.Count==0) return;
				foreach(var trade in Trades.Where(k=>k.PnLPoints==double.MinValue)){
					if(trade.EntryDT == t0 && !PermitEntryExitOnSameBar) continue;
					if(trade.Pos == 'L'){
						if(H > trade.TP){
							trade.ExitPrice = trade.TP;
							trade.PnLPoints = trade.ExitPrice - trade.EntryPrice;
							trade.ExitDT = t0;
							trade.Disposition = "TP";
							montecarlo.AddToTODList(trade.EntryDT, trade.PnLPoints);
						}
						else if(L < trade.SL){
							trade.ExitPrice = trade.SL;
							trade.PnLPoints = trade.ExitPrice - trade.EntryPrice;
							trade.ExitDT = t0;
							trade.Disposition = "SL";
							montecarlo.AddToTODList(trade.EntryDT, trade.PnLPoints);
						}
					}
					else if(trade.Pos == 'S'){
						if(L < trade.TP){
							trade.ExitPrice = trade.TP;
							trade.PnLPoints = trade.EntryPrice - trade.ExitPrice;
							trade.ExitDT = t0;
							trade.Disposition = "TP";
							montecarlo.AddToTODList(trade.EntryDT, trade.PnLPoints);
						}
						else if(H > trade.SL){
							trade.ExitPrice = trade.SL;
							trade.PnLPoints = trade.EntryPrice - trade.ExitPrice;
							trade.ExitDT = t0;
							trade.Disposition = "SL";
							montecarlo.AddToTODList(trade.EntryDT, trade.PnLPoints);
						}
					}
				}
			}

			private MonteCarloEngine montecarlo = new MonteCarloEngine();
			#region -- Monte Carlo --
			private class MonteCarloEngine{
				public SortedDictionary<int, List<double>> PnLByTOD = new SortedDictionary<int, List<double>>();//TOD is time of day in 30-minute sections
				public void AddToTODList(DateTime tod, double pnl, bool InZone=false){
					int t = 0;
					if(tod.Minute<30) t = tod.Hour*100;
					else t = tod.Hour*100+30;
//NinjaTrader.Code.Output.Process(string.Format("{0} added TODList {1} ", t, pnl), PrintTo.OutputTab1);
					if(!PnLByTOD.ContainsKey(t)) PnLByTOD[t] = new List<double>(){pnl};
					else PnLByTOD[t].Add(pnl);
					if(InZone) NinjaTrader.Code.Output.Process(string.Format("{0} added TODList  {1}  {2}", tod.ToString(), t, pnl), PrintTo.OutputTab1);
				}
				public void DoMonteCarlo(int BatchesCount, double PctOfTradesPerBatch, double PV, List<string> Output){
					var distribution = new List<double>();
					var r = new Random();
		
					var pnl_table = new List<double>();
					var list = PnLByTOD.SelectMany(k=> k.Value).ToList();
					int samples = Convert.ToInt32(list.Count * PctOfTradesPerBatch);
					for(int batch = 0; batch< BatchesCount; batch++){
						var randoms = Enumerable.Range(0, list.Count-1).OrderBy(_ => r.Next()).Take(samples).ToList();//guarantees unique random numbers in this list
						pnl_table.Clear();//calc the PnL for each batch of samples...100 batches
						for(int i = 0;i<randoms.Count; i++){//number of samples is list.Count/2
							int idx = Convert.ToInt32(randoms[i]);
							pnl_table.Add(list[idx]);

//	NinjaTrader.Code.Output.Process("***************************   List["+idx+"] was "+list[idx], PrintTo.OutputTab1);
						}
						distribution.Add(pnl_table.Sum());
					}
					var winning_iterations = distribution.Count(k=>k>0);
					var PrintString = "\n";
					Output.Add("-----");

					var s = "Monte Carlo Analysis";
					PrintString = PrintString + s + Environment.NewLine;
					Output.Add(s);
					
					s = string.Format(" ({0}-sims, Trades {1} taking {2}-samples/sim)", BatchesCount, list.Count, samples);
					PrintString = PrintString + s + Environment.NewLine;
					Output.Add(s+"{fontsize8}");
					
					s = string.Format(" {0} probability of a positive PnL", (winning_iterations*1.0/distribution.Count).ToString("0%"));
					PrintString = PrintString + s + Environment.NewLine;
					Output.Add(s);

					s = "";
					PrintString = PrintString + s + Environment.NewLine;
					Output.Add(s);

					s = string.Format("Worst PnL:  {0}   Best: {1}  Avg: {2}  Median: {3}", (Math.Round(distribution.Min()*PV,0)).ToString("C"), (Math.Round(distribution.Max()*PV,0)).ToString("C"), Math.Round(PV*distribution.Average(),0).ToString("C"), Math.Round(PV*distribution[distribution.Count/2],0).ToString("C")).Replace(".00",string.Empty);
					PrintString = PrintString + s + Environment.NewLine;
					Output.Add(s+"{fontsize8}");
					NinjaTrader.Code.Output.Process(PrintString, PrintTo.OutputTab1);
				}
			}
			#endregion
			private DateTime CalendarDay = DateTime.MinValue;
			#region -- supporting methods --
//			private void Print(string s){
//				NinjaTrader.Code.Output.Process(s, PrintTo.OutputTab1);
//			}
			private string ToCurrency(double c){
				if(Math.Abs(c)>10) c = Math.Round(c);
				var s = c.ToString("C");
				return s.Replace(".00",string.Empty);
			}
			private int TradableDaysCount = 0;
			public bool IsValidTimeAndDay(char Dir, DateTime t0, DateTime t1, int CurrentBar){
				bool result = false;
				if(CalendarDay != t0.Date && DOW.Contains(t0.DayOfWeek)) {CalendarDay=t0.Date; TradableDaysCount++;}
				if(StartTOD!=StopTOD){
					int tt0 = ToTime(t0);
					int tt1 = ToTime(t1);
					if(StartTOD < StopTOD){
						if(tt0 < StartTOD || tt0 >= StopTOD) {IsInSession=false; return false;}
					}else{
						if(tt0 < StartTOD && tt0 >= StopTOD) {IsInSession=false; return false;}
					}
				}
				if(Dir=='L'){
					if(DTofLastLong.Day == t0.Day) {IsInSession=false; return false;}
					result = DOW.Contains(t0.DayOfWeek) && DTofLastLong.Day!= t0.Day;
				}else{
					if(DTofLastShort.Day == t0.Day) {IsInSession=false; return false;}
					result = DOW.Contains(t0.DayOfWeek) && DTofLastShort.Day!= t0.Day;
				}
				if(result==true && IsInSession==false){
					IsInSession = true;
					FirstAbarOfSession = CurrentBar;
				}
				return result;
			}
			public void UpdateMinMaxPrices(double H, double L){
				foreach(var t in Trades.Where(k=>k.ExitPrice==0)){
					t.MaxPriceHigh = Math.Max(H, t.MaxPriceHigh);
					t.MinPriceLow = Math.Min(L, t.MinPriceLow);
				}
			}
			public void UpdateMinMaxPrices(info T, double H, double L){
				T.MaxPriceHigh = Math.Max(H, T.MaxPriceHigh);
				T.MinPriceLow = Math.Min(L, T.MinPriceLow);
			}
			#endregion
			private void Print(string s){ indi.Print(s);}
			public void PrintResults(int BarsCount, int CurrentBar, NinjaTrader.NinjaScript.IndicatorBase context){
				#region -- PrintResults --
				if(CurrentBar > BarsCount-3 && !this.ResultsPrinted){
					Output.Clear();
					this.ResultsPrinted = true;
					if(this.Trades.Count==0){ Output.Add("No trades taken"); Print("No trades taken"); return;}
					string s = StrategyName+" strategy results for: "+instrument.MasterInstrument.Name;
					Output.Add(s);
					Print(s);
					if(Comment != ""){
						Output.Add(Comment+"{fontsize8}");
						Print(Comment);
					}
					double pnl = 0;
					double wins = 0;
					double losses = 0;
//					int TPhit = 0;
//					int SLhit = 0;
					var DatesOfTrades = new SortedDictionary<DateTime,  List<double>>();
					var DOWOfTrades   = new SortedDictionary<DayOfWeek, List<double>>();

					int LongWinCount = 0;
					int ShortWinCount = 0;
					int LongCount = 0;
					int ShortCount = 0;
					double LongWinPts = 0;
					double ShortWinPts = 0;
					double LongLossPts = 0;
					double ShortLossPts = 0;
					double LongPnL = 0;
					double ShortPnL = 0;
					List<double> MFELongs = new List<double>();
					List<double> MAELongs = new List<double>();
					List<double> MFEShorts = new List<double>();
					List<double> MAEShorts = new List<double>();
					foreach(var t in Trades){
						if(t.ExitDT == DateTime.MinValue) continue;
						pnl = pnl + t.PnLPoints;
						if(t.Pos=='L'){
							MFELongs.Add(t.MaxPriceHigh-t.EntryPrice);
							MAELongs.Add(t.EntryPrice-t.MinPriceLow);
						}else{
							MFEShorts.Add(t.EntryPrice-t.MinPriceLow);
							MAEShorts.Add(t.MaxPriceHigh-t.EntryPrice);
						}
						if(t.PnLPoints>0){
							wins++;
							if(t.Pos=='L') {LongCount++; LongWinCount++; LongWinPts += t.PnLPoints; LongPnL += t.PnLPoints; }
							if(t.Pos=='S') {ShortCount++; ShortWinCount++; ShortWinPts += t.PnLPoints; ShortPnL += t.PnLPoints; }
						}
						else{
							losses++;
							if(t.Pos=='L') {LongCount++; LongLossPts += t.PnLPoints; LongPnL+= t.PnLPoints; }
							if(t.Pos=='S') {ShortCount++; ShortLossPts += t.PnLPoints; ShortPnL += t.PnLPoints; }
						}
						int hr = t.EntryDT.Hour*100 + (t.EntryDT.Minute<30 ? 0:30);
						if(!TradeTimes.ContainsKey(hr)) TradeTimes[hr] = new List<double>(){t.PnLPoints};
						else TradeTimes[hr].Add(t.PnLPoints);
						if(!DatesOfTrades.ContainsKey(t.EntryDT.Date)) DatesOfTrades[t.EntryDT.Date] = new List<double>(){t.PnLPoints};
						else DatesOfTrades[t.EntryDT.Date].Add(t.PnLPoints);
						if(!DOWOfTrades.ContainsKey(t.EntryDT.DayOfWeek)) DOWOfTrades[t.EntryDT.DayOfWeek] = new List<double>(){t.PnLPoints};
						else DOWOfTrades[t.EntryDT.DayOfWeek].Add(t.PnLPoints);
	
						if(true){
							Draw.Line(context, 
								string.Format("{0} {1} {2}",t.EntryDT.DayOfWeek.ToString().Substring(0,3),t.EntryDT.ToShortDateString(),t.EntryDT.ToShortTimeString()),
								false, t.EntryDT, t.EntryPrice, t.ExitDT, t.ExitPrice, (t.PnLPoints>0 ? Brushes.Lime:Brushes.Magenta), DashStyleHelper.Dash, 2);
						}
//						if(t.ExitPrice == t.TP) TPhit++;
//						if(t.ExitPrice == t.SL) SLhit++;
						s = t.EntryDT.ToString()+"   "+t.Pos+":  "+(t.PnLPoints>0?"+":"")+instrument.MasterInstrument.FormatPrice(t.PnLPoints)+" pts,  total: "+instrument.MasterInstrument.FormatPrice(pnl)+"    "+wins+"/"+losses+"   Disposition: "+t.Disposition;
						Print(s);
					}
					double PV = instrument.MasterInstrument.PointValue;
					Output.Add(""); Print("");
					s = string.Format("Total {0} on {1}-trades   Avg trade {2} PF: {3}", ToCurrency(pnl*PV), Trades.Count, ToCurrency(PV*pnl/Trades.Count), (-(LongWinPts+ShortWinPts)/(LongLossPts+ShortLossPts)).ToString("0.0"));
					Output.Add(s); Print(s);
					s = string.Format("{0}-tradable days,  Avg Trades/day: {1}", TradableDaysCount, (Trades.Count*1.0/TradableDaysCount).ToString("0.0"));
					Output.Add(s+"{fontsize8}"); Print(s);
					s = string.Format("w/l: {0}|{1}  {2}", wins, losses, (wins / Trades.Count).ToString("0%"), Trades.Count);
					Output.Add(s); Print(s);
					if(LongCount>0){
						MFELongs.Sort();
						double mfemedian = MFELongs[MFELongs.Count/2];
						MAELongs.Sort();
						double maemedian = MAELongs[MAELongs.Count/2];
						s = string.Format("Longs:  {0}|{1}  {2}   Avg: {3}  PF: {4}   mae: {5}  mfe: {6}", LongWinCount, (LongCount-LongWinCount), (LongWinCount*1.0 / LongCount).ToString("0%"), ToCurrency(PV*LongPnL/LongCount), (-(LongWinPts)/(LongLossPts)).ToString("0.0"), ToCurrency(PV*maemedian), ToCurrency(PV*mfemedian));
						Output.Add(s+(s.Contains("($")?"{red}":"{lime}")); Print(s);
					}
					if(ShortCount>0){
						MFEShorts.Sort();
						double mfemedian = MFEShorts[MFEShorts.Count/2];
						MAEShorts.Sort();
						double maemedian = MAEShorts[MAEShorts.Count/2];
						s = string.Format("Shorts:  {0}|{1}  {2}   Avg: {3}  PF: {4}   mae: {5}  mfe: {6}", ShortWinCount, (ShortCount-ShortWinCount), (ShortWinCount*1.0 / ShortCount).ToString("0%"), ToCurrency(PV*ShortPnL/ShortCount), (-(ShortWinPts)/(ShortLossPts)).ToString("0.0"), ToCurrency(PV*maemedian), ToCurrency(PV*mfemedian));
						Output.Add(s+(s.Contains("($")?"{red}":"{lime}")); Print(s);
					}
					if(DatesOfTrades.Count>0) {
						Output.Add(""); Print("");
						s = "Avg $/day: "+ToCurrency(pnl*PV/DatesOfTrades.Count);
						if(s.Contains("($"))
							Output.Add(s+"{red}");
						else
							Output.Add(s+"{lime}");
						Print(s);
						Output.Add(""); Print("");
					}
					if(ShowHrOfDayTable && TradeTimes!=null && TradeTimes.Count>0){
						Output.Add("-----"); Print("");
						s = "Hr of day for entry";
						Output.Add(s); Print(s);
						s = "Example: '930' means the trade was entered between 9:30 and 9:59";
						Output.Add(s+"{fontsize8}"); Print(s);
						foreach(var tt in TradeTimes){
							double sum = tt.Value.Sum();
							wins = tt.Value.Count(k=>k>0);
							losses = tt.Value.Count-wins;
							s = string.Format("{0}:   {1}  {2}-win   {3}|{4}", tt.Key, ToCurrency(sum*PV), (wins / tt.Value.Count).ToString("0%"), wins, losses);
							tt.Value.Clear();
							tt.Value.Add(sum);//the list is cleared out, and the PnL for this timeslice is put in its place
							if(s.Contains("($"))
								Output.Add(s+"{fontsize8}{red}");
							else
								Output.Add(s+"{fontsize8}{lime}");
							Print(s);
						}
					}
	//				Print("\nBy Date");
	//				foreach(var tt in DatesOfTrades){
	//					Print(tt.Key.ToShortDateString()+"   PnL: "+ToCurrency(tt.Value.Sum()*PV)+"   "+(tt.Value.Count(k=>k>0)*1.0/tt.Value.Count).ToString("0%"));
	//				}
					if(DOWOfTrades!=null && DOWOfTrades.Count>0){
						Output.Add("-----"); Print("");
						s = "By Day of week  from "+this.StartTOD+" to "+this.StopTOD+", go flat at "+this.GoFlatTOD;
						Output.Add(s); Print(s);
						foreach(var tt in DOWOfTrades){
							wins = tt.Value.Count(k=>k>0);
							losses = tt.Value.Count-wins;
							s = string.Format("{0}  PnL: {1}   {2}  {3}|{4}", tt.Key.ToString().Substring(0,3), ToCurrency(tt.Value.Sum()*PV), (tt.Value.Count(k=>k>0)*1.0/tt.Value.Count).ToString("0%"), wins, losses);
							if(s.Contains("($"))
								Output.Add(s+"{fontsize8}{red}");
							else
								Output.Add(s+"{fontsize8}{lime}");
							Print(s);
						}
					}

					montecarlo.DoMonteCarlo(100, 0.5, PV, Output);
					DatesOfTrades.Clear();
					DOWOfTrades.Clear();
					TradeTimes.Clear();
					MFELongs.Clear();
					MAELongs.Clear();
					MFEShorts.Clear();
					MAEShorts.Clear();
					montecarlo.PnLByTOD.Clear();
				}
				#endregion
			}

			public Dictionary<System.Windows.Media.Brush, SharpDX.Direct2D1.Brush> BrushesDX = new Dictionary<System.Windows.Media.Brush, SharpDX.Direct2D1.Brush>();
			public void InitializeBrushes(SharpDX.Direct2D1.RenderTarget RenderTarget){
				if(!BrushesDX.ContainsKey(Brushes.Lime))   BrushesDX[Brushes.Lime] = null;
				if(!BrushesDX.ContainsKey(Brushes.Red))     BrushesDX[Brushes.Red] = null;
				if(!BrushesDX.ContainsKey(Brushes.Magenta)) BrushesDX[Brushes.Magenta] = null;
				if(!BrushesDX.ContainsKey(Brushes.Cyan))    BrushesDX[Brushes.Cyan] = null;
				if(!BrushesDX.ContainsKey(Brushes.Black))   BrushesDX[Brushes.Black] = null;
				foreach(var b in BrushesDX.Keys.ToList()){
					if(BrushesDX[b]!=null && !BrushesDX[b].IsDisposed) BrushesDX[b].Dispose();
					if(RenderTarget !=null) BrushesDX[b] = b.ToDxBrush(RenderTarget);
					else BrushesDX[b] = null;
				}
			}
			public void OnRender(SharpDX.Direct2D1.RenderTarget RenderTarget, NinjaTrader.Gui.Chart.ChartPanel ChartPanel, int LargeFontSize, int SmallFontSize){
				float x = 10f;
				float y = 25f;
				var txtFormat14 = new NinjaTrader.Gui.Tools.SimpleFont("Arial", LargeFontSize).ToDirectWriteTextFormat();
				#region -- Print Time before we start --
				var now = DateTime.Now;
				if(!DOW.Contains(now.DayOfWeek)){
					x = Convert.ToSingle(ChartPanel.W/2);
					y = Convert.ToSingle(ChartPanel.H/2);
					var s = "Wrong day of week...update/change your 'Days of week' parameter";
					var txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, s, txtFormat14, (float)(ChartPanel.X + ChartPanel.W), txtFormat14.FontSize);
					var labelRect = new SharpDX.RectangleF(x-4f, y-4f, txtLayout.Metrics.Width+16f, txtFormat14.FontSize + 9f);
					RenderTarget.FillRectangle(labelRect, BrushesDX[Brushes.Black]);
					RenderTarget.DrawText(s, txtFormat14, labelRect, BrushesDX[Brushes.Red]);
				}else{
					var hr = StartTOD/100; var min = StartTOD-hr*100; var futureStartTOD = new DateTime(now.Year,now.Month,now.Day,hr,min,0);
					var ts = new TimeSpan(futureStartTOD.Ticks-now.Ticks);
					if(ts.TotalSeconds>0) {
						x = Convert.ToSingle(ChartPanel.W/2);
						y = Convert.ToSingle(ChartPanel.H/2);
						var s = string.Format("{0} until start {1}", ts.ToString("hh':'mm':'ss"), futureStartTOD.ToShortTimeString());
						var txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, s, txtFormat14, (float)(ChartPanel.X + ChartPanel.W), txtFormat14.FontSize);
						var labelRect = new SharpDX.RectangleF(x-4f, y-4f, txtLayout.Metrics.Width+16f, txtFormat14.FontSize + 9f);
						RenderTarget.FillRectangle(labelRect, BrushesDX[Brushes.Black]);
						RenderTarget.DrawText(s, txtFormat14, labelRect, BrushesDX[Brushes.Cyan]);
					}
				}
				#endregion
				var txtFormat8 = new NinjaTrader.Gui.Tools.SimpleFont("Arial", SmallFontSize).ToDirectWriteTextFormat();
				x = 10f;
				y = 25f;
				var Color = 'B';
				string L = "";
				foreach(var line in Output){
					Color = 'B';
					L = line.Replace("{fontsize8}","");
					if(L.Contains("{red}")) {Color = 'R'; L = L.Replace("{red}","");}
					else if(L.Contains("{lime}")) {Color = 'G'; L = L.Replace("{lime}","");}
					if(line=="" || line.CompareTo(Environment.NewLine)==0){
						y = y + txtFormat8.FontSize/2f;
					}else if(line.Contains("{fontsize8}")){
						var txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, L, txtFormat8, (float)(ChartPanel.X + ChartPanel.W), txtFormat8.FontSize);
						var labelRect = new SharpDX.RectangleF(x-4f, y-4f, txtLayout.Metrics.Width+16f, txtFormat8.FontSize + 9f);
						RenderTarget.FillRectangle(labelRect, BrushesDX[Brushes.Black]);
						labelRect.X = x;
						labelRect.Y = y;
						RenderTarget.DrawText(L, txtFormat8, labelRect, Color=='B'? BrushesDX[Brushes.Cyan] : (Color=='R' ? BrushesDX[Brushes.Magenta] : BrushesDX[Brushes.Lime]));
						y = y + txtFormat8.FontSize+8f;
					}else{
						var txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, L, txtFormat14, (float)(ChartPanel.X + ChartPanel.W), txtFormat14.FontSize);
						var labelRect = new SharpDX.RectangleF(x-4f, y-4f, txtLayout.Metrics.Width+16f, txtFormat14.FontSize + 9f);
						RenderTarget.FillRectangle(labelRect, BrushesDX[Brushes.Black]);
						labelRect.X = x;
						labelRect.Y = y;
						RenderTarget.DrawText(L, txtFormat14, labelRect, Color=='B'? BrushesDX[Brushes.Cyan] : (Color=='R' ? BrushesDX[Brushes.Magenta] : BrushesDX[Brushes.Lime]));
						y = y + txtFormat14.FontSize+8f;
					}
				}
			}
		}
		//==============================================
		#endregion
}
































































































































