#define DoLicense
#define MODERATORS
//#define STOCKS_PROGRAM

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using SharpDX.DirectWrite;
#endregion

#region -- Author / Infos version --
/*********************************************************************
************************* Golden Zone Trading ************************
**********************************************************************
* (c) 2014 All Right Reserved
* Authors NT7 : ?
* Author NT8 : Kriss { AzurITec }
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
v1.000  - 11.04.2016    + Conversion from NT7 to NT8b10 "as is".
----------------------------------------------------------------------
v1.001  - 12.04.2016    + Change Default Settings
                        + Put the box in OnRender for custom sizing. Pb with Indicator Name overlay if using Draw.TextFixed function
----------------------------------------------------------------------
v1.002  - 12.04.2016    + Code Optimized for infinite instrument but not possible with UI
                        + Added 16 X so far
----------------------------------------------------------------------
v1.003  - 25.05.2016    + Beta11 code breaking change with FormatPriceMarker Method
----------------------------------------------------------------------
v1.004  - 05.09.2016    + Compatible Beta13 RC1
----------------------------------------------------------------------
v1.005  - 07.12.2016    + Compatible 8.0.0.1
                        + Bug Fix : Plot are Flat due to Calculate.OnEachTick => Set to OnBarClose
----------------------------------------------------------------------
v1.01   - 28.02.2017    + Tested with 8.0.4.0
----------------------------------------------------------------------
v1.02   - 15.01.2018    + Added InstList array for better formatting of text box and price markers...removed the "##-##" from the output
                        + Added try-catch block around body of OnBarUpdate
----------------------------------------------------------------------
######################################################################
~~~~~~~~~~~~~~~~~~~~~~~~~ BUGS/ LIMITATIONS ~~~~~~~~~~~~~~~~~~~~~~~~~~
----------------------------------------------------------------------
*/
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    public enum StartTypeE { Session, ChartStart, Date }

	public class ARC_LeadersLaggers : Indicator
	{
		private bool IsDebug        = false;
		private bool ValidLicense   = false;
		private bool IsExpired      = true;

		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "LeadersLaggers";
#if !STOCKS_PROGRAM
		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "20020", "25900", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
				bool IsConnectionIssue = UserId.CompareTo("253729")==0 || MachineId.CompareTo("0DE7B460EE7C494980DC065DDE946572")==0;//Chris Zolton
				if(IsConnectionIssue) return true;
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

#endif
        private const string VERSION = "v1.3 8.Nov.2022";
		//1.1 introduced the Infusionsoft licensing system (transitioning away from the fixed license key system)
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

        #region -- Variables --
        private List<double> startingValues = new List<double>();
        SortedDictionary<int,double> valuesDict = new SortedDictionary<int,double>();
        
        private bool justStarted = true;
		private List<int> PlotsToSkip = new List<int>();
        
        private string leadingInstrument = "";
        private string laggingInstrument = "";

        private SimpleFont dataFont;
		private string[] InstList = new string[16]{"","","","","","","","","","","","","","","",""};
		#endregion
		SortedDictionary<int, List<double[]>> DailyRanges = new SortedDictionary<int,List<double[]>>();

		protected override void OnStateChange()
        {
            #region State.SetDefaults
            if (State == State.SetDefaults)
			{
				Description							= @"Leaders and Laggers - A market breadth indicator that identifies %Change and Market correlation.";
				Name								= "ARC_LeadersLaggers";
				Calculate							= Calculate.OnBarClose;
				BarsRequiredToPlot                  = 1;
				IsOverlay							= false;
				DisplayInDataBox					= true;
				DrawOnPricePanel					= false;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
				PaintPriceMarkers					= true;
				ScaleJustification					= ScaleJustification.Right;
				IsSuspendedWhileInactive			= true;

				AddPlot(new Stroke(Brushes.Red, 3),     PlotStyle.Line, "Plot1");
				AddPlot(new Stroke(Brushes.Blue, 3),    PlotStyle.Line, "Plot2");
				AddPlot(new Stroke(Brushes.Yellow, 3),  PlotStyle.Line, "Plot3");
				AddPlot(new Stroke(Brushes.Cyan, 3),    PlotStyle.Line, "Plot4");
				AddPlot(new Stroke(Brushes.Orange, 3),  PlotStyle.Line, "Plot5");
				AddPlot(new Stroke(Brushes.Black, 3),   PlotStyle.Line, "Plot6");
				AddPlot(new Stroke(Brushes.Fuchsia, 3), PlotStyle.Line, "Plot7");
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Line, "Plot8");
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Line, "Plot9");
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Line, "Plot10");
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Line, "Plot11");
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Line, "Plot12");
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Line, "Plot13");
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Line, "Plot14");
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Line, "Plot15");
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Line, "Plot16");

				AddLine(new Stroke(Brushes.Transparent), 0, "zero line");


				#region -- Default Settings -- 
				ShowBox = true;
				BoxColor = Brushes.Bisque;
				TextColor = Brushes.Black;
				OutlineColor = Brushes.Black;
				pATRperiod = 20;
				pATRbasis = false;

				InstList[1] = @"ES 06-23";
				InstList[2] = @"NQ 06-23";
				InstList[3] = @"";
				InstList[4] = @"";
				InstList[5] = @"";
				InstList[6] = @"";
				InstList[7] = @"";
				InstList[8] = @"";
				InstList[9] = @"";
				InstList[10] = @"";
				InstList[11] = @"";
				InstList[12] = @"";
				InstList[13] = @"";
				InstList[14] = @"";
				InstList[15] = @"";

				StartTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
				StartTime = StartTime.AddMonths(-1);
				StartType = StartTypeE.Session;
				DataFontSize = 12;

				#endregion
            }
            #endregion

            else if (State == State.Configure)
			{
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");
				#region DoLicense call
#if !STOCKS_PROGRAM
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
#endif
				#endregion
	            #region State.Configure
                try
                {
					InstList[0] = Instrument.FullName;
					for(int i=1; i<InstList.Length; i++){
						InstList[i] = InstList[i].Trim().ToUpper();
	                    if (InstList[i] != "") {
							AddDataSeries(InstList[i], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
							DailyRanges[i] = new List<double[]>();
    	                }else 
							AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
					}

//                    if (InstList[2].Trim() != "") AddDataSeries(InstList[2], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[3].Trim() != "") AddDataSeries(InstList[3], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[4].Trim() != "") AddDataSeries(InstList[4], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[5].Trim() != "") AddDataSeries(InstList[5], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[6].Trim() != "") AddDataSeries(InstList[6], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[7].Trim() != "") AddDataSeries(InstList[7], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[8].Trim() != "") AddDataSeries(InstList[8], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[9].Trim() != "") AddDataSeries(InstList[9], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[10].Trim() != "") AddDataSeries(InstList[10], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[11].Trim() != "") AddDataSeries(InstList[11], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[12].Trim() != "") AddDataSeries(InstList[12], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[13].Trim() != "") AddDataSeries(InstList[13], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[14].Trim() != "") AddDataSeries(InstList[14], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);

//                    if (InstList[15].Trim() != "") AddDataSeries(InstList[15], BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
//                    else AddDataSeries(Instrument.FullName, BarsPeriod.BarsPeriodType, BarsPeriod.BaseBarsPeriodValue);
                }
                catch
                {
                    //Log("Couldn't load data, remove NSLeaders_Laggers and try again", LogLevel.Alert);
                }
	            #endregion
                dataFont = new SimpleFont("Arial", DataFontSize);
            }
			else if(State == State.DataLoaded){
				//uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
			}
        }

        #region public override string FormatPriceMarker(double price)
        public override string FormatPriceMarker(double price)
        {
            try { for (int x = 0; x < Values.Length; x++) 
				if (price == Values[x].GetValueAt(Math.Min(ChartControl.LastSlotPainted, CurrentBars[0]))) return InstList[x].Replace("##-##",string.Empty);/*Instruments[x].FullName;*/ }
            catch { return "undefined"; }

            return Math.Round(price, 6).ToString();
        }
        #endregion

		bool newday = false;
        protected override void OnBarUpdate()
		{
	        #region protected override void OnBarUpdate()
#if !STOCKS_PROGRAM
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
#endif
			if (BarsInProgress != 0) return;
int line=221;
try{
            bool cantContinue = false;
            for (int i = 0; i < Plots.Count() - 1; i++) cantContinue = cantContinue || CurrentBars[i] <= 1;
line=225;
            if (CurrentBars[0] <= 5 || cantContinue)
            {
line=228;
                resetPlots();

line=231;
				Plots[0].Name = Instruments[0].MasterInstrument.Name;
                for (int i = 1; i < Plots.Count(); i++)
                {
//                  Plots[i].Width = 3;
                    if (Instruments[i].MasterInstrument.Name == InstList[0]) 
                        PlotsToSkip.Add(i);
                    else if (InstList[i]==string.Empty) 
                        PlotsToSkip.Add(i);
                    else if (Plots[i].Brush == Brushes.Transparent && Instruments[i].MasterInstrument.Name != Instrument.MasterInstrument.Name)
                        Plots[i].Brush = Brushes.Coral;
					if(InstList[i].Length>0)
						Plots[i].Name = Instruments[i].MasterInstrument.Name;
					else
						Plots[i].Name = "Plot"+i.ToString();
                }
                return;
            }

            if (justStarted)
            {
line=246;
                startingValues.Clear();
                for (int i = 0; i < Plots.Count(); i++) startingValues.Add(Opens[i][0]);
                justStarted = false;
				newday = true;
            }
            else if (StartType == StartTypeE.Session && Bars.IsFirstBarOfSession)
            {
line=253;
                startingValues.Clear();
                for (int i = 0; i < Plots.Count(); i++) startingValues.Add(Opens[i][0]);
                resetPlots();
				newday = true;
                return;
            }
            else if (StartType == StartTypeE.Date && ToDay(Time[0]) < ToDay(StartTime))
            {
line=261;
                startingValues.Clear();
                for (int i = 0; i < Plots.Count(); i++) startingValues.Add(Opens[i][0]);
                resetPlots();
				newday = true;
                return;
            }

line=268;
			if(pATRbasis && pATRperiod>0){
				#region -- Calculate the Daily ATR --
				if(newday){//create new lists in DailyRanges
					for (int i = 0; i < Plots.Count(); i++){
						double sum = 0;
						int j = 0;
						for(j = 0; j<pATRperiod; j++){//0th element is the most recent day, 1st element is the prior day...etc
							if(j>=DailyRanges[i].Count) break;
							sum = sum + DailyRanges[i][j][2];//sum up all of the ranges, which are the 3rd element in the array
						}
						DailyRanges[i][j][3] = sum/j;//calculate the sma(pATRperiod) of the ranges, put it into the 4th element in the array
						DailyRanges[i].Insert(0, new double[4]{Highs[i][0], Lows[i][0], Highs[i][0]-Lows[i][0], double.MinValue});
					}
					newday = false;
				}else{
					double h = 0;
					double l = 0;
					for (int i = 0; i < Plots.Count(); i++){
						h = Math.Max(DailyRanges[i][0][0], Highs[i][0]);
						l = Math.Min(DailyRanges[i][0][1], Lows[i][0]);
						DailyRanges[i][0][0] = h;
						DailyRanges[i][0][1] = l;
						DailyRanges[i][0][2] = h-l;
						DailyRanges[i][0][3] = double.MinValue;//this is the place where the current day pATRperiod-day average will be stored
					}
				}
				#endregion
			}
//            valuesList.Clear();
            for (int i = 0; i < Plots.Count(); i++)
            {
				if(startingValues[i]<=0) continue;
                valuesDict[i]=(Closes[i][0] - startingValues[i]) / startingValues[i];
				if(!PlotsToSkip.Contains(i)) {
					Values[i][0] = valuesDict[i];
//Print("Values["+i+"][0]: "+Values[i][0]);
				}
				else {
					Values[i].Reset(0);
					valuesDict[i] = double.MinValue;
				}
            }

line=276;
            if (ShowBox)
            {
				try{
	                int indexMax = valuesDict.Where(V => V.Value==valuesDict.Values.Max() && V.Value!=double.MinValue).Select(V => V.Key).First();
					//Print("Max: "+indexMax);
    	            leadingInstrument = string.Format("Leading: {0}", InstList[indexMax]);//Instruments[indexMax].FullName.Replace("##-##",string.Empty));
				}catch(Exception e1){Print("e1: "+e1.ToString());}
				try{
					double minval = Values[0][0];
					int indexMin = 0;
					foreach(var kvp in valuesDict){
						if(PlotsToSkip.Contains(kvp.Key)) continue;
						if(kvp.Value<minval) {
							minval = kvp.Value;
							indexMin = kvp.Key;
						}
					}
	                laggingInstrument = string.Format("Lagging: {0}", InstList[indexMin]);//Instruments[indexMin].FullName.Replace("##-##",string.Empty));
				}catch(Exception e2){Print("e2: "+e2.ToString());}
//                int indexMin = valuesDict.IndexOf(valuesDict.Values.Min());

            }
line=285;
}catch(Exception err){Print(line+":  "+err.ToString());}
	        #endregion
		}
        
        #region -- Misc --
        private void resetPlots()
        {
            Plot1[0] = 0;
            Plot2[0] = 0;
            Plot3[0] = 0;
            Plot4[0] = 0;
            Plot5[0] = 0;
            Plot6[0] = 0;
            Plot7[0] = 0;
            Plot8[0] = 0;
            Plot9[0] = 0;
            Plot10[0] = 0;
            Plot11[0] = 0;
            Plot12[0] = 0;
            Plot13[0] = 0;
            Plot14[0] = 0;
            Plot15[0] = 0;
            Plot16[0] = 0;
        }
        #endregion

		private SharpDX.Direct2D1.Brush outlineBrushDX, textBrushDX, boxBrushDX;
		public override void OnRenderTargetChanged()
		{
//try{
			#region -- OnRenderTargetChanged --
			if(outlineBrushDX!=null && !outlineBrushDX.IsDisposed) {outlineBrushDX.Dispose(); outlineBrushDX = null;}
			if(RenderTarget!=null) outlineBrushDX = OutlineColor.ToDxBrush(RenderTarget);

			if(textBrushDX!=null && !textBrushDX.IsDisposed) {textBrushDX.Dispose(); textBrushDX = null;}
			if(RenderTarget!=null) textBrushDX = TextColor.ToDxBrush(RenderTarget);

			if(boxBrushDX!=null && !boxBrushDX.IsDisposed) {boxBrushDX.Dispose(); boxBrushDX = null;}
			if(RenderTarget!=null) boxBrushDX = BoxColor.ToDxBrush(RenderTarget);
			#endregion
		}
        #region -- OnRender : Custom Drawing --
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
#if !STOCKS_PROGRAM
#if DoLicense
			if (!ValidLicense) return;
#endif
#endif
			if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            base.OnRender(chartControl, chartScale);

            SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

            #region -- Draw the Sentiment Box --
            if (ShowBox)
            {
				leadingInstrument = leadingInstrument.Replace(" ##-##",string.Empty);
				laggingInstrument = laggingInstrument.Replace(" ##-##",string.Empty);
                float maxStringWidth1 = getTextWidth(leadingInstrument, dataFont);
                float maxStringWidth2 = getTextWidth(laggingInstrument, dataFont);
                float maxStringWidth = Math.Max(maxStringWidth1, maxStringWidth2);

                double dataStringHeight = dataFont.Size;

                float x0 = ChartPanel.X + 0.5f * (float)dataStringHeight;
                float y0 = ChartPanel.Y + 2f * (float)dataStringHeight;
                float wMult = 0.14f;
                float x1 = x0 + (1+wMult) * maxStringWidth;
                float y1 = y0 + 4.5f * (float)dataStringHeight;

                //draw the box
				if(boxBrushDX!=null)
	                drawRectangle(x0, y0, (1+wMult) * maxStringWidth, 4.5f * (float)dataStringHeight, 25);

				if(outlineBrushDX!=null){
	                drawLine((double)x0, (double)x1, (double)y0, (double)y0, DashStyleHelper.Solid, 1);
    	            drawLine((double)x1, (double)x1, (double)y0, (double)y1, DashStyleHelper.Solid, 1);
        	        drawLine((double)x1, (double)x0, (double)y1, (double)y1, DashStyleHelper.Solid, 1);
            	    drawLine((double)x0, (double)x0, (double)y1, (double)y0, DashStyleHelper.Solid, 1);
				}

				if(textBrushDX!=null){
	                drawstring(leadingInstrument, x0 + wMult/2f * maxStringWidth, y0 + 1.00f * (float)dataStringHeight, dataFont, SharpDX.DirectWrite.TextAlignment.Leading);
    	            drawstring(laggingInstrument, x0 + wMult/2f * maxStringWidth, y0 + 2.50f * (float)dataStringHeight, dataFont, SharpDX.DirectWrite.TextAlignment.Leading);
				}
               
            }
            #endregion

            RenderTarget.AntialiasMode = oldAntialiasMode;
        }
        #endregion

        #region -- drawing functions { AzurITec } --
        //Draw Rectangle Region. x and y as pixel coordinate, w and h in pixel too.
        private void drawRectangle(double x, double y, double w, double h, double opacity)
        {
            drawRegion(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, opacity);
        }

        //Draw Region between 4 points. Coordinates are in pixel.
        private void drawRegion(Point[] points, double opacity)
        {
            //SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            boxBrushDX.Opacity = (float)opacity;

            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, boxBrushDX);
            geo1.Dispose();
            sink1.Dispose();
            //linebrush.Dispose();
        }

        //Draw a line between 2 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawLine(double val1, double val2, int idxslot1, int idxslot2, Brush couleur, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false)
        {
            SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            Point p0 = new Point(GetX0(idxslot1, chartControl), drawOnPricePanel ? 0 : ChartPanel.Y + chartScale.GetYByValueWpf(val1));
            Point p1 = new Point(GetX0(idxslot2, chartControl), drawOnPricePanel ? 0 : ChartPanel.Y + chartScale.GetYByValueWpf(val2));
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }
        //Draw a line between 2 points in pixel coordinates.        
        private void drawLine(double x1, double x2, double y1, double y2, DashStyleHelper dashstyle, int width)
        {
//            SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            Point p0 = new Point(x1, y1);
            Point p1 = new Point(x2, y2);
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), outlineBrushDX, width, strokestyle);

            //linebrush.Dispose();
            strokestyle.Dispose();
        }

        //Draw a text at {x;y} coordinates in pixel.
        private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                ) { TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
        }

        private float getTextWidth(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }

        //retrieve the x coordinate in pixel of a a relative bar index.
        private int GetX0(int bars, ChartControl chartControl) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars); }//NEW VERSION NT8
        #endregion

        #region -- Parameters --

        #region -- Info Box --
        [XmlIgnore]
        [Display(Name = "Box Color", GroupName = "Info Box", Description = "", Order = 1)]
        public Brush BoxColor { get; set; }
        [Browsable(false)]
        public string BoxColorSerialize
        {
            get { return Serialize.BrushToString(BoxColor); }
            set { BoxColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Text Color", GroupName = "Info Box", Description = "", Order = 2)]
        public Brush TextColor { get; set; }
        [Browsable(false)]
        public string TextColorSerialize
        {
            get { return Serialize.BrushToString(TextColor); }
            set { TextColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Outline Color", GroupName = "Info Box", Description = "", Order = 3)]
        public Brush OutlineColor { get; set; }
        [Browsable(false)]
        public string OutlineColorSerialize
        {
            get { return Serialize.BrushToString(OutlineColor); }
            set { OutlineColor = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Show Box?", GroupName = "Info Box", Description = "", Order = 0)]
        public bool ShowBox { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Fontsize", GroupName = "Info Box", Description = "Select fontsize for text which appears in the box", Order = 4)]
        public int DataFontSize { get; set; }
        #endregion

        #region -- Plots --

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot1 { get { return Values[0]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot2 { get { return Values[1]; } }
        
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot3 { get { return Values[2]; } }
        
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot4 { get { return Values[3]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot5 { get { return Values[4]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot6 { get { return Values[5]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot7 { get { return Values[6]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot8 { get { return Values[7]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot9 { get { return Values[8]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot10 { get { return Values[9]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot11 { get { return Values[10]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot12 { get { return Values[11]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot13 { get { return Values[12]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot14 { get { return Values[13]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot15 { get { return Values[14]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Plot16 { get { return Values[15]; } }
                
        #endregion

        #region -- Instruments --
        [Display(Name = "Inst2", GroupName = "Instruments", Description = "", Order = 0)]
        public string Inst1 { get {return InstList[1];} set{InstList[1]=value.Trim();} }

        [Display(Name = "Inst3", GroupName = "Instruments", Description = "", Order = 1)]
        public string Inst2 { get {return InstList[2];} set{InstList[2]=value.Trim();} }

        [Display(Name = "Inst4", GroupName = "Instruments", Description = "", Order = 2)]
        public string Inst3 { get {return InstList[3];} set{InstList[3]=value.Trim();} }

        [Display(Name = "Inst5", GroupName = "Instruments", Description = "", Order = 3)]
        public string Inst4 { get {return InstList[4];} set{InstList[4]=value.Trim();} }

        [Display(Name = "Inst6", GroupName = "Instruments", Description = "", Order = 4)]
        public string Inst5 { get {return InstList[5];} set{InstList[5]=value.Trim();} }

        [Display(Name = "Inst7", GroupName = "Instruments", Description = "", Order = 5)]
        public string Inst6 { get {return InstList[6];} set{InstList[6]=value.Trim();} }

        [Display(Name = "Inst8", GroupName = "Instruments", Description = "", Order = 6)]
        public string Inst7 { get {return InstList[7];} set{InstList[7]=value.Trim();} }

        [Display(Name = "Inst9", GroupName = "Instruments", Description = "", Order = 7)]
        public string Inst8 { get {return InstList[8];} set{InstList[8]=value.Trim();} }

        [Display(Name = "Inst10", GroupName = "Instruments", Description = "", Order = 8)]
        public string Inst9 { get {return InstList[9];} set{InstList[9]=value.Trim();} }

        [Display(Name = "Inst11", GroupName = "Instruments", Description = "", Order = 9)]
        public string Inst10 { get {return InstList[10];} set{InstList[10]=value.Trim();} }

        [Display(Name = "Inst12", GroupName = "Instruments", Description = "", Order = 10)]
        public string Inst11 { get {return InstList[11];} set{InstList[11]=value.Trim();} }

        [Display(Name = "Inst13", GroupName = "Instruments", Description = "", Order = 11)]
        public string Inst12 { get {return InstList[12];} set{InstList[12]=value.Trim();} }

        [Display(Name = "Inst14", GroupName = "Instruments", Description = "", Order = 12)]
        public string Inst13 { get {return InstList[13];} set{InstList[13]=value.Trim();} }

        [Display(Name = "Inst15", GroupName = "Instruments", Description = "", Order = 13)]
        public string Inst14 { get {return InstList[14];} set{InstList[14]=value.Trim();} }

        [Display(Name = "Inst16", GroupName = "Instruments", Description = "", Order = 14)]
        public string Inst15 { get {return InstList[15];} set{InstList[15]=value.Trim();} }

        #endregion

        #region -- Parameters --
        [Display(Name = "Start Time", GroupName = "Parameters", Description = "", Order = 10)]
        public DateTime StartTime { get; set; }

        [Display(Name = "Start Type", GroupName = "Parameters", Description = "", Order = 20)]
        public StartTypeE StartType { get; set; } 

        [Display(Name = "Use ATR basis?", GroupName = "Parameters", Description = "", Order = 30)]
		public bool pATRbasis {get;set;}

        [Display(Name = "ATR period", GroupName = "Parameters", Description = "", Order = 40)]
		public int pATRperiod {get;set;}
        #endregion

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_LeadersLaggers[] cacheARC_LeadersLaggers;
		public ARC.ARC_LeadersLaggers ARC_LeadersLaggers()
		{
			return ARC_LeadersLaggers(Input);
		}

		public ARC.ARC_LeadersLaggers ARC_LeadersLaggers(ISeries<double> input)
		{
			if (cacheARC_LeadersLaggers != null)
				for (int idx = 0; idx < cacheARC_LeadersLaggers.Length; idx++)
					if (cacheARC_LeadersLaggers[idx] != null &&  cacheARC_LeadersLaggers[idx].EqualsInput(input))
						return cacheARC_LeadersLaggers[idx];
			return CacheIndicator<ARC.ARC_LeadersLaggers>(new ARC.ARC_LeadersLaggers(), input, ref cacheARC_LeadersLaggers);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_LeadersLaggers ARC_LeadersLaggers()
		{
			return indicator.ARC_LeadersLaggers(Input);
		}

		public Indicators.ARC.ARC_LeadersLaggers ARC_LeadersLaggers(ISeries<double> input )
		{
			return indicator.ARC_LeadersLaggers(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_LeadersLaggers ARC_LeadersLaggers()
		{
			return indicator.ARC_LeadersLaggers(Input);
		}

		public Indicators.ARC.ARC_LeadersLaggers ARC_LeadersLaggers(ISeries<double> input )
		{
			return indicator.ARC_LeadersLaggers(input);
		}
	}
}

#endregion
