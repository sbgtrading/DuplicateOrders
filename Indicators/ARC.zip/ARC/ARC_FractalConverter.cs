#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using SharpDX.DirectWrite;
#endregion

#region -- Author / Infos version --
/*********************************************************************
************************* Golden Zone Trading ************************
**********************************************************************
* Authors NT7 : ?
* Author NT8 : Kriss { AzurITec }
* Author NT8 after 1/1/2018 :  Ben Letto
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
v1.000  - 22.09.2016    + Conversion from NT7 to NT8b13 RC1 "as is".
                        + Remove bar coloration to transparent and draw a white region above bars instead
                        + Session calculations use sessionIterators
                        + Used [CategoryOrder] Attribute to Order categories
----------------------------------------------------------------------
v1.001  - 02.11.2016    + Work with NT8b14 RC2
----------------------------------------------------------------------
v1.01   - 28.02.2017    + Added Compilation Licensing code
                        + Tested with 8.0.4.0
----------------------------------------------------------------------
v1.2    - 16.01.2018    + Added FCDatabase - writing calculation results to CSV files
----------------------------------------------------------------------
######################################################################
~~~~~~~~~~~~~~~~~~~~~~~~~ BUGS/ LIMITATIONS ~~~~~~~~~~~~~~~~~~~~~~~~~~
----------------------------------------------------------------------
*/
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region Global Enums
    public enum ARC_FractalConverter_UpdateFrequency { Monthly, Bimonthly, Quarterly, Semiannually, Annually }
    public enum ARC_FractalConverter_ConversionType { Range_Bars, Volume_Bars }
    public enum ARC_FractalConverter_TimeFrames { Scalper, Day_Trader, Intra_Swing, Custom }
    #endregion

    [CategoryOrder("General Parameters", 1)]
    [CategoryOrder("Timeframe Parameters", 2)]
    [CategoryOrder("Display Options - General", 3)]
    [CategoryOrder("Display Options - Plot Colors", 4)]
    [CategoryOrder("Display Options - Plot Parameters", 5)]
//    [CategoryOrder("Public Holidays", 5000001)]
    public class ARC_FractalConverter : Indicator
    {
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "FractalConverter";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "861", "819", "27405"};//27405 is Annual Membership and 819 is old mastery program
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion


		bool IsDebug = false;

        #region -- Variables --
		private string FCDatabase_FileNameHT = string.Empty;
		private string FCDatabase_FileNameST = string.Empty;
		private string FCDatabase_FileNameMT = string.Empty;
		private bool SavedDataToFiles = false;
        private SessionIterator sessionIterator0, sessionIterator1;
        private Brush dataBrush, volumeBrush, rangeBrush;
        private int lookback = 0;
        private int customPeriodHT = 15;
        private int customPeriodST = 5;
        private int customPeriodMT = 60;
//        private int selectedPeriodHT = 0;
//        private int selectedPeriodST = 0;
//        private int selectedPeriodMT = 0;
        private double conversionFactorHT = 0.0;
        private double conversionFactorST = 0.0;
        private double conversionFactorMT = 0.0;
        private double sqrtConversionFactorHT = 0.0;
        private double sqrtConversionFactorST = 0.0;
        private double sqrtConversionFactorMT = 0.0;
        private int percentageAdjust = 5;
        private int divisor = 0;
        private int currentBars1 = 0;
        private int dayCount = 0;
        private int priorDayCount = 0;
        private int arrayCount = 0;
        private int arrayCountAtCutoffDate = 0;
        private int cacheLastBarIndex = 0;
        private int updatePeriod = 0;
        private int updateBarVolume = 0;
        private int updateBarRange = 0;
        private double tickDivisor = 0.0;
        private double sessionVolume = 0.0;
        private double priorSessionVolume = 0.0;
        private double sessionHigh = 0.0;
        private double sessionLow = 0.0;
        private double sessionRange = 0.0;
        private double specificVolume = 0.0;
        private double specificRange = 0.0;
        private double iSum = 0.0;
        private double volumeFractal = 0.0;
        private double rangeFractal = 0.0;
        private double volumeDiff = 0.0;
        private double rangeDiff = 0.0;
        private List<double> volArray = new List<double>();
        private List<double> rangeArray = new List<double>();
        
        private bool tickBuilt0 = false;
        private bool isCurrency = false;
        private bool useDefaultParameters = false;
        private bool initRightMargin = false;
        private bool extendPublicHoliday0 = false;
        private bool extendPublicHoliday1 = false;
        private bool isPublicHoliday = false;
        private bool initBarSeries0 = false;
        private bool initBarSeries1 = false;
        private bool firstRealTimeBar1 = true;
        private bool newTradingDay = false;
        private bool runningSession = false;
        private bool initPlot = false;
        private bool updateBarV = false;
        private bool updateBarR = false;
        private bool initUpdate = false;
        private bool recalculateVolumeFractals = false;
        private bool recalculateRangeFractals = false;
        private bool fullPeriod = false;

        private string headline = "";
        private string headlineCustom = "Time Frame";
        private string bottomline = "";
//        private string innerHeadline1 = "time-based";
//        private string innerHeadline2 = "volume-based";
//        private string innerHeadline3 = "range-based";
        private string timeBasedHT = "";
        private string timeBasedST = "";
        private string timeBasedMT = "";
        private string volumeBasedHT = "";
        private string volumeBasedST = "";
        private string volumeBasedMT = "";
        private string rangeBasedHT = "";
        private string rangeBasedST = "";
        private string rangeBasedMT = "";
        private SimpleFont textFont = new SimpleFont("Arial", 36);
        private SimpleFont textFont2 = new SimpleFont("Arial", 32);
        private SimpleFont newTextFont = new SimpleFont("Arial", 36);
        private SimpleFont newTextFont2 = new SimpleFont("Arial", 32);
        private int newFontSize = 24;
        private float cacheBoundsHeight = 0f;
        private float cacheBoundsWidth = 0f;
        private float maxStringWidth = 0f;
        private float maxStringWidth1 = 0f;
        private float maxStringWidth2 = 0f;
        private float maxStringWidth3 = 0f;
        private float maxStringWidth4 = 0f;
        private float stringHeight = 0f;
        private float newStringHeight = 0f;
        private float upperMargin = 0f;
        private float boundsY = 0f;
        private float pos1 = 0f;
        private float pos2 = 0f;
        private float pos3 = 0f;
        private float pos4 = 0f;
        private float pos5 = 0f;
        private float offset1 = 0f;
        private float offset2 = 0f;
        private float offset3 = 0f;
        private float offset4 = 0f;
        private float offset5 = 0f;

        private Brush dataBoxColor = null;        

        private DateTime cacheSessionEndTmp0 = new DateTime(0);
        private DateTime cacheSessionBeginTmp0 = new DateTime(0);
        private DateTime sessionDateTmp0 = new DateTime(0);
        private DateTime cacheSessionEndTmp1 = new DateTime(0);
        private DateTime cacheSessionBeginTmp1 = new DateTime(0);
        private DateTime sessionDateTmp1 = new DateTime(0);

        private DateTime lastBarTimeStamp0 = new DateTime(0);
        private DateTime lastBarTimeStamp1 = new DateTime(0);
        private DateTime lastBarTimeStamp2 = new DateTime(0);
        private DateTime exchangeTime = new DateTime(0);
        private DateTime currentDate0 = new DateTime(0);
        private DateTime currentDate1 = new DateTime(0);
        private DateTime beginTime = new DateTime(0);
        private DateTime endTime = new DateTime(0);

        private TimeSpan evaluationRangeBeginTime = new TimeSpan(0, 0, 0);
        private TimeSpan evaluationRangeEndTime = new TimeSpan(0, 0, 0);
        private TimeSpan beginTime_Default = new TimeSpan(7, 30, 0);
        private TimeSpan endTime_Default = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_ES = new TimeSpan(8, 30, 0);
        private TimeSpan endTime_ES = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_NQ = new TimeSpan(8, 30, 0);
        private TimeSpan endTime_NQ = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_YM = new TimeSpan(8, 30, 0);
        private TimeSpan endTime_YM = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_TF = new TimeSpan(8, 30, 0);
        private TimeSpan endTime_TF = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_UB = new TimeSpan(8, 0, 0);
        private TimeSpan endTime_UB = new TimeSpan(15, 0, 0);
        private TimeSpan beginTime_ZB = new TimeSpan(8, 0, 0);
        private TimeSpan endTime_ZB = new TimeSpan(15, 0, 0);
        private TimeSpan beginTime_ZN = new TimeSpan(8, 0, 0);
        private TimeSpan endTime_ZN = new TimeSpan(15, 0, 0);
        private TimeSpan beginTime_CT = new TimeSpan(8, 0, 0);
        private TimeSpan endTime_CT = new TimeSpan(14, 0, 0);
        private TimeSpan beginTime_KC = new TimeSpan(8, 0, 0);
        private TimeSpan endTime_KC = new TimeSpan(13, 30, 0);
        private TimeSpan beginTime_SB = new TimeSpan(3, 0, 0);
        private TimeSpan endTime_SB = new TimeSpan(13, 0, 0);
        private TimeSpan beginTime_CC = new TimeSpan(5, 0, 0);
        private TimeSpan endTime_CC = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_DX = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_DX = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_6E = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_6E = new TimeSpan(12, 00, 0);
        private TimeSpan beginTime_6S = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_6S = new TimeSpan(12, 00, 0);
        private TimeSpan beginTime_6B = new TimeSpan(3, 0, 0);
        private TimeSpan endTime_6B = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_6J = new TimeSpan(0, 0, 0);
        private TimeSpan endTime_6J = new TimeSpan(15, 0, 0);
        private TimeSpan beginTime_6C = new TimeSpan(8, 0, 0);
        private TimeSpan endTime_6C = new TimeSpan(12, 30, 0);
        private TimeSpan beginTime_6A = new TimeSpan(0, 0, 0);
        private TimeSpan endTime_6A = new TimeSpan(11, 30, 0);
        private TimeSpan beginTime_6M = new TimeSpan(3, 0, 0);
        private TimeSpan endTime_6M = new TimeSpan(15, 0, 0);
        private TimeSpan beginTime_6N = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_6N = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_GC = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_GC = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_SI = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_SI = new TimeSpan(13, 30, 0);
        private TimeSpan beginTime_HG = new TimeSpan(9, 0, 0);
        private TimeSpan endTime_HG = new TimeSpan(14, 0, 0);
        private TimeSpan beginTime_CL = new TimeSpan(9, 0, 0);
        private TimeSpan endTime_CL = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_NG = new TimeSpan(7, 0, 0);
        private TimeSpan endTime_NG = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_HO = new TimeSpan(3, 0, 0);
        private TimeSpan endTime_HO = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_RB = new TimeSpan(3, 0, 0);
        private TimeSpan endTime_RB = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_BRN = new TimeSpan(9, 0, 0);
        private TimeSpan endTime_BRN = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_ZS = new TimeSpan(9, 30, 0);
        private TimeSpan endTime_ZS = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_ZL = new TimeSpan(9, 30, 0);
        private TimeSpan endTime_ZL = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_ZM = new TimeSpan(9, 30, 0);
        private TimeSpan endTime_ZM = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_ZW = new TimeSpan(9, 30, 0);
        private TimeSpan endTime_ZW = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_ZC = new TimeSpan(9, 30, 0);
        private TimeSpan endTime_ZC = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_FGBL = new TimeSpan(8, 0, 0);
        private TimeSpan endTime_FGBL = new TimeSpan(17, 30, 0);
        private TimeSpan beginTime_FGBM = new TimeSpan(8, 0, 0);
        private TimeSpan endTime_FGBM = new TimeSpan(17, 30, 0);
        private TimeSpan beginTime_FESX = new TimeSpan(8, 0, 0);
        private TimeSpan endTime_FESX = new TimeSpan(17, 30, 0);
        private TimeSpan beginTime_FDAX = new TimeSpan(8, 0, 0);
        private TimeSpan endTime_FDAX = new TimeSpan(17, 30, 0);
        private TimeSpan beginTime_USDCAD = new TimeSpan(3, 0, 0);
        private TimeSpan endTime_USDCAD = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_USDCHF = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_USDCHF = new TimeSpan(15, 30, 0);
        private TimeSpan beginTime_USDJPY = new TimeSpan(19, 30, 0);
        private TimeSpan endTime_USDJPY = new TimeSpan(13, 30, 0);
        private TimeSpan beginTime_AUDCAD = new TimeSpan(20, 0, 0);
        private TimeSpan endTime_AUDCAD = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_AUDCHF = new TimeSpan(20, 0, 0);
        private TimeSpan endTime_AUDCHF = new TimeSpan(15, 0, 0);
        private TimeSpan beginTime_AUDJPY = new TimeSpan(20, 0, 0);
        private TimeSpan endTime_AUDJPY = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_AUDNZD = new TimeSpan(17, 0, 0);
        private TimeSpan endTime_AUDNZD = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_AUDUSD = new TimeSpan(20, 0, 0);
        private TimeSpan endTime_AUDUSD = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_GBPAUD = new TimeSpan(20, 0, 0);
        private TimeSpan endTime_GBPAUD = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_GBPCAD = new TimeSpan(3, 0, 0);
        private TimeSpan endTime_GBPCAD = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_GBPCHF = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_GBPCHF = new TimeSpan(15, 0, 0);
        private TimeSpan beginTime_GBPJPY = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_GBPJPY = new TimeSpan(15, 0, 0);
        private TimeSpan beginTime_GBPNZD = new TimeSpan(17, 0, 0);
        private TimeSpan endTime_GBPNZD = new TimeSpan(15, 0, 0);
        private TimeSpan beginTime_GBPUSD = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_GBPUSD = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_CADCHF = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_CADCHF = new TimeSpan(13, 0, 0);
        private TimeSpan beginTime_CADJPY = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_CADJPY = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_EURAUD = new TimeSpan(20, 0, 0);
        private TimeSpan endTime_EURAUD = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_EURCAD = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_EURCAD = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_EURCHF = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_EURCHF = new TimeSpan(16, 0, 0);
        private TimeSpan beginTime_EURGBP = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_EURGBP = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_EURJPY = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_EURJPY = new TimeSpan(14, 30, 0);
        private TimeSpan beginTime_EURNZD = new TimeSpan(17, 0, 0);
        private TimeSpan endTime_EURNZD = new TimeSpan(12, 0, 0);
        private TimeSpan beginTime_EURUSD = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_EURUSD = new TimeSpan(15, 0, 0);
        private TimeSpan beginTime_CHFJPY = new TimeSpan(2, 0, 0);
        private TimeSpan endTime_CHFJPY = new TimeSpan(15, 30, 0);
        private TimeSpan beginTime_NZDCAD = new TimeSpan(17, 0, 0);
        private TimeSpan endTime_NZDCAD = new TimeSpan(13, 0, 0);
        private TimeSpan beginTime_NZDCHF = new TimeSpan(17, 0, 0);
        private TimeSpan endTime_NZDCHF = new TimeSpan(13, 0, 0);
        private TimeSpan beginTime_NZDJPY = new TimeSpan(17, 0, 0);
        private TimeSpan endTime_NZDJPY = new TimeSpan(13, 0, 0);
        private TimeSpan beginTime_NZDUSD = new TimeSpan(17, 0, 0);
        private TimeSpan endTime_NZDUSD = new TimeSpan(13, 0, 0);

		private DateTime PublicHoliday0, PublicHoliday1, PublicHoliday2, PublicHoliday3, PublicHoliday4, PublicHoliday5, PublicHoliday6;
		private DateTime PublicHoliday7, PublicHoliday8;
		private DateTime PublicHoliday9;
		private DateTime PublicHoliday10;
		private DateTime PublicHoliday11;
		private DateTime PublicHoliday12;
		private DateTime PublicHoliday13;
		private DateTime PublicHoliday14;
		private DateTime PublicHoliday15;
		private DateTime PublicHoliday16;
		private DateTime PublicHoliday17;
		private DateTime PublicHoliday18;
		private DateTime PublicHoliday19;
		private DateTime PublicHoliday20;
		private DateTime PublicHoliday21;
		private DateTime PublicHoliday22;
		private DateTime PublicHoliday23;
		private DateTime PublicHoliday24;
		private DateTime PublicHoliday25;
		private DateTime PublicHoliday26;
		private DateTime PublicHoliday27;
		private DateTime PublicHoliday28;
		private DateTime PublicHoliday29;
		private DateTime PublicHoliday30;
		private DateTime PublicHoliday31;
		private DateTime PublicHoliday32;
		private DateTime PublicHoliday33;
		private DateTime PublicHoliday34;
		private DateTime PublicHoliday35;
		private DateTime PublicHoliday36;
		private DateTime PublicHoliday37;
		private DateTime PublicHoliday38;
		private DateTime PublicHoliday39;
		private DateTime PublicHoliday40;
		private DateTime PublicHoliday41;
		private DateTime PublicHoliday42;
		private DateTime PublicHoliday43;
		private DateTime PublicHoliday44;
		private DateTime PublicHoliday45;
		private DateTime PublicHoliday46;
		private DateTime PublicHoliday47;

		private TimeZoneInfo evaluationTimeZone = null;
        private TimeZoneInfo timeZone_Default = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_ES = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_NQ = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_YM = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_TF = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_UB = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_ZB = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_ZN = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_CT = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_KC = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_SB = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_CC = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_DX = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_6E = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_6S = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_6B = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_6J = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_6C = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_6A = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_6M = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_6N = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_GC = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_SI = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_HG = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_CL = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_NG = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_HO = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_RB = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_BRN = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_ZS = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_ZL = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_ZM = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_ZW = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_ZC = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_FGBL = TimeZoneInfo.FindSystemTimeZoneById("Central European Standard Time");
        private TimeZoneInfo timeZone_FGBM = TimeZoneInfo.FindSystemTimeZoneById("Central European Standard Time");
        private TimeZoneInfo timeZone_FESX = TimeZoneInfo.FindSystemTimeZoneById("Central European Standard Time");
        private TimeZoneInfo timeZone_FDAX = TimeZoneInfo.FindSystemTimeZoneById("Central European Standard Time");
        private TimeZoneInfo timeZone_USDCAD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_USDCHF = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_USDJPY = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_AUDCAD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_AUDCHF = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_AUDJPY = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_AUDNZD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_AUDUSD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_GBPAUD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_GBPCAD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_GBPCHF = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_GBPJPY = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_GBPNZD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_GBPUSD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_CADCHF = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_CADJPY = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_EURAUD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_EURCAD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_EURCHF = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_EURGBP = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_EURJPY = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_EURNZD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_EURUSD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_CHFJPY = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_NZDCAD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_NZDCHF = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_NZDJPY = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private TimeZoneInfo timeZone_NZDUSD = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");

        private DateTime[] publicHoliday = new DateTime[48];
        #endregion

        #region -- Series<T> --
        private Series<int> volumeFractalHT;
        private Series<int> volumeFractalST;
        private Series<int> volumeFractalMT;
        private Series<int> rangeFractalHT;
        private Series<int> rangeFractalST;
        private Series<int> rangeFractalMT;
        private Series<int> updateBarVSeries;
        private Series<int> updateBarRSeries;
        private Series<bool> recalcVolumeFractals;
        private Series<bool> recalcRangeFractals;
        #endregion
		DateTime LaunchTime = DateTime.MinValue;
		float[] rowY = new float[6]{0f,0f,0f,0f,0f,0f};
		float[] colX = new float[4]{0f,0f,0f,0f};
		string[,] table = new String[4,6];
		private SortedDictionary<string,List<double>> FractalAvgs = new SortedDictionary<string,List<double>>();
		private SortedDictionary<string,SortedDictionary<int,double>> FractalAvgSeries = new SortedDictionary<string,SortedDictionary<int,double>>();//abar number is key, fractal avg at that bar is value

		private const string VERSION = "1.3 Apr 15 2020";
		[Description("")]
		[Category("~ Indicator Version ~")]
		public string indicatorVersion { get { return VERSION;} set {} }


        //-------------------- Virtuals --------------------------
        public override string DisplayName { get { return "ARC_FractalConverter"; } }

        protected override void OnStateChange()
        {
            #region State == State.SetDefaults
            if (State == State.SetDefaults)
            {
                Description = @"GZT Fractal Converter for Volume and Equal Range Charts";
                Name = "ARC_FractalConverter";

                #region -- UI Settings --
                BarsRequiredToPlot = 0;
                DrawOnPricePanel = true;
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                AllowRemovalOfDrawObjects = true;
                PaintPriceMarkers = true;
                DisplayInDataBox = false;

                MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
                ArePlotsConfigurable = false;
                ScaleJustification = ScaleJustification.Overlay;
                IsSuspendedWhileInactive = true;
                #endregion

                AddPlot(new Stroke(Brushes.Gray, 3), PlotStyle.Bar, "Daily Fractal");
                AddPlot(new Stroke(Brushes.Gray, 3), PlotStyle.Line, "Average Fractal");                

                #region -- Default Values --

                Period = 500;
                UpdatePolicy = ARC_FractalConverter_UpdateFrequency.Quarterly;
                ConversionType = ARC_FractalConverter_ConversionType.Range_Bars;
                Dash1Style = DashStyleHelper.Solid;

                Plot0Color = Brushes.Blue;
                Plot1Color = Brushes.Red;
                DevelopingColor = Brushes.Black;
                TextColor = Brushes.White;
                BackgroundColor = Brushes.Navy;
                AlertColor = Brushes.Yellow;
                BarWidth = 3;
                Plot1Width = 2;
                DataBoxOpacity = 30;
                FontSize = 20;        

                PublicHoliday0 = new DateTime(2010, 01, 18);
                PublicHoliday1 = new DateTime(2010, 02, 15);
                PublicHoliday2 = new DateTime(2010, 04, 02);
                PublicHoliday3 = new DateTime(2010, 05, 31);
                PublicHoliday4 = new DateTime(2010, 07, 05);
                PublicHoliday5 = new DateTime(2010, 09, 06);
                PublicHoliday6 = new DateTime(2010, 11, 11);
                PublicHoliday7 = new DateTime(2010, 11, 25);
                PublicHoliday8 = new DateTime(2011, 01, 17);
                PublicHoliday9 = new DateTime(2011, 02, 21);
                PublicHoliday10 = new DateTime(2011, 04, 22);
                PublicHoliday11 = new DateTime(2011, 05, 30);
                PublicHoliday12 = new DateTime(2011, 07, 04);
                PublicHoliday13 = new DateTime(2011, 09, 05);
                PublicHoliday14 = new DateTime(2011, 11, 11);
                PublicHoliday15 = new DateTime(2011, 11, 24);
                PublicHoliday16 = new DateTime(2012, 01, 16);
                PublicHoliday17 = new DateTime(2012, 02, 20);
                PublicHoliday18 = new DateTime(2012, 04, 06);
                PublicHoliday19 = new DateTime(2012, 05, 28);
                PublicHoliday20 = new DateTime(2012, 07, 04);
                PublicHoliday21 = new DateTime(2012, 09, 03);
                PublicHoliday22 = new DateTime(2012, 11, 12);
                PublicHoliday23 = new DateTime(2012, 11, 22);
                PublicHoliday24 = new DateTime(2013, 01, 21);
                PublicHoliday25 = new DateTime(2013, 02, 18);
                PublicHoliday26 = new DateTime(2013, 03, 29);
                PublicHoliday27 = new DateTime(2013, 05, 27);
                PublicHoliday28 = new DateTime(2013, 07, 04);
                PublicHoliday29 = new DateTime(2013, 09, 02);
                PublicHoliday30 = new DateTime(2013, 11, 11);
                PublicHoliday31 = new DateTime(2013, 11, 28);
                PublicHoliday32 = new DateTime(2014, 01, 20);
                PublicHoliday33 = new DateTime(2014, 02, 17);
                PublicHoliday34 = new DateTime(2014, 04, 18);
                PublicHoliday35 = new DateTime(2014, 05, 26);
                PublicHoliday36 = new DateTime(2014, 07, 04);
                PublicHoliday37 = new DateTime(2014, 09, 01);
                PublicHoliday38 = new DateTime(2014, 11, 11);
                PublicHoliday39 = new DateTime(2014, 11, 27);
                PublicHoliday40 = new DateTime(2015, 01, 19);
                PublicHoliday41 = new DateTime(2015, 02, 16);
                PublicHoliday42 = new DateTime(2015, 04, 03);
                PublicHoliday43 = new DateTime(2015, 05, 25);
                PublicHoliday44 = new DateTime(2015, 07, 03);
                PublicHoliday45 = new DateTime(2015, 09, 07);
                PublicHoliday46 = new DateTime(2015, 11, 11);
                PublicHoliday47 = new DateTime(2015, 11, 26);

                #endregion
            }
            #endregion

            #region State == State.Configure
            else if (State == State.Configure)
            {
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif

                AddDataSeries(BarsPeriodType.Minute, 5);

				SavedDataToFiles = false;
				var dir = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"FCdata");
				var di = new System.IO.DirectoryInfo(dir);
				if(!di.Exists){
					System.IO.Directory.CreateDirectory(dir);
				}

				var instname = Instrument.FullName.Split(new char[]{' '});
				//Set Higher Timeframe name
				if(instname.Length>0)
					FCDatabase_FileNameHT = string.Format("FCDatabase_{0}_{1}.txt",instname[0],S_CustomPeriodHT);
				else
					FCDatabase_FileNameHT = string.Format("FCDatabase_{0}_{1}.txt",Instrument.FullName,S_CustomPeriodHT);
				FCDatabase_FileNameHT = FCDatabase_FileNameHT.Replace(" ",string.Empty);
				FCDatabase_FileNameHT = System.IO.Path.Combine(dir,FCDatabase_FileNameHT);
				FCDatabase_FileNameHT = StripOutIllegalCharacters(FCDatabase_FileNameHT,string.Empty);
				//Set Small Timeframe name
				if(instname.Length>0)
					FCDatabase_FileNameST = string.Format("FCDatabase_{0}_{1}.txt",instname[0],S_CustomPeriodST);
				else
					FCDatabase_FileNameST = string.Format("FCDatabase_{0}_{1}.txt",Instrument.FullName,S_CustomPeriodST);
				FCDatabase_FileNameST = FCDatabase_FileNameST.Replace(" ",string.Empty);
				FCDatabase_FileNameST = System.IO.Path.Combine(dir,FCDatabase_FileNameST);
				FCDatabase_FileNameST = StripOutIllegalCharacters(FCDatabase_FileNameST,string.Empty);
				//Set Micro Timeframe name
				if(instname.Length>0)
					FCDatabase_FileNameMT = string.Format("FCDatabase_{0}_{1}.txt",instname[0],S_CustomPeriodMT);
				else
					FCDatabase_FileNameMT = string.Format("FCDatabase_{0}_{1}.txt",Instrument.FullName,S_CustomPeriodMT);
				FCDatabase_FileNameMT = FCDatabase_FileNameMT.Replace(" ",string.Empty);
				FCDatabase_FileNameMT = System.IO.Path.Combine(dir,FCDatabase_FileNameMT);
				FCDatabase_FileNameMT = StripOutIllegalCharacters(FCDatabase_FileNameMT,string.Empty);
				
				#region Initialize Dataseries
                CurrentVolumeFractal = new Series<double>(this);
                DisplayedVolumeFractal = new Series<double>(this);
                DailyVolume = new Series<double>(this);
                CurrentRangeFractal = new Series<double>(this);
                DisplayedRangeFractal = new Series<double>(this);
                DailyRange = new Series<double>(this);
                VolumeDeviation = new Series<double>(this);
                RangeDeviation = new Series<double>(this);
                volumeFractalHT = new Series<int>(this);
                volumeFractalST = new Series<int>(this);
                volumeFractalMT = new Series<int>(this);
                rangeFractalHT = new Series<int>(this);
                rangeFractalST = new Series<int>(this);
                rangeFractalMT = new Series<int>(this);
                DaysUsedForCalculation = new Series<int>(this);
                updateBarVSeries = new Series<int>(this);
                updateBarRSeries = new Series<int>(this);
                recalcVolumeFractals = new Series<bool>(this);
                recalcRangeFractals = new Series<bool>(this);
				#endregion

                for (int i = 0; i < Period; i++)
                {
                    volArray.Add(0.0);
                    rangeArray.Add(0.0);
                }

//                selectedPeriodHT = customPeriodHT;
//                selectedPeriodST = customPeriodST;
//                selectedPeriodMT = customPeriodMT;
                conversionFactorHT = customPeriodHT / 1.0;
                conversionFactorST = customPeriodST / 1.0;
                conversionFactorMT = customPeriodMT / 60.0;
                headline = headlineCustom;
                timeBasedHT = customPeriodHT + " min";
                timeBasedST = customPeriodST + " min";
                timeBasedMT = customPeriodMT + " sec";
                sqrtConversionFactorHT = Math.Sqrt(conversionFactorHT);
                sqrtConversionFactorST = Math.Sqrt(conversionFactorST);
                sqrtConversionFactorMT = Math.Sqrt(conversionFactorMT);

				#region initialize Begin and End times, and timezones
                if (useDefaultParameters)
                {
                    evaluationRangeBeginTime = beginTime_Default;
                    evaluationRangeEndTime = endTime_Default;
                    evaluationTimeZone = timeZone_Default;
                }
                else if (Instrument.MasterInstrument.Name == "ES")
                {
                    evaluationRangeBeginTime = beginTime_ES;
                    evaluationRangeEndTime = endTime_ES;
                    evaluationTimeZone = timeZone_ES;
                }
                else if (Instrument.MasterInstrument.Name == "NQ")
                {
                    evaluationRangeBeginTime = beginTime_NQ;
                    evaluationRangeEndTime = endTime_NQ;
                    evaluationTimeZone = timeZone_NQ;
                }
                else if (Instrument.MasterInstrument.Name == "YM")
                {
                    evaluationRangeBeginTime = beginTime_YM;
                    evaluationRangeEndTime = endTime_YM;
                    evaluationTimeZone = timeZone_YM;
                }
                else if (Instrument.MasterInstrument.Name == "TF")
                {
                    evaluationRangeBeginTime = beginTime_TF;
                    evaluationRangeEndTime = endTime_TF;
                    evaluationTimeZone = timeZone_TF;
                }
                else if (Instrument.MasterInstrument.Name == "UB")
                {
                    evaluationRangeBeginTime = beginTime_UB;
                    evaluationRangeEndTime = endTime_UB;
                    evaluationTimeZone = timeZone_UB;
                }
                else if (Instrument.MasterInstrument.Name == "ZB")
                {
                    evaluationRangeBeginTime = beginTime_ZB;
                    evaluationRangeEndTime = endTime_ZB;
                    evaluationTimeZone = timeZone_ZB;
                }
                else if (Instrument.MasterInstrument.Name == "ZN")
                {
                    evaluationRangeBeginTime = beginTime_ZN;
                    evaluationRangeEndTime = endTime_ZN;
                    evaluationTimeZone = timeZone_ZN;
                }
                else if (Instrument.MasterInstrument.Name == "CT")
                {
                    evaluationRangeBeginTime = beginTime_CT;
                    evaluationRangeEndTime = endTime_CT;
                    evaluationTimeZone = timeZone_CT;
                }
                else if (Instrument.MasterInstrument.Name == "KC")
                {
                    evaluationRangeBeginTime = beginTime_KC;
                    evaluationRangeEndTime = endTime_KC;
                    evaluationTimeZone = timeZone_KC;
                }
                else if (Instrument.MasterInstrument.Name == "SB")
                {
                    evaluationRangeBeginTime = beginTime_SB;
                    evaluationRangeEndTime = endTime_SB;
                    evaluationTimeZone = timeZone_SB;
                }
                else if (Instrument.MasterInstrument.Name == "CC")
                {
                    evaluationRangeBeginTime = beginTime_CC;
                    evaluationRangeEndTime = endTime_CC;
                    evaluationTimeZone = timeZone_CC;
                }
                else if (Instrument.MasterInstrument.Name == "DX")
                {
                    evaluationRangeBeginTime = beginTime_DX;
                    evaluationRangeEndTime = endTime_DX;
                    evaluationTimeZone = timeZone_DX;
                }
                else if (Instrument.MasterInstrument.Name == "6E")
                {
                    evaluationRangeBeginTime = beginTime_6E;
                    evaluationRangeEndTime = endTime_6E;
                    evaluationTimeZone = timeZone_6E;
                }
                else if (Instrument.MasterInstrument.Name == "6S")
                {
                    evaluationRangeBeginTime = beginTime_6S;
                    evaluationRangeEndTime = endTime_6S;
                    evaluationTimeZone = timeZone_6S;
                }
                else if (Instrument.MasterInstrument.Name == "6B")
                {
                    evaluationRangeBeginTime = beginTime_6B;
                    evaluationRangeEndTime = endTime_6B;
                    evaluationTimeZone = timeZone_6B;
                }
                else if (Instrument.MasterInstrument.Name == "6J")
                {
                    evaluationRangeBeginTime = beginTime_6J;
                    evaluationRangeEndTime = endTime_6J;
                    evaluationTimeZone = timeZone_6J;
                }
                else if (Instrument.MasterInstrument.Name == "6C")
                {
                    evaluationRangeBeginTime = beginTime_6C;
                    evaluationRangeEndTime = endTime_6C;
                    evaluationTimeZone = timeZone_6C;
                }
                else if (Instrument.MasterInstrument.Name == "6A")
                {
                    evaluationRangeBeginTime = beginTime_6A;
                    evaluationRangeEndTime = endTime_6A;
                    evaluationTimeZone = timeZone_6A;
                }
                else if (Instrument.MasterInstrument.Name == "6M")
                {
                    evaluationRangeBeginTime = beginTime_6M;
                    evaluationRangeEndTime = endTime_6M;
                    evaluationTimeZone = timeZone_6M;
                }
                else if (Instrument.MasterInstrument.Name == "6N")
                {
                    evaluationRangeBeginTime = beginTime_6N;
                    evaluationRangeEndTime = endTime_6N;
                    evaluationTimeZone = timeZone_6N;
                }
                else if (Instrument.MasterInstrument.Name == "GC")
                {
                    evaluationRangeBeginTime = beginTime_GC;
                    evaluationRangeEndTime = endTime_GC;
                    evaluationTimeZone = timeZone_GC;
                }
                else if (Instrument.MasterInstrument.Name == "SI")
                {
                    evaluationRangeBeginTime = beginTime_SI;
                    evaluationRangeEndTime = endTime_SI;
                    evaluationTimeZone = timeZone_SI;
                }
                else if (Instrument.MasterInstrument.Name == "HG")
                {
                    evaluationRangeBeginTime = beginTime_HG;
                    evaluationRangeEndTime = endTime_HG;
                    evaluationTimeZone = timeZone_HG;
                }
                else if (Instrument.MasterInstrument.Name == "CL")
                {
                    evaluationRangeBeginTime = beginTime_CL;
                    evaluationRangeEndTime = endTime_CL;
                    evaluationTimeZone = timeZone_ES;
                }
                else if (Instrument.MasterInstrument.Name == "NG")
                {
                    evaluationRangeBeginTime = beginTime_NG;
                    evaluationRangeEndTime = endTime_NG;
                    evaluationTimeZone = timeZone_NG;
                }
                else if (Instrument.MasterInstrument.Name == "HO")
                {
                    evaluationRangeBeginTime = beginTime_HO;
                    evaluationRangeEndTime = endTime_HO;
                    evaluationTimeZone = timeZone_HO;
                }
                else if (Instrument.MasterInstrument.Name == "RB")
                {
                    evaluationRangeBeginTime = beginTime_RB;
                    evaluationRangeEndTime = endTime_RB;
                    evaluationTimeZone = timeZone_RB;
                }
                else if (Instrument.MasterInstrument.Name == "BRN")
                {
                    evaluationRangeBeginTime = beginTime_BRN;
                    evaluationRangeEndTime = endTime_BRN;
                    evaluationTimeZone = timeZone_BRN;
                }
                else if (Instrument.MasterInstrument.Name == "ZS")
                {
                    evaluationRangeBeginTime = beginTime_ZS;
                    evaluationRangeEndTime = endTime_ZS;
                    evaluationTimeZone = timeZone_ZS;
                }
                else if (Instrument.MasterInstrument.Name == "ZL")
                {
                    evaluationRangeBeginTime = beginTime_ZL;
                    evaluationRangeEndTime = endTime_ZL;
                    evaluationTimeZone = timeZone_ZL;
                }
                else if (Instrument.MasterInstrument.Name == "ZM")
                {
                    evaluationRangeBeginTime = beginTime_ZM;
                    evaluationRangeEndTime = endTime_ZM;
                    evaluationTimeZone = timeZone_ZM;
                }
                else if (Instrument.MasterInstrument.Name == "ZC")
                {
                    evaluationRangeBeginTime = beginTime_ZC;
                    evaluationRangeEndTime = endTime_ZC;
                    evaluationTimeZone = timeZone_ZC;
                }
                else if (Instrument.MasterInstrument.Name == "ZW")
                {
                    evaluationRangeBeginTime = beginTime_ZW;
                    evaluationRangeEndTime = endTime_ZW;
                    evaluationTimeZone = timeZone_ZW;
                }
                else if (Instrument.MasterInstrument.Name == "FGBL")
                {
                    evaluationRangeBeginTime = beginTime_FGBL;
                    evaluationRangeEndTime = endTime_FGBL;
                    evaluationTimeZone = timeZone_FGBL;
                }
                else if (Instrument.MasterInstrument.Name == "FGBM")
                {
                    evaluationRangeBeginTime = beginTime_FGBM;
                    evaluationRangeEndTime = endTime_FGBM;
                    evaluationTimeZone = timeZone_FGBM;
                }
                else if (Instrument.MasterInstrument.Name == "FESX")
                {
                    evaluationRangeBeginTime = beginTime_FESX;
                    evaluationRangeEndTime = endTime_FESX;
                    evaluationTimeZone = timeZone_FESX;
                }
                else if (Instrument.MasterInstrument.Name == "FDAX")
                {
                    evaluationRangeBeginTime = beginTime_FDAX;
                    evaluationRangeEndTime = endTime_FDAX;
                    evaluationTimeZone = timeZone_FDAX;
                }
                else if (Instrument.MasterInstrument.Name == "USDCAD")
                {
                    evaluationRangeBeginTime = beginTime_USDCAD;
                    evaluationRangeEndTime = endTime_USDCAD;
                    evaluationTimeZone = timeZone_USDCAD;
                }
                else if (Instrument.MasterInstrument.Name == "USDCHF")
                {
                    evaluationRangeBeginTime = beginTime_USDCAD;
                    evaluationRangeEndTime = endTime_USDCHF;
                    evaluationTimeZone = timeZone_USDCHF;
                }
                else if (Instrument.MasterInstrument.Name == "USDJPY")
                {
                    evaluationRangeBeginTime = beginTime_USDJPY;
                    evaluationRangeEndTime = endTime_USDJPY;
                    evaluationTimeZone = timeZone_USDJPY;
                }
                else if (Instrument.MasterInstrument.Name == "AUDCAD")
                {
                    evaluationRangeBeginTime = beginTime_AUDCAD;
                    evaluationRangeEndTime = endTime_AUDCAD;
                    evaluationTimeZone = timeZone_AUDCAD;
                }
                else if (Instrument.MasterInstrument.Name == "AUDCHF")
                {
                    evaluationRangeBeginTime = beginTime_AUDCHF;
                    evaluationRangeEndTime = endTime_AUDCHF;
                    evaluationTimeZone = timeZone_AUDCHF;
                }
                else if (Instrument.MasterInstrument.Name == "AUDJPY")
                {
                    evaluationRangeBeginTime = beginTime_AUDJPY;
                    evaluationRangeEndTime = endTime_AUDJPY;
                    evaluationTimeZone = timeZone_AUDJPY;
                }
                else if (Instrument.MasterInstrument.Name == "AUDNZD")
                {
                    evaluationRangeBeginTime = beginTime_AUDNZD;
                    evaluationRangeEndTime = endTime_AUDNZD;
                    evaluationTimeZone = timeZone_AUDNZD;
                }
                else if (Instrument.MasterInstrument.Name == "AUDUSD")
                {
                    evaluationRangeBeginTime = beginTime_AUDUSD;
                    evaluationRangeEndTime = endTime_AUDUSD;
                    evaluationTimeZone = timeZone_AUDUSD;
                }
                else if (Instrument.MasterInstrument.Name == "GBPAUD")
                {
                    evaluationRangeBeginTime = beginTime_GBPAUD;
                    evaluationRangeEndTime = endTime_GBPAUD;
                    evaluationTimeZone = timeZone_GBPAUD;
                }
                else if (Instrument.MasterInstrument.Name == "GBPCAD")
                {
                    evaluationRangeBeginTime = beginTime_GBPCAD;
                    evaluationRangeEndTime = endTime_GBPCAD;
                    evaluationTimeZone = timeZone_GBPCAD;
                }
                else if (Instrument.MasterInstrument.Name == "GBPCHF")
                {
                    evaluationRangeBeginTime = beginTime_GBPCHF;
                    evaluationRangeEndTime = endTime_GBPCHF;
                    evaluationTimeZone = timeZone_GBPCHF;
                }
                else if (Instrument.MasterInstrument.Name == "GBPJPY")
                {
                    evaluationRangeBeginTime = beginTime_GBPJPY;
                    evaluationRangeEndTime = endTime_GBPJPY;
                    evaluationTimeZone = timeZone_GBPJPY;
                }
                else if (Instrument.MasterInstrument.Name == "GBPNZD")
                {
                    evaluationRangeBeginTime = beginTime_GBPNZD;
                    evaluationRangeEndTime = endTime_GBPNZD;
                    evaluationTimeZone = timeZone_GBPNZD;
                }
                else if (Instrument.MasterInstrument.Name == "GBPUSD")
                {
                    evaluationRangeBeginTime = beginTime_GBPUSD;
                    evaluationRangeEndTime = endTime_GBPUSD;
                    evaluationTimeZone = timeZone_GBPUSD;
                }
                else if (Instrument.MasterInstrument.Name == "CADCHF")
                {
                    evaluationRangeBeginTime = beginTime_CADCHF;
                    evaluationRangeEndTime = endTime_CADCHF;
                    evaluationTimeZone = timeZone_CADCHF;
                }
                else if (Instrument.MasterInstrument.Name == "CADJPY")
                {
                    evaluationRangeBeginTime = beginTime_CADJPY;
                    evaluationRangeEndTime = endTime_CADJPY;
                    evaluationTimeZone = timeZone_CADJPY;
                }
                else if (Instrument.MasterInstrument.Name == "EURAUD")
                {
                    evaluationRangeBeginTime = beginTime_EURAUD;
                    evaluationRangeEndTime = endTime_EURAUD;
                    evaluationTimeZone = timeZone_EURAUD;
                }
                else if (Instrument.MasterInstrument.Name == "EURCAD")
                {
                    evaluationRangeBeginTime = beginTime_EURCAD;
                    evaluationRangeEndTime = endTime_EURCAD;
                    evaluationTimeZone = timeZone_EURCAD;
                }
                else if (Instrument.MasterInstrument.Name == "EURCHF")
                {
                    evaluationRangeBeginTime = beginTime_EURCHF;
                    evaluationRangeEndTime = endTime_EURCHF;
                    evaluationTimeZone = timeZone_EURCHF;
                }
                else if (Instrument.MasterInstrument.Name == "EURGBP")
                {
                    evaluationRangeBeginTime = beginTime_EURGBP;
                    evaluationRangeEndTime = endTime_EURGBP;
                    evaluationTimeZone = timeZone_EURGBP;
                }
                else if (Instrument.MasterInstrument.Name == "EURJPY")
                {
                    evaluationRangeBeginTime = beginTime_EURJPY;
                    evaluationRangeEndTime = endTime_EURJPY;
                    evaluationTimeZone = timeZone_EURJPY;
                }
                else if (Instrument.MasterInstrument.Name == "EURNZD")
                {
                    evaluationRangeBeginTime = beginTime_EURNZD;
                    evaluationRangeEndTime = endTime_EURNZD;
                    evaluationTimeZone = timeZone_EURNZD;
                }
                else if (Instrument.MasterInstrument.Name == "EURUSD")
                {
                    evaluationRangeBeginTime = beginTime_EURUSD;
                    evaluationRangeEndTime = endTime_EURUSD;
                    evaluationTimeZone = timeZone_EURUSD;
                }
                else if (Instrument.MasterInstrument.Name == "CHFJPY")
                {
                    evaluationRangeBeginTime = beginTime_CHFJPY;
                    evaluationRangeEndTime = endTime_CHFJPY;
                    evaluationTimeZone = timeZone_CHFJPY;
                }
                else if (Instrument.MasterInstrument.Name == "NZDCAD")
                {
                    evaluationRangeBeginTime = beginTime_NZDCAD;
                    evaluationRangeEndTime = endTime_NZDCAD;
                    evaluationTimeZone = timeZone_NZDCAD;
                }
                else if (Instrument.MasterInstrument.Name == "NZDCHF")
                {
                    evaluationRangeBeginTime = beginTime_NZDCHF;
                    evaluationRangeEndTime = endTime_NZDCHF;
                    evaluationTimeZone = timeZone_NZDCHF;
                }
                else if (Instrument.MasterInstrument.Name == "NZDJPY")
                {
                    evaluationRangeBeginTime = beginTime_NZDJPY;
                    evaluationRangeEndTime = endTime_NZDJPY;
                    evaluationTimeZone = timeZone_NZDJPY;
                }
                else if (Instrument.MasterInstrument.Name == "NZDUSD")
                {
                    evaluationRangeBeginTime = beginTime_NZDUSD;
                    evaluationRangeEndTime = endTime_NZDUSD;
                    evaluationTimeZone = timeZone_NZDUSD;
                }
                else
                {
                    evaluationRangeBeginTime = beginTime_Default;
                    evaluationRangeEndTime = endTime_Default;
                    evaluationTimeZone = timeZone_Default;
                }
				#endregion
				#region Public holiday inits
                publicHoliday[0] = PublicHoliday0;
                publicHoliday[1] = PublicHoliday1;
                publicHoliday[2] = PublicHoliday2;
                publicHoliday[3] = PublicHoliday3;
                publicHoliday[4] = PublicHoliday4;
                publicHoliday[5] = PublicHoliday5;
                publicHoliday[6] = PublicHoliday6;
                publicHoliday[7] = PublicHoliday7;
                publicHoliday[8] = PublicHoliday8;
                publicHoliday[9] = PublicHoliday9;
                publicHoliday[10] = PublicHoliday10;
                publicHoliday[11] = PublicHoliday11;
                publicHoliday[12] = PublicHoliday12;
                publicHoliday[13] = PublicHoliday13;
                publicHoliday[14] = PublicHoliday14;
                publicHoliday[15] = PublicHoliday15;
                publicHoliday[16] = PublicHoliday16;
                publicHoliday[17] = PublicHoliday17;
                publicHoliday[18] = PublicHoliday18;
                publicHoliday[19] = PublicHoliday19;
                publicHoliday[20] = PublicHoliday20;
                publicHoliday[21] = PublicHoliday21;
                publicHoliday[22] = PublicHoliday22;
                publicHoliday[23] = PublicHoliday23;
                publicHoliday[24] = PublicHoliday24;
                publicHoliday[25] = PublicHoliday25;
                publicHoliday[26] = PublicHoliday26;
                publicHoliday[27] = PublicHoliday27;
                publicHoliday[28] = PublicHoliday28;
                publicHoliday[29] = PublicHoliday29;
                publicHoliday[30] = PublicHoliday30;
                publicHoliday[31] = PublicHoliday31;
                publicHoliday[32] = PublicHoliday32;
                publicHoliday[33] = PublicHoliday33;
                publicHoliday[34] = PublicHoliday34;
                publicHoliday[35] = PublicHoliday35;
                publicHoliday[36] = PublicHoliday36;
                publicHoliday[37] = PublicHoliday37;
                publicHoliday[38] = PublicHoliday38;
                publicHoliday[39] = PublicHoliday39;
                publicHoliday[40] = PublicHoliday40;
                publicHoliday[41] = PublicHoliday41;
                publicHoliday[42] = PublicHoliday42;
                publicHoliday[43] = PublicHoliday43;
                publicHoliday[44] = PublicHoliday44;
                publicHoliday[45] = PublicHoliday45;
                publicHoliday[46] = PublicHoliday46;
                publicHoliday[47] = PublicHoliday47;
				#endregion

                if (UpdatePolicy == ARC_FractalConverter_UpdateFrequency.Monthly)
                    updatePeriod = 1;
                else if (UpdatePolicy == ARC_FractalConverter_UpdateFrequency.Bimonthly)
                    updatePeriod = 2;
                else if (UpdatePolicy == ARC_FractalConverter_UpdateFrequency.Quarterly)
                    updatePeriod = 3;
                else if (UpdatePolicy == ARC_FractalConverter_UpdateFrequency.Semiannually)
                    updatePeriod = 6;
                else if (UpdatePolicy == ARC_FractalConverter_UpdateFrequency.Annually)
                    updatePeriod = 12;

                divisor = 60 * (evaluationRangeEndTime.Hours - evaluationRangeBeginTime.Hours) + evaluationRangeEndTime.Minutes - evaluationRangeBeginTime.Minutes;
                if (divisor <= 0) divisor = divisor + 1440;
                tickDivisor = Math.Sqrt(divisor) * TickSize;
                if (BarsPeriods[0].BarsPeriodType == BarsPeriodType.Minute || BarsPeriods[0].BarsPeriodType == BarsPeriodType.Second)
                    tickBuilt0 = false;
                else
                    tickBuilt0 = true;
                if (Instrument.MasterInstrument.InstrumentType == Cbi.InstrumentType.Forex)
                    isCurrency = true;
                else
                    isCurrency = false;

                Plots[0].Brush = Plot0Color;
                Plots[0].Width = BarWidth;
                Plots[1].Brush = Plot1Color;
                Plots[1].Width = Plot1Width;
                Plots[1].DashStyleHelper = Dash1Style;

                textFont = new SimpleFont("Calibri", FontSize) { Bold = true };
                textFont2 = new SimpleFont("Calibri", FontSize - 4);

                Brush color = BackgroundColor;
                dataBoxColor = null;
                if (color != null)
                {
                    dataBoxColor = color.Clone();
                    dataBoxColor.Opacity = DataBoxOpacity / 100d;
                    dataBoxColor.Freeze();
                }
                
                if (ChartControl != null) ChartControl.BarsArray[0].Properties.ShowGlobalDrawObjects = false;

				FractalAvgs.Clear();
				FractalAvgs["v HT"]=new List<double>();
				FractalAvgs["v ST"]=new List<double>();
				FractalAvgs["v MT"]=new List<double>();
				FractalAvgs["r HT"]=new List<double>();
				FractalAvgs["r ST"]=new List<double>();
				FractalAvgs["r MT"]=new List<double>();
				FractalAvgSeries.Clear();
				FractalAvgSeries["v HT"] = new SortedDictionary<int,double>();
				FractalAvgSeries["v ST"] = new SortedDictionary<int,double>();
				FractalAvgSeries["v MT"] = new SortedDictionary<int,double>();
				FractalAvgSeries["r HT"] = new SortedDictionary<int,double>();
				FractalAvgSeries["r ST"] = new SortedDictionary<int,double>();
				FractalAvgSeries["r MT"] = new SortedDictionary<int,double>();

            }
            #endregion

            else if (State == State.Historical)
            {
                sessionIterator0 = new SessionIterator(BarsArray[0]);
                sessionIterator1 = new SessionIterator(BarsArray[1]);
            }
			else if (State==State.Realtime){
				LaunchTime = DateTime.Now;
			}
        }
//===============================================================================================
        #region public override string FormatPriceMarker(double price)
        public override string FormatPriceMarker(double price)
        {
            if (ConversionType == ARC_FractalConverter_ConversionType.Volume_Bars) return Math.Round(price).ToString();
            else return Math.Round(price, 1).ToString();
        }
        #endregion
//===============================================================================================
        protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
int line = 1513;
try{

//Print("BIP: "+BarsInProgress+"   Bars.Count: "+BarsArray[BarsInProgress].Count+"   "+Times[BarsInProgress][0].ToString());
        #region Calculate
            if (CurrentBars[1] > currentBars1)
            {
                currentBars1 = CurrentBars[1];
                if (State == State.Historical || Calculate == Calculate.OnBarClose)
                {
line=1522;
                    if (!initBarSeries1)
                    {
                        currentDate1 = GetLastBarSessionDate1(Times[1][0]);
                        initBarSeries1 = true;
                        return;
                    }
line=1529;
                    priorSessionVolume = sessionVolume;
                    exchangeTime       = TimeZoneInfo.ConvertTime(Times[1][0], TimeZoneInfo.Local, evaluationTimeZone);
                    lastBarTimeStamp1  = GetLastBarSessionDate1(Times[1][0]);
                    if (lastBarTimeStamp1 != currentDate1)
                    {
line=1535;
                        if (lastBarTimeStamp1 != currentDate0 && !extendPublicHoliday1)
                        {
                            newTradingDay = true;
                            if (dayCount > priorDayCount)
                            {
                                for (int i = Period - 1; i > 0; i--)
                                {
                                    volArray[i] = volArray[i - 1];
                                    rangeArray[i] = rangeArray[i - 1];
                                }
                                volArray[0] = sessionVolume;
                                rangeArray[0] = sessionHigh - sessionLow;
                                arrayCount = arrayCount + 1;
                                lookback = Math.Min(arrayCount, Period);
                                specificVolume = 0.0;
                                specificRange = 0.0;
                                iSum = 0.0;
                                for (int i = 0; i < lookback; i++)
                                {
                                    specificVolume = specificVolume + volArray[i] * (1 - i / lookback);
                                    specificRange = specificRange + rangeArray[i] * (1 - i / lookback);
                                    iSum = iSum + 1 - i / lookback;
                                }
                                specificVolume = specificVolume / (iSum * divisor);
                                specificRange = specificRange / (iSum * tickDivisor);
                                updateBarV = false;
                                updateBarR = false;
                                if (currentDate1.Month % updatePeriod == 0 && lastBarTimeStamp1.Month != currentDate1.Month)
                                {
                                    volumeFractal = specificVolume;
                                    rangeFractal = specificRange;
                                    arrayCountAtCutoffDate = arrayCount;
                                    updateBarV = true;
                                    updateBarR = true;
                                    recalculateVolumeFractals = false;
                                    recalculateRangeFractals = false;
                                    initUpdate = true;
                                }
                                else
                                {
                                    volumeDiff = 100 * (specificVolume / volumeFractal - 1.0);
                                    if (Math.Abs(volumeDiff) > percentageAdjust)
                                    {
                                        volumeFractal = specificVolume;
                                        updateBarV = true;
                                        recalculateVolumeFractals = true;
                                    }
                                    rangeDiff = 100 * (specificRange / rangeFractal - 1.0);
                                    if (Math.Abs(rangeDiff) > percentageAdjust)
                                    {
                                        rangeFractal = specificRange;
                                        updateBarR = true;
                                        recalculateRangeFractals = true;
                                    }
                                }
                            }
                            priorDayCount = dayCount;
                        }
                        isPublicHoliday = false;
                        for (int i = 0; i < 48; i++)
                        {
                            if (lastBarTimeStamp1 == publicHoliday[i])
                            {
                                isPublicHoliday = true;
                                break;
                            }
                        }
                        if (evaluationRangeBeginTime < evaluationRangeEndTime)
                        {
                            beginTime = lastBarTimeStamp1 + evaluationRangeBeginTime;
                            endTime = lastBarTimeStamp1 + evaluationRangeEndTime;
                        }
                        else
                        {
                            beginTime = lastBarTimeStamp1.AddDays(-1).Date + evaluationRangeBeginTime;
                            endTime = lastBarTimeStamp1 + evaluationRangeEndTime;
                        }
                        if (exchangeTime <= beginTime || isPublicHoliday)
                        {
                            runningSession = false;
                            sessionVolume = 0.0;
                            sessionRange = 0.0;
                        }
                        else if (exchangeTime <= endTime)
                        {
                            dayCount = dayCount + 1;
                            runningSession = true;
                            sessionVolume = Volumes[1][0];
                            sessionHigh = Highs[1][0];
                            sessionLow = Lows[1][0];
                            sessionRange = sessionHigh - sessionLow;
                        }
                        currentDate1 = lastBarTimeStamp1;  
//Print("currentDate1: "+currentDate1.ToString());
                    }
                    else if (!isPublicHoliday)
                    {
                        if (exchangeTime > beginTime && exchangeTime <= endTime)
                        {
                            if (!runningSession)
                            {
                                dayCount = dayCount + 1;
                                runningSession = true;
                                sessionVolume = Volumes[1][0];
                                sessionHigh = Highs[1][0];
                                sessionLow = Lows[1][0];
                                sessionRange = sessionHigh - sessionLow;
                            }
                            else
                            {
                                sessionVolume = sessionVolume + Volumes[1][0];
                                sessionHigh = Math.Max(sessionHigh, Highs[1][0]);
                                sessionLow = Math.Min(sessionLow, Lows[1][0]);
                                sessionRange = sessionHigh - sessionLow;
                            }
                        }
                        else if (exchangeTime > endTime && runningSession)
                            runningSession = false;
                    }
                }
                else
                {
                    if (firstRealTimeBar1 && initBarSeries1)
                    {
                        sessionVolume = priorSessionVolume;
                        firstRealTimeBar1 = false;
                    }
                    else if (!initBarSeries1)
                    {
                        currentDate1 = GetLastBarSessionDate1(Times[1][1]);
                        initBarSeries1 = true;
                        return;
                    }
                    lastBarTimeStamp1 = GetLastBarSessionDate1(Times[1][0]);
                    if (lastBarTimeStamp1 != currentDate1)
                    {
                        if (lastBarTimeStamp1 != currentDate0 && !extendPublicHoliday1)
                        {
                            newTradingDay = true;
                            if (dayCount > priorDayCount)
                            {
                                for (int i = Period - 1; i > 0; i--)
                                {
                                    volArray[i] = volArray[i - 1];
                                    rangeArray[i] = rangeArray[i - 1];
                                }
                                if (runningSession && exchangeTime <= endTime)
                                {
                                    volArray[0] = sessionVolume + Volumes[1][1];
                                    rangeArray[0] = Math.Max(sessionHigh, Highs[1][1]) - Math.Min(sessionLow, Lows[1][1]);
                                }
                                else
                                {
                                    volArray[0] = sessionVolume;
                                    rangeArray[0] = sessionHigh - sessionLow;
                                }
                                arrayCount = arrayCount + 1;
                                lookback = Math.Min(arrayCount, Period);
                                specificVolume = 0.0;
                                specificRange = 0.0;
                                iSum = 0.0;
                                for (int i = 0; i < lookback; i++)
                                {
                                    specificVolume = specificVolume + volArray[i] * (1 - i / lookback);
                                    specificRange = specificRange + rangeArray[i] * (1 - i / lookback);
                                    iSum = iSum + 1 - i / lookback;
                                }
                                specificVolume = specificVolume / (iSum * divisor);
                                specificRange  = specificRange / (iSum * tickDivisor);
                                updateBarV = false;
                                updateBarR = false;
                                if (currentDate1.Month % updatePeriod == 0 && lastBarTimeStamp1.Month != currentDate1.Month)
                                {
                                    volumeFractal = specificVolume;
                                    rangeFractal = specificRange;
                                    arrayCountAtCutoffDate = arrayCount;
                                    updateBarV = true;
                                    updateBarR = true;
                                    recalculateVolumeFractals = false;
                                    recalculateRangeFractals = false;
                                    initUpdate = true;
                                }
                                else
                                {
                                    volumeDiff = 100 * (specificVolume / volumeFractal - 1.0);
                                    if (Math.Abs(volumeDiff) > percentageAdjust)
                                    {
                                        volumeFractal = specificVolume;
                                        updateBarV = true;
                                        recalculateVolumeFractals = true;
                                    }
                                    rangeDiff = 100 * (specificRange / rangeFractal - 1.0);
                                    if (Math.Abs(rangeDiff) > percentageAdjust)
                                    {
                                        rangeFractal = specificRange;
                                        updateBarR = true;
                                        recalculateRangeFractals = true;
                                    }
                                }
                            }
                            priorDayCount = dayCount;
                        }
line=1741;
                        isPublicHoliday = false;
                        for (int i = 0; i < 48; i++)
                        {
                            if (lastBarTimeStamp1 == publicHoliday[i])
                            {
                                isPublicHoliday = true;
                                break;
                            }
                        }
                        exchangeTime = TimeZoneInfo.ConvertTime(Times[1][0], TimeZoneInfo.Local, evaluationTimeZone);
                        if (evaluationRangeBeginTime < evaluationRangeEndTime)
                        {
                            beginTime = lastBarTimeStamp1 + evaluationRangeBeginTime;
                            endTime = lastBarTimeStamp1 + evaluationRangeEndTime;
                        }
                        else
                        {
                            beginTime = lastBarTimeStamp1.AddDays(-1).Date + evaluationRangeBeginTime;
                            endTime = lastBarTimeStamp1 + evaluationRangeEndTime;
                        }
                        if (exchangeTime <= beginTime || isPublicHoliday)
                        {
                            runningSession = false;
                            sessionVolume = 0.0;
                            sessionRange = 0.0;
                        }
                        else
                        {
                            dayCount = dayCount + 1;
                            runningSession = true;
                            sessionVolume = 0.0;
                            sessionHigh = Highs[1][0];
                            sessionLow = Lows[1][0];
                            sessionRange = sessionHigh - sessionLow;
                        }
                        currentDate1 = lastBarTimeStamp1;
                    }
                    else if (!isPublicHoliday)
                    {
line=1781;
                        exchangeTime = TimeZoneInfo.ConvertTime(Times[1][0], TimeZoneInfo.Local, evaluationTimeZone);
                        if (exchangeTime > beginTime && exchangeTime <= endTime)
                        {
                            if (!runningSession)
                            {
                                dayCount = dayCount + 1;
                                runningSession = true;
                                sessionVolume = Volumes[1][1];
                                sessionHigh = Highs[1][1];
                                sessionLow = Lows[1][1];
                                sessionRange = sessionHigh - sessionLow;
                            }
                            else
                            {
                                sessionVolume = sessionVolume + Volumes[1][1];
                                sessionHigh = Math.Max(sessionHigh, Highs[1][1]);
                                sessionLow = Math.Min(sessionLow, Lows[1][1]);
                                sessionRange = sessionHigh - sessionLow;
                            }
                        }
                        else if (exchangeTime > endTime && runningSession)
                        {
                            sessionVolume = sessionVolume + Volumes[1][1];
                            sessionHigh = Math.Max(sessionHigh, Highs[1][1]);
                            sessionLow = Math.Min(sessionLow, Lows[1][1]);
                            sessionRange = sessionHigh - sessionLow;
                            runningSession = false;
                        }
                    }
                }
            }

            if (BarsInProgress == 0)
            {
line=1816;
                if (IsFirstTickOfBar && BarsArray[0].IsFirstBarOfSession)
                {
                    lastBarTimeStamp0 = GetLastBarSessionDate0(Times[0][0]);
                    if (lastBarTimeStamp0 != currentDate0)
                    {
                        if (lastBarTimeStamp0 != currentDate1 && !extendPublicHoliday0)
                        {
                            newTradingDay = true;
                            if (dayCount > priorDayCount)
                            {
                                for (int i = Period - 1; i > 0; i--)
                                {
                                    volArray[i] = volArray[i - 1];
                                    rangeArray[i] = rangeArray[i - 1];
                                }
                                if (State!=State.Historical && Calculate!=Calculate.OnBarClose && runningSession && exchangeTime <= endTime)
                                {
                                    volArray[0] = sessionVolume + Volumes[1][1];
                                    rangeArray[0] = Math.Max(sessionHigh, Highs[1][1]) - Math.Min(sessionLow, Lows[1][1]);
                                }
                                else
                                {
                                    volArray[0] = sessionVolume;
                                    rangeArray[0] = sessionHigh - sessionLow;
                                }
                                arrayCount = arrayCount + 1;
                                lookback = Math.Min(arrayCount, Period);
                                specificVolume = 0.0;
                                specificRange = 0.0;
                                iSum = 0.0;
                                for (int i = 0; i < lookback; i++)
                                {
                                    specificVolume = specificVolume + volArray[i] * (1 - i / lookback);
                                    specificRange = specificRange + rangeArray[i] * (1 - i / lookback);
                                    iSum = iSum + 1 - i / lookback;
                                }
                                specificVolume = specificVolume / (iSum * divisor);
                                specificRange = specificRange / (iSum * tickDivisor);
                                updateBarV = false;
                                updateBarR = false;
                                if (currentDate0.Month % updatePeriod == 0 && lastBarTimeStamp0.Month != currentDate0.Month)
                                {
                                    volumeFractal = specificVolume;
                                    rangeFractal = specificRange;
                                    arrayCountAtCutoffDate = arrayCount;
                                    updateBarV = true;
                                    updateBarR = true;
                                    recalculateVolumeFractals = false;
                                    recalculateRangeFractals = false;
                                    initUpdate = true;
                                }
                                else
                                {
                                    volumeDiff = 100 * (specificVolume / volumeFractal - 1.0);
                                    if (Math.Abs(volumeDiff) > percentageAdjust)
                                    {
                                        volumeFractal = specificVolume;
                                        updateBarV = true;
                                        recalculateVolumeFractals = true;
                                    }
                                    rangeDiff = 100 * (specificRange / rangeFractal - 1.0);
                                    if (Math.Abs(rangeDiff) > percentageAdjust)
                                    {
                                        rangeFractal = specificRange;
                                        updateBarR = true;
                                        recalculateRangeFractals = true;
                                    }
                                }
                            }
                            priorDayCount = dayCount;
                        }
                        currentDate0 = lastBarTimeStamp0;
                    }
                }
line=1891;

                VolumeDeviation[0]        = volumeDiff;
                CurrentVolumeFractal[0]   = specificVolume;
                DisplayedVolumeFractal[0] = volumeFractal;
                DailyVolume[0]            = sessionVolume / divisor;

				if (updateBarV)      updateBarVSeries[0] = CurrentBars[0];
                else if (initUpdate) updateBarVSeries[0] = updateBarVSeries[1];
                else                 updateBarVSeries[0] = 0;

                recalcVolumeFractals[0]  = recalculateVolumeFractals;
                RangeDeviation[0]        = rangeDiff;
                CurrentRangeFractal[0]   = specificRange;
                DisplayedRangeFractal[0] = rangeFractal;
                DailyRange[0]            = sessionRange / tickDivisor;
                if (updateBarR) updateBarRSeries[0] = CurrentBars[0];
                else if(CurrentBars[0]>0){
					updateBarRSeries[0] = updateBarRSeries[1];
				}else
					updateBarRSeries[0] = 0;
                recalcRangeFractals[0] = recalculateRangeFractals;
                volumeFractalHT[0] = Convert.ToInt32(Math.Round(volumeFractal * conversionFactorHT));
                volumeFractalST[0] = Convert.ToInt32(Math.Round(volumeFractal * conversionFactorST));
                volumeFractalMT[0] = Convert.ToInt32(Math.Round(volumeFractal * conversionFactorMT));
                rangeFractalHT[0]  = Convert.ToInt32(Math.Round(rangeFractal * sqrtConversionFactorHT));
                rangeFractalST[0]  = Convert.ToInt32(Math.Round(rangeFractal * sqrtConversionFactorST));
                rangeFractalMT[0]  = Convert.ToInt32(Math.Round(rangeFractal * sqrtConversionFactorMT));
//if(CurrentBars[0]>0) Print(Times[0][0].ToString()+"  volumeFractalHT[0]: "+volumeFractalHT[0]+"   "+(volumeFractalHT[1]!=volumeFractalHT[0] ? "NEW":""));

                if (ConversionType == ARC_FractalConverter_ConversionType.Volume_Bars)
                {
                    DailyFractal[0] = Math.Round(sessionVolume / divisor);
                    DisplayedFractal[0] = Math.Round(volumeFractal);
                }
                else if (ConversionType == ARC_FractalConverter_ConversionType.Range_Bars)
                {
                    DailyFractal[0] = Math.Round(sessionRange / tickDivisor, 2);
                    DisplayedFractal[0] = Math.Round(rangeFractal, 2);
                }
                if (arrayCountAtCutoffDate < Period)
                {
                    PlotBrushes[0][0] = DevelopingColor;
                    DaysUsedForCalculation[0] = arrayCountAtCutoffDate;
                }
                else{
					if(volumeFractalHT[1]!=volumeFractalHT[0]) {
						FractalAvgs["v HT"].Add(volumeFractalHT[0]);
//Print(FractalAvgs["v HT"].Count+"-values:  New FractalAvgs 'v HT': "+volumeFractalHT[0]);
					}
					if(volumeFractalST[1]!=volumeFractalST[0]) {
						FractalAvgs["v ST"].Add(volumeFractalST[0]);
					}
					if(volumeFractalMT[1]!=volumeFractalMT[0]) {
						FractalAvgs["v MT"].Add(volumeFractalMT[0]);
					}
					if(rangeFractalHT[1] != rangeFractalHT[0]) {
						FractalAvgs["r HT"].Add(rangeFractalHT[0]);
					}
					if(rangeFractalST[1] != rangeFractalST[0]) {
						FractalAvgs["r ST"].Add(rangeFractalST[0]);
					}
					if(rangeFractalMT[1] != rangeFractalMT[0]) {
						FractalAvgs["r MT"].Add(rangeFractalMT[0]);
					}
                    DaysUsedForCalculation[0] = Period;
				}
            }
        #endregion
line=1988;
			UpdateFractalAvgData("v HT");
			UpdateFractalAvgData("v ST");
			UpdateFractalAvgData("v MT");
			UpdateFractalAvgData("r HT");
			UpdateFractalAvgData("r ST");
			UpdateFractalAvgData("r MT");
}catch(Exception e){Print("------"+Environment.NewLine+line+":  "+e.ToString()+Environment.NewLine+"-----");}
			try{
			if(false && CurrentBars[0] > BarsArray[0].Count-3 && !SavedDataToFiles){
				#region Save Data To Files
				Print("Saving FractalConverter data to: "+FCDatabase_FileNameHT);
				string outstr = string.Empty;
				if(FractalAvgSeries["v HT"][CurrentBars[0]]==0) {
					outstr = "Vol|"+this.S_CustomPeriodHT+"|0";
					Print(Instrument.FullName+" Vol HigherTime "+this.S_CustomPeriodHT+   " is zero!  Total bars: "+BarsArray[0].Count+"  Lookback "+this.lookback);
				} else {
					outstr = "Vol|"+FractalAvgSeries["v HT"][CurrentBars[0]].ToString("0");
				}
				if(FractalAvgSeries["r HT"][CurrentBars[0]]==0) {
					outstr = outstr+Environment.NewLine+"Range|0";
					Print(Instrument.FullName+" Range HigherTime "+this.S_CustomPeriodHT+   " is zero!  Total bars: "+BarsArray[0].Count+"  Lookback "+this.lookback);
				} else {
					outstr = outstr+Environment.NewLine+"Range|"+FractalAvgSeries["r HT"][CurrentBars[0]];
				}
				//Print(outstr);
				System.IO.File.WriteAllText(FCDatabase_FileNameHT, outstr);

				Print("Saving FractalConverter data to: "+FCDatabase_FileNameST);
				outstr = string.Empty;
				if(FractalAvgSeries["v ST"][CurrentBars[0]]==0) {
					outstr = "Vol|0";
					Print(Instrument.FullName+" Vol SmallerTime "+this.S_CustomPeriodST+   " is zero!  Total bars: "+BarsArray[0].Count+"  Lookback "+this.lookback);
				} else {
					outstr = "Vol|"+FractalAvgSeries["v ST"][CurrentBars[0]].ToString("0");
				}
				if(FractalAvgSeries["r ST"][CurrentBars[0]]==0) {
					outstr = outstr+Environment.NewLine+"Range|0";
					Print(Instrument.FullName+" Range SmallerTime "+this.S_CustomPeriodST+   " is zero!  Total bars: "+BarsArray[0].Count+"  Lookback "+this.lookback);
				} else {
					outstr = outstr+Environment.NewLine+"Range|"+FractalAvgSeries["r ST"][CurrentBars[0]];
				}
				//Print(outstr);
				System.IO.File.WriteAllText(FCDatabase_FileNameST, outstr);

				Print("Saving FractalConverter data to: "+FCDatabase_FileNameMT);
				outstr = string.Empty;
				if(FractalAvgSeries["v MT"][CurrentBars[0]]==0) {
					outstr = "Vol|0";
					Print(Instrument.FullName+" Vol SmallerTime "+this.S_CustomPeriodMT+   " is zero!  Total bars: "+BarsArray[0].Count+"  Lookback "+this.lookback);
				} else {
					outstr = "Vol|"+FractalAvgSeries["v MT"][CurrentBars[0]].ToString("0");
				}
				if(FractalAvgSeries["r MT"][CurrentBars[0]]==0) {
					outstr = outstr+Environment.NewLine+"Range|0";
					Print(Instrument.FullName+" Range SmallerTime "+this.S_CustomPeriodMT+   " is zero!  Total bars: "+BarsArray[0].Count+"  Lookback "+this.lookback);
				} else {
					outstr = outstr+Environment.NewLine+"Range|"+FractalAvgSeries["r MT"][CurrentBars[0]];
				}
				//Print(outstr);
				System.IO.File.WriteAllText(FCDatabase_FileNameMT, outstr);
				#endregion
				SavedDataToFiles = true;
			}
			}catch(Exception err){Print("Error: "+err.ToString());}
        }
		//================================================
		private void UpdateFractalAvgData(string tag){
			if(FractalAvgs[tag].Count>0){
				FractalAvgSeries[tag][CurrentBars[0]] = FractalAvgs[tag].Average();
			}else 
				FractalAvgSeries[tag][CurrentBars[0]] = 0;
		}
//===============================================================================================
		private string StripOutIllegalCharacters(string name, string ReplacementString){
			#region strip
			char[] invalidPathChars = System.IO.Path.GetInvalidPathChars();
			string invalids = string.Empty;
			foreach(char ch in invalidPathChars){
				invalids += ch.ToString();
			}
//			Print("Invalid chars: '"+invalids+"'");
			string result = string.Empty;
			for(int c=0; c<name.Length; c++) {
				if(!invalids.Contains(name[c].ToString())) result += name[c];
				else result += ReplacementString;
			}
			return result;
			#endregion
		}
//===============================================================================================
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
//int line=1958;
            #region -- conditions to return --
            if (!IsVisible || Bars == null || ChartControl == null || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
            if (ChartPanel.H < 61) return;
            #endregion
//try{
            int lastBarIndex = Math.Min(CurrentBars[0], ChartBars.ToIndex);//RIGHT BAR idx (slot)
            int firstBarIndex = Math.Max(BarsRequiredToPlot, ChartBars.FromIndex);//LEFT BAR idx (slot)
            #region -- Set Text Colors --
            if (DaysUsedForCalculation.GetValueAt(lastBarIndex) < Period)
            {
                fullPeriod = false;
                dataBrush = DevelopingColor;
                volumeBrush = DevelopingColor;
                rangeBrush = DevelopingColor;
            }
            else
            {
                fullPeriod = true;
                dataBrush = TextColor;
                if (recalcVolumeFractals.GetValueAt(lastBarIndex)) volumeBrush = AlertColor;
                else volumeBrush = TextColor;
                if (recalcRangeFractals.GetValueAt(lastBarIndex)) rangeBrush = AlertColor;
                else rangeBrush = TextColor;
            }
            #endregion

            updateBarVolume = updateBarVSeries.GetValueAt(lastBarIndex);
            updateBarRange = updateBarRSeries.GetValueAt(lastBarIndex);

            #region -- Calculate FontSize and margin depending on Chart size --
            stringHeight = (float)textFont.Size;
            if (0.96f * ChartPanel.H < 6.0f * stringHeight)
            {
                newFontSize = Convert.ToInt16(0.96f * ChartPanel.H / 9.6f);
                newTextFont = new SimpleFont("Calibri", Math.Max(6, newFontSize));
                newTextFont2 = new SimpleFont("Calibri", Math.Max(6, newFontSize - 4));
                newStringHeight = (float)newTextFont.Size;
                upperMargin = 0f;
            }
            else
            {
                newTextFont = textFont;
                newTextFont2 = textFont2;
                newStringHeight = (float)textFont.Size;
                upperMargin = 0.48f * (float)ChartPanel.H - 3.0f * (float)textFont.Size;
            }
            #endregion

            #region -- Calculate Vertical Positions --
            boundsY = ChartPanel.Y + upperMargin;
            pos1 = boundsY + 0.3f * newStringHeight;
            pos2 = boundsY + 1.3f * newStringHeight;
            pos3 = boundsY + 2.5f * newStringHeight;
            pos4 = boundsY + 3.5f * newStringHeight;
            pos5 = boundsY + 4.5f * newStringHeight;
            #endregion

			var volTxt = new List<string>();
			var rngTxt = new List<string>();
			string str=string.Empty;
			maxStringWidth = 0f;
            #region -- Calculate Horizontal Positions --
            if (fullPeriod)
	            maxStringWidth1 = getTextWidth("Last Update", newTextFont2);
            else
	            maxStringWidth1 = getTextWidth(Convert.ToString(DaysUsedForCalculation.GetValueAt(lastBarIndex)) + " Days / Last Update", newTextFont2);
			maxStringWidth1 = Math.Max(maxStringWidth1, getTextWidth("HTF", newTextFont)) * 1.2f;
//=========================================================================================================================================
//			Column 2
//=========================================================================================================================================
            maxStringWidth2 = getTextWidth("  Time  ", newTextFont);
			maxStringWidth2 = Math.Max(maxStringWidth2, getTextWidth(timeBasedHT, newTextFont));
			maxStringWidth2 = Math.Max(maxStringWidth2, getTextWidth(timeBasedST, newTextFont));
			maxStringWidth2 = Math.Max(maxStringWidth2, getTextWidth(timeBasedMT, newTextFont)) * 1.2f;
//=========================================================================================================================================
//			Column 3
//=========================================================================================================================================
			var DataShortage = false;
			if(FractalAvgSeries["v HT"].ContainsKey(lastBarIndex)) {
				if(FractalAvgSeries["v HT"][lastBarIndex]==0) DataShortage = true;//Msg = "Load more days of data, or reduce the 'Lookback period' parameter value";
//foreach(var kvp in FractalAvgSeries["v HT"])Print(kvp.Key+": "+kvp.Value);
				str = string.Format("{0} V ~{1:0}", Convert.ToString(volumeFractalHT.GetValueAt(lastBarIndex)),FractalAvgSeries["v HT"][lastBarIndex]);
//Print("FractalAvgSeries[v HT][lastBarIndex]: "+FractalAvgSeries["v HT"][lastBarIndex]);
			}else 
				str = string.Format("{0} V",Convert.ToString(volumeFractalHT.GetValueAt(lastBarIndex)));
            maxStringWidth3 = getTextWidth(str, newTextFont);
			volTxt.Add(str);
//=========================================================================================================================================
			if(FractalAvgSeries["v ST"].ContainsKey(lastBarIndex)) {
				if(FractalAvgSeries["v ST"][lastBarIndex]==0) DataShortage = true;//Msg = "Load more days of data, or reduce the 'Lookback period' parameter value";
				str = string.Format("{0} V ~{1:0}", Convert.ToString(volumeFractalST.GetValueAt(lastBarIndex)),FractalAvgSeries["v ST"][lastBarIndex]);
			}else 
				str = string.Format("{0} V",Convert.ToString(volumeFractalST.GetValueAt(lastBarIndex)));
            maxStringWidth3 = Math.Max(maxStringWidth3,getTextWidth(str, newTextFont));
			volTxt.Add(str);
//=========================================================================================================================================
			if(FractalAvgSeries["v MT"].ContainsKey(lastBarIndex)) {
				if(FractalAvgSeries["v MT"][lastBarIndex]==0) DataShortage = true;//Msg = "Load more days of data, or reduce the 'Lookback period' parameter value";
				str = string.Format("{0} V ~{1:0}", Convert.ToString(volumeFractalMT.GetValueAt(lastBarIndex)),FractalAvgSeries["v MT"][lastBarIndex]);
			}else 
				str = string.Format("{0} V", Convert.ToString(volumeFractalMT.GetValueAt(lastBarIndex)));
            maxStringWidth3 = Math.Max(maxStringWidth3, getTextWidth(str, newTextFont)) * 1.2f;
			volTxt.Add(str);

//=========================================================================================================================================
//			Column 4
//=========================================================================================================================================
			if(FractalAvgSeries["r HT"].ContainsKey(lastBarIndex)) {
				if(FractalAvgSeries["r HT"][lastBarIndex]==0) DataShortage = true;//Msg = "Load more days of data, or reduce the 'Lookback period' parameter value";
				str = string.Format("{0} R ~{1:0}", Convert.ToString(rangeFractalHT.GetValueAt(lastBarIndex)),FractalAvgSeries["r HT"][lastBarIndex]);
			}else 
				str = string.Format("{0} R", Convert.ToString(rangeFractalHT.GetValueAt(lastBarIndex)));
            maxStringWidth4 = getTextWidth(str, newTextFont);
			rngTxt.Add(str);
//=========================================================================================================================================
			if(FractalAvgSeries["r ST"].ContainsKey(lastBarIndex)) {
				if(FractalAvgSeries["r ST"][lastBarIndex]==0) DataShortage = true;//Msg = "Load more days of data, or reduce the 'Lookback period' parameter value";
				str = string.Format("{0} R ~{1:0}", Convert.ToString(rangeFractalST.GetValueAt(lastBarIndex)),FractalAvgSeries["r ST"][lastBarIndex]);
			}else 
				str = string.Format("{0} R",Convert.ToString(rangeFractalST.GetValueAt(lastBarIndex)));
            maxStringWidth4 = Math.Max(maxStringWidth4, getTextWidth(str, newTextFont));
			rngTxt.Add(str);
//=========================================================================================================================================
			if(FractalAvgSeries["r MT"].ContainsKey(lastBarIndex)) {
				if(FractalAvgSeries["r MT"][lastBarIndex]==0) DataShortage = true;//Msg = "Load more days of data, or reduce the 'Lookback period' parameter value";
				str = string.Format("{0} R ~{1:0}",Convert.ToString(rangeFractalMT.GetValueAt(lastBarIndex)),FractalAvgSeries["r MT"][lastBarIndex]);
			}else 
				str = string.Format("{0} R",Convert.ToString(rangeFractalMT.GetValueAt(lastBarIndex)));
            maxStringWidth4 = Math.Max(maxStringWidth4, getTextWidth(str, newTextFont)) * 1.2f;
			rngTxt.Add(str);

			var ts = new TimeSpan(DateTime.Now.Ticks - LaunchTime.Ticks);
			if(DataShortage && ts.Seconds<20){
				Draw.TextFixed(this,"DataShortage", Math.Max(20-ts.Seconds,0).ToString("0")+"  Load more days of data, or reduce the 'Lookback period' parameter value", TextPosition.TopRight, Brushes.Black, ChartControl.Properties.LabelFont, Brushes.White, Brushes.White,100);
			}else RemoveDrawObject("DataShortage");
//=========================================================================================================================================
			maxStringWidth = (maxStringWidth1 + maxStringWidth2 + maxStringWidth3 + maxStringWidth4)*1.1f;
//=========================================================================================================================================
            offset1 = Convert.ToSingle(ChartPanel.X + ChartPanel.W) - maxStringWidth;
            offset2 = offset1 + maxStringWidth1;
            offset3 = offset2 + maxStringWidth2;
            offset4 = offset3 + maxStringWidth3;
            #endregion
            ChartControl.Properties.BarMarginRight = Convert.ToInt32(1.1f * maxStringWidth);
            
            //Hide bars on the chart
            drawRectangle(ChartPanel.X, ChartPanel.Y, ChartPanel.W, ChartPanel.H, Brushes.White, 100);

            //draw box
            drawRectangle(offset1 - 0.025f * maxStringWidth, ChartPanel.Y + 0.01f * ChartPanel.H, 1.05f * maxStringWidth, 0.97f * ChartPanel.H, dataBoxColor, 100);

            #region -- Column 1 --
            drawstring(headline, offset1, pos1, newTextFont, dataBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth1);
            if (fullPeriod)
                drawstring("Last Update", offset1, pos2, newTextFont2, dataBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth1);
            else
                drawstring(Convert.ToString(DaysUsedForCalculation.GetValueAt(lastBarIndex)) + " Days / Last Update", offset1, pos2, newTextFont2, dataBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth1);
            drawstring("HTF", offset1, pos3, newTextFont, dataBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth1);
            drawstring("STF", offset1, pos4, newTextFont, dataBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth1);
            drawstring("MTF", offset1, pos5, newTextFont, dataBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth1);
            #endregion

            #region -- Column 2 --
            drawstring("Time",      offset2, pos1, newTextFont, dataBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth2);
            drawstring(timeBasedHT, offset2, pos3, newTextFont, dataBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth2);
            drawstring(timeBasedST, offset2, pos4, newTextFont, dataBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth2);
            drawstring(timeBasedMT, offset2, pos5, newTextFont, dataBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth2);
            #endregion

			//string txt=null;
            #region -- Column 3 --
            drawstring("Volume",                     offset3, pos1, newTextFont, volumeBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth3);
            drawstring(BarsArray[0].GetSessionEndTime(updateBarVolume).ToShortDateString(), offset3, pos2, newTextFont2, volumeBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth3);
//			if(FractalAvgSeries["v HT"].ContainsKey(lastBarIndex)) 
//				txt = string.Format("{0} V ~{1:0}",Convert.ToString(volumeFractalHT.GetValueAt(lastBarIndex)),FractalAvgSeries["v HT"][lastBarIndex]);
//			else 
//				txt = string.Format("{0} V",Convert.ToString(volumeFractalHT.GetValueAt(lastBarIndex)));
            if(volTxt.Count>0) drawstring(volTxt[0], offset3, pos3, newTextFont, volumeBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth3);

//			if(FractalAvgSeries["v ST"].ContainsKey(lastBarIndex)) 
//				txt = string.Format("{0} V ~{1:0}",Convert.ToString(volumeFractalST.GetValueAt(lastBarIndex)),FractalAvgSeries["v ST"][lastBarIndex]);
//			else 
//				txt = string.Format("{0} V",Convert.ToString(volumeFractalST.GetValueAt(lastBarIndex)));
            if(volTxt.Count>1) drawstring(volTxt[1], offset3, pos4, newTextFont, volumeBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth3);
			
//			if(FractalAvgSeries["v MT"].ContainsKey(lastBarIndex)) 
//				txt = string.Format("{0} V ~{1:0}",Convert.ToString(volumeFractalMT.GetValueAt(lastBarIndex)),FractalAvgSeries["v MT"][lastBarIndex]);
//			else 
//				txt = string.Format("{0} V",Convert.ToString(volumeFractalMT.GetValueAt(lastBarIndex)));
            if(volTxt.Count>2) drawstring(volTxt[2], offset3, pos5, newTextFont, volumeBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth3);
            #endregion

            #region -- Column 4 --
            drawstring("Range",                      offset4, pos1, newTextFont, rangeBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth4);
            drawstring(BarsArray[0].GetSessionEndTime(updateBarRange).ToShortDateString(), offset4, pos2, newTextFont2, rangeBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth4);
//			if(FractalAvgSeries["r HT"].ContainsKey(lastBarIndex)) 
//				txt = string.Format("{0} R ~{1:0}",Convert.ToString(rangeFractalHT.GetValueAt(lastBarIndex)),FractalAvgSeries["r HT"][lastBarIndex]);
//			else 
//				txt = string.Format("{0} R",Convert.ToString(rangeFractalHT.GetValueAt(lastBarIndex)));
            if(rngTxt.Count>0) drawstring(rngTxt[0], offset4, pos3, newTextFont, rangeBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth4);

//			if(FractalAvgSeries["r ST"].ContainsKey(lastBarIndex)) 
//				txt = string.Format("{0} R ~{1:0}",Convert.ToString(rangeFractalST.GetValueAt(lastBarIndex)),FractalAvgSeries["r ST"][lastBarIndex]);
//			else 
//				txt = string.Format("{0} R",Convert.ToString(rangeFractalST.GetValueAt(lastBarIndex)));
            if(rngTxt.Count>1) drawstring(rngTxt[1], offset4, pos4, newTextFont, rangeBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth4);

//			if(FractalAvgSeries["r MT"].ContainsKey(lastBarIndex)) 
//				txt = string.Format("{0} R ~{1:0}",Convert.ToString(rangeFractalMT.GetValueAt(lastBarIndex)),FractalAvgSeries["r MT"][lastBarIndex]);
//			else 
//				txt = string.Format("{0} R",Convert.ToString(rangeFractalMT.GetValueAt(lastBarIndex)));
            if(rngTxt.Count>2)drawstring(rngTxt[2], offset4, pos5, newTextFont, rangeBrush, SharpDX.DirectWrite.TextAlignment.Center, maxStringWidth4);
            #endregion

            // loop through all the visable bars on the chart
            for (int i = ChartBars.ToIndex - 1; i >= ChartBars.ToIndex - 10; i--)
            {
                double value = GetValueAt(i);
                //Print(string.Format("The value at bar {0} is {1}", i, value));
            }
//}catch(Exception err){Print(line+":  "+err.ToString());}

            base.OnRender(chartControl, chartScale);
        }
//===============================================================================================


        //-------------------- private Functions -------------------------
        private DateTime GetLastBarSessionDate0(DateTime time)
        {
            bool isNewSession = sessionIterator0.IsNewSession(time, true);
            if (isNewSession)
            {
                sessionIterator0.CalculateTradingDay(time, true);

                extendPublicHoliday0 = false;
                for (int i = 0; i < 48; i++) if (publicHoliday[i].Date == sessionDateTmp1) extendPublicHoliday0 = true;

                //sessionDateTmp0 = sessionIterator0.GetTradingDayEndLocal(time);
                sessionDateTmp0 = sessionIterator0.ActualTradingDayExchange;
            }
            return sessionDateTmp1;
        }
        private DateTime GetLastBarSessionDate1(DateTime time)
        {
            bool isNewSession = sessionIterator1.IsNewSession(time, true);
            if (isNewSession)
            {
                sessionIterator1.CalculateTradingDay(time, true);

                extendPublicHoliday1 = false;
                for (int i = 0; i < 48; i++) if (publicHoliday[i].Date == sessionDateTmp1) extendPublicHoliday1 = true;

                //sessionDateTmp1 = sessionIterator1.GetTradingDayEndLocal(time);
                sessionDateTmp1 = sessionIterator1.ActualTradingDayExchange;
            }
            return sessionDateTmp1;
        }

        #region -- custom drawing Functions from AzurITec --
        private float getTextWidth(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }
        private void drawstring(string text, double x, double y, SimpleFont font, Brush textBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                )
            { TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textBrush.ToDxBrush(RenderTarget), SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
        }
        private void drawRectangle(double x, double y, double w, double h, Brush color, double opacity)
        {
            drawRegion(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, color, color.Opacity);
        }
        //Draw Region between 4 points. Coordinates are in pixel.
        private void drawRegion(Point[] points, Brush color, double opacity)
        {
            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            linebrush.Opacity = (float)opacity;

            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, linebrush);
            geo1.Dispose();
            sink1.Dispose();
            linebrush.Dispose();
        }
        #endregion
        

        //-------------------- Nested Classes --------------------------
        internal class TZListConverter : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }/*true means show a combobox*/
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
            {
                //true will limit to list. false will show the list, 
                //but allow free-form entry
                return true;
            }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection((TimeZoneInfo.GetSystemTimeZones()).Select(x => x.DisplayName).ToList());
            }
        }
        

        //------------------ Properties --------------------------
        #region -- DataSeries --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> DailyFractal { get { return Values[0]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> DisplayedFractal { get { return Values[1]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> CurrentVolumeFractal { get; set; }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> DisplayedVolumeFractal { get; set; }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> DailyVolume { get; set; }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> CurrentRangeFractal { get; set; }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> DisplayedRangeFractal { get; set; }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> DailyRange { get; set; }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> VolumeDeviation { get; set; }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> RangeDeviation { get; set; }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<int> DaysUsedForCalculation { get; set; }
        #endregion

        #region -- Properties --
        [Range(1, int.MaxValue)]
        [Display(Name = "Lookback period", GroupName = "General Parameters", Description = "Number of bars used to calculate the average daily volume for the selected reference period", Order = 0)]
        public int Period { get; set; }

        [Display(Name = "Update Frequency", GroupName = "General Parameters", Description = "Selected frequency for updating volume and range equivalents of minute bars", Order = 1)]
        public ARC_FractalConverter_UpdateFrequency UpdatePolicy { get; set; }

        [Display(Name = "Adjust when fractals change", GroupName = "General Parameters", Description = "Shows a message on the chart, when the bar period has changed more than the selected amount", Order = 2)]
        public string S_PercentageAdjust
        {
            get
            {
                if (percentageAdjust < 10)
                    return string.Format("{0:D1} {1:D1}", percentageAdjust, "%");
                else
                    return string.Format("{0:D2} {1:D1}", percentageAdjust, "%");
            }
            set
            {
                string[] values = ((string)value).Split(' ');
                percentageAdjust = Math.Max(1, Convert.ToInt32(values[0]));
            }
        }

        //---------------------- Timeframe Parameters ---------------------
        [Display(Name = "a. Higher timeframe", GroupName = "Timeframe Parameters", Description = "Bar period used for the higher timeframe chart", Order = 0)]
        public string S_CustomPeriodHT
        {
            get
            {
                if (customPeriodHT < 10)
                    return string.Format("{0:D1} {1:D3}", customPeriodHT, "min");
                else if (customPeriodHT < 100)
                    return string.Format("{0:D2} {1:D3}", customPeriodHT, "min");
                else if (customPeriodHT < 1000)
                    return string.Format("{0:D3} {1:D3}", customPeriodHT, "min");
                else
                    return string.Format("{0:D4} {1:D3}", customPeriodHT, "min");
            }
            set
            {
                string[] values = ((string)value).Split(' ');
                customPeriodHT = Math.Max(1, Convert.ToInt32(values[0]));
            }
        }

        [Display(Name = "b. Smaller timeframe", GroupName = "Timeframe Parameters", Description = "Bar period used for the smaller timeframe chart", Order = 1)]
        public string S_CustomPeriodST
        {
            get
            {
                if (customPeriodST < 10)
                    return string.Format("{0:D1} {1:D3}", customPeriodST, "min");
                else if (customPeriodST < 100)
                    return string.Format("{0:D2} {1:D3}", customPeriodST, "min");
                else if (customPeriodST < 1000)
                    return string.Format("{0:D3} {1:D3}", customPeriodST, "min");
                else
                    return string.Format("{0:D4} {1:D3}", customPeriodST, "min");
            }
            set
            {
                string[] values = ((string)value).Split(' ');
                customPeriodST = Math.Max(1, Convert.ToInt32(values[0]));
            }
        }

        [Display(Name = "c. Micro timeframe", GroupName = "Timeframe Parameters", Description = "Bar period used for the high resolution micro  timeframe chart", Order = 2)]
        public string S_CustomPeriodMT
        {
            get
            {
                if (customPeriodMT < 10)
                    return string.Format("{0:D1} {1:D3}", customPeriodMT, "sec");
                else if (customPeriodMT < 100)
                    return string.Format("{0:D2} {1:D3}", customPeriodMT, "sec");
                else if (customPeriodMT < 1000)
                    return string.Format("{0:D3} {1:D3}", customPeriodMT, "sec");
                else
                    return string.Format("{0:D4} {1:D3}", customPeriodMT, "sec");
            }
            set
            {
                string[] values = ((string)value).Split(' ');
                customPeriodMT = Math.Max(1, Convert.ToInt32(values[0]));
            }
        }

        //---------------------- Display Options - General ---------------------
        [Display(Name = "Select histogram", GroupName = "Display Options - General", Description = "Allows to display volume or range values via the histogram", Order = 0)]
        public ARC_FractalConverter_ConversionType ConversionType { get; set; }

        //---------------------- Display Options - Plot Colors ---------------------
        [XmlIgnore]
        [Display(Name = "Histogram plot", GroupName = "Display Options - Plot Colors", Description = "Select color for histogram plot", Order = 0)]
        public Brush Plot0Color { get; set; }
        [Browsable(false)]
        public string Plot0ColorSerialize
        {
            get { return Serialize.BrushToString(Plot0Color); }
            set { Plot0Color = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Fractal plot", GroupName = "Display Options - Plot Colors", Description = "Select color for fractal plot", Order = 1)]
        public Brush Plot1Color { get; set; }
        [Browsable(false)]
        public string Plot1ColorSerialize
        {
            get { return Serialize.BrushToString(Plot1Color); }
            set { Plot1Color = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Developing fractal plot", GroupName = "Display Options - Plot Colors", Description = "Select color for fractal plot, when data is not sufficient", Order = 2)]
        public Brush DevelopingColor { get; set; }
        [Browsable(false)]
        public string DevelopingColorSerialize
        {
            get { return Serialize.BrushToString(DevelopingColor); }
            set { DevelopingColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Text", GroupName = "Display Options - Plot Colors", Description = "Select color for text displayed in data box", Order = 3)]
        public Brush TextColor { get; set; }
        [Browsable(false)]
        public string TextColorSerialize
        {
            get { return Serialize.BrushToString(TextColor); }
            set { TextColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Data box background", GroupName = "Display Options - Plot Colors", Description = "Select color for data box background", Order = 4)]
        public Brush BackgroundColor { get; set; }
        [Browsable(false)]
        public string BackgroundColorSerialize
        {
            get { return Serialize.BrushToString(BackgroundColor); }
            set { BackgroundColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Update alert", GroupName = "Display Options - Plot Colors", Description = "Select color for update alert, when the current fractal deviates more than the selected percentage", Order = 5)]
        public Brush AlertColor { get; set; }
        [Browsable(false)]
        public string AlertColorSerialize
        {
            get { return Serialize.BrushToString(AlertColor); }
            set { AlertColor = Serialize.StringToBrush(value); }
        }

        //---------------------- Display Options - Plot Parameters ---------------------
        [Range(1, int.MaxValue)]
        [Display(Name = "Bar width histogram", GroupName = "Display Options - Plot Parameters", Description = "Bar width for histogram plot", Order = 0)]
        public int BarWidth { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Line width fractal plot", GroupName = "Display Options - Plot Parameters", Description = "Width for fractal plot", Order = 1)]
        public int Plot1Width { get; set; }

        [Display(Name = "Dash style fractal plot", GroupName = "Display Options - Plot Parameters", Description = "DashStyle for fractal plot", Order = 2)]
        public DashStyleHelper Dash1Style { get; set; }

        [Range(6, int.MaxValue)]
        [Display(Name = "Text font size", GroupName = "Display Options - Plot Parameters", Description = "Select maximum size for text font", Order = 3)]
        public int FontSize { get; set; }

        [Range(1, 100)]
        [Display(Name = "Data Box Opacity", GroupName = "Display Options - Plot Parameters", Description = "Select opacity of the data box back color", Order = 4)]
        public int DataBoxOpacity { get; set; }

        //---------------------- Evaluation Period Default ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period Default", Description = "Start time of evaluation period for Default", Order = 0)]
        public string S_BeginTime_Default
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_Default.Hours, beginTime_Default.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_Default = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period Default", Description = "End time of evaluation period for Default", Order = 1)]
        public string S_EndTime_Default
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_Default.Hours, endTime_Default.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_Default = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }

        
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(TZListConverter))]
        [Display(Name = "Time zone", GroupName = "Evaluation Period Default", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        public string TimeZone_Default
        {
            get
            {
                return timeZone_Default.DisplayName;
            }
            set
            {
                timeZone_Default = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period ES ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period ES", Description = "Start time of evaluation period for ES", Order = 0)]
        public string S_BeginTime_ES
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_ES.Hours, beginTime_ES.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_ES = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period ES", Description = "End time of evaluation period for ES", Order = 1)]
        public string S_EndTime_ES
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_ES.Hours, endTime_ES.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_ES = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period ES", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_ES
        {
            get
            {
                return timeZone_ES.DisplayName;
            }
            set
            {
                timeZone_ES = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period NQ ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period NQ", Description = "Start time of evaluation period for NQ", Order = 0)]
        public string S_BeginTime_NQ
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_NQ.Hours, beginTime_NQ.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_NQ = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period NQ", Description = "End time of evaluation period for NQ", Order = 1)]
        public string S_EndTime_NQ
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_NQ.Hours, endTime_NQ.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_NQ = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period NQ", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_NQ
        {
            get
            {
                return timeZone_NQ.DisplayName;
            }
            set
            {
                timeZone_NQ = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period YM ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period YM", Description = "Start time of evaluation period for YM", Order = 0)]
        public string S_BeginTime_YM
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_YM.Hours, beginTime_YM.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_YM = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period YM", Description = "End time of evaluation period for YM", Order = 1)]
        public string S_EndTime_YM
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_YM.Hours, endTime_YM.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_YM = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period YM", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_YM
        {
            get
            {
                return timeZone_YM.DisplayName;
            }
            set
            {
                timeZone_YM = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period TF ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period TF", Description = "Start time of evaluation period for TF", Order = 0)]
        public string S_BeginTime_TF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_TF.Hours, beginTime_TF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_TF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period TF", Description = "End time of evaluation period for TF", Order = 1)]
        public string S_EndTime_TF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_TF.Hours, endTime_TF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_TF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period TF", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_TF
        {
            get
            {
                return timeZone_TF.DisplayName;
            }
            set
            {
                timeZone_TF = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period UB ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period UB", Description = "Start time of evaluation period for UB", Order = 0)]
        public string S_BeginTime_UB
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_UB.Hours, beginTime_UB.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_UB = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period UB", Description = "End time of evaluation period for UB", Order = 1)]
        public string S_EndTime_UB
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_UB.Hours, endTime_UB.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_UB = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period UB", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_UB
        {
            get
            {
                return timeZone_UB.DisplayName;
            }
            set
            {
                timeZone_UB = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period ZB ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period ZB", Description = "Start time of evaluation period for ZB", Order = 0)]
        public string S_BeginTime_ZB
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_ZB.Hours, beginTime_ZB.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_ZB = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period ZB", Description = "End time of evaluation period for ZB", Order = 1)]
        public string S_EndTime_ZB
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_ZB.Hours, endTime_ZB.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_ZB = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period ZB", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_ZB
        {
            get
            {
                return timeZone_ZB.DisplayName;
            }
            set
            {
                timeZone_ZB = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period ZN ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period ZN", Description = "Start time of evaluation period for ZN", Order = 0)]
        public string S_BeginTime_ZN
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_ZN.Hours, beginTime_ZN.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_ZN = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period ZN", Description = "End time of evaluation period for ZN", Order = 1)]
        public string S_EndTime_ZN
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_ZN.Hours, endTime_ZN.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_ZN = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period ZN", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_ZN
        {
            get
            {
                return timeZone_ZN.DisplayName;
            }
            set
            {
                timeZone_ZN = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period CT ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period CT", Description = "Start time of evaluation period for CT", Order = 0)]
        public string S_BeginTime_CT
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_CT.Hours, beginTime_CT.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_CT = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period CT", Description = "End time of evaluation period for CT", Order = 1)]
        public string S_EndTime_CT
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_CT.Hours, endTime_CT.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_CT = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period CT", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_CT
        {
            get
            {
                return timeZone_CT.DisplayName;
            }
            set
            {
                timeZone_CT = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period KC ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period KC", Description = "Start time of evaluation period for KC", Order = 0)]
        public string S_BeginTime_KC
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_KC.Hours, beginTime_KC.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_KC = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period KC", Description = "End time of evaluation period for KC", Order = 1)]
        public string S_EndTime_KC
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_KC.Hours, endTime_KC.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_KC = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period KC", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_KC
        {
            get
            {
                return timeZone_KC.DisplayName;
            }
            set
            {
                timeZone_KC = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period SB ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period SB", Description = "Start time of evaluation period for SB", Order = 0)]
        public string S_BeginTime_SB
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_SB.Hours, beginTime_SB.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_SB = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period SB", Description = "End time of evaluation period for SB", Order = 1)]
        public string S_EndTime_SB
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_SB.Hours, endTime_SB.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_SB = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period SB", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_SB
        {
            get
            {
                return timeZone_SB.DisplayName;
            }
            set
            {
                timeZone_SB = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period CC ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period CC", Description = "Start time of evaluation period for CC", Order = 0)]
        public string S_BeginTime_CC
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_CC.Hours, beginTime_CC.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_CC = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period CC", Description = "End time of evaluation period for CC", Order = 1)]
        public string S_EndTime_CC
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_CC.Hours, endTime_CC.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_CC = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period CC", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_CC
        {
            get
            {
                return timeZone_CC.DisplayName;
            }
            set
            {
                timeZone_CC = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period DX ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period DX", Description = "Start time of evaluation period for DX", Order = 0)]
        public string S_BeginTime_DX
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_DX.Hours, beginTime_DX.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_DX = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period DX", Description = "End time of evaluation period for DX", Order = 1)]
        public string S_EndTime_DX
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_DX.Hours, endTime_DX.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_DX = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period DX", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_DX
        {
            get
            {
                return timeZone_DX.DisplayName;
            }
            set
            {
                timeZone_DX = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period 6E ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period 6E", Description = "Start time of evaluation period for 6E", Order = 0)]
        public string S_BeginTime_6E
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_6E.Hours, beginTime_6E.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_6E = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period 6E", Description = "End time of evaluation period for 6E", Order = 1)]
        public string S_EndTime_6E
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_6E.Hours, endTime_6E.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_6E = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period 6E", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_6E
        {
            get
            {
                return timeZone_6E.DisplayName;
            }
            set
            {
                timeZone_6E = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period 6S ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period 6S", Description = "Start time of evaluation period for 6S", Order = 0)]
        public string S_BeginTime_6S
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_6S.Hours, beginTime_6S.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_6S = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period 6S", Description = "End time of evaluation period for 6S", Order = 1)]
        public string S_EndTime_6S
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_6S.Hours, endTime_6S.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_6S = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period 6S", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_6S
        {
            get
            {
                return timeZone_6S.DisplayName;
            }
            set
            {
                timeZone_6S = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period 6B ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period 6B", Description = "Start time of evaluation period for 6B", Order = 0)]
        public string S_BeginTime_6B
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_6B.Hours, beginTime_6B.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_6B = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period 6B", Description = "End time of evaluation period for 6B", Order = 1)]
        public string S_EndTime_6B
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_6B.Hours, endTime_6B.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_6B = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period 6B", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_6B
        {
            get
            {
                return timeZone_6B.DisplayName;
            }
            set
            {
                timeZone_6B = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period 6J ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period 6J", Description = "Start time of evaluation period for 6J", Order = 0)]
        public string S_BeginTime_6J
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_6J.Hours, beginTime_6J.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_6J = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period 6J", Description = "End time of evaluation period for 6J", Order = 1)]
        public string S_EndTime_6J
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_6J.Hours, endTime_6J.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_6J = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period 6J", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_6J
        {
            get
            {
                return timeZone_6J.DisplayName;
            }
            set
            {
                timeZone_6J = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period 6C ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period 6C", Description = "Start time of evaluation period for 6C", Order = 0)]
        public string S_BeginTime_6C
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_6C.Hours, beginTime_6C.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_6C = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period 6C", Description = "End time of evaluation period for 6C", Order = 1)]
        public string S_EndTime_6C
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_6C.Hours, endTime_6C.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_6C = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period 6C", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_6C
        {
            get
            {
                return timeZone_6C.DisplayName;
            }
            set
            {
                timeZone_6C = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period 6A ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period 6A", Description = "Start time of evaluation period for 6A", Order = 0)]
        public string S_BeginTime_6A
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_6A.Hours, beginTime_6A.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_6A = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period 6A", Description = "End time of evaluation period for 6A", Order = 1)]
        public string S_EndTime_6A
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_6A.Hours, endTime_6A.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_6A = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period 6A", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_6A
        {
            get
            {
                return timeZone_6A.DisplayName;
            }
            set
            {
                timeZone_6A = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period 6M ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period 6M", Description = "Start time of evaluation period for 6M", Order = 0)]
        public string S_BeginTime_6M
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_6M.Hours, beginTime_6M.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_6M = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period 6M", Description = "End time of evaluation period for 6M", Order = 1)]
        public string S_EndTime_6M
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_6M.Hours, endTime_6M.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_6M = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period 6M", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_6M
        {
            get
            {
                return timeZone_6M.DisplayName;
            }
            set
            {
                timeZone_6M = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period 6N ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period 6N", Description = "Start time of evaluation period for 6N", Order = 0)]
        public string S_BeginTime_6N
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_6N.Hours, beginTime_6N.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_6N = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period 6N", Description = "End time of evaluation period for 6N", Order = 1)]
        public string S_EndTime_6N
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_6N.Hours, endTime_6N.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_6N = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period 6N", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_6N
        {
            get
            {
                return timeZone_6N.DisplayName;
            }
            set
            {
                timeZone_6N = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period GC ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period GC", Description = "Start time of evaluation period for GC", Order = 0)]
        public string S_BeginTime_GC
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_GC.Hours, beginTime_GC.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_GC = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period GC", Description = "End time of evaluation period for GC", Order = 1)]
        public string S_EndTime_GC
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_GC.Hours, endTime_GC.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_GC = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period GC", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_GC
        {
            get
            {
                return timeZone_GC.DisplayName;
            }
            set
            {
                timeZone_GC = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period SI ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period SI", Description = "Start time of evaluation period for SI", Order = 0)]
        public string S_BeginTime_SI
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_SI.Hours, beginTime_SI.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_SI = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period SI", Description = "End time of evaluation period for SI", Order = 1)]
        public string S_EndTime_SI
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_SI.Hours, endTime_SI.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_SI = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period SI", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_SI
        {
            get
            {
                return timeZone_SI.DisplayName;
            }
            set
            {
                timeZone_SI = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period HG ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period HG", Description = "Start time of evaluation period for HG", Order = 0)]
        public string S_BeginTime_HG
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_HG.Hours, beginTime_HG.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_HG = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period HG", Description = "End time of evaluation period for HG", Order = 1)]
        public string S_EndTime_HG
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_HG.Hours, endTime_HG.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_HG = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period HG", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_HG
        {
            get
            {
                return timeZone_HG.DisplayName;
            }
            set
            {
                timeZone_HG = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period CL ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period CL", Description = "Start time of evaluation period for CL", Order = 0)]
        public string S_BeginTime_CL
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_CL.Hours, beginTime_CL.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_CL = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period CL", Description = "End time of evaluation period for CL", Order = 1)]
        public string S_EndTime_CL
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_CL.Hours, endTime_CL.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_CL = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period CL", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_CL
        {
            get
            {
                return timeZone_CL.DisplayName;
            }
            set
            {
                timeZone_CL = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period NG ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period NG", Description = "Start time of evaluation period for NG", Order = 0)]
        public string S_BeginTime_NG
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_NG.Hours, beginTime_NG.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_NG = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period NG", Description = "End time of evaluation period for NG", Order = 1)]
        public string S_EndTime_NG
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_NG.Hours, endTime_NG.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_NG = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period NG", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_NG
        {
            get
            {
                return timeZone_NG.DisplayName;
            }
            set
            {
                timeZone_NG = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period H0 ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period H0", Description = "Start time of evaluation period for H0", Order = 0)]
        public string S_beginTime_HO
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_HO.Hours, beginTime_HO.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_HO = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period H0", Description = "End time of evaluation period for H0", Order = 1)]
        public string S_endTime_HO
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_HO.Hours, endTime_HO.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_HO = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period H0", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string S_timeZone_HO
        {
            get
            {
                return timeZone_HO.DisplayName;
            }
            set
            {
                timeZone_HO = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period RB ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period RB", Description = "Start time of evaluation period for RB", Order = 0)]
        public string S_BeginTime_RB
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_RB.Hours, beginTime_RB.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_RB = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period RB", Description = "End time of evaluation period for RB", Order = 1)]
        public string S_EndTime_RB
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_RB.Hours, endTime_RB.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_RB = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period RB", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_RB
        {
            get
            {
                return timeZone_RB.DisplayName;
            }
            set
            {
                timeZone_RB = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period BRN ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period BRN", Description = "Start time of evaluation period for BRN", Order = 0)]
        public string S_BeginTime_BRN
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_BRN.Hours, beginTime_BRN.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_BRN = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period BRN", Description = "End time of evaluation period for BRN", Order = 1)]
        public string S_EndTime_BRN
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_BRN.Hours, endTime_BRN.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_BRN = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period BRN", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_BRN
        {
            get
            {
                return timeZone_BRN.DisplayName;
            }
            set
            {
                timeZone_BRN = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period ZS ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period ZS", Description = "Start time of evaluation period for ZS", Order = 0)]
        public string S_BeginTime_ZS
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_ZS.Hours, beginTime_ZS.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_ZS = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period ZS", Description = "End time of evaluation period for ZS", Order = 1)]
        public string S_EndTime_ZS
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_ZS.Hours, endTime_ZS.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_ZS = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period ZS", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_ZS
        {
            get
            {
                return timeZone_ZS.DisplayName;
            }
            set
            {
                timeZone_ZS = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period ZL ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period ZL", Description = "Start time of evaluation period for ZL", Order = 0)]
        public string S_BeginTime_ZL
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_ZL.Hours, beginTime_ZL.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_ZL = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period ZL", Description = "End time of evaluation period for ZL", Order = 1)]
        public string S_EndTime_ZL
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_ZL.Hours, endTime_ZL.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_ZL = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period ZL", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_ZL
        {
            get
            {
                return timeZone_ZL.DisplayName;
            }
            set
            {
                timeZone_ZL = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period ZM ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period ZM", Description = "Start time of evaluation period for ZM", Order = 0)]
        public string S_BeginTime_ZM
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_ZM.Hours, beginTime_ZM.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_ZM = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period ZM", Description = "End time of evaluation period for ZM", Order = 1)]
        public string S_EndTime_ZM
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_ZM.Hours, endTime_ZM.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_ZM = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period ZM", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_ZM
        {
            get
            {
                return timeZone_ZM.DisplayName;
            }
            set
            {
                timeZone_ZM = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period ZW ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period ZW", Description = "Start time of evaluation period for ZW", Order = 0)]
        public string S_BeginTime_ZW
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_ZW.Hours, beginTime_ZW.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_ZW = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period ZW", Description = "End time of evaluation period for ZW", Order = 1)]
        public string S_EndTime_ZW
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_ZW.Hours, endTime_ZW.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_ZW = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period ZW", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_ZW
        {
            get
            {
                return timeZone_ZW.DisplayName;
            }
            set
            {
                timeZone_ZW = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period ZC ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period ZC", Description = "Start time of evaluation period for ZC", Order = 0)]
        public string S_BeginTime_ZC
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_ZC.Hours, beginTime_ZC.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_ZC = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period ZC", Description = "End time of evaluation period for ZC", Order = 1)]
        public string S_EndTime_ZC
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_ZC.Hours, endTime_ZC.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_ZC = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period ZC", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_ZC
        {
            get
            {
                return timeZone_ZC.DisplayName;
            }
            set
            {
                timeZone_ZC = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period FGBL ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period FGBL", Description = "Start time of evaluation period for FGBL", Order = 0)]
        public string S_BeginTime_FGBL
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_FGBL.Hours, beginTime_FGBL.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_FGBL = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period FGBL", Description = "End time of evaluation period for FGBL", Order = 1)]
        public string S_EndTime_FGBL
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_FGBL.Hours, endTime_FGBL.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_FGBL = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period FGBL", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_FGBL
        {
            get
            {
                return timeZone_FGBL.DisplayName;
            }
            set
            {
                timeZone_FGBL = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period FGBM ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period FGBM", Description = "Start time of evaluation period for FGBM", Order = 0)]
        public string S_BeginTime_FGBM
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_FGBM.Hours, beginTime_FGBM.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_FGBM = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period FGBM", Description = "End time of evaluation period for FGBM", Order = 1)]
        public string S_EndTime_FGBM
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_FGBM.Hours, endTime_FGBM.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_FGBM = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period FGBM", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_FGBM
        {
            get
            {
                return timeZone_FGBM.DisplayName;
            }
            set
            {
                timeZone_FGBM = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period FESX ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period FESX", Description = "Start time of evaluation period for FESX", Order = 0)]
        public string S_BeginTime_FESX
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_FESX.Hours, beginTime_FESX.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_FESX = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period FESX", Description = "End time of evaluation period for FESX", Order = 1)]
        public string S_EndTime_FESX
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_FESX.Hours, endTime_FESX.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_FESX = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period FESX", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_FESX
        {
            get
            {
                return timeZone_FESX.DisplayName;
            }
            set
            {
                timeZone_FESX = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period FDAX ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period FDAX", Description = "Start time of evaluation period for FDAX", Order = 0)]
        public string S_BeginTime_FDAX
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_FDAX.Hours, beginTime_FDAX.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_FDAX = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period FDAX", Description = "End time of evaluation period for FDAX", Order = 1)]
        public string S_EndTime_FDAX
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_FDAX.Hours, endTime_FDAX.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_FDAX = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period FDAX", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_FDAX
        {
            get
            {
                return timeZone_FDAX.DisplayName;
            }
            set
            {
                timeZone_FDAX = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period USDCAD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period USDCAD", Description = "Start time of evaluation period for USDCAD", Order = 0)]
        public string S_BeginTime_USDCAD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_USDCAD.Hours, beginTime_USDCAD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_USDCAD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period USDCAD", Description = "End time of evaluation period for USDCAD", Order = 1)]
        public string S_EndTime_USDCAD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_USDCAD.Hours, endTime_USDCAD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_USDCAD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period USDCAD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_USDCAD
        {
            get
            {
                return timeZone_USDCAD.DisplayName;
            }
            set
            {
                timeZone_USDCAD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period USDCHF ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period USDCHF", Description = "Start time of evaluation period for USDCHF", Order = 0)]
        public string S_BeginTime_USDCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_USDCHF.Hours, beginTime_USDCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_USDCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period USDCHF", Description = "End time of evaluation period for USDCHF", Order = 1)]
        public string S_EndTime_USDCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_USDCHF.Hours, endTime_USDCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_USDCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period USDCHF", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_USDCHF
        {
            get
            {
                return timeZone_USDCHF.DisplayName;
            }
            set
            {
                timeZone_USDCHF = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period USDJPY ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period USDJPY", Description = "Start time of evaluation period for USDJPY", Order = 0)]
        public string S_BeginTime_USDJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_USDJPY.Hours, beginTime_USDJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_USDJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period USDJPY", Description = "End time of evaluation period for USDJPY", Order = 1)]
        public string S_EndTime_USDJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_USDJPY.Hours, endTime_USDJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_USDJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period USDJPY", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_USDJPY
        {
            get
            {
                return timeZone_USDJPY.DisplayName;
            }
            set
            {
                timeZone_USDJPY = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period AUDCAD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period AUDCAD", Description = "Start time of evaluation period for AUDCAD", Order = 0)]
        public string S_BeginTime_AUDCAD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_AUDCAD.Hours, beginTime_AUDCAD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_AUDCAD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period AUDCAD", Description = "End time of evaluation period for AUDCAD", Order = 1)]
        public string S_EndTime_AUDCAD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_AUDCAD.Hours, endTime_AUDCAD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_AUDCAD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period AUDCAD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_AUDCAD
        {
            get
            {
                return timeZone_AUDCAD.DisplayName;
            }
            set
            {
                timeZone_AUDCAD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period AUDCHF ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period AUDCHF", Description = "Start time of evaluation period for AUDCHF", Order = 0)]
        public string S_BeginTime_AUDCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_AUDCHF.Hours, beginTime_AUDCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_AUDCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period AUDCHF", Description = "End time of evaluation period for AUDCHF", Order = 1)]
        public string S_EndTime_AUDCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_AUDCHF.Hours, endTime_AUDCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_AUDCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period AUDCHF", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_AUDCHF
        {
            get
            {
                return timeZone_AUDCHF.DisplayName;
            }
            set
            {
                timeZone_AUDCHF = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period AUDJPY ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period AUDJPY", Description = "Start time of evaluation period for AUDJPY", Order = 0)]
        public string S_BeginTime_AUDJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_AUDJPY.Hours, beginTime_AUDJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_AUDJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period AUDJPY", Description = "End time of evaluation period for AUDJPY", Order = 1)]
        public string S_EndTime_AUDJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_AUDJPY.Hours, endTime_AUDJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_AUDJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period AUDJPY", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_AUDJPY
        {
            get
            {
                return timeZone_AUDJPY.DisplayName;
            }
            set
            {
                timeZone_AUDJPY = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period AUDNZD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period AUDNZD", Description = "Start time of evaluation period for AUDNZD", Order = 0)]
        public string S_BeginTime_AUDNZD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_AUDNZD.Hours, beginTime_AUDNZD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_AUDNZD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period AUDNZD", Description = "End time of evaluation period for AUDNZD", Order = 1)]
        public string S_EndTime_AUDNZD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_AUDNZD.Hours, endTime_AUDNZD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_AUDNZD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period AUDNZD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_AUDNZD
        {
            get
            {
                return timeZone_AUDNZD.DisplayName;
            }
            set
            {
                timeZone_AUDNZD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period AUDUSD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period AUDUSD", Description = "Start time of evaluation period for AUDUSD", Order = 0)]
        public string S_BeginTime_AUDUSD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_AUDUSD.Hours, beginTime_AUDUSD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_AUDUSD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period AUDUSD", Description = "End time of evaluation period for AUDUSD", Order = 1)]
        public string S_EndTime_AUDUSD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_AUDUSD.Hours, endTime_AUDUSD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_AUDUSD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period AUDUSD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_AUDUSD
        {
            get
            {
                return timeZone_AUDUSD.DisplayName;
            }
            set
            {
                timeZone_AUDUSD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period GBPAUD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period GBPAUD", Description = "Start time of evaluation period for GBPAUD", Order = 0)]
        public string S_BeginTime_GBPAUD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_GBPAUD.Hours, beginTime_GBPAUD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_GBPAUD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period GBPAUD", Description = "End time of evaluation period for GBPAUD", Order = 1)]
        public string S_EndTime_GBPAUD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_GBPAUD.Hours, endTime_GBPAUD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_GBPAUD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period GBPAUD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_GBPAUD
        {
            get
            {
                return timeZone_GBPAUD.DisplayName;
            }
            set
            {
                timeZone_GBPAUD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period GBPCAD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period GBPCAD", Description = "Start time of evaluation period for GBPCAD", Order = 0)]
        public string S_BeginTime_GBPCAD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_GBPCAD.Hours, beginTime_GBPCAD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_GBPCAD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period GBPCAD", Description = "End time of evaluation period for GBPCAD", Order = 1)]
        public string S_EndTime_GBPCAD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_GBPCAD.Hours, endTime_GBPCAD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_GBPCAD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period GBPCAD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_GBPCAD
        {
            get
            {
                return timeZone_GBPCAD.DisplayName;
            }
            set
            {
                timeZone_GBPCAD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period GBPCHF ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period GBPCHF", Description = "Start time of evaluation period for GBPCHF", Order = 0)]
        public string S_BeginTime_GBPCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_GBPCHF.Hours, beginTime_GBPCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_GBPCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period GBPCHF", Description = "End time of evaluation period for GBPCHF", Order = 1)]
        public string S_EndTime_GBPCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_GBPCHF.Hours, endTime_GBPCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_GBPCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period GBPCHF", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_GBPCHF
        {
            get
            {
                return timeZone_GBPCHF.DisplayName;
            }
            set
            {
                timeZone_GBPCHF = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period GBPJPY ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period GBPJPY", Description = "Start time of evaluation period for GBPJPY", Order = 0)]
        public string S_BeginTime_GBPJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_GBPJPY.Hours, beginTime_GBPJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_GBPJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period GBPJPY", Description = "End time of evaluation period for GBPJPY", Order = 1)]
        public string S_EndTime_GBPJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_GBPJPY.Hours, endTime_GBPJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_GBPJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period GBPJPY", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_GBPJPY
        {
            get
            {
                return timeZone_GBPJPY.DisplayName;
            }
            set
            {
                timeZone_GBPJPY = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period GBPNZD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period GBPNZD", Description = "Start time of evaluation period for GBPNZD", Order = 0)]
        public string S_BeginTime_GBPNZD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_GBPNZD.Hours, beginTime_GBPNZD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_GBPNZD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period GBPNZD", Description = "End time of evaluation period for GBPNZD", Order = 1)]
        public string S_EndTime_GBPNZD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_GBPNZD.Hours, endTime_GBPNZD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_GBPNZD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period GBPNZD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_GBPNZD
        {
            get
            {
                return timeZone_GBPNZD.DisplayName;
            }
            set
            {
                timeZone_GBPNZD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period GBPUSD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period GBPUSD", Description = "Start time of evaluation period for GBPUSD", Order = 0)]
        public string S_BeginTime_GBPUSD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_GBPUSD.Hours, beginTime_GBPUSD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_GBPUSD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period GBPUSD", Description = "End time of evaluation period for GBPUSD", Order = 1)]
        public string S_EndTime_GBPUSD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_GBPUSD.Hours, endTime_GBPUSD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_GBPUSD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period GBPUSD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_GBPUSD
        {
            get
            {
                return timeZone_GBPUSD.DisplayName;
            }
            set
            {
                timeZone_GBPUSD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period CADCHF ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period CADCHF", Description = "Start time of evaluation period for CADCHF", Order = 0)]
        public string S_BeginTime_CADCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_CADCHF.Hours, beginTime_CADCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_CADCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period CADCHF", Description = "End time of evaluation period for CADCHF", Order = 1)]
        public string S_EndTime_CADCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_CADCHF.Hours, endTime_CADCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_CADCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period CADCHF", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_CADCHF
        {
            get
            {
                return timeZone_CADCHF.DisplayName;
            }
            set
            {
                timeZone_CADCHF = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period CADJPY ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period CADJPY", Description = "Start time of evaluation period for CADJPY", Order = 0)]
        public string S_BeginTime_CADJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_CADJPY.Hours, beginTime_CADJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_CADJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period CADJPY", Description = "End time of evaluation period for CADJPY", Order = 1)]
        public string S_EndTime_CADJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_CADJPY.Hours, endTime_CADJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_CADJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period CADJPY", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_CADJPY
        {
            get
            {
                return timeZone_CADJPY.DisplayName;
            }
            set
            {
                timeZone_CADJPY = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period EURAUD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period EURAUD", Description = "Start time of evaluation period for EURAUD", Order = 0)]
        public string S_BeginTime_EURAUD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_EURAUD.Hours, beginTime_EURAUD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_EURAUD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period EURAUD", Description = "End time of evaluation period for EURAUD", Order = 1)]
        public string S_EndTime_EURAUD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_EURAUD.Hours, endTime_EURAUD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_EURAUD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period EURAUD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_EURAUD
        {
            get
            {
                return timeZone_EURAUD.DisplayName;
            }
            set
            {
                timeZone_EURAUD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period EURCAD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period EURCAD", Description = "Start time of evaluation period for EURCAD", Order = 0)]
        public string S_BeginTime_EURCAD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_EURCAD.Hours, beginTime_EURCAD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_EURCAD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period EURCAD", Description = "End time of evaluation period for EURCAD", Order = 1)]
        public string S_EndTime_EURCAD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_EURCAD.Hours, endTime_EURCAD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_EURCAD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period EURCAD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_EURCAD
        {
            get
            {
                return timeZone_EURCAD.DisplayName;
            }
            set
            {
                timeZone_EURCAD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period EURCHF ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period EURCHF", Description = "Start time of evaluation period for EURCHF", Order = 0)]
        public string S_BeginTime_EURCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_EURCHF.Hours, beginTime_EURCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_EURCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period EURCHF", Description = "End time of evaluation period for EURCHF", Order = 1)]
        public string S_EndTime_EURCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_EURCHF.Hours, endTime_EURCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_EURCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period EURCHF", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_EURCHF
        {
            get
            {
                return timeZone_EURCHF.DisplayName;
            }
            set
            {
                timeZone_EURCHF = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period EURGBP ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period EURGBP", Description = "Start time of evaluation period for EURGBP", Order = 0)]
        public string S_BeginTime_EURGBP
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_EURGBP.Hours, beginTime_EURGBP.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_EURGBP = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period EURGBP", Description = "End time of evaluation period for EURGBP", Order = 1)]
        public string S_EndTime_EURGBP
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_EURGBP.Hours, endTime_EURGBP.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_EURGBP = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period EURGBP", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_EURGBP
        {
            get
            {
                return timeZone_EURGBP.DisplayName;
            }
            set
            {
                timeZone_EURGBP = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period EURJPY ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period EURJPY", Description = "Start time of evaluation period for EURJPY", Order = 0)]
        public string S_BeginTime_EURJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_EURJPY.Hours, beginTime_EURJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_EURJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period EURJPY", Description = "End time of evaluation period for EURJPY", Order = 1)]
        public string S_EndTime_EURJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_EURJPY.Hours, endTime_EURJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_EURJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period EURJPY", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_EURJPY
        {
            get
            {
                return timeZone_EURJPY.DisplayName;
            }
            set
            {
                timeZone_EURJPY = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period EURNZD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period EURNZD", Description = "Start time of evaluation period for EURNZD", Order = 0)]
        public string S_BeginTime_EURNZD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_EURNZD.Hours, beginTime_EURNZD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_EURNZD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period EURNZD", Description = "End time of evaluation period for EURNZD", Order = 1)]
        public string S_EndTime_EURNZD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_EURNZD.Hours, endTime_EURNZD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_EURNZD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period EURNZD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_EURNZD
        {
            get
            {
                return timeZone_EURNZD.DisplayName;
            }
            set
            {
                timeZone_EURNZD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period EURUSD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period EURUSD", Description = "Start time of evaluation period for EURUSD", Order = 0)]
        public string S_BeginTime_EURUSD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_EURUSD.Hours, beginTime_EURUSD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_EURUSD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period EURUSD", Description = "End time of evaluation period for EURUSD", Order = 1)]
        public string S_EndTime_EURUSD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_EURUSD.Hours, endTime_EURUSD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_EURUSD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period EURUSD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_EURUSD
        {
            get
            {
                return timeZone_EURUSD.DisplayName;
            }
            set
            {
                timeZone_EURUSD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period CHFJPY ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period CHFJPY", Description = "Start time of evaluation period for CHFJPY", Order = 0)]
        public string S_BeginTime_CHFJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_CHFJPY.Hours, beginTime_CHFJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_CHFJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period CHFJPY", Description = "End time of evaluation period for CHFJPY", Order = 1)]
        public string S_EndTime_CHFJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_CHFJPY.Hours, endTime_CHFJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_CHFJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period CHFJPY", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_CHFJPY
        {
            get
            {
                return timeZone_CHFJPY.DisplayName;
            }
            set
            {
                timeZone_CHFJPY = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period NZDCAD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period NZDCAD", Description = "Start time of evaluation period for NZDCAD", Order = 0)]
        public string S_BeginTime_NZDCAD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_NZDCAD.Hours, beginTime_NZDCAD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_NZDCAD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period NZDCAD", Description = "End time of evaluation period for NZDCAD", Order = 1)]
        public string S_EndTime_NZDCAD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_NZDCAD.Hours, endTime_NZDCAD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_NZDCAD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period NZDCAD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_NZDCAD
        {
            get
            {
                return timeZone_NZDCAD.DisplayName;
            }
            set
            {
                timeZone_NZDCAD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period NZDCHF ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period NZDCHF", Description = "Start time of evaluation period for NZDCHF", Order = 0)]
        public string S_BeginTime_NZDCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_NZDCHF.Hours, beginTime_NZDCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_NZDCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period NZDCHF", Description = "End time of evaluation period for NZDCHF", Order = 1)]
        public string S_EndTime_NZDCHF
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_NZDCHF.Hours, endTime_NZDCHF.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_NZDCHF = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period NZDCHF", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_NZDCHF
        {
            get
            {
                return timeZone_NZDCHF.DisplayName;
            }
            set
            {
                timeZone_NZDCHF = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period NZDJPY ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period NZDJPY", Description = "Start time of evaluation period for NZDJPY", Order = 0)]
        public string S_BeginTime_NZDJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_NZDJPY.Hours, beginTime_NZDJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_NZDJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period NZDJPY", Description = "End time of evaluation period for NZDJPY", Order = 1)]
        public string S_EndTime_NZDJPY
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_NZDJPY.Hours, endTime_NZDJPY.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_NZDJPY = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period NZDJPY", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_NZDJPY
        {
            get
            {
                return timeZone_NZDJPY.DisplayName;
            }
            set
            {
                timeZone_NZDJPY = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Evaluation Period NZDUSD ---------------------
        [Display(Name = "Begin time", GroupName = "Evaluation Period NZDUSD", Description = "Start time of evaluation period for NZDUSD", Order = 0)]
        public string S_BeginTime_NZDUSD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", beginTime_NZDUSD.Hours, beginTime_NZDUSD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                beginTime_NZDUSD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "End time", GroupName = "Evaluation Period NZDUSD", Description = "End time of evaluation period for NZDUSD", Order = 1)]
        public string S_EndTime_NZDUSD
        {
            get
            {
                return string.Format("{0:D2}:{1:D2}", endTime_NZDUSD.Hours, endTime_NZDUSD.Minutes);
            }
            set
            {
                string[] values = ((string)value).Split(':');
                endTime_NZDUSD = new TimeSpan(Convert.ToInt16(values[0]), 5 * Convert.ToInt16(Math.Round(Convert.ToDouble(values[1])) / 5.0), 0);
            }
        }
        [Display(Name = "Time zone", GroupName = "Evaluation Period NZDUSD", Description = "Time zone used for evaluation begin time and evaluation end time", Order = 2)]
        [TypeConverter(typeof(TZListConverter))]
        public string TimeZone_NZDUSD
        {
            get
            {
                return timeZone_NZDUSD.DisplayName;
            }
            set
            {
                timeZone_NZDUSD = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault<TimeZoneInfo>(x => ((x.DisplayName == value) || (x.StandardName == value)));
            }
        }

        //---------------------- Public Holidays ---------------------
//        [Display(Name = "Public Holiday 01", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday0 { get; set; }
//        [Display(Name = "Public Holiday 02", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday1 { get; set; }
//        [Display(Name = "Public Holiday 03", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday2 { get; set; }
//        [Display(Name = "Public Holiday 04", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday3 { get; set; }
//        [Display(Name = "Public Holiday 05", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday4 { get; set; }
//        [Display(Name = "Public Holiday 06", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday5 { get; set; }
//        [Display(Name = "Public Holiday 07", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday6 { get; set; }
//        [Display(Name = "Public Holiday 08", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday7 { get; set; }
//        [Display(Name = "Public Holiday 09", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday8 { get; set; }
//        [Display(Name = "Public Holiday 10", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday9 { get; set; }

//        [Display(Name = "Public Holiday 11", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday10 { get; set; }
//        [Display(Name = "Public Holiday 12", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday11 { get; set; }
//        [Display(Name = "Public Holiday 13", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday12 { get; set; }
//        [Display(Name = "Public Holiday 14", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday13 { get; set; }
//        [Display(Name = "Public Holiday 15", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday14 { get; set; }
//        [Display(Name = "Public Holiday 16", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday15 { get; set; }
//        [Display(Name = "Public Holiday 17", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday16 { get; set; }
//        [Display(Name = "Public Holiday 18", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday17 { get; set; }
//        [Display(Name = "Public Holiday 19", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday18 { get; set; }
//        [Display(Name = "Public Holiday 20", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday19 { get; set; }

//        [Display(Name = "Public Holiday 21", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday20 { get; set; }
//        [Display(Name = "Public Holiday 22", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday21 { get; set; }
//        [Display(Name = "Public Holiday 23", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday22 { get; set; }
//        [Display(Name = "Public Holiday 24", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday23 { get; set; }
//        [Display(Name = "Public Holiday 25", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday24 { get; set; }
//        [Display(Name = "Public Holiday 26", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday25 { get; set; }
//        [Display(Name = "Public Holiday 27", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday26 { get; set; }
//        [Display(Name = "Public Holiday 28", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday27 { get; set; }
//        [Display(Name = "Public Holiday 29", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday28 { get; set; }
//        [Display(Name = "Public Holiday 30", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday29 { get; set; }

//        [Display(Name = "Public Holiday 31", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday30 { get; set; }
//        [Display(Name = "Public Holiday 32", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday31 { get; set; }
//        [Display(Name = "Public Holiday 33", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday32 { get; set; }
//        [Display(Name = "Public Holiday 34", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday33 { get; set; }
//        [Display(Name = "Public Holiday 35", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday34 { get; set; }
//        [Display(Name = "Public Holiday 36", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday35 { get; set; }
//        [Display(Name = "Public Holiday 37", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday36 { get; set; }
//        [Display(Name = "Public Holiday 38", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday37 { get; set; }
//        [Display(Name = "Public Holiday 39", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday38 { get; set; }
//        [Display(Name = "Public Holiday 40", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday39 { get; set; }

//        [Display(Name = "Public Holiday 41", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday40 { get; set; }
//        [Display(Name = "Public Holiday 42", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday41 { get; set; }
//        [Display(Name = "Public Holiday 43", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday42 { get; set; }
//        [Display(Name = "Public Holiday 44", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday43 { get; set; }
//        [Display(Name = "Public Holiday 45", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday44 { get; set; }
//        [Display(Name = "Public Holiday 46", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday45 { get; set; }
//        [Display(Name = "Public Holiday 47", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday46 { get; set; }
//        [Display(Name = "Public Holiday 48", GroupName = "Public Holidays", Description = "Enter dates for public holidays with reduced trading volume.", Order = 0)]
//        public DateTime PublicHoliday47 { get; set; }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_FractalConverter[] cacheARC_FractalConverter;
		public ARC.ARC_FractalConverter ARC_FractalConverter()
		{
			return ARC_FractalConverter(Input);
		}

		public ARC.ARC_FractalConverter ARC_FractalConverter(ISeries<double> input)
		{
			if (cacheARC_FractalConverter != null)
				for (int idx = 0; idx < cacheARC_FractalConverter.Length; idx++)
					if (cacheARC_FractalConverter[idx] != null &&  cacheARC_FractalConverter[idx].EqualsInput(input))
						return cacheARC_FractalConverter[idx];
			return CacheIndicator<ARC.ARC_FractalConverter>(new ARC.ARC_FractalConverter(), input, ref cacheARC_FractalConverter);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_FractalConverter ARC_FractalConverter()
		{
			return indicator.ARC_FractalConverter(Input);
		}

		public Indicators.ARC.ARC_FractalConverter ARC_FractalConverter(ISeries<double> input )
		{
			return indicator.ARC_FractalConverter(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_FractalConverter ARC_FractalConverter()
		{
			return indicator.ARC_FractalConverter(Input);
		}

		public Indicators.ARC.ARC_FractalConverter ARC_FractalConverter(ISeries<double> input )
		{
			return indicator.ARC_FractalConverter(input);
		}
	}
}

#endregion
