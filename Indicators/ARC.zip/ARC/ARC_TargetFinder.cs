#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
using System.Windows.Input;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using System.Threading;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;

using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows;


#endregion

#region Author/Copyright
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region -- Global Enums --
	public enum ARC_TargetFinder_SwingTargetOptions { Highs, Lows, Both }
//    public enum ARC_TargetFinder_FiblineResolutionA { Smallest, Small, Default, Increased, Large, Largest }
//    public enum ARC_TargetFinder_ConfluenceWidthA { Strong, Weak }
//	public enum ARC_TargetFinder_TradeEntryBasis{ AtFibPrice, AtMidPrice, AtATR}
//	public enum ARC_TargetFinder_TradePlanLocation {Left,Right}
//	public enum ARC_TargetFinder_DominantTradePlan {Long,Short,None}
//	public enum ARC_TargetFinder_SLTP_CalcBasis {ATR, Ticks}
//	public enum ARC_TargetFinder_Plan_LevelsBasis {AtFib, AtEntryPrice}
    #endregion

    public class ARC_TargetFinder : Indicator
    {
		private const int UP = 1;
		private const int FLAT = 0;
		private const int DOWN = -1;

		private int TargetOffsetTicks = 0;
		private int SLOffsetTicks = 0;
		private class LevelData{
			public double Price=double.MinValue;
			public int ABar=0;
			public LevelData(double price, int abar){Price=price; ABar = abar;}
		}
		private SortedDictionary<string,LevelData> Levels = new SortedDictionary<string,LevelData>();

		private SharpDX.Direct2D1.Brush lineBrushUp = null;
		private SharpDX.Direct2D1.Brush lineBrushDown = null;
		private SharpDX.Direct2D1.Brush tempBrushDX = null;

		private string OnStateChange_ErrorMsg = string.Empty;
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "TargetFinder";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "12229", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsDebug = false;

		private string VERSION = "1.0 5.27.20";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		#region -- Global_RaysData --------------------------------------------------
		private class Global_RaysData{
			public int LMAbar = 0;
			public int Type = -1;//if Support = 1, if Resistance -1
			public DateTime DT;
			public double Price;
			public string TemplateName;
			public bool IsDrawn = false;
			public DateTime EndDT = DateTime.MaxValue;
			public Global_RaysData(DateTime dt, int leftABar, int res_or_sup, double price, string templatename){
				DT=dt; Price=price; LMAbar = leftABar; Type = res_or_sup; TemplateName=templatename.Replace(" Ray Template",string.Empty); IsDrawn=false; EndDT = DateTime.MaxValue;
			}
		}
		#endregion
		private SortedDictionary<string,Global_RaysData> GlobalRays = new SortedDictionary<string,Global_RaysData>();
		private StructureBias StructureBiasMgr = null;
		private class StructureBias{
			#region StructureBias class
			public int    SwingStrength = 1;
			public bool   isHLBased         = false;
			public double MultiplierMD  = 0;
			public double MultiplierDTB = 0;
			public Series<int> Bias;
			public Brush UpTrendColorTinted   = null;
			public Brush DownTrendColorTinted = null;
			public string ErrorMsg = string.Empty;
			public System.Collections.Generic.SortedDictionary<int,double> AllPivots = new System.Collections.Generic.SortedDictionary<int,double>();

			#region internals
			private int  SRType = 0;
			private int  preSRType = 0;
	        private bool vdrawHigherHighLabel   = false;
	        private bool vdrawLowerHighLabel    = false;
	        private bool vdrawDoubleTopLabel    = false;
	        private bool vdrawLowerLowLabel     = false;
	        private bool vdrawHigherLowLabel    = false;
	        private bool vdrawDoubleBottomLabel = false;
			private ISeries<double> High;
			private ISeries<double> Low;
			private Series<bool>   vupTrend;
			private Series<double> vpre_swingHighType;
			private Series<double> vpre_swingLowType;
			private Series<double> vswingHighType;
			private Series<double> vswingLowType;
			private Series<double> vavgTrueRange;
			private Series<double> vswingInput;
			private Series<double> pre_swingHighType;
			private Series<double> pre_swingLowType;
			private Series<double> swingHighType;
			private Series<double> swingLowType;
			private int lastLowIdx;
			private int lastHighIdx;
			public Series<bool> upTrend;
			private double vswingMax;
			private double vswingMin;
			private double vzigzagDeviation;
			private bool vupdateHigh;
			private bool vupdateLow;
			private bool vaddHigh;
			private bool vaddLow;
			private bool updateLow;
			private bool updateHigh;
			private double vcurrentHigh;
			private double vcurrentLow;
			private int vlastLowIdx;
			private int vlastHighIdx;
			private int vpriorSwingHighIdx;
			private int vpriorSwingLowIdx;
			private int vhighCount;
			private int vlowCount;
			private int vpreLastHighIdx;
			private int vpreLastLowIdx;
			private int priorSwingHighIdx;
			private int priorSwingLowIdx;
			private double currentHigh;
			private double currentLow;
			private double vmarginUp;
			private double vmarginDown;
			private double vpreCurrentHigh;
			private double vpreCurrentLow;
			private double swingMax;
			private double swingMin;
			private bool vintraBarUpdateHigh;
			private bool vintraBarUpdateLow;
			private bool vintraBarAddHigh;
			private bool vintraBarAddLow;
			private bool addHigh;
			private bool addLow;
	        public System.Collections.Generic.List<int> sequence = new System.Collections.Generic.List<int>(3);
			#endregion

			public StructureBias(NinjaScriptBase Chart_Bars, ISeries<double> high, ISeries<double> low, int swingStrength, bool use_HL, double multiplierMD, double multiplierDTB){
				#region constructor
				High = high;
				Low  = low;
				vupTrend           = new Series<bool>  (Chart_Bars,MaximumBarsLookBack.Infinite);
				vpre_swingHighType = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vpre_swingLowType  = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vswingHighType     = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vswingLowType      = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vavgTrueRange      = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vswingInput        = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				Bias               = new Series<int>   (Chart_Bars,MaximumBarsLookBack.Infinite);
				upTrend            = new Series<bool>  (Chart_Bars,MaximumBarsLookBack.Infinite);
				pre_swingHighType  = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				pre_swingLowType   = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				swingHighType      = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				swingLowType       = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				SwingStrength = swingStrength;
				isHLBased         = use_HL;
				MultiplierMD  = multiplierMD;
				MultiplierDTB = multiplierDTB;
				#endregion
			}
			private double MAX(ISeries<double> series, int lookback, int rbar_offset){
				double max = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) max = Math.Max(max, series[i]);
				}catch{}
				return max;
			}
			private double MIN(ISeries<double> series, int lookback, int rbar_offset){
				double min = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) min = Math.Min(min, series[i]);
				}catch{}
				return min;
			}
			public void AddToAllPivots(int idx, double price){
				if(AllPivots.Count>0){
					int ptr = AllPivots.Count-1;
					var keys = new System.Collections.Generic.List<int>(AllPivots.Keys);
					if(price<0){
						if(AllPivots[keys[ptr]]<0) AllPivots.Remove(keys[ptr]);
					}
					else if(price>0){
						if(AllPivots[keys[ptr]]>0) AllPivots.Remove(keys[ptr]);
					}
				}
				AllPivots[idx] = price;
			}
			public void CalculateIt(int CurrentBar, ISeries<double>Input, bool IsFirstTickOfBar, NinjaTrader.NinjaScript.Calculate Calculate, NinjaTrader.NinjaScript.State State, double atr256){
				ErrorMsg = string.Empty;
int line=647;
				try{
	            #region --- Calculate ZigZag ---                
	            swingMax = MAX(isHLBased ? High : Input, SwingStrength, 1);
	            swingMin = MIN(isHLBased ? Low : Input, SwingStrength, 1);

	            pre_swingHighType[0] = 0;
	            pre_swingLowType[0] = 0;
	            swingHighType[0] = 0;
	            swingLowType[0] = 0;

	            updateHigh = upTrend[1] && (isHLBased ? High[0] : Input[0]) > currentHigh;
	            updateLow = !upTrend[1] && (isHLBased ? Low[0] : Input[0]) < currentLow;
	            addHigh = !upTrend[1] && !((isHLBased ? Low[0] : Input[0]) < currentLow) && (isHLBased ? High[0] : Input[0]) > Math.Max(swingMax, currentLow);
	            addLow = upTrend[1] && !((isHLBased ? High[0] : Input[0]) > currentHigh) && (isHLBased ? Low[0] : Input[0]) < Math.Min(swingMin, currentHigh);

	            upTrend[0] = upTrend[1];
	            #endregion
line=665;
	            #region -- New High --
	            if (addHigh)
	            {
	                //-- update zigzag H/L --
	                upTrend[0] = true;
	                int lookback = CurrentBar - lastLowIdx;
	                swingLowType[lookback] = pre_swingLowType[lookback];
					AddToAllPivots(lastLowIdx, -Low[lookback]);
	                double newHigh = double.MinValue;
	                int j = 0;
	                for (int i = 0; i < CurrentBar - lastLowIdx; i++)
	                {
	                    if ((isHLBased ? High[i] : Input[i]) > newHigh)
	                    {
	                        newHigh = (isHLBased ? High[i] : Input[i]);
	                        j = i;
	                    }
	                }
	                currentHigh = newHigh;
	                priorSwingHighIdx = lastHighIdx;
	                lastHighIdx = CurrentBar - j;
	            }
	            #endregion
	            #region -- uptrend --
	            else if (updateHigh)
	            {
line=692;
	                upTrend[0] = true;
	                pre_swingHighType[CurrentBar - lastHighIdx] = 0;
	                currentHigh = (isHLBased ? High[0] : Input[0]);
	                lastHighIdx = CurrentBar;
	            }
	            #endregion
	            #region -- New Low --
	            else if (addLow)
	            {
line=702;
	                upTrend[0] = false;
	                int lookback = CurrentBar - lastHighIdx;
	                swingHighType[lookback] = pre_swingHighType[lookback];
					AddToAllPivots(lastHighIdx, High[lookback]);
	                double newLow = double.MaxValue;
	                int j = 0;
	                for (int i = 0; i < CurrentBar - lastHighIdx; i++)
	                {
	                    if ((isHLBased ? Low[i] : Input[i]) < newLow)
	                    {
	                        newLow = (isHLBased ? Low[i] : Input[i]);
	                        j = i;
	                    }
	                }
	                currentLow = newLow;
	                priorSwingLowIdx = lastLowIdx;
	                lastLowIdx = CurrentBar - j;
	            }
	            #endregion

	            #region -- dwtrend --
	            else if (updateLow)
	            {
line=726;
	                upTrend[0] = false;
	                pre_swingLowType[CurrentBar - lastLowIdx] = 0;
	                currentLow = (isHLBased ? Low[0] : Input[0]);
	                lastLowIdx = CurrentBar;
	            }
	            #endregion

	            #region -- Init zigzag states --

				vavgTrueRange[0] = atr256;

line=738;
	            if (CurrentBar < 2)
	            {
	                vupTrend[0] = true;
	                vpre_swingHighType[0] = 0;
	                vpre_swingLowType[0] = 0;
	                vswingHighType[0] = 0;
	                vswingLowType[0] = 0;
	            }
	            #endregion

	            #region OnBarClose
	            else if (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose)
	            {
line=752;
	                vzigzagDeviation = MultiplierMD * vavgTrueRange[0];
	                vswingMax        = MAX(isHLBased ? High : Input, SwingStrength, 1);
	                vswingMin        = MIN(isHLBased ? Low : Input, SwingStrength, 1);

	                vpre_swingHighType[0] = 0;
	                vpre_swingLowType[0]  = 0;
	                vswingHighType[0]     = 0;
	                vswingLowType[0]      = 0;

	                vupdateHigh = vupTrend[1]  && (isHLBased ? High[0] :   vswingInput[0]) > vcurrentHigh;
	                vupdateLow  = !vupTrend[1] && (isHLBased ? Low[0] :    vswingInput[0]) < vcurrentLow;
	                vaddHigh    = !vupTrend[1] && !((isHLBased ? Low[0] :  vswingInput[0]) < vcurrentLow) && (isHLBased ? High[0] : vswingInput[0]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
	                vaddLow     = vupTrend[1]  && !((isHLBased ? High[0] : vswingInput[0]) > vcurrentHigh) && (isHLBased ? Low[0] : vswingInput[0]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

	                vupTrend[0] = vupTrend[1];

line=769;
	                #region -- New High --
	                if (vaddHigh)
	                {
	                    vupTrend[0] = true;
	                    int lookback = CurrentBar - vlastLowIdx;
	                    vswingLowType[lookback] = vpre_swingLowType[lookback];
						AddToAllPivots(vlastLowIdx, -Low[lookback]);
	                    double vnewHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastLowIdx; i++)
	                    {
	                        if ((isHLBased ? High[i] : vswingInput[i]) > vnewHigh)
	                        {
	                            vnewHigh = (isHLBased ? High[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }

	                    vcurrentHigh = vnewHigh;
	                    vpriorSwingHighIdx = vlastHighIdx;
	                    vlastHighIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- uptrend --
	                else if (vupdateHigh)
	                {
line=797;
	                    vupTrend[0] = true;
	                    vpre_swingHighType[CurrentBar - vlastHighIdx] = 0;
	                    vcurrentHigh = (isHLBased ? High[0] : vswingInput[0]);
	                    vlastHighIdx = CurrentBar;
	                }
	                #endregion

	                #region -- New Low --
	                else if (vaddLow)
	                {
line=808;
	                    vupTrend[0] = false;
	                    int lookback = CurrentBar - vlastHighIdx;
	                    vswingHighType[lookback] = vpre_swingHighType[lookback];
						AddToAllPivots(vlastHighIdx, High[lookback]);
	                    double vnewLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastHighIdx; i++)
	                    {
	                        if ((isHLBased ? Low[i] : vswingInput[i]) < vnewLow)
	                        {
	                            vnewLow = (isHLBased ? Low[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vcurrentLow = vnewLow;
	                    vpriorSwingLowIdx = vlastLowIdx;
	                    vlastLowIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- dwtrend --
	                else if (vupdateLow)
	                {
line=832;
	                    vupTrend[0] = false;
	                    vpre_swingLowType[CurrentBar - vlastLowIdx] = 0;
	                    vcurrentLow = (isHLBased ? Low[0] : vswingInput[0]);
	                    vlastLowIdx = CurrentBar;
	                }
	                #endregion

	                #region re-init drawing states at each new bar before calculous

line=842;
	                vdrawHigherHighLabel = false;
	                vdrawLowerHighLabel = false;
	                vdrawDoubleTopLabel = false;
	                vdrawLowerLowLabel = false;
	                vdrawHigherLowLabel = false;
	                vdrawDoubleBottomLabel = false;
	                
	                #endregion

	                #region -- UP || HH --
	                if (vaddHigh || vupdateHigh)
	                {
line=855;
	                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;

	                    double vmarginUp = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) + MultiplierDTB * vavgTrueRange[vhighCount];
	                    double vmarginDown = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) - MultiplierDTB * vavgTrueRange[vhighCount];

	                    #endregion
	                    // end new code

	                    #region -- Set NEW drawing states --

	                    if (vcurrentHigh > vmarginUp) vdrawHigherHighLabel = true;
	                    else if (vcurrentHigh < vmarginDown) vdrawLowerHighLabel = true;
	                    else vdrawDoubleTopLabel = true;

	                    if (vcurrentHigh > vmarginUp)
	                        vpre_swingHighType[vhighCount] = 3;
	                    else if (vcurrentHigh < vmarginDown)
	                        vpre_swingHighType[vhighCount] = 1;
	                    else
	                        vpre_swingHighType[vhighCount] = 2;
	                    #endregion
	                }

	                #region -- DW || LL --
	                else if (vaddLow || vupdateLow)
	                {
line=885;
	                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;

						double vmarginDown = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) - MultiplierDTB * vavgTrueRange[vlowCount];
	                    double vmarginUp = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) + MultiplierDTB * vavgTrueRange[vlowCount];

	                    #region -- Calculate acceleration on BBMACD and Histo --
	                    #endregion

	                    #region -- Set NEW drawing states --

	                    if (vcurrentLow < vmarginDown) vdrawLowerLowLabel = true;
	                    else if (vcurrentLow > vmarginUp) vdrawHigherLowLabel = true;
	                    else vdrawDoubleBottomLabel = true;
	                    
	                    if (vcurrentLow < vmarginDown)
	                        vpre_swingLowType[vlowCount] = -3;
	                    else if (vcurrentLow > vmarginUp)
	                        vpre_swingLowType[vlowCount] = -1;
	                    else
	                        vpre_swingLowType[vlowCount] = -2;
	                    #endregion
	                }
	                #endregion
	            }
                #endregion

	            #region else if (IsFirstTickOfBar)
	            else if (IsFirstTickOfBar)
	            {
line=918;
	                vzigzagDeviation = MultiplierMD * vavgTrueRange[1];
	                vswingMax = MAX(isHLBased ? High : Input, SwingStrength, 2);
	                vswingMin = MIN(isHLBased ? Low : Input, SwingStrength, 2);

	                vpre_swingHighType[0] = 0;
	                vpre_swingLowType[0] = 0;
	                vswingHighType[0] = 0;
	                vswingLowType[0] = 0;

	                vupdateHigh = vupTrend[1] && (isHLBased ? High[1] : vswingInput[1]) > vcurrentHigh;
	                vupdateLow = !vupTrend[1] && (isHLBased ? Low[1] : vswingInput[1]) < vcurrentLow;
	                vaddHigh = !vupTrend[1] && !((isHLBased ? Low[1] : vswingInput[1]) < vcurrentLow) && (isHLBased ? High[1] : vswingInput[1]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
	                vaddLow = vupTrend[1] && !((isHLBased ? High[1] : vswingInput[1]) > vcurrentHigh) && (isHLBased ? Low[1] : vswingInput[1]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

	                vupTrend[0] = vupTrend[1];

	                #region -- New High --
	                if (vaddHigh)
	                {
line=938;
	                    vupTrend[0] = true;
	                    int lookback = CurrentBar - vlastLowIdx;
	                    vswingLowType[lookback] = vpre_swingLowType[lookback];
						AddToAllPivots(vlastLowIdx, -Low[lookback]);
	                    double vnewHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 1; i < CurrentBar - vlastLowIdx; i++)
	                    {
	                        if ((isHLBased ? High[i] : vswingInput[i]) > vnewHigh)
	                        {
	                            vnewHigh = (isHLBased ? High[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vcurrentHigh = vnewHigh;
	                    vpriorSwingHighIdx = vlastHighIdx;
	                    vlastHighIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- UPtrend --
	                else if (vupdateHigh)
	                {
line=962;
	                    vupTrend[0] = true;
	                    vpre_swingHighType[CurrentBar - vlastHighIdx] = 0;
	                    vcurrentHigh = (isHLBased ? High[1] : vswingInput[1]);
	                    vlastHighIdx = CurrentBar - 1;
	                }
	                #endregion

	                #region -- New Low --
	                else if (vaddLow)
	                {
line=973;
	                    vupTrend[0] = false;
	                    int lookback = CurrentBar - vlastHighIdx;
	                    vswingHighType[lookback] = vpre_swingHighType[lookback];
						AddToAllPivots(vlastHighIdx, High[lookback]);
	                    double vnewLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 1; i < CurrentBar - vlastHighIdx; i++)
	                    {
	                        if ((isHLBased ? Low[i] : vswingInput[i]) < vnewLow)
	                        {
	                            vnewLow = (isHLBased ? Low[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vcurrentLow = vnewLow;
	                    vpriorSwingLowIdx = vlastLowIdx;
	                    vlastLowIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- DWtrend --
	                else if (updateLow)
	                {
line=997;
	                    vupTrend[0] = false;
	                    vpre_swingLowType[CurrentBar - vlastLowIdx] = 0;
	                    vcurrentLow = isHLBased ? Low[1] : vswingInput[1];
	                    vlastLowIdx = CurrentBar - 1;
	                }
	                #endregion

	                #region re-init drawing states at each new bar before calculous

	                vdrawHigherHighLabel = false;
	                vdrawLowerHighLabel = false;
	                vdrawDoubleTopLabel = false;
	                vdrawLowerLowLabel = false;
	                vdrawHigherLowLabel = false;
	                vdrawDoubleBottomLabel = false;

	                #endregion

line=1016;
	                #region -- UP || HH --
	                if (vaddHigh || vupdateHigh)
	                {
	                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;

	                    double vmarginUp = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) + MultiplierDTB * vavgTrueRange[vhighCount];
	                    double vmarginDown = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) - MultiplierDTB * vavgTrueRange[vhighCount];

	                    #region -- Set NEW drawing states --

	                    if (vcurrentHigh > vmarginUp) vdrawHigherHighLabel = true;
	                    else if (vcurrentHigh < vmarginDown) vdrawLowerHighLabel = true;
	                    else vdrawDoubleTopLabel = true;
	                    
	                    if (vcurrentHigh > vmarginUp)
	                        vpre_swingHighType[vhighCount] = 3;
	                    else if (currentHigh < vmarginDown)
	                        vpre_swingHighType[vhighCount] = 1;
	                    else
	                        vpre_swingHighType[vhighCount] = 2;
	                    #endregion
	                }
	                #endregion

	                #region -- DW || LL --
	                else if (vaddLow || vupdateLow)
	                {
line=1046;
	                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;

	                    double vmarginDown = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) - MultiplierDTB * vavgTrueRange[vlowCount];
	                    double vmarginUp = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) + MultiplierDTB * vavgTrueRange[vlowCount];

	                    #region -- Set NEW drawing states --

	                    if (vcurrentLow < vmarginDown) vdrawLowerLowLabel = true;
	                    else if (vcurrentLow > vmarginUp) vdrawHigherLowLabel = true;
	                    else vdrawDoubleBottomLabel = true;
	                    
	                    if (vcurrentLow < vmarginDown)
	                        vpre_swingLowType[vlowCount] = -3;
	                    else if (vcurrentLow > vmarginUp)
	                        vpre_swingLowType[vlowCount] = -1;
	                    else
	                        vpre_swingLowType[vlowCount] = -2;
	                    #endregion
	                }
	                #endregion
	            }
	            #endregion
line=1071;
	            #region -- OnPriceChange or OnEachTick --
	            if (Calculate != NinjaTrader.NinjaScript.Calculate.OnBarClose)
	            {
line=1075;
	                vintraBarUpdateHigh = vupTrend[0] && (isHLBased ? High[0] : vswingInput[0]) > vcurrentHigh;
	                vintraBarUpdateLow = !vupTrend[0] && (isHLBased ? Low[0] : vswingInput[0]) < vcurrentLow;
	                vintraBarAddHigh = !vupTrend[0] && !((isHLBased ? Low[0] : vswingInput[0]) < vcurrentLow) && (isHLBased ? High[0] : vswingInput[0]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
	                vintraBarAddLow = vupTrend[0] && !((isHLBased ? High[0] : vswingInput[0]) > vcurrentHigh) && (isHLBased ? Low[0] : vswingInput[0]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

	                #region -- new HH --
	                if (vintraBarAddHigh)
	                {
line=1084;
	                    double vnewHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastLowIdx; i++)
	                    {
	                        if ((isHLBased ? High[i] : vswingInput[i]) > vnewHigh)
	                        {
	                            vnewHigh = (isHLBased ? High[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vpreCurrentHigh = vnewHigh;
	                    vpreLastHighIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- uptrend --
	                else if (vintraBarUpdateHigh)
	                {
line=1103;
	                    vpreCurrentHigh = (isHLBased ? High[0] : vswingInput[0]);
	                    vpreLastHighIdx = CurrentBar;
	                }
	                #endregion

	                #region -- new LL --
	                if (vintraBarAddLow)
	                {
line=1112;
	                    double vnewLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastHighIdx; i++)
	                    {
	                        if ((isHLBased ? Low[i] : vswingInput[i]) < vnewLow)
	                        {
	                            vnewLow = isHLBased ? Low[i] : vswingInput[i];
	                            j = i;
	                        }
	                    }
	                    vpreCurrentLow = vnewLow;
	                    vpreLastLowIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- dwtrend --
	                else if (vintraBarUpdateLow)
	                {
line=1131;
	                    vpreCurrentLow = (isHLBased ? Low[0] : vswingInput[0]);
	                    vpreLastLowIdx = CurrentBar;
	                }
	                #endregion

	                #region -- UP || HH --
	                if (vintraBarAddHigh || vintraBarUpdateHigh)
	                {
line=1140;
	                    int vprePriorHighCount = vintraBarAddHigh ? CurrentBar - vlastHighIdx : CurrentBar - vpriorSwingHighIdx;
	                    int vpreHighCount = CurrentBar - vpreLastHighIdx;
	                    int vprePriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    int vpreLowCount = CurrentBar - vlastLowIdx;

	                    #region ---- StructureBias RealTime ---
	                    double vmarginUp, vmarginDown;
	                    if (isHLBased)//ThisInputType == gztVMDivInputType.High_Low)
	                    {
	                        vmarginUp = High[vprePriorHighCount] + MultiplierDTB * vavgTrueRange[vpreHighCount];
	                        vmarginDown = High[vprePriorHighCount] - MultiplierDTB * vavgTrueRange[vpreHighCount];
	                    }
	                    else
	                    {
	                        vmarginUp = vswingInput[vprePriorHighCount] + MultiplierDTB * vavgTrueRange[vpreHighCount];
	                        vmarginDown = vswingInput[vprePriorHighCount] - MultiplierDTB * vavgTrueRange[vpreHighCount];
	                    }

	                    if (vpreCurrentHigh > vmarginUp) preSRType = 3;//#STRBIAS
	                    else if (vpreCurrentHigh < vmarginDown) preSRType = Math.Max(preSRType, 2);//#STRBIAS
	                    else preSRType = Math.Max(preSRType, 1);//#STRBIAS
	                    #endregion
	                }
	                #endregion

	                #region -- DW || LL --
	                else if (vintraBarAddLow || vintraBarUpdateLow)
	                {
line=1169;
	                    int vprePriorLowCount = vintraBarAddLow ? CurrentBar - vlastLowIdx : CurrentBar - vpriorSwingLowIdx;
	                    int vpreLowCount = CurrentBar - vpreLastLowIdx;
	                    int vprePriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    int vpreHighCount = CurrentBar - vlastHighIdx;

	                    #region ---- StructureBias RealTime ---
	                    double vmarginUp, vmarginDown;
	                    if (isHLBased)//ThisInputType == gztVMDivInputType.High_Low)
	                    {
	                        vmarginDown = Low[vprePriorLowCount] - MultiplierDTB * vavgTrueRange[vpreLowCount];
	                        vmarginUp = Low[vprePriorLowCount] + MultiplierDTB * vavgTrueRange[vpreLowCount];
	                    }
	                    else
	                    {
	                        vmarginDown = vswingInput[vprePriorLowCount] - MultiplierDTB * vavgTrueRange[vpreLowCount];
	                        vmarginUp = vswingInput[vprePriorLowCount] + MultiplierDTB * vavgTrueRange[vpreLowCount];
	                    }
	                    if (vpreCurrentLow < vmarginDown) preSRType = -3;//#STRBIAS
	                    else if (vpreCurrentLow > vmarginUp) preSRType = Math.Min(preSRType, -2);//#STRBIAS
	                    else preSRType = Math.Min(preSRType, -1);//#STRBIAS
	                    #endregion
	                }
	                #endregion
	                //Is it possible ??
	                else
	                {
	                    preSRType = 0;//#STRBIAS
	                }

	                #region ---- StructureBias RealTime ---
	                if (CurrentBar < 2) Bias[0] = FLAT;
	                else
	                {
line=1203;
	                    if (preSRType == 0) Bias[0] = Bias[1];

	                    #region -- Oscillation State --
	                    else if (Bias[1] == FLAT)
	                    {
	                        //Oscillation State
	                        //Need HH/!LL/HH to go to Up Trend
	                        //{NEW} !LL/High/!LL/HH to go to Up Trend
	                        //Need LL/!HH/LL to go to Dw Trend
	                        //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
	                        if (sequence.Count < 2) Bias[0] = FLAT;
	                        else if (sequence.Count < 3)
	                        {
	                            if (sequence[0] == 3 && sequence[1] != -3 && preSRType == 3) Bias[0] = UP;
	                            else if (sequence[0] == -3 && sequence[1] != 3 && preSRType == -3) Bias[0] = DOWN;
	                            else Bias[0] = FLAT;
	                        }
	                        else
	                        {
	                            if (sequence[1] == 3 && sequence[2] != -3 && preSRType == 3) Bias[0] = UP;
	                            else if (sequence[1] == -3 && sequence[2] != 3 && preSRType == -3) Bias[0] = DOWN;
	                            //{NEW} HL/LH/HL/HH to go to Up Trend
	                            else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && preSRType == 3) Bias[0] = UP;
	                            //{NEW} LH/HL/LH/LL to go to Up Trend
	                            else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && preSRType == -3) Bias[0] = DOWN;
	                            else Bias[0] = FLAT;
	                        }
	                    }
	                    #endregion

	                    #region -- UpTrend State --
	                    else if (Bias[1] > FLAT)
	                    {
line=1237;
	                        //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
	                        if (preSRType == -3) Bias[0] = FLAT;
	                        else Bias[0] = UP;
	                    }
	                    #endregion

	                    #region -- DwTrend State --
	                    else if (Bias[1] < FLAT)
	                    {
line=1247;
	                        //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
	                        if (preSRType == 3) Bias[0] = FLAT;
	                        else Bias[0] = DOWN;
	                    }
	                    #endregion

	                    else Bias[0] = Bias[1];
	                }
	                #endregion
	            }
	            #endregion
line=1259;
	            #region -- Structure BIAS --
	            SRType = vdrawHigherHighLabel ? 3 : vdrawLowerHighLabel ? 2 : vdrawDoubleTopLabel ? 1 : vdrawDoubleBottomLabel ? -1 : vdrawHigherLowLabel ? -2 : vdrawLowerLowLabel ? -3 : 0;

				#region -- Oscillation State --
	            int decay = 0;
	            if (Calculate!= NinjaTrader.NinjaScript.Calculate.OnBarClose && State != NinjaTrader.NinjaScript.State.Historical) decay = 1;
	            if (SRType != 0 && Bias[decay + 1] == FLAT)
	            {
line=1268;
	                #region -- update sequence ---
	                //--- Same Trend --
	                if (vupTrend[1] == vupTrend[0])
	                {
	                    if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
//ErrorMsg = "Sequence updated to SameTrend...SRType "+SRType+"   count:"+sequence.Count;
	                }

	                //--- Changing Trend ---
	                else if (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose && upTrend[1] != upTrend[0])
	                {
line=1281;
	                    if (sequence.Count < 4) 
							sequence.Add(SRType);
	                    else
	                    {
	                        sequence[0] = sequence[1];
	                        sequence[1] = sequence[2];
	                        sequence[2] = sequence[3];
	                        sequence[3] = SRType;
	                    }
//ErrorMsg = "Sequence updated to ChangingTrend...SRType "+SRType+"   count:"+sequence.Count;
	                }
	                #region -- eachtick --
	                else if (Calculate != NinjaTrader.NinjaScript.Calculate.OnBarClose && vupTrend[1] != vupTrend[0])
	                {
line=1296;
	                    if (IsFirstTickOfBar)
	                    {
	                        if (sequence.Count < 4) sequence.Add(SRType);
	                        else
	                        {
	                            sequence[0] = sequence[1];
	                            sequence[1] = sequence[2];
	                            sequence[2] = sequence[3];
	                            sequence[3] = SRType;
	                        }
	                    }
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                #endregion
	                #endregion
line=1313;

	                //Oscillation State
	                //Need HH/!LL/HH to go to Up Trend
	                //{NEW} !LL/High/!LL/HH to go to Up Trend
	                //Need LL/!HH/LL to go to Dw Trend
	                //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
	                if (sequence.Count < 3) Bias[decay] = FLAT;
	                else if (sequence.Count < 4)
	                {
line=1323;
	                    if (sequence[0] == 3 && sequence[1] != -3 && sequence[2] == 3) Bias[decay] = UP;
	                    else if (sequence[0] == -3 && sequence[1] != 3 && sequence[2] == -3) Bias[decay] = DOWN;
	                    else Bias[decay] = FLAT;
	                }
	                else
	                {
line=1330;
	                    if (sequence[1] == 3 && sequence[2] != -3 && sequence[3] == 3) Bias[decay] = UP;
	                    else if (sequence[1] == -3 && sequence[2] != 3 && sequence[3] == -3) Bias[decay] = DOWN;
	                    //{NEW} HL/LH/HL/HH to go to Up Trend
	                    else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && sequence[3] == 3) Bias[decay] = UP;
	                    //{NEW} LH/HL/LH/LL to go to Up Trend
	                    else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && sequence[3] == -3) Bias[decay] = DOWN;
	                    else Bias[decay] = FLAT;
	                }
	            }
	            #endregion

	            #region -- UpTrend State --
	            else if (SRType != 0 && Bias[decay + 1] > FLAT)
	            {
line=1345;
	                if (IsFirstTickOfBar) sequence.Clear();
	                //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
	                if (SRType == -3)
	                {
	                    Bias[decay] = FLAT;
	                    if (IsFirstTickOfBar) sequence.Add(SRType);
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                else Bias[decay] = UP;
	            }
	            #endregion

	            #region -- DwTrend State --
	            else if (SRType != 0 && Bias[decay + 1] < FLAT)
	            {
line=1362;
	                if (IsFirstTickOfBar) sequence.Clear();
	                //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
	                if (SRType == 3)
	                {
	                    Bias[decay] = FLAT;
	                    if (IsFirstTickOfBar) sequence.Add(SRType);
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                else Bias[decay] = DOWN;
	            }
	            #endregion

	            else Bias[decay] = Bias[decay + 1];
	            #endregion
line=1378;
				}catch(Exception e){ErrorMsg = "---------------"+line.ToString()+":  StructureBiasMgr\n\n"+e.ToString() + "---------------";}
			}
			#endregion
		}

		private bool iz = false;
		private string ObjTagPrefix = string.Empty;
		static string  HLtemplates_folder = null;
		private SortedDictionary<string, bool> IsGlobalized = new SortedDictionary<string,bool>();
int line=1388;
		
		#region Variables for button interface
		private int    pButtonSize = 15;
		private string toolbarname = "NSTgtFinderSystemToolBar", uID;
		private bool   isToolBarButtonAdded = false;
		private Chart  chartWindow;
		private Grid   indytoolbar;
		private bool   pFreezeCalculations = false;
		private bool   isLive = false;
		private List<Brush> LabelBkgBrushes = new List<Brush>();

		private Menu MenuControlContainer;
		private MenuItem MenuControl, btn1_RecalcIndicator, btn2_RecalcIndicator;
//		private Button      ClearGlobals_Button;
//		private Button		EnableGlobals_Button;

//		private ComboBox comboEntryBasis, comboProfile;
		private MenuItem miShowLongs, miShowShorts, miShowT1, miShowT2, miShowT3, miShowSL, miShowHistoryLines;
		private MenuItem miGlobalize_Longs, miGlobalize_Shorts, miFreezeCalculation, miBarsLookback;
		private MenuItem miExtendTgtLines, miLongTgtOptions, miShortTgtOptions, miMinTicksFromMarket, miMinTicksBetweenTgts;
		private Label label_SwingStrength;
		private int GlobalObjCount = 0;

		private TextBox nudSwingStrength, nudTargetOffsetTicks, nudSLOffsetTicks;//,nudMultiplierDTB, nudSLsize, nudT1size, nudT2size;

		private Button gCmdup;
		private Button gCmddw;
		private Label gLabel;
		#endregion

		private bool ParameterChanged = false;
		private SimpleFont ZZlabelFont;
//==========================================================================================================================
//		private void PlaySoundAlert2(string wav = "alert2.wav"){
//			PlaySound( System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", wav));
//		}
//==========================================================================================================================
		#region -- Toolbar methods --
        private Grid createMktStructure_Menu(string nudValue1, string nudValue2)
        {
			#region Grid maker
			const int rHeight = 26;

			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

			//line 1 - MultiplierDTB
//			var label = new Label() { Content = "Sensitivity: ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0) };
//			label.SetValue(Grid.ColumnProperty, 0);
//			label.SetValue(Grid.RowProperty, 0);
//			label.SetValue(Grid.RowSpanProperty, 2);

//			nudMultiplierDTB = new TextBox() { Name = "MultiplierDTB" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
//			nudMultiplierDTB.Text = nudValue1;
//			nudMultiplierDTB.KeyDown += menuTxtbox_KeyDown;
//			nudMultiplierDTB.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
//				nudMultiplierDTB.Text    = ChangeTextValue("MultiplierDTB", MultiplierDTB.ToString(), e.Delta>0 ? 0.1 : -0.1);
//			};

//			nudMultiplierDTB.SetValue(Grid.ColumnProperty, 1);
//			nudMultiplierDTB.SetValue(Grid.RowProperty, 0);
//			nudMultiplierDTB.SetValue(Grid.RowSpanProperty, 2);

//			Button cmdup1 = new Button() { Name = "MultiplierDTBcmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
//			Button cmddw1 = new Button() { Name = "MultiplierDTBcmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
//			cmdup1.Click += cmdupdw_Click;
//			cmdup1.SetValue(Grid.ColumnProperty, 2);
//			cmdup1.SetValue(Grid.RowProperty, 0);
//			cmddw1.Click += cmdupdw_Click;
//			cmddw1.SetValue(Grid.ColumnProperty, 2);
//			cmddw1.SetValue(Grid.RowProperty, 1);

//			grid.Children.Add(label);
//            grid.Children.Add(nudMultiplierDTB);
//            grid.Children.Add(cmdup1);
//            grid.Children.Add(cmddw1);

			//line 2 - SwingStrength
			var label = new Label() { Content = "Swing Strength: ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0) };
			label.SetValue(Grid.ColumnProperty, 0);
			label.SetValue(Grid.RowProperty, 2);
			label.SetValue(Grid.RowSpanProperty, 2);

			nudSwingStrength = new TextBox() { Name = "SwingStrength" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			nudSwingStrength.Text = nudValue2;
			nudSwingStrength.KeyDown += menuTxtbox_KeyDown;
			nudSwingStrength.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
//				nudSwingStrength.Text    = ChangeTextValue("SwingStrength", SwingStrength.ToString(), e.Delta>0 ? 1 : -1);
				if(e.Delta<0){
					SwingStrength = Math.Max(1, SwingStrength-1);
				}else if(e.Delta>0){
					SwingStrength = Math.Min(1000,SwingStrength+1);
				}
				InformUserAboutRecalculation();
				nudSwingStrength.Text = SwingStrength.ToString();
			};

			nudSwingStrength.SetValue(Grid.ColumnProperty, 1);
			nudSwingStrength.SetValue(Grid.RowProperty, 2);
			nudSwingStrength.SetValue(Grid.RowSpanProperty, 2);

			Button cmdup2 = new Button() { Name = "SwingStrengthcmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			Button cmddw2 = new Button() { Name = "SwingStrengthcmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			cmdup2.Click += cmdupdw_Click;
			cmdup2.SetValue(Grid.ColumnProperty, 2);
			cmdup2.SetValue(Grid.RowProperty, 2);
			cmddw2.Click += cmdupdw_Click;
			cmddw2.SetValue(Grid.ColumnProperty, 2);
			cmddw2.SetValue(Grid.RowProperty, 3);

			grid.Children.Add(label);
            grid.Children.Add(nudSwingStrength);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            return grid;
			#endregion
        }
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
	        #region cmdupdw_Click
			Button cmd = sender as Button;
//			if (cmd.Name.Contains("MultiplierDTB")){
//				if(cmd.Name.Contains("up")) 
//					nudMultiplierDTB.Text = Math.Min(200, Convert.ToDouble(nudMultiplierDTB.Text) + 0.1).ToString();
//				else 
//					nudMultiplierDTB.Text = Math.Max(1, Convert.ToDouble(nudMultiplierDTB.Text) - 0.1).ToString();
//			}
//			else 
			if (cmd.Name.Contains("SwingStrength")){
				if(cmd.Name.Contains("up")) 
					SwingStrength++;
				else 
					SwingStrength = Math.Max(1, SwingStrength-1);
				nudSwingStrength.Text = SwingStrength.ToString();
				InformUserAboutRecalculation();
			}
			else if (cmd.Name.Contains("TargetOffset")){
				if(cmd.Name.Contains("up")) 
					TargetOffsetTicks++;
				else 
					TargetOffsetTicks = Math.Max(0, TargetOffsetTicks-1);
				nudTargetOffsetTicks.Text = TargetOffsetTicks.ToString();
			}
			else if (cmd.Name.Contains("SLOffset")){
				if(cmd.Name.Contains("up")) 
					SLOffsetTicks++;
				else 
					SLOffsetTicks = Math.Max(0, SLOffsetTicks+1);
				nudSLOffsetTicks.Text = SLOffsetTicks.ToString();
			}
	        #endregion
        }
		private void menuTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			#region menuTxtbox_KeyDown
			e.Handled = true;
			TextBox txtSender = sender as TextBox;
			int cursor_location = txtSender.SelectionStart;
			int keyVal = (int)e.Key;
			int new_number = -1;
			if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) {
				new_number = keyVal - (int)System.Windows.Input.Key.D0;
			}else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) {
				new_number = keyVal - (int)System.Windows.Input.Key.NumPad0;
			}

			bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.Decimal;
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.OemPeriod;

			if (isNumeric || e.Key == System.Windows.Input.Key.Back)
			{
				string newText = new_number != -1 ? new_number.ToString() : "";
				if(!txtSender.Text.Contains(".")){
					if(e.Key==System.Windows.Input.Key.Decimal) newText = ".";
					else if(e.Key==System.Windows.Input.Key.OemPeriod) newText = ".";
				}
				try{
					if(txtSender.SelectedText.Length==0)
						txtSender.Text = txtSender.Text.Insert(cursor_location, newText);
					else{
						txtSender.Text = txtSender.Text.Replace(txtSender.SelectedText, newText);
					}
				}catch(Exception t){Print("menuTxtbox_KeyDown: "+t.ToString());}
				cursor_location++;
			}

			string intxt = txtSender.Text;
			intxt = intxt.Replace("-",string.Empty);//no negative values allowed
			intxt = intxt.Trim();
			if (intxt.Length > 0)
			{
				txtSender.Text = this.ChangeTextValue(txtSender.Name, intxt, 0);
				txtSender.SelectionStart = Math.Min(txtSender.Text.Length,cursor_location);
            }            
			#endregion
		}

//        private void MouseWheelEvent(object sender, System.Windows.Input.MouseWheelEventArgs e)
//        {
//			#region ----- MouseWheelEvent -----
//			TextBox txtSender = sender as TextBox;
//			string intxt      = txtSender.Text;
//			txtSender.Text    = ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 1 : -1);
//			#endregion
//        }
//==========================================================================================================================
		private void InformUserAboutRecalculation(){
			btn1_RecalcIndicator.Background = Brushes.Yellow;
			btn1_RecalcIndicator.FontWeight = FontWeights.Bold;
			btn1_RecalcIndicator.FontStyle = FontStyles.Italic;
			btn2_RecalcIndicator.Background = Brushes.Yellow;
			btn2_RecalcIndicator.FontWeight = FontWeights.Bold;
			btn2_RecalcIndicator.FontStyle = FontStyles.Italic;
		}
		private void ResetRecalculationUI(){
			btn1_RecalcIndicator.FontWeight = FontWeights.Normal;
			btn1_RecalcIndicator.FontStyle = FontStyles.Normal;
			btn1_RecalcIndicator.Background = null;
			btn2_RecalcIndicator.FontWeight = FontWeights.Normal;
			btn2_RecalcIndicator.FontStyle = FontStyles.Normal;
			btn2_RecalcIndicator.Background = null;
		}
//===================================================================================================================================
		private string Add_uID(string tag){ return string.Format("{0} {1}", tag, ObjTagPrefix);}
//===================================================================================================================================
        private void VisualsMasterMenuItem_Click(object sender, EventArgs e)
        {
			#region VisualsMasterMenuItem_Click
			MenuItem item = sender as MenuItem;
			if(item==null) return;

//miEntryBasis = new MenuItem { Header = "Entry Basis "+ this.EntryBasis.ToString(), Name = "entryBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };

			#region -- pShowLongs --
			else if (item.Name.Contains("pShowLongs"))
			{
				pShowLongs = !pShowLongs;
				if (!pShowLongs) {
                    item.Header = item.Header.ToString().Replace("ON","OFF");
//					RemoveDrawObject(Add_uID("LT1"));
					RemoveDrawObject(Add_uID("@LT1"));
//					RemoveDrawObject(Add_uID("LT2"));
					RemoveDrawObject(Add_uID("@LT2"));
//					RemoveDrawObject(Add_uID("LT3"));
					RemoveDrawObject(Add_uID("@LT3"));
//					RemoveDrawObject(Add_uID("LSL"));
					RemoveDrawObject(Add_uID("@LSL"));
				} else {
                    item.Header = item.Header.ToString().Replace("OFF","ON");
					CalculatePricesOfStopsAndTargets();
					DrawAllSelectedRays();
                }
			}
			#endregion
			#region -- showShorts --
			else if (item.Name.Contains("pShowShorts"))
			{
				pShowShorts = !pShowShorts;
				if (!pShowShorts) {
                    item.Header = item.Header.ToString().Replace("ON","OFF");
//					RemoveDrawObject(Add_uID("ST1"));
					RemoveDrawObject(Add_uID("@ST1"));
//					RemoveDrawObject(Add_uID("ST2"));
					RemoveDrawObject(Add_uID("@ST2"));
//					RemoveDrawObject(Add_uID("ST3"));
					RemoveDrawObject(Add_uID("@ST3"));
//					RemoveDrawObject(Add_uID("SSL"));
					RemoveDrawObject(Add_uID("@SSL"));
				} else {
                    item.Header = item.Header.ToString().Replace("OFF","ON");
					CalculatePricesOfStopsAndTargets();
					DrawAllSelectedRays();
				}
			}
			#endregion
			#region -- Show T1 line, T2 line and SL line --
			if (item.Name.Contains("showT1"))
			{
				this.pShowT1 = !this.pShowT1;
				if(!pShowT1){
					item.Header = item.Header.ToString().Replace("ON","OFF");
//					RemoveDrawObject(Add_uID("ST1"));
					RemoveDrawObject(Add_uID("@ST1"));
//					RemoveDrawObject(Add_uID("LT1"));
					RemoveDrawObject(Add_uID("@LT1"));
				}
				else{
					item.Header = item.Header.ToString().Replace("OFF","ON");
					CalculatePricesOfStopsAndTargets();
					DrawAllSelectedRays();
				}
			}
			else if (item.Name.Contains("showT2"))
			{
				this.pShowT2 = !this.pShowT2;
				if(!pShowT2){
					item.Header = item.Header.ToString().Replace("ON","OFF");
//					RemoveDrawObject(Add_uID("ST2"));
					RemoveDrawObject(Add_uID("@ST2"));
//					RemoveDrawObject(Add_uID("LT2"));
					RemoveDrawObject(Add_uID("@LT2"));
				}else{
					item.Header = item.Header.ToString().Replace("OFF","ON");
					CalculatePricesOfStopsAndTargets();
					DrawAllSelectedRays();
				}
			}
			else if (item.Name.Contains("showT3"))
			{
				this.pShowT3 = !this.pShowT3;
				if(!pShowT3){
					item.Header = item.Header.ToString().Replace("ON","OFF");
//					RemoveDrawObject(Add_uID("ST3"));
					RemoveDrawObject(Add_uID("@ST3"));
//					RemoveDrawObject(Add_uID("LT3"));
					RemoveDrawObject(Add_uID("@LT3"));
				}else{
					item.Header = item.Header.ToString().Replace("OFF","ON");
					CalculatePricesOfStopsAndTargets();
					DrawAllSelectedRays();
				}
			}
//			else if (item.Name.Contains("showSL"))
//			{
//				this.pShowSL = !this.pShowSL;
//				if (!pShowSL){
//					item.Header = item.Header.ToString().Replace("ON","OFF");
////					RemoveDrawObject(Add_uID("SSL"));
//					RemoveDrawObject(Add_uID("@SSL"));
////					RemoveDrawObject(Add_uID("LSL"));
//					RemoveDrawObject(Add_uID("@LSL"));
//				}else{
//					item.Header = item.Header.ToString().Replace("OFF","ON");
//					CalculatePricesOfStopsAndTargets();
//					DrawAllSelectedRays();
//				}
//			}
			#endregion

			#region -- Hit the Recalc button --
			if (item.Name.Contains("RecalcClick"))
			{
//				if(SLTP_CalcBasis == ARC_TargetFinder_SLTP_CalcBasis.ATR){
//					this.SLsize_inATRs       = Math.Max(0.0, Math.Min(100,Convert.ToDouble(nudSLsize.Text)));
//					this.T1size_inATRs       = Math.Max(0.0, Math.Min(100,Convert.ToDouble(nudT1size.Text)));
//					this.T2size_inATRs       = Math.Max(0.0, Math.Min(100,Convert.ToDouble(nudT2size.Text)));
//				}else{
//					this.SLsize_inTicks      = Convert.ToInt32(Math.Max(0.0, Math.Min(10000,Convert.ToDouble(nudSLsize.Text))));
//					this.T1size_inTicks      = Convert.ToInt32(Math.Max(0.0, Math.Min(10000,Convert.ToDouble(nudT1size.Text))));
//					this.T2size_inTicks      = Convert.ToInt32(Math.Max(0.0, Math.Min(10000,Convert.ToDouble(nudT2size.Text))));
//				}
				System.Windows.Forms.SendKeys.SendWait("{F5}");
//				btn_RecalcTradePlans.Background = null;
				ResetRecalculationUI();
				return;
			}
			#endregion
			else{
				ParameterChanged = true;
			    ChartControl.InvalidateVisual();
			}
			#endregion
        }
//==========================================================================================================================
        private void structureMenuItem_Click(object sender, EventArgs e)
        {
	        #region structureMenuItem_Click
			MenuItem item = sender as MenuItem;
//Print("Item.Name; "+item.Name+"   header: "+item.Header.ToString());
//			#region -- RecalcMarketStructureClick --
//			if (item.Name.Contains("RecalcMarketStructureClick"))
//			{
//				this.SwingStrength = Convert.ToInt32(nudSwingStrength.Text);
//				InformUserAboutRecalculation();
//				System.Windows.Forms.SendKeys.SendWait("{F5}");
//				return;
//			}
//			#endregion
           #region -- showMarketStructureClick --
//            else 
				if (item.Name.Contains( "showStructureLinesClick"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.ShowStructureLines = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
                }
                else
                {
                    this.ShowStructureLines = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
                }
            }
            #endregion
            #region -- showStructureLabelsClick --
            else if (item.Name.Contains( "showStructureLabelsClick"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.ShowStructureLabels = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
                }
                else
                {
                    this.ShowStructureLabels = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
                }
            }
            #endregion
            ChartControl.InvalidateVisual();
	        #endregion
        }
//==========================================================================================================================
		private string ChangeTextValue(string SenderName, string intxt, double change_amount){
	        #region ChangeTextValue
			if (SenderName.Contains("SwingStrength")) {
				InformUserAboutRecalculation();
				intxt = intxt.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
				SwingStrength = Math.Max(1,Convert.ToInt32(intxt) + Convert.ToInt32(change_amount));
				return SwingStrength.ToString();

//			}else if (SenderName.Contains("MultiplierDTB")) {
//				InformUserAboutRecalculation();
//				MultiplierDTB = Math.Round(Math.Max(0,Convert.ToDouble(intxt) + change_amount),1);
//				return MultiplierDTB.ToString();

			} else if (SenderName.Contains("TargetOffset")) {
				intxt = intxt.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
				int num = Convert.ToInt32(intxt) + Convert.ToInt32(change_amount);
				bool isInRange = num>=-100 && num<=100;
				if(isInRange){
					this.TargetOffsetTicks   = num;
					ParameterChanged = true;
					InformUserAboutRecalculation();
		            ChartControl.InvalidateVisual();
					return TargetOffsetTicks.ToString();
				}

			} else if (SenderName.Contains("SLOffset")) {
				intxt = intxt.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
				int num = Convert.ToInt32(intxt) + Convert.ToInt32(change_amount);
				bool isInRange = num>=-100 && num<=100;
				if(isInRange){
					this.SLOffsetTicks   = num;
					ParameterChanged = true;
					InformUserAboutRecalculation();
		            ChartControl.InvalidateVisual();
					return SLOffsetTicks.ToString();
				}
			}
			return intxt;
			#endregion
		}
//==========================================================================================================================
		private int CalculateCountOfGlobalObjects(){
			#region -- CalculateCountOfGlobalObjects --
			var tags = new List<string>();
			tags.Add(string.Format("@LT1 {0}", ObjTagPrefix));
			tags.Add(string.Format("@LT2 {0}", ObjTagPrefix));
			tags.Add(string.Format("@LT3 {0}", ObjTagPrefix));
			tags.Add(string.Format("@LSL {0}", ObjTagPrefix));
			tags.Add(string.Format("@ST1 {0}", ObjTagPrefix));
			tags.Add(string.Format("@ST2 {0}", ObjTagPrefix));
			tags.Add(string.Format("@ST3 {0}", ObjTagPrefix));
			tags.Add(string.Format("@SSL {0}", ObjTagPrefix));
//			tags.Add(string.Format("LT1 {0}", ObjTagPrefix));
//			tags.Add(string.Format("LT2 {0}", ObjTagPrefix));
//			tags.Add(string.Format("LT3 {0}", ObjTagPrefix));
//			tags.Add(string.Format("LSL {0}", ObjTagPrefix));
//			tags.Add(string.Format("ST1 {0}", ObjTagPrefix));
//			tags.Add(string.Format("ST2 {0}", ObjTagPrefix));
//			tags.Add(string.Format("ST3 {0}", ObjTagPrefix));
//			tags.Add(string.Format("SSL {0}", ObjTagPrefix));
			var objects = DrawObjects.Where(ob=> tags.Contains(ob.Tag));
			if(objects==null) return 0;
			return objects.Count();
			#endregion
		}
		private void SLCalcBasis_SetVisibilityOfInputs(){
			#region SLCalcBasis
			return;
//			if(SLTP_CalcBasis == ARC_TargetFinder_SLTP_CalcBasis.ATR){
//				nudSLMult.Visibility = Visibility.Visible;
//				nudSLsize.Visibility = Visibility.Hidden;
//				label_SLATR.Visibility = Visibility.Visible;
//				label_SLsize.Visibility = Visibility.Hidden;
//			}else{
//				nudSLMult.Visibility = Visibility.Hidden;
//				nudSLsize.Visibility = Visibility.Visible;
//				label_SLsize.Visibility = Visibility.Visible;
//				label_SLATR.Visibility = Visibility.Hidden;
//			}
			#endregion
		}
		#endregion
//==========================================================================================================================
		private void AddToolbar()
		{
			#region AddToolbar
			gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
			gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
			gLabel = new Label();//#RJBug001

			MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
			MenuControl          = new MenuItem {Name="NSTF"+uID, BorderThickness   = new Thickness(2), Header = pButtonText, 
														BorderBrush = Brushes.Yellow, 
														Foreground  = Brushes.Yellow, 
														Background  = Brushes.MediumBlue, 
														VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControl.GotFocus += delegate(object o, RoutedEventArgs e){
				GlobalObjCount = CalculateCountOfGlobalObjects();
//				if(GlobalObjCount>0){
//					ClearGlobals_Button.Background = Brushes.DarkGreen;
//					ClearGlobals_Button.Content    = "Clear Globals";
//					ClearGlobals_Button.Visibility = Visibility.Visible;
//				}else
//					ClearGlobals_Button.Visibility = Visibility.Collapsed;
			};
			MenuControlContainer.Items.Add(MenuControl);

			#region -- Reg Visuals --
			//MenuItem miTPMaster = new MenuItem { Header = "Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

//			miDominantTP = new MenuItem { Header = "Dominant Trade Plan: "+ this.DominantTradePlan.ToString().ToUpper(), Name = "dominantTradePlan"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miDominantTP.Click += VisualsMasterMenuItem_Click;
//			miTPMaster.Items.Add(miDominantTP);

//			miEntryBasis = new MenuItem { Header = "Entry Basis: "+ this.EntryBasis.ToString(), Name = "entryBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miEntryBasis.Click += VisualsMasterMenuItem_Click;
//			miTPMaster.Items.Add(miEntryBasis);

//			miPlanLevelsBasis = new MenuItem { Header = "Plan Level Basis: "+ this.PlanLevelsBasis.ToString(), Name = "PlanLevelsBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miPlanLevelsBasis.Click += VisualsMasterMenuItem_Click;
//			miTPMaster.Items.Add(miPlanLevelsBasis);

//			miTPMaster.Items.Add(new Separator());

	//- - - - - - - - - - - - - 
			miShowLongs = new MenuItem { Header = this.pShowLongs ? "Longs ON" : "Long OFF", Name = "pShowLongs"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miShowLongs.Click += VisualsMasterMenuItem_Click;
			miShowLongs.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					pShowLongs = !pShowLongs;
					miShowLongs.Header = pShowLongs ? "Longs ON" : "Longs OFF";
					ForceRefresh();
					MenuControl.InvalidateVisual();
				}
				#endregion
			};
			MenuControl.Items.Add(miShowLongs);
	//- - - - - - - - - - - - - 
			#region -- Globalize Longs --
			miGlobalize_Longs = new MenuItem {Header = "Globalize Longs", Name = "GlobalizeLongs"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			IsGlobalized["L"] = false;
			miGlobalize_Longs.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				var tag = "LSL";
				IsGlobalized["L"] = !IsGlobalized["L"];
				if(!IsGlobalized["L"]){
					miGlobalize_Longs.Header = "Globalize Longs";
//					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
//					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
					tag = "LT1";
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
//					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
					tag = "LT2";
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
//					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
					tag = "LT3";
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
//					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
				} else {
						miGlobalize_Longs.Header = "Localize Longs";
//						if(pShowLongs && pShowSL && Levels["LSL"].Price != double.MinValue){
//							tag = "LSL";
////							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
////							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["LSL"].Price, this.pLongSL_DTTemplate); 
////							GlobalRays[tag].IsDrawn = true;
//							ImmediatelyDraw_Ray(tag);
//						}
						if(pShowLongs && pShowT1 && Levels["LT1"].Price!=double.MinValue){
							tag = "LT1";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
//							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["LT1"].Price, this.pLongT_DTTemplate); 
//							GlobalRays[tag].IsDrawn = true;
							ImmediatelyDraw_Ray(tag);
						}
						if(pShowLongs && pShowT2 && Levels["LT2"].Price!=double.MinValue){
							tag = "LT2";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
//							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["LT2"].Price, this.pLongT_DTTemplate); 
//							GlobalRays[tag].IsDrawn = true;
							ImmediatelyDraw_Ray(tag);
						}
						if(pShowLongs && pShowT3 && Levels["LT3"].Price!=double.MinValue){
							tag = "LT3";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
//							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["LT3"].Price, this.pLongT_DTTemplate); 
//							GlobalRays[tag].IsDrawn = true;
							ImmediatelyDraw_Ray(tag);
						}
				}
				GlobalObjCount = CalculateCountOfGlobalObjects();
//				if(GlobalObjCount>0){
////					pGlobalObjects_Enabled = true;
////					EnableGlobals_Button.Content   = "Globals ON";
//					ClearGlobals_Button.Background = Brushes.DarkGreen;
//					ClearGlobals_Button.Content    = "Clear Globals";
//					ClearGlobals_Button.Visibility = Visibility.Visible;
//				}else{
////					pGlobalObjects_Enabled = false;
////					EnableGlobals_Button.Content   = "Globals OFF";
//					ClearGlobals_Button.Background = Brushes.DimGray;
//					ClearGlobals_Button.Visibility = Visibility.Collapsed;
//				}
				ForceRefresh();
			};
			MenuControl.Items.Add(miGlobalize_Longs);
			#endregion
	//- - - - - - - - - - - - - 
			miShowShorts = new MenuItem { Header = pShowShorts ? "Shorts ON" : "Shorts OFF", Name = "pShowShorts"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miShowShorts.Click += VisualsMasterMenuItem_Click;
			miShowShorts.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					pShowShorts = !pShowShorts;
					miShowShorts.Header = pShowShorts ? "Shorts ON" : "Shorts OFF";
					ForceRefresh();
					MenuControl.InvalidateVisual();
				}
				#endregion
			};
			MenuControl.Items.Add(miShowShorts);
	//- - - - - - - - - - - - - 
			#region -- Globalize Shorts --
			miGlobalize_Shorts = new MenuItem {Header = "Globalize Shorts", Name = "GlobalizeShorts"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			IsGlobalized["S"] = false;
			miGlobalize_Shorts.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				var tag = "SSL";
				IsGlobalized["S"] = !IsGlobalized["S"];
				if(!IsGlobalized["S"]){
					miGlobalize_Shorts.Header = "Globalize Shorts";
//					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
//					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
					tag = "ST1";
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
//					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
					tag = "ST2";
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
//					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
					tag = "ST3";
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
//					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
				} else {
						miGlobalize_Shorts.Header = "Localize shorts";
//						if(pShowShorts && pShowSL && Levels["SSL"].Price !=double.MinValue){
//							tag = "SSL";
////							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
////							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["SSL"].Price, this.pShortSL_DTTemplate); 
////							GlobalRays[tag].IsDrawn = true;
//							ImmediatelyDraw_Ray(tag);
//						}
						if(pShowShorts && pShowT1 && Levels["ST1"].Price!=double.MinValue){
							tag = "ST1";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
//							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["ST1"].Price, this.pShortT_DTTemplate); 
//							GlobalRays[tag].IsDrawn = true;
							ImmediatelyDraw_Ray(tag);
						}
						if(pShowShorts && pShowT2 && Levels["ST2"].Price!=double.MinValue){
							tag = "ST2";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
//							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["ST2"].Price, this.pShortT_DTTemplate); 
//							GlobalRays[tag].IsDrawn = true;
							ImmediatelyDraw_Ray(tag);
						}
						if(pShowShorts && pShowT3 && Levels["ST3"].Price!=double.MinValue){
							tag = "ST3";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
//							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["ST3"].Price, this.pShortT_DTTemplate); 
//							GlobalRays[tag].IsDrawn = true;
							ImmediatelyDraw_Ray(tag);
						}
				}
				GlobalObjCount = CalculateCountOfGlobalObjects();
//				if(GlobalObjCount>0){
////					pGlobalObjects_Enabled = true;
////					EnableGlobals_Button.Content   = "Globals ON";
//					ClearGlobals_Button.Background = Brushes.DarkGreen;
//					ClearGlobals_Button.Content    = "Clear Globals";
//					ClearGlobals_Button.Visibility = Visibility.Visible;
//				}else{
////					pGlobalObjects_Enabled = false;
////					EnableGlobals_Button.Content   = "Globals OFF";
//					ClearGlobals_Button.Background = Brushes.DimGray;
//					ClearGlobals_Button.Visibility = Visibility.Collapsed;
//				}
				ForceRefresh();
			};
			MenuControl.Items.Add(miGlobalize_Shorts);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- LookbackBars --
			miBarsLookback = new MenuItem { Header = "Lookback bars: "+this.pBarsLookback.ToString(), Name = "barsLookback"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miBarsLookback.ToolTip = "Use mousewheel to increment/decrement, and hold down LeftShift key while you scroll to increase the step";
			miBarsLookback.Click += delegate (object o, RoutedEventArgs e){
				pBarsLookback = 1500;
				CalculatePricesOfStopsAndTargets();
				miBarsLookback.Header = "Lookback bars: "+this.pBarsLookback.ToString();
				ForceRefresh();
			};
			miBarsLookback.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					int step = e.Delta > 0 ? 1 : -1;
					if(pBarsLookback<100){
						if(Keyboard.IsKeyDown(Key.LeftShift)) step = step *10;
					}else{
						if(Keyboard.IsKeyDown(Key.LeftShift)) step = step *100;
					}
					pBarsLookback = Math.Max(pBarsLookback + step, 1);
					miBarsLookback.Header = "Lookback bars: "+this.pBarsLookback.ToString();
					CalculatePricesOfStopsAndTargets();
					ForceRefresh();
//					MenuControl.InvalidateVisual();
				}
				#endregion
			};
			MenuControl.Items.Add(miBarsLookback);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Minimum ticks from current market price --
			miMinTicksFromMarket = new MenuItem {Header = "Min. ticks from Mkt price:  "+pMinTicksFromMarket.ToString(),  Name = "minTicksFromMkt"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miMinTicksFromMarket.ToolTip = "Use mousewheel to increment/decrement, and hold down LeftShift key while you scroll to increase the step";
			miMinTicksFromMarket.Click += delegate (object o, RoutedEventArgs e){
				if(e!=null){
					e.Handled = true;
					pMinTicksFromMarket = 1;
					miMinTicksFromMarket.Header = "Min. ticks from Mkt price:  "+pMinTicksFromMarket.ToString();
					CalculatePricesOfStopsAndTargets();
					ForceRefresh();
//					InformUserAboutRecalculation();
				}
			};
			miMinTicksFromMarket.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					int step = e.Delta > 0 ? 1 : -1;
					if(pMinTicksFromMarket<100){
						if(Keyboard.IsKeyDown(Key.LeftShift)) step = step * 10;
					}else{
						if(Keyboard.IsKeyDown(Key.LeftShift)) step = step * 50;
					}
					pMinTicksFromMarket = Math.Max(pMinTicksFromMarket + step, 1);

					miMinTicksFromMarket.Header = "Min. ticks from Mkt price:  "+pMinTicksFromMarket.ToString();
					CalculatePricesOfStopsAndTargets();
					ForceRefresh();
//					InformUserAboutRecalculation();
				}
				#endregion
			};
			MenuControl.Items.Add(miMinTicksFromMarket);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Minimum ticks between targets --
			this.miMinTicksBetweenTgts = new MenuItem {Header = "Min. ticks between tgts:  "+pMinTicksBetweenTgts.ToString(),  Name = "minTicksBetweenTgts"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miMinTicksBetweenTgts.ToolTip = "Use mousewheel to increment/decrement, and hold down LeftShift key while you scroll to increase the step";
			miMinTicksBetweenTgts.Click += delegate (object o, RoutedEventArgs e){
				if(e!=null){
					e.Handled = true;
					pMinTicksBetweenTgts = 1;
					miMinTicksBetweenTgts.Header = "Min. ticks between tgts:  "+pMinTicksBetweenTgts.ToString();
					CalculatePricesOfStopsAndTargets();
					ForceRefresh();
//					InformUserAboutRecalculation();
				}
			};
			miMinTicksBetweenTgts.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					int step = e.Delta > 0 ? 1 : -1;
					if(pMinTicksBetweenTgts<100){
						if(Keyboard.IsKeyDown(Key.LeftShift)) step = step * 10;
					}else{
						if(Keyboard.IsKeyDown(Key.LeftShift)) step = step * 50;
					}
					pMinTicksBetweenTgts = Math.Max(pMinTicksBetweenTgts + step, 1);

					miMinTicksBetweenTgts.Header = "Min. ticks between tgts:  "+pMinTicksBetweenTgts.ToString();
					CalculatePricesOfStopsAndTargets();
					ForceRefresh();
//					InformUserAboutRecalculation();
				}
				#endregion
			};
			MenuControl.Items.Add(miMinTicksBetweenTgts);
			#endregion
	//- - - - - - - - - - - - - 
			miShowT1 = new MenuItem { Header = pShowT1 ? "Show T1 ON" : "Show T1 OFF", Name = "showT1"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miShowT1.Click += delegate (object o, RoutedEventArgs e){
				#region -- click --
				pShowT1 = !pShowT1;
				miShowT1.Header = pShowT1 ? "Show T1 ON" : "Show T1 OFF";
				ForceRefresh();
				#endregion
			};
			miShowT1.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					pShowT1 = !pShowT1;
					miShowT1.Header = pShowT1 ? "Show T1 ON" : "Show T1 OFF";
					ForceRefresh();
					//MenuControl.InvalidateVisual();
				}
				#endregion
			};
			MenuControl.Items.Add(miShowT1);
	//- - - - - - - - - - - - - 
			miShowT2 = new MenuItem { Header = pShowT2 ? "Show T2 ON" : "Show T2 OFF", Name = "showT2"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miShowT2.Click += delegate (object o, RoutedEventArgs e){
				#region -- click --
				pShowT2 = !pShowT2;
				miShowT2.Header = pShowT2 ? "Show T2 ON" : "Show T2 OFF";
				ForceRefresh();
				#endregion
			};
			miShowT2.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					pShowT2 = !pShowT2;
					miShowT2.Header = pShowT2 ? "Show T2 ON" : "Show T2 OFF";
					ForceRefresh();
					//MenuControl.InvalidateVisual();
				}
				#endregion
			};
			MenuControl.Items.Add(miShowT2);
	//- - - - - - - - - - - - - 
			miShowT3 = new MenuItem { Header = pShowT3 ? "Show T3 ON" : "Show T3 OFF", Name = "showT3"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miShowT3.Click += delegate (object o, RoutedEventArgs e){
				#region -- click --
				pShowT3 = !pShowT3;
				miShowT3.Header = pShowT3 ? "Show T3 ON" : "Show T3 OFF";
				ForceRefresh();
				#endregion
			};
			miShowT3.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					pShowT3 = !pShowT3;
					miShowT3.Header = pShowT3 ? "Show T3 ON" : "Show T3 OFF";
					ForceRefresh();
					//MenuControl.InvalidateVisual();
				}
				#endregion
			};
			MenuControl.Items.Add(miShowT3);
	//- - - - - - - - - - - - - 
			#region -- Long targets - options --
			miLongTgtOptions = new MenuItem { Header = "Long Targets: "+pLongTargetsOptions.ToString(), Name = "LongTgtOptions"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miLongTgtOptions.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				if(pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Highs)
					pLongTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Lows;
				else if(pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Lows)
					pLongTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Both;
				else if(pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Both)
					pLongTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Highs;

				miLongTgtOptions.Header = "Long Targets: "+pLongTargetsOptions.ToString();
				StructureBiasMgr.CalculateIt(CurrentBar, Input, IsFirstTickOfBar, Calculate, State, ATR(256)[0]);
				CalculatePricesOfStopsAndTargets();
				ForceRefresh();
				#endregion
			};
			miLongTgtOptions.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					if(e.Delta>0){
						if(pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Highs)
							pLongTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Lows;
						else if(pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Lows)
							pLongTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Both;
						else if(pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Both)
							pLongTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Highs;
					}else{
						if(pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Highs)
							pLongTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Both;
						else if(pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Both)
							pLongTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Lows;
						else if(pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Lows)
							pLongTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Highs;
					}

					miLongTgtOptions.Header = "Long Targets: "+pLongTargetsOptions.ToString();
					CalculatePricesOfStopsAndTargets();
					ForceRefresh();
				}
				#endregion
			};
			MenuControl.Items.Add(miLongTgtOptions);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Short Targets - Options --
			miShortTgtOptions = new MenuItem { Header = "Short Targets: "+pShortTargetsOptions.ToString(), Name = "ShortTgtOptions"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miShortTgtOptions.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				if(pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Highs)
					pShortTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Lows;
				else if(pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Lows)
					pShortTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Both;
				else if(pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Both)
					pShortTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Highs;

				miShortTgtOptions.Header = "Short Targets: "+pShortTargetsOptions.ToString();
				StructureBiasMgr.CalculateIt(CurrentBar, Input, IsFirstTickOfBar, Calculate, State, ATR(256)[0]);
				CalculatePricesOfStopsAndTargets();
				ForceRefresh();
				#endregion
			};
			miShortTgtOptions.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					if(e.Delta>0){
						if(pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Highs)
							pShortTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Lows;
						else if(pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Lows)
							pShortTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Both;
						else if(pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Both)
							pShortTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Highs;
					}else{
						if(pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Highs)
							pShortTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Both;
						else if(pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Both)
							pShortTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Lows;
						else if(pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Lows)
							pShortTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Highs;
					}

					miShortTgtOptions.Header = "Short Targets: "+pShortTargetsOptions.ToString();
					CalculatePricesOfStopsAndTargets();
					ForceRefresh();
				}
				#endregion
			};
			MenuControl.Items.Add(miShortTgtOptions);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Show Hist Lines --
//			miShowHistoryLines = new MenuItem {Header = pShowHistoryLines ? "Show Hist. Lines ON" : "Show Hist Lines OFF",  Name = "showHistLines"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
//			miShowHistoryLines.Click += delegate (object o, RoutedEventArgs e){
//				if(e!=null){
//					e.Handled = true;
//					pShowHistoryLines = !pShowHistoryLines;
//					miShowHistoryLines.Header = pShowHistoryLines ? "Show Hist. Lines ON" : "Show Hist. Lines OFF";
//					ForceRefresh();
//					MenuControl.InvalidateVisual();
//				}
//			};
//			miShowHistoryLines.MouseWheel += delegate(object o, MouseWheelEventArgs e){
//				#region -- Mousewheel --
//				if(e!=null){
//					pShowHistoryLines = !pShowHistoryLines;
//					miShowHistoryLines.Header = pShowHistoryLines ? "Show Hist. Lines ON" : "Show Hist. Lines OFF";
//					ForceRefresh();
//					MenuControl.InvalidateVisual();
//				}
//				#endregion
//			};
//			MenuControl.Items.Add(miShowHistoryLines);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Extend Tgt Lines --
			miExtendTgtLines = new MenuItem {Header = pExtendTgtLines ? "Extend Tgt Lines ON" : "Extend Tgt Lines OFF",  Name = "extendTgtLines"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			miExtendTgtLines.Click += delegate (object o, RoutedEventArgs e){
				if(e!=null){
					e.Handled = true;
					pExtendTgtLines = !pExtendTgtLines;
					miExtendTgtLines.Header = pExtendTgtLines ? "Extend Tgt Lines ON" : "Extend Tgt Lines OFF";
					ForceRefresh();
					//MenuControl.InvalidateVisual();
				}
			};
			miExtendTgtLines.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					pExtendTgtLines = !pExtendTgtLines;
					miExtendTgtLines.Header = pExtendTgtLines ? "Extend Tgt Lines ON" : "Extend Tgt Lines OFF";
					ForceRefresh();
//					MenuControl.InvalidateVisual();
				}
				#endregion
			};
			MenuControl.Items.Add(miExtendTgtLines);
			#endregion
	//- - - - - - - - - - - - - 
//			miTPMaster.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
//			SetLabelsAndTextBoxValues_ATRorTicks();
	//- - - - - - - - - - - - - 
//			miTPMaster.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
//			btn_RecalcTradePlans = new MenuItem { Header = "RE-CALCULATE", Name = "RecalcClick", HorizontalAlignment = HorizontalAlignment.Center };
//			btn_RecalcTradePlans.Click += VisualsMasterMenuItem_Click;
//			btn_RecalcTradePlans.Background = null;
//			miTPMaster.Items.Add(btn_RecalcTradePlans);

			//MenuControl.Items.Add(miTPMaster);
			#endregion

			#region -- RegMarketStructure --
			MenuItem miMarketStructure = new MenuItem { Header = "Market Structure", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miMarketStructureLines = new MenuItem { Header = ShowStructureLines ? "Structure Lines ON" : "Structure Lines OFF", Name = "showStructureLinesClick"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miMarketStructureLines.Click += structureMenuItem_Click;
			miMarketStructure.Items.Add(miMarketStructureLines);

//			MenuItem miShowStructureLabels = new MenuItem { Header = ShowStructureLabels ? "Structure Labels ON" : "Structure Labels OFF", Name = "showStructureLabelsClick"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miShowStructureLabels.Click += structureMenuItem_Click;
//			miMarketStructure.Items.Add(miShowStructureLabels);

//			MenuItem miMarketStructureBkg = new MenuItem { Header = ShowStructureBackground ? "Structure Background ON" : "Structure Background OFF", Name = "showStructureBkgClick"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miMarketStructureBkg.Click += structureMenuItem_Click;
//			miMarketStructure.Items.Add(miMarketStructureBkg);

			miMarketStructure.Items.Add(createMktStructure_Menu("", this.SwingStrength.ToString()));
			miMarketStructure.Items.Add(new Separator());

			btn1_RecalcIndicator = new MenuItem { Header = "RE-CALCULATE STRUCTURE", Name = "RecalcClick1"+uID, HorizontalAlignment = HorizontalAlignment.Center, Background = null, Foreground=Brushes.Black, FontWeight=FontWeights.Normal };
			btn1_RecalcIndicator.Click += delegate (object o, RoutedEventArgs e){
				System.Windows.Forms.SendKeys.SendWait("{F5}");
				ResetRecalculationUI();
			};
			miMarketStructure.Items.Add(btn1_RecalcIndicator);
			
			//------------------

			MenuControl.Items.Add(miMarketStructure);
			#endregion

	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			//var miGlobal_SubMenu = new MenuItem { Header = "Global Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
	//- - - - - - - - - - - - - 
			#region -- Globalize Longs --
//			miGlobalize_Longs = new MenuItem {Header = "Globalize Longs", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
//			IsGlobalized["L"] = false;
//			miGlobalize_Longs.Click += delegate (object o, RoutedEventArgs e){
////				e.Handled = true;
//				var tag = "LSL";
//				IsGlobalized["L"] = !IsGlobalized["L"];
//				if(!IsGlobalized["L"]){
//					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
////					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
//					tag = "LT1";
//					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
////					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
//					tag = "LT2";
//					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
////					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
//					tag = "LT3";
//					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
////					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
//				} else {
//						if(pShowSL && Levels["LSL"].Price != double.MinValue){
//							tag = "LSL";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
////							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["LSL"].Price, this.pLongSL_DTTemplate); 
////							GlobalRays[tag].IsDrawn = true;
//							ImmediatelyDraw_Ray(tag);
//						}
//						if(pShowT1 && Levels["LT1"].Price!=double.MinValue){
//							tag = "LT1";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
////							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["LT1"].Price, this.pLongT_DTTemplate); 
////							GlobalRays[tag].IsDrawn = true;
//							ImmediatelyDraw_Ray(tag);
//						}
//						if(pShowT2 && Levels["LT2"].Price!=double.MinValue){
//							tag = "LT2";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
////							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["LT2"].Price, this.pLongT_DTTemplate); 
////							GlobalRays[tag].IsDrawn = true;
//							ImmediatelyDraw_Ray(tag);
//						}
//						if(pShowT3 && Levels["LT3"].Price!=double.MinValue){
//							tag = "LT3";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
////							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["LT3"].Price, this.pLongT_DTTemplate); 
////							GlobalRays[tag].IsDrawn = true;
//							ImmediatelyDraw_Ray(tag);
//						}
//				}
//				GlobalObjCount = CalculateCountOfGlobalObjects();
//				if(GlobalObjCount>0){
////					pGlobalObjects_Enabled = true;
////					EnableGlobals_Button.Content   = "Globals ON";
//					ClearGlobals_Button.Background = Brushes.DarkGreen;
//					ClearGlobals_Button.Content    = "Clear Globals";
//					ClearGlobals_Button.Visibility = Visibility.Visible;
//				}else{
////					pGlobalObjects_Enabled = false;
////					EnableGlobals_Button.Content   = "Globals OFF";
//					ClearGlobals_Button.Background = Brushes.DimGray;
//					ClearGlobals_Button.Visibility = Visibility.Collapsed;
//				}
//				ForceRefresh();
//			};
//			miGlobal_SubMenu.Items.Add(miGlobalize_Longs);
			#endregion
//	//- - - - - - - - - - - - - 
			#region -- Globalize Shorts --
//			miGlobalize_Shorts = new MenuItem {Header = "Globalize Shorts", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
//			IsGlobalized["S"] = false;
//			miGlobalize_Shorts.Click += delegate (object o, RoutedEventArgs e){
////				e.Handled = true;
//				var tag = "SSL";
//				IsGlobalized["S"] = !IsGlobalized["S"];
//				if(!IsGlobalized["S"]){
//					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
////					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
//					tag = "ST1";
//					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
////					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
//					tag = "ST2";
//					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
////					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
//					tag = "ST3";
//					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
////					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
//				} else {
//						if(pShowSL && Levels["SSL"].Price !=double.MinValue){
//							tag = "SSL";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
////							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["SSL"].Price, this.pShortSL_DTTemplate); 
////							GlobalRays[tag].IsDrawn = true;
//							ImmediatelyDraw_Ray(tag);
//						}
//						if(pShowT1 && Levels["ST1"].Price!=double.MinValue){
//							tag = "ST1";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
////							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["ST1"].Price, this.pShortT_DTTemplate); 
////							GlobalRays[tag].IsDrawn = true;
//							ImmediatelyDraw_Ray(tag);
//						}
//						if(pShowT2 && Levels["ST2"].Price!=double.MinValue){
//							tag = "ST2";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
////							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["ST2"].Price, this.pShortT_DTTemplate); 
////							GlobalRays[tag].IsDrawn = true;
//							ImmediatelyDraw_Ray(tag);
//						}
//						if(pShowT3 && Levels["ST3"].Price!=double.MinValue){
//							tag = "ST3";
//							RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
////							GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, 0, Levels["ST3"].Price, this.pShortT_DTTemplate); 
////							GlobalRays[tag].IsDrawn = true;
//							ImmediatelyDraw_Ray(tag);
//						}
//				}
//				GlobalObjCount = CalculateCountOfGlobalObjects();
//				if(GlobalObjCount>0){
////					pGlobalObjects_Enabled = true;
////					EnableGlobals_Button.Content   = "Globals ON";
//					ClearGlobals_Button.Background = Brushes.DarkGreen;
//					ClearGlobals_Button.Content    = "Clear Globals";
//					ClearGlobals_Button.Visibility = Visibility.Visible;
//				}else{
////					pGlobalObjects_Enabled = false;
////					EnableGlobals_Button.Content   = "Globals OFF";
//					ClearGlobals_Button.Background = Brushes.DimGray;
//					ClearGlobals_Button.Visibility = Visibility.Collapsed;
//				}
//				ForceRefresh();
//			};
//			miGlobal_SubMenu.Items.Add(miGlobalize_Shorts);
			#endregion
//	//- - - - - - - - - - - - - 
//			MenuControl.Items.Add(miGlobal_SubMenu);
	//- - - - - - - - - - - - - 
			#region -- Enable Globals --
//			EnableGlobals_Button = new System.Windows.Controls.Button { Content = (pGlobalObjects_Enabled ? "Globals ON":"Globals OFF"), Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
//			EnableGlobals_Button.Click += delegate (object o, RoutedEventArgs e){
//				//e.Handled = true;
//				pGlobalObjects_Enabled = !pGlobalObjects_Enabled;
//				EnableGlobals_Button.Content = (pGlobalObjects_Enabled ? "Globals ON" : "Globals OFF");
//                ForceRefresh();
//			};
//			MenuControl.Items.Add(EnableGlobals_Button);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Clear Globals --
//			ClearGlobals_Button = new System.Windows.Controls.Button { Content = "Clear Globals", Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
//			ClearGlobals_Button.Visibility = Visibility.Collapsed;
//			ClearGlobals_Button.Click += delegate(object o, RoutedEventArgs e){
//				IsGlobalized["L"]=false;
//				IsGlobalized["S"]=false;
//				miGlobalize_Longs.Header = "Globalize Longs";
//				miGlobalize_Shorts.Header = "Globalize Shorts";
//				DrawAllSelectedRays();
//				ClearGlobals_Button.Content = "";
//				ClearGlobals_Button.Visibility = Visibility.Collapsed;
//				ClearGlobals_Button.Background = Brushes.DimGray;
//				GlobalObjCount = 0;
//			};
//			MenuControl.Items.Add(ClearGlobals_Button);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Targets UPDATE/LOCKED --
			miFreezeCalculation = new MenuItem {Header = "Targets LIVE", Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
			pFreezeCalculations = false;
			miFreezeCalculation.Click += delegate (object o, RoutedEventArgs e){
				pFreezeCalculations = !pFreezeCalculations;
				if(pFreezeCalculations) miFreezeCalculation.Header = "Targets LOCKED";
				else miFreezeCalculation.Header = "Targets LIVE";
			};
			miFreezeCalculation.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pFreezeCalculations = !pFreezeCalculations;
				if(pFreezeCalculations) miFreezeCalculation.Header = "Targets LOCKED";
				else miFreezeCalculation.Header = "Targets LIVE";
			};
			MenuControl.Items.Add(miFreezeCalculation);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Recalc tgts --
			btn2_RecalcIndicator = new MenuItem { Header = "RE-CALCULATE Targets", Name = "RecalcClick2"+uID, HorizontalAlignment = HorizontalAlignment.Center, Foreground=Brushes.Black, Background = null, FontWeight=FontWeights.Normal };
			btn2_RecalcIndicator.Click += delegate (object o, RoutedEventArgs e){
				System.Windows.Forms.SendKeys.SendWait("{F5}");
				ResetRecalculationUI();
			};
			MenuControl.Items.Add(btn2_RecalcIndicator);
			#endregion

			indytoolbar.Children.Add(MenuControlContainer);
			#endregion
		}

//==========================================================================================================================
		public override string DisplayName { get { return "ARC_TargetFinder"; } }
//==========================================================================================================================
        protected override void OnStateChange()
        {
try{
			OnStateChange_ErrorMsg = string.Empty;
            #region State == State.SetDefaults
            if (State == State.SetDefaults)
            {
line=2571;
//ClearOutputWindow();
//				PrintTo = PrintTo.OutputTab2;
                Description              = @"";
                Name                     = "ARC_TargetFinder";
                Calculate                = Calculate.OnBarClose;
                IsOverlay                = true;
                PaintPriceMarkers        = false;
                DisplayInDataBox         = true;
                IsAutoScale              = false;
                ArePlotsConfigurable     = true;
                ZOrder                   = 0;
                DrawOnPricePanel         = true;
                ScaleJustification       = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = true;
				pButtonText = "TF";
line=2587;
//				AddPlot(new Stroke(Brushes.DarkRed), PlotStyle.Line, "Long SL");
				AddPlot(new Stroke(Brushes.Lime),    PlotStyle.Line, "Long T1");
				AddPlot(new Stroke(Brushes.Lime),    PlotStyle.Line, "Long T2");
				AddPlot(new Stroke(Brushes.Lime),    PlotStyle.Line, "Long T3");
//				AddPlot(new Stroke(Brushes.DarkRed), PlotStyle.Line, "Short SL");
				AddPlot(new Stroke(Brushes.Green),   PlotStyle.Line, "Short T1");
				AddPlot(new Stroke(Brushes.Green),   PlotStyle.Line, "Short T2");
				AddPlot(new Stroke(Brushes.Green),   PlotStyle.Line, "Short T3");

line=2597;

				pLongTargetsOptions  = ARC_TargetFinder_SwingTargetOptions.Lows;
				pShortTargetsOptions = ARC_TargetFinder_SwingTargetOptions.Highs;
				pMinTicksBetweenTgts = 5;
				pMinTicksFromMarket  = 8;
				pShowLongs  = true;
				pShowShorts = true;
				pShowT3 = true;
				pShowT2 = true;
				pShowT1 = true;
//				pIgnoreHighsOnLongs = true;
//				pIgnoreLowsOnShorts = true;
				pExtendTgtLines     = false;
				pRayShift   = -2;
				pLabelFont  = new SimpleFont("Arial", 12){Bold=true};
				pLongsLineLength  = 110;
				pShortsLineLength = 30;
				pBkgOpacity       = 100;
				pBarsLookback     = 1500;
				//pShowHistoryLines = false;
				isLive = false;

line = 2516;
				#region SwingTrend Defaults
				SwingStrength = 3;
                isHLBased = true;
				ShowStructureLines = true;
//				UpTrendColor = Brushes.Green;
//				OpacityUpTrendBkg = 20;
//				DownTrendColor = Brushes.Maroon;
//				OpacityDownTrendBkg = 20;
				UpLineColor   = Brushes.DarkGreen;
				DownLineColor = Brushes.Red;
				LineThickness = 2;
                ZZlabelFont = new SimpleFont("Arial", 12);
				ShowStructureLabels = false;
				#endregion

//				pLongSL_DTTemplate  = "Default";
				pLongT_DTTemplate   = "Default";
//				pShortSL_DTTemplate = "Default";
				pShortT_DTTemplate  = "Default";
            }
            #endregion

            #region State == State.Configure
            if (State == State.Configure)
            {
line=2645;
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif

                if (IsAutoScale) IsAutoScale = false;
            }
            #endregion

            #region State == State.Historical
            if (State == State.Historical)
            {
				ObjTagPrefix = string.Format("{0}#{1}{2}", Instrument.MasterInstrument.Name, DateTime.Now.Second,DateTime.Now.Millisecond);
				uID = "TF"+Instrument.MasterInstrument.Name+DateTime.Now.Ticks.ToString();

                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;
                        
                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

                            AddToolbar();
                            
                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion

            }
            #endregion

            #region State == State.DataLoaded
            if (State == State.DataLoaded)
            {
				for(int i = 0; i<Plots.Length; i++)
					this.LabelBkgBrushes.Add(this.ContrastingColor(Plots[i].Brush));
				StructureBiasMgr = new StructureBias(this, Highs[0], Lows[0], SwingStrength, isHLBased, 0, 0);
            }
            #endregion

            #region State == State.Realtime
            if (State == State.Realtime)
            {
line=2706;
				isLive = true;
				CalculatePricesOfStopsAndTargets();
//				Print("LSL: "+Levels["LSL"].Price+" at "+Levels["LSL"].ABar);
line=2710;
				DrawAllSelectedRays();
line=2712;
				foreach(var b in LabelBkgBrushes) b.Freeze();
            }
            #endregion
			
            #region State == State.Terminated
            if(State == State.Terminated)
            {
                if (chartWindow != null)
                {
                    if (indytoolbar != null)
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            chartWindow.MainMenu.Remove(indytoolbar);
                            indytoolbar = null;

                            chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
                            chartWindow = null;
                        }));
                    }
                }
            }
            #endregion

line=2737;
}catch(Exception e){
	OnStateChange_ErrorMsg = string.Format("{0}:  OnStateChange: \n{1}", line, e.ToString());
	Print(OnStateChange_ErrorMsg);
}
        }
//==========================================================================================================================
		#region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}
		#endregion
//==========================================================================================================================
		private double RoundToTick(double p){
			double t = p/TickSize;
			if(t>int.MaxValue) return int.MaxValue*TickSize;
			else if(t<int.MinValue) return int.MinValue*TickSize;
			int i = Convert.ToInt32(t);
			return i*TickSize;
		}
//==========================================================================================================================
        protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if (IsFirstTickOfBar)
			{
iz = false;//Times[0][0].Day==27 && Times[0][0].Hour>=10 && Times[0][0].Minute>=10;
				StructureBiasMgr.CalculateIt(CurrentBar, Input, IsFirstTickOfBar, Calculate, State, ATR(256)[0]);
				try{
					CalculatePricesOfStopsAndTargets();
				}catch(Exception ee){Print(line+"  e: "+ee.ToString());}
			}
        }
//==========================================================================================================================
		private void CalculatePricesOfStopsAndTargets() {
			if(isLive && pFreezeCalculations) return;
			#region -- CalculatePricesOfStopsAndTargets --
			if(StructureBiasMgr.AllPivots.Count>1)	{
line=2798;//Print(line);
				var close = Closes[0].GetValueAt(CurrentBars[0]);
//				Print(StructureBiasMgr.AllPivots.Last().Key+"  "+ StructureBiasMgr.AllPivots.Last().Value);
				Levels.Clear();
				//Levels["LSL"]=new LevelData(double.MinValue,0);
line=2803;//Print(line);
				Levels["LT1"]=new LevelData(double.MinValue,0);
				Levels["LT2"]=new LevelData(double.MinValue,0);
				Levels["LT3"]=new LevelData(double.MinValue,0);
				//Levels["SSL"]=new LevelData(double.MinValue,0);
				Levels["ST1"]=new LevelData(double.MinValue,0);
				Levels["ST2"]=new LevelData(double.MinValue,0);
				Levels["ST3"]=new LevelData(double.MinValue,0);

line=2812;//Print(line);
				var allkeys = StructureBiasMgr.AllPivots.Keys.ToList();
				if(allkeys.Count>1) {
					allkeys.Sort();
					if(allkeys[0] < allkeys.Last()) allkeys.Reverse();
//if(allkeys!=null){
//line=2705;
//for(int r=0; r<Math.Min(allkeys.Count,20); r++) {
//	Print("All keys: "+allkeys[r]+"   Price: "+StructureBiasMgr.AllPivots[allkeys[r]]);
//line=2709;
//	try{
//		Draw.Diamond(this,"ak"+r.ToString(),false,Times[0].GetValueAt(allkeys[r]),Math.Abs(StructureBiasMgr.AllPivots[allkeys[r]]), Brushes.Yellow);
//	}catch{}
//line=2713;
//}
//}
				}
//				StructureBiasMgr.AllPivots[0].
line=2830;//Print(line);
				double nodeprice   = 0;
				var pivs           = new SortedDictionary<int,double>();
				var MinDistancePts = pMinTicksFromMarket * TickSize;
				bool c1 = false;
//Print("LongTargetsOptions:  "+pLongTargetsOptions.ToString());
				foreach(var kvp in StructureBiasMgr.AllPivots) {
					c1 = this.pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Both;
					if(     kvp.Value>0 && this.pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Highs) c1 = true;
					else if(kvp.Value<0 && this.pLongTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Lows)  c1 = true;
					if(c1 && Math.Abs(kvp.Value) > close + MinDistancePts){ 
line=2841;//Print(line);
//if(iz) Print(kvp.Key+"   "+kvp.Value+"   "+Times[0].GetValueAt(kvp.Key));
						pivs[kvp.Key] = Math.Abs(kvp.Value);//select all nodes above current price, Long targets
//if(iz) try{Draw.Dot(this,kvp.Key.ToString(),false, CurrentBars[0]-kvp.Key-1, pivs[kvp.Key], Brushes.Red);}catch{}

					}
				}
line=2846;//Print(line);
				var keys = RemoveLevelsThatAreTooCloseToAnother('L', pivs, pMinTicksBetweenTgts);
line=2848;//Print(line);
				if(keys!=null && keys.Count>0){
					var lvls = pivs.Where(k=> keys.Contains(k.Key)).Select(k=>k.Value).ToList();
					if(lvls!=null){
						lvls.Sort();
						if(lvls[0]>lvls.Last()) lvls.Reverse();
						while(lvls.Count>0){
							nodeprice = lvls[0];
//Draw.Dot(this,"node+"+nodeprice.ToString()
							var k = pivs.Where(v=> v.Value == nodeprice).Select(ki=>ki.Key).Max();
							if(Levels["LT1"].Price == double.MinValue){
								Levels["LT1"] = new LevelData(nodeprice, k);
								Values[0][0]  = Levels["LT1"].Price;
//Print("LT1: "+nodeprice+"  abar: "+k);
//if(isLive) Draw.Dot(this,"aLT1", false, Times[0].GetValueAt(k), Levels["LT1"].Price,Brushes.Green);
							}else if(Levels["LT2"].Price == double.MinValue && nodeprice > Levels["LT1"].Price && Levels["LT1"].Price != double.MinValue){
								Levels["LT2"] = new LevelData(nodeprice, k);
								Values[1][0]  = Levels["LT2"].Price;
//Print("LT2: "+nodeprice+"  abar: "+k);
//if(isLive) Draw.Dot(this,"aLT2", false, Times[0].GetValueAt(k), Levels["LT2"].Price,Brushes.Green);
							}else if(Levels["LT3"].Price == double.MinValue && nodeprice > Levels["LT2"].Price && Levels["LT2"].Price != double.MinValue){
								Levels["LT3"] = new LevelData(nodeprice, k);
								Values[2][0]  = Levels["LT3"].Price;
//Print("LT3: "+nodeprice+"  abar: "+k);
//if(isLive) Draw.Dot(this,"aLT3", false, Times[0].GetValueAt(k), Levels["LT3"].Price,Brushes.Green);
							}
							lvls.RemoveAt(0);
						}
					}
				}
line=2878;//Print(line);
				pivs.Clear();
				foreach(var kvp in StructureBiasMgr.AllPivots) {
					c1 = this.pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Both;
					if(     kvp.Value>0 && this.pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Highs) c1 = true;
					else if(kvp.Value<0 && this.pShortTargetsOptions == ARC_TargetFinder_SwingTargetOptions.Lows)  c1 = true;
					if(c1 && Math.Abs(kvp.Value) < close - MinDistancePts)
						pivs[kvp.Key] = Math.Abs(kvp.Value);//select all swings below current price, Short targets
				}
//var kk = pivs.Keys.ToList();
//kk.Reverse();
//for(int w=0; w<Math.Min(kk.Count,10); w++) Print(w+":  "+Times[0].GetValueAt(kk[w]).ToString()+"  price: "+pivs[kk[w]]);
				keys = RemoveLevelsThatAreTooCloseToAnother('S', pivs, pMinTicksBetweenTgts);
//for(int w=0; w<Math.Min(keys.Count,10); w++) Print(w+":  "+Times[0].GetValueAt(keys[w]).ToString()+"  price: "+pivs[keys[w]]);
line=2893;//Print(line);
				if(keys!=null && keys.Count>0){
					var lvls = pivs.Where(k=> keys.Contains(k.Key)).Select(k=>k.Value).ToList();
					if(lvls!=null){
						lvls.Sort();
						if(lvls[0]<lvls.Last()) lvls.Reverse();
						while(lvls.Count>0){
line=2900;//Print(line);
							nodeprice = lvls[0];
							var k = pivs.Where(v=> v.Value == nodeprice).Select(ki=>ki.Key).Max();

							if(Levels["ST1"].Price == double.MinValue){
								Levels["ST1"] = new LevelData(nodeprice, k);
								Values[3][0]  = Levels["ST1"].Price;
//Print("ST1: "+nodeprice+"  abar: "+keys[0]);
//if(isLive) Draw.Dot(this,"aST1",false,Times[0].GetValueAt(keys[0]),Levels["ST1"].Price,Brushes.Lime);
						//}else if(Levels["ST2"].Price==double.MinValue && nodeprice < Levels["ST1"].Price && Levels["ST1"].Price != double.MinValue){
							}else if(Levels["ST2"].Price == double.MinValue && nodeprice < Levels["ST1"].Price && Levels["ST1"].Price != double.MinValue){
								Levels["ST2"] = new LevelData(nodeprice, k);
								Values[4][0]  = Levels["ST2"].Price;
//Print("ST2: "+nodeprice+"  abar: "+keys[0]);
//if(isLive) Draw.Dot(this,"aST2",false,Times[0].GetValueAt(keys[0]),Levels["ST2"].Price,Brushes.Lime);
							}else if(Levels["ST3"].Price == double.MinValue && nodeprice < Levels["ST2"].Price && Levels["ST2"].Price != double.MinValue){
								Levels["ST3"] = new LevelData(nodeprice, k);
								Values[5][0]  = Levels["ST3"].Price;
//Print("ST3: "+nodeprice+"  abar: "+keys[0]);
//if(isLive) Draw.Dot(this,"aST3",false,Times[0].GetValueAt(keys[0]),Levels["ST3"].Price,Brushes.Lime);
							}
							lvls.RemoveAt(0);
						}
					}
				}
			}
line=2926;//Print(line);
//if(isLive) {
//	if(Levels["LT1"].Price == double.MinValue) RemoveDrawObject("aLT1");
//	if(Levels["LT2"].Price == double.MinValue) RemoveDrawObject("aLT2");
//	if(Levels["LT3"].Price == double.MinValue) RemoveDrawObject("aLT3");
//	if(Levels["ST1"].Price == double.MinValue) RemoveDrawObject("aST1");
//	if(Levels["ST2"].Price == double.MinValue) RemoveDrawObject("aST2");
//	if(Levels["ST3"].Price == double.MinValue) RemoveDrawObject("aST3");
//}
			#endregion
		}
//==========================================================================================================================
		private List<int> RemoveLevelsThatAreTooCloseToAnother(char Dir, SortedDictionary<int,double> pivs, int MinTicksBetweenLevels){
			//RemoveAllVerticalLines();
			if(pivs.Count<2) 
				return pivs.Keys.ToList();
			var keys = pivs.Keys.Where(k=> k>=CurrentBars[0]-pBarsLookback).ToList();
			if(keys==null || keys.Count<=1) return keys;
			keys.Sort();
			if(keys[0] < keys.Last()) keys.Reverse();//highest abs bar number is now at the zero element
//			keys = keys.GetRange(0,Math.Min(keys.Count-1,20));


			double MinDistancePts = MinTicksBetweenLevels * TickSize;
			double p1   = 0;
			var DeleteTheseLevels = new List<int>();
			for(int i = 0; i<keys.Count; i++){
				if(DeleteTheseLevels.Contains(keys[i])) {
					continue;
				}
				p1 = pivs[keys[i]];
				double zone_max = p1 + MinDistancePts;
				double zone_min = p1 - MinDistancePts;
				var k2 = pivs.Where(k => k.Key < keys[i] && k.Value < zone_max && k.Value > zone_min).Select(w=> w.Key);
				foreach(var d in k2) {
					if(d!=keys[i]) DeleteTheseLevels.Add(d);
/*
				if(Dir == 'L'){
//if(iz){
//	Print("Examining "+Times[0].GetValueAt(keys[i]).ToString()+"   "+p1);
//	Draw.Dot(this,"e"+i.ToString(),false,i,p1,Brushes.Pink);
//}
					var k2 = pivs.Where(k => k.Key < keys[i] && k.Value < zone_max && k.Value > zone_min).Select(w=> w.Key);
					foreach(var d in k2) {
						if(d!=keys[i]) DeleteTheseLevels.Add(d);
//if(pShowSkippedLevels) 
//	Draw.VerticalLine(this, "V+"+d.ToString(), Times[0].GetValueAt(d), Brushes.Red);
					}
				}else if(Dir == 'S'){
					var k2 = pivs.Where(k => k.Key < keys[i] && k.Value < zone_max && k.Value > zone_min).Select(w=> w.Key);
					foreach(var d in k2) {
						if(d!=keys[i]) DeleteTheseLevels.Add(d);
//if(pShowSkippedLevels) 
//	Draw.VerticalLine(this, "V+"+d.ToString(), Times[0].GetValueAt(d), Brushes.Blue);
					}
*/
				}
			}
			if(DeleteTheseLevels.Count>0)
				return keys.Except(DeleteTheseLevels).ToList();
			else
				return keys;
		}
//==========================================================================================================================
		private void RemoveAllVerticalLines(){
			var objects = DrawObjects.ToList();
			foreach (dynamic dob in objects) {
				if (dob.ToString().EndsWith(".VerticalLine") && dob.Tag.Contains("V+")) {
					RemoveDrawObject(dob.Tag);
				}
			}
		}
//==========================================================================================================================
		public override void OnRenderTargetChanged()
		{
			if(lineBrushUp!=null   && !lineBrushUp.IsDisposed)   lineBrushUp.Dispose();   lineBrushUp=null;
			if(lineBrushDown!=null && !lineBrushDown.IsDisposed) lineBrushDown.Dispose(); lineBrushDown=null;
			if(tempBrushDX!=null   && !tempBrushDX.IsDisposed)   tempBrushDX.Dispose();   tempBrushDX=null;
			if(RenderTarget!=null){
				lineBrushUp   = this.UpLineColor.ToDxBrush(RenderTarget);
				lineBrushDown = this.DownLineColor.ToDxBrush(RenderTarget);
				tempBrushDX   = Brushes.Lime.ToDxBrush(RenderTarget);
			}
		}
//==========================================================================================================================
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
            #region -- conditions to return --
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (Bars == null || ChartControl == null) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
			if (IsInHitTest) return;
            #endregion
			int rmab = BarsArray[0].GetBar(Times[0].GetValueAt(Math.Min(BarsArray[0].Count-1,ChartBars.ToIndex)));
			if(Calculate == Calculate.OnBarClose) rmab = rmab-1;

			//if(pShowHistoryLines) base.OnRender(chartControl, chartScale);

			#region -- draw structure --            
			if (ShowStructureLines)
			{
			    RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

				if (rmab >= 2)
				{
//				    double ThisSize = 0;

					var StructureLabelBrush = 'U';//lineBrushUp;

					var keys = new System.Collections.Generic.List<int>(StructureBiasMgr.AllPivots.Keys);
				    int j = keys.Count-1;
					double swingprice2 = Closes[0].GetValueAt(1);
					double swingprice1 = Closes[0].GetValueAt(1);
					float vTextOffset = 0;
					int swingABar1 = 1;
				    while (j > 0) { 
						j = j - 1;
						if(keys[j] < ChartBars.FromIndex) {
							swingABar1 = keys[j];
							swingprice1 = Math.Abs(StructureBiasMgr.AllPivots[swingABar1]);
							break;
						}
					}//j is now the first swing point prior to the first bar on the chart

                    try
                    {
						var lineBrush = 'U';//lineBrushUp;
						string zzId0 = "";
                        for (int i = j; keys[i] <= rmab; i++)
                        {
							bool IsLowSwing = false;
							int swingabar = keys[i];
							double swingprice = StructureBiasMgr.AllPivots[swingabar];
							if(swingprice < 0) {
								swingprice = Math.Abs(swingprice);
								lineBrush = 'D';// lineBrushDown;
								if(swingprice<swingprice2) zzId0 = "LL";
								else if(swingprice>swingprice2) zzId0 = "HL";
								else zzId0 = "DB";
								IsLowSwing = true;
							}else{
								lineBrush = 'U';// lineBrushUp;
								if(swingprice<swingprice2) zzId0 = "LH";
								else if(swingprice>swingprice2) zzId0 = "HH";
								else zzId0 = "DT";
							}

							int x1 = ChartControl.GetXByBarIndex(ChartBars, swingabar);
							int x2 = ChartControl.GetXByBarIndex(ChartBars, swingABar1);

							int y1 = chartScale.GetYByValue(swingprice);
							int y2 = chartScale.GetYByValue(swingprice1);

							drawLine(x1, x2, y1, y2, lineBrush=='U' ? lineBrushUp : lineBrushDown ,DashStyleHelper.Solid, LineThickness);
							if (ShowStructureLabels)
							{
try{
							    float[] SZ  = getTextHeightAndWidth(zzId0, ZZlabelFont);
							    if (!IsLowSwing){
									StructureLabelBrush = 'U';//lineBrushUp;
									vTextOffset = -SZ[0] -3f;
								} else if (IsLowSwing) {
									StructureLabelBrush = 'D';//lineBrushDown;
									vTextOffset = 3f;
								}
//Print("SZ[0]: "+SZ[0]+"  SZ[1]: "+SZ[1]);
							    drawString(zzId0, x1 - SZ[1] / 2, y1 + vTextOffset, ZZlabelFont, StructureLabelBrush=='U' ? lineBrushUp : lineBrushDown, SharpDX.DirectWrite.TextAlignment.Center);                                            
}catch(Exception onr){Print("OnRender: "+onr.ToString());}
							}
							swingprice2 = swingprice1;
							swingprice1 = swingprice;
							swingABar1  = swingabar;

						}
			        }
			        catch{ }
				}
				RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
			}
            #endregion
			
			var tag        = "";
			var label_text = "";
			int plot_id    = 0;
			int RMaB       = CurrentBars[0];//Math.Min(CurrentBars[0], ChartBars.ToIndex);
			float width  = this.pLongsLineLength;
			float xL     = ChartControl.GetXByBarIndex(ChartBars, CurrentBars[0]-pRayShift);
			float xR     = xL + width;
			float y      = 0;
			double price = 0;

//			y = chartScale.GetYByValue(Closes[0].GetValueAt(CurrentBars[0]) + pMinTicksFromMarket*TickSize) ;
//			float height = Math.Abs(y - (chartScale.GetYByValue(Closes[0].GetValueAt(CurrentBars[0]) - pMinTicksFromMarket*TickSize)));
//			RenderTarget.FillRectangle(new SharpDX.RectangleF(x,y,100,height), tempBrushDX);
			
			if(pShowLongs){
//Print("x: "+x+"   y: "+y+"  pShowSL: "+pShowSL.ToString()+"  LSL: "+Levels["LSL"].Price+"  is null: "+(Plots[0].BrushDX==null).ToString());
//				if(!IsGlobalized["L"] && pShowSL && width>0) {
//					tag = "LSL";
//					plot_id = 0;
//					price = Values[plot_id].GetValueAt(RMaB);//Levels[tag].Price
//					y = chartScale.GetYByValue(price);
//					RenderTarget.DrawLine(new SharpDX.Vector2(x, y), new SharpDX.Vector2(x+width, y), Plots[plot_id].BrushDX);
//					label_text = string.Format("{0} {1}", tag, Instrument.MasterInstrument.FormatPrice(price));
//					var brushDX = LabelBkgBrushes[plot_id].ToDxBrush(RenderTarget);
//					brushDX.Opacity = pBkgOpacity/100f;
//					drawString(label_text, x+width, y, pLabelFont, Plots[plot_id].BrushDX, brushDX, SharpDX.DirectWrite.TextAlignment.Leading);
//					brushDX.Dispose();brushDX=null;
//				}
				bool global = false;
				if(IsGlobalized.ContainsKey("L")) global = IsGlobalized["L"];
				if(!global && pShowT1 && width>0) {
					tag = "LT1";
					plot_id = 0;
//					price = Values[plot_id].GetValueAt(RMaB);
					if(Levels.ContainsKey(tag)){
						price = Levels[tag].Price;
						y = chartScale.GetYByValue(price);
						if(pExtendTgtLines) {
							xL = ChartControl.GetXByBarIndex(ChartBars, Levels[tag].ABar);
							RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(xL,y), 4,4), Plots[plot_id].BrushDX);
						}
						RenderTarget.DrawLine(new SharpDX.Vector2(xL, y), new SharpDX.Vector2(xR, y), Plots[plot_id].BrushDX);
						label_text  = string.Format("{0} {1}", tag, Instrument.MasterInstrument.FormatPrice(price));
						var brushDX = LabelBkgBrushes[plot_id].ToDxBrush(RenderTarget);
						brushDX.Opacity = pBkgOpacity/100f;
						drawString(label_text, xR, y, pLabelFont, Plots[plot_id].BrushDX, brushDX, SharpDX.DirectWrite.TextAlignment.Leading);
						brushDX.Dispose();brushDX=null;
					}
				}
				if(!global && pShowT2 && width>0) {
					tag = "LT2";
					plot_id = 1;
//					price = Values[plot_id].GetValueAt(RMaB);//Levels[tag].Price
					if(Levels.ContainsKey(tag)){
						price = Levels[tag].Price;
						y = chartScale.GetYByValue(price);
						if(pExtendTgtLines) {
							xL = ChartControl.GetXByBarIndex(ChartBars, Levels[tag].ABar);
							RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(xL,y), 4,4), Plots[plot_id].BrushDX);
						}
						RenderTarget.DrawLine(new SharpDX.Vector2(xL, y), new SharpDX.Vector2(xR, y), Plots[plot_id].BrushDX);
						label_text  = string.Format("{0} {1}", tag, Instrument.MasterInstrument.FormatPrice(price));
						var brushDX = LabelBkgBrushes[plot_id].ToDxBrush(RenderTarget);
						brushDX.Opacity = pBkgOpacity/100f;
						drawString(label_text, xR, y, pLabelFont, Plots[plot_id].BrushDX, brushDX, SharpDX.DirectWrite.TextAlignment.Leading);
						brushDX.Dispose();brushDX=null;
					}
				}
				if(!global && pShowT3 && width>0) {
					tag = "LT3";
					plot_id = 2;
//					price = Values[plot_id].GetValueAt(RMaB);//Levels[tag].Price
					if(Levels.ContainsKey(tag)){
						price = Levels[tag].Price;
						y = chartScale.GetYByValue(price);
						if(pExtendTgtLines) {
							xL = ChartControl.GetXByBarIndex(ChartBars, Levels[tag].ABar);
							RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(xL,y), 4,4), Plots[plot_id].BrushDX);
						}
						RenderTarget.DrawLine(new SharpDX.Vector2(xL, y), new SharpDX.Vector2(xR, y), Plots[plot_id].BrushDX);
						label_text  = string.Format("{0} {1}", tag, Instrument.MasterInstrument.FormatPrice(price));
						var brushDX = LabelBkgBrushes[plot_id].ToDxBrush(RenderTarget);
						brushDX.Opacity = pBkgOpacity/100f;
						drawString(label_text, xR, y, pLabelFont, Plots[plot_id].BrushDX, brushDX, SharpDX.DirectWrite.TextAlignment.Leading);
						brushDX.Dispose();brushDX=null;
					}
				}
			}
			if(pShowShorts){
				bool global = false;
				if(IsGlobalized.ContainsKey("S")) global = IsGlobalized["S"];
				width = this.pShortsLineLength;
				xL = ChartControl.GetXByBarIndex(ChartBars, CurrentBars[0]-pRayShift);
				xR = xL + width;
//				if(!IsGlobalized["S"] && pShowSL && width>0) {
//					tag = "SSL";
//					plot_id = 3;
//					price = Values[plot_id].GetValueAt(RMaB);//Levels[tag].Price
//					y = chartScale.GetYByValue(price);
//					RenderTarget.DrawLine(new SharpDX.Vector2(x, y), new SharpDX.Vector2(x+width, y), Plots[plot_id].BrushDX);
//					label_text = string.Format("{0} {1}", tag, Instrument.MasterInstrument.FormatPrice(price));
//					var brushDX = LabelBkgBrushes[plot_id].ToDxBrush(RenderTarget);
//					brushDX.Opacity = pBkgOpacity/100f;
//					drawString(label_text, x+width, y, pLabelFont, Plots[plot_id].BrushDX, brushDX, SharpDX.DirectWrite.TextAlignment.Leading);
//					brushDX.Dispose();brushDX=null;
//				}
				if(!global && pShowT1 && width>0) {
					tag = "ST1";
					plot_id = 3;
//					price = Values[plot_id].GetValueAt(RMaB);//Levels[tag].Price
					if(Levels.ContainsKey(tag)){
						price = Levels[tag].Price;
						y = chartScale.GetYByValue(price);
						if(pExtendTgtLines) {
							xL = ChartControl.GetXByBarIndex(ChartBars, Levels[tag].ABar);
							RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(xL,y), 4,4), Plots[plot_id].BrushDX);
						}
						RenderTarget.DrawLine(new SharpDX.Vector2(xL, y), new SharpDX.Vector2(xR, y), Plots[plot_id].BrushDX);
						label_text  = string.Format("{0} {1}", tag, Instrument.MasterInstrument.FormatPrice(price));
						var brushDX = LabelBkgBrushes[plot_id].ToDxBrush(RenderTarget);
						brushDX.Opacity = pBkgOpacity/100f;
						drawString(label_text, xR, y, pLabelFont, Plots[plot_id].BrushDX, brushDX, SharpDX.DirectWrite.TextAlignment.Leading);
						brushDX.Dispose();brushDX=null;
					}
				}
				if(!global && pShowT2 && width>0) {
					tag = "ST2";
					plot_id = 4;
//					price = Values[plot_id].GetValueAt(RMaB);//Levels[tag].Price
					if(Levels.ContainsKey(tag)){
						price = Levels[tag].Price;
						y = chartScale.GetYByValue(price);
						if(pExtendTgtLines) {
							xL = ChartControl.GetXByBarIndex(ChartBars, Levels[tag].ABar);
							RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(xL,y), 4,4), Plots[plot_id].BrushDX);
						}
						RenderTarget.DrawLine(new SharpDX.Vector2(xL, y), new SharpDX.Vector2(xR, y), Plots[plot_id].BrushDX);
						label_text  = string.Format("{0} {1}", tag, Instrument.MasterInstrument.FormatPrice(price));
						var brushDX = LabelBkgBrushes[plot_id].ToDxBrush(RenderTarget);
						brushDX.Opacity = pBkgOpacity/100f;
						drawString(label_text, xR, y, pLabelFont, Plots[plot_id].BrushDX, brushDX, SharpDX.DirectWrite.TextAlignment.Leading);
						brushDX.Dispose();brushDX=null;
					}
				}
				if(!global && pShowT3 && width>0) {
					tag = "ST3";
					plot_id = 5;
//					price = Values[plot_id].GetValueAt(RMaB);//Levels[tag].Price
					if(Levels.ContainsKey(tag)){
						price = Levels[tag].Price;
						y = chartScale.GetYByValue(price);
						if(pExtendTgtLines) {
							xL = ChartControl.GetXByBarIndex(ChartBars, Levels[tag].ABar);
							RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(xL,y), 4,4), Plots[plot_id].BrushDX);
						}
						RenderTarget.DrawLine(new SharpDX.Vector2(xL, y), new SharpDX.Vector2(xR, y), Plots[plot_id].BrushDX);
						label_text = string.Format("{0} {1}", tag, Instrument.MasterInstrument.FormatPrice(price));
						var brushDX = LabelBkgBrushes[plot_id].ToDxBrush(RenderTarget);
						brushDX.Opacity = pBkgOpacity/100f;
						drawString(label_text, xR, y, pLabelFont, Plots[plot_id].BrushDX, brushDX, SharpDX.DirectWrite.TextAlignment.Leading);
						brushDX.Dispose();brushDX=null;
					}
				}
			}
//				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "Long SL");
//				AddPlot(new Stroke(Brushes.Lime), PlotStyle.Line, "Long T1");
//				AddPlot(new Stroke(Brushes.Lime), PlotStyle.Line, "Long T2");
//				AddPlot(new Stroke(Brushes.Lime), PlotStyle.Line, "Long T3");
//				AddPlot(new Stroke(Brushes.Red), PlotStyle.Line, "Short SL");
//				AddPlot(new Stroke(Brushes.Green), PlotStyle.Line, "Short T1");
//				AddPlot(new Stroke(Brushes.Green), PlotStyle.Line, "Short T2");
//				AddPlot(new Stroke(Brushes.Green), PlotStyle.Line, "Short T3");
		}
//==========================================================================================================================
		private void DrawAllSelectedRays(){
			#region -- DrawAllSelectedRays --
			bool global = false;
			if(IsGlobalized.ContainsKey("L")) global = IsGlobalized["L"];
			var tag = "LSL";
//			RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
//			RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
//			if(pShowLongs && pShowSL && IsGlobalized["L"] && Levels[tag].Price !=double.MinValue){
//				ImmediatelyDraw_Ray(tag);
//			}
			tag = "LT1";
//			RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
			RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
			if(pShowLongs && pShowT1 && global && Levels[tag].Price !=double.MinValue){
				ImmediatelyDraw_Ray(tag);
			}
			tag = "LT2";
//			RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
			RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
			if(pShowLongs && pShowT2 && global && Levels[tag].Price !=double.MinValue){
				ImmediatelyDraw_Ray(tag);
			}
			tag = "LT3";
//			RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
			RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
			if(pShowLongs && pShowT3 && global && Levels[tag].Price !=double.MinValue){
				ImmediatelyDraw_Ray(tag);
			}

			global = false;
			if(IsGlobalized.ContainsKey("S")) global = IsGlobalized["S"];
			tag = "SSL";
//			RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
			RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
//			if(pShowShorts && pShowSL && IsGlobalized["S"] && Levels[tag].Price !=double.MinValue){
//				ImmediatelyDraw_Ray(tag);
//			}
			tag = "ST1";
//			RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
			RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
			if(pShowShorts && pShowT1 && global && Levels[tag].Price !=double.MinValue){
				ImmediatelyDraw_Ray(tag);
			}
			tag = "ST2";
//			RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
			RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
			if(pShowShorts && pShowT2 && global && Levels[tag].Price !=double.MinValue){
				ImmediatelyDraw_Ray(tag);
			}
			tag = "ST3";
//			RemoveDrawObject(string.Format("{0} {1}", tag, ObjTagPrefix));
			RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
			if(pShowShorts && pShowT2 && global && Levels[tag].Price !=double.MinValue){
				ImmediatelyDraw_Ray(tag);
			}
			#endregion
		}
//==========================================================================================================================
		private void ImmediatelyDraw_Ray(string tag){
			#region -- Draw Rays ------------------------------
			if(tag!=null && tag.Length>0){
				var template_name = string.Empty;// (tag[0]=='L' ? this.pLongSL_DTTemplate : this.pShortSL_DTTemplate);
				if(tag.Contains("T"))
					template_name = (tag[0]=='L' ? this.pLongT_DTTemplate : this.pShortT_DTTemplate);
				var type = tag[0].ToString();
				if(IsGlobalized[type]) TriggerCustomEvent(o2 =>{Draw.Ray(this, Add_uID(tag), 1+pRayShift, Levels[tag].Price, pRayShift, Levels[tag].Price, IsGlobalized[type], template_name);},0,null);
			}
			#endregion ----------------------------
		}
//=============================================================================================================
//		private void ImmediatelyDraw_Ray(string tag, SortedDictionary<string, Global_RaysData> dict){
//			#region -- Draw Global Rays ------------------------------
//			if(tag!=null && tag.Length>0){
//				TriggerCustomEvent(o1 =>{Draw.Ray(this, string.Format("{0} {1}",tag,ObjTagPrefix), dict[tag].DT, dict[tag].Price, Times[0].GetValueAt(CurrentBars[0]), dict[tag].Price, IsGlobalized[tag[0].ToString()], dict[tag].TemplateName);},0,null);
//			}
//			#endregion ----------------------------
//		}
//=============================================================================================================
//		private void ImmediatelyDraw_Rays(SortedDictionary<string, Global_RaysData> dict){
//			#region -- Draw Global Rays ------------------------------
//			foreach(var tag in dict.Keys){
//				if(tag!=null && tag.Length>0){
//					TriggerCustomEvent(o1 =>{Draw.Ray(this, string.Format("{0} {1}",tag,ObjTagPrefix), dict[tag].DT, dict[tag].Price, Times[0].GetValueAt(CurrentBars[0]), dict[tag].Price, IsGlobalized[tag[0].ToString()], dict[tag].TemplateName);},0,null);
//				}
//			}
//			#endregion ----------------------------
//		}
//==========================================================================================================================

		#region ContrastingColor
        public Brush ContrastingColor(SolidColorBrush brush)
        {
            // Counting the perceptive luminance - human eye favors green color... 
            double a = 1 - (0.299 * brush.Color.R + 0.587 * brush.Color.G + 0.114 * brush.Color.B) / 255;
            if (a < 0.5) return Brushes.Black; // bright colors - black 
            else return Brushes.LightYellow; // dark colors - white 
        }
        public SolidColorBrush ContrastingColor(Brush brush)
        {
			var color = ((SolidColorBrush)brush).Color;
            // Counting the perceptive luminance - human eye favors green color... 
            double a = 1 - (0.299 * color.R + 0.587 * color.G + 0.114 * color.B) / 255;
            if (a < 0.5) return Brushes.Black; // bright colors - black 
            else return Brushes.LightYellow; // dark colors - white 
        }
		#endregion

		#region supporting code
        private float[] getTextHeightAndWidth(string text, SimpleFont font){
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			float[] result = new float[2]{(float)font.Size, textLayout.Metrics.Width};

            textLayout.Dispose();
            textFormat.Dispose();

            return result;
		}
        private float getTextWidth(string text, SimpleFont font)
        {
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }
        private float getTextHeight(string text, SimpleFont font)
        {
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textheight = textLayout.Metrics.Height;

            textLayout.Dispose();
            textFormat.Dispose();

            return textheight;
        }
        private void drawString(string text, float x, float y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush,  SharpDX.Direct2D1.Brush bkgBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxX = -9999f)
        {
			#region drawString
			if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
			//SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();

			var textFormat = new SharpDX.DirectWrite.TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
			)
				{ TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, ChartPanel.W/3, ChartPanel.H);
			if(x<0) x = Math.Abs(x) - textLayout.Metrics.Width - 5;

			if(MaxX>0)
				x = Math.Min(x, MaxX - 3f - textLayout.Metrics.Width);

			y = y - textLayout.Metrics.Height/2.0f;
			if (bkgBrush!=null && bkgBrush.Opacity>0) {
				double xl = x - 3;
				double xr = x + textLayout.Metrics.Width + 3;
				double yt = y - 1;
				double yb = y+textLayout.Metrics.Height + 2;
				if(textAlignment==SharpDX.DirectWrite.TextAlignment.Trailing){
					xr = x + textLayout.Metrics.LayoutWidth +3;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				else if(textAlignment==SharpDX.DirectWrite.TextAlignment.Center){
					xr = x + textLayout.Metrics.LayoutWidth/2 + 3 + textLayout.Metrics.Width/2;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				var bkgBox = new System.Windows.Point[]
				{	new System.Windows.Point(xl, yt),
					new System.Windows.Point(xl, yb),
					new System.Windows.Point(xr, yb),
					new System.Windows.Point(xr, yt),
				};
				drawRegion(bkgBox, bkgBrush);
			}
//Print("Drawing text '"+text+"' at "+x+" "+y);
			RenderTarget.DrawTextLayout(new SharpDX.Vector2(x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			textLayout.Dispose();
			textFormat.Dispose();
			#endregion
		}
        //Draw a text at {x;y} coordinates in pixel.
        private void drawString(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                ) { TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

            RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
        }

        private void drawLine(float x1, float x2, float y1, float y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle = DashStyleHelper.Solid, int width = 1, int opacity = 100)
        {
            dxbrush.Opacity = opacity / 100f;
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            RenderTarget.DrawLine(new SharpDX.Vector2(x1,y1), new SharpDX.Vector2(x2,y2), dxbrush, width, strokestyle);

            strokestyle.Dispose();
        }
        private void drawRegion(System.Windows.Point[] points, SharpDX.Direct2D1.Brush dxbrush)
        {
            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();
        }

//        //set the color to Black or White depending on background color
//        public Brush ContrastingColor(SolidColorBrush background)
//        {
//            // Counting the perceptive luminance - human eye favors green color... 
//            double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
//            if (a < 0.5) return Brushes.Black; // bright colors - black font
//            else return Brushes.White; // dark colors - white font
//        }

        //Draw a line between 2 points. 'x1' and 'x2' are pixel locations, the y value is the numerical value (ie price / oscillator value)
		private void drawLine(double val1, double val2, float x1, float x2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = true)
		{
			if(double.IsNaN(val1) || double.IsNaN(val2)) {Print("Val is NaN"); return;}
			//SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.DashStyle _dashstyle;
			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

			SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
			SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

			SharpDX.Vector2 v1 = new SharpDX.Vector2(x1, drawOnPricePanel ? chartScale.GetYByValue(val1) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val1));
			SharpDX.Vector2 v2 = new SharpDX.Vector2(x2, drawOnPricePanel ? chartScale.GetYByValue(val2) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val2));
//Print("\nv1: "+v1.X+", "+v1.Y+"   "+val1);
//Print("v2: "+v2.X+", "+v2.Y+"   "+val2);
			RenderTarget.DrawLine(v1, v2, dxbrush, width, strokestyle);

			strokestyle.Dispose();
		}
		#endregion
		//This function does a bar request to preload historical minute bars. It is an asynchrone function but has been made synchrone.

//==========================================================================================================================
		internal class LoadRayTemplates : StringConverter
		{
			#region LoadRayTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Ray"};
				HLtemplates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(HLtemplates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
//==========================================================================================================================

		#region -- Plots --
//        [Browsable(false)]
//        [XmlIgnore()]
//        public Series<double> Confluence0 { get { return Values[0]; } }
		#endregion

//==========================================================================================================================
		#region -- Parameters --

		#region -- Filters --
		[Description("Swings used for Long targets")]
		[Display(Order = 10, Name = "Long Tgt Basis",  GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public ARC_TargetFinder_SwingTargetOptions pLongTargetsOptions {get;set;}

		[Description("Swings used for Short targets")]
		[Display(Order = 20, Name = "Short Tgt Basis",  GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public ARC_TargetFinder_SwingTargetOptions pShortTargetsOptions {get;set;}

		[Range(0,int.MaxValue)]
		[Description("Number of bars lookback for targets consideration")]
		[Display(Order = 30, Name = "Lookback (bars)",  GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public int pBarsLookback {get;set;}

		[Range(0,int.MaxValue)]
		[Description("Minimum distance from current market price to first target level, in ticks")]
		[Display(Order = 40, Name = "Min Distance from Market (ticks)",  GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public int pMinTicksFromMarket {get;set;}

		[Range(0,int.MaxValue)]
		[Description("Minimum distance from one level to the next target level, in ticks")]
		[Display(Order = 50, Name = "Min Target Separation (ticks)",  GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public int pMinTicksBetweenTgts {get;set;}
		#endregion

		#region -- Visuals --
		[Display(Name = "Show Longs", GroupName = "Visuals", Description = "Show trade plan for long trades", Order = 25)]
		public bool pShowLongs {get; set;}
		[Display(Name = "Show Shorts", GroupName = "Visuals", Description = "Show trade plan for short trades", Order = 30)]
		public bool pShowShorts {get; set;}
		[Display(Name = "Show T1", GroupName = "Visuals", Description = "", Order = 35)]
		public bool pShowT1 {get; set;}
		[Display(Name = "Show T2", GroupName = "Visuals", Description = "", Order = 40)]
		public bool pShowT2 {get; set;}
		[Display(Name = "Show T3", GroupName = "Visuals", Description = "", Order = 50)]
		public bool pShowT3 {get; set;}
		[Display(Name = "Extend Tgt Lines", GroupName = "Visuals", Description = "", Order = 55)]
		public bool pExtendTgtLines {get;set;}

//		[Display(Order = 60, Name = "Ignore swing highs on long targets", GroupName = "Visuals", Description = "Swing highs are not significant for long targets")]
//		public bool pIgnoreHighsOnLongs {get;set;}
//		[Display(Order = 61, Name = "Ignore swing lows on short targets", GroupName = "Visuals", Description = "Swing lows are not significant for short targets")]
//		public bool pIgnoreLowsOnShorts {get;set;}

		[Display(Order = 70, Name = "Shift global rays", GroupName = "Visuals", Description = "")]
		public int pRayShift {get; set;}

		[Display(Order = 90, Name = "Long Target template", GroupName = "Visuals", Description = "Drawing tool template")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pLongT_DTTemplate {get; set;}

//		[Display(Name = "Long SL template", GroupName = "Visuals", Description = "Drawing tool template", Order = 100)]
//		[RefreshProperties(RefreshProperties.All)]
//		[TypeConverter(typeof(LoadRayTemplates))]
//		public string pLongSL_DTTemplate {get; set;}

		[Display(Name = "Short Target template", GroupName = "Visuals", Description = "Drawing tool template", Order = 100)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pShortT_DTTemplate {get; set;}

//		[Display(Name = "Short SL template", GroupName = "Visuals", Description = "Drawing tool template", Order = 120)]
//		[RefreshProperties(RefreshProperties.All)]
//		[TypeConverter(typeof(LoadRayTemplates))]
//		public string pShortSL_DTTemplate {get; set;}

		[Range(0, 10000)]
		[Display(Name = "Longs line length", GroupName = "Visuals", Description = "Line length (in bars)", Order = 130)]
		public int pLongsLineLength {get; set;}
		[Range(0, 10000)]
		[Display(Name = "Shorts line length", GroupName = "Visuals", Description = "Line length (in bars)", Order = 140)]
		public int pShortsLineLength {get; set;}

		[Display(Name = "Label Font", GroupName = "Visuals", Description = "", Order = 150)]
        public SimpleFont pLabelFont { get; set; }
		
		[Range(0,100)]
		[Display(Name = "Label bkg opacity", GroupName = "Visuals", Description = "", Order = 160)]
		public int pBkgOpacity {get;set;}
		
//		[Display(Name = "Show history lines", GroupName = "Visuals", Description = "", Order = 170)]
//		public bool pShowHistoryLines {get;set;}
//==========================================================================================================================
		#endregion

        #region -- SwingTrend Parameters --

        [Display(Name = "Use Highs/Lows", GroupName = "SwingTrend Parameters", Description = "Use High/Lows or Input", Order = 5)]
        public bool isHLBased { get; set; }

        [Range(1, 300)]
        [Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 10)]
        public int SwingStrength { get; set; }

//        [Range(0, double.MaxValue)]
//        [Display(Name = "Deviation multiplier", GroupName = "SwingTrend Parameters", Description = "Multiplier used to calculate minimum as an ATR multiple", Order = 15)]
//        public double MultiplierMD { get; set; }

//        [Range(0, double.MaxValue)]
//        [Display(Name = "Sensitivity double tops/bottoms", GroupName = "SwingTrend Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 20)]
//        public double MultiplierDTB { get; set; }

        [Display(Name = "Show Swing Lines", GroupName = "SwingTrend Parameters", Description = "Show structure trend lines", Order = 53)]
		public bool ShowStructureLines {get;set;}

		[XmlIgnore]
        [Display(Name = "Up-trend line color", GroupName = "SwingTrend Parameters", Description = "Line color for up-trending structure", Order = 55)]
        public Brush UpLineColor { get; set; }
        [Browsable(false)]
        public string UpLineColorSerialize
        {get { return Serialize.BrushToString(UpLineColor); }
                                        set { UpLineColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
        [Display(Name = "Down-trend line color", GroupName = "SwingTrend Parameters", Description = "Line color for down-trending structure", Order = 60)]
        public Brush DownLineColor { get; set; }
        [Browsable(false)]
        public string DownLineColorSerialize
        {get { return Serialize.BrushToString(DownLineColor); }
                                        set { DownLineColor = Serialize.StringToBrush(value); }}
        [Range(1, 10)]
        [Display(Name = "Line Thickness", GroupName = "SwingTrend Parameters", Description = "Thickness of structure lines", Order = 65)]
		public int LineThickness {get;set;}

        [Display(Name = "Show Swing Labels", GroupName = "SwingTrend Parameters", Description = "Show zigzag labels (e.g. 'HH' or 'LH', etc)", Order = 70)]
		public bool ShowStructureLabels{get;set;}
		#endregion

		#region general Parameters
		[Description("Button text - enter how you want the UI button to be labeled")]
		[Display(Order = 10, Name = "Button Txt",  GroupName = " Parameters", ResourceType = typeof(Custom.Resource))]
		public string pButtonText {get;set;}

		#endregion

		#endregion
	}
}
//==========================================================================================================================

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_TargetFinder[] cacheARC_TargetFinder;
		public ARC.ARC_TargetFinder ARC_TargetFinder()
		{
			return ARC_TargetFinder(Input);
		}

		public ARC.ARC_TargetFinder ARC_TargetFinder(ISeries<double> input)
		{
			if (cacheARC_TargetFinder != null)
				for (int idx = 0; idx < cacheARC_TargetFinder.Length; idx++)
					if (cacheARC_TargetFinder[idx] != null &&  cacheARC_TargetFinder[idx].EqualsInput(input))
						return cacheARC_TargetFinder[idx];
			return CacheIndicator<ARC.ARC_TargetFinder>(new ARC.ARC_TargetFinder(), input, ref cacheARC_TargetFinder);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_TargetFinder ARC_TargetFinder()
		{
			return indicator.ARC_TargetFinder(Input);
		}

		public Indicators.ARC.ARC_TargetFinder ARC_TargetFinder(ISeries<double> input )
		{
			return indicator.ARC_TargetFinder(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_TargetFinder ARC_TargetFinder()
		{
			return indicator.ARC_TargetFinder(Input);
		}

		public Indicators.ARC.ARC_TargetFinder ARC_TargetFinder(ISeries<double> input )
		{
			return indicator.ARC_TargetFinder(input);
		}
	}
}

#endregion
