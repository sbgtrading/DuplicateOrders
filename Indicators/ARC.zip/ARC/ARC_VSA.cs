#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Windows.Controls;
using System.Windows.Automation;
#endregion

#region Enums
public enum ARC_VSA_InputType
{
	Real,
	Relative
}

public enum ARC_VSA_PlotStyle
{
	Arrow,
	Triangle,
	Diamond,
	Dot,
	Square
}

public enum ARC_VSA_FeedTimeSeries
{
	Tick,
	Second,
	Minute
}

#endregion


//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	#region -- Category Order --
	[CategoryOrder("Churn Bars", 10)]
	[CategoryOrder("Climactic Bars", 20)]
	[CategoryOrder("Patterns",   30)]
	[CategoryOrder("Pin Bars",   40)]
	[CategoryOrder("Profile",    50)]
	[CategoryOrder("Parameters", 60)]
	[CategoryOrder("Audio",      70)]
	#endregion

    public class ARC_VSA : Indicator
	{
		private const int UP = 0;
		private const int DOWN = -1;
		private const int FLAT = -2;
		private const int NO_PATTERN = 0;
		private const int CLIMACTIC_BAR_SIGNAL = 1;
		private const int CHURN_BAR_SIGNAL = 2;
		private const int PIN_BAR_SIGNAL = 3;
		private const int CLIMACTIC_CHURN_BAR_SIGNAL = 11;
		private const int CLIMACTIC_PINBAR_BAR_SIGNAL = 12;
		private const int P_PROFILE_SIGNAL = 90;
		private const int b_PROFILE_SIGNAL = 91;

		private string VERSION = "v1.1";

		bool IsDebug = false;
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "VSA";

        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "13853", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

        #region Data Series
        private Series<double> RelativeVolume;
		private Series<double> RelativeRange;
		private Series<double> RelativeDensity;
//		private Series<int> PatternType;
		private Dictionary<int, Dictionary<double, long>> ListProfiles;
		private Dictionary<int, BarProfileData> ListProfileData;
		#endregion

		#region Variables
		private int VolumeDataSeries = 0;
		private bool IsForex = false;
		private double gbTickSize = 0;

		#region -- SharpDX brushes --
		SharpDX.Direct2D1.Brush iProfilePOCDXBrush = null;
		SharpDX.Direct2D1.Brush iProfileVAHDXBrush = null;
		SharpDX.Direct2D1.Brush iProfileVALDXBrush = null;
		SharpDX.Direct2D1.Brush iPHistogramBrush = null;
		SharpDX.Direct2D1.Brush iPLabelBrush = null;

		#endregion

		#endregion
		private int SoundAlertBar = 0;
		private bool MasterAudioEnable = true;

		#region -- Toolbar variables --
		private string toolbarname = "NSVSAToolBar", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private Grid indytoolbar;

        private Menu MenuControlContainer;
        private MenuItem MenuControl;

        //private ComboBox comboMTF, comboZFM, comboProfile;
        private MenuItem miGeneral1, miGeneral2, miGeneral3, miGeneral4, miGeneral5, miGeneral6, miGeneral7, miGeneral8;
        private MenuItem miProfile1, miProfile2, miProfile3, miProfile4, miProfile5, miProfile6, miProfile7, miRatio5, miRatio6, miRatio7, miRatio8;
        private MenuItem miTradingPlan1, miTradingPlan2, miTradingPlan3, miTradingPlan4, miTradingPlan5, miAudibleAlerts;

        private Button gCmdup;
        private Button gCmddw;
        private Label gLabel;
        #endregion

        #region -- Toolbar Management Utilities --
        #region private void addToolBar()
        private void addToolBar()
        {
            gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            gLabel = new Label();//#RJBug001

            MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
            MenuControl = new MenuItem {Name="NSVSA"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Orange, Header = pButtonText, Foreground = Brushes.Orange, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
            MenuControlContainer.Items.Add(MenuControl);

            MenuItem item;
            Separator separator;
            #region -- General --
            MenuItem miGeneral = new MenuItem { Header = "General", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miGeneral1 = new MenuItem { Header = "Show Climactic Bars " + (this.ShowClimacticBars ? "ON" : "OFF"), Name = "btGeneral_Climactic", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral1.Click += General_Click;
            miGeneral.Items.Add(miGeneral1);

            miGeneral2 = new MenuItem { Header = "Show Churn Bars " + (this.ShowChurnBars ? "ON" : "OFF"), Name = "btGeneral_Churn", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral2.Click += General_Click;
            miGeneral.Items.Add(miGeneral2);

            //miGeneral3 = new MenuItem { Header = "Show Pin Bars " + (this.ShowPinBars ? "ON" : "OFF"), Name = "btGeneral_Pin", Foreground = Brushes.Black, StaysOpenOnClick = true };
            //miGeneral3.Click += General_Click;
            //miGeneral.Items.Add(miGeneral3);

            miGeneral3 = new MenuItem { Header = "Show 2-bar Churn Pattern " + (this.ShowCCPattern ? "ON" : "OFF"), Name = "btGeneral_CCPattern", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral3.Click += General_Click;
            miGeneral.Items.Add(miGeneral3);

			miGeneral4 = new MenuItem { Header = "Show 2-bar Pin Pattern " + (this.ShowCPPattern ? "ON" : "OFF"), Name = "btGeneral_CPPattern", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miGeneral4.Click += General_Click;
			miGeneral.Items.Add(miGeneral4);
			//------------------

			MenuControl.Items.Add(miGeneral);
			#endregion

			#region -- Profile --
			MenuItem miProfile = new MenuItem { Header = "Profile", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			miProfile1 = new MenuItem { Header = "Display Profile " + (this.iDisplayProfile ? "ON" : "OFF"), Name = "btProfile_DisplayProfile", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProfile1.Click += Profile_Click;
			miProfile.Items.Add(miProfile1);

			miProfile2 = new MenuItem { Header = "Display Profile POC " + (this.iDisplayPOC ? "ON" : "OFF"), Name = "btProfile_DisplayPoc", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProfile2.Click += Profile_Click;
			miProfile.Items.Add(miProfile2);

			miProfile3 = new MenuItem { Header = "Display Profile VA " + (this.iDisplayVA ? "ON" : "OFF"), Name = "btProfile_DisplayVa", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProfile3.Click += Profile_Click;
			miProfile.Items.Add(miProfile3);

			miProfile4 = new MenuItem { Header = "Display Profile P Label " + (this.iDisplay_P_Labels ? "ON" : "OFF"), Name = "btProfile_PDisplay", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProfile4.Click += Profile_Click;
			miProfile.Items.Add(miProfile4);

			miProfile5 = new MenuItem { Header = "Display Profile b Label " + (this.iDisplay_b_Labels ? "ON" : "OFF"), Name = "btProfile_bDisplay", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProfile5.Click += Profile_Click;
			miProfile.Items.Add(miProfile5);

			miProfile6 = new MenuItem { Header = "Display Profile M Label " + (this.iDisplay_M_Labels ? "ON" : "OFF"), Name = "btProfile_MDisplay", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProfile6.Click += Profile_Click;
			miProfile.Items.Add(miProfile6);

			miProfile7 = new MenuItem { Header = "Display Profile D Label " + (this.iDisplay_D_Labels ? "ON" : "OFF"), Name = "btProfile_DDisplay", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProfile7.Click += Profile_Click;
			miProfile.Items.Add(miProfile7);
			//------------------

			MenuControl.Items.Add(miProfile);
			#endregion
			separator = new Separator();
            MenuControl.Items.Add(separator);

			#region -- Audible Alerts --
			MasterAudioEnable = true;
			miAudibleAlerts = new MenuItem { Header = "Audible Alerts ON", Name = "btAudibleAlerts", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			miAudibleAlerts.Click += delegate (object o, RoutedEventArgs e){
				MasterAudioEnable = !MasterAudioEnable;
				miAudibleAlerts.Header = "Audible Alerts "+(MasterAudioEnable ? "ON":"OFF");
			};
			MenuControl.Items.Add(miAudibleAlerts);
			#endregion

            indytoolbar.Children.Add(MenuControlContainer);
        }
        #endregion

        #region -- General_Click --
        private void General_Click(object sender, EventArgs e)
        {
            //Print(sender.ToString());

            MenuItem item = sender as MenuItem;
            if (item != null && item.Name == "btGeneral_Climactic") this.ShowClimacticBars = !ShowClimacticBars;
            else if (item != null && item.Name == "btGeneral_Churn") ShowChurnBars = !ShowChurnBars;
            //else if (item != null && item.Name == "btGeneral_Pin") ShowPinBars = !ShowPinBars;
            else if (item != null && item.Name == "btGeneral_CCPattern") ShowCCPattern = !ShowCCPattern;
			else if (item != null && item.Name == "btGeneral_CPPattern") ShowCPPattern = !ShowCPPattern;

			miGeneral1.Header = "Show Climactic Bars " + (this.ShowClimacticBars ? "ON" : "OFF");
            miGeneral2.Header = "Show Churn Bars " + (this.ShowChurnBars ? "ON" : "OFF");
            //miGeneral3.Header = "Show Pin Bars " + (this.ShowPinBars ? "ON" : "OFF");
            miGeneral3.Header = "Show 2-bar Churn Patterns " + (this.ShowCCPattern ? "ON" : "OFF");
			miGeneral4.Header = "Show 2-bar Pin Patterns " + (this.ShowCPPattern ? "ON" : "OFF");

			TriggerCustomEvent(o => 
			{
				RedrawSignals();
			}, null);
        }
		#endregion

		#region -- Profile_Click --
		private void Profile_Click(object sender, EventArgs e)
		{
			//Print(sender.ToString());

			MenuItem item = sender as MenuItem;
			if (item != null && item.Name == "btProfile_DisplayProfile") this.iDisplayProfile = !iDisplayProfile;
			else if (item != null && item.Name == "btProfile_DisplayPoc") iDisplayPOC = !iDisplayPOC;
			else if (item != null && item.Name == "btProfile_DisplayVa") iDisplayVA = !iDisplayVA;
			else if (item != null && item.Name == "btProfile_PDisplay") iDisplay_P_Labels = !iDisplay_P_Labels;
			else if (item != null && item.Name == "btProfile_bDisplay") iDisplay_b_Labels = !iDisplay_b_Labels;
			else if (item != null && item.Name == "btProfile_MDisplay") iDisplay_M_Labels = !iDisplay_M_Labels;
			else if (item != null && item.Name == "btProfile_DDisplay") iDisplay_D_Labels = !iDisplay_D_Labels;

			miProfile1.Header = "Display Profile " + (this.iDisplayProfile ? "ON" : "OFF");
			miProfile2.Header = "Display Profile POC " + (this.iDisplayPOC ? "ON" : "OFF");
			miProfile3.Header = "Display Profile VA " + (this.iDisplayVA ? "ON" : "OFF");
			miProfile4.Header = "Display Profile P Label " + (this.iDisplay_P_Labels ? "ON" : "OFF");
			miProfile5.Header = "Display Profile b Label " + (this.iDisplay_b_Labels ? "ON" : "OFF");
			miProfile6.Header = "Display Profile M Label " + (this.iDisplay_M_Labels ? "ON" : "OFF");
			miProfile7.Header = "Display Profile D Label " + (this.iDisplay_D_Labels ? "ON" : "OFF");

			TriggerCustomEvent(o =>
			{
				ForceRefresh();
			}, null);
		}
		#endregion

		#region -- ReloadChart_Click --
		private void ReloadChart_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.SendKeys.SendWait("{F5}");
        }

        private void UpdateChart()
        {
            System.Windows.Forms.SendKeys.SendWait("{F5}");
        }

        #endregion

        #region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion


        #endregion
		
		private static BarsPeriodType GetPeriodType(ARC_VSA_FeedTimeSeries feedTimeSeries)
		{
			switch(feedTimeSeries)
			{
				case ARC_VSA_FeedTimeSeries.Tick:
					return BarsPeriodType.Tick;
				case ARC_VSA_FeedTimeSeries.Second:
					return BarsPeriodType.Second;
				case ARC_VSA_FeedTimeSeries.Minute:
				default:
					return BarsPeriodType.Minute;
			}
		}

        public override string DisplayName { get { return "ARC_VSA"; } }
//===========================================================================================================
        protected override void OnStateChange()
		{
			#region OnStateChange
			if (State == State.SetDefaults)
			{
				Description					= @"";
				Name						= "ARC_VSA";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				DrawHorizontalGridLines		= true;
				DrawVerticalGridLines		= true;
				PaintPriceMarkers			= true;
				IsAutoScale = false;
				this.MaximumBarsLookBack	= MaximumBarsLookBack.Infinite;
				ScaleJustification			= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive	= false;
				ShowClimacticBars			= true;
				ShowChurnBars				= true;
				//ShowPinBars				= true;
				ShowCCPattern				= true;
				MinuteBars					= 0;
				VolumeType					= ARC_VSA_InputType.Real;
				RangeType					= ARC_VSA_InputType.Real;
				DensityType					= ARC_VSA_InputType.Real;
				ChurnBarColor				= Brushes.DeepPink;
				ClimacticBarColor			= Brushes.DeepSkyBlue;
				//PinBarColor				= Brushes.Navy;
				ClimacticBarVolumeThreshold	= 120;
				ClimacticBarRangeThreshold	= 120;
				ChurnDensityThreshold		= 140;
				ChurnRangeThreshold			= 80;
				PinBarRatio					= 2;
				CCBarColor					= Brushes.Gold;
				CPBarColor 					= Brushes.Orange;
				ShowPatternArrows 			= true;
				CCPlotStyle     = ARC_VSA_PlotStyle.Arrow;
				CPPlotStyle     = ARC_VSA_PlotStyle.Diamond;
				CCLongColor     = Brushes.Gold;
				CCShortColor    = Brushes.Gold;
				CPLongColor     = Brushes.Orange;
				CPShortColor    = Brushes.Orange;
				ArrowsOffset    = 7;
				pButtonText     = "VSA";
				FeedDataSeries  = ARC_VSA_FeedTimeSeries.Second;

				iMPBarPOCColor  = Brushes.Yellow;
				iMPBarMColor    = Brushes.Crimson;
				iMPBarVAHColor  = Brushes.Aqua;
				iMPBarVALColor  = Brushes.Aqua;
				iTypeLabelColor = Brushes.Black;
				iBarPW = 5;
				iDisplayProfile = true;
				iDisplayPOC     = true;
				iDisplayVA      = true;
				iDisplay_P_Labels    = true;
				iDisplay_b_Labels    = true;
				iDisplay_M_Labels    = false;
				iDisplay_D_Labels    = false;
				iTypeLabelSeparation = 10;
				iVAThreshold    = 67;
				iPeakThreshold  = 50;

				iFontText = new SimpleFont("Arial", 12) { Bold = true };

				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
				AddPlot(new Stroke(Brushes.Blue, 2), PlotStyle.Square, "PatternType");
			}
			else if (State == State.Configure)
			{
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="1E53E271B82EC62C7C03A15C336229AE" || NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A");
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif

				Calculate = Calculate.OnBarClose;
				AddDataSeries(GetPeriodType(FeedDataSeries), 1);
				if (BarsPeriod.BarsPeriodType != BarsPeriodType.Minute && MinuteBars > 0)
                {
					AddDataSeries(BarsPeriodType.Minute, MinuteBars);
					VolumeDataSeries = 2;
					VolumeType  = ARC_VSA_InputType.Real;
					RangeType   = ARC_VSA_InputType.Real;
					DensityType = ARC_VSA_InputType.Real;
                }
			}
			else if (State == State.DataLoaded)
            {
				RelativeVolume = new Series<double>(this);
				RelativeRange = new Series<double>(this);
				RelativeDensity = new Series<double>(this);
//				PatternType = new Series<int>(this);
				ListProfiles = new Dictionary<int, Dictionary<double, long>>();
				ListProfileData = new Dictionary<int, BarProfileData>();
				
				gbTickSize = TickSize;//#BUG001 : bug fix
				IsForex = Instrument.MasterInstrument.InstrumentType == NinjaTrader.Cbi.InstrumentType.Forex;
				if (IsForex && pRoundForexToWholePip)
					gbTickSize = TickSize * 10;
//				if(IsDebug)Print("Ticks loaded: "+BarsArray[1].Count.ToString("###,###,###"));
			}
			else if (State == State.Historical)
            {
				#region -- Add Custom Toolbar --
				if (!isToolBarButtonAdded && ChartControl != null)
				{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
						if (chartWindow == null) return;

						foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

						if (!isToolBarButtonAdded)
						{
							indytoolbar = new Grid { Visibility = Visibility.Collapsed };

							addToolBar();

							chartWindow.MainMenu.Add(indytoolbar);
							chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

							foreach (TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
							AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
						}
					}));
				}
				#endregion
			}
			else if (State == State.Terminated)
			{
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
						indytoolbar = null;
						try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
							indytoolbar = null;
							try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
							chartWindow = null;
						}));
					}
				}
			}
			#endregion
		}
//===========================================================================================================
		#region -- SoundAlertHandler --
		private void SoundAlertHandler(int type, string wav){
			if(MasterAudioEnable && SoundAlertBar != CurrentBars[0] && (IsDebug || State == State.Realtime) && wav.CompareTo("SOUND OFF")!=0){
				wav = AddSoundFolder(wav.Replace("<inst>",Instrument.MasterInstrument.Name));
				if(System.IO.File.Exists(wav)){
					string tg = CurrentBar.ToString();
if(IsDebug) Print("Playing wav: "+wav+" at "+Times[0][0].ToString());
					if(type == UP)        Alert("long"+tg,  pAlertPriority, "VSA Long",  wav, 1,  Brushes.Green, Brushes.White);
					else if(type == DOWN) Alert("short"+tg,  pAlertPriority, "VSA Short",  wav, 1,  Brushes.Red, Brushes.White);
					else if(type == P_PROFILE_SIGNAL) 			  Alert("PPro"+tg,  pAlertPriority, "VSA P-profile",  wav, 1,  Brushes.BlueViolet, Brushes.White);
					else if(type == b_PROFILE_SIGNAL) 			  Alert("bPro"+tg,  pAlertPriority, "VSA b-profile",  wav, 1,  Brushes.Navy, Brushes.White);
					else if(type == CLIMACTIC_BAR_SIGNAL)		  Alert("CL"+tg,    pAlertPriority, "VSA Climactic",  wav, 1,  Brushes.Blue, Brushes.White);
					else if(type == CHURN_BAR_SIGNAL)			  Alert("CH"+tg,    pAlertPriority, "VSA Churn",      wav, 1,  Brushes.Blue, Brushes.White);
					else if(type == PIN_BAR_SIGNAL)				  Alert("PB"+tg,    pAlertPriority, "VSA Pinbar",     wav, 1,  Brushes.Blue, Brushes.White);
					else if(type ==  CLIMACTIC_CHURN_BAR_SIGNAL)  Alert("long"+tg,  pAlertPriority, "VSA CC BUY",     wav, 1,  Brushes.Green, Brushes.White);
					else if(type == -CLIMACTIC_CHURN_BAR_SIGNAL)  Alert("short"+tg, pAlertPriority, "VSA CC SELL",    wav, 1,  Brushes.Red, Brushes.White);
					else if(type ==  CLIMACTIC_PINBAR_BAR_SIGNAL) Alert("long"+tg,  pAlertPriority, "VSA CP BUY",     wav, 1,  Brushes.Green, Brushes.White);
					else if(type == -CLIMACTIC_PINBAR_BAR_SIGNAL) Alert("short"+tg, pAlertPriority, "VSA CP SELL",    wav, 1,  Brushes.Red, Brushes.White);
				}
				SoundAlertBar = CurrentBars[0];
			}
		}
//===========================================================================================================
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
		#endregion
//===========================================================================================================
		protected override void OnBarUpdate()
		{
//			if(IsDebug)return;
			#region -- Licensing --
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			#endregion
			if(CurrentBars[VolumeDataSeries] < 20 || CurrentBar < 20)
            {
				return;
            }

			if(ListProfileData!=null && ListProfileData.ContainsKey(CurrentBars[0]) && BarsInProgress == 0){
				if(ListProfileData[CurrentBars[0]] !=null){
					if(ListProfileData[CurrentBars[0]].Type=='P') SoundAlertHandler(P_PROFILE_SIGNAL, pPProfileWAV);
					if(ListProfileData[CurrentBars[0]].Type=='b') SoundAlertHandler(b_PROFILE_SIGNAL, pbProfileWAV);
				}
			}
			int cb = CurrentBars[0] + 1;
			if(!ListProfiles.ContainsKey(cb))
            {
				ListProfiles.Add(cb, new Dictionary<double, long>());
				ListProfileData.Add(cb, null);
            }

			if(BarsInProgress == 1)
            {
				if (FeedDataSeries != ARC_VSA_FeedTimeSeries.Tick)
				{
					double range = (RoundToWholePip(High[0]) - RoundToWholePip(Low[0]))/gbTickSize;
					long v = (long)(Volume[0] / range);
					if (v <= 0)
                    {
						v = 1;
                    }
					for(double p = RoundToWholePip(Low[0]); p < RoundToWholePip(High[0]) + double.Epsilon; p += gbTickSize)
                    {
						if (ListProfiles[cb].ContainsKey(p))
						{
							ListProfiles[cb][p] += v;
						}
						else
						{
							ListProfiles[cb].Add(p, v);
						}
					}
					if (ListProfiles[cb].Count > 2)
					{
						ListProfileData[cb] = BarProfileData.CreateFromData(ListProfiles[cb], iPeakThreshold, iVAThreshold, this);
					}
				}
				else
				{
					double p = RoundToWholePip(Close[0]);
					if (ListProfiles[cb].ContainsKey(p))
					{
						ListProfiles[cb][p] += (long)Volume[0];
					}
					else
					{
						ListProfiles[cb].Add(p, (long)Volume[0]);
					}
					if (ListProfiles[cb].Count > 2)
					{
						ListProfileData[cb] = BarProfileData.CreateFromData(ListProfiles[cb], iPeakThreshold, iVAThreshold, this);
					}
				}
			}

			if (BarsInProgress != 0)
            {
				return;
            }

			/*if (IsFirstTickOfBar && BarProfile[1] != null && BarProfile[1].Count > 2)
			{
				ProfileData[0] = BarProfileData.CreateFromData(BarProfile[1], 50, 67);
				//Print("Historical, " + Time[1].ToString() + ", " + ProfileData[1].Type);
			}*/
			try
			{
			CalcRelativeVolume(VolumeDataSeries);
			PatternType[0] = NO_PATTERN;
			//Print("Density: " + RelativeDensity[0] + ", Range: " + RelativeRange[0] + ", Volume: " + RelativeVolume[0]);
			if(RelativeRange[0] > -1 && RelativeVolume[0] > - 1 && RelativeRange[0] > ClimacticBarRangeThreshold && RelativeVolume[0] > ClimacticBarVolumeThreshold)
            {
				PatternType[0] = CLIMACTIC_BAR_SIGNAL;//1
				if(ShowClimacticBars)
            	{
					BarBrush = ClimacticBarColor;
                }
				if(BarsInProgress == 0) SoundAlertHandler(CLIMACTIC_BAR_SIGNAL, pClimacticBarWAV);
            }

			if(RelativeRange[0] > -1 && RelativeDensity[0] > -1 && RelativeRange[0] < RelativeRange[1] && RelativeDensity[0] > RelativeDensity[1] && RelativeDensity[0] > ChurnDensityThreshold)
            {
				PatternType[0] = CHURN_BAR_SIGNAL;//2
				if(ShowChurnBars)
    	        {
					BarBrush = ChurnBarColor;
                }
				if(BarsInProgress == 0) SoundAlertHandler(CHURN_BAR_SIGNAL, pChurnBarWAV);
            }
			
			double topWink = High[0] - Math.Max(Open[0], Close[0]);
			double botWink = Math.Min(Open[0], Close[0]) - Low[0];
			double body = Math.Abs(Close[0] - Open[0]);
			double ratio = Math.Max(topWink, botWink) / body;
			if(PatternType[0] == NO_PATTERN && ratio > PinBarRatio)
			{
				if (topWink > botWink && Close[0] < Open[0])
				{
					PatternType[0] = PIN_BAR_SIGNAL;//3;
				}
				else if (topWink < botWink && Close[0] > Open[0])
				{
					PatternType[0] = PIN_BAR_SIGNAL;//3;
				}
				//if(ShowPinBars)
				//{
				//	BarBrush = PinBarColor;
				//}
				if(BarsInProgress == 0) SoundAlertHandler(PIN_BAR_SIGNAL, pPinBarWAV);
			}

			if (PatternType[0] == CHURN_BAR_SIGNAL)
			{
				for(int i = 1; i < 15; i++)
				{
					if(PatternType[i] == CLIMACTIC_BAR_SIGNAL)
					{
						if(Close[0] <= High[i] && Close[0] >= Low[i] && (Close[0] >= Open[0] && (Close[i] > Open[i] || Low[0] < Low[i])) || (Close[0] <= Open[0] && (Close[i] < Open[i] || High[0] > High[i])))
						{
							PatternType[0] = CLIMACTIC_CHURN_BAR_SIGNAL;//11;
						}
						else if(i == 1)
						{
							PatternType[0] = CLIMACTIC_CHURN_BAR_SIGNAL;//11;
						}
						
						if(PatternType[0] == CLIMACTIC_CHURN_BAR_SIGNAL)
						{
							if(Close[i] > Open[i])
							{
								PatternType[0] = -CLIMACTIC_CHURN_BAR_SIGNAL;
							}
							if(ShowCCPattern)
							{
								BarBrush = CCBarColor;
								DrawArrow(0, CCLongColor, CCShortColor, CCPlotStyle);
							}
							if(BarsInProgress == 0) SoundAlertHandler(CLIMACTIC_CHURN_BAR_SIGNAL, PatternType[0] > 0 ? pClimacticChurnBuyWAV : pClimacticChurnSellWAV);
							break;
						}
					}
					else if(PatternType[i] != NO_PATTERN)
					{
						break;
					}
				}
			}

			if (PatternType[0] == PIN_BAR_SIGNAL)
			{
				//Print("Pin Bar");
				for (int i = 1; i < 15; i++)
				{
					if (PatternType[i] == CLIMACTIC_BAR_SIGNAL)
					{
						//Print("Pin Bar Pattern");
						//if (Close[0] <= High[i] && Close[0] >= Low[i] && (Close[0] >= Open[0] && (Close[i] > Open[i] || Low[0] < Low[i])) || (Close[0] <= Open[0] && (Close[i] < Open[i] || High[0] > High[i])))
						if(Close[0] < Open[0] && Close[i] > Open[i])
						{
							PatternType[0] = -CLIMACTIC_PINBAR_BAR_SIGNAL;//12;
						}
						if (Close[0] > Open[0] && Close[i] < Open[i])
						{
							PatternType[0] = CLIMACTIC_PINBAR_BAR_SIGNAL;//12;
						}

						if (Math.Abs(PatternType[0]) == CLIMACTIC_PINBAR_BAR_SIGNAL)
						{
							if (ShowCPPattern)
							{
								BarBrush = CPBarColor;
								DrawArrow(0, CPLongColor, CPShortColor, CPPlotStyle);
							}
							if(BarsInProgress == 0) SoundAlertHandler(CLIMACTIC_PINBAR_BAR_SIGNAL, PatternType[0]>NO_PATTERN ? pClimacticPinBuyWAV : pClimacticPinSellWAV);
							break;
						}
					}
					/*else if (PatternType[i] > 1)
					{
						break;
					}*/
				}
			}
			}
			catch(Exception ex)
			{
				Print(ex.StackTrace);
			}
		}
#region methods
		private void RedrawSignals()
		{
			#region RedrawSignals
			this.RemoveDrawObjects();
			try
			{
				for(int i = 0; i < CurrentBars[0]; i++)
				{
					if(ShowClimacticBars && PatternType[i] == CLIMACTIC_BAR_SIGNAL)
					{
						BarBrushes[i] = ClimacticBarColor;
					}
					else if(ShowChurnBars && PatternType[i] == CHURN_BAR_SIGNAL)
					{
						BarBrushes[i] = ChurnBarColor;
					}
					/*else if(ShowPinBars && PatternType[i] == 3)
					{
						BarBrushes[i] = PinBarColor;
					}*/
					else if(Math.Abs(PatternType[i]) == CLIMACTIC_CHURN_BAR_SIGNAL)
					{
						if(ShowCCPattern)
						{
							BarBrushes[i] = CCBarColor;
							DrawArrow(i, CCLongColor, CCShortColor, CCPlotStyle);
						}
						else if(ShowChurnBars)
						{
							BarBrushes[i] = ChurnBarColor;
						}
						else
						{
							BarBrushes[i] = null;
						}
					}
					else if (ShowCPPattern && Math.Abs(PatternType[i]) == CLIMACTIC_PINBAR_BAR_SIGNAL)
					{
						BarBrushes[i] = CPBarColor;
						DrawArrow(i, CPLongColor, CPShortColor, CPPlotStyle);
					}
					else
					{
						BarBrushes[i] = null;
					}
				}
				ForceRefresh();
			}
			catch(Exception ex)
			{
				Print(ex.StackTrace);
			}
			#endregion
		}

		private void CalcRelativeVolume(int seriesIndex, int barIndex = 0)
        {
			#region CalcRelativeVolume
			List<int> barIndexes = null;
			bool onlyReal = VolumeType == ARC_VSA_InputType.Real && RangeType == ARC_VSA_InputType.Real && DensityType == ARC_VSA_InputType.Real;
			if(!onlyReal)
			{
				int timen = ToTime(Times[seriesIndex][barIndex]);
				barIndexes = TimeBars(timen, seriesIndex, barIndex);
//Print("Time: " + timen + ", bars: " + barIndexes.Count);
				if (barIndexes.Count < 10)
				{
					RelativeVolume[barIndex] = -1;
					RelativeRange[barIndex] = -1;
					RelativeDensity[barIndex] = -1;
					return;
				}
			}

			if (VolumeType == ARC_VSA_InputType.Real)
			{
				RelativeVolume[barIndex] = (100 * Volumes[seriesIndex][barIndex])/SMA(Volumes[seriesIndex], 10)[1];
			}
			else
			{
				double totalVolume = 0;
				foreach (int i in barIndexes)
				{
					totalVolume += Volumes[seriesIndex][i];
				}
				double averageVolume = totalVolume / 10.0;
				double vol = Volumes[seriesIndex][0] * 100.0 / averageVolume;
				RelativeVolume[barIndex] = vol;
			}

			if(RangeType == ARC_VSA_InputType.Real)
            {
				RelativeRange[barIndex] = (100 * (Highs[seriesIndex][barIndex] - Lows[seriesIndex][barIndex])) / RangeMA(seriesIndex, barIndex);
            }
			else
            {
				double totalRange = 0;
				foreach (int i in barIndexes)
				{
					totalRange += (Highs[seriesIndex][i] - Lows[seriesIndex][i]);
				}
				double averageRange = totalRange / 10.0;
				double r = (Highs[seriesIndex][barIndex] - Lows[seriesIndex][barIndex]) * 100.0 / averageRange;
				RelativeRange[0] = r;
			}

			if (DensityType == ARC_VSA_InputType.Real)
			{
				RelativeDensity[barIndex] = (100 * (Volumes[seriesIndex][barIndex] / (TickSize + Highs[seriesIndex][barIndex] - Lows[seriesIndex][barIndex]))) / DensityMA(seriesIndex, barIndex);
			}
			else
			{
				double totalDensity = 0;
				foreach (int i in barIndexes)
				{
					totalDensity += (Volumes[seriesIndex][i] / (TickSize + Highs[seriesIndex][i] - Lows[seriesIndex][i]));
				}
				double averageDensity = totalDensity / 10.0;
				double d = (Volumes[seriesIndex][barIndex] / (TickSize + Highs[seriesIndex][barIndex] - Lows[seriesIndex][barIndex])) * 100.0 / averageDensity;
				RelativeDensity[0] = d;
			}
			#endregion
		}

		private double DensityMA(int seriesIndex, int barIndex)
		{
			double totalDensity = 0;
			for (int i = barIndex + 1; i < barIndex + 11; i++)
			{
				totalDensity += Volumes[seriesIndex][i] / (TickSize + Highs[seriesIndex][i] - Lows[seriesIndex][i]);
			}
			double averageDensity = totalDensity / 10.0;
			//double r = (Volumes[seriesIndex][barIndex] /(TickSize + Highs[seriesIndex][barIndex] - Lows[seriesIndex][barIndex])) / averageDensity;
			return averageDensity;
		}

		private double RangeMA(int seriesIndex, int barIndex)
        {
			double totalRange = 0;
			for(int i = barIndex + 1; i < barIndex + 11; i++)
			{
				totalRange += (TickSize + Highs[seriesIndex][i] - Lows[seriesIndex][i]);
			}
			double averageRange = totalRange / 10.0;
			//double r = (TickSize + Highs[seriesIndex][barIndex] - Lows[seriesIndex][barIndex]) / averageRange;
			return averageRange;
		}

		private List<int> TimeBars(int t, int seriesIndex, int startIndex)
		{
			List<int> result = new List<int>();
			for (int i = startIndex + 1; i < CurrentBars[seriesIndex]; i++)
			{
				int ti = ToTime(Times[seriesIndex][i]);
				if (ti == t)
				{
					result.Add(i);
					if (result.Count == 10)
					{
						break;
					}
				}
			}
			return result;
		}

		private void DrawArrow(int i, Brush arrowColorLong, Brush arrowColorShort, ARC_VSA_PlotStyle plotStyle)
        {
			if (ShowPatternArrows)
			{
				if (plotStyle == ARC_VSA_PlotStyle.Arrow)
				{
					if (PatternType[i] > NO_PATTERN)
					{
						Draw.ArrowUp(this, "VSAP_Up_" + (CurrentBars[0] - i).ToString(), false, i, Lows[0][i] - ArrowsOffset * TickSize, arrowColorLong);
					}
					else
					{
						Draw.ArrowDown(this, "VSAP_Dn_" + (CurrentBars[0] - i).ToString(), false, i, Highs[0][i] + ArrowsOffset * TickSize, arrowColorShort);
					}
				}
				else if (plotStyle == ARC_VSA_PlotStyle.Diamond)
				{
					if (PatternType[i] > NO_PATTERN)
					{
						Draw.Diamond(this, "VSAP_Up_" + (CurrentBars[0] - i).ToString(), false, i, Lows[0][i] - ArrowsOffset * TickSize, arrowColorLong);
					}
					else
					{
						Draw.Diamond(this, "VSAP_Dn_" + (CurrentBars[0] - i).ToString(), false, i, Highs[0][i] + ArrowsOffset * TickSize, arrowColorShort);
					}
				}
				else if (plotStyle == ARC_VSA_PlotStyle.Dot)
				{
					if (PatternType[i] > NO_PATTERN)
					{
						Draw.Dot(this, "VSAP_Up_" + (CurrentBars[0] - i).ToString(), false, i, Lows[0][i] - ArrowsOffset * TickSize, arrowColorLong);
					}
					else
					{
						Draw.Dot(this, "VSAP_Dn_" + (CurrentBars[0] - i).ToString(), false, i, Highs[0][i] + ArrowsOffset * TickSize, arrowColorShort);
					}
				}
				else if (plotStyle == ARC_VSA_PlotStyle.Square)
				{
					if (PatternType[i] > NO_PATTERN)
					{
						Draw.Square(this, "VSAP_Up_" + (CurrentBars[0] - i).ToString(), false, i, Lows[0][i] - ArrowsOffset * TickSize, arrowColorLong);
					}
					else
					{
						Draw.Square(this, "VSAP_Dn_" + (CurrentBars[0] - i).ToString(), false, i, Highs[0][i] + ArrowsOffset * TickSize, arrowColorShort);
					}
				}
				else if (plotStyle == ARC_VSA_PlotStyle.Triangle)
				{
					if (PatternType[i] > NO_PATTERN)
					{
						Draw.TriangleUp(this, "VSAP_Up_" + (CurrentBars[0] - i).ToString(), false, i, Lows[0][i] - ArrowsOffset * TickSize, arrowColorLong);
					}
					else
					{
						Draw.TriangleDown(this, "VSAP_Dn_" + (CurrentBars[0] - i).ToString(), false, i, Highs[0][i] + ArrowsOffset * TickSize, arrowColorShort);
					}
				}
			}

		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			try
            {
				RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
				
				#region -- conditions to return --
				if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot || chartControl == null) return;
				if (Bars == null || BarsArray[0].Count == 0 || BarsArray[1].Count == 0)
				{
					string msg = string.Empty;
					if (BarsArray[0].Count == 0) msg = "No bars on chart";
					if (BarsArray[1].Count == 0)
					{
						if (msg.Length > 0) msg = msg + Environment.NewLine + "No bars in background timeframe";
						else msg = "No bars in background timeframe";
					}
					return;
				}
				if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
				#endregion
				#region Init DXBrushes
				iProfilePOCDXBrush = iMPBarPOCColor.ToDxBrush(RenderTarget);
				iProfileVAHDXBrush = iMPBarVAHColor.ToDxBrush(RenderTarget);
				iProfileVALDXBrush = iMPBarVALColor.ToDxBrush(RenderTarget);
				iPHistogramBrush = iMPBarMColor.ToDxBrush(RenderTarget);
				iPLabelBrush = iTypeLabelColor.ToDxBrush(RenderTarget);
				#endregion

				#region -- Preliminary Calculation --
				int lastBarIndex = Math.Min(CurrentBars[0] + 1, ChartBars.ToIndex);//RIGHT BAR idx (slot)
				int firstBarIndex = Math.Max(BarsRequiredToPlot, ChartBars.FromIndex);// BarsRequiredToPlot;//FIRST LEFT BAR idx (slot)
				int RemainBars = ChartBars.ToIndex;

				//---------------
				if (lastBarIndex < 0 || firstBarIndex < 0 || CurrentBars[0] < 0) return;
				bool ISHardRight = lastBarIndex == CurrentBars[0];

				#region -- Fill PriceBoxes List --
				double ActualTopPrice = chartScale.MaxValue;
				double ActualBottomPrice = chartScale.MinValue;
				double PercentExpand = 20, MinTicksExpand = 50;
				double TotalExpand = Math.Max(chartScale.MaxMinusMin * PercentExpand / 100, MinTicksExpand * gbTickSize);
				double TopPrice = ActualTopPrice + TotalExpand;
				double BottomPrice = ActualBottomPrice - TotalExpand;

				#endregion

				#region -- Calculate Chart Variables (barwidth / bar margin right...) --
				int PixelsBetweenBars = (int)(chartControl.Properties.BarDistance - chartControl.BarWidth);
				int barWidth = chartControl.GetBarPaintWidth(ChartBars);
				barWidth = Math.Max(barWidth, (int)(chartControl.Properties.BarDistance)) / 2;

				#endregion

				#endregion

				for (int abar = firstBarIndex; abar <= lastBarIndex; abar++)
				{
					#region -- if outside of window => continue loop --
					double Highs0CB = RoundToWholePip(Highs[0].GetValueAt(abar));
					double Lows0CB = RoundToWholePip(Lows[0].GetValueAt(abar));
					double BodyHigh = RoundToWholePip(Math.Max(Opens[0].GetValueAt(abar), Closes[0].GetValueAt(abar)));
					double BodyLow = RoundToWholePip(Math.Min(Opens[0].GetValueAt(abar), Closes[0].GetValueAt(abar)));

					if (Highs0CB < ActualBottomPrice || Lows0CB > ActualTopPrice) continue;
					#endregion

					BarProfileData TPRO = null;
					if (ListProfileData.ContainsKey(abar))
						TPRO = ListProfileData[abar];

					if(TPRO == null)
						continue;
					
					int y1 = chartScale.GetYByValue(Highs0CB);
					int y2 = chartScale.GetYByValue(BodyHigh);
					int y3 = chartScale.GetYByValue(BodyLow) + 1;
					int y4 = chartScale.GetYByValue(Lows0CB) + 1;
					int x1 = chartControl.GetXByBarIndex(ChartBars, abar);

					if (y3 - y2 <= 0 || y4 - y1 <= 0) continue;

					Rect BodyRect = new Rect(x1 - barWidth, y2, barWidth * 2, y3 - y2);
					Rect CandleRect = new Rect(x1 - barWidth, y1 - 1, barWidth * 2, y4 - y1);

					if(chartControl.BarWidth > 1)
                    {
						foreach(var p in TPRO.Profile)
                        {
							bool drawthislevel = false;
							SharpDX.Direct2D1.Brush histoBrush = iPHistogramBrush;

							if(p.Key == TPRO.Poc && iDisplayPOC)
                            {
								histoBrush = iProfilePOCDXBrush;
								drawthislevel = true;
							}
							else if (p.Key == TPRO.Vah && iDisplayVA)
							{
								histoBrush = iProfileVAHDXBrush;
								drawthislevel = true;
							}
							else if (p.Key == TPRO.Val && iDisplayVA)
							{
								histoBrush = iProfileVALDXBrush;
								drawthislevel = true;
							}
							else if (iDisplayProfile)
                            {
								drawthislevel = true;
							}

							if (drawthislevel)
							{
								int y = chartScale.GetYByValue(p.Key);
								double w = BodyRect.Width * (iDisplayProfile ? p.Value : 1);
								drawLine(BodyRect.Left - 1, BodyRect.Left + w, y, y, histoBrush, DashStyleHelper.Solid, iBarPW);
							}
						}
					}

//					if(iDisplay_Show_Labels)
                    {
						string label = new string(TPRO.Type, 1);
						if( (iDisplay_P_Labels && label=="P") ||
							(iDisplay_b_Labels && label=="b") ||
							(iDisplay_M_Labels && label=="M") ||
							(iDisplay_D_Labels && label=="D"))
						{
							int y = y4 + iTypeLabelSeparation;
							if(IsDebug && label=="b") y = y1 - iTypeLabelSeparation - Convert.ToInt32(iFontText.Size);//added by Ben...b prints above the bar, P below the bar
							int x = x1 - (int)(getTextWidth(label, iFontText) / 2); ;
							drawstring(label, x, y, iFontText, iPLabelBrush, SharpDX.DirectWrite.TextAlignment.Center);
						}
					}
				}

				#region Dispose of DXBrushes
				if (iProfilePOCDXBrush != null) { iProfilePOCDXBrush.Dispose(); iProfilePOCDXBrush = null; }
				if (iProfileVAHDXBrush != null) { iProfileVAHDXBrush.Dispose(); iProfileVAHDXBrush = null; }
				if (iProfileVALDXBrush != null) { iProfileVALDXBrush.Dispose(); iProfileVALDXBrush = null; }
				if (iPHistogramBrush != null) { iPHistogramBrush.Dispose(); iPHistogramBrush = null; }
				if (iPLabelBrush != null) { iPLabelBrush.Dispose(); iPLabelBrush = null; }
				#endregion
			}
			catch (Exception ex)
            {
				Print(ex.Message);
				Print(ex.StackTrace);
			}
		}

		private void drawLine(double x1, double x2, double y1, double y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
		{
			SharpDX.Direct2D1.DashStyle _dashstyle;
			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

			SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
			SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

			Point p0 = new Point(x1, y1);
			Point p1 = new Point(x2, y2);
			RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), dxbrush, width, strokestyle);

			strokestyle.Dispose();
		}
		private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
		{
			if (x < 0 || y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
														 //SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
			Point textpoint = new Point(x, y);
			SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
				)
			{ TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
			SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

			RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			textLayout.Dispose();
			textFormat.Dispose();
		}
		private float getTextWidth(string text, SimpleFont font)
		{
			SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
				);
			SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			float textwidth = textLayout.Metrics.Width;

			textLayout.Dispose();
			textFormat.Dispose();

			return textwidth;
		}

		private double RoundToWholePip(double D)
		{
			if (IsForex && pRoundForexToWholePip)
			{
				int ticks = (int)Math.Round(D / gbTickSize);
				return ticks * gbTickSize;
			}
			else
			{
				int ticks = (int)Math.Round(D / TickSize);
				return ticks * TickSize;
			}
		}

		internal class BarProfileData
        {
			public double Poc { get; set; }
			public double Vah { get; set; }
			public double Val { get; set; }
			public char Type { get; set; }
			public Dictionary<double, double> Profile { get; set; }

			public static BarProfileData CreateFromData(Dictionary<double, long> barData, int PeakThreshold, int vaPercent, NinjaTrader.NinjaScript.IndicatorBase indicator)
            {
				double pocP = -1;
				long pocV = 0;
				long allVol = 0;
				int pIdx = 0;

				if(barData == null)
                {
					return new BarProfileData() { Type = 'F' };
                }
				for (int p = 0; p < barData.Count; p++)
                {
					KeyValuePair<double, long> kv = barData.ElementAt(p);
					long v = kv.Value;

					if(v > pocV)
                    {
						pocV = v;
						pocP = kv.Key;
						pIdx = p;
                    }
					if(v > 0)
					{
						allVol += v;
					}
                }

				double vaVolume = allVol * vaPercent / 100;
				double curVolume = pocV;
				double pah = pocP;
				double pal = pocP;
				int idxAbove = pIdx;
				int idxBelow = pIdx;
				int idxMax = barData.Count - 1;
				bool isUpCluster = false;

				double VolumeAbove = idxAbove + 1 <= idxMax ? barData.ElementAt(idxAbove + 1).Value : 0;
				if (idxAbove + 2 <= idxMax) VolumeAbove += barData.ElementAt(idxAbove + 2).Value;

				double VolumeBelow = idxBelow - 1 >= 0 ? barData.ElementAt(idxBelow - 1).Value : 0;
				if (idxBelow - 2 >= 0) VolumeBelow += barData.ElementAt(idxBelow - 2).Value;

				while (curVolume < vaVolume)
				{
					if (VolumeBelow > VolumeAbove || idxAbove == idxMax)
					{
						idxBelow = idxBelow - 2 < 0 ? 0 : idxBelow - 2;
						curVolume = curVolume + VolumeBelow;
						VolumeBelow = 0;
						isUpCluster = false;
					}
					else
					{
						idxAbove = idxAbove + 2 > idxMax ? idxMax : idxAbove + 2;
						curVolume = curVolume + VolumeAbove;
						VolumeAbove = 0;
						isUpCluster = idxAbove < idxMax;//to unlock
					}

					if (isUpCluster)
					{
						VolumeAbove = idxAbove + 1 <= idxMax ? barData.ElementAt(idxAbove + 1).Value : 0;
						if (idxAbove + 2 <= idxMax) VolumeAbove += barData.ElementAt(idxAbove + 2).Value;
					}
					else
					{
						VolumeBelow = idxBelow - 1 >= 0 ? barData.ElementAt(idxBelow - 1).Value : 0;
						if (idxBelow - 2 >= 0) VolumeBelow += barData.ElementAt(idxBelow - 2).Value;
					}
				}

				BarProfileData barProfileData = new BarProfileData();
				barProfileData.Poc = pocP;
				barProfileData.Vah = barData.Count == 0 ? 0 : Math.Max(barData.ElementAt(idxBelow).Key,  barData.ElementAt(idxAbove).Key);
				barProfileData.Val = barData.Count == 0 ? 0 : Math.Min(barData.ElementAt(idxBelow).Key,  barData.ElementAt(idxAbove).Key);

				double pLow = barData.Keys.Min();
				double pHigh = barData.Keys.Max();

				double distance = pHigh - pLow;
				double segment = distance / 3;

				long volume1 = barData.Where(kv => kv.Key < pLow + segment).Sum(kv => kv.Value);
				long volume2 = barData.Where(kv => kv.Key >= pLow + segment && kv.Key <= pHigh - segment).Sum(kv => kv.Value);
				long volume3 = barData.Where(kv => kv.Key > pHigh - segment).Sum(kv => kv.Value);

				double threshold = allVol * PeakThreshold / 100;
				//indicator.Print("1: " + volume1 + ", 2: " + volume2 + ", 3: " + volume3 + ", Threshold: " + threshold +  ", All V: " + allVol + ", Peak: " + PeakThreshold);
				
				if (volume1 > threshold && volume1 > volume2 && volume3 <= threshold)
                {
					barProfileData.Type = 'b';
                }
				else if (volume2 > threshold && volume1 <= threshold && volume3 <= threshold)
				{
					barProfileData.Type = 'D';
				}
				else if (volume3 > threshold && volume3 > volume2 && volume1 <= threshold)
				{
					barProfileData.Type = 'P';
				}
				else
                {
					barProfileData.Type = 'M';
                }

				barProfileData.Profile = new Dictionary<double, double>();

				foreach(var kv in barData)
                {
					barProfileData.Profile.Add(kv.Key, (double)kv.Value / (double)pocV);
                }

				return barProfileData;

				//return new BarProfileData() { Type = 'N' };
			}
		}
#endregion

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PatternType { get { return Values[0]; } }
//===========================================================================================================
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
//				list.Add("<inst>_Short_CycleForecaster.wav");
//				list.Add("<inst>_Long_CycleForecaster.wav");
//				list.Add("<inst>_Neutral_CycleForecaster.wav");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }

		#region Properties
		
		#region -- Climactic Bars --
		[NinjaScriptProperty]
		[Display(Name="Show Climactic Bars", Order=1, GroupName="Climactic Bars")]
		public bool ShowClimacticBars
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="ClimacticBarColor", Order=10, GroupName="Climactic Bars")]
		public Brush ClimacticBarColor
		{ get; set; }

		[Browsable(false)]
		public string ClimacticBarColorSerializable
		{
			get { return Serialize.BrushToString(ClimacticBarColor); }
			set { ClimacticBarColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[Range(100, int.MaxValue)]
		[Display(Name="ClimacticBarVolumeThreshold", Description="Percent relative to average", Order=12, GroupName="Climactic Bars")]
		public int ClimacticBarVolumeThreshold
		{ get; set; }

		[NinjaScriptProperty]
		[Range(100, int.MaxValue)]
		[Display(Name="ClimacticBarRangeThreshold", Description="Percent relative to average", Order=13, GroupName="Climactic Bars")]
		public int ClimacticBarRangeThreshold
		{ get; set; }
		#endregion

		#region -- Churn Bars --
		[NinjaScriptProperty]
		[Display(Name="Show Churn Bars", Order=2, GroupName="Churn Bars")]
		public bool ShowChurnBars
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Churn Bar Color", Order=8, GroupName="Churn Bars")]
		public Brush ChurnBarColor
		{ get; set; }

		[Browsable(false)]
		public string ChurnBarColorSerializable
		{
			get { return Serialize.BrushToString(ChurnBarColor); }
			set { ChurnBarColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[Range(100, int.MaxValue)]
		[Display(Name="ChurnDensityThreshold", Description="Percent relative to the average", Order=14, GroupName="Churn Bars")]
		public int ChurnDensityThreshold
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="ChurnRangeThreshold", Description="Percent max relative to the average", Order=15, GroupName="Churn Bars")]
		public int ChurnRangeThreshold
		{ get; set; }
		#endregion

		#region -- Pin bars --
		//[NinjaScriptProperty]
		//[Display(Name="Show Pin Bars", Order=3, GroupName="Pin Bars")]
		//public bool ShowPinBars
		//{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Pin to Body Ratio", Description="", Order=12, GroupName="Pin Bars")]
		public double PinBarRatio
		{ get; set; }

//		[NinjaScriptProperty]
//		[XmlIgnore]
//		[Display(Name="Pin Bar Color", Order=8, GroupName="Pin Bars")]
//		public Brush PinBarColor
//		{ get; set; }

//		[Browsable(false)]
//		public string PinBarColorSerializable
//		{
//			get { return Serialize.BrushToString(PinBarColor); }
//			set { PinBarColor = Serialize.StringToBrush(value); }
//		}		
	
		#endregion

		#region -- Patterns --
		[NinjaScriptProperty]
		[Display(Name="Show Climactic-Churn Pattern", Order=1, GroupName="Patterns")]
		public bool ShowCCPattern
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Climactic-Churn 2 bar pattern Bar Color", Order=2, GroupName="Patterns")]
		public Brush CCBarColor
		{ get; set; }

		[Browsable(false)]
		public string CCBarColorSerializable
		{
			get { return Serialize.BrushToString(CCBarColor); }
			set { CCBarColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[Display(Name = "Climactic-Churn signal plot style", GroupName = "Patterns", Order = 3)]
		public ARC_VSA_PlotStyle CCPlotStyle { get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Climactic-Churn long signal Color", Order = 4, GroupName = "Patterns")]
		public Brush CCLongColor
		{ get; set; }

		[Browsable(false)]
		public string CCLongColorSerializable
		{
			get { return Serialize.BrushToString(CCLongColor); }
			set { CCLongColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Climactic-Churn short signal Color", Order = 5, GroupName = "Patterns")]
		public Brush CCShortColor
		{ get; set; }

		[Browsable(false)]
		public string CCShortColorSerializable
		{
			get { return Serialize.BrushToString(CCShortColor); }
			set { CCShortColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[Display(Name = "Show Climactic-Pin Pattern", Order = 11, GroupName = "Patterns")]
		public bool ShowCPPattern
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Climactic-Pin 2 bar pattern Bar Color", Order = 12, GroupName = "Patterns")]
		public Brush CPBarColor
		{ get; set; }

		[Browsable(false)]
		public string CPBarColorSerializable
		{
			get { return Serialize.BrushToString(CPBarColor); }
			set { CPBarColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[Display(Name = "Climactic-Pin signal plot style", GroupName = "Patterns", Order = 13)]
		public ARC_VSA_PlotStyle CPPlotStyle { get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Climactic-Pin long signal Color", Order = 14, GroupName = "Patterns")]
		public Brush CPLongColor
		{ get; set; }

		[Browsable(false)]
		public string CPLongColorSerializable
		{
			get { return Serialize.BrushToString(CPLongColor); }
			set { CPLongColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Climactic-Pin short signal Color", Order = 15, GroupName = "Patterns")]
		public Brush CPShortColor
		{ get; set; }

		[Browsable(false)]
		public string CPShortColorSerializable
		{
			get { return Serialize.BrushToString(CPShortColor); }
			set { CPShortColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[Display(Name="Show Pattern Arrows", Order=21, GroupName="Patterns")]
		public bool ShowPatternArrows
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Arrows Offset", Order = 22, GroupName = "Patterns")]
		public int ArrowsOffset
		{ get; set; }
		#endregion

		#region -- Profile --
		[Display(Name = "Display Profile", GroupName = "Profile", Description = "", Order = 00)]
		public bool iDisplayProfile { get; set; }

		[Display(Name = "Display POC", GroupName = "Profile", Description = "", Order = 30)]
		public bool iDisplayPOC { get; set; }

		[Display(Name = "Display VAH / VAL", GroupName = "Profile", Description = "", Order = 40)]
		public bool iDisplayVA { get; set; }

		[Display(Name = "Display Profile P Labels", GroupName = "Profile", Description = "", Order = 50)]
		public bool iDisplay_P_Labels { get; set; }
		[Display(Name = "Display Profile b Labels", GroupName = "Profile", Description = "", Order = 51)]
		public bool iDisplay_b_Labels { get; set; }
		[Display(Name = "Display Profile M Labels", GroupName = "Profile", Description = "", Order = 52)]
		public bool iDisplay_M_Labels { get; set; }
		[Display(Name = "Display Profile D Labels", GroupName = "Profile", Description = "", Order = 53)]
		public bool iDisplay_D_Labels { get; set; }

		[Display(Name = "Peak Threshold Volume %", GroupName = "Profile", Description = "", Order = 60)]
		public int iPeakThreshold { get; set; }

		[Display(Name = "Value Area %", GroupName = "Profile", Description = "", Order = 70)]
		public int iVAThreshold { get; set; }

		[Range(0, 10000)]
		[Display(Name = "Histogram Width", GroupName = "Profile", Description = "Width of the histogram lines for bar profile, when print is disabled", Order = 80)]
		public int iBarPW { get; set; }

		[XmlIgnore]
		[Display(Name = "Bar Fill Color", GroupName = "Profile", Description = "", Order = 90)]
		public Brush iMPBarMColor { get; set; }
		[Browsable(false)]
		public string iMPBarMColorSerialize
		{
			get { return Serialize.BrushToString(iMPBarMColor); }
			set { iMPBarMColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bar Fill Color POC", GroupName = "Profile", Description = "", Order = 100)]
		public Brush iMPBarPOCColor { get; set; }
		[Browsable(false)]
		public string iMPBarPOCColorSerialize
		{
			get { return Serialize.BrushToString(iMPBarPOCColor); }
			set { iMPBarPOCColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bar Fill Color VAH", GroupName = "Profile", Description = "", Order = 120)]
		public Brush iMPBarVAHColor { get; set; }
		[Browsable(false)]
		public string iMPBarVAHColorSerialize
		{
			get { return Serialize.BrushToString(iMPBarVAHColor); }
			set { iMPBarVAHColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bar Fill Color VAL", GroupName = "Profile", Description = "", Order = 130)]
		public Brush iMPBarVALColor { get; set; }
		[Browsable(false)]
		public string iMPBarVALColorSerialize
		{
			get { return Serialize.BrushToString(iMPBarVALColor); }
			set { iMPBarVALColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Profile Type Label Color", GroupName = "Profile", Description = "", Order = 150)]
		public Brush iTypeLabelColor { get; set; }
		[Browsable(false)]
		public string iTypeLabelColorSerialize
		{
			get { return Serialize.BrushToString(iTypeLabelColor); }
			set { iTypeLabelColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Type Label Sepration", Order = 160, GroupName = "Profile")]
		public int iTypeLabelSeparation
		{ get; set; }

		[Display(Name = "Type Label Font", GroupName = "Profile", Description = "Choose the font style for the labels displayed.", Order = 170)]
		public SimpleFont iFontText { get; set; }
		#endregion

		#region -- Audio --
		private string pClimacticBarWAV = "SOUND OFF";
		[Description("WAV file for ClimacticBar signal")]
		[Display(Order = 10, Name = "ClimacticBar WAV", GroupName = "Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string ClimacticBarWAV
		{
			get { return pClimacticBarWAV; }
			set { pClimacticBarWAV = value; }
		}
		private string pChurnBarWAV = "SOUND OFF";
		[Description("WAV file for ChurnBar signal")]
		[Display(Order = 20, Name = "ChurnBar WAV", GroupName = "Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string ChurnBarWAV
		{
			get { return pChurnBarWAV; }
			set { pChurnBarWAV = value; }
		}
		private string pPinBarWAV = "SOUND OFF";
		[Description("WAV file for Pin Bar signal")]
		[Display(Order = 30, Name = "Pinbar WAV", GroupName = "Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string PinBarWAV
		{
			get { return pPinBarWAV; }
			set { pPinBarWAV = value; }
		}

		private string pClimacticChurnBuyWAV = "SOUND OFF";
		[Description("WAV file for 2-bar Climactic-ChurnBar BUY signal")]
		[Display(Order = 40, Name = "Climactic-Churn BUY WAV", GroupName = "Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string ClimacticChurnBuyWAV
		{
			get { return pClimacticChurnBuyWAV; }
			set { pClimacticChurnBuyWAV = value; }
		}
		private string pClimacticChurnSellWAV = "SOUND OFF";
		[Description("WAV file for 2-bar Climactic-ChurnBar SELL signal")]
		[Display(Order = 50, Name = "Climactic-Churn SELL WAV", GroupName = "Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string ClimacticChurnSellWAV
		{
			get { return pClimacticChurnSellWAV; }
			set { pClimacticChurnSellWAV = value; }
		}
		private string pClimacticPinBuyWAV = "SOUND OFF";
		[Description("WAV file for 2-bar Climactic-PinBar BUY signal")]
		[Display(Order = 60, Name = "Climactic-Pin BUY WAV", GroupName = "Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string ClimacticPinBuyWAV
		{
			get { return pClimacticPinBuyWAV; }
			set { pClimacticPinBuyWAV = value; }
		}
		private string pClimacticPinSellWAV = "SOUND OFF";
		[Description("WAV file for 2-bar Climactic-PinBar SELL signal")]
		[Display(Order = 70, Name = "Climactic-Pin SELL WAV", GroupName = "Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string ClimacticPinSellWAV
		{
			get { return pClimacticPinSellWAV; }
			set { pClimacticPinSellWAV = value; }
		}
		
		private string pPProfileWAV = "SOUND OFF";
		[Description("WAV file for P-profile signal")]
		[Display(Order = 80, Name = "P-profile WAV", GroupName = "Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string PProfileWAV
		{
			get { return pPProfileWAV; }
			set { pPProfileWAV = value; }
		}

		private string pbProfileWAV = "SOUND OFF";
		[Description("WAV file for b-profile signal")]
		[Display(Order = 90, Name = "b-profile WAV", GroupName = "Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string bProfileWAV
		{
			get { return pbProfileWAV; }
			set { pbProfileWAV = value; }
		}

		private NinjaTrader.NinjaScript.Priority pAlertPriority = NinjaTrader.NinjaScript.Priority.Medium;
        [NinjaScriptProperty]
		[Display(Name = "Alerts window priority", Description = "", GroupName = "Audio", Order = 10)]
		public NinjaTrader.NinjaScript.Priority AlertPriority
        {
            get { return pAlertPriority; }
            set { pAlertPriority = value; }
        }
		#endregion

		#region -- Parameters --
		[NinjaScriptProperty]
		[Display(Name="Volume Source Data Series", Order=1, GroupName="Parameters")]
		public ARC_VSA_FeedTimeSeries FeedDataSeries
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Minute Bars", Order=4, GroupName="Parameters")]
		public int MinuteBars
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Volume Type", Description="If the volume has removed seasonality", Order=5, GroupName="Parameters")]
		public ARC_VSA_InputType VolumeType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Range Type", Description="If the range has seasonality removed", Order=6, GroupName="Parameters")]
		public ARC_VSA_InputType RangeType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Density Type", Description="If the density has seasonality removed", Order=7, GroupName="Parameters")]
		public ARC_VSA_InputType DensityType
		{ get; set; }

		[Display(Name = "Button Text", GroupName = "Parameters", Description = "", Order = 40)]
		public string pButtonText { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Ignore last forex digit", GroupName = "Parameters", Description = "Round-off the rightmost digit in forex instruments", Order = 20)]
		public bool pRoundForexToWholePip { get; set; }
		#endregion
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_VSA[] cacheARC_VSA;
		public ARC.ARC_VSA ARC_VSA(bool showClimacticBars, Brush climacticBarColor, int climacticBarVolumeThreshold, int climacticBarRangeThreshold, bool showChurnBars, Brush churnBarColor, int churnDensityThreshold, int churnRangeThreshold, double pinBarRatio, bool showCCPattern, Brush cCBarColor, ARC_VSA_PlotStyle cCPlotStyle, Brush cCLongColor, Brush cCShortColor, bool showCPPattern, Brush cPBarColor, ARC_VSA_PlotStyle cPPlotStyle, Brush cPLongColor, Brush cPShortColor, bool showPatternArrows, int arrowsOffset, int iTypeLabelSeparation, NinjaTrader.NinjaScript.Priority alertPriority, ARC_VSA_FeedTimeSeries feedDataSeries, int minuteBars, ARC_VSA_InputType volumeType, ARC_VSA_InputType rangeType, ARC_VSA_InputType densityType, bool pRoundForexToWholePip)
		{
			return ARC_VSA(Input, showClimacticBars, climacticBarColor, climacticBarVolumeThreshold, climacticBarRangeThreshold, showChurnBars, churnBarColor, churnDensityThreshold, churnRangeThreshold, pinBarRatio, showCCPattern, cCBarColor, cCPlotStyle, cCLongColor, cCShortColor, showCPPattern, cPBarColor, cPPlotStyle, cPLongColor, cPShortColor, showPatternArrows, arrowsOffset, iTypeLabelSeparation, alertPriority, feedDataSeries, minuteBars, volumeType, rangeType, densityType, pRoundForexToWholePip);
		}

		public ARC.ARC_VSA ARC_VSA(ISeries<double> input, bool showClimacticBars, Brush climacticBarColor, int climacticBarVolumeThreshold, int climacticBarRangeThreshold, bool showChurnBars, Brush churnBarColor, int churnDensityThreshold, int churnRangeThreshold, double pinBarRatio, bool showCCPattern, Brush cCBarColor, ARC_VSA_PlotStyle cCPlotStyle, Brush cCLongColor, Brush cCShortColor, bool showCPPattern, Brush cPBarColor, ARC_VSA_PlotStyle cPPlotStyle, Brush cPLongColor, Brush cPShortColor, bool showPatternArrows, int arrowsOffset, int iTypeLabelSeparation, NinjaTrader.NinjaScript.Priority alertPriority, ARC_VSA_FeedTimeSeries feedDataSeries, int minuteBars, ARC_VSA_InputType volumeType, ARC_VSA_InputType rangeType, ARC_VSA_InputType densityType, bool pRoundForexToWholePip)
		{
			if (cacheARC_VSA != null)
				for (int idx = 0; idx < cacheARC_VSA.Length; idx++)
					if (cacheARC_VSA[idx] != null && cacheARC_VSA[idx].ShowClimacticBars == showClimacticBars && cacheARC_VSA[idx].ClimacticBarColor == climacticBarColor && cacheARC_VSA[idx].ClimacticBarVolumeThreshold == climacticBarVolumeThreshold && cacheARC_VSA[idx].ClimacticBarRangeThreshold == climacticBarRangeThreshold && cacheARC_VSA[idx].ShowChurnBars == showChurnBars && cacheARC_VSA[idx].ChurnBarColor == churnBarColor && cacheARC_VSA[idx].ChurnDensityThreshold == churnDensityThreshold && cacheARC_VSA[idx].ChurnRangeThreshold == churnRangeThreshold && cacheARC_VSA[idx].PinBarRatio == pinBarRatio && cacheARC_VSA[idx].ShowCCPattern == showCCPattern && cacheARC_VSA[idx].CCBarColor == cCBarColor && cacheARC_VSA[idx].CCPlotStyle == cCPlotStyle && cacheARC_VSA[idx].CCLongColor == cCLongColor && cacheARC_VSA[idx].CCShortColor == cCShortColor && cacheARC_VSA[idx].ShowCPPattern == showCPPattern && cacheARC_VSA[idx].CPBarColor == cPBarColor && cacheARC_VSA[idx].CPPlotStyle == cPPlotStyle && cacheARC_VSA[idx].CPLongColor == cPLongColor && cacheARC_VSA[idx].CPShortColor == cPShortColor && cacheARC_VSA[idx].ShowPatternArrows == showPatternArrows && cacheARC_VSA[idx].ArrowsOffset == arrowsOffset && cacheARC_VSA[idx].iTypeLabelSeparation == iTypeLabelSeparation && cacheARC_VSA[idx].AlertPriority == alertPriority && cacheARC_VSA[idx].FeedDataSeries == feedDataSeries && cacheARC_VSA[idx].MinuteBars == minuteBars && cacheARC_VSA[idx].VolumeType == volumeType && cacheARC_VSA[idx].RangeType == rangeType && cacheARC_VSA[idx].DensityType == densityType && cacheARC_VSA[idx].pRoundForexToWholePip == pRoundForexToWholePip && cacheARC_VSA[idx].EqualsInput(input))
						return cacheARC_VSA[idx];
			return CacheIndicator<ARC.ARC_VSA>(new ARC.ARC_VSA(){ ShowClimacticBars = showClimacticBars, ClimacticBarColor = climacticBarColor, ClimacticBarVolumeThreshold = climacticBarVolumeThreshold, ClimacticBarRangeThreshold = climacticBarRangeThreshold, ShowChurnBars = showChurnBars, ChurnBarColor = churnBarColor, ChurnDensityThreshold = churnDensityThreshold, ChurnRangeThreshold = churnRangeThreshold, PinBarRatio = pinBarRatio, ShowCCPattern = showCCPattern, CCBarColor = cCBarColor, CCPlotStyle = cCPlotStyle, CCLongColor = cCLongColor, CCShortColor = cCShortColor, ShowCPPattern = showCPPattern, CPBarColor = cPBarColor, CPPlotStyle = cPPlotStyle, CPLongColor = cPLongColor, CPShortColor = cPShortColor, ShowPatternArrows = showPatternArrows, ArrowsOffset = arrowsOffset, iTypeLabelSeparation = iTypeLabelSeparation, AlertPriority = alertPriority, FeedDataSeries = feedDataSeries, MinuteBars = minuteBars, VolumeType = volumeType, RangeType = rangeType, DensityType = densityType, pRoundForexToWholePip = pRoundForexToWholePip }, input, ref cacheARC_VSA);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_VSA ARC_VSA(bool showClimacticBars, Brush climacticBarColor, int climacticBarVolumeThreshold, int climacticBarRangeThreshold, bool showChurnBars, Brush churnBarColor, int churnDensityThreshold, int churnRangeThreshold, double pinBarRatio, bool showCCPattern, Brush cCBarColor, ARC_VSA_PlotStyle cCPlotStyle, Brush cCLongColor, Brush cCShortColor, bool showCPPattern, Brush cPBarColor, ARC_VSA_PlotStyle cPPlotStyle, Brush cPLongColor, Brush cPShortColor, bool showPatternArrows, int arrowsOffset, int iTypeLabelSeparation, NinjaTrader.NinjaScript.Priority alertPriority, ARC_VSA_FeedTimeSeries feedDataSeries, int minuteBars, ARC_VSA_InputType volumeType, ARC_VSA_InputType rangeType, ARC_VSA_InputType densityType, bool pRoundForexToWholePip)
		{
			return indicator.ARC_VSA(Input, showClimacticBars, climacticBarColor, climacticBarVolumeThreshold, climacticBarRangeThreshold, showChurnBars, churnBarColor, churnDensityThreshold, churnRangeThreshold, pinBarRatio, showCCPattern, cCBarColor, cCPlotStyle, cCLongColor, cCShortColor, showCPPattern, cPBarColor, cPPlotStyle, cPLongColor, cPShortColor, showPatternArrows, arrowsOffset, iTypeLabelSeparation, alertPriority, feedDataSeries, minuteBars, volumeType, rangeType, densityType, pRoundForexToWholePip);
		}

		public Indicators.ARC.ARC_VSA ARC_VSA(ISeries<double> input , bool showClimacticBars, Brush climacticBarColor, int climacticBarVolumeThreshold, int climacticBarRangeThreshold, bool showChurnBars, Brush churnBarColor, int churnDensityThreshold, int churnRangeThreshold, double pinBarRatio, bool showCCPattern, Brush cCBarColor, ARC_VSA_PlotStyle cCPlotStyle, Brush cCLongColor, Brush cCShortColor, bool showCPPattern, Brush cPBarColor, ARC_VSA_PlotStyle cPPlotStyle, Brush cPLongColor, Brush cPShortColor, bool showPatternArrows, int arrowsOffset, int iTypeLabelSeparation, NinjaTrader.NinjaScript.Priority alertPriority, ARC_VSA_FeedTimeSeries feedDataSeries, int minuteBars, ARC_VSA_InputType volumeType, ARC_VSA_InputType rangeType, ARC_VSA_InputType densityType, bool pRoundForexToWholePip)
		{
			return indicator.ARC_VSA(input, showClimacticBars, climacticBarColor, climacticBarVolumeThreshold, climacticBarRangeThreshold, showChurnBars, churnBarColor, churnDensityThreshold, churnRangeThreshold, pinBarRatio, showCCPattern, cCBarColor, cCPlotStyle, cCLongColor, cCShortColor, showCPPattern, cPBarColor, cPPlotStyle, cPLongColor, cPShortColor, showPatternArrows, arrowsOffset, iTypeLabelSeparation, alertPriority, feedDataSeries, minuteBars, volumeType, rangeType, densityType, pRoundForexToWholePip);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_VSA ARC_VSA(bool showClimacticBars, Brush climacticBarColor, int climacticBarVolumeThreshold, int climacticBarRangeThreshold, bool showChurnBars, Brush churnBarColor, int churnDensityThreshold, int churnRangeThreshold, double pinBarRatio, bool showCCPattern, Brush cCBarColor, ARC_VSA_PlotStyle cCPlotStyle, Brush cCLongColor, Brush cCShortColor, bool showCPPattern, Brush cPBarColor, ARC_VSA_PlotStyle cPPlotStyle, Brush cPLongColor, Brush cPShortColor, bool showPatternArrows, int arrowsOffset, int iTypeLabelSeparation, NinjaTrader.NinjaScript.Priority alertPriority, ARC_VSA_FeedTimeSeries feedDataSeries, int minuteBars, ARC_VSA_InputType volumeType, ARC_VSA_InputType rangeType, ARC_VSA_InputType densityType, bool pRoundForexToWholePip)
		{
			return indicator.ARC_VSA(Input, showClimacticBars, climacticBarColor, climacticBarVolumeThreshold, climacticBarRangeThreshold, showChurnBars, churnBarColor, churnDensityThreshold, churnRangeThreshold, pinBarRatio, showCCPattern, cCBarColor, cCPlotStyle, cCLongColor, cCShortColor, showCPPattern, cPBarColor, cPPlotStyle, cPLongColor, cPShortColor, showPatternArrows, arrowsOffset, iTypeLabelSeparation, alertPriority, feedDataSeries, minuteBars, volumeType, rangeType, densityType, pRoundForexToWholePip);
		}

		public Indicators.ARC.ARC_VSA ARC_VSA(ISeries<double> input , bool showClimacticBars, Brush climacticBarColor, int climacticBarVolumeThreshold, int climacticBarRangeThreshold, bool showChurnBars, Brush churnBarColor, int churnDensityThreshold, int churnRangeThreshold, double pinBarRatio, bool showCCPattern, Brush cCBarColor, ARC_VSA_PlotStyle cCPlotStyle, Brush cCLongColor, Brush cCShortColor, bool showCPPattern, Brush cPBarColor, ARC_VSA_PlotStyle cPPlotStyle, Brush cPLongColor, Brush cPShortColor, bool showPatternArrows, int arrowsOffset, int iTypeLabelSeparation, NinjaTrader.NinjaScript.Priority alertPriority, ARC_VSA_FeedTimeSeries feedDataSeries, int minuteBars, ARC_VSA_InputType volumeType, ARC_VSA_InputType rangeType, ARC_VSA_InputType densityType, bool pRoundForexToWholePip)
		{
			return indicator.ARC_VSA(input, showClimacticBars, climacticBarColor, climacticBarVolumeThreshold, climacticBarRangeThreshold, showChurnBars, churnBarColor, churnDensityThreshold, churnRangeThreshold, pinBarRatio, showCCPattern, cCBarColor, cCPlotStyle, cCLongColor, cCShortColor, showCPPattern, cPBarColor, cPPlotStyle, cPLongColor, cPShortColor, showPatternArrows, arrowsOffset, iTypeLabelSeparation, alertPriority, feedDataSeries, minuteBars, volumeType, rangeType, densityType, pRoundForexToWholePip);
		}
	}
}

#endregion
