#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Windows.Controls;
using System.Windows.Automation;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public class ARC_PatternFinder : Indicator
	{
		bool IsDebug = false;
		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "PatternFinder";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "25900", "10759", "27405"};//27405 is Annual Membership
		//v1.2  - SystemSignal was finally connected with meaningful signal info
		//v1.3  - pMarkerOffset was not connected...fixed...now, the Draw.Arrow statements contain pMarkerOffset
		//v1.31 - Added uID string onto the name for 
		private const string VERSION = "v1.31 25 Apr 2022";


        public enum MState
        {
            NoPattern,
            HigherHigh,
            LowerHigh,
            EqualHigh
        }

        public enum WState
        {
            NoPattern,
            LowerLow,
            HigherLow,
            EqualLow
        }

        #region ---- Variables ---- 

        #region -- zigzag indicator -- 
        private int lastHighIdx = 0;
        private int lastLowIdx = 0;
        private int priorSwingHighIdx = 0;
        private int priorSwingLowIdx = 0;
        private int priorSwingHighIdx2 = 0;
        private int priorSwingLowIdx2 = 0;
        private int highCount = 0;
        private int lowCount = 0;
        private int preLastHighIdx = 0;
        private int preLastLowIdx = 0;
        private double zigzagDeviation = 0.0;
        private double currentHigh = 0.0;
        private double currentLow = 0.0;
        private double swingMax = 0.0;
        private double swingMin = 0.0;
        private int lastBreakUp = 0;
        private int lastBreakDown = 0;
        private bool addHigh = false;
        private bool updateHigh = false;
        private bool addLow = false;
        private bool updateLow = false;
        private MState mPattern = MState.NoPattern;
        private WState wPattern = WState.NoPattern;
        private bool intraBarAddHigh = false;
        private bool intraBarUpdateHigh = false;
        private bool intraBarAddLow = false;
        private bool intraBarUpdateLow = false;
        private int lastSignal = 0;

        private SimpleFont labelFont = null;
        private SimpleFont swingDotFont = null;
        private int LabelFontSize = 9;
        private int pixelOffset1 = 10;               //##HARD CODED##
        private int pixelOffset2 = 10;               //##HARD CODED##
        private Brush upColor = Brushes.LimeGreen;//##HARD CODED##
        private Brush downColor = Brushes.Red;      //##HARD CODED##
        private Brush doubleTopBottomColor = Brushes.Yellow;   //##HARD CODED##
        private string dotString = "n";              //##HARD CODED##

        private ATR avgTrueRange;
        private Series<double> swingInput;
        private Series<int> pre_swingHighType;
        private Series<int> pre_swingLowType;
        private Series<int> swingHighType;
        private Series<int> swingLowType;
        private Series<double> currentTop;
        private Series<double> currentBottom;
        private Series<bool> upTrend;
        private Series<double> zigzag;
        #endregion

        #region -- System Signal variables --
        private double BUY_SYSTEMSIGNAL = 1;
        private double SELL_SYSTEMSIGNAL = -1;
        private const int PATTERN_BREAK = 0;
        Brush BuyStripeBrush, SellStripeBrush;
        private int last_trade_signal_bar = -1;
        private int last_visible_bar = -1;
        string MsgOnChart = string.Empty;
        DateTime TimeOfMessagePrint = DateTime.MinValue;
        #endregion

        #endregion


        public override string DisplayName { get { return "ARC_PatternFinder"; } }

        #region -- Toolbar variables --
        private string toolbarname = "NSPatternFinderToolBar", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private Grid indytoolbar;

        private Menu MenuControlContainer;
        private MenuItem MenuControl;

        //private ComboBox comboMTF, comboZFM, comboProfile;
        private MenuItem miGeneral1, miGeneral2, miGeneral3, miGeneral4, miGeneral5, miGeneral6, miGeneral7;
        private MenuItem miMPatterns1, miMPatterns2, miMPatterns3, miMPatterns4;
        private MenuItem miWPatterns1, miWPatterns2, miWPatterns3, miWPatterns4;
        private MenuItem miPlan1, miPlan2, miPLan3, miRecalculate;
        private MenuItem miDivOptions1, miDivOptions2, miDivOptions3, miDivOptions4;
        private MenuItem miDisplayOptions1, miDisplayOptions2, miDisplayOptions3, miDisplayOptions4, miDisplayOptions5, miDisplayOptions6, miDisplayOptions7;
        private ComboBox comboExcursionStyle, comboFlooding;
        private TextBox nudMTF, nudZFM, nudMST1, nudMST2, nudCRV1, nudCRV2;

        private Button gCmdup;
        private Button gCmddw;
        private Label gLabel;
        #endregion

        #region -- Toolbar Management Utilities --
        #region private void addToolBar()
        private void addToolBar()
        {
            gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            gLabel = new Label();//#RJBug001

            MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
            MenuControl = new MenuItem {Name="NSPF"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.White, Header = pButtonText, Foreground = Brushes.White, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
            MenuControlContainer.Items.Add(MenuControl);

            MenuItem item;
            Separator separator;

            #region -- General --
            MenuItem miGeneral = new MenuItem { Header = "General", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miGeneral1 = new MenuItem { Header = "Show Historical Patterns " + (ShowHistoricalPatterns ? "ON" : "OFF"), Name = "btGeneral_historical"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral1.Click += General_Click;
            miGeneral.Items.Add(miGeneral1);

            miGeneral2 = new MenuItem { Header = "Show Current Pattern " + (ShowCurrentPattern ? "ON" : "OFF"), Name = "btGeneral_current"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral2.Click += General_Click;
            miGeneral.Items.Add(miGeneral2);

            miGeneral3 = new MenuItem { Header = "Show Swing Legs " + (ShowZigzagLegs ? "ON" : "OFF"), Name = "btGeneral_zigzag"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral3.Click += General_Click;
            miGeneral.Items.Add(miGeneral3);

            miGeneral4 = new MenuItem { Header = "Show Swing Labels " + (ShowSwingLabels ? "ON" : "OFF"), Name = "btGeneral_labels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral4.Click += General_Click;
            miGeneral.Items.Add(miGeneral4);

            miGeneral5 = new MenuItem { Header = "Anchor Legs " + (AnchorLegs ? "ON" : "OFF"), Name = "btGeneral_anchor"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral5.Click += General_Click;
            miGeneral.Items.Add(miGeneral5);

            miGeneral6 = new MenuItem { Header = "Use HH/LL " + (UseHHLL ? "ON" : "OFF"), Name = "btGeneral_hhll"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral6.Click += General_Click;
            miGeneral.Items.Add(miGeneral6);

            miGeneral7 = new MenuItem { Header = "Show Emerging Pattern " + (ShowEmergingPatterns ? "ON" : "OFF"), Name = "btGeneral_emerging"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral7.Click += General_Click;
            miGeneral.Items.Add(miGeneral7);

            miGeneral.Items.Add(createMSTMenu(MultiplierDTB.ToString(), SwingStrength.ToString()));
            //------------------

            MenuControl.Items.Add(miGeneral);
            #endregion

            #region -- M Patterns --
            MenuItem miMPatterns = new MenuItem { Header = "M Patterns", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miMPatterns1 = new MenuItem { Header = "Show M Patterns " + (ShowMPattern ? "ON" : "OFF"), Name = "btMPatterns_show"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miMPatterns1.Click += MPatterns_Click;
            miMPatterns.Items.Add(miMPatterns1);

            miMPatterns2 = new MenuItem { Header = "Lower High Break " + (LowerHighBreak ? "ON" : "OFF"), Name = "btMPatterns_lh"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miMPatterns2.Click += MPatterns_Click;
            miMPatterns.Items.Add(miMPatterns2);

            miMPatterns3 = new MenuItem { Header = "Higher High Break " + (HigherHighBreak ? "ON" : "OFF"), Name = "btMPatterns_hh"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miMPatterns3.Click += MPatterns_Click;
            miMPatterns.Items.Add(miMPatterns3);

            miMPatterns4 = new MenuItem { Header = "Equal High Break " + (EqualHighBreak ? "ON" : "OFF"), Name = "btMPatterns_eh"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miMPatterns4.Click += MPatterns_Click;
            miMPatterns.Items.Add(miMPatterns4);

            MenuControl.Items.Add(miMPatterns);
            #endregion

            #region -- W Patterns --
            MenuItem miWPatterns = new MenuItem { Header = "W Patterns", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miWPatterns1 = new MenuItem { Header = "Show W Patterns " + (ShowWPattern ? "ON" : "OFF"), Name = "btWPatterns_show"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miWPatterns1.Click += WPatterns_Click;
            miWPatterns.Items.Add(miWPatterns1);

            miWPatterns2 = new MenuItem { Header = "Lower Low Break " + (LowerLowBreak ? "ON" : "OFF"), Name = "btWPatterns_ll"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miWPatterns2.Click += WPatterns_Click;
            miWPatterns.Items.Add(miWPatterns2);

            miWPatterns3 = new MenuItem { Header = "Higher Low Break " + (HigherLowBreak ? "ON" : "OFF"), Name = "btWPatterns_hl"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miWPatterns3.Click += WPatterns_Click;
            miWPatterns.Items.Add(miWPatterns3);

            miWPatterns4 = new MenuItem { Header = "Equal Low Break " + (EqualLowBreak ? "ON" : "OFF"), Name = "btWPatterns_el"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miWPatterns4.Click += WPatterns_Click;
            miWPatterns.Items.Add(miWPatterns4);

            MenuControl.Items.Add(miWPatterns);
            #endregion

            //=============================================================================
            #region -- Show/Hide SL --
            this.miShowHide_SL = new MenuItem { Header = "SL is:   " + (pSLVisible ? "Showing" : "Hidden"), Name = "ShowHide_SL"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miShowHide_SL.Click += delegate (object o, RoutedEventArgs e) {
                #region -- Click --
                e.Handled = true;
                pSLVisible = !pSLVisible;
                miShowHide_SL.Header = "SL is:   " + (pSLVisible ? "Showing" : "Hidden");
				InformUserAboutRecalculation();
                #endregion
            };
            miShowHide_SL.MouseWheel += delegate (object o, MouseWheelEventArgs e) {
                #region -- Mousewheel --
                e.Handled = true;
                pSLVisible = !pSLVisible;
                miShowHide_SL.Header = "SL is:   " + (pSLVisible ? "Showing" : "Hidden");
				InformUserAboutRecalculation();
                #endregion
            };
            MenuControl.Items.Add(miShowHide_SL);
            #endregion
            //=============================================================================
            #region -- Show/Hide T1 --
            this.miShowHide_T1 = new MenuItem { Header = "T1 is:   " + (pT1Visible ? "Showing" : "Hidden"), Name = "ShowHide_T1"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miShowHide_T1.Click += delegate (object o, RoutedEventArgs e) {
                #region -- Click --
                e.Handled = true;
                pT1Visible = !pT1Visible;
                miShowHide_T1.Header = "T1 is:   " + (pT1Visible ? "Showing" : "Hidden");
				InformUserAboutRecalculation();
                #endregion
            };
            miShowHide_T1.MouseWheel += delegate (object o, MouseWheelEventArgs e) {
                #region -- Mousewheel --
                e.Handled = true;
                pT1Visible = !pT1Visible;
                miShowHide_T1.Header = "T1 is:   " + (pT1Visible ? "Showing" : "Hidden");
				InformUserAboutRecalculation();
                #endregion
            };
            MenuControl.Items.Add(miShowHide_T1);
            #endregion
            //=============================================================================
            #region -- Show/Hide T2 --
            this.miShowHide_T2 = new MenuItem { Header = "T2 is:   " + (pT2Visible ? "Showing" : "Hidden"), Name = "ShowHide_T2"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miShowHide_T2.Click += delegate (object o, RoutedEventArgs e) {
                #region -- Click --
                e.Handled = true;
                pT2Visible = !pT2Visible;
                miShowHide_T2.Header = "T2 is:   " + (pT2Visible ? "Showing" : "Hidden");
				InformUserAboutRecalculation();
                #endregion
            };
            miShowHide_T2.MouseWheel += delegate (object o, MouseWheelEventArgs e) {
                #region -- Mousewheel --
                e.Handled = true;
                pT2Visible = !pT2Visible;
                miShowHide_T2.Header = "T2 is:   " + (pT2Visible ? "Showing" : "Hidden");
				InformUserAboutRecalculation();
                #endregion
            };
            MenuControl.Items.Add(miShowHide_T2);
            #endregion
            //=============================================================================
            #region -- SL ticks --
            this.miSLTicks = new MenuItem { Header = "SL Ticks:   " + pSLTicks.ToString(), Name = "SLTicks"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };

            miSLTicks.Click += delegate (object o, RoutedEventArgs e) {
                #region -- Click --
                e.Handled = true;
                pSLTicks++;
                miSLTicks.Header = "SL Ticks:   " + pSLTicks.ToString();
				InformUserAboutRecalculation();
                #endregion
            };
            miSLTicks.MouseWheel += delegate (object o, MouseWheelEventArgs e) {
                #region -- Mousewheel --
                e.Handled = true;
                if (e.Delta > 0)
                    pSLTicks++;
                else
                    pSLTicks--;
                miSLTicks.Header = "SL Ticks:   " + pSLTicks.ToString();
				InformUserAboutRecalculation();
                #endregion
            };
            MenuControl.Items.Add(miSLTicks);
            #endregion
            //=============================================================================
            #region -- T1 ticks --
            this.miT1Ticks = new MenuItem { Header = "T1 Ticks:   " + pT1Ticks.ToString(), Name = "T1Ticks"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };

            miT1Ticks.Click += delegate (object o, RoutedEventArgs e) {
                #region -- Click --
                e.Handled = true;
                pT1Ticks++;
                miT1Ticks.Header = "T1 Ticks:   " + pT1Ticks.ToString();
				InformUserAboutRecalculation();
                #endregion
            };
            miT1Ticks.MouseWheel += delegate (object o, MouseWheelEventArgs e) {
                #region -- Mousewheel --
                e.Handled = true;
                if (e.Delta > 0)
                    pT1Ticks++;
                else
                    pT1Ticks--;
                miT1Ticks.Header = "T1 Ticks:   " + pT1Ticks.ToString();
				InformUserAboutRecalculation();
                #endregion
            };
            MenuControl.Items.Add(miT1Ticks);
            #endregion
            //=============================================================================
            #region -- T2 ticks --
            this.miT2Ticks = new MenuItem { Header = "T2 Ticks:   " + pT2Ticks.ToString(), Name = "T2Ticks"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };

            miT2Ticks.Click += delegate (object o, RoutedEventArgs e) {
                #region -- Click --
                e.Handled = true;
                pT2Ticks++;
                miT2Ticks.Header = "T2 Ticks:   " + pT2Ticks.ToString();
				InformUserAboutRecalculation();
                #endregion
            };
            miT2Ticks.MouseWheel += delegate (object o, MouseWheelEventArgs e) {
                #region -- Mousewheel --
                e.Handled = true;
                if (e.Delta > 0)
                    pT2Ticks++;
                else
                    pT2Ticks--;
                miT2Ticks.Header = "T2 Ticks:   " + pT2Ticks.ToString();
				InformUserAboutRecalculation();
                #endregion
            };
            MenuControl.Items.Add(miT2Ticks);
            #endregion
            //=============================================================================
            #region -- Racing Stripes ticks --
            this.miShowHide_RacingStripes = new MenuItem { Header = "Racing Stripes:  " + (pShowRacingStripes ? "ON" : "OFF"), Name = "ShowHide_RacingStripes"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };

            miShowHide_RacingStripes.Click += delegate (object o, RoutedEventArgs e) {
                #region -- Click --
                e.Handled = true;
                pShowRacingStripes = !pShowRacingStripes;
                miShowHide_RacingStripes.Header = "Racing Stripes:  " + (pShowRacingStripes ? "ON" : "OFF");

                if (pShowRacingStripes && this.pSellStripeOpacity == 0 && pBuyStripeOpacity == 0)
                {
                    MsgOnChart = "Racing stripe opacities are currently '0'\nNo stripes will show until you increase those opacities";
                }
				InformUserAboutRecalculation();
                #endregion
            };
            miShowHide_RacingStripes.MouseWheel += delegate (object o, MouseWheelEventArgs e) {
                #region -- Mousewheel --
                e.Handled = true;
                if (e.Delta > 0)
                    pShowRacingStripes = !pShowRacingStripes;
                else
                    pShowRacingStripes = !pShowRacingStripes;
                miShowHide_RacingStripes.Header = "Racing Stripes:  " + (pShowRacingStripes ? "ON" : "OFF");
				InformUserAboutRecalculation();

                if (pShowRacingStripes && this.pSellStripeOpacity == 0 && pBuyStripeOpacity == 0)
                {
                    MsgOnChart = "Racing stripe opacities are '0', no stripes will show until you increase those opacities";
                }
				InformUserAboutRecalculation();
                #endregion
            };
            MenuControl.Items.Add(miShowHide_RacingStripes);
            #endregion
            //=============================================================================

            separator = new Separator();
            MenuControl.Items.Add(separator);

            miRecalculate = new MenuItem { Header = "RE-CALCULATE PATTERNS", Name = "patternsClick"+uID, HorizontalAlignment = HorizontalAlignment.Center, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = false };
            miRecalculate.Click += ReloadChart_Click;
            MenuControl.Items.Add(miRecalculate);

            indytoolbar.Children.Add(MenuControlContainer);
        }
        #endregion

        private Grid createMSTMenu(string nudValue1, string nudValue2)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(55) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - MST1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Sensitivity :" };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudMST1 = new TextBox() { Name = "MultiplierDTB_tb" + uID, MinWidth = 60, Width = 60, MaxWidth = 60, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST1.Text = nudValue1;
            nudMST1.KeyDown += menuTxtbox_KeyDown;
            nudMST1.TextChanged += NumericUpDownValueChanged;
			nudMST1.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				MultiplierDTB = (e.Delta>0 ? MultiplierDTB+0.1 : Math.Max(0,MultiplierDTB-0.1));
				nudMST1.Text = MultiplierDTB.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			nudMST1.SetValue(Grid.ColumnProperty, 1);
            nudMST1.SetValue(Grid.ColumnSpanProperty, 2);
            nudMST1.SetValue(Grid.RowProperty, 0);
            nudMST1.SetValue(Grid.RowSpanProperty, 2);

            //line 2 - MST2
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Strength : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudMST2 = new TextBox() { Name = "SwingStrength_tb" + uID, MinWidth = 50, Width = 50, MaxWidth = 50, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST2.Text = nudValue2;
            nudMST2.KeyDown += menuTxtbox_KeyDown;
            nudMST2.TextChanged += NumericUpDownValueChanged;
			nudMST2.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				SwingStrength = (e.Delta>0 ? SwingStrength+1 : Math.Max(1,SwingStrength-1));
				nudMST2.Text = SwingStrength.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
			};
            nudMST2.SetValue(Grid.ColumnProperty, 1);
            nudMST2.SetValue(Grid.RowProperty, 2);
            nudMST2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = "SStr_cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = "SStr_cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 2);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMST1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudMST2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            return grid;
        }

        //---------- Events ------------------------------------------------
        #region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #region -- DoubleEditKeyPress -- 
        private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtSender = sender as TextBox;

            int keyVal = (int)e.Key;
            int value = -1;
            if (keyVal >= (int)Key.D0 && keyVal <= (int)Key.D9) value = keyVal - (int)Key.D0;
            else if (keyVal >= (int)Key.NumPad0 && keyVal <= (int)Key.NumPad9) value = keyVal - (int)Key.NumPad0;

            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);

            if (isNumeric || e.Key == Key.Back || (e.Key == Key.Decimal && txtSender.Name == "MultiplierDTB_tb"))
            {
                string newText = value != -1 ? value.ToString() : e.Key == Key.Decimal ? System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator : "";
                int tbPosition = txtSender.SelectionStart;
                txtSender.Text = txtSender.SelectedText == "" ? txtSender.Text.Insert(tbPosition, newText) : txtSender.Text.Replace(txtSender.SelectedText, newText);
                txtSender.Select(tbPosition + 1, 0);
				InformUserAboutRecalculation();
            }
        }
        #endregion

        #region -- DoubleEditTextChanged --
        private string currentTextEdit;
        private void NumericUpDownValueChanged(object sender, EventArgs e)
        {
            TextBox txtSender = sender as TextBox;
            if (txtSender.Text.Length > 0)
            {
                float result;
                bool isNumeric = float.TryParse(txtSender.Text, out result);

                if (isNumeric) currentTextEdit = txtSender.Text;
                else
                {
                    txtSender.Text = currentTextEdit;
                    txtSender.Select(txtSender.Text.Length, 0);
                }
//Print("Sender name: "+txtSender.Name+"   value: "+txtSender.Text);
                if (txtSender.Name.StartsWith("MultiplierDTB_tb")) MultiplierDTB = Convert.ToDouble(nudMST1.Text);
                else if (txtSender.Name.StartsWith("SwingStrength_tb")) SwingStrength = Convert.ToInt32(nudMST2.Text);
				InformUserAboutRecalculation();
            }
        }
        #endregion

        #region private void cmdupdw_Click(object sender, RoutedEventArgs e)
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
            Button cmd = sender as Button;
            if (cmd.Name.Contains("SStr_cmdup")) nudMST2.Text = (Math.Min(999999999, Convert.ToInt32(nudMST2.Text) + 1)).ToString();
            else if (cmd.Name.Contains("SStr_cmddw")) nudMST2.Text = (Math.Max(1, Convert.ToInt32(nudMST2.Text) - 1)).ToString();
			InformUserAboutRecalculation();
        }
        #endregion

        #region -- General_Click --
        private void General_Click(object sender, EventArgs e)
        {

            MenuItem item = sender as MenuItem;

			if (item != null && item.Name.StartsWith("btGeneral_historical")) ShowHistoricalPatterns = !ShowHistoricalPatterns;
            else if (item != null && item.Name.StartsWith("btGeneral_current")) ShowCurrentPattern = !ShowCurrentPattern;
            else if (item != null && item.Name.StartsWith("btGeneral_emerging")) ShowEmergingPatterns = !ShowEmergingPatterns;
            else if (item != null && item.Name.StartsWith("btGeneral_zigzag")) ShowZigzagLegs = !ShowZigzagLegs;
            else if (item != null && item.Name.StartsWith("btGeneral_labels")) ShowSwingLabels = !ShowSwingLabels;
            else if (item != null && item.Name.StartsWith("btGeneral_anchor")) AnchorLegs = !AnchorLegs;
            else if (item != null && item.Name.StartsWith("btGeneral_hhll")) UseHHLL = !UseHHLL;

            miGeneral1.Header = "Show Historical Patterns " + (ShowHistoricalPatterns ? "ON" : "OFF");
            miGeneral2.Header = "Show Current Pattern " + (ShowCurrentPattern ? "ON" : "OFF");
            miGeneral3.Header = "Show Swing Legs " + (ShowZigzagLegs ? "ON" : "OFF");
            miGeneral4.Header = "Show Swing Labels " + (ShowSwingLabels ? "ON" : "OFF");
            miGeneral5.Header = "Anchor Legs " + (AnchorLegs ? "ON" : "OFF");
            miGeneral6.Header = "Use HH/LL " + (UseHHLL ? "ON" : "OFF");
            miGeneral7.Header = "Show Emerging Pattern " + (ShowEmergingPatterns ? "ON" : "OFF");
			InformUserAboutRecalculation();
        }
        #endregion

        #region -- MPatterns_Click --
        private void MPatterns_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //----------- Divergences Options -------------------
            if (item != null && item.Name.StartsWith("btMPatterns_show")) ShowMPattern = !ShowMPattern;
            else if (item != null && item.Name.StartsWith("btMPatterns_lh")) LowerHighBreak = !LowerHighBreak;
            else if (item != null && item.Name.StartsWith("btMPatterns_hh")) HigherHighBreak = !HigherHighBreak;
            else if (item != null && item.Name.StartsWith("btMPatterns_eh")) EqualHighBreak = !EqualHighBreak;

            miMPatterns1.Header = "Show M Patterns " + (ShowMPattern ? "ON" : "OFF");
            miMPatterns2.Header = "Lower High Break " + (LowerHighBreak ? "ON" : "OFF");
            miMPatterns3.Header = "Higher High Break " + (HigherHighBreak ? "ON" : "OFF");
            miMPatterns4.Header = "Equal High Break " + (EqualHighBreak ? "ON" : "OFF");
			InformUserAboutRecalculation();
        }

        #endregion

        #region -- WPatterns_Click --
        private void WPatterns_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //----------- Divergences Options -------------------
            if (item != null && item.Name.StartsWith("btWPatterns_show")) ShowWPattern = !ShowWPattern;
            else if (item != null && item.Name.StartsWith("btWPatterns_ll")) LowerLowBreak = !LowerLowBreak;
            else if (item != null && item.Name.StartsWith("btWPatterns_hl")) HigherLowBreak = !HigherLowBreak;
            else if (item != null && item.Name.StartsWith("btWPatterns_el")) EqualLowBreak = !EqualLowBreak;

            miWPatterns1.Header = "Show W Patterns " + (ShowWPattern ? "ON" : "OFF");
            miWPatterns2.Header = "Lower Low Break " + (LowerLowBreak ? "ON" : "OFF");
            miWPatterns3.Header = "Higher Low Break " + (HigherLowBreak ? "ON" : "OFF");
            miWPatterns4.Header = "Equal Low Break " + (EqualLowBreak ? "ON" : "OFF");
			InformUserAboutRecalculation();
        }

        #endregion

        #region -- ReloadChart_Click --
        private void ReloadChart_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //----------- Market Structure -------------------
            if (item.Name.StartsWith("marketStructureClick"))
            {
                try
                {
                    MultiplierDTB = Math.Max(0, Convert.ToDouble(nudMST1.Text));
                    SwingStrength = Math.Max(1, Convert.ToInt32(nudMST2.Text));
                }
                catch (Exception) { }
            }

			ResetRecalculationUI();
            System.Windows.Forms.SendKeys.SendWait("{F5}");
        }
        #endregion

//=====================================================================================================
		private void InformUserAboutRecalculation(){
			miRecalculate.Background = Brushes.Yellow;
			miRecalculate.FontWeight = FontWeights.Bold;
			miRecalculate.FontStyle = FontStyles.Italic;
		}
		private void ResetRecalculationUI(){
			miRecalculate.FontWeight = FontWeights.Normal;
			miRecalculate.FontStyle = FontStyles.Normal;
			miRecalculate.Background = null;
		}
        #region -- ModifyDisplayOptionsSetting_Click --
        private void ModifyDisplayOptionsSetting_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //-----------Market Structure------------------ -
            if (item.Name.StartsWith("marketStructureClick"))
            {
                MultiplierDTB = Convert.ToDouble(nudMST1.Text);
                SwingStrength = Convert.ToInt16(nudMST2.Text);
            }
        }
        #endregion

        #endregion

        #region -- System Signal classes and methods --
        private MenuItem miSignalType, miSLTicks, miT1Ticks, miT2Ticks;
        private MenuItem miShowHide_TradePlan, miShowHide_HistTPMarkers, miShowHide_CurTPMarkers, miShowHide_SL, miShowHide_T1, miShowHide_T2, miShowHide_RacingStripes;
        static string RayTemplates_folder = null;
        //================================================================================================================================================
        #endregion

        protected override void OnStateChange()
		{
            //Print("State = " + State.ToString());
            #region State == State.SetDefaults 
            if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "ARC_PatternFinder";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
                MaximumBarsLookBack                         = MaximumBarsLookBack.Infinite;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive		= true;
				ShowMPattern					= true;
				ShowWPattern					= true;
				ShowHistoricalPatterns			= true;
				ShowCurrentPattern				= true;
                ShowSwingLabels = true;
                SwingStrength = 3;
                MultiplierMD  = 0;
                MultiplierDTB = 0.1;
                SwingLegWidth = 2;
                ShowZigzagLegs = false;
				pBarsLookback  = 500;
                SwingLegStyle  = DashStyleHelper.Solid;
                LowerHighBreak = true;
				HigherHighBreak					= true;
				EqualHighBreak					= true;
				LowerLowBreak					= true;
				HigherLowBreak					= true;
				EqualLowBreak					= true;
				MPatternColor					= Brushes.RoyalBlue;
				WPatternColor					= Brushes.Orange;
                AnchorLegs = false;
                UseHHLL = false;
                pButtonText = "Pattern Finder";
                SwingLegWidthEm = 1;
                ShowEmergingPatterns = true;
                SwingLegStyleEm = DashStyleHelper.Dash;
                LongPatternColorEm = Brushes.RoyalBlue;
                ShortPatternColorEm = Brushes.Orange;
                uID = DateTime.Now.Ticks.ToString();//prevent multiple toolbar with same name
                AddPlot(new Stroke(Brushes.Transparent, 4), PlotStyle.TriangleUp, "SignalUp");
				AddPlot(new Stroke(Brushes.Transparent, 4), PlotStyle.TriangleDown, "SignalDown");
                AddPlot(new Stroke(Brushes.Transparent, 0.1f), PlotStyle.Line, "SystemSignal");

                #region -- System Signals & TradePlan variables --
                pSLTicks = 10;
                pT1Ticks = 10;
                pT2Ticks = 15;
                pTradePlanVisible = true;
                pSLVisible = true;
                pT1Visible = true;
                pT2Visible = true;
                pBuyBrush = Brushes.Lime;
                pSellBrush = Brushes.Magenta;
                pSLBrush = Brushes.Yellow;
                pT1Brush = Brushes.Blue;
                pT2Brush = Brushes.Cyan;
                pFlagTextBrush = Brushes.Cyan;
                pFlagBkgBrush = Brushes.Navy;
                pBuyStripeBrush = Brushes.Green;
                pBuyStripeOpacity = 60;
                pSellStripeBrush = Brushes.Maroon;
                pSellStripeOpacity = 60;
                pTextFont = new SimpleFont("Arial", 12);
                pMarkerOffset = 1;
                pShowRacingStripes = false;
                pBuySoundWAV = "SOUND OFF";
                pSellSoundWAV = "SOUND OFF";
                #endregion
            }
            #endregion

            #region State == State.Configure  
            else if (State == State.Configure)
            {
				IsDebug = System.IO.File.Exists(@"c:\222222222222.txt");
				IsDebug = IsDebug && (NinjaTrader.Cbi.License.MachineId.CompareTo("1E53E271B82EC62C7C03A15C336229AE")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion

                #region INIT Fonts  
                labelFont = new SimpleFont("Arial", LabelFontSize);
                //swingDotFont = new SimpleFont("Webdings", SwingDotSize) { Bold = true };
                //dataFont1 = new SimpleFont("Arial", Math.Max(1, DataFontSize - 2)) { Bold = true };
                //dataFont2 = new SimpleFont("Arial", DataFontSize) { Bold = true };

                #endregion

            }
            #endregion

            #region State == State.DataLoaded
            else if(State == State.DataLoaded)
            {
                #region INIT Series  
                swingInput = new Series<double>(this);
                pre_swingHighType = new Series<int>(this);
                pre_swingLowType = new Series<int>(this);
                swingHighType = new Series<int>(this);
                swingLowType = new Series<int>(this);
                currentBottom = new Series<double>(this);
                currentTop = new Series<double>(this);
                upTrend = new Series<bool>(this);
                zigzag = new Series<double>(this);

                #endregion

                #region INIT external Series  
                avgTrueRange = ATR(256);
                #endregion
            }
            #endregion

            #region State == State.Historical  
            else if (State == State.Historical)
            {
                BuyStripeBrush = pBuyStripeBrush.Clone();
                BuyStripeBrush.Opacity = this.pBuyStripeOpacity / 100.0f;
                BuyStripeBrush.Freeze();
                SellStripeBrush = pSellStripeBrush.Clone();
                SellStripeBrush.Opacity = this.pSellStripeOpacity / 100.0f;
                SellStripeBrush.Freeze();

                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;

                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new Grid { Visibility = Visibility.Collapsed };

                            addToolBar();

                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                            foreach (TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion
            }
            #endregion

            #region State == State.Terminated
            else if (State == State.Terminated)
            {
                if (chartWindow != null)
                {
                    if (indytoolbar != null)
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            chartWindow.MainMenu.Remove(indytoolbar);
                            indytoolbar = null;

                            chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
                            chartWindow = null;
                        }));
                    }
                }
            }
            #endregion
        }

		private void drawText(string tag, bool autoscale, string Txt, int rbar, double price, int fontsize, Brush txtBrush){
			//TriggerCustomEvent(o1 =>{
				Draw.Text(this, tag, autoscale, Txt, rbar, price, fontsize, txtBrush, labelFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
			//},0,null);
		}

        protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
try{
            #region -- Calculate ZigZag --

            bool drawSwingLegUp = false;
            bool drawSwingLegDown = false;

            #region -- Init zigzag states --    
            if (CurrentBar < 2)
            {
                upTrend[0] = true;
                pre_swingHighType[0] = 0;
                pre_swingLowType[0] = 0;
                swingHighType[0] = 0;
                swingLowType[0] = 0;
            }
            #endregion

            #region else if (Calculate == Calculate.OnBarClose)
            else if (Calculate == Calculate.OnBarClose)
            {
                bool useHL = true;

                zigzagDeviation = MultiplierMD * avgTrueRange[0];
                swingMax = MAX(useHL ? High : Input, SwingStrength)[1];
                swingMin = MIN(useHL ? Low : Input, SwingStrength)[1];

                pre_swingHighType[0] = 0;
                pre_swingLowType[0] = 0;
                swingHighType[0] = 0;
                swingLowType[0] = 0;
                currentBottom[0] = 0;
                currentTop[0] = 0;
                zigzag[0] = 0;

                updateHigh = upTrend[1] && (useHL ? High[0] : swingInput[0]) > currentHigh;
                updateLow = !upTrend[1] && (useHL ? Low[0] : swingInput[0]) < currentLow;
                addHigh = !upTrend[1] && !((useHL ? Low[0] : swingInput[0]) < currentLow) && (useHL ? High[0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                addLow = upTrend[1] && !((useHL ? High[0] : swingInput[0]) > currentHigh) && (useHL ? Low[0] : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

                upTrend[0] = upTrend[1];

                #region -- New High --
                if (addHigh)
                {
                    upTrend[0] = true;
                    int lookback = CurrentBar - lastLowIdx;
                    swingLowType[lookback] = pre_swingLowType[lookback];
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - lastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : swingInput[i]) > newHigh)
                        {
                            newHigh = (useHL ? High[i] : swingInput[i]);
                            j = i;
                        }
                    }
                    currentHigh = newHigh;
                    priorSwingHighIdx2 = priorSwingHighIdx;
                    priorSwingHighIdx = lastHighIdx;
                    lastHighIdx = CurrentBar - j;

                    if (priorSwingHighIdx2 > 0)
                    {
                        double marginUp = (useHL ? High[CurrentBar - priorSwingHighIdx2] : swingInput[CurrentBar - priorSwingHighIdx2]) + MultiplierDTB * avgTrueRange[highCount];
                        double marginDown = (useHL ? High[CurrentBar - priorSwingHighIdx2] : swingInput[CurrentBar - priorSwingHighIdx2]) - MultiplierDTB * avgTrueRange[highCount];

                        if (High[CurrentBar - priorSwingHighIdx] > marginUp)
                        {
                            mPattern = MState.HigherHigh;
                        }
                        else if (High[CurrentBar - priorSwingHighIdx] < marginDown)
                        {
                            mPattern = MState.LowerHigh;
                        }
                        else
                        {
                            mPattern = MState.EqualHigh;
                        }
                    }
                }
                #endregion

                #region -- uptrend --
                else if (updateHigh)
                {
                    upTrend[0] = true;
                    pre_swingHighType[CurrentBar - lastHighIdx] = 0;
                    currentHigh = (useHL ? High[0] : swingInput[0]);
                    lastHighIdx = CurrentBar;
                }
                #endregion

                #region -- New Low --
                else if (addLow)
                {
                    upTrend[0] = false;
                    int lookback = CurrentBar - lastHighIdx;
                    swingHighType[lookback] = pre_swingHighType[lookback];
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - lastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : swingInput[i]) < newLow)
                        {
                            newLow = (useHL ? Low[i] : swingInput[i]);
                            j = i;
                        }
                    }
                    currentLow = newLow;
                    priorSwingLowIdx2 = priorSwingLowIdx;
                    priorSwingLowIdx = lastLowIdx;
                    lastLowIdx = CurrentBar - j;

                    if (priorSwingLowIdx2 > 0)
                    {
                        double marginUp = (useHL ? Low[CurrentBar - priorSwingLowIdx2] : swingInput[CurrentBar - priorSwingLowIdx2]) + MultiplierDTB * avgTrueRange[highCount];
                        double marginDown = (useHL ? Low[CurrentBar - priorSwingLowIdx2] : swingInput[CurrentBar - priorSwingLowIdx2]) - MultiplierDTB * avgTrueRange[highCount];

                        if (Low[CurrentBar - priorSwingLowIdx] < marginDown)
                        {
                            wPattern = WState.LowerLow;
                        }
                        else if (Low[CurrentBar - priorSwingLowIdx] > marginUp)
                        {
                            wPattern = WState.HigherLow;
                        }
                        else
                        {
                            wPattern = WState.EqualLow;
                        }
                    }
                }
                #endregion

                #region -- dwtrend --
                else if (updateLow)
                {
                    upTrend[0] = false;
                    pre_swingLowType[CurrentBar - lastLowIdx] = 0;
                    currentLow = (useHL ? Low[0] : swingInput[0]);
                    lastLowIdx = CurrentBar;
                }
                #endregion

                int priorHighCount2 = CurrentBar - priorSwingHighIdx2;
                int priorLowCount2 = CurrentBar - priorSwingLowIdx2;
                int priorHighCount = CurrentBar - priorSwingHighIdx;
                int priorLowCount = CurrentBar - priorSwingLowIdx;

                #region -- UP || HH --
                if (addHigh || updateHigh)
                {
                    highCount = CurrentBar - lastHighIdx;
                    lowCount = CurrentBar - lastLowIdx;

                    double marginUp = (useHL ? High[priorHighCount] : swingInput[priorHighCount]) + MultiplierDTB * avgTrueRange[highCount];
                    double marginDown = (useHL ? High[priorHighCount] : swingInput[priorHighCount]) - MultiplierDTB * avgTrueRange[highCount];

                    #region -- Set NEW drawing states --

                    drawSwingLegUp = true;
                    //Print("Up: HighCount: " + highCount + ", LowCount: " + lowCount + ", priorHigh: " + priorHighCount + ", priorLow: " + priorLowCount);

                    if (currentHigh > marginUp)
                    {
                        pre_swingHighType[highCount] = 3;
                    }
                    else if (currentHigh < marginDown)
                    {
                        pre_swingHighType[highCount] = 1;
                    }
                    else
                    {
                        pre_swingHighType[highCount] = 2;
                    }

                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (addLow || updateLow)
                {
                    lowCount = CurrentBar - lastLowIdx;
                    highCount = CurrentBar - lastHighIdx;

                    double marginDown = (useHL ? Low[priorLowCount] : swingInput[priorLowCount]) - MultiplierDTB * avgTrueRange[lowCount];
                    double marginUp = (useHL ? Low[priorLowCount] : swingInput[priorLowCount]) + MultiplierDTB * avgTrueRange[lowCount];

                    #region -- Set NEW drawing states --

                    drawSwingLegDown = true;
                    //Print("Down: HighCount: " + highCount + ", LowCount: " + lowCount + ", priorHigh: " + priorHighCount + ", priorLow: " + priorLowCount);
                    if (currentLow < marginDown)
                    {
                        pre_swingLowType[lowCount] = -3;
                    }
                    else if (currentLow > marginUp)
                    {
                        pre_swingLowType[lowCount] = -1;
                    }
                    else
                    {
                        pre_swingLowType[lowCount] = -2;
                    }
                    #endregion
                }
                #endregion

                if (priorSwingHighIdx >= lastBreakUp && ShowMPattern)
                {
                    double l;
                    if(priorLowCount < priorHighCount)
                    {
                        l = Low[priorLowCount2];
                    }
                    else
                    {
                        l = Low[priorLowCount];
                    }
                    bool IsAnchorLeg = (Math.Max(High[priorHighCount], High[priorHighCount2]) - l) / (Math.Min(High[priorHighCount], High[priorHighCount2]) - l) > 2;
                    if (!IsAnchorLeg || AnchorLegs)
                    {
                        if (mPattern == MState.HigherHigh && HigherHighBreak)
                        {
                            currentTop[0] = Math.Max(High[priorHighCount], High[priorHighCount2]);
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingHighIdx.ToString() : "nspf";
								drawText(tag, true,"HH", priorHighCount, High[priorHighCount], (int)labelFont.Size+pixelOffset1, MPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, true, "HH", priorHighCount, High[priorHighCount], (int)(labelFont.Size) + pixelOffset1, MPatternColor, labelFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                            }
                        }
                        else if (mPattern == MState.LowerHigh && LowerHighBreak)
                        {
                            currentTop[0] = UseHHLL ? Math.Max(High[priorHighCount], High[priorHighCount2]) : High[priorHighCount];
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingHighIdx.ToString() : "nspf";
								drawText(tag, true,"LH", priorHighCount, High[priorHighCount], (int)labelFont.Size+pixelOffset1, MPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, true, "LH", priorHighCount, High[priorHighCount], (int)(labelFont.Size) + pixelOffset1, MPatternColor, labelFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                            }
                        }
                        else if (mPattern == MState.EqualHigh && EqualHighBreak)
                        {
                            currentTop[0] = Math.Max(High[priorHighCount], High[priorHighCount2]);
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingHighIdx.ToString() : "nspf";
								drawText(tag, true,"EH", priorHighCount, High[priorHighCount], (int)labelFont.Size+pixelOffset1, MPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, true, "EH", priorHighCount, High[priorHighCount], (int)(labelFont.Size) + pixelOffset1, MPatternColor, labelFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                            }
                        }
                    }
                }

                if (priorSwingLowIdx >= lastBreakDown && ShowWPattern)
                {
                    double h;
                    if (priorHighCount < priorLowCount)
                    {
                        h = High[priorHighCount2];
                    }
                    else
                    {
                        h = High[priorHighCount];
                    }
                    bool IsAnchorLeg = (h - Math.Min(Low[priorLowCount], Low[priorLowCount2])) / (h - Math.Max(Low[priorLowCount], Low[priorLowCount2])) > 2;
                    if (!IsAnchorLeg || AnchorLegs)
                    {
                        if (wPattern == WState.LowerLow && LowerLowBreak)
                        {
                            currentBottom[0] = Math.Min(Low[priorLowCount], Low[priorLowCount2]);
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingLowIdx.ToString() : "nspf";
								drawText(tag, true,"LL", priorLowCount, Low[priorLowCount], -(int)labelFont.Size-pixelOffset1, WPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, true, "LL", priorLowCount, Low[priorLowCount], -(int)(labelFont.Size) - pixelOffset1, WPatternColor, labelFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                            }
                        }
                        else if (wPattern == WState.HigherLow && HigherLowBreak)
                        {
                            currentBottom[0] = UseHHLL ? Math.Min(Low[priorLowCount], Low[priorLowCount2]) : Low[priorLowCount];
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingLowIdx.ToString() : "nspf";
								drawText(tag, true,"HL", priorLowCount, Low[priorLowCount], -(int)labelFont.Size-pixelOffset1, WPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, true, "HL", priorLowCount, Low[priorLowCount], -(int)(labelFont.Size) - pixelOffset1, WPatternColor, labelFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                            }
                        }
                        else if (wPattern == WState.EqualLow && EqualLowBreak)
                        {
                            currentBottom[0] = Math.Min(Low[priorLowCount], Low[priorLowCount2]);
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingLowIdx.ToString() : "nspf";
								drawText(tag, true,"EL", priorLowCount, Low[priorLowCount], -(int)labelFont.Size-pixelOffset1, WPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, true, "EL", priorLowCount, Low[priorLowCount], -(int)(labelFont.Size) - pixelOffset1, WPatternColor, labelFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                            }
                        }
                    }
                }
            }
            #endregion

            #region else if (IsFirstTickOfBar)
            else if (IsFirstTickOfBar)
            {
                bool useHL = true;
                zigzagDeviation = MultiplierMD * avgTrueRange[1];
                swingMax = MAX(useHL ? High : Input, SwingStrength)[2];
                swingMin = MIN(useHL ? Low : Input, SwingStrength)[2];

                pre_swingHighType[0] = 0;
                pre_swingLowType[0] = 0;
                swingHighType[0] = 0;
                swingLowType[0] = 0;

                updateHigh = upTrend[1] && (useHL ? High[1] : swingInput[1]) > currentHigh;
                updateLow = !upTrend[1] && (useHL ? Low[1] : swingInput[1]) < currentLow;
                addHigh = !upTrend[1] && !((useHL ? Low[1] : swingInput[1]) < currentLow) && (useHL ? High[1] : swingInput[1]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                addLow = upTrend[1] && !((useHL ? High[1] : swingInput[1]) > currentHigh) && (useHL ? Low[1] : swingInput[1]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

                upTrend[0] = upTrend[1];

                #region -- New High --
                if (addHigh)
                {
                    upTrend[0] = true;
                    int lookback = CurrentBar - lastLowIdx;
                    swingLowType[lookback] = pre_swingLowType[lookback];
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 1; i < CurrentBar - lastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : swingInput[i]) > newHigh)
                        {
                            newHigh = (useHL ? High[i] : swingInput[i]);
                            j = i;
                        }
                    }
                    currentHigh = newHigh;
                    priorSwingHighIdx2 = priorSwingHighIdx;
                    priorSwingHighIdx = lastHighIdx;
                    lastHighIdx = CurrentBar - j;
                }
                #endregion

                #region -- UPtrend --
                else if (updateHigh)
                {
                    upTrend[0] = true;
                    pre_swingHighType[CurrentBar - lastHighIdx] = 0;
                    currentHigh = (useHL ? High[1] : swingInput[1]);
                    lastHighIdx = CurrentBar - 1;
                }
                #endregion

                #region -- New Low --
                else if (addLow)
                {
                    upTrend[0] = false;
                    int lookback = CurrentBar - lastHighIdx;
                    swingHighType[lookback] = pre_swingHighType[lookback];
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 1; i < CurrentBar - lastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : swingInput[i]) < newLow)
                        {
                            newLow = (useHL ? Low[i] : swingInput[i]);
                            j = i;
                        }
                    }
                    currentLow = newLow;
                    priorSwingLowIdx2 = priorSwingLowIdx;
                    priorSwingLowIdx = lastLowIdx;
                    lastLowIdx = CurrentBar - j;
                }
                #endregion

                #region -- DWtrend --
                else if (updateLow)
                {
                    upTrend[0] = false;
                    pre_swingLowType[CurrentBar - lastLowIdx] = 0;
                    currentLow = useHL ? Low[1] : swingInput[1];
                    lastLowIdx = CurrentBar - 1;
                }
                #endregion

                int priorHighCount2 = CurrentBar - priorSwingHighIdx2;
                int priorLowCount2 = CurrentBar - priorSwingLowIdx2;
                int priorHighCount = CurrentBar - priorSwingHighIdx;
                int priorLowCount = CurrentBar - priorSwingLowIdx;

                #region re-init drawing states at each new bar before calculous
                mPattern = MState.NoPattern;
                wPattern = WState.NoPattern;
                #endregion

                #region -- UP || HH --
                if (addHigh || updateHigh)
                {
                    highCount = CurrentBar - lastHighIdx;
                    lowCount = CurrentBar - lastLowIdx;

                    double marginUp = (useHL ? High[priorHighCount] : swingInput[priorHighCount]) + MultiplierDTB * avgTrueRange[highCount];
                    double marginDown = (useHL ? High[priorHighCount] : swingInput[priorHighCount]) - MultiplierDTB * avgTrueRange[highCount];

                    #region -- Set NEW drawing states --

                    drawSwingLegUp = true;

                    if (currentHigh > marginUp)
                    {
                        pre_swingHighType[highCount] = 3;
                        mPattern = MState.HigherHigh;
                    }
                    else if (currentHigh < marginDown)
                    {
                        pre_swingHighType[highCount] = 1;
                        mPattern = MState.LowerHigh;
                    }
                    else
                    {
                        pre_swingHighType[highCount] = 2;
                        mPattern = MState.EqualHigh;
                    }
                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (addLow || updateLow)
                {
                    lowCount = CurrentBar - lastLowIdx;
                    highCount = CurrentBar - lastHighIdx;

                    double marginDown = (useHL ? Low[priorLowCount] : swingInput[priorLowCount]) - MultiplierDTB * avgTrueRange[lowCount];
                    double marginUp = (useHL ? Low[priorLowCount] : swingInput[priorLowCount]) + MultiplierDTB * avgTrueRange[lowCount];

                    #region -- Set NEW drawing states --

                    drawSwingLegDown = true;

                    if (currentLow < marginDown)
                    {
                        pre_swingLowType[lowCount] = -3;
                        wPattern = WState.LowerLow;
                    }
                    else if (currentLow > marginUp)
                    {
                        pre_swingLowType[lowCount] = -1;
                        wPattern = WState.HigherLow;
                    }
                    else
                    {
                        pre_swingLowType[lowCount] = -2;
                        wPattern = WState.EqualLow;
                    }
                    #endregion
                }
                #endregion


                if (priorSwingHighIdx > lastBreakUp && ShowMPattern)
                {
                    double l;
                    if (priorLowCount < priorHighCount)
                    {
                        l = Low[priorLowCount2];
                    }
                    else
                    {
                        l = Low[priorLowCount];
                    }
                    bool IsAnchorLeg = (Math.Max(High[priorHighCount], High[priorHighCount2]) - l) / (Math.Min(High[priorHighCount], High[priorHighCount2]) - l) > 2;
                    if (!IsAnchorLeg || AnchorLegs)
                    {
                        if (mPattern == MState.HigherHigh && HigherHighBreak)
                        {
                            currentTop[0] = Math.Max(High[priorHighCount], High[priorHighCount2]);
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingHighIdx.ToString() : "nspf";
								drawText(tag, true,"HH", priorHighCount, High[priorHighCount], (int)labelFont.Size, MPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, "HH", priorHighCount, High[priorHighCount], MPatternColor);},0,null);
                            }
                        }
                        else if (mPattern == MState.LowerHigh && LowerHighBreak)
                        {
                            currentTop[0] = UseHHLL ? Math.Max(High[priorHighCount], High[priorHighCount2]) : High[priorHighCount];
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingHighIdx.ToString() : "nspf";
								drawText(tag, true,"LH", priorHighCount, High[priorHighCount], (int)labelFont.Size, MPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, "LH", priorHighCount, High[priorHighCount], MPatternColor);},0,null);
                            }
                        }
                        else if (mPattern == MState.EqualHigh && EqualHighBreak)
                        {
                            currentTop[0] = Math.Max(High[priorHighCount], High[priorHighCount2]);
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingHighIdx.ToString() : "nspf";
								drawText(tag, true,"EH", priorHighCount, High[priorHighCount], (int)labelFont.Size, MPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, "EH", priorHighCount, High[priorHighCount], MPatternColor);},0,null);
                            }
                        }
                    }
                }

                if (priorSwingLowIdx > lastBreakDown && ShowWPattern)
                {
                    double h;
                    if (priorHighCount < priorLowCount)
                    {
                        h = High[priorHighCount2];
                    }
                    else
                    {
                        h = High[priorHighCount];
                    }
                    bool IsAnchorLeg = (h - Math.Min(Low[priorLowCount], Low[priorLowCount2])) / (h - Math.Max(Low[priorLowCount], Low[priorLowCount2])) > 2;
                    if (!IsAnchorLeg || AnchorLegs)
                    {
                        if (wPattern == WState.LowerLow && LowerLowBreak)
                        {
                            currentBottom[0] = Math.Min(Low[priorLowCount], Low[priorLowCount2]);
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingLowIdx.ToString() : "nspf";
								drawText(tag, true,"LL", priorLowCount, Low[priorLowCount], (int)labelFont.Size, WPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, "LL", priorLowCount, Low[priorLowCount], WPatternColor);},0,null);
                            }
                        }
                        else if (wPattern == WState.HigherLow && HigherLowBreak)
                        {
                            currentBottom[0] = UseHHLL ? Math.Min(Low[priorLowCount], Low[priorLowCount2]) : Low[priorLowCount];
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingLowIdx.ToString() : "nspf";
								drawText(tag, true,"HL", priorLowCount, Low[priorLowCount], (int)labelFont.Size, WPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, "HL", priorLowCount, Low[priorLowCount], WPatternColor);},0,null);
                            }
                        }
                        else if (wPattern == WState.EqualLow && EqualLowBreak)
                        {
                            currentBottom[0] = Math.Min(Low[priorLowCount], Low[priorLowCount2]);
                            if (ShowSwingLabels)
                            {
                                string tag = ShowHistoricalPatterns ? "nspf_" + priorSwingLowIdx.ToString() : "nspf";
								drawText(tag, true,"EL", priorLowCount, Low[priorLowCount], (int)labelFont.Size, WPatternColor);
//                                TriggerCustomEvent(o1 =>{Draw.Text(this, tag, "EL", priorLowCount, Low[priorLowCount], WPatternColor);},0,null);
                            }
                        }
                    }
                }
            }
            #endregion

            #endregion

			if(CurrentBars[0] < BarsArray[0].Count-pBarsLookback) return;

            #region -- Draw ZigZag --
            if (Calculate == Calculate.OnBarClose || IsFirstTickOfBar)
            {
                if (ShowZigzagLegs)
                {
                    if (drawSwingLegUp)
                    {
                        zigzag[lowCount] = Low[lowCount];
                        //string tag = string.Format("swingLegUp{0}", (CurrentBar - lowCount));
                        //Draw.Line(this, tag, false, lowCount, Low[lowCount], highCount, High[highCount], upColor, SwingLegStyle, SwingLegWidth);
                    }
                    if (drawSwingLegDown)
                    {
                        zigzag[highCount] = High[highCount];
                        //string tag = string.Format("swingLegDown{0}", (CurrentBar - highCount));
                        //Draw.Line(this, tag, false, highCount, High[highCount], lowCount, Low[lowCount], downColor, SwingLegStyle, SwingLegWidth);
                    }
                }
            }
            #endregion

            #region -- Breakout --
            int b = 0;
            if(Calculate == Calculate.OnBarClose)
            {
                b = 0;
            }
            else
            {
                if(IsFirstTickOfBar)
                {
                    b = 1;
                }
                else
                {
                    return;
                }
            }

            if (currentTop[0] > 0)
            {
                if(Close[b] > currentTop[0])
                {
                    SignalUp[0] = Low[0] - 2 * TickSize;
                    lastBreakUp = CurrentBar;
                    if(!ShowHistoricalPatterns && lastSignal > 0)
                    {
                        SignalUp.Reset(CurrentBar - lastSignal);
                        SignalDown.Reset(CurrentBar - lastSignal);
                        if(ChartControl !=null) BackBrushesAll.Set(lastSignal, Brushes.Transparent);
//                        RemoveDrawObject("EP_Long");
//                        RemoveDrawObject("SL_Long");
//                        RemoveDrawObject("T1_Long");
//                        RemoveDrawObject("T2_Long");
//                        RemoveDrawObject("EP_Short");
//                        RemoveDrawObject("SL_Short");
//                        RemoveDrawObject("T1_Short");
//                        RemoveDrawObject("T2_Short");
                    }
                    lastSignal = CurrentBar;
					if(ChartControl !=null){
	                    AddLongSignal(Close[0], 0);
    	                DrawMPattern(0);
					}
                }
            }

            if (currentBottom[0] > 0)
            {
                if (Close[b] < currentBottom[0])
                {
                    SignalDown[0] = High[0] + 2 * TickSize;
                    lastBreakDown = CurrentBar;
                    if (!ShowHistoricalPatterns && lastSignal > 0)
                    {
                        SignalUp.Reset(CurrentBar - lastSignal);
                        SignalDown.Reset(CurrentBar - lastSignal);
                        if(ChartControl !=null) BackBrushesAll.Set(lastSignal, Brushes.Transparent);
//                        RemoveDrawObject("EP_Long");
//                        RemoveDrawObject("SL_Long");
//                        RemoveDrawObject("T1_Long");
//                        RemoveDrawObject("T2_Long");
//                        RemoveDrawObject("EP_Short");
//                        RemoveDrawObject("SL_Short");
//                        RemoveDrawObject("T1_Short");
//                        RemoveDrawObject("T2_Short");
                    }
                    lastSignal = CurrentBar;
					if(ChartControl !=null){
	                    AddShortSignal(Close[0], 0);
    	                DrawWPattern(0);
					}
                }
            }
            #endregion

            #region -- Pre Patterns --
			
			int prePattern = 0;
            if(currentTop[0] > 0 && currentBottom[0] == 0)
            {
                if (Close[0] > currentTop[0] - 2 * avgTrueRange[0])
                {
                    prePattern = 1;
                }
            }
            else if (currentTop[0] == 0 && currentBottom[0] > 0)
            {
                if (Close[0] < currentBottom[0] + 2 * avgTrueRange[0])
                {
                    prePattern = -1;
                }
            }
            else if(currentTop[0] > 0 && currentBottom[0] > 0)
            {
                double middle = 0.5 * (currentTop[0] + currentBottom[0]);
                if(Close[0] > middle)
                {
                    prePattern = 1;
                }
                else
                {
                    prePattern = -1;
                }
            }
			
			if(prePattern > 0)
            {
                RemovePreWPattern();
                DrawPreMPattern();
            }
			else if(prePattern < 0)
            {
                RemovePreMPattern();
                DrawPreWPattern();
            }
            else
            {
                RemovePreMPattern();
                RemovePreWPattern();
            }
			//Print(Time[0].ToString() + ", M Pattern at: " + currentTop[0].ToString() + ", W Pattern at: " + currentBottom[0].ToString() + ", Pre Pattern: " + prePattern);
            #endregion
}catch(Exception e){Print(Instrument.MasterInstrument.Name+"  PatternFinder "+e.ToString());}
        }

        #region Add Signal
        private bool IsValidRBar(int rbar)
        {
            if (rbar >= 0 && rbar < CurrentBars[0]) return true;
            return false;
        }

        private int AlertBar = 0;
        private void AddLongSignal(double p, int bar)
        {
			SystemSignal[bar] = this.BUY_SYSTEMSIGNAL;
            string suffix = ShowHistoricalPatterns ? string.Format("_{0}", (CurrentBar - bar)) : "_Long";
            string tagEP = string.Format("EP{0}", suffix);
            string tagSL = string.Format("SL{0}", suffix);
            string tagT1 = string.Format("T1{0}", suffix);
            string tagT2 = string.Format("T2{0}", suffix);

            double sl  = p - pSLTicks * TickSize;
            double tp1 = p + pT1Ticks * TickSize;
            double tp2 = p + pT2Ticks * TickSize;

            Draw.ArrowUp(this, tagEP, false, bar, p - pMarkerOffset*TickSize, pBuyBrush);
            if (this.pSLVisible) Draw.Square(this, tagSL, false, bar, sl, pSLBrush);
            if (this.pT1Visible) Draw.TriangleDown(this, tagT1, false, bar, tp1, pT1Brush);
            if (this.pT2Visible) Draw.TriangleDown(this, tagT2, false, bar, tp2, pT2Brush);
//            TriggerCustomEvent(o1 =>{Draw.ArrowUp(this, tagEP, false, bar, p - pMarkerOffset*TickSize, pBuyBrush);},0,null);
//            if (this.pSLVisible) TriggerCustomEvent(o1 =>{Draw.Square(this, tagSL, false, bar, sl, pSLBrush);},0,null);
//            if (this.pT1Visible) TriggerCustomEvent(o1 =>{Draw.TriangleDown(this, tagT1, false, bar, tp1, pT1Brush);},0,null);
//            if (this.pT2Visible) TriggerCustomEvent(o1 =>{Draw.TriangleDown(this, tagT2, false, bar, tp2, pT2Brush);},0,null);

            int rbar = CurrentBar - (last_visible_bar + 1);
            rbar = 0;
            int yPixelOffset = 0;

            if (State != State.Historical && pBuySoundWAV.Length > 0 && AlertBar != CurrentBar)
            {
                AlertBar = CurrentBar;
                Alert(CurrentBar.ToString(), Priority.High, string.Format("Pattern Break BUY {0}", BarsPeriod.ToString()), AddSoundFolder(pBuySoundWAV), 0, Brushes.Green, Brushes.White);
            }

            if (pBuyStripeOpacity > 0 && pBuyStripeBrush != Brushes.Transparent && this.pShowRacingStripes && IsValidRBar(1))
            {
                BackBrushesAll.Set(CurrentBar, BuyStripeBrush);
            }

            /*if (pTradePlanVisible)
            {
                Print("Visible - " + rbar + ", " + pTradePlan_LineLength);
                Draw.Line(this, "E-ray", false, rbar, p, rbar - pTradePlan_LineLength, p, false, pLineTemplateName_EP);
                Draw.Line(this, "SL-ray", false, rbar, sl, rbar - pTradePlan_LineLength, sl, false, pLineTemplateName_SL);
                Draw.Line(this, "T1-ray", false, rbar, tp1, rbar - pTradePlan_LineLength, tp1, false, pLineTemplateName_T1);
                Draw.Line(this, "T2-ray", false, rbar, tp2, rbar - pTradePlan_LineLength, tp2, false, pLineTemplateName_T2);
                Draw.Text(this, "cEP", false, "EP", rbar - pTradePlan_LineLength, p, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100);
                if (this.pSLVisible) Draw.Text(this, "cSL", false, "SL", rbar - pTradePlan_LineLength, sl, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100);
                if (this.pT1Visible) Draw.Text(this, "cT1", false, "T1", rbar - pTradePlan_LineLength, tp1, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100);
                if (this.pT2Visible) Draw.Text(this, "cT2", false, "T2", rbar - pTradePlan_LineLength, tp2, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100);
            }*/
        }

        private void AddShortSignal(double p, int bar)
        {
			SystemSignal[bar] = this.SELL_SYSTEMSIGNAL;
            string suffix = ShowHistoricalPatterns ? string.Format("_{0}", (CurrentBar - bar)) : "_Short";
            string tagEP = string.Format("EP{0}", suffix);
            string tagSL = string.Format("SL{0}", suffix);
            string tagT1 = string.Format("T1{0}", suffix);
            string tagT2 = string.Format("T2{0}", suffix);

            double sl  = p + pSLTicks * TickSize;
            double tp1 = p - pT1Ticks * TickSize;
            double tp2 = p - pT2Ticks * TickSize;

            Draw.ArrowDown(this, tagEP, false, bar, p + pMarkerOffset*TickSize, pSellBrush);
            if (this.pSLVisible) Draw.Square(this, tagSL, false, bar, sl, pSLBrush);
            if (this.pT1Visible) Draw.TriangleUp(this, tagT1, false, bar, tp1, pT1Brush);
            if (this.pT2Visible) Draw.TriangleUp(this, tagT2, false, bar, tp2, pT2Brush);
//            TriggerCustomEvent(o1 =>{Draw.ArrowDown(this, tagEP, false, bar, p + pMarkerOffset*TickSize, pSellBrush);},0,null);
//            if (this.pSLVisible) TriggerCustomEvent(o1 =>{Draw.Square(this, tagSL, false, bar, sl, pSLBrush);},0,null);
//            if (this.pT1Visible) TriggerCustomEvent(o1 =>{Draw.TriangleUp(this, tagT1, false, bar, tp1, pT1Brush);},0,null);
//            if (this.pT2Visible) TriggerCustomEvent(o1 =>{Draw.TriangleUp(this, tagT2, false, bar, tp2, pT2Brush);},0,null);

            int rbar = CurrentBar - (last_visible_bar + 1);
            rbar = 0;
            int yPixelOffset = 0;

            if (State != State.Historical && pSellSoundWAV.Length > 0 && AlertBar != CurrentBar)
            {
                AlertBar = CurrentBar;
                Alert(CurrentBar.ToString(), Priority.High, string.Format("Pattern Break SELL {0}", BarsPeriod.ToString()), AddSoundFolder(pSellSoundWAV), 0, Brushes.Red, Brushes.White);
            }
            if (pSellStripeOpacity > 0 && pSellStripeBrush != Brushes.Transparent && this.pShowRacingStripes && IsValidRBar(1))
            {
                BackBrushesAll.Set(CurrentBar, SellStripeBrush);
            }

            /*if (pTradePlanVisible)
            {
                Draw.Line(this, "E-ray", false, rbar, p, rbar - pTradePlan_LineLength, p, false, pLineTemplateName_EP);
                Draw.Line(this, "SL-ray", false, rbar, sl, rbar - pTradePlan_LineLength, sl, false, pLineTemplateName_SL);
                Draw.Line(this, "T1-ray", false, rbar, tp1, rbar - pTradePlan_LineLength, tp1, false, pLineTemplateName_T1);
                Draw.Line(this, "T2-ray", false, rbar, tp2, rbar - pTradePlan_LineLength, tp2, false, pLineTemplateName_T2);
                Draw.Text(this, "cEP", false, "EP", rbar - pTradePlan_LineLength, p, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100);
                if (this.pSLVisible) Draw.Text(this, "cSL", false, "SL", rbar - pTradePlan_LineLength, sl, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100);
                if (this.pT1Visible) Draw.Text(this, "cT1", false, "T1", rbar - pTradePlan_LineLength, tp1, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100);
                if (this.pT2Visible) Draw.Text(this, "cT2", false, "T2", rbar - pTradePlan_LineLength, tp2, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100);
            }*/
        }
        #endregion

        #region Draw Patterns
        private void DrawMPattern(int barfrom)
        {
            if(!ShowZigzagLegs)
            {
                return;
            }
            List<int> vertexes = new List<int>();
            for(int i = barfrom; i < CurrentBar; i++)
            {
                if(zigzag[i] > 0)
                {
                    if(vertexes.Count == 0 && zigzag[i] > High[i] - TickSize)
                    {
                        continue;
                    }
                    vertexes.Add(i);
                    if(vertexes.Count >= 5)
                    {
                        break;
                    }
                }
            }
            //Print(vertexes.Count);

            if (vertexes.Count >= 5)
            {
                string tag = string.Format("m_pattern_{0}", (CurrentBar - vertexes[0]));
                if(!ShowHistoricalPatterns)
                {
                    tag = "pattern_finder";
                }
                Draw.Line(this, string.Format("{0}_1",tag), false, vertexes[0], Low[vertexes[0]], vertexes[1], High[vertexes[1]], upColor, SwingLegStyle, SwingLegWidth);
                Draw.Line(this, string.Format("{0}_2",tag), false, vertexes[1], High[vertexes[1]], vertexes[2], Low[vertexes[2]], upColor, SwingLegStyle, SwingLegWidth);
                Draw.Line(this, string.Format("{0}_3",tag), false, vertexes[2], Low[vertexes[2]], vertexes[3], High[vertexes[3]], upColor, SwingLegStyle, SwingLegWidth);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_1", false, vertexes[0], Low[vertexes[0]], vertexes[1], High[vertexes[1]], upColor, SwingLegStyle, SwingLegWidth);},0,null);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_2", false, vertexes[1], High[vertexes[1]], vertexes[2], Low[vertexes[2]], upColor, SwingLegStyle, SwingLegWidth);},0,null);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_3", false, vertexes[2], Low[vertexes[2]], vertexes[3], High[vertexes[3]], upColor, SwingLegStyle, SwingLegWidth);},0,null);
                //Draw.Line(this, tag + "_4", false, vertexes[3], High[vertexes[3]], vertexes[4], Low[vertexes[4]], upColor, SwingLegStyle, SwingLegWidth);
            }

        }

        private void DrawWPattern(int barfrom)
        {
            if (!ShowZigzagLegs)
            {
                return;
            }

            List<int> vertexes = new List<int>();
            for (int i = barfrom; i < CurrentBar; i++)
            {
                if (zigzag[i] > 0)
                {
                    if (vertexes.Count == 0 && zigzag[i] < Low[i] + TickSize)
                    {
                        continue;
                    }
                    vertexes.Add(i);
                    if (vertexes.Count >= 5)
                    {
                        break;
                    }
                }
            }
            //Print(vertexes.Count);

            if (vertexes.Count >= 5)
            {
                string tag = string.Format("w_pattern_{0}", (CurrentBar - vertexes[0]));
                if (!ShowHistoricalPatterns)
                {
                    tag = "pattern_finder";
                }
                Draw.Line(this, string.Format("{0}_1",tag), false, vertexes[0], High[vertexes[0]], vertexes[1], Low[vertexes[1]], downColor, SwingLegStyle, SwingLegWidth);
                Draw.Line(this, string.Format("{0}_2",tag), false, vertexes[1], Low[vertexes[1]], vertexes[2], High[vertexes[2]], downColor, SwingLegStyle, SwingLegWidth);
                Draw.Line(this, string.Format("{0}_3",tag), false, vertexes[2], High[vertexes[2]], vertexes[3], Low[vertexes[3]], downColor, SwingLegStyle, SwingLegWidth);
//	            TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_1", false, vertexes[0], High[vertexes[0]], vertexes[1], Low[vertexes[1]], downColor, SwingLegStyle, SwingLegWidth);},0,null);
//	            TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_2", false, vertexes[1], Low[vertexes[1]], vertexes[2], High[vertexes[2]], downColor, SwingLegStyle, SwingLegWidth);},0,null);
//	            TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_3", false, vertexes[2], High[vertexes[2]], vertexes[3], Low[vertexes[3]], downColor, SwingLegStyle, SwingLegWidth);},0,null);
                //Draw.Line(this, tag + "_4", false, vertexes[3], Low[vertexes[3]], vertexes[4], High[vertexes[4]], downColor, SwingLegStyle, SwingLegWidth);
            }

        }

        private void DrawPreMPattern()
        {
            if (!ShowEmergingPatterns)
            {
                return;
            }

            List<int> vertexes = new List<int>();
            for (int i = 0; i < CurrentBar; i++)
            {
                if (zigzag[i] > 0)
                {
                    if (vertexes.Count == 0 && zigzag[i] > High[i] - TickSize)
                    {
                        continue;
                    }
                    vertexes.Add(i);
                    if (vertexes.Count >= 5)
                    {
                        break;
                    }
                }
            }
            //Print(vertexes.Count);

            if (vertexes.Count >= 5)
            {
                string tag = "m_pattern_p";
                Draw.Line(this, string.Format("{0}_1",tag), false, vertexes[0], Low[vertexes[0]], vertexes[1], High[vertexes[1]], LongPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);
                Draw.Line(this, string.Format("{0}_2",tag), false, vertexes[1], High[vertexes[1]], vertexes[2], Low[vertexes[2]], LongPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);
                Draw.Line(this, string.Format("{0}_3",tag), false, vertexes[2], Low[vertexes[2]], vertexes[3], High[vertexes[3]], LongPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);
                Draw.Line(this, string.Format("{0}_top",tag), false, vertexes[1], currentTop[0], -1, currentTop[0], LongPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_1", false, vertexes[0], Low[vertexes[0]], vertexes[1], High[vertexes[1]], LongPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);},0,null);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_2", false, vertexes[1], High[vertexes[1]], vertexes[2], Low[vertexes[2]], LongPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);},0,null);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_3", false, vertexes[2], Low[vertexes[2]], vertexes[3], High[vertexes[3]], LongPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);},0,null);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_top", false, vertexes[1], currentTop[0], -1, currentTop[0], LongPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);},0,null);
                //Draw.Line(this, tag + "_4", false, vertexes[3], High[vertexes[3]], vertexes[4], Low[vertexes[4]], upColor, DashStyleHelper.Dash, 1);
            }

        }

        private void DrawPreWPattern()
        {
            if (!ShowEmergingPatterns)
            {
                return;
            }

            List<int> vertexes = new List<int>();
            for (int i = 0; i < CurrentBar; i++)
            {
                if (zigzag[i] > 0)
                {
                    if (vertexes.Count == 0 && zigzag[i] < Low[i] + TickSize)
                    {
                        continue;
                    }
                    vertexes.Add(i);
                    if (vertexes.Count >= 5)
                    {
                        break;
                    }
                }
            }
            //Print(vertexes.Count);

            if (vertexes.Count >= 5)
            {
                string tag = "w_pattern_p";
                Draw.Line(this, string.Format("{0}_1",tag), false, vertexes[0], High[vertexes[0]], vertexes[1], Low[vertexes[1]], ShortPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);
                Draw.Line(this, string.Format("{0}_2",tag), false, vertexes[1], Low[vertexes[1]], vertexes[2], High[vertexes[2]], ShortPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);
                Draw.Line(this, string.Format("{0}_3",tag), false, vertexes[2], High[vertexes[2]], vertexes[3], Low[vertexes[3]], ShortPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);
                Draw.Line(this, string.Format("{0}_bot",tag), false, vertexes[1], currentBottom[0], -1, currentBottom[0], ShortPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_1", false, vertexes[0], High[vertexes[0]], vertexes[1], Low[vertexes[1]], ShortPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);},0,null);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_2", false, vertexes[1], Low[vertexes[1]], vertexes[2], High[vertexes[2]], ShortPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);},0,null);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_3", false, vertexes[2], High[vertexes[2]], vertexes[3], Low[vertexes[3]], ShortPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);},0,null);
//                TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_bot", false, vertexes[1], currentBottom[0], -1, currentBottom[0], ShortPatternColorEm, SwingLegStyleEm, SwingLegWidthEm);},0,null);
                //TriggerCustomEvent(o1 =>{Draw.Line(this, tag + "_4", false, vertexes[3], Low[vertexes[3]], vertexes[4], High[vertexes[4]], downColor, DashStyleHelper.Dash, 1);
            }
        }

        private void RemovePreMPattern()
        {
            string tag = "m_pattern_p";
            RemoveDrawObject(string.Format("{0}_1",tag));
            RemoveDrawObject(string.Format("{0}_2",tag));
            RemoveDrawObject(string.Format("{0}_3",tag));
            RemoveDrawObject(string.Format("{0}_top",tag));
        }

        private void RemovePreWPattern()
        {
            string tag = "w_pattern_p";
            RemoveDrawObject(string.Format("{0}_1",tag));
            RemoveDrawObject(string.Format("{0}_2",tag));
            RemoveDrawObject(string.Format("{0}_3",tag));
            RemoveDrawObject(string.Format("{0}_bot",tag));
        }
        #endregion

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            last_visible_bar = ChartBars.ToIndex;
        }

        #region Signal Sounds
        //===================================================================================================================
        private string AddSoundFolder(string wav)
        {
            if (wav == "SOUND OFF") return "";
            return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", wav);
        }
        internal class LoadSoundFileList : StringConverter
        {
            #region LoadSoundFileList
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
            {
                //true means show a combobox
                return true;
            }

            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
            {
                //true will limit to list. false will show the list, 
                //but allow free-form entry
                return false;
            }

            public override System.ComponentModel.TypeConverter.StandardValuesCollection
                GetStandardValues(ITypeDescriptorContext context)
            {
                string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds");
                string search = "*.wav";

                System.IO.DirectoryInfo dirCustom = null;
                System.IO.FileInfo[] filCustom = null;
                try
                {
                    dirCustom = new System.IO.DirectoryInfo(folder);
                    filCustom = dirCustom.GetFiles( search);
                }
                catch { }

                var list = new List<string>();//new string[filCustom.Length+1];
                list.Add("SOUND OFF");
                if (filCustom != null)
                {
                    foreach (System.IO.FileInfo fi in filCustom)
                    {
                        if (!list.Contains(fi.Name))
                        {
                            list.Add(fi.Name);
                        }
                    }
                }
                return new StandardValuesCollection(list.ToArray());
            }
            #endregion
        }
        //===================================================================================================================
        #endregion

        #region Properties
        #region Load pulldown parameters
        internal class LoadLineTemplates : StringConverter
        {
            #region LoadLineTemplates
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
            {
                //true means show a combobox
                return true;
            }

            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
            {
                //true will limit to list. false will show the list, 
                //but allow free-form entry
                return false;
            }

            public override System.ComponentModel.TypeConverter.StandardValuesCollection
                GetStandardValues(ITypeDescriptorContext context)
            {
                string[] paths = new string[4] { NinjaTrader.Core.Globals.UserDataDir, "templates", "DrawingTool", "Line" };
                RayTemplates_folder = System.IO.Path.Combine(paths);
                string search = "*.xml";
                System.IO.DirectoryInfo dirCustom = null;
                System.IO.FileInfo[] filCustom = null;
                try
                {
                    dirCustom = new System.IO.DirectoryInfo(RayTemplates_folder);
                    filCustom = dirCustom.GetFiles( search);
                }
                catch { }

                var list = new List<string>();//new string[filCustom.Length+1];
                list.Add("Default");
                if (filCustom != null)
                {
                    foreach (System.IO.FileInfo fi in filCustom)
                    {
                        string name = fi.Name.Replace(".xml", string.Empty);
                        if (!list.Contains(name))
                        {
                            list.Add(name);
                        }
                    }
                }
                return new StandardValuesCollection(list.ToArray());
            }
            #endregion
        }
        #endregion

        #region GroupName = "General Parameters"
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Order = 0, Name = "Swing strength", GroupName = "General Parameters", Description = "Number of bars used to identify a swing high or low")]
        public int SwingStrength { get; set; }

        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Order = 1, Name = "Deviation multiplier", GroupName = "General Parameters", Description = "Multiplier used to calculate minimum deviation as an ATR multiple")]
        public double MultiplierMD { get; set; }

        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Order = 2, Name = "Sensitivity double tops/bottoms", GroupName = "General Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms")]
        public double MultiplierDTB { get; set; }

        [NinjaScriptProperty]
        [Display(Order = 3, Name = "Bars lookback", GroupName = "General Parameters", Description="Signals and zigzags before this bar lookback will be ignored")]
		public int pBarsLookback {get;set;}

        [NinjaScriptProperty]
        [Display(Order = 3, Name = "Show Historical Patterns", GroupName = "General Parameters")]
        public bool ShowHistoricalPatterns
        { get; set; }

        [NinjaScriptProperty]
        [Display(Order = 4, Name = "Show Current Pattern", GroupName = "General Parameters")]
        public bool ShowCurrentPattern
        { get; set; }

        [NinjaScriptProperty]
        [Display(Order = 5, Name = "Show swing legs", GroupName = "General Parameters", Description = "Show swing legs connecting swing highs and lows")]
        public bool ShowZigzagLegs { get; set; }

        [NinjaScriptProperty]
        [Display(Order = 6, Name = "Dash style swing legs", GroupName = "General Parameters", Description = "Dash style for swing legs.")]
        public DashStyleHelper SwingLegStyle { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Order = 7, Name = "Width swing legs", GroupName = "General Parameters", Description = "Select thickness of swing legs connecting swing highs and lows")]
        public int SwingLegWidth { get; set; }

        [NinjaScriptProperty]
        [Display(Order = 8, Name = "Show swing labels", GroupName = "General Parameters", Description = "Show swing legs connecting swing highs and lows")]
        public bool ShowSwingLabels { get; set; }

        [NinjaScriptProperty]
        [Display(Order = 9, Name = "Anchor legs", GroupName = "General Parameters", Description = "Use patterns with long anchor legs")]
        public bool AnchorLegs { get; set; }

        [NinjaScriptProperty]
        [Display(Order = 10, Name = "Use HH/LL for signal", GroupName = "General Parameters", Description = "Use HH/LL for breakout or the last H/L")]
        public bool UseHHLL { get; set; }
		
		[Display(Order = 11, Name = "Button Text", GroupName = "General Parameters", Description = "")]
		public string pButtonText {get;set;}
        #endregion

        #region GroupName = "Emerging Patters"
        [NinjaScriptProperty]
        [Display(Name = "Show emerging patterns", GroupName = "Emerging Patterns", Description = "Show emerging patterns", Order = 1)]
        public bool ShowEmergingPatterns { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Dash style swing legs", GroupName = "Emerging Patterns", Description = "Dash style for swing legs.", Order = 2)]
        public DashStyleHelper SwingLegStyleEm { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Width swing legs", GroupName = "Emerging Patterns", Description = "Select thickness of swing legs connecting swing highs and lows", Order = 3)]
        public int SwingLegWidthEm { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Long Pattern Color", Order = 4, GroupName = "Emerging Patterns")]
        public Brush LongPatternColorEm
        { get; set; }

        [Browsable(false)]
        public string LongPatternColorEmSerializable
        {
            get { return Serialize.BrushToString(LongPatternColorEm); }
            set { LongPatternColorEm = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Short Pattern Color", Order = 5, GroupName = "Emerging Patterns")]
        public Brush ShortPatternColorEm
        { get; set; }

        [Browsable(false)]
        public string ShortPatternColorEmSerializable
        {
            get { return Serialize.BrushToString(ShortPatternColorEm); }
            set { ShortPatternColorEm = Serialize.StringToBrush(value); }
        }
        #endregion

        #region GroupName = "M Patterns"
        [NinjaScriptProperty]
		[Display(Name = "Show M Pattern", Order=1, GroupName="M Patterns")]
		public bool ShowMPattern
		{ get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Lower High Break", Order = 8, GroupName = "M Patterns")]
        public bool LowerHighBreak
        { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Higher High Break", Order = 9, GroupName = "M Patterns")]
        public bool HigherHighBreak
        { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Equal High Break", Order = 10, GroupName = "M Patterns")]
        public bool EqualHighBreak
        { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "M Pattern Color", Order = 14, GroupName = "M Patterns")]
        public Brush MPatternColor
        { get; set; }

        [Browsable(false)]
        public string MPatternColorSerializable
        {
            get { return Serialize.BrushToString(MPatternColor); }
            set { MPatternColor = Serialize.StringToBrush(value); }
        }
        #endregion

        #region GroupName = "W Patterns"
        [NinjaScriptProperty]
		[Display(Name = "Show W Pattern", Order=2, GroupName= "W Patterns")]
		public bool ShowWPattern
		{ get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Lower Low Break", Order = 11, GroupName = "W Patterns")]
        public bool LowerLowBreak
        { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Higher Low Break", Order = 12, GroupName = "W Patterns")]
        public bool HigherLowBreak
        { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Equal Low Break", Order = 13, GroupName = "W Patterns")]
        public bool EqualLowBreak
        { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "W Pattern Color", Order = 15, GroupName = "W Patterns")]
        public Brush WPatternColor
        { get; set; }

        [Browsable(false)]
        public string WPatternColorSerializable
        {
            get { return Serialize.BrushToString(WPatternColor); }
            set { WPatternColor = Serialize.StringToBrush(value); }
        }
        #endregion

        #region GroupName = "System Signals"
        //[Display(Order = 10, Name = "Display Signals", GroupName = "System Signals", Description = "")]
        //public bool DisplaySignals { get; set; }

        [Display(Order = 20, Name = "SL Ticks", GroupName = "System Signals", Description = "")]
        public int pSLTicks { get; set; }

        [Display(Order = 30, Name = "T1 Ticks", GroupName = "System Signals", Description = "")]
        public int pT1Ticks { get; set; }

        [Display(Order = 40, Name = "T2 Ticks", GroupName = "System Signals", Description = "")]
        public int pT2Ticks { get; set; }

        [Display(Order = 50, Name = "Show Trade Plan?", GroupName = "System Signals", Description = "")]
        public bool pTradePlanVisible { get; set; }

        [Display(Order = 80, Name = "Text font", GroupName = "System Signals", Description = "")]
        public SimpleFont pTextFont { get; set; }

        [Display(Order = 85, Name = "Marker Offset", GroupName = "System Signals", Description = "Number of ticks between marker and price bar")]
        public int pMarkerOffset { get; set; }

        [Display(Order = 90, Name = "Show SL?", GroupName = "System Signals", Description = "")]
        public bool pSLVisible { get; set; }

        [Display(Order = 100, Name = "Show T1?", GroupName = "System Signals", Description = "")]
        public bool pT1Visible { get; set; }

        [Display(Order = 110, Name = "Show T2?", GroupName = "System Signals", Description = "")]
        public bool pT2Visible { get; set; }

        [XmlIgnore]
        [Display(Order = 120, Name = "Buy Arrow Color", GroupName = "System Signals", Description = "Color of the buy signal arrow")]
        public Brush pBuyBrush { get; set; }
        [Browsable(false)]
        public string pBuyBrushSerialize { get { return Serialize.BrushToString(pBuyBrush); } set { pBuyBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Order = 130, Name = "Sell Arrow Color", GroupName = "System Signals", Description = "Color of the sell signal arrow")]
        public Brush pSellBrush { get; set; }
        [Browsable(false)]
        public string pSellBrushSerialize { get { return Serialize.BrushToString(pSellBrush); } set { pSellBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Order = 140, Name = "SL Square Color", GroupName = "System Signals", Description = "Color of the SL marker")]
        public Brush pSLBrush { get; set; }
        [Browsable(false)]
        public string pSLBrushSerialize { get { return Serialize.BrushToString(pSLBrush); } set { pSLBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Order = 150, Name = "T1 Triangle Color", GroupName = "System Signals", Description = "Color of the T1 marker")]
        public Brush pT1Brush { get; set; }
        [Browsable(false)]
        public string pT1BrushSerialize { get { return Serialize.BrushToString(pT1Brush); } set { pT1Brush = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Order = 160, Name = "T2 Triangle Color", GroupName = "System Signals", Description = "Color of the T2 marker")]
        public Brush pT2Brush { get; set; }
        [Browsable(false)]
        public string pT2BrushSerialize { get { return Serialize.BrushToString(pT2Brush); } set { pT2Brush = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Order = 170, Name = "Flag Text", GroupName = "System Signals", Description = "Color of the text of the TradePlan Flags")]
        public Brush pFlagTextBrush { get; set; }
        [Browsable(false)]
        public string pFlagTextBrushSerialize { get { return Serialize.BrushToString(pFlagTextBrush); } set { pFlagTextBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Order = 180, Name = "Flag Background", GroupName = "System Signals", Description = "Color of the background of the TradePlan Flags")]
        public Brush pFlagBkgBrush { get; set; }
        [Browsable(false)]
        public string pFlagBkgBrushSerialize { get { return Serialize.BrushToString(pFlagBkgBrush); } set { pFlagBkgBrush = Serialize.StringToBrush(value); } }

        [Display(Order = 185, Name = "Show Racing Stripes?", GroupName = "System Signals", Description = "")]
        public bool pShowRacingStripes { get; set; }

        [XmlIgnore]
        [Display(Order = 190, Name = "Buy Stripe", GroupName = "System Signals", Description = "Color of the background on a BUY signal")]
        public Brush pBuyStripeBrush { get; set; }
        [Browsable(false)]
        public string pBuyStripeBrushSerialize { get { return Serialize.BrushToString(pBuyStripeBrush); } set { pBuyStripeBrush = Serialize.StringToBrush(value); } }

        [Range(0, 100)]
        [Display(Order = 200, Name = "Buy Stripe Op.", GroupName = "System Signals", Description = "Opacity of BUY background stripe")]
        public int pBuyStripeOpacity { get; set; }

        [XmlIgnore]
        [Display(Order = 210, Name = "Sell Stripe", GroupName = "System Signals", Description = "Color of the background on a SELL signal")]
        public Brush pSellStripeBrush { get; set; }
        [Browsable(false)]
        public string pSellStripeBrushSerialize { get { return Serialize.BrushToString(pSellStripeBrush); } set { pSellStripeBrush = Serialize.StringToBrush(value); } }

        [Range(0, 100)]
        [Display(Order = 220, Name = "Sell Stripe Op.", GroupName = "System Signals", Description = "Opacity of SELL background stripe")]
        public int pSellStripeOpacity { get; set; }

        [Description("WAV file to play for Termite BUY signals, 'SOUND OFF' to turn off the alert")]
        [Display(Order = 280, Name = "Buy Sound", GroupName = "System Signals")]
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
        public string pBuySoundWAV
        { get; set; }

        [Description("WAV file to play for Termite SELL signals, 'SOUND OFF' to turn off the alert")]
        [Display(Order = 290, Name = "Sell Sound", GroupName = "System Signals")]
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
        public string pSellSoundWAV
        { get; set; }

        #endregion

		[Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SignalUp
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SignalDown
		{
			get { return Values[1]; }
		}

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> SystemSignal { get { return Values[2]; } }
        #endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_PatternFinder[] cacheARC_PatternFinder;
		public ARC.ARC_PatternFinder ARC_PatternFinder(int swingStrength, double multiplierMD, double multiplierDTB, int pBarsLookback, bool showHistoricalPatterns, bool showCurrentPattern, bool showZigzagLegs, DashStyleHelper swingLegStyle, int swingLegWidth, bool showSwingLabels, bool anchorLegs, bool useHHLL, bool showEmergingPatterns, DashStyleHelper swingLegStyleEm, int swingLegWidthEm, Brush longPatternColorEm, Brush shortPatternColorEm, bool showMPattern, bool lowerHighBreak, bool higherHighBreak, bool equalHighBreak, Brush mPatternColor, bool showWPattern, bool lowerLowBreak, bool higherLowBreak, bool equalLowBreak, Brush wPatternColor)
		{
			return ARC_PatternFinder(Input, swingStrength, multiplierMD, multiplierDTB, pBarsLookback, showHistoricalPatterns, showCurrentPattern, showZigzagLegs, swingLegStyle, swingLegWidth, showSwingLabels, anchorLegs, useHHLL, showEmergingPatterns, swingLegStyleEm, swingLegWidthEm, longPatternColorEm, shortPatternColorEm, showMPattern, lowerHighBreak, higherHighBreak, equalHighBreak, mPatternColor, showWPattern, lowerLowBreak, higherLowBreak, equalLowBreak, wPatternColor);
		}

		public ARC.ARC_PatternFinder ARC_PatternFinder(ISeries<double> input, int swingStrength, double multiplierMD, double multiplierDTB, int pBarsLookback, bool showHistoricalPatterns, bool showCurrentPattern, bool showZigzagLegs, DashStyleHelper swingLegStyle, int swingLegWidth, bool showSwingLabels, bool anchorLegs, bool useHHLL, bool showEmergingPatterns, DashStyleHelper swingLegStyleEm, int swingLegWidthEm, Brush longPatternColorEm, Brush shortPatternColorEm, bool showMPattern, bool lowerHighBreak, bool higherHighBreak, bool equalHighBreak, Brush mPatternColor, bool showWPattern, bool lowerLowBreak, bool higherLowBreak, bool equalLowBreak, Brush wPatternColor)
		{
			if (cacheARC_PatternFinder != null)
				for (int idx = 0; idx < cacheARC_PatternFinder.Length; idx++)
					if (cacheARC_PatternFinder[idx] != null && cacheARC_PatternFinder[idx].SwingStrength == swingStrength && cacheARC_PatternFinder[idx].MultiplierMD == multiplierMD && cacheARC_PatternFinder[idx].MultiplierDTB == multiplierDTB && cacheARC_PatternFinder[idx].pBarsLookback == pBarsLookback && cacheARC_PatternFinder[idx].ShowHistoricalPatterns == showHistoricalPatterns && cacheARC_PatternFinder[idx].ShowCurrentPattern == showCurrentPattern && cacheARC_PatternFinder[idx].ShowZigzagLegs == showZigzagLegs && cacheARC_PatternFinder[idx].SwingLegStyle == swingLegStyle && cacheARC_PatternFinder[idx].SwingLegWidth == swingLegWidth && cacheARC_PatternFinder[idx].ShowSwingLabels == showSwingLabels && cacheARC_PatternFinder[idx].AnchorLegs == anchorLegs && cacheARC_PatternFinder[idx].UseHHLL == useHHLL && cacheARC_PatternFinder[idx].ShowEmergingPatterns == showEmergingPatterns && cacheARC_PatternFinder[idx].SwingLegStyleEm == swingLegStyleEm && cacheARC_PatternFinder[idx].SwingLegWidthEm == swingLegWidthEm && cacheARC_PatternFinder[idx].LongPatternColorEm == longPatternColorEm && cacheARC_PatternFinder[idx].ShortPatternColorEm == shortPatternColorEm && cacheARC_PatternFinder[idx].ShowMPattern == showMPattern && cacheARC_PatternFinder[idx].LowerHighBreak == lowerHighBreak && cacheARC_PatternFinder[idx].HigherHighBreak == higherHighBreak && cacheARC_PatternFinder[idx].EqualHighBreak == equalHighBreak && cacheARC_PatternFinder[idx].MPatternColor == mPatternColor && cacheARC_PatternFinder[idx].ShowWPattern == showWPattern && cacheARC_PatternFinder[idx].LowerLowBreak == lowerLowBreak && cacheARC_PatternFinder[idx].HigherLowBreak == higherLowBreak && cacheARC_PatternFinder[idx].EqualLowBreak == equalLowBreak && cacheARC_PatternFinder[idx].WPatternColor == wPatternColor && cacheARC_PatternFinder[idx].EqualsInput(input))
						return cacheARC_PatternFinder[idx];
			return CacheIndicator<ARC.ARC_PatternFinder>(new ARC.ARC_PatternFinder(){ SwingStrength = swingStrength, MultiplierMD = multiplierMD, MultiplierDTB = multiplierDTB, pBarsLookback = pBarsLookback, ShowHistoricalPatterns = showHistoricalPatterns, ShowCurrentPattern = showCurrentPattern, ShowZigzagLegs = showZigzagLegs, SwingLegStyle = swingLegStyle, SwingLegWidth = swingLegWidth, ShowSwingLabels = showSwingLabels, AnchorLegs = anchorLegs, UseHHLL = useHHLL, ShowEmergingPatterns = showEmergingPatterns, SwingLegStyleEm = swingLegStyleEm, SwingLegWidthEm = swingLegWidthEm, LongPatternColorEm = longPatternColorEm, ShortPatternColorEm = shortPatternColorEm, ShowMPattern = showMPattern, LowerHighBreak = lowerHighBreak, HigherHighBreak = higherHighBreak, EqualHighBreak = equalHighBreak, MPatternColor = mPatternColor, ShowWPattern = showWPattern, LowerLowBreak = lowerLowBreak, HigherLowBreak = higherLowBreak, EqualLowBreak = equalLowBreak, WPatternColor = wPatternColor }, input, ref cacheARC_PatternFinder);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_PatternFinder ARC_PatternFinder(int swingStrength, double multiplierMD, double multiplierDTB, int pBarsLookback, bool showHistoricalPatterns, bool showCurrentPattern, bool showZigzagLegs, DashStyleHelper swingLegStyle, int swingLegWidth, bool showSwingLabels, bool anchorLegs, bool useHHLL, bool showEmergingPatterns, DashStyleHelper swingLegStyleEm, int swingLegWidthEm, Brush longPatternColorEm, Brush shortPatternColorEm, bool showMPattern, bool lowerHighBreak, bool higherHighBreak, bool equalHighBreak, Brush mPatternColor, bool showWPattern, bool lowerLowBreak, bool higherLowBreak, bool equalLowBreak, Brush wPatternColor)
		{
			return indicator.ARC_PatternFinder(Input, swingStrength, multiplierMD, multiplierDTB, pBarsLookback, showHistoricalPatterns, showCurrentPattern, showZigzagLegs, swingLegStyle, swingLegWidth, showSwingLabels, anchorLegs, useHHLL, showEmergingPatterns, swingLegStyleEm, swingLegWidthEm, longPatternColorEm, shortPatternColorEm, showMPattern, lowerHighBreak, higherHighBreak, equalHighBreak, mPatternColor, showWPattern, lowerLowBreak, higherLowBreak, equalLowBreak, wPatternColor);
		}

		public Indicators.ARC.ARC_PatternFinder ARC_PatternFinder(ISeries<double> input , int swingStrength, double multiplierMD, double multiplierDTB, int pBarsLookback, bool showHistoricalPatterns, bool showCurrentPattern, bool showZigzagLegs, DashStyleHelper swingLegStyle, int swingLegWidth, bool showSwingLabels, bool anchorLegs, bool useHHLL, bool showEmergingPatterns, DashStyleHelper swingLegStyleEm, int swingLegWidthEm, Brush longPatternColorEm, Brush shortPatternColorEm, bool showMPattern, bool lowerHighBreak, bool higherHighBreak, bool equalHighBreak, Brush mPatternColor, bool showWPattern, bool lowerLowBreak, bool higherLowBreak, bool equalLowBreak, Brush wPatternColor)
		{
			return indicator.ARC_PatternFinder(input, swingStrength, multiplierMD, multiplierDTB, pBarsLookback, showHistoricalPatterns, showCurrentPattern, showZigzagLegs, swingLegStyle, swingLegWidth, showSwingLabels, anchorLegs, useHHLL, showEmergingPatterns, swingLegStyleEm, swingLegWidthEm, longPatternColorEm, shortPatternColorEm, showMPattern, lowerHighBreak, higherHighBreak, equalHighBreak, mPatternColor, showWPattern, lowerLowBreak, higherLowBreak, equalLowBreak, wPatternColor);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_PatternFinder ARC_PatternFinder(int swingStrength, double multiplierMD, double multiplierDTB, int pBarsLookback, bool showHistoricalPatterns, bool showCurrentPattern, bool showZigzagLegs, DashStyleHelper swingLegStyle, int swingLegWidth, bool showSwingLabels, bool anchorLegs, bool useHHLL, bool showEmergingPatterns, DashStyleHelper swingLegStyleEm, int swingLegWidthEm, Brush longPatternColorEm, Brush shortPatternColorEm, bool showMPattern, bool lowerHighBreak, bool higherHighBreak, bool equalHighBreak, Brush mPatternColor, bool showWPattern, bool lowerLowBreak, bool higherLowBreak, bool equalLowBreak, Brush wPatternColor)
		{
			return indicator.ARC_PatternFinder(Input, swingStrength, multiplierMD, multiplierDTB, pBarsLookback, showHistoricalPatterns, showCurrentPattern, showZigzagLegs, swingLegStyle, swingLegWidth, showSwingLabels, anchorLegs, useHHLL, showEmergingPatterns, swingLegStyleEm, swingLegWidthEm, longPatternColorEm, shortPatternColorEm, showMPattern, lowerHighBreak, higherHighBreak, equalHighBreak, mPatternColor, showWPattern, lowerLowBreak, higherLowBreak, equalLowBreak, wPatternColor);
		}

		public Indicators.ARC.ARC_PatternFinder ARC_PatternFinder(ISeries<double> input , int swingStrength, double multiplierMD, double multiplierDTB, int pBarsLookback, bool showHistoricalPatterns, bool showCurrentPattern, bool showZigzagLegs, DashStyleHelper swingLegStyle, int swingLegWidth, bool showSwingLabels, bool anchorLegs, bool useHHLL, bool showEmergingPatterns, DashStyleHelper swingLegStyleEm, int swingLegWidthEm, Brush longPatternColorEm, Brush shortPatternColorEm, bool showMPattern, bool lowerHighBreak, bool higherHighBreak, bool equalHighBreak, Brush mPatternColor, bool showWPattern, bool lowerLowBreak, bool higherLowBreak, bool equalLowBreak, Brush wPatternColor)
		{
			return indicator.ARC_PatternFinder(input, swingStrength, multiplierMD, multiplierDTB, pBarsLookback, showHistoricalPatterns, showCurrentPattern, showZigzagLegs, swingLegStyle, swingLegWidth, showSwingLabels, anchorLegs, useHHLL, showEmergingPatterns, swingLegStyleEm, swingLegWidthEm, longPatternColorEm, shortPatternColorEm, showMPattern, lowerHighBreak, higherHighBreak, equalHighBreak, mPatternColor, showWPattern, lowerLowBreak, higherLowBreak, equalLowBreak, wPatternColor);
		}
	}
}

#endregion
