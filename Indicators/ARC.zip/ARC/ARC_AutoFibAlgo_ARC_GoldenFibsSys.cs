#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using System.Threading;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;

using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows;
using System.Security.Cryptography;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using SharpDX.DirectWrite;

using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;

#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	/*
	 * NOTE: this is the old version of the code, it's only here as a reference to ensure cleanup and changes aren't affecting the output levels
	 */

	#region -- Global Enums --
	public enum ARC_AutoFibAlgo_NS_GoldenFibsSys_TradeEntryBasis { AtFibPrice, AtMidPrice, AtATR }
	public enum ARC_AutoFibAlgo_NS_GoldenFibsSys_TradePlanLocation { Left, Right }
	public enum ARC_AutoFibAlgo_NS_GoldenFibsSys_DominantTradePlan { Long, Short, None }
	public enum ARC_AutoFibAlgo_NS_GoldenFibsSys_SLTP_CalcBasis { ATR, Ticks }
	public enum ARC_AutoFibAlgo_NS_GoldenFibsSys_Plan_LevelsBasis { AtFib, AtEntryPrice }
	#endregion

	public class ARC_AutoFibAlgo_ARC_GoldenFibsSys : ARC_AutoFibAlgo_ARCIndicatorBase
	{
		public override string ProductVersion { get { return "v1.0.1 (9/6/2023)"; } }
		public override bool ColicensedOnly { get { return true; } }

		private const int UP = 1;
		private const int FLAT = 0;
		private const int DOWN = -1;
		#region TradePlan class definition
		private class TradePlan
		{
			public double EntryPrice;
			public double SLPrice;
			public double T1Price;
			public double T2Price;
			public double EntryZoneHighPrice;
			public double EntryZoneLowPrice;
			public TradePlan(char Type, double fibLevel, ARC_AutoFibAlgo_NS_GoldenFibsSys_Plan_LevelsBasis planlevelsbasis, ARC_AutoFibAlgo_NS_GoldenFibsSys_TradeEntryBasis entrybasis, double atr, double EntryZoneMult, double SL_inPts, double T1_inPts, double T2_inPts, double TickSize)
			{
				var ticks = (int)Math.Round(atr * EntryZoneMult / TickSize);
				if (ticks % 2 == 1) ticks++;
				if (Type == 'S')
				{//'S' for supportive
					EntryZoneLowPrice = fibLevel;
					EntryZoneHighPrice = EntryZoneLowPrice + ticks * TickSize;
				}
				else
				{
					EntryZoneHighPrice = fibLevel;
					EntryZoneLowPrice = EntryZoneHighPrice - ticks * TickSize;
				}
				if (entrybasis == ARC_AutoFibAlgo_NS_GoldenFibsSys_TradeEntryBasis.AtFibPrice)
					EntryPrice = fibLevel;
				else if (entrybasis == ARC_AutoFibAlgo_NS_GoldenFibsSys_TradeEntryBasis.AtMidPrice)
				{
					EntryPrice = (EntryZoneHighPrice + EntryZoneLowPrice) / 2.0;
					//					EntryPrice = Math.Round(EntryPrice/TickSize,0) * TickSize;
				}
				else if (entrybasis == ARC_AutoFibAlgo_NS_GoldenFibsSys_TradeEntryBasis.AtATR)
				{
					if (Type == 'R')
					{//it's a resistance, SHORT entry plan
						EntryPrice = EntryZoneLowPrice;
					}
					else
					{//it's a support, LONG entry plan
						EntryPrice = EntryZoneHighPrice;
					}
				}
				else
				{//AtNearestEdge
					if (Type == 'S')
					{//it's a supportive, LONG entry plan
						EntryPrice = EntryZoneHighPrice;
					}
					else
					{//it's a resistance, SHORT entry plan
						EntryPrice = EntryZoneLowPrice;
					}
				}
				var keyprice = fibLevel;
				if (planlevelsbasis == ARC_AutoFibAlgo_NS_GoldenFibsSys_Plan_LevelsBasis.AtEntryPrice) keyprice = EntryPrice;
				if (Type == 'R')
				{//it's a resistance, SHORT entry plan
					SLPrice = keyprice + SL_inPts;
					if (T1_inPts > 0) T1Price = keyprice - T1_inPts; else T1Price = double.NaN;
					if (T2_inPts > 0) T2Price = keyprice - T2_inPts; else T2Price = double.NaN;
				}
				else
				{//it's a supportive, LONG entry plan
					SLPrice = keyprice - SL_inPts;
					if (T1_inPts > 0) T1Price = keyprice + T1_inPts; else T1Price = double.NaN;
					if (T2_inPts > 0) T2Price = keyprice + T2_inPts; else T2Price = double.NaN;
				}
			}
		}
		private TradePlan[] SupTPlan = new TradePlan[2] { null, null };
		private TradePlan[] ResTPlan = new TradePlan[2] { null, null };
		private double AvgSL = double.MinValue;
		private double AvgT1 = double.MinValue;
		private double AvgT2 = double.MinValue;
		#endregion

		bool IsDebug = false;

		//2.1 - added ButtonText parameter...letting user select the text on the UI button
		//2.2 - Moved Series<double> inits to DataLoaded state, for NT8.0.20.0 compatibility
		//2.3 - Changed DisplayName to clean up the NT IndicatorDialog
		private string VERSION = "v2.3 Apr.29.20";
		[Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
		public string indicatorVersion { get { return VERSION; } }

		#region -- Variables --

		#region -- Arrays --
		private bool[] upTrend = new bool[10];
		private bool[] existsSwingHigh = new bool[10];
		private bool[] existsSwingLow = new bool[10];
		private double[] minimumDeviation = new double[10];
		private double[,] microHigh = new double[10, 20];
		private double[,] microLow = new double[10, 20];
		private double[] currentHigh = new double[10];
		private double[] currentLow = new double[10];
		private double[] priorCurrentHigh = new double[10];
		private double[] priorCurrentLow = new double[10];
		private double[] currentSwingHigh = new double[10];
		private double[] currentSwingLow = new double[10];
		private double[] lastSwingHigh = new double[10];
		private double[] lastSwingLow = new double[10];
		private double[] microSwingHigh0 = new double[10];
		private double[] microSwingHigh1 = new double[10];
		private double[] microSwingHigh2 = new double[10];
		private double[] microSwingHigh3 = new double[10];
		private double[] microSwingLow0 = new double[10];
		private double[] microSwingLow1 = new double[10];
		private double[] microSwingLow2 = new double[10];
		private double[] microSwingLow3 = new double[10];
		private double[] retUp0 = new double[10];
		private double[] retUp23 = new double[10];
		private double[] retUp38 = new double[10];
		private double[] retUp50 = new double[10];
		private double[] retUp62 = new double[10];
		private double[] retUp76 = new double[10];
		private double[] retUp100 = new double[10];
		private double[] retDown0 = new double[10];
		private double[] retDown23 = new double[10];
		private double[] retDown38 = new double[10];
		private double[] retDown50 = new double[10];
		private double[] retDown62 = new double[10];
		private double[] retDown76 = new double[10];
		private double[] retDown100 = new double[10];
		private double[] extUp0 = new double[10];
		private double[] extUp100 = new double[10];
		private double[] extUp127 = new double[10];
		private double[] extUp162 = new double[10];
		private double[] extUp200 = new double[10];
		private double[] extUp262 = new double[10];
		private double[] extUp300 = new double[10];
		private double[] extUp423 = new double[10];
		private double[] extDown0 = new double[10];
		private double[] extDown100 = new double[10];
		private double[] extDown127 = new double[10];
		private double[] extDown162 = new double[10];
		private double[] extDown200 = new double[10];
		private double[] extDown262 = new double[10];
		private double[] extDown300 = new double[10];
		private double[] extDown423 = new double[10];
		private double[] dirUp38 = new double[10];
		private double[] dirUp62 = new double[10];
		private double[] dirUp100 = new double[10];
		private double[] dirDown38 = new double[10];
		private double[] dirDown62 = new double[10];
		private double[] dirDown100 = new double[10];
		private double[] lastDirUp38 = new double[10];
		private double[] lastDirUp62 = new double[10];
		private double[] lastDirUp100 = new double[10];
		private double[] lastDirDown38 = new double[10];
		private double[] lastDirDown62 = new double[10];
		private double[] lastDirDown100 = new double[10];
		private double[] alt0Up = new double[10];
		private double[] alt1Up = new double[10];
		private double[] alt0Down = new double[10];
		private double[] alt1Down = new double[10];
		private double[] alt0Up62 = new double[10];
		private double[] alt0Up100 = new double[10];
		private double[] alt0Up162 = new double[10];
		private double[] alt1Up100 = new double[10];
		private double[] alt0Down62 = new double[10];
		private double[] alt0Down100 = new double[10];
		private double[] alt0Down162 = new double[10];
		private double[] alt1Down100 = new double[10];
		private double[] priorCurrentSwingHigh = new double[10];
		private double[] priorLastSwingHigh = new double[10];
		private double[] priorCurrentSwingLow = new double[10];
		private double[] priorLastSwingLow = new double[10];
		private double[] priorMicroSwingHigh0 = new double[10];
		private double[] priorMicroSwingHigh1 = new double[10];
		private double[] priorMicroSwingHigh2 = new double[10];
		private double[] priorMicroSwingHigh3 = new double[10];
		private double[] priorMicroSwingLow0 = new double[10];
		private double[] priorMicroSwingLow1 = new double[10];
		private double[] priorMicroSwingLow2 = new double[10];
		private double[] priorMicroSwingLow3 = new double[10];
		private double[] priorRetUp0 = new double[10];
		private double[] priorRetUp23 = new double[10];
		private double[] priorRetUp38 = new double[10];
		private double[] priorRetUp50 = new double[10];
		private double[] priorRetUp62 = new double[10];
		private double[] priorRetUp76 = new double[10];
		private double[] priorRetUp100 = new double[10];
		private double[] priorRetDown0 = new double[10];
		private double[] priorRetDown23 = new double[10];
		private double[] priorRetDown38 = new double[10];
		private double[] priorRetDown50 = new double[10];
		private double[] priorRetDown62 = new double[10];
		private double[] priorRetDown76 = new double[10];
		private double[] priorRetDown100 = new double[10];
		private double[] priorExtUp0 = new double[10];
		private double[] priorExtUp100 = new double[10];
		private double[] priorExtUp127 = new double[10];
		private double[] priorExtUp162 = new double[10];
		private double[] priorExtUp200 = new double[10];
		private double[] priorExtUp262 = new double[10];
		private double[] priorExtUp300 = new double[10];
		private double[] priorExtUp423 = new double[10];
		private double[] priorExtDown0 = new double[10];
		private double[] priorExtDown100 = new double[10];
		private double[] priorExtDown127 = new double[10];
		private double[] priorExtDown162 = new double[10];
		private double[] priorExtDown200 = new double[10];
		private double[] priorExtDown262 = new double[10];
		private double[] priorExtDown300 = new double[10];
		private double[] priorExtDown423 = new double[10];
		private double[] priorDirUp38 = new double[10];
		private double[] priorDirUp62 = new double[10];
		private double[] priorDirUp100 = new double[10];
		private double[] priorDirDown38 = new double[10];
		private double[] priorDirDown62 = new double[10];
		private double[] priorDirDown100 = new double[10];
		private double[] priorLastDirUp38 = new double[10];
		private double[] priorLastDirUp62 = new double[10];
		private double[] priorLastDirUp100 = new double[10];
		private double[] priorLastDirDown38 = new double[10];
		private double[] priorLastDirDown62 = new double[10];
		private double[] priorLastDirDown100 = new double[10];
		private double[] priorAlt0Up62 = new double[10];
		private double[] priorAlt0Up100 = new double[10];
		private double[] priorAlt0Up162 = new double[10];
		private double[] priorAlt0Down62 = new double[10];
		private double[] priorAlt0Down100 = new double[10];
		private double[] priorAlt0Down162 = new double[10];
		private double[] priorAlt1Up100 = new double[10];
		private double[] priorAlt1Down100 = new double[10];
		private int[] countDown = new int[10];
		private int[] currentSwingHighIndex = new int[10];
		private int[] lastSwingHighIndex = new int[10];
		private int[] currentSwingLowIndex = new int[10];
		private int[] lastSwingLowIndex = new int[10];
		#endregion

		private bool generalError = false;
		private bool init = true;
		private bool initATR = true;
		private Brush textBrush = Brushes.Red;
		private SimpleFont textFont = new SimpleFont("Arial", 12);
		private SimpleFont textFont2 = new SimpleFont("Arial", 10);
		private string errorData = "Loading of minute data is incomplete. Please refresh chart via F5 or check minute data.";
		private string preloadedData = "";
		private DateTime firstSessionBegin = new DateTime(0);
		private bool isIntraday = true;
		private bool preloadMinuteData = false;
		private bool isMinuteDataLoaded = false;
		private bool isMinuteBarsCalled = false;
		private bool existsHistMinuteData = false;
		private bool isTrainingComplete = false;
		private bool drawPreloadInfo = false;
		private Bars minuteBars = null;
		private DateTime lastMinuteBarTime = new DateTime(0);
		private int minuteBarIndex = 0;

		private double avgTrueRangeLog = 0;
		private double avgTrueRange = 0;
		private double timeFrameMultiplier = 0;
		private double dummy = 0;
		private bool goAhead = false;
		private int k = 0;
		private int m = 0;
		private int n = 0;

		private int countResistance = 0;
		private int countSupport = 0;
		private int countWeakResistance = 0;
		private int countWeakSupport = 0;

		private int tmpOldState = 0;
		private double tmpFibValue = 0.0;
		private double lowestResistance = double.MaxValue;
		private double highestSupport = double.MinValue;

		private bool highUpdate;
		private bool lowUpdate;
		private bool addHigh;
		private bool addLow;
		private double normalizedRangeUp;
		private double normalizedRangeDown;
		private int highCount;
		private int lowCount;

		private int countLine;
		private double initialWeight;
		private double compoundedWeight;
		private double highestWeight;

		private Series<double> ResNear;
		private Series<double> ResFar;
		private Series<double> SupNear;
		private Series<double> SupFar;
		private Series<double> atr;
		private Series<double> SupFar_SL;
		private Series<double> SupFar_T1;
		private Series<double> SupFar_T2;
		private Series<double> SupFar_En;
		private Series<double> SupFar_AH;
		private Series<double> SupFar_AL;
		private Series<double> SupNear_SL;
		private Series<double> SupNear_T1;
		private Series<double> SupNear_T2;
		private Series<double> SupNear_En;
		private Series<double> SupNear_AH;
		private Series<double> SupNear_AL;
		private Series<double> ResFar_SL;
		private Series<double> ResFar_T1;
		private Series<double> ResFar_T2;
		private Series<double> ResFar_En;
		private Series<double> ResFar_AH;
		private Series<double> ResFar_AL;
		private Series<double> ResNear_SL;
		private Series<double> ResNear_T1;
		private Series<double> ResNear_T2;
		private Series<double> ResNear_En;
		private Series<double> ResNear_AH;
		private Series<double> ResNear_AL;

		#region -- zigzag --
		private double currentBarHigh = 0;
		private double currentBarLow = 0;
		private double currentBarClose = 0;
		private double currentBarTrueRange = 0;
		private double priorBarHigh = 0;
		private double priorBarLow = 0;
		private double priorBarClose = 0;
		private double zigZagFactor = 0;
		private double displayFactor = 80.0;
		private double confluenceRange = 0;
		private int currentBars1 = 0;
		private int priorCurrentBars1 = 0;
		private int lowestTimeFrame = 0;
		private int highestTimeFrame = 9;
		private double stepUpRatio = 1.5;
		#endregion

		#region -- Lines --
		private bool SHOW_WEAKER_LINES = true;

		private double confluenceRangeWidth = 0;
		private double upperLimitResistance = double.MaxValue;
		private double lowerLimitResistance = 0;
		private double upperLimitSupport = double.MaxValue;
		private double lowerLimitSupport = 0;
		private double upperLimitWeakResistance = double.MaxValue;
		private double lowerLimitWeakSupport = 0;
		#endregion

		#region -- Specific Weights --
		private double specificWeightMicroSwing0 = 44.10;
		private double specificWeightMicroSwing1 = 37.48;
		private double specificWeightMicroSwing2 = 31.86;
		private double specificWeightMicroSwing3 = 27.08;
		private double specificWeightCurrentSwing = 46.42;
		private double specificWeightLastSwing = 39.45;
		private double specificWeightRet23 = 28.44;
		private double specificWeightRet38 = 33.62;
		private double specificWeightRet50 = 36.84;
		private double specificWeightRet62 = 39.58;
		private double specificWeightRet76 = 42.36;
		private double specificWeightExt127 = 50.27;
		private double specificWeightExt162 = 54.51;
		private double specificWeightExt200 = 50.27;
		private double specificWeightExt262 = 42.36;
		private double specificWeightExt300 = 39.58;
		private double specificWeightExt423 = 36.84;
		private double specificWeightDir38 = 36.17;
		private double specificWeightDir62 = 38.16;
		private double specificWeightDir100 = 32.49;
		private double specificWeightLastDir38 = 30.75;
		private double specificWeightLastDir62 = 32.44;
		private double specificWeightLastDir100 = 27.62;
		private double specificWeightAlt62 = 23.75;
		private double specificWeightAlt100 = 27.85;
		private double specificWeightAlt162 = 32.71;
		private double specificWeightAlt100Prior = 23.67;
		private double devalueRet = 0.8;
		private double devalueExt = 0.8;
		private double devalueDir = 0.6;
		private double devalueAlt = 0.6;
		#endregion

		#region -- Arrays --
		private double[] fibLine = new double[540];
		private double[] fibWeight = new double[540];
		private double[] fibResistance = new double[540];
		private double[] weakResistance = new double[540];
		private double[] weightResistance = new double[540];
		private double[] fibSupport = new double[540];
		private double[] weakSupport = new double[540];
		private double[] weightSupport = new double[540];

		private double[] timeFrameFactor = new double[10];
		private double[] weightMicroSwingHigh0 = new double[10];
		private double[] weightMicroSwingHigh1 = new double[10];
		private double[] weightMicroSwingHigh2 = new double[10];
		private double[] weightMicroSwingHigh3 = new double[10];
		private double[] weightMicroSwingLow0 = new double[10];
		private double[] weightMicroSwingLow1 = new double[10];
		private double[] weightMicroSwingLow2 = new double[10];
		private double[] weightMicroSwingLow3 = new double[10];
		private double[] weightCurrentSwingHigh = new double[10];
		private double[] weightLastSwingHigh = new double[10];
		private double[] weightCurrentSwingLow = new double[10];
		private double[] weightLastSwingLow = new double[10];
		private double[] weightRetUp23 = new double[10];
		private double[] weightRetUp38 = new double[10];
		private double[] weightRetUp50 = new double[10];
		private double[] weightRetUp62 = new double[10];
		private double[] weightRetUp76 = new double[10];
		private double[] weightRetDown23 = new double[10];
		private double[] weightRetDown38 = new double[10];
		private double[] weightRetDown50 = new double[10];
		private double[] weightRetDown62 = new double[10];
		private double[] weightRetDown76 = new double[10];
		private double[] weightExtUp127 = new double[10];
		private double[] weightExtUp162 = new double[10];
		private double[] weightExtUp200 = new double[10];
		private double[] weightExtUp262 = new double[10];
		private double[] weightExtUp300 = new double[10];
		private double[] weightExtUp423 = new double[10];
		private double[] weightExtDown127 = new double[10];
		private double[] weightExtDown162 = new double[10];
		private double[] weightExtDown200 = new double[10];
		private double[] weightExtDown262 = new double[10];
		private double[] weightExtDown300 = new double[10];
		private double[] weightExtDown423 = new double[10];
		private double[] weightDirUp38 = new double[10];
		private double[] weightDirUp62 = new double[10];
		private double[] weightDirUp100 = new double[10];
		private double[] weightDirDown38 = new double[10];
		private double[] weightDirDown62 = new double[10];
		private double[] weightDirDown100 = new double[10];
		private double[] weightLastDirUp38 = new double[10];
		private double[] weightLastDirUp62 = new double[10];
		private double[] weightLastDirUp100 = new double[10];
		private double[] weightLastDirDown38 = new double[10];
		private double[] weightLastDirDown62 = new double[10];
		private double[] weightLastDirDown100 = new double[10];
		private double[] weightAlt0Up62 = new double[10];
		private double[] weightAlt0Up100 = new double[10];
		private double[] weightAlt0Up162 = new double[10];
		private double[] weightAlt1Up100 = new double[10];
		private double[] weightAlt0Down62 = new double[10];
		private double[] weightAlt0Down100 = new double[10];
		private double[] weightAlt0Down162 = new double[10];
		private double[] weightAlt1Down100 = new double[10];

		private double[] cumulatedWeightMicroSwingHigh0 = new double[10];
		private double[] cumulatedWeightMicroSwingHigh1 = new double[10];
		private double[] cumulatedWeightMicroSwingHigh2 = new double[10];
		private double[] cumulatedWeightMicroSwingHigh3 = new double[10];
		private double[] cumulatedWeightMicroSwingLow0 = new double[10];
		private double[] cumulatedWeightMicroSwingLow1 = new double[10];
		private double[] cumulatedWeightMicroSwingLow2 = new double[10];
		private double[] cumulatedWeightMicroSwingLow3 = new double[10];
		private double[] cumulatedWeightCurrentSwingHigh = new double[10];
		private double[] cumulatedWeightLastSwingHigh = new double[10];
		private double[] cumulatedWeightCurrentSwingLow = new double[10];
		private double[] cumulatedWeightLastSwingLow = new double[10];
		private double[] cumulatedWeightRetUp23 = new double[10];
		private double[] cumulatedWeightRetUp38 = new double[10];
		private double[] cumulatedWeightRetUp50 = new double[10];
		private double[] cumulatedWeightRetUp62 = new double[10];
		private double[] cumulatedWeightRetUp76 = new double[10];
		private double[] cumulatedWeightRetDown23 = new double[10];
		private double[] cumulatedWeightRetDown38 = new double[10];
		private double[] cumulatedWeightRetDown50 = new double[10];
		private double[] cumulatedWeightRetDown62 = new double[10];
		private double[] cumulatedWeightRetDown76 = new double[10];
		private double[] cumulatedWeightExtUp127 = new double[10];
		private double[] cumulatedWeightExtUp162 = new double[10];
		private double[] cumulatedWeightExtUp200 = new double[10];
		private double[] cumulatedWeightExtUp262 = new double[10];
		private double[] cumulatedWeightExtUp300 = new double[10];
		private double[] cumulatedWeightExtUp423 = new double[10];
		private double[] cumulatedWeightExtDown127 = new double[10];
		private double[] cumulatedWeightExtDown162 = new double[10];
		private double[] cumulatedWeightExtDown200 = new double[10];
		private double[] cumulatedWeightExtDown262 = new double[10];
		private double[] cumulatedWeightExtDown300 = new double[10];
		private double[] cumulatedWeightExtDown423 = new double[10];
		private double[] cumulatedWeightDirUp38 = new double[10];
		private double[] cumulatedWeightDirUp62 = new double[10];
		private double[] cumulatedWeightDirUp100 = new double[10];
		private double[] cumulatedWeightDirDown38 = new double[10];
		private double[] cumulatedWeightDirDown62 = new double[10];
		private double[] cumulatedWeightDirDown100 = new double[10];
		private double[] cumulatedWeightLastDirUp38 = new double[10];
		private double[] cumulatedWeightLastDirUp62 = new double[10];
		private double[] cumulatedWeightLastDirUp100 = new double[10];
		private double[] cumulatedWeightLastDirDown38 = new double[10];
		private double[] cumulatedWeightLastDirDown62 = new double[10];
		private double[] cumulatedWeightLastDirDown100 = new double[10];
		private double[] cumulatedWeightAlt0Up62 = new double[10];
		private double[] cumulatedWeightAlt0Up100 = new double[10];
		private double[] cumulatedWeightAlt0Up162 = new double[10];
		private double[] cumulatedWeightAlt1Up100 = new double[10];
		private double[] cumulatedWeightAlt0Down62 = new double[10];
		private double[] cumulatedWeightAlt0Down100 = new double[10];
		private double[] cumulatedWeightAlt0Down162 = new double[10];
		private double[] cumulatedWeightAlt1Down100 = new double[10];

		private double[] strongFibs = new double[20];
		private double[] weakFibs = new double[20];
		private double[] priorStrongFibs = new double[20];
		private double[] priorWeakFibs = new double[20];
		private double[] oldStrongFibs = new double[20];
		private double[] oldWeakFibs = new double[20];
		private double[] newBOBHigh = new double[40];
		private double[] oldBOBHigh = new double[40];
		private double[] newBOBLow = new double[40];
		private double[] oldBOBLow = new double[40];
		private double[] newBOBClose = new double[40];
		private double[] oldBOBClose = new double[40];
		private int[] newState = new int[40];
		private int[] oldState = new int[40];
		#endregion

		#endregion
		List<int> SL_List = new List<int>();
		List<int> T1_List = new List<int>();
		List<int> T2_List = new List<int>();

		private const int SUP_ID = 1;
		private const int RES_ID = -1;
		private string ObjTagPrefix = string.Empty;
		static string HLtemplates_folder = null;
		private SortedDictionary<string, bool> IsGlobalized = new SortedDictionary<string, bool>();
		#region -- Global_RaysData --------------------------------------------------
		private class Global_RaysData
		{
			public int LMAbar = 0;
			public int Type = -1;//if Support = 1, if Resistance -1
			public DateTime DT;
			public double Price;
			public string TemplateName;
			public bool IsDrawn = false;
			public DateTime EndDT = DateTime.MaxValue;
			public Global_RaysData(DateTime dt, int leftABar, int res_or_sup, double price, string templatename)
			{
				DT = dt; Price = price; LMAbar = leftABar; Type = res_or_sup; TemplateName = templatename.Replace(" Ray Template", string.Empty); IsDrawn = false; EndDT = DateTime.MaxValue;
			}
		}
		#endregion
		private SortedDictionary<string, Global_RaysData> GlobalRays = new SortedDictionary<string, Global_RaysData>();

		#region -- variables for benchmark --
		private DateTime benchStart = new DateTime(0);
		private DateTime benchStop = new DateTime(0);
		private bool getBench = false;
		#endregion

		private bool ParameterChanged = false;
		private SimpleFont ZZlabelFont;
		private int SLdistanceTicks = 0;
		private int T1distanceTicks = 0;
		private int T2distanceTicks = 0;

		//=====================================================================================================
		private int CalculateCountOfGlobalObjects()
		{
			var Tag1 = string.Format("@{0} {1}", "FS", ObjTagPrefix);
			var Tag2 = string.Format("@{0} {1}", "FB", ObjTagPrefix);
			var Tag3 = string.Format("@{0} {1}", "NS", ObjTagPrefix);
			var Tag4 = string.Format("@{0} {1}", "NB", ObjTagPrefix);
			var objects = DrawObjects.Where(ob => ob.Tag.StartsWith(Tag1) || ob.Tag.StartsWith(Tag2) || ob.Tag.StartsWith(Tag3) || ob.Tag.StartsWith(Tag4));
			if (objects == null) return 0;
			return objects.Count();
		}

		private StructureBias StructureBiasMgr = null;
		private class StructureBias
		{
			#region StructureBias class
			public int SwingStrength = 0;
			public bool isHLBased = false;
			public double MultiplierMD = 0;
			public double MultiplierDTB = 0;
			public Series<int> Bias;
			public Brush UpTrendColorTinted = null;
			public Brush DownTrendColorTinted = null;
			public string ErrorMsg = string.Empty;
			public SortedDictionary<int, double> AllPivots = new SortedDictionary<int, double>();

			#region internals
			private int SRType = 0;
			private int preSRType = 0;
			private bool vdrawHigherHighLabel = false;
			private bool vdrawLowerHighLabel = false;
			private bool vdrawDoubleTopLabel = false;
			private bool vdrawLowerLowLabel = false;
			private bool vdrawHigherLowLabel = false;
			private bool vdrawDoubleBottomLabel = false;
			private ISeries<double> High;
			private ISeries<double> Low;
			private Series<bool> vupTrend;
			private Series<double> vpre_swingHighType;
			private Series<double> vpre_swingLowType;
			private Series<double> vswingHighType;
			private Series<double> vswingLowType;
			private Series<double> vavgTrueRange;
			private Series<double> vswingInput;
			private Series<double> pre_swingHighType;
			private Series<double> pre_swingLowType;
			private Series<double> swingHighType;
			private Series<double> swingLowType;
			private int lastLowIdx;
			private int lastHighIdx;
			public Series<bool> upTrend;
			private double vswingMax;
			private double vswingMin;
			private double vzigzagDeviation;
			private bool vupdateHigh;
			private bool vupdateLow;
			private bool vaddHigh;
			private bool vaddLow;
			private bool updateLow;
			private bool updateHigh;
			private double vcurrentHigh;
			private double vcurrentLow;
			private int vlastLowIdx;
			private int vlastHighIdx;
			private int vpriorSwingHighIdx;
			private int vpriorSwingLowIdx;
			private int vhighCount;
			private int vlowCount;
			private int vpreLastHighIdx;
			private int vpreLastLowIdx;
			private int priorSwingHighIdx;
			private int priorSwingLowIdx;
			private double currentHigh;
			private double currentLow;
			private double vmarginUp;
			private double vmarginDown;
			private double vpreCurrentHigh;
			private double vpreCurrentLow;
			private double swingMax;
			private double swingMin;
			private bool vintraBarUpdateHigh;
			private bool vintraBarUpdateLow;
			private bool vintraBarAddHigh;
			private bool vintraBarAddLow;
			private bool addHigh;
			private bool addLow;
			public List<int> sequence = new List<int>(3);
			#endregion

			public StructureBias(NinjaScriptBase Chart_Bars, ISeries<double> high, ISeries<double> low, int swingStrength, bool use_HL, double multiplierMD, double multiplierDTB, Brush trendUpColor, int opacityUp, Brush trendDownColor, int opacityDown)
			{
				#region constructor
				High = high;
				Low = low;
				vupTrend = new Series<bool>(Chart_Bars, MaximumBarsLookBack.Infinite);
				vpre_swingHighType = new Series<double>(Chart_Bars, MaximumBarsLookBack.Infinite);
				vpre_swingLowType = new Series<double>(Chart_Bars, MaximumBarsLookBack.Infinite);
				vswingHighType = new Series<double>(Chart_Bars, MaximumBarsLookBack.Infinite);
				vswingLowType = new Series<double>(Chart_Bars, MaximumBarsLookBack.Infinite);
				vavgTrueRange = new Series<double>(Chart_Bars, MaximumBarsLookBack.Infinite);
				vswingInput = new Series<double>(Chart_Bars, MaximumBarsLookBack.Infinite);
				Bias = new Series<int>(Chart_Bars, MaximumBarsLookBack.Infinite);
				upTrend = new Series<bool>(Chart_Bars, MaximumBarsLookBack.Infinite);
				pre_swingHighType = new Series<double>(Chart_Bars, MaximumBarsLookBack.Infinite);
				pre_swingLowType = new Series<double>(Chart_Bars, MaximumBarsLookBack.Infinite);
				swingHighType = new Series<double>(Chart_Bars, MaximumBarsLookBack.Infinite);
				swingLowType = new Series<double>(Chart_Bars, MaximumBarsLookBack.Infinite);
				SwingStrength = swingStrength;
				isHLBased = use_HL;
				MultiplierMD = multiplierMD;
				MultiplierDTB = multiplierDTB;
				UpTrendColorTinted = trendUpColor.Clone();
				UpTrendColorTinted.Opacity = opacityUp / 100f;
				UpTrendColorTinted.Freeze();
				DownTrendColorTinted = trendDownColor.Clone();
				DownTrendColorTinted.Opacity = opacityDown / 100f;
				DownTrendColorTinted.Freeze();
				#endregion
			}
			private double MAX(ISeries<double> series, int lookback, int rbar_offset)
			{
				var max = series[rbar_offset];
				try
				{
					for (var i = rbar_offset + 1; i < lookback + rbar_offset; i++) 
						max = Math.Max(max, series[i]);
				}
				catch { }
				return max;
			}
			private double MIN(ISeries<double> series, int lookback, int rbar_offset)
			{
				var min = series[rbar_offset];
				try
				{
					for (var i = rbar_offset + 1; i < lookback + rbar_offset; i++) 
						min = Math.Min(min, series[i]);
				}
				catch { }
				return min;
			}
			public void AddToAllPivots(int idx, double price)
			{
				if (AllPivots.Count > 0)
				{
					var ptr = AllPivots.Count - 1;
					var keys = new List<int>(AllPivots.Keys);
					if (price < 0)
					{
						if (AllPivots[keys[ptr]] < 0) AllPivots.Remove(keys[ptr]);
					}
					else if (price > 0)
					{
						if (AllPivots[keys[ptr]] > 0) AllPivots.Remove(keys[ptr]);
					}
				}
				AllPivots[idx] = price;
			}
			#endregion
		}
		private class LevelData
		{
			public int LMAbar = 0;
			public int RMAbar = 0;
			public int State = 0;
			public LevelData(int lmabar, int rmabar, int state) { LMAbar = lmabar; RMAbar = rmabar; State = state; }
		}
		private SortedDictionary<double, LevelData> AllLevels = new SortedDictionary<double, LevelData>();
		private List<double> TerminatedLevels = new List<double>();

		public override string DisplayName { get { return "NS_GoldenFibsSys"; } }

		[Browsable(false)]
		[XmlIgnore]
		internal ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>> Confluences
		{
			get
			{
				return confluences ?? (confluences = new ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>>(() => Values.Take(20), i =>
				{
					if (i > 19)
						throw new IndexOutOfRangeException();

					return Values[i];
				}));
			}
		}
		private ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>> confluences;

		[Browsable(false)]
		[XmlIgnore]
		internal ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>> WeakConfluences
		{
			get
			{
				return weakConfluences ?? (weakConfluences = new ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>>(() => Values.Skip(20).Take(20), i =>
				{
					if (i > 19)
						throw new IndexOutOfRangeException();

					return Values[i + 20];
				}));
			}
		}
		private ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>> weakConfluences;

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && !this.ARC_AutoFibAlgo_IsLicensed())
				return;

			try
			{
				#region State == State.SetDefaults
				if (State == State.SetDefaults)
				{
					PrintTo = PrintTo.OutputTab2;
                Description             = @"Multi-timeframe fib levels with trade plans";
                Name                    = "NS_GoldenFibsSystem_MTF";
                Calculate               = Calculate.OnBarClose;
                IsOverlay               = true;
                PaintPriceMarkers       = false;
                DisplayInDataBox        = false;
                IsAutoScale             = false;
                ArePlotsConfigurable    = false;
                ZOrder                  = 0;
                DrawOnPricePanel        = true;
                ScaleJustification      = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = true;
				pButtonText = "GF System";

                for (int i = 0; i < 20; i++) AddPlot(Brushes.Black, String.Format("Confluence{0}", i));
                for (int i = 0; i < 20; i++) AddPlot(new Stroke(Brushes.Black, DashStyleHelper.Dash, 1), PlotStyle.Line, String.Format("WeakConfluence{0}", i));

				//uID = Guid.NewGuid().ToString().Replace("-",string.Empty);

				#region -- default parameters --
                BarPeriod               = 5;
                LineDensity             = ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Default;
                ConfluenceZone          = ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth.Strong;
                Threshold               = 100;
                LookBackMinute          = 300;
                ShowMinuteDataPeriod    = false;
                ResistanceColor         = Brushes.Maroon;
                SupportColor            = Brushes.Blue;
                StrongPlotStyle         = PlotStyle.Line;
                WeakPlotStyle           = PlotStyle.Line;
                StrongDashStyle         = DashStyleHelper.Solid;
                WeakDashStyle           = DashStyleHelper.Solid;
                LineWidthStrong         = 2;
                LineWidthWeak           = 2;
                #endregion

				#region SwingTrend Defaults
				SwingStrength = 3;
                isHLBased = true;
				ShowStructureLines = true;
				UpTrendColor = Brushes.Green;
				OpacityUpTrendBkg = 20;
				DownTrendColor = Brushes.Maroon;
				OpacityDownTrendBkg = 20;
				UpLineColor   = Brushes.DarkGreen;
				DownLineColor = Brushes.Red;
				LineThickness = 2;
                ZZlabelFont = new SimpleFont("Arial", 12);
				ShowStructureLabels = false;
				#endregion

				//pFarSell_RayTemplate  = "Default";
				//pNearSell_RayTemplate = "Default";
				//pNearBuy_RayTemplate  = "Default";
				//pFarBuy_RayTemplate   = "Default";
				}
				#endregion

				#region State == State.Configure
				if (State == State.Configure)
				{
					if (getBench) benchStart = DateTime.Now;

					AddDataSeries(BarsPeriodType.Minute, BarPeriod);

					if (IsAutoScale) IsAutoScale = false;
				}
				#endregion

				#region State == State.Historical
				if (State == State.Historical)
				{
					#region -- end of initialization with User Parameters --
					for (var i = 0; i < 10; i++)
					{
						Plots[i].Brush = ResistanceColor;
						Plots[i].PlotStyle = StrongPlotStyle;
						Plots[i].DashStyleHelper = StrongDashStyle;
						Plots[i].Width = LineWidthStrong;
					}
					for (var i = 10; i < 20; i++)
					{
						Plots[i].Brush = SupportColor;
						Plots[i].PlotStyle = StrongPlotStyle;
						Plots[i].DashStyleHelper = StrongDashStyle;
						Plots[i].Width = LineWidthStrong;
					}
					for (var i = 20; i < 30; i++)
					{
						Plots[i].Brush = ResistanceColor;
						Plots[i].PlotStyle = WeakPlotStyle;
						Plots[i].DashStyleHelper = WeakDashStyle;
						Plots[i].Width = LineWidthWeak;
					}
					for (var i = 30; i < 40; i++)
					{
						Plots[i].Brush = SupportColor;
						Plots[i].PlotStyle = WeakPlotStyle;
						Plots[i].DashStyleHelper = WeakDashStyle;
						Plots[i].Width = LineWidthWeak;
					}
					#endregion
					ObjTagPrefix = string.Format("{0}#{1}{2}", Instrument.MasterInstrument.Name, DateTime.Now.Second, DateTime.Now.Millisecond);

				}
				#endregion

				#region State == State.DataLoaded
				if (State == State.DataLoaded)
				{
					StructureBiasMgr = new StructureBias(this, Highs[0], Lows[0], SwingStrength, isHLBased, MultiplierMD, MultiplierDTB, UpTrendColor, OpacityUpTrendBkg, DownTrendColor, OpacityDownTrendBkg);

					#region -- Init Arrays --
					for (var i = 0; i < 10; i++)
					{
						timeFrameFactor[i] = i == 0 ? 1 : Math.Sqrt(stepUpRatio) * timeFrameFactor[i - 1];

						upTrend[i] = true;
						existsSwingHigh[i] = false;
						existsSwingLow[i] = false;
						minimumDeviation[i] = double.MaxValue;
						for (var j = 0; j < 20; j++)
						{
							microHigh[i, j] = double.MaxValue;
							microLow[i, j] = double.MinValue;
						}
						currentHigh[i] = 0;
						currentLow[i] = 0;
						currentSwingHigh[i] = double.MaxValue;
						currentSwingLow[i] = double.MinValue;
						lastSwingHigh[i] = double.MaxValue;
						lastSwingLow[i] = double.MinValue;
						microSwingHigh0[i] = double.MaxValue;
						microSwingHigh1[i] = double.MaxValue;
						microSwingHigh2[i] = double.MaxValue;
						microSwingHigh3[i] = double.MaxValue;
						microSwingLow0[i] = double.MinValue;
						microSwingLow1[i] = double.MinValue;
						microSwingLow2[i] = double.MinValue;
						microSwingLow3[i] = double.MinValue;
						retUp0[i] = 0;
						retUp23[i] = 0;
						retUp38[i] = 0;
						retUp50[i] = 0;
						retUp62[i] = 0;
						retUp76[i] = 0;
						retUp100[i] = 0;
						retDown0[i] = 0;
						retDown23[i] = 0;
						retDown38[i] = 0;
						retDown50[i] = 0;
						retDown62[i] = 0;
						retDown76[i] = 0;
						retDown100[i] = 0;
						extUp0[i] = 0;
						extUp100[i] = 0;
						extUp127[i] = 0;
						extUp162[i] = 0;
						extUp200[i] = 0;
						extUp262[i] = 0;
						extUp300[i] = 0;
						extUp423[i] = 0;
						extDown0[i] = 0;
						extDown100[i] = 0;
						extDown127[i] = 0;
						extDown162[i] = 0;
						extDown200[i] = 0;
						extDown262[i] = 0;
						extDown300[i] = 0;
						extDown423[i] = 0;
						dirUp38[i] = 0;
						dirUp62[i] = 0;
						dirUp100[i] = 0;
						dirDown38[i] = 0;
						dirDown62[i] = 0;
						dirDown100[i] = 0;
						lastDirUp38[i] = 0;
						lastDirUp62[i] = 0;
						lastDirUp100[i] = 0;
						lastDirDown38[i] = 0;
						lastDirDown62[i] = 0;
						lastDirDown100[i] = 0;
						alt0Up[i] = 0;
						alt0Down[i] = 0;
						alt1Up[i] = 0;
						alt1Down[i] = 0;
						alt0Up62[i] = 0;
						alt0Up100[i] = 0;
						alt0Up162[i] = 0;
						alt1Up100[i] = 0;
						alt0Down62[i] = 0;
						alt0Down100[i] = 0;
						alt0Down162[i] = 0;
						alt1Down100[i] = 0;
						priorCurrentHigh[i] = 0;
						priorCurrentLow[i] = 0;
						priorMicroSwingHigh0[i] = double.MaxValue;
						priorMicroSwingHigh1[i] = double.MaxValue;
						priorMicroSwingHigh2[i] = double.MaxValue;
						priorMicroSwingHigh3[i] = double.MaxValue;
						priorMicroSwingLow0[i] = double.MinValue;
						priorMicroSwingLow1[i] = double.MinValue;
						priorMicroSwingLow2[i] = double.MinValue;
						priorMicroSwingLow3[i] = double.MinValue;
						priorCurrentSwingHigh[i] = 0;
						priorLastSwingHigh[i] = 0;
						priorCurrentSwingLow[i] = 0;
						priorLastSwingLow[i] = 0;
						priorRetUp0[i] = 0;
						priorRetUp23[i] = 0;
						priorRetUp38[i] = 0;
						priorRetUp50[i] = 0;
						priorRetUp62[i] = 0;
						priorRetUp76[i] = 0;
						priorRetUp100[i] = 0;
						priorRetDown0[i] = 0;
						priorRetDown23[i] = 0;
						priorRetDown38[i] = 0;
						priorRetDown50[i] = 0;
						priorRetDown62[i] = 0;
						priorRetDown76[i] = 0;
						priorRetDown100[i] = 0;
						priorExtUp0[i] = 0;
						priorExtUp100[i] = 0;
						priorExtUp127[i] = 0;
						priorExtUp162[i] = 0;
						priorExtUp200[i] = 0;
						priorExtUp262[i] = 0;
						priorExtUp300[i] = 0;
						priorExtUp423[i] = 0;
						priorExtDown0[i] = 0;
						priorExtDown100[i] = 0;
						priorExtDown127[i] = 0;
						priorExtDown162[i] = 0;
						priorExtDown200[i] = 0;
						priorExtDown262[i] = 0;
						priorExtDown300[i] = 0;
						priorExtDown423[i] = 0;
						priorDirUp38[i] = 0;
						priorDirUp62[i] = 0;
						priorDirUp100[i] = 0;
						priorDirDown38[i] = 0;
						priorDirDown62[i] = 0;
						priorDirDown100[i] = 0;
						priorLastDirUp38[i] = 0;
						priorLastDirUp62[i] = 0;
						priorLastDirUp100[i] = 0;
						priorLastDirDown38[i] = 0;
						priorLastDirDown62[i] = 0;
						priorLastDirDown100[i] = 0;
						priorAlt0Up62[i] = 0;
						priorAlt0Up100[i] = 0;
						priorAlt0Up162[i] = 0;
						priorAlt1Up100[i] = 0;
						priorAlt0Down62[i] = 0;
						priorAlt0Down100[i] = 0;
						priorAlt0Down162[i] = 0;
						priorAlt1Down100[i] = 0;
						countDown[i] = -1;
						currentSwingHighIndex[i] = -100;
						lastSwingHighIndex[i] = -100;
						currentSwingLowIndex[i] = -100;
						lastSwingLowIndex[i] = -100;
						weightMicroSwingHigh0[i] = 0;
						weightMicroSwingHigh1[i] = 0;
						weightMicroSwingHigh2[i] = 0;
						weightMicroSwingHigh3[i] = 0;
						weightMicroSwingLow0[i] = 0;
						weightMicroSwingLow1[i] = 0;
						weightMicroSwingLow2[i] = 0;
						weightMicroSwingLow3[i] = 0;
						weightCurrentSwingHigh[i] = 0;
						weightLastSwingHigh[i] = 0;
						weightCurrentSwingLow[i] = 0;
						weightLastSwingLow[i] = 0;
						weightRetUp23[i] = 0;
						weightRetUp38[i] = 0;
						weightRetUp50[i] = 0;
						weightRetUp62[i] = 0;
						weightRetUp76[i] = 0;
						weightRetDown23[i] = 0;
						weightRetDown38[i] = 0;
						weightRetDown50[i] = 0;
						weightRetDown62[i] = 0;
						weightRetDown76[i] = 0;
						weightExtUp127[i] = 0;
						weightExtUp162[i] = 0;
						weightExtUp200[i] = 0;
						weightExtUp262[i] = 0;
						weightExtUp300[i] = 0;
						weightExtUp423[i] = 0;
						weightExtDown127[i] = 0;
						weightExtDown162[i] = 0;
						weightExtDown200[i] = 0;
						weightExtDown262[i] = 0;
						weightExtDown300[i] = 0;
						weightExtDown423[i] = 0;
						weightDirUp38[i] = 0;
						weightDirUp62[i] = 0;
						weightDirUp100[i] = 0;
						weightDirDown38[i] = 0;
						weightDirDown62[i] = 0;
						weightDirDown100[i] = 0;
						weightLastDirUp38[i] = 0;
						weightLastDirUp62[i] = 0;
						weightLastDirUp100[i] = 0;
						weightLastDirDown38[i] = 0;
						weightLastDirDown62[i] = 0;
						weightLastDirDown100[i] = 0;
						weightAlt0Up62[i] = 0;
						weightAlt0Up100[i] = 0;
						weightAlt0Up162[i] = 0;
						weightAlt1Up100[i] = 0;
						weightAlt0Down62[i] = 0;
						weightAlt0Down100[i] = 0;
						weightAlt0Down162[i] = 0;
						weightAlt1Down100[i] = 0;
						cumulatedWeightMicroSwingHigh0[i] = 0;
						cumulatedWeightMicroSwingHigh1[i] = 0;
						cumulatedWeightMicroSwingHigh2[i] = 0;
						cumulatedWeightMicroSwingHigh3[i] = 0;
						cumulatedWeightMicroSwingLow0[i] = 0;
						cumulatedWeightMicroSwingLow1[i] = 0;
						cumulatedWeightMicroSwingLow2[i] = 0;
						cumulatedWeightMicroSwingLow3[i] = 0;
						cumulatedWeightCurrentSwingHigh[i] = 0;
						cumulatedWeightLastSwingHigh[i] = 0;
						cumulatedWeightCurrentSwingLow[i] = 0;
						cumulatedWeightLastSwingLow[i] = 0;
						cumulatedWeightRetUp23[i] = 0;
						cumulatedWeightRetUp38[i] = 0;
						cumulatedWeightRetUp50[i] = 0;
						cumulatedWeightRetUp62[i] = 0;
						cumulatedWeightRetUp76[i] = 0;
						cumulatedWeightRetDown23[i] = 0;
						cumulatedWeightRetDown38[i] = 0;
						cumulatedWeightRetDown50[i] = 0;
						cumulatedWeightRetDown62[i] = 0;
						cumulatedWeightRetDown76[i] = 0;
						cumulatedWeightExtUp127[i] = 0;
						cumulatedWeightExtUp162[i] = 0;
						cumulatedWeightExtUp200[i] = 0;
						cumulatedWeightExtUp262[i] = 0;
						cumulatedWeightExtUp300[i] = 0;
						cumulatedWeightExtUp423[i] = 0;
						cumulatedWeightExtDown127[i] = 0;
						cumulatedWeightExtDown162[i] = 0;
						cumulatedWeightExtDown200[i] = 0;
						cumulatedWeightExtDown262[i] = 0;
						cumulatedWeightExtDown300[i] = 0;
						cumulatedWeightExtDown423[i] = 0;
						cumulatedWeightDirUp38[i] = 0;
						cumulatedWeightDirUp62[i] = 0;
						cumulatedWeightDirUp100[i] = 0;
						cumulatedWeightDirDown38[i] = 0;
						cumulatedWeightDirDown62[i] = 0;
						cumulatedWeightDirDown100[i] = 0;
						cumulatedWeightLastDirUp38[i] = 0;
						cumulatedWeightLastDirUp62[i] = 0;
						cumulatedWeightLastDirUp100[i] = 0;
						cumulatedWeightLastDirDown38[i] = 0;
						cumulatedWeightLastDirDown62[i] = 0;
						cumulatedWeightLastDirDown100[i] = 0;
						cumulatedWeightAlt0Up62[i] = 0;
						cumulatedWeightAlt0Up100[i] = 0;
						cumulatedWeightAlt0Up162[i] = 0;
						cumulatedWeightAlt1Up100[i] = 0;
						cumulatedWeightAlt0Down62[i] = 0;
						cumulatedWeightAlt0Down100[i] = 0;
						cumulatedWeightAlt0Down162[i] = 0;
						cumulatedWeightAlt1Down100[i] = 0;
					}
					for (var i = 0; i < 20; i++)
					{
						strongFibs[i] = 0;
						weakFibs[i] = 0;
						priorStrongFibs[i] = 0;
						priorWeakFibs[i] = 0;
						oldStrongFibs[i] = 0;
						oldWeakFibs[i] = 0;
					}
					for (var i = 0; i < 40; i++)
					{
						newBOBHigh[i] = 0.0;
						oldBOBHigh[i] = 0.0;
						newBOBLow[i] = 0.0;
						oldBOBLow[i] = 0.0;
						newBOBClose[i] = 0.0;
						oldBOBClose[i] = 0.0;
						newState[i] = 1;
						oldState[i] = 1;
					}
					for (var i = 0; i < 540; i++)
					{
						fibLine[i] = 0;
						fibWeight[i] = 0;
						fibResistance[i] = 0;
						weakResistance[i] = 0;
						weightResistance[i] = 0;
						fibSupport[i] = 0;
						weakSupport[i] = 0;
						weightSupport[i] = 0;
					}
					#endregion
					ResNear = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResNear_SL = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResNear_T1 = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResNear_T2 = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResNear_En = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResNear_AH = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResNear_AL = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResFar = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResFar_SL = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResFar_T1 = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResFar_T2 = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResFar_En = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResFar_AH = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					ResFar_AL = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupNear = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupNear_SL = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupNear_T1 = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupNear_T2 = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupNear_En = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupNear_AH = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupNear_AL = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupFar = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupFar_SL = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupFar_T1 = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupFar_T2 = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupFar_En = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupFar_AH = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					SupFar_AL = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					atr = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
					#region -- calculate zigZagFactor and confluenceRange --
					zigZagFactor = Math.Max(8, 16.0 / Math.Pow(BarPeriod, 0.25));
					if (ConfluenceZone == ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth.Weak)
						zigZagFactor = 1.2 * zigZagFactor;
					if (LineDensity == ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Small)
						zigZagFactor /= 1.4;
					else if (LineDensity == ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Smallest)
						zigZagFactor /= 1.96;
					else if (LineDensity == ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Increased)
						zigZagFactor = 1.4 * zigZagFactor;
					else if (LineDensity == ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Large)
						zigZagFactor = 1.96 * zigZagFactor;
					else if (LineDensity == ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Largest)
						zigZagFactor = 2.74 * zigZagFactor;
					if (ConfluenceZone == ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth.Strong)
						confluenceRange = 0.2 * zigZagFactor;
					else
						confluenceRange = 0.1 * zigZagFactor;
					#endregion

					#region -- preloading code if needed --

					var firstBarTime = DateTime.MinValue;
					var minuteBarsStartDate = DateTime.MinValue;
					try { firstBarTime = BarsArray[1].GetTime(0); } catch { firstBarTime = BarsArray[0].GetTime(0); }
					try { minuteBarsStartDate = BarsArray[1].LastBarTime.AddDays(-LookBackMinute).Date; }
					catch { minuteBarsStartDate = BarsArray[0].LastBarTime.AddDays(-LookBackMinute).Date; }

					if (minuteBarsStartDate.CompareTo(firstBarTime.Date) < 0) preloadMinuteData = true;
					else preloadMinuteData = false;//no need preload because aleady 300days on the chart

					if (preloadMinuteData)
					{
						minuteBars = loadHistoricalBars(Bars.ToDate.AddDays(-LookBackMinute).Date, Bars.ToDate);//preload bars - sync code
						if (minuteBars == null || minuteBars.Count <= 1)//if no historical data
						{
							textBrush = ChartControl.Properties.AxisPen.Brush;
							Draw.TextFixed(this, "errortag", errorData, TextPosition.Center, textBrush, textFont, Brushes.Transparent, Brushes.Transparent, 0);
							generalError = true;
						}
						else
						{
							var minuteBarsStart = "";
							var minuteBarsCulture = new CultureInfo("en-us");

							#region -- Calculate ATR and Fibs after 14 days --
							while (minuteBars.GetTime(minuteBarIndex).CompareTo(firstBarTime) < 0)
							{
								priorBarHigh = minuteBars.GetHigh(minuteBarIndex);
								priorBarLow = minuteBars.GetLow(minuteBarIndex);
								priorBarClose = minuteBars.GetClose(minuteBarIndex);
								currentBarHigh = minuteBars.GetHigh(minuteBarIndex + 1);
								currentBarLow = minuteBars.GetLow(minuteBarIndex + 1);
								currentBarClose = minuteBars.GetClose(minuteBarIndex + 1);

								if (minuteBarIndex == 0)
								{
									minuteBarsStart = minuteBars.GetTime(minuteBarIndex).Date.ToString("d MMM yyyy", minuteBarsCulture);
									firstSessionBegin = minuteBars.GetTime(minuteBarIndex).Date;
								}
								else if (minuteBarIndex == 1)
								{
									for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
									{
										currentHigh[i] = currentBarHigh;
										currentLow[i] = currentBarLow;
									}
									currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
									avgTrueRange = currentBarTrueRange;
								}
								else
								{
									currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
									avgTrueRange = avgTrueRange * (minuteBarIndex - 1) / minuteBarIndex + currentBarTrueRange / minuteBarIndex;
									if (minuteBars.GetTime(minuteBarIndex).CompareTo(firstSessionBegin.AddDays(14)) > 0)
									{
										for (var i = lowestTimeFrame; i <= highestTimeFrame; i++) CalculateFibonacci(i);
										isTrainingComplete = true;
									}
								}
								minuteBarIndex++;
							}
							#endregion
							lastMinuteBarTime = minuteBars.GetTime(minuteBarIndex - 1);
							if (ShowMinuteDataPeriod)
							{
								var minuteBarsEnd = minuteBars.GetTime(minuteBarIndex).Date.ToString("d MMM yyyy", minuteBarsCulture);
								preloadedData = "NS_GoldenFibsSystemtem v 2.0: Minute data preloaded from " + minuteBarsStart + " to " + minuteBarsEnd + " with " + minuteBars.Count + " bars";
								textBrush = ChartControl.Properties.AxisPen.Brush;
								drawPreloadInfo = true;
							}
						}
					}
					else if (ShowMinuteDataPeriod)
					{
						preloadedData = "NS_GoldenFibsSystemtem v 2.0: No minute data preloaded";
						textBrush = ChartControl.Properties.AxisPen.Brush;
						drawPreloadInfo = true;
					}
					#endregion

				}
				#endregion

				#region State == State.Realtime
				if (State == State.Realtime)
				{
					if (getBench)
					{
						benchStop = DateTime.Now;
						getBench = false;//only one print                    
						Print("Loading time : " + benchStop.Subtract(benchStart).TotalMilliseconds);
					}
				}
				#endregion

			}
			catch (Exception e)
			{
				Draw.TextFixed(this, "InitError", "NS_GoldenFibsSystemtem_MTF\n\nError during initialization...are you connected to your active datafeed?\n\nSee OutputWindow for more details", TextPosition.Center, Brushes.White, new SimpleFont("Arial", 12), Brushes.Maroon, Brushes.Maroon, 80);
			}
		}
		
		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_AutoFibAlgo_IsLicensed())
				return;

			try
			{
				if (!BarsType.CreateInstance(Bars.BarsPeriod.BarsPeriodType).IsIntraday) return;
				if (generalError) return;

				if (BarsInProgress == 1)
				{
					#region -- preload needed --

					if (preloadMinuteData)
					{
						#region -- Calculate on bar close --

						if (Calculate == Calculate.OnBarClose)
						{
							if (Times[1][0].CompareTo(lastMinuteBarTime) <= 0) return;
							currentBars1 = CurrentBars[1];
							priorBarHigh = currentBarHigh;
							priorBarLow = currentBarLow;
							priorBarClose = currentBarClose;
							currentBarHigh = Highs[1][0];
							currentBarLow = Lows[1][0];
							currentBarClose = Closes[1][0];
							currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
							avgTrueRange = avgTrueRange * (minuteBarIndex - 1) / minuteBarIndex + currentBarTrueRange / minuteBarIndex;
							minuteBarIndex++;
							//==============================================================================================================================
							// Calculates Swing Highs and Lows, Retracements, Extensions, Alternates and Projections from currentBarHigh and currentBarLow
							//==============================================================================================================================
							if (Times[1][0].CompareTo(firstSessionBegin.AddDays(14)) > 0)
							{
								for (var i = lowestTimeFrame; i <= highestTimeFrame; i++) CalculateFibonacci(i);
								isTrainingComplete = true;
							}

							confluenceRangeWidth = confluenceRange * avgTrueRange;
							upperLimitResistance = MAX(Highs[1], 20)[0] + displayFactor * avgTrueRange;
							lowerLimitResistance = Closes[1][0];
							upperLimitSupport = Closes[1][0];
							lowerLimitSupport = MIN(Lows[1], 20)[0] - displayFactor * avgTrueRange;
							upperLimitWeakResistance = MAX(Highs[1], 20)[0] + displayFactor * avgTrueRange;
							lowerLimitWeakSupport = MIN(Lows[1], 20)[0] - displayFactor * avgTrueRange;
						}

						#endregion

						#region -- Calculate on eachtick or change --

						else if (CurrentBars[1] == 0) currentBars1 = CurrentBars[1];
						else if (IsFirstTickOfBar)
						{
							if (Times[1][1].CompareTo(lastMinuteBarTime) <= 0) return;
							currentBars1 = CurrentBars[1];
							priorBarHigh = currentBarHigh;
							priorBarLow = currentBarLow;
							priorBarClose = currentBarClose;
							currentBarHigh = Highs[1][1];
							currentBarLow = Lows[1][1];
							currentBarClose = Closes[1][1];
							currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
							avgTrueRange = avgTrueRange * (minuteBarIndex - 1) / minuteBarIndex + currentBarTrueRange / minuteBarIndex;
							minuteBarIndex++;
							//==============================================================================================================================
							// Calculates Swing Highs and Lows, Retracements, Extensions, Alternates and Projections from currentBarHigh and currentBarLow
							//==============================================================================================================================
							if (Times[1][1].CompareTo(firstSessionBegin.AddDays(14)) > 0)
							{
								for (var i = lowestTimeFrame; i <= highestTimeFrame; i++) CalculateFibonacci(i);
								isTrainingComplete = true;
							}

							confluenceRangeWidth = confluenceRange * avgTrueRange;
							upperLimitResistance = MAX(Highs[1], 20)[1] + displayFactor * avgTrueRange;
							lowerLimitResistance = Closes[1][1];
							upperLimitSupport = Closes[1][1];
							lowerLimitSupport = MIN(Lows[1], 20)[1] - displayFactor * avgTrueRange;
							upperLimitWeakResistance = MAX(Highs[1], 20)[1] + displayFactor * avgTrueRange;
							lowerLimitWeakSupport = MIN(Lows[1], 20)[1] - displayFactor * avgTrueRange;
						}

						#endregion
					}

					#endregion

					#region -- no preload needed --

					else if (Times[1][0].CompareTo(firstSessionBegin) > 0) //no calculous if more than 300 days
					{
						#region -- Calculate on bar close --

						if (Calculate == Calculate.OnBarClose)
						{
							priorBarHigh = currentBarHigh;
							priorBarLow = currentBarLow;
							priorBarClose = currentBarClose;
							currentBarHigh = Highs[1][0];
							currentBarLow = Lows[1][0];
							currentBarClose = Closes[1][0];
							if (minuteBarIndex == 1)
							{
								for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
								{
									currentHigh[i] = priorBarHigh;
									currentLow[i] = priorBarLow;
								}

								currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
								avgTrueRange = currentBarTrueRange;
							}
							else if (minuteBarIndex > 1)
							{
								currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
								avgTrueRange = avgTrueRange * (minuteBarIndex - 1) / minuteBarIndex + currentBarTrueRange / minuteBarIndex;
								//==============================================================================================================================
								// Calculates Swing Highs and Lows, Retracements, Extensions, Alternates and Projections from currentBarHigh and currentBarLow
								//==============================================================================================================================
								if (Times[1][0].CompareTo(firstSessionBegin.AddDays(14)) > 0)
								{
									for (var i = lowestTimeFrame; i <= highestTimeFrame; i++) CalculateFibonacci(i);
									isTrainingComplete = true;
								}

								confluenceRangeWidth = confluenceRange * avgTrueRange;
								upperLimitResistance = MAX(Highs[1], 20)[0] + displayFactor * avgTrueRange;
								lowerLimitResistance = Closes[1][0];
								upperLimitSupport = Closes[1][0];
								lowerLimitSupport = MIN(Lows[1], 20)[0] - displayFactor * avgTrueRange;
								upperLimitWeakResistance = MAX(Highs[1], 20)[0] + displayFactor * avgTrueRange;
								lowerLimitWeakSupport = MIN(Lows[1], 20)[0] - displayFactor * avgTrueRange;
							}

							minuteBarIndex++;
						}

						#endregion

						#region -- Calculate on eachtick or change --

						else if (CurrentBars[1] == 0)
						{
							currentBarHigh = Highs[1][0];
							currentBarLow = Lows[1][0];
							currentBarClose = Closes[1][0];
						}
						else if (CurrentBars[1] > 0 && IsFirstTickOfBar)
						{
							priorBarHigh = currentBarHigh;
							priorBarLow = currentBarLow;
							priorBarClose = currentBarClose;
							currentBarHigh = Highs[1][1];
							currentBarLow = Lows[1][1];
							currentBarClose = Closes[1][1];
							if (minuteBarIndex == 1)
							{
								for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
								{
									currentHigh[i] = priorBarHigh;
									currentLow[i] = priorBarLow;
								}

								currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
								avgTrueRange = currentBarTrueRange;
							}
							else if (minuteBarIndex > 1)
							{
								currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
								avgTrueRange = avgTrueRange * (minuteBarIndex - 1) / minuteBarIndex + currentBarTrueRange / minuteBarIndex;
								//==============================================================================================================================
								// Calculates Swing Highs and Lows, Retracements, Extensions, Alternates and Projections from currentBarHigh and currentBarLow
								//==============================================================================================================================
								if (Times[1][1].CompareTo(firstSessionBegin.AddDays(14)) > 0)
								{
									for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
										CalculateFibonacci(i);
									isTrainingComplete = true;
								}

								confluenceRangeWidth = confluenceRange * avgTrueRange;
								upperLimitResistance = MAX(Highs[1], 20)[1] + displayFactor * avgTrueRange;
								lowerLimitResistance = Closes[1][1];
								upperLimitSupport = Closes[1][1];
								lowerLimitSupport = MIN(Lows[1], 20)[1] - displayFactor * avgTrueRange;
								upperLimitWeakResistance = MAX(Highs[1], 20)[1] + displayFactor * avgTrueRange;
								lowerLimitWeakSupport = MIN(Lows[1], 20)[1] - displayFactor * avgTrueRange;
							}

							minuteBarIndex++;
						}

						#endregion
					}

					#endregion
				}

				if (BarsInProgress == 0)
				{
					if (drawPreloadInfo)
					{
						Draw.TextFixed(this, "data check", preloadedData, TextPosition.BottomRight, textBrush,
							textFont2, Brushes.Transparent, Brushes.Transparent, 1);
						drawPreloadInfo = false;
					}

					if (CurrentBars[0] < 2) return;

					if (isTrainingComplete && (IsFirstTickOfBar || currentBars1 > priorCurrentBars1))
					{
						priorCurrentBars1 = currentBars1;

						//==============================================================================================================================
						// Sets all lines and weights within the display range
						// Note : this is the hot path. It takes on average 1ms to run for each bar. On a 5 days 1Min barchart = 37000 bars, it takes 3.7s to run.
						//==============================================================================================================================
						SetLinesAndWeights();

						//==============================================================================================================================
						// Selects strong and weak lines above defined theshold for weight and checks whether weaker lines are in the smaller display range
						//==============================================================================================================================
						SelectLines();

						//==============================================================================================================================
						// Sorting Arrays fibLine, fibWeight, fibLine and  fibWeight with BubbleSort to prepare for Analyzer
						// Note : the sorting method has been written to be faster than the Array.Sort c# method.
						//==============================================================================================================================
						SortLines();

						//==============================================================================================================================

						#region Display up to 10 Resistance and 10 Support Ranges

						for (var i = 0; i < 10; i++)
						{
							strongFibs[i] = Instrument.MasterInstrument.RoundToTickSize(fibSupport[9 - i]);
							strongFibs[10 + i] = Instrument.MasterInstrument.RoundToTickSize(fibResistance[i]);
							weakFibs[i] = Instrument.MasterInstrument.RoundToTickSize(weakSupport[9 - i]);
							weakFibs[10 + i] = Instrument.MasterInstrument.RoundToTickSize(weakResistance[i]);
						}

						if (IsFirstTickOfBar)
						{
							for (var i = 0; i < 20; i++)
							{
								oldStrongFibs[i] = Instrument.MasterInstrument.RoundToTickSize(priorStrongFibs[i]);
								oldState[i] = newState[i];
								oldBOBHigh[i] = newBOBHigh[i];
								oldBOBLow[i] = newBOBLow[i];
								oldBOBClose[i] = newBOBClose[i];
								if (SHOW_WEAKER_LINES)
								{
									var j = i + 20;
									oldWeakFibs[i] = Instrument.MasterInstrument.RoundToTickSize(priorWeakFibs[i]);
									oldState[j] = newState[j];
									oldBOBHigh[j] = newBOBHigh[j];
									oldBOBLow[j] = newBOBLow[j];
									oldBOBClose[j] = newBOBClose[j];
								}
							}
						}

						for (var i = 0; i < 20; i++)
						{
							for (var j = 0; j < 20; j++)
							{
								if (strongFibs[j] == oldStrongFibs[i])
								{
									strongFibs[j] = Instrument.MasterInstrument.RoundToTickSize(strongFibs[i]);
									strongFibs[i] = Instrument.MasterInstrument.RoundToTickSize(oldStrongFibs[i]);
								}

								if (weakFibs[j] == oldWeakFibs[i])
								{
									weakFibs[j] = Instrument.MasterInstrument.RoundToTickSize(weakFibs[i]);
									weakFibs[i] = Instrument.MasterInstrument.RoundToTickSize(oldWeakFibs[i]);
								}
							}
						}

						#region -- SET Confluences to strongFibs --

						Confluence0[0] = strongFibs[0];
						Confluence1[0] = strongFibs[1];
						Confluence2[0] = strongFibs[2];
						Confluence3[0] = strongFibs[3];
						Confluence4[0] = strongFibs[4];
						Confluence5[0] = strongFibs[5];
						Confluence6[0] = strongFibs[6];
						Confluence7[0] = strongFibs[7];
						Confluence8[0] = strongFibs[8];
						Confluence9[0] = strongFibs[9];
						Confluence10[0] = strongFibs[10];
						Confluence11[0] = strongFibs[11];
						Confluence12[0] = strongFibs[12];
						Confluence13[0] = strongFibs[13];
						Confluence14[0] = strongFibs[14];
						Confluence15[0] = strongFibs[15];
						Confluence16[0] = strongFibs[16];
						Confluence17[0] = strongFibs[17];
						Confluence18[0] = strongFibs[18];
						Confluence19[0] = strongFibs[19];

						#endregion

						//newState und newBobClose determined via fib values
						lowestResistance = double.MaxValue;
						highestSupport = double.MinValue;
						//bool inzone = Time[0].Day==11 && Time[0].Month==6 && Time[0].Hour==10;

						for (var i = 0; i < 20; i++)
						{
							tmpFibValue = strongFibs[i];
							priorStrongFibs[i] = tmpFibValue;
							tmpOldState = oldState[i];
							newState[i] = UpdateState(newState[i], oldState[i], oldStrongFibs[i], tmpFibValue,
								Highs[0][0], Lows[0][0], Closes[0][0]);

							if (newState[i] == 0)
								PlotBrushes[i][0] = Brushes.Transparent;
							else if (newState[i] == 1 || newState[i] == 2)
							{
								PlotBrushes[i][0] = ResistanceColor;
								lowestResistance = Math.Min(tmpFibValue, lowestResistance);
							}
							else if (newState[i] == 3 || newState[i] == 4)
							{
								PlotBrushes[i][0] = SupportColor;
								highestSupport = Math.Max(tmpFibValue, highestSupport);
							}
						}

						#endregion

						#region if (SHOW_WEAKER_LINES)

						if (SHOW_WEAKER_LINES)
						{
							#region -- SET WeakConfluences to weakFibs --

							WeakConfluence0[0] = weakFibs[0];
							WeakConfluence1[0] = weakFibs[1];
							WeakConfluence2[0] = weakFibs[2];
							WeakConfluence3[0] = weakFibs[3];
							WeakConfluence4[0] = weakFibs[4];
							WeakConfluence5[0] = weakFibs[5];
							WeakConfluence6[0] = weakFibs[6];
							WeakConfluence7[0] = weakFibs[7];
							WeakConfluence8[0] = weakFibs[8];
							WeakConfluence9[0] = weakFibs[9];
							WeakConfluence10[0] = weakFibs[10];
							WeakConfluence11[0] = weakFibs[11];
							WeakConfluence12[0] = weakFibs[12];
							WeakConfluence13[0] = weakFibs[13];
							WeakConfluence14[0] = weakFibs[14];
							WeakConfluence15[0] = weakFibs[15];
							WeakConfluence16[0] = weakFibs[16];
							WeakConfluence17[0] = weakFibs[17];
							WeakConfluence18[0] = weakFibs[18];
							WeakConfluence19[0] = weakFibs[19];

							#endregion

							for (var i = 20; i < 40; i++)
							{
								tmpFibValue = weakFibs[i - 20];
								priorWeakFibs[i - 20] = tmpFibValue;
								tmpOldState = oldState[i];
								newState[i] = UpdateState(newState[i], oldState[i], oldWeakFibs[i - 20], tmpFibValue,
									Highs[0][0], Lows[0][0], Closes[0][0]);

								if (newState[i] == 0)
									PlotBrushes[i][0] = Brushes.Transparent;
								else if (newState[i] == 1 || newState[i] == 2)
								{
									PlotBrushes[i][0] = ResistanceColor;
									//                                lowestResistance = Math.Min(tmpFibValue, lowestResistance);
								}
								else if (newState[i] == 3 || newState[i] == 4)
								{
									PlotBrushes[i][0] = SupportColor;
									//                                highestSupport = Math.Max(tmpFibValue, highestSupport);
								}
							}
						}

						#endregion

						//if(IncludeTerminatedLevels)
						for (var i = 0; i < 40; i++)
						{
							if (AllLevels.ContainsKey(Values[i][0]))
							{
								AllLevels[Values[i][0]].RMAbar = CurrentBar;
								AllLevels[Values[i][0]].State = newState[i];
								//if(inzone && Values[i][0]==65.79) Print(Time[0].ToString()+"  3562  State: "+newState[i]+"   "+Bars.GetTime(CurrentBar).ToString());
							}
							else
							{
								AllLevels[Values[i][0]] = new LevelData(CurrentBar, CurrentBar, newState[i]);
								//if(inzone && Values[i][0]==65.79) Print(Time[0].ToString()+"  3565  State: "+newState[i]+"   "+Bars.GetTime(CurrentBar).ToString());
							}
						}

						TerminatedLevels.Clear();
						var near_support = double.MinValue;
						var far_support = double.MinValue;
						var keys = new List<double>(AllLevels.Keys);
						for (var i = 0; i < keys.Count; i++)
						{
							if (AllLevels[keys[i]].RMAbar < CurrentBar)
							{
								TerminatedLevels.Add(keys[i]);
								AllLevels[keys[i]].State = int.MinValue; //slated for removal
								//if(inzone)Print(Time[0].ToString()+"  AllLevels["+keys[i].ToString()+"].State: "+AllLevels[keys[i]].State);
							}

							if (AllLevels[keys[i]].State == 3 || AllLevels[keys[i]].State == 4)
							{
								if (keys[i] > near_support)
								{
									far_support = near_support;
									near_support = keys[i];
								}
							}
						}

						var near_resistance = double.MaxValue;
						var far_resistance = double.MaxValue;
						for (var i = keys.Count - 1; i >= 0; i--)
						{
							if (AllLevels[keys[i]].State == 1 || AllLevels[keys[i]].State == 2)
							{
								if (keys[i] < near_resistance)
								{
									far_resistance = near_resistance;
									near_resistance = keys[i];
								}
							}
						}

						//Print("AllLevels.Count: "+AllLevels.Count);
						//int ii = 0;
						//foreach(var LK in AllLevels.Keys){
						//	ii++;
						//	Draw.Text(this, ii.ToString(), string.Format("State: {0}",AllLevels[LK].State), 10, LK);
						//}
						if (true)
						{
							#region remove terminated levels

							for (var i = 0; i < keys.Count; i++)
								AllLevels.Remove(keys[i]);
							keys = new List<double>(AllLevels.Keys);

							#endregion
						}

						var priorSupNear = SupNear[1];
						var priorResNear = ResNear[1];
						SupNear[0] = Instrument.MasterInstrument.RoundToTickSize(near_support);
						SupFar[0] = Instrument.MasterInstrument.RoundToTickSize(far_support);
						ResNear[0] = Instrument.MasterInstrument.RoundToTickSize(near_resistance);
						ResFar[0] = Instrument.MasterInstrument.RoundToTickSize(far_resistance);

						#region --- Update globalized rays if necessary ---

						var tag = "FS";
						if (GlobalRays.ContainsKey(tag))
						{
							GlobalRays[tag].LMAbar = CurrentBars[0] - 1;
							GlobalRays[tag].DT = Times[0].GetValueAt(CurrentBars[0] - 1);
							if (ResFar[0] != GlobalRays[tag].Price)
							{
								GlobalRays[tag].Price = ResFar[0];
								if (GlobalRays[tag].IsDrawn)
								{
									RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
									ImmediatelyDraw_Ray(tag, GlobalRays);
								}
							}
						}

						tag = "NS";
						if (GlobalRays.ContainsKey(tag))
						{
							GlobalRays[tag].LMAbar = CurrentBars[0] - 1;
							GlobalRays[tag].DT = Times[0].GetValueAt(CurrentBars[0] - 1);
							if (ResNear[0] != GlobalRays[tag].Price)
							{
								GlobalRays[tag].Price = ResNear[0];
								if (GlobalRays[tag].IsDrawn)
								{
									RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
									ImmediatelyDraw_Ray(tag, GlobalRays);
								}
							}
						}

						tag = "NB";
						if (GlobalRays.ContainsKey(tag))
						{
							GlobalRays[tag].LMAbar = CurrentBars[0] - 1;
							GlobalRays[tag].DT = Times[0].GetValueAt(CurrentBars[0] - 1);
							if (SupNear[0] != GlobalRays[tag].Price)
							{
								GlobalRays[tag].Price = SupNear[0];
								if (GlobalRays[tag].IsDrawn)
								{
									RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
									ImmediatelyDraw_Ray(tag, GlobalRays);
								}
							}
						}

						tag = "FB";
						if (GlobalRays.ContainsKey(tag))
						{
							GlobalRays[tag].LMAbar = CurrentBars[0] - 1;
							GlobalRays[tag].DT = Times[0].GetValueAt(CurrentBars[0] - 1);
							if (SupFar[0] != GlobalRays[tag].Price)
							{
								GlobalRays[tag].Price = SupFar[0];
								if (GlobalRays[tag].IsDrawn)
								{
									RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
									ImmediatelyDraw_Ray(tag, GlobalRays);
								}
							}
						}

						#endregion
						//bool inzone = Time[0].Day==4 && Time[0].Month==6 && Time[0].Hour==21;
						//if(inzone){
						//	if(StructureBiasMgr.ErrorMsg.Length>0) Print(StructureBiasMgr.ErrorMsg);
						//	Print(Time[0].ToString()+"   --------------");
						//	foreach(var ss in StructureBiasMgr.sequence) Print(ss);
						//}
					}
				}
			}
			catch (Exception obue)
			{

			}
		}
		//=======================================================================================================================
		#region UpdateState
		private int UpdateState(int newState, int oldState, double oldFibs, double tmpFibValue, double H, double L, double C)
		{
			if (oldFibs != tmpFibValue)
				return 0;
			if (oldState == 0 && C < tmpFibValue)
				return 1;
			if (oldState == 0 && C >= tmpFibValue)
				return 3;
			if (oldState == 1 && L > tmpFibValue)
				return 3;
			if (oldState == 1)
				return 1;
			if (oldState == 3 && H < tmpFibValue)
				return 1;
			if (oldState == 3)
				return 3;

			return newState;
		}
		#endregion

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (!this.ARC_AutoFibAlgo_IsLicensed())
				return;
			
			#region -- conditions to return --
			if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
			if (Bars == null || ChartControl == null) return;
			if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
			if (IsInHitTest) return;
			#endregion
			#region Create DX Brushes
			SharpDX.Direct2D1.Brush fillbrush = null;
			#endregion

			var rmab = BarsArray[0].GetBar(Times[0].GetValueAt(Math.Min(BarsArray[0].Count - 1, ChartBars.ToIndex)));
			if (Calculate == Calculate.OnBarClose) rmab--;

			try
			{
				base.OnRender(chartControl, chartScale);
			}
			catch (Exception perr)
			{

			}

			#region DX Brush Disposal
			if (fillbrush != null && !fillbrush.IsDisposed) fillbrush.Dispose();
			fillbrush = null;
			#endregion
		}
		//=============================================================================================================
		private void ImmediatelyDraw_Ray(string tag, SortedDictionary<string, Global_RaysData> dict)
		{
			#region -- Draw Global Rays ------------------------------
			if (tag != null && tag.Length > 0)
			{
				TriggerCustomEvent(o1 => { Draw.Ray(this, string.Format("@{0} {1}", tag, ObjTagPrefix), dict[tag].DT, dict[tag].Price, Times[0].GetValueAt(CurrentBars[0]), dict[tag].Price, true, dict[tag].TemplateName); }, 0, null);
			}
			#endregion ----------------------------
		}
		//=============================================================================================================
		private void ImmediatelyDraw_Rays(SortedDictionary<string, Global_RaysData> dict)
		{
			#region -- Draw Global Rays ------------------------------
			foreach (var tag in dict.Keys)
			{
				if (tag != null && tag.Length > 0)
				{
					TriggerCustomEvent(o1 => { Draw.Ray(this, string.Format("@{0} {1}", tag, ObjTagPrefix), dict[tag].DT, dict[tag].Price, Times[0].GetValueAt(CurrentBars[0]), dict[tag].Price, true, dict[tag].TemplateName); }, 0, null);
				}
			}
			#endregion ----------------------------
		}
		//=============================================================================================================

		#region supporting code
		private float[] getTextHeightAndWidth(string text, SimpleFont font)
		{
			var textFormat = new TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
				);
			var textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			var result = new float[2] { (float)font.Size, textLayout.Metrics.Width };

			textLayout.Dispose();
			textFormat.Dispose();

			return result;
		}
		private float getTextWidth(string text, SimpleFont font)
		{
			var textFormat = new TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
				);
			var textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			var textwidth = textLayout.Metrics.Width;

			textLayout.Dispose();
			textFormat.Dispose();

			return textwidth;
		}
		private float getTextHeight(string text, SimpleFont font)
		{
			var textFormat = new TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
				);
			var textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			var textheight = textLayout.Metrics.Height;

			textLayout.Dispose();
			textFormat.Dispose();

			return textheight;
		}
		private void drawstring(string text, float x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.Direct2D1.Brush bkgBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxX = -9999f)
		{
			#region drawstring
			if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
												//SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();

			var textFormat = new TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
			)
			{ TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
			var textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, ChartPanel.W / 3, ChartPanel.H);
			if (x < 0) x = Math.Abs(x) - textLayout.Metrics.Width - 5;

			if (MaxX > 0)
				x = Math.Min(x, MaxX - 3f - textLayout.Metrics.Width);

			y -= textLayout.Metrics.Height / 2.0;
			if (bkgBrush != null && bkgBrush.Opacity > 0)
			{
				double xl = x - 3;
				double xr = x + textLayout.Metrics.Width + 3;
				var yt = y - 1;
				var yb = y + textLayout.Metrics.Height + 2;
				if (textAlignment == SharpDX.DirectWrite.TextAlignment.Trailing)
				{
					xr = x + textLayout.Metrics.LayoutWidth + 3;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				else if (textAlignment == SharpDX.DirectWrite.TextAlignment.Center)
				{
					xr = x + textLayout.Metrics.LayoutWidth / 2 + 3 + textLayout.Metrics.Width / 2;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				var bkgBox = new[]
				{   new Point(xl, yt),
					new Point(xl, yb),
					new Point(xr, yb),
					new Point(xr, yt),
				};
				drawRegion(bkgBox, bkgBrush);
			}
			RenderTarget.DrawTextLayout(new SharpDX.Vector2(x, (float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			textLayout.Dispose();
			textFormat.Dispose();
			#endregion
		}
		//Draw a text at {x;y} coordinates in pixel.
		private void drawString(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
		{
			var factory = new SharpDX.Direct2D1.Factory();
			var textFormat = new TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
				)
			{ TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
			var textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

			RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x, (float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			textLayout.Dispose();
			textFormat.Dispose();
		}

		private void drawLine(float x1, float x2, float y1, float y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle = DashStyleHelper.Solid, int width = 1, int opacity = 100)
		{
			dxbrush.Opacity = opacity / 100f;
			SharpDX.Direct2D1.DashStyle _dashstyle;
			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

			var properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
			var strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

			RenderTarget.DrawLine(new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), dxbrush, width, strokestyle);

			strokestyle.Dispose();
		}
		private void drawRegion(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
		{
			var vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

			var geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
			var sink1 = geo1.Open();
			sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
			sink1.AddLines(vectors);
			sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink1.Close();

			RenderTarget.FillGeometry(geo1, dxbrush);
			geo1.Dispose();
			sink1.Dispose();
		}

		//set the color to Black or White depending on background color
		public Brush ContrastingColor(SolidColorBrush background)
		{
			// Counting the perceptive luminance - human eye favors green color... 
			var a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
			if (a < 0.5) return Brushes.Black; // bright colors - black font
			return Brushes.White; // dark colors - white font
		}

		//Draw a line between 2 points. 'x1' and 'x2' are pixel locations, the y value is the numerical value (ie price / oscillator value)
		private void drawLine(double val1, double val2, float x1, float x2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = true)
		{
			if (double.IsNaN(val1) || double.IsNaN(val2)) { Print("Val is NaN"); return; }
			//SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.DashStyle _dashstyle;
			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

			var properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
			var strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

			var v1 = new SharpDX.Vector2(x1, drawOnPricePanel ? chartScale.GetYByValue(val1) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val1));
			var v2 = new SharpDX.Vector2(x2, drawOnPricePanel ? chartScale.GetYByValue(val2) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val2));
			//Print("\nv1: "+v1.X+", "+v1.Y+"   "+val1);
			//Print("v2: "+v2.X+", "+v2.Y+"   "+val2);
			RenderTarget.DrawLine(v1, v2, dxbrush, width, strokestyle);

			strokestyle.Dispose();
		}
		#endregion
		//This function does a bar request to preload historical minute bars. It is an asynchrone function but has been made synchrone.
		#region -- loadHistoricalBars --
		private Bars loadHistoricalBars(DateTime dtfrom, DateTime dtto)
		{
			//---- Prepa Bars Request ----
			var barsRequest = new BarsRequest(Bars.Instrument, dtfrom, dtto) { TradingHours = Bars.TradingHours, IsSplitAdjusted = false/*Bars.IsSplitAdjusted*/, IsDividendAdjusted = Bars.IsDividendAdjusted };
			barsRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, MarketDataType = Bars.BarsPeriod.MarketDataType, Value = BarPeriod };

			//---- Request the bars ----
			var doWait = true;
			Bars retour = null;
			barsRequest.Request((bars, errorCode, errorMessage) =>
			{
				if (errorCode != Cbi.ErrorCode.NoError) { retour = null; doWait = false; return; }

				if (bars.Bars == null || bars.Bars.Count == 0) { doWait = false; return; }
				retour = bars.Bars;
				doWait = false;
			});
			while (doWait) { Thread.Sleep(10); }//made synchrone cause need request to finish before continuing
			return retour;
		}
		#endregion

		#region -- CalculateFibonacci --
		public void CalculateFibonacci(int i)
		{
			minimumDeviation[i] = zigZagFactor * Math.Pow(stepUpRatio, i) * avgTrueRange;
			timeFrameMultiplier = 1.5 * timeFrameFactor[i];
			highUpdate = upTrend[i] && priorBarHigh >= currentBarHigh && priorBarHigh > currentHigh[i];
			lowUpdate = !upTrend[i] && priorBarLow <= currentBarLow && priorBarLow < currentLow[i];
			addHigh = !upTrend[i] && priorBarHigh >= currentBarHigh && priorBarHigh > currentLow[i] + minimumDeviation[i];
			addLow = upTrend[i] && priorBarLow <= currentBarLow && priorBarLow < currentHigh[i] - minimumDeviation[i];
			normalizedRangeUp = 0;
			normalizedRangeDown = 0;

			// Condition required to speed up the indicator
			//==========================================================================================================================
			// printing of lines is delayed by one bar to avoid vertical lines on the chart

			countDown[i] = highUpdate || lowUpdate || addHigh || addLow ? 1 : countDown[i] - 1;

			#region -- countDown[i] == 0 --
			if (countDown[i] == 0)
			{
				priorCurrentHigh[i] = currentHigh[i];
				priorCurrentLow[i] = currentLow[i];
				priorMicroSwingHigh0[i] = microSwingHigh0[i];
				priorMicroSwingHigh1[i] = microSwingHigh1[i];
				priorMicroSwingHigh2[i] = microSwingHigh2[i];
				priorMicroSwingHigh3[i] = microSwingHigh3[i];
				priorMicroSwingLow0[i] = microSwingLow0[i];
				priorMicroSwingLow1[i] = microSwingLow1[i];
				priorMicroSwingLow2[i] = microSwingLow2[i];
				priorMicroSwingLow3[i] = microSwingLow3[i];
				priorCurrentSwingHigh[i] = currentSwingHigh[i];
				priorLastSwingHigh[i] = lastSwingHigh[i];
				priorCurrentSwingLow[i] = currentSwingLow[i];
				priorLastSwingLow[i] = lastSwingLow[i];
				priorRetUp0[i] = retUp0[i];
				priorRetUp23[i] = retUp23[i];
				priorRetUp38[i] = retUp38[i];
				priorRetUp50[i] = retUp50[i];
				priorRetUp62[i] = retUp62[i];
				priorRetUp76[i] = retUp76[i];
				priorRetUp100[i] = retUp100[i];
				priorRetDown0[i] = retDown0[i];
				priorRetDown23[i] = retDown23[i];
				priorRetDown38[i] = retDown38[i];
				priorRetDown50[i] = retDown50[i];
				priorRetDown62[i] = retDown62[i];
				priorRetDown76[i] = retDown76[i];
				priorRetDown100[i] = retDown100[i];
				priorExtUp0[i] = extUp0[i];
				priorExtUp100[i] = extUp100[i];
				priorExtUp127[i] = extUp127[i];
				priorExtUp162[i] = extUp162[i];
				priorExtUp200[i] = extUp200[i];
				priorExtUp262[i] = extUp262[i];
				priorExtUp300[i] = extUp300[i];
				priorExtUp423[i] = extUp423[i];
				priorExtDown0[i] = extDown0[i];
				priorExtDown100[i] = extDown100[i];
				priorExtDown127[i] = extDown127[i];
				priorExtDown162[i] = extDown162[i];
				priorExtDown200[i] = extDown200[i];
				priorExtDown262[i] = extDown262[i];
				priorExtDown300[i] = extDown300[i];
				priorExtDown423[i] = extDown423[i];
				priorLastDirUp38[i] = lastDirUp38[i];
				priorLastDirUp62[i] = lastDirUp62[i];
				priorLastDirUp100[i] = lastDirUp100[i];
				priorLastDirDown38[i] = lastDirDown38[i];
				priorLastDirDown62[i] = lastDirDown62[i];
				priorLastDirDown100[i] = lastDirDown100[i];
				priorDirUp38[i] = dirUp38[i];
				priorDirUp62[i] = dirUp62[i];
				priorDirUp100[i] = dirUp100[i];
				priorDirDown38[i] = dirDown38[i];
				priorDirDown62[i] = dirDown62[i];
				priorDirDown100[i] = dirDown100[i];
				priorLastDirUp38[i] = lastDirUp38[i];
				priorLastDirUp62[i] = lastDirUp62[i];
				priorLastDirUp100[i] = lastDirUp100[i];
				priorLastDirDown38[i] = lastDirDown38[i];
				priorLastDirDown62[i] = lastDirDown62[i];
				priorLastDirDown100[i] = lastDirDown100[i];
				priorDirUp38[i] = dirUp38[i];
				priorDirUp62[i] = dirUp62[i];
				priorDirUp100[i] = dirUp100[i];
				priorDirDown38[i] = dirDown38[i];
				priorDirDown62[i] = dirDown62[i];
				priorDirDown100[i] = dirDown100[i];
				priorAlt0Up62[i] = alt0Up62[i];
				priorAlt0Up100[i] = alt0Up100[i];
				priorAlt0Up162[i] = alt0Up162[i];
				priorAlt1Up100[i] = alt1Up100[i];
				priorAlt0Down62[i] = alt0Down62[i];
				priorAlt0Down100[i] = alt0Down100[i];
				priorAlt0Down162[i] = alt0Down162[i];
				priorAlt1Down100[i] = alt1Down100[i];
			}
			#endregion

			if (countDown[i] != 1)
				return;

			#region -- Section to identify ZigZagHighs and ZigZagLows filling them into arrays --
			priorCurrentHigh[i] = currentHigh[i];
			priorCurrentLow[i] = currentLow[i];
			priorMicroSwingHigh0[i] = microSwingHigh0[i];
			priorMicroSwingHigh1[i] = microSwingHigh1[i];
			priorMicroSwingHigh2[i] = microSwingHigh2[i];
			priorMicroSwingHigh3[i] = microSwingHigh3[i];
			priorMicroSwingLow0[i] = microSwingLow0[i];
			priorMicroSwingLow1[i] = microSwingLow1[i];
			priorMicroSwingLow2[i] = microSwingLow2[i];
			priorMicroSwingLow3[i] = microSwingLow3[i];

			if (addHigh) // when new high is added, currentLow is validated
			{
				upTrend[i] = true;
				microLow[i, 0] = currentLow[i];
				currentHigh[i] = priorBarHigh;
				if (microLow[i, 0] < microLow[i, 1]) // requires initialization
					existsSwingLow[i] = true;
			}
			else if (highUpdate)
			{
				currentHigh[i] = priorBarHigh;
			}
			else if (addLow)  // when new low is added, currentHigh is validated and set to MicroHighArray, microLow[0] is left empty 
			{
				upTrend[i] = false;
				for (var j = 19; j > 0; j--)
				{
					microHigh[i, j] = microHigh[i, j - 1];
					microLow[i, j] = microLow[i, j - 1];
				}
				microHigh[i, 0] = currentHigh[i];
				microLow[i, 0] = double.MinValue; // not yet containing valid information, assymetric code
				currentLow[i] = priorBarLow;
				if (microHigh[i, 0] > microHigh[i, 1]) // requires initialization
					existsSwingHigh[i] = true;
			}
			else if (lowUpdate)
			{
				currentLow[i] = priorBarLow;
			}
			#endregion

			//=========================================================================================================================
			#region -- Section to calculate Swing Highs and Swing Lows --
			priorCurrentSwingHigh[i] = currentSwingHigh[i];
			priorLastSwingHigh[i] = lastSwingHigh[i];
			priorCurrentSwingLow[i] = currentSwingLow[i];
			priorLastSwingLow[i] = lastSwingLow[i];

			if (addLow)
			{
				if (microHigh[i, 0] >= microHigh[i, 1] + double.Epsilon)
				{
					if (currentSwingHighIndex[i] >= 0)
					{
						lastSwingHigh[i] = currentSwingHigh[i];
						lastSwingHighIndex[i] = currentSwingHighIndex[i] + 1;
						if (lastSwingLowIndex[i] >= 0)
							weightLastSwingHigh[i] = specificWeightLastSwing * (1.0 + 0.001 * i) * Math.Sqrt((lastSwingHigh[i] - lastSwingLow[i]) / (zigZagFactor * avgTrueRange));
						else
							weightLastSwingHigh[i] = specificWeightLastSwing * (1.0 + 0.001 * i) * timeFrameMultiplier;
					}
					currentSwingHigh[i] = microHigh[i, 0];
					if (currentSwingLowIndex[i] >= 0)
						weightCurrentSwingHigh[i] = specificWeightCurrentSwing * (1.0 + 0.001 * i) * Math.Sqrt((currentSwingHigh[i] - currentSwingLow[i]) / (zigZagFactor * avgTrueRange));
					else
						weightCurrentSwingHigh[i] = specificWeightCurrentSwing * (1.0 + 0.001 * i) * timeFrameMultiplier;
					currentSwingHighIndex[i] = 0;
				}
				else
				{
					currentSwingHighIndex[i] += 1;
					lastSwingHighIndex[i] += 1;
				}
				currentSwingLowIndex[i] += 1;
				lastSwingLowIndex[i] += 1;
			}
			if (addHigh)
			{
				if (microLow[i, 0] <= microLow[i, 1] - double.Epsilon)
				{
					if (currentSwingLowIndex[i] >= 0)
					{
						lastSwingLow[i] = currentSwingLow[i];
						lastSwingLowIndex[i] = currentSwingLowIndex[i];
						if (lastSwingHighIndex[i] >= 0)
							weightLastSwingLow[i] = specificWeightLastSwing * (1.0 + 0.001 * i) * Math.Sqrt((lastSwingHigh[i] - lastSwingLow[i]) / (zigZagFactor * avgTrueRange));
						else
							weightLastSwingLow[i] = specificWeightLastSwing * (1.0 + 0.001 * i) * timeFrameMultiplier;
					}
					currentSwingLow[i] = microLow[i, 0];
					if (currentSwingHighIndex[i] >= 0)
						weightCurrentSwingLow[i] = specificWeightCurrentSwing * (1.0 + 0.001 * i) * Math.Sqrt((currentSwingHigh[i] - currentSwingLow[i]) / (zigZagFactor * avgTrueRange));
					else
						weightCurrentSwingLow[i] = specificWeightCurrentSwing * (1.0 + 0.001 * i) * timeFrameMultiplier;
					currentSwingLowIndex[i] = 0;
				}
			}
			#endregion

			//=========================================================================================================================
			#region -- Section to separate Swing Highs from MicroSwing Highs and Swing Lows from MicroSwing Lows --

			highCount = 0;

			if (addLow)
			{
				if (currentSwingHighIndex[i] != highCount)
				{
					microSwingHigh0[i] = microHigh[i, highCount];
					highCount++;
				}
				else if (lastSwingHighIndex[i] != highCount + 1)
				{
					microSwingHigh0[i] = microHigh[i, highCount + 1];
					highCount += 2;
				}
				else
				{
					microSwingHigh0[i] = microHigh[i, highCount + 2];
					highCount += 3;
				}

				if (currentSwingHighIndex[i] != highCount && lastSwingHighIndex[i] != highCount)
				{
					microSwingHigh1[i] = microHigh[i, highCount];
					highCount++;
				}
				else if (lastSwingHighIndex[i] != highCount + 1)
				{
					microSwingHigh1[i] = microHigh[i, highCount + 1];
					highCount += 2;
				}
				else
				{
					microSwingHigh1[i] = microHigh[i, highCount + 2];
					highCount += 3;
				}

				if (currentSwingHighIndex[i] != highCount && lastSwingHighIndex[i] != highCount)
				{
					microSwingHigh2[i] = microHigh[i, highCount];
					highCount++; ;
				}
				else if (lastSwingHighIndex[i] != highCount + 1)
				{
					microSwingHigh2[i] = microHigh[i, highCount + 1];
					highCount += 2;
				}
				else
				{
					microSwingHigh2[i] = microHigh[i, highCount + 2];
					highCount += 3;
				}

				if (currentSwingHighIndex[i] != highCount && lastSwingHighIndex[i] != highCount)
				{
					microSwingHigh3[i] = microHigh[i, highCount];
					highCount++; ;
				}
				else if (lastSwingHighIndex[i] != highCount + 1)
				{
					microSwingHigh3[i] = microHigh[i, highCount + 1];
					highCount += 2;
				}
				else
				{
					microSwingHigh3[i] = microHigh[i, highCount + 2];
					highCount += 3;
				}
				weightMicroSwingHigh0[i] = specificWeightMicroSwing0 * (1.0 + 0.001 * i) * timeFrameMultiplier;
				weightMicroSwingHigh1[i] = specificWeightMicroSwing1 * (1.0 + 0.001 * i) * timeFrameMultiplier;
				weightMicroSwingHigh2[i] = specificWeightMicroSwing2 * (1.0 + 0.001 * i) * timeFrameMultiplier;
				weightMicroSwingHigh3[i] = specificWeightMicroSwing3 * (1.0 + 0.001 * i) * timeFrameMultiplier;
			}

			lowCount = 0;

			if (addHigh)
			{
				if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
				{
					microSwingLow0[i] = microLow[i, lowCount];
					lowCount++; ;
				}
				else if (lastSwingLowIndex[i] != lowCount + 1)
				{
					microSwingLow0[i] = microLow[i, lowCount + 1];
					lowCount += 2;
				}
				else
				{
					microSwingLow0[i] = microLow[i, lowCount + 2];
					lowCount += 3;
				}

				if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
				{
					microSwingLow1[i] = microLow[i, lowCount];
					lowCount++; ;
				}
				else if (lastSwingLowIndex[i] != lowCount + 1)
				{
					microSwingLow1[i] = microLow[i, lowCount + 1];
					lowCount += 2;
				}
				else
				{
					microSwingLow1[i] = microLow[i, lowCount + 2];
					lowCount += 3;
				}

				if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
				{
					microSwingLow2[i] = microLow[i, lowCount];
					lowCount++; ;
				}
				else if (lastSwingLowIndex[i] != lowCount + 1)
				{
					microSwingLow2[i] = microLow[i, lowCount + 1];
					lowCount += 2;
				}
				else
				{
					microSwingLow2[i] = microLow[i, lowCount + 2];
					lowCount += 3;
				}

				if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
				{
					microSwingLow3[i] = microLow[i, lowCount];
					lowCount++; ;
				}
				else if (lastSwingLowIndex[i] != lowCount + 1)
				{
					microSwingLow3[i] = microLow[i, lowCount + 1];
					lowCount += 2;
				}
				else
				{
					microSwingLow3[i] = microLow[i, lowCount + 2];
					lowCount += 3;
				}
				weightMicroSwingLow0[i] = specificWeightMicroSwing0 * (1.0 + 0.001 * i) * timeFrameMultiplier;
				weightMicroSwingLow1[i] = specificWeightMicroSwing1 * (1.0 + 0.001 * i) * timeFrameMultiplier;
				weightMicroSwingLow2[i] = specificWeightMicroSwing2 * (1.0 + 0.001 * i) * timeFrameMultiplier;
				weightMicroSwingLow3[i] = specificWeightMicroSwing3 * (1.0 + 0.001 * i) * timeFrameMultiplier;
			}
			#endregion

			//=========================================================================================================================
			#region -- Section to calculate Retracements from last Swing High and last Swing Low --

			priorRetUp0[i] = retUp0[i];
			priorRetUp23[i] = retUp23[i];
			priorRetUp38[i] = retUp38[i];
			priorRetUp50[i] = retUp50[i];
			priorRetUp62[i] = retUp62[i];
			priorRetUp76[i] = retUp76[i];
			priorRetUp100[i] = retUp100[i];
			priorRetDown0[i] = retDown0[i];
			priorRetDown23[i] = retDown23[i];
			priorRetDown38[i] = retDown38[i];
			priorRetDown50[i] = retDown50[i];
			priorRetDown62[i] = retDown62[i];
			priorRetDown76[i] = retDown76[i];
			priorRetDown100[i] = retDown100[i];

			if (microHigh[i, 0] < double.MaxValue && (addLow || lowUpdate))
			{
				retUp0[i] = currentLow[i];
				retUp100[i] = microHigh[i, 0];
				retUp23[i] = retUp0[i] + 0.236 * (retUp100[i] - retUp0[i]);
				retUp38[i] = retUp0[i] + 0.382 * (retUp100[i] - retUp0[i]);
				retUp50[i] = retUp0[i] + 0.50 * (retUp100[i] - retUp0[i]);
				retUp62[i] = retUp0[i] + 0.618 * (retUp100[i] - retUp0[i]);
				retUp76[i] = retUp0[i] + 0.764 * (retUp100[i] - retUp0[i]);
				normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((retUp100[i] - retUp0[i]) / (zigZagFactor * avgTrueRange));
				weightRetUp23[i] = specificWeightRet23 * normalizedRangeUp;
				weightRetUp38[i] = specificWeightRet38 * normalizedRangeUp;
				weightRetUp50[i] = specificWeightRet50 * normalizedRangeUp;
				weightRetUp62[i] = specificWeightRet62 * normalizedRangeUp;
				weightRetUp76[i] = specificWeightRet76 * normalizedRangeUp;
			}

			if (microLow[i, 0] > double.MinValue && (addHigh || highUpdate))
			{
				retDown0[i] = currentHigh[i];
				retDown100[i] = microLow[i, 0];
				retDown23[i] = retDown0[i] + 0.236 * (retDown100[i] - retDown0[i]);
				retDown38[i] = retDown0[i] + 0.382 * (retDown100[i] - retDown0[i]);
				retDown50[i] = retDown0[i] + 0.50 * (retDown100[i] - retDown0[i]);
				retDown62[i] = retDown0[i] + 0.618 * (retDown100[i] - retDown0[i]);
				retDown76[i] = retDown0[i] + 0.764 * (retDown100[i] - retDown0[i]);
				normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((retDown0[i] - retDown100[i]) / (zigZagFactor * avgTrueRange));
				weightRetDown23[i] = specificWeightRet23 * normalizedRangeDown;
				weightRetDown38[i] = specificWeightRet38 * normalizedRangeDown;
				weightRetDown50[i] = specificWeightRet50 * normalizedRangeDown;
				weightRetDown62[i] = specificWeightRet62 * normalizedRangeDown;
				weightRetDown76[i] = specificWeightRet76 * normalizedRangeDown;
			}

			if (addHigh || highUpdate)
			{
				normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((retUp100[i] - retUp0[i]) / (zigZagFactor * avgTrueRange));
				if (currentBarClose > retUp38[i])
					weightRetUp23[i] = devalueRet * specificWeightRet23 * normalizedRangeUp;
				if (currentBarClose > retUp50[i])
					weightRetUp38[i] = devalueRet * specificWeightRet38 * normalizedRangeUp;
				if (currentBarClose > retUp62[i])
					weightRetUp50[i] = devalueRet * specificWeightRet50 * normalizedRangeUp;
				if (currentBarClose > retUp76[i])
					weightRetUp62[i] = devalueRet * specificWeightRet62 * normalizedRangeUp;
				if (currentBarClose > retUp100[i])
					weightRetUp76[i] = devalueRet * specificWeightRet76 * normalizedRangeUp;
			}

			if (addLow || lowUpdate)
			{
				normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((retDown0[i] - retDown100[i]) / (zigZagFactor * avgTrueRange));
				if (currentBarClose < retDown38[i])
					weightRetDown23[i] = devalueRet * specificWeightRet23 * normalizedRangeDown;
				if (currentBarClose < retDown50[i])
					weightRetDown38[i] = devalueRet * specificWeightRet38 * normalizedRangeDown;
				if (currentBarClose < retDown62[i])
					weightRetDown50[i] = devalueRet * specificWeightRet50 * normalizedRangeDown;
				if (currentBarClose < retDown76[i])
					weightRetDown62[i] = devalueRet * specificWeightRet62 * normalizedRangeDown;
				if (currentBarClose < retDown100[i])
					weightRetDown76[i] = devalueRet * specificWeightRet76 * normalizedRangeDown;
			}
			#endregion

			//================================================================================================================================
			#region -- Section to calculate External Retracements from MicroHighs and MicroLows --

			priorExtUp0[i] = extUp0[i];
			priorExtUp100[i] = extUp100[i];
			priorExtUp127[i] = extUp127[i];
			priorExtUp162[i] = extUp162[i];
			priorExtUp200[i] = extUp200[i];
			priorExtUp262[i] = extUp262[i];
			priorExtUp300[i] = extUp300[i];
			priorExtUp423[i] = extUp423[i];
			priorExtDown0[i] = extDown0[i];
			priorExtDown100[i] = extDown100[i];
			priorExtDown127[i] = extDown127[i];
			priorExtDown162[i] = extDown162[i];
			priorExtDown200[i] = extDown200[i];
			priorExtDown262[i] = extDown262[i];
			priorExtDown300[i] = extDown300[i];
			priorExtDown423[i] = extDown423[i];

			if (microHigh[i, 0] < double.MaxValue && (addLow || lowUpdate))
			{
				extUp0[i] = currentLow[i];
				extUp100[i] = microHigh[i, 0];
				extUp127[i] = extUp0[i] + 1.272 * (extUp100[i] - extUp0[i]);
				extUp162[i] = extUp0[i] + 1.618 * (extUp100[i] - extUp0[i]);
				extUp200[i] = extUp0[i] + 2.0 * (extUp100[i] - extUp0[i]);
				extUp262[i] = extUp0[i] + 2.618 * (extUp100[i] - extUp0[i]);
				extUp300[i] = extUp0[i] + 3.0 * (extUp100[i] - extUp0[i]);
				extUp423[i] = extUp0[i] + 4.236 * (extUp100[i] - extUp0[i]);
				normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((extUp100[i] - extUp0[i]) / (zigZagFactor * avgTrueRange));
				weightExtUp127[i] = specificWeightExt127 * normalizedRangeUp;
				weightExtUp162[i] = specificWeightExt162 * normalizedRangeUp;
				weightExtUp200[i] = specificWeightExt200 * normalizedRangeUp;
				weightExtUp262[i] = specificWeightExt262 * normalizedRangeUp;
				weightExtUp300[i] = specificWeightExt300 * normalizedRangeUp;
				weightExtUp423[i] = specificWeightExt423 * normalizedRangeUp;
			}

			if (microLow[i, 0] > double.MinValue && (addHigh || highUpdate))
			{
				extDown0[i] = currentHigh[i];
				extDown100[i] = microLow[i, 0];
				extDown127[i] = extDown0[i] + 1.272 * (extDown100[i] - extDown0[i]);
				extDown162[i] = extDown0[i] + 1.618 * (extDown100[i] - extDown0[i]);
				extDown200[i] = extDown0[i] + 2.0 * (extDown100[i] - extDown0[i]);
				extDown262[i] = extDown0[i] + 2.618 * (extDown100[i] - extDown0[i]);
				extDown300[i] = extDown0[i] + 3.0 * (extDown100[i] - extDown0[i]);
				extDown423[i] = extDown0[i] + 4.236 * (extDown100[i] - extDown0[i]);
				normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((extDown0[i] - extDown100[i]) / (zigZagFactor * avgTrueRange));
				weightExtDown127[i] = specificWeightExt127 * normalizedRangeDown;
				weightExtDown162[i] = specificWeightExt162 * normalizedRangeDown;
				weightExtDown200[i] = specificWeightExt200 * normalizedRangeDown;
				weightExtDown262[i] = specificWeightExt262 * normalizedRangeDown;
				weightExtDown300[i] = specificWeightExt300 * normalizedRangeDown;
				weightExtDown423[i] = specificWeightExt423 * normalizedRangeDown;
			}

			if (addHigh || highUpdate)
			{
				normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((extUp100[i] - extUp0[i]) / (zigZagFactor * avgTrueRange));
				if (currentBarClose > extUp162[i])
					weightExtUp127[i] = devalueExt * specificWeightExt127 * normalizedRangeUp;
				if (currentBarClose > extUp200[i])
					weightExtUp162[i] = devalueExt * specificWeightExt162 * normalizedRangeUp;
				if (currentBarClose > extUp262[i])
					weightExtUp200[i] = devalueExt * specificWeightExt200 * normalizedRangeUp;
				if (currentBarClose > extUp300[i])
					weightExtUp262[i] = devalueExt * specificWeightExt262 * normalizedRangeUp;
				if (currentBarClose > extUp423[i])
					weightExtUp300[i] = devalueExt * specificWeightExt300 * normalizedRangeUp;
				if (currentBarClose > extUp0[i] + 5.0 * (extUp100[i] - extUp0[i]))
					weightExtUp423[i] = devalueExt * specificWeightExt423 * normalizedRangeUp;
			}

			if (addLow || lowUpdate)
			{
				normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((extDown0[i] - extDown100[i]) / (zigZagFactor * avgTrueRange));
				if (currentBarClose < extDown162[i])
					weightExtDown127[i] = devalueExt * specificWeightExt127 * normalizedRangeDown;
				if (currentBarClose < extDown200[i])
					weightExtDown162[i] = devalueExt * specificWeightExt162 * normalizedRangeDown;
				if (currentBarClose < extDown262[i])
					weightExtDown200[i] = devalueExt * specificWeightExt200 * normalizedRangeDown;
				if (currentBarClose < extDown300[i])
					weightExtDown262[i] = devalueExt * specificWeightExt262 * normalizedRangeDown;
				if (currentBarClose < extDown423[i])
					weightExtDown300[i] = devalueExt * specificWeightExt300 * normalizedRangeDown;
				if (currentBarClose < extDown0[i] + 5.0 * (extDown100[i] - extDown0[i]))
					weightExtDown423[i] = devalueExt * specificWeightExt423 * normalizedRangeDown;
			}
			#endregion

			//=====================================================================================================================
			#region -- Section to calculate Direct Projections --

			priorLastDirUp38[i] = lastDirUp38[i];
			priorLastDirUp62[i] = lastDirUp62[i];
			priorLastDirUp100[i] = lastDirUp100[i];
			priorLastDirDown38[i] = lastDirDown38[i];
			priorLastDirDown62[i] = lastDirDown62[i];
			priorLastDirDown100[i] = lastDirDown100[i];
			priorDirUp38[i] = dirUp38[i];
			priorDirUp62[i] = dirUp62[i];
			priorDirUp100[i] = dirUp100[i];
			priorDirDown38[i] = dirDown38[i];
			priorDirDown62[i] = dirDown62[i];
			priorDirDown100[i] = dirDown100[i];

			if (microHigh[i, 0] < double.MaxValue && microLow[i, 1] > double.MinValue && addLow)
			{
				lastDirUp38[i] = dirUp38[i];
				lastDirUp62[i] = dirUp62[i];
				lastDirUp100[i] = dirUp100[i];
				if (specificWeightDir38 > 0)
					weightLastDirUp38[i] = weightDirUp38[i] * specificWeightLastDir38 / specificWeightDir38;
				else
					weightLastDirUp38[i] = 0;
				if (specificWeightDir62 > 0)
					weightLastDirUp62[i] = weightDirUp62[i] * specificWeightLastDir62 / specificWeightDir62;
				else
					weightLastDirUp62[i] = 0;
				if (specificWeightDir100 > 0)
					weightLastDirUp100[i] = weightDirUp100[i] * specificWeightLastDir100 / specificWeightDir100;
				else
					weightLastDirUp100[i] = 0;

				dirUp38[i] = microHigh[i, 0] + 0.382 * (microHigh[i, 0] - microLow[i, 1]);
				dirUp62[i] = microHigh[i, 0] + 0.618 * (microHigh[i, 0] - microLow[i, 1]);
				dirUp100[i] = 2 * microHigh[i, 0] - microLow[i, 1];

				normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 0] - microLow[i, 1]) / (zigZagFactor * avgTrueRange));
				weightDirUp38[i] = specificWeightDir38 * normalizedRangeUp;
				weightDirUp62[i] = specificWeightDir62 * normalizedRangeUp;
				weightDirUp100[i] = specificWeightDir100 * normalizedRangeUp;
			}

			if (microHigh[i, 0] < double.MaxValue && microLow[i, 0] > double.MinValue && addHigh)
			{
				lastDirDown38[i] = dirDown38[i];
				lastDirDown62[i] = dirDown62[i];
				lastDirDown100[i] = dirDown100[i];
				if (specificWeightDir38 > 0)
					weightLastDirDown38[i] = weightDirDown38[i] * specificWeightLastDir38 / specificWeightDir38;
				else
					weightLastDirDown38[i] = 0;
				if (specificWeightDir62 > 0)
					weightLastDirDown62[i] = weightDirDown62[i] * specificWeightLastDir62 / specificWeightDir62;
				else
					weightLastDirDown62[i] = 0;
				if (specificWeightDir100 > 0)
					weightLastDirDown100[i] = weightDirDown100[i] * specificWeightLastDir100 / specificWeightDir100;
				else
					weightLastDirDown100[i] = 0;

				dirDown38[i] = microLow[i, 0] + 0.382 * (microLow[i, 0] - microHigh[i, 0]);
				dirDown62[i] = microLow[i, 0] + 0.618 * (microLow[i, 0] - microHigh[i, 0]);
				dirDown100[i] = 2 * microLow[i, 0] - microHigh[i, 0];
				normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 0] - microLow[i, 0]) / (zigZagFactor * avgTrueRange));
				weightDirDown38[i] = specificWeightDir38 * normalizedRangeDown;
				weightDirDown62[i] = specificWeightDir62 * normalizedRangeDown;
				weightDirDown100[i] = specificWeightDir100 * normalizedRangeDown;
			}

			if (addHigh || highUpdate)
			{
				if (microHigh[i, 1] < double.MaxValue && microLow[i, 2] > double.MinValue)
				{
					normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 1] - microLow[i, 2]) / (zigZagFactor * avgTrueRange));
					if (currentBarClose > lastDirUp62[i])
						weightLastDirUp38[i] = devalueDir * specificWeightLastDir38 * normalizedRangeUp;
					if (currentBarClose > lastDirUp100[i])
						weightLastDirUp62[i] = devalueDir * specificWeightLastDir62 * normalizedRangeUp;
					if (currentBarClose > 2 * lastDirUp100[i] - lastDirUp62[i])
						weightLastDirUp100[i] = devalueDir * specificWeightLastDir100 * normalizedRangeUp;
				}
				if (microHigh[i, 0] < double.MaxValue && microLow[i, 1] > double.MinValue)
				{
					normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 0] - microLow[i, 1]) / (zigZagFactor * avgTrueRange));
					if (currentBarClose > dirUp62[i])
						weightDirUp38[i] = devalueDir * specificWeightDir38 * normalizedRangeUp;
					if (currentBarClose > dirUp100[i])
						weightDirUp62[i] = devalueDir * specificWeightDir62 * normalizedRangeUp;
					if (currentBarClose > 2 * dirUp100[i] - dirUp62[i])
						weightDirUp100[i] = devalueDir * specificWeightDir100 * normalizedRangeUp;
				}
			}

			if (addLow || lowUpdate)
			{
				if (microHigh[i, 2] < double.MaxValue && microLow[i, 2] > double.MinValue)
				{
					normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 2] - microLow[i, 2]) / (zigZagFactor * avgTrueRange));
					if (currentBarClose < lastDirDown62[i])
						weightLastDirDown38[i] = devalueDir * specificWeightLastDir38 * normalizedRangeDown;
					if (currentBarClose < lastDirDown100[i])
						weightLastDirDown62[i] = devalueDir * specificWeightLastDir62 * normalizedRangeDown;
					if (currentBarClose < 2 * lastDirDown100[i] - lastDirDown62[i])
						weightLastDirDown100[i] = devalueDir * specificWeightLastDir100 * normalizedRangeDown;
				}
				if (microHigh[i, 1] < double.MaxValue && microLow[i, 1] > double.MinValue)
				{
					normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 1] - microLow[i, 1]) / (zigZagFactor * avgTrueRange));
					if (currentBarClose < dirDown62[i])
						weightDirDown38[i] = devalueDir * specificWeightDir38 * normalizedRangeDown;
					if (currentBarClose < dirDown100[i])
						weightDirDown62[i] = devalueDir * specificWeightDir62 * normalizedRangeDown;
					if (currentBarClose < 2 * dirDown100[i] - dirDown62[i])
						weightDirDown100[i] = devalueDir * specificWeightDir100 * normalizedRangeDown;
				}
			}
			#endregion

			//=====================================================================================================================
			#region -- Section to calculate Alternate Projections --

			priorAlt0Up62[i] = alt0Up62[i];
			priorAlt0Up100[i] = alt0Up100[i];
			priorAlt0Up162[i] = alt0Up162[i];
			priorAlt1Up100[i] = alt1Up100[i];
			priorAlt0Down62[i] = alt0Down62[i];
			priorAlt0Down100[i] = alt0Down100[i];
			priorAlt0Down162[i] = alt0Down162[i];
			priorAlt1Down100[i] = alt1Down100[i];

			if (microHigh[i, 1] < double.MaxValue && microLow[i, 2] > double.MinValue && (addLow || lowUpdate))
			{
				alt0Up[i] = microHigh[i, 0] - microLow[i, 1];
				alt1Up[i] = microHigh[i, 1] - microLow[i, 2];
				alt0Up62[i] = currentLow[i] + 0.618 * alt0Up[i];
				alt0Up100[i] = currentLow[i] + alt0Up[i];
				alt0Up162[i] = currentLow[i] + 1.618 * alt0Up[i];
				alt1Up100[i] = currentLow[i] + alt1Up[i];
				normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt(alt0Up[i] / (zigZagFactor * avgTrueRange));
				weightAlt0Up62[i] = specificWeightAlt62 * normalizedRangeUp;
				weightAlt0Up100[i] = specificWeightAlt100 * normalizedRangeUp;
				weightAlt0Up162[i] = specificWeightAlt162 * normalizedRangeUp;
				weightAlt1Up100[i] = specificWeightAlt100Prior * (1.0 + 0.001 * i) * Math.Sqrt(alt1Up[i] / (zigZagFactor * avgTrueRange));
			}

			if (microHigh[i, 1] < double.MaxValue && microLow[i, 1] > double.MinValue && (addHigh || highUpdate))
			{
				alt0Down[i] = microHigh[i, 0] - microLow[i, 0];
				alt1Down[i] = microHigh[i, 1] - microLow[i, 1];
				alt0Down62[i] = currentHigh[i] - 0.618 * alt0Down[i];
				alt0Down100[i] = currentHigh[i] - alt0Down[i];
				alt0Down162[i] = currentHigh[i] - 1.618 * alt0Down[i];
				alt1Down100[i] = currentHigh[i] - alt1Down[i];
				normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt(alt0Down[i] / (zigZagFactor * avgTrueRange));
				weightAlt0Down62[i] = specificWeightAlt62 * normalizedRangeDown;
				weightAlt0Down100[i] = specificWeightAlt100 * normalizedRangeDown;
				weightAlt0Down162[i] = specificWeightAlt162 * normalizedRangeDown;
				normalizedRangeDown = Math.Sqrt(alt1Down[i] / (zigZagFactor * avgTrueRange));
				weightAlt1Down100[i] = specificWeightAlt100Prior * (1.0 + 0.001 * i) * Math.Sqrt(alt1Down[i] / (zigZagFactor * avgTrueRange));
			}

			if (addHigh || highUpdate)
			{
				normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt(alt0Up[i] / (zigZagFactor * avgTrueRange));
				if (currentBarClose > alt0Up100[i])
					weightAlt0Up62[i] = devalueAlt * specificWeightAlt62 * normalizedRangeUp;
				if (currentBarClose > alt0Up162[i])
					weightAlt0Up100[i] = devalueAlt * specificWeightAlt100 * normalizedRangeUp;
				if (currentBarClose > alt0Up100[i] + alt0Up[i])
					weightAlt0Up162[i] = devalueAlt * specificWeightAlt162 * normalizedRangeUp;
				if (currentBarClose > alt1Up100[i] + 0.62 * alt1Up[i])
					weightAlt1Up100[i] = devalueAlt * specificWeightAlt100Prior * (1.0 + 0.001 * i) * Math.Sqrt(alt1Up[i] / (zigZagFactor * avgTrueRange));
			}

			if (addLow || lowUpdate)
			{
				normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt(alt0Down[i] / (zigZagFactor * avgTrueRange));
				if (currentBarClose < alt0Down100[i])
					weightAlt0Down62[i] = devalueAlt * specificWeightAlt62 * normalizedRangeDown;
				if (currentBarClose < alt0Down162[i])
					weightAlt0Down100[i] = devalueAlt * specificWeightAlt100 * normalizedRangeDown;
				if (currentBarClose < alt0Down100[i] + alt0Down[i])
					weightAlt0Down162[i] = devalueAlt * specificWeightAlt162 * normalizedRangeDown;
				if (currentBarClose < alt1Down100[i] + 0.62 * alt1Down[i])
					weightAlt1Down100[i] = devalueAlt * specificWeightAlt100Prior * (1.0 + 0.001 * i) * Math.Sqrt(alt1Down[i] / (zigZagFactor * avgTrueRange));
			}
			#endregion
		}
		#endregion

		//=========================================================================================================================
		// Writing all Fib Lines and Fib Weights to two separate Arrays that can be sorted
		//=========================================================================================================================            
		#region -- SetLinesAndWeights --
		public void SetLinesAndWeights()
		{
			countLine = 0;
			for(var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				//=========================================================================================================================
				#region -- Section to set Support and Resistance from previous Swing Highs and Swing Lows (max. 12 Values calculated and displayed) --

				if (microSwingHigh0[i] < double.MaxValue)
				{
					fibLine[countLine] = microSwingHigh0[i];
					fibWeight[countLine] = weightMicroSwingHigh0[i];
					countLine++;
				}
				if (microSwingHigh1[i] < double.MaxValue)
				{
					fibLine[countLine] = microSwingHigh1[i];
					fibWeight[countLine] = weightMicroSwingHigh1[i];
					countLine++;
				}
				if (microSwingHigh2[i] < double.MaxValue)
				{
					fibLine[countLine] = microSwingHigh2[i];
					fibWeight[countLine] = weightMicroSwingHigh2[i];
					countLine++;
				}
				if (microSwingHigh3[i] < double.MaxValue)
				{
					fibLine[countLine] = microSwingHigh3[i];
					fibWeight[countLine] = weightMicroSwingHigh3[i];
					countLine++;
				}
				if (microSwingLow0[i] > double.MinValue)
				{
					fibLine[countLine] = microSwingLow0[i];
					fibWeight[countLine] = weightMicroSwingLow0[i];
					countLine++;
				}
				if (microSwingLow1[i] > double.MinValue)
				{
					fibLine[countLine] = microSwingLow1[i];
					fibWeight[countLine] = weightMicroSwingLow1[i];
					countLine++;
				}
				if (microSwingLow2[i] > double.MinValue)
				{
					fibLine[countLine] = microSwingLow2[i];
					fibWeight[countLine] = weightMicroSwingLow2[i];
					countLine++;
				}
				if (microSwingLow3[i] > double.MinValue)
				{
					fibLine[countLine] = microSwingLow3[i];
					fibWeight[countLine] = weightMicroSwingLow3[i];
					countLine++;
				}
				if (existsSwingHigh[i])
				{
					fibLine[countLine] = currentSwingHigh[i];
					fibWeight[countLine] = weightCurrentSwingHigh[i];
					countLine++;
					if (lastSwingHigh[i] < double.MaxValue)
					{
						fibLine[countLine] = lastSwingHigh[i];
						fibWeight[countLine] = weightLastSwingHigh[i];
						countLine++;
					}
				}
				if (existsSwingLow[i])
				{
					fibLine[countLine] = currentSwingLow[i];
					fibWeight[countLine] = weightCurrentSwingLow[i];
					countLine++;
					if (lastSwingLow[i] > double.MinValue)
					{
						fibLine[countLine] = lastSwingLow[i];
						fibWeight[countLine] = weightLastSwingLow[i];
						countLine++;
					}
				}
				#endregion

				//=========================================================================================================================
				#region -- Section to set Retracements from last Swing High and last Swing Low (max. 8 Values calculated and displayed) --

				fibLine[countLine] = retUp23[i];
				fibWeight[countLine] = weightRetUp23[i];
				countLine++;

				fibLine[countLine] = retUp38[i];
				fibWeight[countLine] = weightRetUp38[i];
				countLine++;

				fibLine[countLine] = retUp50[i];
				fibWeight[countLine] = weightRetUp50[i];
				countLine++;

				fibLine[countLine] = retUp62[i];
				fibWeight[countLine] = weightRetUp62[i];
				countLine++;

				fibLine[countLine] = retUp76[i];
				fibWeight[countLine] = weightRetUp76[i];
				countLine++;

				fibLine[countLine] = retDown23[i];
				fibWeight[countLine] = weightRetDown23[i];
				countLine++;

				fibLine[countLine] = retDown38[i];
				fibWeight[countLine] = weightRetDown38[i];
				countLine++;

				fibLine[countLine] = retDown50[i];
				fibWeight[countLine] = weightRetDown50[i];
				countLine++;

				fibLine[countLine] = retDown62[i];
				fibWeight[countLine] = weightRetDown62[i];
				countLine++;

				fibLine[countLine] = retDown76[i];
				fibWeight[countLine] = weightRetDown76[i];
				countLine++;
				#endregion

				//===========================================================================================================================
				#region -- Section to set External Retracements from MicroHighs and MicroLows (max. 12 Values calculated and displayed) --

				fibLine[countLine] = extUp127[i];
				fibWeight[countLine] = weightExtUp127[i];
				countLine++;

				fibLine[countLine] = extUp162[i];
				fibWeight[countLine] = weightExtUp162[i];
				countLine++;

				fibLine[countLine] = extUp200[i];
				fibWeight[countLine] = weightExtUp200[i];
				countLine++;

				fibLine[countLine] = extUp262[i];
				fibWeight[countLine] = weightExtUp262[i];
				countLine++;

				fibLine[countLine] = extUp300[i];
				fibWeight[countLine] = weightExtUp300[i];
				countLine++;

				fibLine[countLine] = extUp423[i];
				fibWeight[countLine] = weightExtUp423[i];
				countLine++;

				fibLine[countLine] = extDown127[i];
				fibWeight[countLine] = weightExtDown127[i];
				countLine++;

				fibLine[countLine] = extDown162[i];
				fibWeight[countLine] = weightExtDown162[i];
				countLine++;

				fibLine[countLine] = extDown200[i];
				fibWeight[countLine] = weightExtDown200[i];
				countLine++;

				fibLine[countLine] = extDown262[i];
				fibWeight[countLine] = weightExtDown262[i];
				countLine++;

				fibLine[countLine] = extDown300[i];
				fibWeight[countLine] = weightExtDown300[i];
				countLine++;

				fibLine[countLine] = extDown423[i];
				fibWeight[countLine] = weightExtDown423[i];
				countLine++;
				#endregion

				//==============================================================================================================================
				#region -- Section to calculate Direct Projections (max. 12 Values calculated and displayed) --

				fibLine[countLine] = dirUp38[i];
				fibWeight[countLine] = weightDirUp38[i];
				countLine++;

				fibLine[countLine] = dirUp62[i];
				fibWeight[countLine] = weightDirUp62[i];
				countLine++;

				fibLine[countLine] = dirUp100[i];
				fibWeight[countLine] = weightDirUp100[i];
				countLine++;

				fibLine[countLine] = dirDown38[i];
				fibWeight[countLine] = weightDirDown38[i];
				countLine++;

				fibLine[countLine] = dirDown62[i];
				fibWeight[countLine] = weightDirDown62[i];
				countLine++;

				fibLine[countLine] = dirDown100[i];
				fibWeight[countLine] = weightDirDown100[i];
				countLine++;

				fibLine[countLine] = lastDirUp38[i];
				fibWeight[countLine] = weightLastDirUp38[i];
				countLine++;

				fibLine[countLine] = lastDirUp62[i];
				fibWeight[countLine] = weightLastDirUp62[i];
				countLine++;

				fibLine[countLine] = lastDirUp100[i];
				fibWeight[countLine] = weightLastDirUp100[i];
				countLine++;

				fibLine[countLine] = lastDirDown38[i];
				fibWeight[countLine] = weightLastDirDown38[i];
				countLine++;

				fibLine[countLine] = lastDirDown62[i];
				fibWeight[countLine] = weightLastDirDown62[i];
				countLine++;

				fibLine[countLine] = lastDirDown100[i];
				fibWeight[countLine] = weightLastDirDown100[i];
				countLine++;
				#endregion

				//==============================================================================================================================
				#region -- Section to calculate Alternate Projections (max. 8 Values calculated and displayed) --

				if (alt0Up[i] > 1.272 * alt1Up[i])
				{
					fibLine[countLine] = alt0Up62[i];
					fibWeight[countLine] = weightAlt0Up62[i];
					countLine++;
				}
				fibLine[countLine] = alt0Up100[i];
				fibWeight[countLine] = weightAlt0Up100[i];
				countLine++;

				fibLine[countLine] = alt0Up162[i];
				fibWeight[countLine] = weightAlt0Up162[i];
				countLine++;

				fibLine[countLine] = alt1Up100[i];
				fibWeight[countLine] = weightAlt1Up100[i];
				countLine++;

				if (alt0Down[i] > 1.272 * alt1Down[i])
				{
					fibLine[countLine] = alt0Down62[i];
					fibWeight[countLine] = weightAlt0Down62[i];
					countLine++;
				}

				fibLine[countLine] = alt0Down100[i];
				fibWeight[countLine] = weightAlt0Down100[i];
				countLine++;

				fibLine[countLine] = alt0Down162[i];
				fibWeight[countLine] = weightAlt0Down162[i];
				countLine++;

				fibLine[countLine] = alt1Down100[i];
				fibWeight[countLine] = weightAlt1Down100[i];
				countLine++;
				#endregion
			}

			//==============================================================================================================================
			// Select all Resistance and Support Lines within the Display Range and Determine Compounded Weight of Each Line
			//==============================================================================================================================			
			initialWeight = 0;
			compoundedWeight = 0;
			highestWeight = 0;

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				#region -- swings --
				dummy = cumulatedWeightMicroSwingHigh0[i];
				cumulatedWeightMicroSwingHigh0[i] = 0;
				if (microSwingHigh0[i] >= lowerLimitSupport && microSwingHigh0[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingHigh0[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingHigh0[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingHigh0[i] == microSwingHigh0[i])
							cumulatedWeightMicroSwingHigh0[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightMicroSwingHigh0[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightMicroSwingHigh1[i];
				cumulatedWeightMicroSwingHigh1[i] = 0;
				if (microSwingHigh1[i] >= lowerLimitSupport && microSwingHigh1[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingHigh1[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingHigh1[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingHigh1[i] == microSwingHigh1[i])
							cumulatedWeightMicroSwingHigh1[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightMicroSwingHigh1[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightMicroSwingHigh2[i];
				cumulatedWeightMicroSwingHigh2[i] = 0;
				if (microSwingHigh2[i] >= lowerLimitSupport && microSwingHigh2[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingHigh2[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingHigh2[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingHigh2[i] == microSwingHigh2[i])
							cumulatedWeightMicroSwingHigh2[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightMicroSwingHigh2[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightMicroSwingHigh3[i];
				cumulatedWeightMicroSwingHigh3[i] = 0;
				if (microSwingHigh3[i] >= lowerLimitSupport && microSwingHigh3[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingHigh3[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingHigh3[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingHigh3[i] == microSwingHigh3[i])
							cumulatedWeightMicroSwingHigh3[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightMicroSwingHigh3[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightMicroSwingLow0[i];
				cumulatedWeightMicroSwingLow0[i] = 0;
				if (microSwingLow0[i] >= lowerLimitSupport && microSwingLow0[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingLow0[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingLow0[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingLow0[i] == microSwingLow0[i])
							cumulatedWeightMicroSwingLow0[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightMicroSwingLow0[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightMicroSwingLow1[i];
				cumulatedWeightMicroSwingLow1[i] = 0;
				if (microSwingLow1[i] >= lowerLimitSupport && microSwingLow1[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingLow1[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingLow1[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingLow1[i] == microSwingLow1[i])
							cumulatedWeightMicroSwingLow1[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightMicroSwingLow1[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightMicroSwingLow2[i];
				cumulatedWeightMicroSwingLow2[i] = 0;
				if (microSwingLow2[i] >= lowerLimitSupport && microSwingLow2[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingLow2[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingLow2[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingLow2[i] == microSwingLow2[i])
							cumulatedWeightMicroSwingLow2[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightMicroSwingLow2[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightMicroSwingLow3[i];
				cumulatedWeightMicroSwingLow3[i] = 0;
				if (microSwingLow3[i] >= lowerLimitSupport && microSwingLow3[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingLow3[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingLow3[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingLow3[i] == microSwingLow3[i])
							cumulatedWeightMicroSwingLow3[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightMicroSwingLow3[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightCurrentSwingHigh[i];
				cumulatedWeightCurrentSwingHigh[i] = 0;
				if (currentSwingHigh[i] >= lowerLimitSupport && currentSwingHigh[i] <= upperLimitResistance)
				{
					initialWeight = weightCurrentSwingHigh[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(currentSwingHigh[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorCurrentSwingHigh[i] == currentSwingHigh[i])
							cumulatedWeightCurrentSwingHigh[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightCurrentSwingHigh[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightLastSwingHigh[i];
				cumulatedWeightLastSwingHigh[i] = 0;
				if (lastSwingHigh[i] >= lowerLimitSupport && lastSwingHigh[i] <= upperLimitResistance)
				{
					initialWeight = weightLastSwingHigh[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastSwingHigh[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastSwingHigh[i] == lastSwingHigh[i])
							cumulatedWeightLastSwingHigh[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightLastSwingHigh[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightCurrentSwingLow[i];
				cumulatedWeightCurrentSwingLow[i] = 0;
				if (currentSwingLow[i] >= lowerLimitSupport && currentSwingLow[i] <= upperLimitResistance)
				{
					initialWeight = weightCurrentSwingLow[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(currentSwingLow[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorCurrentSwingLow[i] == currentSwingLow[i])
							cumulatedWeightCurrentSwingLow[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightCurrentSwingLow[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightLastSwingLow[i];
				cumulatedWeightLastSwingLow[i] = 0;
				if (lastSwingLow[i] >= lowerLimitSupport && lastSwingLow[i] <= upperLimitResistance)
				{
					initialWeight = weightLastSwingLow[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastSwingLow[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastSwingLow[i] == lastSwingLow[i])
							cumulatedWeightLastSwingLow[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightLastSwingLow[i] = 0.5 * compoundedWeight;
					}
				}
				#endregion

				#region -- Ret --
				dummy = cumulatedWeightRetUp23[i];
				cumulatedWeightRetUp23[i] = 0;
				if (retUp23[i] >= lowerLimitSupport && retUp23[i] <= upperLimitResistance)
				{
					initialWeight = weightRetUp23[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retUp23[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetUp23[i] == retUp23[i])
							cumulatedWeightRetUp23[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightRetUp23[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightRetUp38[i];
				cumulatedWeightRetUp38[i] = 0;
				if (retUp38[i] >= lowerLimitSupport && retUp38[i] <= upperLimitResistance)
				{
					initialWeight = weightRetUp38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retUp38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetUp38[i] == retUp38[i])
							cumulatedWeightRetUp38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightRetUp38[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightRetUp50[i];
				cumulatedWeightRetUp50[i] = 0;
				if (retUp50[i] >= lowerLimitSupport && retUp50[i] <= upperLimitResistance)
				{
					initialWeight = weightRetUp50[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retUp50[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetUp50[i] == retUp50[i])
							cumulatedWeightRetUp50[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightRetUp50[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightRetUp62[i];
				cumulatedWeightRetUp62[i] = 0;
				if (retUp62[i] >= lowerLimitSupport && retUp62[i] <= upperLimitResistance)
				{
					initialWeight = weightRetUp62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retUp62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetUp62[i] == retUp62[i])
							cumulatedWeightRetUp62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightRetUp62[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightRetUp76[i];
				cumulatedWeightRetUp76[i] = 0;
				if (retUp76[i] >= lowerLimitSupport && retUp76[i] <= upperLimitResistance)
				{
					initialWeight = weightRetUp76[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retUp76[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetUp76[i] == retUp76[i])
							cumulatedWeightRetUp76[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightRetUp76[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightRetDown23[i];
				cumulatedWeightRetDown23[i] = 0;
				if (retDown23[i] >= lowerLimitSupport && retDown23[i] <= upperLimitResistance)
				{
					initialWeight = weightRetDown23[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retDown23[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetDown23[i] == retDown23[i])
							cumulatedWeightRetDown23[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightRetDown23[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightRetDown38[i];
				cumulatedWeightRetDown38[i] = 0;
				if (retDown38[i] >= lowerLimitSupport && retDown38[i] <= upperLimitResistance)
				{
					initialWeight = weightRetDown38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retDown38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetDown38[i] == retDown38[i])
							cumulatedWeightRetDown38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightRetDown38[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightRetDown50[i];
				cumulatedWeightRetDown50[i] = 0;
				if (retDown50[i] >= lowerLimitSupport && retDown50[i] <= upperLimitResistance)
				{
					initialWeight = weightRetDown50[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retDown50[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetDown50[i] == retDown50[i])
							cumulatedWeightRetDown50[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightRetDown50[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightRetDown62[i];
				cumulatedWeightRetDown62[i] = 0;
				if (retDown62[i] >= lowerLimitSupport && retDown62[i] <= upperLimitResistance)
				{
					initialWeight = weightRetDown62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retDown62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetDown62[i] == retDown62[i])
							cumulatedWeightRetDown62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightRetDown62[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightRetDown76[i];
				cumulatedWeightRetDown76[i] = 0;
				if (retDown76[i] >= lowerLimitSupport && retDown76[i] <= upperLimitResistance)
				{
					initialWeight = weightRetDown76[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retDown76[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetDown76[i] == retDown76[i])
							cumulatedWeightRetDown76[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightRetDown76[i] = 0.5 * compoundedWeight;
					}
				}
				#endregion

				#region -- Ext --
				dummy = cumulatedWeightExtUp127[i];
				cumulatedWeightExtUp127[i] = 0;
				if (extUp127[i] >= lowerLimitSupport && extUp127[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp127[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp127[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtUp127[i] == extUp127[i])
							cumulatedWeightExtUp127[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtUp127[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtUp162[i];
				cumulatedWeightExtUp162[i] = 0;
				if (extUp162[i] >= lowerLimitSupport && extUp162[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp162[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp162[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight <= initialWeight)
					{
						if (priorExtUp162[i] == extUp162[i])
							cumulatedWeightExtUp162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtUp162[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtUp200[i];
				cumulatedWeightExtUp200[i] = 0;
				if (extUp200[i] >= lowerLimitSupport && extUp200[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp200[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp200[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtUp200[i] == extUp200[i])
							cumulatedWeightExtUp200[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtUp200[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtUp262[i];
				cumulatedWeightExtUp262[i] = 0;
				if (extUp262[i] >= lowerLimitSupport && extUp262[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp262[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp262[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtUp262[i] == extUp262[i])
							cumulatedWeightExtUp262[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtUp262[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtUp300[i];
				cumulatedWeightExtUp300[i] = 0;
				if (extUp300[i] >= lowerLimitSupport && extUp300[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp300[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp300[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtUp300[i] == extUp300[i])
							cumulatedWeightExtUp300[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtUp300[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtUp423[i];
				cumulatedWeightExtUp423[i] = 0;
				if (extUp423[i] >= lowerLimitSupport && extUp423[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp423[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp423[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtUp423[i] == extUp423[i])
							cumulatedWeightExtUp423[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtUp423[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtDown127[i];
				cumulatedWeightExtDown127[i] = 0;
				if (extDown127[i] >= lowerLimitSupport && extDown127[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown127[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown127[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown127[i] == extDown127[i])
							cumulatedWeightExtDown127[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtDown127[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtDown162[i];
				cumulatedWeightExtDown162[i] = 0;
				if (extDown162[i] >= lowerLimitSupport && extDown162[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown162[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown162[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown162[i] == extDown162[i])
							cumulatedWeightExtDown162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtDown162[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtDown200[i];
				cumulatedWeightExtDown200[i] = 0;
				if (extDown200[i] >= lowerLimitSupport && extDown200[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown200[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown200[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown200[i] == extDown200[i])
							cumulatedWeightExtDown200[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtDown200[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtDown262[i];
				cumulatedWeightExtDown262[i] = 0;
				if (extDown262[i] >= lowerLimitSupport && extDown262[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown262[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown262[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown262[i] == extDown262[i])
							cumulatedWeightExtDown262[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtDown262[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtDown300[i];
				cumulatedWeightExtDown300[i] = 0;
				if (extDown300[i] >= lowerLimitSupport && extDown300[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown300[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown300[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown300[i] == extDown300[i])
							cumulatedWeightExtDown300[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtDown300[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightExtDown423[i];
				cumulatedWeightExtDown423[i] = 0;
				if (extDown423[i] >= lowerLimitSupport && extDown423[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown423[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown423[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown423[i] == extDown423[i])
							cumulatedWeightExtDown423[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightExtDown423[i] = 0.5 * compoundedWeight;
					}
				}
				#endregion

				#region -- Dir and LastDir --
				dummy = cumulatedWeightDirUp38[i];
				cumulatedWeightDirUp38[i] = 0;
				if (dirUp38[i] >= lowerLimitSupport && dirUp38[i] <= upperLimitResistance)
				{
					initialWeight = weightDirUp38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirUp38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirUp38[i] == dirUp38[i])
							cumulatedWeightDirUp38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightDirUp38[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightDirUp62[i];
				cumulatedWeightDirUp62[i] = 0;
				if (dirUp62[i] >= lowerLimitSupport && dirUp62[i] <= upperLimitResistance)
				{
					initialWeight = weightDirUp62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirUp62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirUp62[i] == dirUp62[i])
							cumulatedWeightDirUp62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightDirUp62[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightDirUp100[i];
				cumulatedWeightDirUp100[i] = 0;
				if (dirUp100[i] >= lowerLimitSupport && dirUp100[i] <= upperLimitResistance)
				{
					initialWeight = weightDirUp100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirUp100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirUp100[i] == dirUp100[i])
							cumulatedWeightDirUp100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightDirUp100[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightDirDown38[i];
				cumulatedWeightDirDown38[i] = 0;
				if (dirDown38[i] >= lowerLimitSupport && dirDown38[i] <= upperLimitResistance)
				{
					initialWeight = weightDirDown38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirDown38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirDown38[i] == dirDown38[i])
							cumulatedWeightDirDown38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightDirDown38[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightDirDown62[i];
				cumulatedWeightDirDown62[i] = 0;
				if (dirDown62[i] >= lowerLimitSupport && dirDown62[i] <= upperLimitResistance)
				{
					initialWeight = weightDirDown62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirDown62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirDown62[i] == dirDown62[i])
							cumulatedWeightDirDown62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightDirDown62[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightDirDown100[i];
				cumulatedWeightDirDown100[i] = 0;
				if (dirDown100[i] >= lowerLimitSupport && dirDown100[i] <= upperLimitResistance)
				{
					initialWeight = weightDirDown100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirDown100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirDown100[i] == dirDown100[i])
							cumulatedWeightDirDown100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightDirDown100[i] = 0.5 * compoundedWeight;
					}
				}

				dummy = cumulatedWeightLastDirUp38[i];
				cumulatedWeightLastDirUp38[i] = 0;
				if (lastDirUp38[i] >= lowerLimitSupport && lastDirUp38[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirUp38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirUp38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirUp38[i] == lastDirUp38[i])
							cumulatedWeightLastDirUp38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightLastDirUp38[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightLastDirUp62[i];
				cumulatedWeightLastDirUp62[i] = 0;
				if (lastDirUp62[i] >= lowerLimitSupport && lastDirUp62[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirUp62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirUp62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirUp62[i] == lastDirUp62[i])
							cumulatedWeightLastDirUp62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightLastDirUp62[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightLastDirUp100[i];
				cumulatedWeightLastDirUp100[i] = 0;
				if (lastDirUp100[i] >= lowerLimitSupport && lastDirUp100[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirUp100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirUp100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirUp100[i] == lastDirUp100[i])
							cumulatedWeightLastDirUp100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightLastDirUp100[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightLastDirDown38[i];
				cumulatedWeightLastDirDown38[i] = 0;
				if (lastDirDown38[i] >= lowerLimitSupport && lastDirDown38[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirDown38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirDown38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirDown38[i] == lastDirDown38[i])
							cumulatedWeightLastDirDown38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightLastDirDown38[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightLastDirDown62[i];
				cumulatedWeightLastDirDown62[i] = 0;
				if (lastDirDown62[i] >= lowerLimitSupport && lastDirDown62[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirDown62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirDown62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirDown62[i] == lastDirDown62[i])
							cumulatedWeightLastDirDown62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightLastDirDown62[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightLastDirDown100[i];
				cumulatedWeightLastDirDown100[i] = 0;
				if (lastDirDown100[i] >= lowerLimitSupport && lastDirDown100[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirDown100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirDown100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirDown100[i] == lastDirDown100[i])
							cumulatedWeightLastDirDown100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightLastDirDown100[i] = 0.5 * compoundedWeight;
					}
				}
				#endregion

				#region -- Alt --
				dummy = cumulatedWeightAlt0Up62[i];
				cumulatedWeightAlt0Up62[i] = 0;
				if (alt0Up62[i] >= lowerLimitSupport && alt0Up62[i] <= upperLimitResistance && alt0Up[i] > 1.272 * alt1Up[i])
				{
					initialWeight = weightAlt0Up62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Up62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Up62[i] == alt0Up62[i])
							cumulatedWeightAlt0Up62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightAlt0Up62[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightAlt0Up100[i];
				cumulatedWeightAlt0Up100[i] = 0;
				if (alt0Up100[i] >= lowerLimitSupport && alt0Up100[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt0Up100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Up100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Up100[i] == alt0Up100[i])
							cumulatedWeightAlt0Up100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightAlt0Up100[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightAlt0Up162[i];
				cumulatedWeightAlt0Up162[i] = 0;
				if (alt0Up162[i] >= lowerLimitSupport && alt0Up162[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt0Up162[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Up162[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Up162[i] == alt0Up162[i])
							cumulatedWeightAlt0Up162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightAlt0Up162[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightAlt1Up100[i];
				cumulatedWeightAlt1Up100[i] = 0;
				if (alt1Up100[i] >= lowerLimitSupport && alt1Up100[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt1Up100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt1Up100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt1Up100[i] == alt1Up100[i])
							cumulatedWeightAlt1Up100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightAlt1Up100[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightAlt0Down62[i];
				cumulatedWeightAlt0Down62[i] = 0;
				if (alt0Down62[i] >= lowerLimitSupport && alt0Down62[i] <= upperLimitResistance && alt0Down[i] > 1.272 * alt1Down[i])
				{
					initialWeight = weightAlt0Down62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Down62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Down62[i] == alt0Down62[i])
							cumulatedWeightAlt0Down62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightAlt0Down62[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightAlt0Down100[i];
				cumulatedWeightAlt0Down100[i] = 0;
				if (alt0Down100[i] >= lowerLimitSupport && alt0Down100[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt0Down100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Down100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Down100[i] == alt0Down100[i])
							cumulatedWeightAlt0Down100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightAlt0Down100[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightAlt0Down162[i];
				cumulatedWeightAlt0Down162[i] = 0;
				if (alt0Down162[i] >= lowerLimitSupport && alt0Down162[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt0Down162[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Down162[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Down162[i] == alt0Down162[i])
							cumulatedWeightAlt0Down162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightAlt0Down162[i] = 0.5 * compoundedWeight;
					}
				}
				dummy = cumulatedWeightAlt1Down100[i];
				cumulatedWeightAlt1Down100[i] = 0;
				if (alt1Down100[i] >= lowerLimitSupport && alt1Down100[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt1Down100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt1Down100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}
					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt1Down100[i] == alt1Down100[i])
							cumulatedWeightAlt1Down100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						else
							cumulatedWeightAlt1Down100[i] = 0.5 * compoundedWeight;
					}
				}
				#endregion

			}
		}
		#endregion

		//==============================================================================================================================
		// Prepare Lines for Display Range if Compounded Weight is Above Multiple of Threshold
		//==============================================================================================================================	
		#region -- SelectLines --
		public void SelectLines()
		{
			countResistance = 0;
			for (var i = 0; i < 540; i++) fibResistance[i] = 0;
			countSupport = 0;
			for (var i = 0; i < 540; i++) fibSupport[i] = 0;
			countWeakResistance = 0;
			for (var i = 0; i < 540; i++) weakResistance[i] = 0;
			countWeakSupport = 0;
			for (var i = 0; i < 540; i++) weakSupport[i] = 0;

			#region -- swings --
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightMicroSwingHigh0[i] > Threshold)
					if (microSwingHigh0[i] > lowerLimitResistance)
					{
						if (cumulatedWeightMicroSwingHigh0[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingHigh0[i];
							countResistance++;
						}
						else if (microSwingHigh0[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingHigh0[i];
							countWeakResistance++;
						}
					}
					else if (microSwingHigh0[i] <= upperLimitSupport)
					{
						if (cumulatedWeightMicroSwingHigh0[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingHigh0[i];
							countSupport++;
						}
						else if (microSwingHigh0[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingHigh0[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightMicroSwingHigh1[i] > Threshold)
					if (microSwingHigh1[i] > lowerLimitResistance)
					{
						if (cumulatedWeightMicroSwingHigh1[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingHigh1[i];
							countResistance++;
						}
						else if (microSwingHigh1[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingHigh1[i];
							countWeakResistance++;
						}
					}
					else if (microSwingHigh1[i] <= upperLimitSupport)
					{
						if (cumulatedWeightMicroSwingHigh1[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingHigh1[i];
							countSupport++;
						}
						else if (microSwingHigh1[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingHigh1[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightMicroSwingHigh2[i] > Threshold)
					if (microSwingHigh2[i] > lowerLimitResistance)
					{
						if (cumulatedWeightMicroSwingHigh2[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingHigh2[i];
							countResistance++;
						}
						else if (microSwingHigh2[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingHigh2[i];
							countWeakResistance++;
						}
					}
					else if (microSwingHigh2[i] <= upperLimitSupport)
					{
						if (cumulatedWeightMicroSwingHigh2[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingHigh2[i];
							countSupport++;
						}
						else if (microSwingHigh2[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingHigh2[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightMicroSwingHigh3[i] > Threshold)
					if (microSwingHigh3[i] > lowerLimitResistance)
					{
						if (cumulatedWeightMicroSwingHigh3[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingHigh3[i];
							countResistance++;
						}
						else if (microSwingHigh3[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingHigh3[i];
							countWeakResistance++;
						}
					}
					else if (microSwingHigh3[i] <= upperLimitSupport)
					{
						if (cumulatedWeightMicroSwingHigh3[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingHigh3[i];
							countSupport++;
						}
						else if (microSwingHigh3[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingHigh3[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightMicroSwingLow0[i] > Threshold)
					if (microSwingLow0[i] > lowerLimitResistance)
					{
						if (cumulatedWeightMicroSwingLow0[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingLow0[i];
							countResistance++;
						}
						else if (microSwingLow0[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingLow0[i];
							countWeakResistance++;
						}
					}
					else if (microSwingLow0[i] <= upperLimitSupport)
					{
						if (cumulatedWeightMicroSwingLow0[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingLow0[i];
							countSupport++;
						}
						else if (microSwingLow0[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingLow0[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightMicroSwingLow1[i] > Threshold)
					if (microSwingLow1[i] > lowerLimitResistance)
					{
						if (cumulatedWeightMicroSwingLow1[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingLow1[i];
							countResistance++;
						}
						else if (microSwingLow1[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingLow1[i];
							countWeakResistance++;
						}
					}
					else if (microSwingLow1[i] <= upperLimitSupport)
					{
						if (cumulatedWeightMicroSwingLow1[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingLow1[i];
							countSupport++;
						}
						else if (microSwingLow1[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingLow1[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightMicroSwingLow2[i] > Threshold)
					if (microSwingLow2[i] > lowerLimitResistance)
					{
						if (cumulatedWeightMicroSwingLow2[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingLow2[i];
							countResistance++;
						}
						else if (microSwingLow2[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingLow2[i];
							countWeakResistance++;
						}
					}
					else if (microSwingLow2[i] <= upperLimitSupport)
					{
						if (cumulatedWeightMicroSwingLow2[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingLow2[i];
							countSupport++;
						}
						else if (microSwingLow2[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingLow2[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightMicroSwingLow3[i] > Threshold)
					if (microSwingLow3[i] > lowerLimitResistance)
					{
						if (cumulatedWeightMicroSwingLow3[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingLow3[i];
							countResistance++;
						}
						else if (microSwingLow3[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingLow3[i];
							countWeakResistance++;
						}
					}
					else if (microSwingLow3[i] <= upperLimitSupport)
					{
						if (cumulatedWeightMicroSwingLow3[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingLow3[i];
							countSupport++;
						}
						else if (microSwingLow3[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingLow3[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightCurrentSwingHigh[i] > Threshold)
					if (currentSwingHigh[i] > lowerLimitResistance)
					{
						if (cumulatedWeightCurrentSwingHigh[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = currentSwingHigh[i];
							countResistance++;
						}
						else if (currentSwingHigh[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = currentSwingHigh[i];
							countWeakResistance++;
						}
					}
					else if (currentSwingHigh[i] <= upperLimitSupport)
					{
						if (cumulatedWeightCurrentSwingHigh[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = currentSwingHigh[i];
							countSupport++;
						}
						else if (currentSwingHigh[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = currentSwingHigh[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightLastSwingHigh[i] > Threshold)
					if (lastSwingHigh[i] > lowerLimitResistance)
					{
						if (cumulatedWeightLastSwingHigh[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastSwingHigh[i];
							countResistance++;
						}
						else if (lastSwingHigh[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastSwingHigh[i];
							countWeakResistance++;
						}
					}
					else if (lastSwingHigh[i] <= upperLimitSupport)
					{
						if (cumulatedWeightLastSwingHigh[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastSwingHigh[i];
							countSupport++;
						}
						else if (lastSwingHigh[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastSwingHigh[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightCurrentSwingLow[i] > Threshold)
					if (currentSwingLow[i] > lowerLimitResistance)
					{
						if (cumulatedWeightCurrentSwingLow[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = currentSwingLow[i];
							countResistance++;
						}
						else if (currentSwingLow[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = currentSwingLow[i];
							countWeakResistance++;
						}
					}
					else if (currentSwingLow[i] <= upperLimitSupport)
					{
						if (cumulatedWeightCurrentSwingLow[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = currentSwingLow[i];
							countSupport++;
						}
						else if (currentSwingLow[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = currentSwingLow[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightLastSwingLow[i] > Threshold)
					if (lastSwingLow[i] > lowerLimitResistance)
					{
						if (cumulatedWeightLastSwingLow[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastSwingLow[i];
							countResistance++;
						}
						else if (lastSwingLow[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastSwingLow[i];
							countWeakResistance++;
						}
					}
					else if (lastSwingLow[i] <= upperLimitSupport)
					{
						if (cumulatedWeightLastSwingLow[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastSwingLow[i];
							countSupport++;
						}
						else if (lastSwingLow[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastSwingLow[i];
							countWeakSupport++;
						}
					}
			}
			#endregion

			#region -- Ret --
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightRetUp23[i] > Threshold)
					if (retUp23[i] > lowerLimitResistance)
					{
						if (cumulatedWeightRetUp23[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retUp23[i];
							countResistance++;
						}
						else if (retUp23[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retUp23[i];
							countWeakResistance++;
						}
					}
					else if (retUp23[i] <= upperLimitSupport)
					{
						if (cumulatedWeightRetUp23[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retUp23[i];
							countSupport++;
						}
						else if (retUp23[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retUp23[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightRetUp38[i] > Threshold)
					if (retUp38[i] > lowerLimitResistance)
					{
						if (cumulatedWeightRetUp38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retUp38[i];
							countResistance++;
						}
						else if (retUp38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retUp38[i];
							countWeakResistance++;
						}
					}
					else if (retUp38[i] <= upperLimitSupport)
					{
						if (cumulatedWeightRetUp38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retUp38[i];
							countSupport++;
						}
						else if (retUp38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retUp38[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightRetUp50[i] > Threshold)
					if (retUp50[i] > lowerLimitResistance)
					{
						if (cumulatedWeightRetUp50[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retUp50[i];
							countResistance++;
						}
						else if (retUp50[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retUp50[i];
							countWeakResistance++;
						}
					}
					else if (retUp50[i] <= upperLimitSupport)
					{
						if (cumulatedWeightRetUp50[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retUp50[i];
							countSupport++;
						}
						else if (retUp50[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retUp50[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightRetUp62[i] > Threshold)
					if (retUp62[i] > lowerLimitResistance)
					{
						if (cumulatedWeightRetUp62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retUp62[i];
							countResistance++;
						}
						else if (retUp62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retUp62[i];
							countWeakResistance++;
						}
					}
					else if (retUp62[i] <= upperLimitSupport)
					{
						if (cumulatedWeightRetUp62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retUp62[i];
							countSupport++;
						}
						else if (retUp62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retUp62[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightRetUp76[i] > Threshold)
					if (retUp76[i] > lowerLimitResistance)
					{
						if (cumulatedWeightRetUp76[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retUp76[i];
							countResistance++;
						}
						else if (retUp76[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retUp76[i];
							countWeakResistance++;
						}
					}
					else if (retUp76[i] <= upperLimitSupport)
					{
						if (cumulatedWeightRetUp76[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retUp76[i];
							countSupport++;
						}
						else if (retUp76[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retUp76[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightRetDown23[i] > Threshold)
					if (retDown23[i] > lowerLimitResistance)
					{
						if (cumulatedWeightRetDown23[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retDown23[i];
							countResistance++;
						}
						else if (retDown23[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retDown23[i];
							countWeakResistance++;
						}
					}
					else if (retDown23[i] <= upperLimitSupport)
					{
						if (cumulatedWeightRetDown23[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retDown23[i];
							countSupport++;
						}
						else if (retDown23[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retDown23[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightRetDown38[i] > Threshold)
					if (retDown38[i] > lowerLimitResistance)
					{
						if (cumulatedWeightRetDown38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retDown38[i];
							countResistance++;
						}
						else if (retDown38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retDown38[i];
							countWeakResistance++;
						}
					}
					else if (retDown38[i] <= upperLimitSupport)
					{
						if (cumulatedWeightRetDown38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retDown38[i];
							countSupport++;
						}
						else if (retDown38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retDown38[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightRetDown50[i] > Threshold)
					if (retDown50[i] > lowerLimitResistance)
					{
						if (cumulatedWeightRetDown50[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retDown50[i];
							countResistance++;
						}
						else if (retDown50[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retDown50[i];
							countWeakResistance++;
						}
					}
					else if (retDown50[i] <= upperLimitSupport)
					{
						if (cumulatedWeightRetDown50[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retDown50[i];
							countSupport++;
						}
						else if (retDown50[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retDown50[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightRetDown62[i] > Threshold)
					if (retDown62[i] > lowerLimitResistance)
					{
						if (cumulatedWeightRetDown62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retDown62[i];
							countResistance++;
						}
						else if (retDown62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retDown62[i];
							countWeakResistance++;
						}
					}
					else if (retDown62[i] <= upperLimitSupport)
					{
						if (cumulatedWeightRetDown62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retDown62[i];
							countSupport++;
						}
						else if (retDown62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retDown62[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightRetDown76[i] > Threshold)
					if (retDown76[i] > lowerLimitResistance)
					{
						if (cumulatedWeightRetDown76[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retDown76[i];
							countResistance++;
						}
						else if (retDown76[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retDown76[i];
							countWeakResistance++;
						}
					}
					else if (retDown76[i] <= upperLimitSupport)
					{
						if (cumulatedWeightRetDown76[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retDown76[i];
							countSupport++;
						}
						else if (retDown76[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retDown76[i];
							countWeakSupport++;
						}
					}
			}
			#endregion

			#region -- Ext --
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtUp127[i] > Threshold)
					if (extUp127[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtUp127[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp127[i];
							countResistance++;
						}
						else if (extUp127[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp127[i];
							countWeakResistance++;
						}
					}
					else if (extUp127[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtUp127[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp127[i];
							countSupport++;
						}
						else if (extUp127[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp127[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtUp162[i] > Threshold)
					if (extUp162[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtUp162[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp162[i];
							countResistance++;
						}
						else if (extUp162[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp162[i];
							countWeakResistance++;
						}
					}
					else if (extUp162[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtUp162[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp162[i];
							countSupport++;
						}
						else if (extUp162[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp162[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtUp200[i] > Threshold)
					if (extUp200[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtUp200[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp200[i];
							countResistance++;
						}
						else if (extUp200[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp200[i];
							countWeakResistance++;
						}
					}
					else if (extUp200[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtUp200[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp200[i];
							countSupport++;
						}
						else if (extUp200[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp200[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtUp262[i] > Threshold)
					if (extUp262[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtUp262[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp262[i];
							countResistance++;
						}
						else if (extUp262[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp262[i];
							countWeakResistance++;
						}
					}
					else if (extUp262[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtUp262[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp262[i];
							countSupport++;
						}
						else if (extUp262[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp262[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtUp300[i] > Threshold)
					if (extUp300[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtUp300[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp300[i];
							countResistance++;
						}
						else if (extUp300[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp300[i];
							countWeakResistance++;
						}
					}
					else if (extUp300[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtUp300[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp300[i];
							countSupport++;
						}
						else if (extUp300[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp300[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtUp423[i] > Threshold)
					if (extUp423[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtUp423[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp423[i];
							countResistance++;
						}
						else if (extUp423[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp423[i];
							countWeakResistance++;
						}
					}
					else if (extUp423[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtUp423[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp423[i];
							countSupport++;
						}
						else if (extUp423[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp423[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtDown127[i] > Threshold)
					if (extDown127[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtDown127[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown127[i];
							countResistance++;
						}
						else if (extDown127[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown127[i];
							countWeakResistance++;
						}
					}
					else if (extDown127[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtDown127[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown127[i];
							countSupport++;
						}
						else if (extDown127[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown127[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtDown162[i] > Threshold)
					if (extDown162[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtDown162[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown162[i];
							countResistance++;
						}
						else if (extDown162[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown162[i];
							countWeakResistance++;
						}
					}
					else if (extDown162[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtDown162[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown162[i];
							countSupport++;
						}
						else if (extDown162[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown162[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtDown200[i] > Threshold)
					if (extDown200[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtDown200[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown200[i];
							countResistance++;
						}
						else if (extDown200[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown200[i];
							countWeakResistance++;
						}
					}
					else if (extDown200[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtDown200[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown200[i];
							countSupport++;
						}
						else if (extDown200[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown200[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtDown262[i] > Threshold)
					if (extDown262[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtDown262[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown262[i];
							countResistance++;
						}
						else if (extDown262[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown262[i];
							countWeakResistance++;
						}
					}
					else if (extDown262[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtDown262[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown262[i];
							countSupport++;
						}
						else if (extDown262[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown262[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtDown300[i] > Threshold)
					if (extDown300[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtDown300[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown300[i];
							countResistance++;
						}
						else if (extDown300[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown300[i];
							countWeakResistance++;
						}
					}
					else if (extDown300[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtDown300[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown300[i];
							countSupport++;
						}
						else if (extDown300[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown300[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightExtDown423[i] > Threshold)
					if (extDown423[i] > lowerLimitResistance)
					{
						if (cumulatedWeightExtDown423[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown423[i];
							countResistance++;
						}
						else if (extDown423[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown423[i];
							countWeakResistance++;
						}
					}
					else if (extDown423[i] <= upperLimitSupport)
					{
						if (cumulatedWeightExtDown423[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown423[i];
							countSupport++;
						}
						else if (extDown423[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown423[i];
							countWeakSupport++;
						}
					}
			}
			#endregion

			#region -- Dir and LastDir --
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightDirUp38[i] > Threshold)
					if (dirUp38[i] > lowerLimitResistance)
					{
						if (cumulatedWeightDirUp38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirUp38[i];
							countResistance++;
						}
						else if (dirUp38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirUp38[i];
							countWeakResistance++;
						}
					}
					else if (dirUp38[i] <= upperLimitSupport)
					{
						if (cumulatedWeightDirUp38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirUp38[i];
							countSupport++;
						}
						else if (dirUp38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirUp38[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightDirUp62[i] > Threshold)
					if (dirUp62[i] > lowerLimitResistance)
					{
						if (cumulatedWeightDirUp62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirUp62[i];
							countResistance++;
						}
						else if (dirUp62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirUp62[i];
							countWeakResistance++;
						}
					}
					else if (dirUp62[i] <= upperLimitSupport)
					{
						if (cumulatedWeightDirUp62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirUp62[i];
							countSupport++;
						}
						else if (dirUp62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirUp62[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightDirUp100[i] > Threshold)
					if (dirUp100[i] > lowerLimitResistance)
					{
						if (cumulatedWeightDirUp100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirUp100[i];
							countResistance++;
						}
						else if (dirUp100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirUp100[i];
							countWeakResistance++;
						}
					}
					else if (dirUp100[i] <= upperLimitSupport)
					{
						if (cumulatedWeightDirUp100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirUp100[i];
							countSupport++;
						}
						else if (dirUp100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirUp100[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightDirDown38[i] > Threshold)
					if (dirDown38[i] > lowerLimitResistance)
					{
						if (cumulatedWeightDirDown38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirDown38[i];
							countResistance++;
						}
						else if (dirDown38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirDown38[i];
							countWeakResistance++;
						}
					}
					else if (dirDown38[i] <= upperLimitSupport)
					{
						if (cumulatedWeightDirDown38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirDown38[i];
							countSupport++;
						}
						else if (dirDown38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirDown38[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightDirDown62[i] > Threshold)
					if (dirDown62[i] > lowerLimitResistance)
					{
						if (cumulatedWeightDirDown62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirDown62[i];
							countResistance++;
						}
						else if (dirDown62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirDown62[i];
							countWeakResistance++;
						}
					}
					else if (dirDown62[i] <= upperLimitSupport)
					{
						if (cumulatedWeightDirDown62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirDown62[i];
							countSupport++;
						}
						else if (dirDown62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirDown62[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightDirDown100[i] > Threshold)
					if (dirDown100[i] > lowerLimitResistance)
					{
						if (cumulatedWeightDirDown100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirDown100[i];
							countResistance++;
						}
						else if (dirDown100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirDown100[i];
							countWeakResistance++;
						}
					}
					else if (dirDown100[i] <= upperLimitSupport)
					{
						if (cumulatedWeightDirDown100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirDown100[i];
							countSupport++;
						}
						else if (dirDown100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirDown100[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightLastDirUp38[i] > Threshold)
					if (lastDirUp38[i] > lowerLimitResistance)
					{
						if (cumulatedWeightLastDirUp38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirUp38[i];
							countResistance++;
						}
						else if (lastDirUp38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirUp38[i];
							countWeakResistance++;
						}
					}
					else if (lastDirUp38[i] <= upperLimitSupport)
					{
						if (cumulatedWeightLastDirUp38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirUp38[i];
							countSupport++;
						}
						else if (lastDirUp38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirUp38[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightLastDirUp62[i] > Threshold)
					if (lastDirUp62[i] > lowerLimitResistance)
					{
						if (cumulatedWeightLastDirUp62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirUp62[i];
							countResistance++;
						}
						else if (lastDirUp62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirUp62[i];
							countWeakResistance++;
						}
					}
					else if (lastDirUp62[i] <= upperLimitSupport)
					{
						if (cumulatedWeightLastDirUp62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirUp62[i];
							countSupport++;
						}
						else if (lastDirUp62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirUp62[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightLastDirUp100[i] > Threshold)
					if (lastDirUp100[i] > lowerLimitResistance)
					{
						if (cumulatedWeightLastDirUp100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirUp100[i];
							countResistance++;
						}
						else if (lastDirUp100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirUp100[i];
							countWeakResistance++;
						}
					}
					else if (lastDirUp100[i] <= upperLimitSupport)
					{
						if (cumulatedWeightLastDirUp100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirUp100[i];
							countSupport++;
						}
						else if (lastDirUp100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirUp100[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightLastDirDown38[i] > Threshold)
					if (lastDirDown38[i] > lowerLimitResistance)
					{
						if (cumulatedWeightLastDirDown38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirDown38[i];
							countResistance++;
						}
						else if (lastDirDown38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirDown38[i];
							countWeakResistance++;
						}
					}
					else if (lastDirDown38[i] <= upperLimitSupport)
					{
						if (cumulatedWeightLastDirDown38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirDown38[i];
							countSupport++;
						}
						else if (lastDirDown38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirDown38[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightLastDirDown62[i] > Threshold)
					if (lastDirDown62[i] > lowerLimitResistance)
					{
						if (cumulatedWeightLastDirDown62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirDown62[i];
							countResistance++;
						}
						else if (lastDirDown62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirDown62[i];
							countWeakResistance++;
						}
					}
					else if (lastDirDown62[i] <= upperLimitSupport)
					{
						if (cumulatedWeightLastDirDown62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirDown62[i];
							countSupport++;
						}
						else if (lastDirDown62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirDown62[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightLastDirDown100[i] > Threshold)
					if (lastDirDown100[i] > lowerLimitResistance)
					{
						if (cumulatedWeightLastDirDown100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirDown100[i];
							countResistance++;
						}
						else if (lastDirDown100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirDown100[i];
							countWeakResistance++;
						}
					}
					else if (lastDirDown100[i] <= upperLimitSupport)
					{
						if (cumulatedWeightLastDirDown100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirDown100[i];
							countSupport++;
						}
						else if (lastDirDown100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirDown100[i];
							countWeakSupport++;
						}
					}
			}
			#endregion

			#region -- Alt --
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightAlt0Up62[i] > Threshold)
					if (alt0Up62[i] > lowerLimitResistance)
					{
						if (cumulatedWeightAlt0Up62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Up62[i];
							countResistance++;
						}
						else if (alt0Up62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Up62[i];
							countWeakResistance++;
						}
					}
					else if (alt0Up62[i] <= upperLimitSupport)
					{
						if (cumulatedWeightAlt0Up62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Up62[i];
							countSupport++;
						}
						else if (alt0Up62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Up62[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightAlt0Up100[i] > Threshold)
					if (alt0Up100[i] > lowerLimitResistance)
					{
						if (cumulatedWeightAlt0Up100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Up100[i];
							countResistance++;
						}
						else if (alt0Up100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Up100[i];
							countWeakResistance++;
						}
					}
					else if (alt0Up100[i] <= upperLimitSupport)
					{
						if (cumulatedWeightAlt0Up100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Up100[i];
							countSupport++;
						}
						else if (alt0Up100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Up100[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightAlt0Up162[i] > Threshold)
					if (alt0Up162[i] > lowerLimitResistance)
					{
						if (cumulatedWeightAlt0Up162[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Up162[i];
							countResistance++;
						}
						else if (alt0Up162[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Up162[i];
							countWeakResistance++;
						}
					}
					else if (alt0Up162[i] <= upperLimitSupport)
					{
						if (cumulatedWeightAlt0Up162[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Up162[i];
							countSupport++;
						}
						else if (alt0Up162[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Up162[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightAlt1Up100[i] > Threshold)
					if (alt1Up100[i] > lowerLimitResistance)
					{
						if (cumulatedWeightAlt1Up100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt1Up100[i];
							countResistance++;
						}
						else if (alt1Up100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt1Up100[i];
							countWeakResistance++;
						}
					}
					else if (alt1Up100[i] <= upperLimitSupport)
					{
						if (cumulatedWeightAlt1Up100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt1Up100[i];
							countSupport++;
						}
						else if (alt1Up100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt1Up100[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightAlt0Down62[i] > Threshold)
					if (alt0Down62[i] > lowerLimitResistance)
					{
						if (cumulatedWeightAlt0Down62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Down62[i];
							countResistance++;
						}
						else if (alt0Down62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Down62[i];
							countWeakResistance++;
						}
					}
					else if (alt0Down62[i] <= upperLimitSupport)
					{
						if (cumulatedWeightAlt0Down62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Down62[i];
							countSupport++;
						}
						else if (alt0Down62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Down62[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightAlt0Down100[i] > Threshold)
					if (alt0Down100[i] > lowerLimitResistance)
					{
						if (cumulatedWeightAlt0Down100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Down100[i];
							countResistance++;
						}
						else if (alt0Down100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Down100[i];
							countWeakResistance++;
						}
					}
					else if (alt0Down100[i] <= upperLimitSupport)
					{
						if (cumulatedWeightAlt0Down100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Down100[i];
							countSupport++;
						}
						else if (alt0Down100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Down100[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightAlt0Down162[i] > Threshold)
					if (alt0Down162[i] > lowerLimitResistance)
					{
						if (cumulatedWeightAlt0Down162[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Down162[i];
							countResistance++;
						}
						else if (alt0Down162[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Down162[i];
							countWeakResistance++;
						}
					}
					else if (alt0Down162[i] <= upperLimitSupport)
					{
						if (cumulatedWeightAlt0Down162[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Down162[i];
							countSupport++;
						}
						else if (alt0Down162[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Down162[i];
							countWeakSupport++;
						}
					}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumulatedWeightAlt1Down100[i] > Threshold)
					if (alt1Down100[i] > lowerLimitResistance)
					{
						if (cumulatedWeightAlt1Down100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt1Down100[i];
							countResistance++;
						}
						else if (alt1Down100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt1Down100[i];
							countWeakResistance++;
						}
					}
					else if (alt1Down100[i] <= upperLimitSupport)
					{
						if (cumulatedWeightAlt1Down100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt1Down100[i];
							countSupport++;
						}
						else if (alt1Down100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt1Down100[i];
							countWeakSupport++;
						}
					}
			}
			#endregion
		}
		#endregion

		//==============================================================================================================================
		// Sorting Arrays fibResistance, fib, fibLine and  fibWeight with BubbleSort to prepare for Analyzer
		//==============================================================================================================================
		#region -- SortLines --
		public void SortLines()
		{
			#region -- Resistance Array is sorted in ascending order
			goAhead = true;
			m = countResistance;
			while (goAhead && m >= 1)
			{
				goAhead = false;
				for (var i = 1; i < m; i++)
				{
					if (fibResistance[i - 1] > fibResistance[i])
					{
						dummy = fibResistance[i - 1];
						fibResistance[i - 1] = fibResistance[i];
						fibResistance[i] = dummy;
						goAhead = true;
					}
					fibResistance[i - 1] = Instrument.MasterInstrument.RoundToTickSize(fibResistance[i - 1]);
				}
				m--;
			}
			#endregion

			#region -- Support Array is sorted in descending order
			goAhead = true;
			n = countSupport;
			while (goAhead && n >= 1)
			{
				goAhead = false;
				for (var i = 1; i < n; i++)
				{
					if (fibSupport[i - 1] < fibSupport[i])
					{
						dummy = fibSupport[i - 1];
						fibSupport[i - 1] = fibSupport[i];
						fibSupport[i] = dummy;
						goAhead = true;
					}
					fibSupport[i - 1] = Instrument.MasterInstrument.RoundToTickSize(fibSupport[i - 1]);
				}
				n--;
			}
			#endregion

			#region -- Weak Resistance Array is sorted in ascending order
			goAhead = true;
			m = countWeakResistance;
			while (goAhead && m >= 1)
			{
				goAhead = false;
				for (var i = 1; i < m; i++)
				{
					if (weakResistance[i - 1] > weakResistance[i])
					{
						dummy = weakResistance[i - 1];
						weakResistance[i - 1] = weakResistance[i];
						weakResistance[i] = dummy;
						goAhead = true;
					}
					weakResistance[i - 1] = Instrument.MasterInstrument.RoundToTickSize(weakResistance[i - 1]);
				}
				m--;
			}
			#endregion

			#region -- Support Array is sorted in descending order
			goAhead = true;
			n = countWeakSupport;
			while (goAhead && n >= 1)
			{
				goAhead = false;
				for (var i = 1; i < n; i++)
				{
					if (weakSupport[i - 1] < weakSupport[i])
					{
						dummy = weakSupport[i - 1];
						weakSupport[i - 1] = weakSupport[i];
						weakSupport[i] = dummy;
						goAhead = true;
					}
					weakSupport[i - 1] = Instrument.MasterInstrument.RoundToTickSize(weakSupport[i - 1]);
				}
				n--;
			}
			#endregion
		}
		#endregion

		#region --- Properties ---

		#region -- Confluences --
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence0 { get { return Values[0]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence1 { get { return Values[1]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence2 { get { return Values[2]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence3 { get { return Values[3]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence4 { get { return Values[4]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence5 { get { return Values[5]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence6 { get { return Values[6]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence7 { get { return Values[7]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence8 { get { return Values[8]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence9 { get { return Values[9]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence10 { get { return Values[10]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence11 { get { return Values[11]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence12 { get { return Values[12]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence13 { get { return Values[13]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence14 { get { return Values[14]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence15 { get { return Values[15]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence16 { get { return Values[16]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence17 { get { return Values[17]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence18 { get { return Values[18]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Confluence19 { get { return Values[19]; } }
		#endregion

		#region -- WeakConfluences --
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence0 { get { return Values[20]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence1 { get { return Values[21]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence2 { get { return Values[22]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence3 { get { return Values[23]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence4 { get { return Values[24]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence5 { get { return Values[25]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence6 { get { return Values[26]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence7 { get { return Values[27]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence8 { get { return Values[28]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence9 { get { return Values[29]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence10 { get { return Values[30]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence11 { get { return Values[31]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence12 { get { return Values[32]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence13 { get { return Values[33]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence14 { get { return Values[34]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence15 { get { return Values[35]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence16 { get { return Values[36]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence17 { get { return Values[37]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence18 { get { return Values[38]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence19 { get { return Values[39]; } }
		#endregion
		#endregion

		#region -- Parameters --

		#region -- SwingTrend Parameters --

		[Display(Name = "Use Highs/Lows", GroupName = "SwingTrend Parameters", Description = "Use High/Lows or Input", Order = 5)]
		public bool isHLBased { get; set; }

		[Range(1, 300)]
		[Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 10)]
		public int SwingStrength { get; set; }

		[Range(0, double.MaxValue)]
		[Display(Name = "Deviation multiplier", GroupName = "SwingTrend Parameters", Description = "Multiplier used to calculate minimum as an ATR multiple", Order = 15)]
		public double MultiplierMD { get; set; }

		[Range(0, double.MaxValue)]
		[Display(Name = "Sensitivity double tops/bottoms", GroupName = "SwingTrend Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 20)]
		public double MultiplierDTB { get; set; }

		[Display(Name = "Show Background Color", GroupName = "SwingTrend Parameters", Description = "Colorize the background up/down structure trend zones", Order = 30)]
		public bool ShowStructureBackground { get; set; }

		[XmlIgnore]
		[Display(Name = "Up-trend bkg color", GroupName = "SwingTrend Parameters", Description = "Background color for up-trending structure", Order = 35)]
		public Brush UpTrendColor { get; set; }
		[Browsable(false)]
		public string UpTrendColorSerialize
		{
			get { return Serialize.BrushToString(UpTrendColor); }
			set { UpTrendColor = Serialize.StringToBrush(value); }
		}
		[Range(0, 100)]
		[Display(Name = "Opacity (up-trend)", GroupName = "SwingTrend Parameters", Description = "Opacity of the up-trend background color", Order = 40)]
		public int OpacityUpTrendBkg { get; set; }

		[XmlIgnore]
		[Display(Name = "Down-trend bkg color", GroupName = "SwingTrend Parameters", Description = "Background color for down-trending structure", Order = 45)]
		public Brush DownTrendColor { get; set; }
		[Browsable(false)]
		public string DownTrendColorSerialize
		{
			get { return Serialize.BrushToString(DownTrendColor); }
			set { DownTrendColor = Serialize.StringToBrush(value); }
		}
		[Range(0, 100)]
		[Display(Name = "Opacity (down-trend)", GroupName = "SwingTrend Parameters", Description = "Opacity of the down-trend background color", Order = 50)]
		public int OpacityDownTrendBkg { get; set; }


		[Display(Name = "Show Lines", GroupName = "SwingTrend Parameters", Description = "Show structure trend lines", Order = 53)]
		public bool ShowStructureLines { get; set; }

		[XmlIgnore]
		[Display(Name = "Up-trend line color", GroupName = "SwingTrend Parameters", Description = "Line color for up-trending structure", Order = 55)]
		public Brush UpLineColor { get; set; }
		[Browsable(false)]
		public string UpLineColorSerialize
		{
			get { return Serialize.BrushToString(UpLineColor); }
			set { UpLineColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Down-trend line color", GroupName = "SwingTrend Parameters", Description = "Line color for down-trending structure", Order = 60)]
		public Brush DownLineColor { get; set; }
		[Browsable(false)]
		public string DownLineColorSerialize
		{
			get { return Serialize.BrushToString(DownLineColor); }
			set { DownLineColor = Serialize.StringToBrush(value); }
		}
		[Range(1, 10)]
		[Display(Name = "Line Thickness", GroupName = "SwingTrend Parameters", Description = "Thickness of structure lines", Order = 65)]
		public int LineThickness { get; set; }

		[Display(Name = "Show Labels", GroupName = "SwingTrend Parameters", Description = "Show zigzag labels (e.g. 'HH' or 'LH', etc)", Order = 70)]
		public bool ShowStructureLabels { get; set; }
		#endregion

		#region general Parameters
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Bar period for minute bars", GroupName = " Parameters", Description = "Bar period for minute bars which are used to calculate the Fibonacci confluence lines", Order = 0)]
		public int BarPeriod { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Fibonacci swing timeframe", GroupName = " Parameters", Description = "Timeframes used to identify Fibonacci swings", Order = 1)]
		public ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution LineDensity { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Grid strength", GroupName = " Parameters", Description = "Width of the grid used for summing up Fibonacci lines", Order = 2)]
		public ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth ConfluenceZone { get; set; }

		[NinjaScriptProperty]
		[Range(0.0, double.MaxValue)]
		[Display(Name = "Threshold for confluence lines", GroupName = " Parameters", Description = "The treshold set the minumum statistical weight required for a confluence line. Confluence lines with a weight below the threshold value will not be shown.", Order = 3)]
		public double Threshold { get; set; }

		[NinjaScriptProperty]
		[Range(30, int.MaxValue)]
		[Display(Name = "Total lookback (days)", GroupName = " Parameters", Description = "Lookback period for data used for calculating Fibonacci lines", Order = 4)]
		public int LookBackMinute { get; set; }

		[Display(Name = "Check data preloading", GroupName = " Parameters", Description = "Checks and displays the range for the preloaded data", Order = 5)]
		public bool ShowMinuteDataPeriod { get; set; }

		[Description("Button text - enter how you want the UI button to be labeled")]
		[Display(Order = 10, Name = "Button Txt", GroupName = " Parameters", ResourceType = typeof(Custom.Resource))]
		public string pButtonText { get; set; }

		#endregion
		#endregion

		#region -- Plots --
		[XmlIgnore]
		[Display(Name = "Resistance lines", GroupName = "Plots", Description = "Select color for all resistance lines", Order = 0)]
		public Brush ResistanceColor { get; set; }
		[Browsable(false)]
		public string ResistanceColorSerialize
		{
			get { return Serialize.BrushToString(ResistanceColor); }
			set { ResistanceColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Support lines", GroupName = "Plots", Description = "Select color for all support lines", Order = 1)]
		public Brush SupportColor { get; set; }
		[Browsable(false)]
		public string SupportColorSerialize
		{
			get { return Serialize.BrushToString(SupportColor); }
			set { SupportColor = Serialize.StringToBrush(value); }
		}

		[Range(1, int.MaxValue)]
		[Display(Name = "Line width major lines", GroupName = "Plots", Description = "Width for major lines.", Order = 2)]
		public int LineWidthStrong { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Line width minor lines", GroupName = "Plots", Description = "Width for minor lines.", Order = 3)]
		public int LineWidthWeak { get; set; }

		[Display(Name = "Plot style major lines", GroupName = "Plots", Description = "Plot style for major lines.", Order = 4)]
		public PlotStyle StrongPlotStyle { get; set; }

		[Display(Name = "Plot style minor lines", GroupName = "Plots", Description = "Plot style for minor lines.", Order = 5)]
		public PlotStyle WeakPlotStyle { get; set; }

		[Display(Name = "Dash style major lines", GroupName = "Plots", Description = "Dash style for major lines.", Order = 6)]
		public DashStyleHelper StrongDashStyle { get; set; }

		[Display(Name = "Dash style minor lines", GroupName = "Plots", Description = "Dash style for minor lines.", Order = 7)]
		public DashStyleHelper WeakDashStyle { get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_AutoFibAlgo_ARC_GoldenFibsSys[] cacheARC_AutoFibAlgo_ARC_GoldenFibsSys;
		public ARC.ARC_AutoFibAlgo_ARC_GoldenFibsSys ARC_AutoFibAlgo_ARC_GoldenFibsSys(int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			return ARC_AutoFibAlgo_ARC_GoldenFibsSys(Input, barPeriod, lineDensity, confluenceZone, threshold, lookBackMinute);
		}

		public ARC.ARC_AutoFibAlgo_ARC_GoldenFibsSys ARC_AutoFibAlgo_ARC_GoldenFibsSys(ISeries<double> input, int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			if (cacheARC_AutoFibAlgo_ARC_GoldenFibsSys != null)
				for (int idx = 0; idx < cacheARC_AutoFibAlgo_ARC_GoldenFibsSys.Length; idx++)
					if (cacheARC_AutoFibAlgo_ARC_GoldenFibsSys[idx] != null && cacheARC_AutoFibAlgo_ARC_GoldenFibsSys[idx].BarPeriod == barPeriod && cacheARC_AutoFibAlgo_ARC_GoldenFibsSys[idx].LineDensity == lineDensity && cacheARC_AutoFibAlgo_ARC_GoldenFibsSys[idx].ConfluenceZone == confluenceZone && cacheARC_AutoFibAlgo_ARC_GoldenFibsSys[idx].Threshold == threshold && cacheARC_AutoFibAlgo_ARC_GoldenFibsSys[idx].LookBackMinute == lookBackMinute && cacheARC_AutoFibAlgo_ARC_GoldenFibsSys[idx].EqualsInput(input))
						return cacheARC_AutoFibAlgo_ARC_GoldenFibsSys[idx];
			return CacheIndicator<ARC.ARC_AutoFibAlgo_ARC_GoldenFibsSys>(new ARC.ARC_AutoFibAlgo_ARC_GoldenFibsSys(){ BarPeriod = barPeriod, LineDensity = lineDensity, ConfluenceZone = confluenceZone, Threshold = threshold, LookBackMinute = lookBackMinute }, input, ref cacheARC_AutoFibAlgo_ARC_GoldenFibsSys);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_AutoFibAlgo_ARC_GoldenFibsSys ARC_AutoFibAlgo_ARC_GoldenFibsSys(int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			return indicator.ARC_AutoFibAlgo_ARC_GoldenFibsSys(Input, barPeriod, lineDensity, confluenceZone, threshold, lookBackMinute);
		}

		public Indicators.ARC.ARC_AutoFibAlgo_ARC_GoldenFibsSys ARC_AutoFibAlgo_ARC_GoldenFibsSys(ISeries<double> input , int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			return indicator.ARC_AutoFibAlgo_ARC_GoldenFibsSys(input, barPeriod, lineDensity, confluenceZone, threshold, lookBackMinute);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_AutoFibAlgo_ARC_GoldenFibsSys ARC_AutoFibAlgo_ARC_GoldenFibsSys(int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			return indicator.ARC_AutoFibAlgo_ARC_GoldenFibsSys(Input, barPeriod, lineDensity, confluenceZone, threshold, lookBackMinute);
		}

		public Indicators.ARC.ARC_AutoFibAlgo_ARC_GoldenFibsSys ARC_AutoFibAlgo_ARC_GoldenFibsSys(ISeries<double> input , int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			return indicator.ARC_AutoFibAlgo_ARC_GoldenFibsSys(input, barPeriod, lineDensity, confluenceZone, threshold, lookBackMinute);
		}
	}
}

#endregion
