//#define FREE_TRIAL_VERSION
#define DoLicense
#define MODERATORS
//#define HTO_LTO
#define DETERMINE_DISQUALIFIED_ARBZONES
//#define SHOW_TERMINATED_RAYS


#region Using declarations
using System;
//using System.Diagnostics;
//using System.Drawing;
//using System.Drawing.Drawing2D;
using System.ComponentModel;
using System.Xml.Serialization;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using SharpDX.DirectWrite;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Windows.Media;
using System.Linq;
using System.Windows.Controls;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	//======================================================    Extension method - make a kvp by kvp copy of a SortedDictionary
	public static class KeyValuePairEnumerableExtensions
	{
	    public static SortedDictionary<TKey, TValue> 
		ToSortedDictionary<TKey, TValue>(this IEnumerable<KeyValuePair<TKey, TValue>> l){
			#region --
	        SortedDictionary<TKey, TValue> result = new SortedDictionary<TKey, TValue>();
	        foreach (var e in l) 
	            result[e.Key] = e.Value;
	        return result;
			#endregion
	    }
	}
	//======================================================
    [CategoryOrder("Parameters", 10)]
    [CategoryOrder("Zones Settings", 20)]
    [CategoryOrder("Visuals - TPO", 30)]
    [CategoryOrder("Visuals - VolumeProfile", 40)]
    [CategoryOrder("Visuals", 50)]
    [CategoryOrder("TPO Touch Counter", 60)]
    [CategoryOrder("CurSess Global Visuals", 70)]
    [CategoryOrder("Hist Global Visuals", 80)]
    [CategoryOrder("Split/Merge Settings", 90)]
	[CategoryOrder("Alerts", 100)]
	[CategoryOrder("ATR Delta Box Visual", 110)]
	public class ARC_MacroProfiles : Indicator
	{
		static int EXAMINE_THIS_PROFILE = 0;
		static int line             = 50;
		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId       = string.Empty;
		private string MachineId    = string.Empty;
		private bool IsGeoffZimmerman = false;
		string ModuleName = "MacroProfiles";
		string inst = string.Empty;

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "9177","25900", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion


		//v2.2 Nov 8 - added InstrumentName to zone alert email subject lines
		//v2.2 Nov 12 - added LVN global zones, added HVN/LVN Significance and RegionSize to pulldown
		//v2.2 Nov 13 - added MinSplit depth to pulldown, added "Show VAH" and "Show VAL" on/off filter to dropdown
		//v2.2 Dec 2  - fixed wandering global rays issue, fixed LVN globals being recreated every new TPO, even though the "Clear Globals" button had removed them
		//Starting 2020
		//v2.3 Feb 5  - attempted fix of poor profile splits occuring on chart refresh.
		//v2.4 Mar 29 - added new options for Sensitivity.  Minute1, Minute2, Minute3, Minute4, Minute5
		//v2.5 June 17 - added Show/Hide Current Profile LVN and Show/Hide Historical Profile LVN
		//				FIXED "public void Calc_HVN_LVN()" calculation issue on M2K contracts which had prices with zero volume
		//v2.6 Aug 2020 - fixed profile splits problem...Close price of split  profiles were not getting set correctly, leading to miscalculation of SplitAssistPrice
		//v2.7 Aug 2020 - fixed "RMB" miscalculation...it used to be "Bars.Count", now, it's BarsArray[0].Count
		//v2.8 Aug 2020 - Added HVN global zones
		//v2.8.1 Oct 2020 - Fixed volume profile was not calculating correctly on the last bar of the session.  The last 1-minute bar of volume was being assigned to the 1st bar of next profile
		//v2.8.2 Aug 2022 - bug fixed Aug 2022, v2.8.2...added "CurrentBars[0]>1" since Range()[1] causing error  (line 6492)
		private const string VERSION = "2.8.2 23.Aug.2022";
		[Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
		public string indicatorVersion { get { return VERSION; } }
		public override string DisplayName { get { return "ARC_MacroProfiles"; } }

		private const int V_ID   = 0;//VolumeProfile identifier
		private const int TPO_ID = 1;//TPO identifier
		private const int POC_ID = 3;//POC identifier
		private const int RES_ID = 0;
		private const int SUP_ID = 1;
		private const char END_OF_PROFILE_FLAG = '~';//the last 2 TPO slices of a profile are flagged as the "END_OF_PROFILE_FLAG".  They are not selectable by the user for splitting.  To split the last 2 TPO slices off into a separate profile would cause a partial profile (profiles must have at least 3 TPO slices in them
		#region -- Variables ---------------------------------------------------------------
		double priceBoxSizeInPrice = 0;
		int RMB = 0;
		SharpDX.Direct2D1.Brush vpVA_BrushDX=null;
		SharpDX.Direct2D1.Brush vpAboveVA_BrushDX=null;
		SharpDX.Direct2D1.Brush vpBelowVA_BrushDX=null;
		SharpDX.Direct2D1.Brush tpoVA_BrushDX=null;
		SharpDX.Direct2D1.Brush tpoAboveVA_BrushDX=null;
		SharpDX.Direct2D1.Brush tpoBelowVA_BrushDX=null;
		SharpDX.Direct2D1.Brush DisqBrushDX=null, SupBrushDX=null, OverlapBrushDX=null;
		SharpDX.Direct2D1.Brush SupTestedBrushDX=null, SupTestedStrokeBrushDX=null, SupStrokeBrushDX=null;
		SharpDX.Direct2D1.Brush SupBrokenBrushDX=null, SupBrokenStrokeBrushDX=null;
		SharpDX.Direct2D1.Brush ResBrushDX=null;
		SharpDX.Direct2D1.Brush ResTestedBrushDX=null, ResTestedStrokeBrushDX=null, ResStrokeBrushDX=null;
		SharpDX.Direct2D1.Brush ResBrokenBrushDX=null, ResBrokenStrokeBrushDX=null;
		SharpDX.Direct2D1.Brush SplitAssistMarkerBrushDX=null, SplitMarkerOutlineBrushDX=null;
		SharpDX.Direct2D1.Brush tpoVerticalBarBrushDX=null, vpVerticalBarBrushDX=null;
		SharpDX.Direct2D1.Brush yellowBrushDX=null, pinkBrushDX=null, magentaBrushDX=null, merge_warning_BrushDX=null;
		SharpDX.Direct2D1.Brush	tpoSinglePrintLine_BrushDX=null, tpoPOC_BrushDX=null, vpPOC_BrushDX=null, TPOCounterFont_BrushDX=null, TPOCounterFont_BkgBrushDX=null;
		SharpDX.Direct2D1.Brush	backBrushDX=null, boxTextBrushDX=null, borderBrushDX=null, whiteBrushDX=null, blackBrushDX=null;
		SharpDX.Direct2D1.Brush OpenMarkerBrushDX=null, UpCloseMarkerBrushDX=null, DownCloseMarkerBrushDX=null, SessionBreak_BrushDX=null;
		SharpDX.Direct2D1.Brush HVN_BrushDX=null, LVN_BrushDX=null;
#if HTO_LTO
		SharpDX.Direct2D1.Brush HTO_BrushDX=null, LTO_BrushDX=null;
#endif

		DateTime KeyDate=DateTime.MinValue;
		bool Initialized = false;
		DateTime currentSessionDate = DateTime.MinValue;
		DateTime Current_Session_Date = DateTime.MinValue;
		double	VWAP_CumVol			= 0;
		double	VWAP_TypiCumVol	= 0;
		double CurrentVWAP = 0;
		int StateOfZoneCalculation = 0;
		bool IsDebug = false;


		private SessionIterator sessionIterator0;
		#endregion
		int MAX_CURRENT_BAR = int.MaxValue;
		bool RealtimeStateFinished = false;
		private bool PermitZoneBreaksOnCurrentSession = true;//false;//set to true if arb zones are to persist on current session regardless of price touches/breaks

		#region -- ArbZone class ----------------------
		private class ArbZone {
			public char    Type           = ' ';
			public char    Disposition    = 'F';//fresh initially
			public int     EndABar        = int.MaxValue;
			public double  HighPrice      = 0;
			public double  LowPrice       = 0;
			public float[] ScreenXYWH     = new float[4]{0,0,0,0};
			public bool    Tested         = false;
			public bool    Broken	      = false;
			public int     BrokenABar     = int.MaxValue;
			public bool    Overlapped     = false;//whenever a zone runs into a value area, that zone is Overlapped - this is determine every end of session
			public int     OverlappedABar = int.MaxValue;
			public bool    Disqualified   = false;
			public DateTime TestedDate    = new DateTime();
			public bool IsTested(double High, double Low){
				if     (Type=='R' && High >= this.LowPrice) {return true;}
				else if(Type=='S' && Low <= this.HighPrice) {return true;}
				return false;
			}
			public bool IsBroken(double High, double Low){
				if     (Type=='R' && High >= this.HighPrice) {return true;}
				else if(Type=='S' && Low <= this.LowPrice) {return true;}
				return false;
			}
			public ArbZone(char type, double highPrice, double lowPrice){Type=type; HighPrice=highPrice; LowPrice=lowPrice;}
		}
		#endregion ----------------------------
		#region -- DevelopingData class ----------------------
		private class DevelopingData{
			public float VAH;
			public float VAL;
			public float POC;
			public DevelopingData(double vah, double val, double poc){VAH=Convert.ToSingle(vah); VAL=Convert.ToSingle(val); POC=Convert.ToSingle(poc);}
			public DevelopingData(float vah, float val, float poc){VAH=vah; VAL=val; POC=poc;}
			public void Update(double vah, double val, double poc){VAH=Convert.ToSingle(vah); VAL=Convert.ToSingle(val); POC=Convert.ToSingle(poc);}
			public void Update(float vah, float val, float poc){VAH=vah; VAL=val; POC=poc;}
		}
		#endregion ---------------------
		#region -- ProfileData class ----------------------
		private class ProfileData{
			#region ProfileData properties
			public DateTime SessionDate = DateTime.MinValue;
			public int      StartABar  = -1;
			public DateTime StartTime  = DateTime.MaxValue;
			public int      EndABar    = -1;
			public DateTime EndTime    = DateTime.MaxValue;
			public double    OpenPrice  = 0;
			public double    ClosePrice = 0;
			public SortedDictionary<double,float>        VatP             = new SortedDictionary<double,float>();
			public SortedDictionary<double,float>        ConsolidatedVatP = new SortedDictionary<double,float>();
			public SortedDictionary<double,List<char>>   TPOatP           = new SortedDictionary<double,List<char>>();
			public DateTime FirstSplitableBarDataKey = DateTime.MinValue;
//			public SortedDictionary<double,List<char>>   ConsolidatedTPOatP = new SortedDictionary<double,List<char>>();
			public SortedDictionary<int, DevelopingData> VP_DevData  = new SortedDictionary<int,DevelopingData>();//abar is key, developing data for each absolute bar
			public SortedDictionary<int, DevelopingData> TPO_DevData = new SortedDictionary<int,DevelopingData>();//abar is key, developing data for each absolute bar
			public List<double> BrokenVolNodes = new List<double>();//list of prices of HVN's and LVN's that have been broken by price action...these HVN's and LVN's will NOT be permitted to be drawn as EXTENDED lines
			public List<double> HVN = new List<double>();
			public List<double> LVN = new List<double>();
#if HTO_LTO
			public List<double> HTO = new List<double>();
			public List<double> LTO = new List<double>();
#endif

			public double vpPOC_Volume = double.MinValue;
			public double vpPOC_Price  = double.MinValue;
			public double vpVAH_Price  = double.MinValue;
			public double vpVAL_Price  = double.MinValue;
			public double ConsolidatedvpPOC_Price  = 0;
			public double ConsolidatedvpPOC_Volume = 0;

			public float  tpoPOC_Volume = float.MinValue;
			public double tpoPOC_Price  = double.MinValue;
			public double tpoVAH_Price  = double.MinValue;
			public double tpoVAL_Price  = double.MinValue;
//			public double ConsolidatedtpoPOC_Price  = 0;
//			public double ConsolidatedtpoPOC_Volume = 0;

			public double  Highest_Price    = double.MinValue;
			public double  Lowest_Price     = double.MaxValue;
			public double  SplitAssistPrice = double.MinValue;
			public float[] SplitAssistMarker_ScreenXYWH = new float[4]{0,0,0,0};
			public SortedDictionary<double,float>  ScreenXY_TpoEdge  = new SortedDictionary<double,float>();//key is the price level, value is the X location (screen coord) of tpo right-edge, to help select split price
			public bool   IsSingularDistribution = false;
			public double StaticVWAP_Price = double.MinValue;
			public float  ticksizef     = 0f;
			public float  halfticksizef = 0f;
			public double ticksize = 0;
//			public double halfticksize = 0;
			public SortedDictionary<int,ArbZone> Zones  = new SortedDictionary<int,ArbZone>();
			//public int UnbrokenZonesCount = 0;
			private SortedDictionary<int,int> tpo_histo = new SortedDictionary<int,int>();
			private SortedDictionary<int,long> vp_histo = new SortedDictionary<int,long>();
			#endregion
			//-------------------------------------------------------------------------------------------------------------------------
			public ProfileData(DateTime sessionDate, int startABar, DateTime startTime, int[] zone_ids, double TickSize){
				SessionDate = sessionDate.Date;
				StartABar   = startABar;
				StartTime   = startTime;
				ticksize = TickSize;
//				halfticksize = ticksize/2.0;
				ticksizef = Convert.ToSingle(TickSize.ToString());
				halfticksizef = ticksizef/2f;
				//UnbrokenZonesCount = zone_ids.Length;
				for(int i = 0; i<zone_ids.Length; i++) Zones[zone_ids[i]] = new ArbZone(zone_ids[i]==SUP_ID?'S':'R',double.MinValue,double.MaxValue);
			}
			private float  RoundToTick (float p)                  { int t=(int)Math.Truncate(p/ticksizef); return t*ticksizef;}
			private double RoundToTick (float p, double ticksize) { int t=(int)Math.Truncate(p/ticksizef); return t*ticksize;}
			private double RoundToTick (double p, double ticksize){ int t=(int)Math.Truncate(p/ticksize); return t*ticksize;}
			private double RoundToTick (double p)                 { int t=(int)Math.Truncate(p/ticksize); return t*ticksize;}
			private float  RoundToTick (float p, float addit)     { int t=(int)Math.Truncate((p+addit)/ticksizef); return t*ticksizef;}
			private int    RoundToInt  (float p)                  { int t=(int)Math.Truncate(p/ticksizef); return t;}
			private int    RoundToInt  (double p)                 { int t=(int)Math.Truncate(p/ticksizef); return t;}
			//-------------------------------------------------------------------------------------------------------------------------
			public void ClearAllDictionaries(){
				TPOatP.Clear();
				ConsolidatedVatP.Clear();
				tpo_histo.Clear();
				vp_histo.Clear();
			}
			//-------------------------------------------------------------------------------------------------------------------------
			public void Calc_CurrentSplitAssistPrice(int MinSplitDepth, NinjaTrader.NinjaScript.IndicatorBase parent){
				//method sets IsSingularDistribution to 'false' if the profile contains 2 or more distributions
				//or 'true' if this is a singular distribution
line=990;
				#region Calc_CurrentSplitAssistPrice
				MinSplitDepth = MinSplitDepth-1;
				var ptrs = this.TPOatP.Keys.ToList();
				if(ptrs==null || ptrs.Count<1) {
					return;
				}
line=997;
				int    CurrentCandidateLetterCount = 0;
				double CurrentCandidatePrice       = ptrs[0];
				bool   NearsideQualified           = false;
				if(ptrs.Count<=2) {
					SplitAssistPrice = double.MinValue;
					return;
				}
line=1005;
				if(this.OpenPrice < this.ClosePrice){
					if(ptrs[0]>ptrs[1]) ptrs.Reverse();
				}else{
line=1009;
					if(ptrs[0]<ptrs[1]) ptrs.Reverse();
				}
try{
				bool SplitAssistPriceFound = false;
				int i = 1;
				int MaxDepth = 0;
line=1016;
				for(i = 1; i<ptrs.Count-2; i++){
					MaxDepth = Math.Max(MaxDepth, TPOatP[ptrs[i]].Count);
					if(!NearsideQualified && TPOatP[ptrs[i]].Count > MinSplitDepth && TPOatP[ptrs[i]].Count > 3) {
						NearsideQualified = true;
						CurrentCandidatePrice = ptrs[i];
						CurrentCandidateLetterCount = TPOatP[CurrentCandidatePrice].Count;
						continue;
					}
line=1025;
					if(NearsideQualified){
						if(TPOatP[ptrs[i]].Count > CurrentCandidateLetterCount){
							CurrentCandidatePrice = ptrs[i];
							CurrentCandidateLetterCount = TPOatP[CurrentCandidatePrice].Count;
						}else if(TPOatP[ptrs[i]].Count < CurrentCandidateLetterCount - MinSplitDepth){
							SplitAssistPrice = CurrentCandidatePrice;
							SplitAssistPriceFound = true;
							break;
						}
					}
				}
line=1037;

				NearsideQualified             = false;
				double PriceOf2ndDistribution = double.MinValue;
				while(i<ptrs.Count-1) {
					if(TPOatP[ptrs[i]].Count < CurrentCandidateLetterCount) 
						CurrentCandidateLetterCount = TPOatP[ptrs[i]].Count;
					if(TPOatP[ptrs[i]].Count > CurrentCandidateLetterCount+MinSplitDepth) {
						PriceOf2ndDistribution = ptrs[i];
						break;
					}
					i++;
				}
line=1050;
				if(PriceOf2ndDistribution == double.MinValue)       this.IsSingularDistribution = true;//no secondary distributions found
				else if(PriceOf2ndDistribution == SplitAssistPrice) this.IsSingularDistribution = true;//no secondary distributions found
				else if(MaxDepth <= MinSplitDepth+1)                this.IsSingularDistribution = true;//no secondary distributions found
				else if(SplitAssistPrice == double.MinValue)        this.IsSingularDistribution = true;//no primary distributions found
				else this.IsSingularDistribution = false;//there was a secondary distribution peak price found, and it's not the SplitAssistPrice

//parent.Print(this.StartTime.ToString()+"   SpAss: "+SplitAssistPrice.ToString()+"  2ndDistPrice: "+PriceOf2ndDistribution.ToString()+"  IsSingular: "+this.IsSingularDistribution.ToString());
}catch(Exception ee){parent.Print(line+": "+ee.ToString());}
				#endregion
			}
			//-------------------------------------------------------------------------------------------------------------------------
			public void Calc_DevelopingTPO(int startABar, DateTime startTime, float ValAreaPct, SortedDictionary<DateTime,TPOBarData> tpo_bars, DateTime CutoffDT, Bars bars, NinjaTrader.NinjaScript.IndicatorBase parent){
				#region Calc_DevelopingTPO
bool inzone= this.StartABar==137;
//parent.Print("Calc_DevelopingTPO  from Line: "+line);
				List<DateTime> D=null;
				if(startABar==this.StartABar){
					D = tpo_bars.Where(x => x.Key > startTime && x.Key.Ticks <= Math.Min(CutoffDT.Ticks, this.EndTime.Ticks)).Select(x => x.Key).ToList();
					TPO_DevData.Clear();
					tpo_histo.Clear();
				}else{
					D = tpo_bars.Where(x => x.Key > startTime).Select(x => x.Key).ToList();
				}

				int ptr = 0;
				int MaxPtrOfDevProfile = int.MinValue;
				int MinPtrOfDevProfile = int.MaxValue;
				foreach(DateTime bartime in D){
					startABar = bars.GetBar(bartime);
					ptr = RoundToInt(tpo_bars[bartime].H);
					MaxPtrOfDevProfile = Math.Max(ptr, MaxPtrOfDevProfile);
					while(ptr >= RoundToInt(tpo_bars[bartime].L)){// - halfticksizef)){
						if(tpo_histo.ContainsKey(ptr)) tpo_histo[ptr] += 1;
						else tpo_histo[ptr] = 1;
						ptr -= 1;
					}
					MinPtrOfDevProfile = Math.Min(ptr+1, MinPtrOfDevProfile);
					//find POC in TPO dictionary
					int total_vol  = tpo_histo.Values.Sum();
					int poc_volume = tpo_histo.Values.Max();
					var poc_prices = (from xx in tpo_histo where xx.Value==poc_volume select xx.Key).ToList();
					float dev_POC_price = 0f;
					if(poc_prices.Count>1){
						if(this.OpenPrice > this.ClosePrice) dev_POC_price = poc_prices.Min()*ticksizef;
						else dev_POC_price = poc_prices.Max()*ticksizef;
					}else if(poc_prices.Count==1)
						dev_POC_price = poc_prices[0]*ticksizef;
					float vol_in_VA = poc_volume;
					int ptrUp   = RoundToInt(dev_POC_price) + 1;
					int ptrDn   = RoundToInt(dev_POC_price) - 1;
					int dev_VAH = ptrUp;
					int dev_VAL = ptrUp;

					float tgt_vol = ValAreaPct * total_vol;
					while(vol_in_VA < tgt_vol){
						bool c1 = tpo_histo.ContainsKey(ptrUp);
						bool c2 = tpo_histo.ContainsKey(ptrDn);
						if(ptrUp > MaxPtrOfDevProfile && ptrDn < MinPtrOfDevProfile) {
							//parent.Print("StartABar: "+StartABar+" @ "+StartTime.ToString()+":    No value area can be found:   volInVA: "+vol_in_VA+"  ValAreaPct: "+ValAreaPct+"  total_vol: "+total_vol); 
							break;
						}
						if(c1) {
							vol_in_VA += tpo_histo[ptrUp];
							dev_VAH    = ptrUp;
						}
						ptrUp += 1;
						if(c2 && vol_in_VA < ValAreaPct * total_vol) {
							vol_in_VA += tpo_histo[ptrDn];
							dev_VAL    = ptrDn;
						}
						ptrDn -= 1;
					}
					this.TPO_DevData[startABar] = new DevelopingData(RoundToTick(dev_VAH*ticksizef), RoundToTick(dev_VAL*ticksizef), dev_POC_price);
					this.tpoPOC_Price  = RoundToTick(TPO_DevData[startABar].POC, ticksize);
					this.tpoPOC_Volume = poc_volume;
					this.tpoVAH_Price  = RoundToTick(TPO_DevData[startABar].VAH,ticksize);
					this.tpoVAL_Price  = RoundToTick(TPO_DevData[startABar].VAL,ticksize);
//if(this.StartABar==137) parent.Print("      Calc_DevelopingTPO:   "+this.StartABar+"   tpoVAH: "+this.tpoVAH_Price+"   VAL: "+this.tpoVAL_Price);
				}
				#endregion
			}
			//-------------------------------------------------------------------------------------------------------------------------
			public void Calc_DevelopingVP(int startABarChart, DateTime startTime, float ValAreaPct, Bars bars_1Min, Bars barsChart, NinjaTrader.NinjaScript.IndicatorBase parent){
				#region -- Calc_DevelopingVP ---------------------------------------------------------
				int startABar_1Min = bars_1Min.GetBar(startTime)+1;
				int endABar_1Min   = bars_1Min.GetBar(EndTime);
				if(startABarChart == this.StartABar){
					VP_DevData.Clear();
					vp_histo.Clear();
					this.Highest_Price = double.MinValue;
					this.Lowest_Price  = double.MaxValue;
				}
//parent.Print("CalcDeveloping   startime: "+startTime.ToString()+"  startABarChart: "+startABarChart);
//List<DateTime> keys = BarData.Keys.Where(x => x > startDT && x.Ticks <= Math.Min(CutoffDT.Ticks, endDT.Ticks)).ToList();

				int MaxPtrOfDevProfile = int.MinValue;
				int MinPtrOfDevProfile = int.MaxValue;
				int ptr     = 0;
				int dev_VAH = 0;
				int dev_VAL = 0;
				float dev_POC_price = 0f;
				float poc_volume    = 0f;
				DateTime t;
//parent.Print("Start at: "+this.StartTime.ToString());
				for(int abar = startABar_1Min; abar<=Math.Min(bars_1Min.Count-1,endABar_1Min); abar++){
					t = bars_1Min.GetTime(abar);
					startABarChart = barsChart.GetBar(t);
//bool inzone = this.StartABar==116;
					double H = bars_1Min.GetHigh(abar);
					double L = bars_1Min.GetLow(abar);
//if(inzone) parent.Print("     bar time: "+t.ToString()+"  h/l/c: "+H+" "+L+" "+bars_1Min.GetClose(abar).ToString());
					Highest_Price = Math.Max(Highest_Price,H);
					Lowest_Price = Math.Min(Lowest_Price,L);
					double range = H-L;
					long v_per_tick = range==0 ? bars_1Min.GetVolume(abar) : Convert.ToInt64(bars_1Min.GetVolume(abar) / (1+(H-L) / ticksizef));
					ptr = RoundToInt(H);
					MaxPtrOfDevProfile = Math.Max(ptr, MaxPtrOfDevProfile);
					while(ptr>=RoundToInt(L - halfticksizef)){
						if(vp_histo.ContainsKey(ptr)) vp_histo[ptr] = vp_histo[ptr] + v_per_tick;
						else vp_histo[ptr] = v_per_tick;
						ptr -= 1;
					}
					MinPtrOfDevProfile = Math.Min(ptr+1, MinPtrOfDevProfile);
					if(vp_histo.Values.Count==0) continue;
					//find POC in VP dictionary
					float total_vol  = vp_histo.Values.Sum();
					poc_volume = vp_histo.Values.Max();
					var poc_prices = (from x in vp_histo where x.Value==poc_volume select x.Key).ToList();
					dev_POC_price = 0f;
					if(poc_prices.Count>1){
						if(this.OpenPrice > this.ClosePrice) dev_POC_price = Convert.ToSingle(poc_prices.Min())*ticksizef;
						else dev_POC_price = Convert.ToSingle(poc_prices.Max())*ticksizef;
					}else if(poc_prices.Count==1)
						dev_POC_price = Convert.ToSingle(poc_prices[0])*ticksizef;
//if(inzone) parent.Print(" ----------------------dev_POC_price: "+dev_POC_price);

					float vol_in_VA = poc_volume;
					int ptrUp   = RoundToInt(dev_POC_price) + 1;
					int ptrDn   = RoundToInt(dev_POC_price) - 1;
					dev_VAH = ptrUp;
					dev_VAL = ptrUp;
					double VAtargetVolume = ValAreaPct * total_vol;
//					int it=0;
					bool c1=true;
					bool c2=true;
					while(vol_in_VA < VAtargetVolume){
						c1 = vp_histo.ContainsKey(ptrUp);
						c2 = vp_histo.ContainsKey(ptrDn);
						if(ptrUp > MaxPtrOfDevProfile && ptrDn < MinPtrOfDevProfile) {
//if(inzone) parent.Print("tgt: "+VAtargetVolume.ToString("0")+"  cur vol: "+vol_in_VA+"   ptrUp: "+(this.ticksizef*ptrUp).ToString("0.00")+":"+(this.ticksizef*ptrDn).ToString("0.00")+"   iteration: "+it);it++;
//if(inzone) parent.Print("\n\n<<<<<<<<<<<<<<<  No value area can be found  >>>>>>>>>>>>>>>\n\n\n\n\n"); 
							break;
						}
						if(c1) {
							vol_in_VA += vp_histo[ptrUp];
							dev_VAH    = ptrUp;
						}
						ptrUp += 1;
						if(c2 && vol_in_VA < VAtargetVolume) {
							vol_in_VA += vp_histo[ptrDn];
							dev_VAL    = ptrDn;
						}
						ptrDn -= 1;
					}
//					if(!VP_DevData.ContainsKey(startABarChart))
						this.VP_DevData[startABarChart] = new DevelopingData(RoundToTick(dev_VAH*ticksizef), RoundToTick(dev_VAL*ticksizef), dev_POC_price);
//					else{
//						VP_DevData[startABarChart].VAH = RoundToTick(dev_VAH*ticksizef);
//						VP_DevData[startABarChart].VAL = RoundToTick(dev_VAL*ticksizef);
//						VP_DevData[startABarChart].POC = dev_POC_price;
//					}

					this.vpPOC_Price  = RoundToTick(dev_POC_price,ticksize);
					this.vpPOC_Volume = poc_volume;
//if(inzone) parent.Print("vpPOC Price: "+vpPOC_Price+"  POC : "+VP_DevData[startABarChart].POC);
					this.vpVAH_Price  = RoundToTick(VP_DevData[startABarChart].VAH,ticksize);
					this.vpVAL_Price  = RoundToTick(VP_DevData[startABarChart].VAL,ticksize);
				}
				VatP.Clear();
				foreach(int k in vp_histo.Keys) VatP[k*this.ticksize] = vp_histo[k];
				#endregion
			}
			//-------------------------------------------------------------------------------------------------------------------------
			public void Calc_ConsolidatedVP(int TicksPerHistoBar, double TickSize){
				if(TicksPerHistoBar==1){
					ConsolidatedVatP         = VatP;
					ConsolidatedvpPOC_Volume = vpPOC_Volume;
					ConsolidatedvpPOC_Price  = vpPOC_Price;
				}else{
					#region Consolidate the prior day vol at price dictionary into priceBoxSized histo areas
					//If the user wants each price level to be 3-ticks wide, then we consolidate the single tick volume into 3-tick wide regions of volume
//		double TotalVolume = 0;
//		double TotalTPOVolume = 0;
//		double MaxTPOVolume = 0;
//		double PriceOfMaxTPOVolume = 0;
					double MaxVolume        = 0;
					double PriceOfMaxVolume = 0;
					int count = 0;
					double consolidated_volumeVP = 0;
					double L  = 0;
					int Lint = 0;
					ConsolidatedVatP.Clear();
					vp_histo.Clear();
					foreach(KeyValuePair<double,float> kvp2 in VatP){//key is the price level, value is the volume at that price level
						count++;
						L = kvp2.Key;
						Lint = RoundToInt(L);
						consolidated_volumeVP  += VatP[L];
						if(count % TicksPerHistoBar == 0){
							if(consolidated_volumeVP > 0)
								if(!ConsolidatedVatP.ContainsKey(L)) {
									ConsolidatedVatP[L] = 0f;
									vp_histo[Lint] = 0;//this dictionary is useful for HVN/LVN calculation...integer prices and long volumes
								}
							if(consolidated_volumeVP > 0){
								ConsolidatedVatP[L] = Convert.ToSingle(consolidated_volumeVP);
								vp_histo[Lint] = Convert.ToInt64(consolidated_volumeVP);
							}
							if(consolidated_volumeVP > MaxVolume){
								MaxVolume        = consolidated_volumeVP;
								PriceOfMaxVolume = L;
							}
							consolidated_volumeVP = 0;
						}
					}
					bool c1 = consolidated_volumeVP>0;
					double ptr = RoundToTick(L - count*TickSize, TickSize);
					if(c1){//leftover volume, put it into the topmost histo bar
						ConsolidatedVatP[ptr]  = Convert.ToSingle(consolidated_volumeVP);
						vp_histo[RoundToInt(ptr)] = Convert.ToInt64(consolidated_volumeVP);
//PrintNew1("Added remainder vol "+consolidated_volume.ToString("0")+" at "+RoundToTick(L - count*TickSize).ToString());
					}
					ConsolidatedvpPOC_Price   = PriceOfMaxVolume;
					ConsolidatedvpPOC_Volume  = MaxVolume;
//foreach(double p in ConsolidatedVatP.Keys) PrintNew1("    "+p+"  "+ConsolidatedVatP[p].ToString("0"));
					#endregion
				}
			}
			//-------------------------------------------------------------------------------------------------------------------------
			public void Calc_ArbZones(double NextProfileOpenPrice, bool ResetUnbrokenZonesCount, bool ResetZonesToStart){
				#region -- Calculate Arb Zones (diff between TPO and VP VAH's and between TPO and VP VAL's) ----
				if(vpVAH_Price > tpoVAL_Price && vpVAL_Price < tpoVAH_Price){//if the zones are not touching/overlapping each other, they are disjoint...no arb zones when VA's are disjoint
					double HP = Math.Max(tpoVAH_Price, vpVAH_Price);
					double LP = Math.Min(tpoVAH_Price, vpVAH_Price);
					if(HP!=LP && HP!=double.MaxValue && HP!=double.MinValue){
						if(ResetZonesToStart || !Zones.ContainsKey(RES_ID)) Zones[RES_ID]=new ArbZone('R',HP,LP);
						Zones[RES_ID].HighPrice = HP;
						Zones[RES_ID].LowPrice  = LP;
						//Zones[RES_ID].Disqualified = NextProfileOpenPrice > HP;
					}else if(Zones.ContainsKey(RES_ID)) Zones.Remove(RES_ID);

					HP = Math.Max(tpoVAL_Price, vpVAL_Price);
					LP = Math.Min(tpoVAL_Price, vpVAL_Price);
					if(HP!=LP && HP!=double.MaxValue && HP!=double.MinValue){
						if(ResetZonesToStart || !Zones.ContainsKey(SUP_ID)) Zones[SUP_ID]=new ArbZone('S',HP,LP);
						Zones[SUP_ID].HighPrice = HP;
						Zones[SUP_ID].LowPrice  = LP;
						//Zones[SUP_ID].Disqualified = NextProfileOpenPrice < LP;
					}else if(Zones.ContainsKey(SUP_ID)) Zones.Remove(SUP_ID);
				}else {
					if(Zones.ContainsKey(RES_ID)) Zones.Remove(RES_ID);
					if(Zones.ContainsKey(SUP_ID)) Zones.Remove(SUP_ID);
				}
				//if(ResetUnbrokenZonesCount) this.UnbrokenZonesCount = Zones.Count;
				#endregion -----------------
			}
			//-------------------------------------------------------------------------------------------------------------------------
				#region -- private GetPeakVolumeAtPrice -----------------------------------------------------------------------------
				private float GetPeakVolumeAtPrice(int step, ref int offset, int limit, SortedDictionary<int,float> prof){
					offset = offset+step;
					while(!prof.ContainsKey(offset)) {
						if(step>0 && offset>limit)      return 0;//float.MinValue;
						else if(step<0 && offset<limit) return 0;//float.MinValue;
						offset = offset+step;
					}
					if(prof.ContainsKey(offset)) {
						return prof[offset];
					}

					return float.MinValue;
				}
				private int GetPeakVolumeAtPrice(int step, ref int offset, int limit, SortedDictionary<double,List<char>> prof){
					offset = offset+step;
					double price = offset * ticksize;
					while(!prof.ContainsKey(price)) {
						if(step>0 && offset>limit)      return 0;//int.MinValue;
						else if(step<0 && offset<limit) return 0;//int.MinValue;
						offset = offset+step;
						price = offset * ticksize;
					}
					if(prof.ContainsKey(price)) return prof[price].Count;
					return int.MinValue;
				}
				#endregion
			//-------------------------------------------------------------------------------------------------------------------------
#if HTO_LTO
			public void Calc_HTO_LTO(int Significance_HTO_LTO, bool HighlightFullRegion){
				#region -- Calc_HTO_LTO -----------------------------------------------------------------------------
				if(TPOatP==null || TPOatP.Count<=0) return;
				HTO.Clear();
				var MAX_PriceInt = RoundToInt(TPOatP.Keys.Max());
				var MIN_PriceInt = RoundToInt(TPOatP.Keys.Min());
				var HVNvols = TPOatP.OrderByDescending(x => x.Value.Count).ToList();
//bool inzone = this.StartTime.Day==14 && this.StartTime.Hour>=16;
//if(inzone){
//	parent.Print(" -----------------------------------------");
//	foreach(var xk in HVNvols) parent.Print(xk.Value.Count+"   "+xk.Key);
//}
				long volume_above = 0;
				long volume_below = 0;
				long prior_vol_above = 0;
				long prior_vol_below = 0;
				foreach(var ptrs in HVNvols){
//inzone = ptrs.Key==2834.5;
					var Uptr = RoundToInt(ptrs.Key);
					var Dptr = Uptr;
					prior_vol_above = ptrs.Value.Count;
					prior_vol_below = ptrs.Value.Count;
					volume_above = ptrs.Value.Count;
					volume_below = ptrs.Value.Count;
					bool done=false;
					while(!done && volume_above == ptrs.Value.Count){
						volume_above = GetPeakVolumeAtPrice(1,  ref Uptr, MAX_PriceInt, TPOatP);	if(volume_above<0 || volume_above > prior_vol_above) done=true;
					}
					while(!done && volume_below == ptrs.Value.Count){
						volume_below = GetPeakVolumeAtPrice(-1, ref Dptr, MIN_PriceInt, TPOatP);	if(volume_below<0 || volume_below > prior_vol_below) done=true;
					}
					if(done) continue;
					int iteration = 0;
					while(prior_vol_above >= volume_above && prior_vol_below >= volume_below){
//						prior_vol_above = volume_above;
//						prior_vol_below = volume_below;
						volume_above = GetPeakVolumeAtPrice(1,  ref Uptr, MAX_PriceInt, TPOatP);	if(volume_above<0) break;
						volume_below = GetPeakVolumeAtPrice(-1, ref Dptr, MIN_PriceInt, TPOatP);	if(volume_below<0) break;
						iteration++;
						if(iteration>=Significance_HTO_LTO) { 
							HTO.Add(ptrs.Key); 
							if(HighlightFullRegion){
								var regionkeys = TPOatP.Keys.Where(rk=> rk < ptrs.Key + Significance_HTO_LTO * ticksize + ticksize/2.0 && rk > ptrs.Key - Significance_HTO_LTO * ticksize - ticksize/2.0).ToList();
								if(regionkeys!=null && regionkeys.Count>0) HTO.Concat(regionkeys);
							}
							break;
						}
					}
				}

				LTO.Clear();
				var LVNvols = TPOatP.OrderBy(x => x.Value.Count).ToList();
				foreach(var ptrs in LVNvols){
					var Uptr = RoundToInt(ptrs.Key);
					var Dptr = Uptr;
					prior_vol_above = ptrs.Value.Count;
					prior_vol_below = ptrs.Value.Count;
					volume_above = ptrs.Value.Count;
					volume_below = ptrs.Value.Count;
					bool done=false;
					while(!done && volume_above == ptrs.Value.Count){
						volume_above = GetPeakVolumeAtPrice(1,  ref Uptr, MAX_PriceInt, TPOatP);	if(volume_above<0 || volume_above < ptrs.Value.Count) done=true;
					}
					while(!done && volume_below == ptrs.Value.Count){
						volume_below = GetPeakVolumeAtPrice(-1, ref Dptr, MIN_PriceInt, TPOatP);	if(volume_below<0 || volume_below < ptrs.Value.Count) done=true;
					}
					if(done) continue;
					int iteration = 0;
					while(prior_vol_above <= volume_above && prior_vol_below <= volume_below){
//						prior_vol_above = volume_above;
//						prior_vol_below = volume_below;
						volume_above = GetPeakVolumeAtPrice(1,  ref Uptr, MAX_PriceInt, TPOatP);	if(volume_above<0) break;
						volume_below = GetPeakVolumeAtPrice(-1, ref Dptr, MIN_PriceInt, TPOatP);	if(volume_below<0) break;
						iteration++;
						if(iteration>=Significance_HTO_LTO) { 
							LTO.Add(ptrs.Key);
							if(HighlightFullRegion){
								var regionkeys = TPOatP.Keys.Where(rk=> rk < ptrs.Key + Significance_HTO_LTO * ticksize + ticksize/2.0 && rk > ptrs.Key - Significance_HTO_LTO * ticksize - ticksize/2.0).ToList();
								if(regionkeys!=null && regionkeys.Count>0) LTO.Concat(regionkeys);
							}
							break;
						}
					}
				}
				#endregion
			}
#endif
			//-------------------------------------------------------------------------------------------------------------------------
			public void Calc_HVN_LVN(int Significance_HVN_LVN, bool HighlightFullRegion, int HighlightRegionSize, int TicksPerHisto, NinjaTrader.NinjaScript.IndicatorBase parent){
				#region -- Calc_HVN_LVN -----------------------------------------------------------------------------
				if(ConsolidatedVatP==null || ConsolidatedVatP.Count<=0) return;
				var histo = new SortedDictionary<int,float>();
				foreach(var kvp in ConsolidatedVatP) histo[(int)Math.Round(kvp.Key/ticksize,0)]=kvp.Value;
//return;
//bool iz = this.StartABar==140;
//if(iz)parent.Print("********************************************************");
//if(iz) foreach(var kvp in histo)parent.Print((kvp.Key*this.ticksize).ToString()+": "+kvp.Value);
				HVN.Clear();
				var MAX_PriceInt = histo.Keys.Max();
				var MIN_PriceInt = histo.Keys.Min();
				var HVNvols = histo.OrderByDescending(x => x.Value).ToList();//highest volumes are at the beginning of this list
//return;
				float volume_above = 0;
				float volume_below = 0;
				float prior_vol_above = 0;
				float prior_vol_below = 0;
				int histo_id = 0;//top of the list of HVNvols
				if(HVNvols!=null) {
//parent.Print(this.StartABar+"   HVNvols.Count: "+HVNvols.Count);
//					foreach(var ptrs in HVNvols){
//parent.Print("     ptrs: "+ptrs.Key+"  "+ptrs.Value);
//					}
					foreach(var ptrs in HVNvols){//start with the highest volume prices first
line=1460;
						if(ptrs.Value<=1) continue;
						int Uptr = ptrs.Key;
						int Dptr = ptrs.Key;
						prior_vol_above = ptrs.Value;
						prior_vol_below = ptrs.Value;
						volume_above = ptrs.Value;
						volume_below = ptrs.Value;
						bool done=false;
line=1469;
						while(!done && volume_above == ptrs.Value){
//parent.Print(1148);
							volume_above = GetPeakVolumeAtPrice(TicksPerHisto,  ref Uptr, MAX_PriceInt, histo);	
//parent.Print(ptrs.Value+"  Vol_above: "+volume_above+"   vol_below: "+volume_below+"   Key: "+this.StartABar);
							if(volume_above<=0 || volume_above > ptrs.Value) done=true;
						}
						while(!done && volume_below == ptrs.Value){
//parent.Print(1155);
							volume_below = GetPeakVolumeAtPrice(-TicksPerHisto, ref Dptr, MIN_PriceInt, histo);	
							if(volume_below<=0 || volume_below > ptrs.Value) done=true;
						}
						if(done) continue;
						int iteration = 0;
line=1483;
						while(prior_vol_above >= volume_above && prior_vol_below >= volume_below){
//							prior_vol_above = volume_above;
//							prior_vol_below = volume_below;
							volume_above = GetPeakVolumeAtPrice(TicksPerHisto,  ref Uptr, MAX_PriceInt, histo);	if(volume_above<0) break;
line=1488;
							volume_below = GetPeakVolumeAtPrice(-TicksPerHisto, ref Dptr, MIN_PriceInt, histo);	if(volume_below<0) break;
							iteration++;
							if(iteration>=Significance_HVN_LVN) {
								HVN.Add(ptrs.Key*ticksize);
								if(HighlightFullRegion && HighlightRegionSize>0){
									var regionkeys = histo.Keys.Where(rk=> rk <= ptrs.Key + HighlightRegionSize && rk >= ptrs.Key - HighlightRegionSize).ToList();
									if(regionkeys!=null && regionkeys.Count>0) {
										foreach(var rkey in regionkeys) HVN.Add(rkey*ticksize);
									}
								}
								break;
							}
						}
					}
				}
				LVN.Clear();
				var LVNvols = histo.OrderBy(x => x.Value).ToList();//lowest volumes are at the beginning of this list
				if(LVNvols!=null) foreach(var ptrs in LVNvols){
					int Uptr = ptrs.Key;
					int Dptr = ptrs.Key;
					prior_vol_above = ptrs.Value;
					prior_vol_below = ptrs.Value;
					volume_above    = ptrs.Value;
					volume_below    = ptrs.Value;
					bool done=false;
					while(!done && volume_above == ptrs.Value){
//parent.Print("1193  "+DateTime.Now.Ticks);
						volume_above = GetPeakVolumeAtPrice(TicksPerHisto,  ref Uptr, MAX_PriceInt, histo);	
						if(volume_above<=0 || volume_above < ptrs.Value) done=true;
					}
					while(!done && volume_below == ptrs.Value){
//parent.Print(1197);
						volume_below = GetPeakVolumeAtPrice(-TicksPerHisto, ref Dptr, MIN_PriceInt, histo);	
						if(volume_below<=0 || volume_below < ptrs.Value) done=true;
					}
					if(done) continue;
					int iteration = 0;
line=1526;
					while(prior_vol_above <= volume_above && prior_vol_below <= volume_below){
//						prior_vol_above = volume_above;
//						prior_vol_below = volume_below;
//parent.Print(12052);
						volume_above = GetPeakVolumeAtPrice(TicksPerHisto,  ref Uptr, MAX_PriceInt, histo);	if(volume_above<0) break;
						volume_below = GetPeakVolumeAtPrice(-TicksPerHisto, ref Dptr, MIN_PriceInt, histo);	if(volume_below<0) break;
						iteration++;
						if(iteration>=Significance_HVN_LVN) {
							LVN.Add(ptrs.Key*ticksize); 
							if(HighlightFullRegion){
								var regionkeys = histo.Keys.Where(rk=> rk <= ptrs.Key + HighlightRegionSize && rk >= ptrs.Key - HighlightRegionSize).ToList();

								if(regionkeys!=null && regionkeys.Count>0) {
									foreach(var rkey in regionkeys) {
										LVN.Add(rkey*ticksize);
									}
								}
							}
							break;
						}
					}
				}
line=1549;
				#endregion
			}
			//-------------------------------------------------------------------------------------------------------------------------
		}
		#endregion ------------------------
		#region -- TPO bars and data manager ------------------------------------
		private class TPOBarData{
			public char Letter;
			public float O;
			public float H;
			public float L;
			public float C;
			public TPOBarData(char letter, float o, float h, float l, float c){Letter=letter; O=o; H=h; L=l; C=c;}
			public TPOBarData(char letter, double o, double h, double l, double c){Letter=letter; O=Convert.ToSingle(o); H=Convert.ToSingle(h); L=Convert.ToSingle(l); C=Convert.ToSingle(c);}
			public void UpdateClose(double h, double l, double c){
				//return new TPOBarData(this.Letter, this.O, Math.Max(this.H,Convert.ToSingle(h)), Math.Min(this.L,Convert.ToSingle(l)), Convert.ToSingle(c));}
					C=Convert.ToSingle(c);  H=Convert.ToSingle(Math.Max(H,h)); L=Convert.ToSingle(Math.Min(L,l));}
			public string ToStr(){return string.Format("Ltr:{0}  o:{1}  h:{2}  l:{3}  c:{4}",Letter,O,H,L,C);}
		}
		private class TPO_DataManager{
			public int             TimeSliceMinutes = 30;
			private int            tpo_bar_id = 0;
			private int            letter_ptr = 0;
			private double         ticksize   = 0;
			private double         halfticksize = 0;
			private List<int>	   profileABars = new List<int>();
			private DateTime       BarDataKey = DateTime.MinValue;
			public List<char>      Letters      = new List<char>(){'A','B','C','D','E','F','G','H','O','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','O','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','0','1','2','3','4','5','6','7','8','9'};
			public SortedDictionary<DateTime,TPOBarData> BarData = new SortedDictionary<DateTime,TPOBarData>();
			//private List<DateTime> TimeSlices = new List<DateTime>();
			public TPO_DataManager(double tick_size, char type, DateTime t0, List<DateTime>SessionDates){
				#region -- Constructor --
				ticksize = tick_size; 
				halfticksize=tick_size/2.0;
				if(type=='D') TimeSliceMinutes = 30;
				if(type=='W') TimeSliceMinutes = 150;
				if(type=='M') TimeSliceMinutes = 660;
				var t = new DateTime(t0.Year,t0.Month,t0.Day,0,0,0);
				BarData[t] = new TPOBarData(Letters[0], float.MinValue, float.MinValue, float.MaxValue, float.MinValue);
				BarDataKey = t;
				int sessPtr = 0;
				int i = 0;
				while(t < DateTime.Now){
					t = t.AddMinutes(TimeSliceMinutes);
					if(t<t0) continue;
					i++;
					if(i>=Letters.Count)i=0;
					if(sessPtr<SessionDates.Count-1 && t > SessionDates[sessPtr]) {
						sessPtr++;
						i = 0;
					}
					BarData[t] = new TPOBarData(Letters[i], float.MinValue, float.MinValue, float.MinValue, float.MinValue);
				}
				#endregion --------------------
			}
			public TPO_DataManager(double tick_size, char type, DateTime TimeOfFirstChartBar, NinjaTrader.NinjaScript.IndicatorBase parent){
				#region -- Constructor --
				ticksize = tick_size; 
				halfticksize=tick_size/2.0;
				var t = new DateTime(2019, 1, 1,0,0,0);
				var final = DateTime.Now.AddDays(2);
				if(type=='D') 
					TimeSliceMinutes = 30;
				if(type=='W') {
					TimeSliceMinutes = 150;
					while(t.DayOfWeek != DayOfWeek.Sunday) t = t.AddDays(1);
					final = DateTime.Now.AddDays(7);
				}
				if(type=='M') {
					TimeSliceMinutes = 660;
					final = DateTime.Now.AddMonths(1);
				}
				TimeOfFirstChartBar = TimeOfFirstChartBar.AddDays(-1);
				while(t < final){
					if(t >= TimeOfFirstChartBar) BarData[t] = new TPOBarData(' ', float.MinValue, float.MinValue, float.MinValue, float.MinValue);
					t = t.AddMinutes(TimeSliceMinutes);
				}
				#endregion --------------------
			}
			private double RoundToTick(double p){		int t = (int)Math.Round(p/ticksize,0);	return t*ticksize;}
			//=================================================================================================
			public void Accumulate(Bars ticks, List<DateTime> SessionDates, NinjaTrader.NinjaScript.IndicatorBase parent){
				var T    = ticks.GetTime(0);
				var keys = BarData.Keys.ToList();
				int sessPtr = 0;
				int ptr     = 0;
				while(keys[ptr] < T) ptr++;
				BarDataKey = keys[ptr];
				letter_ptr = 0;
//foreach(var bu in BarData) if(bu.Key.Month==10 && bu.Key.Day>=26) parent.Print("BarData: "+bu.Key.ToString()+"  "+bu.Value.ToStr());
				while(sessPtr < SessionDates.Count-1 && T > SessionDates[sessPtr]) sessPtr++;
				for(int i = 0; i < ticks.Count; i++){
					T = ticks.GetTime(i);
//bool inzone = T.Day>=26 && T.Month==10;
//if(inzone) parent.Print("\n"+T.ToString());//     +"   O: "+ticks.GetOpen(i).ToString()+"    H: "+ticks.GetHigh(i).ToString()+"   L: "+ticks.GetLow(i).ToString());
					bool NewSession = sessPtr < SessionDates.Count-1 && T > SessionDates[sessPtr];

					if(T > keys[ptr] || NewSession) {
						if(NewSession){
							while(sessPtr < SessionDates.Count-1 && T > SessionDates[sessPtr]) {
								sessPtr++;
//if(inzone) parent.Print(" ----------------------------     New session "+sessPtr+" of "+SessionDates.Count.ToString()+"  "+SessionDates[sessPtr].ToString());
							}
							while(ptr<keys.Count && T > keys[ptr]) {
//if(inzone) parent.Print("1604   "+ptr+"  "+keys.Count+"  T: "+T.ToString()+"   keys[ptr]: "+keys[ptr].ToString());
								ptr++;
							}
							BarDataKey = keys[ptr];
							letter_ptr = 0;
						}else{
							try{
//if(inzone) parent.Print("1611 "+ptr+"  keys.Count: "+keys.Count);
//if(inzone) parent.Print(" ----------------------------     T > keys["+ptr+"].Count: "+keys.Count);
								while(ptr<keys.Count && T > keys[ptr]) {
//if(inzone) parent.Print("1614   "+ptr+"  "+keys.Count+"  T: "+T.ToString()+"   keys[ptr]: "+keys[ptr].ToString());
									ptr++;
								}
								BarDataKey = keys[ptr];
								letter_ptr++;
								if(letter_ptr>= Letters.Count) letter_ptr = 0;
							}catch(Exception eee){parent.Print("err 1620: "+eee.ToString());}
						}
//if(inzone) parent.Print("  new BarDataKey: "+BarDataKey.ToString());
//if(inzone) parent.Print("1623 "+Letters.Count+"  "+letter_ptr+"   ticks.Count: "+ticks.Count+" i: "+i);
						try{
							BarData[BarDataKey] = new TPOBarData(this.Letters[letter_ptr], ticks.GetOpen(i), ticks.GetHigh(i), ticks.GetLow(i), ticks.GetClose(i));
//parent.Print(BarDataKey.ToString()+":   "+ticks.GetTime(i).ToString());
						}catch(Exception eee1){parent.Print("err 1627: "+eee1.ToString());}
//if(inzone)parent.Print("New tpo:  @ "+BarDataKey+"  "+BarData[BarDataKey].ToStr());
					}
					BarData[BarDataKey].UpdateClose(ticks.GetHigh(i), ticks.GetLow(i), ticks.GetClose(i));
//if(inzone)parent.Print("Updated tpo: @ "+BarDataKey+"  "+BarData[BarDataKey].ToStr());
				}
			}
			//=================================================================================================
			public void Accumulate(double O, double H, double L, double C, DateTime T, bool IsNewSession, NinjaTrader.NinjaScript.IndicatorBase parent){
//bool z = (T.Hour>=16 && T.Day==30);
				int count = 0;
//if(z)parent.Print("IsNewSession? "+IsNewSession.ToString());
				while(T > BarData.Keys.Max()){
//if(z)parent.Print("1342: "+T.ToString()+"   BarData.Keys.Max(): "+BarData.Keys.Max().ToString());
					tpo_bar_id = 0;
					BarDataKey = BarData.Keys.Max().AddMinutes(TimeSliceMinutes);
					if(IsNewSession){//when a new session comes along, we must advance BarDataKey further than normal...we must set it to accomodate the start of the new session.
						while(T>BarDataKey) BarDataKey = BarDataKey.AddMinutes(TimeSliceMinutes);
					}
					if(T<BarDataKey){
						if(IsNewSession) {
							letter_ptr = 0;
						}else{
							letter_ptr++;
							if(letter_ptr>= Letters.Count) letter_ptr = 0;
						}
						BarData[BarDataKey] = new TPOBarData(this.Letters[letter_ptr], O, H, L, C);
					}
				}
				BarData[BarDataKey].UpdateClose(H, L, C);
			}
			//=================================================================================================
			public SortedDictionary<double,List<char>> CreateTPOatP(DateTime startDT, DateTime endDT, ref DateTime FirstSplitableBarDataKey, SortedDictionary<DateTime,TPOBarData> BarData, DateTime CutoffDT, NinjaTrader.NinjaScript.IndicatorBase parent, int StartABar, bool IsLiveData){
				#region -- CreateTPOatP ----------------------------------------------------
				var result = new SortedDictionary<double,List<char>>();
//bool inzone = endDT.Month==10 && endDT.Day>=26;
				List<DateTime> keys = BarData.Keys.Where(x => x > startDT && x.Ticks <= Math.Min(CutoffDT.Ticks, endDT.Ticks)).ToList();
				if(keys==null || keys.Count==0)
					FirstSplitableBarDataKey = startDT;
				else{
					FirstSplitableBarDataKey = keys[keys.Count-Math.Min(3,keys.Count)];//see the note about END_OF_PROFILE_FLAG for details of why we have '3' here
					int loc = keys.IndexOf(FirstSplitableBarDataKey);
//if(inzone)	parent.Print(loc+":  StartABar: "+StartABar+"   keys.Count: "+keys.Count+"  keys[0]: "+keys[0].ToString()+" "+BarData[keys[0]].ToStr());
					if(loc<=3) FirstSplitableBarDataKey = keys[0];//this ensures that there are enough TPO slices BEFORE the split TPO slice...so if the profile splits, the left-profile will have 3 (or more) TPO slices in it
				}
				double HH = 0;
				double LL = double.MaxValue;
				foreach(var key in keys){
					var letter = key <= FirstSplitableBarDataKey ? BarData[key].Letter : END_OF_PROFILE_FLAG;
					double p = RoundToTick(BarData[key].H);//must round this to tick...conversion of float to double introduces extra digits
					HH = Math.Max(HH,p);
					while(p >= BarData[key].L - halfticksize) {
						if(!result.ContainsKey(p)) result[p] = new List<char>();
						result[p].Add(letter);
						LL = Math.Min(LL,p);
						p  = RoundToTick(p - ticksize);
					}
				}
//if(false && IsLiveData){
//	parent.Print("----   "+DateTime.Now.ToString()+"   startDT: "+startDT.ToString()+"  startabar: "+StartABar);
//	foreach(var kdt in keys) parent.Print("  "+BarData[kdt].ToStr());
//	var rk = result.Keys.ToList();
//	rk.Reverse();
//	foreach(var kkr in rk) {
//		var rkstr = string.Empty;
//		foreach(var rl in result[kkr]) rkstr = string.Format("{0}{1}",rkstr,rl);
//		parent.Print("  "+parent.Instrument.MasterInstrument.RoundToTickSize(kkr)+": "+rkstr);
//	}
//}
//parent.Print("1116:  Result.Count: "+result.Count);
				return result;
				#endregion
			}
			//=================================================================================================
		}
		TPO_DataManager TPO_Data = null;
		#endregion ------------------
		SortedDictionary<int, ProfileData> Prof         = new SortedDictionary<int, ProfileData>();
		SortedDictionary<int, DateTime>    ProfileDates = new SortedDictionary<int, DateTime>();
		List<int> SessionBreakLocs = new List<int>();//abs bar (chart bar) of session breaks

		#region -- SavedConfigManager -------------------------
		private class SavedConfigManager {
			#region SavedConfigManager
//			public int CurrentViewMode_SelectedIndex = 0;
//			public SortedDictionary<int,string> ViewMode_ConfigFileSuffixes = new SortedDictionary<int,string>();
			public string ConfigDir = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "templates", "MacroProfilesConfig");
			public string InstName  = string.Empty;
			public System.IO.DirectoryInfo dirCustom = null;
			public string Status=string.Empty;

			//==========================================================================================================
			public SavedConfigManager(string InstrumentFullName, string InstrumentType){
				try{
					//Status = "Constructor "+InstrumentFullName+"  "+InstrumentType;
					if(!System.IO.Directory.Exists(ConfigDir)) System.IO.Directory.CreateDirectory(ConfigDir);
					dirCustom = new System.IO.DirectoryInfo(ConfigDir);
					InstName = StripOutIllegalCharacters(string.Format("{0}-{1}",InstrumentFullName, InstrumentType),"_");
				}catch(Exception e){Status = "SavedConfigManager constructor: "+e.ToString();}
			}
			//==========================================================================================================
//			public void AddViewMode(int idx, string suffix){
//				try{
//					//Status = Status+"\nAddViewMode "+suffix;
//					ViewMode_ConfigFileSuffixes[idx] = suffix;
//				}catch(Exception e){Status = "AddViewMode: "+e.ToString();}
//			}
			//==========================================================================================================
			public void UpdateStatus(string StatusName, bool NewStatus){
				var fname = System.IO.Path.Combine(ConfigDir,this.StripOutIllegalCharacters(InstName+"-"+StatusName+".config","_"));
				try{
					if(NewStatus){
						System.IO.File.WriteAllText(fname,"x");
					}else{
						if(System.IO.File.Exists(fname)) System.IO.File.Delete(fname);
					}
				}catch(Exception e){Status = "Update "+StatusName+": "+e.ToString();}
			}
			//==========================================================================================================
			public bool DetermineStatus(string StatusName){
				var fname = System.IO.Path.Combine(ConfigDir,this.StripOutIllegalCharacters(InstName+"-"+StatusName+".config","_"));
				try{
					return System.IO.File.Exists(fname);
				}catch(Exception e){Status = "DetermineStatus: "+StatusName+": "+e.ToString();}
				return false;
			}
			//==========================================================================================================
			public string StripOutIllegalCharacters(string name, string ReplacementString){
				#region strip
				char[] invalidPathChars = System.IO.Path.GetInvalidFileNameChars();
				string invalids = string.Empty;
				foreach(char ch in invalidPathChars){
					invalids += ch.ToString();
				}
				string result = string.Empty;
				for(int c=0; c<name.Length; c++) {
					if(!invalids.Contains(name[c].ToString())) result += name[c];
					else result += ReplacementString;
				}
				return result;
				#endregion
			}
			#endregion
		}
		private SavedConfigManager ConfigMgr = null;
		#endregion -------------------

		private double   SelectedVolMultiplier = 0.01;
		private DateTime priorDate = DateTime.MinValue;
		private bool     InitializationRun = true;
		private int		 newestProfileId = -1;
		private int		 FirstProfileIdOfCurrentSession  = -1;
		private bool	 UPDATE_globaldict_pricelevels = false;
//		private bool	 profile_locations_changed = false;
		private SortedDictionary<string, bool> IsGlobalized = new SortedDictionary<string,bool>();

		private MouseManager MM;
		private double    H=0;
		private double    L=0;
		private DateTime  TimeOfCondensedErrorMessage = DateTime.MinValue;
		private DateTime  newestDate = DateTime.MinValue;
		private bool      isNewSession = false;
		private bool      isLiveData = false;
		private bool	  IsTerminated = false;
		private float     barwidth_f = 0;
		private int       barwidth_int = 0;
		private int		  PixelsPerTick = 0;
		private int       ProfileId_EarliestUnbrokenArbZone = 0;
		private List<int> ProfKeysWithZonesInView = null;
		private List<int> CurSessProfileIds1 = new List<int>();
		private bool      ReadyToCheckAlerts = false;
		private double    FrontRunPts = 0;
		private DateTime  LaunchTime = DateTime.Now;
		private bool      Force_DrawGlobalObjectsNow = true;
		private bool      Delayed_Ray_Deletion = false;//when user selects "Remove" rays, there's a delay.  The removal is only completed once he clicks on the chart
		public ARC_MacroProfiles_GlobalRayScopes pcVisual_ScopeVARays  = ARC_MacroProfiles_GlobalRayScopes.Manual;
		public ARC_MacroProfiles_GlobalRayScopes pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
		public ARC_MacroProfiles_GlobalRayScopes phVisual_ScopeVARays  = ARC_MacroProfiles_GlobalRayScopes.Manual;
		public ARC_MacroProfiles_GlobalRayScopes phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;

		#region -- Write ArbZone variables --------------------------
		private List<string> ArbZoneOutput = new List<string>();
		private bool SaveArbZoneData = false;
		private DateTime WrittenArbsMsgDT = DateTime.MinValue;
		#endregion -------------------------

		#region -- Global_RaysData --------------------------------------------------
		private class Global_RaysData{
			public int LMAbar = 0;
			public int TPOorVPorPOC = -1;
			public int Type = -1;//if TPOorVPorPOC = TPO or VP, then is it Support or Resistance...if TPOorVPorPOC = POC, then is it a TPO type or a VP type
			public DateTime DT;
			public double Price;
			public string TemplateName;
			public bool IsDrawn = false;
			public DateTime EndDT = DateTime.MaxValue;
			public Global_RaysData(DateTime dt, int leftABar, int tpo_or_vp_or_poc, int res_or_sup, double price, string templatename){
				DT=dt; Price=price; LMAbar = leftABar; TPOorVPorPOC = tpo_or_vp_or_poc; Type = res_or_sup; TemplateName=templatename.Replace(" Ray Template",string.Empty); IsDrawn=false; EndDT = DateTime.MaxValue;
			}
		}
		#endregion
		private SortedDictionary<string,Global_RaysData> Global_VAHL_Rays = new SortedDictionary<string,Global_RaysData>();
		private SortedDictionary<string,Global_RaysData> Global_POC_Rays  = new SortedDictionary<string,Global_RaysData>();

		#region -- Global_RectsData ---------------------------------------------------
		private class Global_RectsData{
			public int      StartABar;
			//public int      EndABar;
			public DateTime DTStart;
			public double   TopPrice;
			public DateTime DTEnd;
			public double   BottomPrice;
			public string   TemplateName;
			public char     Type_S_R_V;
			public bool     IsDrawn = false;
			public Global_RectsData(int startabar, DateTime dtStart, double topprice, DateTime dtEnd, double bottomprice, string templatename, char type_s_r_v){
				StartABar = startabar+1; DTStart=dtStart; DTEnd=dtEnd; TopPrice=topprice; BottomPrice=bottomprice; TemplateName=templatename.Replace(" Rectangle Template",string.Empty); IsDrawn=false; this.Type_S_R_V=type_s_r_v;
			}
			public string ToString(){
				return string.Format("{0} {1}  {2}  {3}  {4} {5}", StartABar, DTStart, TopPrice, BottomPrice, Type_S_R_V, DTEnd.ToString());
			}
		}
		#endregion
		private SortedDictionary<string,Global_RectsData>  Global_Arb_Rects = new SortedDictionary<string,Global_RectsData>();
		private SortedDictionary<string,Global_RectsData>  Global_LVN_Rects = new SortedDictionary<string,Global_RectsData>();
		private SortedDictionary<string,Global_RectsData>  Global_HVN_Rects = new SortedDictionary<string,Global_RectsData>();
		private string ObjTagPrefix       = string.Empty;
		private string small_tag		  = string.Empty;
		static string  HLtemplates_folder = null;

		private SortedDictionary<double,char> UntestedResPrices = new SortedDictionary<double,char>();
		private SortedDictionary<double,char> UntestedSupPrices = new SortedDictionary<double,char>();
		
		#region -- Variables for managing Volume Nodes --
		private bool HVNLVN_AreVisible = false;
//		private double PriorBarHigh = double.MinValue;
//		private double PriorBarLow = double.MaxValue;
		#endregion

		#region -- PrintNew --------------------------------
		static string printprior1 = string.Empty;
		static string printprior2 = string.Empty;
		private void PrintNew1(int number){//only prints to the output window if the new string is different than the prior printed string
			PrintNew1(string.Format("{0}",number));
		}
		private void PrintNew1(string newstring){//only prints to the output window if the new string is different than the prior printed string
			if(printprior1.CompareTo(newstring)!=0) {
				printprior1 = newstring;
				NinjaTrader.Code.Output.Process(newstring, PrintTo.OutputTab1);
			}
		}
		private void PrintNew2(string newstring){//only prints to the output window if the new string is different than the prior printed string
			if(printprior2.CompareTo(newstring)!=0) {
				printprior2 = newstring;
				NinjaTrader.Code.Output.Process(newstring, PrintTo.OutputTab2);
			}
		}
		private void PrintNew1(DateTime t, string newstring){//only prints to the output window if the new string is different than the prior printed string
			if(printprior1.CompareTo(newstring)!=0) {
				printprior1 = newstring;
				NinjaTrader.Code.Output.Process(t.ToString()+": "+newstring, PrintTo.OutputTab1);
			}
		}
		private void PrintNew2(DateTime t, string newstring){//only prints to the output window if the new string is different than the prior printed string
			if(printprior2.CompareTo(newstring)!=0) {
				printprior2 = newstring;
				NinjaTrader.Code.Output.Process(t.ToString()+": "+newstring, PrintTo.OutputTab2);
			}
		}

		private int prior_line = 0;
//		private void PrintLineNumber(int line){
//			if(!IsDebug) return;
//			if(line<prior_line) Print("");			prior_line=line;
//			Print(string.Format("L: {0}",line));
//		}
//		private void PrintLineNumber(int line, int bip){
//			if(!IsDebug) return;
//			if(line<prior_line) Print("");			prior_line=line;
//			Print(string.Format("L: {0}  BIP:{1}",line,bip));
//		}
		#endregion
		//=========================================================================================
		private DateTime UpdateRayEndDT(Global_RaysData ray){
			#region -- UpdateRayEndDT ---------------------------------
			var pkeys = Prof.Where(pro=> pro.Key > ray.LMAbar).Select(pro=> pro.Key).ToList();
//if(line==5966)Print("\nExamining Ray lmabar: "+ray.LMAbar+"  IsDranw? "+ray.IsDrawn.ToString()+"  EndDT: "+ray.EndDT.ToString());
			if(pkeys == null || pkeys.Count==0) return DateTime.MaxValue;
			double vah = 0;
			double val = 0;
			foreach(var id in pkeys){
bool z = false;//line==5966 && id>=137;
//if(z)Print("      Profile id: "+id);
				vah = Math.Max(Prof[id].tpoVAH_Price, Prof[id].vpVAH_Price);
				val = Math.Min(Prof[id].tpoVAL_Price, Prof[id].vpVAL_Price);
//if(z)Print("           va H: "+vah+" va L: "+val);
				if(ray.Price <= vah && ray.Price >= val) {
					ray.IsDrawn = false;
//if(z)Print("           "+ray.Price+" is inside of Profile VA");
					return Prof[id].StartTime;
				}
//else if(z)Print("           "+ray.Price+" is OUTSIDE of Profile VA");
//				else if(ray.Price <= Prof[id].vpVAH_Price && ray.Price >= Prof[id].vpVAL_Price) {
//					ray.IsDrawn = false;
//					return Prof[id].StartTime;
//				}
			}
			return DateTime.MaxValue;
			#endregion -----------------------
		}
		#region -- LVN management and drawing -------------------------------------------
		//=========================================================================================
		private List<int> UpdateVolNodeTerminationState(double BarHigh, double BarLow, int TicksPerHisto, int CurrentProfileId){
			#region -- UpdateVolNodeTerminationState ---------------------------
			//if(BarHigh <= PriorBarHigh && BarLow >= PriorBarLow) {
			//	return null;//only calculate this method if we have current High or Low outside of prior bar High or Low
			//}
			var pkeys = Prof.Where(pro=> pro.Value.HVN.Any(hx=> hx<=BarHigh && hx>= BarLow) || pro.Value.LVN.Any(lx=> lx<=BarHigh && lx>=BarLow)).Select(pro=> pro.Key).ToList();
			if(pkeys == null || pkeys.Count==0) {
				return null;
			}
			var changed_ids = new List<int>();
			if(pkeys.Last()==CurrentProfileId) pkeys.RemoveAt(pkeys.Count-1);
			if(TicksPerHisto==1){
				foreach(var id in pkeys){
					var vnList = Prof[id].HVN.Where(hx=> hx<=BarHigh && hx>= BarLow).ToList();
					if(vnList!=null && vnList.Count>0){
						foreach(var vnPrice in vnList){ 
							if(!Prof[id].BrokenVolNodes.Contains(vnPrice)) {
								Prof[id].BrokenVolNodes.Add(vnPrice);
								if(!changed_ids.Contains(id)) {
									changed_ids.Add(id);
									RemoveAllGlobal_HVN_Zones(vnPrice);
								}
							}
						}
					}
					vnList     = Prof[id].LVN.Where(lx=> lx<=BarHigh && lx>= BarLow).ToList();
					if(vnList!=null && vnList.Count>0){
						foreach(var vnPrice in vnList){ 
							if(!Prof[id].BrokenVolNodes.Contains(vnPrice)) {
								Prof[id].BrokenVolNodes.Add(vnPrice);
								if(!changed_ids.Contains(id)) {
									changed_ids.Add(id);
									RemoveAllGlobal_LVN_Zones(vnPrice);
								}
							}
						}
					}
				}
			}else{
				foreach(var id in pkeys){
					var vnList = Prof[id].HVN.Where(hx=> hx<=BarHigh+priceBoxSizeInPrice && hx>= BarLow).ToList();
					if(vnList!=null && vnList.Count>0){
						foreach(var vnPrice in vnList){ 
							if(!Prof[id].BrokenVolNodes.Contains(vnPrice)) {
								Prof[id].BrokenVolNodes.Add(vnPrice);
								if(!changed_ids.Contains(id)) {
									changed_ids.Add(id);
									RemoveAllGlobal_HVN_Zones(vnPrice);
								}
							}
						}
					}
					vnList     = Prof[id].LVN.Where(lx=> lx<=BarHigh+priceBoxSizeInPrice && lx>= BarLow).ToList();
					if(vnList!=null && vnList.Count>0) {
						foreach(var vnPrice in vnList){ 
							if(!Prof[id].BrokenVolNodes.Contains(vnPrice)) {
								Prof[id].BrokenVolNodes.Add(vnPrice);
								if(!changed_ids.Contains(id)) {
									changed_ids.Add(id);
									RemoveAllGlobal_LVN_Zones(vnPrice);
								}
							}
						}
					}
				}
			}
			return changed_ids;
			#endregion ---------------------------
		}
		private void InitialzeVolNodeTerminationStates(){
			#region -- InitializeVolNodeTerminationStates ----------------------
			InitialzeVolNodeTerminationStates(Prof.Keys.ToList());
			#endregion --------------------------
		}
		private void InitialzeVolNodeTerminationStates(DateTime ThisSessionDate){
			#region -- InitializeVolNodeTerminationStates ----------------------
			var ids = Prof.Where(pk=> pk.Value.SessionDate == ThisSessionDate).Select(pk=> pk.Key).ToList();
			InitialzeVolNodeTerminationStates(ids);
			#endregion --------------------------
		}
		private void InitialzeVolNodeTerminationStates(List<int> ids){
			#region -- InitializeVolNodeTerminationStates ----------------------
			if(ids==null) return;
			if(ids.Count>1 && ids[0]<ids[1]) ids.Reverse(); //most recent (developing) profile id (abs bar number) is the 0 element of the list
			ids.RemoveAt(0); //don't start with the current profile...start with the one to the left of it
			var HH = Highs[0].GetValueAt(CurrentBars[0])+priceBoxSizeInPrice;
			var LL = Lows[0].GetValueAt(CurrentBars[0]);
			foreach(var id in ids){
				Prof[id].BrokenVolNodes.Clear();
				var VNs = Prof[id].HVN.Union(Prof[id].LVN == null ? new List<double>() : Prof[id].LVN).ToList();
				if(VNs==null || VNs.Count==0) {
					continue;
				}
				if(VNs.Max() <= HH && VNs.Min() >= LL){
					Prof[id].BrokenVolNodes = new List<double>(VNs);
					continue;
				}
				for(int abar = CurrentBars[0]; abar >= Prof[id].EndABar; abar--){
					var TouchedVNs = VNs.Where(px=> px<=HH && px>= LL).ToList();
					if(TouchedVNs!=null && TouchedVNs.Count>0){
						Prof[id].BrokenVolNodes = Prof[id].BrokenVolNodes.Union(TouchedVNs==null ? new List<double>() : TouchedVNs).ToList();
						//if(Prof[id].BrokenVolNodes.Count == VNs.Count) break;
					}
					HH = Math.Max(HH, Highs[0].GetValueAt(abar)+priceBoxSizeInPrice);
					LL = Math.Min(LL, Lows[0].GetValueAt(abar));
				}
			}
			#endregion --------------------------
		}
		private void RemoveThisTag(string tag){
//			return;
			if(!tag.Contains("DataLoadingMsg")) Log("Removing tag: "+tag, NinjaTrader.Cbi.LogLevel.Information);
			RemoveDrawObject(tag);
		}
		#region -- Global LVN methods --
		private void RemoveAllGlobal_LVN_Zones(){
line=2100;
			var RectTag = string.Format("LVN{0}_", ObjTagPrefix);
			var objects = DrawObjects.ToList();
			foreach (dynamic dob in objects) {
//Print(dob.Tag+" found");//changes
				if (dob.ToString().EndsWith(".Rectangle") && dob.Tag.Contains(RectTag)) {
//Print(dob.Tag+" being removed");//changes
					RemoveThisTag(dob.Tag);
				}
			}
			Global_LVN_Rects.Clear();
		}
		private void RemoveAllGlobal_LVN_Zones(double price){
line=2113;
			var RectTag = string.Format("LVN{0}_", ObjTagPrefix);
			var objects = DrawObjects.ToList();
			foreach (dynamic dob in objects) {
//Print(dob.Tag+" found");//changes
				var type = dob.ToString();
				if (type.EndsWith(".Rectangle") && dob.Tag.Contains(RectTag)) {
					double highprice = Math.Max(dob.StartAnchor.Price,dob.EndAnchor.Price);
					double lowprice  = Math.Min(dob.StartAnchor.Price,dob.EndAnchor.Price);
					if(price <= highprice && price >= lowprice){
//Print(dob.Tag+" being removed");//changes
						RemoveThisTag(dob.Tag);
					}
				}
			}
			Global_LVN_Rects.Clear();
		}
		private void RemoveAllGlobal_LVN_Zones(int ProfileID){
			var RectTag = string.Format("LVN{0}_{1}_", ObjTagPrefix, ProfileID);
			var tags_to_delete = new List<string>();
			var objects = DrawObjects.ToList();
			foreach (dynamic dob in objects) {
//Print(dob.Tag+" found");//changes
				var type = dob.ToString();
				if (type.EndsWith(".Rectangle") && dob.Tag.Contains(RectTag)){
//Print(dob.Tag+" being removed");//changes
					tags_to_delete.Add(dob.Tag);
					RemoveThisTag(dob.Tag);
				}
			}
			foreach(var tag in tags_to_delete) if(Global_LVN_Rects.ContainsKey(tag)) Global_LVN_Rects.Remove(tag);
		}
		private void UpdateGlobalLVN_EndABars(List<int> profile_ids, bool ShowHide_CurrentProfileVN, bool ShowHide_PriorProfileVN){
			if(profile_ids==null) return;
			foreach(var pid in profile_ids){
				RemoveAllGlobal_LVN_Zones(pid);
				if(IsGlobalized["LVN"]){
					if(ShowHide_CurrentProfileVN && pid == Prof.Keys.Max())
						CreateAndDrawAllGlobal_LVN_Zones(Prof[pid]);
					if(ShowHide_PriorProfileVN && pid < Prof.Keys.Max())
						CreateAndDrawAllGlobal_LVN_Zones(Prof[pid]);
				}
			}
		}
		private void CreateAndDrawAllGlobal_LVN_Zones (ProfileData profile){
			#region -- CreateAndDraw GlobalZones For LVNs --
			if(profile.ConsolidatedVatP==null) return;
			if(profile.ConsolidatedVatP.Count<=2) return;
			List<double> histos = profile.ConsolidatedVatP.Keys.OrderBy(n=>n).ToList();
			int ptr = 0;
line=2163;
			double zone_low_price = double.MinValue;
			var next_profile_ids  = Prof.Keys.Where(k => k > profile.StartABar).ToList();
			int next_profile_id   = int.MaxValue;
			if(next_profile_ids!=null && next_profile_ids.Count>0) next_profile_id = next_profile_ids.Min();
			while(ptr < histos.Count){
line=2169;
				if(profile.LVN.Contains(histos[ptr]) && !profile.BrokenVolNodes.Contains(histos[ptr])){
					if(zone_low_price==double.MinValue){
						zone_low_price = histos[ptr]-TickSize * this.pTicksPerHistoBar/2.0;
					}
				}else{
line=2175;
					if(zone_low_price != double.MinValue){
						double zone_high_price = histos[ptr]/* + pTicksPerHistoBar*TickSize*/;//backup the ptr one tick...that is the high price of the zone
						zone_high_price = histos[ptr] - TickSize * this.pTicksPerHistoBar/2.0;

line=2180;
						int endbar = BarsArray[0].Count;//z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
						if(endbar>=BarsArray[0].Count) {
							var tag = string.Format("LVN{0}_{1}_{2}_{3}", ObjTagPrefix, profile.StartABar, "V", zone_high_price);
line=2184;
							Global_LVN_Rects[tag] = new Global_RectsData(profile.StartABar,
										BarsArray[0].GetTime(profile.StartABar+1), 
										zone_high_price, 
										endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
										zone_low_price, 
										(profile.StartABar >= FirstProfileIdOfCurrentSession ? pcLVN_Template : phLVN_Template),
										'V');
line=2192;
if(IsDebug) Print("--------- Drawing "+tag);//changes
							ImmediatelyDraw_Zone(tag, Global_LVN_Rects);
						}
						zone_low_price = double.MinValue;
					}
				}
				ptr++;
			}
			#endregion
		}
		private void CreateAndDrawAllGlobal_LVN_Zones(bool Show_CurrentProfileVN, bool Show_HistoricalProfileVN){
line=2204;
			if(!IsGlobalized.ContainsKey("LVN") || !IsGlobalized["LVN"]) return;
			#region -- CreateAndDrawAllGlobal_LVN_Zones --
			if(Show_HistoricalProfileVN && Prof.Count>0){
line=2208;
				int min_key = Show_HistoricalProfileVN ? 0 : Prof.Keys.Max()-1;
				int max_key = Show_CurrentProfileVN    ? Prof.Keys.Max()+1  : Prof.Keys.Max()-1;
				var plist = Prof.Where(k => k.Value.LVN.Count>0 && k.Key <= max_key && k.Key >= min_key).ToList();
line=2212;
				if(plist!=null && plist.Count>0){
					foreach(var p in plist){
						CreateAndDrawAllGlobal_LVN_Zones(p.Value);
					}
				}
			}
			if(Show_CurrentProfileVN && Prof.Count>0){
line=2220;
				CreateAndDrawAllGlobal_LVN_Zones(Prof[Prof.Keys.Max()]);
			}
			#endregion
		}
		#endregion

//==============================

		#region -- Global HVN methods --
		private void RemoveAllGlobal_HVN_Zones(){
line=2231;
			var RectTag = string.Format("HVN{0}_", ObjTagPrefix);
			var objects = DrawObjects.ToList();
			foreach (dynamic dob in objects) {
				if (dob.ToString().EndsWith(".Rectangle") && dob.Tag.Contains(RectTag)) {
					RemoveThisTag(dob.Tag);
				}
			}
			Global_HVN_Rects.Clear();
		}
		private void RemoveAllGlobal_HVN_Zones(double price){
line=2242;
			var RectTag = string.Format("HVN{0}_", ObjTagPrefix);
			var objects = DrawObjects.ToList();
			foreach (dynamic dob in objects) {
				var type = dob.ToString();
				if (type.EndsWith(".Rectangle") && dob.Tag.Contains(RectTag)) {
					double highprice = Math.Max(dob.StartAnchor.Price,dob.EndAnchor.Price);
					double lowprice  = Math.Min(dob.StartAnchor.Price,dob.EndAnchor.Price);
					if(price <= highprice && price >= lowprice)
						RemoveThisTag(dob.Tag);
				}
			}
			Global_HVN_Rects.Clear();
		}
		private void RemoveAllGlobal_HVN_Zones(int ProfileID){
			var RectTag = string.Format("HVN{0}_{1}_", ObjTagPrefix, ProfileID);
			var tags_to_delete = new List<string>();
			var objects = DrawObjects.ToList();
			foreach (dynamic dob in objects) {
				var type = dob.ToString();
				if (type.EndsWith(".Rectangle") && dob.Tag.Contains(RectTag)){
					tags_to_delete.Add(dob.Tag);
					RemoveThisTag(dob.Tag);
				}
			}
			foreach(var tag in tags_to_delete) if(Global_HVN_Rects.ContainsKey(tag)) Global_HVN_Rects.Remove(tag);
		}
		private void UpdateGlobalHVN_EndABars(List<int> profile_ids, bool ShowHide_CurrentProfileVN, bool ShowHide_PriorProfileVN){
			if(profile_ids==null) return;
			foreach(var pid in profile_ids){
				RemoveAllGlobal_HVN_Zones(pid);
				if(IsGlobalized["HVN"]){
					if(ShowHide_CurrentProfileVN && pid == Prof.Keys.Max())
						CreateAndDrawAllGlobal_HVN_Zones(Prof[pid]);
					if(ShowHide_PriorProfileVN && pid < Prof.Keys.Max())
						CreateAndDrawAllGlobal_HVN_Zones(Prof[pid]);
				}
			}
		}

		private void CreateAndDrawAllGlobal_HVN_Zones (ProfileData profile){
			#region -- CreateAndDraw GlobalZones For HVNs --
			if(profile.ConsolidatedVatP==null) return;
			if(profile.ConsolidatedVatP.Count<=2) return;
			List<double> histos = profile.ConsolidatedVatP.Keys.OrderBy(n=>n).ToList();
			int ptr = 0;
			double zone_low_price = double.MinValue;
			var next_profile_ids  = Prof.Keys.Where(k => k > profile.StartABar).ToList();
			int next_profile_id   = int.MaxValue;
			if(next_profile_ids!=null && next_profile_ids.Count>0) next_profile_id = next_profile_ids.Min();
			while(ptr < histos.Count){
				if(profile.HVN.Contains(histos[ptr]) && !profile.BrokenVolNodes.Contains(histos[ptr])){
					if(zone_low_price==double.MinValue){
						zone_low_price = histos[ptr]-TickSize * this.pTicksPerHistoBar/2.0;
					}
				}else{
					if(zone_low_price != double.MinValue){
						double zone_high_price = histos[ptr]/* + pTicksPerHistoBar*TickSize*/;//backup the ptr one tick...that is the high price of the zone
						zone_high_price = histos[ptr] - TickSize * this.pTicksPerHistoBar/2.0;

						int endbar = BarsArray[0].Count;//z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
						if(endbar>=BarsArray[0].Count) {
							var tag = string.Format("HVN{0}_{1}_{2}_{3}", ObjTagPrefix, profile.StartABar, "V", zone_high_price);
							Global_HVN_Rects[tag] = new Global_RectsData(profile.StartABar,
										BarsArray[0].GetTime(profile.StartABar+1), 
										zone_high_price, 
										endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
										zone_low_price, 
										(profile.StartABar >= FirstProfileIdOfCurrentSession ? pcHVN_Template : phHVN_Template),
										'V');
							ImmediatelyDraw_Zone(tag, Global_HVN_Rects);
						}
						zone_low_price = double.MinValue;
					}
				}
				ptr++;
			}
			#endregion
		}
		private void CreateAndDrawAllGlobal_HVN_Zones(bool Show_CurrentProfileVN, bool Show_HistoricalProfileVN){
line=2322;
			if(!IsGlobalized.ContainsKey("HVN") || !IsGlobalized["HVN"]) return;
			#region -- CreateAndDrawAllGlobal_HVN_Zones --
			if(Show_HistoricalProfileVN && Prof.Count>0){
line=2326;
				int min_key = Show_HistoricalProfileVN ? 0 : Prof.Keys.Max()-1;
				int max_key = Show_CurrentProfileVN    ? Prof.Keys.Max()+1  : Prof.Keys.Max()-1;
				var plist = Prof.Where(k => k.Value.HVN.Count>0 && k.Key <= max_key && k.Key >= min_key).ToList();
				if(plist!=null && plist.Count>0){
					foreach(var p in plist){
						CreateAndDrawAllGlobal_HVN_Zones(p.Value);
					}
				}
			}
line=2336;
			if(Show_CurrentProfileVN && Prof.Count>0){
				CreateAndDrawAllGlobal_HVN_Zones(Prof[Prof.Keys.Max()]);
			}
			#endregion
		}
		#endregion

		#endregion ------------
//=====================================================================================================
		#region -- Plots ---------
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> vpVAHigh { get { return Values[0]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> vpVALow { get { return Values[1]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> vpPoc { get { return Values[2]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> tpoVAHigh { get { return Values[3]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> tpoVALow { get { return Values[4]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> tpoPoc { get { return Values[5]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> VWAP { get { return Values[6]; } }
		#endregion
		#region -- DeleteTheseZones --
		private void DeleteTheseZones(List<int> pkeys, int ZoneType, SortedDictionary<string,Global_RectsData> dict){
			var tag = string.Empty;
			foreach(var p in pkeys){
				if(ZoneType=='V')
					tag = string.Format("LVN{0}_{1}", ObjTagPrefix);
				else
					tag = string.Format("Z{0}_{1}_{2}#", ObjTagPrefix, p, ZoneType==RES_ID ? 'R':'S');
				var objects = DrawObjects.Where(x=> x.Tag.Contains(tag)).ToList();
				if(objects!=null && objects.Count>0) {
					foreach(var obj in objects){
						RemoveThisTag(obj.Tag);
						if(dict.ContainsKey(tag)) dict.Remove(obj.Tag);
					}
				}
			}
		}
		private void DeleteTheseZones(int pkey, int ZoneType, SortedDictionary<string,Global_RectsData> dict){
			var tag = string.Empty;
			if(ZoneType=='V')
				tag = string.Format("LVN{0}_{1}", ObjTagPrefix);
			else
				tag = string.Format("Z{0}_{1}_{2}#", ObjTagPrefix, pkey, ZoneType==RES_ID ? 'R':'S');
			var objects = DrawObjects.Where(x=> x.Tag.Contains(tag)).ToList();
			if(objects!=null && objects.Count>0) {
				foreach(var obj in objects){
					RemoveThisTag(obj.Tag);
					if(dict.ContainsKey(tag)) dict.Remove(obj.Tag);
				}
			}
		}
		private void DeleteTheseZones(int ZoneType, SortedDictionary<string,Global_RectsData> dict){
			var tag = string.Empty;
			var tag2 = string.Empty;
			if(ZoneType=='V')
				tag = string.Format("LVN{0}_{1}", ObjTagPrefix);
			else{
				tag = string.Format("Z{0}_", ObjTagPrefix);
				tag2 = string.Format("_{1}#", ZoneType==RES_ID ? 'R':'S');
			}
			var objects = DrawObjects.Where(x=> x.Tag.Contains(tag) && x.Tag.Contains(tag2)).ToList();
			if(objects!=null && objects.Count>0) {
				foreach(var obj in objects){
					RemoveThisTag(obj.Tag);
					if(dict.ContainsKey(tag)) dict.Remove(obj.Tag);
				}
			}
		}
		private void DeleteTheseRays(int RayType, SortedDictionary<string,Global_RaysData> dict){
			var RayTag    = string.Format("{0}{1}_", RayType==RES_ID ? 'H':'L', ObjTagPrefix);
			var objects = DrawObjects.Where(x=> x.Tag.Contains(RayTag)).ToList();
			if(objects!=null && objects.Count>0) {
				foreach(var obj in objects){
					RemoveThisTag(obj.Tag);
					if(dict.ContainsKey(obj.Tag)) dict.Remove(obj.Tag);
				}
			}
		}
		#endregion
		private void UpdateGlobalRaysOnPriceChanges(int MinProfileId, SortedDictionary<string,Global_RaysData> Global_POC_Rays, SortedDictionary<string,Global_RaysData>Global_VAHL_Rays){
			#region -- UpdateGlobalRaysOnPriceChanges --
//int TPOorVPorPOC = -1;
//int Type = if TPOorVPorPOC = TPO or VP, then is it Support or Resistance...if TPOorVPorPOC = POC, then is it a TPO type or a VP type
			//Update the price levels of the rays in the current session dictionaries

			var rays = Global_POC_Rays.Where(k=>k.Value.LMAbar >= MinProfileId);
			if(rays!=null) foreach(var r in rays){
				if(r.Value.TPOorVPorPOC == TPO_ID){
					if(r.Value.Type==RES_ID)      r.Value.Price = Prof[r.Value.LMAbar].tpoVAH_Price;
					else if(r.Value.Type==SUP_ID) r.Value.Price = Prof[r.Value.LMAbar].tpoVAL_Price;
				}
				else if(r.Value.TPOorVPorPOC == V_ID){
					if(r.Value.Type==RES_ID)      r.Value.Price = Prof[r.Value.LMAbar].vpVAH_Price;
					else if(r.Value.Type==SUP_ID) r.Value.Price = Prof[r.Value.LMAbar].vpVAL_Price;
				}
				else if(r.Value.TPOorVPorPOC == POC_ID){
					if(r.Value.Type==TPO_ID)    r.Value.Price = Prof[r.Value.LMAbar].tpoPOC_Price;
					else if(r.Value.Type==V_ID) r.Value.Price = Prof[r.Value.LMAbar].vpVAL_Price;
				}
			}
			rays = Global_VAHL_Rays.Where(k=>k.Value.LMAbar >= MinProfileId);
			if(rays!=null) foreach(var r in rays){
				if(r.Value.TPOorVPorPOC == TPO_ID){
					if(r.Value.Type==RES_ID)      r.Value.Price = Prof[r.Value.LMAbar].tpoVAH_Price;
					else if(r.Value.Type==SUP_ID) r.Value.Price = Prof[r.Value.LMAbar].tpoVAL_Price;
				}
				else if(r.Value.TPOorVPorPOC == V_ID){
					if(r.Value.Type==RES_ID)      r.Value.Price = Prof[r.Value.LMAbar].vpVAH_Price;
					else if(r.Value.Type==SUP_ID) r.Value.Price = Prof[r.Value.LMAbar].vpVAL_Price;
				}
				else if(r.Value.TPOorVPorPOC == POC_ID){
					if(r.Value.Type==TPO_ID)    r.Value.Price = Prof[r.Value.LMAbar].tpoPOC_Price;
					else if(r.Value.Type==V_ID) r.Value.Price = Prof[r.Value.LMAbar].vpVAL_Price;
				}
			}
			#endregion
		}

//=====================================================================================================
		private void DetermineIfDelayedRayDeletionMessageIsNecessary(ARC_MacroProfiles_GlobalRayScopes pcVA, ARC_MacroProfiles_GlobalRayScopes phVA, ARC_MacroProfiles_GlobalRayScopes pcPOC, ARC_MacroProfiles_GlobalRayScopes phPOC){
			if( pcVA == ARC_MacroProfiles_GlobalRayScopes.Remove ||
				phVA == ARC_MacroProfiles_GlobalRayScopes.Remove ||
				pcPOC == ARC_MacroProfiles_GlobalRayScopes.Remove ||
				phPOC == ARC_MacroProfiles_GlobalRayScopes.Remove)
					Draw.TextFixed(this, "DelayedRayDeleteMsg", "To complete the deletion of the rays, click on the chart", TextPosition.BottomLeft,Brushes.Magenta, new SimpleFont("Arial",16),Brushes.Magenta, Brushes.Black,80);
			else
				RemoveThisTag("DelayedRayDeleteMsg");
		}
//=====================================================================================================
		private int CalculateCountOfGlobalObjects(){
			var RayHTag    = string.Format("@H{0}_", ObjTagPrefix);
			var RayLTag    = string.Format("@L{0}_", ObjTagPrefix);
			var RayPOCTag  = string.Format("@POC{0}_", ObjTagPrefix);
			var RectTag    = string.Format("@Z{0}_", ObjTagPrefix);
			var LVNRectTag = string.Format("@LVN{0}_", ObjTagPrefix);
			var objects = DrawObjects.Where(ob=> ob.Tag.StartsWith(RayHTag) || ob.Tag.StartsWith(RayLTag) || ob.Tag.StartsWith(RayPOCTag) || ob.Tag.StartsWith(RectTag) || ob.Tag.StartsWith(LVNRectTag));
			if(objects==null) return 0;
			return objects.Count();
		}
//=====================================================================================================
		private void InformUserAboutRecalculation(){
			miRecalculate1.Background = Brushes.Yellow;
			miRecalculate1.FontWeight = FontWeights.Bold;
			miRecalculate1.FontStyle = FontStyles.Italic;
		}
		private void ResetRecalculationUI(){
			miRecalculate1.FontWeight = FontWeights.Normal;
			miRecalculate1.FontStyle = FontStyles.Normal;
			miRecalculate1.Background = null;
		}
//=====================================================================================================
		#region -- UI menu variables -------------------------------------------------------
        private Menu MenuControlContainer;
        private MenuItem MenuControl, miTPO_VisualStyle;
		private MenuItem miTPO_SubMenu, miVolProfile_SubMenu, miATRRRBox_SubMenu, miRayGlobal_SubMenu, miHVNLVNBox_SubMenu;
		private MenuItem miVisualType_VPVAH, miVisualType_VPVAL, miVisualType_VPPOC, miVisualType_VPHisto;
		private MenuItem miRR_Visuals, miATR_Visuals, miATRMode;
		private MenuItem miVisualType_TPOSinglePrints, miVisualType_TPOVAH, miVisualType_TPOVAL, miVisualType_TPOPOC, miVisualType_TPOHisto, miVisualType_VWAP, miShowHide_ContinuousVWAP;
		private MenuItem miTimeBasis, miMinSplitDepth, miRecalculate1, miTicksPerHistoBar, miShowHide_FreshZones, miShowHide_BrokenZones, miShowHide_TestedZones, miAutoScaleHistoWidth, miShowHide_ZonePrices;
		private MenuItem miSplitMergeEnabled, miSplitAssistEnabled, miAutoMergeOverlappers, miShowHide_DisqZones, miShowHide_OverlappedZones, miShowHide_TPOTouchCounter;
		private MenuItem miShowHide_SupportZones, miShowHide_ResistanceZones, miShowHide_LVNZones, miVisualType_HVN, miVisualType_LVN, miSignificance_HVN_LVN, miRegionSize_HVN_LVN, miVisualType_CurrentProfileVNs, miVisualType_HistoricalProfileVNs;
		private MenuItem miShowHide_cVARays, miShowHide_hVARays, miShowHide_cPOCRays, miShowHide_hPOCRays, mi_CurrentSessionRaysFilter, mi_HistoricalRaysFilter;
		private MenuItem miPermitVAHRaysZones, miPermitVALRaysZones, miShow_CurrentSessionZones, miGlobalize_LVNZones, miGlobalize_HVNZones, miGlobalize_FreshZones, miGlobalize_BrokenZones, miGlobalize_TestedZones, miGlobalize_DisqualifiedZones, miGlobalize_OverlappedZones;

#if HTO_LTO
		private MenuItem miVisualType_HTO, miVisualType_LTO;
#endif
        private Button      ClearGlobals_Button;
		private Button		EnableGlobals_Button;
		ARC_MacroProfiles_GlobalRayScopes Current_VisualType_CurrentSessionRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
		ARC_MacroProfiles_GlobalRayScopes Current_VisualType_HistoricalRays     = ARC_MacroProfiles_GlobalRayScopes.Manual;
		ARC_MacroProfiles_GlobalRayScopes Current_VisualType_pocCurrentSessionRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
		ARC_MacroProfiles_GlobalRayScopes Current_VisualType_pocHistoricalRays     = ARC_MacroProfiles_GlobalRayScopes.Manual;

		private string toolbarname = "NSMacroProfilesTB", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private Grid indytoolbar;
		private DateTime LastMousewheelSpin = DateTime.MinValue;

		private bool ShowZonesClickedJustNow = false;
		#endregion ****************************************************************
//=====================================================================================================
		private void addToolBar(){
			#region -- addToolBar ------------------------------------------------------------------
			if(pButtonText=="terminated") return;

			MenuControlContainer = new System.Windows.Controls.Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
			MenuControl = new MenuItem {Name="MProf"+uID, Header = string.Format("{0} {1}", pButtonText,this.pTimeBasis.ToString()[0]), BorderThickness = new Thickness(2), BorderBrush = Brushes.Violet, Foreground = Brushes.Cyan, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControl.GotFocus += delegate(object o, RoutedEventArgs e){
				MM.obj_count = CalculateCountOfGlobalObjects();
				if(MM.obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
				if(Keyboard.IsKeyDown(Key.LeftShift)){//REMOVE the indicator if left-shift is held down and left-click on the UI pulldown
					this.IsVisible = false;
					IsTerminated = true;
					pButtonText = "terminated";
					indytoolbar.Visibility = Visibility.Collapsed;
					SetState(State.Terminated);
//					if(ChartPanel!=null){
//						ChartPanel.MouseMove -= OnMouseMove;
//						ChartPanel.MouseUp -= OnMouseUp;
//						//ChartControl.PreviewMouseLeftButtonUp -=	OnCtrlPlusClick;
//					}
//	                if (chartWindow != null)
//	                {
//	                    if (indytoolbar != null)
//	                    {
//	                        Dispatcher.BeginInvoke(new Action(() =>
//	                        {
//	                            chartWindow.MainMenu.Remove(indytoolbar);
//	                            indytoolbar = null;

//	                            chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
//	                            chartWindow = null;
//	                        }));
//	                    }
//	                }
				}
			};
			MenuControlContainer.Items.Add(MenuControl);
	//- - - - - - - - - - - - - 
			#region -- TimeBasis --
			var miTimeBasis = new MenuItem {Header = "Basis: "+this.pTimeBasis.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miTimeBasis.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled = true;
				Draw.TextFixed(this, "DataLoadingMsg", "Time basis change is in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				if(pTimeBasis==ARC_MacroProfiles_TimeBasis.Daily) 		pTimeBasis = ARC_MacroProfiles_TimeBasis.Weekly;
				else if(pTimeBasis==ARC_MacroProfiles_TimeBasis.Weekly) 	pTimeBasis = ARC_MacroProfiles_TimeBasis.Monthly;
				else if(pTimeBasis==ARC_MacroProfiles_TimeBasis.Monthly)	pTimeBasis = ARC_MacroProfiles_TimeBasis.Daily;
				var MI = (MenuItem)o;     MI.Header = "Basis: "+this.pTimeBasis.ToString();
				miRecalculate1.FontWeight = FontWeights.Bold;
				miRecalculate1.FontStyle = FontStyles.Italic;
				MenuControl.Header = string.Format("{0} {1}",pButtonText,this.pTimeBasis.ToString()[0]);
				ForceRefresh();
				};
			miTimeBasis.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				Draw.TextFixed(this, "DataLoadingMsg", "Time basis change in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				if(e.Delta>0) {
					if(pTimeBasis==ARC_MacroProfiles_TimeBasis.Daily) 		pTimeBasis = ARC_MacroProfiles_TimeBasis.Weekly;
					else if(pTimeBasis==ARC_MacroProfiles_TimeBasis.Weekly) 	pTimeBasis = ARC_MacroProfiles_TimeBasis.Monthly;
					else if(pTimeBasis==ARC_MacroProfiles_TimeBasis.Monthly)	pTimeBasis = ARC_MacroProfiles_TimeBasis.Daily;
				}else{
					if(pTimeBasis==ARC_MacroProfiles_TimeBasis.Daily)		pTimeBasis = ARC_MacroProfiles_TimeBasis.Monthly;
					else if(pTimeBasis==ARC_MacroProfiles_TimeBasis.Weekly)	pTimeBasis = ARC_MacroProfiles_TimeBasis.Daily;
					else if(pTimeBasis==ARC_MacroProfiles_TimeBasis.Monthly)	pTimeBasis = ARC_MacroProfiles_TimeBasis.Weekly;
				}
				var MI = (MenuItem)o;     MI.Header = "Basis: "+this.pTimeBasis.ToString();
				miRecalculate1.FontWeight = FontWeights.Bold;
				miRecalculate1.FontStyle = FontStyles.Italic;
				MenuControl.Header = string.Format("{0} {1}",pButtonText,this.pTimeBasis.ToString()[0]);
				ForceRefresh();
			};
			#endregion
			MenuControl.Items.Add(miTimeBasis);
	//- - - - - - - - - - - - - 
			#region -- Min Profile SplitDepth --
			miMinSplitDepth = new MenuItem {Header = "Min SplitDepth: "+pMinSplitDepth.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miMinSplitDepth.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pMinSplitDepth++;
				miMinSplitDepth.Header = "Min SplitDepth:  "+pMinSplitDepth.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
				};
			miMinSplitDepth.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				var original = pMinSplitDepth;
				if(e.Delta>0) pMinSplitDepth++;
				else pMinSplitDepth--;
				pMinSplitDepth = Math.Max(2,pMinSplitDepth);
				miMinSplitDepth.Header = "Min SplitDepth:  "+pMinSplitDepth.ToString();
				if(original != pMinSplitDepth) InformUserAboutRecalculation();
				ForceRefresh();
				};
			MenuControl.Items.Add(miMinSplitDepth);
			#endregion
	//- - - - - - - - - - - - - 
            miTPO_SubMenu = new MenuItem { Header = "TPO Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			#region -- Show/Hide TPO lines -----------------
	//- - - - - - - - - - - - - 
			miVisualType_TPOSinglePrints = new MenuItem {Header = "TPO SinglePrints "+(pShowSinglePrintLines ? "ON" : "OFF"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_TPOSinglePrints.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShowSinglePrintLines = !pShowSinglePrintLines;
				var MI = (MenuItem)o;      MI.Header = "TPO SinglePrints "+(pShowSinglePrintLines ? "ON" : "OFF");
				ForceRefresh();
				};
			miVisualType_TPOSinglePrints.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				pShowSinglePrintLines = !pShowSinglePrintLines;
				var MI = (MenuItem)o;      MI.Header = "TPO SinglePrints "+(pShowSinglePrintLines ? "ON" : "OFF");
				ForceRefresh();
				};
			miTPO_SubMenu.Items.Add(miVisualType_TPOSinglePrints);
	//- - - - - - - - - - - - - 
			miVisualType_TPOVAH = new MenuItem {Header = "TPO VAH "+pVisualType_TPOVAH.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_TPOVAH.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_TPOVAH==ARC_MacroProfiles_VisualsType.Both)    pVisualType_TPOVAH = ARC_MacroProfiles_VisualsType.Dynamic;
				else if(pVisualType_TPOVAH==ARC_MacroProfiles_VisualsType.Dynamic) pVisualType_TPOVAH = ARC_MacroProfiles_VisualsType.Static;
				else if(pVisualType_TPOVAH==ARC_MacroProfiles_VisualsType.Static)  pVisualType_TPOVAH = ARC_MacroProfiles_VisualsType.None;
				else if(pVisualType_TPOVAH==ARC_MacroProfiles_VisualsType.None)    pVisualType_TPOVAH = ARC_MacroProfiles_VisualsType.Both;
				var MI = (MenuItem)o;      MI.Header = "TPO VAH "+pVisualType_TPOVAH.ToString();
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			miTPO_SubMenu.Items.Add(miVisualType_TPOVAH);
	//- - - - - - - - - - - - - 
			miVisualType_TPOPOC = new MenuItem {Header = "TPO POC "+pVisualType_TPOPOC.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_TPOPOC.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_TPOPOC==ARC_MacroProfiles_VisualsType.Both)    pVisualType_TPOPOC = ARC_MacroProfiles_VisualsType.Dynamic;
				else if(pVisualType_TPOPOC==ARC_MacroProfiles_VisualsType.Dynamic) pVisualType_TPOPOC = ARC_MacroProfiles_VisualsType.Static;
				else if(pVisualType_TPOPOC==ARC_MacroProfiles_VisualsType.Static)  pVisualType_TPOPOC = ARC_MacroProfiles_VisualsType.None;
				else if(pVisualType_TPOPOC==ARC_MacroProfiles_VisualsType.None)    pVisualType_TPOPOC = ARC_MacroProfiles_VisualsType.Both;
				var MI = (MenuItem)o;      MI.Header = "TPO POC "+pVisualType_TPOPOC.ToString();
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			miTPO_SubMenu.Items.Add(miVisualType_TPOPOC);
	//- - - - - - - - - - - - -
			miVisualType_TPOVAL = new MenuItem {Header = "TPO VAL "+pVisualType_TPOVAL.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_TPOVAL.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_TPOVAL==ARC_MacroProfiles_VisualsType.Both)    pVisualType_TPOVAL = ARC_MacroProfiles_VisualsType.Dynamic;
				else if(pVisualType_TPOVAL==ARC_MacroProfiles_VisualsType.Dynamic) pVisualType_TPOVAL = ARC_MacroProfiles_VisualsType.Static;
				else if(pVisualType_TPOVAL==ARC_MacroProfiles_VisualsType.Static)  pVisualType_TPOVAL = ARC_MacroProfiles_VisualsType.None;
				else if(pVisualType_TPOVAL==ARC_MacroProfiles_VisualsType.None)    pVisualType_TPOVAL = ARC_MacroProfiles_VisualsType.Both;
				var MI = (MenuItem)o;      MI.Header = "TPO VAL "+pVisualType_TPOVAL.ToString();
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			miTPO_SubMenu.Items.Add(miVisualType_TPOVAL);
	//- - - - - - - - - - - - -
			miTPO_VisualStyle = new MenuItem {Header = "TPO Style: Line "+pTPOLineThickness.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miTPO_VisualStyle.ToolTip = "Plot thickness:  Use mousewheel-up to increase, and mousewheel-down to decrease";
			miTPO_VisualStyle.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(miTPO_VisualStyle.Header.ToString().Contains("Dot")){
					miTPO_VisualStyle.Header = "TPO Style: Line "+pTPOLineThickness.ToString();
				}else{
					miTPO_VisualStyle.Header = "TPO Style: Dot "+pTPOLineThickness.ToString();
				}
				ForceRefresh();
				};
			miTPO_VisualStyle.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) pTPOLineThickness = pTPOLineThickness +1; else pTPOLineThickness = pTPOLineThickness-1;
				pTPOLineThickness = Math.Max(1,Math.Min(10,pTPOLineThickness));
				if(miTPO_VisualStyle.Header.ToString().Contains("Line")){
					miTPO_VisualStyle.Header = "TPO Style: Line "+pTPOLineThickness.ToString();
				}else{
					miTPO_VisualStyle.Header = "TPO Style: Dot "+pTPOLineThickness.ToString();
				}
				ForceRefresh();
			};
			miTPO_SubMenu.Items.Add(miTPO_VisualStyle);
	//- - - - - - - - - - - - - 
			miVisualType_TPOHisto = new MenuItem {Header = pShowTPO_Histo ? "Hide TPO Histo" : "Show TPO Histo", Foreground = Brushes.Black, FontWeight = FontWeights.Bold , StaysOpenOnClick = true };
			miVisualType_TPOHisto.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShowTPO_Histo = !pShowTPO_Histo;
				var MI = (MenuItem)o;     MI.Header = pShowTPO_Histo ? "Hide TPO Histo" : "Show TPO Histo";
				ForceRefresh();
				};
			miTPO_SubMenu.Items.Add(miVisualType_TPOHisto);
			#endregion -----------------------------------------
			MenuControl.Items.Add(miTPO_SubMenu);
	//- - - - - - - - - - - - - 
	//- - - - - - - - - - - - - 
			miVolProfile_SubMenu = new MenuItem { Header = "VolProfile Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			#region -- Show/Hide VolumeProfile lines -----------------
	//- - - - - - - - - - - - - 
			miVisualType_VPVAH = new MenuItem {Header = "VP VAH "+pVisualType_VPVAH.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_VPVAH.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_VPVAH==ARC_MacroProfiles_VisualsType.Both)    pVisualType_VPVAH = ARC_MacroProfiles_VisualsType.Dynamic;
				else if(pVisualType_VPVAH==ARC_MacroProfiles_VisualsType.Dynamic) pVisualType_VPVAH = ARC_MacroProfiles_VisualsType.Static;
				else if(pVisualType_VPVAH==ARC_MacroProfiles_VisualsType.Static)  pVisualType_VPVAH = ARC_MacroProfiles_VisualsType.None;
				else if(pVisualType_VPVAH==ARC_MacroProfiles_VisualsType.None)    pVisualType_VPVAH = ARC_MacroProfiles_VisualsType.Both;
				var MI = (MenuItem)o;      MI.Header = "VP VAH "+pVisualType_VPVAH.ToString();
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			miVolProfile_SubMenu.Items.Add(miVisualType_VPVAH);
	//- - - - - - - - - - - - - 
			miVisualType_VPPOC = new MenuItem {Header = "VP POC "+pVisualType_VPPOC.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_VPPOC.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_VPPOC==ARC_MacroProfiles_VisualsType.Both)    pVisualType_VPPOC = ARC_MacroProfiles_VisualsType.Dynamic;
				else if(pVisualType_VPPOC==ARC_MacroProfiles_VisualsType.Dynamic) pVisualType_VPPOC = ARC_MacroProfiles_VisualsType.Static;
				else if(pVisualType_VPPOC==ARC_MacroProfiles_VisualsType.Static)  pVisualType_VPPOC = ARC_MacroProfiles_VisualsType.None;
				else if(pVisualType_VPPOC==ARC_MacroProfiles_VisualsType.None)    pVisualType_VPPOC = ARC_MacroProfiles_VisualsType.Both;
				var MI = (MenuItem)o;      MI.Header = "VP POC "+pVisualType_VPPOC.ToString();
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			miVolProfile_SubMenu.Items.Add(miVisualType_VPPOC);
	//- - - - - - - - - - - - -
			miVisualType_VPVAL = new MenuItem {Header = "VP VAL "+pVisualType_VPVAL.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_VPVAL.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_VPVAL==ARC_MacroProfiles_VisualsType.Both)    pVisualType_VPVAL = ARC_MacroProfiles_VisualsType.Dynamic;
				else if(pVisualType_VPVAL==ARC_MacroProfiles_VisualsType.Dynamic) pVisualType_VPVAL = ARC_MacroProfiles_VisualsType.Static;
				else if(pVisualType_VPVAL==ARC_MacroProfiles_VisualsType.Static)  pVisualType_VPVAL = ARC_MacroProfiles_VisualsType.None;
				else if(pVisualType_VPVAL==ARC_MacroProfiles_VisualsType.None)    pVisualType_VPVAL = ARC_MacroProfiles_VisualsType.Both;
				var MI = (MenuItem)o;      MI.Header = "VP VAL "+pVisualType_VPVAL.ToString();
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			miVolProfile_SubMenu.Items.Add(miVisualType_VPVAL);
	//- - - - - - - - - - - - - 
			miVisualType_VPHisto = new MenuItem {Header = pShowVP_Histo ? "Hide VP Histo" : "Show VP Histo", Foreground = Brushes.Black, FontWeight = FontWeights.Bold , StaysOpenOnClick = true };
			miVisualType_VPHisto.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShowVP_Histo = !pShowVP_Histo;
				var MI = (MenuItem)o;     MI.Header = pShowVP_Histo ? "Hide VP Histo" : "Show VP Histo";
				ForceRefresh();
				};
			miVolProfile_SubMenu.Items.Add(miVisualType_VPHisto);
			#endregion --------------------------------------------------
			MenuControl.Items.Add(miVolProfile_SubMenu);
	//- - - - - - - - - - - - - 
	//- - - - - - - - - - - - - 
			miATRRRBox_SubMenu = new MenuItem { Header = "ATR+RR Box Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			#region -- Show/Hide RR and ATR box -----------------
	//- - - - - - - - - - - - - 
			miRR_Visuals = new MenuItem {Header = "RR Box "+(ShowRR_databox ? "ON":"OFF"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miRR_Visuals.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				ShowRR_databox = !ShowRR_databox;
				var MI = (MenuItem)o;      MI.Header = "RR Box "+(ShowRR_databox ? "ON":"OFF");
				ForceRefresh();
				};
			miATRRRBox_SubMenu.Items.Add(miRR_Visuals);
	//- - - - - - - - - - - - - 
			miATR_Visuals = new MenuItem {Header = "ATR Box "+(ShowATR_databox ? "ON":"OFF"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miATR_Visuals.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				ShowATR_databox = !ShowATR_databox;
				var MI = (MenuItem)o;      MI.Header = "ATR Box "+(ShowATR_databox ? "ON":"OFF");
				ForceRefresh();
				};
			miATRRRBox_SubMenu.Items.Add(miATR_Visuals);
	//- - - - - - - - - - - - - 
			miATRMode = new MenuItem {Header = "ATR Mode: "+ATRMode.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miATRMode.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(ATRMode == ARC_MacroProfiles_ATRModeEnum.Points) ATRMode = ARC_MacroProfiles_ATRModeEnum.Ticks;
				else if(ATRMode == ARC_MacroProfiles_ATRModeEnum.Ticks) ATRMode = ARC_MacroProfiles_ATRModeEnum.Points;
				var MI = (MenuItem)o;      MI.Header = "ATR Mode: "+ATRMode.ToString();
				ForceRefresh();
				};
			miATRRRBox_SubMenu.Items.Add(miATRMode);

	//- - - - - - - - - - - - - 
			#endregion --------------------------------------------------
			MenuControl.Items.Add(miATRRRBox_SubMenu);
	//- - - - - - - - - - - - - 
			miHVNLVNBox_SubMenu = new MenuItem { Header = "HVN/LVN Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			#region -- HVN/LVN visual type --
			miVisualType_HVN = new MenuItem {Header = "HVN: "+pVisualType_HVN.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_HVN.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Half;
				else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Full;
				else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Extended;
				else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Dot;
				else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				miVisualType_HVN.Header = "HVN: "+pVisualType_HVN.ToString();
				HVNLVN_AreVisible =	pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				if(pVisualType_HVN == ARC_MacroProfiles_VisualsType_HNLN.Extended)
					InitialzeVolNodeTerminationStates();
#if HTO_LTO
				HVNLVN_AreVisible = HVNLVN_AreVisible || 
									pVisualType_HTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#endif
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			miVisualType_HVN.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if     (pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Half;
					else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Full;
					else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Extended;
					else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Dot;
					else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				}else{
					if     (pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Dot;
					else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Extended;
					else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Full;
					else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Half;
					else if(pVisualType_HVN==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_HVN = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				}
				miVisualType_HVN.Header = "HVN: "+pVisualType_HVN.ToString();
				HVNLVN_AreVisible =	pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				if(pVisualType_HVN == ARC_MacroProfiles_VisualsType_HNLN.Extended)
					InitialzeVolNodeTerminationStates();
#if HTO_LTO
				HVNLVN_AreVisible = HVNLVN_AreVisible || 
									pVisualType_HTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#endif
				ForceRefresh();
			};
			miHVNLVNBox_SubMenu.Items.Add(miVisualType_HVN);
	//- - - - - - - - - - - - -
			miVisualType_LVN = new MenuItem {Header = "LVN: "+pVisualType_LVN.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_LVN.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Half;
				else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Full;
				else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Extended;
				else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Dot;
				else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				miVisualType_LVN.Header = "LVN: "+pVisualType_LVN.ToString();
				HVNLVN_AreVisible =	pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Extended)
					InitialzeVolNodeTerminationStates();
#if HTO_LTO
				HVNLVN_AreVisible = HVNLVN_AreVisible || 
									pVisualType_HTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#endif
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			miVisualType_LVN.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if     (pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Half;
					else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Full;
					else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Extended;
					else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Dot;
					else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				}else{
					if     (pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Dot;
					else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Extended;
					else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Full;
					else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Half;
					else if(pVisualType_LVN==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_LVN = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				}
				miVisualType_LVN.Header = "LVN: "+pVisualType_LVN.ToString();
				HVNLVN_AreVisible =	pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Extended)
					InitialzeVolNodeTerminationStates();
#if HTO_LTO
				HVNLVN_AreVisible = HVNLVN_AreVisible || 
									pVisualType_HTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#endif
				ForceRefresh();
			};
			miHVNLVNBox_SubMenu.Items.Add(miVisualType_LVN);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- HVN/LVN Significance --
			miSignificance_HVN_LVN = new MenuItem {Header = "HVN/LVN Signifcance: "+pSignificance_HVN_LVN.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miSignificance_HVN_LVN.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pSignificance_HVN_LVN++;
				miSignificance_HVN_LVN.Header = "HVN/LVN Signifcance: "+pSignificance_HVN_LVN.ToString();
				RemoveAllGlobal_LVN_Zones();
				RemoveAllGlobal_HVN_Zones();
				foreach(var profile in Prof){
					profile.Value.Calc_HVN_LVN(this.pSignificance_HVN_LVN, pHighlightHVNLVN_Region, pHighlightHVNLVN_RegionSize, pTicksPerHistoBar, this);
				}
				InitialzeVolNodeTerminationStates();
				ForceRefresh();
				};
			miSignificance_HVN_LVN.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0) pSignificance_HVN_LVN++;
				else pSignificance_HVN_LVN--;
				pSignificance_HVN_LVN = Math.Max(1,pSignificance_HVN_LVN);
				miSignificance_HVN_LVN.Header = "HVN/LVN Signifcance: "+pSignificance_HVN_LVN.ToString();
				RemoveAllGlobal_LVN_Zones();
				RemoveAllGlobal_HVN_Zones();
				foreach(var profile in Prof){
					profile.Value.Calc_HVN_LVN(this.pSignificance_HVN_LVN, pHighlightHVNLVN_Region, pHighlightHVNLVN_RegionSize, pTicksPerHistoBar, this);
				}
				InitialzeVolNodeTerminationStates();
				ForceRefresh();
				};
			miHVNLVNBox_SubMenu.Items.Add(miSignificance_HVN_LVN);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- HVN/LVN Region Size --
			miRegionSize_HVN_LVN = new MenuItem {Header = "Region Size: "+pHighlightHVNLVN_RegionSize.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miRegionSize_HVN_LVN.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pHighlightHVNLVN_RegionSize++;
				miRegionSize_HVN_LVN.Header = "Region Size: "+pHighlightHVNLVN_RegionSize.ToString();
				RemoveAllGlobal_LVN_Zones();
				RemoveAllGlobal_HVN_Zones();
				foreach(var profile in Prof)
					profile.Value.Calc_HVN_LVN(this.pSignificance_HVN_LVN, pHighlightHVNLVN_Region, pHighlightHVNLVN_RegionSize, pTicksPerHistoBar, this);
				InitialzeVolNodeTerminationStates();
				ForceRefresh();
				};
			miRegionSize_HVN_LVN.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0) pHighlightHVNLVN_RegionSize++;
				else pHighlightHVNLVN_RegionSize--;
				pHighlightHVNLVN_RegionSize = Math.Max(0,pHighlightHVNLVN_RegionSize);
				miRegionSize_HVN_LVN.Header = "Region Size: "+pHighlightHVNLVN_RegionSize.ToString();
				RemoveAllGlobal_LVN_Zones();
				RemoveAllGlobal_HVN_Zones();
				foreach(var profile in Prof)
					profile.Value.Calc_HVN_LVN(this.pSignificance_HVN_LVN, pHighlightHVNLVN_Region, pHighlightHVNLVN_RegionSize, pTicksPerHistoBar, this);
				InitialzeVolNodeTerminationStates();
				ForceRefresh();
				};
			miHVNLVNBox_SubMenu.Items.Add(miRegionSize_HVN_LVN);
			#endregion
	//- - - - - - - - - - - - - 
#if HTO_LTO
			#region -- HTO/LTO visual type --
			miVisualType_HTO = new MenuItem {Header = "HTO: "+pVisualType_HTO.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_HTO.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Half;
				else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Full;
				else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Extended;
				else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Dot;
				else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				miVisualType_HTO.Header = "HTO: "+pVisualType_HTO.ToString();
				HVNLVN_AreVisible =	pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#if HTO_LTO
				HVNLVN_AreVisible = HVNLVN_AreVisible || 
									pVisualType_HTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#endif
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			miVisualType_HTO.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if     (pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Half;
					else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Full;
					else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Extended;
					else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Dot;
					else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				}else{
					if     (pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Dot;
					else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Extended;
					else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Full;
					else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Half;
					else if(pVisualType_HTO==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_HTO = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				}
				miVisualType_HTO.Header = "HTO: "+pVisualType_HTO.ToString();
				HVNLVN_AreVisible =	pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#if HTO_LTO
				HVNLVN_AreVisible = HVNLVN_AreVisible || 
									pVisualType_HTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#endif
				ForceRefresh();
			};

			miHVNLVNBox_SubMenu.Items.Add(miVisualType_HTO);
	//- - - - - - - - - - - - -
			miVisualType_LTO = new MenuItem {Header = "LTO: "+pVisualType_LTO.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_LTO.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Half;
				else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Full;
				else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Extended;
				else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Dot;
				else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				miVisualType_LTO.Header = "LTO: "+pVisualType_LTO.ToString();
				HVNLVN_AreVisible =	pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#if HTO_LTO
				HVNLVN_AreVisible = HVNLVN_AreVisible || 
									pVisualType_HTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#endif
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			miVisualType_LTO.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if     (pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Half;
					else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Full;
					else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Extended;
					else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Dot;
					else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				}else{
					if     (pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Hidden)   pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Dot;
					else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Dot)      pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Extended;
					else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Extended) pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Full;
					else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Full)     pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Half;
					else if(pVisualType_LTO==ARC_MacroProfiles_VisualsType_HNLN.Half)     pVisualType_LTO = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				}
				miVisualType_LTO.Header = "LTO: "+pVisualType_LTO.ToString();
				HVNLVN_AreVisible =	pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#if HTO_LTO
				HVNLVN_AreVisible = HVNLVN_AreVisible || 
									pVisualType_HTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#endif
				ForceRefresh();
			};
			miHVNLVNBox_SubMenu.Items.Add(miVisualType_LTO);
			#endregion
#endif
	//- - - - - - - - - - - - -
			#region -- Show/Hide VN's on current profile --
			miVisualType_CurrentProfileVNs = new MenuItem {Header = (pShow_CurrentProfileVN ? "HIDE CurProf VN" : "SHOW CurProf VN"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_CurrentProfileVNs.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShow_CurrentProfileVN = !pShow_CurrentProfileVN;
				miVisualType_CurrentProfileVNs.Header = (pShow_CurrentProfileVN ? "HIDE CurProf VN" : "SHOW CurProf VN");
				if(!pShow_CurrentProfileVN){
					RemoveAllGlobal_LVN_Zones(Prof.Keys.Max());
					RemoveAllGlobal_HVN_Zones(Prof.Keys.Max());
				}else{
					CreateAndDrawAllGlobal_LVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
					CreateAndDrawAllGlobal_HVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
				}
				MM.obj_count = CalculateCountOfGlobalObjects();
				ForceRefresh();
				};
			miVisualType_CurrentProfileVNs.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				pShow_CurrentProfileVN = !pShow_CurrentProfileVN;
				miVisualType_CurrentProfileVNs.Header = (pShow_CurrentProfileVN ? "HIDE CurProf VN" : "SHOW CurProf VN");
				if(!pShow_CurrentProfileVN){
					RemoveAllGlobal_LVN_Zones(Prof.Keys.Max());
					RemoveAllGlobal_HVN_Zones(Prof.Keys.Max());
				}else{
					CreateAndDrawAllGlobal_LVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
					CreateAndDrawAllGlobal_HVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
				}
				MM.obj_count = CalculateCountOfGlobalObjects();
				ForceRefresh();
			};
			miHVNLVNBox_SubMenu.Items.Add(miVisualType_CurrentProfileVNs);
			#endregion
	//- - - - - - - - - - - - -
			#region -- Show/Hide VN's on historical profile --
			miVisualType_HistoricalProfileVNs = new MenuItem {Header = (pShow_HistoricalProfileVN ? "HIDE HistProf VN" : "SHOW HistProf VN"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_HistoricalProfileVNs.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShow_HistoricalProfileVN = !pShow_HistoricalProfileVN;
				miVisualType_HistoricalProfileVNs.Header = (pShow_HistoricalProfileVN ? "HIDE HistProf VN" : "SHOW HistProf VN");
				if(!pShow_HistoricalProfileVN){
					foreach(var p in Prof){
						if(p.Key < Prof.Keys.Max()){
							RemoveAllGlobal_LVN_Zones(p.Key);
							RemoveAllGlobal_HVN_Zones(p.Key);
						}
					}
				}else{
					CreateAndDrawAllGlobal_LVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
					CreateAndDrawAllGlobal_HVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
				}
				MM.obj_count = CalculateCountOfGlobalObjects();
				ForceRefresh();
				};
			miVisualType_HistoricalProfileVNs.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				pShow_HistoricalProfileVN = !pShow_HistoricalProfileVN;
				miVisualType_HistoricalProfileVNs.Header = (pShow_HistoricalProfileVN ? "HIDE HistProf VN" : "SHOW HistProf VN");
				if(!pShow_HistoricalProfileVN){
					foreach(var p in Prof){
						if(p.Key < Prof.Keys.Max()){
							RemoveAllGlobal_LVN_Zones(p.Key);
							RemoveAllGlobal_HVN_Zones(p.Key);
						}
					}
				}else{
					CreateAndDrawAllGlobal_LVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
					CreateAndDrawAllGlobal_HVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
				}
				MM.obj_count = CalculateCountOfGlobalObjects();
				ForceRefresh();
			};
			miHVNLVNBox_SubMenu.Items.Add(miVisualType_HistoricalProfileVNs);
			#endregion
			MenuControl.Items.Add(miHVNLVNBox_SubMenu);
	//- - - - - - - - - - - - - 
			#region -- VWAP visual type --
			miVisualType_VWAP = new MenuItem {Header = "VWAP "+pVisualType_VWAP.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miVisualType_VWAP.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pVisualType_VWAP==ARC_MacroProfiles_VisualsType.Both)    pVisualType_VWAP = ARC_MacroProfiles_VisualsType.Dynamic;
				else if(pVisualType_VWAP==ARC_MacroProfiles_VisualsType.Dynamic) pVisualType_VWAP = ARC_MacroProfiles_VisualsType.Static;
				else if(pVisualType_VWAP==ARC_MacroProfiles_VisualsType.Static)  pVisualType_VWAP = ARC_MacroProfiles_VisualsType.None;
				else if(pVisualType_VWAP==ARC_MacroProfiles_VisualsType.None)    pVisualType_VWAP = ARC_MacroProfiles_VisualsType.Both;
				var MI = (MenuItem)o;      MI.Header = "VWAP "+pVisualType_VWAP.ToString();
				ForceRefresh();
//				PrintNew1(e.Source.ToString());
				};
			MenuControl.Items.Add(miVisualType_VWAP);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Auto scale Histo Width --
//			var miAutoScaleHistoWidth = new MenuItem {Header = pAutoScaleHistoWidth ? "Free-float Histo width" : "Auto-scale Histo width", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
//			miAutoScaleHistoWidth.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
//				pAutoScaleHistoWidth = !pAutoScaleHistoWidth;
//				var MI = (MenuItem)o;     MI.Header = pAutoScaleHistoWidth ? "Free-float Histo width" : "Auto-scale Histo width";
//				ForceRefresh();
//				};
//			MenuControl.Items.Add(miAutoScaleHistoWidth);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Show/Hide PriceBars --
			var miShowHide_PriceBars = new MenuItem {Header = pPriceBarSetting==ARC_MacroProfiles_PriceBarSetting.Hide ? "Hiding PriceBars" : (pPriceBarSetting==ARC_MacroProfiles_PriceBarSetting.BarsInFront ? "Bars In Front" : "Bars Behind"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_PriceBars.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(pPriceBarSetting==ARC_MacroProfiles_PriceBarSetting.Hide)             pPriceBarSetting = ARC_MacroProfiles_PriceBarSetting.BarsInFront;
				else if(pPriceBarSetting==ARC_MacroProfiles_PriceBarSetting.BarsInFront) pPriceBarSetting = ARC_MacroProfiles_PriceBarSetting.BarsBehind;
				else if(pPriceBarSetting==ARC_MacroProfiles_PriceBarSetting.BarsBehind)  pPriceBarSetting = ARC_MacroProfiles_PriceBarSetting.Hide;

				var MI = (MenuItem)o;     MI.Header = (pPriceBarSetting==ARC_MacroProfiles_PriceBarSetting.Hide ? "Hiding PriceBars" : (pPriceBarSetting==ARC_MacroProfiles_PriceBarSetting.BarsInFront ? "Bars In Front" : "Bars Behind"));
				if(pPriceBarSetting == ARC_MacroProfiles_PriceBarSetting.Hide){
					ChartBars.Properties.ChartStyle.UpBrush			= Brushes.Transparent;
					ChartBars.Properties.ChartStyle.DownBrush		= Brushes.Transparent;
					ChartBars.Properties.ChartStyle.Stroke.Brush	= Brushes.Transparent;
					ChartBars.Properties.ChartStyle.Stroke2.Brush	= Brushes.Transparent;
				}else{
					if(!EqualColor(Brushes.Transparent, CandleBodyUpBrush) && !EqualColor(CandleBodyUpBrush, ChartBars.Properties.ChartStyle.UpBrush))
						ChartBars.Properties.ChartStyle.UpBrush			= CandleBodyUpBrush;
					if(!EqualColor(Brushes.Transparent, CandleBodyDownBrush) && !EqualColor(CandleBodyDownBrush, ChartBars.Properties.ChartStyle.DownBrush))
						ChartBars.Properties.ChartStyle.DownBrush		= CandleBodyDownBrush;
					if(!EqualColor(Brushes.Transparent, CandleOutlineBrush) && !EqualColor(CandleOutlineBrush, ChartBars.Properties.ChartStyle.Stroke.Brush))
						ChartBars.Properties.ChartStyle.Stroke.Brush	= CandleOutlineBrush;
					if(!EqualColor(Brushes.Transparent, CandleWickBrush) && !EqualColor(CandleWickBrush, ChartBars.Properties.ChartStyle.Stroke2.Brush))
						ChartBars.Properties.ChartStyle.Stroke2.Brush	= CandleWickBrush;

					if (this.pPriceBarSetting == ARC_MacroProfiles_PriceBarSetting.BarsInFront){
		                SetZOrder(-1);
						TriggerCustomEvent(o1 =>{	Draw.Dot(this,"zordersetting",false,-2,0,Brushes.Transparent);	RemoveThisTag("zordersetting");},0,null);
					}else if (this.pPriceBarSetting == ARC_MacroProfiles_PriceBarSetting.BarsBehind){
		                SetZOrder(int.MaxValue);
						TriggerCustomEvent(o2 =>{	Draw.Dot(this,"zordersetting",false,-2,0,Brushes.Transparent);	RemoveThisTag("zordersetting");},0,null);
					}
				}
				ForceRefresh();
			};
			MenuControl.Items.Add(miShowHide_PriceBars);
			#endregion
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			#region -- Ticks per histo bar --
			miTicksPerHistoBar = new MenuItem {Header = this.pTicksPerHistoBar.ToString()+"-ticks per histo bar", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miTicksPerHistoBar.ToolTip = "Use mousewheel-up to increase, and mousewheel-down to decrease";
			miTicksPerHistoBar.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				Draw.TextFixed(this, "DataLoadingMsg", "Thickness of histo bars change is in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				if(e.Delta>0)
					pTicksPerHistoBar++;
				else
					pTicksPerHistoBar--;
				if(pTicksPerHistoBar<1) pTicksPerHistoBar = 1;

				RemoveAllGlobal_LVN_Zones();
				RemoveAllGlobal_HVN_Zones();
				miTicksPerHistoBar.Header = this.pTicksPerHistoBar.ToString()+"-ticks per histo bar";
				InformUserAboutRecalculation();
			};
			MenuControl.Items.Add(miTicksPerHistoBar);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Recalc Profiles --
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE Profiles", HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				Draw.TextFixed(this, "DataLoadingMsg", "Reclaculating profiles in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			MenuControl.Items.Add(miRecalculate1);
			#endregion
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			#region -- Permit VAH Rays + ArbZones --
			miPermitVAHRaysZones = new MenuItem {Header = "VAH objects:   "+(pPermitVAHRaysZones ? "ON":"OFF"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miPermitVAHRaysZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				pPermitVAHRaysZones = !pPermitVAHRaysZones;
				miPermitVAHRaysZones.Header = "VAH objects:   "+(pPermitVAHRaysZones ? "ON":"OFF");
				if(!pPermitVAHRaysZones && Prof.Count>0){
					DeleteTheseZones(Prof.Keys.ToList(), RES_ID, this.Global_Arb_Rects);
					DeleteTheseRays(RES_ID, this.Global_VAHL_Rays);
				}
				ForceRefresh();
				};
			miPermitVAHRaysZones.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				pPermitVAHRaysZones = !pPermitVAHRaysZones;
				miPermitVAHRaysZones.Header = "VAH objects:   "+(pPermitVAHRaysZones ? "ON":"OFF");
				if(!pPermitVAHRaysZones && Prof.Count>0){
					DeleteTheseZones(Prof.Keys.ToList(), RES_ID, this.Global_Arb_Rects);
					DeleteTheseRays(RES_ID, this.Global_VAHL_Rays);
				}
				ForceRefresh();
				};
			MenuControl.Items.Add(miPermitVAHRaysZones);
			#endregion
			#region -- Permit VAL Rays + ArbZones --
			miPermitVALRaysZones = new MenuItem {Header = "VAL objects:   "+(pPermitVALRaysZones ? "ON":"OFF"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miPermitVALRaysZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				pPermitVALRaysZones = !pPermitVALRaysZones;
				miPermitVALRaysZones.Header = "VAL objects:   "+(pPermitVALRaysZones ? "ON":"OFF");
				if(!pPermitVALRaysZones && Prof.Count>0){
					DeleteTheseZones(Prof.Keys.ToList(), SUP_ID, this.Global_Arb_Rects);
					DeleteTheseRays(SUP_ID, this.Global_VAHL_Rays);
				}
				ForceRefresh();
				};
			miPermitVALRaysZones.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				pPermitVALRaysZones = !pPermitVALRaysZones;
				miPermitVALRaysZones.Header = "VAL objects:   "+(pPermitVALRaysZones ? "ON":"OFF");
				if(!pPermitVALRaysZones && Prof.Count>0){
					DeleteTheseZones(Prof.Keys.ToList(), SUP_ID, this.Global_Arb_Rects);
					DeleteTheseRays(SUP_ID, this.Global_VAHL_Rays);
				}
				ForceRefresh();
				};
			MenuControl.Items.Add(miPermitVALRaysZones);
			#endregion
	//- - - - - - - - - - - - - 
			var miZones_SubMenu = new MenuItem { Header = "Zones Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			#region -- Show_LVNZones --
//			if(pEnableParameterCaching)	pShow_LVNZones = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("ShowLVNZones") : false);
//			miShowHide_LVNZones = new MenuItem {Header = pShow_LVNZones ? "Hide LVN Zones" : "Show LVN Zones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
//			miShowHide_LVNZones.Click += delegate (object o, RoutedEventArgs e){
////				e.Handled = true;
//				pShow_LVNZones = !pShow_LVNZones;
//				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("ShowLVNZones", pShow_LVNZones);
//				ShowZonesClickedJustNow = true;
//				miShowHide_LVNZones.Header = pShow_LVNZones ? "Hide LVN Zones" : "Show LVN Zones";
//				if(!pShow_LVNZones)
//					RemoveAllGlobal_LVN_Zones();
//				ForceRefresh();
//				};
//			miZones_SubMenu.Items.Add(miShowHide_LVNZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Show_FreshZones --
			if(pEnableParameterCaching)	pShow_FreshZones = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("ShowFreshZones") : false);
			miShowHide_FreshZones = new MenuItem {Header = pShow_FreshZones ? "Hide FreshZones" : "Show FreshZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_FreshZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				pShow_FreshZones = !pShow_FreshZones;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("ShowFreshZones", pShow_FreshZones);
				ShowZonesClickedJustNow = true;
				miShowHide_FreshZones.Header = pShow_FreshZones ? "Hide FreshZones" : "Show FreshZones";
				ForceRefresh();
				};
			miZones_SubMenu.Items.Add(miShowHide_FreshZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Show_BrokenZones --
			if(pEnableParameterCaching) pShow_BrokenZones = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("ShowBrokenZones") : false);
			miShowHide_BrokenZones = new MenuItem {Header = pShow_BrokenZones ? "Hide BrokenZones" : "Show BrokenZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_BrokenZones.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled = true;
				pShow_BrokenZones = !pShow_BrokenZones;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("ShowBrokenZones", pShow_BrokenZones);
				ShowZonesClickedJustNow = true;
				miShowHide_BrokenZones.Header = pShow_BrokenZones ? "Hide BrokenZones" : "Show BrokenZones";
				ForceRefresh();
				};
			miZones_SubMenu.Items.Add(miShowHide_BrokenZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Show_TestedZones --
			if(pEnableParameterCaching) pShow_TestedZones = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("ShowTestedZones") : false);
			miShowHide_TestedZones = new MenuItem {Header = pShow_TestedZones ? "Hide TestedZones" : "Show TestedZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_TestedZones.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled = true;
				pShow_TestedZones = !pShow_TestedZones;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("ShowTestedZones", pShow_TestedZones);
				ShowZonesClickedJustNow = true;
				miShowHide_TestedZones.Header = pShow_TestedZones ? "Hide TestedZones" : "Show TestedZones";
				ForceRefresh();
				};
			miZones_SubMenu.Items.Add(miShowHide_TestedZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- ShowHide_ResistanceZones --
			if(pEnableParameterCaching) pPermit_ResistanceZones = (ConfigMgr!=null ? !ConfigMgr.DetermineStatus("HideAllResistanceZones") : false);
			miShowHide_ResistanceZones = new MenuItem {Header = pPermit_ResistanceZones ? "Hide All ResistanceZones" : "Permit ResistanceZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_ResistanceZones.Click += delegate (object o, RoutedEventArgs e){
				pPermit_ResistanceZones = !pPermit_ResistanceZones;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("HideAllResistanceZones", !pPermit_ResistanceZones);
				ShowZonesClickedJustNow = true;
				miShowHide_ResistanceZones.Header = pPermit_ResistanceZones ? "Hide All ResistanceZones" : "Permit All ResistanceZones";
				ForceRefresh();
				};
			miZones_SubMenu.Items.Add(miShowHide_ResistanceZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- ShowHide_SupportZones --
			if(pEnableParameterCaching) pPermit_SupportZones = (ConfigMgr!=null ? !ConfigMgr.DetermineStatus("HideAllSupportZones") : false);
			miShowHide_SupportZones = new MenuItem {Header = pPermit_SupportZones ? "Hide All SupportZones" : "Permit SupportZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_SupportZones.Click += delegate (object o, RoutedEventArgs e){
				pPermit_SupportZones = !pPermit_SupportZones;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("HideAllSupportZones", !pPermit_SupportZones);
				ShowZonesClickedJustNow = true;
				miShowHide_SupportZones.Header = pPermit_SupportZones ? "Hide All SupportZones" : "Permit SupportZones";
				ForceRefresh();
				};
			miZones_SubMenu.Items.Add(miShowHide_SupportZones);
			#endregion
	//- - - - - - - - - - - - - 
#if DETERMINE_DISQUALIFIED_ARBZONES
			#region -- Show_DisqualifiedZones --
			if(pEnableParameterCaching) pShow_DisqZones = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("ShowDisqZones") : false);
			miShowHide_DisqZones = new MenuItem {Header = pShow_DisqZones ? "Hide DisqualifiedZones" : "Show DisqualifiedZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_DisqZones.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled = true;
				pShow_DisqZones = !pShow_DisqZones;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("ShowDisqZones", pShow_DisqZones);
				ShowZonesClickedJustNow = true;
				miShowHide_DisqZones.Header = pShow_DisqZones ? "Hide DisqualifiedZones" : "Show DisqualifiedZones";
				if(pShow_DisqZones) this.DetermineDisqualifiedZones(0);
				ForceRefresh();
				};
			miZones_SubMenu.Items.Add(miShowHide_DisqZones);
			#endregion
#endif
	//- - - - - - - - - - - - - 
			#region -- Show_OverlappedZones --
			if(pEnableParameterCaching) pShow_OverlappedZones = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("ShowOverlappedZones") : false);
			miShowHide_OverlappedZones = new MenuItem {Header = pShow_OverlappedZones ? "Hide OverlappedZones" : "Show OverlappedZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_OverlappedZones.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled = true;
				pShow_OverlappedZones = !pShow_OverlappedZones;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("ShowOverlappedZones", pShow_OverlappedZones);
				ShowZonesClickedJustNow = true;
				miShowHide_OverlappedZones.Header = pShow_OverlappedZones ? "Hide OverlappedZones" : "Show OverlappedZones";
				ForceRefresh();
				};
			miZones_SubMenu.Items.Add(miShowHide_OverlappedZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Show_ZonePrices --
			if(pEnableParameterCaching) pShow_ZonePrices = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("ShowZonePrices") : false);
			miShowHide_ZonePrices = new MenuItem {Header = pShow_ZonePrices ? "Hide Zone Prices" : "Show Zone Prices", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_ZonePrices.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled = true;
				pShow_ZonePrices = !pShow_ZonePrices;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("ShowZonePrices", pShow_ZonePrices);
				var MI = (MenuItem)o;     MI.Header = pShow_ZonePrices ? "Hide Zone Prices" : "Show Zone Prices";
				ForceRefresh();
				};
			miZones_SubMenu.Items.Add(miShowHide_ZonePrices);
			#endregion
			MenuControl.Items.Add(miZones_SubMenu);
	//- - - - - - - - - - - - - 
			#region -- Permit CurrentSessionZones --
			if(pEnableParameterCaching) pShow_CurrentSessionZones = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("ShowCurSesZs") : false);
			miShow_CurrentSessionZones = new MenuItem {Header = "CurrentSession Zones:  "+(pShow_CurrentSessionZones ? "ON" : "OFF"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShow_CurrentSessionZones.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled = true;
				pShow_CurrentSessionZones = !pShow_CurrentSessionZones;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("ShowCurSesZs", pShow_CurrentSessionZones);
				miShow_CurrentSessionZones.Header = "CurrentSession Zones:  "+(pShow_CurrentSessionZones ? "ON" : "OFF");
				ForceRefresh();
				};
			MenuControl.Items.Add(miShow_CurrentSessionZones);
			#endregion
	//- - - - - - - - - - - - - 
			var miZoneGlobal_SubMenu = new MenuItem { Header = "Zone Global Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			#region -- miGlobalize_HVNZones --
			miGlobalize_HVNZones = new MenuItem {Header = "Globalize HVN Zones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["HVN"] = false;
			miGlobalize_HVNZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["HVN"] = !IsGlobalized["HVN"];
				if(!IsGlobalized["HVN"]){
					RemoveAllGlobal_HVN_Zones();
				} else {
//					if(!pShow_HVNZones) {
//						pShow_HVNZones = true;
//						miShowHide_HVNZones.Header = "Hide HVN Zones";
//						ShowZonesClickedJustNow = true;
//					}
//					if(pShow_HVNZones)
					{
line=3456;
						#region -- enable globals UI --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content   = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						CreateAndDrawAllGlobal_HVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
						MM.obj_count = CalculateCountOfGlobalObjects();
					}
				}
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_HVNZones);
			#endregion
			#region -- miGlobalize_LVNZones --
			miGlobalize_LVNZones = new MenuItem {Header = "Globalize LVN Zones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["LVN"] = false;
			miGlobalize_LVNZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["LVN"] = !IsGlobalized["LVN"];
				if(!IsGlobalized["LVN"]){
					RemoveAllGlobal_LVN_Zones();
				} else {
//					if(!pShow_LVNZones) {
//						pShow_LVNZones = true;
//						miShowHide_LVNZones.Header = "Hide LVN Zones";
//						ShowZonesClickedJustNow = true;
//					}
//					if(pShow_LVNZones)
					{
line=3488;
						#region -- enable globals UI --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content   = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						CreateAndDrawAllGlobal_LVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
						MM.obj_count = CalculateCountOfGlobalObjects();
					}
				}
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_LVNZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Globalize_FreshZones --
			miGlobalize_FreshZones = new MenuItem {Header = "Globalize FreshZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["F"] = false;
			miGlobalize_FreshZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["F"] = !IsGlobalized["F"];
				if(!IsGlobalized["F"]){
					#region -- Delete all Fresh global arbzones --
					var profs = Prof.Where(x=> x.Value.Zones.ContainsKey(RES_ID) && x.Value.Zones[RES_ID].Disposition=='F').Select(x=> x.Key).ToList();
					if(profs!=null && profs.Count>0) DeleteTheseZones(profs, 'R', Global_Arb_Rects);
					profs = Prof.Where(x=> x.Value.Zones.ContainsKey(SUP_ID) && x.Value.Zones[SUP_ID].Disposition=='F').Select(x=> x.Key).ToList();
					if(profs!=null && profs.Count>0) DeleteTheseZones(profs, 'S', Global_Arb_Rects);
					#endregion ---------------------------------
				} else {
					if(!pShow_FreshZones) {
						pShow_FreshZones = true;
						this.miShowHide_FreshZones.Header = "Hide FreshZones";
						ShowZonesClickedJustNow = true;
					}
					if(pShow_FreshZones){
line=3525;
						ResetArbZoneDispositionFlags(0);
						CheckArbZoneTouchOrBreak(0);
						DetermineOverlappedZones(0);
						DetermineDisqualifiedZones(0);
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						#region -- See if the user is selecting a fresh zone ---------------------------------------------------------
						var plist = Prof.Where(k => 
								   k.Value.Zones.ContainsKey(RES_ID) 
								&& k.Value.Zones[            RES_ID].Disposition=='F').ToList();
						if(this.pPermit_ResistanceZones && pPermitVAHRaysZones && plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(pShow_CurrentSessionZones){
									if(p.Key== Prof.Keys.Max()) continue;
								}else if(p.Key >= FirstProfileIdOfCurrentSession) continue;
								foreach(var z in p.Value.Zones){
									if(z.Key!=RES_ID) continue;
									var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, p.Key, 'R', z.Value.HighPrice);
									int endbar = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									Global_Arb_Rects[tag] = new Global_RectsData(p.Value.StartABar,
													BarsArray[0].GetTime(p.Value.StartABar), 
													z.Value.HighPrice, 
													endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar), 
													z.Value.LowPrice, 
													(p.Key>=this.FirstProfileIdOfCurrentSession ? pcResZone_Template : phResZone_Template), 
													'R');
									ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//PrintNew1("Created R rect at "+tag+"  "+Global_Arb_Rects[tag].ToString());
								}
							}
						}
						plist.Clear();
						plist = Prof.Where(k => 
								   k.Value.Zones.ContainsKey(SUP_ID) 
								&& k.Value.Zones[            SUP_ID].Disposition=='F').ToList();
						if(this.pPermit_SupportZones && pPermitVALRaysZones && plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(pShow_CurrentSessionZones){
									if(p.Key== Prof.Keys.Max()) continue;
								}else if(p.Key >= FirstProfileIdOfCurrentSession) continue;
								foreach(var z in p.Value.Zones){
									if(z.Key!=SUP_ID) continue;
									var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, p.Key, 'S', z.Value.HighPrice);
									int endbar = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									Global_Arb_Rects[tag] = new Global_RectsData(p.Value.StartABar,
													BarsArray[0].GetTime(p.Value.StartABar+1), 
													z.Value.HighPrice, 
													endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
													z.Value.LowPrice,
													(p.Key>=this.FirstProfileIdOfCurrentSession ? pcSupZone_Template : phSupZone_Template), 
													'S');
									ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//if(IsDebug) PrintNew1(string.Format("SUP Zone identified: {0}-{1}  H: {2} L: {3}", MM.SelectedArbZoneData[0], (MM.SelectedArbZoneData[2]==int.MaxValue ? "unending":MM.SelectedArbZoneData[2].ToString()), MM.SelectedArbZoneData[1], MM.SelectedArbZoneData[3]));
								}
							}
						}
						#endregion
						MM.obj_count = CalculateCountOfGlobalObjects();
					}
				}
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_FreshZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Globalize_BrokenZones --
			miGlobalize_BrokenZones = new MenuItem {Header = "Globalize BrokenZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["B"] = false;
			miGlobalize_BrokenZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["B"] = !IsGlobalized["B"];
				if(!IsGlobalized["B"]){
					#region -- Delete all broken global arbzones --
					var profs = Prof.Where(x=> x.Value.Zones.ContainsKey(RES_ID) && x.Value.Zones[RES_ID].Disposition=='B').Select(x=> x.Key).ToList();
					if(profs!=null && profs.Count>0) DeleteTheseZones(profs, 'R', Global_Arb_Rects);
					profs = Prof.Where(x=> x.Value.Zones.ContainsKey(SUP_ID) && x.Value.Zones[SUP_ID].Disposition=='B').Select(x=> x.Key).ToList();
					if(profs!=null && profs.Count>0) DeleteTheseZones(profs, 'S', Global_Arb_Rects);
					#endregion ---------------------------------
				} else {
					if(!pShow_BrokenZones) {
						pShow_BrokenZones = true;
						this.miShowHide_BrokenZones.Header = "Hide BrokenZones";
						ShowZonesClickedJustNow = true;
					}
line=3615;
					if(pShow_BrokenZones){
						ResetArbZoneDispositionFlags(0);
						CheckArbZoneTouchOrBreak(0);
						DetermineOverlappedZones(0);
						DetermineDisqualifiedZones(0);
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						#region -- See if the user is selecting a broken zone -----------------------------------------------------------
						var plist = Prof.Where(k => 
								   k.Value.Zones.ContainsKey(RES_ID) 
								&& k.Value.Zones[            RES_ID].Disposition=='B').ToList();
						if(this.pPermit_ResistanceZones && pPermitVAHRaysZones && plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(pShow_CurrentSessionZones){
									if(p.Key == Prof.Keys.Max()) continue;
								}else if(p.Key >= FirstProfileIdOfCurrentSession) continue;
								foreach(var z in p.Value.Zones){
									if(z.Key!=RES_ID) continue;
									var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, p.Key, 'R', z.Value.HighPrice);
									int endbar = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									Global_Arb_Rects[tag] = new Global_RectsData(p.Value.StartABar,
														BarsArray[0].GetTime(p.Value.StartABar+1), 
														z.Value.HighPrice, 
														endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
														z.Value.LowPrice,
														(p.Key>=this.FirstProfileIdOfCurrentSession ? pcResZone_Template : phResZone_Template), 
														'R');
									ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//PrintNew1("Created R rect at "+tag+"  "+Global_Arb_Rects[tag].ToString());
								}
							}
						}
						plist = Prof.Where(k => 
							   k.Value.Zones.ContainsKey(SUP_ID) 
							&& k.Value.Zones[            SUP_ID].Disposition=='B').ToList();
						if(this.pPermit_SupportZones && pPermitVALRaysZones && plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(pShow_CurrentSessionZones){
									if(p.Key == Prof.Keys.Max()) continue;
								}else if(p.Key >= FirstProfileIdOfCurrentSession) continue;
								foreach(var z in p.Value.Zones){
									if(z.Key!=SUP_ID) continue;
									var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, p.Key, 'S', z.Value.HighPrice);
									int endbar = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									Global_Arb_Rects[tag] = new Global_RectsData(p.Value.StartABar,
														BarsArray[0].GetTime(p.Value.StartABar+1), 
														z.Value.HighPrice, 
														endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
														z.Value.LowPrice,
														(p.Key>=this.FirstProfileIdOfCurrentSession ? pcSupZone_Template : phSupZone_Template), 
														'S');
									ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//if(IsDebug) PrintNew1(string.Format("SUP Zone identified: {0}-{1}  H: {2} L: {3}", MM.SelectedArbZoneData[0], (MM.SelectedArbZoneData[2]==int.MaxValue ? "unending":MM.SelectedArbZoneData[2].ToString()), MM.SelectedArbZoneData[1], MM.SelectedArbZoneData[3]));
								}
							}
						}
						#endregion
						MM.obj_count = CalculateCountOfGlobalObjects();
					}
				}
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_BrokenZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Globalize_TestedZones --
			miGlobalize_TestedZones = new MenuItem {Header = "Globalize TestedZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["T"] = false;
			miGlobalize_TestedZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["T"] = !IsGlobalized["T"];
				if(!IsGlobalized["T"]){
					#region -- Delete all tested global arb zones --
					var profs = Prof.Where(x=> x.Value.Zones.ContainsKey(RES_ID) &&  x.Value.Zones[RES_ID].Disposition=='T').Select(x=> x.Key).ToList();
					if(profs!=null && profs.Count>0) DeleteTheseZones(profs, 'R', Global_Arb_Rects);
					profs = Prof.Where(x=> x.Value.Zones.ContainsKey(SUP_ID) &&  x.Value.Zones[SUP_ID].Disposition=='T').Select(x=> x.Key).ToList();
					if(profs!=null && profs.Count>0) DeleteTheseZones(profs, 'S', Global_Arb_Rects);
					#endregion ---------------------------------
				} else {
					if(!pShow_TestedZones) {
						pShow_TestedZones = true;
						this.miShowHide_TestedZones.Header = "Hide TestedZones";
						ShowZonesClickedJustNow = true;
					}
line=3705;
					if(pShow_TestedZones){
						ResetArbZoneDispositionFlags(0);
						CheckArbZoneTouchOrBreak(0);
						DetermineOverlappedZones(0);
						DetermineDisqualifiedZones(0);
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						#region -- See if the user is selecting a tested zone ----------------------------------------------------------
						var plist = Prof.Where(k => 
							   k.Value.Zones.ContainsKey(RES_ID) 
							&& k.Value.Zones[            RES_ID].Disposition=='T').ToList();
						if(this.pPermit_ResistanceZones && pPermitVAHRaysZones && plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(pShow_CurrentSessionZones){
									if(p.Key == Prof.Keys.Max()) continue;
								}else if(p.Key >= FirstProfileIdOfCurrentSession) continue;
								foreach(var z in p.Value.Zones){
									if(z.Key!=RES_ID) continue;
									var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, p.Key, 'R', z.Value.HighPrice);
									int endbar = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									Global_Arb_Rects[tag] = new Global_RectsData(p.Value.StartABar,
														BarsArray[0].GetTime(p.Value.StartABar+1), 
														z.Value.HighPrice, 
														endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
														z.Value.LowPrice,
														(p.Key>=this.FirstProfileIdOfCurrentSession ? pcResZone_Template : phResZone_Template), 
														'R');
									ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//PrintNew1("Created R rect at "+tag+"  "+Global_Arb_Rects[tag].ToString());
								}
							}
						}
						plist = Prof.Where(k => 
							   k.Value.Zones.ContainsKey(SUP_ID) 
							&& k.Value.Zones[            SUP_ID].Disposition=='T').ToList();
						if(this.pPermit_SupportZones && pPermitVALRaysZones && plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(pShow_CurrentSessionZones){
									if(p.Key == Prof.Keys.Max()) continue;
								}else if(p.Key >= FirstProfileIdOfCurrentSession) continue;
								foreach(var z in p.Value.Zones){
									if(z.Key!=SUP_ID) continue;
									var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, p.Key, 'S', z.Value.HighPrice);
									int endbar = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									Global_Arb_Rects[tag] = new Global_RectsData(p.Value.StartABar,
														BarsArray[0].GetTime(p.Value.StartABar+1), 
														z.Value.HighPrice, 
														endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
														z.Value.LowPrice,
														(p.Key>=this.FirstProfileIdOfCurrentSession ? pcSupZone_Template : phSupZone_Template), 
														'S');
									ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//if(IsDebug) PrintNew1(string.Format("SUP Zone identified: {0}-{1}  H: {2} L: {3}", MM.SelectedArbZoneData[0], (MM.SelectedArbZoneData[2]==int.MaxValue ? "unending":MM.SelectedArbZoneData[2].ToString()), MM.SelectedArbZoneData[1], MM.SelectedArbZoneData[3]));
								}
							}
						}
						#endregion
						MM.obj_count = CalculateCountOfGlobalObjects();
					}
				}
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_TestedZones);
			#endregion
	//- - - - - - - - - - - - - 
#if DETERMINE_DISQUALIFIED_ARBZONES
			#region -- Globalize_DisqualifiedZones --
			miGlobalize_DisqualifiedZones = new MenuItem {Header = "Globalize DisqualifiedZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["D"] = false;
			miGlobalize_DisqualifiedZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["D"] = !IsGlobalized["D"];
				if(!IsGlobalized["D"]){
					#region -- Delete all disqualified global objects --
					var profs = Prof.Where(x=> x.Value.Zones.ContainsKey(RES_ID) && x.Value.Zones[RES_ID].Disposition=='D').Select(x=> x.Key).ToList();
					if(profs!=null && profs.Count>0) DeleteTheseZones(profs, 'R', Global_Arb_Rects);
					profs     = Prof.Where(x=> x.Value.Zones.ContainsKey(SUP_ID) && x.Value.Zones[SUP_ID].Disposition=='D').Select(x=> x.Key).ToList();
					if(profs!=null && profs.Count>0) DeleteTheseZones(profs, 'S', Global_Arb_Rects);
					#endregion ---------------------------------
				} else {
					if(!pShow_DisqZones) {
						pShow_DisqZones = true;
						this.miShowHide_DisqZones.Header = "Hide DisqualifiedZones";
						ShowZonesClickedJustNow = true;
					}
line=3796;//if(IsDebug)Print("ShowDisq:"+pShow_DisqZones.ToString());
					if(pShow_DisqZones){
						ResetArbZoneDispositionFlags(0);
						CheckArbZoneTouchOrBreak(0);
						DetermineOverlappedZones(0);
						DetermineDisqualifiedZones(0);
//if(Prof.ContainsKey(216)) Print("2637  Disposition: "+Prof[216].Zones[RES_ID].Disposition);
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						#region -- See if the user is selecting a disq zone ----------------------------------------------------------
						var plist = Prof.Where(k => 
							   k.Value.Zones.ContainsKey(RES_ID) 
							&& k.Value.Zones[            RES_ID].Disposition=='D').ToList();
						if(this.pPermit_ResistanceZones && pPermitVAHRaysZones && plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(pShow_CurrentSessionZones){
									if(p.Key== Prof.Keys.Max()) continue;
								}else if(p.Key >= FirstProfileIdOfCurrentSession) continue;
								foreach(var z in p.Value.Zones){
									if(z.Key!=RES_ID) continue;
									var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, p.Key, 'R', z.Value.HighPrice);
									int endbar = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									Global_Arb_Rects[tag] = new Global_RectsData(p.Value.StartABar,
														BarsArray[0].GetTime(p.Value.StartABar+1), 
														z.Value.HighPrice, 
														endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
														z.Value.LowPrice, 
														(p.Key>=this.FirstProfileIdOfCurrentSession ? pcResZone_Template : phResZone_Template), 
														'R');
									ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//PrintNew1("Created R rect at "+tag+"  "+Global_Arb_Rects[tag].ToString());
								}
							}
						}
						plist = Prof.Where(k => 
							   k.Value.Zones.ContainsKey(SUP_ID) 
							&& k.Value.Zones[            SUP_ID].Disposition=='D').ToList();
						if(this.pPermit_SupportZones && pPermitVALRaysZones && plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(pShow_CurrentSessionZones){
									if(p.Key== Prof.Keys.Max()) continue;
								}else if(p.Key >= FirstProfileIdOfCurrentSession) continue;
								foreach(var z in p.Value.Zones){
									if(z.Key!=SUP_ID) continue;
									var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, p.Key, 'S', z.Value.HighPrice);
									int endbar = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									Global_Arb_Rects[tag] = new Global_RectsData(p.Value.StartABar,
														BarsArray[0].GetTime(p.Value.StartABar+1), 
														z.Value.HighPrice, 
														endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
														z.Value.LowPrice,
														(p.Key>=this.FirstProfileIdOfCurrentSession ? pcSupZone_Template : phSupZone_Template), 
														'S');
									ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//if(IsDebug) PrintNew1(string.Format("SUP Zone identified: {0}-{1}  H: {2} L: {3}", MM.SelectedArbZoneData[0], (MM.SelectedArbZoneData[2]==int.MaxValue ? "unending":MM.SelectedArbZoneData[2].ToString()), MM.SelectedArbZoneData[1], MM.SelectedArbZoneData[3]));
								}
							}
						}
						#endregion
						MM.obj_count = CalculateCountOfGlobalObjects();
					}
				}
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_DisqualifiedZones);
			#endregion
#endif
	//- - - - - - - - - - - - - 
			#region -- Globalize_OverlappedZones --
			miGlobalize_OverlappedZones = new MenuItem {Header = "Globalize OverlappedZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["O"] = false;
			miGlobalize_OverlappedZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["O"] = !IsGlobalized["O"];
				if(!IsGlobalized["O"]){
					#region -- Delete all overlapping global objects --
					var profs = Prof.Where(x=> x.Value.Zones.ContainsKey(RES_ID) && x.Value.Zones[RES_ID].Disposition=='O').Select(x=> x.Key).ToList();
					if(profs!=null && profs.Count>0) DeleteTheseZones(profs, 'R', Global_Arb_Rects);
					profs     = Prof.Where(x=> x.Value.Zones.ContainsKey(SUP_ID) && x.Value.Zones[SUP_ID].Disposition=='O').Select(x=> x.Key).ToList();
					if(profs!=null && profs.Count>0) DeleteTheseZones(profs, 'S', Global_Arb_Rects);
					#endregion ---------------------------------
				} else {
					if(!pShow_OverlappedZones) {
						pShow_OverlappedZones   = true;
						this.miShowHide_OverlappedZones.Header = "Hide OverlappedZones";
						ShowZonesClickedJustNow = true;
					}
line=3888;
					if(pShow_OverlappedZones){
						ResetArbZoneDispositionFlags(0);
						CheckArbZoneTouchOrBreak(0);
						DetermineOverlappedZones(0);
						DetermineDisqualifiedZones(0);
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						#region -- See if the user is selecting a overlapped zone ----------------------------------------------------------
						var plist = Prof.Where(k => 
							   k.Value.Zones.ContainsKey(RES_ID) 
							&& k.Value.Zones[            RES_ID].Disposition=='O').ToList();
						if(this.pPermit_ResistanceZones && pPermitVAHRaysZones && plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(pShow_CurrentSessionZones){
									if(p.Key== Prof.Keys.Max()) continue;
								}else if(p.Key >= FirstProfileIdOfCurrentSession) continue;
								foreach(var z in p.Value.Zones){
									if(z.Key!=RES_ID) continue;
									var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, p.Key, 'R', z.Value.HighPrice);
									int endbar = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									Global_Arb_Rects[tag] = new Global_RectsData(p.Value.StartABar,
														BarsArray[0].GetTime(p.Value.StartABar+1), 
														z.Value.HighPrice, 
														endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
														z.Value.LowPrice, 
														(p.Key>=this.FirstProfileIdOfCurrentSession ? pcResZone_Template : phResZone_Template), 
														'R');
									ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//PrintNew1("Created R rect at "+tag+"  "+Global_Arb_Rects[tag].ToString());
								}
							}
						}
						plist = Prof.Where(k => 
							   k.Value.Zones.ContainsKey(SUP_ID) 
							&& k.Value.Zones[            SUP_ID].Disposition=='O').ToList();
						if(this.pPermit_SupportZones && pPermitVALRaysZones && plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(pShow_CurrentSessionZones){
									if(p.Key== Prof.Keys.Max()) continue;
								}else if(p.Key >= FirstProfileIdOfCurrentSession) continue;
								foreach(var z in p.Value.Zones){
									if(z.Key!=SUP_ID) continue;
									var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, p.Key, 'S', z.Value.HighPrice);
									int endbar = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									Global_Arb_Rects[tag] = new Global_RectsData(p.Value.StartABar,
														BarsArray[0].GetTime(p.Value.StartABar+1), 
														z.Value.HighPrice, 
														endbar >= BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime(endbar+1), 
														z.Value.LowPrice,
														(p.Key>=this.FirstProfileIdOfCurrentSession ? pcSupZone_Template : phSupZone_Template), 
														'S');
									ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//if(IsDebug) PrintNew1(string.Format("SUP Zone identified: {0}-{1}  H: {2} L: {3}", MM.SelectedArbZoneData[0], (MM.SelectedArbZoneData[2]==int.MaxValue ? "unending":MM.SelectedArbZoneData[2].ToString()), MM.SelectedArbZoneData[1], MM.SelectedArbZoneData[3]));
								}
							}
						}
						#endregion
						MM.obj_count = CalculateCountOfGlobalObjects();
					}
				}
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_OverlappedZones);
			#endregion
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(miZoneGlobal_SubMenu);
	//- - - - - - - - - - - - - 
			miRayGlobal_SubMenu = new MenuItem { Header = "Ray Global Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			#region -- ShowHide CurrentSession VA Rays --
			miShowHide_cVARays = new MenuItem {Header = "VA CurSession Ray:   "+pcVisual_ScopeVARays.ToString().Replace("and"," & "), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			#region events
			miShowHide_cVARays.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Manual)   pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Remove;
				else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Remove)   pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPO;
				else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPO)      pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.VP;
				else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.VP)       pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
				else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				miShowHide_cVARays.Header = "VA CurSession Ray:   "+pcVisual_ScopeVARays.ToString().Replace("and"," & ");
				if(Current_VisualType_CurrentSessionRays != pcVisual_ScopeVARays && ProfileDates.Count>0){
					Current_VisualType_CurrentSessionRays = pcVisual_ScopeVARays;
					Force_DrawGlobalObjectsNow = true;
					if(pcVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Remove){
						var CurSessProfileIds = ProfileDates.Keys.Where(csd=> csd >= FirstProfileIdOfCurrentSession).ToList();
						ApplyGlobalRaySelections(pcVisual_ScopeVARays, pcVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, CurSessProfileIds);
						ImmediatelyDraw_Rays(Global_VAHL_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
					}else
						Delayed_Ray_Deletion = true;
					DetermineIfDelayedRayDeletionMessageIsNecessary(pcVisual_ScopeVARays, phVisual_ScopeVARays, pcVisual_ScopePOCRays, phVisual_ScopePOCRays);
				}
				if(pcVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Remove) ForceRefresh();
//				MM.obj_count = Global_Arb_Rects.Where(ar => ar.Value.IsDrawn).Count()+Global_VAHL_Rays.Where(ar => ar.Value.IsDrawn).Count();
//				var DO = DrawObjects.ToList();
//				MM.obj_count = DO.Where(d=> d.Tag.StartsWith(string.Format("H{0}_",ObjTagPrefix))).Count() + DO.Where(d=> d.Tag.StartsWith(string.Format("L{0}_",ObjTagPrefix))).Count() + DO.Where(d=> d.Tag.StartsWith(string.Format("Z{0}-",ObjTagPrefix))).Count();
				MM.obj_count = CalculateCountOfGlobalObjects();
				if(MM.obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
					#region -- enable globals --
					pGlobalObjects_Enabled = true;
					EnableGlobals_Button.Content = "Globals ON";
					#endregion
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
				MenuControl.InvalidateVisual();
//				PrintNew1(e.Source.ToString());
				};
			miShowHide_cVARays.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if     (pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Manual)   pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Remove;
					else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Remove)   pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPO;
					else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPO)      pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.VP;
					else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.VP)       pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
					else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				}else{
					if     (pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Manual)   pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
					else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.VP;
					else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.VP)       pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPO;
					else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPO)      pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Remove;
					else if(pcVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Remove)   pcVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				}
				miShowHide_cVARays.Header = "VA CurSession Ray:   "+pcVisual_ScopeVARays.ToString().Replace("and"," & ");
				if(Current_VisualType_CurrentSessionRays != pcVisual_ScopeVARays && ProfileDates.Count>0){
					Current_VisualType_CurrentSessionRays = pcVisual_ScopeVARays;
					Force_DrawGlobalObjectsNow = true;
					if(pcVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Remove){
						var CurSessProfileIds = ProfileDates.Keys.Where(csd=> csd >= FirstProfileIdOfCurrentSession).ToList();
						ApplyGlobalRaySelections(pcVisual_ScopeVARays, pcVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, CurSessProfileIds);
						ImmediatelyDraw_Rays(Global_VAHL_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
					}else
						Delayed_Ray_Deletion = true;
					DetermineIfDelayedRayDeletionMessageIsNecessary(pcVisual_ScopeVARays, phVisual_ScopeVARays, pcVisual_ScopePOCRays, phVisual_ScopePOCRays);
				}
				if(pcVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Remove) ForceRefresh();
				MM.obj_count = CalculateCountOfGlobalObjects();
				if(MM.obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
					#region -- enable globals --
					pGlobalObjects_Enabled = true;
					EnableGlobals_Button.Content = "Globals ON";
					#endregion
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
				MenuControl.InvalidateVisual();
			};
			#endregion
			miRayGlobal_SubMenu.Items.Add(miShowHide_cVARays);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- ShowHide Historical VA Rays --
			miShowHide_hVARays = new MenuItem {Header = "VA Historical Ray:   "+phVisual_ScopeVARays.ToString().Replace("and"," & "), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_hVARays.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Manual)   phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Remove;
				else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Remove)   phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPO;
				else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPO)      phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.VP;
				else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.VP)       phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
				else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				miShowHide_hVARays.Header = "VA Historical Ray:   "+phVisual_ScopeVARays.ToString().Replace("and"," & ");
				if(Current_VisualType_HistoricalRays != phVisual_ScopeVARays && ProfileDates.Count>0){
					Current_VisualType_HistoricalRays = phVisual_ScopeVARays;
					Force_DrawGlobalObjectsNow = true;
					if(phVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Remove){
						var HistoricalProfileIds = ProfileDates.Keys.Where(csd=> csd < FirstProfileIdOfCurrentSession).ToList();
						ApplyGlobalRaySelections(phVisual_ScopeVARays, phVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, HistoricalProfileIds);
						ImmediatelyDraw_Rays(Global_VAHL_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
					}else
						Delayed_Ray_Deletion = true;
					DetermineIfDelayedRayDeletionMessageIsNecessary(pcVisual_ScopeVARays, phVisual_ScopeVARays, pcVisual_ScopePOCRays, phVisual_ScopePOCRays);
				}
				if(phVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Remove) ForceRefresh();
				MM.obj_count = CalculateCountOfGlobalObjects();
				if(MM.obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
					#region -- enable globals --
					pGlobalObjects_Enabled = true;
					EnableGlobals_Button.Content = "Globals ON";
					#endregion
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
				MenuControl.InvalidateVisual();
//				PrintNew1(e.Source.ToString());
				};
			miShowHide_hVARays.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if     (phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Manual)   phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Remove;
					else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Remove)   phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPO;
					else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPO)      phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.VP;
					else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.VP)       phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
					else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				}else{
					if     (phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Manual)   phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
					else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.VP;
					else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.VP)       phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.TPO;
					else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.TPO)      phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Remove;
					else if(phVisual_ScopeVARays==ARC_MacroProfiles_GlobalRayScopes.Remove)   phVisual_ScopeVARays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				}
				miShowHide_hVARays.Header = "VA Historical Ray:   "+phVisual_ScopeVARays.ToString().Replace("and"," & ");
				if(Current_VisualType_HistoricalRays != phVisual_ScopeVARays && ProfileDates.Count>0){
					Current_VisualType_HistoricalRays = phVisual_ScopeVARays;
					Force_DrawGlobalObjectsNow = true;
					if(phVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Remove){
						var HistoricalProfileIds = ProfileDates.Keys.Where(csd=> csd < FirstProfileIdOfCurrentSession).ToList();
						ApplyGlobalRaySelections(phVisual_ScopeVARays, phVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, HistoricalProfileIds);
						ImmediatelyDraw_Rays(Global_VAHL_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
					}else
						Delayed_Ray_Deletion = true;
					DetermineIfDelayedRayDeletionMessageIsNecessary(pcVisual_ScopeVARays, phVisual_ScopeVARays, pcVisual_ScopePOCRays, phVisual_ScopePOCRays);
				}
				if(phVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Remove) ForceRefresh();
				MM.obj_count = CalculateCountOfGlobalObjects();
				if(MM.obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
					#region -- enable globals --
					pGlobalObjects_Enabled = true;
					EnableGlobals_Button.Content = "Globals ON";
					#endregion
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
				MenuControl.InvalidateVisual();
			};
			miRayGlobal_SubMenu.Items.Add(miShowHide_hVARays);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- ShowHide CurrentSession POC Rays --
			miShowHide_cPOCRays = new MenuItem {Header = "POC CurSession Ray:   "+pcVisual_ScopePOCRays.ToString().Replace("and"," & "), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_cPOCRays.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Manual)   pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Remove;
				else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Remove)   pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPO;
				else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPO)      pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.VP;
				else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.VP)       pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
				else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				miShowHide_cPOCRays.Header = "POC CurSession Ray:   "+pcVisual_ScopePOCRays.ToString().Replace("and"," & ");
				if(Current_VisualType_pocCurrentSessionRays != pcVisual_ScopePOCRays && ProfileDates.Count>0){
					Current_VisualType_pocCurrentSessionRays = pcVisual_ScopePOCRays;
					Force_DrawGlobalObjectsNow = true;
					if(pcVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Remove){
						var CurSessProfileIds = ProfileDates.Keys.Where(csd=> csd >= FirstProfileIdOfCurrentSession).ToList();
						ApplyGlobalRaySelections(pcVisual_ScopeVARays, pcVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, CurSessProfileIds);
						ImmediatelyDraw_Rays(Global_POC_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
					}else
						Delayed_Ray_Deletion = true;
					DetermineIfDelayedRayDeletionMessageIsNecessary(pcVisual_ScopeVARays, phVisual_ScopeVARays, pcVisual_ScopePOCRays, phVisual_ScopePOCRays);
				}
				if(pcVisual_ScopePOCRays != ARC_MacroProfiles_GlobalRayScopes.Remove) ForceRefresh();
				MM.obj_count = CalculateCountOfGlobalObjects();
				if(MM.obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
					#region -- enable globals --
					pGlobalObjects_Enabled = true;
					EnableGlobals_Button.Content = "Globals ON";
					#endregion
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
				MenuControl.InvalidateVisual();
//				PrintNew1(e.Source.ToString());
				};
			miShowHide_cPOCRays.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if     (pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Manual)   pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Remove;
					else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Remove)   pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPO;
					else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPO)      pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.VP;
					else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.VP)       pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
					else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				}else{
					if     (pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Remove)   pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
					else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPO)      pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Remove;
					else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.VP)       pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPO;
					else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.VP;
					else if(pcVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Manual)   pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
				}
				miShowHide_cPOCRays.Header = "POC CurSession Ray:   "+pcVisual_ScopePOCRays.ToString().Replace("and"," & ");
				if(Current_VisualType_pocCurrentSessionRays != pcVisual_ScopePOCRays && ProfileDates.Count>0){
					Current_VisualType_pocCurrentSessionRays = pcVisual_ScopePOCRays;
					Force_DrawGlobalObjectsNow = true;
					if(pcVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Remove){
						var CurSessProfileIds = ProfileDates.Keys.Where(csd=> csd >= FirstProfileIdOfCurrentSession).ToList();
						ApplyGlobalRaySelections(pcVisual_ScopeVARays, pcVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, CurSessProfileIds);
						ImmediatelyDraw_Rays(Global_POC_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
					}else
						Delayed_Ray_Deletion = true;
					DetermineIfDelayedRayDeletionMessageIsNecessary(pcVisual_ScopeVARays, phVisual_ScopeVARays, pcVisual_ScopePOCRays, phVisual_ScopePOCRays);
				}
				if(pcVisual_ScopePOCRays != ARC_MacroProfiles_GlobalRayScopes.Remove) ForceRefresh();
				MM.obj_count = CalculateCountOfGlobalObjects();
				if(MM.obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
					#region -- enable globals --
					pGlobalObjects_Enabled = true;
					EnableGlobals_Button.Content = "Globals ON";
					#endregion
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
				MenuControl.InvalidateVisual();
			};
			miRayGlobal_SubMenu.Items.Add(miShowHide_cPOCRays);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- ShowHide Historical POC Rays --
			miShowHide_hPOCRays = new MenuItem {Header = "POC Historical Ray:   "+phVisual_ScopePOCRays.ToString().Replace("and"," & "), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_hPOCRays.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if     (phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Manual)   phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Remove;
				else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Remove)   phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPO;
				else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPO)      phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.VP;
				else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.VP)       phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
				else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				miShowHide_hPOCRays.Header = "POC Historical Ray:   "+phVisual_ScopePOCRays.ToString().Replace("and"," & ");
				if(Current_VisualType_pocHistoricalRays != phVisual_ScopePOCRays && ProfileDates.Count>0){
					Current_VisualType_pocHistoricalRays = phVisual_ScopePOCRays;
					Force_DrawGlobalObjectsNow = true;
					if(phVisual_ScopePOCRays != ARC_MacroProfiles_GlobalRayScopes.Remove){
						var HistoricalProfileIds = Prof.Keys.Where(csd=> csd < FirstProfileIdOfCurrentSession).ToList();
if(IsDebug) Print("Deleting all rays prior to "+FirstProfileIdOfCurrentSession);
						ApplyGlobalRaySelections(phVisual_ScopeVARays, phVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, HistoricalProfileIds);
						ImmediatelyDraw_Rays(Global_POC_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
					}else
						Delayed_Ray_Deletion = true;
					DetermineIfDelayedRayDeletionMessageIsNecessary(pcVisual_ScopeVARays, phVisual_ScopeVARays, pcVisual_ScopePOCRays, phVisual_ScopePOCRays);
				}
				if(phVisual_ScopePOCRays != ARC_MacroProfiles_GlobalRayScopes.Remove) ForceRefresh();
				MM.obj_count = CalculateCountOfGlobalObjects();
				if(MM.obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
					#region -- enable globals --
					pGlobalObjects_Enabled       = true;
					EnableGlobals_Button.Content = "Globals ON";
					#endregion
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
				MenuControl.InvalidateVisual();
//				PrintNew1(e.Source.ToString());
				};
			miShowHide_hPOCRays.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if     (phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Manual)   phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Remove;
					else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Remove)   phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPO;
					else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPO)      phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.VP;
					else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.VP)       phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
					else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				}else{
					if     (phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Remove)   phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
					else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPO)      phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Remove;
					else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.VP)       phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPO;
					else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.TPOandVP) phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.VP;
					else if(phVisual_ScopePOCRays==ARC_MacroProfiles_GlobalRayScopes.Manual)   phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.TPOandVP;
				}
				miShowHide_hPOCRays.Header = "POC Historical Ray:   "+phVisual_ScopePOCRays.ToString().Replace("and"," & ");
				if(Current_VisualType_pocHistoricalRays != phVisual_ScopePOCRays && ProfileDates.Count>0){
					Current_VisualType_pocHistoricalRays = phVisual_ScopePOCRays;
					Force_DrawGlobalObjectsNow = true;
					if(phVisual_ScopePOCRays != ARC_MacroProfiles_GlobalRayScopes.Remove){
						var HistoricalProfileIds   = Prof.Keys.Where(csd=> csd < FirstProfileIdOfCurrentSession).ToList();
						ApplyGlobalRaySelections(phVisual_ScopeVARays, phVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, HistoricalProfileIds);
						ImmediatelyDraw_Rays(Global_POC_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
					}else
						Delayed_Ray_Deletion = true;
					DetermineIfDelayedRayDeletionMessageIsNecessary(pcVisual_ScopeVARays, phVisual_ScopeVARays, pcVisual_ScopePOCRays, phVisual_ScopePOCRays);
				}
				if(phVisual_ScopePOCRays != ARC_MacroProfiles_GlobalRayScopes.Remove) ForceRefresh();
				MM.obj_count = CalculateCountOfGlobalObjects();
				if(MM.obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
					#region -- enable globals --
					pGlobalObjects_Enabled = true;
					EnableGlobals_Button.Content = "Globals ON";
					#endregion
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
				MenuControl.InvalidateVisual();
			};
			miRayGlobal_SubMenu.Items.Add(miShowHide_hPOCRays);
			#endregion
			MenuControl.Items.Add(miRayGlobal_SubMenu);
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			#region -- Show_TPOTouchCounter --
			if(pEnableParameterCaching) pShow_TPOTouchCounter = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("ShowTPOTouchCounter") : false);
			miShowHide_TPOTouchCounter = new MenuItem {Header = pShow_TPOTouchCounter ? "Hide TPO counter" : "Show TPO counter", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_TPOTouchCounter.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled = true;
				pShow_TPOTouchCounter = !pShow_TPOTouchCounter;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("ShowTPOTouchCounter", pShow_TPOTouchCounter);
				miShowHide_TPOTouchCounter.Header = pShow_TPOTouchCounter ? "Hide TPO counter" : "Show TPO counter";
				ForceRefresh();
				};
			MenuControl.Items.Add(miShowHide_TPOTouchCounter);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Session Breaks show/hide --
			var mi = new MenuItem
			{
			    Name = "miShowHide_SessionBreaks",
			    Header = (pShow_SessionBreaks ? "Hide SessionBreaks" : "Show SessionBreaks"),
			    Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true 
			};

			mi.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled=true;
				pShow_SessionBreaks = !pShow_SessionBreaks;
				MenuItem m = (MenuItem)o;
				m.Header = (pShow_SessionBreaks ? "Hide SessionBreaks" : "Show SessionBreaks");
			    ForceRefresh();
			};
			MenuControl.Items.Add(mi);
			#endregion
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
            #region -- SplitEnabled --
			if(pEnableParameterCaching) this.IsSplitMergeEnabled = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("SplitMergeEnabled") : false);
            miSplitMergeEnabled = new MenuItem
            {
                Name = "miSplitMergeEnabled",
                Header = (IsSplitMergeEnabled ? "Split/Merge ENABLED" : "Split/Merge Disabled"),
                Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true 
            };

            miSplitMergeEnabled.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled=true;
				IsSplitMergeEnabled = !IsSplitMergeEnabled;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("SplitMergeEnabled", IsSplitMergeEnabled);
				miSplitMergeEnabled.Header = (IsSplitMergeEnabled ? "Split/Merge ENABLED" : "Split/Merge Disabled");
				Draw.TextFixed(this, "DataLoadingMsg", "Merging overlapping value areas is in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				if(IsSplitMergeEnabled){
					#region -- Merge any/all overlappers on the chart -------------------
					int prof_count = Prof.Count;
					var dates = ProfileDates.Values.Distinct().ToList();
					if(dates!=null){
						foreach(var sessdate in dates){
							MergeAllOverlappers(sessdate, false);
						}
					}
					if(prof_count != Prof.Count){
						ResetProfileDates();
						InitialzeVolNodeTerminationStates();
						ResetArbZoneDispositionFlags(0);
						CheckArbZoneTouchOrBreak(0);
						DetermineOverlappedZones(0);
						DetermineDisqualifiedZones(0);
					}
line=4356;
					#endregion ----------------------------------------
				}
                ForceRefresh();
			};
			MenuControl.Items.Add(miSplitMergeEnabled);
            #endregion
	//- - - - - - - - - - - - - 
            #region -- SplitAssistEnabled --
			if(pEnableParameterCaching) IsSplitAssist = (ConfigMgr!=null ? ConfigMgr.DetermineStatus("SplitAssist") : false);
            miSplitAssistEnabled = new MenuItem
            {
                Name = "miSplitAssistEnabled",
                Header = (IsSplitAssist ? "Split Assist is ON" : "Split Assist is OFF"),
                Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true 
            };

            miSplitAssistEnabled.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled=true;
				IsSplitAssist = !IsSplitAssist;
				if(pEnableParameterCaching && ConfigMgr!=null) ConfigMgr.UpdateStatus("SplitAssist", IsSplitAssist);
				miSplitAssistEnabled.Header = (IsSplitAssist ? "Split Assist is ON" : "Split Assist is OFF");
                ForceRefresh();
			};
			MenuControl.Items.Add(miSplitAssistEnabled);
            #endregion
	//- - - - - - - - - - - - - 
            #region -- AutoMergeOverlappers --
			if(IsDebug){
				miAutoMergeOverlappers = new MenuItem
				{
				    Name = "miAutoMergeOverlappers",
				    Header = (IsAutoMergeOverlappers ? "* AutoMergeOverlaps is ON" : "* AutoMergeOverlaps is OFF"),
				    Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true 
				};

				miAutoMergeOverlappers.Click += delegate (object o, RoutedEventArgs e){
					//e.Handled=true;
					IsAutoMergeOverlappers = !IsAutoMergeOverlappers;
					miAutoMergeOverlappers.Header = (IsAutoMergeOverlappers ? "* AutoMergeOverlaps is ON" : "* AutoMergeOverlaps is OFF");
				    ForceRefresh();
				};
				MenuControl.Items.Add(miAutoMergeOverlappers);
			}
			#endregion
	//- - - - - - - - - - - - - 
			#region -- AutoSplitNow --
			var miAutoSplitNow = new MenuItem
			{
			    Name = "miAutoSplitNow",
			    Header = "Auto Split",
			    Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true 
			};

			miAutoSplitNow.Click += AutoSplitAllProfiles;
			MenuControl.Items.Add(miAutoSplitNow);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- AutoMerge (overlapped) --
			if(IsDebug){
				var miAutoMerge = new MenuItem
				{
				    Name = "miAutoMerge",
				    Header = "* Auto Merge",
			    	Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true 
				};

				miAutoMerge.Click += delegate (object o, RoutedEventArgs e){
					Draw.TextFixed(this, "DataLoadingMsg", "Auto-Merge overlapping value areas is in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
					//e.Handled=true;
					int prof_count = Prof.Count;
					var dates = ProfileDates.Values.Distinct().ToList();
					if(dates!=null){
						foreach(var sessdate in dates){
							MergeAllOverlappers(sessdate, false);
						}
					}
					if(prof_count!=Prof.Count){
						ResetProfileDates();
						InitialzeVolNodeTerminationStates();
						ResetArbZoneDispositionFlags(0);
						CheckArbZoneTouchOrBreak(0);
						DetermineOverlappedZones(0);
						DetermineDisqualifiedZones(0);
					}
					ForceRefresh();
				};
				MenuControl.Items.Add(miAutoMerge);
			}
			#endregion
	//- - - - - - - - - - - - - 
			#region -- MergeAllNow --
			var miMergeAllNow = new MenuItem
			{
			    Name = "miMergeAllNow",
			    Header = "Merge All",
			    Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true 
			};

			miMergeAllNow.Click += delegate (object o, RoutedEventArgs e){
				Draw.TextFixed(this, "DataLoadingMsg", "Merge All Profiles is in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				MergeAllProfiles();
				RecalcAllProfiles();
				InitialzeVolNodeTerminationStates();
				ResetArbZoneDispositionFlags(0);
				CheckArbZoneTouchOrBreak(0);
				DetermineOverlappedZones(0);
				DetermineDisqualifiedZones(0);
			    ForceRefresh();
			};
			MenuControl.Items.Add(miMergeAllNow);
			#endregion
	//- - - - - - - - - - - - - 
//			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			#region -- Enable Globals --
			EnableGlobals_Button = new System.Windows.Controls.Button { Content = (pGlobalObjects_Enabled ? "Globals ON":"Globals OFF"), Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
			EnableGlobals_Button.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled = true;
				pGlobalObjects_Enabled = !pGlobalObjects_Enabled;
				EnableGlobals_Button.Content = (pGlobalObjects_Enabled ? "Globals ON" : "Globals OFF");
				if(pGlobalObjects_Enabled){
					miShowHide_cVARays.Visibility = Visibility.Visible;
					miShowHide_hVARays.Visibility = Visibility.Visible;
				}else{
					miShowHide_cVARays.Visibility = Visibility.Collapsed;
					miShowHide_hVARays.Visibility = Visibility.Collapsed;
				}
                ForceRefresh();
			};
			MenuControl.Items.Add(EnableGlobals_Button);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Clear Globals --
			ClearGlobals_Button = new System.Windows.Controls.Button { Content = "", Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
			ClearGlobals_Button.Visibility = Visibility.Collapsed;
			ClearGlobals_Button.Click += delegate(object o, RoutedEventArgs e){
				Draw.TextFixed(this, "DataLoadingMsg", "Clearing Globals is in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				IsGlobalized["LVN"] = false;
				IsGlobalized["F"] = false;
				IsGlobalized["B"] = false;
				IsGlobalized["T"] = false;
				IsGlobalized["D"] = false;
				IsGlobalized["O"] = false;
				var RayHTag   = string.Format("@H{0}_", ObjTagPrefix);
				var RayLTag   = string.Format("@L{0}_", ObjTagPrefix);
				var RayPOCTag = string.Format("@POC{0}_", ObjTagPrefix);
				var RectTag1  = string.Format("@Z{0}_",   ObjTagPrefix);
				var RectTag2  = string.Format("@LVN{0}_", ObjTagPrefix);
				var objects = DrawObjects.ToList();
				foreach (dynamic dob in objects)
				{
					var type = dob.ToString();
#if SHOW_TERMINATED_RAYS
					//need to delete any lines that start with RayHTag or RayLTag
#endif
					if (type.EndsWith(".Ray")){
						if(dob.Tag.StartsWith(RayHTag))			RemoveThisTag(dob.Tag);
						else if(dob.Tag.StartsWith(RayLTag))	RemoveThisTag(dob.Tag);
						else if(dob.Tag.StartsWith(RayPOCTag))	RemoveThisTag(dob.Tag);
					} else if (type.EndsWith(".Rectangle")){
						if(dob.Tag.StartsWith(RectTag1))		RemoveThisTag(dob.Tag);
						else if(dob.Tag.StartsWith(RectTag2))	RemoveThisTag(dob.Tag);
					}
				}
				Global_VAHL_Rays.Clear();
				Global_POC_Rays.Clear();
				Global_Arb_Rects.Clear();
				Global_LVN_Rects.Clear();
				//e.Handled=true;
				ClearGlobals_Button.Content = "";
				ClearGlobals_Button.Visibility = Visibility.Collapsed;
				ClearGlobals_Button.Background = Brushes.DimGray;
				MM.obj_count = 0;
				pcVisual_ScopeVARays  = ARC_MacroProfiles_GlobalRayScopes.Manual;
				phVisual_ScopeVARays  = ARC_MacroProfiles_GlobalRayScopes.Manual;
				pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				miShowHide_cVARays.Header  = "VA CurSession Ray:  "+pcVisual_ScopeVARays.ToString().Replace("and"," & ");
				miShowHide_hVARays.Header  = "VA Historical Ray:  "+phVisual_ScopeVARays.ToString().Replace("and"," & ");
				miShowHide_cPOCRays.Header = "POC CurSession Ray:  "+pcVisual_ScopePOCRays.ToString().Replace("and"," & ");
				miShowHide_hPOCRays.Header = "POC Historical Ray:  "+phVisual_ScopePOCRays.ToString().Replace("and"," & ");
			};
			MenuControl.Items.Add(ClearGlobals_Button);
			#endregion
			//Print(UserId);
			if(IsGeoffZimmerman || IsDebug){
				MenuControl.Items.Add(new Separator());
				#region Write CSV data
				var WiteCSV_Button = new System.Windows.Controls.Button { Content = "Write CSV", Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
				WiteCSV_Button.Visibility = Visibility.Visible;
				WiteCSV_Button.Click += delegate(object o, RoutedEventArgs e){
					SaveArbZoneData = true;
					ForceRefresh();
				};
				MenuControl.Items.Add(WiteCSV_Button);
				#endregion
			}
	//- - - - - - - - - - - - - 

			indytoolbar.Children.Add(MenuControlContainer);
			#endregion
		}
//=====================================================================================================
		private void AutoSplitAllProfiles(object o, RoutedEventArgs e){
			#region -- AutoSplitAllProfiles --
			Draw.TextFixed(this, "DataLoadingMsg", "Auto-Split is in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);

			MergeAllProfiles();
			RecalcAllProfiles();
//Print("------------------------------------\nFirst pass");
			#region Perform 1st split and merge of overlappers
			int count  = 0;
			int count2 = 0;
			bool done  = false;

			int prof_count = Prof.Count;
			while(!done && Prof.Keys.Count>0){
				count2   = 0;
				var keys = Prof.Keys.ToList();//Where(p=> !p.Value.IsSingularDistribution).Select(p=>p.Key).ToList();
				if(count >= keys.Count) break;
				while(!Prof[keys[count]].IsSingularDistribution && count2<10){
					count2++;
					SplitProfile(keys[count], Prof[keys[count]].SplitAssistPrice, true, true, isLiveData && IsDebug);
				}
				count++;
if(count2>=10) Print("4299 Count2 was: "+count2);
			}
			if(IsAutoMergeOverlappers){
//PrintNew1("AutoSplit completed...nowAutoMerge processing\n");
				var dates = ProfileDates.Values.Distinct().ToList();
				if(dates!=null && dates.Count>0){
					foreach(var sessdate in dates){
						MergeAllOverlappers(sessdate, false);
					}
				}
			}
			#endregion
			#region Perform 2nd split and merge of overlappers
			count  = 0;
			count2 = 0;
			done  = false;

//Print("-----------------------\nSecond pass");
			prof_count = Prof.Count;
			while(!done && Prof.Keys.Count>0){
				count2   = 0;
				var keys = Prof.Keys.ToList();//Where(p=> !p.Value.IsSingularDistribution).Select(p=>p.Key).ToList();
				if(count >= keys.Count) break;
				while(!Prof[keys[count]].IsSingularDistribution && count2<10){
//if(keys[count]>=137)Print("Key: "+keys[count]+"  at  "+Prof[keys[count]].SplitAssistPrice+"  Open: "+Prof[keys[count]].OpenPrice+"  Close: "+Prof[keys[count]].ClosePrice);
					count2++;
					SplitProfile(keys[count], Prof[keys[count]].SplitAssistPrice, true, true, isLiveData && IsDebug);
				}
				count++;
if(count2>=10) Print("4328 Count2 was: "+count2);
			}
			if(IsAutoMergeOverlappers){
				var dates = ProfileDates.Values.Distinct().ToList();
				if(dates!=null && dates.Count>0){
					foreach(var sessdate in dates){
						MergeAllOverlappers(sessdate, false);
					}
				}
			}
			#endregion
			
			ResetProfileDates();
			InitialzeVolNodeTerminationStates();
			ResetArbZoneDispositionFlags(0);
			CheckArbZoneTouchOrBreak(0);
			DetermineOverlappedZones(0);
			DetermineDisqualifiedZones(0);
			ForceRefresh();
			#endregion -------------------
		}
//=====================================================================================================
		protected override void OnStateChange()
		{
try{
			if(pButtonText == "terminated") return;
//if(IsDebug && State!=null) PrintNew1("---------------------------------------- Entering as State: "+State.ToString());
			#region OnStateChange
			if (State == State.SetDefaults)
			{
//Process[] ps = Process.GetProcessesByName("NinjaTrader");
//foreach (Process p in ps) Print("Process: "+p.Id.ToString());
line=4645;
				#region -- SetDefaults -------------------------------------
				Name = "ARC_MacroProfiles";
				IsChartOnly = true;
				IsOverlay   = true;
				IsAutoScale = false;
				IsSuspendedWhileInactive=false;
				Calculate   = Calculate.OnPriceChange;
				AddPlot(new Stroke(Brushes.Cyan,2), PlotStyle.Hash, "vpVAH");
				AddPlot(new Stroke(Brushes.Cyan,2), PlotStyle.Hash, "vpVAL");
				AddPlot(new Stroke(Brushes.Blue,2), PlotStyle.Hash, "vpPOC");
				AddPlot(new Stroke(Brushes.Pink,2), PlotStyle.Hash,    "tpoVAH");
				AddPlot(new Stroke(Brushes.Pink,2), PlotStyle.Hash,    "tpoVAL");
				AddPlot(new Stroke(Brushes.Magenta,2), PlotStyle.Hash, "tpoPOC");
				AddPlot(new Stroke(Brushes.Purple,2), PlotStyle.Line,  "VWAP");
				pGlobalObjects_Enabled = false;

				pcVP_VAH_RayTemplate   = "Default";
				pcVP_VAL_RayTemplate   = "Default";
				pcTPO_VAH_RayTemplate  = "Default";
				pcTPO_VAL_RayTemplate  = "Default";
				pcResZone_Template     = "Default";
				pcSupZone_Template     = "Default";
				pcTPO_POC_RayTemplate  = "Default";
				pcVP_POC_RayTemplate   = "Default";
				pcLVN_Template         = "Default";
				pcHVN_Template         = "Default";
				
				phVP_VAH_RayTemplate   = "Default";
				phVP_VAL_RayTemplate   = "Default";
				phTPO_VAH_RayTemplate  = "Default";
				phTPO_VAL_RayTemplate  = "Default";
				phResZone_Template     = "Default";
				phSupZone_Template     = "Default";
				phTPO_POC_RayTemplate  = "Default";
				phVP_POC_RayTemplate   = "Default";
				phLVN_Template         = "Default";
				phHVN_Template         = "Default";

				SupZone_Brush		    = Brushes.Green;
				ResZone_Brush		    = Brushes.Red;
				ResTestedZone_Brush	    = Brushes.LightCoral;
				SupTestedZone_Brush	    = Brushes.LightGreen;
				ResBrokenZone_Brush	    = Brushes.Magenta;
				SupBrokenZone_Brush	    = Brushes.Cyan;
				DisqZone_Brush          = Brushes.LightGray;
				OverlapZone_Brush       = Brushes.LightYellow;
				TPOCounterFont_Brush    = Brushes.White;
				TPOCounterFont_BkgBrush = Brushes.Black;

line=4695;

				tpoSinglePrintLine_Brush = Brushes.Chartreuse;
				tpoPOC_Brush		 = Brushes.Orange;
				vpPOC_Brush			 = Brushes.Yellow;
				OpenMarkerBrush      = Brushes.Goldenrod;
				UpCloseMarkerBrush   = Brushes.Lime;
				DownCloseMarkerBrush = Brushes.Crimson;
				SupZoneOpacity		 = 20;
				ResZoneOpacity		 = 20;
				ResTestedZoneOpacity = 20;
				SupTestedZoneOpacity = 20;
				ResBrokenZoneOpacity = 20;
				SupBrokenZoneOpacity = 20;
				DisqZoneOpacity      = 50;
				OverlapZoneOpacity   = 40;
				ResZoneBorder        = new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
				SupZoneBorder        = new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
				SupTestedZoneBorder  = new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
				ResTestedZoneBorder  = new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
				SupBrokenZoneBorder  = new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
				ResBrokenZoneBorder  = new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
				pShowSinglePrintLines = true;
				pSinglePrintLineThickness = 5f;

				pVisualType_VWAP     = ARC_MacroProfiles_VisualsType.None;
				pVisualType_VPVAH    = ARC_MacroProfiles_VisualsType.None;
				pVisualType_VPVAL    = ARC_MacroProfiles_VisualsType.None;
				pVisualType_VPPOC    = ARC_MacroProfiles_VisualsType.None;
				pShowVP_Histo        = true;
				pVisualType_TPOVAH   = ARC_MacroProfiles_VisualsType.None;
				pVisualType_TPOVAL   = ARC_MacroProfiles_VisualsType.None;
				pVisualType_TPOPOC   = ARC_MacroProfiles_VisualsType.None;
				pShowTPO_Histo       = true;
				pShow_CurrentSessionZones = true;

				pAutoScaleHistoWidth  = true;
				pcVisual_ScopeVARays  = ARC_MacroProfiles_GlobalRayScopes.Manual;
				phVisual_ScopeVARays  = ARC_MacroProfiles_GlobalRayScopes.Manual;
				pcVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				phVisual_ScopePOCRays = ARC_MacroProfiles_GlobalRayScopes.Manual;
				pPermitVAHRaysZones = true;
				pPermitVALRaysZones = true;

				HVN_Brush = Brushes.Red;
				LVN_Brush = Brushes.Blue;
				pHighlightHVNLVN_Region = true;
				pShow_CurrentProfileVN = false;
				pShow_HistoricalProfileVN = false;
				pVisualType_HVN		 = ARC_MacroProfiles_VisualsType_HNLN.Dot;
				pVisualType_LVN		 = ARC_MacroProfiles_VisualsType_HNLN.Full;
line=4746;
#if HTO_LTO
				#region -- HTO LTO brushes ---------
				HTO_Brush = Brushes.Red;
				LTO_Brush = Brushes.Blue;
				pHighlightHTOLTO_Region = true;
				pVisualType_HTO		 = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				pVisualType_LTO		 = ARC_MacroProfiles_VisualsType_HNLN.Hidden;
				#endregion
#endif

				pPriceBarSetting     = ARC_MacroProfiles_PriceBarSetting.Hide;
				SessionBreak_Brush   = Brushes.Yellow;
				TPOTouchCounter_Font =	new SimpleFont("Arial",12);
				pPermit_ResistanceZones = true;
				pPermit_SupportZones    = true;

				pButtonText = "MacroProfiles";

//				IsAutoSplit = false;
				IsSplitAssist       = false;
				IsSplitMergeEnabled = true;
				IsAutoMergeOverlappers = true;
				SplitAssistMarkerBrush = Brushes.Yellow;
				SplitMarkerFillOpacity = 50f;
				SplitMarkerOutline_Stroke = new Stroke(Brushes.Black, 2);

				ShowATR_databox = true;
				ShowRR_databox  = true;
				ATRMode						= 	ARC_MacroProfiles_ATRModeEnum.Points;
				ATR_Delta_Box_Font			=	new SimpleFont("Verdana",12);
				ATR_Delta_Box_Font_Color	=	Brushes.Black;
				ATR_Delta_Box_Back_Color	=	Brushes.DarkKhaki;
				ATR_Delta_Box_Border		=	new Stroke(Brushes.Black,1);

				CandleBodyUpBrush   = Brushes.DarkGreen;
				CandleBodyDownBrush = Brushes.Crimson;
				CandleOutlineBrush  = Brushes.DimGray;
				CandleWickBrush     = Brushes.DimGray;

				BuyZoneWAV			= "none";
				SellZoneWAV			= "none";
				pFrontrunTicks		= 0;
				pPlayOnFrontRunHit	= true;
				pPlayOnZoneHit		= true;

				#endregion
				//Draw.TextFixed(this, "DataLoadingMsg", "Data is loading..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
line=4794;
			}
			else if (State == State.Configure)
			{
line=4798;
				IsDebug = System.IO.File.Exists(@"c:\222222222222.txt");
				IsDebug = IsDebug && (NinjaTrader.Cbi.License.MachineId.CompareTo("CB15E08BE30BC80628CFF6010471FA2A")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion
line=4815;
				//IsDebug = false;
				if(UserId=="GeoffZimmerman") IsGeoffZimmerman = true;

				#region -- Configure ---------------------------------------
				//PrintNew1("Instrument.FullName: "+Instrument.FullName);
//				uID = Instrument.FullName+" "+Bars.BarsPeriod.ToString()+" "+DateTime.Now.Ticks.ToString();//prevent multiple toolbar with same name
//				uID = uID.Replace(" ",string.Empty);
				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);

				if(pSensitivity==ARC_MacroProfiles_Sensitivity.Tick)
					AddDataSeries(BarsPeriodType.Tick,1);
				else if(pSensitivity==ARC_MacroProfiles_Sensitivity.Second) 
					AddDataSeries(BarsPeriodType.Second,5);
				else if(pSensitivity==ARC_MacroProfiles_Sensitivity.Minute1) 
					AddDataSeries(BarsPeriodType.Minute,1);
				else if(pSensitivity==ARC_MacroProfiles_Sensitivity.Minute2) 
					AddDataSeries(BarsPeriodType.Minute,2);
				else if(pSensitivity==ARC_MacroProfiles_Sensitivity.Minute3) 
					AddDataSeries(BarsPeriodType.Minute,3);
				else if(pSensitivity==ARC_MacroProfiles_Sensitivity.Minute4) 
					AddDataSeries(BarsPeriodType.Minute,4);
				else if(pSensitivity==ARC_MacroProfiles_Sensitivity.Minute5) 
					AddDataSeries(BarsPeriodType.Minute,5);
				else if(pSensitivity==ARC_MacroProfiles_Sensitivity.Minute10) 
					AddDataSeries(BarsPeriodType.Minute,10);
				else if(pSensitivity==ARC_MacroProfiles_Sensitivity.Minute15) 
					AddDataSeries(BarsPeriodType.Minute,15);
				else if(pSensitivity==ARC_MacroProfiles_Sensitivity.Minute30) 
					AddDataSeries(BarsPeriodType.Minute,30);
line=4844;
				
				MM = new MouseManager();
				#endregion
			}
			else if(State == State.Historical){
line=4850;
				#region -- Historical ----------------------------------
				priceBoxSizeInPrice = TickSize*pTicksPerHistoBar;
                sessionIterator0 = new SessionIterator(BarsArray[1]);
				if(ChartPanel!=null){
					ChartPanel.MouseMove  += OnMouseMove;
					ChartPanel.MouseUp    += OnMouseUp;
				}
line=4858;
				small_tag = string.Format("{0}-{1}", pTimeBasis.ToString()[0].ToString(), Instrument.MasterInstrument.Name);
				ObjTagPrefix = string.Format("{0}-{1}#{2}{3}", pTimeBasis.ToString()[0].ToString(), Instrument.MasterInstrument.Name, DateTime.Now.Second,DateTime.Now.Millisecond);

				#endregion
				ConfigMgr = new SavedConfigManager(Instrument.MasterInstrument.Name, Instrument.MasterInstrument.InstrumentType.ToString());
line=4864;
                #region -- Add Custom Toolbar --------------------------
				if (!isToolBarButtonAdded && ChartControl != null)
					Dispatcher.BeginInvoke(new Action(() =>
					{
					    chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
					    if (chartWindow == null) return;

//PrintNew1("toolbarname: "+this.toolbarname);
//PrintNew1("UID: "+this.uID);
						//int c = 1;
line=4875;
						foreach (DependencyObject item in chartWindow.MainMenu) {
//PrintNew1(c+": "+System.Windows.Automation.AutomationProperties.GetAutomationId(item));c++;
							if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;
//PrintNew1("    IsToolbarButtonAdded: "+this.isToolBarButtonAdded.ToString());
						}

						if (!isToolBarButtonAdded)
						{
						    indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

						    addToolBar();
						    
						    chartWindow.MainMenu.Add(indytoolbar);
						    chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

						    foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
						    System.Windows.Automation.AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
						}
					}));
                #endregion
			}
			else if(State == State.DataLoaded){
line=4898;
				inst = Instrument.FullName;
				if(pTimeBasis == ARC_MacroProfiles_TimeBasis.Daily)
					TPO_Data = new TPO_DataManager(RoundToTick(TickSize), 'D', Times[1].GetValueAt(0), this);//30-min per TPO slice
				else if(pTimeBasis == ARC_MacroProfiles_TimeBasis.Weekly)
					TPO_Data = new TPO_DataManager(RoundToTick(TickSize), 'W', Times[1].GetValueAt(0), this);//150-min per TPO slice
				else if(pTimeBasis == ARC_MacroProfiles_TimeBasis.Monthly)
					TPO_Data = new TPO_DataManager(RoundToTick(TickSize), 'M', Times[1].GetValueAt(0), this);//660-min per TPO slice
//foreach(var bd in TPO_Data.BarData) PrintNew1("BarData key: "+bd.Key.ToString());
line=4907;
			}
			else if(State == State.Realtime){
				isLiveData = true;
line=4911;
				#region -- Realtime --
				var bar0_Dates = new SortedDictionary<int,DateTime>();
				foreach(var pdd in ProfileDates.Keys) {
					bar0_Dates[pdd] = BarsArray[0].GetTime(pdd);
				}

				FrontRunPts = this.pFrontrunTicks * TickSize;
				TPO_Data.Accumulate(BarsArray[1], bar0_Dates.Values.ToList(), this);
				RecalcAllProfiles();
				CheckArbZoneTouchOrBreak(0);

				if(pPriceBarSetting == ARC_MacroProfiles_PriceBarSetting.Hide){
					ChartBars.Properties.ChartStyle.UpBrush			= Brushes.Transparent;
					ChartBars.Properties.ChartStyle.DownBrush		= Brushes.Transparent;
					ChartBars.Properties.ChartStyle.Stroke.Brush	= Brushes.Transparent;
					ChartBars.Properties.ChartStyle.Stroke2.Brush	= Brushes.Transparent;
				}else{
					if(!EqualColor(Brushes.Transparent, CandleBodyUpBrush) && !EqualColor(CandleBodyUpBrush, ChartBars.Properties.ChartStyle.UpBrush))
						ChartBars.Properties.ChartStyle.UpBrush			= CandleBodyUpBrush;
					if(!EqualColor(Brushes.Transparent, CandleBodyDownBrush) && !EqualColor(CandleBodyDownBrush, ChartBars.Properties.ChartStyle.DownBrush))
						ChartBars.Properties.ChartStyle.DownBrush		= CandleBodyDownBrush;
					if(!EqualColor(Brushes.Transparent, CandleOutlineBrush) && !EqualColor(CandleOutlineBrush, ChartBars.Properties.ChartStyle.Stroke.Brush))
						ChartBars.Properties.ChartStyle.Stroke.Brush	= CandleOutlineBrush;
					if(!EqualColor(Brushes.Transparent, CandleWickBrush) && !EqualColor(CandleWickBrush, ChartBars.Properties.ChartStyle.Stroke2.Brush))
						ChartBars.Properties.ChartStyle.Stroke2.Brush	= CandleWickBrush;
				}

				UntestedResPrices.Clear();
				UntestedSupPrices.Clear();
				if(pPermitProfileSplits){
					AutoSplitAllProfiles(null,null);
				}
				InitializationRun = true;
				#endregion -----------------------------------------
line=4946;
				#region -- Calculate all HVN and LVN termination points -- 
				InitialzeVolNodeTerminationStates();
				HVNLVN_AreVisible =	pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#if HTO_LTO
				HVNLVN_AreVisible = HVNLVN_AreVisible || 
									pVisualType_HTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden ||
									pVisualType_LTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
#endif
				#endregion
				if(HVNLVN_AreVisible && (pShow_CurrentProfileVN || pShow_HistoricalProfileVN)) {
					CreateAndDrawAllGlobal_LVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
					CreateAndDrawAllGlobal_HVN_Zones(pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
				}
				ResetProfileDates();
				ResetArbZoneDispositionFlags(0);
				CheckArbZoneTouchOrBreak(0);
				DetermineOverlappedZones(0);
				DetermineDisqualifiedZones(0);
				if(Prof.Count>0){
					if(pcVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Manual || pcVisual_ScopePOCRays != ARC_MacroProfiles_GlobalRayScopes.Manual){
						Current_VisualType_CurrentSessionRays = pcVisual_ScopeVARays;
						var CurSessProfileIds = ProfileDates.Keys.Where(csd=> csd >= FirstProfileIdOfCurrentSession).ToList();
						ApplyGlobalRaySelections(pcVisual_ScopeVARays, pcVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, CurSessProfileIds);
						Force_DrawGlobalObjectsNow = true;
					}
					if(phVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Manual || phVisual_ScopePOCRays != ARC_MacroProfiles_GlobalRayScopes.Manual){
						Current_VisualType_HistoricalRays = phVisual_ScopeVARays;
						var HistoricalProfileIds = ProfileDates.Keys.Where(csd=> csd < FirstProfileIdOfCurrentSession).ToList();
						ApplyGlobalRaySelections(phVisual_ScopeVARays, phVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, HistoricalProfileIds);
						Force_DrawGlobalObjectsNow = true;
					}
				}
				RealtimeStateFinished = true;
				ForceRefresh();
			}
			else if(State == State.Terminated){
				#region Terminated
				if(ChartPanel!=null){
					ChartPanel.MouseMove -= OnMouseMove;
					ChartPanel.MouseUp -= OnMouseUp;
					//ChartControl.PreviewMouseLeftButtonUp -=	OnCtrlPlusClick;
				}
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
						indytoolbar = null;
						try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
							indytoolbar = null;
							try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
							chartWindow = null;
						}));
					}
				}

				#endregion
			}
			#endregion
//if(IsDebug && State!=null) PrintNew1("--------- Exiting State: "+State.ToString());
}catch(Exception OSC){
	Print(line+":  "+OSC.ToString()+"  inst: "+inst);
	NinjaScript.Log(line+":  "+OSC.ToString(), NinjaTrader.Cbi.LogLevel.Information);
}
		}
#region methods
//=====================================================================================================
		private void ResetProfileDates() {
			ProfileDates.Clear();
			foreach(var pr in Prof)
				ProfileDates[pr.Key] = pr.Value.SessionDate;
		}
//=====================================================================================================
		private void ResetArbZoneDispositionFlags(int StartABar){
			var plist = Prof.Where(k=> k.Key>=StartABar).Select(k=> k.Key).ToList();
			foreach(var id in plist){
				foreach(var z in Prof[id].Zones){
					z.Value.EndABar        = int.MaxValue;
					z.Value.Broken         = false;
					z.Value.BrokenABar     = int.MaxValue;
					z.Value.Tested         = false;
					z.Value.Overlapped     = false;
					z.Value.OverlappedABar = int.MaxValue;
					z.Value.TestedDate     = new DateTime();
					z.Value.Disqualified   = false;
					z.Value.Disposition    = 'F';
				}
			}
		}
//=====================================================================================================
		private void RecalcAllProfiles(){
			#region -- RecalcAllProfiles --
			var blanks = TPO_Data.BarData.Where(bd=> bd.Value.Letter==' ').Select(bd=> bd.Key).ToList();
			if(blanks!=null && blanks.Count>0){
				foreach(var del in blanks) {
					TPO_Data.BarData.Remove(del);
				}
			}
			DateTime sessDT = DateTime.MinValue;
			var ProfThatNeedUpdating = new List<int>();
			foreach(var profile in Prof){
line=5055;
				ProfThatNeedUpdating.Add(profile.Key);
				profile.Value.TPOatP.Clear();
				float ValueAreaPctF  = ValueAreaPct/100f;
line=5059;
				profile.Value.TPOatP = TPO_Data.CreateTPOatP(BarsArray[0].GetTime(profile.Value.StartABar), BarsArray[0].GetTime(profile.Value.EndABar), ref profile.Value.FirstSplitableBarDataKey, TPO_Data.BarData, Times[1].GetValueAt(CurrentBars[1]), this, profile.Value.StartABar, false);
				profile.Value.Calc_DevelopingTPO(profile.Value.StartABar, BarsArray[0].GetTime(profile.Value.StartABar), ValueAreaPctF, TPO_Data.BarData, Times[1].GetValueAt(CurrentBars[1]), BarsArray[0], this);
line=5062;
				profile.Value.Calc_DevelopingVP (profile.Value.StartABar, BarsArray[0].GetTime(profile.Value.StartABar), ValueAreaPctF, BarsArray[1], BarsArray[0], this);
				profile.Value.Calc_ConsolidatedVP(pTicksPerHistoBar, TickSize);
				profile.Value.Calc_HVN_LVN(pSignificance_HVN_LVN, pHighlightHVNLVN_Region, pHighlightHVNLVN_RegionSize, pTicksPerHistoBar, this);
line=5066;
#if HTO_LTO
				profile.Value.Calc_HTO_LTO(pSignificance_HTO_LTO, pHighlightHTOLTO_Region);
#endif
				profile.Value.Calc_ArbZones(profile.Value.ClosePrice, true, true);
				profile.Value.Calc_CurrentSplitAssistPrice(this.pMinSplitDepth, this);
			}
line=5073;
			ResetArbZoneDispositionFlags(0);
line=5075;
			CheckArbZoneTouchOrBreak(0);
line=5077;
			DetermineOverlappedZones(0);
line=5079;
			DetermineDisqualifiedZones(0);
			#endregion
		}
		/*
1)  Existing zones are disqualified only at the open of the next session (the session immediately following their origination bar), based on the open price of that session.  Support zones above that open price are disqualified.  Resistance zones below that open price are disqualified.  If the open occurs inside of any zone (between upper and lower price), that zone is disqualified
	The rightmost edge bar of a disqualified zone is the first bar of the next session
2)  Tested zones are tested starting at the beginning of the next session after they originate.  Anytime price touches or ventures into the zone, the zone is tested
3)  Broken zones are tested zones that do not contain price action.  Price touches/exceeds both the upper and lower price levels of the zone.
4)  Overlapped zones are zones whose upper/lower level touches or intersectes with a future value area (either TPO or VP).
	The rightmost edge bar of an overlapped zone is the first price bar that touches them.  They are basically broken or tested zones that also happen to run into (overlap) a value area
5)  Fresh zones are zones that are not disqualified, tested, broken or overlapped
		*/
//=====================================================================================================
		#region -- Determine Disqualifieds --
		private void DetermineDisqualifiedZones(DateTime sessDT){
#if !DETERMINE_DISQUALIFIED_ARBZONES
			return;
#endif
			var keys = Prof.Where(k=>k.Value.SessionDate == sessDT.Date).Select(k=>k.Key).ToList();
			if(keys==null || keys.Count==0) return;
			DetermineDisqualifiedZones(keys);
		}
//=====================================================================================================
		private void DetermineDisqualifiedZones(List<int> keys){
#if !DETERMINE_DISQUALIFIED_ARBZONES
			return;
#endif
line=5100;
bool x = false;
			if(keys==null || keys.Count==0) return;
			keys.Sort();
			if(keys.Count>1 && keys[0] < keys.Last()) keys.Reverse();//keys[0] should be the highest profile id (abar)
			DateTime sessDate    = DateTime.MinValue;
			int SessionEndABar   = keys.Max();
			int prior_updateThis = SessionEndABar;
			double ClosePrice    = 0;
			double OpenPrice     = 0;
			double NextOpenPrice = double.MinValue;
			foreach(var updateThis in keys){
//x = IsDebug && updateThis==183;
				if(sessDate == DateTime.MinValue) {
					sessDate       = Prof[updateThis].SessionDate;
					ClosePrice     = Prof[updateThis].ClosePrice;
					OpenPrice      = Prof[updateThis].OpenPrice;
					SessionEndABar = updateThis-1;
				}
				if(sessDate != Prof[updateThis].SessionDate){
					sessDate       = Prof[updateThis].SessionDate;
					ClosePrice     = Prof[updateThis].ClosePrice;
					OpenPrice      = Prof[updateThis].OpenPrice;
					SessionEndABar = prior_updateThis-1;
					if(Prof[updateThis].EndABar+1<=BarsArray[0].Count && Prof[updateThis].EndABar+1>0) NextOpenPrice  = Opens[0].GetValueAt(Prof[updateThis].EndABar+1);
				}
//if(x && Prof[updateThis].Zones.ContainsKey(SUP_ID)) {
//	Print(line+"   ClosePrice: "+Instrument.MasterInstrument.FormatPrice(ClosePrice) + "  zone Low: "+Prof[updateThis].Zones[SUP_ID].LowPrice);
//	TriggerCustomEvent(o1 =>{
//		Draw.Line(this,"cpl",CurrentBars[0]-Prof[updateThis].StartABar,Prof[updateThis].OpenPrice, CurrentBars[0]-Prof[updateThis].EndABar, Prof[updateThis].ClosePrice,Brushes.Yellow);},0,null);
//}
				if(Prof[updateThis].Zones.ContainsKey(SUP_ID)){
					Prof[updateThis].Zones[SUP_ID].Disqualified     = false;
					if(ClosePrice < Prof[updateThis].Zones[SUP_ID].LowPrice){
						Prof[updateThis].Zones[SUP_ID].Disqualified = true;
						Prof[updateThis].Zones[SUP_ID].Disposition  = 'D';
						Prof[updateThis].Zones[SUP_ID].EndABar      = SessionEndABar;
					}else if(NextOpenPrice!=double.MinValue && NextOpenPrice < Prof[updateThis].Zones[SUP_ID].LowPrice){
						Prof[updateThis].Zones[SUP_ID].Disqualified = true;
						Prof[updateThis].Zones[SUP_ID].Disposition  = 'D';
						Prof[updateThis].Zones[SUP_ID].EndABar      = SessionEndABar;
					}
//if(x) Print("4572:  SUP Disqualified? "+Prof[updateThis].Zones[SUP_ID].Disqualified.ToString());
				}
//if(x && Prof[updateThis].Zones.ContainsKey(RES_ID)) {
//	Print(line+"   ClosePrice: "+Instrument.MasterInstrument.FormatPrice(ClosePrice) + "  zone High: "+Prof[updateThis].Zones[RES_ID].HighPrice);
//}
				if(Prof[updateThis].Zones.ContainsKey(RES_ID)){
					Prof[updateThis].Zones[RES_ID].Disqualified     = false;
					if(ClosePrice > Prof[updateThis].Zones[RES_ID].HighPrice){
						Prof[updateThis].Zones[RES_ID].Disqualified = true;
						Prof[updateThis].Zones[RES_ID].Disposition  = 'D';
						Prof[updateThis].Zones[RES_ID].EndABar      = SessionEndABar;
					}else if(NextOpenPrice!=double.MinValue && NextOpenPrice > Prof[updateThis].Zones[RES_ID].HighPrice){
						Prof[updateThis].Zones[RES_ID].Disqualified = true;
						Prof[updateThis].Zones[RES_ID].Disposition  = 'D';
						Prof[updateThis].Zones[RES_ID].EndABar      = SessionEndABar;
					}
//if(x) Print("4589:  RES Disqualified? "+Prof[updateThis].Zones[RES_ID].Disqualified.ToString());
				}
				prior_updateThis = updateThis;
			}
		}
//=====================================================================================================
		private void DetermineDisqualifiedZones(int StartABar){
#if !DETERMINE_DISQUALIFIED_ARBZONES
			return;
#endif
			if(StartABar==0) {
				if(Prof.Count > 0) DetermineDisqualifiedZones(Prof.Keys.ToList());
			} else {
				List<int> keys = Prof.Keys.Where(k=>k>=StartABar).ToList();
				if(keys!=null && keys.Count>0) DetermineDisqualifiedZones(keys);
			}
		}
		#endregion
//=====================================================================================================
		private bool EqualColor(Brush FirstBrush, Brush SecondBrush)	{return (((SolidColorBrush)FirstBrush).Color == ((SolidColorBrush)SecondBrush).Color); }
//=====================================================================================================
		#region -- UI Events -----------------------------------------------------
        private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            System.Windows.Controls.TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
		#endregion
//=====================================================================================================
		private double RoundToTick(double p){		int t = (int)Math.Round(p/TickSize,0);	return t*TickSize;		}
//=====================================================================================================
        #region -- Mouse utilities --
		//=========================================================================================
        #region -- private class MouseManager --
        private class MouseManager
        {
            public int SelectedProfileId = -1;
			public int HoverProfileId    = -1;
			public int MouseABar         = -1;
			public bool ChoosingToAddRay = false;
			public double MousePrice     = -1;
            public int X = 0;
            public int Y = 0;
			public double ChartMaxPrice = double.MinValue;
			public double ChartMinPrice = double.MaxValue;
			public int    ChartMinABar  = int.MaxValue;
			public int    ChartMaxABar  = 0;
			public int    TPOCount      = 0;
			public double  ChartHeight  = 0;
			public int obj_count        = 0;
			public char     SelectedArbZoneType =   ' ';
			public double[] SelectedRayData     = new double[3]{-1,-1,double.MinValue};//[0] is the VAHigh and [1] is the VALow prices, [2] is the V_ID or TPO_ID, (used for tag on the rays)
			public double[] SelectedArbZoneData = new double[4]{-1,-1,-1,-1};
														//[0] is the abar of left-edge of rectangle
														//[1] is the price of the top edge of the rectangle
														//[2] is the abar of the right edge of the rectangle
														//[3] is the price of the bottom edge of the rectangle

            public void Clear()
            {
                this.SelectedProfileId = -1;
				this.ChoosingToAddRay = false;
                this.X = 0;
                this.Y = 0;
				SelectedRayData = new double[3]{-1,-1,double.MinValue};	
				SelectedArbZoneData = new double[4]{-1,-1,-1,-1};	
				SelectedArbZoneType =   ' ';
            }
        }
        #endregion
		//=========================================================================================
        private void OnMouseMove(object sender, MouseEventArgs e)
        {
			#region -- OnMouseMove -----------------------------------------------------------
			Point coords = e.GetPosition(ChartPanel);
			MM.X = ChartingExtensions.ConvertToHorizontalPixels(coords.X, ChartControl.PresentationSource);//+ barwidth_int;
			MM.Y = ChartingExtensions.ConvertToVerticalPixels(coords.Y, ChartControl.PresentationSource);
			MM.MouseABar = ChartBars.GetBarIdxByX(ChartControl, MM.X);
line=5240;
			MM.HoverProfileId = -1;
			var profs = Prof.Where(x => x.Value.StartABar < MM.MouseABar-1 && x.Value.EndABar > MM.MouseABar).Select(x => x.Key).ToList();
			if(profs!=null && profs.Count>0) MM.HoverProfileId = profs.Min();

			#region -- Display current profile info in LL corner --
			if(false && IsDebug){
				#region -- Print moc info for debug --
				try{
					RemoveThisTag("moc");
					var precList = Prof.Where(x => x.Value.StartABar<=MM.MouseABar && x.Value.EndABar>MM.MouseABar).ToList();
					if(precList!=null && precList.Count>0){
						var prec = precList[0];
line=5253;
						int dd=Prof.Keys.ToList().IndexOf(prec.Key);
						var RESinfo = "RES   N/A";//  Overlap: N/A  Disq: N/A  Tst: N/A  Bkn: N/A";
						if(prec.Value.Zones.ContainsKey(RES_ID)){
							RESinfo = string.Format("RES {0}-{1}   Ovlap: {2}@{3}  Disp: {4} Disq: {5}  Tst: {6}  Bkn: {7}@{8}  TstDate {9} at {10}",  
										Instrument.MasterInstrument.FormatPrice(prec.Value.Zones[RES_ID].HighPrice), 
										Instrument.MasterInstrument.FormatPrice(prec.Value.Zones[RES_ID].LowPrice), 
										prec.Value.Zones[RES_ID].Overlapped.ToString(), 
										prec.Value.Zones[RES_ID].OverlappedABar==int.MaxValue ? "inf" : prec.Value.Zones[RES_ID].OverlappedABar.ToString(), 
										prec.Value.Zones[RES_ID].Disposition, 
										prec.Value.Zones[RES_ID].Disqualified.ToString(), 
										prec.Value.Zones[RES_ID].Tested.ToString(), 
										prec.Value.Zones[RES_ID].Broken.ToString(),
										prec.Value.Zones[RES_ID].BrokenABar.ToString(),
										prec.Value.Zones[RES_ID].TestedDate.ToString(),
										prec.Value.Zones[RES_ID].EndABar==int.MaxValue ? "inf" : prec.Value.Zones[RES_ID].EndABar.ToString()
								);
							RESinfo = RESinfo.Replace("True","T").Replace("False","F");
						}
line=5272;
						var SUPinfo = "SUP   N/A";//  Overlap: N/A  Disq: N/A  Tst: N/A  Bkn: N/A";
						if(prec.Value.Zones.ContainsKey(SUP_ID)){
							SUPinfo = string.Format("SUP {0}-{1}  Ovlap: {2}@{3}  Disp: {4} Disq: {5}  Tst: {6}  Bkn: {7}@{8}  TstDate {9} at {10}",  
										Instrument.MasterInstrument.FormatPrice(prec.Value.Zones[SUP_ID].HighPrice), 
										Instrument.MasterInstrument.FormatPrice(prec.Value.Zones[SUP_ID].LowPrice), 
										prec.Value.Zones[SUP_ID].Overlapped.ToString(), 
										prec.Value.Zones[SUP_ID].OverlappedABar==int.MaxValue ? "inf" : prec.Value.Zones[SUP_ID].OverlappedABar.ToString(), 
										prec.Value.Zones[SUP_ID].Disposition, 
										prec.Value.Zones[SUP_ID].Disqualified.ToString(), 
										prec.Value.Zones[SUP_ID].Tested.ToString(), 
										prec.Value.Zones[SUP_ID].Broken.ToString(),
										prec.Value.Zones[SUP_ID].BrokenABar.ToString(),
										prec.Value.Zones[SUP_ID].TestedDate.ToString(),
										prec.Value.Zones[SUP_ID].EndABar==int.MaxValue ? "inf" : prec.Value.Zones[SUP_ID].EndABar.ToString()
								);
							SUPinfo = SUPinfo.Replace("True","T").Replace("False","F");
						}
line=5290;
						Draw.TextFixed(this,"moc",MM.MouseABar+"-abar  "+
							string.Format("Profile: {0}  s:{1}-{2} {3}-{4}\nSessDate: {7} vpPOC {8} Open/Close: {9}/{10}   tpoPOC {11} VAH/L {12}/{13}  IsSignular: {12}\n{5}\n{6}\n", 
									dd, 
									prec.Value.StartABar, prec.Value.EndABar, prec.Value.StartTime.ToString(), prec.Value.EndTime.ToString(),
									RESinfo, SUPinfo, prec.Value.SessionDate.ToShortDateString(), prec.Value.ConsolidatedvpPOC_Price, 
									RoundToTick(prec.Value.OpenPrice), RoundToTick(prec.Value.ClosePrice),	prec.Value.tpoPOC_Price, prec.Value.tpoVAH_Price, 
									prec.Value.tpoVAL_Price, prec.Value.IsSingularDistribution.ToString()
							), TextPosition.BottomLeft);
//						foreach(var kkx in TPO_Data.) 
					}
				}catch(Exception ee){PrintNew1(line+"  E: "+ee.ToString());}
				#endregion
			}
			#endregion

			if(!pGlobalObjects_Enabled) return;
			#region -- MouseMove - Global object selection ----------------------------------------------------------
            //detect if mouse over a TPO ValueArea bar
			MM.SelectedProfileId = int.MinValue;
			MM.ChoosingToAddRay = false;
			if(Prof.ContainsKey(MM.MouseABar-1)){
				MM.SelectedProfileId = MM.MouseABar-1;
				MM.ChoosingToAddRay = true;
			}else if(Prof.ContainsKey(MM.MouseABar)){
				MM.SelectedProfileId = MM.MouseABar;
				MM.ChoosingToAddRay = true;
			}else {
				MM.SelectedProfileId = int.MinValue;
			}

			MM.SelectedRayData[0] = -1;
			MM.SelectedArbZoneData[0] = -1;
			MM.SelectedArbZoneData[1] = -1;
			MM.SelectedArbZoneData[2] = -1;
			MM.SelectedArbZoneData[3] = -1;
			MM.SelectedArbZoneType=' ';
//PrintNew1("MOusemove: "+MM.MousePrice);
//			var prof = Prof.Where(p => p.Key <= MM.SelectedProfileId && p.Value.EndABar < MM.SelectedProfileId).Select(p => p.Value).ToList();
			//foreach(var p in prof)
			int ray_type = int.MinValue;
			if(MM.SelectedProfileId!=int.MinValue)
			{
				MM.MousePrice = RoundToTick(MM.MousePrice);
//		Print("Selected Profile: "+MM.SelectedProfileId);
//		Print("MousePrice: "+MM.MousePrice);
				var p = Prof[MM.SelectedProfileId];
				if(MM.MousePrice < Math.Max(p.vpVAH_Price,p.tpoVAH_Price) || MM.MousePrice > Math.Min(p.vpVAL_Price,p.tpoVAL_Price)){
					ray_type = int.MinValue;
					if(MM.MousePrice == p.ConsolidatedvpPOC_Price) {
						MM.SelectedRayData[0] = p.ConsolidatedvpPOC_Price; 
						MM.SelectedRayData[1] = V_ID;
						MM.SelectedRayData[2] = POC_ID; 
					}
					else if(MM.MousePrice == p.tpoPOC_Price) {
						MM.SelectedRayData[0] = p.tpoPOC_Price; 
						MM.SelectedRayData[1] = TPO_ID;
						MM.SelectedRayData[2] = POC_ID; 
					}
					else{
//		Print("p.vpVAH: "+p.vpVAH_Price+"  vpVAL: "+p.vpVAH_Price);
//		Print("p.tpoVAH: "+p.tpoVAH_Price+"  tpoVAL: "+p.tpoVAH_Price);
						if(MM.MousePrice > p.vpVAH_Price  && MM.MousePrice <= p.tpoVAH_Price) ray_type = TPO_ID;
						else if(MM.MousePrice > p.tpoVAH_Price && MM.MousePrice <= p.vpVAH_Price)  ray_type = V_ID;
						else if(MM.MousePrice < p.tpoVAL_Price && MM.MousePrice >= p.vpVAL_Price)  ray_type = V_ID;
						else if(MM.MousePrice < p.vpVAL_Price  && MM.MousePrice >= p.tpoVAL_Price) ray_type = TPO_ID;
						else if(Keyboard.IsKeyDown(Key.LeftCtrl) && MM.MousePrice <= p.vpVAH_Price && MM.MousePrice >= p.vpVAL_Price) ray_type = V_ID;
						else if(!Keyboard.IsKeyDown(Key.LeftCtrl) && MM.MousePrice <= p.tpoVAH_Price && MM.MousePrice >= p.tpoVAL_Price) ray_type = TPO_ID;
						if(ray_type==TPO_ID) {
							MM.SelectedRayData[0] = p.tpoVAH_Price; 
							MM.SelectedRayData[1] = p.tpoVAL_Price; 
							MM.SelectedRayData[2] = TPO_ID;
						}// PrintNew1(string.Format(" -------------- 1616  {0} {1} {2}",MM.SelectedRayData[0],MM.SelectedRayData[1],MM.SelectedRayData[2]));}
						else if(ray_type==V_ID){
							MM.SelectedRayData[0] = p.vpVAH_Price;  
							MM.SelectedRayData[1] = p.vpVAL_Price;  
							MM.SelectedRayData[2] = V_ID;
						}//  PrintNew1(string.Format(" -------------- 1617  {0} {1} {2}",MM.SelectedRayData[0],MM.SelectedRayData[1],MM.SelectedRayData[2]));}
						else{
							MM.SelectedRayData[0] = double.MinValue;  
							MM.SelectedRayData[1] = double.MinValue;  
							MM.SelectedRayData[2] = double.MinValue;
						}//  PrintNew1(string.Format(" -------------- 1617  {0} {1} {2}",MM.SelectedRayData[0],MM.SelectedRayData[1],MM.SelectedRayData[2]));}
					}
				}
			}else{
				var zone_identified = false;
				if(pShow_FreshZones){
					#region -- See if the user is selecting a fresh zone ---------------------------------------------------------
					var plist = Prof.Where(k => 
							(MM.MouseABar >=k.Value.StartABar || k.Value.EndABar==-1) 
							&& k.Value.Zones.ContainsKey(RES_ID) 
							&& k.Value.Zones[            RES_ID].Disposition=='F'
							&& k.Value.Zones.Any(kz => kz.Value.HighPrice > MM.ChartMinPrice && kz.Value.LowPrice < MM.ChartMaxPrice)).ToList();
					if(plist!=null && plist.Count>0){
						foreach(var p in plist){
							foreach(var z in p.Value.Zones){
								if(MM.X > z.Value.ScreenXYWH[0] && MM.X<z.Value.ScreenXYWH[0]+z.Value.ScreenXYWH[2] && MM.Y > z.Value.ScreenXYWH[1] && MM.Y < z.Value.ScreenXYWH[1]+z.Value.ScreenXYWH[3]){
									MM.SelectedArbZoneData[0] = p.Value.StartABar;
																	//[0] is the abar of left-edge of rectangle
																	//[1] is the price of the top edge of the rectangle
																	//[2] is the abar of the right edge of the rectangle, int.MaxValue if it's a fresh zone
																	//[3] is the price of the bottom edge of the rectangle
									MM.SelectedArbZoneData[1] = z.Value.HighPrice;
									MM.SelectedArbZoneData[2] = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									MM.SelectedArbZoneData[3] = z.Value.LowPrice;
									MM.SelectedArbZoneType = 'R';
									MM.SelectedProfileId = p.Key;
									zone_identified = true;
//if(IsDebug) PrintNew1(string.Format("RES Zone identified: {0}-{1}  H: {2} L: {3}", MM.SelectedArbZoneData[0], (MM.SelectedArbZoneData[2]==int.MaxValue ? "unending":MM.SelectedArbZoneData[2].ToString()), MM.SelectedArbZoneData[1], MM.SelectedArbZoneData[3]));
								}
							}
						}
					}
					if(!zone_identified){
						plist = Prof.Where(k => 
								(MM.MouseABar >=k.Value.StartABar || k.Value.EndABar==-1) 
								&& k.Value.Zones.ContainsKey(SUP_ID) 
								&& k.Value.Zones[            SUP_ID].Disposition=='F'
								&& k.Value.Zones.Any(kz => kz.Value.HighPrice > MM.ChartMinPrice && kz.Value.LowPrice < MM.ChartMaxPrice)).ToList();
						if(plist!=null && plist.Count>0){
							foreach(var p in plist){
								foreach(var z in p.Value.Zones){
									if(MM.X > z.Value.ScreenXYWH[0] && MM.X<z.Value.ScreenXYWH[0]+z.Value.ScreenXYWH[2] && MM.Y > z.Value.ScreenXYWH[1] && MM.Y < z.Value.ScreenXYWH[1]+z.Value.ScreenXYWH[3]){
										MM.SelectedArbZoneData[0] = p.Value.StartABar;
										MM.SelectedArbZoneData[1] = z.Value.HighPrice;
										MM.SelectedArbZoneData[2] = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
										MM.SelectedArbZoneData[3] = z.Value.LowPrice;
										MM.SelectedArbZoneType = 'S';
										MM.SelectedProfileId = p.Key;
										zone_identified = true;
//if(IsDebug) PrintNew1(string.Format("SUP Zone identified: {0}-{1}  H: {2} L: {3}", MM.SelectedArbZoneData[0], (MM.SelectedArbZoneData[2]==int.MaxValue ? "unending":MM.SelectedArbZoneData[2].ToString()), MM.SelectedArbZoneData[1], MM.SelectedArbZoneData[3]));
									}
								}
							}
						}
					}
					#endregion
				}
				if(pShow_BrokenZones && !zone_identified){
					#region -- See if the user is selecting a broken zone -----------------------------------------------------------
					var plist = Prof.Where(k => 
							(MM.MouseABar >=k.Value.StartABar || k.Value.EndABar==-1) 
							&& k.Value.Zones.ContainsKey(RES_ID) 
							&& k.Value.Zones[            RES_ID].Disposition=='B' 
							&& k.Value.Zones.Any(kz => kz.Value.HighPrice > MM.ChartMinPrice && kz.Value.LowPrice < MM.ChartMaxPrice)).ToList();
					if(plist!=null && plist.Count>0){
						foreach(var p in plist){
							foreach(var z in p.Value.Zones){
								if(MM.X > z.Value.ScreenXYWH[0] && MM.X<z.Value.ScreenXYWH[0]+z.Value.ScreenXYWH[2] && MM.Y > z.Value.ScreenXYWH[1] && MM.Y < z.Value.ScreenXYWH[1]+z.Value.ScreenXYWH[3]){
									MM.SelectedArbZoneData[0] = p.Value.StartABar;
									MM.SelectedArbZoneData[1] = z.Value.HighPrice;
									MM.SelectedArbZoneData[2] = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									MM.SelectedArbZoneData[3] = z.Value.LowPrice;
									MM.SelectedArbZoneType = 'R';
									MM.SelectedProfileId = p.Key;
									zone_identified = true;
								}
							}
						}
					}
					if(!zone_identified){
						plist = Prof.Where(k => 
							(MM.MouseABar >=k.Value.StartABar || k.Value.EndABar==-1)
							&& k.Value.Zones.ContainsKey(SUP_ID) 
							&& k.Value.Zones[            SUP_ID].Disposition=='B' 
							&& k.Value.Zones.Any(kz => kz.Value.HighPrice > MM.ChartMinPrice && kz.Value.LowPrice < MM.ChartMaxPrice)).ToList();
						if(plist!=null && plist.Count>0){
							foreach(var p in plist){
								foreach(var z in p.Value.Zones){
									if(MM.X > z.Value.ScreenXYWH[0] && MM.X<z.Value.ScreenXYWH[0]+z.Value.ScreenXYWH[2] && MM.Y > z.Value.ScreenXYWH[1] && MM.Y < z.Value.ScreenXYWH[1]+z.Value.ScreenXYWH[3]){
										MM.SelectedArbZoneData[0] = p.Value.StartABar;
										MM.SelectedArbZoneData[1] = z.Value.HighPrice;
										MM.SelectedArbZoneData[2] = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
										MM.SelectedArbZoneData[3] = z.Value.LowPrice;
										MM.SelectedArbZoneType = 'S';
										MM.SelectedProfileId = p.Key;
										zone_identified = true;
									}
								}
							}
						}
					}
					#endregion
				}
				if(this.pShow_DisqZones && !zone_identified){
					#region -- See if the user is selecting a disqualified zone ----------------------------------------------------------
					var plist = Prof.Where(k => 
						(MM.MouseABar >=k.Value.StartABar || k.Value.EndABar==-1) 
						&& k.Value.Zones.ContainsKey(RES_ID) 
						&& k.Value.Zones[            RES_ID].Disposition=='D'
						&& k.Value.Zones.Any(kz => kz.Value.HighPrice > MM.ChartMinPrice && kz.Value.LowPrice < MM.ChartMaxPrice)).ToList();
					if(plist!=null && plist.Count>0){
						foreach(var p in plist){
							foreach(var z in p.Value.Zones){
								if(MM.X > z.Value.ScreenXYWH[0] && MM.X<z.Value.ScreenXYWH[0]+z.Value.ScreenXYWH[2] && MM.Y > z.Value.ScreenXYWH[1] && MM.Y < z.Value.ScreenXYWH[1]+z.Value.ScreenXYWH[3]){
									MM.SelectedArbZoneData[0] = p.Value.StartABar;
									MM.SelectedArbZoneData[1] = z.Value.HighPrice;
									MM.SelectedArbZoneData[2] = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									MM.SelectedArbZoneData[3] = z.Value.LowPrice;
									MM.SelectedArbZoneType = 'R';
									MM.SelectedProfileId = p.Key;
									zone_identified = true;
								}
							}
						}
					}
					if(!zone_identified){
						plist = Prof.Where(k => 
							(MM.MouseABar >=k.Value.StartABar || k.Value.EndABar==-1) 
							&& k.Value.Zones.ContainsKey(SUP_ID) 
							&& k.Value.Zones[            SUP_ID].Disposition=='D'
							&& k.Value.Zones.Any(kz => kz.Value.HighPrice > MM.ChartMinPrice && kz.Value.LowPrice < MM.ChartMaxPrice)).ToList();
						if(plist!=null && plist.Count>0){
							foreach(var p in plist){
								foreach(var z in p.Value.Zones){
									if(MM.X > z.Value.ScreenXYWH[0] && MM.X<z.Value.ScreenXYWH[0]+z.Value.ScreenXYWH[2] && MM.Y > z.Value.ScreenXYWH[1] && MM.Y < z.Value.ScreenXYWH[1]+z.Value.ScreenXYWH[3]){
										MM.SelectedArbZoneData[0] = p.Value.StartABar;
										MM.SelectedArbZoneData[1] = z.Value.HighPrice;
										MM.SelectedArbZoneData[2] = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
										MM.SelectedArbZoneData[3] = z.Value.LowPrice;
										MM.SelectedArbZoneType = 'S';
										MM.SelectedProfileId = p.Key;
									}
								}
							}
						}
					}
					#endregion
				}
				if(pShow_TestedZones && !zone_identified){
					#region -- See if the user is selecting a tested zone ----------------------------------------------------------
					var plist = Prof.Where(k => 
						(MM.MouseABar >=k.Value.StartABar || k.Value.EndABar==-1) 
						&& k.Value.Zones.ContainsKey(RES_ID) 
						&& k.Value.Zones[            RES_ID].Disposition=='T'
						&& k.Value.Zones.Any(kz => kz.Value.HighPrice > MM.ChartMinPrice && kz.Value.LowPrice < MM.ChartMaxPrice)).ToList();
					if(plist!=null && plist.Count>0){
						foreach(var p in plist){
							foreach(var z in p.Value.Zones){
								if(MM.X > z.Value.ScreenXYWH[0] && MM.X<z.Value.ScreenXYWH[0]+z.Value.ScreenXYWH[2] && MM.Y > z.Value.ScreenXYWH[1] && MM.Y < z.Value.ScreenXYWH[1]+z.Value.ScreenXYWH[3]){
									MM.SelectedArbZoneData[0] = p.Value.StartABar;
									MM.SelectedArbZoneData[1] = z.Value.HighPrice;
									MM.SelectedArbZoneData[2] = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
									MM.SelectedArbZoneData[3] = z.Value.LowPrice;
									MM.SelectedArbZoneType = 'R';
									MM.SelectedProfileId = p.Key;
									zone_identified = true;
								}
							}
						}
					}
					if(!zone_identified){
						plist = Prof.Where(k => 
							(MM.MouseABar >=k.Value.StartABar || k.Value.EndABar==-1) 
							&& k.Value.Zones.ContainsKey(SUP_ID) 
							&& k.Value.Zones[            SUP_ID].Disposition=='T'
							&& k.Value.Zones.Any(kz => kz.Value.HighPrice > MM.ChartMinPrice && kz.Value.LowPrice < MM.ChartMaxPrice)).ToList();
						if(plist!=null && plist.Count>0){
							foreach(var p in plist){
								foreach(var z in p.Value.Zones){
									if(MM.X > z.Value.ScreenXYWH[0] && MM.X<z.Value.ScreenXYWH[0]+z.Value.ScreenXYWH[2] && MM.Y > z.Value.ScreenXYWH[1] && MM.Y < z.Value.ScreenXYWH[1]+z.Value.ScreenXYWH[3]){
										MM.SelectedArbZoneData[0] = p.Value.StartABar;
										MM.SelectedArbZoneData[1] = z.Value.HighPrice;
										MM.SelectedArbZoneData[2] = z.Value.EndABar<0 ? int.MaxValue : z.Value.EndABar;
										MM.SelectedArbZoneData[3] = z.Value.LowPrice;
										MM.SelectedArbZoneType = 'S';
										MM.SelectedProfileId = p.Key;
									}
								}
							}
						}
					}
					#endregion
				}
			}
//		PrintNew1("  zone type: "+MM.SelectedArbZoneType);
//		PrintNew1("  ray type: "+ray_type);
//		if(MM.SelectedArbZoneType != ' '){
//			PrintNew1("			MM.SelectedArbZoneData[0] = "+MM.SelectedArbZoneData[0]);
//			PrintNew1("			MM.SelectedArbZoneData[1] = "+MM.SelectedArbZoneData[1]);
//			PrintNew1("			MM.SelectedArbZoneData[2] = "+MM.SelectedArbZoneData[2]);
//			PrintNew1("			MM.SelectedArbZoneData[3] = "+MM.SelectedArbZoneData[3]);
//		}else{
//			PrintNew1("   SelectedRayData[0]: "+MM.SelectedRayData[0]);
//			PrintNew1("   SelectedRayData[1]: "+MM.SelectedRayData[1]);
//			PrintNew1("   SelectedRayData[2]: "+MM.SelectedRayData[2]);
//		}

			ChartControl.InvalidateVisual();
			#endregion
			#endregion
		}
		//=========================================================================================
		private void OnMouseUp(object sender, MouseButtonEventArgs e)
		{
			if(e.ChangedButton == MouseButton.Left && Keyboard.IsKeyDown(Key.RightCtrl)){
				SaveArbZoneData = true;
				ForceRefresh();
			}
			#region -- OnMouseUp -----------------------------------------------------------------------
			int profile_count = Prof.Count;
			bool handledOk = false;
			if(IsSplitMergeEnabled){
//if(IsDebug) Print("MM.SelectedProfileId: "+MM.SelectedProfileId);
				if(!MM.ChoosingToAddRay && e.ChangedButton == MouseButton.Middle && Keyboard.IsKeyDown(Key.LeftCtrl)) {
					handledOk = true;
					#region -- MiddleMouse button + LeftCtrl clicked, merge/split all profiles on this date --
					var ks = Prof.Keys.Where(pk=> pk<MM.MouseABar).ToList();
					if(ks==null || ks.Count<1) return;
					MergeAndSplitThisSessionDate(ks.Max(), false);
					#endregion -----------------------------
//================================
				}else if(!MM.ChoosingToAddRay && e.ChangedButton == MouseButton.Left && !Keyboard.IsKeyDown(Key.LeftCtrl)){//user may have clicked on the TPO for manual splitting
					#region -- See if a valid split location has been clicked on --
					var profs = Prof.Where(x => x.Value.StartABar < MM.MouseABar && x.Value.EndABar > MM.MouseABar).Select(x => x.Key).ToList();
					if(profs != null && profs.Count!=0){
						var profileId   = profs.Max();
						var mouse_price = RoundToTick(MM.MousePrice);
//foreach(var sdd in Prof[profileId].ScreenXY_TpoEdge)
//	PrintNew1("TpoEdge: "+sdd.Key+"  "+sdd.Value);
						if(IsSplitAssist){
							#region -- Determine if the mouse click was on the SplitAssistMarker --
//PrintNew1("MousePrice: "+mouse_price);
//PrintNew1("    "+MM.X+"    "+Prof[profileId].SplitAssistMarker_ScreenXYWH[0]+" : "+(Prof[profileId].SplitAssistMarker_ScreenXYWH[0]+Prof[profileId].SplitAssistMarker_ScreenXYWH[2]).ToString());
//PrintNew1("    "+MM.Y+"    "+Prof[profileId].SplitAssistMarker_ScreenXYWH[1]+" : "+(Prof[profileId].SplitAssistMarker_ScreenXYWH[0]+Prof[profileId].SplitAssistMarker_ScreenXYWH[3]).ToString());
line=5616;
							if(
//								TickSize*5 > diff && 
								MM.X >= Prof[profileId].SplitAssistMarker_ScreenXYWH[0] &&
								MM.X <= Prof[profileId].SplitAssistMarker_ScreenXYWH[0]+Prof[profileId].SplitAssistMarker_ScreenXYWH[2] &&
								MM.Y >= Prof[profileId].SplitAssistMarker_ScreenXYWH[1] &&
								MM.Y <= Prof[profileId].SplitAssistMarker_ScreenXYWH[1]+Prof[profileId].SplitAssistMarker_ScreenXYWH[3]){
									SplitProfile(profileId, Prof[profileId].SplitAssistPrice, true, true, IsDebug);
									handledOk = true;
							}
							#endregion
						}else if(Prof[profileId].ScreenXY_TpoEdge.ContainsKey(mouse_price)){
							if(MM.X <= Prof[profileId].ScreenXY_TpoEdge[mouse_price]+15f &&
								MM.X >= Prof[profileId].ScreenXY_TpoEdge[mouse_price]-15f) {
								#region -- If mouse was not on SplitAssistMarker, then split on the selected TPO letter
//PrintNew1("MM.MousePrice: "+MM.MousePrice+"   profileId: "+profileId);
//var str = string.Empty;
//foreach(var s in Prof[profileId].TPOatP[mouse_price]) str = string.Format("{0} {1}",str,s);
//PrintNew1("  "+str);
								SplitProfile(profileId, mouse_price, false, false, false);
								#endregion
								handledOk = true;
							}
						}
					}
					#endregion
				}else if(!MM.ChoosingToAddRay && e.ChangedButton == MouseButton.Left && Keyboard.IsKeyDown(Key.LeftCtrl)){//merge the profile you're hovering over with the profile to the left of it
					var proId = Prof.Keys.Where(k=> k<=MM.MouseABar).ToList();
					if(proId!=null && proId.Count>1){
						handledOk = true;
						int left = proId[proId.Count-2];
						int right = proId[proId.Count-1];
line=5648;
						MergeProfiles(left, right, false, false);
					}
				}

				if(Prof.Count!=profile_count){
					var profs = Prof.Where(x=> x.Value.EndABar > MM.MouseABar).Select(x=> x.Key).ToList();
					ResetProfileDates();
line=5656;
					if(profs!=null && profs.Count>0){
						CheckArbZoneTouchOrBreak(Prof[profs[0]].SessionDate, true);
line=5659;
//						foreach(var pkey in profs){
//							Prof[pkey].UnbrokenZonesCount = 0;
//							foreach(ArbZone zone in Prof[pkey].Zones.Values){
//								if(!zone.Broken) Prof[pkey].UnbrokenZonesCount++;
//							}
//						}
						CleanUpOrphanedRaysAndRectangles();
						InitialzeVolNodeTerminationStates(Prof[profs[0]].SessionDate);
						DetermineOverlappedZones(profs.Min());
						DetermineDisqualifiedZones(profs.Min());
					}
				}
			}
			if(!handledOk){
				#region -- Select Global Objects --
				if(this.pGlobalObjects_Enabled && MM.SelectedProfileId>=0)// && ProfileDates.ContainsKey(MM.SelectedProfileId))
				{
					string tagH;
					string tagL;
					string tagPOC;
					if(MM.ChoosingToAddRay && MM.SelectedArbZoneData[0]<0 && (MM.SelectedRayData[2]==TPO_ID || MM.SelectedRayData[2]==V_ID)){
						tagH = string.Format("H{0}_{1}_{2}", ObjTagPrefix, MM.SelectedProfileId, MM.SelectedRayData[2]);
						tagL = string.Format("L{0}_{1}_{2}", ObjTagPrefix, MM.SelectedProfileId, MM.SelectedRayData[2]);
						if(Global_VAHL_Rays.ContainsKey(tagH) || Global_VAHL_Rays.ContainsKey(tagL)) {//if either is present, then delete them both
							RemoveThisTag(tagH);
							Global_VAHL_Rays.Remove(tagH);
							RemoveThisTag(tagL);
							Global_VAHL_Rays.Remove(tagL);
						}else{//if both are not present, then draw them both
							if(MM.SelectedRayData[0]>=0 && Prof.ContainsKey(MM.SelectedProfileId)){
								string TemplateTPOhigh = phTPO_VAH_RayTemplate;
								string TemplateVPhigh  =  phVP_VAH_RayTemplate;
								string TemplateTPOlow  = phTPO_VAL_RayTemplate;
								string TemplateVPlow   =  phVP_VAL_RayTemplate;
								if(ProfileInCurrentSession(MM.SelectedProfileId)){
									TemplateTPOhigh = pcTPO_VAH_RayTemplate;
									TemplateVPhigh  =  pcVP_VAH_RayTemplate;
									TemplateTPOlow  = pcTPO_VAL_RayTemplate;
									TemplateVPlow   =  pcVP_VAL_RayTemplate;
								}
								Global_VAHL_Rays[tagH] = new Global_RaysData(
													Times[0].GetValueAt(MM.SelectedProfileId+1),  MM.SelectedProfileId, Convert.ToInt32(MM.SelectedRayData[2]), RES_ID, 
													MM.SelectedRayData[0], 
													MM.SelectedRayData[2]==TPO_ID ? TemplateTPOhigh : TemplateVPhigh);
								Global_VAHL_Rays[tagH].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tagH]);

								Global_VAHL_Rays[tagL] = new Global_RaysData(
												Times[0].GetValueAt(MM.SelectedProfileId+1),  MM.SelectedProfileId, Convert.ToInt32(MM.SelectedRayData[2]), SUP_ID,
												MM.SelectedRayData[1], 
												MM.SelectedRayData[2]==TPO_ID ? TemplateTPOlow : TemplateVPlow);
								Global_VAHL_Rays[tagL].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tagL]);
								ImmediatelyDraw_Ray(tagH, Global_VAHL_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
								ImmediatelyDraw_Ray(tagL, Global_VAHL_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
							}
						}
					}else if(MM.ChoosingToAddRay && MM.SelectedArbZoneData[0]<0 && MM.SelectedRayData[2]==POC_ID){
						tagPOC = string.Format("POC{0}_{1}_{2}", ObjTagPrefix, MM.SelectedProfileId, MM.SelectedRayData[1].ToString("0"));
						if(Global_POC_Rays.ContainsKey(tagPOC)) {//if POC ray is present, then delete it
							RemoveThisTag(tagPOC);
							Global_POC_Rays.Remove(tagPOC);
						}else{//if POC ray is not present, then draw
							if(MM.SelectedRayData[0]>=0 && Prof.ContainsKey(MM.SelectedProfileId)){
								var template_name = string.Empty;
								if(ProfileInCurrentSession(MM.SelectedProfileId))
									template_name = MM.SelectedRayData[1]==TPO_ID ? pcTPO_POC_RayTemplate : pcVP_POC_RayTemplate;
								else
									template_name = MM.SelectedRayData[1]==TPO_ID ? phTPO_POC_RayTemplate : phVP_POC_RayTemplate;

								Global_POC_Rays[tagPOC] = new Global_RaysData(
												Times[0].GetValueAt(MM.SelectedProfileId+1),  MM.SelectedProfileId, Convert.ToInt32(MM.SelectedRayData[2]), Convert.ToInt32(MM.SelectedRayData[1]),
												MM.SelectedRayData[0],
												template_name);
								Global_POC_Rays[tagPOC].EndDT = UpdateRayEndDT(Global_POC_Rays[tagPOC]);
								ImmediatelyDraw_Ray(tagPOC, Global_POC_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
							}
						}
					}else{
line=5737;
						var tag = string.Format("Z{0}_{1}_{2}#{3}", ObjTagPrefix, MM.SelectedProfileId, MM.SelectedArbZoneType.ToString(), MM.SelectedArbZoneData[1]);//Data[1] is the price of the top-edge rectangle
						if(Global_Arb_Rects.ContainsKey(tag) && Global_Arb_Rects[tag].IsDrawn) {
							RemoveThisTag(tag);
							Global_Arb_Rects.Remove(tag);
						}else{
//PrintNew1("MouseUp  Zonetype: "+MM.SelectedArbZoneType+"   ProDate: "+Times[0].GetValueAt(MM.SelectedProfileId).ToString()+"   tag: "+tag);
							if(MM.SelectedArbZoneType == 'S'){
								Global_Arb_Rects[tag] = new Global_RectsData(
												(int)MM.SelectedArbZoneData[0],
												BarsArray[0].GetTime((int)MM.SelectedArbZoneData[0]+1), 
												MM.SelectedArbZoneData[1],
												MM.SelectedArbZoneData[2]>=BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime((int)MM.SelectedArbZoneData[2]+1), 
												MM.SelectedArbZoneData[3], pcSupZone_Template, 'S');
								ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//PrintNew1("Created S rect at "+tag+"  "+Global_Arb_Rects[tag].ToString());
							}
							else if(MM.SelectedArbZoneType == 'R'){
								Global_Arb_Rects[tag] = new Global_RectsData((int)MM.SelectedArbZoneData[0],
												BarsArray[0].GetTime((int)MM.SelectedArbZoneData[0]+1), 
												MM.SelectedArbZoneData[1], 
												MM.SelectedArbZoneData[2]>=BarsArray[0].Count ? BarsArray[0].GetTime(CurrentBars[0]).AddDays(5) : BarsArray[0].GetTime((int)MM.SelectedArbZoneData[2]+1), 
												MM.SelectedArbZoneData[3], pcResZone_Template, 'R');
								ImmediatelyDraw_Zone(tag, Global_Arb_Rects);
//PrintNew1("Created R rect at "+tag+"  "+Global_Arb_Rects[tag].ToString());
							}
						}
					}
//				}catch(Exception e4496){PrintNew1(line+"  e682  "+e4496.ToString());}
				}
				#endregion

				MM.obj_count = CalculateCountOfGlobalObjects();
				#region -- Clear Global Objects --
				if(MM.obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
				#endregion
			}
			#endregion
			ForceRefresh();
		}
		//=========================================================================================
		#endregion
//=====================================================================================================
		private void MergeAllProfiles(){
			int left  = 0;
			int right = 0;
			var datekeys = ProfileDates.Keys.ToList();
			foreach(var sesskey in datekeys){
				left = sesskey;
				if(!Prof.ContainsKey(left)) continue;
				var sessiondate = ProfileDates[left];

				var keys = Prof.Keys.Where(k => Prof[k].SessionDate == Prof[left].SessionDate && k>left).ToList();
				while(keys.Count>=1){
					right = keys[0];
					OneSimpleMerge(left, right, false);
					keys.RemoveAt(0);
				}
				CleanUpOrphanedRaysAndRectangles(sessiondate);
			}
		}
//=====================================================================================================
		private void MergeAllProfilesInThisRange(int left, int right){
			var keys = Prof.Keys.Where(k => k >=left && k <= right).ToList();
			int minKey = 0;
			int maxKey = 0;
			if(keys != null && keys.Count>1){
				minKey = keys.Min();
				maxKey = keys.Max();
			}else return;

			int iteration=0;
			bool done = false;
			var ProfileDates_Subset = new SortedDictionary<int, DateTime>(ProfileDates.Where(x => x.Key>=minKey && x.Key <= maxKey).ToSortedDictionary());
			foreach(var sessdate in ProfileDates_Subset){
				left = sessdate.Key;
				try{
					keys = Prof.Keys.Where(k => k >= minKey && k<=maxKey && Prof[k].SessionDate == sessdate.Value.Date).ToList();
					iteration++; if(iteration>40) return;
					while(keys!=null && keys.Count>1){
						right  = keys[1];
						OneSimpleMerge(left, right, false);
						minKey = right;
						keys.RemoveAt(1);
					}
					CleanUpOrphanedRaysAndRectangles(sessdate.Value);
				}catch(Exception ex){PrintNew1("L5231: "+ex.ToString());}
			}
		}
//=====================================================================================================
		private List<int> MergeAndSplitThisSessionDate(DateTime SplitThisDate, bool Forceful){
			#region -- MergeAndSplitThisSessionDate --
bool inzone = isLiveData && IsDebug;//line==5713;
			var pkeys = Prof.Where(x => x.Value.SessionDate == SplitThisDate.Date).Select(x => x.Key).ToList();
			if(pkeys != null){
				var inboundKeys = new List<int>(pkeys);
				UPDATE_globaldict_pricelevels = true;
				if(pkeys.Count==1 || Forceful){
					MergeAllProfilesInThisRange(pkeys.Min(), pkeys.Max());
					pkeys = Prof.Where(x => x.Value.SessionDate == SplitThisDate.Date && !x.Value.IsSingularDistribution).Select(x => x.Key).ToList();
if(inzone)Print("We are in MergeAndSplit...1st pass... pkeys.Count: "+pkeys.Count);
					#region -- Split then merge overlapping profiles on this session date --
					int  count = 0;
					while(pkeys!=null){
						if(pkeys.Count>1 && pkeys[0]>pkeys.Last()) pkeys.Reverse();
						for(int k = 0; k<pkeys.Count; k++){
if(inzone) Print(pkeys[k]+"  5533 Count was: "+count);
							SplitProfile(pkeys[k], Prof[pkeys[k]].SplitAssistPrice, true, false, inzone);
						}
						pkeys = Prof.Where(x => x.Value.SessionDate == SplitThisDate.Date && !x.Value.IsSingularDistribution).Select(x => x.Key).ToList();
						if(pkeys==null || count > 4) {break;}
						count++;
					}
					ResetProfileDates();
					if(this.IsAutoMergeOverlappers){ 
						MergeAllOverlappers(SplitThisDate, inzone);
						pkeys = Prof.Where(x => x.Value.SessionDate == SplitThisDate.Date && !x.Value.IsSingularDistribution).Select(x => x.Key).ToList();
					}
					#endregion
if(inzone)Print("We are in MergeAndSplit...2nd pass");
					#region -- Perform one additional split then merge overlapping profiles on this session date --
					count = 0;
					while(pkeys!=null){
						if(pkeys.Count>1 && pkeys[0]>pkeys.Last()) pkeys.Reverse();
						for(int k = 0; k<pkeys.Count; k++){
if(inzone) Print(pkeys[k]+"  5552 Count was: "+count);
							SplitProfile(pkeys[k], Prof[pkeys[k]].SplitAssistPrice, true, false, inzone);
						}
						pkeys = Prof.Where(x => x.Value.SessionDate == SplitThisDate.Date && !x.Value.IsSingularDistribution).Select(x => x.Key).ToList();
						if(pkeys==null || count > 4) {break;}
						count++;
					}
					ResetProfileDates();
					if(this.IsAutoMergeOverlappers){
						MergeAllOverlappers(SplitThisDate, inzone);
					}
					#endregion -----------------------------
				} else if(pkeys.Count>=2){
					#region -- Merge overlappers if chosen, or merge all if this date only if it has multiple profiles --
					if(this.IsAutoMergeOverlappers){ 
						MergeAllOverlappers(SplitThisDate, inzone);
					}else{
						int left  = 0;
						int right = 0;
						while(pkeys.Count>1){
							left  = pkeys[0];
							right = pkeys[1];
							MergeProfiles(left, right, false, inzone);
							pkeys = Prof.Where(x => x.Value.SessionDate == SplitThisDate.Date).Select(x => x.Key).ToList();
						}
					}
					#endregion --------------------------
				}
				ResetProfileDates();
				CleanUpOrphanedRaysAndRectangles(SplitThisDate);
				InitialzeVolNodeTerminationStates(SplitThisDate);
				CheckArbZoneTouchOrBreak(SplitThisDate, true);
				DetermineOverlappedZones(0);
				DetermineDisqualifiedZones(0);
				var pkeys2 = Prof.Where(x => x.Value.SessionDate == SplitThisDate.Date).Select(x => x.Key).ToList();
				if(pkeys2.Except(inboundKeys).Count()>0) return pkeys2;
				if(inboundKeys.Except(pkeys2).Count()>0) return pkeys2;
			}
line=5905;
			pkeys.Clear();
			return pkeys;
			#endregion --------------------------
		}
//=====================================================================================================
		private List<int> MergeAndSplitThisSessionDate(int profileId, bool Forceful){
			#region -- MergeAndSplitThisSessionDate --
			var date = Prof[profileId].SessionDate;
			return MergeAndSplitThisSessionDate(date, Forceful);
			#endregion --------------------------
		}
//=====================================================================================================
		private void SplitProfile(int IdBeingSplit, double SplitPrice, bool ExitOnSingularDistributionCondition, bool AutoMergeProfilesOnRight, bool inzone){
			#region -- SplitProfile --
			if(ExitOnSingularDistributionCondition && Prof[IdBeingSplit].IsSingularDistribution) {
				return;
			}
			if(!Prof[IdBeingSplit].TPOatP.ContainsKey(SplitPrice)) {
				if(SplitPrice>0) PrintNew1(Prof[IdBeingSplit].StartTime.ToString()+": "+SplitPrice+" Split price was not found in the TPOatP database");
				return;
			}
			int letters_count = Prof[IdBeingSplit].TPOatP[SplitPrice].Count;
if(IdBeingSplit<13700) inzone=false;
if(inzone){
	//PrintNew1("letters_count: "+letters_count);
	PrintNew1("\n-------\nIdBeingSplit: "    +IdBeingSplit);
	PrintNew1("  StartABar: "  +Prof[IdBeingSplit].StartABar +            " - "+Prof[IdBeingSplit].EndABar);
	PrintNew1("  StartTime: "  +Prof[IdBeingSplit].StartTime.ToString() + " - "+Prof[IdBeingSplit].EndTime.ToString());
}
			if(letters_count < this.pMinSplitDepth) {
				if(isLiveData) PrintNew1("Split Request Rejected:  Profile cannot be split at the selected price...not enough TPO depth to accommodate 2 new profiles");
				return; //profile cannot be split at the selected price...not enough TPO letters to accommodate 2 profiles
			}
			char letter = Prof[IdBeingSplit].TPOatP[SplitPrice][letters_count-2];//split on not the last letter in the distribution, split on the one prior to that.  The last letter in the distribution is to be the first letter in the new distribution.
			if(letter == END_OF_PROFILE_FLAG){
				var valid_letters = Prof[IdBeingSplit].TPOatP[SplitPrice].Where(ll=> ll != END_OF_PROFILE_FLAG).ToList();
				if(valid_letters==null || valid_letters.Count==0) {
					Prof[IdBeingSplit].IsSingularDistribution = true;
					Prof[IdBeingSplit].SplitAssistPrice       = double.MinValue;
					if(isLiveData) PrintNew1("Split Request Rejected:  The profile is a singular distribution");
					return;
				}
				letter = valid_letters[Math.Max(0,valid_letters.Count-2)];//split on not the last letter in the distribution, split on the one prior to that.  The last letter in the distribution is to be the first letter in the new distribution.
			}
			var bdkvp = TPO_Data.BarData.Where(kk => kk.Key > Prof[IdBeingSplit].StartTime && kk.Key<= Prof[IdBeingSplit].EndTime).ToList();
			if(bdkvp==null) return;
//if(inzone)
//{
//	PrintNew1("\n\n");
//	PrintNew1("5313   Letter: "+letter+"   Prof.StartTime: "+Prof[IdBeingSplit].StartTime.ToString()+" EndTime: "+Prof[IdBeingSplit].EndTime.ToString()+"  StartABar: "+Prof[IdBeingSplit].StartABar+" EndABar: "+Prof[IdBeingSplit].EndABar);
//	foreach(var kvp in bdkvp) Print("  "+kvp.Key+":  "+kvp.Value.Letter+"   "+kvp.Value.ToStr());
//}
			int lettersInThisSession = bdkvp.Count;
			int idxOfSplitLetter = 0;
			for(idxOfSplitLetter = 0; idxOfSplitLetter < bdkvp.Count; idxOfSplitLetter++){
//if(inzone)Print("idx:  "+idxOfSplitLetter+"    ... "+bdkvp[idxOfSplitLetter].Value.Letter);
				if(bdkvp[idxOfSplitLetter].Value.Letter == letter) break;
			}
			if(idxOfSplitLetter >= lettersInThisSession) {
				if(isLiveData) PrintNew1("Split Request Rejected:  The TPO selected was the last TPO slice in the session, no split at that position is possible");
				return; //the letter selected was the last letter in the session, no split at that letter is possible
			}
			if(idxOfSplitLetter < pMinSplitDepth) {
				if(isLiveData) PrintNew1("Split Request Rejected:  The number of TPO's on the proposed new left-side profile was less than MinSplitDepth");
				return;//the number of TPO letters in the new leftside profile must be at least pMinSplitDepth
			}
			if(lettersInThisSession - idxOfSplitLetter - 1 < pMinSplitDepth) {
				if(isLiveData) PrintNew1("Split Request Rejected:  The number of TPO's on the proposed new right-side profile was less than MinSplitDepth");
				return;//the number of TPO letters in the new rightside profile must be at least pMinSplitDepth
			}
//if(inzone) foreach(var x in bdkvp)Print("   "+x.Key+" :  "+x.Value.ToStr());

			var bd = bdkvp.Where(L => L.Value.Letter==letter).ToList();
			if(bd!=null && bd.Count>0)
			{
				int newRightPID = Math.Min(Prof[IdBeingSplit].EndABar-1,BarsArray[0].GetBar(bd[0].Key));
				int newStartABar = newRightPID;
				//if Prof already contains a profile in the suggested newRightPID slot (two profiles would have the same abs bar number, which is a problem
				//...then we must find some prior bar number slot that is not being occupied, and put the new profile in that unoccupied bar slot
				while(Prof.ContainsKey(newRightPID)) {
					if(newRightPID==-1) {
						//RARE...but if there's no available key (barslot) for the potential new profile...then you'll need to drop that profile and exit the method
						CheckArbZoneTouchOrBreak(Prof[IdBeingSplit].StartABar);
						return;
					}
					newRightPID--;
				}
				UPDATE_globaldict_pricelevels = true;
if(inzone) PrintNew1("\n5936   Letter: "+letter+"   "+bd[0].Key.ToString()+"  newRightPID: "+newRightPID);
				Prof[newRightPID]           = new ProfileData(Prof[IdBeingSplit].SessionDate, newRightPID, bd[0].Key, new int[2]{SUP_ID,RES_ID}, TickSize);
				Prof[newRightPID].EndABar   = Prof[IdBeingSplit].EndABar;
				Prof[newRightPID].EndTime   = Prof[IdBeingSplit].EndTime;
				Prof[IdBeingSplit   ].EndABar = newRightPID;
				Prof[IdBeingSplit   ].EndTime = bd[0].Key;
				Prof[IdBeingSplit   ].ClosePrice = RoundToTick(Closes[0].GetValueAt(Prof[IdBeingSplit].EndABar));
if(inzone){
	PrintNew1("IdBeingSplit: "+IdBeingSplit);
	PrintNew1("  StartABar: "+Prof[IdBeingSplit].StartABar+" - "+Prof[IdBeingSplit].EndABar);
	PrintNew1("  StartTime: "+Prof[IdBeingSplit].StartTime.ToString()+" - "+Prof[IdBeingSplit].EndTime.ToString());
	PrintNew1("\nnewRightPID: "+newRightPID);
	PrintNew1("  StartABar: "+Prof[newRightPID].StartABar+" - "+Prof[newRightPID].EndABar);
	PrintNew1("  StartTime: "+Prof[newRightPID].StartTime.ToString()+" - "+Prof[newRightPID].EndTime.ToString());
}
line=6009;
				Prof[newRightPID].Zones[RES_ID].Type = 'R';
				Prof[newRightPID].Zones[SUP_ID].Type = 'S';
				Prof[newRightPID].OpenPrice  = RoundToTick(Opens[0].GetValueAt( Prof[newRightPID].StartABar+1));
				if(Prof[newRightPID].EndABar == CurrentBars[0])
					Prof[newRightPID].ClosePrice = RoundToTick(Closes[0].GetValueAt(CurrentBars[0]-1));//don't use the current live market price, use the close of the last completed bar
				else
					Prof[newRightPID].ClosePrice = RoundToTick(Closes[0].GetValueAt(Prof[newRightPID].EndABar));

				Prof[IdBeingSplit   ].ClearAllDictionaries();
				float ValueAreaPctF    = ValueAreaPct/100f;
				Prof[IdBeingSplit].TPOatP = TPO_Data.CreateTPOatP(Prof[IdBeingSplit].StartTime, Prof[IdBeingSplit].EndTime,ref Prof[IdBeingSplit].FirstSplitableBarDataKey, TPO_Data.BarData, Times[1].GetValueAt(CurrentBars[1]), this, Prof[IdBeingSplit].StartABar,false);
				Prof[IdBeingSplit].Calc_DevelopingTPO(Prof[IdBeingSplit].StartABar, Prof[IdBeingSplit].StartTime, ValueAreaPctF, TPO_Data.BarData, Times[1].GetValueAt(CurrentBars[1]), BarsArray[0], this);
				Prof[IdBeingSplit].Calc_DevelopingVP(Prof[IdBeingSplit].StartABar, Prof[IdBeingSplit].StartTime, ValueAreaPctF, BarsArray[1], BarsArray[0], this);
				Prof[IdBeingSplit].Calc_ConsolidatedVP(pTicksPerHistoBar, TickSize);
				Prof[IdBeingSplit].Calc_HVN_LVN(this.pSignificance_HVN_LVN, pHighlightHVNLVN_Region, pHighlightHVNLVN_RegionSize, pTicksPerHistoBar, this);
#if HTO_LTO
				Prof[IdBeingSplit].Calc_HTO_LTO(this.pSignificance_HTO_LTO, pHighlightHTOLTO_Region);
#endif
				Prof[IdBeingSplit].Calc_ArbZones(Prof[IdBeingSplit].ClosePrice, true, true);
				Prof[IdBeingSplit].Calc_CurrentSplitAssistPrice(this.pMinSplitDepth, this);

				Prof[newRightPID].ClearAllDictionaries();
				Prof[newRightPID].TPOatP = TPO_Data.CreateTPOatP(Prof[newRightPID].StartTime, Prof[newRightPID].EndTime, ref Prof[newRightPID].FirstSplitableBarDataKey, TPO_Data.BarData, 
					newRightPID >= Prof.Keys.Max() ? Times[0].GetValueAt(CurrentBars[0]-1) : Times[1].GetValueAt(CurrentBars[1]), 
					this, Prof[newRightPID].StartABar, false);
				Prof[newRightPID].Calc_DevelopingTPO(Prof[newRightPID].StartABar, Prof[newRightPID].StartTime, ValueAreaPctF, TPO_Data.BarData, Times[1].GetValueAt(CurrentBars[1]), BarsArray[0], this);
				Prof[newRightPID].Calc_DevelopingVP(Prof[newRightPID].StartABar, Prof[newRightPID].StartTime, ValueAreaPctF, BarsArray[1], BarsArray[0], this);
				Prof[newRightPID].Calc_ConsolidatedVP(pTicksPerHistoBar, TickSize);
				Prof[newRightPID].Calc_HVN_LVN(this.pSignificance_HVN_LVN, pHighlightHVNLVN_Region, pHighlightHVNLVN_RegionSize, pTicksPerHistoBar, this);
#if HTO_LTO
				Prof[newRightPID].Calc_HTO_LTO(this.pSignificance_HTO_LTO, pHighlightHTOLTO_Region);
#endif
				Prof[newRightPID].Calc_ArbZones(Prof[newRightPID].ClosePrice, true, true);
				Prof[newRightPID].Calc_CurrentSplitAssistPrice(this.pMinSplitDepth, this);
				ProfileDates[newRightPID] = Prof[IdBeingSplit].SessionDate;
//				CleanUpOrphanedRaysAndRectangles(IdBeingSplit, currentSessionDate);
				CleanUpOrphanedRaysAndRectangles(currentSessionDate);

				CheckArbZoneTouchOrBreak(IdBeingSplit);
				DetermineOverlappedZones(0);
				DetermineDisqualifiedZones(0);
line=6051;
			}
			#endregion
		}
//=============================================================================================================
		private void MergeProfiles(int left, int right, bool CheckForOverlappingVA, bool inzone){
			#region -- MergeProfiles --
			bool mergeit = true;
if(inzone){
	PrintNew1("==================");
	PrintNew1(string.Format("In MergeProfiles({0} {1} {2})",left,right,CheckForOverlappingVA.ToString()));
	PrintNew1(string.Format("     Bar Times:   : {0}   {1}",BarsArray[0].GetTime(left).ToString(), BarsArray[0].GetTime(right).ToString()));
	PrintNew1(string.Format("     Start Times: : {0}   {1}",Prof[left].StartTime.ToString(),Prof[right].StartTime.ToString()));
}
			if(CheckForOverlappingVA){
				if(     Prof[left].tpoVAL_Price > Prof[right].tpoVAH_Price) mergeit = false;
				else if(Prof[left].tpoVAH_Price < Prof[right].tpoVAL_Price) mergeit = false;
			}
if(inzone) PrintNew1(string.Format("     SessionDates : {0}   {1}", Prof[left].SessionDate.ToString(), Prof[right].SessionDate.ToString()));
			if(mergeit && Prof[left].SessionDate == Prof[right].SessionDate){
				OneSimpleMerge(left, right, inzone);
				CleanUpOrphanedRaysAndRectangles(Prof[left].SessionDate);
				InitialzeVolNodeTerminationStates(Prof[left].SessionDate);
				ResetArbZoneDispositionFlags(0);
				CheckArbZoneTouchOrBreak(0);
				DetermineOverlappedZones(0);
				DetermineDisqualifiedZones(0);
				UPDATE_globaldict_pricelevels = true;
			}
else if(inzone) PrintNew1("Merge not performed...different SessionDates!");
			#endregion
		}
//=============================================================================================================
		private void MergeAllOverlappers(DateTime sessionDate, bool inzone){
			#region -- MergeAllOverlappers --
if(inzone) PrintNew1("MergeAllOverlappers by datetime: "+sessionDate.ToString());
			var profileIds = Prof.Where(k => k.Value.SessionDate==sessionDate.Date).Select(k => k.Key).ToList();
			if(profileIds==null || profileIds.Count<=1) return;
			profileIds.Sort();

if(inzone) foreach(var pk in profileIds) PrintNew1(string.Format("{0}   start:{1} end:{2}  {3} ",pk,Prof[pk].StartABar,Prof[pk].EndABar,Prof[pk].IsSingularDistribution.ToString()));
			if(profileIds[0] < profileIds.Last()) profileIds.Reverse();//highest abar is first in the list

			int mergedcount = 0;
			bool done = false, NoOverlap = false;
			int left  = 0;
			int right = 1;
			while(!done){
				try{
line=6100;
					int i = 0;
					while(i < profileIds.Count-1){
						right = profileIds[i];
						left  = profileIds[i+1];
if(inzone)PrintNew1("Left: "+left+"  right: "+right);
						NoOverlap = Prof[right].tpoVAH_Price < Prof[left].tpoVAL_Price || Prof[right].tpoVAL_Price > Prof[left].tpoVAH_Price;
						if(NoOverlap == false) {
line=6108;
//if(inzone) PrintNew1("    Merging Left: "+left+" and  Right: "+right);
if(inzone) PrintNew1(string.Format("L {0}   {1}-{2}    R {3}  {4}-{5}",left, Prof[left].Highest_Price.ToString(),Prof[left].Lowest_Price, right, Prof[right].Highest_Price.ToString(),Prof[right].Lowest_Price));
							MergeProfiles(left, right, false, inzone); mergedcount++;
							UPDATE_globaldict_pricelevels = true;
						}
						i++;
					}
line=6116;
					done=true;
					profileIds = Prof.Where(k => k.Value.SessionDate==sessionDate.Date).Select(k => k.Key).ToList();
					profileIds.Sort();
					if(profileIds[0] < profileIds.Last()) profileIds.Reverse();//highest abar is first in the list
					for(i=0; i<profileIds.Count-1; i++) {
line=6122;//if(inzone)PrintNew1(profileIds.Count+"-ids,weareexamining(right)i:"+i+"and(left)i+1:"+(i+1).ToString());
						left  = profileIds[i+1];
						right = profileIds[i];
						NoOverlap = Prof[right].tpoVAH_Price < Prof[left].tpoVAL_Price || Prof[right].tpoVAL_Price > Prof[left].tpoVAH_Price;
line=6126;
						if(NoOverlap == false) {done=false;
if(inzone) PrintNew1("        overlaps still exist...rerunning the merge pass");
							break;}
					}
line=6131;
				}catch(Exception ex){PrintNew1(line+": "+ex.ToString());}
if(inzone) PrintNew1("        "+ mergedcount+"-merge operations completed");
line=6134;
			}
			#endregion ------------------
line=6137;
		}
//=============================================================================================================
		private void OneSimpleMerge(int left, int right, bool inzone){
			#region -- OneSimpleMerge --
line=6142;
if(inzone) PrintNew1(string.Format(" in OneSimpleMerge( {0} into {1} )", right, left));
			Prof[left].EndABar    = Prof[right].EndABar;
			Prof[left].EndTime    = Prof[right].EndTime;
			Prof[left].ClosePrice = Prof[right].ClosePrice;
			Prof[left].ClearAllDictionaries();
			Prof[left].TPOatP     = TPO_Data.CreateTPOatP(Prof[left].StartTime, Prof[left].EndTime, ref Prof[left].FirstSplitableBarDataKey, TPO_Data.BarData, Times[1].GetValueAt(CurrentBars[1]), this, Prof[left].StartABar,false);
			float ValueAreaPctF   = ValueAreaPct/100f;
			Prof[left].Calc_DevelopingTPO(Prof[left].StartABar, Prof[left].StartTime, ValueAreaPctF, TPO_Data.BarData, Times[1].GetValueAt(CurrentBars[1]), BarsArray[0], this);
			Prof[left].Calc_DevelopingVP( Prof[left].StartABar, Prof[left].StartTime, ValueAreaPctF, BarsArray[1],     BarsArray[0], this);
			Prof[left].Calc_ConsolidatedVP(pTicksPerHistoBar, TickSize);
			Prof[left].Calc_HVN_LVN(this.pSignificance_HVN_LVN, pHighlightHVNLVN_Region, pHighlightHVNLVN_RegionSize, pTicksPerHistoBar, this);
#if HTO_LTO
			Prof[left].Calc_HTO_LTO(this.pSignificance_HTO_LTO, pHighlightHTOLTO_Region);
#endif
			Prof[left].Calc_ArbZones(Prof[left].ClosePrice, true, true);
			Prof[left].Calc_CurrentSplitAssistPrice(this.pMinSplitDepth, this);

			Prof.Remove(right);
			ProfileDates.Remove(right);
			UPDATE_globaldict_pricelevels = true;
if(inzone) PrintNew1("Removed profile "+right);
			#endregion
		}
//=============================================================================================================
		private void CheckArbZoneTouchOrBreak(int StartABar){//, DateTime SessionDate){
			#region -- CheckArbZoneTouchOrBreak --
			int pid = -1;
//Print(5431);
bool z1 = false;
			var pKeys = Prof.Where(z=> z.Value.Zones.ContainsKey(SUP_ID) || z.Value.Zones.ContainsKey(RES_ID)).Select(z=>z.Key).ToList();
			if(pKeys==null || pKeys.Count==0) return;
			foreach (var p in pKeys) {
				pid++;
//z1 = p==129;
				#region -- Get abar of first session AFTER this profiles session date...this is where we start looking for price bars that cross/touch the zones --
				int firstabar = StartABar;
				if(PermitZoneBreaksOnCurrentSession){
					var SessionDateStartABars = Prof.Where(px=> px.Value.SessionDate >= Prof[p].SessionDate).Select(px=>px.Key).ToList();
					if(SessionDateStartABars==null || SessionDateStartABars.Count==0) continue;
					firstabar = SessionDateStartABars.First()+1;
				}
				#endregion -------------
				for(int abar = firstabar; abar<=CurrentBars[0]; abar++){
					double H = Highs[0].GetValueAt(abar);
					double L = Lows[0].GetValueAt(abar);
					foreach(int zid in Prof[p].Zones.Keys){
						if(abar <= Prof[p].EndABar) continue;
						if (!Prof[p].Zones[zid].Tested && Prof[p].Zones[zid].IsTested(H, L)) {
				            Prof[p].Zones[zid].Disposition = 'T';
				            Prof[p].Zones[zid].Tested      = true;
				            Prof[p].Zones[zid].TestedDate  = Times[0].GetValueAt(abar);
if(z1) PrintNew1(line+(zid==SUP_ID ? " S : ":" R : ")+"  Zone was tested! at "+Prof[p].Zones[zid].TestedDate.ToString()+"  H: "+H.ToString()+" L: "+L.ToString()+"   ZoneHigh: "+Prof[p].Zones[zid].HighPrice+" ZoneLow:"+Prof[p].Zones[zid].LowPrice);
							if(!pShow_TestedZones) DeleteTheseZones(p, zid, Global_Arb_Rects);
						}
						if (PermitZoneBreaksOnCurrentSession && Prof[p].Zones[zid].Tested && !Prof[p].Zones[zid].Broken && Prof[p].Zones[zid].IsBroken(H, L)) {
if(z1) PrintNew1(line+(zid==SUP_ID ? " S : ":" R : ")+ (Prof[p].Zones[zid].EndABar!=int.MaxValue ? Times[0].GetValueAt(Prof[p].Zones[zid].EndABar).ToString():"No end")+"    H$ "+Prof[p].Zones[zid].HighPrice+"  L$ "+Prof[p].Zones[zid].LowPrice+"  tested: "+Prof[p].Zones[zid].Tested.ToString()+"  broken: "+Prof[p].Zones[zid].Broken.ToString());
				            Prof[p].Zones[zid].Disposition = 'B';
				            Prof[p].Zones[zid].Broken      = true;
				            Prof[p].Zones[zid].BrokenABar  = abar;
							//Prof[p].UnbrokenZonesCount--;
				            Prof[p].Zones[zid].EndABar     = abar;
if(z1) PrintNew1("---- broken "+p.ToString()+" abar: "+Prof[p].Zones[zid].EndABar+" @ "+Times[0].GetValueAt(abar).ToString());
							if(!pShow_BrokenZones) DeleteTheseZones(p, zid, Global_Arb_Rects);
						}
					}
					//if(Prof[p].UnbrokenZonesCount<=0) break;
				}
if(z1){
	try{
	PrintNew1(string.Format("#{0}      tH {1}  tL {2}  vH {3}  vL {4}", p, Prof[p].tpoVAH_Price, Prof[p].tpoVAL_Price, Prof[p].vpVAH_Price, Prof[p].vpVAL_Price));
	}catch{}
	try{
	PrintNew1(string.Format("Res:  {0}-{1}   {2} to {3}", Prof[p].Zones[RES_ID].HighPrice, Prof[p].Zones[RES_ID].LowPrice, Prof[p].StartABar, Prof[p].Zones[RES_ID].EndABar));
	}catch{}
	try{
	PrintNew1(string.Format("Sup:  {0}-{1}   {2} to {3}", Prof[p].Zones[SUP_ID].HighPrice, Prof[p].Zones[SUP_ID].LowPrice, Prof[p].StartABar, Prof[p].Zones[SUP_ID].EndABar));
	}catch{}
}
			}
			#endregion
		}
//=============================================================================================================
		private void CheckArbZoneTouchOrBreak(DateTime ThisSessionDateOnly, bool ResetUnbrokenCount){
			#region -- CheckArbZoneTouchOrBreak - only for a specific date --
			int pid = -1;
line=6228;
			int StartABar = 0;
			var datelist = ProfileDates.Where(D => D.Value >= ThisSessionDateOnly).ToList();
			if(datelist==null || datelist.Count<=0) return;
			StartABar = datelist[0].Key;
bool z1=false;
			var profs = Prof.Where(X => X.Value.SessionDate == ThisSessionDateOnly.Date).ToList();
			if(profs==null || profs.Count<=0) return;

			#region -- Get abar of first session AFTER this profiles session date...this is where we start looking for price bars that cross/touch the zones --
			int firstabar = StartABar;
			if(PermitZoneBreaksOnCurrentSession){
				var SessionDateStartABars = Prof.Where(px=> px.Value.SessionDate >= ThisSessionDateOnly.Date).Select(px=>px.Key).ToList();
				if(SessionDateStartABars==null || SessionDateStartABars.Count==0) return;
				firstabar = Prof[SessionDateStartABars.First()].StartABar;
			}
			#endregion -------------
line=6245;
			foreach (var p in profs) {
z1 = p.Key == EXAMINE_THIS_PROFILE;
//if(z1) PrintNew1(line+": "+StartABar+"  "+Times[0].GetValueAt(p.Key).ToString()+"   TPOVAH: "+Prof[p.Key].tpoVAH_Price.ToString()+"   TPOVAL: "+Prof[p.Key].tpoVAL_Price.ToString()+"   VPVAH: "+Prof[p.Key].vpVAH_Price.ToString()+"   VPVAL: "+Prof[p.Key].vpVAL_Price.ToString() +" UnbrokenZoneCount: "+Prof[p.Key].UnbrokenZonesCount);
//				if(ResetUnbrokenCount)
//					p.Value.UnbrokenZonesCount = p.Value.Zones.Count;
//				else if(p.Value.UnbrokenZonesCount<=0) 
//					continue;

				for(int abar = firstabar; abar<=CurrentBars[0]; abar++){
					double H = Highs[0].GetValueAt(abar);
					double L = Lows[0].GetValueAt(abar);
					foreach(int zid in p.Value.Zones.Keys){
						if(abar <= p.Value.EndABar) continue;
						if (!p.Value.Zones[zid].Tested && p.Value.Zones[zid].IsTested(H, L)) {
				            Prof[p.Key].Zones[zid].Disposition = 'T';
				            Prof[p.Key].Zones[zid].Tested      = true;
				            Prof[p.Key].Zones[zid].TestedDate  = Times[0].GetValueAt(abar);
line=6263;//if(z1)PrintNew1(line+":Tested=true"+Times[0].GetValueAt(p.Key).ToString());
							if(!pShow_TestedZones) DeleteTheseZones(p.Key, zid, Global_Arb_Rects);
						}
						if (PermitZoneBreaksOnCurrentSession && Prof[p.Key].Zones[zid].Tested && !Prof[p.Key].Zones[zid].Broken && Prof[p.Key].Zones[zid].IsBroken(H, L)) {
				            Prof[p.Key].Zones[zid].Broken     = true;
				            Prof[p.Key].Zones[zid].BrokenABar = abar;
//							Prof[p.Key].UnbrokenZonesCount--;
				            Prof[p.Key].Zones[zid].EndABar    = abar;
line=6271;//if(z1)PrintNew1(line+":Broken=true"+Times[0].GetValueAt(p.Key).ToString());
							if(!pShow_BrokenZones) DeleteTheseZones(p.Key, zid, Global_Arb_Rects);
						}
					}
//					if(Prof[p.Key].UnbrokenZonesCount<=0) break;
				}
			}
line=6278;
			#endregion
		}
//=============================================================================================================
		private void UpdateRaysTemplates_CurrentToHistorical(int FirstProfileId){
			//when a new session starts, all historical rays need their TemplateNames updated to Historical templates
			foreach(var r in Global_VAHL_Rays.Where(rx=> rx.Value.LMAbar < FirstProfileId).Select(rx=> rx.Key)){
				string orig_name = Global_VAHL_Rays[r].TemplateName;
				if(Global_VAHL_Rays[r].Type == SUP_ID)
					Global_VAHL_Rays[r].TemplateName = Global_VAHL_Rays[r].Type==TPO_ID ? phTPO_VAL_RayTemplate : phVP_VAL_RayTemplate;
				else if(Global_VAHL_Rays[r].Type == RES_ID)
					Global_VAHL_Rays[r].TemplateName = Global_VAHL_Rays[r].Type==TPO_ID ? phTPO_VAH_RayTemplate : phVP_VAH_RayTemplate;
				if(orig_name.CompareTo(Global_VAHL_Rays[r].TemplateName)!=0){
					RemoveThisTag(r);
					ImmediatelyDraw_Ray(r, Global_VAHL_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
				}
			}
			foreach(var r in Global_POC_Rays.Where(rx=> rx.Value.LMAbar < FirstProfileId).Select(rx=> rx.Key)){
				string orig_name = Global_POC_Rays[r].TemplateName;
				Global_POC_Rays[r].TemplateName = Global_POC_Rays[r].Type==TPO_ID ? phTPO_POC_RayTemplate : phVP_POC_RayTemplate;
				if(orig_name.CompareTo(Global_POC_Rays[r].TemplateName)!=0){
					RemoveThisTag(r);
					ImmediatelyDraw_Ray(r, Global_POC_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
				}
			}
		}
#endregion
//=============================================================================================================
		private SortedDictionary<int,double> ATRhistory = new SortedDictionary<int,double>();
		private List<double> atrs = new List<double>();
		protected override void OnBarUpdate()
		{
			if(IsTerminated) return;
line=6309;
//if(CurrentBars[0]>MAX_CURRENT_BAR) {PrintNew1("Max_Current_Bar: "+MAX_CURRENT_BAR+"   cb: "+CurrentBars[0]);return;}

#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
line=6351;

try{
			if(BarsInProgress==1 && isLiveData){
				#region -- BIP=1 and LiveData --
				if(IsFirstTickOfBar) {
					isNewSession    = sessionIterator0.IsNewSession(Times[1][0],true);
//if(IsDebug)	Draw.ArrowUp(this,CurrentBars[0].ToString()+" "+Times[1][0].ToString(),false,Times[1][0],Lows[0][0],Brushes.Yellow);
					newestProfileId = Prof.Keys.Max();
					UPDATE_globaldict_pricelevels = true;//update the prices in the globals dicts for all rays, zones
				}

				var tpocount = TPO_Data.BarData.Count;
				TPO_Data.Accumulate(Opens[1][0], Highs[1][0], Lows[1][0], Closes[1][0], Times[1][0], isNewSession, this);
				if(tpocount != TPO_Data.BarData.Count){
					Prof[newestProfileId].TPOatP.Clear();
					Prof[newestProfileId].TPOatP = TPO_Data.CreateTPOatP(BarsArray[0].GetTime(Prof[newestProfileId].StartABar), BarsArray[0].GetTime(Prof[newestProfileId].EndABar), ref Prof[newestProfileId].FirstSplitableBarDataKey, TPO_Data.BarData, Times[0].GetValueAt(CurrentBars[0]-1), this, Prof[newestProfileId].StartABar, isLiveData);
					float ValueAreaPctF = ValueAreaPct/100f;
					Prof[newestProfileId].Calc_DevelopingTPO(Prof[newestProfileId].StartABar, BarsArray[0].GetTime(Prof[newestProfileId].StartABar), ValueAreaPctF, TPO_Data.BarData, Times[1].GetValueAt(CurrentBars[1]), BarsArray[0], this);
					Prof[newestProfileId].Calc_DevelopingVP(Prof[newestProfileId].StartABar, BarsArray[0].GetTime(Prof[newestProfileId].StartABar), ValueAreaPctF, BarsArray[1], BarsArray[0], this);
					Prof[newestProfileId].Calc_ConsolidatedVP(pTicksPerHistoBar, TickSize);
					Prof[newestProfileId].Calc_CurrentSplitAssistPrice(this.pMinSplitDepth, this);
line=6353;
//					List<int> newPIDs;
					if(pPermitProfileSplits){
						/*newPIDs = */MergeAndSplitThisSessionDate(newestProfileId, true);
					}else{
					}
//foreach(var ppp in newPIDs)Print("  New PID: "+ppp);
//					if(newPIDs.Count>0)
					{
						CurSessProfileIds1 = Prof.Where(csd=> csd.Key >= FirstProfileIdOfCurrentSession).Select(csd=> csd.Key).ToList();
						newestProfileId = Prof.Keys.Max();
						foreach(var newPID in CurSessProfileIds1){
							Prof[newPID].Calc_HVN_LVN(this.pSignificance_HVN_LVN, pHighlightHVNLVN_Region, pHighlightHVNLVN_RegionSize, pTicksPerHistoBar, this);
#if HTO_LTO
							Prof[newPID].Calc_HTO_LTO(this.pSignificance_HTO_LTO, pHighlightHTOLTO_Region);
#endif
							Prof[newPID].Calc_ArbZones(Prof[newPID].ClosePrice, true, false);
						}
//Print("5703  "+DateTime.Now.ToString());		return;
						#region -- Delete the rays and arb zones and LVN zones in the current session --

						#region -- Remove the objects --
						var TagsToRemove = new List<string>();
						var Obj2del = Global_Arb_Rects.Where(rk=> rk.Value.StartABar >= FirstProfileIdOfCurrentSession).Select(rk=> rk.Key).ToList();
						if(Obj2del!=null) foreach(var obj in Obj2del) {
							TagsToRemove.Add(obj);
							RemoveThisTag(obj);
						}
						foreach(var tag in TagsToRemove) Global_Arb_Rects.Remove(tag);
						TagsToRemove.Clear();

						Obj2del = Global_LVN_Rects.Where(rk=> rk.Value.StartABar >= FirstProfileIdOfCurrentSession).Select(rk=> rk.Key).ToList();
						if(Obj2del!=null) foreach(var obj in Obj2del) {
							TagsToRemove.Add(obj);
							RemoveThisTag(obj);
						}
						foreach(var tag in TagsToRemove) Global_LVN_Rects.Remove(tag);
						TagsToRemove.Clear();

						Obj2del = Global_VAHL_Rays.Where(rk=> rk.Value.LMAbar >= FirstProfileIdOfCurrentSession).Select(rk=> rk.Key).ToList();
						if(Obj2del!=null) foreach(var obj in Obj2del) {
							if(pcVisual_ScopeVARays != ARC_MacroProfiles_GlobalRayScopes.Manual){//don't remove any rays when we're in Manual mode
								TagsToRemove.Add(obj);
								RemoveThisTag(obj);
							}else{
								Global_VAHL_Rays[obj].IsDrawn = false;
							}
						}
						foreach(var tag in TagsToRemove) Global_VAHL_Rays.Remove(tag);
						TagsToRemove.Clear();

						Obj2del = Global_POC_Rays.Where(rk=> rk.Value.LMAbar >= FirstProfileIdOfCurrentSession).Select(rk=> rk.Key).ToList();
						if(Obj2del!=null) foreach(var obj in Obj2del) {
							if(pcVisual_ScopePOCRays != ARC_MacroProfiles_GlobalRayScopes.Manual){//don't remove any rays when we're in Manual mode
								TagsToRemove.Add(obj);
								RemoveThisTag(obj);
							}else{
								Global_POC_Rays[obj].IsDrawn = false;
							}
						}
						foreach(var tag in TagsToRemove) Global_POC_Rays.Remove(tag);
line=6414;
						TagsToRemove.Clear();
						var objs = DrawObjects.Where(k=> k.ToString().EndsWith(".Ray"));
						if(objs!=null) foreach(dynamic obj in objs) {
							if(!obj.Tag.StartsWith("H") && !obj.Tag.StartsWith("L") && !obj.Tag.StartsWith("POC") && obj.StartAnchor.SlotIndex >= FirstProfileIdOfCurrentSession){
								TagsToRemove.Add(obj.Tag);
							}else{
								
							}
						}
						foreach(var del in TagsToRemove) RemoveThisTag(del);
						#endregion
//	object o = obj;	
//	var propertyNames = o.GetType().GetProperties();
//	Print(o.GetType().GetProperty("Name").GetValue(o, null)+"   DrawnBy: "+o.GetType().GetProperty("DrawnBy").GetValue(o, null)+"   IsUserDrawn: "+o.GetType().GetProperty("IsUserDrawn").GetValue(o, null).ToString());

						ResetArbZoneDispositionFlags(CurSessProfileIds1.Min());
						CheckArbZoneTouchOrBreak(CurSessProfileIds1.Min());
						DetermineOverlappedZones(CurSessProfileIds1.Min());
						DetermineDisqualifiedZones(CurSessProfileIds1.Min());
						ResetProfileDates();
						CleanUpOrphanedRaysAndRectangles();
						ApplyGlobalRaySelections(pcVisual_ScopeVARays, pcVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, CurSessProfileIds1);
						#region -- Calculate HVN/LVN lengths and draw global LVNs --
						if(HVNLVN_AreVisible) {//update LVN's as the profiles split and are created
							UpdateVolNodeTerminationState(Highs[0][1], Lows[0][1], this.pTicksPerHistoBar, newestProfileId);
							UpdateGlobalLVN_EndABars(CurSessProfileIds1, pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
							UpdateGlobalHVN_EndABars(CurSessProfileIds1, pShow_CurrentProfileVN, pShow_HistoricalProfileVN);
						}
						#endregion
						Force_DrawGlobalObjectsNow = true;
						UPDATE_globaldict_pricelevels = true;//the update occurred in ApplyGlobalRaySelections, no need to do it again.
					}
					#endregion
				}
				CheckArbZoneTouchOrBreak(0);
				#endregion
			}
			if(BarsInProgress==0){
line=6473;
				#region VWAP
				if(CurrentBars[1]>0){
					if (Bars.IsFirstBarOfSession)
					{
						VWAP_CumVol = Volumes[1][0];
						VWAP_TypiCumVol = Volumes[1][0] * Typicals[1][0];
					}
					else
					{
						VWAP_CumVol = VWAP_CumVol + Volumes[1][0];
						VWAP_TypiCumVol = VWAP_TypiCumVol + (Volumes[1][0] * Typicals[1][0]);
					}
				}
				VWAP[0] = (VWAP_TypiCumVol / VWAP_CumVol);
				CurrentVWAP = VWAP[0];
				#endregion
				if(IsFirstTickOfBar && CurrentBars[0]>1){ //bug fixed Aug 2022, v2.8.2...added "CurrentBars[0]>1" since Range()[1] causing error
					atrs.Add(Range()[1]);
					while(atrs.Count>this.pATRperiod) atrs.RemoveAt(0);
					ATRhistory[CurrentBars[0]-1] = atrs.Average();
				}
				if(Prof.Keys==null || Prof.Keys.Count==0) {
					newestProfileId = 0;
				}
				else {
					newestProfileId = Prof.Keys.Max();
					if(Prof.Count>0 && CurrentBars[0]>0) {
						Prof.Values.Last().EndABar    = Math.Max(Prof.Values.Last().StartABar,CurrentBars[0]);
						Prof.Values.Last().ClosePrice = this.RoundToTick(Closes[0][0]);
						try{
							Prof.Values.Last().EndTime = Times[0][0];
						}catch{
							Prof.Values.Last().EndTime = Times[1][0];
						}
					}
				}
			}
line=6515;
			if(BarsInProgress==1 && IsFirstTickOfBar){
				priorDate           = currentSessionDate;
				currentSessionDate  = sessionIterator0.GetTradingDay(Times[1][0]).Date;
				if(priorDate != currentSessionDate && isLiveData) {
					ResetArbZoneDispositionFlags(0);
					CheckArbZoneTouchOrBreak(0);
					DetermineOverlappedZones(0);
					DetermineDisqualifiedZones(0);
					UPDATE_globaldict_pricelevels = true;
				}
line=6526;
				bool c2 = false;
				#region -- Determine if a new session has started -- 
				if(ProfileDates.Count == 0 && BarsArray[1] != null && BarsArray[1].Count > 0) {
					c2 = true;
					Current_Session_Date = Times[1][0];
				}else if(pTimeBasis == ARC_MacroProfiles_TimeBasis.Daily){
					c2 = priorDate.Day != currentSessionDate.Day;
					if(c2 && !ProfileDates.Values.Contains(currentSessionDate)) {
						Current_Session_Date = currentSessionDate;
						SessionBreakLocs.Add(CurrentBars[0]);
						FirstProfileIdOfCurrentSession = CurrentBars[0];
						UpdateRaysTemplates_CurrentToHistorical(FirstProfileIdOfCurrentSession);
					}
				}
				else if(pTimeBasis == ARC_MacroProfiles_TimeBasis.Weekly && CurrentBars[1]>1){
					c2 = Times[1][0].DayOfWeek < Times[1][1].DayOfWeek;
					if(c2 && !ProfileDates.Values.Contains(currentSessionDate)) {
						Current_Session_Date = currentSessionDate;
						SessionBreakLocs.Add(CurrentBars[0]);
						FirstProfileIdOfCurrentSession = CurrentBars[0];
						UpdateRaysTemplates_CurrentToHistorical(FirstProfileIdOfCurrentSession);
					}
				}
				else if(pTimeBasis == ARC_MacroProfiles_TimeBasis.Monthly && CurrentBars[1]>1){
					c2 = Times[1][0].Month != Times[1][1].Month;
					if(c2 && !ProfileDates.Values.Contains(currentSessionDate)) {
						Current_Session_Date = currentSessionDate;
						SessionBreakLocs.Add(CurrentBars[0]);
						FirstProfileIdOfCurrentSession = CurrentBars[0];
						UpdateRaysTemplates_CurrentToHistorical(FirstProfileIdOfCurrentSession);
					}
				}
				if(c2) {
					int abar = Math.Max(0,CurrentBars[0]);
					ProfileDates[abar] = Current_Session_Date;//the Current_Session_Date is the date of the trading session...and may not be the local datetime.  So, we must assign the session datetime to start at the current bar (regardless of what the local datetime is)
//					if(newestDate != Current_Session_Date){//on a new session, you need to delete the saved history of global rays that were created on that most recent session
//						CurrentSessionRays_H.Clear();
//						CurrentSessionRays_L.Clear();
//					}
					newestDate = Current_Session_Date;//ProfileDates.Count>0 ? ProfileDates.Values.Max() : DateTime.MaxValue;
					Prof[abar] = new ProfileData(newestDate, abar, (abar>0 ? Bars.GetTime(abar-1):Bars.GetTime(0)), new int[]{SUP_ID,RES_ID}, TickSize);
					try{
						Prof.Values.Last().StartTime = Times[0][0];
					}catch{
						Prof.Values.Last().StartTime = Times[1][0];
					}
					Prof[abar].Zones[RES_ID].Type = 'R';
					Prof[abar].Zones[SUP_ID].Type = 'S';
					Force_DrawGlobalObjectsNow = true;
					UPDATE_globaldict_pricelevels = true;
				}

				H = RoundToTick(Highs[1][0]);
				L = RoundToTick(Lows[1][0]);
				if(Prof.Count>0){
					if(CurrentBars[0]-1 == Prof.Values.Last().StartABar) Prof.Values.Last().OpenPrice = RoundToTick(Opens[0][0]);
					Prof.Values.Last().StaticVWAP_Price = CurrentVWAP;
				}
				#endregion

				if(isLiveData){
line=6588;
					if(Force_DrawGlobalObjectsNow || UPDATE_globaldict_pricelevels){
						int Changes_VAHLRays = 0;
						int Changes_POCRays  = 0;
						int Changes_ArbZones = 0;
						//int Changes_LVNZones = 0;
line=6594;
						#region -- Update dictionaries for drawn rays and arb zone levels and POC/VA changes occur ---------------------
						if(UPDATE_globaldict_pricelevels && (Global_VAHL_Rays.Count>0 || Global_Arb_Rects.Count>0 || Global_POC_Rays.Count>0)){
							UPDATE_globaldict_pricelevels = false;
							if(CurSessProfileIds1!=null) foreach(var cspId in CurSessProfileIds1){//check current session global objects for any price changes...update the drawn element when necessary
								if(Global_VAHL_Rays.Count>0){
line=6600;
									#region -- Update current TPO vah/val -----------------------------------
									string tagH = string.Format("H{0}_{1}_{2}", ObjTagPrefix, cspId, TPO_ID);
									string tagL = string.Format("L{0}_{1}_{2}", ObjTagPrefix, cspId, TPO_ID);
//Print("5774  Profile: "+cspId);
//if(zx && Global_VAHL_Rays.ContainsKey(tagH))Print("\n  "+tagH+": "+ Global_VAHL_Rays[tagH].Price+"   Prof.tpoVAH: "+Prof[cspId].tpoVAH_Price);
									if(Global_VAHL_Rays.ContainsKey(tagH) && Prof[cspId].tpoVAH_Price != Global_VAHL_Rays[tagH].Price){
//if(zx) Print("   updated tpo HIGH price to "+Prof[cspId].tpoVAH_Price);
										Changes_VAHLRays++;
										Global_VAHL_Rays[tagH].Price   = Prof[cspId].tpoVAH_Price;
										Global_VAHL_Rays[tagH].IsDrawn = false;//forces a redraw of this ray
										Global_VAHL_Rays[tagH].EndDT   = DateTime.MaxValue;
									}
//if(zx && Global_VAHL_Rays.ContainsKey(tagL))Print("\n  "+tagL+": "+ Global_VAHL_Rays[tagL].Price+"   Prof.tpoVAL: "+Prof[cspId].tpoVAL_Price);
									if(Global_VAHL_Rays.ContainsKey(tagL) && Prof[cspId].tpoVAL_Price != Global_VAHL_Rays[tagL].Price){
//if(zx)Print("   updated tpo LOW price to "+Prof[cspId].tpoVAL_Price);
										Changes_VAHLRays++;
										Global_VAHL_Rays[tagL].Price   = Prof[cspId].tpoVAL_Price;
										Global_VAHL_Rays[tagL].IsDrawn = false;//forces a redraw of this ray
										Global_VAHL_Rays[tagL].EndDT   = DateTime.MaxValue;
									}
									#endregion --------------------------------------------
									#region -- Update current VA vah/val -----------------------------------
									tagH = string.Format("H{0}_{1}_{2}", ObjTagPrefix, cspId, V_ID);
									tagL = string.Format("L{0}_{1}_{2}", ObjTagPrefix, cspId, V_ID);
									if(Global_VAHL_Rays.ContainsKey(tagH) && Prof[cspId].vpVAH_Price != Global_VAHL_Rays[tagH].Price){
//if(zx) Print("   updated vp HIGH price to "+Prof[cspId].vpVAH_Price);
										Changes_VAHLRays++;
										Global_VAHL_Rays[tagH].Price   = Prof[cspId].vpVAH_Price;
										Global_VAHL_Rays[tagH].IsDrawn = false;//forces a redraw of this ray
										Global_VAHL_Rays[tagH].EndDT   = DateTime.MaxValue;
									}
									if(Global_VAHL_Rays.ContainsKey(tagL) && Prof[cspId].vpVAL_Price != Global_VAHL_Rays[tagL].Price){
//if(zx)Print("   updated vp LOW price to "+Prof[cspId].vpVAL_Price);
										Changes_VAHLRays++;
										Global_VAHL_Rays[tagL].Price   = Prof[cspId].vpVAL_Price;
										Global_VAHL_Rays[tagL].IsDrawn = false;//forces a redraw of this ray
										Global_VAHL_Rays[tagL].EndDT   = DateTime.MaxValue;
									}
									#endregion ---------------------------------------------
								}
								if(Global_POC_Rays.Count>0){
line=6642;
									#region -- Update current POC -----------------------------------
									string tagPOC = string.Format("POC{0}_{1}_{2}", ObjTagPrefix, cspId, TPO_ID);
//if(zx && Global_VAHL_Rays.ContainsKey(tagH))Print("  "+tagH+": "+ Global_VAHL_Rays[tagH].Price+"   Prof.tpoVAH: "+Prof[cspId].tpoVAH_Price);
									if(Global_POC_Rays.ContainsKey(tagPOC) && Prof[cspId].tpoPOC_Price != Global_POC_Rays[tagPOC].Price){
//if(zx)Print("   updated poc HIGH price to "+Prof[cspId].tpoPOC_Price);
										Changes_POCRays++;
										Global_POC_Rays[tagPOC].Price   = Prof[cspId].tpoPOC_Price;
										Global_POC_Rays[tagPOC].IsDrawn = false;//forces a redraw of this ray
										Global_POC_Rays[tagPOC].EndDT   = DateTime.MaxValue;
									}
//if(zx && Global_VAHL_Rays.ContainsKey(tagH))Print("  "+tagH+": "+ Global_VAHL_Rays[tagH].Price+"   Prof.tpoVAH: "+Prof[cspId].tpoVAH_Price);
									tagPOC = string.Format("POC{0}_{1}_{2}", ObjTagPrefix, cspId, V_ID);
									if(Global_POC_Rays.ContainsKey(tagPOC) && Prof[cspId].ConsolidatedvpPOC_Price != Global_POC_Rays[tagPOC].Price){
//if(zx)Print("   updated poc HIGH price to "+Prof[cspId].tpoPOC_Price);
										Changes_POCRays++;
										Global_POC_Rays[tagPOC].Price   = Prof[cspId].ConsolidatedvpPOC_Price;
										Global_POC_Rays[tagPOC].IsDrawn = false;//forces a redraw of this ray
										Global_POC_Rays[tagPOC].EndDT   = DateTime.MaxValue;
									}
									#endregion --------------------------------------------
								}
								if(Global_Arb_Rects.Count>0){
line=6665;
									#region -- Update current sup/res arb zones ------------------------
									string tag = string.Format("Z{0}_{1}_", ObjTagPrefix, cspId);
									var keys = Global_Arb_Rects.Where(xr => xr.Key.StartsWith(tag) && xr.Value.IsDrawn && xr.Value.DTEnd==DateTime.MaxValue).Select(xr => xr.Key).ToList();
									if(keys!=null && keys.Count>0){
										foreach (var id in keys) {
											if(Global_Arb_Rects[id].Type_S_R_V=='S' && Prof[cspId].Zones.ContainsKey(SUP_ID)){
												if(Global_Arb_Rects[id].TopPrice    != Prof[cspId].Zones[SUP_ID].HighPrice || Global_Arb_Rects[id].BottomPrice != Prof[cspId].Zones[SUP_ID].LowPrice){
													Changes_ArbZones++;
													Global_Arb_Rects[id].TopPrice    = Prof[cspId].Zones[SUP_ID].HighPrice;
													Global_Arb_Rects[id].BottomPrice = Prof[cspId].Zones[SUP_ID].LowPrice;
													Global_Arb_Rects[id].IsDrawn     = false;//forces a redraw of this rectangle
					//PrintNew1("Updated S rect at "+id+"  "+Global_Arb_Rects[id].ToString());
												}
											}else if(Global_Arb_Rects[id].Type_S_R_V=='R' && Prof[cspId].Zones.ContainsKey(RES_ID)){
												if(Global_Arb_Rects[id].TopPrice    != Prof[cspId].Zones[RES_ID].HighPrice || Global_Arb_Rects[id].BottomPrice != Prof[cspId].Zones[RES_ID].LowPrice){
													Changes_ArbZones++;
													Global_Arb_Rects[id].TopPrice    = Prof[cspId].Zones[RES_ID].HighPrice;
													Global_Arb_Rects[id].BottomPrice = Prof[cspId].Zones[RES_ID].LowPrice;
													Global_Arb_Rects[id].IsDrawn     = false;//forces a redraw of this rectangle
					//PrintNew1("Updated R rect at "+id+"  "+Global_Arb_Rects[id].ToString());
												}
											}
										}
									}
									#endregion ----------------------------------------------
								}
							}
							//UpdateGlobalRaysOnPriceChanges(0, Global_POC_Rays, Global_VAHL_Rays);
						}
						#endregion ------------------------------------------------
line=6696;
						#region -- Set the EndDT for all POC and VAH/VAL rays --
						//if(pAutoSplitCurrentDay) MergeAndSplitThisSessionDate(newestProfileId, true);
						if(Global_VAHL_Rays.Count>0){
							var candidate_rays = Global_VAHL_Rays.Where(cr=> cr.Value.EndDT==DateTime.MaxValue && cr.Value.LMAbar <= newestProfileId).Select(cr=> cr.Key).ToList();
							foreach(var tag in candidate_rays)	{
								Global_VAHL_Rays[tag].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tag]);
								if(Global_VAHL_Rays[tag].EndDT != DateTime.MaxValue) Changes_VAHLRays++;
							}
						}
//Print("5956  "+newestProfileId+"  tpoVAH: "+Prof[newestProfileId].tpoVAH_Price+"   tpoVAL: "+Prof[newestProfileId].tpoVAL_Price+"  vpVAH: "+Prof[newestProfileId].vpVAH_Price+"  vaVAL: "+Prof[newestProfileId].vpVAL_Price);
						if(Global_POC_Rays.Count>0){
							var candidate_rays = Global_POC_Rays.Where(cr=> cr.Value.EndDT==DateTime.MaxValue && cr.Value.LMAbar <= newestProfileId).Select(cr=> cr.Key).ToList();
//Print("Candidate rays count: "+(candidate_rays==null?"null":candidate_rays.Count.ToString()));
							foreach(var tag in candidate_rays)	{
								Global_POC_Rays[tag].EndDT = UpdateRayEndDT(Global_POC_Rays[tag]);
								if(Global_POC_Rays[tag].EndDT != DateTime.MaxValue) Changes_POCRays++;
//if(Global_POC_Rays[tag].EndDT != DateTime.MaxValue) Print("    "+tag+" now has an EndDT of:   "+Global_POC_Rays[tag].EndDT.ToString()+"   "+Global_POC_Rays[tag].Price);
							}
						}
						#endregion

						if((Global_VAHL_Rays.Count>0 && (Force_DrawGlobalObjectsNow || Changes_VAHLRays>0))){
							ImmediatelyDraw_Rays(Global_VAHL_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
						}
						if((Global_POC_Rays.Count>0 && (Force_DrawGlobalObjectsNow || Changes_POCRays>0))){
							ImmediatelyDraw_Rays(Global_POC_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
						}
						if((Global_Arb_Rects.Count>0 && (Force_DrawGlobalObjectsNow || Changes_ArbZones>0))){
							ImmediatelyDraw_Zones(Global_Arb_Rects);
						}
						MM.obj_count = CalculateCountOfGlobalObjects();
						Force_DrawGlobalObjectsNow = false;
//						profile_locations_changed = false;
					}
				}
			}//BIP==1 && IsFirstTick
line=6702;
}catch(Exception ex){PrintNew1(line+":  "+ex.ToString()+"   inst:"+ inst);}
		}
//=============================================================================================================
		private void ImmediatelyDraw_Ray(string tag, SortedDictionary<string, Global_RaysData> dict, bool ShowDisqualifiedRays_Current, bool ShowDisqualifiedRays_Historical){
			#region -- Draw Global Rays, or lines if they intersect with a VA ------------------------------
			var delete_these_rays = new List<string>();
			if(tag!=null && tag.Length>0 && dict[tag].IsDrawn==false && dict[tag].DT < dict[tag].EndDT){
				if(dict[tag].EndDT != DateTime.MaxValue) {
					bool cC = dict[tag].LMAbar >= FirstProfileIdOfCurrentSession && ShowDisqualifiedRays_Current;
					bool cH = dict[tag].LMAbar < FirstProfileIdOfCurrentSession && ShowDisqualifiedRays_Historical;
					RemoveThisTag(tag);
					if(cC || cH)
						TriggerCustomEvent(o1 =>{Draw.Line(this, tag, false, dict[tag].DT, dict[tag].Price, dict[tag].EndDT, dict[tag].Price, true, "Default");},0,null);
				}else  
					TriggerCustomEvent(o1 =>{Draw.Ray(this, tag, dict[tag].DT, dict[tag].Price, Times[1].GetValueAt(CurrentBars[1]), dict[tag].Price, true, dict[tag].TemplateName);},0,null);
				dict[tag].IsDrawn = true;
			}
			#endregion ----------------------------
		}
//=============================================================================================================
		private void ImmediatelyDraw_Rays(SortedDictionary<string, Global_RaysData> dict, bool ShowDisqualifiedRays_Current, bool ShowDisqualifiedRays_Historical){
			#region -- Draw Global Rays, or lines if they intersect with a VA ------------------------------
			var delete_these_rays = new List<string>();
			var globalobjs = dict.Where(xr => xr.Value.IsDrawn==false && xr.Value.DT < xr.Value.EndDT).Select(xr => xr.Key).ToList();
			foreach(var tag in globalobjs){
				if(tag!=null && tag.Length>0){
					if(dict[tag].EndDT != DateTime.MaxValue) {
						bool cC = dict[tag].LMAbar >= FirstProfileIdOfCurrentSession && ShowDisqualifiedRays_Current;
						bool cH = dict[tag].LMAbar < FirstProfileIdOfCurrentSession && ShowDisqualifiedRays_Historical;
//Print("Removing "+tag);
						RemoveThisTag(tag);
						if(cC || cH)
							TriggerCustomEvent(o1 =>{Draw.Line(this, tag, false, dict[tag].DT, dict[tag].Price, dict[tag].EndDT, dict[tag].Price, true, "Default");},0,null);
					}else{
						TriggerCustomEvent(o1 =>{Draw.Ray(this, tag, dict[tag].DT, dict[tag].Price, Times[1].GetValueAt(CurrentBars[1]), dict[tag].Price, true, dict[tag].TemplateName);},0,null);
					}
					dict[tag].IsDrawn = true;
				}
			}
			#endregion ----------------------------
		}
//=============================================================================================================
		private void ImmediatelyDraw_Zone(string tag, SortedDictionary<string, Global_RectsData> dict){
			#region -- Draw Global rect --------------------------------
			if(tag!=null && tag.Length>0 && dict[tag].IsDrawn==false){
				TriggerCustomEvent(o =>{	Draw.Rectangle(this, tag, dict[tag].DTStart, dict[tag].TopPrice, (dict[tag].DTEnd==DateTime.MaxValue ? Times[0].GetValueAt(CurrentBars[0]).AddDays(5) : dict[tag].DTEnd), dict[tag].BottomPrice, true, dict[tag].TemplateName);},0,null);
				dict[tag].IsDrawn=true;
			}
			if(IsFirstTickOfBar){//if this is an untested arb zone, then the right-edge of the rectangle must continue to expand to the current bar
				if(tag!=null && tag.Length>0 && dict[tag].IsDrawn && dict[tag].DTEnd==DateTime.MaxValue){
					TriggerCustomEvent(o =>{	Draw.Rectangle(this, tag, dict[tag].DTStart, dict[tag].TopPrice, Times[0].GetValueAt(CurrentBars[0]).AddDays(5), dict[tag].BottomPrice, true, dict[tag].TemplateName);},0,null);
				}
			}
			#endregion -----------------------------------------------------------
		}
//=============================================================================================================
		private void ImmediatelyDraw_Zones(SortedDictionary<string, Global_RectsData> dict){
			#region -- Draw Global rects --------------------------------
			foreach(var tag in dict.Where(xr => xr.Value.IsDrawn==false).Select(xr => xr.Key)){
if(IsDebug) Print("--------- Immediately Drawing Zones "+tag);//changes
				TriggerCustomEvent(o =>{	Draw.Rectangle(this, tag, dict[tag].DTStart, dict[tag].TopPrice, (dict[tag].DTEnd==DateTime.MaxValue ? Times[0].GetValueAt(CurrentBars[0]).AddDays(5) : dict[tag].DTEnd), dict[tag].BottomPrice, true, dict[tag].TemplateName);},0,null);
				dict[tag].IsDrawn=true;
			}
			if(IsFirstTickOfBar){//if this is an untested arb zone, then the right-edge of the rectangle must continue to expand to the current bar
				foreach(var tag in dict.Where(xr => xr.Value.IsDrawn && xr.Value.DTEnd == DateTime.MaxValue).Select(xr => xr.Key)){
if(IsDebug) Print("--------- Immediately Drawing Zones "+tag);//changes
					TriggerCustomEvent(o =>{	Draw.Rectangle(this, tag, dict[tag].DTStart, dict[tag].TopPrice, Times[0].GetValueAt(CurrentBars[0]).AddDays(5), dict[tag].BottomPrice, true, dict[tag].TemplateName);},0,null);
				}
			}
			#endregion -----------------------------------------------------------
		}
//=============================================================================================================

//=============================================================================================================
		private bool ProfileInCurrentSession(int ProfID){
			if(ProfID >= FirstProfileIdOfCurrentSession) return true; else return false;
		}
        public Brush ContrastingColor(SolidColorBrush brush)
        {
            // Counting the perceptive luminance - human eye favors green color... 
            double a = 1 - (0.299 * brush.Color.R + 0.587 * brush.Color.G + 0.114 * brush.Color.B) / 255;
            if (a < 0.5) return Brushes.Black; // bright colors - black font
            else return Brushes.White; // dark colors - white font
        }
        public SolidColorBrush ContrastingColor(Brush brush)
        {
			var color = ((SolidColorBrush)brush).Color;
            // Counting the perceptive luminance - human eye favors green color... 
            double a = 1 - (0.299 * color.R + 0.587 * color.G + 0.114 * color.B) / 255;
            if (a < 0.5) return Brushes.Black; // bright colors - black font
            else return Brushes.White; // dark colors - white font
        }
//=============================================================================================================
		public override void OnRenderTargetChanged()
		{
line=6802;
			#region -- Brush disposal --
			if(tpoVA_BrushDX!=null      && !tpoVA_BrushDX.IsDisposed)      tpoVA_BrushDX.Dispose();      tpoVA_BrushDX      = null;
			if(tpoAboveVA_BrushDX!=null && !tpoAboveVA_BrushDX.IsDisposed) tpoAboveVA_BrushDX.Dispose(); tpoAboveVA_BrushDX = null;
			if(tpoBelowVA_BrushDX!=null && !tpoBelowVA_BrushDX.IsDisposed) tpoBelowVA_BrushDX.Dispose(); tpoBelowVA_BrushDX = null;
			if(vpVA_BrushDX!=null       && !vpVA_BrushDX.IsDisposed)       vpVA_BrushDX.Dispose();       vpVA_BrushDX       = null;
			if(vpAboveVA_BrushDX!=null  && !vpAboveVA_BrushDX.IsDisposed)  vpAboveVA_BrushDX.Dispose();  vpAboveVA_BrushDX  = null;
line=6809;
			if(vpBelowVA_BrushDX!=null  && !vpBelowVA_BrushDX.IsDisposed)  vpBelowVA_BrushDX.Dispose();  vpBelowVA_BrushDX  = null;
line=6811;
			if(tpoSinglePrintLine_BrushDX!=null     && !tpoSinglePrintLine_BrushDX.IsDisposed)     tpoSinglePrintLine_BrushDX.Dispose();     tpoSinglePrintLine_BrushDX=null;
			if(tpoPOC_BrushDX!=null     && !tpoPOC_BrushDX.IsDisposed)     tpoPOC_BrushDX.Dispose();     tpoPOC_BrushDX=null;
line=6814;
			if(vpPOC_BrushDX!=null      && !vpPOC_BrushDX.IsDisposed)      vpPOC_BrushDX.Dispose();      vpPOC_BrushDX=null;

			if(DisqBrushDX!=null        && !DisqBrushDX.IsDisposed)        DisqBrushDX.Dispose();        DisqBrushDX	= null;
			if(OverlapBrushDX!=null       && !OverlapBrushDX.IsDisposed)       OverlapBrushDX.Dispose();       OverlapBrushDX   = null;

			if(SupBrushDX!=null        && !SupBrushDX.IsDisposed)        SupBrushDX.Dispose();        SupBrushDX		= null;
			if(SupStrokeBrushDX!=null  && !SupStrokeBrushDX.IsDisposed)  SupStrokeBrushDX.Dispose();  SupStrokeBrushDX	= null;
			if(SupTestedBrushDX!=null  && !SupTestedBrushDX.IsDisposed)  SupTestedBrushDX.Dispose();  SupTestedBrushDX  = null;
			if(SupTestedStrokeBrushDX!=null && !SupTestedStrokeBrushDX.IsDisposed)  SupTestedStrokeBrushDX.Dispose();  SupTestedStrokeBrushDX  = null;
			if(SupBrokenBrushDX!=null        && !SupBrokenBrushDX.IsDisposed)        SupBrokenBrushDX.Dispose();        SupBrokenBrushDX		= null;
			if(SupBrokenStrokeBrushDX!=null  && !SupBrokenStrokeBrushDX.IsDisposed)  SupBrokenStrokeBrushDX.Dispose();  SupBrokenStrokeBrushDX	= null;

			if(ResBrushDX!=null        && !ResBrushDX.IsDisposed)        ResBrushDX.Dispose();        ResBrushDX		= null;
			if(ResStrokeBrushDX!=null  && !ResStrokeBrushDX.IsDisposed)  ResStrokeBrushDX.Dispose();  ResStrokeBrushDX	= null;
			if(ResTestedBrushDX!=null       && !ResTestedBrushDX.IsDisposed)        ResTestedBrushDX.Dispose();        ResTestedBrushDX        = null;
			if(ResTestedStrokeBrushDX!=null && !ResTestedStrokeBrushDX.IsDisposed)  ResTestedStrokeBrushDX.Dispose();  ResTestedStrokeBrushDX  = null;
			if(ResBrokenBrushDX!=null        && !ResBrokenBrushDX.IsDisposed)        ResBrokenBrushDX.Dispose();        ResBrokenBrushDX		= null;
			if(ResBrokenStrokeBrushDX!=null  && !ResBrokenStrokeBrushDX.IsDisposed)  ResBrokenStrokeBrushDX.Dispose();  ResBrokenStrokeBrushDX	= null;
			if(SplitAssistMarkerBrushDX!=null && !SplitAssistMarkerBrushDX.IsDisposed) SplitAssistMarkerBrushDX.Dispose(); SplitAssistMarkerBrushDX =null;
			if(SplitMarkerOutlineBrushDX!=null && !SplitMarkerOutlineBrushDX.IsDisposed) SplitMarkerOutlineBrushDX.Dispose(); SplitMarkerOutlineBrushDX =null;

			if(tpoVerticalBarBrushDX!=null    && !tpoVerticalBarBrushDX.IsDisposed) tpoVerticalBarBrushDX.Dispose(); tpoVerticalBarBrushDX =null;
			if(vpVerticalBarBrushDX!=null     && !vpVerticalBarBrushDX.IsDisposed)  vpVerticalBarBrushDX.Dispose();  vpVerticalBarBrushDX  =null;
			if(SessionBreak_BrushDX!=null && !SessionBreak_BrushDX.IsDisposed) SessionBreak_BrushDX.Dispose(); SessionBreak_BrushDX=null;
			
			if(yellowBrushDX!=null && !yellowBrushDX.IsDisposed) yellowBrushDX.Dispose(); yellowBrushDX=null;
			if(magentaBrushDX!=null && !magentaBrushDX.IsDisposed) magentaBrushDX.Dispose(); magentaBrushDX=null;
			if(pinkBrushDX!=null && !pinkBrushDX.IsDisposed) pinkBrushDX.Dispose(); pinkBrushDX=null;
			if(merge_warning_BrushDX!=null && !merge_warning_BrushDX.IsDisposed) merge_warning_BrushDX.Dispose(); merge_warning_BrushDX=null;
			if(backBrushDX!=null && !backBrushDX.IsDisposed) backBrushDX.Dispose(); backBrushDX=null;
			if(boxTextBrushDX!=null && !boxTextBrushDX.IsDisposed) boxTextBrushDX.Dispose(); boxTextBrushDX=null;
			if(borderBrushDX!=null && !borderBrushDX.IsDisposed) borderBrushDX.Dispose(); borderBrushDX=null;
			if(whiteBrushDX!=null && !whiteBrushDX.IsDisposed) whiteBrushDX.Dispose(); whiteBrushDX=null;
			if(blackBrushDX!=null && !blackBrushDX.IsDisposed) blackBrushDX.Dispose(); blackBrushDX=null;
			if(OpenMarkerBrushDX!=null && !OpenMarkerBrushDX.IsDisposed) OpenMarkerBrushDX.Dispose(); OpenMarkerBrushDX=null;
			if(UpCloseMarkerBrushDX!=null && !UpCloseMarkerBrushDX.IsDisposed) UpCloseMarkerBrushDX.Dispose(); UpCloseMarkerBrushDX=null;
			if(DownCloseMarkerBrushDX!=null && !DownCloseMarkerBrushDX.IsDisposed) DownCloseMarkerBrushDX.Dispose(); DownCloseMarkerBrushDX=null;
//			if(!=null && !.IsDisposed) .Dispose(); =null;
			if(TPOCounterFont_BrushDX!=null && !TPOCounterFont_BrushDX.IsDisposed) TPOCounterFont_BrushDX.Dispose(); TPOCounterFont_BrushDX=null;
			if(TPOCounterFont_BkgBrushDX!=null && !TPOCounterFont_BkgBrushDX.IsDisposed) TPOCounterFont_BkgBrushDX.Dispose(); TPOCounterFont_BkgBrushDX=null;
			if(HVN_BrushDX!=null && !HVN_BrushDX.IsDisposed) HVN_BrushDX.Dispose(); HVN_BrushDX=null;
			if(LVN_BrushDX!=null && !LVN_BrushDX.IsDisposed) LVN_BrushDX.Dispose(); LVN_BrushDX=null;
#if HTO_LTO
			if(HTO_BrushDX!=null && !HTO_BrushDX.IsDisposed) HTO_BrushDX.Dispose(); HTO_BrushDX=null;
			if(LTO_BrushDX!=null && !LTO_BrushDX.IsDisposed) LTO_BrushDX.Dispose(); LTO_BrushDX=null;
#endif
line=6861;
			
			#endregion

int count = 0;
			if(RenderTarget!=null){
				float divisor = 100f;
				#region -- Brush init --
				if(RenderTarget!=null)
					vpVA_BrushDX              = vpVABrush.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					vpVA_BrushDX.Opacity      = pvpVA_Opacity/divisor;
				if(RenderTarget!=null){
count=1;
					vpAboveVA_BrushDX         = vpAboveVABrush.ToDxBrush(RenderTarget);
					vpAboveVA_BrushDX.Opacity = pvpNonVA_Opacity/divisor;
				}
				if(RenderTarget!=null){
count=2;
					vpBelowVA_BrushDX         = vpBelowVABrush.ToDxBrush(RenderTarget);
					vpBelowVA_BrushDX.Opacity = pvpNonVA_Opacity/divisor;
				}
				if(RenderTarget!=null){
count=3;
					tpoVA_BrushDX             = tpoVABrush.ToDxBrush(RenderTarget);
					tpoVA_BrushDX.Opacity     = ptpoVA_Opacity/divisor;
				}
				if(RenderTarget!=null)
					tpoAboveVA_BrushDX        = tpoAboveVABrush.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					tpoBelowVA_BrushDX        = tpoBelowVABrush.ToDxBrush(RenderTarget);

line=6893;
				if(RenderTarget!=null)
					tpoSinglePrintLine_BrushDX = tpoSinglePrintLine_Brush.ToDxBrush(RenderTarget);
				if(RenderTarget!=null){
count=4;
					tpoPOC_BrushDX			   = tpoPOC_Brush.ToDxBrush(RenderTarget);
					tpoPOC_BrushDX.Opacity	   = tpoPOC_Opacity/divisor;
				}
line=6901;
				if(RenderTarget!=null){
count=5;
					vpPOC_BrushDX			 = vpPOC_Brush.ToDxBrush(RenderTarget);
					vpPOC_BrushDX.Opacity	 = vpPOC_Opacity/divisor;
				}

				if(RenderTarget!=null){
count=6;
					DisqBrushDX				 = DisqZone_Brush.ToDxBrush(RenderTarget);
					DisqBrushDX.Opacity		 = DisqZoneOpacity/divisor;
				}
				
				if(RenderTarget!=null){
count=7;
					OverlapBrushDX			 = OverlapZone_Brush.ToDxBrush(RenderTarget);
					OverlapBrushDX.Opacity	 = OverlapZoneOpacity/divisor;
				}

				if(RenderTarget!=null){
count=8;
					SupBrushDX				 = SupZone_Brush.ToDxBrush(RenderTarget);
					SupBrushDX.Opacity       = SupZoneOpacity/divisor;
				}
				if(RenderTarget!=null)
					SupStrokeBrushDX		 = SupZoneBorder.Brush.ToDxBrush(RenderTarget);

				if(RenderTarget!=null){
count=9;
					ResBrushDX		         = ResZone_Brush.ToDxBrush(RenderTarget);
					ResBrushDX.Opacity       = ResZoneOpacity/divisor;
				}
				if(RenderTarget!=null)
					ResStrokeBrushDX		 = ResZoneBorder.Brush.ToDxBrush(RenderTarget);

				if(RenderTarget!=null){
count=10;
					SupTestedBrushDX		 = SupTestedZone_Brush.ToDxBrush(RenderTarget);
					SupTestedBrushDX.Opacity = SupTestedZoneOpacity/divisor;
				}

				if(RenderTarget!=null)
					SupTestedStrokeBrushDX	 = SupTestedZoneBorder.Brush.ToDxBrush(RenderTarget);
				if(RenderTarget!=null){
count=11;
					ResTestedBrushDX		 = ResTestedZone_Brush.ToDxBrush(RenderTarget);
					ResTestedBrushDX.Opacity = ResTestedZoneOpacity/divisor;
				}

				if(RenderTarget!=null)
					ResTestedStrokeBrushDX	 = ResTestedZoneBorder.Brush.ToDxBrush(RenderTarget);

				if(RenderTarget!=null){
count=12;
					ResBrokenBrushDX         = ResBrokenZone_Brush.ToDxBrush(RenderTarget);
					ResBrokenBrushDX.Opacity = ResBrokenZoneOpacity/divisor;
				}

				if(RenderTarget!=null)
					ResBrokenStrokeBrushDX	 = ResBrokenZoneBorder.Brush.ToDxBrush(RenderTarget);

				if(RenderTarget!=null){
count=13;
					SupBrokenBrushDX         = SupBrokenZone_Brush.ToDxBrush(RenderTarget);
					SupBrokenBrushDX.Opacity = SupBrokenZoneOpacity/divisor;
				}

				if(RenderTarget!=null)
					SupBrokenStrokeBrushDX	 = SupBrokenZoneBorder.Brush.ToDxBrush(RenderTarget);

				if(RenderTarget!=null){
count=14;
					SplitAssistMarkerBrushDX         = SplitAssistMarkerBrush.ToDxBrush(RenderTarget);
					SplitAssistMarkerBrushDX.Opacity = SplitMarkerFillOpacity/divisor;
				}
				if(RenderTarget!=null)
					SplitMarkerOutlineBrushDX        = SplitMarkerOutline_Stroke.Brush.ToDxBrush(RenderTarget);

				if(RenderTarget!=null)
					vpVerticalBarBrushDX     = vpVerticalBarBrush.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					tpoVerticalBarBrushDX    = tpoVerticalBarBrush.ToDxBrush(RenderTarget);
				
				if(RenderTarget!=null)
					SessionBreak_BrushDX = SessionBreak_Brush.ToDxBrush(RenderTarget);
				
				if(RenderTarget!=null)
					yellowBrushDX = Brushes.Yellow.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					magentaBrushDX = Brushes.Magenta.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					pinkBrushDX   = Brushes.Pink.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					whiteBrushDX  = Brushes.White.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					blackBrushDX  = Brushes.Black.ToDxBrush(RenderTarget);

				if(RenderTarget!=null){
count=15;
					merge_warning_BrushDX = Brushes.LimeGreen.ToDxBrush(RenderTarget);
					merge_warning_BrushDX.Opacity = 0.5f;
				}

				if(RenderTarget!=null)
					backBrushDX     = ATR_Delta_Box_Back_Color.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					boxTextBrushDX  = ATR_Delta_Box_Font_Color.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					borderBrushDX   = ATR_Delta_Box_Border.Brush.ToDxBrush(RenderTarget);
				
				if(RenderTarget!=null)
					OpenMarkerBrushDX      = OpenMarkerBrush.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					UpCloseMarkerBrushDX   = UpCloseMarkerBrush.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					DownCloseMarkerBrushDX = DownCloseMarkerBrush.ToDxBrush(RenderTarget);
				
				if(RenderTarget!=null)
					TPOCounterFont_BrushDX    = TPOCounterFont_Brush.ToDxBrush(RenderTarget);
				if(RenderTarget!=null)
					TPOCounterFont_BkgBrushDX = TPOCounterFont_BkgBrush.ToDxBrush(RenderTarget);

				if(RenderTarget!=null){
count=16;
					HVN_BrushDX = HVN_Brush.ToDxBrush(RenderTarget); HVN_BrushDX.Opacity = pHVN_Opacity/100f;
				}
				if(RenderTarget!=null){
count=17;
					LVN_BrushDX = LVN_Brush.ToDxBrush(RenderTarget); LVN_BrushDX.Opacity = pLVN_Opacity/100f;
				}
#if HTO_LTO
				if(RenderTarget!=null){
					HTO_BrushDX = HTO_Brush.ToDxBrush(RenderTarget); HTO_BrushDX.Opacity = pHTO_Opacity/100f;
				}
				if(RenderTarget!=null){
					LTO_BrushDX = LTO_Brush.ToDxBrush(RenderTarget); LTO_BrushDX.Opacity = pLTO_Opacity/100f;
				}
#endif
				#endregion
			}
if(IsDebug && count>0 && count!=17) Log("OnRenderTargetChange()  Count = "+count.ToString(), NinjaTrader.Cbi.LogLevel.Information);
		}
//=============================================================================================================
		private class ArbitrageZoneData {
			public int StartABar;
			public int EndABar;
			public double HighPrice;
			public double LowPrice;
			public char ZoneType;
			public ArbitrageZoneData( int startABar, int endABar, char zoneType, double highPrice, double lowPrice){/*SessionStartABar=sessionStartABar; */StartABar=startABar; EndABar=endABar; ZoneType=zoneType; HighPrice=highPrice; LowPrice=lowPrice;}
		}
		private List<ArbitrageZoneData> ArbitrageZones = new List<ArbitrageZoneData>();
		
		private class ArbZoneDataCSV {
			public DateTime     StartTime;
			public int          EndABar;
			public double       OpenPrice;
			public List<double> NearEdges = new List<double>();
			public List<double> FarEdges  = new List<double>();
			public ArbZoneDataCSV(double openPrice){ OpenPrice=openPrice; }
			public void AddEdges(double Edge1, double Edge2, int endabar, char zoneType){
				double max = Math.Max(Edge1, Edge2);
				double min = Math.Min(Edge1, Edge2);
				EndABar = endabar;
				if(max >= OpenPrice && min <= OpenPrice) {
					if(zoneType=='R') {NearEdges.Add(min); FarEdges.Add(max);}
					if(zoneType=='S') {NearEdges.Add(max); FarEdges.Add(min);}
				}
				if(max < OpenPrice) {NearEdges.Add(max); FarEdges.Add(min);}
				if(min > OpenPrice) {NearEdges.Add(min); FarEdges.Add(max);}
			}
		}
		private SortedDictionary<DateTime,ArbZoneDataCSV> CSVdata = new SortedDictionary<DateTime, ArbZoneDataCSV>();
//=============================================================================================================
//=============================================================================================================
		private SharpDX.DirectWrite.TextLayout ATR_RR_Layout=null;
		private float ATRBox_width = 0f;
		private float ATRBox_height = 0f;
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale) 
		{
line=7078;
			if(!RealtimeStateFinished) return;//pause the drawing of the zones...the mouse-movements from the user are causing SortedDictionary lookup errors
			if (!IsVisible) return;
			if (chartControl==null) return;
			if (IsInHitTest) {
				if(Delayed_Ray_Deletion){
					RemoveThisTag("DelayedRayDeleteMsg");
					Delayed_Ray_Deletion = false;
					var HistoricalProfileIds   = Prof.Keys.Where(csd=> csd < FirstProfileIdOfCurrentSession).ToList();
					ApplyGlobalRaySelections(phVisual_ScopeVARays, phVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, HistoricalProfileIds);
					var CurrentProfileIds      = Prof.Keys.Where(csd=> csd >= FirstProfileIdOfCurrentSession).ToList();
					ApplyGlobalRaySelections(pcVisual_ScopeVARays, pcVisual_ScopePOCRays, pPermitVAHRaysZones, pPermitVALRaysZones, CurrentProfileIds);
					ImmediatelyDraw_Rays(Global_POC_Rays,  pcShowDisqualifiedRays, phShowDisqualifiedRays);
					ImmediatelyDraw_Rays(Global_VAHL_Rays, pcShowDisqualifiedRays, phShowDisqualifiedRays);
				}
				return;
			}
line=7095;
if(false && IsDebug && MM.HoverProfileId>0 && Keyboard.IsKeyDown(Key.LeftCtrl)){
	#region Interrogate the profile
	PrintNew1("");
	try{
		var bddk = TPO_Data.BarData.Where(kee=> kee.Key>=Prof[MM.HoverProfileId].StartTime && kee.Key<Prof[MM.HoverProfileId].EndTime);
		if(bddk!=null) foreach(var b1 in bddk) {
			PrintNew1(string.Format("{0}    {1}  {2}",line, b1.Key.ToString(), b1.Value.ToStr()));
			if(this.ObjTagPrefix!="D")TriggerCustomEvent(o =>{	Draw.Diamond(this,b1.Value.Letter+"@"+b1.Key.ToString(),false,b1.Key, Lows[0].GetValueAt(BarsArray[0].GetBar(b1.Key))-TickSize*3,Brushes.Yellow);},0,null);
		}
		var barclosetime = BarsArray[0].GetTime(MM.MouseABar);
		var bardatas = TPO_Data.BarData.Keys.Where(kee=> kee<=barclosetime).ToList();
		barclosetime = bardatas.Max();
		PrintNew1(string.Format("{0}  letter: {1}",barclosetime.ToString(), TPO_Data.BarData[barclosetime].Letter));
		var stri = string.Empty;
		double rmp = RoundToTick(MM.MousePrice);
		if(Prof[MM.HoverProfileId].TPOatP.ContainsKey(rmp)){
			PrintNew1("MousePrice: "+rmp);
			try{
				foreach(var le in Prof[MM.HoverProfileId].TPOatP[rmp]) stri = string.Format("{0} {1}",stri,le);
				PrintNew1(stri);
			}catch(Exception e1){PrintNew1(line+"  moc Ben 4624:  "+e1.ToString());}
		}
	}catch(Exception e2){PrintNew1(line+"  moc Ben 4626:  "+e2.ToString());}
	#endregion
}
line=7121;
//Print("6375  "+DateTime.Now.ToString());		return;
			#region Save bar colors if they are non-transparent
			if(!EqualColor(Brushes.Transparent, ChartBars.Properties.ChartStyle.UpBrush) && !EqualColor(CandleBodyUpBrush, ChartBars.Properties.ChartStyle.UpBrush)) {
				CandleBodyUpBrush = ChartBars.Properties.ChartStyle.UpBrush.Clone();
				CandleBodyUpBrush.Freeze();
			}
			if(!EqualColor(Brushes.Transparent, ChartBars.Properties.ChartStyle.DownBrush) && !EqualColor(CandleBodyDownBrush, ChartBars.Properties.ChartStyle.DownBrush))	{
				CandleBodyDownBrush = ChartBars.Properties.ChartStyle.DownBrush.Clone();
				CandleBodyDownBrush.Freeze();
			}
			if(!EqualColor(Brushes.Transparent, ChartBars.Properties.ChartStyle.Stroke.Brush) && !EqualColor(CandleOutlineBrush, ChartBars.Properties.ChartStyle.Stroke.Brush)) {
				CandleOutlineBrush = ChartBars.Properties.ChartStyle.Stroke.Brush.Clone();
				CandleOutlineBrush.Freeze();
			}
			if(!EqualColor(Brushes.Transparent, ChartBars.Properties.ChartStyle.Stroke2.Brush) && !EqualColor(CandleWickBrush, ChartBars.Properties.ChartStyle.Stroke2.Brush))	{
				CandleWickBrush = ChartBars.Properties.ChartStyle.Stroke2.Brush.Clone();
				CandleWickBrush.Freeze();
			}
			#endregion

line=7142;
			bool RecalcScreenCoord = (ShowZonesClickedJustNow || InitializationRun) ? true : false;
			if(InitializationRun && Prof.Count>0) InitializationRun = false;
			#region Determine if screen has been resized
			bool RecalcZonesVisible = false;
			if(chartScale.MinValue       != MM.ChartMinPrice) {
				//PrintNew1("3046   "+chartScale.MinValue+"   MM."+MM.ChartMinPrice);
				RecalcScreenCoord=true; RecalcZonesVisible=true; MM.ChartMinPrice = chartScale.MinValue;
			}
			else if(chartScale.MaxValue  != MM.ChartMaxPrice) {
				//PrintNew1("3050   "+chartScale.MaxValue+"   MM."+MM.ChartMaxPrice);
				RecalcScreenCoord=true; RecalcZonesVisible=true; MM.ChartMaxPrice = chartScale.MaxValue;
			}
//			else if(BarsInProgress==0 && IsFirstTickOfBar) {
//				PrintNew1("3054   ");
//				RecalcScreenCoord=true;
//			}
			else if(ChartBars.FromIndex    != MM.ChartMinABar)  {
				//PrintNew1("3058   "+ChartBars.FromIndex+"   MM."+MM.ChartMinABar);
				RecalcScreenCoord=true; MM.ChartMinABar = ChartBars.FromIndex;
			}
			else if(ChartBars.ToIndex      != MM.ChartMaxABar)  {
				//PrintNew1("3062   "+ChartBars.ToIndex+"   MM."+MM.ChartMaxABar);
				RecalcScreenCoord=true; MM.ChartMaxABar = ChartBars.ToIndex;
			}
			else if(Prof.Count != MM.TPOCount) {
//PrintNew1("New tpo found");
				RecalcScreenCoord=true; RecalcZonesVisible=true;
			}
			MM.TPOCount = Prof.Count;
			//MM.ChartHeight = chartScale.Height;
			MM.MousePrice = chartScale.GetValueByY(MM.Y);
			barwidth_f = chartControl.GetXByBarIndex(ChartBars, 1) - chartControl.GetXByBarIndex(ChartBars, 0);
			barwidth_int = Convert.ToInt32(barwidth_f);
			#endregion

			if(pShow_SessionBreaks){
				var h = (float)chartScale.GetYByValue(chartScale.MinValue);
				foreach(var sb in SessionBreakLocs.Where(b=> b >= ChartBars.FromIndex && b<=ChartBars.ToIndex)){
					RenderTarget.FillRectangle(new SharpDX.RectangleF(
						Convert.ToSingle(chartControl.GetXByBarIndex(ChartBars, sb) + barwidth_f/10.0f),
						0f, 1f, h),//pSessionBreaksSize*10f),
						SessionBreak_BrushDX);
				}
			}
try{
			RMB = Math.Min(MAX_CURRENT_BAR, Math.Min(ChartBars.ToIndex, BarsArray[0].Count-1)-1);
			float RMBx = chartControl.GetXByBarIndex(ChartBars, RMB+1);
			int x = 0;
			int PriceBoxSizePx = Math.Abs((chartScale.GetYByValue(0)-chartScale.GetYByValue(priceBoxSizeInPrice))) - BarSpacing;
			int halfPriceBoxSizePx = PriceBoxSizePx / 2;
			var v0 = new SharpDX.Vector2();
			var v1 = new SharpDX.Vector2();
			int bar2barDistance = chartControl.GetXByBarIndex(ChartBars, 1)-chartControl.GetXByBarIndex(ChartBars, 0);

			#region -- Print error message if price-axis is too condensed --

//			double ticks_per_pixel = 0;
//			if(TimeOfCondensedErrorMessage==DateTime.MinValue){
//				var v0 = chartScale.GetValueByY(0);
//				var v1 = chartScale.GetValueByY(this.p);
//				ticks_per_pixel = Math.Abs((v0-v1)/TickSize);
// //				PrintNew1("Ticks per pixel: "+ticks_per_pixel.ToString("0.00"));
//			}
			if(pShowVP_Histo && pShowErrorMessageWhenTooCondensed){
				var tsCEM = new TimeSpan(DateTime.Now.Ticks-TimeOfCondensedErrorMessage.Ticks);
				if(PriceBoxSizePx < 1 && TimeOfCondensedErrorMessage==DateTime.MinValue) {
					halfPriceBoxSizePx = 1;
					PriceBoxSizePx = 2;
					TimeOfCondensedErrorMessage = DateTime.Now;
					Draw.TextFixed(this, "toosmall","Price axis may be too condensed...increase the TicksPerHistoBar parameter",TextPosition.BottomLeft,Brushes.Black,chartControl.Properties.LabelFont,Brushes.Maroon,Brushes.Red,80);
				}else if(tsCEM.TotalSeconds > 15)
					RemoveThisTag("toosmall");
			}
			#endregion --------------------------

			//find the bar index of the first profile that is immediately off the left-side of the chart
			#region -- Find profileId that is prior to leftmost chart bar --
			var il = Prof.Keys.Where(xi => xi<=ChartBars.FromIndex).ToList();

			int prior_i = 0;
			if(il==null || il.Count==0) prior_i = Prof.Keys.First();
			else prior_i = il.Last();
			#endregion -----------------------------

			var   RM_ProfileId = -1;//this will be the profileId of the rightmost visible profile
			var   rect         = new SharpDX.RectangleF();
			var   rect_HNLN    = new SharpDX.RectangleF();//rectangle for drawing HVN and LVN and HTO and LTO histo bars
			float max_histowidth_pixels     = int.MaxValue;
			float TPO_pixels_per_occurrence = 0;
			float VP_pixels_per_vol = 0;
			bool  TPO_plot_IsDot    = miTPO_VisualStyle!=null ? (miTPO_VisualStyle.Header.ToString().Contains("Dot")) : false;
			int   Prior_profileId   = int.MinValue;//used for finding overlapping TPO value areas, and highlighting them

			var zonePricesTextFormat = this.pZonePricesFont.ToDirectWriteTextFormat();
			var zonePricesLayout     = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, Instrument.MasterInstrument.FormatPrice(Closes[0][0]), zonePricesTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
			var RMx = ChartPanel.W;//chartControl.GetXByBarIndex(ChartBars, ChartBars.ToIndex);
			var AlertsEnabled        = pPrintToAlertWindow || pLaunchPopupsOnZoneHit || pLaunchPopupsOnFrontrun || pEmailOnZoneHit.Length>0 || pEmailOnFrontRun.Length>0;

			int ArbZoneCount=0;
			if(this.SaveArbZoneData) {
				ArbZoneOutput.Clear();
				ArbZoneOutput.Add("Dir = 1 is Support...-1 is Resistance");
				ArbZoneOutput.Add("Price = zone top for Support zone...zone bottom for Resistance zone");
				ArbZoneOutput.Add("Type = 'B' is broken...'F' is Fresh (untouched)...'T' is touched");
				ArbZoneOutput.Add("");
				ArbZoneOutput.Add("Dir,LowPrice,HighPrice,Zone#,Type,StartDT,InForceDT,EndDT");
				ArbZoneCount = ArbZoneOutput.Count;
			}
//if(EXAMINE_THIS_PROFILE>=0 && Prof.ContainsKey(EXAMINE_THIS_PROFILE)){
//	foreach(var kdd in Prof[EXAMINE_THIS_PROFILE].Zones.Keys) {
//		Print("Zone Key: "+(kdd==SUP_ID ? "Support":"Resistance"));
//		Print("Prof["+EXAMINE_THIS_PROFILE+"].Zones[].Tested: "+Prof[EXAMINE_THIS_PROFILE].Zones[kdd].Tested.ToString());
//		Print("Prof["+EXAMINE_THIS_PROFILE+"].Zones[].Disq: "+Prof[EXAMINE_THIS_PROFILE].Zones[kdd].Disqualified.ToString());
//		Print("Prof["+EXAMINE_THIS_PROFILE+"].Zones[].Broken: "+Prof[EXAMINE_THIS_PROFILE].Zones[kdd].Broken.ToString());
//		Print("Prof["+EXAMINE_THIS_PROFILE+"].Zones[].EndABar: "+Prof[EXAMINE_THIS_PROFILE].Zones[kdd].EndABar.ToString());
//	}
//}
			if(pShow_BrokenZones || pShow_FreshZones || pShow_TestedZones || pShow_DisqZones || pShow_OverlappedZones){
				if(RecalcZonesVisible || Closes[0].GetValueAt(CurrentBars[0]) < chartScale.MinValue || Closes[0].GetValueAt(CurrentBars[0]) > chartScale.MaxValue || ProfKeysWithZonesInView==null){
					ProfKeysWithZonesInView = Prof.Where(xp=> xp.Value.StartABar<ChartBars.ToIndex && xp.Value.Zones.Any(xp2 => (/*!xp2.Value.Overlapped && !xp2.Value.Disqualified &&*/ xp2.Value.EndABar>ChartBars.FromIndex /*&& xp2.Value.HighPrice > chartScale.MinValue && xp2.Value.LowPrice < chartScale.MaxValue*/))).Select(xp=>xp.Key).ToList();
					if(ProfKeysWithZonesInView!=null && ProfKeysWithZonesInView.Count>1 && ProfKeysWithZonesInView.First()<ProfKeysWithZonesInView.Last()) ProfKeysWithZonesInView.Reverse();//first key should be the maximum key
				}
				RecalcZonesVisible = false;
bool iz = false; 
				#region -- ShowZones --
				SharpDX.RectangleF ArbRectangle;
				float x1 = 0f;
				if(ProfKeysWithZonesInView!=null) foreach(var z in ProfKeysWithZonesInView) {
line=7271;
iz = z==75; 
					if(!Prof.ContainsKey(z)) continue;
					if(pShow_CurrentSessionZones){
						if(z == Prof.Keys.Max()) continue;
					}else if(Prof[z].SessionDate == Current_Session_Date.Date) continue;//don't show zones on the current (most recent) session date
					x = chartControl.GetXByTime(Prof[z].StartTime)+bar2barDistance;//chartControl.GetXByBarIndex(ChartBars, profileId) + bar2barDistance/2;

					if(pPermit_SupportZones && pPermitVALRaysZones && Prof[z].Zones.ContainsKey(SUP_ID)) {
						#region -- Handle Support zone printing --
						char ztype = Prof[z].Zones[SUP_ID].Disposition;
						//the specific order of this if-then-else statement is VERY critical...do not change the order of the conditional
						if(     !pShow_OverlappedZones && ztype=='O') ztype = ' ';
						else if(!pShow_DisqZones       && ztype=='D') ztype = ' ';
						else if(!pShow_BrokenZones     && ztype=='B') ztype = ' ';
						else if(!pShow_TestedZones     && ztype=='T') ztype = ' ';
						else if(!pShow_FreshZones      && ztype=='F') ztype = ' ';
if(iz)Print("6683  SUP type: "+ztype);

						if((ztype=='F' || ztype=='T') && AlertsEnabled){
							#region -- Manage audible alerts on fresh and tested zones
							double arb_price = Prof[z].Zones[SUP_ID].HighPrice + FrontRunPts;
							if((pPlayOnFrontRunHit || pEmailOnFrontRun.Length>0) && !UntestedSupPrices.ContainsKey(arb_price) && arb_price < Lows[0].GetValueAt(CurrentBars[0]))
									UntestedSupPrices[arb_price] = 'F';//'F' for Frontrunner alert
							if(pPlayOnZoneHit || pEmailOnZoneHit.Length>0){
								arb_price = Prof[z].Zones[SUP_ID].HighPrice;
								if(!UntestedSupPrices.ContainsKey(arb_price) && arb_price < Lows[0].GetValueAt(CurrentBars[0]))
									UntestedSupPrices[arb_price] = 'Z';//'Z' for Zone alert
							}
							#endregion ---------------------
						}
						if(ztype != ' '){//if the zone is selected to be visible on the chart
							Prof[z].Zones[SUP_ID].ScreenXYWH[0]  = x;
							if(ztype =='F' || ztype =='T') x1 = RMx;
							else                           x1 = chartControl.GetXByBarIndex(ChartBars, Prof[z].Zones[SUP_ID].EndABar);
//if(iz) PrintNew1(string.Format("{0}   x{1} x1{2}  FirstPIDNextSession {3}", z, x, x1, FirstProfileIdOfNextSession));

							Prof[z].Zones[SUP_ID].ScreenXYWH[2] = Math.Abs(x1 - Prof[z].Zones[SUP_ID].ScreenXYWH[0]);
							Prof[z].Zones[SUP_ID].ScreenXYWH[1] = chartScale.GetYByValue(Prof[z].Zones[SUP_ID].HighPrice);
							Prof[z].Zones[SUP_ID].ScreenXYWH[3] = chartScale.GetPixelsForDistance(Prof[z].Zones[SUP_ID].HighPrice - Prof[z].Zones[SUP_ID].LowPrice);
							ArbRectangle = new SharpDX.RectangleF(Prof[z].Zones[SUP_ID].ScreenXYWH[0], Prof[z].Zones[SUP_ID].ScreenXYWH[1], Prof[z].Zones[SUP_ID].ScreenXYWH[2], Prof[z].Zones[SUP_ID].ScreenXYWH[3]);
//if(iz) PrintNew1(string.Format("   ArbRect: x{0} y{1} w{2} h{3}", ArbRectangle.X, ArbRectangle.Y, ArbRectangle.Width, ArbRectangle.Height));
							var zoneBrushDX = (ztype=='D' ? DisqBrushDX : (ztype=='O' ? OverlapBrushDX : (ztype=='B' ? SupBrokenBrushDX : (ztype=='T' ? SupTestedBrushDX : SupBrushDX))));
							RenderTarget.FillRectangle(ArbRectangle, zoneBrushDX);
							RenderTarget.DrawRectangle(ArbRectangle, 
								ztype=='B' ? SupBrokenStrokeBrushDX			 :(ztype=='T' ? SupTestedStrokeBrushDX          : SupStrokeBrushDX), 
								ztype=='B' ? SupBrokenZoneBorder.Width       :(ztype=='T' ? SupTestedZoneBorder.Width       : SupZoneBorder.Width), 
								ztype=='B' ? SupBrokenZoneBorder.StrokeStyle :(ztype=='T' ? SupTestedZoneBorder.StrokeStyle : SupZoneBorder.StrokeStyle));
							if(this.SaveArbZoneData){
								#region -- Save ArbZone data --
								var sbl_List = SessionBreakLocs.Where(sbl=> sbl>z).ToList();
								var NextSessionStartTime = DateTime.MaxValue;
								if(sbl_List!=null && sbl_List.Count>0) NextSessionStartTime = Times[0].GetValueAt(sbl_List.Min());
								ArbitrageZones.Add(new ArbitrageZoneData(z, Prof[z].Zones[SUP_ID].EndABar, 'S', Prof[z].Zones[SUP_ID].HighPrice, Prof[z].Zones[SUP_ID].LowPrice));
								ArbZoneOutput.Add(string.Format("1,{0},{1},{2},{3},{4},{5},{6}", Prof[z].Zones[SUP_ID].LowPrice, Prof[z].Zones[SUP_ID].HighPrice, ArbZoneOutput.Count-ArbZoneCount, ztype, Prof[z].StartTime.ToString(), NextSessionStartTime.ToString(), ztype=='F' ? string.Empty : Times[0].GetValueAt(Prof[z].Zones[SUP_ID].EndABar).ToString()));
								#endregion
							}
							if(pShow_ZonePrices){
								#region -- Show zone prices --
								var labelRect = new SharpDX.RectangleF(Math.Min(RMx, x1)-zonePricesLayout.Metrics.Width-2f, Prof[z].Zones[SUP_ID].ScreenXYWH[1]-zonePricesLayout.Metrics.Height-0f, zonePricesLayout.Metrics.Width, Convert.ToSingle(this.ZonePricesFont.Size));
								float op = zoneBrushDX.Opacity;
								zoneBrushDX.Opacity = 1f;
								RenderTarget.DrawText(Instrument.MasterInstrument.FormatPrice(Prof[z].Zones[SUP_ID].HighPrice), zonePricesTextFormat, labelRect, zoneBrushDX);
								labelRect = new SharpDX.RectangleF(Math.Min(RMx, x1)-zonePricesLayout.Metrics.Width-2f, chartScale.GetYByValue(Prof[z].Zones[SUP_ID].LowPrice)+0f, zonePricesLayout.Metrics.Width, Convert.ToSingle(this.ZonePricesFont.Size));
								RenderTarget.DrawText(Instrument.MasterInstrument.FormatPrice(Prof[z].Zones[SUP_ID].LowPrice), zonePricesTextFormat, labelRect, zoneBrushDX);
								zoneBrushDX.Opacity = op;
								#endregion
							}
						}
						#endregion ----------------------------------------- 
					}
					if(pPermit_ResistanceZones && pPermitVAHRaysZones && Prof[z].Zones.ContainsKey(RES_ID)) {
						#region -- Handle Resistance zone printing --
						char ztype = Prof[z].Zones[RES_ID].Disposition;
						//the specific order of this if-then-else statement is VERY critical...do not change the order of the conditional
						if(     !pShow_OverlappedZones && ztype=='O') ztype = ' ';
						else if(!pShow_DisqZones       && ztype=='D') ztype = ' ';
						else if(!pShow_BrokenZones     && ztype=='B') ztype = ' ';
						else if(!pShow_TestedZones     && ztype=='T') ztype = ' ';
						else if(!pShow_FreshZones      && ztype=='F') ztype = ' ';
if(iz)Print("6746  RES type: "+ztype);
						if((ztype=='F' || ztype=='T') && AlertsEnabled){
							#region -- Manage audible alerts on fresh and tested zones
							double arb_price = Prof[z].Zones[RES_ID].LowPrice - FrontRunPts;
							if((pPlayOnFrontRunHit || pEmailOnFrontRun.Length>0) && !UntestedResPrices.ContainsKey(arb_price) && arb_price > Highs[0].GetValueAt(CurrentBars[0])){
//Print("Adding Frontrun alert on Res at "+arb_price);
								UntestedResPrices[arb_price] = 'F';//'F' for Frontrunner alert
							}
							if(pPlayOnZoneHit || pEmailOnZoneHit.Length>0){
								arb_price = Prof[z].Zones[RES_ID].LowPrice;
								if(!UntestedResPrices.ContainsKey(arb_price) && arb_price > Highs[0].GetValueAt(CurrentBars[0])){
//Print("Adding zonehit alert on Res at "+arb_price);
									UntestedResPrices[arb_price] = 'Z';//'Z' for Zone alert
								}
							}
							#endregion ---------------------
						}
						if(ztype != ' '){//if the zone is selected to be visible on the chart
							Prof[z].Zones[RES_ID].ScreenXYWH[0]  = x;
							if(ztype =='F' || ztype =='T') x1 = RMx;
							else                           x1 = chartControl.GetXByBarIndex(ChartBars, Prof[z].Zones[RES_ID].EndABar);
//if(iz) Print("RES  "+(ztype=='D' ? Prof[z].EndABar.ToString():""));
							Prof[z].Zones[RES_ID].ScreenXYWH[2] = Math.Abs(x1 - Prof[z].Zones[RES_ID].ScreenXYWH[0]);
							Prof[z].Zones[RES_ID].ScreenXYWH[1] = chartScale.GetYByValue(Prof[z].Zones[RES_ID].HighPrice);
							Prof[z].Zones[RES_ID].ScreenXYWH[3] = chartScale.GetPixelsForDistance(Prof[z].Zones[RES_ID].HighPrice - Prof[z].Zones[RES_ID].LowPrice);
							ArbRectangle = new SharpDX.RectangleF(Prof[z].Zones[RES_ID].ScreenXYWH[0], Prof[z].Zones[RES_ID].ScreenXYWH[1], Prof[z].Zones[RES_ID].ScreenXYWH[2], Prof[z].Zones[RES_ID].ScreenXYWH[3]);
							var zoneBrushDX = (ztype=='D' ? DisqBrushDX : (ztype=='O' ? OverlapBrushDX : (ztype=='B' ? ResBrokenBrushDX : (ztype=='T' ? ResTestedBrushDX : ResBrushDX))));
							RenderTarget.FillRectangle(ArbRectangle, zoneBrushDX);
							RenderTarget.DrawRectangle(ArbRectangle, 
								ztype=='B' ? ResBrokenStrokeBrushDX			 :(ztype=='T' ? ResTestedStrokeBrushDX			: ResStrokeBrushDX), 
								ztype=='B' ? ResBrokenZoneBorder.Width       :(ztype=='T' ? ResTestedZoneBorder.Width       : ResZoneBorder.Width), 
								ztype=='B' ? ResBrokenZoneBorder.StrokeStyle :(ztype=='T' ? ResTestedZoneBorder.StrokeStyle : ResZoneBorder.StrokeStyle));

							if(this.SaveArbZoneData){
								var sbl_List = SessionBreakLocs.Where(sbl=> sbl>z).ToList();
								var NextSessionStartTime = DateTime.MaxValue;
								if(sbl_List!=null && sbl_List.Count>0) NextSessionStartTime = Times[0].GetValueAt(sbl_List.Min());
								ArbitrageZones.Add(new ArbitrageZoneData(z, Prof[z].Zones[RES_ID].EndABar, 'R', Prof[z].Zones[RES_ID].HighPrice, Prof[z].Zones[RES_ID].LowPrice));
								ArbZoneOutput.Add(string.Format("-1,{0},{1},{2},{3},{4},{5},{6}", Prof[z].Zones[RES_ID].LowPrice, Prof[z].Zones[RES_ID].HighPrice, ArbZoneOutput.Count-ArbZoneCount, ztype, Prof[z].StartTime.ToString(), NextSessionStartTime.ToString(), ztype=='F' ? string.Empty : Times[0].GetValueAt(Prof[z].Zones[RES_ID].EndABar).ToString()));
							}
							if(pShow_ZonePrices){
								var labelRect = new SharpDX.RectangleF(Math.Min(RMx, x1)-zonePricesLayout.Metrics.Width-2f, Prof[z].Zones[RES_ID].ScreenXYWH[1]-zonePricesLayout.Metrics.Height-0f, zonePricesLayout.Metrics.Width, Convert.ToSingle(this.ZonePricesFont.Size));
								float op = zoneBrushDX.Opacity;
								zoneBrushDX.Opacity = 1f;
								RenderTarget.DrawText(Instrument.MasterInstrument.FormatPrice(Prof[z].Zones[RES_ID].HighPrice), zonePricesTextFormat, labelRect, zoneBrushDX);
								labelRect = new SharpDX.RectangleF(Math.Min(RMx, x1)-zonePricesLayout.Metrics.Width-2f, chartScale.GetYByValue(Prof[z].Zones[RES_ID].LowPrice)+0f, zonePricesLayout.Metrics.Width, Convert.ToSingle(this.ZonePricesFont.Size));
								RenderTarget.DrawText(Instrument.MasterInstrument.FormatPrice(Prof[z].Zones[RES_ID].LowPrice), zonePricesTextFormat, labelRect, zoneBrushDX);
								zoneBrushDX.Opacity = op;
							}
						}
						#endregion --------------------------------------
					}
				}
				#endregion
			}
			int FirstPrintedProfileId = int.MaxValue;//this is used when we need to draw all HVN/LVN that are from older, non-printed profiles
			var ProfileKeys = Prof.Keys.ToList();
			foreach(int profileId in ProfileKeys.Where(b => b>=prior_i && b>=0 && b<RMB)) 
			{
				if(!Prof.ContainsKey(profileId)) continue;
line=7411;
				RM_ProfileId = profileId;
				FirstPrintedProfileId = Math.Min(FirstPrintedProfileId, profileId);
				x = chartControl.GetXByTime(Prof[profileId].StartTime)+bar2barDistance;//chartControl.GetXByBarIndex(ChartBars, profileId) + bar2barDistance/2;
				if(RecalcScreenCoord) {
					PixelsPerTick = Math.Abs(chartScale.GetYByValue(0) - chartScale.GetYByValue(TickSize));
					#region Clear the ScreenX_TpoEdge of each profile
					foreach(var kvp in Prof) {
						kvp.Value.ScreenXY_TpoEdge.Clear();
						kvp.Value.SplitAssistMarker_ScreenXYWH[0]=0;
						kvp.Value.SplitAssistMarker_ScreenXYWH[1]=0;
						kvp.Value.SplitAssistMarker_ScreenXYWH[2]=0;
						kvp.Value.SplitAssistMarker_ScreenXYWH[3]=0;
					}
					#endregion
					#region Clear the ScreenXYWH of each zone
					foreach(var kvp in Prof[profileId].Zones){
						for(int zii = 0; zii< kvp.Value.ScreenXYWH.Length; zii++)
							kvp.Value.ScreenXYWH[zii] = 0;
					}
					#endregion
				}
				//if(IsDebug && RecalcScreenCoord) PrintNew1(DateTime.Now.Second+"  SplitAssisMarker locs and Rect XY have been recalculated");
line=7434;

				#region -- Print Volume Histo --
				int yLowerPx = chartScale.GetYByValue(Prof[profileId].Lowest_Price) - halfPriceBoxSizePx;
				int yUpperPx = yLowerPx - PriceBoxSizePx;
				if(this.pAutoScaleHistoWidth){
					max_histowidth_pixels = chartControl.GetXByBarIndex(ChartBars, (Prof[profileId].EndABar<0?CurrentBars[0]:Prof[profileId].EndABar)) - chartControl.GetXByTime(Prof[profileId].StartTime);
					//TPO_pixels_per_occurrence = max_histowidth_pixels / Convert.ToSingle(Prof[profileId].ConsolidatedtpoPOC_Volume);
					VP_pixels_per_vol = max_histowidth_pixels *0.9f / Convert.ToSingle(Prof[profileId].ConsolidatedvpPOC_Volume);
				}

				double VPsPerTPO = Prof[profileId].ConsolidatedvpPOC_Volume / Prof[profileId].tpoPOC_Volume;
line=7446;
				if(pShowVP_Histo){
					/*
					When HVN's are a Dot, we ignore any overlap, and we permit the LVN's to go forth as per the LVN visual style setting
					When HVN's are anything but a Dot, then all overlaps are identified by a full length magenta histo bar
					*/
					bool IncompatibleVisualStyles = pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Dot && pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Dot;

					foreach(double pricePtr in Prof[profileId].ConsolidatedVatP.Keys){//.Where(p => p>min && p<max)){
//bool inzone= profileId==137;
//if(inzone) Print("Price: "+pricePtr+"   v: "+Prof[profileId].ConsolidatedVatP[pricePtr]);
						#region Volume Profile histo bars and HVN/LVN (high volume nodes and low volume nodes) (nodes = prices with extreme high or low volume)
line=7458;
						rect = new SharpDX.RectangleF(Convert.ToSingle(x), 
														Convert.ToSingle(yLowerPx), 
														Convert.ToSingle(Prof[profileId].ConsolidatedVatP[pricePtr] * (pAutoScaleHistoWidth ? VP_pixels_per_vol : SelectedVolMultiplier)), 
														Convert.ToSingle(PriceBoxSizePx));
						bool IsHVN = Prof[profileId].HVN.Contains(pricePtr) && pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
						bool IsLVN = Prof[profileId].LVN.Contains(pricePtr) && pVisualType_LVN != ARC_MacroProfiles_VisualsType_HNLN.Hidden;
						bool IsOverlapped = IsHVN && IsLVN;

						bool NormalHistoBar = true;
						bool DrawThisVN =   (IsHVN || IsLVN) && 
											(	(pShow_CurrentProfileVN    && profileId == Prof.Keys.Max()) ||
												(pShow_HistoricalProfileVN && profileId < Prof.Keys.Max())
											);
						if(DrawThisVN && pricePtr != Prof[profileId].ConsolidatedvpPOC_Price){
							if(IsOverlapped){
								if(IncompatibleVisualStyles || pVisualType_HVN != ARC_MacroProfiles_VisualsType_HNLN.Dot){//only if HVN's are dots will we disregard the incompatibility and draw the LVN as whatever the user wants
									NormalHistoBar = false;
									RenderTarget.FillRectangle(rect, magentaBrushDX);
								}
							}
							if(NormalHistoBar){
								rect_HNLN = rect;//by default, use the rectangle of the actual histogram...modify it if Half or Extended is requested
								if(IsHVN){
									#region -- draw histo as a HVN --
									if(pVisualType_HVN == ARC_MacroProfiles_VisualsType_HNLN.Dot){
										float dot_offset = rect.Height;
										if(IsOverlapped){
											if(     pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Dot)     {NormalHistoBar = true; dot_offset=rect.Height*2f;}
											else if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Hidden)   NormalHistoBar = true;
											else if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Half)     NormalHistoBar = true;
											else if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Full)     NormalHistoBar = false;
											else if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Extended) NormalHistoBar = false;
										}
										RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(rect.X+rect.Width + dot_offset,rect.Y+rect.Height/2f), rect.Height/2f, rect.Height/2f), this.HVN_BrushDX);
									}else{
										if(pVisualType_HVN == ARC_MacroProfiles_VisualsType_HNLN.Full){
											NormalHistoBar = false;
										}else if(pVisualType_HVN == ARC_MacroProfiles_VisualsType_HNLN.Half){
											if(IsOverlapped){
												if(     pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Dot)      NormalHistoBar = true;
												else if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Hidden)   NormalHistoBar = true;
											}
											rect_HNLN = new SharpDX.RectangleF(rect.X, rect.Y, rect.Width/2f, rect.Height);
										}else if(pVisualType_HVN == ARC_MacroProfiles_VisualsType_HNLN.Extended){
											NormalHistoBar = false;
											var IsBrokenLevel = Prof[profileId].BrokenVolNodes.Contains(pricePtr);//if a level is broken, do NOT print it as extended
											if(!IsBrokenLevel) rect_HNLN = new SharpDX.RectangleF(rect.X, rect.Y, RMBx-rect.X, rect.Height);
										}
										RenderTarget.FillRectangle(rect_HNLN, this.HVN_BrushDX);
									}
									#endregion
								}
								if(IsLVN){
									#region -- draw histo as a LVN --
									if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Dot){
										if(!IsOverlapped) NormalHistoBar = true;
										RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(rect.X+rect.Width+rect.Height,rect.Y+rect.Height/2f), rect.Height/2f, rect.Height/2f), this.LVN_BrushDX);
									}else{
										if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Full){
											NormalHistoBar = false;
										}else if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Half){
											if(!IsOverlapped) NormalHistoBar = true;
											rect_HNLN = new SharpDX.RectangleF(rect.X, rect.Y, rect.Width/2f, rect.Height);
										}else if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Extended){
											NormalHistoBar = false;
											var IsBrokenLevel = Prof[profileId].BrokenVolNodes.Contains(pricePtr);//if a level is broken, do NOT print it as extended
											if(!IsBrokenLevel) rect_HNLN = new SharpDX.RectangleF(rect.X, rect.Y, RMBx-rect.X, rect.Height);
										}
										RenderTarget.FillRectangle(rect_HNLN, this.LVN_BrushDX);
									}
									#endregion
								}
							}
						}
						if(NormalHistoBar){//it's not a HVN or LVN, just a normal histo
							if(pricePtr == Prof[profileId].ConsolidatedvpPOC_Price)
								RenderTarget.FillRectangle(rect, this.vpPOC_BrushDX);
							else if(pricePtr > Prof[profileId].vpVAL_Price && pricePtr<Prof[profileId].vpVAH_Price)
								RenderTarget.FillRectangle(rect, this.vpVA_BrushDX);
							else if(pricePtr >= Prof[profileId].vpVAH_Price)
								RenderTarget.FillRectangle(rect, this.vpAboveVA_BrushDX);
							else if(pricePtr <= Prof[profileId].vpVAL_Price)
								RenderTarget.FillRectangle(rect, this.vpBelowVA_BrushDX);
						}
						#endregion
						yLowerPx = chartScale.GetYByValue(pricePtr) - halfPriceBoxSizePx - PriceBoxSizePx;
						yUpperPx = yLowerPx - PriceBoxSizePx;
					}
				}
				#endregion
line=7549;
				#region -- Print the vertical bar for the VolProfile VAH-VAL --
				yUpperPx = chartScale.GetYByValue(Prof[profileId].vpVAH_Price);
				yLowerPx = chartScale.GetYByValue(Prof[profileId].vpVAL_Price);
				rect     = new SharpDX.RectangleF(x-8f, yUpperPx, 3f, yLowerPx-yUpperPx);
				RenderTarget.FillRectangle(rect, vpVerticalBarBrushDX);
				#endregion
				var VerticalBar_yTopmost    = yUpperPx-3f;
				var VerticalBar_yBottommost = yLowerPx+3f;
				var VerticalBar_x0 = x-9f;

				#region -- Print the vertical bar for the TPO VAH-VAL --
//if(profileId>=135)Print("OnRender:   "+profileId+"   tpoVAH: "+Prof[profileId].tpoVAH_Price+"   VAL: "+Prof[profileId].tpoVAL_Price);
				yUpperPx = chartScale.GetYByValue(Prof[profileId].tpoVAH_Price);
				yLowerPx = chartScale.GetYByValue(Prof[profileId].tpoVAL_Price);
				rect     = new SharpDX.RectangleF(x-4f, yUpperPx, 3f, yLowerPx-yUpperPx);
				RenderTarget.FillRectangle(rect, tpoVerticalBarBrushDX);
				#endregion
				VerticalBar_yTopmost    = Math.Min(VerticalBar_yTopmost, yUpperPx);
				VerticalBar_yBottommost = Math.Max(VerticalBar_yBottommost, yLowerPx);
				var VerticalBar_x1 = x+1f;

				if(this.pShowTPO_Histo){
					float max_histo_width = 0;
					float min_splitmarker_size = 5f;
					#region -- Print dots at TPO letter positions, and SplitAssitMarker --
					float pixels_per_tpo_volume = max_histowidth_pixels / 2f / Prof[profileId].tpoPOC_Volume;
					float SAMarkerWidth = Math.Max(min_splitmarker_size, Math.Min(min_splitmarker_size*2f,Math.Max(PriceBoxSizePx*1.2f, chartControl.GetBarPaintWidth(ChartBars)*1.5f)));//Math.Max(8f,pixels_per_tpo_volume/2f);
					double prior_pricePtr = double.MinValue;
					double rounded_price = RoundToTick(MM.MousePrice);
					float x_of_tpo_touch_price = 0f;
line=7580;
//if(RecalcScreenCoord || RecalcZonesVisible) PrintNew1(profileId+"   RecalcScreenCoord: "+RecalcScreenCoord.ToString()+"     RecalcZonesVisible: "+RecalcZonesVisible.ToString());

//double rounded_mouse_price = this.RoundToTick(MM.MousePrice);
					var init_tpoedge = Prof[profileId].ScreenXY_TpoEdge.Count==0;
					var tpoAtP_Keys = Prof[profileId].TPOatP.Keys;
					foreach(double pricePtr in tpoAtP_Keys){
						//if(!Prof[profileId].TPOatP.Keys.Contains(pricePtr)) continue;
						v1.Y = chartScale.GetYByValue(pricePtr);
						v1.X = x + pixels_per_tpo_volume * Prof[profileId].TPOatP[pricePtr].Count;
						#region -- Draw SplitAssist marker --
						if(IsSplitMergeEnabled && this.IsSplitAssist && pricePtr == Prof[profileId].SplitAssistPrice && !Prof[profileId].IsSingularDistribution){
	//PrintNew1("drawing split assist marker at "+pricePtr);
							var SArect = new SharpDX.RectangleF(v1.X-SAMarkerWidth/2f, v1.Y-SAMarkerWidth/2f, SAMarkerWidth, SAMarkerWidth);
							RenderTarget.FillRectangle(SArect, SplitAssistMarkerBrushDX);
							RenderTarget.DrawRectangle(SArect, SplitMarkerOutlineBrushDX, SplitMarkerOutline_Stroke.Width, SplitMarkerOutline_Stroke.StrokeStyle);
							Prof[profileId].SplitAssistMarker_ScreenXYWH[0] = SArect.X;
							Prof[profileId].SplitAssistMarker_ScreenXYWH[1] = SArect.Y;
							Prof[profileId].SplitAssistMarker_ScreenXYWH[2] = SArect.Width;
							Prof[profileId].SplitAssistMarker_ScreenXYWH[3] = SArect.Height;
//							RenderTarget.DrawEllipse(new SharpDX.Direct2D1.Ellipse(v1, ellipse_size, ellipse_size), SplitMarkerOutlineBrushDX);  //
						}
//PrintNew1("    3399    "+Prof[profileId].SplitAssistMarker_ScreenXYWH[0]+" : "+(Prof[profileId].SplitAssistMarker_ScreenXYWH[0]+Prof[profileId].SplitAssistMarker_ScreenXYWH[2]).ToString());
//PrintNew1("    3400    "+Prof[profileId].SplitAssistMarker_ScreenXYWH[1]+" : "+(Prof[profileId].SplitAssistMarker_ScreenXYWH[0]+Prof[profileId].SplitAssistMarker_ScreenXYWH[3]).ToString());
						#endregion ---------------------
						rect = new SharpDX.RectangleF(Convert.ToSingle(x), 
														v1.Y- halfPriceBoxSizePx, 0f,
														Convert.ToSingle(PriceBoxSizePx));
						#region -- Draw TPO POC price --
						if(pricePtr == Prof[profileId].tpoPOC_Price){
							rect.Width = v1.X - x - SAMarkerWidth;
							RenderTarget.FillRectangle(rect, this.tpoPOC_BrushDX);
							if(RecalcScreenCoord) Prof[profileId].ScreenXY_TpoEdge[pricePtr] = v1.X;//+15f;
						}
						#endregion ----------------------------

						rect.Width = v1.X-x; 

//						rect = new SharpDX.RectangleF(Convert.ToSingle(x), 
//														Convert.ToSingle(yLowerPx), 
//														v1.X, 
//														Convert.ToSingle(PriceBoxSizePx));
						rect_HNLN = rect;
						if(prior_pricePtr!=double.MinValue){
#if HTO_LTO
							#region -- HTO/LTO --------
							if(pVisualType_HTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden && Prof[profileId].HTO.Contains(pricePtr)){
								if(  pVisualType_HTO == ARC_MacroProfiles_VisualsType_HNLN.Dot){
									RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(v1.X, v1.Y), rect.Height/2f, rect.Height/2f), this.HTO_BrushDX);
								}else{
									if(     pVisualType_HTO == ARC_MacroProfiles_VisualsType_HNLN.Half)     rect_HNLN = new SharpDX.RectangleF(rect.X, rect.Y, rect.Width/2f, rect.Height);
									else if(pVisualType_HTO == ARC_MacroProfiles_VisualsType_HNLN.Extended) rect_HNLN = new SharpDX.RectangleF(rect.X, rect.Y, RMBx-rect.X, rect.Height);
									RenderTarget.FillRectangle(rect_HNLN, this.HTO_BrushDX);
								}
							}
							if(pVisualType_LTO != ARC_MacroProfiles_VisualsType_HNLN.Hidden && Prof[profileId].LTO.Contains(pricePtr)){
								if(  pVisualType_LTO == ARC_MacroProfiles_VisualsType_HNLN.Dot)
									RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(v1.X, v1.Y), rect.Height/2f, rect.Height/2f), this.LTO_BrushDX);
								else{
									if(     pVisualType_LTO == ARC_MacroProfiles_VisualsType_HNLN.Half)     rect_HNLN = new SharpDX.RectangleF(rect.X, rect.Y, rect.Width/2f, rect.Height);
									else if(pVisualType_LTO == ARC_MacroProfiles_VisualsType_HNLN.Extended) rect_HNLN = new SharpDX.RectangleF(rect.X, rect.Y, RMBx-rect.X, rect.Height);
									RenderTarget.FillRectangle(rect_HNLN, this.LTO_BrushDX);
								}
							}
							#endregion
#endif
							if(TPO_plot_IsDot){
								#region draw dots
								if(pricePtr > Prof[profileId].tpoVAH_Price){
									RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(v1, pTPOLineThickness, pTPOLineThickness),this.tpoAboveVA_BrushDX);
									if(RecalcScreenCoord || init_tpoedge) 
										Prof[profileId].ScreenXY_TpoEdge[pricePtr] = v1.X;//+15f;
									if(profileId == MM.HoverProfileId && pricePtr == rounded_price) x_of_tpo_touch_price = v1.X;
								}
								else if(pricePtr < Prof[profileId].tpoVAL_Price){
									RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(v1, pTPOLineThickness, pTPOLineThickness),this.tpoBelowVA_BrushDX);
									if(RecalcScreenCoord || init_tpoedge) 
										Prof[profileId].ScreenXY_TpoEdge[pricePtr] = v1.X;
									if(profileId == MM.HoverProfileId && pricePtr == rounded_price) x_of_tpo_touch_price = v1.X;
								}
								else{
									RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(v1, pTPOLineThickness, pTPOLineThickness), this.tpoVA_BrushDX);
									if(RecalcScreenCoord || init_tpoedge) 
										Prof[profileId].ScreenXY_TpoEdge[pricePtr] = v1.X;
									max_histo_width = Math.Max(max_histo_width, v1.X);
									if(profileId == MM.HoverProfileId && pricePtr == rounded_price) x_of_tpo_touch_price = v1.X;
								}
								#endregion
							}else{
								if(pricePtr > Prof[profileId].tpoVAL_Price && pricePtr < Prof[profileId].tpoVAH_Price){
									RenderTarget.DrawLine(v0, v1, this.tpoVA_BrushDX, pTPOLineThickness);
									if(RecalcScreenCoord || init_tpoedge) 
										Prof[profileId].ScreenXY_TpoEdge[pricePtr] = v1.X;
									if(profileId == MM.HoverProfileId && pricePtr == rounded_price) x_of_tpo_touch_price = v1.X;
								}else if(pricePtr >= Prof[profileId].tpoVAH_Price){
									RenderTarget.DrawLine(v0, v1, this.tpoAboveVA_BrushDX, pTPOLineThickness);
									if(RecalcScreenCoord || init_tpoedge) 
										Prof[profileId].ScreenXY_TpoEdge[pricePtr] = v1.X;
									if(profileId == MM.HoverProfileId && pricePtr == rounded_price) x_of_tpo_touch_price = v1.X;
								}else if(pricePtr <= Prof[profileId].tpoVAL_Price){
									RenderTarget.DrawLine(v0, v1, this.tpoBelowVA_BrushDX, pTPOLineThickness);
									if(RecalcScreenCoord || init_tpoedge) 
										Prof[profileId].ScreenXY_TpoEdge[pricePtr] = v1.X;
									if(profileId == MM.HoverProfileId && pricePtr == rounded_price) x_of_tpo_touch_price = v1.X;
								}
							}
							if(pShowSinglePrintLines && Prof[profileId].TPOatP[pricePtr].Count==1){
								RenderTarget.FillRectangle(
												new SharpDX.RectangleF(v1.X-pSinglePrintLineThickness-2, v1.Y-PixelsPerTick/2, pSinglePrintLineThickness, PixelsPerTick), 
												this.tpoSinglePrintLine_BrushDX
								);
							}
//PrintNew1("MM.HoverId: "+MM.HoverProfileId);
//if(profileId==MM.HoverProfileId && pricePtr==rounded_mouse_price){
//	if(Prof[profileId].ScreenXY_TpoEdge.ContainsKey(pricePtr)) Draw.TextFixed(this,"mousexy",string.Format("Mouse xy:  {0}  {1}  tpoEdge: {2}",MM.X,rounded_mouse_price,Prof[profileId].ScreenXY_TpoEdge[pricePtr]),TextPosition.TopRight);
//	else Draw.TextFixed(this,"mousexy",string.Format("Mouse xy:  {0}  {1}",MM.X,rounded_mouse_price),TextPosition.TopRight);
						}
//}
						v0.X = v1.X;//x + Convert.ToSingle(x + prior_TPO_count * (pAutoScaleHistoWidth ? TPO_pixels_per_occurrence : VPsPerTPO * SelectedVolMultiplier));
						v0.Y = v1.Y;
						prior_pricePtr = pricePtr;
					}
//if(BarsInProgress==0) PrintNew1("2540  "+Times[0].GetValueAt(profileId).ToString()+"  "+Prof[profileId].ScreenXY_TpoEdge.Count);
					#endregion
					if(pShow_TPOTouchCounter && Keyboard.IsKeyDown(Key.LeftShift) && MM.HoverProfileId>=0 && profileId==MM.HoverProfileId){
						#region TPO TouchCounter
						int tpo_touch_count = -1;
						if(Prof.ContainsKey(MM.HoverProfileId) && Prof[MM.HoverProfileId].TPOatP.ContainsKey(rounded_price)){
							tpo_touch_count = Prof[MM.HoverProfileId].TPOatP[rounded_price].Count;
//string strr = string.Empty;
//foreach(var cc in Prof[MM.HoverProfileId].TPOatP[rounded_price]) strr = string.Format("{0} {1}",strr, cc); Print(rounded_price+":  "+strr);

							string tpo_countertxt = string.Format("{0}: {1}{2}", RoundToTick(rounded_price), pTPOCounterLabel,tpo_touch_count);
							var tpocounter_TextFormat = this.TPOTouchCounter_Font.ToDirectWriteTextFormat();
							var tpocounter_Layout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, tpo_countertxt, tpocounter_TextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
							x = chartControl.GetXByBarIndex(ChartBars, MM.HoverProfileId);
							v1.Y = chartScale.GetYByValue(rounded_price);
							RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(
									new SharpDX.Vector2(x_of_tpo_touch_price,v1.Y+halfPriceBoxSizePx),
									pTPOLineThickness+2f,pTPOLineThickness+2f), this.yellowBrushDX);
							if(rounded_price < (ChartBars.MinValue+ChartBars.MaxValue)/2) v1.Y = v1.Y - tpocounter_Layout.Metrics.Height;
							v1.X = Math.Max(x - tpocounter_Layout.Metrics.Width/2f, 5f);

							var labelRect = new SharpDX.RectangleF(v1.X, v1.Y, tpocounter_Layout.Metrics.Width, tpocounter_Layout.Metrics.Height);
							RenderTarget.FillRectangle(labelRect, this.TPOCounterFont_BkgBrushDX);
							RenderTarget.DrawText(tpo_countertxt, tpocounter_TextFormat, labelRect, TPOCounterFont_BrushDX);

							tpocounter_TextFormat.Dispose(); tpocounter_TextFormat=null;
							tpocounter_Layout.Dispose(); tpocounter_Layout=null;
							
	//PrintNew1(Prof[MM.HoverProfileId].ScreenXY_TpoEdge[rounded_price]);
						}
						//}catch{}						
						//PrintNew1("Mouseprice: "+MM.MousePrice);
						#endregion
					}
				}
				#region -- Print Merge Warning rectangle when a TPO VA overlaps prior TPO VA --
				if(Prior_profileId == int.MinValue)
					Prior_profileId = profileId;
				else if(Prof[profileId].SessionDate == Prof[Prior_profileId].SessionDate) {
//bool z = profileId==454;
					bool ov1 = Prof[profileId].tpoVAH_Price < Prof[Prior_profileId].tpoVAL_Price || Prof[profileId].tpoVAL_Price > Prof[Prior_profileId].tpoVAH_Price;
//if(z){
//	PrintNew1("ov1 and ov2: "+ ov1.ToString()+"  "+ov2.ToString());
//	PrintNew1("VAH:  "+Prof[profileId].tpoVAH_Price+" to prior "+Prof[Prior_profileId].tpoVAH_Price);
//	PrintNew1("VAL:  "+Prof[profileId].tpoVAL_Price+" to prior "+Prof[Prior_profileId].tpoVAL_Price);
//}
					if(ov1 == false){//means that there is overlap
//							var rect_height = chartScale.GetYByValue(Prof[profileId].Lowest_Price) - chartScale.GetYByValue(Prof[profileId].Highest_Price);
//							rect_height = rect_height * 2;
//							var warnrect = new SharpDX.RectangleF(x, Convert.ToSingle(chartScale.GetYByValue(Prof[profileId].Highest_Price) - rect_height/4), max_histo_width-x, Convert.ToSingle(rect_height));
						var rect_height = VerticalBar_yBottommost - VerticalBar_yTopmost;
						rect_height = rect_height * 2f;
						var warnrect = new SharpDX.RectangleF(VerticalBar_x0, VerticalBar_yTopmost - rect_height/4f, VerticalBar_x1-VerticalBar_x0, rect_height);
						RenderTarget.FillRectangle(warnrect, merge_warning_BrushDX);
					}
				}
				#endregion

				Prior_profileId = profileId;
				#region -- Print the dots on the open and close prices of the profile --
				float centerY = Convert.ToSingle(chartScale.GetYByValue(Prof[profileId].OpenPrice));
				if(pOpenMarkerSize>0) RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x-barwidth_f*pCloseMarkerOffset,centerY),pOpenMarkerSize,pOpenMarkerSize),OpenMarkerBrushDX);
				if(pCloseMarkerSize>0){
					centerY = chartScale.GetYByValue(Prof[profileId].ClosePrice);
					if(profileId < newestProfileId){
						if(Prof[profileId].OpenPrice < Prof[profileId].ClosePrice){
							RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(
								new SharpDX.Vector2(chartControl.GetXByBarIndex(ChartBars, Prof[profileId].EndABar)-barwidth_f*pCloseMarkerOffset, centerY),pCloseMarkerSize,pCloseMarkerSize),UpCloseMarkerBrushDX);
//								new SharpDX.Vector2(x + 5 + Convert.ToSingle(Prof[profileId].vpPOC_Volume * (pAutoScaleHistoWidth ? VP_pixels_per_vol : SelectedVolMultiplier)), centerY),pCloseMarkerSize,pCloseMarkerSize),UpCloseMarkerBrushDX);
						}else{
							RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(
								new SharpDX.Vector2(chartControl.GetXByBarIndex(ChartBars, Prof[profileId].EndABar)-barwidth_f*pCloseMarkerOffset, centerY),pCloseMarkerSize,pCloseMarkerSize),DownCloseMarkerBrushDX);
//								new SharpDX.Vector2(x + 5 + Convert.ToSingle(Prof[profileId].vpPOC_Volume * (pAutoScaleHistoWidth ? VP_pixels_per_vol : SelectedVolMultiplier)), centerY),pCloseMarkerSize,pCloseMarkerSize),DownCloseMarkerBrushDX);
						}
					}
				}
				#endregion
			}
line=7780;
			if(pShowVP_Histo && HVNLVN_AreVisible && (pVisualType_HVN == ARC_MacroProfiles_VisualsType_HNLN.Extended || pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Extended)){
				#region -- HVN's/LVN's that originate from profiles that are to the left of the first visible bar --
				int min_key = pShow_HistoricalProfileVN ? 0 : Prof.Keys.Max()-1;
				int max_key = pShow_CurrentProfileVN    ? Prof.Keys.Max()+1  : Prof.Keys.Max()-1;
				var profileIds = Prof.Where(k => k.Value.LVN.Count>0 && k.Key <= max_key && k.Key >= min_key).Select(k=>k.Key).ToList();

				if(profileIds!=null){
					foreach(var profileId in profileIds){
						x = chartControl.GetXByTime(Prof[profileId].StartTime) + bar2barDistance;
						int yLowerPx = chartScale.GetYByValue(Prof[profileId].Lowest_Price) - halfPriceBoxSizePx;
						int yUpperPx = yLowerPx - PriceBoxSizePx;
						foreach(double pricePtr in Prof[profileId].ConsolidatedVatP.Keys){
							if(pricePtr <= chartScale.MaxValue && pricePtr >+ chartScale.MinValue){
								var IsBrokenLevel = Prof[profileId].BrokenVolNodes.Contains(pricePtr);//if a level is broken, do NOT print it as extended
								if(!IsBrokenLevel){
									#region -- Draw the qualified levels --
									var xEnd = chartControl.GetXByBarIndex(ChartBars, CurrentBars[0]);
									if(pVisualType_HVN == ARC_MacroProfiles_VisualsType_HNLN.Extended &&
										Prof[profileId].HVN.Contains(pricePtr) && !Prof[profileId].LVN.Contains(pricePtr)){
											rect = new SharpDX.RectangleF(x, 
															Convert.ToSingle(yLowerPx), 
															Convert.ToSingle(xEnd-x), 
															Convert.ToSingle(PriceBoxSizePx));
											RenderTarget.FillRectangle(rect, this.HVN_BrushDX);
									}
									if(pVisualType_LVN == ARC_MacroProfiles_VisualsType_HNLN.Extended &&
										Prof[profileId].LVN.Contains(pricePtr) && !Prof[profileId].HVN.Contains(pricePtr)){
											rect = new SharpDX.RectangleF(x, 
															Convert.ToSingle(yLowerPx), 
															Convert.ToSingle(xEnd-x), 
															Convert.ToSingle(PriceBoxSizePx));
											RenderTarget.FillRectangle(rect, this.LVN_BrushDX);
									}
									#endregion
								}
							}
							yLowerPx = chartScale.GetYByValue(pricePtr) - halfPriceBoxSizePx - PriceBoxSizePx;
							yUpperPx = yLowerPx - PriceBoxSizePx;
						}
					}
				}
				#endregion
			}
line=7824;
			#region SaveArbZoneData
			if(this.SaveArbZoneData){
				foreach(ArbitrageZoneData azd in ArbitrageZones){
					var sbl_List = SessionBreakLocs.Where(abr=> abr > azd.StartABar && abr <= azd.EndABar).ToList();
					sbl_List.Sort(); 
					if(sbl_List.Count>1 && sbl_List[0] > sbl_List[sbl_List.Count-1]) sbl_List.Reverse();
					foreach(var abr in sbl_List){
						var SessionStartLocalTime = Times[0].GetValueAt(abr);
						if(!CSVdata.ContainsKey(SessionStartLocalTime))
							CSVdata[SessionStartLocalTime] = new ArbZoneDataCSV(Opens[0].GetValueAt(abr+1));
	//Print("Adding "+azd.ZoneType+" at lo price of "+azd.LowPrice);
						CSVdata[SessionStartLocalTime].AddEdges(azd.LowPrice, azd.HighPrice, azd.EndABar, azd.ZoneType);
					}
				}
				ArbitrageZones.Clear();
				string mydoc = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
				string path1 = System.IO.Path.Combine(mydoc,ConfigMgr.StripOutIllegalCharacters(Instrument.MasterInstrument.Name+"_"+small_tag+"_LVLS.csv","_"));
				System.IO.File.WriteAllLines(path1, ArbZoneOutput.ToArray());
				string path2 = System.IO.Path.Combine(mydoc,ConfigMgr.StripOutIllegalCharacters("NearEdge_TPOLEVELS."+Instrument.MasterInstrument.Name+"."+small_tag+".csv","_"));
				#region Generate CSV records for Near edges of the ArbZones
				List<string> csvstring1 = new List<string>(){"INSTR,DATE,R9,R8,R7,R6,R5,R4,R3,R2,R1,OPEN,S1,S2,S3,S4,S5,S6,S7,S8,S9"};
				foreach(var csvd in CSVdata){
					string s1 = csvd.Value.OpenPrice.ToString();
					var R = csvd.Value.NearEdges.Where(epr=> epr > csvd.Value.OpenPrice).Distinct().ToList();
					var S = csvd.Value.NearEdges.Where(epr=> epr < csvd.Value.OpenPrice).Distinct().ToList();
					if(R.Count>1){
						R.Sort();
						if(R[0]>R[R.Count-1]) R.Reverse();//Lowest resistance price is first, it is nearest to the open of the profile
						while(R.Count>9) R.RemoveAt(R.Count-1);
					}
					if(S.Count>1){
						S.Sort();
						if(S[0]<S[S.Count-1]) S.Reverse();//Highest support price is first, it is nearest to the open of the profile
						while(S.Count>9) S.RemoveAt(S.Count-1);
					}
					for(int ri = 0; ri< 9; ri++){
						if(ri<R.Count) s1 = string.Format("{0},{1}",R[ri].ToString(), s1);
						else s1 = string.Format("{0},{1}"," ", s1);
						if(ri<S.Count) s1 = string.Format("{0},{1}",s1, S[ri].ToString());
					}
					csvstring1.Add(string.Format("{0},{1},{2}",Instrument.FullName,csvd.Key.ToString(),s1));
				}
				System.IO.File.WriteAllLines(path2, csvstring1.ToArray());
				#endregion

				string path3 = System.IO.Path.Combine(mydoc,ConfigMgr.StripOutIllegalCharacters("FarEdge_TPOLEVELS."+Instrument.MasterInstrument.Name+"."+small_tag+".csv","_"));
				#region Generate CSV records for Far edges of the ArbZones
				List<string> csvstring2 = new List<string>(){"INSTR,DATE,R9,R8,R7,R6,R5,R4,R3,R2,R1,OPEN,S1,S2,S3,S4,S5,S6,S7,S8,S9"};
				foreach(var csvd in CSVdata){
					string s1 = csvd.Value.OpenPrice.ToString();
//Print("**********************  Open Price  "+s1);
//foreach(var edge in csvd.Value.FarEdges) Print("far edge: "+edge);
					var R = csvd.Value.FarEdges.Where(epr=> epr > csvd.Value.OpenPrice).Distinct().ToList();
					var S = csvd.Value.FarEdges.Where(epr=> epr < csvd.Value.OpenPrice).Distinct().ToList();
					if(R.Count>1){
						R.Sort();
						if(R[0]>R[R.Count-1]) R.Reverse();//Lowest resistance price is first, it is nearest to the open of the profile
						while(R.Count>9) R.RemoveAt(R.Count-1);
					}
					if(S.Count>1){
						S.Sort();
						if(S[0]<S[S.Count-1]) S.Reverse();//Highest support price is first, it is nearest to the open of the profile
						while(S.Count>9) S.RemoveAt(S.Count-1);
					}
					for(int ri = 0; ri< 9; ri++){
						if(ri<R.Count) s1 = string.Format("{0},{1}",R[ri].ToString(), s1);
						else s1 = string.Format("{0},{1}"," ", s1);
						if(ri<S.Count) s1 = string.Format("{0},{1}",s1, S[ri].ToString());
					}
					csvstring2.Add(string.Format("{0},{1},{2}",Instrument.FullName,csvd.Key.ToString(),s1));
				}
				System.IO.File.WriteAllLines(path3, csvstring2.ToArray());
				#endregion

				Draw.TextFixed(this, "writtenarbs", (ArbZoneOutput.Count-5).ToString()+"-lines written to "+path1+"\n"+CSVdata.Count.ToString()+"-lines written to "+path2+"\n"+CSVdata.Count.ToString()+"-lines written to "+path3, TextPosition.Center, Brushes.Yellow, new SimpleFont("Arial",16),Brushes.Black,Brushes.Black,100,DashStyleHelper.Solid,1,false,"");
				CSVdata.Clear();
				SaveArbZoneData  = false;
				WrittenArbsMsgDT = DateTime.Now;
			}
line=7904;
			if(WrittenArbsMsgDT != DateTime.MinValue){
				var ts1 = new TimeSpan(DateTime.Now.Ticks - WrittenArbsMsgDT.Ticks);
				if(ts1.Seconds>15) {
					RemoveThisTag("writtenarbs");
					WrittenArbsMsgDT = DateTime.MinValue;
				}
			}
			#endregion

			zonePricesTextFormat.Dispose(); zonePricesTextFormat = null;
			zonePricesLayout.Dispose();     zonePricesLayout = null;
			if(pGlobalObjects_Enabled){
line=7917;
				#region -- Draw yellow ellipses on hovered rays and zones -----------------------------------------
				if(MM.SelectedProfileId >= 0){
					if(Prof.ContainsKey(MM.SelectedProfileId)
						&& MM.MousePrice <= Math.Max(Prof[MM.SelectedProfileId].tpoVAH_Price,Prof[MM.SelectedProfileId].vpVAH_Price) 
						&& MM.MousePrice >= Math.Min(Prof[MM.SelectedProfileId].tpoVAL_Price,Prof[MM.SelectedProfileId].vpVAL_Price)){
						var inside_va = MM.SelectedRayData[2] != int.MinValue;
						if(inside_va && MM.SelectedArbZoneType==' '){
							if(MM.SelectedRayData[2] == POC_ID){//if user selected a POC price, then MM.SelectedRayData[1] contains either TPO_ID or V_ID
								var vect = new SharpDX.Vector2(
														chartControl.GetXByTime(Prof[MM.SelectedProfileId].StartTime) + bar2barDistance,
														chartScale.GetYByValue(MM.SelectedRayData[0])	);
								RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(vect, 10f, 4f), pinkBrushDX);
							}else{//If it's not  POC price, then MM.SelectedRayData[2] contains either TPO_ID for TPO value area, or V_ID for volume value area
								var vect = new SharpDX.Vector2(
														chartControl.GetXByTime(Prof[MM.SelectedProfileId].StartTime) + bar2barDistance,
														chartScale.GetYByValue(MM.SelectedRayData[2]==TPO_ID ? Prof[MM.SelectedProfileId].tpoVAH_Price : Prof[MM.SelectedProfileId].vpVAH_Price)	);
								RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(vect, 10f, 4f), yellowBrushDX);
								vect.Y = chartScale.GetYByValue(
												MM.SelectedRayData[2]==TPO_ID ? Prof[MM.SelectedProfileId].tpoVAL_Price : Prof[MM.SelectedProfileId].vpVAL_Price);
								RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(vect, 10f, 4f), yellowBrushDX);
							}
						}
					}else if(MM.SelectedArbZoneData[0]>=0){
						float arbX    = ChartControl.GetXByBarIndex(ChartBars, Math.Max(ChartBars.FromIndex+2, (int)MM.SelectedArbZoneData[0]));
						float arbYtop = chartScale.GetYByValue(MM.SelectedArbZoneData[1]);
						float arbYbot = chartScale.GetYByValue(MM.SelectedArbZoneData[3]);
//PrintNew1("In a zone at "+MM.SelectedProfileId.ToString()+" top: "+MM.SelectedArbZoneData[1].ToString() + "  bot: "+MM.SelectedArbZoneData[3].ToString());
						float radius  = (arbYbot-arbYtop)/2f;
						RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(
							new SharpDX.Vector2(arbX, arbYtop+radius), 5f, radius), yellowBrushDX);
					}
				}
				#endregion ------------------
			}
line=7952;
			ShowZonesClickedJustNow = false;
			#region -- Render the plots - developing and static profile data --------------------
			float y0=0, y1=0;
			int profile_key=-1;
//PrintNew1("---- TPO times -----------------------------");
//			foreach(var k in this.TPO_Data.BarData.Keys.Where(dt => dt >= BarsArray[0].GetTime(ProfileDates.Keys.Max()))) PrintNew1(k.ToString());
//PrintNew1(" ---------------------------------");
			float plot_width = Math.Max(Plots[0].Width, pTPOLineThickness);
//			var StaticLineVectors = new SortedDictionary<int,List<SharpDX.Vector2>>();//key is the Plot number, value is the list of vector points for that plot
//			var DynamicLineVectors = new SortedDictionary<int,List<SharpDX.Vector2>>();//key is the Plot number, value is the list of vector points for that plot
//			var StaticLastPt = new SortedDictionary<int,SharpDX.Vector2>();
//			var DynamicLastPt = new SortedDictionary<int,SharpDX.Vector2>();

line=7966;
			for(int abar = Math.Max(1,ChartBars.FromIndex); abar<Math.Min(BarsArray[0].Count,ChartBars.ToIndex); abar++){
				if(abar<1 && ProfileDates.Count>0) continue;
//				profile_key = Prof.Keys.Where(pdate => pdate < BarsArray[0].GetTime(abar)).Max();
				if(Prof.Keys.Min() >= abar) continue;
				profile_key = Prof.Keys.Where(pd => pd < abar).Max();
				v0.X = chartControl.GetXByBarIndex(ChartBars, abar-1);
				v1.X = chartControl.GetXByBarIndex(ChartBars, abar);
				//-------------------------- VP vah --------------------------
				plot_width = Math.Max(Plots[0].Width, pTPOLineThickness);
				if(pVisualType_VPVAH == ARC_MacroProfiles_VisualsType.Static || pVisualType_VPVAH == ARC_MacroProfiles_VisualsType.Both){
					v0.Y = chartScale.GetYByValue(Prof[profile_key].vpVAH_Price);
					v1.Y = v0.Y;
//					if(v0.Y==v1.Y && !StaticLineVectors.ContainsKey(0)) StaticLineVectors[0] = new List<SharpDX.Vector2>();
					if(v0.Y==v1.Y) {
						RenderTarget.DrawLine(v0, v1, Plots[0].BrushDX, plot_width, Plots[0].StrokeStyle);
//						StaticLastPt[0] = new SharpDX.Vector2(v1.X, v1.Y);
					}
				}
				else if(pVisualType_VPVAH == ARC_MacroProfiles_VisualsType.Dynamic || pVisualType_VPVAH == ARC_MacroProfiles_VisualsType.Both){
					if(Prof[profile_key].VP_DevData.ContainsKey(abar)) {
						y0 = Prof[profile_key].VP_DevData[abar].VAH;
						if(Prof[profile_key].VP_DevData.ContainsKey(abar-1)) y1 = Prof[profile_key].VP_DevData[abar-1].VAH;
						else y1 = y0;
						v0.Y = chartScale.GetYByValue(y1);
						v1.Y = chartScale.GetYByValue(y0);
//						if(!DynamicLineVectors.ContainsKey(0)) DynamicLineVectors[0] = new List<SharpDX.Vector2>();
						RenderTarget.DrawLine(v0, v1, Plots[0].BrushDX, plot_width, Plots[0].StrokeStyle);
					}
				}
				//-------------------------- VP val --------------------------
				plot_width = Math.Max(Plots[1].Width, pTPOLineThickness);
				if(pVisualType_VPVAL == ARC_MacroProfiles_VisualsType.Static || pVisualType_VPVAL == ARC_MacroProfiles_VisualsType.Both){
					v0.Y = chartScale.GetYByValue(Prof[profile_key].vpVAL_Price);
					v1.Y = v0.Y;
//					if(v0.Y==v1.Y && !StaticLineVectors.ContainsKey(1)) StaticLineVectors[1] = new List<SharpDX.Vector2>();
					if(v0.Y==v1.Y) RenderTarget.DrawLine(v0, v1, Plots[1].BrushDX, plot_width, Plots[1].StrokeStyle);
				}
				else if(pVisualType_VPVAL == ARC_MacroProfiles_VisualsType.Dynamic || pVisualType_VPVAL == ARC_MacroProfiles_VisualsType.Both){
					if(Prof[profile_key].VP_DevData.ContainsKey(abar)) {
						y0 = Prof[profile_key].VP_DevData[abar].VAL;
						if(Prof[profile_key].VP_DevData.ContainsKey(abar-1)) y1 = Prof[profile_key].VP_DevData[abar-1].VAL;
						else y1 = y0;
						v0.Y = chartScale.GetYByValue(y1);
						v1.Y = chartScale.GetYByValue(y0);
//						if(!DynamicLineVectors.ContainsKey(1)) DynamicLineVectors[1] = new List<SharpDX.Vector2>();
						RenderTarget.DrawLine(v0, v1, Plots[1].BrushDX, plot_width, Plots[1].StrokeStyle);
					}
				}
				//-------------------------- VP poc --------------------------
				plot_width = Math.Max(Plots[2].Width, pTPOLineThickness);
				if(pVisualType_VPPOC == ARC_MacroProfiles_VisualsType.Static || pVisualType_VPPOC == ARC_MacroProfiles_VisualsType.Both){
					v0.Y = chartScale.GetYByValue(Prof[profile_key].ConsolidatedvpPOC_Price);
					v1.Y = v0.Y;
//					if(v0.Y==v1.Y && !StaticLineVectors.ContainsKey(2)) StaticLineVectors[2] = new List<SharpDX.Vector2>();
					if(v0.Y==v1.Y) RenderTarget.DrawLine(v0, v1, Plots[2].BrushDX, plot_width, Plots[2].StrokeStyle);
				}
				else if(pVisualType_VPPOC == ARC_MacroProfiles_VisualsType.Dynamic || pVisualType_VPPOC == ARC_MacroProfiles_VisualsType.Both){
					if(Prof[profile_key].VP_DevData.ContainsKey(abar)) {
						y0 = Prof[profile_key].VP_DevData[abar].POC;
						if(Prof[profile_key].VP_DevData.ContainsKey(abar-1)) y1 = Prof[profile_key].VP_DevData[abar-1].POC;
						else y1 = y0;
						v0.Y = chartScale.GetYByValue(y1);
						v1.Y = chartScale.GetYByValue(y0);
//						if(!DynamicLineVectors.ContainsKey(2)) DynamicLineVectors[2] = new List<SharpDX.Vector2>();
						RenderTarget.DrawLine(v0, v1, Plots[2].BrushDX, plot_width, Plots[2].StrokeStyle);
					}
				}
				//-------------------------- TPO vah --------------------------
				plot_width = Math.Max(Plots[3].Width, pTPOLineThickness);
				if(pVisualType_TPOVAH == ARC_MacroProfiles_VisualsType.Static || pVisualType_TPOVAH == ARC_MacroProfiles_VisualsType.Both){
					v0.Y = chartScale.GetYByValue(Prof[profile_key].tpoVAH_Price);
					v1.Y = v0.Y;
//					if(v0.Y==v1.Y && !StaticLineVectors.ContainsKey(3)) StaticLineVectors[3] = new List<SharpDX.Vector2>();
					if(v0.Y==v1.Y) RenderTarget.DrawLine(v0, v1, Plots[3].BrushDX, plot_width, Plots[3].StrokeStyle);
				}
				if(pVisualType_TPOVAH == ARC_MacroProfiles_VisualsType.Dynamic || pVisualType_TPOVAH == ARC_MacroProfiles_VisualsType.Both){
					if(Prof[profile_key].TPO_DevData.ContainsKey(abar)) {
						y0 = Prof[profile_key].TPO_DevData[abar].VAH;
						if(Prof[profile_key].TPO_DevData.ContainsKey(abar-1)) y1 = Prof[profile_key].TPO_DevData[abar-1].VAH;
						else y1 = y0;
						v0.Y = chartScale.GetYByValue(y1);
						v1.Y = chartScale.GetYByValue(y0);
//						if(!DynamicLineVectors.ContainsKey(3)) DynamicLineVectors[3] = new List<SharpDX.Vector2>();
						RenderTarget.DrawLine(v0, v1, Plots[3].BrushDX, plot_width, Plots[3].StrokeStyle);
					}
				}
				//-------------------------- TPO val --------------------------
				plot_width = Math.Max(Plots[4].Width, pTPOLineThickness);
				if(pVisualType_TPOVAL == ARC_MacroProfiles_VisualsType.Static || pVisualType_TPOVAL == ARC_MacroProfiles_VisualsType.Both){
					v0.Y = chartScale.GetYByValue(Prof[profile_key].tpoVAL_Price);
					v1.Y = v0.Y;
//					if(v0.Y==v1.Y && !StaticLineVectors.ContainsKey(4)) StaticLineVectors[4] = new List<SharpDX.Vector2>();
					if(v0.Y==v1.Y) RenderTarget.DrawLine(v0, v1, Plots[4].BrushDX, plot_width, Plots[4].StrokeStyle);
				}
				else if(pVisualType_TPOVAL == ARC_MacroProfiles_VisualsType.Dynamic || pVisualType_TPOVAL == ARC_MacroProfiles_VisualsType.Both){
					if(Prof[profile_key].TPO_DevData.ContainsKey(abar)) {
						y0 = Prof[profile_key].TPO_DevData[abar].VAL;
						if(Prof[profile_key].TPO_DevData.ContainsKey(abar-1)) y1 = Prof[profile_key].TPO_DevData[abar-1].VAL;
						else y1 = y0;
						v0.Y = chartScale.GetYByValue(y1);
						v1.Y = chartScale.GetYByValue(y0);
//						if(!DynamicLineVectors.ContainsKey(4)) DynamicLineVectors[4] = new List<SharpDX.Vector2>();
						RenderTarget.DrawLine(v0, v1, Plots[4].BrushDX, plot_width, Plots[4].StrokeStyle);
					}
				}
				//-------------------------- TPO poc --------------------------
				plot_width = Math.Max(Plots[5].Width, pTPOLineThickness);
				if(pVisualType_TPOPOC == ARC_MacroProfiles_VisualsType.Static || pVisualType_TPOPOC == ARC_MacroProfiles_VisualsType.Both){
					v0.Y = chartScale.GetYByValue(Prof[profile_key].tpoPOC_Price);
					v1.Y = v0.Y;
//					if(v0.Y==v1.Y && !StaticLineVectors.ContainsKey(5)) StaticLineVectors[5] = new List<SharpDX.Vector2>();
					if(v0.Y==v1.Y) RenderTarget.DrawLine(v0, v1, Plots[5].BrushDX, plot_width, Plots[5].StrokeStyle);
				}
				else if(pVisualType_TPOPOC == ARC_MacroProfiles_VisualsType.Dynamic || pVisualType_TPOPOC == ARC_MacroProfiles_VisualsType.Both){
					if(Prof[profile_key].TPO_DevData.ContainsKey(abar)) {
//if(profile_key.Day==22)PrintNew1(abar+" == "+BarsArray[0].GetTime(abar).ToString()+"  "+Prof[profile_key].TPO_DevData[abar].POC+"   prof: "+profile_key.ToString());
						y0 = Prof[profile_key].TPO_DevData[abar].POC;
						if(Prof[profile_key].TPO_DevData.ContainsKey(abar-1)) y1 = Prof[profile_key].TPO_DevData[abar-1].POC;
						else y1 = y0;
						v0.Y = chartScale.GetYByValue(y1);
						v1.Y = chartScale.GetYByValue(y0);
//						if(!DynamicLineVectors.ContainsKey(5)) DynamicLineVectors[5] = new List<SharpDX.Vector2>();
						RenderTarget.DrawLine(v0, v1, Plots[5].BrushDX, plot_width, Plots[5].StrokeStyle);
					}
				}
				//-------------------------- VWAP --------------------------
				plot_width = Math.Max(Plots[6].Width, pTPOLineThickness);
				if(pVisualType_VWAP == ARC_MacroProfiles_VisualsType.Dynamic || pVisualType_VWAP == ARC_MacroProfiles_VisualsType.Both){
					v0.Y = chartScale.GetYByValue(VWAP.GetValueAt(abar-1));
					v1.Y = chartScale.GetYByValue(VWAP.GetValueAt(abar));
//					if(!DynamicLineVectors.ContainsKey(6)) DynamicLineVectors[6] = new List<SharpDX.Vector2>();
					RenderTarget.DrawLine(v0, v1, Plots[6].BrushDX, plot_width, Plots[6].StrokeStyle);
				}
				if(pVisualType_VWAP == ARC_MacroProfiles_VisualsType.Static || pVisualType_VWAP == ARC_MacroProfiles_VisualsType.Both){
					int pid = Prof.Keys.Where(xb => xb < abar).Max();
					if(Prof.ContainsKey(pid)){
						v0.Y = chartScale.GetYByValue(Prof[pid].StaticVWAP_Price);
						v1.Y = v0.Y;
//						if(!StaticLineVectors.ContainsKey(6)) StaticLineVectors[6] = new List<SharpDX.Vector2>();
						RenderTarget.DrawLine(v0, v1, Plots[6].BrushDX, plot_width, Plots[6].StrokeStyle);
					}
				}
			}
			//base.OnRender(chartControl, chartScale);
			#endregion --------------------------

line=8113;
            //Net Imbalance in right bottom corner.ATR.
			#region -- Draw ATR box --
			var imbTextFormat = ATR_Delta_Box_Font.ToDirectWriteTextFormat();
			int key = ATRhistory.Keys.Max();
			if(ATRhistory.ContainsKey(RMB))
				key = RMB;
			else{
				while(key>ATRhistory.Keys.Min() && !ATRhistory.ContainsKey(key)) key--;
			}
			var atrval = ATRhistory[key];
			if(ShowATR_databox){
				if(ATRhistory.ContainsKey(key)){
		            string atrText = string.Format("ATR: {0}", (ATRMode == ARC_MacroProfiles_ATRModeEnum.Points ? 
										Math.Round(atrval, 3) : 
										Math.Round(atrval / TickSize, 0)));

		           	ATR_RR_Layout	= new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, atrText, imbTextFormat, (float)(ChartPanel.X + ChartPanel.W), 12f);
		            ATRBox_width	= ATR_RR_Layout.Metrics.Width  + 5f;
		   	        ATRBox_height	= ATR_RR_Layout.Metrics.Height + 10f;
		            var atrRect		= new SharpDX.RectangleF(ChartPanel.W - ATRBox_width  - 5f, ChartPanel.H - ATRBox_height - 20f,ATRBox_width, ATRBox_height);
		            RenderTarget.FillRectangle(atrRect, backBrushDX);
	    	        RenderTarget.DrawRectangle(atrRect, borderBrushDX,ATR_Delta_Box_Border.Width,ATR_Delta_Box_Border.StrokeStyle);

		            imbTextFormat.TextAlignment = SharpDX.DirectWrite.TextAlignment.Center;
	    	        imbTextFormat.ParagraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center;
	        	    RenderTarget.DrawText(atrText, imbTextFormat, atrRect, boxTextBrushDX);
				}
			}
			#endregion
//Print("7394  "+DateTime.Now.ToString());		return;
line=8148;
			#region -- Draw RR box --
			if(ShowRR_databox && Prof.Count>0){
//				atrRect		= new SharpDX.RectangleF(ChartPanel.W - ATRBox_width  - 5f, ChartPanel.H - ATRBox_height - 20f,ATRBox_width, ATRBox_height);
				double TicksCurrentTPO = 0;
				double rrval = 0;
				try{
					TicksCurrentTPO = (Math.Round((Prof[RM_ProfileId].tpoVAH_Price- Prof[RM_ProfileId].tpoVAL_Price)/TickSize,0));
					rrval = (ATRMode == ARC_MacroProfiles_ATRModeEnum.Points ? TicksCurrentTPO*TickSize/Math.Round(atrval, 3) : TicksCurrentTPO/Math.Round(atrval / TickSize, 0));
				}catch{}
				string msg = string.Format("TPO tk: {0}  RR: {1}", TicksCurrentTPO.ToString("0"),rrval.ToString("0.0"));
				ATR_RR_Layout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, imbTextFormat, (float)(ChartPanel.X + ChartPanel.W), 12f);
				ATRBox_width	  = ATR_RR_Layout.Metrics.Width + 5f;
				ATRBox_height	  = ATR_RR_Layout.Metrics.Height + 10f;
				var RR_Rect   = new SharpDX.RectangleF(ChartPanel.W - ATRBox_width  - 5f, ChartPanel.H - ATRBox_height*2 - 20f, ATRBox_width,ATRBox_height);
				RenderTarget.FillRectangle(RR_Rect, blackBrushDX);
				RenderTarget.DrawRectangle(RR_Rect, borderBrushDX, ATR_Delta_Box_Border.Width, ATR_Delta_Box_Border.StrokeStyle);
				RenderTarget.DrawText(msg, imbTextFormat, RR_Rect, whiteBrushDX);
			}
			ATR_RR_Layout.Dispose(); ATR_RR_Layout = null;
			#endregion

//Print("7429  "+DateTime.Now.ToString());		return;
line=8171;
			#region - Audible alerts on zones -
			if(ReadyToCheckAlerts){
				int alert_count=0;
				string alert_msg = string.Empty;
				foreach(var SupPrice in UntestedSupPrices){
					if(Lows[0].GetValueAt(CurrentBars[0]) <= SupPrice.Key){
						alert_msg = string.Format("{0}{1}", (SupPrice.Value=='Z' ? "Hit BuyZone @ " : "Nearing BuyZone @ "), Instrument.MasterInstrument.FormatPrice(SupPrice.Key));
						if(pPrintToAlertWindow)	Alert(DateTime.Now.Ticks.ToString(), Priority.High, alert_msg, AddSoundFolder(BuyZoneWAV), 0, Brushes.Green, Brushes.White);
						if(SupPrice.Value=='Z') {
							if(pLaunchPopupsOnZoneHit) Log(alert_msg, NinjaTrader.Cbi.LogLevel.Alert);
							if(pEmailOnZoneHit.Length>0) SendMail(pEmailOnZoneHit, Instrument.FullName+" MacroProfiles Sup zone hit",alert_msg);
						}
						if(SupPrice.Value=='F') {
							if(pLaunchPopupsOnFrontrun) Log(alert_msg, NinjaTrader.Cbi.LogLevel.Alert);
							if(pEmailOnFrontRun.Length>0) SendMail(pEmailOnFrontRun, Instrument.FullName+" MacroProfiles Sup zone approached",alert_msg);
						}
						alert_count++;
						break;
					}
				}
				foreach(var ResPrice in UntestedResPrices){
					if(Highs[0].GetValueAt(CurrentBars[0]) >= ResPrice.Key){
						alert_msg = string.Format("{0}{1}", (ResPrice.Value=='Z' ? "Hit SellZone @ " : "Nearing SellZone @ "), Instrument.MasterInstrument.FormatPrice(ResPrice.Key));
						if(pPrintToAlertWindow) Alert(DateTime.Now.Ticks.ToString(), Priority.High, alert_msg, AddSoundFolder(SellZoneWAV), 0, Brushes.Maroon, Brushes.White);
						
						if(ResPrice.Value=='Z') {
							if(pLaunchPopupsOnZoneHit) Log(alert_msg, NinjaTrader.Cbi.LogLevel.Alert);
							if(pEmailOnZoneHit.Length>0) SendMail(pEmailOnZoneHit, Instrument.FullName+" MacroProfiles Res zone hit",alert_msg);
						}
						if(ResPrice.Value=='F') {
							if(pLaunchPopupsOnFrontrun) Log(alert_msg, NinjaTrader.Cbi.LogLevel.Alert);
							if(pEmailOnFrontRun.Length>0) SendMail(pEmailOnFrontRun, Instrument.FullName+" MacroProfiles Res zone approached",alert_msg);
						}
						alert_count++;
						break;
					}
				}
				if(alert_count>0){
					UntestedResPrices.Clear();
					UntestedSupPrices.Clear();
				}
			}
			ReadyToCheckAlerts = true;
			#endregion

//Print("7476  "+DateTime.Now.ToString());		return;
line=8218;
			if(pShowCurrentPriceLine) {
				var cpl_BrushDX = this.pCurrentPriceLineBrush.ToDxBrush(RenderTarget);
				float priceY = chartScale.GetYByValue(Closes[1].GetValueAt(CurrentBars[1]));
				v1 = new SharpDX.Vector2(Convert.ToSingle(ChartPanel.W),priceY);
				if(pCurrentPriceLineLength==0)
					RenderTarget.DrawLine(v1, new SharpDX.Vector2(ChartControl.GetXByBarIndex(ChartBars, CurrentBars[0])+barwidth_f, priceY), cpl_BrushDX, pCurrentPriceLineWidth);
				else
					RenderTarget.DrawLine(v1, new SharpDX.Vector2(v1.X-pCurrentPriceLineLength,priceY), cpl_BrushDX, pCurrentPriceLineWidth);
				RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(v1,10f,10f), cpl_BrushDX);
				cpl_BrushDX.Dispose();
				cpl_BrushDX = null;
			}
			RemoveThisTag("DataLoadingMsg");
}catch(Exception err){PrintNew1(line.ToString()+":  Err: "+err.ToString());}
		}
//======================================================================================================
		private void ApplyGlobalRaySelections(ARC_MacroProfiles_GlobalRayScopes value_area_scope, ARC_MacroProfiles_GlobalRayScopes poc_scope, bool permitHighRays, bool permitLowRays, List<int> profiles){
			#region -- ApplyGlobalRaySelections -------------
line=8237;
			if(profiles == null) return;
			string tagH = string.Empty;
			string tagL = string.Empty;
			string tagPOC = string.Empty;
			var rays = new List<string>();
			if(poc_scope == ARC_MacroProfiles_GlobalRayScopes.Remove){
				#region -- Delete all POC rays -----------------
				rays = Global_POC_Rays.Where(r=> profiles.Contains(r.Value.LMAbar)).Select(r=> r.Key).ToList();
				if(rays!=null) foreach(var ray in rays){
					RemoveThisTag(string.Format("{0}",ray));
					Global_POC_Rays.Remove(ray);
				}
				#endregion --------
			} else {
				#region -- Create POC rays --
				if(poc_scope == ARC_MacroProfiles_GlobalRayScopes.TPO || poc_scope == ARC_MacroProfiles_GlobalRayScopes.TPOandVP){
					foreach(var cspId in profiles){
						tagPOC = string.Format("POC{0}_{1}_{2}", ObjTagPrefix, cspId, TPO_ID);
						var template_name = string.Empty;
						if(ProfileInCurrentSession(cspId))	template_name = pcTPO_POC_RayTemplate;
						else								template_name = phTPO_POC_RayTemplate;
						Global_POC_Rays[tagPOC] = new Global_RaysData(
										Times[0].GetValueAt(cspId+1), cspId, POC_ID, TPO_ID,
										Prof[cspId].tpoPOC_Price, 
										template_name);
						Global_POC_Rays[tagPOC].EndDT = UpdateRayEndDT(Global_POC_Rays[tagPOC]);
					}
					//If only TPO is selected, then delete any Volume POC rays
					if(poc_scope == ARC_MacroProfiles_GlobalRayScopes.TPO){
						var delete_suffix = string.Format("_{0}",V_ID);
						var tags = Global_POC_Rays.Where(tg=> profiles.Contains(tg.Value.LMAbar) && tg.Key.StartsWith("POC") && tg.Key.EndsWith(delete_suffix)).Select(tg=> tg.Key);
						if(tags!=null){
							foreach(var Tag in tags.ToList()){
								RemoveThisTag(string.Format("{0}",Tag));
								Global_POC_Rays.Remove(Tag);
							}
						}
					}
				}
				if(poc_scope == ARC_MacroProfiles_GlobalRayScopes.VP || poc_scope == ARC_MacroProfiles_GlobalRayScopes.TPOandVP){
					foreach(var cspId in profiles){
						tagPOC = string.Format("POC{0}_{1}_{2}", ObjTagPrefix, cspId, V_ID);
						var template_name = string.Empty;
						if(ProfileInCurrentSession(cspId))	template_name = pcVP_POC_RayTemplate;
						else								template_name = phVP_POC_RayTemplate;
						Global_POC_Rays[tagPOC] = new Global_RaysData(
										Times[0].GetValueAt(cspId+1), cspId, POC_ID, V_ID,
										Prof[cspId].ConsolidatedvpPOC_Price, 
										template_name);
						Global_POC_Rays[tagPOC].EndDT = UpdateRayEndDT(Global_POC_Rays[tagPOC]);
					}
					//If only V is selected, then delete any TPO POC rays
					if(poc_scope == ARC_MacroProfiles_GlobalRayScopes.VP){
						var delete_suffix = string.Format("_{0}",TPO_ID);
						var tags = Global_POC_Rays.Where(tg=> profiles.Contains(tg.Value.LMAbar) && tg.Key.StartsWith("POC") && tg.Key.EndsWith(delete_suffix)).Select(tg=> tg.Key);
						if(tags!=null){
							foreach(var Tag in tags.ToList()){
								RemoveThisTag(string.Format("{0}",Tag));
								Global_POC_Rays.Remove(Tag);
							}
						}
					}
				}
				#endregion  --------------
			}
line=8303;
			if(value_area_scope == ARC_MacroProfiles_GlobalRayScopes.Remove) {
				#region -- Delete Both H and L, or H, or L -----------------
				rays = Global_VAHL_Rays.Where(r=> profiles.Contains(r.Value.LMAbar)).Select(r=> r.Key).ToList();
				if(rays!=null) foreach(var ray in rays){
					RemoveThisTag(ray);
					Global_VAHL_Rays.Remove(ray);
				}
				#endregion --------
				MM.obj_count = CalculateCountOfGlobalObjects();
				return;
			}

line=8316;
			if(value_area_scope == ARC_MacroProfiles_GlobalRayScopes.TPOandVP){
				foreach(var cspId in profiles){
					#region -- Create TPO rays --
					if(permitHighRays){
						tagH = string.Format("H{0}_{1}_{2}", ObjTagPrefix, cspId, TPO_ID);
						Global_VAHL_Rays[tagH] = new Global_RaysData(
									Times[0].GetValueAt(cspId+1), cspId, TPO_ID, RES_ID,
									Prof[cspId].tpoVAH_Price, 
									ProfileInCurrentSession(cspId) ? pcTPO_VAH_RayTemplate : phTPO_VAH_RayTemplate);
						Global_VAHL_Rays[tagH].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tagH]);
					}
					if(permitLowRays){
						tagL = string.Format("L{0}_{1}_{2}", ObjTagPrefix, cspId, TPO_ID);
						Global_VAHL_Rays[tagL] = new Global_RaysData(
									Times[0].GetValueAt(cspId+1), cspId, TPO_ID, SUP_ID,
									Prof[cspId].tpoVAL_Price, 
									ProfileInCurrentSession(cspId) ? pcTPO_VAL_RayTemplate : phTPO_VAL_RayTemplate);
						Global_VAHL_Rays[tagL].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tagL]);
					}
					#endregion --------------
					#region -- Create VP rays --
					if(permitHighRays){
						tagH = string.Format("H{0}_{1}_{2}", ObjTagPrefix, cspId, V_ID);
						Global_VAHL_Rays[tagH] = new Global_RaysData(
									Times[0].GetValueAt(cspId+1), cspId, V_ID, RES_ID,
									Prof[cspId].vpVAH_Price, 
									ProfileInCurrentSession(cspId) ? pcVP_VAH_RayTemplate : phVP_VAH_RayTemplate);
						Global_VAHL_Rays[tagH].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tagH]);
					}
					if(permitLowRays){
						tagL = string.Format("L{0}_{1}_{2}", ObjTagPrefix, cspId, V_ID);
						Global_VAHL_Rays[tagL] = new Global_RaysData(
									Times[0].GetValueAt(cspId+1), cspId, V_ID, SUP_ID,
									Prof[cspId].vpVAL_Price, 
									ProfileInCurrentSession(cspId) ? pcVP_VAL_RayTemplate : phVP_VAL_RayTemplate);
						Global_VAHL_Rays[tagL].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tagL]);
					}
					#endregion  --------------
				}
				MM.obj_count = CalculateCountOfGlobalObjects();
				return;
			}
line=8359;
			if(value_area_scope == ARC_MacroProfiles_GlobalRayScopes.TPO){
				foreach(var cspId in profiles){
					#region -- Create TPO rays --
					if(permitHighRays){
						tagH = string.Format("H{0}_{1}_{2}", ObjTagPrefix, cspId, TPO_ID);
						Global_VAHL_Rays[tagH] = new Global_RaysData(
									Times[0].GetValueAt(cspId+1), cspId, TPO_ID, RES_ID,
									Prof[cspId].tpoVAH_Price, 
									ProfileInCurrentSession(cspId) ? pcTPO_VAH_RayTemplate : phTPO_VAH_RayTemplate);
						Global_VAHL_Rays[tagH].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tagH]);
					}
					if(permitLowRays){
						tagL = string.Format("L{0}_{1}_{2}", ObjTagPrefix, cspId, TPO_ID);
						Global_VAHL_Rays[tagL] = new Global_RaysData(
									Times[0].GetValueAt(cspId+1), cspId, TPO_ID, SUP_ID,
									Prof[cspId].tpoVAL_Price, 
									ProfileInCurrentSession(cspId) ? pcTPO_VAL_RayTemplate : phTPO_VAL_RayTemplate);
						Global_VAHL_Rays[tagL].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tagL]);
					}
					#endregion --------------
					#region -- Delete all VP rays on the supplied profile ids ----------
					rays = Global_VAHL_Rays.Where(r=> profiles.Contains(r.Value.LMAbar) && r.Value.TPOorVPorPOC==V_ID).Select(r=> r.Key).ToList();
					if(rays!=null) foreach(var ray in rays){
						RemoveThisTag(string.Format("{0}",ray));
						Global_VAHL_Rays.Remove(ray);
					}
					#endregion ------------
				}
				MM.obj_count = CalculateCountOfGlobalObjects();
				return;
			}
line=8391;
			if(value_area_scope == ARC_MacroProfiles_GlobalRayScopes.VP){
				foreach(var cspId in profiles){
					#region -- Create VP rays --
					if(permitHighRays){
						tagH = string.Format("H{0}_{1}_{2}", ObjTagPrefix, cspId, V_ID);
						Global_VAHL_Rays[tagH] = new Global_RaysData(
									Times[0].GetValueAt(cspId+1), cspId, V_ID, RES_ID,
									Prof[cspId].vpVAH_Price, 
									ProfileInCurrentSession(cspId) ? pcVP_VAH_RayTemplate : phVP_VAH_RayTemplate);
						Global_VAHL_Rays[tagH].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tagH]);
					}
					if(permitLowRays){
						tagL = string.Format("L{0}_{1}_{2}", ObjTagPrefix, cspId, V_ID);
						Global_VAHL_Rays[tagL] = new Global_RaysData(
									Times[0].GetValueAt(cspId+1), cspId, V_ID, SUP_ID,
									Prof[cspId].vpVAL_Price, 
									ProfileInCurrentSession(cspId) ? pcVP_VAL_RayTemplate : phVP_VAL_RayTemplate);
						Global_VAHL_Rays[tagL].EndDT = UpdateRayEndDT(Global_VAHL_Rays[tagL]);
					}
					#endregion  --------------
					#region -- Delete all TPO rays on the supplied profile ids ----------
					rays = Global_VAHL_Rays.Where(r=> profiles.Contains(r.Value.LMAbar) && r.Value.TPOorVPorPOC==TPO_ID).Select(r=> r.Key).ToList();
					if(rays!=null) foreach(var ray in rays){
						RemoveThisTag(string.Format("{0}",ray));
						Global_VAHL_Rays.Remove(ray);
					}
					#endregion ------------
				}
line=8420;
				MM.obj_count = CalculateCountOfGlobalObjects();
				return;
			}
			#endregion ---------------
		}
//======================================================================================================
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
//======================================================================================================
		private void DetermineOverlappedZones(int FirstABar){
			#region Determine Overlapping zones
			//var pkeys = Prof.Where(k=> k.Key>=FirstABar && k.Value.SessionDate != currentSessionDate).Select(k=> k.Key).ToList();//don't evaluate profiles in the most recent (developing) session
			var pkeys = Prof.Where(k=> k.Key>=FirstABar).Select(k=> k.Key).ToList();
			if(pkeys == null || pkeys.Count<=1) return;//need at least 2 profiles to make this calculation
			if(pkeys[0] < pkeys.Last()) pkeys.Reverse();//most recent profile first element
//bool iz=false;
			DateTime date_next_session = DateTime.MaxValue;
			foreach(var key in pkeys){
				var next_session_pkeys = Prof.Where(p=> p.Value.SessionDate > Prof[key].SessionDate).Select(p=> p.Key).ToList();
				if(next_session_pkeys != null && next_session_pkeys.Count>0) date_next_session = Prof[next_session_pkeys.Min()].SessionDate;

				foreach(var zid in Prof[key].Zones){
					if(zid.Value.HighPrice == double.MinValue) continue;
					zid.Value.Overlapped = false;
					var future_pkeys = Prof.Where(pk=> pk.Key > key).Select(pk=> pk.Key).ToList();
					if(future_pkeys!=null && future_pkeys.Count>0){
						foreach(var overlapping_pro in future_pkeys){
							double highestprice = Math.Max(Prof[overlapping_pro].tpoVAH_Price, Prof[overlapping_pro].vpVAH_Price);
							double lowestprice  = Math.Min(Prof[overlapping_pro].tpoVAL_Price, Prof[overlapping_pro].vpVAL_Price);
							if(zid.Value.HighPrice >= highestprice && zid.Value.LowPrice <= lowestprice) {
								zid.Value.Overlapped     = true;
								zid.Value.OverlappedABar = overlapping_pro;
							}
							if(zid.Value.HighPrice <= highestprice && zid.Value.HighPrice >= lowestprice) {
								zid.Value.Overlapped     = true;
								zid.Value.OverlappedABar = overlapping_pro;
							}
							if(zid.Value.LowPrice <= highestprice && zid.Value.LowPrice >= lowestprice) {
								zid.Value.Overlapped     = true;
								zid.Value.OverlappedABar = overlapping_pro;
							}
							if(zid.Value.Broken && zid.Value.BrokenABar < zid.Value.OverlappedABar) continue;//if the break occurs before the overlapping profile, then it's broken
							if(!zid.Value.Disqualified && zid.Value.Overlapped) {//if the overlap occurred on the very next session, then keep the zone as Tested or Broken (those are the only 2 possible states)
								if(Prof[overlapping_pro].SessionDate > date_next_session)      zid.Value.Disposition = 'O';//if the overlap occurred on any other future session, then it's an overlap
								else if(Prof[overlapping_pro].SessionDate < date_next_session) zid.Value.Disposition = 'O';//if the overlap occurred on with another profile in the same session, then it's an overlap
								else if(Prof[overlapping_pro].SessionDate == date_next_session){//the overlap profile is on the session immediately after the arb zone origination
									var pk2 = Prof.Where(pkk=> pkk.Key > overlapping_pro).Select(pkk=> pkk.Key);
									if(pk2!=null){
										var pk2list = pk2.ToList();
										if(pk2list.Count>0){
											int pk2_min = pk2list.Min();//id of first profile id beyond the id of the overlapping pro
											if(zid.Value.Broken && zid.Value.BrokenABar >= pk2_min){
												zid.Value.Disposition = 'O';//if the zone isn't broken on the same profile as the overlapping profile, merely tested, the zone must stop printing at the EndABar of that overlapping profile (not at the first bar of that overlapping profile)
												zid.Value.OverlappedABar = pk2_min;
												zid.Value.EndABar = pk2_min;
											}
										}
									}
								}
								break;
							}
						}
					}
				}
			}
			#endregion
		}
//======================================================================================================
		private Global_RaysData CloneRay(Global_RaysData ray){
			var r= new Global_RaysData(ray.DT, ray.LMAbar, ray.Type, ray.TPOorVPorPOC, ray.Price, ray.TemplateName);
			r.IsDrawn = false;
			r.EndDT = DateTime.MaxValue;
			return r;
		}
//======================================================================================================
		#region -- Clean Up Orphaned Rays and Rectangles --------------------------------------
		private void CleanUpOrphanedRaysAndRectangles(){//if a ray or rectangle's LMAbar is not found in the Prof.Keys list, delete that ray/rect
line=8499;
//ClearOutputWindow();  Print("CleanUpOrphanedRaysAndRectangles");
			var TagsToRemove = new List<string>();
			#region -- Update global rects if their profile no longer exists --------------------------------------
			var rect2del = Global_Arb_Rects.Where(rk=> !Prof.Keys.Contains(rk.Value.StartABar)).ToList();
			if(rect2del!=null) foreach(var rect in rect2del) {
				TagsToRemove.Add(rect.Key);
				RemoveThisTag(rect.Key);
			}
			foreach(var tag in TagsToRemove) Global_Arb_Rects.Remove(tag);
			#endregion ---------------------------------------
			TagsToRemove.Clear();
			#region -- Update global POC rays if their profile no longer exists ---------------------------
line=8512;
			var ray2del = Global_POC_Rays.Where(rk=> !Prof.Keys.Contains(rk.Value.LMAbar)).ToList();
			if(ray2del!=null) foreach(var ray in ray2del) {
//				if(ray.Value.LMAbar >= minProfileId) {//remember any current session ray that is marked for deletion (due to merging of a profile into another, these are orphaned rays but should be automatically redrawn if that profile id ever comes around again
//					if(ray.Key.StartsWith("H"))      CurrentSessionRays_H[ray.Value.LMAbar] = CloneRay(ray.Value);
//					else if(ray.Key.StartsWith("L")) CurrentSessionRays_L[ray.Value.LMAbar] = CloneRay(ray.Value);
//				}
if(IsDebug) Print(line+": Removing POC ray: "+ray.Key);
				TagsToRemove.Add(ray.Key);
				RemoveThisTag(ray.Key);
			}
			foreach(var tag in TagsToRemove) Global_POC_Rays.Remove(tag);
			#endregion ---------------------
			TagsToRemove.Clear();
			#region -- Update global VA rays if their profile no longer exists ---------------------------
line=8527;
			ray2del = Global_VAHL_Rays.Where(rk=> !Prof.Keys.Contains(rk.Value.LMAbar)).ToList();
			if(ray2del!=null) foreach(var ray in ray2del) {
//				if(ray.Value.LMAbar >= minProfileId) {//remember any current session ray that is marked for deletion (due to merging of a profile into another, these are orphaned rays but should be automatically redrawn if that profile id ever comes around again
//					if(ray.Key.StartsWith("H"))      CurrentSessionRays_H[ray.Value.LMAbar] = CloneRay(ray.Value);
//					else if(ray.Key.StartsWith("L")) CurrentSessionRays_L[ray.Value.LMAbar] = CloneRay(ray.Value);
//				}
if(IsDebug) Print(line+": Removing ray: "+ray.Key);
				TagsToRemove.Add(ray.Key);
				RemoveThisTag(ray.Key);
			}
			foreach(var tag in TagsToRemove) Global_VAHL_Rays.Remove(tag);
			#endregion ---------------------
			MM.obj_count = CalculateCountOfGlobalObjects();
		}
//==========================================================================================
		private void CleanUpOrphanedRaysAndRectangles(DateTime sessDate){

//ClearOutputWindow();  Print("CleanUpOrphanedRaysAndRectangles");
			#region -- Update global rects if their profile no longer exists --------------------------------------
			var profids = Prof.Where(pd=> pd.Value.SessionDate == sessDate.Date).Select(pd=> pd.Key).ToList();
			if(profids==null || profids.Count==0) return;

			var TagsToRemove = new List<string>();
			var rect2del = Global_Arb_Rects.Where(rk=> rk.Value.StartABar >= profids.Min() && rk.Value.StartABar <= profids.Max() && !profids.Contains(rk.Value.StartABar)).ToList();
			if(rect2del!=null) foreach(var rect in rect2del) {
if(IsDebug) Print(line+": Removing ArbZone: "+rect.Key);
				TagsToRemove.Add(rect.Key);
				RemoveThisTag(rect.Key);
			}
			foreach(var tag in TagsToRemove) Global_Arb_Rects.Remove(tag);
			#endregion ---------------------------------------
			TagsToRemove.Clear();
			#region -- Update global POC rays if their profile no longer exists ---------------------------
line=8561;
			var ray2del = Global_POC_Rays.Where(rk=> rk.Value.LMAbar>= profids.Min() && rk.Value.LMAbar <= profids.Max() && !profids.Contains(rk.Value.LMAbar)).ToList();
			if(ray2del!=null) foreach(var ray in ray2del) {
if(IsDebug) Print(line+":  Removing POC ray: "+ray.Key+"  LMAbar: "+ray.Value.LMAbar);
				TagsToRemove.Add(ray.Key);
				RemoveThisTag(ray.Key);
			}
			foreach(var tag in TagsToRemove) Global_POC_Rays.Remove(tag);
			#endregion ---------------------
			TagsToRemove.Clear();
			#region -- Update global VA rays if their profile no longer exists ---------------------------
			ray2del = Global_VAHL_Rays.Where(rk=> rk.Value.LMAbar>= profids.Min() && rk.Value.LMAbar <= profids.Max() && !profids.Contains(rk.Value.LMAbar)).ToList();
			if(ray2del!=null) foreach(var ray in ray2del) {
//if(IsDebug) Print(line+":  Removing VAHL ray: "+ray.Key+"  LMAbar: "+ray.Value.LMAbar);
				TagsToRemove.Add(ray.Key);
				RemoveThisTag(ray.Key);
			}
			foreach(var tag in TagsToRemove) Global_VAHL_Rays.Remove(tag);
			#endregion ---------------------
			MM.obj_count = CalculateCountOfGlobalObjects();
		}
//==========================================================================================
		#endregion

		#region -- Properties -------------------------------------------------------------------------
		#region -- Parameters -------------------------------------------------------------------------
		private ARC_MacroProfiles_Sensitivity pSensitivity = ARC_MacroProfiles_Sensitivity.Minute1;
		[Description("Sensitivity of background data - Tick is single tick, Second is 5-second bar, Minute1 is 1-minute bar, Minute2 is 2-minute bar, Minute3 is a 3-minute bar, etc")]
		[Display(Order=10, Name = "Sensitivity",  GroupName = "Parameters", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_Sensitivity Sensitivity{	get { return pSensitivity; }
															set { pSensitivity = value;}}

		[Description("Enable selection of Value Area Highs and Lows for gobalization")]
		[Display(Order=20, Name = "Globals Enabled",  GroupName = "Parameters", ResourceType = typeof(Custom.Resource))]
		public bool pGlobalObjects_Enabled {get;set;}

		private ARC_MacroProfiles_TimeBasis pTimeBasis=ARC_MacroProfiles_TimeBasis.Daily;
		[Display(Order=30, Name = "Time Basis",  GroupName = "Parameters", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_TimeBasis TimeBasis		{	get { return pTimeBasis; }
															set { pTimeBasis = value;}}

		private bool pPermitProfileSplits = false;
		[Display(Order=40, Name = "Split Immediately",  GroupName = "Parameters", Description="All profiles are split immediately during a refresh or chart load", ResourceType = typeof(Custom.Resource))]
		public bool PermitProfileSplits		{			get { return pPermitProfileSplits; }
															set { pPermitProfileSplits = value;}}

		private bool pEnableParameterCaching = false;
		[Display(Order=50, Name = "Cache parameter defaults?",  GroupName = "Parameters", Description="Enable parameter caching, remember the current state of several of the show/hide parameters", ResourceType = typeof(Custom.Resource))]
		public bool EnableParameterCaching		{			get { return pEnableParameterCaching; }
															set { pEnableParameterCaching = value;}}
		#endregion

		#region -- Classes for Load pulldown parameters --
		internal class LoadRayTemplates : StringConverter
		{
			#region LoadRayTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Ray"};
				HLtemplates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(HLtemplates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
		internal class LoadZoneTemplates : StringConverter
		{
			#region LoadZoneTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Rectangle"};
				HLtemplates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(HLtemplates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("none");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }
		#endregion
		
		#region -- Alerts buy/sell zone --
		[Display(Order = 10, Name = "BuyZone Alert WAV", GroupName = "Alerts", ResourceType = typeof(Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string BuyZoneWAV { get; set; }

		[Display(Order = 20, Name = "SellZone Alert WAV", GroupName = "Alerts", ResourceType = typeof(Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string SellZoneWAV { get; set; }

		[Display(Order = 30, Description = "Play alert when price hits the actual zone?", Name = "Play On ZoneHit", GroupName = "Alerts", ResourceType = typeof(Resource))]
		public bool pPlayOnZoneHit { get; set; }

		[Display(Order = 40, Description = "Play alert when price touches the Front-run price?", Name = "Play On FrontRun", GroupName = "Alerts", ResourceType = typeof(Resource))]
		public bool pPlayOnFrontRunHit { get; set; }

		[Range(0,int.MaxValue)]
		[Display(Order = 50, Description = "Number of ticks, in advance of a zone, to provide audible alert", Name = "Front-run ticks", GroupName = "Alerts", ResourceType = typeof(Resource))]
		public int pFrontrunTicks { get; set; }

		private bool pPrintToAlertWindow=false;
		[Display(Order = 60, Description = "Print alerts to Alert Window", Name = "Print To AlertWindow", GroupName = "Alerts", ResourceType = typeof(Resource))]
		public bool PrintToAlertWindow { get{return pPrintToAlertWindow;} set{pPrintToAlertWindow = value;} }

		private bool pLaunchPopupsOnFrontrun = false;
		[Display(Order = 70, Description = "Launch popup alert Front-run alerts?", Name = "Popup On FrontRun", GroupName = "Alerts", ResourceType = typeof(Resource))]
		public bool LauchPopupOnFrontrun { get{return pLaunchPopupsOnFrontrun;} set{pLaunchPopupsOnFrontrun = value;} }

		private bool pLaunchPopupsOnZoneHit = true;
		[Display(Order = 80, Description = "Launch popup alert Zone Hit alerts?", Name = "Popup On ZoneHit", GroupName = "Alerts", ResourceType = typeof(Resource))]
		public bool LauchPopupOnZoneHit { get{return pLaunchPopupsOnZoneHit;} set{pLaunchPopupsOnZoneHit = value;} }

		private string pEmailOnFrontRun = "";
		[Display(Order = 90, Description = "Email on front-run alert...leave blank to turn-off the email alert", Name = "Email On FrontRun", GroupName = "Alerts", ResourceType = typeof(Resource))]
		public string EmailOnFrontRun { get{return pEmailOnFrontRun;} set{pEmailOnFrontRun = value.Trim();} }

		private string pEmailOnZoneHit = "";
		[Display(Order = 100, Description = "Email on Zone Hit alert...leave blank to turn-off the email alert", Name = "Email On ZoneHit", GroupName = "Alerts", ResourceType = typeof(Resource))]
		public string EmailOnZoneHit { get{return pEmailOnZoneHit;} set{pEmailOnZoneHit = value.Trim();} }
		#endregion ---------------------------------------------------

		#region -- CurrSession Global Visuals ----------------------------------------------------------
		[Display(Order = 10, Name = "VP VAH Ray Template", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pcVP_VAH_RayTemplate { get; set; }

		[Display(Order = 20, Name = "VP VAL Ray Template", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pcVP_VAL_RayTemplate { get; set; }

		[Display(Order = 30, Name = "TPO VAH Ray Template", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pcTPO_VAH_RayTemplate { get; set; }

		[Display(Order = 40, Name = "TPO VAL Ray Template", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pcTPO_VAL_RayTemplate { get; set; }

		[Display(Order = 50, Name = "POC TPO Ray Template", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pcTPO_POC_RayTemplate { get; set; }

		[Display(Order = 52, Name = "POC VP Ray Template", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pcVP_POC_RayTemplate { get; set; }

		[Display(Order = 58, Name = "LVN Zone Template", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pcLVN_Template { get; set; }

		[Display(Order = 59, Name = "HVN Zone Template", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pcHVN_Template { get; set; }

		#region -- CurSess Global Visuals --
#if SHOW_TERMINATED_RAYS
		private bool pcShowDisqualifiedRays = true;
		[Display(Order = 60, Name = "Show Disqu. Rays?", GroupName = "CurSess Global Visuals", Description ="When a ray hits a value area, do you want to see that ray?", ResourceType = typeof(Custom.Resource))]
		public bool cShowDisqualifiedRays
		{	get { return pcShowDisqualifiedRays; }
			set { pcShowDisqualifiedRays = value;}
		}
#else
		private bool pcShowDisqualifiedRays = false;
#endif
		[Display(Order = 70, Name = "ResZone Template", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pcResZone_Template { get; set; }

		[Display(Order = 80, Name = "SupZone Template", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pcSupZone_Template { get; set; }

//		[Display(Order = 90, Name = "VA Ray Scope", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
//		public ARC_MacroProfiles_GlobalRayScopes pcVisual_ScopeVARays{ get; set;}

//		[Display(Order = 100, Name = "POC Ray Scope", GroupName = "CurSess Global Visuals", ResourceType = typeof(Custom.Resource))]
//		public ARC_MacroProfiles_GlobalRayScopes pcVisual_ScopePOCRays {get;set;}

		#endregion -------------------------------------
		#endregion -------------------------------------

		#region -- Historical Global Visuals --------------------------------
		[Display(Order = 10, Name = "VP VAH Ray Template", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string phVP_VAH_RayTemplate { get; set; }

		[Display(Order = 20, Name = "VP VAL Ray Template", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string phVP_VAL_RayTemplate { get; set; }

		[Display(Order = 30, Name = "TPO VAH Ray Template", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string phTPO_VAH_RayTemplate { get; set; }

		[Display(Order = 40, Name = "TPO VAL Ray Template", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string phTPO_VAL_RayTemplate { get; set; }

		[Display(Order = 50, Name = "POC TPO Ray Template", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string phTPO_POC_RayTemplate { get; set; }

		[Display(Order = 52, Name = "POC VP Ray Template", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string phVP_POC_RayTemplate { get; set; }

		[Display(Order = 58, Name = "LVN Zone Template", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string phLVN_Template { get; set; }

		[Display(Order = 59, Name = "HVN Zone Template", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string phHVN_Template { get; set; }

#if SHOW_TERMINATED_RAYS
		private bool phShowDisqualifiedRays = true;
		[Display(Order = 60, Name = "Show Disqu. Rays?", GroupName = "Hist Global Visuals", Description ="When a ray hits a value area, do you want to see that ray?", ResourceType = typeof(Custom.Resource))]
		public bool hShowDisqualifiedRays
		{	get { return phShowDisqualifiedRays; }
			set { phShowDisqualifiedRays = value;}
		}
#else
		private bool phShowDisqualifiedRays = false;
#endif
		[Display(Order = 70, Name = "ResZone Template", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string phResZone_Template { get; set; }

		[Display(Order = 80, Name = "SupZone Template", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string phSupZone_Template { get; set; }

//		[Display(Order = 90, Name = "VA Ray Scope", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
//		public ARC_MacroProfiles_GlobalRayScopes phVisual_ScopeVARays {get;set;}

//		[Display(Order = 100, Name = "POC Ray Scope", GroupName = "Hist Global Visuals", ResourceType = typeof(Custom.Resource))]
//		public ARC_MacroProfiles_GlobalRayScopes phVisual_ScopePOCRays {get;set;}

		#endregion -------------------------------------

        #region -- ZONES ------------------------------------------------------------------------
		[XmlIgnore]
		[Display(Order = 10, Name = "Support Zone color", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Brush SupZone_Brush { get; set; }
			[Browsable(false)]
			public string SupZone_BrushSerialize{	get { return Serialize.BrushToString(SupZone_Brush); } set { SupZone_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Range(0,100)]
		[Display(Order = 20, Name = "Support Zone Opacity",Description = "Support Zone Opacity 0-100%",GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public int SupZoneOpacity { get; set; }
//====================================
		[Display(Order = 25, Name = "Support Zone Border", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Stroke SupZoneBorder { get;set; }
//====================================
		[XmlIgnore]
		[Display(Order = 30, Name = "Resistance Zone color", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Brush ResZone_Brush { get; set; }
			[Browsable(false)]
			public string ResZone_BrushSerialize{ get { return Serialize.BrushToString(ResZone_Brush); } set { ResZone_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Range(0, 100)]
		[Display(Order = 40, Name = "Resistance Zone Opacity", Description = "Resistance Zone Opacity 0-100%", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public int ResZoneOpacity { get; set; }
//====================================
		[Display(Order = 45, Name = "Resistance Zone Border", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Stroke ResZoneBorder { get; set; }
//====================================
		[XmlIgnore]
		[Display(Order = 50, Name = "Support Tested Zone color", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Brush SupTestedZone_Brush { get; set; }
			[Browsable(false)]
			public string SupTestedZone_BrushSerialize{   get { return Serialize.BrushToString(SupTestedZone_Brush); } set { SupTestedZone_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Range(0, 100)]
		[Display(Order = 60, Name = "Support Tested Zone Opacity", Description = "Tested Support Opacity 0-100%", GroupName = "Zones Settings")]
		public int SupTestedZoneOpacity { get; set; }
//====================================
		[Display(Order = 65, Name = "Support Tested Zone Border", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Stroke SupTestedZoneBorder { get; set; }
//====================================
		[XmlIgnore]
		[Display(Order = 70, Name = "Support Broken Zone color", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Brush SupBrokenZone_Brush { get; set; }
			[Browsable(false)]
			public string SupBrokenZone_BrushSerialize{   get { return Serialize.BrushToString(SupBrokenZone_Brush); } set { SupBrokenZone_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Range(0, 100)]
		[Display(Order = 80, Name = "Support Broken Zone Opacity", Description = "Broken Support Opacity 0-100%", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public int SupBrokenZoneOpacity { get; set; }
//====================================
		[Display(Order = 90, Name = "Support Broken Zone Border", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Stroke SupBrokenZoneBorder { get; set; }
//====================================
		[XmlIgnore]
		[Display(Order = 100, Name = "Resistance Tested Zone color", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Brush ResTestedZone_Brush { get; set; }
			[Browsable(false)]
			public string TestedZone_BrushSerialize{   get { return Serialize.BrushToString(ResTestedZone_Brush); } set { ResTestedZone_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Range(0, 100)]
		[Display(Order = 110, Name = "Resistance Tested Zone Opacity", Description = "Tested Zone Opacity 0-100%", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public int ResTestedZoneOpacity { get; set; }
//====================================
		[Display(Order = 120, Name = "Resistance Tested Zone Border", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Stroke ResTestedZoneBorder { get; set; }
//====================================
		[XmlIgnore]
		[Display(Order = 130, Name = "Resistance Broken Zone color", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Brush ResBrokenZone_Brush { get; set; }
			[Browsable(false)]
			public string ResBrokenZone_BrushSerialize{   get { return Serialize.BrushToString(ResBrokenZone_Brush); } set { ResBrokenZone_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Range(0, 100)]
		[Display(Order = 140, Name = "Resistance Broken Zone Opacity", Description = "Broken Resistance Opacity 0-100%", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public int ResBrokenZoneOpacity { get; set; }
//====================================
		[Display(Order = 150, Name = "Resistance Broken Zone Border", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Stroke ResBrokenZoneBorder { get; set; }
//====================================
		[XmlIgnore]
		[Display(Order = 160, Name = "Disqualified Zone color", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Brush DisqZone_Brush { get; set; }
			[Browsable(false)]
			public string DisqZone_BrushSerialize{   get { return Serialize.BrushToString(DisqZone_Brush); } set { DisqZone_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Range(0, 100)]
		[Display(Order = 170, Name = "Disqualified Zone Opacity", Description = "Opacity 0-100%", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public int DisqZoneOpacity { get; set; }
//====================================
		[XmlIgnore]
		[Display(Order = 180, Name = "Overlapped Zone color", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Brush OverlapZone_Brush { get; set; }
			[Browsable(false)]
			public string OverlapZone_BrushSerialize{   get { return Serialize.BrushToString(OverlapZone_Brush); } set { OverlapZone_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Range(0, 100)]
		[Display(Order = 190, Name = "Overlapped Zone Opacity", Description = "Opacity 0-100%", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public int OverlapZoneOpacity { get; set; }
//====================================
		[Display(Order = 200, Name = "Permit VAH RaysZones", Description = "Remove drawn VAH rays and arb zones", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool pPermitVAHRaysZones { get; set; }
//====================================
		[Display(Order = 201, Name = "Permit VAL RaysZones", Description = "Remove drawn VAL rays and arb zones", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool pPermitVALRaysZones { get; set; }
//====================================
//		[Display(Order = 210, Name = "LVN Zones", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
//		public bool pShow_LVNZones { get; set; }
//====================================
		[Display(Order = 225, Name = "Current Session Zones?", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool pShow_CurrentSessionZones { get; set; }

//====================================
		[Display(Order = 230, Name = "Fresh Zones", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool pShow_FreshZones { get; set; }
//====================================
		[Display(Order = 240, Name = "Broken Zones", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool pShow_BrokenZones { get; set; }
//====================================
		[Display(Order = 250, Name = "Tested Zones", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool pShow_TestedZones {get;set;}
//====================================
		[Display(Order = 260, Name = "All Resistance Zones", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool pPermit_ResistanceZones {get;set;}
//====================================
		[Display(Order = 270, Name = "All Support Zones", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool pPermit_SupportZones {get;set;}
//====================================
		[Display(Order = 280, Name = "Disqualified Zones", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool pShow_DisqZones {get;set;}
//====================================
		[Display(Order = 290, Name = "Overlapped Zones", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool pShow_OverlappedZones {get;set;}
//====================================
		private bool pShow_ZonePrices = false;
		[Display(Order = 300, Name = "Show Zone Prices", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool Show_ZonePrices {get{return pShow_ZonePrices; }  set{pShow_ZonePrices=value;} }
//====================================
		private bool pShow_SessionBreaks = false;
		[Display(Order = 310, Name = "Show Session Breaks", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public bool Show_SessionBreaks {get{return pShow_SessionBreaks; }  set{pShow_SessionBreaks = value;} }
//====================================
//		private int pSessionBreaksSize = 10;
//		[Display(Order = 240, Name = "Length of Session Break line", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
//		public int SessionBreaksSize {get{return pSessionBreaksSize; }  set{pSessionBreaksSize= Math.Abs(value);} }
//====================================
		[XmlIgnore]
		[Display(Order = 320, Name = "Session Break color", GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public Brush SessionBreak_Brush { get; set; }
			[Browsable(false)]
			public string SessionBreak_BrushSerialize{   get { return Serialize.BrushToString(SessionBreak_Brush); } set { SessionBreak_Brush = Serialize.StringToBrush(value); }}
//====================================
		private NinjaTrader.Gui.Tools.SimpleFont pZonePricesFont = new NinjaTrader.Gui.Tools.SimpleFont("Arial",10);
		[Description("Choose your font style for Zone Prices")]
		[Display(Order=340, Name = "Prices Font",  GroupName = "Zones Settings", ResourceType = typeof(Custom.Resource))]
		public NinjaTrader.Gui.Tools.SimpleFont ZonePricesFont
		{
			get { return pZonePricesFont; }
			set { pZonePricesFont = value; }
		}
//====================================
		#endregion ----------------------------------------------

		#region -- TPO Touch Counter --
//====================================
		private bool pShow_TPOTouchCounter = true;
		[Display(Order = 10, Name = "Show TPO Counter", GroupName = "TPO Touch Counter", ResourceType = typeof(Custom.Resource))]
		public bool Show_TPOTouchCounter {get{return pShow_TPOTouchCounter; }  set{pShow_TPOTouchCounter = value;} }
//====================================
		[Display(Order = 20, Name = "TPO Counter Font", GroupName = "TPO Touch Counter", ResourceType = typeof(Custom.Resource))]
		public SimpleFont TPOTouchCounter_Font {get;set; }
//====================================
		private string pTPOCounterLabel = "TPO Touch: ";
		[Display(Order = 30, Name = "TPO Counter Label", GroupName = "TPO Touch Counter", ResourceType = typeof(Custom.Resource))]
		public string TPOCounterLabel {get{return pTPOCounterLabel;} set{pTPOCounterLabel=value;} }
//====================================
		[XmlIgnore]
		[Display(Order = 40, Name = "TPO Counter Text Color", GroupName = "TPO Touch Counter", ResourceType = typeof(Custom.Resource))]
		public Brush TPOCounterFont_Brush { get; set; }
			[Browsable(false)]
			public string TPOCounterFont_BrushSerialize{   get { return Serialize.BrushToString(TPOCounterFont_Brush); } set { TPOCounterFont_Brush = Serialize.StringToBrush(value); }}
//====================================
		[XmlIgnore]
		[Display(Order = 50, Name = "TPO Counter Bkg Color", GroupName = "TPO Touch Counter", ResourceType = typeof(Custom.Resource))]
		public Brush TPOCounterFont_BkgBrush { get; set; }
			[Browsable(false)]
			public string TPOCounterFont_BkgBrushSerialize{   get { return Serialize.BrushToString(TPOCounterFont_BkgBrush); } set { TPOCounterFont_BkgBrush = Serialize.StringToBrush(value); }}
		#endregion --------------------------

		#region -- Visuals - TPO --------------------------------------------------------------
//====================================
		private Brush tpoVerticalBarBrush = Brushes.Black;
		[XmlIgnore()]
		[Description("Color of vertical line for TPO value area")]
		[Display(Order=10, Name = "Vertline color",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public Brush _tpoVerticalBarBrush
		{	get { return tpoVerticalBarBrush; }
			set { tpoVerticalBarBrush = value; }
		}
				[Browsable(false)]
				public string tpoVerticalBarBrushSerialize{	get { return Serialize.BrushToString(tpoVerticalBarBrush); }set { tpoVerticalBarBrush = Serialize.StringToBrush(value); }}
//====================================
		private Brush tpoVABrush = Brushes.Cyan;
		[XmlIgnore()]
		[Description("Color of TPO value area")]
		[Display(Order=20, Name = "VA color",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public Brush _tpoVABrush
		{	get { return tpoVABrush; }
			set { tpoVABrush = value; }
		}
				[Browsable(false)]
				public string tpoVABrushSerialize{	get { return Serialize.BrushToString(tpoVABrush); }set { tpoVABrush = Serialize.StringToBrush(value); }}
//====================================
		private Brush tpoAboveVABrush = Brushes.Blue;
		[XmlIgnore()]
		[Description("Color of TPO above the TPO value area")]
		[Display(Order=30, Name = "Above VA color",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public Brush _tpoAboveVABrush
		{	get { return tpoAboveVABrush; }
			set { tpoAboveVABrush = value; }
		}
				[Browsable(false)]
				public string tpoAboveVABrushSerialize{	get { return Serialize.BrushToString(tpoAboveVABrush); }set { tpoAboveVABrush = Serialize.StringToBrush(value); }}
//====================================
		private Brush tpoBelowVABrush = Brushes.Red;
		[XmlIgnore()]
		[Description("Color of TPO below value area")]
		[Display(Order=40, Name = "Below VA color",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public Brush _tpoBelowVABrush
		{	get { return tpoBelowVABrush; }
			set { tpoBelowVABrush = value; }
		}
				[Browsable(false)]
				public string tpoBelowVABrushSerialize{	get { return Serialize.BrushToString(tpoBelowVABrush); }set { tpoBelowVABrush = Serialize.StringToBrush(value); }}
//====================================
		private int ptpoVA_Opacity = 50;
		[Description("Opacity of TPO Value Area histo (100=full opaque, 0=transparent)")]
		[Display(Order=50, Name = "VA opacity",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public int tpoVA_Opacity
		{
			get { return ptpoVA_Opacity; }
			set { ptpoVA_Opacity = Math.Max(0,Math.Min(100,value));}
		}
//====================================
		private int ptpoNonVA_Opacity = 50;
		[Description("Opacity of TPO Non-Value Area histo (100=full opaque, 0=transparent)")]
		[Display(Order=60, Name = "Non-VA opacity",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public int tpoNonVA_Opacity
		{
			get { return ptpoNonVA_Opacity; }
			set { ptpoNonVA_Opacity = Math.Max(0,Math.Min(100,value));}
		}
//====================================
		[Description("Show the SinglePrint TPO areas with a highlighted line?")]
		[Display(Order=64, Name = "Show SinglPrints",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public bool pShowSinglePrintLines {get;set;}
//====================================
		[XmlIgnore()]
		[Description("Color of SinglePrint Lines")]
		[Display(Order=65, Name = "SinglePrintLine color",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public Brush tpoSinglePrintLine_Brush{get;set;}
				[Browsable(false)]
				public string tpoSinglePrintLine_BrushSerialize {	get { return Serialize.BrushToString(tpoSinglePrintLine_Brush); }set { tpoSinglePrintLine_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Range(1f,float.MaxValue)]
		[Description("Thickness of single print lines")]
		[Display(Order=66, Name = "SinglePrintLine thickness",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public float pSinglePrintLineThickness {get;set;}
//====================================
		[Description("Show the TPO Profile histogram dots?")]
		[Display(Order=70, Name = "Show TPO histo",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public bool pShowTPO_Histo {get;set;}
//====================================
		[Description("Show the TPO Profile VAHigh plot?")]
		[Display(Order=80, Name = "VAH Type",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType pVisualType_TPOVAH {get;set;}
//====================================
		[Description("Show the TPO Profile VALow plot?")]
		[Display(Order=90, Name = "VAL Type",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType pVisualType_TPOVAL {get;set;}
//====================================
		[Description("Show the TPO Profile POC plot?")]
		[Display(Order=100, Name = "POC Type",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType pVisualType_TPOPOC {get;set;}
//====================================
		[XmlIgnore()]
		[Description("Color of TPO POC histo bar")]
		[Display(Order=110, Name = "POC color",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public Brush tpoPOC_Brush{get;set;}
				[Browsable(false)]
				public string tpoPOC_BrushSerialize {	get { return Serialize.BrushToString(tpoPOC_Brush); }set { tpoPOC_Brush = Serialize.StringToBrush(value); }}

		private int ptpoPOC_Opacity = 90;
		[Description("Opacity of TPO POC histo (100=full opaque, 0=transparent)")]
		[Display(Order=120, Name = "POC opacity",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public int tpoPOC_Opacity
		{	get { return ptpoPOC_Opacity; }
			set { ptpoPOC_Opacity = Math.Max(0,Math.Min(100,value));}
		}
//====================================
#if HTO_LTO
		public int pSignificance_HTO_LTO = 8;
		private bool pHighlightHTOLTO_Region = false;
		private int pHTO_Opacity = 90;
		private int pLTO_Opacity = 90;
		#region -- HTO_LTO -------------
		[Description(@"How prominent must the HTO/LTO histo bar be?")]
		[Display(Order=110, Name = @"HTO/LTO Significance",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public int Significance_HTO_LTO {get{return pSignificance_HTO_LTO;} set{ pSignificance_HTO_LTO = Math.Max(1,value);}}
//====================================
		[Description("Highlight entire region of HTO/LTO?  Otherwise, just highlight the central node")]
		[Display(Order=115, Name = "Highlight Region",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public bool HighlightHTOLTO_Region
		{	get { return pHighlightHTOLTO_Region; }
			set { pHighlightHTOLTO_Region = value;}
		}
//====================================
		[Description("HTO plot type?")]
		[Display(Order=120, Name = "HTO Visual",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType_HNLN pVisualType_HTO {get;set;}
//====================================
		[Description("LTO plot type?")]
		[Display(Order=130, Name = "LTO Visual",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType_HNLN pVisualType_LTO {get;set;}
//====================================
		[XmlIgnore()]
		[Description("Color of TPO HTO bar")]
		[Display(Order=140, Name = "HTO color",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public Brush HTO_Brush{get;set;}
			[Browsable(false)]
			public string HTO_BrushSerialize{	get { return Serialize.BrushToString(HTO_Brush); }set { HTO_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Description("Opacity of TPO HTO (100=full opaque, 0=transparent)")]
		[Display(Order=150, Name = "HTO opacity",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public int HTO_Opacity
		{	get { return pHTO_Opacity; }
			set { pHTO_Opacity = Math.Max(0,Math.Min(100,value));}
		}
//====================================
		[XmlIgnore()]
		[Description("Color of TPO LTO bar")]
		[Display(Order=160, Name = "LTO color",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public Brush LTO_Brush{get;set;}
			[Browsable(false)]
			public string LTO_BrushSerialize{	get { return Serialize.BrushToString(LTO_Brush); }set { LTO_Brush = Serialize.StringToBrush(value); }}
//====================================
		[Description("Opacity of TPO LTO (100=full opaque, 0=transparent)")]
		[Display(Order=170, Name = "LTO opacity",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public int LTO_Opacity
		{	get { return pLTO_Opacity; }
			set { pLTO_Opacity = Math.Max(0,Math.Min(100,value));}
		}
		#endregion
#endif
//====================================
		private int pTPOLineThickness = 2;
		[Description("TPO line thickness")]
		[Display(Order=180, Name = "TPO LineWidth",  GroupName = "Visuals - TPO", ResourceType = typeof(Custom.Resource))]
		public int TPOLineThickness
		{	get { return pTPOLineThickness; }
			set { pTPOLineThickness = Math.Max(1,value);}
		}
		#endregion ------------------------------------------------------------------------------
//====================================
		#region -- Visuals - VolumeProfile --------------------------------------------------------------
		private Brush vpVerticalBarBrush = Brushes.Cyan;
		[XmlIgnore()]
		[Description("Color of vertical line for VolumeProfile value area")]
		[Display(Order=10, Name = "Vertline color",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public Brush _vpVerticalBarBrush
		{	get { return vpVerticalBarBrush; }
			set { vpVerticalBarBrush = value; }
		}
			[Browsable(false)]
			public string vpVerticalBarBrushSerialize{	get { return Serialize.BrushToString(vpVerticalBarBrush); }set { vpVerticalBarBrush = Serialize.StringToBrush(value); }}
//====================================
		private Brush vpVABrush = Brushes.White;
		[XmlIgnore()]
		[Description("Color of VolumeProfile value area")]
		[Display(Order=20, Name = "VA color",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public Brush _vpVABrush
		{	get { return vpVABrush; }
			set { vpVABrush = value; }
		}
			[Browsable(false)]
			public string vpVABrushSerialize{	get { return Serialize.BrushToString(vpVABrush); }set { vpVABrush = Serialize.StringToBrush(value); }}
//====================================
		private Brush vpAboveVABrush = Brushes.White;
		[XmlIgnore()]
		[Description("Color of VolumeProfile above the VolumeProfile value area")]
		[Display(Order=30, Name = "Above VA color",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public Brush _vpAboveVABrush
		{	get { return vpAboveVABrush; }
			set { vpAboveVABrush = value; }
		}
			[Browsable(false)]
			public string vpAboveVABrushSerialize{	get { return Serialize.BrushToString(vpAboveVABrush); }set { vpAboveVABrush = Serialize.StringToBrush(value); }}
//====================================
		private Brush vpBelowVABrush = Brushes.White;
		[XmlIgnore()]
		[Description("Color of VolumeProfile below value area")]
		[Display(Order=40, Name = "Below VA color",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public Brush _vpBelowVABrush
		{	get { return vpBelowVABrush; }
			set { vpBelowVABrush = value; }
		}
			[Browsable(false)]
			public string vpBelowVABrushSerialize{	get { return Serialize.BrushToString(vpBelowVABrush); }set { vpBelowVABrush = Serialize.StringToBrush(value); }}
//====================================
		private int pvpVA_Opacity = 50;
		[Description("Opacity of VolumeProfile Value Area histo (100=full opaque, 0=transparent)")]
		[Display(Order=50, Name = "VA opacity",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public int vpVA_Opacity
		{
			get { return pvpVA_Opacity; }
			set { pvpVA_Opacity = Math.Max(0,Math.Min(100,value));}
		}
//====================================
		private int pvpNonVA_Opacity = 50;
		[Description("Opacity of VolumeProfile Non-Value Area histo (100=full opaque, 0=transparent)")]
		[Display(Order=60, Name = "Non-VA opacity",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public int vpNonVA_Opacity
		{
			get { return pvpNonVA_Opacity; }
			set { pvpNonVA_Opacity = Math.Max(0,Math.Min(100,value));}
		}
//====================================
		[Description("Show the VolumeProfile Profile histogram dots?")]
		[Display(Order=70, Name = "Show VolumeProfile histo",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public bool pShowVP_Histo {get;set;}
//====================================
		[Description("Show the VolumeProfile Profile VAHigh plot?")]
		[Display(Order=80, Name = "VAH Type",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType pVisualType_VPVAH {get;set;}
//====================================
		[Description("Show the VolumeProfile Profile VALow plot?")]
		[Display(Order=90, Name = "VAL Type",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType pVisualType_VPVAL {get;set;}
//====================================
		[Description("Show the VolumeProfile Profile POC plot?")]
		[Display(Order=100, Name = "POC Type",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType pVisualType_VPPOC {get;set;}
//====================================
		[XmlIgnore()]
		[Description("Color of VolumeProfile POC histo bar")]
		[Display(Order=110, Name = "POC color",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public Brush vpPOC_Brush{get;set;}
			[Browsable(false)]
			public string vpPOC_BrushSerialize{	get { return Serialize.BrushToString(vpPOC_Brush); }set { vpPOC_Brush = Serialize.StringToBrush(value); }}
//====================================
		private int pvpPOC_Opacity = 90;
		[Description("Opacity of VolumeProfile POC histo (100=full opaque, 0=transparent)")]
		[Display(Order=120, Name = "POC opacity",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public int vpPOC_Opacity
		{	get { return pvpPOC_Opacity; }
			set { pvpPOC_Opacity = Math.Max(0,Math.Min(100,value));}
		}
//====================================
		public int pTicksPerHistoBar = 1;
		[Description("Number of price ticks (vertical distance) of a volume profile histogram bar")]
		[Display(Order=130, Name = "Ticks per histo",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public int _TicksPerHistoBar
		{
			get { return pTicksPerHistoBar; }
			set { pTicksPerHistoBar = Math.Max(1,value);}
		}
//====================================
		public int pSignificance_HVN_LVN = 4;
		[Description(@"How prominent must the HVN/LVN histo bar be?")]
		[Display(Order=140, Name = @"HVN/LVN Significance",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public int Significance_HVN_LVN {get{return pSignificance_HVN_LVN;} set{ pSignificance_HVN_LVN = Math.Max(1,value);}}
//====================================
		private bool pHighlightHVNLVN_Region = true;
		[Description("Highlight entire region of HVN/LVN?  Otherwise, just highlight the central node")]
		[Display(Order=145, Name = "Highlight Region",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public bool HighlightHVNLVN_Region
		{	get { return pHighlightHVNLVN_Region; }
			set { pHighlightHVNLVN_Region = value;}
		}
//====================================
		private int pHighlightHVNLVN_RegionSize = 2;
		[Range(0,int.MaxValue)]
		[Description("Size of HVN/LVN region ")]
		[Display(Order=146, Name = "Highlight Region Size",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public int HighlightHVNLVN_RegionSize
		{	get { return pHighlightHVNLVN_RegionSize; }
			set { pHighlightHVNLVN_RegionSize = value;}
		}
//====================================
		[Description("HVN plot type?")]
		[Display(Order=150, Name = "HVN Visual",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType_HNLN pVisualType_HVN {get;set;}
//====================================
		[Description("LVN plot type?")]
		[Display(Order=160, Name = "LVN Visual",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType_HNLN pVisualType_LVN {get;set;}
//====================================
		[XmlIgnore()]
		[Description("Color of VolumeProfile HVN bar")]
		[Display(Order=170, Name = "HVN color",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public Brush HVN_Brush{get;set;}
			[Browsable(false)]
			public string HVN_BrushSerialize{	get { return Serialize.BrushToString(HVN_Brush); }set { HVN_Brush = Serialize.StringToBrush(value); }}
//====================================
		private int pHVN_Opacity = 90;
		[Description("Opacity of VolumeProfile HVN (100=full opaque, 0=transparent)")]
		[Display(Order=180, Name = "HVN opacity",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public int HVN_Opacity
		{	get { return pHVN_Opacity; }
			set { pHVN_Opacity = Math.Max(0,Math.Min(100,value));}
		}
//====================================
		[XmlIgnore()]
		[Description("Color of VolumeProfile LVN bar")]
		[Display(Order=190, Name = "LVN color",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public Brush LVN_Brush{get;set;}
			[Browsable(false)]
			public string LVN_BrushSerialize{	get { return Serialize.BrushToString(LVN_Brush); }set { LVN_Brush = Serialize.StringToBrush(value); }}
//====================================
		private int pLVN_Opacity = 90;
		[Description("Opacity of VolumeProfile LVN (100=full opaque, 0=transparent)")]
		[Display(Order=200, Name = "LVN opacity",  GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public int LVN_Opacity
		{	get { return pLVN_Opacity; }
			set { pLVN_Opacity = Math.Max(0,Math.Min(100,value));}
		}
//====================================
		[Display(Order = 210, Name = "Current profile VN?", GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public bool pShow_CurrentProfileVN { get; set; }
		
		[Display(Order = 220, Name = "Historical profile VN?", GroupName = "Visuals - VolumeProfile", ResourceType = typeof(Custom.Resource))]
		public bool pShow_HistoricalProfileVN {get;set;}
//====================================

//====================================
		#endregion ------------------------------------------------------------------------------

		#region -- Visuals --------------------------------------------------------------------
		//====================================
//		private int pVAHLine_Opacity = 50;
//		[Description("Opacity of Value Area High Line (100=full opaque, 0=transparent)")]
//		[Display(Name = "VAH Line opacity",  GroupName = "Visuals")]
//		public int VAHLine_Opacity
//		{
//			get { return pVAHLine_Opacity; }
//			set { pVAHLine_Opacity = Math.Max(0,Math.Min(100,value));}
//		}
//		private int pVALLine_Opacity = 50;
//		[Description("Opacity of Value Area Low Line (100=full opaque, 0=transparent)")]
//		[Display(Name = "VAL Line opacity",  GroupName = "Visuals")]
//		public int VALLine_Opacity
//		{
//			get { return pVALLine_Opacity; }
//			set { pVALLine_Opacity = Math.Max(0,Math.Min(100,value));}
//		}

//		private int pVolumeDivisor = 1000;
//		[Description("Divisor in the total Volume display")]
//		[Category("Visuals")]
//		public int VolumeDivisor
//		{
//			get { return pVolumeDivisor; }
//			set { pVolumeDivisor = Math.Max(1,value);}
//		}
		[Description("Button text - enter how you want the UI button to be labeled")]
		[Display(Order = 10, Name = "Button Txt",  GroupName = "Visuals", ResourceType = typeof(Custom.Resource))]
		public string pButtonText {get;set;}
//====================================
		private bool pShowErrorMessageWhenTooCondensed = false;
		[Description("Show an error message on chart when the 'PriceTicksPerHistoBar' parameter is too small to be viewed properly?")]
		[Display(Order=20, Name = "Show Error Msg?",  GroupName = "Visuals", ResourceType = typeof(Custom.Resource))]
		public bool ShowErrorMessageWhenTooCondensed
		{
			get { return pShowErrorMessageWhenTooCondensed; }
			set { pShowErrorMessageWhenTooCondensed = value;}
		}
//====================================
		private int pValueAreaPct = 60;
		[Range(0,95)]
		[Description("Value Area size, as a pct of the entire volume of the profile")]
		[Display(Order=30, Name = "Value Area %",  GroupName = "Visuals", ResourceType = typeof(Custom.Resource))]
		public int ValueAreaPct
		{
			get { return pValueAreaPct; }
			set { pValueAreaPct = Math.Max(1,Math.Min(100,value));}
		}
//====================================
		private NinjaTrader.Gui.Tools.SimpleFont labelFont = new NinjaTrader.Gui.Tools.SimpleFont("Arial",10);
		[Description("Choose your font style for VAH/VAL and POC text")]
		[Display(Order=40, Name = "Label Font",  GroupName = "Visuals", ResourceType = typeof(Custom.Resource))]
		public NinjaTrader.Gui.Tools.SimpleFont LabelFont
		{
			get { return labelFont; }
			set { labelFont = value; }
		}
//====================================
		[Description("Show the price bars?")]
		[Display(Order=50, Name = "Show Price bars",  GroupName = "Visuals", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_PriceBarSetting pPriceBarSetting {get;set;}
//====================================
		[Description("Auto scale the width of the volume and TPO histos?  Set to 'false' to use the mousewheel to control the width of the histos")]
		[Display(Order=60, Name = "AutoScale Histo widths",  GroupName = "Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pAutoScaleHistoWidth {get;set;}
//====================================
		[Description("Show the static VWAP plot?")]
		[Display(Order=70, Name = "VWAP Type",  GroupName = "Visuals", ResourceType = typeof(Custom.Resource))]
		public ARC_MacroProfiles_VisualsType pVisualType_VWAP {get;set;}
//====================================
		private int pMaxHistogramWidth = 0;
//		[Description("Maximum width of histogram (in pixels).  Set to '0' for auto-calculation")]
//		[Category("Visuals")]
//		public int MaxHistogramWidth
//		{
//			get { return pMaxHistogramWidth; }
//			set { pMaxHistogramWidth = Math.Max(0,value);}
//		}

		private ARC_MacroProfiles_HistoLocation pLocation = ARC_MacroProfiles_HistoLocation.AtRightMarker;
//		[Description("Location of histogram")]
//		[Display(Name = "Location",  GroupName = "Visuals")]
//		public ARC_MacroProfiles_HistoLocation Location
//		{
//			get { return pLocation; }
//			set { pLocation = value;}
//		}
//====================================
		private int pBarSpacing = 1;
		[Description("Pixel spacing between the volume histogram bars.")]
		[Display(Order=80, Name = "Bar spacing",  GroupName = "Visuals", ResourceType = typeof(Custom.Resource))]
		public int BarSpacing
		{
			get { return pBarSpacing; }
			set { pBarSpacing = Math.Min(5, Math.Max(0,  value));}
		}
		#endregion
//====================================
		#region -- Marker Visuals ---------------------------------------------------------------------------------
		[XmlIgnore()]
		[Description("Color of marker on the open of the profile")]
		[Display(Order=90, Name = "Open Marker",  GroupName = "Marker Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush OpenMarkerBrush {get;set;}
				[Browsable(false)]
				public string OpenMarkerBrushSerialize {	get { return Serialize.BrushToString(OpenMarkerBrush); }set { OpenMarkerBrush = Serialize.StringToBrush(value); }}
//====================================
		private float pOpenMarkerSize = 1f;
		[Description("Pixel size of the profile open marker")]
		[Display(Order=100, Name = "Open Marker size",  GroupName = "Marker Visuals", ResourceType = typeof(Custom.Resource))]
		public float OpenMarkerSize	{			get { return pOpenMarkerSize; }
												set { pOpenMarkerSize = Math.Max(1f, value);}}
//====================================
		[XmlIgnore()]
		[Description("Color of marker on an up-closed profile")]
		[Display(Order=110, Name = "Up-close Marker",  GroupName = "Marker Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush UpCloseMarkerBrush {get;set;}
				[Browsable(false)]
				public string UpCloseMarkerBrushSerialize {	get { return Serialize.BrushToString(UpCloseMarkerBrush); }set { UpCloseMarkerBrush = Serialize.StringToBrush(value); }}
//====================================
		[XmlIgnore()]
		[Description("Color of marker on an up-closed profile")]
		[Display(Order=120, Name = "Down-close Marker",  GroupName = "Marker Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush DownCloseMarkerBrush {get;set;}
				[Browsable(false)]
				public string DownCloseMarkerBrushSerialize {	get { return Serialize.BrushToString(DownCloseMarkerBrush); }set { DownCloseMarkerBrush = Serialize.StringToBrush(value); }}
//====================================
		private float pCloseMarkerSize = 3f;
		[Description("Pixel size of the profile Close marker")]
		[Display(Order=130, Name = "Close Marker size",  GroupName = "Marker Visuals", ResourceType = typeof(Custom.Resource))]
		public float CloseMarkerSize	{		get { return pCloseMarkerSize; }
												set { pCloseMarkerSize = Math.Max(1f, value);}}
//====================================
		private float pCloseMarkerOffset = 0.5f;
		[Description("Bars separation between closing bar and Close marker, and the opening bar and the Open marker")]
		[Display(Order=140, Name = "Marker offset",  GroupName = "Marker Visuals", ResourceType = typeof(Custom.Resource))]
		public float CloseMarkerOffset	{		get { return pCloseMarkerOffset; }
												set { pCloseMarkerOffset = Math.Abs(value);}}
//====================================
		private bool pShowCurrentPriceLine = true;
		[Description("If you have the price bars hidden, then do you want to show the current price line?")]
		[Display(Order=150, Name = "Show Current Price?",  GroupName = "Marker Visuals", ResourceType = typeof(Custom.Resource))]
		public bool ShowCurrentPriceLine{		get { return pShowCurrentPriceLine; }
												set { pShowCurrentPriceLine = value;}}
//====================================
		private Brush pCurrentPriceLineBrush = Brushes.Yellow;
		[XmlIgnore()]
		[Description("Color of price marker line")]
		[Display(Order=160, Name = "Current Price Color",  GroupName = "Marker Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush CurrentPriceLineBrush{		get { return pCurrentPriceLineBrush; }
												set { pCurrentPriceLineBrush = value; }}
			[Browsable(false)]
			public string pCurrentPriceLineBrushSerialize{	get { return Serialize.BrushToString(pCurrentPriceLineBrush); }set { pCurrentPriceLineBrush = Serialize.StringToBrush(value); }}
//====================================
		private float pCurrentPriceLineLength = 0f;
		[Description("Length (in pixels) of current price line")]
		[Display(Order=170, Name = "Current Price Length",  GroupName = "Marker Visuals", ResourceType = typeof(Custom.Resource))]
		public float CurrentPriceLineLength{	get { return pCurrentPriceLineLength; }
												set { pCurrentPriceLineLength = Math.Abs(value);}}
//====================================
		private float pCurrentPriceLineWidth = 1f;
		[Description("Width (in pixels) of current price line")]
		[Display(Order=180, Name = "Current Price Width",  GroupName = "Marker Visuals", ResourceType = typeof(Custom.Resource))]
		public float CurrentPriceLineWidth{		get { return pCurrentPriceLineWidth; }
												set { pCurrentPriceLineWidth = Math.Abs(value);}}
//====================================

		#endregion

		#region -- Splitting Parameters -------------------------------------------------------------------------
		[Display(Order = 10, Name = "Split/Merge Enabled", GroupName = "Split/Merge Settings", ResourceType = typeof(Resource))]
        public bool IsSplitMergeEnabled {get; set;}
////====================================
//        [Display(Order = 20, ResourceType = typeof(Resource), Name = "Auto Split", GroupName = "Split/Merge Settings")]
//        public bool IsAutoSplit {get; set;}
//====================================
        [Display(Order = 30, Name = "Split Assist", GroupName = "Split/Merge Settings", ResourceType = typeof(Resource))]
        public bool IsSplitAssist {get; set;}
//====================================
//		private bool pAutoSplitCurrentDay=true;
//        [Display(Order = 40, Name = "Dynamic Split CurrentDay", GroupName = "Split/Merge Settings", ResourceType = typeof(Resource))]
//        public bool AutoSplitCurrentDay {get{return pAutoSplitCurrentDay;} set{pAutoSplitCurrentDay = value;} }
//====================================
        [Display(Order = 45, Name = "AutoMerge Overlappers", GroupName = "Split/Merge Settings", ResourceType = typeof(Resource))]
        public bool IsAutoMergeOverlappers {get; set;}
//====================================
		[XmlIgnore()]
		[Description("Color of Split Assist marker")]
		[Display(Order = 50, Name = "Split Assist marker",  GroupName = "Split/Merge Settings")]
		public Brush SplitAssistMarkerBrush{get;set;}
			[Browsable(false)]
			public string SplitAssistBrushSerialize {	get { return Serialize.BrushToString(SplitAssistMarkerBrush); }set { SplitAssistMarkerBrush = Serialize.StringToBrush(value); }}
//====================================
		[Range(0,100)]
        [Display(Order = 60, Name = "Split Marker Opacity", GroupName = "Split/Merge Settings", ResourceType = typeof(Resource))]
        public float SplitMarkerFillOpacity { get; set; }
//====================================
        [Display(Order = 65, Name = "Split Marker Outline", GroupName = "Split/Merge Settings", ResourceType = typeof(Resource))]
        public Stroke SplitMarkerOutline_Stroke { get; set; }
//====================================
		private int pMinSplitDepth = 2;
		[Description("Minimum TPO Volume depth required for valid autosplit and split assist")]
		[Display(Order = 70, Name = "Min. Split Depth",  GroupName = "Split/Merge Settings", ResourceType = typeof(Custom.Resource))]
		public int MinSplitDepth
		{	get { return pMinSplitDepth; }
			set { pMinSplitDepth = Math.Max(2,value);}
		}
		#endregion
		
		#region -- ATR Delta Box Visual --------------------------------------------------------------------

		[Display(Order = 5, ResourceType = typeof(Resource), Name = "Show RR", Description = "Shows the RR databox in lower-right corner",GroupName = "ATR Delta Box Visual")]
		public bool ShowRR_databox {get; set;}

		[Display(Order = 10, ResourceType = typeof(Resource), Name = "Show ATR", Description = "Shows the ATR databox in lower-right corner",GroupName = "ATR Delta Box Visual")]
		public bool ShowATR_databox {get;set;}

		private int pATRperiod = 14;
		[Display(Order = 20, Name = "ATR period", Description = "ATR period",GroupName = "ATR Delta Box Visual", ResourceType = typeof(Resource))]
		public int ATRperiod {get{return pATRperiod;} set{pATRperiod = Math.Max(1,value);}}

		[Display(Order = 30, ResourceType = typeof(Resource), Name = "ATR Mode", GroupName = "ATR Delta Box Visual")]
        public ARC_MacroProfiles_ATRModeEnum ATRMode { get; set; }

		[Display(Order = 40, ResourceType = typeof(Resource), Name = "Font",Description = "Font",GroupName = "ATR Delta Box Visual")]
		public SimpleFont ATR_Delta_Box_Font {get; set;}

		[XmlIgnore]
		[Display(Order = 50, ResourceType = typeof(Resource), Name = "Font Color",Description = "Font Color",GroupName = "ATR Delta Box Visual")]
		public Brush ATR_Delta_Box_Font_Color { get; set; }

				[Browsable(false)]
				public string ATR_Delta_Box_Font_ColorSerialize{get { return NinjaTrader.Gui.Serialize.BrushToString(ATR_Delta_Box_Font_Color); }set { ATR_Delta_Box_Font_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }}
		
		[XmlIgnore]
		[Display(Order = 60, ResourceType = typeof(Resource), Name = "Box Background Color",Description = "Box Background Color",GroupName = "ATR Delta Box Visual")]
		public Brush ATR_Delta_Box_Back_Color { get; set; }

				[Browsable(false)]
				public string ATR_Delta_Box_Back_ColorSerialize {get { return NinjaTrader.Gui.Serialize.BrushToString(ATR_Delta_Box_Back_Color); }set { ATR_Delta_Box_Back_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }}
		
		[XmlIgnore]
		[Display(Order = 70, ResourceType = typeof(Resource), Name = "Box Border",Description = "Box Border",GroupName = "ATR Delta Box Visual")]
		public Stroke ATR_Delta_Box_Border { get; set; }

		#endregion
		
		#region -- Price Bars colors -----------------------------------------------------------------------
		[XmlIgnore]
		[Display(Order = 10, ResourceType = typeof(Resource), Name = "Up Candle",Description = "Body color of up-closing bars",GroupName = "Price Bars")]
		public Brush CandleBodyUpBrush { get; set; }
				[Browsable(false)]
				public string CandleBodyUpBrushSerialize{get { return NinjaTrader.Gui.Serialize.BrushToString(CandleBodyUpBrush); }set { CandleBodyUpBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order = 20, ResourceType = typeof(Resource), Name = "Down Candle",Description = "Body color of down-closing bars",GroupName = "Price Bars")]
		public Brush CandleBodyDownBrush { get; set; }
				[Browsable(false)]
				public string CandleBodyDownBrushSerialize{get { return NinjaTrader.Gui.Serialize.BrushToString(CandleBodyDownBrush); }set { CandleBodyDownBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order = 30, ResourceType = typeof(Resource), Name = "Candle Outline",Description = "Outline color of bars",GroupName = "Price Bars")]
		public Brush CandleOutlineBrush { get; set; }
				[Browsable(false)]
				public string CandleOutlineBrushSerialize{get { return NinjaTrader.Gui.Serialize.BrushToString(CandleOutlineBrush); }set { CandleOutlineBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order = 40, ResourceType = typeof(Resource), Name = "Candle Wick",Description = "Color of bar wicks",GroupName = "Price Bars")]
		public Brush CandleWickBrush { get; set; }
				[Browsable(false)]
				public string CandleWickBrushSerialize{get { return NinjaTrader.Gui.Serialize.BrushToString(CandleWickBrush); }set { CandleWickBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }}
		#endregion
#endregion
//======================================================================================================
	}
}
public enum ARC_MacroProfiles_HistoLocation{Left,Right,AtCurrentBar,AtLeftMarker,AtRightMarker}
public enum ARC_MacroProfiles_Sensitivity      {Tick, Second, Minute1, Minute2, Minute3, Minute4, Minute5, Minute10, Minute15, Minute30}
public enum ARC_MacroProfiles_VisualsType      {None, Static, Dynamic, Both}
public enum ARC_MacroProfiles_VisualsType_HNLN {Hidden, Half, Full, Extended, Dot}
public enum ARC_MacroProfiles_TimeBasis        {Daily, Weekly, Monthly}
public enum ARC_MacroProfiles_ATRModeEnum      {Ticks,Points}
public enum ARC_MacroProfiles_PriceBarSetting  {Hide, BarsInFront, BarsBehind}
public enum ARC_MacroProfiles_GlobalRayScopes {TPOandVP, Remove, TPO, VP, Manual}
public enum ARC_MacroProfiles_GlobalRaysTypes {VAHandVAL, VAH, VAL}


//public enum ARC_MacroProfiles_TimeBasis{Minutes30, Hours1, Hours2, Hours4, Hours8, Hours12, Daily, Weekly, Monthly}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_MacroProfiles[] cacheARC_MacroProfiles;
		public ARC.ARC_MacroProfiles ARC_MacroProfiles()
		{
			return ARC_MacroProfiles(Input);
		}

		public ARC.ARC_MacroProfiles ARC_MacroProfiles(ISeries<double> input)
		{
			if (cacheARC_MacroProfiles != null)
				for (int idx = 0; idx < cacheARC_MacroProfiles.Length; idx++)
					if (cacheARC_MacroProfiles[idx] != null &&  cacheARC_MacroProfiles[idx].EqualsInput(input))
						return cacheARC_MacroProfiles[idx];
			return CacheIndicator<ARC.ARC_MacroProfiles>(new ARC.ARC_MacroProfiles(), input, ref cacheARC_MacroProfiles);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_MacroProfiles ARC_MacroProfiles()
		{
			return indicator.ARC_MacroProfiles(Input);
		}

		public Indicators.ARC.ARC_MacroProfiles ARC_MacroProfiles(ISeries<double> input )
		{
			return indicator.ARC_MacroProfiles(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_MacroProfiles ARC_MacroProfiles()
		{
			return indicator.ARC_MacroProfiles(Input);
		}

		public Indicators.ARC.ARC_MacroProfiles ARC_MacroProfiles(ISeries<double> input )
		{
			return indicator.ARC_MacroProfiles(input);
		}
	}
}

#endregion
