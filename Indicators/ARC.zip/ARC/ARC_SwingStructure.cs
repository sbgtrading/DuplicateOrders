#define DoLicense
#define MODERATORS
//#define ENABLE_CURRENTCURVE
//#define USE_WPF_COORDS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using System.Threading;
using System.Globalization;
using System.Linq;

using System.Windows.Automation;
using System.Windows.Controls;
//using System.Windows.Input;
using System.Windows;
#endregion

#region Author/Copyright
/*********************************************************************
****************************** NeuroStreet ***************************
**********************************************************************
* Author NT8 : Kriss { AzurITec } + Ben Letto {SBG Trading}
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##########################################################################################################################
--------------------------------------------------------------------------------------------------------------------------
v1.0    - Jun 12 2018  + Launch - StructureSwing code borrowed from GF_System_MTF, Curve drawing code from SDVolumeZones
--------------------------------------------------------------------------------------------------------------------------
v1.1    - Jul 13 2018  + Added "Show Midline" feature to 'StructureDetector Parameters'
					   + Fixed - was not printing all price/percent values on curve at 0 and 100
--------------------------------------------------------------------------------------------------------------------------
v1.2    - Jul 31 2018  + Bug fix to printing of midline
--------------------------------------------------------------------------------------------------------------------------
v1.3    - Sept 7 2018  + Added/enhanced support for MarketAnalyzer (PermissiveSignal, CurveState, StructureState)
                       + Removed "DisplayName"...it was preventing customization of MarketAnalyzer header info
--------------------------------------------------------------------------------------------------------------------------
v1.4    - Sept 13 2018 + Changed logic for current day DailyCurve.  See both code statements under "commented out for v1.4"
--------------------------------------------------------------------------------------------------------------------------
v1.5    - Oct 26 2018  + Added Aggressive Buy, Sell Permissive Signal types
--------------------------------------------------------------------------------------------------------------------------
v1.6    - Nov 20 2018  + Changed Structure Detector to a more comprehensive Sentiment triple box, for StructureBias, CurveState and Permission
--------------------------------------------------------------------------------------------------------------------------
v1.7    - March 1 2019 + Removed the public properties for "CurrentCurve".  The NinjaScript footer code ignores conditional compilation regions, thus making inaccurate NinjaScript footer code
--------------------------------------------------------------------------------------------------------------------------
v1.8    - Dec 10 2019  + Moved all Series<double> inits to the DataLoaded state, for compatibility with 8.0.20.0
--------------------------------------------------------------------------------------------------------------------------
		PermissiveSignal:
			CONSERVATIVE_UP   = 1
			CONSERVATIVE_DOWN = -1
			AGGRESSIVE_UP     = 2
			AGGRESSIVE_DOWN   = -2
		CurveState:
			Positive if above midline
			Negative if below midline
		StructureState:
			DOWN = -1
			NONE = 0
			UP = 1

*/
#endregion

#region -- Global Enums --
	public enum ARC_SwingPointConfluence_StructureQualifiers {OnTick, OnBarClose}
	public enum ARC_SwingPointConfluence_SentimentDetectionMode {OFF, OnClose, OnTick}
	public enum ARC_SwingPointConfluence_SentimentDialogLoc {TopRight, BottomRight, TopLeft, BottomLeft, Center}
	public enum ARC_SwingPointConfluence_CurveBasis {ATR_HL, Structure}
#endregion
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	#region -- Category Order --
	[CategoryOrder("Parameters",         10)]
	[CategoryOrder("Custom Visuals",     20)]
	[CategoryOrder("Indicator Version", 180)]
	#endregion

    public class ARC_SwingStructure : Indicator
    {
		private const int UP   = 1;
		private const int FLAT = 0;
		private const int DOWN = -1;

		private string OnStateChange_StatusMsg = string.Empty;
		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "SwingStructure";
		
		private string VERSION = "v1.5 3-Aug-22";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "25900", "21462", "27405"};//27405 is Annual Membership, PTMastermind and Solo indi
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsDebug = false;
//        public override string DisplayName { get { return "ARC_SwingStructure"; }}

		private int line = 0;
		private bool generalError = false;

		#region  ----- Variables for button interface ----- 
		private int pButtonSize = 15;
		private string toolbarname = "ARCSwStructTB", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;

		private Menu MenuControlContainer;
		private MenuItem MenuControl, miSelectedCurve;

		private MenuItem miRecalculate1;
		private TextBox tb_SwingStrength;
//		private Label gLabel;
//		private Button gCmdup, gCmddw;

		#endregion

        private int diff = 0;
//		SortedDictionary<double, int> AllLevels = new SortedDictionary<double, int>();
        private DashStyleHelper pDashStyle = DashStyleHelper.Solid;

//        private SimpleFont ButtonFont = new SimpleFont("Arial", 12) { Bold = true };

		#region ----------  UI button pulldown  ----------
		#region ----- ChangeTextBoxValue -----
		private void ChangeTextValue(string Name, string Value, double Delta){
line=513;
try{
			Value = Value.Replace("-",string.Empty).Trim();//no negative values allowed
			double incr = 0;
			if(!double.IsNaN(Delta)) {
				incr = Delta > 0 ? 1 : (Delta < 0 ? -1 : 0);
			}
line=520;
			//Print("Name: "+Name);
			if (Value.Length > 0)
			{
				if (Name.StartsWith("tb_SwingStrength")) {
line=524;
					Value = Value.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
					if(incr!=0){
						SwingStrength = Math.Max(1,Math.Min(200,Convert.ToInt32(Value) + (int)incr));
						tb_SwingStrength.Text = SwingStrength.ToString();
					}else
						tb_SwingStrength.Text = Value;
					if(!double.IsNaN(Delta))
						this.InformUserAboutRecalculation();
				}
line=640;
			}
}catch(Exception e){Print(line+": "+e.ToString());}
		}
		#endregion
		#region ----- MouseWheelEvent -----
        private void MouseWheelEvent(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
			TextBox txtSender = sender as TextBox;
			string intxt = txtSender.Text;
			ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 1 : -1);
        }
		#endregion
		#region  ----- createMktStructure_Menu ----- 
        private Grid createMktStructure_Menu(string tb_Value, string tb_ATRPeriodValue, string tb_ATRMultValue)
        {
			const int rHeight = 26;

			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });

			int row = 0;
			//line 1 - SwingStrength
			#region ----- SwingStrength -----
			Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Swing Strength: " };
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 2);

			tb_SwingStrength = new TextBox() { Name = "tb_SwingStrength" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0)};
			tb_SwingStrength.Text = tb_Value;
			tb_SwingStrength.MouseWheel += MouseWheelEvent;
			tb_SwingStrength.KeyDown += menuTxtbox_KeyDown;
//			tb_SwingStrength.TextChanged += NumericValueChanged;
			tb_SwingStrength.SetValue(Grid.ColumnProperty, 1);
			tb_SwingStrength.SetValue(Grid.RowProperty, row);
			tb_SwingStrength.SetValue(Grid.RowSpanProperty, 2);
			grid.Children.Add(lbl1);
            grid.Children.Add(tb_SwingStrength);
			#endregion

            return grid;
        }
		#endregion

		#region  ----- menuTxtbox_KeyDown ----- 
		private void menuTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			e.Handled = true;
			TextBox txtSender = sender as TextBox;
			int keyVal = (int)e.Key;

			int value = -1;
			if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
				value = keyVal - (int)System.Windows.Input.Key.D0;
			else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
				value = keyVal - (int)System.Windows.Input.Key.NumPad0;

			bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.Decimal;
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.OemPeriod;
			if (isNumeric || e.Key == System.Windows.Input.Key.Back)
			{
				string newText = value != -1 ? value.ToString() : "";
				if(!txtSender.Text.Contains(".")){
					if(e.Key==System.Windows.Input.Key.Decimal) newText = ".";
					else if(e.Key==System.Windows.Input.Key.OemPeriod) newText = ".";
				}
				int tbPosition = txtSender.SelectionStart;
				try{
					if(txtSender.SelectedText.Length==0)
						txtSender.Text = txtSender.Text.Insert(tbPosition, newText);
					else
						txtSender.Text.Replace(txtSender.SelectedText, newText);
				}catch(Exception t){Print(t.ToString());}
				txtSender.Select(tbPosition + 1, 0);
			}
			ChangeTextValue(txtSender.Name, txtSender.Text, 0);
		}
		#endregion

        #region  ----- structureMenuItem_Click ----- 
        private void structureMenuItem_Click(object sender, EventArgs e)
        {
			MenuItem item = sender as MenuItem;
            #region -- showMarketSwingsClick --
            if (item.Name.Contains( "miMarketSwingLines"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.ShowSwingLines = false;
                    item.Header     = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                }
                else
                {
                    this.ShowSwingLines = true;
                    item.Header     = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
            #endregion
            #region -- miShowSwingLabels --
            else if (item.Name.Contains( "miShowSwingLabels"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.ShowSwingLabels = false;
                    item.Header     = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                }
                else
                {
                    this.ShowSwingLabels = true;
                    item.Header     = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
			#endregion
			ChartControl.InvalidateVisual();
        }
        #endregion

        #region  ----- NumericValueChanged ----- 
		private string currentTextEdit;
		private void NumericValueChanged(object sender, TextChangedEventArgs e)
		{
//			TextBox txtSender = sender as TextBox;
//			string intxt = txtSender.Text;
//			intxt = intxt.Replace("-",string.Empty);
//			intxt = intxt.Trim();
//			if (intxt.Length > 0)
//			{
//				if (txtSender.Name.Contains("tb_SwingStrength")) {
//					intxt = intxt.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
//					SwingStrength = Math.Max(1,Math.Min(200,Convert.ToInt32(intxt)));
//					txtSender.Text = SwingStrength.ToString();
//					this.InformUserAboutRecalculation();
//				}
//				else if (txtSender.Name.Contains("tb_QualifyingATRperiod")) {
//					intxt = intxt.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
//					int num = Math.Max(1,Math.Min(100,Convert.ToInt32(intxt)));
//					this.QualifyingATRperiod   = num;
//					txtSender.Text   = num.ToString();
//				}
//				else if (txtSender.Name.Contains("Changetb_QualifyingATRmult")) {
//					double num = Math.Max(0,Math.Min(200,Convert.ToDouble(intxt)));
//					this.QualifyingATRmult   = num;
//					txtSender.Text   = num.ToString();
//				}
//				else if (txtSender.Name.StartsWith("TradePlan_EntryAreaSize")) {
//					double num = Convert.ToDouble(intxt);
//					bool isInRange = num>=0.0 && num<=3;
//					if(isInRange){
//						if(num>0.01 && num<=3) this.EntryAreaSize_inATRs = num;
//						txtSender.Text            = intxt;
//						ParameterChanged          = true;
//			            ChartControl.InvalidateVisual();
//					}
//				}
//				else if (txtSender.Name.StartsWith("TradePlan_SLsize")) {
//					double num = Convert.ToDouble(intxt);
//					bool isInRange = num>=0.0 && num<=100;
//					if(isInRange){
//						this.SLsize_inATRs = num;
//						txtSender.Text     = intxt;
//						ParameterChanged   = true;
//			            ChartControl.InvalidateVisual();
//					}
//				}
//				else if (txtSender.Name.StartsWith("TradePlan_T1size")){
//					double num = Convert.ToDouble(intxt);
//					bool isInRange = num>=0.0 && num<=100;
//					if(isInRange){
//						this.PT1size_inSLs = num;
//						txtSender.Text      = intxt;
//						ParameterChanged    = true;
//			            ChartControl.InvalidateVisual();
//					}
//				}
//				else if (txtSender.Name.StartsWith("TradePlan_T2size")){
//					double num = Convert.ToDouble(intxt);
//					bool isInRange = num>=0.0 && num<=100;
//					if(isInRange){
//						this.PT2size_inSLs = num;
//						txtSender.Text      = intxt;
//						ParameterChanged    = true;
//			            ChartControl.InvalidateVisual();
//					}
//				}
//			}
		}
		#endregion

//=====================================================================================================
		private void InformUserAboutRecalculation(){
			if(miRecalculate1!=null){
				miRecalculate1.Background = Brushes.Yellow;
				miRecalculate1.FontWeight = FontWeights.Bold;
				miRecalculate1.FontStyle  = FontStyles.Italic;
			}
		}
		private void ResetRecalculationUI(){
			if(miRecalculate1!=null){
				miRecalculate1.FontWeight = FontWeights.Normal;
				miRecalculate1.FontStyle  = FontStyles.Normal;
				miRecalculate1.Background = null;
			}
		}
		#region  ----- addToolBar ----- 
		private void addToolBar()
		{
			MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
			MenuControl          = new MenuItem { Name="ARC_STB"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Pink, Header = pButtonText, Foreground = Brushes.Pink, Background = Brushes.Maroon, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);

			MenuControl.Items.Add(new Separator());

			#region -- RegMarketSwings --
			MenuItem miMarketSwings = new MenuItem { Header = "Market Swings", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miMarketSwingLines = new MenuItem { Header = ShowSwingLines ? "Swing Lines ON" : "Swing Lines OFF", Name = "miMarketSwingLines"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(!ShowSwingLines) miMarketSwingLines.FontWeight = FontWeights.Light;
			miMarketSwingLines.Click += structureMenuItem_Click;
			miMarketSwings.Items.Add(miMarketSwingLines);

			MenuItem miShowSwingLabels = new MenuItem { Header = ShowSwingLabels ? "Swing Labels ON" : "Swing Labels OFF", Name = "miShowSwingLabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(!ShowSwingLabels) miShowSwingLabels.FontWeight = FontWeights.Light;
			miShowSwingLabels.Click += structureMenuItem_Click;
			miMarketSwings.Items.Add(miShowSwingLabels);

			miMarketSwings.Items.Add(new Separator());
			miMarketSwings.Items.Add(createMktStructure_Menu(this.SwingStrength.ToString(), "", ""));
	//- - - - - - - - - - - - - 
			#region -- Recalc --
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", Name = "btn_Recalc1"+uID, HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				this.SwingStrength       = Math.Max(1,Math.Min(200,Convert.ToInt32(tb_SwingStrength.Text)));
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			miMarketSwings.Items.Add(miRecalculate1);
			#endregion
			//------------------

			#endregion
			MenuControl.Items.Add(miMarketSwings);

			indytoolbar.Children.Add(MenuControlContainer);
		}
		#endregion
		#endregion

		private StructureBiasClass StructureMgr = null;
		private class StructureBiasClass {
			private const double UP = 1;
			private const double DOWN = -1;
			#region  ----- StructureBias class ----- 
			public SortedDictionary<int,double[]>	AllPivots     = new SortedDictionary<int,double[]>();//one record for each pivot bar.  The first double is the initial swing price, and if there's a final swing price on that bar, the 2nd double will hold that price
			//public SortedDictionary<int,byte>	Bias = new SortedDictionary<int,byte>();
			public int    SwingStrength = 0;
			public bool   isHLBased     = false;
			public double ExtentOfMove = double.NaN;
			public bool   CalculateOnBarClose = false;
			public string StatusMsg = string.Empty;
			public bool z=false;

			#region  ----- properties ----- 
			public SortedDictionary<int, char> Trend = new SortedDictionary<int,char>();
			private NinjaTrader.NinjaScript.IndicatorBase Parent;
			private bool updateHigh=false;
			private bool updateLow=false;
			private bool addHigh=false;
			private bool addLow=false;
			private int offset = 0;
			private ISeries<double> High;
			private ISeries<double> Low;
//			private ISeries<double> Close;
			#endregion

			private double MAX(ISeries<double> series, int lookback, int rbar_offset){
				double max = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) {
						if(i>=series.Count) return max;
						max = Math.Max(max, series[i]);
					}
				}catch{}
				return max;
			}
			private double MIN(ISeries<double> series, int lookback, int rbar_offset){
				double min = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) {
						if(i>=series.Count) return min;
						min = Math.Min(min, series[i]);
					}
				}catch{}
				return min;
			}
			public void AddToAllPivots(int idx, char current_trend, char new_trend, double price1, double price2=double.NaN){
				bool IsOutsideBar = double.IsNaN(price2)==false;
				bool IsPriorBarOutside = AllPivots.Count>0 && double.IsNaN(AllPivots.Last().Value[2])==false;//if the prior bar was an outside bar
				double priorleadprice = IsPriorBarOutside ? AllPivots.Last().Value[2] : AllPivots.Last().Value[1];
				double newleadprice = IsOutsideBar ? price2 : price1;
if(z) Parent.Print("AddToAllPivots:   current_trend: "+current_trend+"  new_trend: "+new_trend);

//if(z) Parent.Print("a AddToAllPivots:   priorleadprice: "+priorleadprice+"  new leadprice: "+newleadprice);
				if(current_trend=='u' && new_trend=='u'){
// TREND CONTINUATION conditions
					if(!IsOutsideBar && newleadprice < priorleadprice) return;//outside bars are interior trend reversals, you must respect the lower low
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("b AddToAllPivots:   PriorBarOutside and current bar outside - adding new swing bar UP");
						AllPivots[idx] = new double[]{UP, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("c AddToAllPivots:   not PriorBarOutside and current bar outside - adding new swing bar UP");
						AllPivots[idx] = new double[]{UP, price1, price2};
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
if(z) Parent.Print("d AddToAllPivots:   not PriorBarOutside and not current bar outside - removing prior swing bar, adding new swing bar UP");
						var remove_idx = AllPivots.Keys.Max();
						AllPivots.Remove(remove_idx);//a trend continuation is taking place, the prior bar is no longer the max extent of the original trend...so remove it
//						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[idx] = new double[]{UP, price1, price2};
					}else if(IsPriorBarOutside && !IsOutsideBar){
if(z) Parent.Print("e AddToAllPivots:   PriorBarOutside and not current bar outside - update prior swing bar leading price, adding new swing bar UP");
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[idx] = new double[]{UP, price1, price2};
					}
					else{
if(z) Parent.Print("f AddToAllPivots:   else - update prior swing bar leading price, adding new swing bar UP");
						AllPivots[idx] = new double[]{UP, price1, price2};
					}

				}else if(current_trend=='d' && new_trend=='d'){
// TREND CONTINUATION conditions
					if(!IsOutsideBar && newleadprice > priorleadprice) return;//outside bars are interior trend reversals, you must respect the higher high
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("b AddToAllPivots:   PriorBarOutside and current bar outside - adding new swing bar DOWN");
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("c AddToAllPivots:   not PriorBarOutside and current bar outside - adding new swing bar DOWN");
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
if(z) Parent.Print("d AddToAllPivots:   not PriorBarOutside and not current bar outside - removing prior swing bar, adding new swing bar DOWN");
						var remove_idx = AllPivots.Keys.Max();
						AllPivots.Remove(remove_idx);//a trend continuation is taking place, the prior bar is no longer the max extent of the original trend...so remove it
//						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
					else if(IsPriorBarOutside && !IsOutsideBar){
if(z) Parent.Print("e AddToAllPivots:   PriorBarOutside and not current bar outside - update prior swing bar leading price, adding new swing bar DOWN");
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
					else{
if(z) Parent.Print("f AddToAllPivots:   else - update prior swing bar leading price, adding new swing bar DOWN");
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
				}else if(current_trend=='d' && new_trend=='u'){//trend reversal occurred from down to up
// TREND REVERSAL conditions
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("ud w AddToAllPivots:   PriorBarOutside and current bar outside - blank out prior ending price, adding new swing bar UP");
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a lower low trend extending price is found on this new outside bar
						AllPivots[idx] = new double[]{UP, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
						if(price1 <= priorleadprice){
if(z) Parent.Print("du x AddToAllPivots:   Not PriorBarOutside and current bar outside, yes new low made - adding new swing bar UP");
							var remove_idx = AllPivots.Keys.Max();
							AllPivots.Remove(remove_idx);
							AllPivots[idx] = new double[]{UP, price1, price2};
						}else{
if(z) Parent.Print("du x AddToAllPivots:   Not PriorBarOutside and current bar outside, no new low made - ignoring low of current outside bar, adding new swing bar DOWN");
							AllPivots[idx] = new double[]{UP, price2, double.NaN};
						}
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
						AllPivots[idx] = new double[]{UP, price1, price2};
					}else
						AllPivots[idx] = new double[]{UP, price1, price2};

				}else if(current_trend=='u' && new_trend=='d'){//trend reversal occurred from up to down
// TREND REVERSAL conditions
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("ud w AddToAllPivots:   PriorBarOutside and current bar outside - blank out prior ending price, adding new swing bar DOWN");
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher high trend extending price is found on this new outside bar
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
						if(price1 >= priorleadprice){
if(z) Parent.Print("ud x AddToAllPivots:   Not PriorBarOutside and current bar outside, yes new high made - adding new swing bar DOWN");
							var remove_idx = AllPivots.Keys.Max();
							AllPivots.Remove(remove_idx);//a trend reversal is taking place on an outside bar, the prior bar is no longer the max extent of the original trend...so remove it
							AllPivots[idx] = new double[]{DOWN, price1, price2};
						}else{
if(z) Parent.Print("ud x AddToAllPivots:   Not PriorBarOutside and current bar outside, no new high made - ignoring high of current outside bar, adding new swing bar DOWN");
							AllPivots[idx] = new double[]{DOWN, price2, double.NaN};
						}
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
if(z) Parent.Print("ud y AddToAllPivots:   Not PriorBarOutside and Not current bar outside - adding new swing bar DOWN");
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}else{
if(z) Parent.Print("ud z AddToAllPivots:   else - adding new swing bar DOWN");
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
if(z) Parent.Print("AddToAllPivots:   New low is put in...deleted the prior swing point, added a new point");
				}
//				var AllPivotsKeys  = new List<int>(AllPivots.Keys);
//				AllPivotsKeys.Reverse();
//				#region Clean up swings when consecutive swings are lows or highs
//				if(false && AllPivots.Count>4){
//					var keysToRemove = new List<int>();
//					if(Trend[idx] == Trend[idx-1]){
//						keysToRemove.Add(idx-1);
//					}
////					for(int i =0; i<3; i++){
////						if(AllPivots[AllPivotsKeys[i]] < 0 && AllPivots[AllPivotsKeys[i+1]] < 0)
////							keysToRemove.Add(AllPivotsKeys[i+1]);
////						else if(AllPivots[AllPivotsKeys[i]] > 0 && AllPivots[AllPivotsKeys[i+1]] > 0)
////							keysToRemove.Add(AllPivotsKeys[i+1]);
////					}
//					if(keysToRemove.Count>0){
//						foreach(int key in keysToRemove){
//							if(AllPivots.ContainsKey(key)) AllPivots.Remove(key);
//						}
////						AllPivotsKeys  = new List<int>(AllPivots.Keys);
////						AllPivotsKeys.Reverse();
//					}
//				}
//				#endregion
//				IsRising = price<0;//if we put in a new swing low, then structure is rising, a new swing high means structure is falling
			}
			public StructureBiasClass(ISeries<double> high, ISeries<double> low, int swingStrength, bool is_hlBased, bool calcOnBarClose, NinjaTrader.NinjaScript.IndicatorBase parent){
				High = high;
				Low = low;
				SwingStrength = swingStrength;
				isHLBased = isHLBased; 
				CalculateOnBarClose = calcOnBarClose; 
				offset = calcOnBarClose ? 0 : 1;
				High   = high; Low = low;
				Parent = parent;
			}


			public void CalculateIt(int CurrentBar, bool IsUpClosing, bool IsFirstTickOfBar, NinjaTrader.NinjaScript.Calculate Calculate, NinjaTrader.NinjaScript.State State, double? atr256=0){
				int bar  = CurrentBar-offset;
if(z) Parent.Print(Parent.Time.GetValueAt(CurrentBar).ToString()+"  CalculateIt");
				if(Trend.Count==0){
					if(High[offset]>High[offset+1])    {Trend[bar] ='u'; AllPivots.Add(bar, new double[3]{UP, High[offset], double.NaN}); ExtentOfMove=High[offset];}
					else if(Low[offset]<Low[offset+1]) {Trend[bar] ='d'; AllPivots.Add(bar, new double[3]{DOWN, Low[offset],double.NaN}); ExtentOfMove=Low[offset];}
					return;
				}

				double H = MAX(High, SwingStrength, offset+1);
				double L = MIN(Low,  SwingStrength, offset+1);
				if(High[offset]>H && Low[offset]<L)	Trend[bar] ='?';//this is an outside bar...meaning the trend reversal occurs on the same bar
				else if(High[offset]>H)				Trend[bar] ='u';
				else if(Low[offset]<L)				Trend[bar] ='d';
				else								Trend[bar] = Trend[bar-1];
if(z) Parent.Print("  Trend: "+Trend[bar]);
int line = 1204;
				int i = 1;
				char current_trend = Trend[bar-i];
				if(Trend[bar] == '?'){
					if(IsUpClosing){//an upclosing outside bar
						Trend[bar] = 'u';
						if(Trend[bar-i] == 'u'){//if the most recent trend was Up
							AddToAllPivots(bar, 'u', 'u', Low[offset], High[offset]);//in an uptrend, the outside bar reversal down is first, and the upward finish is second
						}else{//existing trend was down
							AddToAllPivots(bar, 'd', 'u', Low[offset], High[offset]);//in a downtrend, the down move continued, and the upward finish is second
						}
					}else{//a downclosing outside bar
						Trend[bar] = 'd';
						if(Trend[bar-i] == 'd'){//if the most recent trend was Down
							AddToAllPivots(bar, 'd', 'd', High[offset], Low[offset]);//in a downtrend, the outside bar reversal up is first, and the downward finish is second
						}else{//existing trend was up
							AddToAllPivots(bar, 'u', 'd', High[offset], Low[offset]);//in an uptrend, the up move continued, and the downward finish is second
						}
					}
//}catch(Exception ee){parent.Print(line+":  "+ee.ToString());}
				}
				else if(Trend[bar] == 'u'){
					AddToAllPivots(bar, current_trend, 'u', High[offset]);
				}
				else if(Trend[bar] == 'd'){
					AddToAllPivots(bar, current_trend, 'd', Low[offset]);
				}
				
				}

			//================================================================================================
			public void UpdateSessionDate(DateTime t, double high, double low, SessionIterator sessionIterator0){
//				DateTime currentDate = SessionDate.Date;
//				if(sessionIterator0 == null)
//					SessionDate = t.Date;
//				else if(sessionIterator0.IsNewSession(t, true)) {
//					sessionIterator0.CalculateTradingDay(t, true);
//					SessionDate = sessionIterator0.ActualTradingDayExchange.Date;
//				}
			}
			#endregion
		}

		//private double currentHigh = 0, currentLow=0, priorDayHigh=0, priorDayLow=0;
//		private ATR atr;


        protected override void OnStateChange()
        {
line = 3234;
			#region  ----- OnStateChange ----- 
try{
			OnStateChange_StatusMsg = string.Empty;
            #region ----- State == State.SetDefaults -----
            if (State == State.SetDefaults)
            {
				PrintTo = PrintTo.OutputTab1;
				Description             = @"";
				Name                    = "ARC_SwingStructure";
				Calculate               = Calculate.OnBarClose;
				IsOverlay               = true;
				PaintPriceMarkers       = false;
				DisplayInDataBox        = true;
				IsAutoScale             = false;
				ArePlotsConfigurable    = true;
				ZOrder                  = 0;
				DrawOnPricePanel        = true;
				ScaleJustification      = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive = false;

				IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
				IsDebug = IsDebug && (NinjaTrader.Cbi.License.MachineId.CompareTo("CB15E08BE30BC80628CFF6010471FA2A")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);

				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
				#region ----- SMC_Swing Defaults -----
				SwingStrength = 1;
				isHLBased     = true;
				ShowSwingLines  = true;
				UpLineColor   = Brushes.DarkGreen;
				DownLineColor = Brushes.Red;
				ZZLineThickness = 2;
				//pSwingLabelFontSize = 12;
				pZZlabelFont = new SimpleFont("Arial",12);
				ShowSwingLabels = false;
				#endregion

				pButtonText = "SMC Swing";

                #region -- Indicator Display --
                //iButtonSize = 13;
                //iButtonTextSize = 10;
                #endregion

            }
            #endregion

            #region ----- State == State.Configure ----- 
            if (State == State.Configure)
            {
				SetZOrder(int.MaxValue-1);
				Calculate = Calculate.OnBarClose;
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
#endif
			}
            #endregion

line = 3153;
            #region  ----- State == State.Historical ----- 
            if (State == State.Historical)
            {
//                sessionIterator0 = new SessionIterator(BarsArray[0]);
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;
                        
                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

                            addToolBar();
                            
                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion
            }
            #endregion

            #region  ----- State == State.DataLoaded ----- 
            if (State == State.DataLoaded)
            {
//ClearOutputWindow();
				//atr = ATR(256);
				StructureMgr = new StructureBiasClass(Highs[0], Lows[0], SwingStrength, isHLBased, Calculate==Calculate.OnBarClose, this);
            }
            #endregion

            #region  ----- State == State.Realtime ----- 
            if (State == State.Realtime)
            {
            }
            #endregion
			
            #region  ----- State == State.Terminated ----- 
            if(State == State.Terminated)
            {
line=3066;
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
            }
            #endregion
}catch(Exception e){
	OnStateChange_StatusMsg = string.Format("{0}:  OnStateChange: \n{1}", line, e.ToString());
	Print(OnStateChange_StatusMsg);
	Draw.TextFixed(this,"InitError","ARC_SwingStructure\n\nError during initialization...are you connected to your active datafeed?\n\nSee OutputWindow for more details", TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Maroon,Brushes.Maroon,80);
}
            #endregion
        }
		//====================================================
		#region  ----- TabSelectionChangedHandler ----- 
		private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}
		#endregion

		protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(BarsInProgress == 0 && CurrentBar>3){
//int startabar = Bars.GetBar(new DateTime(2022,7,19,16,50,0));
//int endabar = Bars.GetBar(new DateTime(2022,7,19,18,40,0));
//StructureMgr.z = CurrentBar>startabar && CurrentBar<endabar;

				bool IsUpClosing = High[0]-Close[0] < Close[0]-Low[0];//if the close is nearer to the high, then it's an upclosing bar
//if(StructureMgr.z)Print("-----------------------   "+Time[0].ToString());
				StructureMgr.CalculateIt(CurrentBar, IsUpClosing, IsFirstTickOfBar, Calculate, State);
//if(!double.IsNaN(StructureMgr.ExtentOfMove)) Draw.Dot(this,CurrentBars[0].ToString(),false,0,StructureMgr.ExtentOfMove,Brushes.White);

//if(StructureMgr.z){
//	var pivots = StructureMgr.AllPivots.Where(x=>x.Key > startabar && x.Key<endabar);
//	foreach(var k in pivots){
//		Print(Times[0].GetValueAt(k.Key).ToString()+"   "+(k.Value[0]>0?"UP":"DN")+"   "+(k.Value[1]).ToString()+"   "+(k.Value[2]).ToString());
//	}
//}
			}
			//StructureMgr.UpdateSessionDate(Time[0], High[0], Low[0], null);

        }

		private SharpDX.Direct2D1.Brush lineBrushUp, lineBrushDown;
        public override void OnRenderTargetChanged()
        {
			if(lineBrushUp!=null   && !lineBrushUp.IsDisposed)   {lineBrushUp.Dispose();   lineBrushUp=null;}
			if(lineBrushDown!=null && !lineBrushDown.IsDisposed) {lineBrushDown.Dispose(); lineBrushDown=null;}
			if(RenderTarget!=null) lineBrushUp = this.UpLineColor.ToDxBrush(RenderTarget);
			if(RenderTarget!=null) lineBrushDown = this.DownLineColor.ToDxBrush(RenderTarget);
		}

//=======================================================================================================================
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
            #region -- conditions to return --
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (Bars == null || ChartControl == null) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
			if (IsInHitTest) return;
            #endregion
line=1572;

			#region -- draw structure --            
			if (ShowSwingLines)
			{
				int rmab = BarsArray[0].GetBar(Times[0].GetValueAt(Math.Min(BarsArray[0].Count-1,ChartBars.ToIndex)));
				if(rmab==BarsArray[0].Count-1 && Calculate == Calculate.OnBarClose) rmab = rmab-1;

				int x1 = 0;
				int y1 = 0;
				int x2 = 0;
				int y2 = 0;
			    RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

				if (rmab >= 2 && StructureMgr.AllPivots.Count>0){
					var SwingLabelBrush = ' ';//fillbrush;
					var keys = new System.Collections.Generic.List<int>(StructureMgr.AllPivots.Keys);
				    int j = keys.Count-1;
					double swingprice2 = Closes[0].GetValueAt(1);
					double swingprice1 = Closes[0].GetValueAt(1);
					double swingpriceOB = 0;  //swing price of an outside bar
					float vTextOffset = 0;
					int swingABar1 = 1;
				    while (j > 0) { 
						j = j - 1;
						if(keys[j] < ChartBars.FromIndex-1) {
							swingABar1 = keys[j];
							swingpriceOB = StructureMgr.AllPivots[swingABar1][2];
							if(!double.IsNaN(swingprice2))
								swingprice1 = swingpriceOB;//swingprice2 contains the last swing price of an outside bar
							else
								swingprice1 = StructureMgr.AllPivots[swingABar1][1];//that bar is a normal (non-outsidebar), therefore the last swing price of that swing bar is in element [1]
							break;
						}
					}//j is now the index of the first swing point prior to the left-most bar on the chart
//try{
					var lineBrush = 'u';
					string zzId0 = "";
					int swingABar0 = keys[j];
					double priorH = StructureMgr.AllPivots[swingABar0][1];
					double priorL = StructureMgr.AllPivots[swingABar0][1];
					if(!double.IsNaN(StructureMgr.AllPivots[swingABar0][2])){
						priorL = StructureMgr.AllPivots[swingABar0][2];
						if(priorH < priorL){
							double temp = priorH;
							priorH = priorL;
							priorL = temp;
						}
					}
					double OB_High = 0;//high price of an outside bar
					double OB_Low = 0;//low price of an outside bar
                    for (int i = j; i<keys.Count && keys[i] <= Bars.Count; i++)
                    {
						swingABar0 = keys[i];
						x1 = ChartControl.GetXByBarIndex(ChartBars, swingABar0);
						x2 = ChartControl.GetXByBarIndex(ChartBars, swingABar1);

						double swingprice = StructureMgr.AllPivots[swingABar0][1];
						swingpriceOB = StructureMgr.AllPivots[swingABar0][2];//Outside Bar swing price at the close of the bar
						bool IsOutsideBar = !double.IsNaN(swingpriceOB);
						if(IsOutsideBar){
							OB_High = Math.Max(swingprice, swingpriceOB);
							OB_Low = Math.Min(swingprice, swingpriceOB);
							y1 = chartScale.GetYByValue(swingprice);
							y2 = chartScale.GetYByValue(swingprice1);
							drawLine(x1, x2, y1, y2, (swingprice1 < swingprice ? lineBrushUp : lineBrushDown), DashStyleHelper.Solid, ZZLineThickness);
							y1 = chartScale.GetYByValue(swingpriceOB);
							y2 = chartScale.GetYByValue(swingprice);
							drawLine(x1, x1, y1, y2, (swingpriceOB > swingprice ? lineBrushUp : lineBrushDown), DashStyleHelper.Solid, ZZLineThickness);
							swingprice = swingpriceOB;
						}else{
							if(swingprice1 > swingprice){//a down swing
								lineBrush = 'd';
							}else{
								lineBrush = 'u';
							}

							y1 = chartScale.GetYByValue(swingprice);
							y2 = chartScale.GetYByValue(swingprice1);

							drawLine(x1, x2, y1, y2, (lineBrush=='u' ? lineBrushUp : lineBrushDown), DashStyleHelper.Solid, ZZLineThickness);
							swingprice1 = swingprice;
						}

						if (ShowSwingLabels){
//try{
							float[] SZ  = getTextHeightAndWidth(zzId0, pZZlabelFont);
							if(!IsOutsideBar){
						    	if (lineBrush == 'u'){
									SwingLabelBrush = 'u';
									vTextOffset = -SZ[0] -3f;
									if(swingprice > priorH) zzId0 = "HH";
									else if(swingprice < priorH) zzId0 = "LH";
									else zzId0 = "DT";
									priorH = swingprice;
								} else {
									SwingLabelBrush = 'd';
									vTextOffset = 3f;
									if(swingprice < priorL) zzId0 = "LL";
									else if(swingprice > priorL) zzId0 = "HL";
									else zzId0 = "DB";
									priorL = swingprice;
								}
//Print("SZ[0]: "+SZ[0]+"  SZ[1]: "+SZ[1]);
							    drawString(zzId0, x1 - SZ[1] / 2, y1 + vTextOffset, pZZlabelFont, (SwingLabelBrush=='u' ? lineBrushUp : lineBrushDown), SharpDX.DirectWrite.TextAlignment.Center);                                            
							}else{//need to draw 2 labels on an outside bar
								SwingLabelBrush = 'u';
								zzId0 = "HH";
								if(OB_High == priorH) zzId0 = "DT";
								else if(OB_High < priorH) zzId0 = "LH";
								priorH = OB_High;
								vTextOffset = -SZ[0] -3f;
							    drawString(zzId0, x1 - SZ[1] / 2, Math.Min(y1,y2) + vTextOffset, pZZlabelFont, (SwingLabelBrush=='u' ? lineBrushUp : lineBrushDown), SharpDX.DirectWrite.TextAlignment.Center);                                            

								SwingLabelBrush = 'd';
								vTextOffset = 3f;
								zzId0 = "LL";
								if(OB_Low == priorL) zzId0 = "DB";
								else if(OB_Low > priorL) zzId0 = "HL";
								priorL = OB_Low;
							    drawString(zzId0, x1 - SZ[1] / 2, Math.Max(y1,y2) + vTextOffset, pZZlabelFont, (SwingLabelBrush=='u' ? lineBrushUp : lineBrushDown), SharpDX.DirectWrite.TextAlignment.Center);                                            
							}
//}catch(Exception onr){Print("OnRender: "+onr.ToString());}
						}
						if(swingABar0 > rmab) break;
						swingprice2 = swingprice1;
						swingprice1 = swingprice;
						swingABar1  = swingABar0;
					}
//}catch(Exception eee){Print(line+"  Error: "+eee.ToString());}
				}
				RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
			}
			#endregion
		}


		#region supporting code
		//set the color to Black or White depending on background color
		public Brush ContrastingColor(SolidColorBrush background)
		{
		    // Counting the perceptive luminance - human eye favors green color... 
		    double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
		    if (a < 0.5) return Brushes.Black; // bright colors - black font
		    else return Brushes.White; // dark colors - white font
		}

		private float[] getTextHeightAndWidth(string text, SimpleFont font){
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			float[] result = new float[2]{(float)font.Size, textLayout.Metrics.Width};

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return result;
		}
		private float getTextWidth(string text, SimpleFont font)
		{
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

		    float textwidth = textLayout.Metrics.Width;

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return textwidth;
		}
		private float getTextHeight(string text, SimpleFont font)
		{
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

		    float textheight = textLayout.Metrics.Height;

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return textheight;
		}
		#region drawstring
		//Draw a text at {x;y} coordinates in pixel.
		private void drawString(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxTextWidth = -9999f)
		{
		    SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        ) { TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, MaxTextWidth <= 0f ? getTextWidth(text, font) : MaxTextWidth, float.MaxValue);

		    RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

		    textLayout.Dispose();
		    textFormat.Dispose();
		}
		private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.Direct2D1.Brush bkgBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxTextWidth = -9999f, float MaxX = -9999f)
		{
			#region drawstring
			if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
			SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();

			var textFormat = new SharpDX.DirectWrite.TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
			)
				{ TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, (MaxTextWidth>0 ? MaxTextWidth : ChartPanel.W/3), ChartPanel.H);
			if(x<0) x = Math.Abs(x) - textLayout.Metrics.Width - 5;

			if(MaxX>0)
				x = Math.Min(x, MaxX - 3f - textLayout.Metrics.Width);

			y = y - textLayout.Metrics.Height/2.0;
			if (bkgBrush!=null && bkgBrush.Opacity>0) {
				double xl = x - 3;
				double xr = x + textLayout.Metrics.Width + 3;
				double yt = y - 1;
				double yb = y+textLayout.Metrics.Height + 2;
				if(textAlignment==SharpDX.DirectWrite.TextAlignment.Trailing){
					xr = x + textLayout.Metrics.LayoutWidth +3;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				else if(textAlignment==SharpDX.DirectWrite.TextAlignment.Center){
					xr = x + textLayout.Metrics.LayoutWidth/2 + 3 + textLayout.Metrics.Width/2;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				var bkgBox = new System.Windows.Point[]
				{	new System.Windows.Point(xl, yt),
					new System.Windows.Point(xl, yb),
					new System.Windows.Point(xr, yb),
					new System.Windows.Point(xr, yt),
				};
				drawRegion(bkgBox, bkgBrush);
			}
			RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			textLayout.Dispose();
			textFormat.Dispose();
			#endregion
		}
		#endregion

		private void drawLine(double x1, double x2, double y1, double y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle = DashStyleHelper.Solid, int width = 1, int opacity = 100)
		{
		    dxbrush.Opacity = opacity / 100f;
		    SharpDX.Direct2D1.DashStyle _dashstyle;
		    if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

		    SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
		    SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

		    RenderTarget.DrawLine(new SharpDX.Vector2((float)x1,(float)y1), new SharpDX.Vector2((float)x2,(float)y2), dxbrush, width, strokestyle);

		    strokestyle.Dispose();
		}
		
        //Draw Region. Rect in pixel coordinate.
        private void drawRegion(Rect rectangle, SharpDX.Direct2D1.Brush color)//, int opacity = 100)
        {
            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, color);
        }
        //Draw Region. x and y as pixel coordinate, w and h in pixel too.
        private void drawRegion(double x, double y, double w, double h, SharpDX.Direct2D1.Brush color)
        {
            drawRegion(
				new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, 
				color);
        }
		private void drawRegion(System.Windows.Point[] points, SharpDX.Direct2D1.Brush dxbrush)
		{
		    SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

		    SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
		    SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
		    sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
		    sink1.AddLines(vectors);
		    sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
		    sink1.Close();

		    RenderTarget.FillGeometry(geo1, dxbrush);
		    geo1.Dispose();
		    sink1.Dispose();
		}

		//Draw a line between 2 points. 'x1' and 'x2' are pixel locations, the y value is the numerical value (ie price / oscillator value)
		private void drawLine(double val1, double val2, float x1, float x2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = true)
		{
			if(double.IsNaN(val1) || double.IsNaN(val2)) {Print("Val is NaN"); return;}
			//SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.DashStyle _dashstyle;
			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

			SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
			SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

			SharpDX.Vector2 v1 = new SharpDX.Vector2(x1, drawOnPricePanel ? chartScale.GetYByValue(val1) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val1));
			SharpDX.Vector2 v2 = new SharpDX.Vector2(x2, drawOnPricePanel ? chartScale.GetYByValue(val2) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val2));
//Print("\nv1: "+v1.X+", "+v1.Y+"   "+val1);
//Print("v2: "+v2.X+", "+v2.Y+"   "+val2);
			RenderTarget.DrawLine(v1, v2, dxbrush, width, strokestyle);

			strokestyle.Dispose();
		}
		private void drawRectangle(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush, int width, DashStyleHelper dashstyle = DashStyleHelper.Solid)
		{
			drawRectangle(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, dxbrush, dashstyle, width);
		}
		//Draw Rectangle. x and y as pixel coordinate, w and h in pixel too.
		private void drawRectangle(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
		{
			drawRectangle(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush, dashstyle, width);
		}
		private void drawRectangle(Point[] points, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
		{
			drawLine(points[0].X, points[1].X, points[0].Y, points[1].Y, dxbrush, dashstyle, width);
			drawLine(points[1].X, points[2].X, points[1].Y, points[2].Y, dxbrush, dashstyle, width);
			drawLine(points[2].X, points[3].X, points[2].Y, points[3].Y, dxbrush, dashstyle, width);
			drawLine(points[3].X, points[0].X, points[3].Y, points[0].Y, dxbrush, dashstyle, width);
		}
		#endregion

		#region -- Parameters --

//		[Display(Name = "Use Session Date", GroupName = " Parameters", Description = "Use Session date as the reset period for daily H/L, if not, then it will use calendar date as reset", Order = 20)]
		public bool UseSessionDate = true;//{get;set;}

		#region -- SwingTrend Parameters --

		[Display(Name = "Use Highs/Lows", GroupName = "SwingTrend Parameters", Description = "Use High/Lows or Input", Order = 5)]
		public bool isHLBased { get; set; }

		[Range(1, 200)]
		[Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 10)]
		public int SwingStrength { get; set; }

		#endregion

		#region Custom Visuals
		[Display(Name = "Show Lines", GroupName = "SwingTrend Parameters", Description = "Show structure trend lines", Order = 53)]
		public bool ShowSwingLines {get;set;}

		[XmlIgnore]
		[Display(Name = "Up-trend line color", GroupName = "Custom Visuals", Description = "Line color for up-trending structure", Order = 10)]
		public Brush UpLineColor { get; set; }
		[Browsable(false)]
		public string UpLineColorSerialize
		{get { return Serialize.BrushToString(UpLineColor); }
		                                set { UpLineColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Down-trend line color", GroupName = "Custom Visuals", Description = "Line color for down-trending structure", Order = 20)]
		public Brush DownLineColor { get; set; }
		[Browsable(false)]
		public string DownLineColorSerialize
		{get { return Serialize.BrushToString(DownLineColor); }
		                                set { DownLineColor = Serialize.StringToBrush(value); }}
		[Range(1, 10)]
		[Display(Name = "Line Thickness", GroupName = "Custom Visuals", Description = "Thickness of structure lines", Order = 30)]
		public int ZZLineThickness {get;set;}

		[Display(Name = "Show Labels", GroupName = "Custom Visuals", Description = "Show zigzag labels (e.g. 'HH' or 'LH', etc)", Order = 40)]
		public bool ShowSwingLabels{get;set;}

		[Display(Name = "Font size", GroupName = "Custom Visuals", Description = "Font for structure labels", Order = 50)]
        public SimpleFont pZZlabelFont { get; set; }
		#endregion

        [Display(Name = "Button Text", GroupName = "Custom Visuals", Description = "", Order = 60)]
		public string pButtonText {get;set;}

		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_SwingStructure[] cacheARC_SwingStructure;
		public ARC.ARC_SwingStructure ARC_SwingStructure()
		{
			return ARC_SwingStructure(Input);
		}

		public ARC.ARC_SwingStructure ARC_SwingStructure(ISeries<double> input)
		{
			if (cacheARC_SwingStructure != null)
				for (int idx = 0; idx < cacheARC_SwingStructure.Length; idx++)
					if (cacheARC_SwingStructure[idx] != null &&  cacheARC_SwingStructure[idx].EqualsInput(input))
						return cacheARC_SwingStructure[idx];
			return CacheIndicator<ARC.ARC_SwingStructure>(new ARC.ARC_SwingStructure(), input, ref cacheARC_SwingStructure);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_SwingStructure ARC_SwingStructure()
		{
			return indicator.ARC_SwingStructure(Input);
		}

		public Indicators.ARC.ARC_SwingStructure ARC_SwingStructure(ISeries<double> input )
		{
			return indicator.ARC_SwingStructure(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_SwingStructure ARC_SwingStructure()
		{
			return indicator.ARC_SwingStructure(Input);
		}

		public Indicators.ARC.ARC_SwingStructure ARC_SwingStructure(ISeries<double> input )
		{
			return indicator.ARC_SwingStructure(input);
		}
	}
}

#endregion
