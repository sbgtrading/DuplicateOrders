using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using SharpDX;
using SharpDX.Direct2D1;
using Brush = System.Windows.Media.Brush;

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[ARC_PatternFinderAlgo_CoLicenses(typeof(ARC_PatternFinderAlgo_ARC_MWPatternFinderZigZag))]
	public class ARC_PatternFinderAlgo_ARC_MWPatternFinder : ARC_PatternFinderAlgo_ARCIndicatorBase
	{
		public override string ProductVersion { get { return "v1.0.3 (5/9/2023)"; } }
		public override bool ColicensedOnly { get { return true; } }

		internal enum MWPatternType
		{
			PointsEven,
			FirstPointOutermost,
			SecondPointOutermost
		}

		internal class MWPattern
		{
			/// <summary>
			/// A list of the 3 points that make up the inner V of the M/W pattern
			/// </summary>
			public List<ARC_PatternFinderAlgo_ZigZagPoint> VPoints { get; private set; }

			/// <summary>
			/// The bar the pattern was terminated
			/// </summary>
			public int? EndBar { get; set; }

			/// <summary>
			/// 1 for an m pattern, -1 for a w pattern
			/// </summary>
			public int Side { get; private set; }

			public MWPatternType Type { get; set; }

			public ARC_PatternFinderAlgo_ZigZagPoint MiddlePoint { get { return VPoints[1]; } }
			
			public ARC_PatternFinderAlgo_ZigZagPoint ThreshPoint { get { return VPoints[2]; } }

			public MWPattern(List<ARC_PatternFinderAlgo_ZigZagPoint> points)
			{
				if (points.Count != 3)
					throw new Exception("MW pattern takes as input exactly 3 zig zag points");

				// The side it's on is the side of the two outer points of the v structure
				VPoints = points;
				Side = points
					.GroupBy(p => p.Side)
					.OrderByDescending(g => g.Count())
					.Select(g => g.Key)
					.First();
			}
		}

		[Browsable(false), XmlIgnore]
		internal IReadOnlyList<MWPattern> Patterns
		{
			get
			{
				Update();
				return patterns;
			}
		}

		private readonly ARC_PatternFinderAlgo_DefaultingDictionary<int, MWPattern> pendingPatterns = new ARC_PatternFinderAlgo_DefaultingDictionary<int, MWPattern>();
		private readonly List<MWPattern> patterns = new List<MWPattern>();
		private int pointCountWhenPatternLastFound;
		private int mostRecentPointBarWhenPatternChecked;
		private ARC_PatternFinderAlgo_ARC_MWPatternFinderZigZag zigZag;
		private ATR avgTrueRange;
		protected override void OnStateChange()
		{
			base.OnStateChange();
//			if (State != State.SetDefaults && !this.ARC_PatternFinderAlgo_IsLicensed())
	//			return;

			if (State == State.SetDefaults)
			{
				IsOverlay = true;
				
				SwingStrength = 3;
				IncludeWicks = true;
				DoubleTopOrBottomTolerance = 0.1;

				ShowZigZags = true;
				NeutralZigZagBrushBrush = Brushes.Black;
				LongPatternBrush = Brushes.Green;
				ShortPatternBrush = Brushes.Maroon;
				ZigZagLineThickness = 3;
				VConnectorLineThickness = 2;
			}
			else if (State == State.Configure)
			{
				pendingPatterns.Clear();
				pointCountWhenPatternLastFound = 0;
				mostRecentPointBarWhenPatternChecked = -1;
				patterns.Clear();
			}
			else if (State == State.DataLoaded)
			{
				zigZag = ARC_PatternFinderAlgo_ARC_MWPatternFinderZigZag(SwingStrength, IncludeWicks);
				avgTrueRange = ATR(256);
			}
		}
		
		protected override void OnBarUpdate()
		{
//Print("126  "+ARC_PatternFinderAlgo_IsLicensed().ToString());
			base.OnBarUpdate();
			//if (!this.ARC_PatternFinderAlgo_IsLicensed())
			//	return;

//Print(131);
			if(zigZag==null) return;
//Print(133);
			// Can't have an M or W without 4 points
			if (zigZag.SwingPoints.Count < 5)
				return;

			// Check if the current live patterns threshes has been exceeded, confirming it. If any are confirmed, end all pending patterns.
			foreach (var p in pendingPatterns.Values.Where(p => p != null).ToArray())
			{
				if (Close[0].ApproxCompare(p.ThreshPoint.Price) != p.Side)
					continue;
				p.EndBar = CurrentBar;
				patterns.Add(p);
				pendingPatterns.Clear();
				break;
			}

			// If we haven't changed trend once since the last time we found a pattern, and our most recent extreme is the same or we already found a pattern for the leg, there's nothing to check
			if (zigZag.SwingPoints.Count == pointCountWhenPatternLastFound || mostRecentPointBarWhenPatternChecked == zigZag.SwingPoints.Last().Bar)
				return;

			// Take the last 5 points, needed to check the m pattern
			var vPoints = zigZag.SwingPoints
				.AsEnumerable()
				.Reverse()
				.Skip(1)
				.Take(3)
				.Reverse()
				.ToList();

			// Last point updated, check for new patterns
			mostRecentPointBarWhenPatternChecked = zigZag.SwingPoints.Last().Bar;
			var pendingPattern = new MWPattern(vPoints);
			var diff = vPoints[2].Price - vPoints[0].Price;

			if (Math.Abs(diff) < avgTrueRange[0] * DoubleTopOrBottomTolerance)
				pendingPattern.Type = MWPatternType.PointsEven;
			else
				pendingPattern.Type = diff.CompareTo(0) == pendingPattern.Side
					? MWPatternType.SecondPointOutermost
					: MWPatternType.FirstPointOutermost;

			pendingPatterns[pendingPattern.Side] = pendingPattern;
			pointCountWhenPatternLastFound = zigZag.SwingPoints.Count;
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
//			if (!this.ARC_PatternFinderAlgo_IsLicensed())
//				return;

			var priorAaMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
			if (ShowZigZags)
				using (var zzDxBrush = NeutralZigZagBrushBrush.ToDxBrush(RenderTarget))
					RenderTarget.ARC_PatternFinderAlgo_DrawZigZag(this, chartScale, zigZag.SwingPoints, zzDxBrush, ZigZagLineThickness);

			Update();
			var entryPerDirStrokes = new [] { -1, 1 }.ToDictionary(dir => dir, dir => new Stroke(dir == 1 ? LongPatternBrush : ShortPatternBrush, DashStyleHelper.Dot, VConnectorLineThickness, 255) { RenderTarget = RenderTarget });
			using (var upVDxBrush = LongPatternBrush.ToDxBrush(RenderTarget))
			using (var downVDxBrush = ShortPatternBrush.ToDxBrush(RenderTarget))
				foreach (var pattern in pendingPatterns.Values.Where(p => p != null).Concat(patterns))
				{
					RenderTarget.ARC_PatternFinderAlgo_DrawZigZag(this, chartScale, pattern.VPoints, pattern.Side == 1 ? upVDxBrush : downVDxBrush, ZigZagLineThickness);
					if (pattern.ThreshPoint.Bar > ChartBars.ToIndex)
						continue;

					var lineSeries = !IncludeWicks ? Close : (pattern.Side == -1 ? Low : High);
					var v1 = new Vector2(ChartControl.GetXByBarIndex(ChartBars, pattern.ThreshPoint.Bar), chartScale.GetYByValue(lineSeries.GetValueAt(pattern.ThreshPoint.Bar)));
					var endBar = Math.Min(pattern.EndBar ?? ChartBars.ToIndex, Math.Min(ChartBars.Count - 1, ChartBars.ToIndex + 1));
					var v2 = new Vector2(ChartControl.GetXByBarIndex(ChartBars, endBar), v1.Y);
					var entryConnectorStroke = entryPerDirStrokes[pattern.Side];
					RenderTarget.DrawLine(v1, v2, entryConnectorStroke.BrushDX, entryConnectorStroke.Width, entryConnectorStroke.StrokeStyle);
				}

			foreach (var dir in entryPerDirStrokes.Keys) 
				entryPerDirStrokes[dir].BrushDX.Dispose();
			RenderTarget.AntialiasMode = priorAaMode;
		}

		#region Properties
		#region Parameters
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Order = 0, Name = "Swing Strength", GroupName = "Parameters", Description = "Number of bars used to identify a swing high or low")]
		public int SwingStrength { get; set; }
		
		[NinjaScriptProperty]
		[Display(Order = 1, Name = "Include Wicks", GroupName = "Parameters", Description = "Whether or not to use wicks (vs closes) for pivot points")]
		public bool IncludeWicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Order = 2, Name = "Double Tops/Bottoms Sensitivity", GroupName = "Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms")]
		public double DoubleTopOrBottomTolerance { get; set; }
		#endregion

		#region Visual Parameters
		[Display(Name = "Show Zig Zags", Order = 0, GroupName = "Visual Parameters")]
		public bool ShowZigZags { get; set; }
		
		[XmlIgnore]
		[Display(Name = "Long Pattern Brush", Order = 1, GroupName = "Visual Parameters")]
		public Brush NeutralZigZagBrushBrush { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string NeutralZigZagBrushBrushSerializable
		{
			get { return Serialize.BrushToString(NeutralZigZagBrushBrush); }
			set { NeutralZigZagBrushBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Long Pattern Brush", Order = 2, GroupName = "Visual Parameters")]
		public Brush LongPatternBrush { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string LongPatternBrushSerializable
		{
			get { return Serialize.BrushToString(LongPatternBrush); }
			set { LongPatternBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Short Pattern Color", Order = 3, GroupName = "Visual Parameters")]
		public Brush ShortPatternBrush { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ShortPatternBrushSerializable
		{
			get { return Serialize.BrushToString(ShortPatternBrush); }
			set { ShortPatternBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(1e-5f, float.MaxValue)]
		[Display(Name = "Zig Zag Line Thickness", Order = 4, GroupName = "Visual Parameters")]
		public float ZigZagLineThickness { get; set; }
		
		[Range(1e-5f, float.MaxValue)]
		[Display(Name = "Connector Line Thickness", Order = 5, GroupName = "Visual Parameters")]
		public float VConnectorLineThickness { get; set; }
		#endregion
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder[] cacheARC_PatternFinderAlgo_ARC_MWPatternFinder;
		public ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder ARC_PatternFinderAlgo_ARC_MWPatternFinder(int swingStrength, bool includeWicks, double doubleTopOrBottomTolerance)
		{
			return ARC_PatternFinderAlgo_ARC_MWPatternFinder(Input, swingStrength, includeWicks, doubleTopOrBottomTolerance);
		}

		public ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder ARC_PatternFinderAlgo_ARC_MWPatternFinder(ISeries<double> input, int swingStrength, bool includeWicks, double doubleTopOrBottomTolerance)
		{
			if (cacheARC_PatternFinderAlgo_ARC_MWPatternFinder != null)
				for (int idx = 0; idx < cacheARC_PatternFinderAlgo_ARC_MWPatternFinder.Length; idx++)
					if (cacheARC_PatternFinderAlgo_ARC_MWPatternFinder[idx] != null && cacheARC_PatternFinderAlgo_ARC_MWPatternFinder[idx].SwingStrength == swingStrength && cacheARC_PatternFinderAlgo_ARC_MWPatternFinder[idx].IncludeWicks == includeWicks && cacheARC_PatternFinderAlgo_ARC_MWPatternFinder[idx].DoubleTopOrBottomTolerance == doubleTopOrBottomTolerance && cacheARC_PatternFinderAlgo_ARC_MWPatternFinder[idx].EqualsInput(input))
						return cacheARC_PatternFinderAlgo_ARC_MWPatternFinder[idx];
			return CacheIndicator<ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder>(new ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder(){ SwingStrength = swingStrength, IncludeWicks = includeWicks, DoubleTopOrBottomTolerance = doubleTopOrBottomTolerance }, input, ref cacheARC_PatternFinderAlgo_ARC_MWPatternFinder);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder ARC_PatternFinderAlgo_ARC_MWPatternFinder(int swingStrength, bool includeWicks, double doubleTopOrBottomTolerance)
		{
			return indicator.ARC_PatternFinderAlgo_ARC_MWPatternFinder(Input, swingStrength, includeWicks, doubleTopOrBottomTolerance);
		}

		public Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder ARC_PatternFinderAlgo_ARC_MWPatternFinder(ISeries<double> input , int swingStrength, bool includeWicks, double doubleTopOrBottomTolerance)
		{
			return indicator.ARC_PatternFinderAlgo_ARC_MWPatternFinder(input, swingStrength, includeWicks, doubleTopOrBottomTolerance);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder ARC_PatternFinderAlgo_ARC_MWPatternFinder(int swingStrength, bool includeWicks, double doubleTopOrBottomTolerance)
		{
			return indicator.ARC_PatternFinderAlgo_ARC_MWPatternFinder(Input, swingStrength, includeWicks, doubleTopOrBottomTolerance);
		}

		public Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder ARC_PatternFinderAlgo_ARC_MWPatternFinder(ISeries<double> input , int swingStrength, bool includeWicks, double doubleTopOrBottomTolerance)
		{
			return indicator.ARC_PatternFinderAlgo_ARC_MWPatternFinder(input, swingStrength, includeWicks, doubleTopOrBottomTolerance);
		}
	}
}

#endregion
