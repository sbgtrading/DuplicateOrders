#region Using declarations
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Strategies.Licensing;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC.Supporting
{
	[Browsable(false)]
	[CategoryOrder(ProductInfoGroupName, 1000)]
	public class ARC_PinBarAlgo_ARCIndicatorBase : Indicator, ARC_PinBarAlgo_IARCLicensedWithMessages
	{
		public const string ProductInfoGroupName = "Product Info";

		[XmlIgnore, Browsable(false)]
		public virtual string ProductInfusionSoftTag => "";
		[XmlIgnore, Browsable(false)]
		public List<string> ProductBundleInfusionSoftTags => new List<string>();
		[XmlIgnore, Browsable(false)]
		public TextFixed LicensingLoadingText { get; set; }
		[XmlIgnore, Browsable(false)]
		public TextFixed LicensingErrorText { get; set; }
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ProductVersion => "";
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ModuleName => GetType().Name.Replace("ARC_", "");
		[XmlIgnore, Browsable(false)]
		public virtual bool ColicensedOnly => false;
		public override string DisplayName => IsCreatedByStrategy ? "" : ModuleName + ARC_PinBarAlgo_ARCLicenseValidator.LicenseModeDenotingNameSuffix;

		/// <summary>
		/// The default name for the script in the UI and ToString
		/// </summary>
		protected virtual string ProductName => GetType().Name;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = ProductName;
				Calculate = Calculate.OnBarClose;
				IsOverlay = false;
				BarsRequiredToPlot = 1;
				IsSuspendedWhileInactive = true;
			}
			else if (State == State.Configure)
			{
				this.ARC_PinBarAlgo_EnactLicensingWithWarnings(ARC_PinBarAlgo_LicensingContextStep.Configure);
			}
		}

		protected override void OnBarUpdate()
		{
			this.ARC_PinBarAlgo_EnactLicensingWithWarnings(ARC_PinBarAlgo_LicensingContextStep.BarUpdate);
		}

		public override string ToString()
		{
			return DisplayName;
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Supporting.ARC_PinBarAlgo_ARCIndicatorBase[] cacheARC_PinBarAlgo_ARCIndicatorBase;
		public ARC.Supporting.ARC_PinBarAlgo_ARCIndicatorBase ARC_PinBarAlgo_ARCIndicatorBase()
		{
			return ARC_PinBarAlgo_ARCIndicatorBase(Input);
		}

		public ARC.Supporting.ARC_PinBarAlgo_ARCIndicatorBase ARC_PinBarAlgo_ARCIndicatorBase(ISeries<double> input)
		{
			if (cacheARC_PinBarAlgo_ARCIndicatorBase != null)
				for (int idx = 0; idx < cacheARC_PinBarAlgo_ARCIndicatorBase.Length; idx++)
					if (cacheARC_PinBarAlgo_ARCIndicatorBase[idx] != null &&  cacheARC_PinBarAlgo_ARCIndicatorBase[idx].EqualsInput(input))
						return cacheARC_PinBarAlgo_ARCIndicatorBase[idx];
			return CacheIndicator<ARC.Supporting.ARC_PinBarAlgo_ARCIndicatorBase>(new ARC.Supporting.ARC_PinBarAlgo_ARCIndicatorBase(), input, ref cacheARC_PinBarAlgo_ARCIndicatorBase);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Supporting.ARC_PinBarAlgo_ARCIndicatorBase ARC_PinBarAlgo_ARCIndicatorBase()
		{
			return indicator.ARC_PinBarAlgo_ARCIndicatorBase(Input);
		}

		public Indicators.ARC.Supporting.ARC_PinBarAlgo_ARCIndicatorBase ARC_PinBarAlgo_ARCIndicatorBase(ISeries<double> input )
		{
			return indicator.ARC_PinBarAlgo_ARCIndicatorBase(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Supporting.ARC_PinBarAlgo_ARCIndicatorBase ARC_PinBarAlgo_ARCIndicatorBase()
		{
			return indicator.ARC_PinBarAlgo_ARCIndicatorBase(Input);
		}

		public Indicators.ARC.Supporting.ARC_PinBarAlgo_ARCIndicatorBase ARC_PinBarAlgo_ARCIndicatorBase(ISeries<double> input )
		{
			return indicator.ARC_PinBarAlgo_ARCIndicatorBase(input);
		}
	}
}

#endregion
