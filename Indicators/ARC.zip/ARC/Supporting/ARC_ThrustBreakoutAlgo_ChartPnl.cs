#region Using declarations
using System;
using System.ComponentModel;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Strategies;
using SharpDX;
using SharpDX.DirectWrite;
using NinjaTrader.Core;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC.Supporting
{
	[Browsable(false)]
	public class ARC_ThrustBreakoutAlgo_ChartPnl : Indicator
	{
		private readonly SimpleFont font1 = new SimpleFont("Arial", 16);
		private readonly Stroke pen = new Stroke(Brushes.Black);
		[Browsable(false), XmlIgnore]
		public Brush defaultTextBrush = Brushes.Black;

		/// <summary>
		/// Active trades open PNL
		/// </summary>
		[Browsable(false), XmlIgnore]
		public double OpenPnl { get; set; }

		/// <summary>
		/// Realized is for the current session
		/// </summary>
		[Browsable(false), XmlIgnore]
		public double SessionClosedPnl { get; set; }

		/// <summary>
		/// Realized PNL since the beginning of the loaded data
		/// </summary>
		[Browsable(false), XmlIgnore]
		public double ChartTotalClosedPnl { get; set; }

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = "Chart PnL";
				Calculate = Calculate.OnBarClose;
				IsOverlay = false;
				DisplayInDataBox = true;
				PaintPriceMarkers = true;
				IsChartOnly = true;
				IsSuspendedWhileInactive = true;
				BarsRequiredToPlot = 0;

				AddPlot(new Stroke(Brushes.Green, DashStyleHelper.Solid, 3), PlotStyle.Line, "Daily Pnl Plot");
				AddPlot(new Stroke(Brushes.Green, DashStyleHelper.Dash, 3), PlotStyle.Line, "Historic Daily Pnl Plot");
				AddLine(new Stroke(Brushes.Black, DashStyleHelper.Dash, 2), 0, "ZeroLine");
			}
			else if (State == State.Configure)
			{
				OpenPnl = 0;
				SessionClosedPnl = 0;
				ChartTotalClosedPnl = 0;
				lagSeconds = 0;
			}
		}

		private double lagSeconds;
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType != MarketDataType.Ask && e.MarketDataType != MarketDataType.Bid)
				return;
			lagSeconds = Math.Abs(new TimeSpan(DateTime.Now.Ticks - e.Time.Ticks).TotalSeconds);
		}

		#region Graphics
		private static Brush GetPnlBrush(double pnl)
		{
			return pnl > 0 ? Brushes.Green : pnl < 0 ? Brushes.Red : Brushes.Black;
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (chartControl == null || RenderTarget == null)
				return;
			
			base.OnRender(chartControl, chartScale);
			var graphics = new NT7Graphics(RenderTarget);

			var bounds = new RectangleF(ChartPanel.X, ChartPanel.Y, ChartPanel.W, ChartPanel.H);
			var textPosition = bounds.Y + 0.05f * bounds.Height;

			graphics.FillRectangle(Brushes.LightGray, 5, textPosition, 330, 80);
			graphics.DrawRectangle(pen, 5, textPosition, 330, 80);

			const float valuesLeftOffset = 235f;
			const float labelsRightOffset = 220f;

			if (!(Parent?.Parent is Strategy parentStrategy))
				return;

			textPosition += 2;
			for (var i = 0; i < 4; i++)
			{
				string label;
				double value;
				switch (i)
				{
				case 0:
					label = "Closed P&L (All Trades):";
					value = ChartTotalClosedPnl;
					break;
				case 1:
					label = "Closed P&L (Current Session):";
					value = SessionClosedPnl;
					break;
				case 2:
					label = "Open P&L:";
					value = OpenPnl;
					break;
				case 3:
					label = "Data Lag:";
					value = lagSeconds < 60 ? lagSeconds : Math.Round(lagSeconds / 60, 1);
					
					break;
				default:
					throw new ArgumentOutOfRangeException("");
				}

				string valueString;
				if (i < 3)
				{
					valueString = Globals.FormatCurrency(value, parentStrategy.Account.Denomination);
				}
				else
				{
					string valueFormatString;
					if (lagSeconds >= 60)
						valueFormatString = "{0}-min";
					else if (lagSeconds > 2)
						valueFormatString = "{0:0.0}-sec";
					else
						valueFormatString = "{0:0.00}-sec";
					valueString = string.Format(valueFormatString, value);
				}

				graphics.DrawString(label, font1, defaultTextBrush, 10f, textPosition, labelsRightOffset, Convert.ToSingle(font1.Size), TextAlignment.Trailing);
				graphics.DrawString(valueString, font1, i == 3 ? defaultTextBrush : GetPnlBrush(value), valuesLeftOffset, textPosition, TextAlignment.Leading);
				textPosition += 20;
			}
		}

		#region RegNT7toNT8Class
		internal class NT7Graphics
		{
			private readonly SharpDX.Direct2D1.RenderTarget rt;
			public NT7Graphics(SharpDX.Direct2D1.RenderTarget rt)
			{
				this.rt = rt;
			}
			
			public void DrawRectangle(Stroke s, float x, float y, float w, float h)
			{
				var rectF = new RectangleF(x, y, w, h);
				using var brush = s.Brush.ToDxBrush(rt);
				if (brush == null)
					return;

				rt.DrawRectangle(rectF, brush, s.Width);
			}
			
			public void FillRectangle(Brush b, float x, float y, float w, float h)
			{
				var rectF = new RectangleF(x, y, w, h);
				using var brush = b.ToDxBrush(rt);
				if (brush == null)
					return;

				rt.FillRectangle(rectF, brush);
			}
			
			public void DrawString(string text, SimpleFont f, Brush b, float x, float y, TextAlignment ta)
			{
				DrawString(text, f, b, x, y, 400, Convert.ToSingle(f.Size), ta);
			}

			public void DrawString(string text, SimpleFont f, Brush b, float x, float y, float w, float h, TextAlignment ta)
			{
				using var textFormat = new TextFormat(Globals.DirectWriteFactory, f.Family.ToString(), f.Bold ? FontWeight.Bold : FontWeight.Normal, FontStyle.Normal, FontStretch.Normal, Convert.ToSingle(f.Size));
				textFormat.TextAlignment = ta;
				textFormat.WordWrapping = WordWrapping.NoWrap;
				using var textLayout = new TextLayout(Globals.DirectWriteFactory, text, textFormat, w, h);
				using var brush = b.ToDxBrush(rt);
				var upperTextPoint = new System.Windows.Point(x, y);
				if (brush == null)
					return;
					
				rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush,
					SharpDX.Direct2D1.DrawTextOptions.NoSnap);
			}
		}
		#endregion
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Supporting.ARC_ThrustBreakoutAlgo_ChartPnl[] cacheARC_ThrustBreakoutAlgo_ChartPnl;
		public ARC.Supporting.ARC_ThrustBreakoutAlgo_ChartPnl ARC_ThrustBreakoutAlgo_ChartPnl()
		{
			return ARC_ThrustBreakoutAlgo_ChartPnl(Input);
		}

		public ARC.Supporting.ARC_ThrustBreakoutAlgo_ChartPnl ARC_ThrustBreakoutAlgo_ChartPnl(ISeries<double> input)
		{
			if (cacheARC_ThrustBreakoutAlgo_ChartPnl != null)
				for (int idx = 0; idx < cacheARC_ThrustBreakoutAlgo_ChartPnl.Length; idx++)
					if (cacheARC_ThrustBreakoutAlgo_ChartPnl[idx] != null &&  cacheARC_ThrustBreakoutAlgo_ChartPnl[idx].EqualsInput(input))
						return cacheARC_ThrustBreakoutAlgo_ChartPnl[idx];
			return CacheIndicator<ARC.Supporting.ARC_ThrustBreakoutAlgo_ChartPnl>(new ARC.Supporting.ARC_ThrustBreakoutAlgo_ChartPnl(), input, ref cacheARC_ThrustBreakoutAlgo_ChartPnl);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Supporting.ARC_ThrustBreakoutAlgo_ChartPnl ARC_ThrustBreakoutAlgo_ChartPnl()
		{
			return indicator.ARC_ThrustBreakoutAlgo_ChartPnl(Input);
		}

		public Indicators.ARC.Supporting.ARC_ThrustBreakoutAlgo_ChartPnl ARC_ThrustBreakoutAlgo_ChartPnl(ISeries<double> input )
		{
			return indicator.ARC_ThrustBreakoutAlgo_ChartPnl(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Supporting.ARC_ThrustBreakoutAlgo_ChartPnl ARC_ThrustBreakoutAlgo_ChartPnl()
		{
			return indicator.ARC_ThrustBreakoutAlgo_ChartPnl(Input);
		}

		public Indicators.ARC.Supporting.ARC_ThrustBreakoutAlgo_ChartPnl ARC_ThrustBreakoutAlgo_ChartPnl(ISeries<double> input )
		{
			return indicator.ARC_ThrustBreakoutAlgo_ChartPnl(input);
		}
	}
}

#endregion
