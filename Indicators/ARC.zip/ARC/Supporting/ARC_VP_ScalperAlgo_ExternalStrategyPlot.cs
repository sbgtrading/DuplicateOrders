using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui.Chart;
using SharpDX.Direct2D1;

namespace NinjaTrader.NinjaScript.Indicators.ARC.Supporting
{
	[Browsable(false)]
	public class ARC_VP_ScalperAlgo_ExternalStrategyPlot : Indicator
	{
		public override string DisplayName => Name;

		[Browsable(false), XmlIgnore]
		public Action<RenderTarget, ChartBars, ChartScale> RenderCallback { get; set; }

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = "External Strategy Plot";
				Calculate = Calculate.OnBarClose;
				IsOverlay = false;
				DisplayInDataBox = true;
				DrawOnPricePanel = true;
				DrawHorizontalGridLines = true;
				DrawVerticalGridLines = true;
				PaintPriceMarkers = true;
				ScaleJustification = ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive = true;

				PlotCount = 1;
				Guid = Guid.NewGuid();
			}
			else if (State == State.Configure)
			{
				for (var i = 0; i < PlotCount; i++)
					AddPlot(Brushes.Aqua, "Plot" + i);
			}
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			RenderCallback?.Invoke(RenderTarget, ChartBars, chartScale);
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		public int PlotCount { get; set; }

		[NinjaScriptProperty]
		public Guid Guid { get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Supporting.ARC_VP_ScalperAlgo_ExternalStrategyPlot[] cacheARC_VP_ScalperAlgo_ExternalStrategyPlot;
		public ARC.Supporting.ARC_VP_ScalperAlgo_ExternalStrategyPlot ARC_VP_ScalperAlgo_ExternalStrategyPlot(int plotCount, Guid guid)
		{
			return ARC_VP_ScalperAlgo_ExternalStrategyPlot(Input, plotCount, guid);
		}

		public ARC.Supporting.ARC_VP_ScalperAlgo_ExternalStrategyPlot ARC_VP_ScalperAlgo_ExternalStrategyPlot(ISeries<double> input, int plotCount, Guid guid)
		{
			if (cacheARC_VP_ScalperAlgo_ExternalStrategyPlot != null)
				for (int idx = 0; idx < cacheARC_VP_ScalperAlgo_ExternalStrategyPlot.Length; idx++)
					if (cacheARC_VP_ScalperAlgo_ExternalStrategyPlot[idx] != null && cacheARC_VP_ScalperAlgo_ExternalStrategyPlot[idx].PlotCount == plotCount && cacheARC_VP_ScalperAlgo_ExternalStrategyPlot[idx].Guid == guid && cacheARC_VP_ScalperAlgo_ExternalStrategyPlot[idx].EqualsInput(input))
						return cacheARC_VP_ScalperAlgo_ExternalStrategyPlot[idx];
			return CacheIndicator<ARC.Supporting.ARC_VP_ScalperAlgo_ExternalStrategyPlot>(new ARC.Supporting.ARC_VP_ScalperAlgo_ExternalStrategyPlot(){ PlotCount = plotCount, Guid = guid }, input, ref cacheARC_VP_ScalperAlgo_ExternalStrategyPlot);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Supporting.ARC_VP_ScalperAlgo_ExternalStrategyPlot ARC_VP_ScalperAlgo_ExternalStrategyPlot(int plotCount, Guid guid)
		{
			return indicator.ARC_VP_ScalperAlgo_ExternalStrategyPlot(Input, plotCount, guid);
		}

		public Indicators.ARC.Supporting.ARC_VP_ScalperAlgo_ExternalStrategyPlot ARC_VP_ScalperAlgo_ExternalStrategyPlot(ISeries<double> input , int plotCount, Guid guid)
		{
			return indicator.ARC_VP_ScalperAlgo_ExternalStrategyPlot(input, plotCount, guid);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Supporting.ARC_VP_ScalperAlgo_ExternalStrategyPlot ARC_VP_ScalperAlgo_ExternalStrategyPlot(int plotCount, Guid guid)
		{
			return indicator.ARC_VP_ScalperAlgo_ExternalStrategyPlot(Input, plotCount, guid);
		}

		public Indicators.ARC.Supporting.ARC_VP_ScalperAlgo_ExternalStrategyPlot ARC_VP_ScalperAlgo_ExternalStrategyPlot(ISeries<double> input , int plotCount, Guid guid)
		{
			return indicator.ARC_VP_ScalperAlgo_ExternalStrategyPlot(input, plotCount, guid);
		}
	}
}

#endregion
