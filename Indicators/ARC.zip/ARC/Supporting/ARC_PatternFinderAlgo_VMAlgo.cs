#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using SharpDX.DirectWrite;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC.AlgoSup
{
	[Browsable(true)]
	[CategoryOrder("Parameters", 1)]
	[CategoryOrder("Divergence Options", 10)]
	[CategoryOrder("Divergence Parameters", 20)]
	[CategoryOrder("MACDBB Parameters", 30)]
	[CategoryOrder("SwingTrend Parameters", 40)]
	[CategoryOrder("Display Options Divergences", 50)]
	[CategoryOrder("Display Options Oscillator Panel", 60)]
	[CategoryOrder("Display Options Price Excursions", 65)]
	[CategoryOrder("Display Options Swing Trend", 70)]
	[CategoryOrder("Histogram Divergences - Plot Colors", 80)]
	[CategoryOrder("Histogram Divergences - Plot Parameters", 90)]
	[CategoryOrder("Histogram Hidden Divergences - Plot Colors", 100)]
	[CategoryOrder("Histogram Hidden Divergences - Plot Parameters", 110)]
	[CategoryOrder("MACD Divergences - Plot Colors", 120)]
	[CategoryOrder("MACD Divergences - Plot Parameters", 130)]
	[CategoryOrder("MACD Hidden Divergences - Plot Colors", 140)]
	[CategoryOrder("MACD Hidden Divergences - Plot Parameters", 150)]
	[CategoryOrder("Plot Colors", 160)]
	[CategoryOrder("Plot Parameters", 170)]
	[CategoryOrder("Price Excursion - Plot Colors", 180)]
	[CategoryOrder("Price Excursion - Plot Parameters", 190)]
	[CategoryOrder("Sentiment Box - Colors", 200)]
	[CategoryOrder("Sentiment Box - Parameters", 210)]
	[CategoryOrder("Sentiment Box - Text Elements", 220)]
	public class ARC_PatternFinderAlgo_VMAlgo : ARC_PatternFinderAlgo_ARCIndicatorBase
	{
		public override bool ColicensedOnly { get { return true; } }
		public override string ProductVersion { get { return "1.0"; } }

		#region ---- Variables ---- 
		#region -- Bloodhound --
		private Series<double> structureBiasState;
		private Series<double> swingHighsState;
		private Series<double> swingLowsState;
		#endregion

		#region -- Structure BIAS + Swings --
		private readonly List<int> sequence = new List<int>(3);
		private int srType, preSrType;  
		private SharpDX.Direct2D1.Brush bullishDivergenceDxBrush, bearishDivergenceDxBrush, dataTableDxBrush, oppositeBkgDxBrush;
		private SharpDX.Direct2D1.Brush bullishBkgDxBrush, bearishBkgDxBrush;
		private SharpDX.Direct2D1.Brush deepBullishBkgDxBrush, deepBearishBkgDxBrush;
		#endregion

		#region -- velocity momo  --
		private MACD bMacd;
		private MACD macd1;
		private MACD macd2;
		private MACD macd3;
		private MACD macd4;
		private StdDev sdBb;
		#endregion

		#region -- zigzag indicator -- 
		private int lastHighIdx;
		private int lastLowIdx;
		private int priorSwingHighIdx;
		private int priorSwingLowIdx;
		private int highCount;
		private int lowCount;
		private int preLastHighIdx;
		private int preLastLowIdx;
		private double zigzagDeviation;
		private double currentHigh;
		private double currentLow;
		private double swingMax;
		private double swingMin;
		private double preCurrentHigh;
		private double preCurrentLow;
		private bool addHigh;
		private bool updateHigh;
		private bool addLow;
		private bool updateLow;
		private bool drawHigherHighDot;
		private bool drawLowerHighDot;
		private bool drawDoubleTopDot;
		private bool drawLowerLowDot;
		private bool drawHigherLowDot;
		private bool drawDoubleBottomDot;
		private bool drawHigherHighLabel;
		private bool drawLowerHighLabel;
		private bool drawDoubleTopLabel;
		private bool drawLowerLowLabel;
		private bool drawHigherLowLabel;
		private bool drawDoubleBottomLabel;
		private bool drawSwingLegUp;
		private bool drawSwingLegDown;
		private bool intraBarAddHigh;
		private bool intraBarUpdateHigh;
		private bool intraBarAddLow;
		private bool intraBarUpdateLow;

		private SimpleFont labelFont;
		private SimpleFont swingDotFont;
		private const int PixelOffset1 = 10;               
		private const int PixelOffset2 = 10;               
		private readonly Brush upColor = Brushes.LimeGreen;
		private readonly Brush downColor = Brushes.Red;      
		private readonly Brush doubleTopBottomColor = Brushes.Yellow;   
		private const string DotString = "n"; 

		private ATR avgTrueRange;
		private Series<double> swingInput;
		private Series<int> preSwingHighType;
		private Series<int> preSwingLowType;
		private Series<int> swingHighType;
		private Series<int> swingLowType;
		private Series<int> acceleration1;
		private Series<int> acceleration2;
		private Series<bool> upTrend;
		#endregion

		private const ARC_PatternFinderAlgo_VMAlgo_InputType thisInputType = ARC_PatternFinderAlgo_VMAlgo_InputType.High_Low;

		private Series<double> bbDotTrend;
		private Series<double> momoSigNum;

		#region -- Box --
		private SimpleFont dataFont1;
		private SimpleFont dataFont2;

		private const System.Windows.TextAlignment TextAlignmentCenter = System.Windows.TextAlignment.Center;

		private double dataStringHeight;
		private string maxString1 = "";
		private string maxString2 = "";
		#endregion

		private SMA excursionSeries;
		#endregion

		#region -- Index Constants to change Plot order and superposition. Lower index goes below --        
		private const int BbMacdIdx = 12;
		private const int BbMacdFrameIdx = 11;
		private const int BbMacdLineIdx = 10;
		private const int AverageIdx = 9;
		private const int UpperIdx = 8;
		private const int LowerIdx = 7;
		private const int HistogramIdx = 6;
		private const int PriceExcursionUl3Idx = 5;
		private const int PriceExcursionUl2Idx = 4;
		private const int PriceExcursionUl1Idx = 3;
		private const int PriceExcursionLl1Idx = 2;
		private const int PriceExcursionLl2Idx = 1;
		private const int PriceExcursionLl3Idx = 0;
		private const int PriceExcursionMaxIdx = 14;
		private const int PriceExcursionMinIdx = 13;
		#endregion

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && !this.ARC_PatternFinderAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				Description = @"The NS_VelocityMomoDiv Measures 2 components of momentum:  1) the velocity histogram measures minor cycles of Multiple timeframe momentum cycles and act as a leading guage of momentum before a trend has started  2)(Moving Average Convergence/Divergence) is a trend following momentum indicator that shows the relationship between two moving averages of prices.";
				ArePlotsConfigurable = false;
				DrawOnPricePanel = false;
				AreLinesConfigurable = false;
				DrawOnPricePanel = false;
				PaintPriceMarkers = false;
				ZOrder = -1;
				MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				ScaleJustification = ScaleJustification.Right;
				IsSuspendedWhileInactive = false;
				Calculate = Calculate.OnEachTick;
				IsOverlay = false;
				DisplayInDataBox = true;
				
				#region INIT Plots / Lines 

				//rj RJ5GROUP code Algorithm
				AddPlot(new Stroke(Brushes.Red), PlotStyle.HLine, "PriceExcursionLL3");
				AddPlot(new Stroke(Brushes.Blue), PlotStyle.HLine, "PriceExcursionLL2");
				AddPlot(new Stroke(Brushes.Black), PlotStyle.HLine, "PriceExcursionLL1");
				AddPlot(new Stroke(Brushes.Black), PlotStyle.HLine, "PriceExcursionUL1");
				AddPlot(new Stroke(Brushes.Blue), PlotStyle.HLine, "PriceExcursionUL2");
				AddPlot(new Stroke(Brushes.Red), PlotStyle.HLine, "PriceExcursionUL3");
				//rj RJ5GROUP code Algorithm

				//AddLine(Brushes.Gray, 0, "Zeroline");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Bar, "Histogram");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "Lower");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "Upper");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "Average");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "BBMACDLine");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Dot, "BBMACDFrame");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Dot, "BBMACD");

				AddPlot(new Stroke(Brushes.Black, 0.1f), PlotStyle.Line, "PriceExcursionMAX");
				AddPlot(new Stroke(Brushes.Black, 0.1f), PlotStyle.Line, "PriceExcursionMIN");
				#endregion

				pButtonText = "VMLean";

				#region MACDBB Parameters
				BandPeriod = 10;
				Fast = 12;
				Slow = 26;
				StdDevNumber = 1.0;
				#endregion

				#region INIT Properties to Default Values 
				#region SwingTrend Parameters 
				SwingStrength = 3;
				MultiplierMD = 0.0;
				MultiplierDTB = 0.0;
				#endregion

				#region Display Options Oscillator Panel 
				//BackgroundFloodingPanel = gztFloodPanel.None;//##MODIF## AzurITec - 18.05.2016
				ShowBiasInBox = true;
				BackgroundFlooding = ARC_PatternFinderAlgo_VMAlgo_Flooding.None;
				#endregion

				#region Display Options Swing Trend 
				SwingDotSize = 7;
				LabelFontSize = 10;
				SwingLegWidth = 2;
				ShowZigzagDots = false;
				ShowZigzagLabels = false;
				ShowZigzagLegs = false;
				SwingLegStyle = DashStyleHelper.Solid;
				#endregion

				//rj RJ5GROUP code Algorithm
				#region Display Options Price Excursions 
				DisplayLevel1 = false;
				DisplayLevel2 = true;
				DisplayLevel3 = true;
				#endregion

				OptimizeSpeed = ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings.Max;
				OverprintSentimentBox = false;

				#region Plot Parameters 
				DotSize = 2;
				Plot2Width = 2;
				Plot3Width = 2;
				Plot4Width = 2;
				Dash3Style = DashStyleHelper.Dot;
				Dash4Style = DashStyleHelper.Solid;
				ZerolineWidth = 1;
				ZerolineStyle = DashStyleHelper.Solid;
				MomoWidth = 6;

				DeepBullishBackgroundColor = Brushes.DarkGreen;
				BullishBackgroundColor = Brushes.Green;
				OppositeBackgroundColor = Brushes.Gray;
				BearishBackgroundColor = Brushes.Red;
				DeepBearishBackgroundColor = Brushes.DarkRed;
				BackgroundOpacity = 30;//##DEFAULT VALUE TO CHECK##
				ChannelColor = Brushes.DodgerBlue;
				ChannelOpacity = 20;
				#endregion

				#region Plot Colors 
				DotsUpRisingColor = Brushes.Green;
				DotsDownRisingColor = Brushes.Green;
				DotsDownFallingColor = Brushes.Red;
				DotsUpFallingColor = Brushes.Red;
				DotsRimColor = Brushes.Black;
				BBAverageColor = Brushes.Transparent;
				BBUpperColor = Brushes.Black;
				BBLowerColor = Brushes.Black;
				HistUpColor = Brushes.LimeGreen;
				HistDownColor = Brushes.Maroon;
				ZerolineColor = Brushes.Black;
				ConnectorColor = Brushes.White;
				#endregion

				//rj RJ5GROUP code Algorithm
				#region Price Excursion: Plot Colors / Parameters 
				Level1Color = Brushes.WhiteSmoke;
				Level2Color = Brushes.Blue;
				Level3Color = Brushes.Red;
				PlotStyleLevels = PlotStyle.HLine;
				DashStyleHelperLevels = DashStyleHelper.Solid;
				PlotWidthLevels = 3;
				#endregion

				#region Sentiment Box: Colors 
				BearishAccelerationColor = Brushes.Red;
				BearishDivergenceColor = Brushes.Red;
				BearishForegroundColor = Brushes.Black;
				BullishAccelerationColor = Brushes.Lime;
				BullishDivergenceColor = Brushes.Lime;
				BullishForegroundColor = Brushes.Black;
				TextBoxOutlineColor = Brushes.MidnightBlue;
				TextColor = Brushes.White;
				DataTableColor = Brushes.MidnightBlue;
				#endregion

				#region Sentiment Box: Parameters 
				//JQ 11.26.2017
				// Bug 12782. The set right margin is causing the shifting of the SDV bar when the PP bar and the Divergence indicator
				// are all on the same chart. This could be a NT8 issue as it appears the BarMarginRight is only applied to the
				// primary bar (PP) rather than the secondary bar SDV). For now, I will disable the setrightmargin properties
				// until I have a chance to talk to NT about this issue.
				// --start--
				//                SetRightSideMargin = true;
				// --end--
				DataFontSize = 12;
				SentimentBoxLocation = ARC_PatternFinderAlgo_VMAlgo_SentimentBoxLocations.Hide;
				#endregion

				#region Sentiment Box: Text Elements 
				BullAccString = "Bullish Acc";
				BullDivCString = "Bullish Div (C)";
				BullDivPString = "Bullish Div (P)";
				BullHDivCString = "Bullish HDiv (C)";
				BullHDivPString = "Bullish HDiv (P)";
				BearAccString = "Bearish Acc";
				BearDivCString = "Bearish Div (C)";
				BearDivPString = "Bearish Div (P)";
				BearHDivCString = "Bearish HDiv (C)";
				BearHDivPString = "Bearish HDiv (P)";
				NeutralString = "Neutral";
				UpBiasString = "Up Trend";
				DwBiasString = "Down Trend";
				NeutralBiasString = "Oscillation";     
				#endregion

				#endregion
			}
			else if (State == State.Configure)
			{
				ResetPerRunCustomValues();

				#region INIT Fonts  
				labelFont = new SimpleFont("Arial", LabelFontSize);
				swingDotFont = new SimpleFont("Webdings", SwingDotSize) { Bold = true };
				dataFont1 = new SimpleFont("Arial", Math.Max(1, DataFontSize - 2)) { Bold = true };
				dataFont2 = new SimpleFont("Arial", DataFontSize) { Bold = true };

				//Get string size (H / W) for Sentiment BOX
				dataStringHeight = dataFont2.Size;

				maxString1 = "STRUCTURE BIAS" + 1;

				var boxStrings = new List<string> { NeutralString, BullAccString, BullDivCString, BullDivPString, BullHDivCString, BullHDivPString, BearAccString, BearDivCString, BearDivPString, BearHDivCString, BearHDivPString, UpBiasString, DwBiasString, NeutralBiasString };
				maxString2 = boxStrings.Aggregate("", (max, cur) => max.Length > cur.Length ? max : cur);
				maxString2 += 1;
				#endregion

				#region -- Set default to plots --
				Plots[BbMacdIdx].Width = DotSize;
				Plots[BbMacdIdx].DashStyleHelper = DashStyleHelper.Dot;
				Plots[BbMacdFrameIdx].Width = DotSize + 1;
				Plots[BbMacdFrameIdx].DashStyleHelper = DashStyleHelper.Dot;
				Plots[BbMacdLineIdx].Width = Plot2Width;
				Plots[AverageIdx].Width = Plot3Width;
				Plots[AverageIdx].DashStyleHelper = Dash3Style;
				Plots[UpperIdx].Width = Plot4Width;
				Plots[UpperIdx].DashStyleHelper = Dash4Style;
				Plots[LowerIdx].Width = Plot4Width;
				Plots[LowerIdx].DashStyleHelper = Dash4Style;
				Plots[HistogramIdx].Width = MomoWidth;
				Plots[HistogramIdx].DashStyleHelper = DashStyleHelper.Solid;

				Plots[BbMacdFrameIdx].Brush = DotsRimColor;
				Plots[BbMacdLineIdx].Brush = ConnectorColor;
				Plots[AverageIdx].Brush = BBAverageColor;
				Plots[UpperIdx].Brush = BBUpperColor;
				Plots[LowerIdx].Brush = BBLowerColor;

				//rj RJ5GROUP code Algorithm
				Plots[PriceExcursionUl3Idx].Brush = Brushes.Transparent;
				Plots[PriceExcursionUl2Idx].Brush = Brushes.Transparent;
				Plots[PriceExcursionUl1Idx].Brush = Brushes.Transparent;
				Plots[PriceExcursionLl1Idx].Brush = Brushes.Transparent;
				Plots[PriceExcursionLl2Idx].Brush = Brushes.Transparent;
				Plots[PriceExcursionLl3Idx].Brush = Brushes.Transparent;

				Plots[PriceExcursionMaxIdx].Brush = Level3Color;
				Plots[PriceExcursionMinIdx].Brush = Level3Color;
				//rj RJ5GROUP code Algorithm
				#endregion
			}
			else if (State == State.DataLoaded)
			{
				#region INIT Series  
				swingInput = new Series<double>(this);
				preSwingHighType = new Series<int>(this);
				preSwingLowType = new Series<int>(this);
				swingHighType = new Series<int>(this);
				swingLowType = new Series<int>(this);
				acceleration1 = new Series<int>(this);
				acceleration2 = new Series<int>(this);
				upTrend = new Series<bool>(this);

				bbDotTrend = new Series<double>(this);
				momoSigNum = new Series<double>(this);

				structureBiasState = new Series<double>(this, MaximumBarsLookBack.Infinite);
				swingHighsState = new Series<double>(this, MaximumBarsLookBack.Infinite);
				swingLowsState = new Series<double>(this, MaximumBarsLookBack.Infinite);
				#endregion

				#region INIT external Series
				bMacd = MACD(Input, Fast, Slow, BandPeriod);
				sdBb = StdDev(bMacd, BandPeriod);
				macd1 = MACD(8, 20, 20);
				macd2 = MACD(10, 20, 20);
				macd3 = MACD(20, 60, 20);
				macd4 = MACD(60, 240, 20);
				avgTrueRange = ATR(256);
				excursionSeries = SMA(ATR(256), 65);//rj RJ5GROUP code Algorithm
				#endregion
			}
		}
		//===============================================================================================================
		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_PatternFinderAlgo_IsLicensed())
				return;

			var line = 1411;
			try
			{
				line = 1421;
				#region --- Calculate VelocityMomo ---  
				var macdValue = bMacd[0];
				line = 1422;
				var average = bMacd.Avg[0];
				line = 1423;
				var stdDevValue = sdBb[0];

				line = 1424;
				BBMACD[0] = macdValue;
				line = 1425;
				BBMACDLine[0] = macdValue;
				line = 1426;
				BBMACDFrame[0] = macdValue;//used for drawing only
				line = 1427;
				Average[0] = average;
				line = 1428;
				Upper[0] = average + StdDevNumber * stdDevValue;
				line = 1429;
				Lower[0] = average - StdDevNumber * stdDevValue;
				line = 1430;
				Histogram[0] = macd1.Diff[0] + macd2.Diff[0] + macd3.Diff[0] + macd4.Diff[0];
				#endregion
				line = 1431;
				#region -- Color BB + Histo plots --  
				line = 1432;
				if (CurrentBars[0] > 0)
				{
					line = 1433;
					#region -- Histogram --
					if (Histogram[0] > 0)
					{
						PlotBrushes[HistogramIdx][0] = HistUpColor;
						momoSigNum[0] = 1.0;
					}
					else if (Histogram[0] < 0)
					{
						PlotBrushes[HistogramIdx][0] = HistDownColor;
						momoSigNum[0] = -1.0;
					}
					else
					{
						PlotBrushes[HistogramIdx][0] = PlotBrushes[HistogramIdx][1];
						momoSigNum[0] = momoSigNum[1];
					}
					#endregion
					line = 1434;
					#region -- MACD --
					bbDotTrend[0] = 0.0;
					if (IsRising(BBMACD))
					{
						if (BBMACD[0] > Upper[0])
						{
							bbDotTrend[0] = 2.0;
							PlotBrushes[BbMacdIdx][0] = DotsUpRisingColor;
						}
						else
						{
							bbDotTrend[0] = 1.0;
							PlotBrushes[BbMacdIdx][0] = DotsDownRisingColor;
						}
					}
					else if (IsFalling(BBMACD))
					{
						if (BBMACD[0] < Lower[0])
						{
							bbDotTrend[0] = -2.0;
							PlotBrushes[BbMacdIdx][0] = DotsDownFallingColor;
						}
						else
						{
							bbDotTrend[0] = -1.0;
							PlotBrushes[BbMacdIdx][0] = DotsUpFallingColor;
						}
					}
					else
					{
						bbDotTrend[0] = bbDotTrend[1];
						PlotBrushes[BbMacdIdx][0] = PlotBrushes[BbMacdIdx][1];
					}
					#endregion
				}
				#endregion

				line = 1502;
				//rj RJ5GROUP code Algorithm
				#region --- Calculate ExcursionValue ---  
				//Excursion Algorithm
				var excursionValue = excursionSeries[0];

				momoSigNum[0] = 0.0;

				//Plots
				PriceExcursionUL1[0] = excursionValue;
				PriceExcursionLL1[0] = -excursionValue;
				PriceExcursionUL2[0] = excursionValue * 2;
				PriceExcursionLL2[0] = excursionValue * -2;
				PriceExcursionUL3[0] = excursionValue * 3;
				PriceExcursionLL3[0] = excursionValue * -3;
				if (CurrentBars[0] > 0) PriceExcursionMAX.Reset(1);
				PriceExcursionMAX[0] = excursionValue * 3;
				if (CurrentBars[0] > 0) PriceExcursionMIN.Reset(1);
				PriceExcursionMIN[0] = excursionValue * -3;

				#region -- Show/Hide Excursion levels --  
				if (IsFirstTickOfBar)
				{
					if (!DisplayLevel1)
					{
						PlotBrushes[PriceExcursionUl1Idx][0] = Brushes.Transparent;
						PlotBrushes[PriceExcursionLl1Idx][0] = Brushes.Transparent;
					}
					if (!DisplayLevel2)
					{
						PlotBrushes[PriceExcursionUl2Idx][0] = Brushes.Transparent;
						PlotBrushes[PriceExcursionLl2Idx][0] = Brushes.Transparent;
					}
					if (!DisplayLevel3)
					{
						PlotBrushes[PriceExcursionUl3Idx][0] = Brushes.Transparent;
						PlotBrushes[PriceExcursionLl3Idx][0] = Brushes.Transparent;
					}
				}
				#endregion

				#endregion

				line = 1546;
				#region --- Calculate and Draw ZigZag + Intrabar Structure BIAS ---

				#region -- Init zigzag states --    
				if (CurrentBars[0] < 2)
				{
					line = 1552;
					upTrend[0] = true;
					preSwingHighType[0] = 0;
					preSwingLowType[0] = 0;
					swingHighType[0] = 0;
					swingLowType[0] = 0;
				}
				#endregion

				#region else if (Calculate == Calculate.OnBarClose)
				else if (Calculate == Calculate.OnBarClose)
				{
					line = 1564;
					var useHl = thisInputType == ARC_PatternFinderAlgo_VMAlgo_InputType.High_Low;

					zigzagDeviation = MultiplierMD * avgTrueRange[0];
					swingMax = MAX(useHl ? High : Input, SwingStrength)[1];
					swingMin = MIN(useHl ? Low : Input, SwingStrength)[1];

					preSwingHighType[0] = 0;
					preSwingLowType[0] = 0;
					swingHighType[0] = 0;
					swingLowType[0] = 0;

					updateHigh = upTrend[1] && (useHl ? Highs[0][0] : swingInput[0]) > currentHigh;
					updateLow = !upTrend[1] && (useHl ? Lows[0][0] : swingInput[0]) < currentLow;
					addHigh = !upTrend[1] && !((useHl ? Lows[0][0] : swingInput[0]) < currentLow) && (useHl ? Highs[0][0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
					addLow = upTrend[1] && !((useHl ? Highs[0][0] : swingInput[0]) > currentHigh) && (useHl ? Lows[0][0] : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

					upTrend[0] = upTrend[1];

					line = 1583;
					#region -- New High --
					if (addHigh)
					{
						upTrend[0] = true;
						var lookback = CurrentBars[0] - lastLowIdx;
						swingLowType[lookback] = preSwingLowType[lookback];
						var newHigh = double.MinValue;
						var j = 0;
						for (var i = 0; i < CurrentBars[0] - lastLowIdx; i++)
						{
							if ((useHl ? Highs[0][i] : swingInput[i]) > newHigh)
							{
								newHigh = (useHl ? Highs[0][i] : swingInput[i]);
								j = i;
							}
						}
						line = 1600;
						currentHigh = newHigh;
						priorSwingHighIdx = lastHighIdx;
						lastHighIdx = CurrentBars[0] - j;
					}
					#endregion

					#region -- uptrend --
					else if (updateHigh)
					{
						line = 1610;
						upTrend[0] = true;
						if (ShowZigzagDots) RemoveDrawObject(string.Format("swingHighDot{0}", lastHighIdx));
						if (ShowZigzagLabels) RemoveDrawObject(string.Format("swingHighLabel{0}", lastHighIdx));
						if (ShowZigzagLegs) RemoveDrawObject(string.Format("swingLegUp{0}", lastHighIdx));
						preSwingHighType[CurrentBars[0] - lastHighIdx] = 0;
						currentHigh = (useHl ? Highs[0][0] : swingInput[0]);
						lastHighIdx = CurrentBars[0];
					}
					#endregion

					#region -- New Low --
					else if (addLow)
					{
						line = 1624;
						upTrend[0] = false;
						var lookback = CurrentBars[0] - lastHighIdx;
						swingHighType[lookback] = preSwingHighType[lookback];
						var newLow = double.MaxValue;
						var j = 0;
						for (var i = 0; i < CurrentBars[0] - lastHighIdx; i++)
						{
							if ((useHl ? Lows[0][i] : swingInput[i]) < newLow)
							{
								newLow = (useHl ? Lows[0][i] : swingInput[i]);
								j = i;
							}
						}
						line = 1638;
						currentLow = newLow;
						priorSwingLowIdx = lastLowIdx;
						lastLowIdx = CurrentBars[0] - j;
					}
					#endregion

					#region -- dwtrend --
					else if (updateLow)
					{
						line = 1648;
						upTrend[0] = false;
						if (ShowZigzagDots) RemoveDrawObject(string.Format("swingLowDot{0}", lastLowIdx));
						if (ShowZigzagLabels) RemoveDrawObject(string.Format("swingLowLabel{0}", lastLowIdx));
						if (ShowZigzagLegs) RemoveDrawObject(string.Format("swingLegDown{0}", lastLowIdx));
						preSwingLowType[CurrentBars[0] - lastLowIdx] = 0;
						currentLow = (useHl ? Lows[0][0] : swingInput[0]);
						lastLowIdx = CurrentBars[0];
					}
					#endregion

					#region re-init drawing states at each new bar before calculous
					if (ShowZigzagDots)
					{
						drawHigherHighDot = false;
						drawLowerHighDot = false;
						drawDoubleTopDot = false;
						drawLowerLowDot = false;
						drawHigherLowDot = false;
						drawDoubleBottomDot = false;
					}

					drawHigherHighLabel = false;
					drawLowerHighLabel = false;
					drawDoubleTopLabel = false;
					drawLowerLowLabel = false;
					drawHigherLowLabel = false;
					drawDoubleBottomLabel = false;

					if (ShowZigzagLegs)
					{
						drawSwingLegUp = false;
						drawSwingLegDown = false;
					}
					#endregion

					#region -- UP || HH --
					if (addHigh || updateHigh)
					{
						line = 1687;
						var priorHighCount = CurrentBars[0] - priorSwingHighIdx;
						highCount = CurrentBars[0] - lastHighIdx;
						lowCount = CurrentBars[0] - lastLowIdx;

						var marginUp = (useHl ? Highs[0][priorHighCount] : swingInput[priorHighCount]) + MultiplierDTB * avgTrueRange[highCount];
						var marginDown = (useHl ? Highs[0][priorHighCount] : swingInput[priorHighCount]) - MultiplierDTB * avgTrueRange[highCount];

						line = 1696;
						// new code goes here
						#region -- Calculate acceleration on BBMACD and Histo --
						if (currentHigh > Highs[0][priorHighCount] && BBMACD[highCount] > 0 && BBMACD[0] > 0 && BBMACD[highCount] > BBMACD[priorHighCount])
							acceleration1[0] = 2;
						else if (currentHigh <= Highs[0][priorHighCount] && BBMACD[highCount] > 0 && BBMACD[0] > 0 && acceleration1[lowCount] == 1)
							acceleration1[0] = 1;
						else if (currentHigh <= Highs[0][priorHighCount] && BBMACD[highCount] < 0 && BBMACD[0] < 0 && acceleration1[lowCount] == -2)
							acceleration1[0] = -1;
						else
							acceleration1[0] = 0;
						if (currentHigh > Highs[0][priorHighCount] && Histogram[highCount] > 0 && Histogram[0] > 0 && Histogram[highCount] > Histogram[priorHighCount])
							acceleration2[0] = 2;
						else if (currentHigh <= Highs[0][priorHighCount] && Histogram[highCount] > 0 && Histogram[0] > 0 && acceleration2[lowCount] == 1)
							acceleration2[0] = 1;
						else if (currentHigh <= Highs[0][priorHighCount] && Histogram[highCount] < 0 && Histogram[0] < 0 && acceleration2[lowCount] == -2)
							acceleration2[0] = -1;
						else
							acceleration2[0] = 0;
						#endregion
						// end new code

						line = 1718;
						#region -- Set NEW drawing states --
						if (ShowZigzagDots)
						{
							if (currentHigh > marginUp)
								drawHigherHighDot = true;
							else if (currentHigh < marginDown)
								drawLowerHighDot = true;
							else
								drawDoubleTopDot = true;
						}

						if (currentHigh > marginUp) drawHigherHighLabel = true;
						else if (currentHigh < marginDown) drawLowerHighLabel = true;
						else drawDoubleTopLabel = true;

						line = 1734;
						if (ShowZigzagLegs)
							drawSwingLegUp = true;
						if (currentHigh > marginUp)
							preSwingHighType[highCount] = 3;
						else if (currentHigh < marginDown)
							preSwingHighType[highCount] = 1;
						else
							preSwingHighType[highCount] = 2;
						#endregion
					}
					#endregion

					#region -- DW || LL --
					else if (addLow || updateLow)
					{
						line = 1750;
						var priorLowCount = CurrentBars[0] - priorSwingLowIdx;
						lowCount = CurrentBars[0] - lastLowIdx;
						highCount = CurrentBars[0] - lastHighIdx;

						var marginDown = (useHl ? Lows[0][priorLowCount] : swingInput[priorLowCount]) - MultiplierDTB * avgTrueRange[lowCount];
						var marginUp = (useHl ? Lows[0][priorLowCount] : swingInput[priorLowCount]) + MultiplierDTB * avgTrueRange[lowCount];

						line = 1759;
						// new code goes here
						#region -- Calculate acceleration on BBMACD and Histo --
						if (currentLow < Lows[0][priorLowCount] && (BBMACD[lowCount] < 0 && BBMACD[0] < 0) && BBMACD[lowCount] < BBMACD[priorLowCount])
							acceleration1[0] = -2;
						else if (currentLow >= Lows[0][priorLowCount] && (BBMACD[lowCount] < 0 && BBMACD[0] < 0) && acceleration1[highCount] == -1)
							acceleration1[0] = -1;
						else if (currentLow >= Lows[0][priorLowCount] && (BBMACD[lowCount] > 0 && BBMACD[0] > 0) && acceleration1[highCount] == 2)
							acceleration1[0] = 1;
						else
							acceleration1[0] = 0;
						if (currentLow < Lows[0][priorLowCount] && Histogram[lowCount] < 0 && Histogram[0] < 0 && Histogram[lowCount] < Histogram[priorLowCount])
							acceleration2[0] = -2;
						else if (currentLow >= Lows[0][priorLowCount] && Histogram[lowCount] < 0 && Histogram[0] < 0 && acceleration2[highCount] == -1)
							acceleration2[0] = -1;
						else if (currentLow >= Lows[0][priorLowCount] && Histogram[lowCount] > 0 && Histogram[0] > 0 && acceleration2[highCount] == 2)
							acceleration2[0] = 1;
						else
							acceleration2[0] = 0;
						#endregion
						// end new code

						line = 1781;
						#region -- Set NEW drawing states --
						if (ShowZigzagDots)
						{
							if (currentLow < marginDown)
								drawLowerLowDot = true;
							else if (currentLow > marginUp)
								drawHigherLowDot = true;
							else
								drawDoubleBottomDot = true;
						}

						line = 1793;
						if (currentLow < marginDown) drawLowerLowLabel = true;
						else if (currentLow > marginUp) drawHigherLowLabel = true;
						else drawDoubleBottomLabel = true;

						if (ShowZigzagLegs)
							drawSwingLegDown = true;
						if (currentLow < marginDown)
							preSwingLowType[lowCount] = -3;
						else if (currentLow > marginUp)
							preSwingLowType[lowCount] = -1;
						else
							preSwingLowType[lowCount] = -2;
						#endregion
					}
					#endregion

					//Is it possible ??
					else
					{
						line = 1813;
						if ((acceleration1[1] > 0 && BBMACD[0] > 0) || (acceleration1[1] < 0 && BBMACD[0] < 0))
							acceleration1[0] = acceleration1[1];
						else
							acceleration1[0] = 0;
						if ((acceleration2[1] > 0 && Histogram[0] > 0) || (acceleration2[1] < 0 && Histogram[0] < 0))
							acceleration2[0] = acceleration2[1];
						else
							acceleration2[0] = 0;
					}
				}
				#endregion

				#region else if (IsFirstTickOfBar)
				else if (IsFirstTickOfBar)
				{
					line = 1829;
					var useHl = thisInputType == ARC_PatternFinderAlgo_VMAlgo_InputType.High_Low;
					zigzagDeviation = MultiplierMD * avgTrueRange[1];
					swingMax = MAX(useHl ? High : Input, SwingStrength)[2];
					swingMin = MIN(useHl ? Low : Input, SwingStrength)[2];

					preSwingHighType[0] = 0;
					preSwingLowType[0] = 0;
					swingHighType[0] = 0;
					swingLowType[0] = 0;

					updateHigh = upTrend[1] && (useHl ? Highs[0][1] : swingInput[1]) > currentHigh;
					updateLow = !upTrend[1] && (useHl ? Lows[0][1] : swingInput[1]) < currentLow;
					addHigh = !upTrend[1] && !((useHl ? Lows[0][1] : swingInput[1]) < currentLow) && (useHl ? Highs[0][1] : swingInput[1]) > Math.Max(swingMax, currentLow + zigzagDeviation);
					addLow = upTrend[1] && !((useHl ? Highs[0][1] : swingInput[1]) > currentHigh) && (useHl ? Lows[0][1] : swingInput[1]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

					upTrend[0] = upTrend[1];

					line = 1847;
					#region -- New High --
					if (addHigh)
					{
						upTrend[0] = true;
						var lookback = CurrentBars[0] - lastLowIdx;
						swingLowType[lookback] = preSwingLowType[lookback];
						var newHigh = double.MinValue;
						var j = 0;
						for (var i = 1; i < CurrentBars[0] - lastLowIdx; i++)
							if ((useHl ? Highs[0][i] : swingInput[i]) > newHigh)
							{
								newHigh = (useHl ? Highs[0][i] : swingInput[i]);
								j = i;
							}

						currentHigh = newHigh;
						priorSwingHighIdx = lastHighIdx;
						lastHighIdx = CurrentBars[0] - j;
					}
					#endregion

					#region -- UPtrend --
					else if (updateHigh)
					{
						line = 1873;
						upTrend[0] = true;
						if (ShowZigzagDots)
							RemoveDrawObject(string.Format("swingHighDot{0}", lastHighIdx));
						if (ShowZigzagLabels)
							RemoveDrawObject(string.Format("swingHighLabel{0}", lastHighIdx));
						if (ShowZigzagLegs)
							RemoveDrawObject(string.Format("swingLegUp{0}", lastHighIdx));
						preSwingHighType[CurrentBars[0] - lastHighIdx] = 0;
						currentHigh = (useHl ? Highs[0][1] : swingInput[1]);
						lastHighIdx = CurrentBars[0] - 1;
					}
					#endregion

					#region -- New Low --
					else if (addLow)
					{
						line = 1890;
						upTrend[0] = false;
						var lookback = CurrentBars[0] - lastHighIdx;
						swingHighType[lookback] = preSwingHighType[lookback];
						var newLow = double.MaxValue;
						var j = 0;
						for (var i = 1; i < CurrentBars[0] - lastHighIdx; i++)
						{
							if ((useHl ? Lows[0][i] : swingInput[i]) < newLow)
							{
								newLow = (useHl ? Lows[0][i] : swingInput[i]);
								j = i;
							}
						}
						currentLow = newLow;
						priorSwingLowIdx = lastLowIdx;
						lastLowIdx = CurrentBars[0] - j;
					}
					#endregion

					#region -- DWtrend --
					else if (updateLow)
					{
						line = 1913;
						upTrend[0] = false;
						if (ShowZigzagDots)
							RemoveDrawObject(string.Format("swingLowDot{0}", lastLowIdx));
						if (ShowZigzagLabels)
							RemoveDrawObject(string.Format("swingLowLabel{0}", lastLowIdx));
						if (ShowZigzagLegs)
							RemoveDrawObject(string.Format("swingLegDown{0}", lastLowIdx));
						preSwingLowType[CurrentBars[0] - lastLowIdx] = 0;
						currentLow = useHl ? Lows[0][1] : swingInput[1];
						lastLowIdx = CurrentBars[0] - 1;
					}
					#endregion

					#region re-init drawing states at each new bar before calculous
					if (ShowZigzagDots)
					{
						drawHigherHighDot = false;
						drawLowerHighDot = false;
						drawDoubleTopDot = false;
						drawLowerLowDot = false;
						drawHigherLowDot = false;
						drawDoubleBottomDot = false;
					}

					drawHigherHighLabel = false;
					drawLowerHighLabel = false;
					drawDoubleTopLabel = false;
					drawLowerLowLabel = false;
					drawHigherLowLabel = false;
					drawDoubleBottomLabel = false;

					if (ShowZigzagLegs)
					{
						drawSwingLegUp = false;
						drawSwingLegDown = false;
					}
					#endregion

					#region -- UP || HH --
					if (addHigh || updateHigh)
					{
						line = 1955;
						var priorHighCount = CurrentBars[0] - priorSwingHighIdx;
						highCount = CurrentBars[0] - lastHighIdx;
						lowCount = CurrentBars[0] - lastLowIdx;

						var marginUp = (useHl ? Highs[0][priorHighCount] : swingInput[priorHighCount]) + MultiplierDTB * avgTrueRange[highCount];
						var marginDown = (useHl ? Highs[0][priorHighCount] : swingInput[priorHighCount]) - MultiplierDTB * avgTrueRange[highCount];

						#region -- Set NEW drawing states --
						if (ShowZigzagDots)
						{
							if (currentHigh > marginUp)
								drawHigherHighDot = true;
							else if (currentHigh < marginDown)
								drawLowerHighDot = true;
							else
								drawDoubleTopDot = true;
						}

						line = 1974;
						if (currentHigh > marginUp) drawHigherHighLabel = true;
						else if (currentHigh < marginDown) drawLowerHighLabel = true;
						else drawDoubleTopLabel = true;

						if (ShowZigzagLegs)
							drawSwingLegUp = true;
						if (currentHigh > marginUp)
							preSwingHighType[highCount] = 3;
						else if (currentHigh < marginDown)
							preSwingHighType[highCount] = 1;
						else
							preSwingHighType[highCount] = 2;
						#endregion
					}
					#endregion

					#region -- DW || LL --
					else if (addLow || updateLow)
					{
						line = 1994;
						var priorLowCount = CurrentBars[0] - priorSwingLowIdx;
						lowCount = CurrentBars[0] - lastLowIdx;
						highCount = CurrentBars[0] - lastHighIdx;

						var marginDown = (useHl ? Lows[0][priorLowCount] : swingInput[priorLowCount]) - MultiplierDTB * avgTrueRange[lowCount];
						var marginUp = (useHl ? Lows[0][priorLowCount] : swingInput[priorLowCount]) + MultiplierDTB * avgTrueRange[lowCount];

						#region -- Set NEW drawing states --
						if (ShowZigzagDots)
						{
							if (currentLow < marginDown)
								drawLowerLowDot = true;
							else if (currentLow > marginUp)
								drawHigherLowDot = true;
							else
								drawDoubleBottomDot = true;
						}

						line = 2013;
						if (currentLow < marginDown) drawLowerLowLabel = true;
						else if (currentLow > marginUp) drawHigherLowLabel = true;
						else drawDoubleBottomLabel = true;

						if (ShowZigzagLegs)
							drawSwingLegDown = true;
						if (currentLow < marginDown)
							preSwingLowType[lowCount] = -3;
						else if (currentLow > marginUp)
							preSwingLowType[lowCount] = -1;
						else
							preSwingLowType[lowCount] = -2;
						#endregion
					}
					#endregion
				}
				#endregion

				line = 2032;
				#region if (Calculate != Calculate.OnBarClose)
				if (Calculate != Calculate.OnBarClose)
				{
					var useHl = thisInputType == ARC_PatternFinderAlgo_VMAlgo_InputType.High_Low;

					intraBarUpdateHigh = upTrend[0] && (useHl ? Highs[0][0] : swingInput[0]) > currentHigh;
					intraBarUpdateLow = !upTrend[0] && (useHl ? Lows[0][0] : swingInput[0]) < currentLow;
					intraBarAddHigh = !upTrend[0] && !((useHl ? Lows[0][0] : swingInput[0]) < currentLow) && (useHl ? Highs[0][0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
					intraBarAddLow = upTrend[0] && !((useHl ? Highs[0][0] : swingInput[0]) > currentHigh) && (useHl ? Lows[0][0] : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

					line = 2043;
					#region -- new HH --
					if (intraBarAddHigh)
					{
						var newHigh = double.MinValue;
						var j = 0;
						for (var i = 0; i < CurrentBars[0] - lastLowIdx; i++)
						{
							if ((useHl ? Highs[0][i] : swingInput[i]) > newHigh)
							{
								newHigh = (useHl ? Highs[0][i] : swingInput[i]);
								j = i;
							}
						}
						preCurrentHigh = newHigh;
						preLastHighIdx = CurrentBars[0] - j;
					}
					#endregion

					#region -- uptrend --
					else if (intraBarUpdateHigh)
					{
						line = 2065;
						preCurrentHigh = (useHl ? Highs[0][0] : swingInput[0]);
						preLastHighIdx = CurrentBars[0];
					}
					#endregion

					line = 2071;
					#region -- new LL --
					if (intraBarAddLow)
					{
						line = 2075;
						var newLow = double.MaxValue;
						var j = 0;
						for (var i = 0; i < CurrentBars[0] - lastHighIdx; i++)
						{
							if ((useHl ? Lows[0][i] : swingInput[i]) < newLow)
							{
								newLow = useHl ? Lows[0][i] : swingInput[i];
								j = i;
							}
						}
						preCurrentLow = newLow;
						preLastLowIdx = CurrentBars[0] - j;
					}
					#endregion

					#region -- dwtrend --
					else if (intraBarUpdateLow)
					{
						line = 2094;
						preCurrentLow = (useHl ? Lows[0][0] : swingInput[0]);
						preLastLowIdx = CurrentBars[0];
					}
					#endregion

					#region -- UP || HH --
					if (intraBarAddHigh || intraBarUpdateHigh)
					{
						line = 2103;
						var prePriorHighCount = intraBarAddHigh ? CurrentBars[0] - lastHighIdx : CurrentBars[0] - priorSwingHighIdx;
						var preHighCount = CurrentBars[0] - preLastHighIdx;
						var prePriorLowCount = CurrentBars[0] - priorSwingLowIdx;
						var preLowCount = CurrentBars[0] - lastLowIdx;

						#region -- Calculate acceleration on BBMACD and Histo --
						if (preCurrentHigh > Highs[0][prePriorHighCount] && (BBMACD[preHighCount] > 0 && BBMACD[0] > 0) && BBMACD[preHighCount] > BBMACD[prePriorHighCount])
							acceleration1[0] = 2;
						else if (preCurrentHigh <= Highs[0][prePriorHighCount] && (BBMACD[preHighCount] > 0 && BBMACD[0] > 0) && acceleration1[preLowCount] == 1)
							acceleration1[0] = 1;
						else if (preCurrentHigh <= Highs[0][prePriorHighCount] && (BBMACD[preHighCount] < 0 && BBMACD[0] < 0) && acceleration1[preLowCount] == -2)
							acceleration1[0] = -1;
						else
							acceleration1[0] = 0;
						if (preCurrentHigh > Highs[0][prePriorHighCount] && Histogram[preHighCount] > 0 && Histogram[0] > 0 && Histogram[preHighCount] > Histogram[prePriorHighCount])
							acceleration2[0] = 2;
						else if (preCurrentHigh <= Highs[0][prePriorHighCount] && Histogram[preHighCount] > 0 && Histogram[0] > 0 && acceleration2[preLowCount] == 1)
							acceleration2[0] = 1;
						else if (preCurrentHigh <= Highs[0][prePriorHighCount] && Histogram[preHighCount] < 0 && Histogram[0] < 0 && acceleration2[preLowCount] == -2)
							acceleration2[0] = -1;
						else
							acceleration2[0] = 0;
						#endregion

						line = 2128;
						#region ---- StructureBias RealTime ---
						double marginUp, marginDown;
						if (thisInputType == ARC_PatternFinderAlgo_VMAlgo_InputType.High_Low)
						{
							marginUp = Highs[0][prePriorHighCount] + MultiplierDTB * avgTrueRange[preHighCount];
							marginDown = Highs[0][prePriorHighCount] - MultiplierDTB * avgTrueRange[preHighCount];
						}
						else
						{
							marginUp = swingInput[prePriorHighCount] + MultiplierDTB * avgTrueRange[preHighCount];
							marginDown = swingInput[prePriorHighCount] - MultiplierDTB * avgTrueRange[preHighCount];
						}

						if (preCurrentHigh > marginUp) preSrType = 3;
						else if (preCurrentHigh < marginDown) preSrType = Math.Max(preSrType, 2);
						else preSrType = Math.Max(preSrType, 1);
						#endregion
					}
					#endregion

					#region -- DW || LL --
					else if (intraBarAddLow || intraBarUpdateLow)
					{
						line = 2152;
						var prePriorLowCount = intraBarAddLow ? CurrentBars[0] - lastLowIdx : CurrentBars[0] - priorSwingLowIdx;
						var preLowCount = CurrentBars[0] - preLastLowIdx;
						var prePriorHighCount = CurrentBars[0] - priorSwingHighIdx;
						var preHighCount = CurrentBars[0] - lastHighIdx;

						#region -- Calculate acceleration on BBMACD and Histo --
						if (preCurrentLow < Lows[0][prePriorLowCount] && (BBMACD[preLowCount] < 0 && BBMACD[0] < 0) && BBMACD[preLowCount] < BBMACD[prePriorLowCount])
							acceleration1[0] = -2;
						else if (preCurrentLow >= Lows[0][prePriorLowCount] && (BBMACD[preLowCount] < 0 && BBMACD[0] < 0) && acceleration1[preHighCount] == -1)
							acceleration1[0] = -1;
						else if (preCurrentLow >= Lows[0][prePriorLowCount] && (BBMACD[preLowCount] > 0 && BBMACD[0] > 0) && acceleration1[preHighCount] == 2)
							acceleration1[0] = 1;
						else
							acceleration1[0] = 0;
						if (preCurrentLow < Lows[0][prePriorLowCount] && Histogram[preLowCount] < 0 && Histogram[0] < 0 && Histogram[preLowCount] < Histogram[prePriorLowCount])
							acceleration2[0] = -2;
						else if (preCurrentLow >= Lows[0][prePriorLowCount] && Histogram[preLowCount] < 0 && Histogram[0] < 0 && acceleration2[preHighCount] == -1)
							acceleration2[0] = -1;
						else if (preCurrentLow >= Lows[0][prePriorLowCount] && Histogram[preLowCount] > 0 && Histogram[0] > 0 && acceleration2[preHighCount] == 2)
							acceleration2[0] = 1;
						else
							acceleration2[0] = 0;
						#endregion

						line = 2177;
						#region ---- StructureBias RealTime ---
						double marginUp, marginDown;
						if (thisInputType == ARC_PatternFinderAlgo_VMAlgo_InputType.High_Low)
						{
							marginDown = Lows[0][prePriorLowCount] - MultiplierDTB * avgTrueRange[preLowCount];
							marginUp = Lows[0][prePriorLowCount] + MultiplierDTB * avgTrueRange[preLowCount];
						}
						else
						{
							marginDown = swingInput[prePriorLowCount] - MultiplierDTB * avgTrueRange[preLowCount];
							marginUp = swingInput[prePriorLowCount] + MultiplierDTB * avgTrueRange[preLowCount];
						}
						if (preCurrentLow < marginDown) preSrType = -3;
						else if (preCurrentLow > marginUp) preSrType = Math.Min(preSrType, -2);
						else preSrType = Math.Min(preSrType, -1);
						#endregion
					}
					#endregion

					//Is it possible ??
					else
					{
						line = 2200;
						if ((acceleration1[1] > 0 && BBMACD[0] > 0) || (acceleration1[1] < 0 && BBMACD[0] < 0))
							acceleration1[0] = acceleration1[1];
						else
							acceleration1[0] = 0;
						if ((acceleration2[1] > 0 && Histogram[0] > 0) || (acceleration2[1] < 0 && Histogram[0] < 0))
							acceleration2[0] = acceleration2[1];
						else
							acceleration2[0] = 0;

						preSrType = 0;
					}

					#region ---- StructureBias RealTime ---
					if (CurrentBars[0] < 2)
						structureBiasState[0] = 0;
					else
					{
						line = 2218;
						if (preSrType == 0) structureBiasState[0] = structureBiasState[1];

						#region -- Oscillation State --
						else if (structureBiasState[1] == 0)
						{
							//Oscillation State
							//Need HH/!LL/HH to go to Up Trend
							//{NEW} !LL/High/!LL/HH to go to Up Trend
							//Need LL/!HH/LL to go to Dw Trend
							//{NEW} !HH/Low/!HH/LL to go to Dw Trend				
							if (sequence.Count < 2) structureBiasState[0] = 0;
							else if (sequence.Count < 3)
							{
								line = 2232;
								if (sequence[0] == 3 && sequence[1] != -3 && preSrType == 3) structureBiasState[0] = 1;
								else if (sequence[0] == -3 && sequence[1] != 3 && preSrType == -3) structureBiasState[0] = -1;
								else structureBiasState[0] = 0;
							}
							else
							{
								line = 2239;
								if (sequence[1] == 3 && sequence[2] != -3 && preSrType == 3) structureBiasState[0] = 1;
								else if (sequence[1] == -3 && sequence[2] != 3 && preSrType == -3) structureBiasState[0] = -1;
								//{NEW} HL/LH/HL/HH to go to Up Trend
								else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && preSrType == 3) structureBiasState[0] = 1;
								//{NEW} LH/HL/LH/LL to go to Up Trend
								else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && preSrType == -3) structureBiasState[0] = -1;
								else structureBiasState[0] = 0;
							}
						}
						#endregion

						#region -- UpTrend State --
						else if (structureBiasState[1] > 0)
						{
							line = 2254;
							//Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
							if (preSrType == -3) structureBiasState[0] = 0;
							else structureBiasState[0] = 1;
						}
						#endregion

						#region -- DwTrend State --
						else if (structureBiasState[1] < 0)
						{
							line = 2264;
							//Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
							if (preSrType == 3) structureBiasState[0] = 0;
							else structureBiasState[0] = -1;
						}
						#endregion

						else structureBiasState[0] = structureBiasState[1];
					}
					#endregion
				}
				#endregion

				var cutoffIdx = int.MinValue;
				var cb = CurrentBars[0];
				if (State == State.Historical) cb = Bars.Count;
				if (OptimizeSpeed == ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings.Min) cutoffIdx = cb - 500;
				else if (OptimizeSpeed == ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings.Max) cutoffIdx = cb - 100;
				var printMarkers = CurrentBars[0] > cutoffIdx;

				line = 2284;
				if (Calculate == Calculate.OnBarClose || IsFirstTickOfBar)
				{
					DrawOnPricePanel = true;
					#region -- Draw zigzag --    
					if (printMarkers && ShowZigzagDots && thisInputType == ARC_PatternFinderAlgo_VMAlgo_InputType.High_Low)
					{
						line = 2291;
						if (IsFirstTickOfBar && cutoffIdx > 0)
						{
							RemoveDrawObject(string.Format("swingHighDot{0}", cutoffIdx));
							RemoveDrawObject(string.Format("swingLowDot{0}", cutoffIdx));
						}
						if (drawHigherHighDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, DotString, highCount, Highs[0][highCount], SwingDotSize / 2, upColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawLowerHighDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, DotString, highCount, Highs[0][highCount], SwingDotSize / 2, downColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawDoubleTopDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, DotString, highCount, Highs[0][highCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						if (drawLowerLowDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, DotString, lowCount, Lows[0][lowCount], SwingDotSize / 2, downColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawHigherLowDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, DotString, lowCount, Lows[0][lowCount], SwingDotSize / 2, upColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawDoubleBottomDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, DotString, lowCount, Lows[0][lowCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
					}
					else if (printMarkers && ShowZigzagDots)
					{
						line = 2311;
						if (IsFirstTickOfBar && cutoffIdx > 0)
						{
							RemoveDrawObject(string.Format("swingHighDot{0}", cutoffIdx));
							RemoveDrawObject(string.Format("swingLowDot{0}", cutoffIdx));
						}
						if (drawHigherHighDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, DotString, highCount, swingInput[highCount], SwingDotSize / 2, upColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawLowerHighDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, DotString, highCount, swingInput[highCount], SwingDotSize / 2, downColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawDoubleTopDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, DotString, highCount, swingInput[highCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						if (drawLowerLowDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, DotString, lowCount, swingInput[lowCount], SwingDotSize / 2, downColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawHigherLowDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, DotString, lowCount, swingInput[lowCount], SwingDotSize / 2, upColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawDoubleBottomDot)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, DotString, lowCount, swingInput[lowCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
					}
					if (printMarkers && ShowZigzagLabels)
					{
						line = 2331;
						if (IsFirstTickOfBar && cutoffIdx > 0)
						{
							RemoveDrawObject(string.Format("swingHighLabel{0}", cutoffIdx));
							RemoveDrawObject(string.Format("swingLowLabel{0}", cutoffIdx));
						}
						if (drawHigherHighLabel)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingHighLabel{0}", lastHighIdx), true, "HH", highCount, Highs[0][highCount], (int)(labelFont.Size) + PixelOffset1, upColor, labelFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawLowerHighLabel)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingHighLabel{0}", lastHighIdx), true, "LH", highCount, Highs[0][highCount], (int)(labelFont.Size) + PixelOffset1, downColor, labelFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawDoubleTopLabel)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingHighLabel{0}", lastHighIdx), true, "DT", highCount, Highs[0][highCount], (int)(labelFont.Size) + PixelOffset1, doubleTopBottomColor, labelFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						if (drawLowerLowLabel)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingLowLabel{0}", lastLowIdx), true, "LL", lowCount, Lows[0][lowCount], -(int)(labelFont.Size) - PixelOffset2, downColor, labelFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawHigherLowLabel)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingLowLabel{0}", lastLowIdx), true, "HL", lowCount, Lows[0][lowCount], -(int)(labelFont.Size) - PixelOffset2, upColor, labelFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
						else if (drawDoubleBottomLabel)
							TriggerCustomEvent(o1 => { Draw.Text(this, string.Format("swingLowLabel{0}", lastLowIdx), true, "DB", lowCount, Lows[0][lowCount], -(int)(labelFont.Size) - PixelOffset2, doubleTopBottomColor, labelFont, TextAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0); }, 0, null);
					}
					if (printMarkers && ShowZigzagLegs && thisInputType == ARC_PatternFinderAlgo_VMAlgo_InputType.High_Low)
					{
						line = 2351;
						if (IsFirstTickOfBar && cutoffIdx > 0)
						{
							RemoveDrawObject(string.Format("swingLegUp{0}", cutoffIdx));
							RemoveDrawObject(string.Format("swingLegDown{0}", cutoffIdx));
						}
						if (drawSwingLegUp)
							TriggerCustomEvent(o1 => { Draw.Line(this, string.Format("swingLegUp{0}", lastHighIdx), false, lowCount, Lows[0][lowCount], highCount, Highs[0][highCount], upColor, SwingLegStyle, SwingLegWidth); }, 0, null);
						if (drawSwingLegDown)
							TriggerCustomEvent(o1 => { Draw.Line(this, string.Format("swingLegDown{0}", lastLowIdx), false, highCount, Highs[0][highCount], lowCount, Lows[0][lowCount], downColor, SwingLegStyle, SwingLegWidth); }, 0, null);
					}
					else if (printMarkers && ShowZigzagLegs)
					{
						line = 2365;
						if (IsFirstTickOfBar && cutoffIdx > 0)
						{
							RemoveDrawObject(string.Format("swingLegUp{0}", cutoffIdx));
							RemoveDrawObject(string.Format("swingLegDown{0}", cutoffIdx));
						}
						if (drawSwingLegUp)
							TriggerCustomEvent(o1 => { Draw.Line(this, string.Format("swingLegUp{0}", lastHighIdx), false, lowCount, swingInput[lowCount], highCount, swingInput[highCount], upColor, SwingLegStyle, SwingLegWidth); }, 0, null);
						if (drawSwingLegDown)
							TriggerCustomEvent(o1 => { Draw.Line(this, string.Format("swingLegDown{0}", lastLowIdx), false, highCount, swingInput[highCount], lowCount, swingInput[lowCount], downColor, SwingLegStyle, SwingLegWidth); }, 0, null);
					}
					#endregion
				}

				#endregion

				#region --- init before having enough bars --- 
				if (CurrentBars[0] < BarsRequiredToPlot + 55)
				{
					line = 2385;
					structureBiasState[0] = 0;
					srType = 0;
					swingHighsState[0] = 0;
					swingLowsState[0] = 0;
					return;
				}
				#endregion

				#region -- Structure BIAS --
				line = 2341;
				srType = drawHigherHighLabel ? 3 : drawLowerHighLabel ? 2 : drawDoubleTopLabel ? 1 : drawDoubleBottomLabel ? -1 : drawHigherLowLabel ? -2 : drawLowerLowLabel ? -3 : 0;
				swingHighsState[0] = drawHigherHighLabel ? 3 : drawLowerHighLabel ? 2 : drawDoubleTopLabel ? 1 : 0;//#SWINGS for BH
				swingLowsState[0] = drawDoubleBottomLabel ? -1 : drawHigherLowLabel ? -2 : drawLowerLowLabel ? -3 : 0;//#SWINGS for BH	

				line = 2346;
				#region -- Oscillation State --
				var decay = 0;
				if (Calculate != Calculate.OnBarClose && State != State.Historical) decay = 1;
				if (srType != 0 && structureBiasState[decay + 1] == 0)
				{
					#region -- update sequence ---
					//--- Same Trend --
					if (upTrend[1] == upTrend[0])
					{
						if (sequence.Count == 0) sequence.Add(srType);
						else sequence[sequence.Count - 1] = srType;
					}

					//--- Changing Trend ---
					else if (Calculate == Calculate.OnBarClose && upTrend[1] != upTrend[0])
					{
						if (sequence.Count < 4) sequence.Add(srType);
						else
						{
							sequence[0] = sequence[1];
							sequence[1] = sequence[2];
							sequence[2] = sequence[3];
							sequence[3] = srType;
						}
					}
					#region -- eachtick --
					else if (Calculate != Calculate.OnBarClose && upTrend[1] != upTrend[0])
					{
						if (IsFirstTickOfBar)
						{
							if (sequence.Count < 4) sequence.Add(srType);
							else
							{
								sequence[0] = sequence[1];
								sequence[1] = sequence[2];
								sequence[2] = sequence[3];
								sequence[3] = srType;
							}
						}
						else if (sequence.Count == 0) sequence.Add(srType);
						else sequence[sequence.Count - 1] = srType;
					}
					#endregion
					#endregion

					//Oscillation State
					//Need HH/!LL/HH to go to Up Trend
					//{NEW} !LL/High/!LL/HH to go to Up Trend
					//Need LL/!HH/LL to go to Dw Trend
					//{NEW} !HH/Low/!HH/LL to go to Dw Trend				
					if (sequence.Count < 3) structureBiasState[decay] = 0;
					else if (sequence.Count < 4)
					{
						if (sequence[0] == 3 && sequence[1] != -3 && sequence[2] == 3) structureBiasState[decay] = 1;
						else if (sequence[0] == -3 && sequence[1] != 3 && sequence[2] == -3) structureBiasState[decay] = -1;
						else structureBiasState[decay] = 0;
					}
					else
					{
						if (sequence[1] == 3 && sequence[2] != -3 && sequence[3] == 3) structureBiasState[decay] = 1;
						else if (sequence[1] == -3 && sequence[2] != 3 && sequence[3] == -3) structureBiasState[decay] = -1;
						//{NEW} HL/LH/HL/HH to go to Up Trend
						else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && sequence[3] == 3) structureBiasState[decay] = 1;
						//{NEW} LH/HL/LH/LL to go to Up Trend
						else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && sequence[3] == -3) structureBiasState[decay] = -1;
						else structureBiasState[decay] = 0;
					}
				}
				#endregion

				#region -- UpTrend State --
				else if (srType != 0 && structureBiasState[decay + 1] > 0)
				{
					line = 2420;
					if (IsFirstTickOfBar) sequence.Clear();
					//Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
					if (srType == -3)
					{
						structureBiasState[decay] = 0;
						if (IsFirstTickOfBar) sequence.Add(srType);
						else if (sequence.Count == 0) sequence.Add(srType);
						else sequence[sequence.Count - 1] = srType;
					}
					else structureBiasState[decay] = 1;
				}
				#endregion

				#region -- DwTrend State --
				else if (srType != 0 && structureBiasState[decay + 1] < 0)
				{
					line = 2437;
					if (IsFirstTickOfBar) sequence.Clear();
					//Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
					if (srType == 3)
					{
						structureBiasState[decay] = 0;
						if (IsFirstTickOfBar) sequence.Add(srType);
						else if (sequence.Count == 0) sequence.Add(srType);
						else sequence[sequence.Count - 1] = srType;
					}
					else structureBiasState[decay] = -1;
				}
				#endregion

				else structureBiasState[decay] = structureBiasState[decay + 1];

				#endregion

			}
			catch (Exception e) { Print(line + ": " + e.ToString()); }
		}
		//===================================================================================================================
		
		private void ResetPerRunCustomValues()
		{
			sequence.Clear();
			srType = 0;
			preSrType = 0;

			lastHighIdx = 0;
			lastLowIdx = 0;
			priorSwingHighIdx = 0;
			priorSwingLowIdx = 0;
			highCount = 0;
			lowCount = 0;
			preLastHighIdx = 0;
			preLastLowIdx = 0;
			zigzagDeviation = 0;
			currentHigh = 0;
			currentLow = 0;
			swingMax = 0;
			swingMin = 0;
			preCurrentHigh = 0;
			preCurrentLow = 0;
			addHigh = false;
			updateHigh = false;
			addLow = false;
			updateLow = false;
			drawHigherHighDot = false;
			drawLowerHighDot = false;
			drawDoubleTopDot = false;
			drawLowerLowDot = false;
			drawHigherLowDot = false;
			drawDoubleBottomDot = false;
			drawHigherHighLabel = false;
			drawLowerHighLabel = false;
			drawDoubleTopLabel = false;
			drawLowerLowLabel = false;
			drawHigherLowLabel = false;
			drawDoubleBottomLabel = false;
			drawSwingLegUp = false;
			drawSwingLegDown = false;
			intraBarAddHigh = false;
			intraBarUpdateHigh = false;
			intraBarAddLow = false;
			intraBarUpdateLow = false;

			dataStringHeight = 0;
			maxString1 = "";
			maxString2 = "";
		}
		
		#region -- OnRender : Custom Drawing --  
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (!this.ARC_PatternFinderAlgo_IsLicensed())
				return;

			if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) 
				return;
			
			var lastBarIndex = Math.Min(CurrentBars[0], ChartBars.ToIndex);//RIGHT BAR idx (absolute)
			if (lastBarIndex < BarsRequiredToPlot) 
				return;

			var firstBarIndex = Math.Max(BarsRequiredToPlot, ChartBars.FromIndex);//LEFT BAR idx (absolute)

			var oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

			#region -- Zero Line --
			DrawLine(0, 0, lastBarIndex, firstBarIndex, ZerolineColor, ZerolineStyle, ZerolineWidth, chartControl, chartScale);
			#endregion

			bullishBkgDxBrush = BullishBackgroundColor.ToDxBrush(RenderTarget);
			bullishBkgDxBrush.Opacity = BackgroundOpacity / 100f;
			bearishBkgDxBrush = BearishBackgroundColor.ToDxBrush(RenderTarget);
			bearishBkgDxBrush.Opacity = BackgroundOpacity / 100f;

			deepBullishBkgDxBrush = DeepBullishBackgroundColor.ToDxBrush(RenderTarget);
			deepBullishBkgDxBrush.Opacity = BackgroundOpacity / 100f;
			deepBearishBkgDxBrush = DeepBearishBackgroundColor.ToDxBrush(RenderTarget);
			deepBearishBkgDxBrush.Opacity = BackgroundOpacity / 100f;

			oppositeBkgDxBrush = OppositeBackgroundColor.ToDxBrush(RenderTarget);
			oppositeBkgDxBrush.Opacity = BackgroundOpacity / 100f;

			if (ShowBiasInBox)
			{
				dataTableDxBrush = DataTableColor.ToDxBrush(RenderTarget);
				bullishDivergenceDxBrush = BullishDivergenceColor.ToDxBrush(RenderTarget);
				bearishDivergenceDxBrush = BearishDivergenceColor.ToDxBrush(RenderTarget);
			}

			//			var BullishAccelerationDXBrush = BullishAccelerationColor.ToDxBrush(RenderTarget);
			//			var BearishAccelerationDXBrush = BearishAccelerationColor.ToDxBrush(RenderTarget);

			#region -- Draw Channel + Div on indicator panel + flooding on momo panel --
			var drawbbchannel = CurrentBars[0] > BarsRequiredToPlot && ChannelOpacity > 0;
			var divergenceSpan = 0;
			var channelBkgDxBrush = ChannelColor.ToDxBrush(RenderTarget);
			channelBkgDxBrush.Opacity = ChannelOpacity / 100f;
			//	Print("7953  Background flooding: "+BackgroundFlooding.ToString());

			for (var i = lastBarIndex; i >= firstBarIndex; i--)
			{
				try
				{
					#region -- draw Bollinger Channel --
					if (drawbbchannel)
					{
						//						int x = chartControl.GetXByBarIndex(chartControl.BarsArray[0], i);
						//						int y = chartScale.GetYByValue(-3);
						//						RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x,y),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
						//						var y0 = chartScale.GetYByValue(Upper.GetValueAt(i));
						//						var y1 = chartScale.GetYByValue(Upper.GetValueAt(i - 1));
						//						var y2 = chartScale.GetYByValue(Lower.GetValueAt(i - 1));
						//						var y3 = chartScale.GetYByValue(Lower.GetValueAt(i));
						//						var x0 = chartControl.GetXByBarIndex(chartControl.BarsArray[0], i);
						//						var x1 = chartControl.GetXByBarIndex(chartControl.BarsArray[0], i - 1);
						//if(i==lastBarIndex) {
						//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x0,y0),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
						//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x1,y1),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
						//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x1,y2),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
						//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x0,y3),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
						//}
						DrawRegion(
							new double[] { Upper.GetValueAt(i), Upper.GetValueAt(i - 1), Lower.GetValueAt(i - 1), Lower.GetValueAt(i) },
							new int[] { i, i - 1, i - 1, i },
							channelBkgDxBrush, chartControl, chartScale);//25.05.16 - beta11 code breaking change
					}
					#endregion

					//##MODIF## AzurITec - 18.05.2016
					#region -- flooding on momo panel only --
					if (BackgroundFlooding != ARC_PatternFinderAlgo_VMAlgo_Flooding.None)
					{
						var indexes = new int[] { i, i + 1, i + 1, i };
						var minmax = new double[] { chartScale.MaxValue, chartScale.MaxValue, chartScale.MinValue, chartScale.MinValue };
						if (BackgroundFlooding == ARC_PatternFinderAlgo_VMAlgo_Flooding.Histogram)
						{
							if (Histogram.GetValueAt(i) > 0)
								DrawRegion(minmax, indexes, bullishBkgDxBrush, chartControl, chartScale, false, true);
							else if (Histogram.GetValueAt(i) < 0)
								DrawRegion(minmax, indexes, bearishBkgDxBrush, chartControl, chartScale, false, true);
							else if (Histogram.GetValueAt(i + 1) > 0)
								DrawRegion(minmax, indexes, bullishBkgDxBrush, chartControl, chartScale, false, true);
							else
								DrawRegion(minmax, indexes, bearishBkgDxBrush, chartControl, chartScale, false, true);
						}
						else if (BackgroundFlooding == ARC_PatternFinderAlgo_VMAlgo_Flooding.Structure)
						{
							if (structureBiasState.GetValueAt(i) > 0)
								DrawRegion(minmax, indexes, bullishBkgDxBrush, chartControl, chartScale, false, true);
							else if (structureBiasState.GetValueAt(i) < 0)
								DrawRegion(minmax, indexes, bearishBkgDxBrush, chartControl, chartScale, false, true);
						}
						else
						{
							if (structureBiasState.GetValueAt(i) > 0)
							{
								if (Histogram.GetValueAt(i) > 0)
									DrawRegion(minmax, indexes, deepBullishBkgDxBrush, chartControl, chartScale, false, true);
								else if (Histogram.GetValueAt(i) < 0)
									DrawRegion(minmax, indexes, oppositeBkgDxBrush, chartControl, chartScale, false, true);
								else if (Histogram.GetValueAt(i + 1) > 0)
									DrawRegion(minmax, indexes, deepBullishBkgDxBrush, chartControl, chartScale, false, true);
								else
									DrawRegion(minmax, indexes, oppositeBkgDxBrush, chartControl, chartScale, false, true);
							}
							else if (structureBiasState.GetValueAt(i) < 0)
							{
								if (Histogram.GetValueAt(i) > 0)
									DrawRegion(minmax, indexes, oppositeBkgDxBrush, chartControl, chartScale, false, true);
								else if (Histogram.GetValueAt(i) < 0)
									DrawRegion(minmax, indexes, deepBearishBkgDxBrush, chartControl, chartScale, false, true);
								else if (Histogram.GetValueAt(i + 1) > 0)
									DrawRegion(minmax, indexes, oppositeBkgDxBrush, chartControl, chartScale, false, true);
								else
									DrawRegion(minmax, indexes, deepBearishBkgDxBrush, chartControl, chartScale, false, true);
							}
							else
							{
								if (Histogram.GetValueAt(i) > 0)
									DrawRegion(minmax, indexes, bullishBkgDxBrush, chartControl, chartScale, false, true);
								else if (Histogram.GetValueAt(i) < 0)
									DrawRegion(minmax, indexes, bearishBkgDxBrush, chartControl, chartScale, false, true);
								else if (Histogram.GetValueAt(i + 1) > 0)
									DrawRegion(minmax, indexes, bullishBkgDxBrush, chartControl, chartScale, false, true);
								else
									DrawRegion(minmax, indexes, bearishBkgDxBrush, chartControl, chartScale, false, true);
							}
						}
					}
					#endregion

				}
				catch (Exception) { }//After testing, didn't find any problem. Let Try Catch to avoid crashes...
			}
			#endregion

			#region -- excursion levels --
			try
			{
				var idxMin = lastBarIndex;
				var idxMax = firstBarIndex;
				int x1;

				var idxHLineStart = idxMax;
				if (PlotStyleLevels == PlotStyle.HLine) idxMax = idxMin;

				for (var i = idxMin; i >= idxMax; i--)
				{
					x1 = PlotStyleLevels == PlotStyle.HLine ? idxHLineStart : i - 1;
					#region -- Excursion Levels --
					if (DisplayLevel3)
					{
						DrawLine(PriceExcursionUL3.GetValueAt(i), PriceExcursionUL3.GetValueAt(i - 1), i, x1, Level3Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
						DrawLine(PriceExcursionLL3.GetValueAt(i), PriceExcursionLL3.GetValueAt(i - 1), i, x1, Level3Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
					}
					if (DisplayLevel2)
					{
						DrawLine(PriceExcursionUL2.GetValueAt(i), PriceExcursionUL2.GetValueAt(i - 1), i, x1, Level2Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
						DrawLine(PriceExcursionLL2.GetValueAt(i), PriceExcursionLL2.GetValueAt(i - 1), i, x1, Level2Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
					}
					if (DisplayLevel1)
					{
						DrawLine(PriceExcursionUL1.GetValueAt(i), PriceExcursionUL1.GetValueAt(i - 1), i, x1, Level1Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
						DrawLine(PriceExcursionLL1.GetValueAt(i), PriceExcursionLL1.GetValueAt(i - 1), i, x1, Level1Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
					}
					#endregion
				}
			}
			catch (Exception) { }//thrown if scrollback to chart first bar
			#endregion

			if (OverprintSentimentBox) base.OnRender(chartControl, chartScale);
			#region -- Draw the Sentiment Box --
			if (ShowBiasInBox && SentimentBoxLocation != ARC_PatternFinderAlgo_VMAlgo_SentimentBoxLocations.Hide)
			{
				var maxStringWidth1 = GetTextWidth(maxString1, dataFont1);
				var maxStringWidth2 = GetTextWidth(maxString2, dataFont2);
				var maxStringWidth = Math.Max(maxStringWidth1, maxStringWidth2);

				var offset1 = ChartPanel.X + ChartPanel.W - 1.2f * maxStringWidth;
				if (SentimentBoxLocation == ARC_PatternFinderAlgo_VMAlgo_SentimentBoxLocations.Left)
				{
					offset1 = ChartPanel.X + 10f;
				}
				var offset2 = offset1 + 0.03f * maxStringWidth;
				var offset3 = offset1 + 0.08f * maxStringWidth;
				var offset6 = offset1 + 1.17f * maxStringWidth;
				var pos11 = ChartPanel.Y + 0.01f * ChartPanel.H;
				var pos12 = ChartPanel.Y + 0.97f * ChartPanel.H;
				var midPoint = ChartPanel.Y + 0.49f * ChartPanel.H;
				float pos1, pos1F, pos2, pos2F, pos3, pos3F, pos4, pos4F, pos5, pos6, pos6F;

				pos1 = pos2 = pos2F = pos3 = pos4 = pos4F = 0;
				pos5 = midPoint - 1.3f * (float)dataStringHeight;
				pos6F = midPoint - 0f * (float)dataStringHeight;
				pos6 = midPoint + 0.2f * (float)dataStringHeight;

				DrawRectangle(offset2, pos11, 1.14f * maxStringWidth, 0.99f * ChartPanel.H - 3, dataTableDxBrush);
				DrawLine((double)offset2, (double)offset6, (double)pos11, (double)pos11, TextBoxOutlineColor, DashStyleHelper.Solid, 1);
				DrawLine((double)offset2, (double)offset6, (double)pos12, (double)pos12, TextBoxOutlineColor, DashStyleHelper.Solid, 1);
				DrawLine((double)offset2, (double)offset2, (double)pos11, (double)pos12, TextBoxOutlineColor, DashStyleHelper.Solid, 1);
				DrawLine((double)offset6, (double)offset6, (double)pos11, (double)pos12, TextBoxOutlineColor, DashStyleHelper.Solid, 1);

				var filterValue = structureBiasState.GetValueAt(lastBarIndex);

				if (ShowBiasInBox)
				{
					#region -- BIAS State --
					Drawstring("STRUCTURE BIAS:", offset1 + 0.1f * maxStringWidth, pos5, dataFont1, TextColor, SharpDX.DirectWrite.TextAlignment.Leading);
					if (filterValue > 0)
					{
						DrawRectangle(offset3, pos6F, 1.04f * maxStringWidth, 1.4f * dataStringHeight, bullishDivergenceDxBrush);
						Drawstring(UpBiasString, offset3, pos6, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
					}
					else if (filterValue < 0)
					{
						DrawRectangle(offset3, pos6F, 1.04f * maxStringWidth, 1.4f * dataStringHeight, bearishDivergenceDxBrush);
						Drawstring(DwBiasString, offset3, pos6, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
					}
					else
					{
						DrawLine(offset3, offset3 + 1.04f * maxStringWidth, pos6F, pos6F, TextColor, DashStyleHelper.Solid, 1);
						DrawLine(offset3, offset3 + 1.04f * maxStringWidth, pos6F + 1.4f * dataStringHeight, pos6F + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
						DrawLine(offset3, offset3, pos6F, pos6F + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
						DrawLine(offset3 + 1.04f * maxStringWidth, offset3 + 1.04f * maxStringWidth, pos6F, pos6F + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
						Drawstring(NeutralBiasString, offset3, pos6 + 0.1f * dataStringHeight, dataFont1, TextColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
					}
					#endregion
				}
			}
			#endregion
			if (!OverprintSentimentBox) base.OnRender(chartControl, chartScale);

			RenderTarget.AntialiasMode = oldAntialiasMode;
			channelBkgDxBrush.Dispose(); channelBkgDxBrush = null;
			bullishBkgDxBrush.Dispose(); bullishBkgDxBrush = null;
			bearishBkgDxBrush.Dispose(); bearishBkgDxBrush = null;
			deepBullishBkgDxBrush.Dispose(); deepBullishBkgDxBrush = null;
			deepBearishBkgDxBrush.Dispose(); deepBearishBkgDxBrush = null;
			oppositeBkgDxBrush.Dispose(); oppositeBkgDxBrush = null;
			if (ShowBiasInBox)
			{
				dataTableDxBrush.Dispose(); dataTableDxBrush = null;
				bullishDivergenceDxBrush.Dispose(); bullishDivergenceDxBrush = null;
				bearishDivergenceDxBrush.Dispose(); bearishDivergenceDxBrush = null;
			}
		}
		#endregion

		#region -- drawing functions { AzurITec } --
		//Draw Rectangle Region. x and y as pixel coordinate, w and h in pixel too.
		private void DrawRectangle(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush, int opacity = 100)
		{
			DrawRegion(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush);
		}

		private void DrawRegion(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
		{
			var vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

			var geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
			var sink1 = geo1.Open();
			sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
			sink1.AddLines(vectors);
			sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink1.Close();

			RenderTarget.FillGeometry(geo1, dxbrush);
			geo1.Dispose();
			sink1.Dispose();
		}

		private void DrawRegion(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false, bool atMiddle = false)
		{
#if USE_WPF_COORDS
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[3]))
                },
                dxbrush
                );
#else
			DrawRegion(new Point[]{
					new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[0])),
					new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[1])),
					new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[2])),
					new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[3]))
				},
				dxbrush
				);
#endif
		}

		//Draw a line between 2 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
		private void DrawLine(double val1, double val2, int idxslot1, int idxslot2, Brush couleur, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false)
		{
			var linebrush = couleur.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.DashStyle _dashstyle;
			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

			var properties = new SharpDX.Direct2D1.StrokeStyleProperties { DashStyle = _dashstyle };
			var strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

#if USE_WPF_COORDS
            Point p0 = new Point(GetX0(idxslot1, chartControl), drawOnPricePanel ? 0 : ChartPanel.Y + chartScale.GetYByValueWpf(val1));
            Point p1 = new Point(GetX0(idxslot2, chartControl), drawOnPricePanel ? 0 : ChartPanel.Y + chartScale.GetYByValueWpf(val2));
#else
			var p0 = new Point(GetX0(idxslot1, chartControl), drawOnPricePanel ? 0 : chartScale.GetYByValue(val1));
			var p1 = new Point(GetX0(idxslot2, chartControl), drawOnPricePanel ? 0 : chartScale.GetYByValue(val2));
#endif
			RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

			linebrush.Dispose();
			strokestyle.Dispose();
		}
		//Draw a line between 2 points in pixel coordinates.        
		private void DrawLine(double x1, double x2, double y1, double y2, Brush couleur, DashStyleHelper dashstyle, int width)
		{
			var linebrush = couleur.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.DashStyle _dashstyle;
			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

			var properties = new SharpDX.Direct2D1.StrokeStyleProperties { DashStyle = _dashstyle };
			var strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

			var p0 = new Point(x1, y1);
			var p1 = new Point(x2, y2);
			RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

			linebrush.Dispose();
			strokestyle.Dispose();
		}

		//Draw a text at {x;y} coordinates in pixel.
		private void Drawstring(string text, double x, double y, SimpleFont font, Brush textBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
		{
			var factory = new SharpDX.Direct2D1.Factory();
			var textpoint = new Point(x, y);
			var textFormat = new TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
				)
			{ TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
			var textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? GetTextWidth(text, font) : width, float.MaxValue);

			var textBrushDx = textBrush.ToDxBrush(RenderTarget);
			RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textBrushDx, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
			textBrushDx.Dispose(); textBrushDx = null;

			textLayout.Dispose();
			textFormat.Dispose();
		}

		private static float GetTextWidth(string text, SimpleFont font)
		{
			var textFormat = new TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
				);
			var textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			var textwidth = textLayout.Metrics.Width;

			textLayout.Dispose();
			textFormat.Dispose();

			return textwidth;
		}

		//retrieve the x coordinate in pixel of a a relative bar index.
		//##MODIF## AzurITec - 18.05.2016
		private static int GetX0(int bars, ChartControl chartControl, bool atMiddle = false) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars) - (atMiddle ? (int)(chartControl.Properties.BarDistance / 2) : 0); }//NEW VERSION NT8        
		#endregion

		#region -- Properties ------------------------------------------------------------

		#region -- PLOTS --
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BBMACD { get { return Values[BbMacdIdx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BBMACDFrame { get { return Values[BbMacdFrameIdx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BBMACDLine { get { return Values[BbMacdLineIdx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Average { get { return Values[AverageIdx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Upper { get { return Values[UpperIdx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Lower { get { return Values[LowerIdx]; } }

		/// <summary>
		/// RJ5Group LLC
		/// </summary>
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Histogram { get { return Values[HistogramIdx]; } }

		/// <summary>
		/// //rj RJ5GROUP code Algorithm
		/// </summary>
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriceExcursionUL3 { get { return Values[PriceExcursionUl3Idx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriceExcursionUL2 { get { return Values[PriceExcursionUl2Idx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriceExcursionUL1 { get { return Values[PriceExcursionUl1Idx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriceExcursionLL1 { get { return Values[PriceExcursionLl1Idx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriceExcursionLL2 { get { return Values[PriceExcursionLl2Idx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriceExcursionLL3 { get { return Values[PriceExcursionLl3Idx]; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriceExcursionMAX { get { return Values[PriceExcursionMaxIdx]; } }
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriceExcursionMIN { get { return Values[PriceExcursionMinIdx]; } }
		#endregion

		#region -- Exposed DataSeries --
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> StructureBiasState
		{
			get
			{
				Update();
				return structureBiasState;
			}
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SwingHighsState
		{
			get
			{
				Update();
				return swingHighsState;
			}
		}//#SWINGS
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SwingLowsState
		{
			get
			{
				Update();
				return swingLowsState;
			}
		}//#SWINGS

		#region -- Trend Filters --
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BBDotTrend { get { return bbDotTrend; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MomoSignum { get { return momoSigNum; } }
		#endregion

		#endregion

		[NinjaScriptProperty]
		[Display(Name = "Optimize for Speed", GroupName = "Parameters", Description = "Improve run-time performance (reduces the number of historical chart markers", Order = 0)]
		public ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings OptimizeSpeed { get; set; }

		#region GroupName = "MACDBB Parameters"
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Period Bollinger Band", GroupName = "MACDBB Parameters", Description = "Band Period for Bollinger Band", Order = 0)]
		public int BandPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Lookback fast EMA", GroupName = "MACDBB Parameters", Description = "Period for fast EMA", Order = 1)]
		public int Fast { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Lookback slow EMA", GroupName = "MACDBB Parameters", Description = "Period for slow EMA", Order = 2)]
		public int Slow { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Std. dev. multiplier", GroupName = "MACDBB Parameters", Description = "Number of standard deviations", Order = 3)]
		public double StdDevNumber { get; set; }
		#endregion

		#region GroupName = "SwingTrend Parameters"
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 0)]
		public int SwingStrength { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Deviation multiplier", GroupName = "SwingTrend Parameters", Description = "Multiplier used to calculate minimum deviation as an ATR multiple", Order = 1)]
		public double MultiplierMD { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Sensitivity double tops/bottoms", GroupName = "SwingTrend Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 2)]
		public double MultiplierDTB { get; set; }
		#endregion

		#region GroupName = "Display Options Oscillator Panel"
		[Display(Name = "Background Flooding", GroupName = "Display Options Oscillator Panel", Description = "Choose the type of background flooding to show", Order = 1)]
		public ARC_PatternFinderAlgo_VMAlgo_Flooding BackgroundFlooding { get; set; }

		[Display(Name = "Display Structure Bias in box", GroupName = "Display Options Oscillator Panel", Description = "Option to display or remove the Structure Bias in Box", Order = 3)]
		public bool ShowBiasInBox { get; set; }
		#endregion

		#region GroupName = "Display Options Swing Trend"
		[Range(1, double.MaxValue)]
		[Display(Name = "Dotsize swing dots", GroupName = "Display Options Swing Trend", Description = "Dotsize for swing dots representing swing highs and swing lows", Order = 0)]
		public int SwingDotSize { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Fontsize swing labels", GroupName = "Display Options Swing Trend", Description = "Dotsize for swing labels for swing highs and swing lows", Order = 1)]
		public int LabelFontSize { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width swing legs", GroupName = "Display Options Swing Trend", Description = "Select thickness of swing legs connecting swing highs and lows", Order = 2)]
		public int SwingLegWidth { get; set; }

		[Display(Name = "Show swing dots", GroupName = "Display Options Swing Trend", Description = "Show dots for swing highs and lows", Order = 3)]
		public bool ShowZigzagDots { get; set; }

		[Display(Name = "Show swing labels", GroupName = "Display Options Swing Trend", Description = "Show labels for swing highs and lows", Order = 4)]
		public bool ShowZigzagLabels { get; set; }

		[Display(Name = "Show swing legs", GroupName = "Display Options Swing Trend", Description = "Show swing legs connecting swing highs and lows", Order = 5)]
		public bool ShowZigzagLegs { get; set; }

		[Display(Name = "Dash style swing legs", GroupName = "Display Options Swing Trend", Description = "Dash style for swing legs.", Order = 6)]
		public DashStyleHelper SwingLegStyle { get; set; }
		#endregion

		//rj RJ5GROUP code Algorithm
		#region GroupName = "Display Options Price Excursions"
		[Display(GroupName = "Display Options Price Excursions", Description = "Display Level 1", Order = 0)]
		public bool DisplayLevel1 { get; set; }

		[Display(GroupName = "Display Options Price Excursions", Description = "Display Level 2", Order = 1)]
		public bool DisplayLevel2 { get; set; }

		[Display(GroupName = "Display Options Price Excursions", Description = "Display Level 3", Order = 2)]
		public bool DisplayLevel3 { get; set; }
		#endregion

		#region GroupName = "Plot Parameters"
		[Range(1, int.MaxValue)]
		[Display(Name = "Dot size MACD", GroupName = "Plot Parameters", Description = "Dotsize for MACD dots", Order = 0)]
		public int DotSize { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width connectors", GroupName = "Plot Parameters", Description = "Width for MACD connectors.", Order = 1)]
		public int Plot2Width { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width average", GroupName = "Plot Parameters", Description = "Width for Average of Bollinger Bands.", Order = 2)]
		public int Plot3Width { get; set; }

		[Display(Name = "Dash style average", GroupName = "Plot Parameters", Description = "DashStyleHelper for Average of Bollinger Bands.", Order = 3)]
		public DashStyleHelper Dash3Style { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width Bollinger Bands", GroupName = "Plot Parameters", Description = "Width for Bollinger Bands.", Order = 4)]
		public int Plot4Width { get; set; }

		[Display(Name = "Dash style Bollinger Bands", GroupName = "Plot Parameters", Description = "DashStyleHelper for Bollinger Bands.", Order = 5)]
		public DashStyleHelper Dash4Style { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width zeroline", GroupName = "Plot Parameters", Description = "Width for Zero Line.", Order = 6)]
		public int ZerolineWidth { get; set; }

		[Display(Name = "Dash style zeroline", GroupName = "Plot Parameters", Description = "DashStyleHelper for Zero Line.", Order = 7)]
		public DashStyleHelper ZerolineStyle { get; set; }

		[Range(0, 100)]
		[Display(Name = "Opacity channel shading", GroupName = "Plot Parameters", Description = "Opacity for shading the area between the Bollinger Bands", Order = 8)]
		public int ChannelOpacity { get; set; }

		[Range(0, 100)]
		[Display(Name = "Opacity background flooding", GroupName = "Plot Parameters", Description = "Opacity used for flooding the chart background", Order = 9)]
		public int BackgroundOpacity { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width histogram bars", GroupName = "Plot Parameters", Description = "Width for the Histogram Momo.", Order = 10)]
		public int MomoWidth { get; set; }
		#endregion

		#region GroupName = "Plot Colors"
		[XmlIgnore]
		[Display(Name = "Rising dots above channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 0)]
		public Brush DotsUpRisingColor { get; set; }
		[Browsable(false)]
		public string DotsUpRisingColorSerialize
		{
			get { return Serialize.BrushToString(DotsUpRisingColor); }
			set { DotsUpRisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Rising dots inside/below channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 1)]
		public Brush DotsDownRisingColor { get; set; }
		[Browsable(false)]
		public string DotsDownRisingColorSerialize
		{
			get { return Serialize.BrushToString(DotsDownRisingColor); }
			set { DotsDownRisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling dots below channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 2)]
		public Brush DotsDownFallingColor { get; set; }
		[Browsable(false)]
		public string DotsDownFallingColorSerialize
		{
			get { return Serialize.BrushToString(DotsDownFallingColor); }
			set { DotsDownFallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling dots inside/above channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 3)]
		public Brush DotsUpFallingColor { get; set; }
		[Browsable(false)]
		public string DotsUpFallingColorSerialize
		{
			get { return Serialize.BrushToString(DotsUpFallingColor); }
			set { DotsUpFallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Dots rim", GroupName = "Plot Colors", Description = "Select Color", Order = 4)]
		public Brush DotsRimColor { get; set; }
		[Browsable(false)]
		public string DotsRimColorSerialize
		{
			get { return Serialize.BrushToString(DotsRimColor); }
			set { DotsRimColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger average", GroupName = "Plot Colors", Description = "Select Color", Order = 5)]
		public Brush BBAverageColor { get; set; }
		[Browsable(false)]
		public string BBAverageColorSerialize
		{
			get { return Serialize.BrushToString(BBAverageColor); }
			set { BBAverageColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger upper band", GroupName = "Plot Colors", Description = "Select Color", Order = 6)]
		public Brush BBUpperColor { get; set; }
		[Browsable(false)]
		public string BBUpperColorSerialize
		{
			get { return Serialize.BrushToString(BBUpperColor); }
			set { BBUpperColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger lower band", GroupName = "Plot Colors", Description = "Select Color", Order = 7)]
		public Brush BBLowerColor { get; set; }
		[Browsable(false)]
		public string BBLowerColorSerialize
		{
			get { return Serialize.BrushToString(BBLowerColor); }
			set { BBLowerColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Hi Color", GroupName = "Plot Colors", Description = "Select Color", Order = 8)]
		public Brush HistUpColor { get; set; }
		[Browsable(false)]
		public string HistUpColorSerialize
		{
			get { return Serialize.BrushToString(HistUpColor); }
			set { HistUpColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Down Color", GroupName = "Plot Colors", Description = "Select Color", Order = 9)]
		public Brush HistDownColor { get; set; }
		[Browsable(false)]
		public string HistDownColorSerialize
		{
			get { return Serialize.BrushToString(HistDownColor); }
			set { HistDownColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Zeroline", GroupName = "Plot Colors", Description = "Select Color", Order = 10)]
		public Brush ZerolineColor { get; set; }
		[Browsable(false)]
		public string ZerolineColorSerialize
		{
			get { return Serialize.BrushToString(ZerolineColor); }
			set { ZerolineColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Connector", GroupName = "Plot Colors", Description = "Select Color", Order = 11)]
		public Brush ConnectorColor { get; set; }
		[Browsable(false)]
		public string ConnectorColorSerialize
		{
			get { return Serialize.BrushToString(ConnectorColor); }
			set { ConnectorColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Channel shading", GroupName = "Plot Colors", Description = "Select Color", Order = 12)]
		public Brush ChannelColor { get; set; }
		[Browsable(false)]
		public string ChannelColorSerialize
		{
			get { return Serialize.BrushToString(ChannelColor); }
			set { ChannelColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Deep Bearish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 17)]
		public Brush DeepBearishBackgroundColor { get; set; }
		[Browsable(false)]
		public string DeepBearishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(DeepBearishBackgroundColor); }
			set { DeepBearishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bearish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 16)]
		public Brush BearishBackgroundColor { get; set; }
		[Browsable(false)]
		public string BearishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(BearishBackgroundColor); }
			set { BearishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Opposite background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 15)]
		public Brush OppositeBackgroundColor { get; set; }
		[Browsable(false)]
		public string OppositeBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(OppositeBackgroundColor); }
			set { OppositeBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bullish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 14)]
		public Brush BullishBackgroundColor { get; set; }
		[Browsable(false)]
		public string BullishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(BullishBackgroundColor); }
			set { BullishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Deep Bullish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 13)]
		public Brush DeepBullishBackgroundColor { get; set; }
		[Browsable(false)]
		public string DeepBullishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(DeepBullishBackgroundColor); }
			set { DeepBullishBackgroundColor = Serialize.StringToBrush(value); }
		}
		#endregion

		//rj RJ5GROUP code Algorithm
		#region Category("Price Excursion - Plot Colors")
		[XmlIgnore]
		[Display(Name = "Color level 1 ", GroupName = "Price Excursion - Plot Colors", Description = "Select Color for Level 1 lines", Order = 0)]
		public Brush Level1Color { get; set; }
		[Browsable(false)]
		public string Level1ColorSerialize
		{
			get { return Serialize.BrushToString(Level1Color); }
			set { Level1Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Color level 2 ", GroupName = "Price Excursion - Plot Colors", Description = "Select Color for Level 2 lines", Order = 1)]
		public Brush Level2Color { get; set; }
		[Browsable(false)]
		public string Level2ColorSerialize
		{
			get { return Serialize.BrushToString(Level2Color); }
			set { Level2Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Color level 3 ", GroupName = "Price Excursion - Plot Colors", Description = "Select Color for Level 3 lines", Order = 2)]
		public Brush Level3Color { get; set; }
		[Browsable(false)]
		public string Level3ColorSerialize
		{
			get { return Serialize.BrushToString(Level3Color); }
			set { Level3Color = Serialize.StringToBrush(value); }
		}
		#endregion

		//rj RJ5GROUP code Algorithm
		#region Category("Price Excursion - Plot Colors")
		[Display(Name = "Plot style for Level Lines", GroupName = "Price Excursion - Plot Parameters", Description = "PlotStyle for Level Lines", Order = 0)]
		public PlotStyle PlotStyleLevels { get; set; }

		[Display(Name = "Dash style for Level Lines", GroupName = "Price Excursion - Plot Parameters", Description = "DashStyleHelper for level lines", Order = 1)]
		public DashStyleHelper DashStyleHelperLevels { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width for level lines", GroupName = "Price Excursion - Plot Parameters", Description = "Width for level lines", Order = 2)]
		public int PlotWidthLevels { get; set; }
		#endregion

		#region GroupName = "Sentiment Box - Colors"
		[XmlIgnore]
		[Display(Name = "Bearish Acceleration", GroupName = "Sentiment Box - Colors", Description = "Select color for bearish acceleration signal", Order = 1)]
		public Brush BearishAccelerationColor { get; set; }
		[Browsable(false)]
		public string BearishAccelerationColorSerialize
		{
			get { return Serialize.BrushToString(BearishAccelerationColor); }
			set { BearishAccelerationColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bearish Divergence", GroupName = "Sentiment Box - Colors", Description = "Select color for bearish divergence signal", Order = 2)]
		public Brush BearishDivergenceColor { get; set; }
		[Browsable(false)]
		public string BearishDivergenceColorSerialize
		{
			get { return Serialize.BrushToString(BearishDivergenceColor); }
			set { BearishDivergenceColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bearish Foreground", GroupName = "Sentiment Box - Colors", Description = "Select color for bearish foreground text", Order = 3)]
		public Brush BearishForegroundColor { get; set; }
		[Browsable(false)]
		public string BearishForegroundColorSerialize
		{
			get { return Serialize.BrushToString(BearishForegroundColor); }
			set { BearishForegroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bullish Acceleration", GroupName = "Sentiment Box - Colors", Description = "Select color for bullish acceleration signal", Order = 3)]
		public Brush BullishAccelerationColor { get; set; }
		[Browsable(false)]
		public string BullishAccelerationColorSerialize
		{
			get { return Serialize.BrushToString(BullishAccelerationColor); }
			set { BullishAccelerationColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bullish Divergence", GroupName = "Sentiment Box - Colors", Description = "Select color for bullish divergence signal", Order = 4)]
		public Brush BullishDivergenceColor { get; set; }
		[Browsable(false)]
		public string BullishDivergenceColorSerialize
		{
			get { return Serialize.BrushToString(BullishDivergenceColor); }
			set { BullishDivergenceColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bullish Foreground", GroupName = "Sentiment Box - Colors", Description = "Select color for bullish foreground text", Order = 5)]
		public Brush BullishForegroundColor { get; set; }
		[Browsable(false)]
		public string BullishForegroundColorSerialize
		{
			get { return Serialize.BrushToString(BullishForegroundColor); }
			set { BullishForegroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Box Outline Color", GroupName = "Sentiment Box - Colors", Description = "Select color if there is no bullish or bearish indication", Order = 6)]
		public Brush TextBoxOutlineColor { get; set; }
		[Browsable(false)]
		public string TextBoxOutlineColorSerialize
		{
			get { return Serialize.BrushToString(TextBoxOutlineColor); }
			set { TextBoxOutlineColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Text Color", GroupName = "Sentiment Box - Colors", Description = "Select color if there is no bullish or bearish indication", Order = 7)]
		public Brush TextColor { get; set; }
		[Browsable(false)]
		public string TextColorSerialize
		{
			get { return Serialize.BrushToString(TextColor); }
			set { TextColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Background Color", GroupName = "Sentiment Box - Colors", Description = "Select color for back ground of display", Order = 8)]
		public Brush DataTableColor { get; set; }
		[Browsable(false)]
		public string DataTableColorSerialize
		{
			get { return Serialize.BrushToString(DataTableColor); }
			set { DataTableColor = Serialize.StringToBrush(value); }
		}
		#endregion

		//JQ 11.26.2017
		// Bug 12782. The set right margin is causing the shifting of the SDV bar when the PP bar and the Divergence indicator
		// are all on the same chart. This could be a NT8 issue as it appears the BarMarginRight is only applied to the
		// primary bar (PP) rather than the secondary bar SDV). For now, I will disable the setrightmargin properties
		// until I have a chance to talk to NT about this issue.
		// --start--
		#region Category("Sentiment Box - Parameters")
		//        [Display(Name = "Set right side margin", GroupName = "Sentiment Box - Parameters", Description = "When set to true the margin required between the last bar and the chart boundary is set as needed for the box", Order = 1)]
		//        public bool SetRightSideMargin { get; set; }
		// --End--

		[Range(1, int.MaxValue)]
		[Display(Name = "Fontsize", GroupName = "Sentiment Box - Parameters", Description = "Select fontsize for text which appears in the box", Order = 0)]
		public int DataFontSize { get; set; }

		[Display(Name = "Location", GroupName = "Sentiment Box - Parameters", Description = "Select location of the sentiment box", Order = 10)]
		public ARC_PatternFinderAlgo_VMAlgo_SentimentBoxLocations SentimentBoxLocation { get; set; }

		[Display(Name = "Overprint?", GroupName = "Sentiment Box - Parameters", Description = "Will the sentiment box print on top of the histogram?", Order = 20)]
		public bool OverprintSentimentBox { get; set; }
		#endregion

		#region Category("Sentiment Box - Text Elements")
		[Display(Name = "Bullish Acceleration", GroupName = "Sentiment Box - Text Elements", Description = "Select text for bullish acceleration", Order = 1)]
		public string BullAccString { get; set; }

		[Display(Name = "Confirmed bull divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bullish divergence", Order = 4)]
		public string BullDivCString { get; set; }

		[Display(Name = "Potential bull divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bullish divergence", Order = 9)]
		public string BullDivPString { get; set; }

		[Display(Name = "Confirmed bull hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bullish hidden divergence", Order = 5)]
		public string BullHDivCString { get; set; }

		[Display(Name = "Potential bull hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bullish hidden divergence", Order = 10)]
		public string BullHDivPString { get; set; }

		[Display(Name = "Bearish Acceleration", GroupName = "Sentiment Box - Text Elements", Description = "Select text for bearish acceleration", Order = 0)]
		public string BearAccString { get; set; }

		[Display(Name = "Confirmed bear divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bearish divergence", Order = 2)]
		public string BearDivCString { get; set; }

		[Display(Name = "Potential bear divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bearish divergence", Order = 7)]
		public string BearDivPString { get; set; }

		[Display(Name = "Confirmed bear hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bearish hidden divergence", Order = 3)]
		public string BearHDivCString { get; set; }

		[Display(Name = "Potential bear hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bearish hidden divergence", Order = 8)]
		public string BearHDivPString { get; set; }

		[Display(Name = "Neutral condition", GroupName = "Sentiment Box - Text Elements", Description = "Select text for neutral condition without bullish or bearish indications", Order = 6)]
		public string NeutralString { get; set; }

		[Display(Name = "Up Trend Bias", GroupName = "Sentiment Box - Text Elements", Description = "Select text for Up Trend Bias", Order = 11)]
		public string UpBiasString { get; set; }

		[Display(Name = "Neutral Bias", GroupName = "Sentiment Box - Text Elements", Description = "Select text for Neutral Bias", Order = 12)]
		public string NeutralBiasString { get; set; }

		[Display(Name = "Down Trend Bias", GroupName = "Sentiment Box - Text Elements", Description = "Select text for Down Trend Bias", Order = 13)]
		public string DwBiasString { get; set; }
		#endregion

		[Display(Name = "Button Text", GroupName = "Indicator Display", Description = "", Order = 20)]
		public string pButtonText { get; set; }
		#endregion
	}
}

public enum ARC_PatternFinderAlgo_VMAlgo_BiasType { Structural, ZeroLine }
public enum ARC_PatternFinderAlgo_VMAlgo_InputType { High_Low, Close, Median, Typical }
public enum ARC_PatternFinderAlgo_VMAlgo_Flooding { None, Histogram, Structure, Both }
public enum ARC_PatternFinderAlgo_VMAlgo_ExcursionStyle { Static, Dynamic }
public enum ARC_PatternFinderAlgo_VMAlgo_SentimentBoxLocations { Left, Right, Hide }
public enum ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings { Max, Min, None }

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.AlgoSup.ARC_PatternFinderAlgo_VMAlgo[] cacheARC_PatternFinderAlgo_VMAlgo;
		public ARC.AlgoSup.ARC_PatternFinderAlgo_VMAlgo ARC_PatternFinderAlgo_VMAlgo(ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB)
		{
			return ARC_PatternFinderAlgo_VMAlgo(Input, optimizeSpeed, bandPeriod, fast, slow, stdDevNumber, swingStrength, multiplierMD, multiplierDTB);
		}

		public ARC.AlgoSup.ARC_PatternFinderAlgo_VMAlgo ARC_PatternFinderAlgo_VMAlgo(ISeries<double> input, ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB)
		{
			if (cacheARC_PatternFinderAlgo_VMAlgo != null)
				for (int idx = 0; idx < cacheARC_PatternFinderAlgo_VMAlgo.Length; idx++)
					if (cacheARC_PatternFinderAlgo_VMAlgo[idx] != null && cacheARC_PatternFinderAlgo_VMAlgo[idx].OptimizeSpeed == optimizeSpeed && cacheARC_PatternFinderAlgo_VMAlgo[idx].BandPeriod == bandPeriod && cacheARC_PatternFinderAlgo_VMAlgo[idx].Fast == fast && cacheARC_PatternFinderAlgo_VMAlgo[idx].Slow == slow && cacheARC_PatternFinderAlgo_VMAlgo[idx].StdDevNumber == stdDevNumber && cacheARC_PatternFinderAlgo_VMAlgo[idx].SwingStrength == swingStrength && cacheARC_PatternFinderAlgo_VMAlgo[idx].MultiplierMD == multiplierMD && cacheARC_PatternFinderAlgo_VMAlgo[idx].MultiplierDTB == multiplierDTB && cacheARC_PatternFinderAlgo_VMAlgo[idx].EqualsInput(input))
						return cacheARC_PatternFinderAlgo_VMAlgo[idx];
			return CacheIndicator<ARC.AlgoSup.ARC_PatternFinderAlgo_VMAlgo>(new ARC.AlgoSup.ARC_PatternFinderAlgo_VMAlgo(){ OptimizeSpeed = optimizeSpeed, BandPeriod = bandPeriod, Fast = fast, Slow = slow, StdDevNumber = stdDevNumber, SwingStrength = swingStrength, MultiplierMD = multiplierMD, MultiplierDTB = multiplierDTB }, input, ref cacheARC_PatternFinderAlgo_VMAlgo);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.AlgoSup.ARC_PatternFinderAlgo_VMAlgo ARC_PatternFinderAlgo_VMAlgo(ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB)
		{
			return indicator.ARC_PatternFinderAlgo_VMAlgo(Input, optimizeSpeed, bandPeriod, fast, slow, stdDevNumber, swingStrength, multiplierMD, multiplierDTB);
		}

		public Indicators.ARC.AlgoSup.ARC_PatternFinderAlgo_VMAlgo ARC_PatternFinderAlgo_VMAlgo(ISeries<double> input , ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB)
		{
			return indicator.ARC_PatternFinderAlgo_VMAlgo(input, optimizeSpeed, bandPeriod, fast, slow, stdDevNumber, swingStrength, multiplierMD, multiplierDTB);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.AlgoSup.ARC_PatternFinderAlgo_VMAlgo ARC_PatternFinderAlgo_VMAlgo(ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB)
		{
			return indicator.ARC_PatternFinderAlgo_VMAlgo(Input, optimizeSpeed, bandPeriod, fast, slow, stdDevNumber, swingStrength, multiplierMD, multiplierDTB);
		}

		public Indicators.ARC.AlgoSup.ARC_PatternFinderAlgo_VMAlgo ARC_PatternFinderAlgo_VMAlgo(ISeries<double> input , ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB)
		{
			return indicator.ARC_PatternFinderAlgo_VMAlgo(input, optimizeSpeed, bandPeriod, fast, slow, stdDevNumber, swingStrength, multiplierMD, multiplierDTB);
		}
	}
}

#endregion
