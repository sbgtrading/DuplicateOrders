#region Using declarations
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Strategies.Licensing;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC.Supporting
{
	[Browsable(false)]
	[CategoryOrder(ProductInfoGroupName, 1000)]
	public class ARC_VolDivAlgo_ARCIndicatorBase : Indicator, ARC_VolDivAlgo_IARCLicensedWithMessages
	{
		public const string ProductInfoGroupName = "Product Info";

		[XmlIgnore, Browsable(false)]
		public virtual string ProductInfusionSoftTag { get { return ""; } }
		[XmlIgnore, Browsable(false)]
		public List<string> ProductBundleInfusionSoftTags { get { return new List<string>(); } }
		[XmlIgnore, Browsable(false)]
		public TextFixed LicensingLoadingText { get; set; }
		[XmlIgnore, Browsable(false)]
		public TextFixed LicensingErrorText { get; set; }
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ProductVersion { get { return ""; } }
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ModuleName { get { return GetType().Name.Replace("ARC_", ""); } }
		[XmlIgnore, Browsable(false)]
		public virtual bool ColicensedOnly { get { return false; } }
		public override string DisplayName { get { return IsCreatedByStrategy ? "" : ModuleName + ARC_VolDivAlgo_ARCLicenseValidator.LicenseModeDenotingNameSuffix; } }

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = DisplayName;
				Calculate = Calculate.OnBarClose;
				IsOverlay = false;
				BarsRequiredToPlot = 1;
				IsSuspendedWhileInactive = true;
			}
			else if (State == State.Configure)
			{
				this.ARC_VolDivAlgo_EnactLicensingWithWarnings(ARC_VolDivAlgo_LicensingContextStep.Configure);
			}
		}

		protected override void OnBarUpdate()
		{
			this.ARC_VolDivAlgo_EnactLicensingWithWarnings(ARC_VolDivAlgo_LicensingContextStep.BarUpdate);
		}

		public override string ToString()
		{
			return DisplayName;
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Supporting.ARC_VolDivAlgo_ARCIndicatorBase[] cacheARC_VolDivAlgo_ARCIndicatorBase;
		public ARC.Supporting.ARC_VolDivAlgo_ARCIndicatorBase ARC_VolDivAlgo_ARCIndicatorBase()
		{
			return ARC_VolDivAlgo_ARCIndicatorBase(Input);
		}

		public ARC.Supporting.ARC_VolDivAlgo_ARCIndicatorBase ARC_VolDivAlgo_ARCIndicatorBase(ISeries<double> input)
		{
			if (cacheARC_VolDivAlgo_ARCIndicatorBase != null)
				for (int idx = 0; idx < cacheARC_VolDivAlgo_ARCIndicatorBase.Length; idx++)
					if (cacheARC_VolDivAlgo_ARCIndicatorBase[idx] != null &&  cacheARC_VolDivAlgo_ARCIndicatorBase[idx].EqualsInput(input))
						return cacheARC_VolDivAlgo_ARCIndicatorBase[idx];
			return CacheIndicator<ARC.Supporting.ARC_VolDivAlgo_ARCIndicatorBase>(new ARC.Supporting.ARC_VolDivAlgo_ARCIndicatorBase(), input, ref cacheARC_VolDivAlgo_ARCIndicatorBase);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Supporting.ARC_VolDivAlgo_ARCIndicatorBase ARC_VolDivAlgo_ARCIndicatorBase()
		{
			return indicator.ARC_VolDivAlgo_ARCIndicatorBase(Input);
		}

		public Indicators.ARC.Supporting.ARC_VolDivAlgo_ARCIndicatorBase ARC_VolDivAlgo_ARCIndicatorBase(ISeries<double> input )
		{
			return indicator.ARC_VolDivAlgo_ARCIndicatorBase(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Supporting.ARC_VolDivAlgo_ARCIndicatorBase ARC_VolDivAlgo_ARCIndicatorBase()
		{
			return indicator.ARC_VolDivAlgo_ARCIndicatorBase(Input);
		}

		public Indicators.ARC.Supporting.ARC_VolDivAlgo_ARCIndicatorBase ARC_VolDivAlgo_ARCIndicatorBase(ISeries<double> input )
		{
			return indicator.ARC_VolDivAlgo_ARCIndicatorBase(input);
		}
	}
}

#endregion
