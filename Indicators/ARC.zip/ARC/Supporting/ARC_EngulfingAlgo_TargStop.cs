#region Using declarations
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC.Supporting
{
	[Browsable(false)]
	public class ARC_EngulfingAlgo_TargStop : Indicator
	{
		[Browsable(false), XmlIgnore]
		public List<Plot> StopPlots => stopIndexes.Select(i => Plots[i]).ToList();

		[Browsable(false), XmlIgnore]
		public List<Plot> TargetPlots => targetIndexes.Select(i => Plots[i]).ToList();

		public readonly List<int> stopIndexes = new List<int> { 0 };
		public readonly List<int> targetIndexes = new List<int> { 1 };
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = "Target and Stops";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				DisplayInDataBox = true;
				DrawOnPricePanel = true;
				PaintPriceMarkers = true;
				IsChartOnly = true;
				IsSuspendedWhileInactive = true;
				BarsRequiredToPlot = 0;

				Stops = 1;
				Targets = 4;

				stopIndexes.Clear();
				for (var i = 0; i < 3; i++)
				{
					stopIndexes.Add(Plots.Length);
					AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Dot, $"Stop Loss {(i + 1)}");
				}
				
				targetIndexes.Clear();
				for (var i = 0; i < 3; i++) 
				{
					targetIndexes.Add(Plots.Length);
					AddPlot(new Stroke(Brushes.Lime, 2), PlotStyle.Dot, $"Target {(i + 1)}");
				}
			}
		}

		internal void SetStop(double value, int idx = -1)
		{
			Update();
			if (CurrentBar < 0)
				return;

			if (idx != -1)
			{
				Values[stopIndexes[idx]][0] = value;
				return;
			}

			foreach (var i in stopIndexes)
				Values[i][0] = value;
		}

		internal void SetTarget(double value, int idx = -1)
		{
			Update();
			if (CurrentBar < 0)
				return;

			if (idx != -1)
			{
				Values[targetIndexes[idx]][0] = value;
				return;
			}

			foreach (var i in targetIndexes)
				Values[i][0] = value;
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Stop Count", Order = 0, GroupName = "Parameters")]
		public int Stops { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Target Count", Order = 1, GroupName = "Parameters")]
		public int Targets { get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Supporting.ARC_EngulfingAlgo_TargStop[] cacheARC_EngulfingAlgo_TargStop;
		public ARC.Supporting.ARC_EngulfingAlgo_TargStop ARC_EngulfingAlgo_TargStop(int stops, int targets)
		{
			return ARC_EngulfingAlgo_TargStop(Input, stops, targets);
		}

		public ARC.Supporting.ARC_EngulfingAlgo_TargStop ARC_EngulfingAlgo_TargStop(ISeries<double> input, int stops, int targets)
		{
			if (cacheARC_EngulfingAlgo_TargStop != null)
				for (int idx = 0; idx < cacheARC_EngulfingAlgo_TargStop.Length; idx++)
					if (cacheARC_EngulfingAlgo_TargStop[idx] != null && cacheARC_EngulfingAlgo_TargStop[idx].Stops == stops && cacheARC_EngulfingAlgo_TargStop[idx].Targets == targets && cacheARC_EngulfingAlgo_TargStop[idx].EqualsInput(input))
						return cacheARC_EngulfingAlgo_TargStop[idx];
			return CacheIndicator<ARC.Supporting.ARC_EngulfingAlgo_TargStop>(new ARC.Supporting.ARC_EngulfingAlgo_TargStop(){ Stops = stops, Targets = targets }, input, ref cacheARC_EngulfingAlgo_TargStop);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Supporting.ARC_EngulfingAlgo_TargStop ARC_EngulfingAlgo_TargStop(int stops, int targets)
		{
			return indicator.ARC_EngulfingAlgo_TargStop(Input, stops, targets);
		}

		public Indicators.ARC.Supporting.ARC_EngulfingAlgo_TargStop ARC_EngulfingAlgo_TargStop(ISeries<double> input , int stops, int targets)
		{
			return indicator.ARC_EngulfingAlgo_TargStop(input, stops, targets);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Supporting.ARC_EngulfingAlgo_TargStop ARC_EngulfingAlgo_TargStop(int stops, int targets)
		{
			return indicator.ARC_EngulfingAlgo_TargStop(Input, stops, targets);
		}

		public Indicators.ARC.Supporting.ARC_EngulfingAlgo_TargStop ARC_EngulfingAlgo_TargStop(ISeries<double> input , int stops, int targets)
		{
			return indicator.ARC_EngulfingAlgo_TargStop(input, stops, targets);
		}
	}
}

#endregion
