using System.ComponentModel;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui;

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC.Supporting
{
	[Browsable(false)]
	public class ARC_CWAPAlgo_OrderSingle : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = "Order Single";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				DisplayInDataBox = true;
				DrawOnPricePanel = true;
				PaintPriceMarkers = true;
				IsChartOnly = true;
				IsSuspendedWhileInactive = true;
				AddPlot(new Stroke(Brushes.Green, 2), PlotStyle.Hash, "Entry Order L");
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Hash, "Entry OrderS ");
			}
		}

		#region Properties
		[Browsable(false), XmlIgnore]
		public Series<double> EntryPriceL => Values[0];

		[Browsable(false), XmlIgnore]
		public Series<double> EntryPriceS => Values[1];
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Supporting.ARC_CWAPAlgo_OrderSingle[] cacheARC_CWAPAlgo_OrderSingle;
		public ARC.Supporting.ARC_CWAPAlgo_OrderSingle ARC_CWAPAlgo_OrderSingle()
		{
			return ARC_CWAPAlgo_OrderSingle(Input);
		}

		public ARC.Supporting.ARC_CWAPAlgo_OrderSingle ARC_CWAPAlgo_OrderSingle(ISeries<double> input)
		{
			if (cacheARC_CWAPAlgo_OrderSingle != null)
				for (int idx = 0; idx < cacheARC_CWAPAlgo_OrderSingle.Length; idx++)
					if (cacheARC_CWAPAlgo_OrderSingle[idx] != null &&  cacheARC_CWAPAlgo_OrderSingle[idx].EqualsInput(input))
						return cacheARC_CWAPAlgo_OrderSingle[idx];
			return CacheIndicator<ARC.Supporting.ARC_CWAPAlgo_OrderSingle>(new ARC.Supporting.ARC_CWAPAlgo_OrderSingle(), input, ref cacheARC_CWAPAlgo_OrderSingle);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Supporting.ARC_CWAPAlgo_OrderSingle ARC_CWAPAlgo_OrderSingle()
		{
			return indicator.ARC_CWAPAlgo_OrderSingle(Input);
		}

		public Indicators.ARC.Supporting.ARC_CWAPAlgo_OrderSingle ARC_CWAPAlgo_OrderSingle(ISeries<double> input )
		{
			return indicator.ARC_CWAPAlgo_OrderSingle(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Supporting.ARC_CWAPAlgo_OrderSingle ARC_CWAPAlgo_OrderSingle()
		{
			return indicator.ARC_CWAPAlgo_OrderSingle(Input);
		}

		public Indicators.ARC.Supporting.ARC_CWAPAlgo_OrderSingle ARC_CWAPAlgo_OrderSingle(ISeries<double> input )
		{
			return indicator.ARC_CWAPAlgo_OrderSingle(input);
		}
	}
}

#endregion
