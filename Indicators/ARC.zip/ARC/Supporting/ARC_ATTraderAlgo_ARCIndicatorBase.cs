#region Using declarations
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Strategies.Licensing;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC.Supporting
{
	[Browsable(false)]
	[CategoryOrder(ProductInfoGroupName, 1000)]
	public class ARC_ATTraderAlgo_ARCIndicatorBase : Indicator, ARC_ATTraderAlgo_IARCLicensedWithMessages
	{
		public const string ProductInfoGroupName = "Product Info";

		[XmlIgnore, Browsable(false)]
		public virtual string ProductInfusionSoftTag => "";
		[XmlIgnore, Browsable(false)]
		public List<string> ProductBundleInfusionSoftTags => new List<string>();
		[XmlIgnore, Browsable(false)]
		public TextFixed LicensingLoadingText { get; set; }
		[XmlIgnore, Browsable(false)]
		public TextFixed LicensingErrorText { get; set; }
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ProductVersion => "";
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ModuleName => GetType().Name.Replace("ARC_", "");
		[XmlIgnore, Browsable(false)]
		public virtual bool ColicensedOnly => false;
		public override string DisplayName => IsCreatedByStrategy ? "" : ModuleName + ARC_ATTraderAlgo_ARCLicenseValidator.LicenseModeDenotingNameSuffix;

		/// <summary>
		/// The default name for the script in the UI and ToString
		/// </summary>
		protected virtual string ProductName => GetType().Name;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = ProductName;
				Calculate = Calculate.OnBarClose;
				IsOverlay = false;
				BarsRequiredToPlot = 1;
				IsSuspendedWhileInactive = true;
			}
			else if (State == State.Configure)
			{
				this.ARC_ATTraderAlgo_EnactLicensingWithWarnings(ARC_ATTraderAlgo_LicensingContextStep.Configure);
			}
		}

		protected override void OnBarUpdate()
		{
			this.ARC_ATTraderAlgo_EnactLicensingWithWarnings(ARC_ATTraderAlgo_LicensingContextStep.BarUpdate);
		}

		public override string ToString()
		{
			return DisplayName;
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Supporting.ARC_ATTraderAlgo_ARCIndicatorBase[] cacheARC_ATTraderAlgo_ARCIndicatorBase;
		public ARC.Supporting.ARC_ATTraderAlgo_ARCIndicatorBase ARC_ATTraderAlgo_ARCIndicatorBase()
		{
			return ARC_ATTraderAlgo_ARCIndicatorBase(Input);
		}

		public ARC.Supporting.ARC_ATTraderAlgo_ARCIndicatorBase ARC_ATTraderAlgo_ARCIndicatorBase(ISeries<double> input)
		{
			if (cacheARC_ATTraderAlgo_ARCIndicatorBase != null)
				for (int idx = 0; idx < cacheARC_ATTraderAlgo_ARCIndicatorBase.Length; idx++)
					if (cacheARC_ATTraderAlgo_ARCIndicatorBase[idx] != null &&  cacheARC_ATTraderAlgo_ARCIndicatorBase[idx].EqualsInput(input))
						return cacheARC_ATTraderAlgo_ARCIndicatorBase[idx];
			return CacheIndicator<ARC.Supporting.ARC_ATTraderAlgo_ARCIndicatorBase>(new ARC.Supporting.ARC_ATTraderAlgo_ARCIndicatorBase(), input, ref cacheARC_ATTraderAlgo_ARCIndicatorBase);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Supporting.ARC_ATTraderAlgo_ARCIndicatorBase ARC_ATTraderAlgo_ARCIndicatorBase()
		{
			return indicator.ARC_ATTraderAlgo_ARCIndicatorBase(Input);
		}

		public Indicators.ARC.Supporting.ARC_ATTraderAlgo_ARCIndicatorBase ARC_ATTraderAlgo_ARCIndicatorBase(ISeries<double> input )
		{
			return indicator.ARC_ATTraderAlgo_ARCIndicatorBase(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Supporting.ARC_ATTraderAlgo_ARCIndicatorBase ARC_ATTraderAlgo_ARCIndicatorBase()
		{
			return indicator.ARC_ATTraderAlgo_ARCIndicatorBase(Input);
		}

		public Indicators.ARC.Supporting.ARC_ATTraderAlgo_ARCIndicatorBase ARC_ATTraderAlgo_ARCIndicatorBase(ISeries<double> input )
		{
			return indicator.ARC_ATTraderAlgo_ARCIndicatorBase(input);
		}
	}
}

#endregion
