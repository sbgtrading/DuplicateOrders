using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui.Chart;
using SharpDX.Direct2D1;

namespace NinjaTrader.NinjaScript.Indicators.ARC.Supporting
{
	[Browsable(false)]
	public class ExternalStrategyPlot : Indicator
	{
		public override string DisplayName => Name;

		[Browsable(false), XmlIgnore]
		public Action<RenderTarget, ChartBars, ChartScale> RenderCallback { get; set; }

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = "External Strategy Plot";
				Calculate = Calculate.OnBarClose;
				IsOverlay = false;
				DisplayInDataBox = true;
				DrawOnPricePanel = true;
				DrawHorizontalGridLines = true;
				DrawVerticalGridLines = true;
				PaintPriceMarkers = true;
				ScaleJustification = ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive = true;

				PlotCount = 1;
				Guid = Guid.NewGuid();
			}
			else if (State == State.Configure)
			{
				for (var i = 0; i < PlotCount; i++)
					AddPlot(Brushes.Aqua, "Plot" + i);
			}
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			RenderCallback?.Invoke(RenderTarget, ChartBars, chartScale);
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		public int PlotCount { get; set; }

		[NinjaScriptProperty]
		public Guid Guid { get; set; }
	}
}





#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Supporting.ExternalStrategyPlot[] cacheExternalStrategyPlot;
		public ARC.Supporting.ExternalStrategyPlot ExternalStrategyPlot(int plotCount, Guid guid)
		{
			return ExternalStrategyPlot(Input, plotCount, guid);
		}

		public ARC.Supporting.ExternalStrategyPlot ExternalStrategyPlot(ISeries<double> input, int plotCount, Guid guid)
		{
			if (cacheExternalStrategyPlot != null)
				for (int idx = 0; idx < cacheExternalStrategyPlot.Length; idx++)
					if (cacheExternalStrategyPlot[idx] != null && cacheExternalStrategyPlot[idx].PlotCount == plotCount && cacheExternalStrategyPlot[idx].Guid == guid && cacheExternalStrategyPlot[idx].EqualsInput(input))
						return cacheExternalStrategyPlot[idx];
			return CacheIndicator<ARC.Supporting.ExternalStrategyPlot>(new ARC.Supporting.ExternalStrategyPlot(){ PlotCount = plotCount, Guid = guid }, input, ref cacheExternalStrategyPlot);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Supporting.ExternalStrategyPlot ExternalStrategyPlot(int plotCount, Guid guid)
		{
			return indicator.ExternalStrategyPlot(Input, plotCount, guid);
		}

		public Indicators.ARC.Supporting.ExternalStrategyPlot ExternalStrategyPlot(ISeries<double> input , int plotCount, Guid guid)
		{
			return indicator.ExternalStrategyPlot(input, plotCount, guid);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Supporting.ExternalStrategyPlot ExternalStrategyPlot(int plotCount, Guid guid)
		{
			return indicator.ExternalStrategyPlot(Input, plotCount, guid);
		}

		public Indicators.ARC.Supporting.ExternalStrategyPlot ExternalStrategyPlot(ISeries<double> input , int plotCount, Guid guid)
		{
			return indicator.ExternalStrategyPlot(input, plotCount, guid);
		}
	}
}

#endregion
