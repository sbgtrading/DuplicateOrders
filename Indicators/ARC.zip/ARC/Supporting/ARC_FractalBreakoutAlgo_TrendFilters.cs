using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Indicators.ARC.AlgoSup
{
	public class ARC_FractalBreakoutAlgo_TrendFilters : ARC_FractalBreakoutAlgo_ARCIndicatorBase
	{
		public override bool ColicensedOnly => true;
		private int BasisBarsIdx => MAType == ARC_FractalBreakoutAlgo_MovingAverageType.StepMA || MABasis == ARC_FractalBreakoutAlgo_TrendFiltersMaBasis.PrimaryBars ? 0 : htfBarsIdx;

		[Browsable(false), XmlIgnore]
		public int Trend
		{
			get
			{
				Update();

				// Ensure sufficient bars
				if (MAType != ARC_FractalBreakoutAlgo_MovingAverageType.StepMA && CurrentBars[BasisBarsIdx] < 0)
					return 0;

				// Double trends are always based on which side of slow fast is on
				if (MACount == ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Double)
					return filterMa1[0].ApproxCompare(filterMa2[0]);

				// Handle single step MA trend
				if (MAType == ARC_FractalBreakoutAlgo_MovingAverageType.StepMA && FilterMATrendType == ARC_FractalBreakoutAlgo_StepMaTrendType.Trend)
					return ((ARC_FractalBreakoutAlgo_ARC_TrendStepper)filterMa1).LastMovementDir;

				// Return no trend if we're not sufficiently on one side, otherwise return the side of the filter ma that close is on
				var dir = Closes[0][0].ApproxCompare(filterMa1[0]);
				if (dir == 0)
					return 0;

				var anchor = dir == 1
					? Lows[0][0] * MABarBiasPercentRequirement / 100 + Highs[0][0] * (1 - MABarBiasPercentRequirement / 100)
					: Highs[0][0] * MABarBiasPercentRequirement / 100 + Lows[0][0] * (1 - MABarBiasPercentRequirement / 100);

				return anchor.ApproxCompare(filterMa1[0]) != dir ? 0 : dir;
			}
		}

		private int htfBarsIdx;
		protected Indicator filterMa1;
		protected Indicator filterMa2;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_FractalBreakoutAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				IsOverlay = true;

				MACount = ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Single;
				MAType = ARC_FractalBreakoutAlgo_MovingAverageType.EMA;
				MABasis = ARC_FractalBreakoutAlgo_TrendFiltersMaBasis.Minutes;
				MATimeframe = 1;
				MAPeriod = 15;
				MAPeriod2 = 30;
				FilterMAStepSize = 40;
				FilterMAStepSize2 = 80;
				FilterMATrendType = ARC_FractalBreakoutAlgo_StepMaTrendType.Trend;
				MABarBiasPercentRequirement = 0;
				MAColor = Brushes.WhiteSmoke;
				MAColor2 = Brushes.DodgerBlue;
			}
			else if (State == State.Configure)
			{
				htfBarsIdx = this.ARC_FractalBreakoutAlgo_EnsureDataSeriesAdded(AddDataSeries, BarsPeriodType.Minute, MATimeframe);

				AddPlot(Brushes.Aqua, MACount == ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Single ? "Filter" : "Filter 1");

				if (MACount == ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Double)
					AddPlot(Brushes.Teal, "Filter 2");

				for (var i = 0; i < (MACount == ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Single ? 1 : 2); i++)
				{
					Plots[i].PlotStyle = MAType == ARC_FractalBreakoutAlgo_MovingAverageType.StepMA ? PlotStyle.Square : PlotStyle.Line;
					Plots[i].Width = 2;
				}
			}
			else if (State == State.DataLoaded)
			{
				Plots[0].Brush = MAColor;
				if (MACount == ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Double)
					Plots[1].Brush = MAColor2;
	
				for (var i = 0; i < (MACount == ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Single ? 1 : 2); i++)
				{
					var filterMa = MAType switch
					{
						ARC_FractalBreakoutAlgo_MovingAverageType.EMA => (Indicator) EMA(Closes[BasisBarsIdx], i == 0 ? MAPeriod : MAPeriod2),
						ARC_FractalBreakoutAlgo_MovingAverageType.SMA => SMA(Closes[BasisBarsIdx], i == 0 ? MAPeriod : MAPeriod2),
						ARC_FractalBreakoutAlgo_MovingAverageType.StepMA => ARC_FractalBreakoutAlgo_ARC_TrendStepper(Closes[BasisBarsIdx], i == 0 ? FilterMAStepSize : FilterMAStepSize2, 0),
						_ => throw new ArgumentOutOfRangeException()
					};

					if (i == 0)
						filterMa1 = filterMa;
					else
						filterMa2 = filterMa;
				}
			}
		}

		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_FractalBreakoutAlgo_IsLicensed())
				return;
			if (BarsInProgress != 0 || CurrentBars[0] < 0 || CurrentBars[BasisBarsIdx] < 0)
				return;

			Values[0][0] = filterMa1[0];
			if (MACount == ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Double)
				Values[1][0] = filterMa2[0];
		}

		private const string HTFMovingAveragesGroupName = "Moving Averages Filter";
		
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_FractalBreakoutAlgo_HideByDefault]
		[Display(Name = "MA Count", Order = 2, GroupName = HTFMovingAveragesGroupName)]
		public ARC_FractalBreakoutAlgo_TrendFiltersMaCount MACount { get; set; }
		
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_FractalBreakoutAlgo_HideByDefault]
		[Display(Name = "Type", Order = 3, GroupName = HTFMovingAveragesGroupName, Description = "Moving average type")]
		public ARC_FractalBreakoutAlgo_MovingAverageType MAType { get; set; }
		
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_FractalBreakoutAlgo_HideByDefault]
		[Display(Name = "Basis", Order = 4, GroupName = HTFMovingAveragesGroupName)]
		public ARC_FractalBreakoutAlgo_TrendFiltersMaBasis MABasis { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_FractalBreakoutAlgo_HideByDefault]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MABasis), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaBasis.Minutes)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MAType), ARC_FractalBreakoutAlgo_PropComparisonType.NEQ, ARC_FractalBreakoutAlgo_MovingAverageType.StepMA)]
		[Display(Name = "Timeframe Minutes", Order = 5, GroupName = HTFMovingAveragesGroupName, Description = "Timeframe to calculate moving average on in minutes")]
		public int MATimeframe { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_FractalBreakoutAlgo_HideByDefault]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MAType), ARC_FractalBreakoutAlgo_PropComparisonType.NEQ, ARC_FractalBreakoutAlgo_MovingAverageType.StepMA)]
		[ARC_FractalBreakoutAlgo_Rename("Period", nameof(MACount), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Single)]
		[ARC_FractalBreakoutAlgo_Rename("Period 1", nameof(MACount), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Period", Order = 6, GroupName = HTFMovingAveragesGroupName, Description = "Period of the filter moving average")]
		public int MAPeriod { get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_FractalBreakoutAlgo_HideByDefault]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MAType), ARC_FractalBreakoutAlgo_PropComparisonType.NEQ, ARC_FractalBreakoutAlgo_MovingAverageType.StepMA)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MACount), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Period 2", Order = 7, GroupName = HTFMovingAveragesGroupName, Description = "Period of the filter moving average")]
		public int MAPeriod2 { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_FractalBreakoutAlgo_HideByDefault]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MAType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_MovingAverageType.StepMA)]
		[ARC_FractalBreakoutAlgo_Rename("Step Size", nameof(MACount), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Single)]
		[ARC_FractalBreakoutAlgo_Rename("Step Size 1", nameof(MACount), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Step Size", Order = 8, GroupName = HTFMovingAveragesGroupName, Description = "Step size of the filter moving average")]
		public int FilterMAStepSize { get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_FractalBreakoutAlgo_HideByDefault]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MAType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_MovingAverageType.StepMA)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MACount), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Step Size 2", Order = 9, GroupName = HTFMovingAveragesGroupName, Description = "Step size of the filter moving average")]
		public int FilterMAStepSize2 { get; set; }

		[NinjaScriptProperty]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MAType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_MovingAverageType.StepMA)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MACount), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Single)]
		[Display(Name = "Step Method", Order = 10, GroupName = HTFMovingAveragesGroupName, Description = "The method step MA will use to determine direction")]
		public ARC_FractalBreakoutAlgo_StepMaTrendType FilterMATrendType { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "Bar % HTF MA", Order = 11, GroupName = HTFMovingAveragesGroupName, Description = "The minimum percentage of the bar that must be on the right side of the MA.")]
		public double MABarBiasPercentRequirement { get; set; }

		[XmlIgnore]
		[ARC_FractalBreakoutAlgo_Rename("Color", nameof(MACount), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Single)]
		[ARC_FractalBreakoutAlgo_Rename("Color 1", nameof(MACount), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Color", Order = 12, GroupName = HTFMovingAveragesGroupName)]
		public Brush MAColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MAColorSerializable
		{
			get => Serialize.BrushToString(MAColor);
			set => MAColor = Serialize.StringToBrush(value);
		}
		
		[XmlIgnore]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MACount), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Color 2", Order = 13, GroupName = HTFMovingAveragesGroupName)]
		public Brush MAColor2 { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MAColor2Serializable
		{
			get => Serialize.BrushToString(MAColor2);
			set => MAColor2 = Serialize.StringToBrush(value);
		}
	}
}

public enum ARC_FractalBreakoutAlgo_TrendFiltersMaCount
{
	Single,
	Double
}


public enum ARC_FractalBreakoutAlgo_TrendFiltersMaBasis
{
	PrimaryBars,
	Minutes
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.AlgoSup.ARC_FractalBreakoutAlgo_TrendFilters[] cacheARC_FractalBreakoutAlgo_TrendFilters;
		public ARC.AlgoSup.ARC_FractalBreakoutAlgo_TrendFilters ARC_FractalBreakoutAlgo_TrendFilters(ARC_FractalBreakoutAlgo_TrendFiltersMaCount mACount, ARC_FractalBreakoutAlgo_MovingAverageType mAType, ARC_FractalBreakoutAlgo_TrendFiltersMaBasis mABasis, int mATimeframe, int mAPeriod, int mAPeriod2, int filterMAStepSize, int filterMAStepSize2, ARC_FractalBreakoutAlgo_StepMaTrendType filterMATrendType, double mABarBiasPercentRequirement)
		{
			return ARC_FractalBreakoutAlgo_TrendFilters(Input, mACount, mAType, mABasis, mATimeframe, mAPeriod, mAPeriod2, filterMAStepSize, filterMAStepSize2, filterMATrendType, mABarBiasPercentRequirement);
		}

		public ARC.AlgoSup.ARC_FractalBreakoutAlgo_TrendFilters ARC_FractalBreakoutAlgo_TrendFilters(ISeries<double> input, ARC_FractalBreakoutAlgo_TrendFiltersMaCount mACount, ARC_FractalBreakoutAlgo_MovingAverageType mAType, ARC_FractalBreakoutAlgo_TrendFiltersMaBasis mABasis, int mATimeframe, int mAPeriod, int mAPeriod2, int filterMAStepSize, int filterMAStepSize2, ARC_FractalBreakoutAlgo_StepMaTrendType filterMATrendType, double mABarBiasPercentRequirement)
		{
			if (cacheARC_FractalBreakoutAlgo_TrendFilters != null)
				for (int idx = 0; idx < cacheARC_FractalBreakoutAlgo_TrendFilters.Length; idx++)
					if (cacheARC_FractalBreakoutAlgo_TrendFilters[idx] != null && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].MACount == mACount && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].MAType == mAType && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].MABasis == mABasis && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].MATimeframe == mATimeframe && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].MAPeriod == mAPeriod && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].MAPeriod2 == mAPeriod2 && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].FilterMAStepSize == filterMAStepSize && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].FilterMAStepSize2 == filterMAStepSize2 && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].FilterMATrendType == filterMATrendType && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].MABarBiasPercentRequirement == mABarBiasPercentRequirement && cacheARC_FractalBreakoutAlgo_TrendFilters[idx].EqualsInput(input))
						return cacheARC_FractalBreakoutAlgo_TrendFilters[idx];
			return CacheIndicator<ARC.AlgoSup.ARC_FractalBreakoutAlgo_TrendFilters>(new ARC.AlgoSup.ARC_FractalBreakoutAlgo_TrendFilters(){ MACount = mACount, MAType = mAType, MABasis = mABasis, MATimeframe = mATimeframe, MAPeriod = mAPeriod, MAPeriod2 = mAPeriod2, FilterMAStepSize = filterMAStepSize, FilterMAStepSize2 = filterMAStepSize2, FilterMATrendType = filterMATrendType, MABarBiasPercentRequirement = mABarBiasPercentRequirement }, input, ref cacheARC_FractalBreakoutAlgo_TrendFilters);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.AlgoSup.ARC_FractalBreakoutAlgo_TrendFilters ARC_FractalBreakoutAlgo_TrendFilters(ARC_FractalBreakoutAlgo_TrendFiltersMaCount mACount, ARC_FractalBreakoutAlgo_MovingAverageType mAType, ARC_FractalBreakoutAlgo_TrendFiltersMaBasis mABasis, int mATimeframe, int mAPeriod, int mAPeriod2, int filterMAStepSize, int filterMAStepSize2, ARC_FractalBreakoutAlgo_StepMaTrendType filterMATrendType, double mABarBiasPercentRequirement)
		{
			return indicator.ARC_FractalBreakoutAlgo_TrendFilters(Input, mACount, mAType, mABasis, mATimeframe, mAPeriod, mAPeriod2, filterMAStepSize, filterMAStepSize2, filterMATrendType, mABarBiasPercentRequirement);
		}

		public Indicators.ARC.AlgoSup.ARC_FractalBreakoutAlgo_TrendFilters ARC_FractalBreakoutAlgo_TrendFilters(ISeries<double> input , ARC_FractalBreakoutAlgo_TrendFiltersMaCount mACount, ARC_FractalBreakoutAlgo_MovingAverageType mAType, ARC_FractalBreakoutAlgo_TrendFiltersMaBasis mABasis, int mATimeframe, int mAPeriod, int mAPeriod2, int filterMAStepSize, int filterMAStepSize2, ARC_FractalBreakoutAlgo_StepMaTrendType filterMATrendType, double mABarBiasPercentRequirement)
		{
			return indicator.ARC_FractalBreakoutAlgo_TrendFilters(input, mACount, mAType, mABasis, mATimeframe, mAPeriod, mAPeriod2, filterMAStepSize, filterMAStepSize2, filterMATrendType, mABarBiasPercentRequirement);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.AlgoSup.ARC_FractalBreakoutAlgo_TrendFilters ARC_FractalBreakoutAlgo_TrendFilters(ARC_FractalBreakoutAlgo_TrendFiltersMaCount mACount, ARC_FractalBreakoutAlgo_MovingAverageType mAType, ARC_FractalBreakoutAlgo_TrendFiltersMaBasis mABasis, int mATimeframe, int mAPeriod, int mAPeriod2, int filterMAStepSize, int filterMAStepSize2, ARC_FractalBreakoutAlgo_StepMaTrendType filterMATrendType, double mABarBiasPercentRequirement)
		{
			return indicator.ARC_FractalBreakoutAlgo_TrendFilters(Input, mACount, mAType, mABasis, mATimeframe, mAPeriod, mAPeriod2, filterMAStepSize, filterMAStepSize2, filterMATrendType, mABarBiasPercentRequirement);
		}

		public Indicators.ARC.AlgoSup.ARC_FractalBreakoutAlgo_TrendFilters ARC_FractalBreakoutAlgo_TrendFilters(ISeries<double> input , ARC_FractalBreakoutAlgo_TrendFiltersMaCount mACount, ARC_FractalBreakoutAlgo_MovingAverageType mAType, ARC_FractalBreakoutAlgo_TrendFiltersMaBasis mABasis, int mATimeframe, int mAPeriod, int mAPeriod2, int filterMAStepSize, int filterMAStepSize2, ARC_FractalBreakoutAlgo_StepMaTrendType filterMATrendType, double mABarBiasPercentRequirement)
		{
			return indicator.ARC_FractalBreakoutAlgo_TrendFilters(input, mACount, mAType, mABasis, mATimeframe, mAPeriod, mAPeriod2, filterMAStepSize, filterMAStepSize2, filterMATrendType, mABarBiasPercentRequirement);
		}
	}
}

#endregion
