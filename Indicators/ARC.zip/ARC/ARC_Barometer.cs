#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Reflection;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using System.Windows.Controls;
using System.Windows.Input;
using System.IO;
using SharpDX;
using System.Text;
using SharpDX.DirectWrite;
using System.Windows.Media.Imaging;
using System.Linq;
using NinjaTrader.NinjaScript.Indicators.ARC.Sup;
#endregion

public enum ARC_Barometer_Locations{TopLeft,TopRight,Center,BottomLeft,BottomRight}
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    [CategoryOrder("Parameters", 0)]
	public class ARC_Barometer : Indicator 
	{
		private int AudibleAlertBar = 0;
		private bool IsDebug        = false;
		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName        = "Barometer";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "3626"};
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		#region RegGauge
		public class ClassGauge
		{        
			#region RegHelper
			internal class NT7MeasureStringData
			{
				public float Height;
				public float Width;
				
				public NT7MeasureStringData()
				{
					
				}
			}
				
			
			internal class NT7Graphics
			{
				SharpDX.Direct2D1.RenderTarget rt;
			
				public NT7Graphics(SharpDX.Direct2D1.RenderTarget rt)
				{
					this.rt = rt;
				}
				
				public void FillEllipse(Brush b, float x, float y, float w, float h)
				{
					float half = w / 2;
					float x0 = Convert.ToSingle (x + half - 1);
					float y0 = Convert.ToSingle (y + half - 1);
					SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
					SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f); 
					var brush = b.ToDxBrush(this.rt);
					this.rt.FillEllipse(ellipse, brush);
					brush.Dispose();
					brush=null;
				}

				public void FillEllipse(SharpDX.Direct2D1.Brush brush, float x, float y, float w, float h)
				{
					float half = w / 2;
					float x0 = Convert.ToSingle(x + half - 1);
					float y0 = Convert.ToSingle(y + half - 1);
					SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
					SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f);
					this.rt.FillEllipse(ellipse, brush);
				}

				public void DrawLine(Stroke s, float x1, float y1, float x2, float y2)
				{
					System.Windows.Point startPoint	= new System.Windows.Point(x1, y1);
					System.Windows.Point endPoint		= new System.Windows.Point(x2, y2);
					var brush = s.Brush.ToDxBrush(this.rt);
					this.rt.DrawLine(startPoint.ToVector2(), endPoint.ToVector2(), brush, s.Width, s.StrokeStyle);
					brush.Dispose();brush=null;
				}

				public void DrawLine(SharpDX.Direct2D1.Brush brush, float width, float x1, float y1, float x2, float y2)
				{
					System.Windows.Point startPoint = new System.Windows.Point(x1, y1);
					System.Windows.Point endPoint = new System.Windows.Point(x2, y2);
					this.rt.DrawLine(startPoint.ToVector2(), endPoint.ToVector2(), brush, width);
				}

				public void DrawString(String text, SimpleFont f, Brush b, float x, float y)
				{
					this.DrawString(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading);
				}
				
				public void DrawStringRotated(String text, SimpleFont f, Brush b, float x, float y, float iAngle)
				{
					this.DrawStringRotated(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading, iAngle);
				}				
				
				public void DrawString(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta)
				{
					TextFormat textFormat		= 
						new TextFormat(
							Core.Globals.DirectWriteFactory, 
							f.Family.ToString(), 
							(f.Bold?SharpDX.DirectWrite.FontWeight.Bold:SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal, 
							SharpDX.DirectWrite.FontStretch.Normal, 
							Convert.ToSingle(f.Size)) 
							{ 
								TextAlignment = ta, 
								WordWrapping = WordWrapping.NoWrap 
							};
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,w,h);//(float)f.Size);
					
					System.Windows.Point upperTextPoint	= new System.Windows.Point(x,y);
					var brush = b.ToDxBrush(this.rt);
					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					brush.Dispose();brush=null;
				}

				public void DrawString(String text, SimpleFont f, SharpDX.Direct2D1.Brush brush, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta)
				{
					TextFormat textFormat =
						new TextFormat(
							Core.Globals.DirectWriteFactory,
							f.Family.ToString(),
							(f.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal,
							SharpDX.DirectWrite.FontStretch.Normal,
							Convert.ToSingle(f.Size))
						{
							TextAlignment = ta,
							WordWrapping = WordWrapping.NoWrap
						};

					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, w, h);//(float)f.Size);

					System.Windows.Point upperTextPoint = new System.Windows.Point(x, y);
					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
				}

				public void DrawStringRotated(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta, float iAngle)
				{
					TextFormat textFormat		= 
						new TextFormat(
							Core.Globals.DirectWriteFactory, 
							f.Family.ToString(), 
							(f.Bold?SharpDX.DirectWrite.FontWeight.Bold:SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal, 
							SharpDX.DirectWrite.FontStretch.Normal, 
							Convert.ToSingle(f.Size)) 
							{ 
								TextAlignment = ta, 
								WordWrapping = WordWrapping.NoWrap 
							};
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,w,h);//(float)f.Size);
					
					System.Windows.Point upperTextPoint	= new System.Windows.Point(x,y);
								
					SharpDX.Matrix3x2 savedTransform = this.rt.Transform;
					
					this.rt.Transform = SharpDX.Matrix3x2.Rotation(iAngle, new SharpDX.Vector2(x, y));	
					
					var brush = b.ToDxBrush(this.rt);
					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					brush.Dispose();brush=null;
							
					this.rt.Transform = savedTransform;																		
				}

				public void DrawStringRotated(String text, SimpleFont f, SharpDX.Direct2D1.Brush brush, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta, float iAngle)
				{
					TextFormat textFormat =
						new TextFormat(
							Core.Globals.DirectWriteFactory,
							f.Family.ToString(),
							(f.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal,
							SharpDX.DirectWrite.FontStretch.Normal,
							Convert.ToSingle(f.Size))
						{
							TextAlignment = ta,
							WordWrapping = WordWrapping.NoWrap
						};

					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, w, h);//(float)f.Size);

					System.Windows.Point upperTextPoint = new System.Windows.Point(x, y);

					SharpDX.Matrix3x2 savedTransform = this.rt.Transform;

					this.rt.Transform = SharpDX.Matrix3x2.Rotation(iAngle, new SharpDX.Vector2(x, y));

					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

					this.rt.Transform = savedTransform;
				}

				public NT7MeasureStringData MeasureString( String text, SimpleFont f)
				{
					NT7MeasureStringData sd = new NT7MeasureStringData();
					
					TextFormat textFormat		= new TextFormat(Core.Globals.DirectWriteFactory, f.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal,
													SharpDX.DirectWrite.FontStyle.Normal, SharpDX.DirectWrite.FontStretch.Normal, Convert.ToSingle(f.Size)) 
													{ TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading, WordWrapping = WordWrapping.NoWrap };
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,400,Convert.ToSingle(f.Size));
					
													
					sd.Height = Convert.ToSingle( textLayout.Metrics.Height);
					sd.Width = Convert.ToSingle( textLayout.Metrics.Width);
													
					return sd;
				}
			}
			
			#endregion
			
	        public ClassGauge(float iX, float iY, float iHeight, float iWidth)
	        {            
	            X = (int)iX;
	            Y = (int)iY;

	            Major_Width = (int)iWidth;
	            Major_Height = (int)iHeight;

	            Width = (int)iWidth - m_BaseMajorRadiusHeight;
	            Height = (int)iHeight - m_BaseMajorRadiusHeight;
				
	            this.m_Center = new System.Windows.Point(Major_Width / 2 - Major_Width / 25, Major_Height / 2);
				
				m_Center.X += 144;
				m_Center.Y += 8;				

	            //#####################################################################
				InitBaseValue(20, 0, 0);
	        }

	        public void InitBaseValue(Int32 nNumberStringMargin, Int32 ScaleHeight, Int32 GaugeScreenSize)
	        {
	            Int32 absRadius = 0;
	            absRadius = Major_Width / 2 - nNumberStringMargin - GaugeScreenSize;
	            BaseLineRadiusHeight = ScaleHeight;
	            if (ScaleHeight == 0)
	            {
	                nAnotherLineRadius = (2 * absRadius) / 9;
	                BaseLineRadiusHeight = nAnotherLineRadius / 2;
	            }

	            NeedleWidth = BaseLineRadiusHeight/4;

	            ScaleLinesMajorOuterRadius = absRadius - m_BaseLineRadiusHeight;
	            ScaleLinesMajorInnerRadius = absRadius;

	            ScaleLinesMinorOuterRadius = absRadius - 5;
	            ScaleLinesMinorInnerRadius = absRadius - m_BaseLineRadiusHeight;

	            ScaleLinesInterOuterRadius = absRadius - 3;
	            ScaleLinesInterInnerRadius = absRadius - m_BaseLineRadiusHeight;

	            ScaleNumbersRadius = absRadius + 0/*nNumberStringMargin*/;
	            NeedleRadius = absRadius - m_BaseLineRadiusHeight / 2;
	        }

	        #region Variables
			Stroke blackStroke = new Stroke(Brushes.Black);
			
	        private int Width = 0;
	        private int Height = 0;
	        private int Major_Width = 0;
	        private int Major_Height = 0;
	        private int X = 0;
	        private int Y = 0;
	        private Boolean drawGaugeBackground = true;
	        private SharpDX.Direct2D1.Bitmap gaugeBitmap;
	        
	        private const Byte ZERO = 0;
	        private const Byte NUMOFCAPS = 5;
	        private const Byte NUMOFRANGES = 5;        

	        private Boolean[] m_valueIsInRange = { false, false, false, false, false };
	        private Boolean[] m_RangeEnabled = { true, true, false, false, false };
	        private Single[] m_RangeStartValue = { -100.0f, 300.0f, 0.0f, 0.0f, 0.0f };
	        private Single[] m_RangeEndValue = { 300.0f, 400.0f, 0.0f, 0.0f, 0.0f };        

	        private Int32 m_BaseMajorRadiusHeight = 10;        
	        private Int32 nAnotherLineRadius = 50;

	        private Brush m_BaseArcColor = Brushes.Gray;
	        private Int32 m_BaseArcRadius = 80;
	        private Int32 m_BaseArcStart = 232;
	        private Int32 m_BaseArcSweep = 252;
	        private Int32 m_BaseArcWidth = 2;
	                
	        private Single m_MinValue = -50;
	        private Single m_MaxValue = 50;

	        private Single fontBoundY1;
	        private Single fontBoundY2;        

	        private Single m_ScaleLinesMajorStepValue = 50.0f;
	        private Brush m_ScaleLinesMajorColor = Brushes.Black;        
	        private Int32 m_ScaleLinesMajorWidth = 2;
	        private Int32 m_ScaleLinesMinorNumOf = 9;
	        private Brush m_ScaleLinesMinorColor = Brushes.Gray;        
	        private Int32 m_ScaleLinesMinorWidth = 1;
	        private Brush m_ScaleLinesInterColor = Brushes.Black;        
	        private Int32 m_ScaleLinesInterWidth = 1;        
	        private Brush m_NeedleColor2 = Brushes.DimGray;        

	        #endregion

	        #region Init Process Variable
	        public Brush BackBrush { get; set; }

	        private Brush needleBrush1 = Brushes.LemonChiffon;
			private SharpDX.Direct2D1.Brush dxNeedleBrush1 = null;

	        public Brush NeedleBrush1
	        {
	            set { needleBrush1 = value; }
	            get { return needleBrush1; }
	        }

	        private Brush needleBrush2 = Brushes.Blue;
			private SharpDX.Direct2D1.Brush dxNeedleBrush2 = null;
			public Brush NeedleBrush2
	        {
	            set { needleBrush2 = value; }
	            get { return needleBrush2; }
	        }

	        private Brush needleBrush3 = Brushes.HotPink;
			private SharpDX.Direct2D1.Brush dxNeedleBrush3 = null;
			public Brush NeedleBrush3
	        {
	            set { needleBrush3 = value; }
	            get { return needleBrush3; }
	        }

	        private Int32 m_NeedleType = 1;
	        public Int32 NeedleType
	        {
	            get{return m_NeedleType;}
	            set{m_NeedleType = value;}
	        }

	        private Int32 m_NeedleRadius = 80;
	        public Int32 NeedleRadius
	        {
	            get{return m_NeedleRadius;}
	            set{m_NeedleRadius = value;}
	        }

	        private Int32 m_NeedleWidth = 3;
	        public Int32 NeedleWidth
	        {
	            get{return m_NeedleWidth;}
	            set{m_NeedleWidth = value;}
	        }

	        private System.Windows.Point m_Center = new System.Windows.Point(100, 100);
	        public System.Windows.Point Center
	        {
	            get{return m_Center;}
	            set{m_Center = value;}
	        }

	        private Int32 m_BaseLineRadiusHeight = 20;
	        public Int32 BaseLineRadiusHeight
	        {
	            get{return m_BaseLineRadiusHeight;}
	            set{m_BaseLineRadiusHeight = value;  }
	        }

	        private Int32 m_ScaleLinesMajorOuterRadius = 80;
	        public Int32 ScaleLinesMajorOuterRadius
	        {
	            get{return m_ScaleLinesMajorOuterRadius;}
	            set{m_ScaleLinesMajorOuterRadius = value;}
	        }

	        private Int32 m_ScaleLinesMajorInnerRadius = 70;
	        public Int32 ScaleLinesMajorInnerRadius
	        {
	            get{return m_ScaleLinesMajorInnerRadius;}
	            set{m_ScaleLinesMajorInnerRadius = value;}
	        }

	        private Int32 m_ScaleLinesMinorInnerRadius = 75;
	        public Int32 ScaleLinesMinorInnerRadius
	        {
	            get{return m_ScaleLinesMinorInnerRadius;}
	            set{m_ScaleLinesMinorInnerRadius = value;}
	        }

	        private Int32 m_ScaleLinesMinorOuterRadius = 80;
	        public Int32 ScaleLinesMinorOuterRadius
	        {
	            get{return m_ScaleLinesMinorOuterRadius;}
	            set{m_ScaleLinesMinorOuterRadius = value;}
	        }

	        private Int32 m_ScaleLinesInterInnerRadius = 73;
	        public Int32 ScaleLinesInterInnerRadius
	        {
	            get{return m_ScaleLinesInterInnerRadius;}
	            set{m_ScaleLinesInterInnerRadius = value;}
	        }

	        private Int32 m_ScaleLinesInterOuterRadius = 80;
	        public Int32 ScaleLinesInterOuterRadius
	        {
	            get{return m_ScaleLinesInterOuterRadius;}
	            set{m_ScaleLinesInterOuterRadius = value;}
	        }

	        private Int32 m_ScaleNumbersRadius = 95;
	        public Int32 ScaleNumbersRadius
	        {
	            get{return m_ScaleNumbersRadius;}
	            set{m_ScaleNumbersRadius = value;}
	        }

	        public Int32 m_ScaleNumbersStartScaleLine = 0;
	        public Int32 ScaleNumbersStartScaleLine
	        {
	            get{return m_ScaleNumbersStartScaleLine;}
	            set{m_ScaleNumbersStartScaleLine = value;}
	        }

	        private Brush m_ScaleNumbersBrush = Brushes.DarkSlateGray;
	        public Brush ScaleNumbersBrush
	        {
	            get{return m_ScaleNumbersBrush;}
	            set{m_ScaleNumbersBrush = value;}
	        }

	        private Int32 m_ScaleNumbersRotation = 0;
	        public Int32 ScaleNumbersRotation
	        {
	            get{return m_ScaleNumbersRotation;}
	            set
	            { 
	                m_ScaleNumbersRotation = value;
	                                
	            }
	        }

	        private Byte m_CapIdx = 1;
	        private Brush[] m_CapBrush = { Brushes.Black, Brushes.Black, Brushes.Black, Brushes.Black, Brushes.Black };
	        private Brush CapBrush
	        {
	            get
	            {
	                return m_CapBrush[m_CapIdx];
	            }
	            set
	            {
	                if (m_CapBrush[m_CapIdx] != value)
	                {
	                    m_CapBrush[m_CapIdx] = value;
	                    CapBrushs = m_CapBrush;
	                    drawGaugeBackground = true;
	                    //Refresh();
	                }
	            }
	        }
	        public Brush[] CapBrushs
	        {
	            get{return m_CapBrush;}
	            set{m_CapBrush = value;}
	        }

	        private String[] m_CapText = { "", "", "", "", "" };
	        public String CapText
	        {
	            get{return m_CapText[m_CapIdx];}
	            set
	            {
	                if (m_CapText[m_CapIdx] != value)
	                {
	                    m_CapText[m_CapIdx] = value;
	                    CapsText = m_CapText;
	                    drawGaugeBackground = true;
	                    //Refresh();
	                }
	            }
	        }

	        public String[] CapsText
	        {
	            get{return m_CapText;}
	            set
	            {
	                for (Int32 counter = 0; counter < 5; counter++)
	                {
	                    m_CapText[counter] = value[counter];
	                }
	            }
	        }

	        private System.Windows.Point[] m_CapPosition = { new System.Windows.Point(10, 10), new System.Windows.Point(10, 10), new System.Windows.Point(10, 10), new System.Windows.Point(10, 10), new System.Windows.Point(10, 10) };
	        public System.Windows.Point CapPosition
	        {
	            get{return m_CapPosition[m_CapIdx];}
	            set
	            {
	                if (m_CapPosition[m_CapIdx] != value)
	                {
	                    m_CapPosition[m_CapIdx] = value;
	                    CapsPosition = m_CapPosition;
	                    drawGaugeBackground = true;
	                    //Refresh();
	                }
	            }
	        }

	        public System.Windows.Point[] CapsPosition
	        {
	            get
	            {
	                return m_CapPosition;
	            }
	            set
	            {
	                m_CapPosition = value;
	            }
	        }

	        private SimpleFont m_Font = new SimpleFont("Arial", 14);
	        public SimpleFont MyFont
	        {
	            get{return m_Font;}
	            set{m_Font = value;}
	        }

	        private Brush titleBrush = Brushes.DarkSlateGray;
	        public Brush TitleBrush
	        {
	            set { titleBrush = value; }
	            get { return titleBrush; }
	        }

	        private string titleGauge = "TitleGauge";
	        public string TitleGauge
	        {
	            set { titleGauge = value; }
	            get { return titleGauge; }
	        }

	        private float titleGaugePtX = -10;
	        public float TitleGaugePtX
	        {
	            set { titleGaugePtX = value; }
	            get { return titleGaugePtX; }
	        }

	        private float titleGaugePtY = 15;
	        public float TitleGaugePtY
	        {
	            set { titleGaugePtY = value; }
	            get { return titleGaugePtY; }
	        }

	        private SimpleFont titleFontGauge = new SimpleFont("Aril", 10);        
	        public SimpleFont TitleFontGauge
	        {
	            get { return titleFontGauge; }
	            set { titleFontGauge = value; }
	        }

	        private Single m_value1;
	        public Single Value1
	        {
	            get{return m_value1;}
	            set
	            {
	                if (m_value1 != value)
	                {
	                    m_value1 = Math.Min(Math.Max(value, m_MinValue), m_MaxValue);
	                    drawGaugeBackground = true;                    
	                    
	                }
	            }
	        }

	        private Single m_value2;

	        public Single Value2
	        {
	            get{return m_value2;}
	            set
	            {
	                if (m_value2 != value)
	                {
	                    m_value2 = Math.Min(Math.Max(value, m_MinValue), m_MaxValue);
	                    drawGaugeBackground = true;                    
	                    
	                }
	            }
	        }

	        private Single m_value3;
	        public Single Value3
	        {
	            get{return m_value3;}
	            set
	            {
	                if (m_value3 != value)
	                {
	                    m_value3 = Math.Min(Math.Max(value, m_MinValue), m_MaxValue);
	                    drawGaugeBackground = true;
	                    
	                }
	            }
	        }
	        #endregion

	        #region helper

	        public void InitTitle_Gauge(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleGauge = strTitle;
	            TitleFontGauge = nFont;
	            TitleGaugePtX = nX;
	            TitleGaugePtY = nY;	            
	        }
	        #endregion

			public void InitDxBrushes(SharpDX.Direct2D1.RenderTarget renderTarget)
            {
				if (dxNeedleBrush1 != null) { dxNeedleBrush1.Dispose(); dxNeedleBrush1 = null; }
				if (dxNeedleBrush2 != null) { dxNeedleBrush2.Dispose(); dxNeedleBrush2 = null; }
				if (dxNeedleBrush3 != null) { dxNeedleBrush3.Dispose(); dxNeedleBrush3 = null; }

				if (renderTarget == null)
                {
					return;
                }

				dxNeedleBrush1 = NeedleBrush1.ToDxBrush(renderTarget);
				dxNeedleBrush2 = NeedleBrush2.ToDxBrush(renderTarget);
				dxNeedleBrush3 = NeedleBrush3.ToDxBrush(renderTarget);
			}

			#region RegPaint       
			public void GaugeControl_Paint(SharpDX.Direct2D1.RenderTarget iRenderTarget, float originX, float originY)
	        {
				NT7Graphics graphics = new NT7Graphics(iRenderTarget);
				

	            if ((Width < 10) || (Height < 10))	            
	                return;
	            

                //1-circle
                int circle1_x1 = (int)m_Center.X - m_ScaleLinesMajorInnerRadius;
                int circle1_y1 = (int)m_Center.Y - m_ScaleLinesMajorInnerRadius;
                int circle1_r1 = 2 * m_ScaleLinesMajorInnerRadius;
                RectangleF rect1_1 = new RectangleF(circle1_x1, circle1_y1, circle1_r1, circle1_r1);

                int circle1_x2 = circle1_x1 + m_BaseLineRadiusHeight;
                int circle1_y2 = circle1_y1 + m_BaseLineRadiusHeight;
                int circle1_r2 = 2 * (m_ScaleLinesMajorInnerRadius - m_BaseLineRadiusHeight);
                RectangleF rect1_2 = new RectangleF(circle1_x2, circle1_y2, circle1_r2, circle1_r2);

//                //2-circle
//                int circle2_x1 = circle1_x1 + nAnotherLineRadius;
//                int circle2_y1 = circle1_y1 + nAnotherLineRadius;
//                int circle2_r1 = 2 * (m_ScaleLinesMajorInnerRadius - nAnotherLineRadius);
//                RectangleF rect2_1 = new RectangleF(circle2_x1, circle2_y1, circle2_r1, circle2_r1);

//                int circle2_x2 = circle1_x2 + nAnotherLineRadius;
//                int circle2_y2 = circle1_y2 + nAnotherLineRadius;
//                int circle2_r2 = 2 * (m_ScaleLinesMajorInnerRadius - m_BaseLineRadiusHeight - nAnotherLineRadius);
//                RectangleF rect2_2 = new RectangleF(circle2_x2, circle2_y2, circle2_r2, circle2_r2);

//                //3-circle               
//                int circle3_x1 = circle2_x1 + nAnotherLineRadius;
//                int circle3_y1 = circle2_y1 + nAnotherLineRadius;
//                int circle3_r1 = 2 * (m_ScaleLinesMajorInnerRadius - 2 * nAnotherLineRadius);
//                RectangleF rect3_1 = new RectangleF(circle3_x1, circle3_y1, circle3_r1, circle3_r1);

//                int circle3_x2 = circle2_x2 + nAnotherLineRadius;
//                int circle3_y2 = circle2_y2 + nAnotherLineRadius;
//                int circle3_r2 = 2 * (m_ScaleLinesMajorInnerRadius - m_BaseLineRadiusHeight - 2 * nAnotherLineRadius);
//                RectangleF rect3_2 = new RectangleF(circle3_x2, circle3_y2, circle3_r2, circle3_r2);

                double centerPointer = m_BaseArcSweep / 2;
				
				Stroke majorTickPen = new Stroke(Brushes.DimGray, 1);
				Stroke minorTickPen = new Stroke(Brushes.LightGray, 1);
			
				#region RegCircle1
			
				int cX = (int)(originX+ rect1_2.X) + m_ScaleLinesMajorOuterRadius;
				int cY = (int)(originY+ rect1_2.Y) + m_ScaleLinesMajorOuterRadius;				
			
				// main red area
				SharpDX.Direct2D1.PathGeometry	g1		= null;
				SharpDX.Direct2D1.GeometrySink	sink1	= null;
				
				if (sink1 == null)
				{
					g1			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					sink1		= g1.Open();
				}
				
				double startAngle = 126;
				double endAngle = startAngle + -254;
				
				// Initial Circle Offset
				int offset = 43;					
				int offsetDelta = 15;
																					
				sink1.BeginFigure(new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(startAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(startAngle)))), SharpDX.Direct2D1.FigureBegin.Filled);
				
				SharpDX.Direct2D1.ArcSegment arcSegment = new SharpDX.Direct2D1.ArcSegment();
				arcSegment.Size = new SharpDX.Size2F(offset,offset);
				arcSegment.Point = new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(endAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(endAngle))));
				arcSegment.SweepDirection = SharpDX.Direct2D1.SweepDirection.CounterClockwise;
				arcSegment.ArcSize = SharpDX.Direct2D1.ArcSize.Large;
				
				sink1.AddArc(arcSegment);
				
				offset += offsetDelta;
			
				sink1.AddLine(new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(endAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(endAngle)))));
							
				startAngle = 232;
				endAngle = startAngle + 254;
	
				SharpDX.Direct2D1.ArcSegment arcSegment2 = new SharpDX.Direct2D1.ArcSegment();
				arcSegment2.Size = new SharpDX.Size2F(offset,offset);
				arcSegment2.Point = new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(endAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(endAngle))));
				arcSegment2.SweepDirection = SharpDX.Direct2D1.SweepDirection.Clockwise;
				arcSegment2.ArcSize = SharpDX.Direct2D1.ArcSize.Large;
				
				sink1.AddArc(arcSegment2);	
								
				sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
				sink1.Close();	
									
				LinearGradientBrush lgb0 = new LinearGradientBrush();
				lgb0.StartPoint = new System.Windows.Point(cX - offset, cY - offset);								
				lgb0.EndPoint = new System.Windows.Point(cX - offset, cY + offset);
				
				GradientStop redGS = new GradientStop(Colors.Red, 0.75);					    					
				lgb0.GradientStops.Add(redGS);
				
				GradientStop yellowGS = new GradientStop(Colors.Yellow, 0.5);					    				
				lgb0.GradientStops.Add(yellowGS);		
				
				GradientStop greenGS = new GradientStop(Colors.Green, 0.25);								
			    lgb0.GradientStops.Add(greenGS);
					
				var blackStrokeDXBrush = blackStroke.Brush.ToDxBrush(iRenderTarget);
				if (g1 != null)
				{
					var brush1 = lgb0.ToDxBrush(iRenderTarget);
					iRenderTarget.FillGeometry(g1,brush1);
					brush1.Dispose();brush1=null;
					iRenderTarget.DrawGeometry(g1, blackStrokeDXBrush);

					g1.Dispose();
					sink1.Dispose();
					g1 = null;
					sink1 = null;
				}

				double degrees = -110;
				for(int z = 0; z < 12; z++)
				{
					graphics.DrawLine(
										majorTickPen,
										cX + (int) (offset * Math.Cos(DegreeToRadian(degrees))),
										cY + (int) (offset * Math.Sin(DegreeToRadian(degrees))),
										cX + (int) ((offset - offsetDelta + 1) * Math.Cos(DegreeToRadian(degrees))),
										cY + (int) ((offset - offsetDelta + 1) * Math.Sin(DegreeToRadian(degrees)))
									);					
					
					degrees += 20.0;
				}				
				
				#endregion
				
				#region RegCircle2
				
				cX = (int)(originX+ rect1_2.X) + m_ScaleLinesMajorOuterRadius;
				cY = (int)(originY+ rect1_2.Y) + m_ScaleLinesMajorOuterRadius;					
				
				if (sink1 == null)
				{
					g1			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					sink1		= g1.Open();
				}
				
				startAngle = 126;
				endAngle = startAngle + -254;
				
				offset += (int)(offsetDelta * .5); 
				
				sink1.BeginFigure(new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(startAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(startAngle)))), SharpDX.Direct2D1.FigureBegin.Filled);
				
				arcSegment = new SharpDX.Direct2D1.ArcSegment();
				arcSegment.Size = new SharpDX.Size2F(offset,offset);
				arcSegment.Point = new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(endAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(endAngle))));
				arcSegment.SweepDirection = SharpDX.Direct2D1.SweepDirection.CounterClockwise;
				arcSegment.ArcSize = SharpDX.Direct2D1.ArcSize.Large;
				
				sink1.AddArc(arcSegment);
				
				offset += offsetDelta;
			
				sink1.AddLine(new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(endAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(endAngle)))));
		
				startAngle = 232;
				endAngle = startAngle + 254;
				
				arcSegment2 = new SharpDX.Direct2D1.ArcSegment();
				arcSegment2.Size = new SharpDX.Size2F(offset,offset);
				arcSegment2.Point = new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(endAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(endAngle))));
				arcSegment2.SweepDirection = SharpDX.Direct2D1.SweepDirection.Clockwise;
				arcSegment2.ArcSize = SharpDX.Direct2D1.ArcSize.Large;
				
				sink1.AddArc(arcSegment2);	
								
				sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
				sink1.Close();	
				
				LinearGradientBrush lgb1 = new LinearGradientBrush();
				lgb1.StartPoint = new System.Windows.Point(cX - offset, cY - offset);								
				lgb1.EndPoint = new System.Windows.Point(cX - offset, cY + offset);
												    				
				lgb1.GradientStops.Add(redGS);		
				lgb1.GradientStops.Add(yellowGS);									
			    lgb1.GradientStops.Add(greenGS);				

				if (g1 != null)
				{		
					var brush1 = lgb1.ToDxBrush(iRenderTarget);
					iRenderTarget.FillGeometry(g1,brush1);
					iRenderTarget.DrawGeometry(g1, blackStrokeDXBrush);
					brush1.Dispose();brush1=null;

					g1.Dispose();
					sink1.Dispose();
					g1 = null;
					sink1 = null;
				}	
				
				degrees = -110;
				for(int z = 0; z < 12; z++)
				{
					graphics.DrawLine(
										majorTickPen,
										cX + (int) (offset * Math.Cos(DegreeToRadian(degrees))),
										cY + (int) (offset * Math.Sin(DegreeToRadian(degrees))),
										cX + (int) ((offset - offsetDelta + 1) * Math.Cos(DegreeToRadian(degrees))),
										cY + (int) ((offset - offsetDelta + 1) * Math.Sin(DegreeToRadian(degrees)))
									);					
					
					degrees += 20.0;
				}				
				
				#endregion
			
				#region RegCircle3
				
				cX = (int)(originX+ rect1_2.X) + m_ScaleLinesMajorOuterRadius;
				cY = (int)(originY+ rect1_2.Y) + m_ScaleLinesMajorOuterRadius;					
				
				if (sink1 == null)
				{
					g1			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					sink1		= g1.Open();
				}
				
				startAngle = 126;
				endAngle = startAngle + -254;
				
				offset += (int)(offsetDelta * 0.5);
				
				sink1.BeginFigure(new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(startAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(startAngle)))), SharpDX.Direct2D1.FigureBegin.Filled);
				
				arcSegment = new SharpDX.Direct2D1.ArcSegment();
				arcSegment.Size = new SharpDX.Size2F(offset,offset);
				arcSegment.Point = new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(endAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(endAngle))));
				arcSegment.SweepDirection = SharpDX.Direct2D1.SweepDirection.CounterClockwise;
				arcSegment.ArcSize = SharpDX.Direct2D1.ArcSize.Large;
				
				sink1.AddArc(arcSegment);
				
				offset += offsetDelta;
			
				sink1.AddLine(new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(endAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(endAngle)))));
		
				startAngle = 232;
				endAngle = startAngle + 254;
				
				arcSegment2 = new SharpDX.Direct2D1.ArcSegment();
				arcSegment2.Size = new SharpDX.Size2F(offset,offset);
				arcSegment2.Point = new SharpDX.Vector2(cX + offset * Convert.ToSingle( Math.Cos(DegreeToRadian(endAngle))), cY + offset * Convert.ToSingle( Math.Sin(DegreeToRadian(endAngle))));
				arcSegment2.SweepDirection = SharpDX.Direct2D1.SweepDirection.Clockwise;
				arcSegment2.ArcSize = SharpDX.Direct2D1.ArcSize.Large;
				
				sink1.AddArc(arcSegment2);	
									
				sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
				sink1.Close();				

				LinearGradientBrush lgb2 = new LinearGradientBrush();
				lgb2.StartPoint = new System.Windows.Point(cX - offset, cY - offset);								
				lgb2.EndPoint = new System.Windows.Point(cX - offset, cY + offset);
									    					
				lgb2.GradientStops.Add(redGS);				    				
				lgb2.GradientStops.Add(yellowGS);										
			    lgb2.GradientStops.Add(greenGS);
				
				if (g1 != null)
				{			
					var brush1 = lgb2.ToDxBrush(iRenderTarget);
					iRenderTarget.FillGeometry(g1,brush1);
					iRenderTarget.DrawGeometry(g1,blackStrokeDXBrush);
					brush1.Dispose();brush1=null;

					g1.Dispose();
					sink1.Dispose();
					g1 = null;
					sink1 = null;
				}	
				
				degrees = -110;
				for(int z = 0; z < 12; z++)
				{
					graphics.DrawLine(
										majorTickPen,
										cX + (int) (offset * Math.Cos(DegreeToRadian(degrees))),
										cY + (int) (offset * Math.Sin(DegreeToRadian(degrees))),
										cX + (int) ((offset - offsetDelta + 1) * Math.Cos(DegreeToRadian(degrees))),
										cY + (int) ((offset - offsetDelta + 1) * Math.Sin(DegreeToRadian(degrees)))
									);					
					
					degrees += 20.0;
				}					
				#endregion
				
                #region RegText 
                String valueText = "";
                Single countValue = 0;
                Int32 counter1 = 0;
                string m_ScaleNumbersFormat = "";
                while (countValue <= (m_MaxValue - m_MinValue))
                {
                    valueText = (m_MinValue + countValue).ToString(m_ScaleNumbersFormat);

                    if (counter1 >= m_ScaleNumbersStartScaleLine - 1)
                    {
                        float nX = Convert.ToSingle((Center.X + m_ScaleNumbersRadius * Math.Cos((m_BaseArcStart + countValue * m_BaseArcSweep / (m_MaxValue - m_MinValue)) * Math.PI / 180.0f)));// - boundingBox.Width;
                        float nY = Convert.ToSingle((Center.Y + m_ScaleNumbersRadius * Math.Sin((m_BaseArcStart + countValue * m_BaseArcSweep / (m_MaxValue - m_MinValue)) * Math.PI / 180.0f)));// -fontBoundY1 - (fontBoundY2 - fontBoundY1 + 1) / 2 + 10;
                        Single vTXT = Single.Parse(valueText);

                        valueText = "";
                        if (vTXT == m_MinValue)
                        {
                            valueText = "Bullish";
							NT7MeasureStringData szTxt = graphics.MeasureString(valueText.ToString(), m_Font);	
							
                            nX -= 2*szTxt.Width/3;
                            nY -= Convert.ToSingle((m_BaseLineRadiusHeight * Math.Sin((m_BaseArcStart + countValue * m_BaseArcSweep / (m_MaxValue - m_MinValue)) * Math.PI / 180.0f)));// szTxt.Height / 2;
							
							nY -= 40;
							
							graphics.DrawString(valueText, m_Font, m_ScaleNumbersBrush, originX+ nX, originY+ nY);		
							
							valueText = "L";
							nY += 28; 
							nX += 20;
							
							graphics.DrawString(valueText, m_Font, m_ScaleNumbersBrush, originX+ nX, originY+ nY);		
							
							valueText = "M";
							nY += 18; 
							nX += 8;
							
							graphics.DrawString(valueText, m_Font, m_ScaleNumbersBrush, originX+ nX, originY+ nY);
							
							valueText = "S";
							nY += 16; 
							nX += 16;
							
							graphics.DrawString(valueText, m_Font, m_ScaleNumbersBrush, originX+ nX, originY+ nY);								
                        }
                        if (vTXT == m_MaxValue)
                        {
                            valueText = "Bearish";
                            NT7MeasureStringData szTxt = graphics.MeasureString(valueText.ToString(), m_Font);	
                            nX -= 2 * szTxt.Width / 3;
							nX += 2;
                            nY -= (4*szTxt.Height/5 + Convert.ToSingle((m_BaseLineRadiusHeight * Math.Sin((m_BaseArcStart + countValue * m_BaseArcSweep / (m_MaxValue - m_MinValue)) * Math.PI / 180.0f))));
							
							nY += 36;
							
							graphics.DrawString(valueText, m_Font, m_ScaleNumbersBrush, originX+ nX, originY+ nY);							
                        }
                        if (vTXT == 0)
                        {
                            valueText = "N";
                            NT7MeasureStringData szTxt = graphics.MeasureString(valueText.ToString(), m_Font);	
                            nX += szTxt.Width / 2 + 5;
                            nY -= szTxt.Height / 2 - 5;
							
							graphics.DrawString(valueText, m_Font, m_ScaleNumbersBrush, originX+ nX, originY+ nY);							
                        }
                    }

                    countValue += m_ScaleLinesMajorStepValue;
                    counter1++;
                }
				
                NT7MeasureStringData szTitle = graphics.MeasureString(titleGauge.ToString(), titleFontGauge);
				graphics.DrawString(titleGauge, titleFontGauge, titleBrush, (int)(originX+ Center.X - circle1_r1 / 2 + titleGaugePtX), (int)(originY+ Center.Y + titleGaugePtY - szTitle.Height / 2));

				#endregion
				
				#region RegNeedle
				
	            //For 1 circle
	            Single brushAngle = (Int32)(m_BaseArcStart + (m_value1 - m_MinValue) * m_BaseArcSweep / (m_MaxValue - m_MinValue)) % 360;
	            Double needleAngle = brushAngle * Math.PI / 180;
	            //For 2 circle
	            Single brushAngle2 = (Int32)(m_BaseArcStart + (m_value2 - m_MinValue) * m_BaseArcSweep / (m_MaxValue - m_MinValue)) % 360;
	            Double needleAngle2 = brushAngle2 * Math.PI / 180;
	            //For 3 circle
	            Single brushAngle3 = (Int32)(m_BaseArcStart + (m_value3 - m_MinValue) * m_BaseArcSweep / (m_MaxValue - m_MinValue)) % 360;
	            Double needleAngle3 = brushAngle3 * Math.PI / 180;

				int needle_X = (int)(originX+ rect1_2.X) + m_ScaleLinesMajorOuterRadius;
				int needle_Y = (int)(originY+ rect1_2.Y) + m_ScaleLinesMajorOuterRadius;	
				
	            switch (m_NeedleType)
	            {
	                case 1:
	                    //For 1 circle
	                    System.Windows.Point startPoint = new System.Windows.Point((Int32)(needle_X - m_NeedleRadius / 8 * Math.Cos(needleAngle)),
	                                                (Int32)(needle_Y - m_NeedleRadius / 8 * Math.Sin(needleAngle)));
	                    System.Windows.Point endPoint = new System.Windows.Point((Int32)(needle_X + m_NeedleRadius * Math.Cos(needleAngle)),
	                                                (Int32)(needle_Y + m_NeedleRadius * Math.Sin(needleAngle)));

	                    graphics.DrawLine(dxNeedleBrush1, m_NeedleWidth, needle_X, needle_Y, Convert.ToSingle(endPoint.X), Convert.ToSingle(endPoint.Y));
						graphics.DrawLine(dxNeedleBrush1, m_NeedleWidth, needle_X, needle_Y, Convert.ToSingle(startPoint.X), Convert.ToSingle(startPoint.Y));									                    
						graphics.FillEllipse(dxNeedleBrush1, Convert.ToSingle(endPoint.X) - 2, Convert.ToSingle(endPoint.Y) - 2, 6, 6);										                    

	                    //For 2 circle
	                    System.Windows.Point startPoint2 = new System.Windows.Point((Int32)(needle_X - m_NeedleRadius / 8 * Math.Cos(needleAngle2)),
	                                                (Int32)(needle_Y - m_NeedleRadius / 8 * Math.Sin(needleAngle2)));
	                    System.Windows.Point endPoint2 = new System.Windows.Point((Int32)(needle_X + (m_NeedleRadius - nAnotherLineRadius) * Math.Cos(needleAngle2)),
	                                                (Int32)(needle_Y + (m_NeedleRadius - nAnotherLineRadius) * Math.Sin(needleAngle2)));

	                    graphics.DrawLine(dxNeedleBrush2, m_NeedleWidth, needle_X, needle_Y, Convert.ToSingle(endPoint2.X), Convert.ToSingle(endPoint2.Y));
	                    graphics.DrawLine(dxNeedleBrush2, m_NeedleWidth, needle_X, needle_Y, Convert.ToSingle(startPoint2.X), Convert.ToSingle(startPoint2.Y));
						graphics.FillEllipse(dxNeedleBrush2, Convert.ToSingle(endPoint2.X) - 2, Convert.ToSingle(endPoint2.Y) - 2, 6, 6);										                    

	                    //For 3 circle
	                    System.Windows.Point startPoint3 = new System.Windows.Point((Int32)(needle_X - m_NeedleRadius / 8 * Math.Cos(needleAngle3)),
	                                                (Int32)(needle_Y - m_NeedleRadius / 8 * Math.Sin(needleAngle3)));
	                    System.Windows.Point endPoint3 = new System.Windows.Point((Int32)(needle_X + (m_NeedleRadius - 2 * nAnotherLineRadius) * Math.Cos(needleAngle3)),
	                                                (Int32)(needle_Y + (m_NeedleRadius - 2 * nAnotherLineRadius) * Math.Sin(needleAngle3)));

	                    graphics.DrawLine(dxNeedleBrush3, m_NeedleWidth, needle_X, needle_Y, Convert.ToSingle(endPoint3.X), Convert.ToSingle(endPoint3.Y));
	                    graphics.DrawLine(dxNeedleBrush3, m_NeedleWidth, needle_X, needle_Y, Convert.ToSingle(startPoint3.X), Convert.ToSingle(startPoint3.Y));
						graphics.FillEllipse(dxNeedleBrush3, Convert.ToSingle(endPoint3.X) - 2, Convert.ToSingle(endPoint3.Y) - 2, 6, 6);										                    

						RectangleF ball = new RectangleF((int)m_Center.X - m_NeedleWidth * 4, (int)m_Center.Y - m_NeedleWidth * 4, m_NeedleWidth * 4, m_NeedleWidth * 4);
						
						// Center Point
						LinearGradientBrush centerLinearBrush = 
														new LinearGradientBrush( 
															Colors.Black, 									
															Colors.White, 															
															new System.Windows.Point(ball.TopLeft.X,ball.TopLeft.Y),
															new System.Windows.Point(ball.BottomRight.X, ball.BottomRight.Y));				
												
	                    graphics.FillEllipse(centerLinearBrush, needle_X - m_NeedleWidth * 4, needle_Y - m_NeedleWidth * 4, m_NeedleWidth * 8, m_NeedleWidth * 8);
						break;
	            }
				
				#endregion
	 
				blackStrokeDXBrush.Dispose();blackStrokeDXBrush=null;
	        }

			private bool IsOdd(int iValue)
			{			
				return iValue % 2 != 0;
			}

	        private void DrawRotatedTextAt(SharpDX.Direct2D1.RenderTarget iRenderTarget, NT7Graphics iGraphics, float angle, string txt, int x, int y, SimpleFont iFont, Brush iBrush)
	        {				
				iGraphics.DrawStringRotated(txt, iFont, iBrush, x, y, angle);
	        }
			
			private double DegreeToRadian(double angle)
			{
				return Math.PI * angle / 180.0;
			}
			
			private double RadianToDegree(double angle)
			{
				return angle * (180.0 / Math.PI);
			}
		
	        #endregion
	    }	

		#endregion

		#region RegThermometer
	    internal class ClassThermometerBar
	    {
			#region RegHelper
			
			internal class NT7MeasureStringData
			{
				public float Height;
				public float Width;
				
				public NT7MeasureStringData()
				{
					
				}
			}
				
			
			internal class NT7Graphics
			{
				SharpDX.Direct2D1.RenderTarget rt;
			
				public NT7Graphics(SharpDX.Direct2D1.RenderTarget rt)
				{
					this.rt = rt;
				}
				
				public void DrawEllipse(Stroke s, RectangleF rect)
				{
					this.DrawEllipse(s, rect.X, rect.Y, rect.Width, rect.Height);
				}
				
				public void DrawEllipse(Stroke s, float x, float y, float w, float h)
				{
					float half = w / 2;
					float x0 = Convert.ToSingle (x + half - 1);
					float y0 = Convert.ToSingle (y + half - 1);
					SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
					SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f); 
					var brush = s.Brush.ToDxBrush(this.rt);
					this.rt.DrawEllipse(ellipse, brush,s.Width);
					brush.Dispose();brush=null;
				}
				
				public void FillEllipse(Brush b, RectangleF rect)
				{
					this.FillEllipse(b, rect.X, rect.Y, rect.Width, rect.Height);
				}
				
				public void FillEllipse(Brush b, float x, float y, float w, float h)
				{
					float half = w / 2;
					float x0 = Convert.ToSingle (x + half - 1);
					float y0 = Convert.ToSingle (y + half - 1);
					SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
					SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f); 
					var brush = b.ToDxBrush(this.rt);
					this.rt.FillEllipse(ellipse, brush);
					brush.Dispose();brush=null;
				}
				
				public void DrawRectangle(Stroke s, RectangleF rect)
				{
					this.DrawRectangle(s,rect.X, rect.Y, rect.Width, rect.Height);
				}
				
				public void DrawRectangle(Stroke s, float x, float y, float w, float h)
				{
					SharpDX.RectangleF rectf = new SharpDX.RectangleF(x, y, w, h);
					var brush = s.Brush.ToDxBrush(this.rt);
					this.rt.DrawRectangle(rectf, brush,s.Width);
					brush.Dispose();brush=null;
				}
				
				public void FillRectangle(Brush b, RectangleF rect)
				{
					this.FillRectangle(b,rect.X, rect.Y, rect.Width, rect.Height);
				}
				
				public void FillRectangle(Brush b, float x, float y, float w, float h)
				{
					SharpDX.RectangleF rectf = new SharpDX.RectangleF(x, y, w, h);
					var brush = b.ToDxBrush(this.rt);
					this.rt.FillRectangle(rectf, brush);
					brush.Dispose();brush=null;
				}
				
				public void DrawLine(Stroke s, float x1, float y1, float x2, float y2)
				{
					System.Windows.Point startPoint	= new System.Windows.Point(x1, y1);
					System.Windows.Point endPoint		= new System.Windows.Point(x2, y2);
					var brush = s.Brush.ToDxBrush(this.rt);
					this.rt.DrawLine(startPoint.ToVector2(), endPoint.ToVector2(), brush, s.Width, s.StrokeStyle);
					brush.Dispose();brush=null;
				}
				
				public void DrawString(String text, SimpleFont f, Brush b, RectangleF rect, SharpDX.DirectWrite.TextAlignment ta)
				{
					this.DrawString(text, f, b, rect.X, rect.Y, rect.Width, rect.Height, ta);
				}
				
				public void DrawString(String text, SimpleFont f, Brush b, RectangleF rect)
				{
					this.DrawString(text, f, b, rect.X, rect.Y);
				}
				
				public void DrawString(String text, SimpleFont f, Brush b, float x, float y)
				{
					this.DrawString(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading);
				}
				
				public void DrawStringRotated(String text, SimpleFont f, Brush b, float x, float y, float iAngle)
				{
					this.DrawStringRotated(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading, iAngle);
				}				
				
				public void DrawString(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta)
				{
					TextFormat textFormat		= 
						new TextFormat(
							Core.Globals.DirectWriteFactory, 
							f.Family.ToString(), 
							(f.Bold?SharpDX.DirectWrite.FontWeight.Bold:SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal, 
							SharpDX.DirectWrite.FontStretch.Normal, 
							Convert.ToSingle(f.Size)) 
							{ 
								TextAlignment = ta, 
								WordWrapping = WordWrapping.NoWrap 
							};
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,w,h);//(float)f.Size);
					
					System.Windows.Point upperTextPoint	= new System.Windows.Point(x,y);
					var brush = b.ToDxBrush(this.rt);
					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					brush.Dispose();brush=null;
				}
				
				public void DrawStringRotated(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta, float iAngle)
				{
					TextFormat textFormat		= 
						new TextFormat(
							Core.Globals.DirectWriteFactory, 
							f.Family.ToString(), 
							(f.Bold?SharpDX.DirectWrite.FontWeight.Bold:SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal, 
							SharpDX.DirectWrite.FontStretch.Normal, 
							Convert.ToSingle(f.Size))
							{ 
								TextAlignment = ta, 
								WordWrapping = WordWrapping.NoWrap 
							};
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,w,h);//(float)f.Size);
					
					System.Windows.Point upperTextPoint	= new System.Windows.Point(x,y);
								
					SharpDX.Matrix3x2 savedTransform = this.rt.Transform;
					
					this.rt.Transform = SharpDX.Matrix3x2.Rotation(iAngle, new SharpDX.Vector2(x, y));	
					var brush = b.ToDxBrush(this.rt);
					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					brush.Dispose();brush=null;
							
					this.rt.Transform = savedTransform;																		
				}				
				
				public NT7MeasureStringData MeasureString( String text, SimpleFont f)
				{
					NT7MeasureStringData sd = new NT7MeasureStringData();
					
					TextFormat textFormat		= new TextFormat(Core.Globals.DirectWriteFactory, f.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal,
													SharpDX.DirectWrite.FontStyle.Normal, SharpDX.DirectWrite.FontStretch.Normal, Convert.ToSingle(f.Size)) 
													{ TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading, WordWrapping = WordWrapping.NoWrap };
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,400,Convert.ToSingle(f.Size));
					
													
					sd.Height = Convert.ToSingle( textLayout.Metrics.Height);
					sd.Width = Convert.ToSingle( textLayout.Metrics.Width);
													
					return sd;
				}
				
				public void FillPolygon(Brush b, System.Windows.Point[] p)
				{
					SharpDX.Direct2D1.PathGeometry	g		= null;
					SharpDX.Direct2D1.GeometrySink	sink	= null;
					
					if (sink == null)
					{
						g			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						sink		= g.Open();
						
					}
					
					sink.BeginFigure(new SharpDX.Vector2(Convert.ToSingle(p[0].X), Convert.ToSingle(p[0].Y)), SharpDX.Direct2D1.FigureBegin.Filled);
					for(int pidx = 1; pidx < p.Length; pidx++)
					{
						sink.AddLine(new SharpDX.Vector2(Convert.ToSingle(p[pidx].X), Convert.ToSingle(p[pidx].Y)));
					}
					sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
					sink.Close();
					
					if (g != null)
					{
						var brush = b.ToDxBrush(this.rt);
						this.rt.FillGeometry(g, brush); 
						brush.Dispose();brush=null;
						g.Dispose();
						sink.Dispose();
						g = null;
						sink = null;
					}
				}
				
				public void DrawPolygon(Stroke s, System.Windows.Point[] p)
				{
					SharpDX.Direct2D1.PathGeometry	g		= null;
					SharpDX.Direct2D1.GeometrySink	sink	= null;
					
					if (sink == null)
					{
						g			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						sink		= g.Open();
						
					}
					
					sink.BeginFigure(new SharpDX.Vector2(Convert.ToSingle(p[0].X) ,Convert.ToSingle(p[0].Y)), SharpDX.Direct2D1.FigureBegin.Filled);
					for(int pidx = 1; pidx < p.Length; pidx++)
					{
						sink.AddLine(new SharpDX.Vector2(Convert.ToSingle(p[pidx].X), Convert.ToSingle(p[pidx].Y)));
					}
					sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
					sink.Close();
					
					if (g != null)
					{
						var brush = s.Brush.ToDxBrush(this.rt);
						this.rt.DrawGeometry(g,brush); 
						brush.Dispose();brush=null;
						
						g.Dispose();
						sink.Dispose();
						g = null;
						sink = null;
					}
				}
			}
			#endregion

	        public ClassThermometerBar(float iHeight, float iWidth)
	        {
	            m_width = iWidth;
	            m_height = iHeight;            
	        }

			#region RegInputs
			
	        // Corner Round
	        private float cornerRadius = 5;        
	        public float CornerRadius
	        {
	            set { cornerRadius = value; }
	            get { return cornerRadius; }
	        }

	        // Temperature Value1
	        private float val1 = 0;        
	        public float Value1
	        {
	            set { val1 = value; }
	            get { return val1; }
	        }
	        // Temperature Value2
	        private float val2 = 0;        
	        public float Value2
	        {
	            set { val2 = value;  }
	            get { return val2; }
	        }
	        // Temperature Value3
	        private float val3 = 0;        
	        public float Value3
	        {
	            set { val3 = value;  }
	            get { return val3; }
	        }

	        // Bar 1 Max Value
	        private float scale1_Max = 50;        
	        public float Scale1_Max
	        {
	            set { scale1_Max = value; }
	            get { return scale1_Max; }
	        }

	        // Bar 1 Min Value
	        private float scale1_Min = -20;        
	        public float Scale1_Min
	        {
	            set { scale1_Min = value; }
	            get { return scale1_Min; }
	        }

	        // Bar 2 Max Value
	        private float scale2_Max = 50;        
	        public float Scale2_Max
	        {
	            set { scale2_Max = value; }
	            get { return scale2_Max; }
	        }

	        // Bar 2 Min Value
	        private float scale2_Min = -20;        
	        public float Scale2_Min
	        {
	            set { scale2_Min = value; }
	            get { return scale2_Min; }
	        }

	        // Bar 3 Max Value
	        private float scale3_Max = 50;        
	        public float Scale3_Max
	        {
	            set { scale3_Max = value; }
	            get { return scale3_Max; }
	        }

	        // Bar 3 Min Value
	        private float scale3_Min = -20;        
	        public float Scale3_Min
	        {
	            set { scale3_Min = value; }
	            get { return scale3_Min; }
	        }

	        // Bar 1 Margin
	        private float bar_margin_TopBottom1 = 15;        
	        public float Bar_margin_TopBottom1
	        {
	            set { bar_margin_TopBottom1 = value; }
	            get { return bar_margin_TopBottom1; }
	        }
	        // Bar 2 Margin
	        private float bar_margin_TopBottom2 = 15;
	        public float Bar_margin_TopBottom2
	        {
	            set { bar_margin_TopBottom2 = value; }
	            get { return bar_margin_TopBottom2; }
	        }
	        // Bar 3 Margin
	        private float bar_margin_TopBottom3 = 15;
	        public float Bar_margin_TopBottom3
	        {
	            set { bar_margin_TopBottom3 = value; }
	            get { return bar_margin_TopBottom3; }
	        }

	        // Current Value Font
	        private SimpleFont tempFont = new SimpleFont("Times New Roman", 13);        
	        public SimpleFont TempFont
	        {
	            set { tempFont = value; }
	            get { return tempFont; }
	        }

	        
	        private Brush titleColor = Brushes.DarkSlateGray;        
	        public Brush TitleColor
	        {
	            set { titleColor = value; }
	            get { return titleColor; }
	        }

	        //Bar1 Big scale counts
	        private int bigScale1 = 5;        
	        public int BigScale1
	        {
	            set { bigScale1 = value; }
	            get { return bigScale1; }
	        }

	        //Bar2 Big scale counts
	        private int bigScale2 = 5;        
	        public int BigScale2
	        {
	            set { bigScale2 = value; }
	            get { return bigScale2; }
	        }

	        //Bar3 Big scale counts
	        private int bigScale3 = 5;        
	        public int BigScale3
	        {
	            set { bigScale3 = value; }
	            get { return bigScale3; }
	        }

	        private string titleBar1 = "Bar1";        
	        public string TitleBar1
	        {
	            set { titleBar1 = value; }
	            get { return titleBar1; }
	        }

	        private string titleBar2 = "Bar2";
	        public string TitleBar2
	        {
	            set { titleBar2 = value; }
	            get { return titleBar2; }
	        }

	        private string titleBar3 = "Bar3";
	        public string TitleBar3
	        {
	            set { titleBar3 = value; }
	            get { return titleBar3; }
	        }

	        private float titlePtXBar1 = 15;
	        public float TitlePtXBar1
	        {
	            set { titlePtXBar1 = value; }
	            get { return titlePtXBar1; }
	        }

	        private float titlePtXBar2 = 15;
	        public float TitlePtXBar2
	        {
	            set { titlePtXBar2 = value; }
	            get { return titlePtXBar2; }
	        }

	        private float titlePtXBar3 = 15;
	        public float TitlePtXBar3
	        {
	            set { titlePtXBar3 = value; }
	            get { return titlePtXBar3; }
	        }

	        private float titlePtYBar1 = 15;
	        public float TitlePtYBar1
	        {
	            set { titlePtYBar1 = value; }
	            get { return titlePtYBar1; }
	        }

	        private float titlePtYBar2 = 15;
	        public float TitlePtYBar2
	        {
	            set { titlePtYBar2 = value; }
	            get { return titlePtYBar2; }
	        }

	        private float titlePtYBar3 = 15;
	        public float TitlePtYBar3
	        {
	            set { titlePtYBar3 = value; }
	            get { return titlePtYBar3; }
	        }

	        private SimpleFont titleFontBar1 = new SimpleFont("Aril", 14);        
	        public SimpleFont TitleFontBar1
	        {
	            get { return titleFontBar1; }
	            set { titleFontBar1 = value; }
	        }

	        private SimpleFont titleFontBar2 = new SimpleFont("Aril", 14);        
	        public SimpleFont TitleFontBar2
	        {
	            get { return titleFontBar2; }
	            set { titleFontBar2 = value; }
	        }

	        private SimpleFont titleFontBar3 = new SimpleFont("Aril", 14);        
	        public SimpleFont TitleFontBar3
	        {
	            get { return titleFontBar3; }
	            set { titleFontBar3 = value; }
	        }

	        // bar small scale counts
	        private int smallScale = 5;        
	        public int SmallScale
	        {
	            set { smallScale = value; }
	            get { return smallScale; }
	        }

	        // scale Font
	        private SimpleFont drawFont = new SimpleFont("Aril", 9);        
	        public SimpleFont DrawFont
	        {
	            get { return drawFont; }
	            set { drawFont = value; }
	        }

	        // Font Color
	        private Brush drawColor = Brushes.White;        
	        public Brush DrawColor
	        {
	            set { drawColor = value; }
	            get { return drawColor; }
	        }

	        // Outline line color
	        private Brush dialOutLineColor = Brushes.Gray;        
	        public Brush DialOutLineColor
	        {
	            set { dialOutLineColor = value; }
	            get { return dialOutLineColor; }
	        }

	        // Main BackColor
	        private Brush dialBackColor = Brushes.Gray;        
	        public Brush DialBackColor
	        {
	            set { dialBackColor = value; }
	            get { return dialBackColor; }
	        }

	        // Big Scale Color
	        private Brush bigScaleColor = Brushes.Black;        
	        public Brush BigScaleColor
	        {
	            set { bigScaleColor = value; }
	            get { return bigScaleColor; }
	        }

	        // Small Scale Color
	        private Brush smallScaleColor = Brushes.Black;        
	        public Brush SmallScaleColor
	        {
	            set { smallScaleColor = value; }
	            get { return smallScaleColor; }
	        }

	        // Value bar backColor
	        private Brush mercuryBackColor = Brushes.LightGray;        
	        public Brush MercuryBackColor
	        {
	            set { mercuryBackColor = value; }
	            get { return mercuryBackColor; }
	        }

	        // Color really Value
	        private Brush mercuryColor = Brushes.Blue;        
	        public Brush MercuryColor
	        {
	            set { mercuryColor = value; }
	            get { return mercuryColor; }
	        }
			
			#endregion

	        #region RegFunctions
	        public void InitBaseVal_Bar1(float nScaleMin, float nScaleMax, int barTopBottomMargin, int nBigscale)
	        {
	            Bar_margin_TopBottom1 = barTopBottomMargin;
	            BigScale1 = nBigscale;
	            Scale1_Min = nScaleMin;
	            Scale1_Max = nScaleMax;
	        }

	        public void InitBaseVal_Bar2(float nScaleMin, float nScaleMax, int barTopBottomMargin, int nBigscale)
	        {
	            Bar_margin_TopBottom2 = barTopBottomMargin;
	            BigScale2 = nBigscale;
	            Scale2_Min = nScaleMin;
	            Scale2_Max = nScaleMax;
	        }

	        public void InitBaseVal_Bar3(float nScaleMin, float nScaleMax, int barTopBottomMargin, int nBigscale)
	        {
	            Bar_margin_TopBottom3 = barTopBottomMargin;
	            BigScale3 = nBigscale;
	            Scale3_Min = nScaleMin;
	            Scale3_Max = nScaleMax;
	        }

	        public void InitTitle_Bar1(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleBar1 = strTitle;
	            TitleFontBar1 = nFont;
	            TitlePtXBar1 = nX;            
	            TitlePtYBar1 = nY;            
	        }

	        public void InitTitle_Bar2(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleBar2 = strTitle;
	            TitleFontBar2 = nFont;
	            TitlePtXBar2 = nX;
	            TitlePtYBar2 = nY;
	        }

	        public void InitTitle_Bar3(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleBar3 = strTitle;
	            TitleFontBar3 = nFont;
	            TitlePtXBar3 = nX;
	            TitlePtYBar3 = nY;
	        }

	        private void DrawRotatedTextAt(SharpDX.Direct2D1.RenderTarget iRenderTarget, NT7Graphics iGraphics, float angle, string txt, int x, int y, SimpleFont iFont, Brush iBrush)
	        {				
				iGraphics.DrawStringRotated(txt, iFont, iBrush, x, y, angle);
	        }
			
			#endregion
					
	        private float X;
	        private float Y;
	        private float H1;
	        private float H2;
	        private float H3;
	        private float m_width;
	        private float m_height;
	        private Stroke p, s_p;
	        //private Brush b;        
	        
	        public void ThermometerControl_Paint(SharpDX.Direct2D1.RenderTarget iRenderTarget, float originX, float originY, NinjaTrader.NinjaScript.IndicatorBase parent)
	        {
				NT7Graphics graphics = new NT7Graphics(iRenderTarget);
				
	            // truncate Values
	            if (val1 > scale1_Max)
	            {
	                val1 = scale1_Max;
	            }
	            if (val1 < scale1_Min)
	            {
	                val1 = scale1_Min;
	            }

	            if (val2 > scale2_Max)
	            {
	                val2 = scale2_Max;
	            }
	            if (val2 < scale2_Min)
	            {
	                val2 = scale2_Min;
	            }

	            if (val3 > scale3_Max)
	            {
	                val3 = scale3_Max;
	            }
	            if (val3 < scale3_Min)
	            {
	                val3 = scale3_Min;
	            }

	            //graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;            

	            X = m_width - 2;
	            Y = m_height - 2;
	            
	            float barPoint_X = X * 2 / 5;
	            float barEllipseHeight = X / (5 * CornerRadius);
	            float barRealHeight1 = Y - 2 * bar_margin_TopBottom1;
	            float barRealHeight2 = Y - 2 * bar_margin_TopBottom2;
	            float barRealHeight3 = Y - 2 * bar_margin_TopBottom3;

	            for (int i=0; i<3; i++)
	            {
	                float barMargin = 0;
	                float barRHeight = 0;
	                switch (i)
	                {
	                    case 0:
	                        barMargin = bar_margin_TopBottom1; barRHeight = barRealHeight1;
	                        break;
	                    case 1:
	                        barMargin = bar_margin_TopBottom2; barRHeight = barRealHeight2;
	                        break;
	                    case 2:
	                        barMargin = bar_margin_TopBottom3; barRHeight = barRealHeight3;
	                        break;
	                }
	                //Draw Outline
	                //@-1
	                p = new Stroke(dialOutLineColor, 2);
					
					// This draws the outlines around each one
	                //graphics.DrawLine(p, i * X, X / (2 * CornerRadius), i * X, (Y - X / (2 * CornerRadius)));
	                //graphics.DrawLine(p, (i+1) * X, X / (2 * CornerRadius), (i + 1) * X, (Y - X / (2 * CornerRadius)));
	                //e.Graphics.DrawArc(p, i * X, 0, X, X / CornerRadius, 180, 180);
	                //e.Graphics.DrawArc(p, i * X, (Y - X / CornerRadius), X, X / CornerRadius, 0, 180);							
					

	                //Draw BackColor
	                float nX = X - 8;
	                float nY = Y - 8;                
//	                b = this.dialBackColor;
	                int dx = 4;
	                int dy = 4;                
	                graphics.FillRectangle(dialBackColor, originX+ (2 * i + 1) * dx + i * nX, nX / (2 * CornerRadius) + dy +originY, nX, (nY - nX / (2 * CornerRadius) - dy));

					// This draws the ellipse around each bar
	                //graphics.FillEllipse(b, (2 * i + 1) * dx + i * nX, dy, nX, nX / CornerRadius);
	               	//graphics.FillEllipse(b, (2 * i + 1) * dx + i * nX, (nY - nX / CornerRadius) + dy, nX, nX / CornerRadius);

	                //Draw Value background                
	                //graphics.FillEllipse(Brushes.Green, i * X + barPoint_X, barMargin - 4, X / 5, barEllipseHeight);                
	                //graphics.FillEllipse(this.mercuryColor, i * X + barPoint_X, (Y - barMargin), X / 5, barEllipseHeight);

					RectangleF gradientRect0 = new RectangleF(originX+ i * X + barPoint_X, (barMargin + barEllipseHeight / 2) +originY, X / 5, barRHeight);														
					LinearGradientBrush lgb0 = new LinearGradientBrush();
					
					lgb0.StartPoint = new System.Windows.Point(gradientRect0.TopLeft.X, gradientRect0.TopLeft.Y);
					lgb0.EndPoint = new System.Windows.Point(gradientRect0.BottomRight.X,gradientRect0.BottomRight.Y);
					
					GradientStop redGS = new GradientStop(Colors.Red, 0.75);
					lgb0.GradientStops.Add(redGS);

					GradientStop yellowGS = new GradientStop(Colors.Yellow, 0.5);
					lgb0.GradientStops.Add(yellowGS);		
					
					GradientStop greenGS = new GradientStop(Colors.Green, 0.25);
				    lgb0.GradientStops.Add(greenGS);

		            graphics.FillRectangle(lgb0, originX+ i * X + barPoint_X, (barMargin + barEllipseHeight / 2) +originY, X / 5, barRHeight);						
	            }							
	                        
	            //StringFormat format = new StringFormat();            
	            p = new Stroke(bigScaleColor, 2);           
	            s_p = new Stroke(smallScaleColor, 1);       
//	            Brush drawBrush = drawColor.Clone();
//				drawBrush.Freeze();
	            //format.Alignment = StringAlignment.Near;         

				float rotationAngle = -1.57079633f;
	            // Position current value           
	            
	            //@-1
	            int nScaleHeight1 = (int)(scale1_Max - scale1_Min);            
//parent.Print("\nnScaleHeight1: "+nScaleHeight1+" = scale1_Max/Min: "+scale1_Max+" - "+scale1_Min);
	            float smallInterval1 = Convert.ToSingle(barRealHeight1) / nScaleHeight1;
//parent.Print("\nsmallInterval1: "+smallInterval1+" = barRealHeight1/nScaleHeight1: "+barRealHeight1+" / "+nScaleHeight1);
	            H1 = barRealHeight1 * (val1 - scale1_Min) / (scale1_Max - scale1_Min);
//parent.Print("H1: "+H1+" = barRealHeight: "+barRealHeight1+" * (val1: "+val1+" - scale1_Min: "+scale1_Min+") / (scale1_Max-Min: "+scale1_Max+" - "+scale1_Min);
	            float absValueHeight1 = barRealHeight1 - H1;
//parent.Print("AbsValueH1: "+absValueHeight1+" = barRealHeight1-H1: "+barRealHeight1+" - "+H1);
	            //Draw current value
	            if (absValueHeight1 == 0) absValueHeight1 = 1f;
								
				RectangleF gradientRect = new RectangleF(originX+ 0 * X + barPoint_X, bar_margin_TopBottom1 +originY, X / 5, absValueHeight1);				
				LinearGradientBrush lgb1 = 
					new LinearGradientBrush(
						Colors.LightGray, 
						Colors.Gray, 
						new System.Windows.Point(gradientRect.TopLeft.X, gradientRect.TopLeft.Y),
						new System.Windows.Point(gradientRect.BottomRight.X,gradientRect.BottomRight.Y));
				
	            graphics.FillRectangle(lgb1,originX+  0 * X + barPoint_X, bar_margin_TopBottom1 +originY, X / 5, absValueHeight1);


	            //@-2
	            int nScaleHeight2 = (int)(scale2_Max - scale2_Min);
	            float smallInterval2 = Convert.ToSingle(barRealHeight2) / nScaleHeight2;

	            H2 = barRealHeight2 * (val2 - scale2_Min) / (scale2_Max - scale2_Min);
	            float absValueHeight2 = barRealHeight2 - H2;
	            //Draw current value
	            if (absValueHeight2 == 0) absValueHeight2 = 1f;
				
				RectangleF gradientRect2 = new RectangleF(originX+ 1 * X + barPoint_X, bar_margin_TopBottom2 +originY, X / 5, absValueHeight2);				
				LinearGradientBrush lgb2 = 
					new LinearGradientBrush(
						Colors.LightGray, 
						Colors.Gray, 
						new System.Windows.Point(gradientRect2.TopLeft.X, gradientRect2.TopLeft.Y),
						new System.Windows.Point(gradientRect2.BottomRight.X,gradientRect2.BottomRight.Y));
				
	            graphics.FillRectangle(lgb2, originX+ 1 * X + barPoint_X, bar_margin_TopBottom2 +originY, X / 5, absValueHeight2);

	            //@-3            
	            int nScaleHeight3 = (int)(scale3_Max - scale3_Min);
	            float smallInterval3 = Convert.ToSingle(barRealHeight3) / nScaleHeight3;

	            H3 = barRealHeight3 * (val3 - scale3_Min) / (scale3_Max - scale3_Min);
	            float absValueHeight3 = barRealHeight3 - H3;
	            //Draw current value
	            if (absValueHeight3 == 0) absValueHeight3 = 1f;
				
				RectangleF gradientRect3 = new RectangleF(originX+ 2 * X + barPoint_X, bar_margin_TopBottom3 +originY, X / 5, absValueHeight3);				
				LinearGradientBrush lgb3 = 
					new LinearGradientBrush(
						Colors.LightGray, 
						Colors.Gray, 
						new System.Windows.Point(gradientRect3.TopLeft.X, gradientRect3.TopLeft.Y),
						new System.Windows.Point(gradientRect3.BottomRight.X,gradientRect3.BottomRight.Y));
				
	            graphics.FillRectangle(lgb3, originX+ 2 * X + barPoint_X, bar_margin_TopBottom3 +originY, X / 5, absValueHeight3);	          
	             
	            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	            //@-1
	            int tempNum1 = (int)scale1_Max;            
	            for (int i = 0; i <= nScaleHeight1; i++)
	            {
	                float d = bigScale1 / smallScale;
	                if (tempNum1 % d == 0)
	                {
	                    float s_s_y = bar_margin_TopBottom1 + i * smallInterval1 +originY;
	                    graphics.DrawLine(s_p, originX+ 0 * X + barPoint_X + X / 15, s_s_y, originX+ 0 * X + barPoint_X + 2 * X / 15, s_s_y);

	                    if (tempNum1 % bigScale1 == 0)
	                    {                        
	                        graphics.DrawLine(p, originX+ 0 * X + barPoint_X, s_s_y, originX+ 0 * X + barPoint_X + X / 5, s_s_y); // ??? ????????? ?????????  
	                        
							NT7MeasureStringData szTxt = graphics.MeasureString(tempNum1.ToString(), drawFont);
	                        DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, tempNum1.ToString(), (int)(originX+ 0 * X + barPoint_X - 3 * X / 12), (int)(s_s_y + szTxt.Width / 2), drawFont, drawColor);
	                    }
	                }
	                tempNum1 -= 1;    // Scale Number
	            }

	            //@-2
	            int tempNum2 = (int)scale2_Max;
	            for (int i = 0; i <= nScaleHeight2; i++)
	            {
	                float d = bigScale2 / smallScale;
	                if (tempNum2 % d == 0)
	                {
	                    float s_s_y = bar_margin_TopBottom2 + i * smallInterval2 +originY;
	                    graphics.DrawLine(s_p, originX+ 1 * X + barPoint_X + X / 15, s_s_y, originX+ 1 * X + barPoint_X + 2 * X / 15, s_s_y);

	                    if (tempNum2 % bigScale2 == 0)
	                    {
	                        graphics.DrawLine(p, originX+ 1 * X + barPoint_X, s_s_y, originX+ 1 * X + barPoint_X + X / 5, s_s_y); // ??? ????????? ?????????  

							NT7MeasureStringData szTxt = graphics.MeasureString(tempNum2.ToString(), drawFont);							
	                        DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, tempNum2.ToString(), (int)(originX+ 1 * X + barPoint_X - 3 * X / 12), (int)(s_s_y + szTxt.Width / 2), drawFont, drawColor);
	                    }
	                }
	                tempNum2 -= 1;    // Scale Number
	            }

	            //@-3
	            int tempNum3 = (int)scale3_Max;
	            for (int i = 0; i <= nScaleHeight3; i++)
	            {
	                float d = bigScale3 / smallScale;
	                if (tempNum3 % d == 0)
	                {
	                    float s_s_y = bar_margin_TopBottom3 + i * smallInterval3 +originY;
	                    graphics.DrawLine(s_p, originX+ 2 * X + barPoint_X + X / 15, s_s_y, originX+ 2 * X + barPoint_X + 2 * X / 15, s_s_y);

	                    if (tempNum3 % bigScale3 == 0)
	                    {
	                        graphics.DrawLine(p, originX+ 2 * X + barPoint_X, s_s_y, originX+ 2 * X + barPoint_X + X / 5, s_s_y); // ??? ????????? ?????????  

							NT7MeasureStringData szTxt = graphics.MeasureString(tempNum3.ToString(), drawFont);
							
	                        DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, tempNum3.ToString(), (int)(originX+ 2 * X + barPoint_X - 3 * X / 12), (int)(s_s_y + szTxt.Width / 2), drawFont, drawColor);
	                    }
	                }
	                tempNum3 -= 1;    // Scale Number
	            }


	            //Draw Title
	            //@-1            
	            NT7MeasureStringData szTitle1 = graphics.MeasureString(titleBar1.ToString(), titleFontBar1);
	            DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, titleBar1.ToString(), (int)(originX+ 0 * X + barPoint_X + titlePtXBar1 - 1), (int)(Y/2 + titlePtYBar1 + szTitle1.Width / 2 +originY), titleFontBar1, titleColor);
	            //@-2
	            NT7MeasureStringData szTitle2 = graphics.MeasureString(titleBar2.ToString(), titleFontBar2);
	            DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, titleBar2.ToString(), (int)(originX+ 1 * X + barPoint_X + titlePtXBar2 - 1), (int)(Y / 2 + titlePtYBar2 + szTitle2.Width / 2 +originY), titleFontBar2, titleColor);
	            //@-3
	            NT7MeasureStringData szTitle3 = graphics.MeasureString(titleBar3.ToString(), titleFontBar3);
	            DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, titleBar3.ToString(), (int)(originX+ 2 * X + barPoint_X + titlePtXBar3 - 1), (int)(Y / 2 + titlePtYBar3 + szTitle3.Width / 2 +originY), titleFontBar3, titleColor);
	            
	            //Draw Polygon

	            //@-1
	            System.Windows.Point[] pt1 = new System.Windows.Point[] {
	                new System.Windows.Point((int)(originX+ 0 * X + barPoint_X + X / 10), (int)(bar_margin_TopBottom1 + absValueHeight1 +originY)),
	                new System.Windows.Point((int)(originX+ 0 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom1 + absValueHeight1 - X / 15 +originY)),
	                new System.Windows.Point((int)(originX+ 0 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom1 + absValueHeight1 + X / 15 +originY)) };
	            graphics.FillPolygon(Brushes.Crimson, pt1);
	            //@-2
	            System.Windows.Point[] pt2 = new System.Windows.Point[] {
	                new System.Windows.Point((int)(originX+ 1 * X + barPoint_X + X / 10), (int)(bar_margin_TopBottom2 + absValueHeight2 +originY)),
	                new System.Windows.Point((int)(originX+ 1 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom2 + absValueHeight2 - X / 15 +originY)),
	                new System.Windows.Point((int)(originX+ 1 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom2 + absValueHeight2 + X / 15 +originY)) };
	            graphics.FillPolygon(Brushes.Crimson, pt2);
	            //@-3
	            System.Windows.Point[] pt3 = new System.Windows.Point[] {
	                new System.Windows.Point((int)(originX+ 2 * X + barPoint_X + X / 10), (int)(bar_margin_TopBottom3 + absValueHeight3 +originY)),
	                new System.Windows.Point((int)(originX+ 2 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom3 + absValueHeight3 - X / 15 +originY)),
	                new System.Windows.Point((int)(originX+ 2 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom3 + absValueHeight3 + X / 15 +originY)) };
	            graphics.FillPolygon(Brushes.Crimson, pt3);
	        }
				
			private double DegreeToRadian(double angle)
			{
				return Math.PI * angle / 180.0;
			}
			
			private double RadianToDegree(double angle)
			{
				return angle * (180.0 / Math.PI);
			}			

	       
	    }		
		#endregion

        private const string VERSION = "v1.4 10.Sep.2021";
        private const string productName = "ARC_Barometer";
		//1.4:  Fixed memory leak by commenting out a .Freeze() within ThermometerControl_Paint()
		//		Also added originX, originY controls to move the location of the gauge

        public override string DisplayName {	get{return productName;}	}

        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		#region RegBarVisualInputs
		
		private SimpleFont iBarFont = new SimpleFont("Arial Black", 11){ Size = 11, Bold = true };

		private ARC_Barometer_Locations iGraphicLocation = ARC_Barometer_Locations.TopLeft;
        [Display(Name = "Graphics Location", Description = "", GroupName = "Parameters")]       
		public ARC_Barometer_Locations GraphicLocation 
		{
            get { return iGraphicLocation; }
            set { iGraphicLocation = value; }
        }

		private Brush iBarTextColor = Brushes.White;
		[XmlIgnore()]
        [Display(Name = "01. Bar Text Color", Description = "", GroupName = "01. Bar Visual Parameters")]       
		public Brush BarTextColor
        {
            get { return iBarTextColor; }
            set { iBarTextColor = value; }
        }
					[Browsable(false)]
					public string BarTextColorSerialize
					{
						get { return Serialize.BrushToString(iBarTextColor); }
						set { iBarTextColor = Serialize.StringToBrush(value); }
					}

		#endregion

		#region RegGaugeVisualInputs
		
		private SimpleFont iTextFontGauge = new SimpleFont("Arial Black", 14){ Size = 14, Bold = true };	
		
//		[XmlIgnore]
//		[Description("Font Selection")]
//		[GridCategory("01. Gauge Visual Parameters")]
//		[Gui.Design.DisplayName("01. Font")]
//		public Font TextFont
//		{
//			get { return iTextFont; }
//			set { iTextFont = value; }
//		}		
//		[Browsable(false)]
//        public string TextFontSerialize
//        {
//            get { return Gui.Design.SerializableFont.ToString(iTextFont); }
//            set { iTextFont = Gui.Design.SerializableFont.FromString(value); }
//        }	

		private Brush iBackgroundColor = Brushes.Black;
		[XmlIgnore()]
        [Display(Name = "00. Behind Color", Description = "", GroupName = "02. Gauge Visual Parameters")]       
		public Brush BackgroundColor
        {
            get { return iBackgroundColor; }
            set { iBackgroundColor = value; }
        }
		private float iBackgroundOpacity = 90f;
		[XmlIgnore()]
        [Display(Name = "00. Behind Opacity", Description = "", GroupName = "02. Gauge Visual Parameters")]       
		public float BackgroundOpacity
        {
            get { return iBackgroundOpacity; }
            set { iBackgroundOpacity = Math.Max(0f,Math.Min(100f,value)); }
        }
		[Browsable(false)]
		public string BackgroundColorSerialize
		{
			get { return Serialize.BrushToString(iBackgroundColor); }
			set { iBackgroundColor = Serialize.StringToBrush(value); }
		}		
		private Brush iGaugeTextColor = Brushes.White;
		[XmlIgnore()]
        [Display(Name = "01. Gauge Text Color", Description = "", GroupName = "02. Gauge Visual Parameters")]       
		public Brush GaugeTextColor
        {
            get { return iGaugeTextColor; }
            set { iGaugeTextColor = value; }
        }
					[Browsable(false)]
					public string GaugeTextColorSerialize
					{
						get { return Serialize.BrushToString(iGaugeTextColor); }
						set { iGaugeTextColor = Serialize.StringToBrush(value); }
					}		
		private int iGaugeNeedleWidth = 2;
        [Display(Name = "02a. Gauge Needle Width", Description = "", GroupName = "02. Gauge Visual Parameters")]        
		public int GaugeNeedleWidth
        {
            get { return iGaugeNeedleWidth; }
            set { iGaugeNeedleWidth = value; }
        }	
		private Brush iGaugeLongSentimentNeedleColor = Brushes.Navy;
		[XmlIgnore()]
        [Display(Name = "02b. Long Term Needle Color", Description = "", GroupName = "02. Gauge Visual Parameters")]        
		public Brush GaugeLongSentimentNeedleColor
        {
            get { return iGaugeLongSentimentNeedleColor; }
            set { iGaugeLongSentimentNeedleColor = value; }
        }
					[Browsable(false)]
					public string GaugeLongSentimentNeedleColorSerialize
					{
						get { return Serialize.BrushToString(iGaugeLongSentimentNeedleColor); }
						set { iGaugeLongSentimentNeedleColor = Serialize.StringToBrush(value); }
					}		
		private Brush iGaugeMediumSentimentNeedleColor = Brushes.Black;
		[XmlIgnore()]
        [Display(Name = "02c. Medium Term Needle Color", Description = "", GroupName = "02. Gauge Visual Parameters")]        
		public Brush GaugeMediumSentimentNeedleColor
        {
            get { return iGaugeMediumSentimentNeedleColor; }
            set { iGaugeMediumSentimentNeedleColor = value; }
        }
					[Browsable(false)]
					public string GaugeMediumSentimentNeedleColorSerialize
					{
						get { return Serialize.BrushToString(iGaugeMediumSentimentNeedleColor); }
						set { iGaugeMediumSentimentNeedleColor = Serialize.StringToBrush(value); }
					}
		private Brush iGaugeShortSentimentNeedleColor = Brushes.Maroon;
		[XmlIgnore()]
        [Display(Name = "02d. Short Term Needle Color", Description = "", GroupName = "02. Gauge Visual Parameters")]        
		public Brush GaugeShortSentimentNeedleColor
        {
            get { return iGaugeShortSentimentNeedleColor; }
            set { iGaugeShortSentimentNeedleColor = value; }
        }
					[Browsable(false)]
					public string GaugeShortSentimentNeedleColorSerialize
					{
						get { return Serialize.BrushToString(iGaugeShortSentimentNeedleColor); }
						set { iGaugeShortSentimentNeedleColor = Serialize.StringToBrush(value); }
					}		

		#endregion

		#region RegSensitivity
		
		private int iTrendPeriodS = 13;
        [NinjaScriptProperty]        [Display(Name = "01. Short Trend Period", Description = "", GroupName = "03. Trend Sentiment Control")]        
		public int TrendPeriodS
        {
            get { return iTrendPeriodS; }
            set { iTrendPeriodS = Math.Max(6, value); }
        }
		private int iTrendPeriodM = 21;
        [NinjaScriptProperty]        [Display(Name = "02. Mid Trend Period", Description = "", GroupName = "03. Trend Sentiment Control")]        
		public int TrendPeriodM
        {
            get { return iTrendPeriodM; }
            set { iTrendPeriodM = Math.Max(7, value); }
        }		
		private int iTrendPeriodL = 34;
        [NinjaScriptProperty]        [Display(Name = "03. Long Trend Period", Description = "", GroupName = "03. Trend Sentiment Control")]       
		public int TrendPeriodL
        {
            get { return iTrendPeriodL; }
            set { iTrendPeriodL = Math.Max(8, value); }
        }	
		private int iRangeVolatilitySensitivity = 1;
        [NinjaScriptProperty]        [Display(Name = "04. Range / Volatility Sensitivity", Description = "", GroupName = "03. Trend Sentiment Control")]       
		public int RangeVolatilitySensitivity
        {
            get { return iRangeVolatilitySensitivity; }
            set { iRangeVolatilitySensitivity = Math.Max(1, value); }
        }	
		
		#endregion

		#region RegAudio

//		private bool iEnableSoundAlert = false;
//		[Display(Name = "01. Enable", Description = "", GroupName = "04. Audio / Alert")]       
//		public bool EnableSoundAlert
//        {
//            get { return iEnableSoundAlert; }
//            set { iEnableSoundAlert = value; }
//        }	
		private string iSoundAlert = "SOUND OFF"; 
		[TypeConverter(typeof(LoadSoundFileList))]
		[Display(Name = "02. Sound File", Description = "", GroupName = "04. Audio / Alert")]       
		public string SoundAlert
        {
            get { return iSoundAlert; }
            set { iSoundAlert = value; }
        }		
		private int iVolatilityThreshold = 20; 
		[Display(Name = "03a. Volatility Threshold", Description = "Volatility must be below this value to trigger alert", GroupName = "04. Audio / Alert")]       
		public int VolatilityThreshold
        {
            get { return iVolatilityThreshold; }
            set { iVolatilityThreshold = value; }
        }		
		private int iRangeThreshold = 20; 
		[Display(Name = "03b. Range Threshold", Description = "Range must be below this value to trigger alert", GroupName = "04. Audio / Alert")]       
		public int RangeThreshold
        {
            get { return iRangeThreshold; }
            set { iRangeThreshold = value; }
        }	
		private int iVolumeThreshold = 80; 
		[Display(Name = "03c. Volume Threshold", Description = "Volume must be above this value to trigger alert", GroupName = "04. Audio / Alert")]       
		public int VolumeThreshold
        {
            get { return iVolumeThreshold; }
            set { iVolumeThreshold = value; }
        }					
		
		#endregion

		private ARC_BarometerSupportRange indRange;
		private ARC_BarometerSupportTrend indTrendS, indTrendM, indTrendL;
		private ARC_BarometerSupportVolume indVolume;		
		private ARC_BarometerSupportVolatility indVolatility;		

		private ClassGauge CG = null;
		private ClassThermometerBar CT = null;		

		private bool bGraphicsInitialized;

		private Brush backBrush;
		private Stroke	backPen;

		private Series<double> sExtrnRange, sExtrnVolume, sExtrnVolatility;
		private Series<double> sExtrnTrendS, sExtrnTrendM, sExtrnTrendL;					

		private int idTag;			
		private bool bCanAlertTrigger;

	#region RegInitialize

	protected override void OnStateChange()
	{
		switch (State)
		{
			case State.SetDefaults:
				Name = "ARC_Barometer";

				IsOverlay = true;
				this.Calculate = Calculate.OnEachTick;            
				this.ArePlotsConfigurable = false;
				this.Name = productName;//string.Format("{0} {1} ", productName, productVersion);

				break;

			case State.Configure:
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion

				this.idTag = int.MinValue;
				this.bGraphicsInitialized = false;
					
				this.indTrendS = ARC_BarometerSupportTrend(BarsArray[0], this.iTrendPeriodS);
				this.indTrendS.MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				this.indTrendS.key = 102812655;
				this.indTrendS.iFindAdjustFactor = 50;
				this.indTrendM = ARC_BarometerSupportTrend(BarsArray[0], this.iTrendPeriodM);
				this.indTrendM.MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				this.indTrendM.key = 102812655;
				this.indTrendM.iFindAdjustFactor = 1;
				this.indTrendL = ARC_BarometerSupportTrend(BarsArray[0], this.iTrendPeriodL);
				this.indTrendL.MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				this.indTrendL.key = 102812655;
				this.indTrendL.iFindAdjustFactor = 1;

				ARC_Barometer_BinTimeScalar bts = ARC_Barometer_BinTimeScalar.MINUTES;
				if(BarsArray[0].BarsType.BuiltFrom == BarsPeriodType.Tick)
					bts = ARC_Barometer_BinTimeScalar.SECONDS;
					
				this.indRange = ARC_BarometerSupportRange(bts);
				this.indRange.MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				this.indRange.key = 102812655;			
				this.indRange.iAveragePeriod = this.iRangeVolatilitySensitivity;

				this.indVolume = ARC_BarometerSupportVolume(bts);
				this.indVolume.MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				this.indVolume.key = 102812655;
					
				this.indVolatility = ARC_BarometerSupportVolatility(bts);
				this.indVolatility.MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				this.indVolatility.iAveragePeriod = this.iRangeVolatilitySensitivity;
				this.indVolatility.key = 102812655;						
				break;

			case State.DataLoaded:
				this.backBrush	= this.iBackgroundColor.Clone();
				this.backBrush.Opacity = iBackgroundOpacity / 100f;
				this.backBrush.Freeze();
				this.backPen = new Stroke(this.iBackgroundColor);			
									                   
				this.sExtrnRange = new Series<double>(this, MaximumBarsLookBack.Infinite);
				this.sExtrnVolume = new Series<double>(this, MaximumBarsLookBack.Infinite);
				this.sExtrnVolatility = new Series<double>(this, MaximumBarsLookBack.Infinite);
					
				this.sExtrnTrendS = new Series<double>(this, MaximumBarsLookBack.Infinite);
				this.sExtrnTrendM = new Series<double>(this, MaximumBarsLookBack.Infinite);
				this.sExtrnTrendL = new Series<double>(this, MaximumBarsLookBack.Infinite);
				break;

			case State.Terminated:
				OnTermination();
				break;
		}
	}


	#endregion

        protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			this.sExtrnTrendS[0] = -this.indTrendS.ForecastValue[0];
			this.sExtrnTrendM[0] = -this.indTrendM.ForecastValue[0];
			this.sExtrnTrendL[0] = -this.indTrendL.ForecastValue[0];

			if(CurrentBars[0] < 5)
				return;
			
			if(this.IsFirstTickOfBar)
				this.bCanAlertTrigger = true;
			
			this.sExtrnRange[0] = this.ComputePercent(this.indRange.ForecastValue[0], this.indRange.CurrentValue[0]);				
			this.sExtrnVolume[0] = this.ComputePercent(this.indVolume.ForecastValue[0], this.indVolume.CurrentValue[0]);
			this.sExtrnVolatility[0] = this.ComputePercent(this.indVolatility.ForecastValue[0], this.indVolatility.CurrentValue[0]);			
			if(
				this.sExtrnRange[0] <= this.iRangeThreshold
				&& this.sExtrnVolatility[0] <= this.iVolatilityThreshold
				&& this.sExtrnVolume[0] >= this.iVolumeThreshold
				){
					if(CurrentBar!=AudibleAlertBar)
						this.SignalAlert();
					AudibleAlertBar = CurrentBar;
					if(IsDebug) BackBrushes[0] = Brushes.Yellow;
				}
        } 

		private void SetGraphic(int iOffset)
		{
			if(CG == null || CT == null)// || iOffset >= CurrentBars[0] - 1)
				return;							

			try
			{
				double range      = sExtrnRange.GetValueAt(iOffset);
				double volume     = sExtrnVolume.GetValueAt(iOffset);
				double volatility = sExtrnVolatility.GetValueAt(iOffset);
				
				double trendS = sExtrnTrendS.GetValueAt(iOffset);
				double trendM = sExtrnTrendM.GetValueAt(iOffset);
				double trendL = sExtrnTrendL.GetValueAt(iOffset);		

				// Protect against invalid seed values until the data is correct.
				if(
					!IsFinite(range)	
					|| !IsFinite(volume)	
					|| !IsFinite(volatility)	
					|| !IsFinite(trendS)	
					|| !IsFinite(trendM)	
					|| !IsFinite(trendL)
					)
					return;

				CG.Value3 = Convert.ToSingle(trendS);
				CG.Value2 = Convert.ToSingle(trendM);
				CG.Value1 = Convert.ToSingle(trendL);

				// Forecasted Volume
				CT.Value1 = Convert.ToSingle(volume);
				// Forecasted Volatility
				CT.Value2 = Convert.ToSingle(volatility);
				// Forecasted Range
				CT.Value3 = Convert.ToSingle(range);	
			}
			catch(Exception e)
			{
				Print(e.Message);
				Log("NS Barometer - SetGraphic Exception = " + e.ToString(), NinjaTrader.Cbi.LogLevel.Error);
			}			
		}
		
        private bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value) && value < double.MaxValue;
        }

		#region RegAlerts
		
		private void SignalAlert()
		{
			if(!this.bCanAlertTrigger)
				return;
			
			if(this.iSoundAlert != "SOUND OFF")// && this.iEnableSoundAlert)
				this.PlaySound(AddSoundFolder(iSoundAlert));				
			this.idTag++;			
		}
		//======================================================================================================
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
		#endregion
		#region RegNormalizing
		
		private float ComputePercent(double iForecast, double iCurrent)
		{
			if(iForecast == 0)
			{
				//Log("NS Barometer - ComputePercent Exception = Div/0; Call " + iCall.ToString(), NinjaTrader.Cbi.LogLevel.Error);
				return 0;
			}
			
			if(iCurrent > iForecast)
				return Convert.ToSingle(100.0 * (iCurrent / iForecast));
						
			return Math.Min(100, Convert.ToSingle(100.0 * (1.0 - (Math.Abs(iForecast - iCurrent) / iForecast))));
		}
		
		#endregion

		#region RegGraphics
		
		#region RegNT7toNT8Class
		
		internal class NT7MeasureStringData
		{
			public float Height;
			public float Width;
			
			public NT7MeasureStringData()
			{
				
			}
		}
			
		internal class NT7Graphics
		{
			SharpDX.Direct2D1.RenderTarget rt;
		
			public NT7Graphics(SharpDX.Direct2D1.RenderTarget rt)
			{
				this.rt = rt;
			}
			
			public void DrawEllipse(Stroke s, RectangleF rect)
			{
				this.DrawEllipse(s, rect.X, rect.Y, rect.Width, rect.Height);
			}
			
			public void DrawEllipse(Stroke s, float x, float y, float w, float h)
			{
				float half = w / 2;
				float x0 = Convert.ToSingle (x + half - 1);
				float y0 = Convert.ToSingle (y + half - 1);
				SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
				SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f); 
				var brush = s.Brush.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawEllipse(ellipse, brush,s.Width);
				brush.Dispose();brush=null;
			}
			
			public void FillEllipse(Brush b, RectangleF rect)
			{
				this.FillEllipse(b, rect.X, rect.Y, rect.Width, rect.Height);
			}
			
			public void FillEllipse(Brush b, float x, float y, float w, float h)
			{
				float half = w / 2;
				float x0 = Convert.ToSingle (x + half - 1);
				float y0 = Convert.ToSingle (y + half - 1);
				SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
				SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f); 
				var brush = b.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.FillEllipse(ellipse, brush);
				brush.Dispose();brush=null;
			}
			
			public void DrawRectangle(Stroke s, RectangleF rect)
			{
				this.DrawRectangle(s,rect.X, rect.Y, rect.Width, rect.Height);
			}
			
			public void DrawRectangle(Stroke s, float x, float y, float w, float h)
			{
				SharpDX.RectangleF rectf = new SharpDX.RectangleF(x, y, w, h);
				var brush = s.Brush.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawRectangle(rectf, brush,s.Width);
				brush.Dispose();brush=null;
			}
			
			public void FillRectangle(Brush b, RectangleF rect)
			{
				this.FillRectangle(b,rect.X, rect.Y, rect.Width, rect.Height);
			}
			
			public void FillRectangle(Brush b, float x, float y, float w, float h)
			{
				SharpDX.RectangleF rectf = new SharpDX.RectangleF(x, y, w, h);
				var brush = b.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.FillRectangle(rectf, brush);
				brush.Dispose();brush=null;
			}
			
			public void DrawLine(Stroke s, float x1, float y1, float x2, float y2)
			{
				System.Windows.Point startPoint	= new System.Windows.Point(x1, y1);
				System.Windows.Point endPoint		= new System.Windows.Point(x2, y2);
				var brush = s.Brush.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawLine(startPoint.ToVector2(), endPoint.ToVector2(), brush, s.Width, s.StrokeStyle);
				brush.Dispose();brush=null;
			}
			
			public void DrawString(String text, SimpleFont f, Brush b, RectangleF rect, SharpDX.DirectWrite.TextAlignment ta)
			{
				this.DrawString(text, f, b, rect.X, rect.Y, rect.Width, rect.Height, ta);
			}
			
			public void DrawString(String text, SimpleFont f, Brush b, RectangleF rect)
			{
				this.DrawString(text, f, b, rect.X, rect.Y);
			}
			
			public void DrawString(String text, SimpleFont f, Brush b, float x, float y)
			{
				this.DrawString(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading);
			}
			
			public void DrawString(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta)
			{
				TextFormat textFormat		= 
					new TextFormat(
						Core.Globals.DirectWriteFactory, 
						f.Family.ToString(), 
						(f.Bold?SharpDX.DirectWrite.FontWeight.Bold:SharpDX.DirectWrite.FontWeight.Normal),
						SharpDX.DirectWrite.FontStyle.Normal, 
						SharpDX.DirectWrite.FontStretch.Normal, 
						Convert.ToSingle(f.Size)) 
						{ 
							TextAlignment = ta, 
							WordWrapping = WordWrapping.NoWrap 
						};
												
				TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,w,h);//(float)f.Size);
				
				System.Windows.Point upperTextPoint	= new System.Windows.Point(x,y);
				var brush = b.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
				brush.Dispose();brush=null;
			}
			
			public NT7MeasureStringData MeasureString( String text, SimpleFont f)
			{
				NT7MeasureStringData sd = new NT7MeasureStringData();
				
				TextFormat textFormat		= new TextFormat(Core.Globals.DirectWriteFactory, f.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal,
												SharpDX.DirectWrite.FontStyle.Normal, SharpDX.DirectWrite.FontStretch.Normal, Convert.ToSingle(f.Size)) 
												{ TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading, WordWrapping = WordWrapping.NoWrap };
												
				TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,400,Convert.ToSingle(f.Size));
				
												
				sd.Height = Convert.ToSingle( textLayout.Metrics.Height);
				sd.Width = Convert.ToSingle( textLayout.Metrics.Width);
												
				return sd;
			}
			
			public void FillPolygon(Brush b, System.Windows.Point[] p)
			{
				SharpDX.Direct2D1.PathGeometry	g		= null;
				SharpDX.Direct2D1.GeometrySink	sink	= null;
				
				if (sink == null)
				{
					g			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					sink		= g.Open();
					
				}
				
				sink.BeginFigure(new SharpDX.Vector2(Convert.ToSingle(p[0].X),Convert.ToSingle(p[0].Y)), SharpDX.Direct2D1.FigureBegin.Filled);
				for(int pidx = 1; pidx < p.Length; pidx++)
				{
					sink.AddLine(new SharpDX.Vector2(Convert.ToSingle(p[pidx].X), Convert.ToSingle(p[pidx].Y)));
				}
				sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
				sink.Close();
				
				if (g != null)
				{
					var brush = b.ToDxBrush(this.rt);
					if (brush == null) return;
					this.rt.FillGeometry(g,brush); 
					brush.Dispose();brush=null;
					
					g.Dispose();
					sink.Dispose();
					g = null;
					sink = null;
				}
			}
			
			public void DrawPolygon(Stroke s, System.Windows.Point[] p)
			{
				SharpDX.Direct2D1.PathGeometry	g		= null;
				SharpDX.Direct2D1.GeometrySink	sink	= null;
				
				if (sink == null)
				{
					g			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					sink		= g.Open();
					
				}
				
				sink.BeginFigure(new SharpDX.Vector2(Convert.ToSingle(p[0].X),Convert.ToSingle(p[0].Y)), SharpDX.Direct2D1.FigureBegin.Filled);
				for(int pidx = 1; pidx < p.Length; pidx++)
				{
					sink.AddLine(new SharpDX.Vector2(Convert.ToSingle(p[pidx].X), Convert.ToSingle(p[pidx].Y)));
				}
				sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
				sink.Close();
				
				if (g != null)
				{
					var brush = s.Brush.ToDxBrush(this.rt);
					if (brush == null) return;
					this.rt.DrawGeometry(g,brush); 
					brush.Dispose();brush=null;
					
					g.Dispose();
					sink.Dispose();
					g = null;
					sink = null;
				}
			}
		}
		
		#endregion
		
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }

        public override void OnRenderTargetChanged()
        {
            base.OnRenderTargetChanged();
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			if (Bars == null || chartControl == null)
                return;
			
			if(ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1)
				return;
			
			if(!IsOverlay)
				IsOverlay = true;

//			try
//			{

				base.OnRender(chartControl, chartScale);

				if (RenderTarget == null)
				{
					return;
				}
				NT7Graphics graphics = new NT7Graphics(RenderTarget);
				float ratio = 0.6f;
				float w = (675 * ratio);
				float h = (430 * ratio);

				SharpDX.Direct2D1.AntialiasMode originalMode = RenderTarget.AntialiasMode;
				RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
				float originX = 0f;
				float originY = 0f;
				if(iGraphicLocation == ARC_Barometer_Locations.TopLeft){
					originX = 10f;
					originY = 10f;
				}else if(iGraphicLocation == ARC_Barometer_Locations.TopRight){
					originX = ChartPanel.W - 388;
					originY = 10f;
				}else if(iGraphicLocation == ARC_Barometer_Locations.Center){
					originX = (ChartPanel.W - 388)/2f;
					originY = (ChartPanel.H - 252)/2f;
				}else if(iGraphicLocation == ARC_Barometer_Locations.BottomLeft){
					originX = 10f;
					originY = ChartPanel.H - 252;
				}else if(iGraphicLocation == ARC_Barometer_Locations.BottomRight){
					originX = ChartPanel.W - 388;
					originY = ChartPanel.H - 252;
				}

				RectangleF bounds = new RectangleF(ChartPanel.X, ChartPanel.Y, ChartPanel.W, ChartPanel.H);

				// Initial Draw and Setup
				if (!this.bGraphicsInitialized)
				{
					this.bGraphicsInitialized = true;
					this.DrawGraphics(new SharpDX.RectangleF(originX, bounds.Top +originY, (int)w, (int)h));
				}

				graphics.FillRectangle(backBrush, originX, bounds.Top +originY, 388, 252);
				graphics.DrawRectangle(backPen, originX, bounds.Top +originY, 388, 252);

				this.SetGraphic(Math.Max(0, Math.Min(CurrentBars[0] - 1, chartControl.LastSlotPainted)));

				this.CT.ThermometerControl_Paint(RenderTarget, originX, originY, this);
				this.CG.InitDxBrushes(RenderTarget);
				this.CG.GaugeControl_Paint(RenderTarget, originX, originY);

				RenderTarget.AntialiasMode = originalMode;
//			} catch(Exception ex){
//				Log("Exception Happened in OnRender: " + ex.Message + "\n" + ex.StackTrace, Cbi.LogLevel.Error);
//			}
		}

// ////////////////////////////////////////////////////////////////
        public void DrawGraphics(SharpDX.RectangleF iDrawBox)
        {
            int nBar_X = (int)iDrawBox.X;
            int nBar_Y = (int)iDrawBox.Y;
            int mBar_Width  = (int)iDrawBox.Width - (int)iDrawBox.Height;
            int mBar_Height = (int)iDrawBox.Height;

            SharpDX.RectangleF mBar_rect = new SharpDX.RectangleF(nBar_X, nBar_Y, mBar_Width / 3, mBar_Height);
            PlotBars(mBar_rect);					

            int nCircle_Padding_Top = 10;
            int nCircle_Padding_Right = 10;
            int nCircle_Padding_Bottom = 10;
            int nCircle_Padding_Left = 10;

            int nCircle_X = mBar_Width;
            int nCircle_Y = 0;
            int mCircle_Width = (int)iDrawBox.Height;
            int mCircle_Height = (int)iDrawBox.Height;

            nCircle_X += nCircle_Padding_Left;
            nCircle_Y += nCircle_Padding_Top;
            mCircle_Width -= (nCircle_Padding_Right + nCircle_Padding_Left);
            mCircle_Height -= (nCircle_Padding_Top + nCircle_Padding_Bottom);

            SharpDX.RectangleF mCircle_rect = new SharpDX.RectangleF(nCircle_X, nCircle_Y, mCircle_Width, mCircle_Height);
            PlotGauge(mCircle_rect);
        }

        private void PlotGauge(SharpDX.RectangleF iBounds)
        {
            this.CG = new ClassGauge(iBounds.X, iBounds.Y, iBounds.Height, iBounds.Width);            
			
			this.CG.NeedleWidth  = this.iGaugeNeedleWidth;
			this.CG.NeedleBrush1 = this.iGaugeLongSentimentNeedleColor;
			this.CG.NeedleBrush2 = this.iGaugeMediumSentimentNeedleColor;
			this.CG.NeedleBrush3 = this.iGaugeShortSentimentNeedleColor;
			this.CG.MyFont     = this.iTextFontGauge;
            this.CG.TitleBrush = this.iGaugeTextColor;
			this.CG.ScaleNumbersBrush = this.iGaugeTextColor;			
            this.CG.InitTitle_Gauge("Direction", this.iTextFontGauge, 5, 0);						
        }

        private void PlotBars(SharpDX.RectangleF iBounds)
        {
            this.CT = new ClassThermometerBar(iBounds.Height, iBounds.Width);            

            this.CT.TitleColor = this.iBarTextColor;
			this.CT.DrawColor = this.iBarTextColor;

            this.CT.InitTitle_Bar1("Volume", this.iBarFont, 12, 90);
            this.CT.InitBaseVal_Bar1(0, 200, 20, 20);

            this.CT.InitTitle_Bar2("Volatility", this.iBarFont, 12, 86);
            this.CT.InitBaseVal_Bar2(0, 100, 20, 10);

            this.CT.InitTitle_Bar3("Range", this.iBarFont, 12, 92);
            this.CT.InitBaseVal_Bar3(0, 100, 20, 10);  			
        }		

		
		#endregion
		
		#region RegBloodHoundInterface
		
		[Browsable(false)]    
        [XmlIgnore()]     		
		public Series<double> BH_RangeForecast
		{
			get 
			{
				return sExtrnRange;
			}
		}
		[Browsable(false)]    
        [XmlIgnore()]     		
		public Series<double> BH_VolumeForecast
		{
			get 
			{
				return sExtrnVolume;
			}
		}
		[Browsable(false)]    
        [XmlIgnore()]     		
		public Series<double> BH_VolatilityForecast
		{
			get 
			{
				return sExtrnVolatility;
			}
		}	
		
		[Browsable(false)]    
        [XmlIgnore()]     		
		public Series<double> BH_TrendForecastShort
		{
			get 
			{
				return sExtrnTrendS;
			}
		}	
		[Browsable(false)]    
        [XmlIgnore()]     		
		public Series<double> BH_TrendForecastMedium
		{
			get 
			{
				return sExtrnTrendM;
			}
		}
		[Browsable(false)]    
        [XmlIgnore()]     		
		public Series<double> BH_TrendForecastLong
		{
			get 
			{
				return sExtrnTrendL;
			}
		}		
		
		#endregion	
		
		#region RegTermination
		private void OnTermination()
        {	
//			if (this.ChartControl != null)
//			{
//				if(this.CG != null)
//					this.ChartControl.ChartPanel.Paint -= CG.pictureBox_Paint;
//				if(this.CT != null)
//					this.ChartControl.ChartPanel.Paint -= CT.ThermometerControl_Paint;				
//			}	
      	}
		#endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_Barometer[] cacheARC_Barometer;
		public ARC.ARC_Barometer ARC_Barometer(int trendPeriodS, int trendPeriodM, int trendPeriodL, int rangeVolatilitySensitivity)
		{
			return ARC_Barometer(Input, trendPeriodS, trendPeriodM, trendPeriodL, rangeVolatilitySensitivity);
		}

		public ARC.ARC_Barometer ARC_Barometer(ISeries<double> input, int trendPeriodS, int trendPeriodM, int trendPeriodL, int rangeVolatilitySensitivity)
		{
			if (cacheARC_Barometer != null)
				for (int idx = 0; idx < cacheARC_Barometer.Length; idx++)
					if (cacheARC_Barometer[idx] != null && cacheARC_Barometer[idx].TrendPeriodS == trendPeriodS && cacheARC_Barometer[idx].TrendPeriodM == trendPeriodM && cacheARC_Barometer[idx].TrendPeriodL == trendPeriodL && cacheARC_Barometer[idx].RangeVolatilitySensitivity == rangeVolatilitySensitivity && cacheARC_Barometer[idx].EqualsInput(input))
						return cacheARC_Barometer[idx];
			return CacheIndicator<ARC.ARC_Barometer>(new ARC.ARC_Barometer(){ TrendPeriodS = trendPeriodS, TrendPeriodM = trendPeriodM, TrendPeriodL = trendPeriodL, RangeVolatilitySensitivity = rangeVolatilitySensitivity }, input, ref cacheARC_Barometer);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_Barometer ARC_Barometer(int trendPeriodS, int trendPeriodM, int trendPeriodL, int rangeVolatilitySensitivity)
		{
			return indicator.ARC_Barometer(Input, trendPeriodS, trendPeriodM, trendPeriodL, rangeVolatilitySensitivity);
		}

		public Indicators.ARC.ARC_Barometer ARC_Barometer(ISeries<double> input , int trendPeriodS, int trendPeriodM, int trendPeriodL, int rangeVolatilitySensitivity)
		{
			return indicator.ARC_Barometer(input, trendPeriodS, trendPeriodM, trendPeriodL, rangeVolatilitySensitivity);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_Barometer ARC_Barometer(int trendPeriodS, int trendPeriodM, int trendPeriodL, int rangeVolatilitySensitivity)
		{
			return indicator.ARC_Barometer(Input, trendPeriodS, trendPeriodM, trendPeriodL, rangeVolatilitySensitivity);
		}

		public Indicators.ARC.ARC_Barometer ARC_Barometer(ISeries<double> input , int trendPeriodS, int trendPeriodM, int trendPeriodL, int rangeVolatilitySensitivity)
		{
			return indicator.ARC_Barometer(input, trendPeriodS, trendPeriodM, trendPeriodL, rangeVolatilitySensitivity);
		}
	}
}

#endregion
