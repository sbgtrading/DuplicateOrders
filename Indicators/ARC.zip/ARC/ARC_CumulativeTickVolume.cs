#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public class ARC_CumulativeTickVolume : Indicator
	{
		private const int Transparent_ID = 0;
		private const int Ask_Greater_Bid_50_BrushId   = 1;
		private const int Ask_Greater_Bid_1549_BrushId = 2;
		private const int Ask_Greater_Bid_014_BrushId  = 3;
		private const int Bid_Greater_Ask_50_BrushId   = 4;
		private const int Bid_Greater_Ask_1549_BrushId = 5;
		private const int Bid_Greater_Ask_014_BrushId  = 6;

		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string    ModuleName = "TPOCTV";
		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "3556", "4690"};
		bool IsDebug = false;
		string indicatorVersion = "1.0";
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId,LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion


//        public override string DisplayName { get { return "ARC_CumulativeTickVolume"; } }

        #region Variables

        #region Enums
        public enum ARC_CumulativeTickMode
        {
            ChartCumulative,
            DailyCumulative,
            NonCumulative
        }

        public enum ARC_CumPlotMode
        {
            Histogram,
            Candlestick,
            OHLC,
            LineOnClose
        }
        #endregion

        private double footer_dist = 0;
        private	int	currentBar		=	0;
		private	int	prevCurrentBar	=	-2;
		
		private List<CummulativeFootPrint>			CummulativeFootPrintList;
		private SessionIterator 					sessionIterator;
		private	bool								FirstRun			=	true;
		private	bool								reset				=	false;
		private bool								drawWarning			=	true;
		private	Brush								upBarBrush			=	Brushes.LimeGreen;
		private	Brush								downBarBrush		=	Brushes.Crimson;
                Brush                               upDownBarBrush      =   Brushes.DarkGreen;
                Brush                               downUpBarBrush      =   Brushes.DarkRed;
        private	Brush								outlineBrush		=	Brushes.White;
		private	Brush								wickBrush			=	Brushes.White;
		private	Brush								zeroBrush			=	Brushes.Black;
		private	Brush								lineOnCloseBrush	=	Brushes.White;
		private	int									lineOnCloseWidth	=	2;
		private	Series<double>						vol;
		private	Brush								fastBrush			=	Brushes.DarkCyan;
		private	int									fastWidth			=	1;
		private	Brush								slowBrush			=	Brushes.Crimson;
		private	int									slowWidth			=	1;
		private	int									fastPeriod			=	9;
		private	int									slowPeriod			=	26;
		MarketDataEventArgs lastArgs;

		#endregion

		#region Properties

		#region Cummulative Tick Settings

		[Display(ResourceType = typeof(Resource), Name = "Cummulative Tick Mode", GroupName = "Cumulative Tick Settings", Order = 1)]
		public ARC_CumulativeTickMode cummulativeTickMode { get; set; }
		[Display(ResourceType = typeof(Resource), Name = "Plot Mode", GroupName = "Cumulative Tick Settings", Order = 2)]
		public ARC_CumPlotMode cumPlotMode { get; set; }
		[Display(ResourceType = typeof(Resource), Name = "Min lot", GroupName = "Cumulative Tick Settings", Order = 3)]
		public double cummulativeMinLot { get; set; }
		[Display(ResourceType = typeof(Resource), Name = "Max lot", GroupName = "Cumulative Tick Settings", Order = 4)]
		public double cummulativeMaxLot { get; set; }
		[Display(ResourceType = typeof(Resource), Name = "Fast MA Period", GroupName = "Cumulative Tick Settings", Order = 5)]
		public int	FastPeriod 
		{ 	
			get{return fastPeriod;} 
			set{fastPeriod	=	value;} 
		}
		[Display(ResourceType = typeof(Resource), Name = "Slow MA Period", GroupName = "Cumulative Tick Settings", Order = 6)]
		public int	SlowPeriod 
		{ 	
			get{return slowPeriod;} 
			set{slowPeriod	=	value;} 
		}

		#endregion

		#region Visuals
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Up,Up", GroupName = "Visual Parameters", Order = 1)]
		public Brush UpBarBrush 
		{ 	
			get{return upBarBrush;} 
			set{upBarBrush	=	value;} 
		}
		[Browsable(false)]
		public string UpBarBrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(upBarBrush); }
			set { upBarBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Up,Down", GroupName = "Visual Parameters", Order = 2)]
		public Brush UpDownBarBrush
		{
		    get { return upDownBarBrush; }
		    set { upDownBarBrush = value; }
		}
		[Browsable(false)]
		public string UpDownBarBrushSerialize
		{
		    get { return NinjaTrader.Gui.Serialize.BrushToString(upDownBarBrush); }
		    set { upDownBarBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Down,Down", GroupName = "Visual Parameters", Order = 3)]
		public Brush DownBarBrush 
		{ 	
			get{return downBarBrush;} 
			set{downBarBrush	=	value;} 
		}
		[Browsable(false)]
		public string DownBarBrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(downBarBrush); }
			set { downBarBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Down,Up", GroupName = "Visual Parameters", Order = 4)]
		public Brush DownUpBarBrush
		{
		    get { return downUpBarBrush; }
		    set { downUpBarBrush = value; }
		}
		[Browsable(false)]
		public string DownUpBarBrushSerialize
		{
		    get { return NinjaTrader.Gui.Serialize.BrushToString(downUpBarBrush); }
		    set { downUpBarBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Outline Color", GroupName = "Visual Parameters", Order = 5)]
		public Brush OutlineBrush 
		{ 	
			get{return outlineBrush;} 
			set{outlineBrush	=	value;} 
		}
		[Browsable(false)]
		public string OutlineBrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(outlineBrush); }
			set { outlineBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Wick Color", GroupName = "Visual Parameters", Order = 6)]
		public Brush WickBrush 
		{ 	
			get{return wickBrush;} 
			set{wickBrush	=	value;} 
		}
		[Browsable(false)]
		public string WickBrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(wickBrush); }
			set { wickBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Zero Line Color", GroupName = "Visual Parameters", Order = 7)]
		public Brush ZeroBrush
		{ 	
			get{return zeroBrush;} 
			set{zeroBrush	=	value;} 
		}
		[Browsable(false)]
		public string ZeroBrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(zeroBrush); }
			set { zeroBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Fast MA Color", GroupName = "Visual Parameters", Order = 8)]
		public Brush FastBrush
		{ 	
			get{return fastBrush;} 
			set{fastBrush	=	value;} 
		}
		[Browsable(false)]
		public string FastBrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(fastBrush); }
			set { fastBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Fast MA Width", GroupName = "Visual Parameters", Order = 9)]
		public int FastWidth
		{ 	
			get{return fastWidth;} 
			set{fastWidth	=	value;} 
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Slow MA Color", GroupName = "Visual Parameters", Order = 10)]
		public Brush SlowBrush
		{ 	
			get{return slowBrush;} 
			set{slowBrush	=	value;} 
		}
		[Browsable(false)]
		public string SlowBrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(slowBrush); }
			set { slowBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Slow MA Width", GroupName = "Visual Parameters", Order = 11)]
		public int SlowWidth
		{ 	
			get{return slowWidth;} 
			set{slowWidth	=	value;} 
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Ask > Bid 50%", GroupName = "Visual Parameters", Order = 12)]
		public Brush Ask_Greater_Bid_50_Brush { get; set; }
		[Browsable(false)]
		public string Ask_Greater_Bid_50_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Ask_Greater_Bid_50_Brush); }
			set { Ask_Greater_Bid_50_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Ask > Bid 15%-49%", GroupName = "Visual Parameters", Order = 13)]
		public Brush Ask_Greater_Bid_1549_Brush { get; set; }
		[Browsable(false)]
		public string Ask_Greater_Bid_1549_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Ask_Greater_Bid_1549_Brush); }
			set { Ask_Greater_Bid_1549_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Ask > Bid 0%-14%", GroupName = "Visual Parameters", Order = 14)]
		public Brush Ask_Greater_Bid_014_Brush { get; set; }
		[Browsable(false)]
		public string Ask_Greater_Bid_014_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Ask_Greater_Bid_014_Brush); }
			set { Ask_Greater_Bid_014_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Bid > Ask 50%", GroupName = "Visual Parameters", Order = 15)]
		public Brush Bid_Greater_Ask_50_Brush { get; set; }
		[Browsable(false)]
		public string Bid_Greater_Ask_50_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Bid_Greater_Ask_50_Brush); }
			set { Bid_Greater_Ask_50_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Bid > Ask 15%-49%", GroupName = "Visual Parameters", Order = 16)]
		public Brush Bid_Greater_Ask_1549_Brush { get; set; }
		[Browsable(false)]
		public string Bid_Greater_Ask_1549_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Bid_Greater_Ask_1549_Brush); }
			set { Bid_Greater_Ask_1549_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Bid > Ask 0%-14%", GroupName = "Visual Parameters", Order = 17)]
		public Brush Bid_Greater_Ask_014_Brush { get; set; }
		[Browsable(false)]
		public string Bid_Greater_Ask_014_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Bid_Greater_Ask_014_Brush); }
			set { Bid_Greater_Ask_014_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		#endregion

		#endregion

		#region OnStateChange
		protected override void OnStateChange()
		{
            #region SetDefaults
            if (State == State.SetDefaults)
			{
				Description									=   @"";
				Name										=   "ARC_CumulativeTickVolume";
				Calculate									=   Calculate.OnEachTick;
				IsOverlay									=   false;
				DisplayInDataBox							=   true;
				DrawOnPricePanel							=   false;
				DrawHorizontalGridLines						=   true;
				DrawVerticalGridLines						=   true;
				PaintPriceMarkers							=   true;
				ScaleJustification							=   NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive					=   false;
				ArePlotsConfigurable						=   true;
				cumPlotMode									=	ARC_CumPlotMode.Candlestick;
				cummulativeMinLot							=	50;
				cummulativeMaxLot							=	200;

                Ask_Greater_Bid_50_Brush                    =   Brushes.LimeGreen;
                Ask_Greater_Bid_1549_Brush                  =   Brushes.DarkSeaGreen;
                Ask_Greater_Bid_014_Brush                   =   Brushes.LightBlue;
                Bid_Greater_Ask_50_Brush                    =   Brushes.Red;
                Bid_Greater_Ask_1549_Brush                  =   Brushes.Salmon;
                Bid_Greater_Ask_014_Brush                   =   Brushes.Yellow;

                AddPlot(Brushes.Lime, "Current VOL");
            }
            #endregion

			#region Configure
			else if (State == State.Configure)
			{
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion
				if(cumPlotMode == ARC_CumPlotMode.LineOnClose) AddPlot(new Stroke(Brushes.White,2),PlotStyle.Line,"LineOnClose");
				AddPlot(new Stroke(fastBrush,fastWidth), PlotStyle.Line, "Fast");
				AddPlot(new Stroke(slowBrush,slowWidth), PlotStyle.Line, "Slow");
//				if(ChartPanel!=null)
				{
	                //if(!Bars.IsTickReplay)
    	            {
        	            AddDataSeries(BarsPeriodType.Tick, 1);
            	    }
				}
                CummulativeFootPrintList = new List<CummulativeFootPrint>();
				vol						 = new Series<double>(this,MaximumBarsLookBack.Infinite);
			}
            #endregion

            #region Transition
            else if(State==State.Transition)
            {
            }
            #endregion

            #region DataLoaded
            else if(State==State.DataLoaded)
            {
				sessionIterator				=	new SessionIterator(Bars);
				if(Bars.IsTickReplay)
					Draw.TextFixed(this,"tickreplayerror","Please disable TickReplay - CTV will not run with TickReplay enabled",TextPosition.Center);
            }
            #endregion
		}
		#endregion

		#region OnBarUpdate
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
int line=777;
try{
            if (BarsInProgress == 0)
            {
                if (!Bars.IsTickReplay)
                {
line=783;
                    if(CummulativeFootPrintList.Count>0)
                        vol[0] = CummulativeFootPrintList.Last().Volume;

                    if (State == State.Historical && Closes[0].Count - 1 != CurrentBars[0])
                    {
line=789;
                        if (CummulativeFootPrintList.Count > 0 && ((cummulativeTickMode == ARC_CumulativeTickMode.DailyCumulative && !reset) || (cummulativeTickMode == ARC_CumulativeTickMode.ChartCumulative)))
                        {
                            CummulativeFootPrintList.Add(new CummulativeFootPrint(CurrentBars[0]+1, CummulativeFootPrintList.Last().Volume, cummulativeMinLot, cummulativeMaxLot,
                                Ask_Greater_Bid_50_BrushId, Ask_Greater_Bid_1549_BrushId, Ask_Greater_Bid_014_BrushId, Bid_Greater_Ask_50_BrushId,
                                Bid_Greater_Ask_1549_BrushId, Bid_Greater_Ask_014_BrushId));
                            //CummulativeFootPrintList.Last().AddVolume(tick_volume, IsAsk);
                        }
                        else
                        {
                            CummulativeFootPrintList.Add(new CummulativeFootPrint(CurrentBars[0]+1, 0, cummulativeMinLot, cummulativeMaxLot,
                                Ask_Greater_Bid_50_BrushId, Ask_Greater_Bid_1549_BrushId, Ask_Greater_Bid_014_BrushId, Bid_Greater_Ask_50_BrushId,
                                Bid_Greater_Ask_1549_BrushId, Bid_Greater_Ask_014_BrushId));
                            //CummulativeFootPrintList.Last().AddVolume(tick_volume, IsAsk);
                            reset = false;
                        }
                    }
line=806;
                    if (State == State.Historical)
                        prevCurrentBar = CurrentBars[0];
                    if (cumPlotMode == ARC_CumPlotMode.LineOnClose && CurrentBars[0]>1)
                        Value[1] = CummulativeFootPrintList.Last().Volume;
                }
line=812;

                int idx = cumPlotMode == ARC_CumPlotMode.LineOnClose ? 2 : 1;

                Values[idx][0] = EMA(vol, fastPeriod)[0];
                Values[idx + 1][0] = EMA(vol, slowPeriod)[0];
//				if(System.IO.File.Exists("c:\\222222222222.txt")){
//					if(vol[0] > Values[idx+1][0]) BackBrush = Brushes.Green; else BackBrush = Brushes.Maroon;
////					if(Values[idx][0] > Values[idx+1][0]) BackBrush = Brushes.Green; else BackBrush = Brushes.Maroon;
//				}

line=819;
                if (State == State.Historical)
                {
line=822;
                    if (CurrentBars[0] > 0)
                        Values[0].Reset(1);
line=825;
                    Values[0][0] = CummulativeFootPrintList.Last().Volume;
line=827;
					try{
//					Print("Count: "+CummulativeFootPrintList.Count+"  CB[0]: "+ CurrentBars[0]);
line=830;
					var v = CummulativeFootPrintList[CurrentBars[0]].Volume;
line=832;
					var vO = CummulativeFootPrintList[CurrentBars[0]].VolumeOpen;
line=834;
                    PlotBrushes[0][0] = v > vO && v > 0 ? upBarBrush :
                                            v < vO && v > 0 ? upDownBarBrush :
                                            v < vO && v < 0 ? downBarBrush :
                                            v > vO && v < 0 ? downUpBarBrush :
                                            outlineBrush;
					}catch(Exception e834){Print(line+":  "+e834.ToString());}
                }
line=845;
            }

            //if (!Bars.IsTickReplay && (CurrentBars[2] <= 0 || CurrentBars[3] <= 0)) { return; }
line=849;
            if (BarsInProgress==1&&State==State.Historical)
            {
                double      last        =   Closes[1][0];
                DateTime    tick_time   =   Times[1][0];
                double      tick_volume =   Volumes[1][0];
                double      ask         =   BarsArray[1].GetAsk(CurrentBars[1]);
                double      bid         =   BarsArray[1].GetBid(CurrentBars[1]);

                //if (Close.IsValidDataPointAt(CurrentBar))
                //    currentBar = Close.Count - 1;

                

line=863;
                bool? IsAsk = null;
                if (last >= ask)
                    IsAsk = true;
                if (last <= bid)
                    IsAsk = false;

                #region CummulativeTick

                if (FirstRun || sessionIterator.IsNewSession(tick_time, true))
                {
                    FirstRun = false;
                    sessionIterator.CalculateTradingDay(tick_time, true);
                    reset = true;
                }

line=879;
                if (CummulativeFootPrintList.Count == 0)
                    CummulativeFootPrintList.Add(new CummulativeFootPrint(0, tick_volume, cummulativeMinLot, cummulativeMaxLot,
                        Ask_Greater_Bid_50_BrushId, Ask_Greater_Bid_1549_BrushId, Ask_Greater_Bid_014_BrushId, Bid_Greater_Ask_50_BrushId,
                        Bid_Greater_Ask_1549_BrushId, Bid_Greater_Ask_014_BrushId));
                else
                    CummulativeFootPrintList.Last().AddVolume(tick_volume, IsAsk);
                
                #endregion
line=888;
            }
}catch(Exception eee){Print(line+":  "+eee.ToString());}
        }
        #endregion

        #region OnMarketData
        protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
		{
int line=897;
try{
            if (lastArgs != null && lastArgs == marketDataUpdate)
                return;
line=901;
            lastArgs = marketDataUpdate;

            if (marketDataUpdate.MarketDataType!=MarketDataType.Last)
				return;
			
line=907;
			double		last			=	marketDataUpdate.Price;
			DateTime 	tick_time 		= 	marketDataUpdate.Time;
			double		tick_volume		=	marketDataUpdate.Volume;
		
			if(Closes[0].IsValidDataPointAt(CurrentBars[0]))
			currentBar	=	Closes[0].Count-1;
			
line=915;
			bool?	IsAsk			=	null;
			if(last>=marketDataUpdate.Ask)
				IsAsk	=	true;
			if(last<=marketDataUpdate.Bid)
				IsAsk	=	false;
            

line=923;
            #region CummulativeTick
            if (FirstRun||sessionIterator.IsNewSession(tick_time,true))
			{
				FirstRun = false;
				sessionIterator.CalculateTradingDay(tick_time,true);
				reset	=	true;
			}
line=931;
			if(currentBar!=prevCurrentBar)
			{
				if(CummulativeFootPrintList.Count>0 && ((cummulativeTickMode == ARC_CumulativeTickMode.DailyCumulative && !reset)||(cummulativeTickMode == ARC_CumulativeTickMode.ChartCumulative)))
				{
					CummulativeFootPrintList.Add(new CummulativeFootPrint(currentBar, CummulativeFootPrintList.Last().Volume, cummulativeMinLot, cummulativeMaxLot,
						Ask_Greater_Bid_50_BrushId, Ask_Greater_Bid_1549_BrushId, Ask_Greater_Bid_014_BrushId, Bid_Greater_Ask_50_BrushId,
						Bid_Greater_Ask_1549_BrushId, Bid_Greater_Ask_014_BrushId));
					CummulativeFootPrintList.Last().AddVolume(tick_volume,IsAsk);
				}
				else
				{
					CummulativeFootPrintList.Add(new CummulativeFootPrint(currentBar,0,cummulativeMinLot,cummulativeMaxLot,
                        Ask_Greater_Bid_50_BrushId, Ask_Greater_Bid_1549_BrushId, Ask_Greater_Bid_014_BrushId, Bid_Greater_Ask_50_BrushId,
                    	Bid_Greater_Ask_1549_BrushId, Bid_Greater_Ask_014_BrushId));
					CummulativeFootPrintList.Last().AddVolume(tick_volume,IsAsk);
					reset = false;
				}
				
			}
			else
			{
line=953;
				CummulativeFootPrintList.Last().AddVolume(tick_volume,IsAsk);
			}
			
line=957;
			if(cumPlotMode==ARC_CumPlotMode.LineOnClose)
				Value[0]	=	CummulativeFootPrintList.Last().Volume;
			
line=961;
			vol[0]			=	CummulativeFootPrintList.Last().Volume;
            #endregion

            if (CurrentBars[0] > 0)
                Values[0].Reset(1);
line=967;
            Values[0][0] = CummulativeFootPrintList.Last().Volume;
			try{
			var v = CummulativeFootPrintList[CurrentBars[0]].Volume;
line=971;
			var vO = CummulativeFootPrintList[CurrentBars[0]].VolumeOpen;
line=973;
            PlotBrushes[0][0] = v > vO && v > 0 ? upBarBrush :
                                    v < vO && v > 0 ? upDownBarBrush :
                                    v < vO && v < 0 ? downBarBrush :
                                    v > vO && v < 0 ? downUpBarBrush :
                                    outlineBrush;
			}catch(Exception e979){Print(line+":  "+e979.ToString());}

            prevCurrentBar = currentBar;


}catch(Exception eOMD){Print(line+":  "+eOMD.ToString());}

        }
        #endregion
		SharpDX.Direct2D1.Brush wickBrushDX;
		SharpDX.Direct2D1.Brush blackBrushDX;
		SharpDX.Direct2D1.Brush posImbBrushDX;
		SharpDX.Direct2D1.Brush negImbBrushDX;
		SharpDX.Direct2D1.Brush upBarBrushDX;
		SharpDX.Direct2D1.Brush downBarBrushDX;
		SharpDX.Direct2D1.Brush upDownBarBrushDX;
		SharpDX.Direct2D1.Brush downUpBarBrushDX;
		SharpDX.Direct2D1.Brush outlineBrushDX;
		SharpDX.Direct2D1.Brush zeroBrushDX;
		SortedDictionary<int, SharpDX.Direct2D1.Brush> BrushDX = new SortedDictionary<int, SharpDX.Direct2D1.Brush>();
		public override void OnRenderTargetChanged()
        {
			#region -- ORTC --
//			if(dx!=null   && !dx.IsDisposed)   {dx.Dispose();   dx=null;}
//			if(RenderTarget!=null) dx = bbb.ToDxBrush(RenderTarget);

			if(!BrushDX.ContainsKey(Bid_Greater_Ask_014_BrushId)) BrushDX[Bid_Greater_Ask_014_BrushId] = null;
			if(BrushDX[Bid_Greater_Ask_014_BrushId]!=null   && !BrushDX[Bid_Greater_Ask_014_BrushId].IsDisposed)   {BrushDX[Bid_Greater_Ask_014_BrushId].Dispose();   BrushDX[Bid_Greater_Ask_014_BrushId]=null;}
			if(RenderTarget!=null) BrushDX[Bid_Greater_Ask_014_BrushId] = Bid_Greater_Ask_014_Brush.ToDxBrush(RenderTarget);

			if(!BrushDX.ContainsKey(Bid_Greater_Ask_1549_BrushId)) BrushDX[Bid_Greater_Ask_1549_BrushId] = null;
			if(BrushDX[Bid_Greater_Ask_1549_BrushId]!=null   && !BrushDX[Bid_Greater_Ask_1549_BrushId].IsDisposed)   {BrushDX[Bid_Greater_Ask_1549_BrushId].Dispose();   BrushDX[Bid_Greater_Ask_1549_BrushId]=null;}
			if(RenderTarget!=null) BrushDX[Bid_Greater_Ask_1549_BrushId] = Bid_Greater_Ask_1549_Brush.ToDxBrush(RenderTarget);

			if(!BrushDX.ContainsKey(Bid_Greater_Ask_50_BrushId)) BrushDX[Bid_Greater_Ask_50_BrushId] = null;
			if(BrushDX[Bid_Greater_Ask_50_BrushId]!=null   && !BrushDX[Bid_Greater_Ask_50_BrushId].IsDisposed)   {BrushDX[Bid_Greater_Ask_50_BrushId].Dispose();   BrushDX[Bid_Greater_Ask_50_BrushId]=null;}
			if(RenderTarget!=null) BrushDX[Bid_Greater_Ask_50_BrushId] = Bid_Greater_Ask_50_Brush.ToDxBrush(RenderTarget);

			if(!BrushDX.ContainsKey(Ask_Greater_Bid_014_BrushId)) BrushDX[Ask_Greater_Bid_014_BrushId] = null;
			if(BrushDX[Ask_Greater_Bid_014_BrushId]!=null   && !BrushDX[Ask_Greater_Bid_014_BrushId].IsDisposed)   {BrushDX[Ask_Greater_Bid_014_BrushId].Dispose();   BrushDX[Ask_Greater_Bid_014_BrushId]=null;}
			if(RenderTarget!=null) BrushDX[Ask_Greater_Bid_014_BrushId] = Ask_Greater_Bid_014_Brush.ToDxBrush(RenderTarget);

			if(!BrushDX.ContainsKey(Ask_Greater_Bid_1549_BrushId)) BrushDX[Ask_Greater_Bid_1549_BrushId] = null;
			if(BrushDX[Ask_Greater_Bid_1549_BrushId]!=null   && !BrushDX[Ask_Greater_Bid_1549_BrushId].IsDisposed)   {BrushDX[Ask_Greater_Bid_1549_BrushId].Dispose();   BrushDX[Ask_Greater_Bid_1549_BrushId]=null;}
			if(RenderTarget!=null) BrushDX[Ask_Greater_Bid_1549_BrushId] = Ask_Greater_Bid_1549_Brush.ToDxBrush(RenderTarget);

			if(!BrushDX.ContainsKey(Ask_Greater_Bid_50_BrushId)) BrushDX[Ask_Greater_Bid_50_BrushId] = null;
			if(BrushDX[Ask_Greater_Bid_50_BrushId]!=null   && !BrushDX[Ask_Greater_Bid_50_BrushId].IsDisposed)   {BrushDX[Ask_Greater_Bid_50_BrushId].Dispose();   BrushDX[Ask_Greater_Bid_50_BrushId]=null;}
			if(RenderTarget!=null) BrushDX[Ask_Greater_Bid_50_BrushId] = Ask_Greater_Bid_50_Brush.ToDxBrush(RenderTarget);

			if(!BrushDX.ContainsKey(Transparent_ID)) BrushDX[Transparent_ID] = null;
			if(BrushDX[Transparent_ID]!=null   && !BrushDX[Transparent_ID].IsDisposed)   {BrushDX[Transparent_ID].Dispose();   BrushDX[Transparent_ID]=null;}
			if(RenderTarget!=null) BrushDX[Transparent_ID] = Brushes.Transparent.ToDxBrush(RenderTarget);


			if(zeroBrushDX!=null   && !zeroBrushDX.IsDisposed)   {zeroBrushDX.Dispose();   zeroBrushDX=null;}
			if(RenderTarget!=null) zeroBrushDX = zeroBrush.ToDxBrush(RenderTarget);

			if(outlineBrushDX!=null   && !outlineBrushDX.IsDisposed)   {outlineBrushDX.Dispose();   outlineBrushDX=null;}
			if(RenderTarget!=null) outlineBrushDX = outlineBrush.ToDxBrush(RenderTarget);

			if(downUpBarBrushDX!=null   && !downUpBarBrushDX.IsDisposed)   {downUpBarBrushDX.Dispose();   downUpBarBrushDX=null;}
			if(RenderTarget!=null) downUpBarBrushDX = downUpBarBrush.ToDxBrush(RenderTarget);

			if(upDownBarBrushDX!=null   && !upDownBarBrushDX.IsDisposed)   {upDownBarBrushDX.Dispose();   upDownBarBrushDX=null;}
			if(RenderTarget!=null) upDownBarBrushDX = upDownBarBrush.ToDxBrush(RenderTarget);

			if(downBarBrushDX!=null   && !downBarBrushDX.IsDisposed)   {downBarBrushDX.Dispose();   downBarBrushDX=null;}
			if(RenderTarget!=null) downBarBrushDX = downBarBrush.ToDxBrush(RenderTarget);

			if(upBarBrushDX!=null   && !upBarBrushDX.IsDisposed)   {upBarBrushDX.Dispose();   upBarBrushDX=null;}
			if(RenderTarget!=null) upBarBrushDX = upBarBrush.ToDxBrush(RenderTarget);

			if(negImbBrushDX!=null   && !negImbBrushDX.IsDisposed)   {negImbBrushDX.Dispose();   negImbBrushDX=null;}
			if(RenderTarget!=null) negImbBrushDX = Brushes.Red.ToDxBrush(RenderTarget);

			if(posImbBrushDX!=null   && !posImbBrushDX.IsDisposed)   {posImbBrushDX.Dispose();   posImbBrushDX=null;}
			if(RenderTarget!=null) posImbBrushDX = Brushes.LimeGreen.ToDxBrush(RenderTarget);

			if(blackBrushDX!=null   && !blackBrushDX.IsDisposed)   {blackBrushDX.Dispose();   blackBrushDX=null;}
			if(RenderTarget!=null) blackBrushDX = Brushes.Black.ToDxBrush(RenderTarget);

			if(wickBrushDX!=null   && !wickBrushDX.IsDisposed)   {wickBrushDX.Dispose();   wickBrushDX=null;}
			if(RenderTarget!=null) wickBrushDX = wickBrush.ToDxBrush(RenderTarget);
			#endregion
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			#region OnRender
			if(chartControl==null || ChartBars==null || chartScale==null) return;
			if (IsInHitTest) 
				return;

			//Tick size in pixels
//			float zero_pos	 =	(float)((ChartPanel.Y + ChartPanel.H) - ((0 - ChartPanel.MinValue )/ chartScale.MaxMinusMin) * ChartPanel.H);
//			float tick_pos	 =	(float)((ChartPanel.Y + ChartPanel.H) - ((TickSize - ChartPanel.MinValue )/ chartScale.MaxMinusMin) * ChartPanel.H);
//			float tick_float =	Math.Abs(tick_pos-zero_pos);
			float barWidth	 =	Math.Max((float)chartControl.BarWidth,1);

			SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;

int L=1438;
try{
			var bottomTextFormat = new SharpDX.DirectWrite.TextFormat(NinjaTrader.Core.Globals.DirectWriteFactory, "Verdana",
			                           SharpDX.DirectWrite.FontWeight.Bold, SharpDX.DirectWrite.FontStyle.Normal, 12);
			bottomTextFormat.TextAlignment = SharpDX.DirectWrite.TextAlignment.Center;
			float	zero_y		 = chartScale.GetYByValue(0);
			float	bar_w        = chartControl.Properties.BarDistance;
			float	block_y      = (ChartPanel.Y+ChartPanel.H) - 15f;
			float	block_w      = chartControl.Properties.BarDistance;
			float	block_h      = 15f;
			var		bottomPoint  = new SharpDX.Vector2(0f, block_y);
			var		blockRect    = new SharpDX.RectangleF(0f,block_y,block_w,block_h);
			float	cumm_width   = block_w*0.6f;
			var		cummRect     = new SharpDX.RectangleF(0f,0f,cumm_width,0f);
			var		bottomLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, "x", bottomTextFormat, block_w, 100);
			var v1 = new SharpDX.Vector2(0f,0f);
			var v2 = new SharpDX.Vector2(0f,0f);
L=1454;
			for(int i=ChartBars.FromIndex;i<=ChartBars.ToIndex;i++)
			{
				#region --- CummulativeTicksRender ---
				double cum_vol			=	CummulativeFootPrintList[i].Volume;
				float  cum_vol_y		=	chartScale.GetYByValue(cum_vol);
				double cumm_open_vol 	=	CummulativeFootPrintList[i].VolumeOpen;
				double cumm_high_vol 	=	CummulativeFootPrintList[i].VolumeHigh;
				double cumm_low_vol  	=	CummulativeFootPrintList[i].VolumeLow;
				float  cumm_open_y		=	chartScale.GetYByValue(cumm_open_vol);
				float  cumm_high_y		=	chartScale.GetYByValue(cumm_high_vol);
				float  cumm_low_y		=	chartScale.GetYByValue(cumm_low_vol);
				float  cumm_x			=	(float)(chartControl.GetXByBarIndex(ChartBars,i)-block_w*0.3f);

				ChartPanel.MaxValue	= cumm_high_vol;
				ChartPanel.MinValue	= cumm_low_vol;

L=1471;
				if(cumPlotMode != ARC_CumPlotMode.LineOnClose && cumPlotMode != ARC_CumPlotMode.OHLC){
					v1.X = chartControl.GetXByBarIndex(ChartBars,i);
					v1.Y = cumm_high_y;
					v2.X = v1.X;
					v2.Y = cumm_low_y;
					RenderTarget.DrawLine(v1, v2, wickBrushDX);
				}

L=1480;
				cummRect.X = cumm_x;
				cummRect.Width = cumm_width;
				if(cumPlotMode==ARC_CumPlotMode.Candlestick)	
				{
L=1485;
					cummRect.Y = cumm_open_vol<cum_vol ? cum_vol_y:cumm_open_y;
					cummRect.Height = Math.Abs(cum_vol_y - cumm_open_y);

					if(cum_vol > cumm_open_vol && cum_vol > 0)
						RenderTarget.FillRectangle(cummRect, upBarBrushDX);
					else if(cum_vol < cumm_open_vol && cum_vol > 0)
						RenderTarget.FillRectangle(cummRect, upDownBarBrushDX);
					else if(cum_vol < cumm_open_vol && cum_vol < 0)
						RenderTarget.FillRectangle(cummRect, downBarBrushDX);
					else if(cum_vol > cumm_open_vol && cum_vol < 0)
						RenderTarget.FillRectangle(cummRect, downUpBarBrushDX);
					else
						RenderTarget.FillRectangle(cummRect, outlineBrushDX);
					RenderTarget.DrawRectangle(cummRect, outlineBrushDX);
				}
				else if(cumPlotMode==ARC_CumPlotMode.Histogram)
				{
					cummRect.Y = cum_vol>0 ? cum_vol_y : zero_y;
					cummRect.Height = Math.Abs(cum_vol_y-zero_y);
					RenderTarget.DrawRectangle(cummRect,outlineBrushDX);

					int z=0;
					while(i-z>0 && CummulativeFootPrintList[i-z].Volume == CummulativeFootPrintList[i-z].VolumeOpen)
						z++;

					if(CummulativeFootPrintList[i - z].Volume > CummulativeFootPrintList[i - z].VolumeOpen && CummulativeFootPrintList[i - z].Volume > 0)
						RenderTarget.FillRectangle(cummRect, upBarBrushDX);
					else if(CummulativeFootPrintList[i - z].Volume < CummulativeFootPrintList[i - z].VolumeOpen && CummulativeFootPrintList[i - z].Volume > 0)
						RenderTarget.FillRectangle(cummRect, upDownBarBrushDX);
					else if(CummulativeFootPrintList[i - z].Volume < CummulativeFootPrintList[i - z].VolumeOpen && CummulativeFootPrintList[i - z].Volume < 0)
						RenderTarget.FillRectangle(cummRect, downBarBrushDX);
					else if(CummulativeFootPrintList[i - z].Volume > CummulativeFootPrintList[i - z].VolumeOpen && CummulativeFootPrintList[i - z].Volume < 0)
						RenderTarget.FillRectangle(cummRect, downUpBarBrushDX);
					else
						RenderTarget.FillRectangle(cummRect, outlineBrushDX);
				}

				else if(cumPlotMode==ARC_CumPlotMode.OHLC)
				{
L=1525;
					v1.X = chartControl.GetXByBarIndex(ChartBars,i);
					v1.Y = cumm_high_y;
					v2.X = v1.X;
					v2.Y = cumm_low_y;
					RenderTarget.DrawLine(v1, v2, cum_vol>cumm_open_vol ? upBarBrushDX : cum_vol<cumm_open_vol ? downBarBrushDX : upBarBrushDX, barWidth);
					v1.X = chartControl.GetXByBarIndex(ChartBars,i)+barWidth/2f;
					v1.Y = cumm_open_y;
					v2.X = chartControl.GetXByBarIndex(ChartBars,i)-barWidth*1.5f;
					v2.Y = v1.Y;
					RenderTarget.DrawLine(v1, v2, cum_vol>cumm_open_vol ? upBarBrushDX : cum_vol<cumm_open_vol ? downBarBrushDX : upBarBrushDX, barWidth);
					v1.X = chartControl.GetXByBarIndex(ChartBars,i)-barWidth/2f;
					v1.Y = cum_vol_y;
					v2.X = chartControl.GetXByBarIndex(ChartBars,i)+barWidth*1.5f;
					v2.Y = v1.Y;
					RenderTarget.DrawLine(v1, v2, cum_vol>cumm_open_vol ? upBarBrushDX : cum_vol<cumm_open_vol ? downBarBrushDX : upBarBrushDX, barWidth);
				}

				#endregion

				#region BarDeltaRender
L=1546;
				double imbalance = CummulativeFootPrintList[i].GetDelta();
				blockRect.X = chartControl.GetXByBarIndex(ChartBars, i) - bar_w * 0.5f;
				RenderTarget.DrawRectangle(blockRect, blackBrushDX);
				if(BrushDX[CummulativeFootPrintList[i].ImbalanceBrushId]!=null) RenderTarget.FillRectangle(blockRect, BrushDX[CummulativeFootPrintList[i].ImbalanceBrushId]);

L=1552;
				bottomLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, imbalance.ToString(), bottomTextFormat, block_w, 100);
				bottomPoint.X = blockRect.X;
				RenderTarget.DrawTextLayout(bottomPoint, bottomLayout, blackBrushDX);
				#endregion
            }
L=1558;
			bottomTextFormat.Dispose();

            //Draw zero line
			v1.X = chartControl.GetXByBarIndex(ChartBars,ChartBars.FromIndex);
			v1.Y = zero_y;
			v2.X = chartControl.GetXByBarIndex(ChartBars,ChartBars.ToIndex);
			v2.Y = v1.Y;
L=1566;
            RenderTarget.DrawLine(v1, v2, zeroBrushDX, 2f,new Stroke(zeroBrush,2f){DashStyleHelper=DashStyleHelper.Dash}.StrokeStyle);

//			if(cumPlotMode==ARC_CumPlotMode.LineOnClose)
//			{
//				base.OnRender(chartControl, chartScale);
//			}
			base.OnRender(chartControl, chartScale);
			RenderTarget.AntialiasMode = OSM;

L=1576;
			footer_dist = chartScale.GetValueByY(20) - chartScale.GetValueByY(40);
}catch(Exception ee){Print(L+": "+ee.ToString());}
	        #endregion
        }

        #region OnCalculateMinMax
        public override void OnCalculateMinMax()
		{
			// make sure to always start fresh values to calculate new min/max values
			double tmpMin = double.MaxValue;
			double tmpMax = double.MinValue;

			// For performance optimization, only loop through what is viewable on the chart
			for (int index = ChartBars.FromIndex; index <= ChartBars.ToIndex; index++)
			{
				// since using Close[0] is not guaranteed to be in sync
				// retrieve "Close" value at the current viewable range index
				double plotValue = Closes[0].GetValueAt(index);
					
				// return min/max of close value
				if(cumPlotMode==ARC_CumPlotMode.Candlestick)
				{
				    tmpMin = Math.Min(tmpMin, (CummulativeFootPrintList.Count>index)?CummulativeFootPrintList[index].VolumeLow:0);
				    tmpMax = Math.Max(tmpMax, (CummulativeFootPrintList.Count>index)?CummulativeFootPrintList[index].VolumeHigh:0);
				}
				else
				{
					tmpMin = Math.Min(tmpMin, (CummulativeFootPrintList.Count>index)?CummulativeFootPrintList[index].Volume:0);
				    tmpMax = Math.Max(tmpMax, Math.Max((CummulativeFootPrintList.Count>index)?CummulativeFootPrintList[index].Volume:0,0));
				}
			}

			// Finally, set the minimum and maximum Y-Axis values to +/- 50 ticks from the primary close value

			MinValue = tmpMin-footer_dist;
			MaxValue = tmpMax;

			//System.Diagnostics.Debug.WriteLine(tmpMin + " " + MinValue);
        }
        #endregion

        #region Cummulative FootPrint
        public class CummulativeFootPrint
		{
			public double    	VolumeOpen
			{get;set;}
			public double    	VolumeHigh
			{get;set;}
			public double    	VolumeLow
			{get;set;}
			public int    		BarIndex
			{get;set;}
			public double	  	Volume
			{get;set;}
			private	double		cummulativeMinLot;
			private	double		cummulativeMaxLot;
			public int ImbalanceBrushId
			{ get; set; }
//			private	int AskBid1BrushId;
//			private	int AskBid2BrushId;
//			private	int AskBid3BrushId;
//			private	int BidAsk1BrushId;
//			private	int BidAsk2BrushId;
//			private	int BidAsk3BrushId;
			public double Bid
			{ get; set; }
			public double Ask
			{ get; set; }

            public CummulativeFootPrint(int barIndex,double volume,double minLot,double maxLot,
                int Ask_Greater_Bid_50_Brush, int Ask_Greater_Bid_1549_Brush, int Ask_Greater_Bid_014_Brush, 
                int Bid_Greater_Ask_50_Brush, int Bid_Greater_Ask_1549_Brush, int Bid_Greater_Ask_014_Brush)
			{
//                AskBid1BrushId = Ask_Greater_Bid_50_Brush;
//                AskBid2BrushId = Ask_Greater_Bid_1549_Brush;
//                AskBid3BrushId = Ask_Greater_Bid_014_Brush;
//                BidAsk1BrushId = Bid_Greater_Ask_50_Brush;
//                BidAsk2BrushId = Bid_Greater_Ask_1549_Brush;
//                BidAsk3BrushId = Bid_Greater_Ask_014_Brush;

                VolumeOpen	=	volume;
				BarIndex	=	barIndex;
				VolumeLow	=	volume;
				VolumeHigh	=	volume;
				Volume		=	volume;
				cummulativeMinLot	=	minLot;
				cummulativeMaxLot	=	maxLot;

                CalcImbalanceState();

            }
			public void AddVolume(double volume, bool? ask)
			{
				if(volume >= cummulativeMinLot && volume <= cummulativeMaxLot)
				{
					if(ask==true)
					{
						Volume+=volume;
                        Ask += volume;
					}
					else
					{
						Volume-=volume;
                        Bid += volume;
					}
					if(Volume>VolumeHigh)
						VolumeHigh=Volume;
					if(Volume<VolumeLow)
						VolumeLow=Volume;

                    CalcImbalanceState();

                }
			}

            public double GetDelta()
            {
                return (Ask-Bid);
            }

            public void CalcImbalanceState()
            {
                int result = Transparent_ID;
                double rel;
                if (Ask >= Bid)
                {
                    rel = Math.Round(1 - Bid / Ask, 2);
                    result = rel >= 0.5 ? Ask_Greater_Bid_50_BrushId :
                             rel >= 0.15 && rel <= 0.49 ? Ask_Greater_Bid_1549_BrushId :
                             rel >= 0 && rel <= 0.14 ? Ask_Greater_Bid_014_BrushId : Transparent_ID;
                }
                else
                {
                    rel = Math.Round(1 - Ask / Bid, 2);
                    result = rel >= 0.5 ? Bid_Greater_Ask_50_BrushId :
                             rel >= 0.15 && rel <= 0.49 ? Bid_Greater_Ask_1549_BrushId :
                             rel >= 0 && rel <= 0.14 ? Bid_Greater_Ask_014_BrushId : Transparent_ID;
                }

                ImbalanceBrushId = result;
            }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_CumulativeTickVolume[] cacheARC_CumulativeTickVolume;
		public ARC.ARC_CumulativeTickVolume ARC_CumulativeTickVolume()
		{
			return ARC_CumulativeTickVolume(Input);
		}

		public ARC.ARC_CumulativeTickVolume ARC_CumulativeTickVolume(ISeries<double> input)
		{
			if (cacheARC_CumulativeTickVolume != null)
				for (int idx = 0; idx < cacheARC_CumulativeTickVolume.Length; idx++)
					if (cacheARC_CumulativeTickVolume[idx] != null &&  cacheARC_CumulativeTickVolume[idx].EqualsInput(input))
						return cacheARC_CumulativeTickVolume[idx];
			return CacheIndicator<ARC.ARC_CumulativeTickVolume>(new ARC.ARC_CumulativeTickVolume(), input, ref cacheARC_CumulativeTickVolume);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_CumulativeTickVolume ARC_CumulativeTickVolume()
		{
			return indicator.ARC_CumulativeTickVolume(Input);
		}

		public Indicators.ARC.ARC_CumulativeTickVolume ARC_CumulativeTickVolume(ISeries<double> input )
		{
			return indicator.ARC_CumulativeTickVolume(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_CumulativeTickVolume ARC_CumulativeTickVolume()
		{
			return indicator.ARC_CumulativeTickVolume(Input);
		}

		public Indicators.ARC.ARC_CumulativeTickVolume ARC_CumulativeTickVolume(ISeries<double> input )
		{
			return indicator.ARC_CumulativeTickVolume(input);
		}
	}
}

#endregion
