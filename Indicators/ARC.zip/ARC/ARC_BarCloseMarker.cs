#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using SharpDX.DirectWrite;
using System.Linq;
#endregion
using NinjaTrader.NinjaScript.DrawingTools;
using System.Collections.Generic;

#region Author/Copyright
/*********************************************************************
************************* Golden Zone Trading ************************
**********************************************************************
* Author NT8 : Kriss { AzurITec }
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
v0.001  - 29.08.2016    + conversion from NT7
----------------------------------------------------------------------
v0.002  - 05.09.2016    + Compatible Beta13 RC1
----------------------------------------------------------------------
v1.01   - 02.11.2016    + Compatible Beta14 RC2
                        + Added BXT_BTMode (new bartype same as BXT but always to BTMode ON)
----------------------------------------------------------------------
######################################################################
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ COMMENTS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
**********************************************************************
*/
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    public enum ARC_BarCloseMarkerType { NONE, PRICE, EXTENDED_LINES }
    [CategoryOrder("Timeframe", 10)]
    [CategoryOrder("Marker Settings", 20)]
    [CategoryOrder("Shadow Settings", 30)]
    [CategoryOrder("Audio", 40)]
    [CategoryOrder("Indicator Version", 1000)]

    public class ARC_BarCloseMarker : Indicator
    {
		private bool IsDebug        = false;
		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName        = "BarCloseMarker";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "21434","25900", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion
		
		private string VERSION = "1.0";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

        #region -- Variables --
        //-- computation --
        private double cLow;
        private double cHigh;

        //-- DataSeries --
//        private Series<double> lowBarClose;
//        private Series<double> highBarClose;
		private SortedDictionary<int,double> lowBarClose = new SortedDictionary<int,double>();
		private SortedDictionary<int,double> highBarClose = new SortedDictionary<int,double>();
        #endregion

        //------------------------ Virtuals -----------------------------------------
//        public override string DisplayName { get { return "ARC_BarCloseMarker"; } }

		private int DATA_ID = 0;
        protected override void OnStateChange()
        {
            #region State == State.SetDefaults
            if (State == State.SetDefaults)
            {
                Name = "ARC_BarCloseMarker";
                Calculate = Calculate.OnEachTick;
                MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
                IsOverlay = true;
                ArePlotsConfigurable = false;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = true;
				pBXTSize     = 30;
				pBXTOffset   = 15;
				pBXTReverse  = 35;
				pUseHigherTimeframe = false;

                AddPlot(Brushes.Gray, "BarCloseHigh");
                AddPlot(Brushes.Gray, "BarCloseLow");

                //-- Markers --
                pDisplayMarkers = ARC_BarCloseMarkerType.EXTENDED_LINES;
                pMarkerWidth = 2;
                pMarkerOpacity = 50;
                pMarkerHighColor = Brushes.Lime;
                pMarkerPriceColor = Brushes.Black;
                pMarkerLowColor = Brushes.Red;
                pTextFont = new SimpleFont("Arial", 12) { Bold = true };

                //-- Shadow --
                pDisplayShadow = true;
                pShadowOpacity = 10;
                pShadowUpColor = Brushes.Lime;
                pShadowDwColor = Brushes.Red;
            }
            #endregion

            #region State == Configure
            else if (State == State.Configure)
            {
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion
				bool NSRenkoBXT  = BarsArray[0].BarsType.Name.Contains("NS_RenkoBXT");
				bool ARCRenkoBXT = BarsArray[0].BarsType.Name.Contains("ARC_RenkoBXT");
				if(NSRenkoBXT){
					try{
						AddDataSeries(new BarsPeriod { BarsPeriodType = (BarsPeriodType) 16005, Value = pBXTSize, Value2 = pBXTOffset, BaseBarsPeriodValue = pBXTReverse });//NS_RenkoBXT
						if(pUseHigherTimeframe) DATA_ID = 1;
						ARCRenkoBXT = false;
					}catch(Exception e){
						if(pUseHigherTimeframe) Print("Cannot add NS_RenkoBXT!");
					}
				}
				if(ARCRenkoBXT){
					try{
						AddDataSeries(new BarsPeriod { BarsPeriodType = (BarsPeriodType) 19875, Value = pBXTSize, Value2 = pBXTOffset, BaseBarsPeriodValue = pBXTReverse });//ARC_RenkoBXT
						if(pUseHigherTimeframe) DATA_ID = 1;
					}catch(Exception ee){
						if(pUseHigherTimeframe) Print("Cannot add ARC_RenkoBXT!");
					}
				}

                MaximumBarsLookBack = MaximumBarsLookBack.Infinite;//FORCE if user changed

                Plots[0].Brush = pMarkerHighColor;
                Plots[0].Width = 0;
                Plots[0].PlotStyle = PlotStyle.Line;
                Plots[0].DashStyleHelper = DashStyleHelper.Solid;

                Plots[1].Brush = pMarkerLowColor;
                Plots[1].Width = 0;
                Plots[1].PlotStyle = PlotStyle.Line;
                Plots[1].DashStyleHelper = DashStyleHelper.Solid;

//                lowBarClose = new Series<double>(SMA(Closes[DATA_ID],2));
//                highBarClose = new Series<double>(SMA(Closes[DATA_ID],2));
            }
            #endregion
        }

        protected override void OnBarUpdate()
        {
			if(BarsInProgress != DATA_ID) return;
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
            if (CurrentBar < 2 || State == State.Historical) return;
			bool FullRange =  Bars.BarsType.Name.Contains("NS_FullRange") || Bars.BarsType.Name.Contains("ARC_FullRange");
			bool RenkoBT   =  Bars.BarsType.Name.Contains("NS_RenkoBT")   || Bars.BarsType.Name.Contains("ARC_RenkoBT");
			bool RenkoBXT  =  Bars.BarsType.Name.Contains("NS_RenkoBXT")  || Bars.BarsType.Name.Contains("ARC_RenkoBXT");
			bool PullBack  =  Bars.BarsType.Name.Contains("NS_PullBack")  || Bars.BarsType.Name.Contains("ARC_PullBack");
			bool RenkoBXT_BTMode =  Bars.BarsType.Name.Contains("NS_RenkoBXT_BTMode") || Bars.BarsType.Name.Contains("ARC_RenkoBXT_BTMode");
//Print("FullRange? "+FullRange.ToString()+"    "+Bars.BarsType.Name);
            if (Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Range 
				&& !FullRange
				&& !PullBack
				&& !RenkoBXT_BTMode
				&& !RenkoBT 
				&& !RenkoBXT) return;
            #region -- Range and Full Range Bars logic --
            if (Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Range || FullRange)
            {
                double tickSize = Bars.Instrument.MasterInstrument.TickSize;
                double rangeValue = Math.Floor(10000000.0 * (double)Bars.BarsPeriod.Value * tickSize) / 10000000.0;
                cLow  = Highs[DATA_ID][0] - rangeValue;
                cHigh = Lows[DATA_ID][0] + rangeValue;
            }
            #endregion

            #region -- NS_RenkoBT logic --
            else if (RenkoBT)
            {
                double body = BarsArray[DATA_ID].BarsPeriod.Value * Bars.Instrument.MasterInstrument.TickSize;
                bool btMode = (int)BarsArray[DATA_ID].BarsPeriod.BaseBarsPeriodValue == 1;
                bool trend  = Closes[DATA_ID][1] > Opens[DATA_ID][1];

                if (Times[DATA_ID][0].CompareTo(Times[DATA_ID][1].AddSeconds(BarsArray[DATA_ID].BarsPeriod.Value2)) < 0)
                {
                    cLow  = 0;
                    cHigh = 0;
                }
                else if (!btMode)
                {
                    cHigh = Math.Max(Opens[DATA_ID][0] + body, Highs[DATA_ID][0]);
                    cLow  = Math.Min(Opens[DATA_ID][0] - body, Lows[DATA_ID][0]);
                }
                else
                {
                    if (trend)
                    {
                        cHigh = Math.Max(RTTS(Closes[DATA_ID][1] - body / 2) + body, Highs[DATA_ID][0]);
                        cLow  = Math.Min(RTTS(Closes[DATA_ID][1] - body / 2) - body, Lows[DATA_ID][0]);
                    }
                    else
                    {
                        cHigh = Math.Max(RTTS(Closes[DATA_ID][1] + body / 2) + body, Highs[DATA_ID][0]);
                        cLow  = Math.Min(RTTS(Closes[DATA_ID][1] + body / 2) - body, Lows[DATA_ID][0]);
                    }
                }
            }
            #endregion

            #region -- NS_PullBack logic --
            else if (PullBack)
            {
                double pullbacksize = (BarsArray[DATA_ID].BarsPeriod.Value2 - 1) * TickSize;
                double barsize = BarsArray[DATA_ID].BarsPeriod.Value * TickSize;

                if (RTTS(Highs[DATA_ID][0] - Lows[DATA_ID][0]) <= barsize)
                {
                    cHigh = 0;
                    cLow = 0;
                }
                else
                {
                    cHigh = Highs[DATA_ID][0] - pullbacksize;
                    cLow = Lows[DATA_ID][0] + pullbacksize;
                }
            }
            #endregion

            #region -- NS_RenkoBXT logic --
            else if (RenkoBXT || RenkoBXT_BTMode)
            {
                bool trend = Closes[DATA_ID][1] > Opens[DATA_ID][1];
                double body = BarsArray[DATA_ID].BarsPeriod.Value * BarsArray[DATA_ID].Instrument.MasterInstrument.TickSize;
                double offset = BarsArray[DATA_ID].BarsPeriod.Value2 * BarsArray[DATA_ID].Instrument.MasterInstrument.TickSize;
                double reverse = BarsArray[DATA_ID].BarsPeriod.BaseBarsPeriodValue * BarsArray[DATA_ID].Instrument.MasterInstrument.TickSize;

                if (trend)
                {
                    cHigh = RenkoBXT_BTMode ? Closes[DATA_ID][1] - offset + body : Opens[DATA_ID][0] + body;
                    cLow = Highs[DATA_ID][0] - reverse;
                }
                else
                {
                    cLow = RenkoBXT_BTMode ? Closes[DATA_ID][1] + offset - body : Opens[DATA_ID][0] - body;
                    cHigh = Lows[DATA_ID][0] + reverse;
                }
            }
            #endregion

//            if (cLow > 0)  lowBarClose[0] = cLow;   else lowBarClose.Reset(0);
//            if (cHigh > 0) highBarClose[0] = cHigh; else highBarClose.Reset(0);
            if (cLow > 0)  lowBarClose[CurrentBars[0]] = cLow;
            if (cHigh > 0) highBarClose[CurrentBars[0]] = cHigh;

            if (pDisplayMarkers == ARC_BarCloseMarkerType.EXTENDED_LINES)
            {
                //-- first reset previous value to show only last bar marker --
                BarCloseHigh.Reset(1);
                BarCloseLow.Reset(1);
                //-- then set value --
                if (cHigh > 0) BarCloseHigh[0] = cHigh;
                if (cLow > 0)  BarCloseLow[0] = cLow;
            }
			if(State != State.Historical && IsFirstTickOfBar && pBarClosedWAV.Length>0)
				PlaySound(AddSoundFolder(pBarClosedWAV));
        }
//====================================================================
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
//====================================================================
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            #region -- conditions to return --
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (Bars == null || BarsArray[DATA_ID]==null || ChartControl == null) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
            #endregion

            base.OnRender(chartControl, chartScale);
            SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
            int barWidth = (int)ChartControl.Properties.BarDistance / 2;

            try
            {
                int index0 = Math.Min(CurrentBars[0], ChartControl.LastSlotPainted);
				int index1 = index0;
				double h = 0;
				if(highBarClose.ContainsKey(index0)) h = highBarClose[index0];
				double l = 0;
				if(lowBarClose.ContainsKey(index0)) l = lowBarClose[index0];
				if(DATA_ID>0){
					var t = BarsArray[0].GetTime(index0);
					index1 = BarsArray[DATA_ID].GetBar(t);
				}
                if (!lowBarClose.ContainsKey(index0) || !highBarClose.ContainsKey(index0)) return;

                //Shadow
                if (pDisplayShadow)
                {
                    DrawShadow(h, Math.Max(Opens[DATA_ID].GetValueAt(index1), Closes[0].GetValueAt(index0)), pShadowUpColor, pShadowOpacity, barWidth, index0, chartScale);
                    DrawShadow(Math.Min(Opens[DATA_ID].GetValueAt(index1), Closes[0].GetValueAt(index0)), l, pShadowDwColor, pShadowOpacity, barWidth, index0, chartScale);
                }
                //Marker
                #region -- EXTENDED_LINES --
                if (pDisplayMarkers == ARC_BarCloseMarkerType.EXTENDED_LINES)
                {
                    DrawExtendedLine(h, pMarkerHighColor, pMarkerOpacity, pMarkerWidth, barWidth, index0, chartControl, chartScale);
                    DrawExtendedLine(Closes[DATA_ID].GetValueAt(index1), pMarkerPriceColor, pMarkerOpacity, pMarkerWidth, barWidth, index0, chartControl, chartScale);
                    DrawExtendedLine(l, pMarkerLowColor, pMarkerOpacity, pMarkerWidth, barWidth, index0, chartControl, chartScale);

                    DrawBarLine(h, pMarkerHighColor, 100, pMarkerWidth, barWidth, index0, chartControl, chartScale);
                    DrawBarLine(l, pMarkerLowColor, 100, pMarkerWidth, barWidth, index0, chartControl, chartScale);
                }
                #endregion

                #region -- PRICE --
                else if (pDisplayMarkers == ARC_BarCloseMarkerType.PRICE)
                {
                    int upStringWidth = (int)getTextWidth(h.ToString(), pTextFont);
                    int dwStringWidth = (int)getTextWidth(l.ToString(), pTextFont);

                    if (Math.Max(dwStringWidth, upStringWidth) <= 4 * barWidth)
                    {
                        drawstring(h.ToString(), h, -1 * (int)pTextFont.Size, pTextFont, pMarkerHighColor, SharpDX.DirectWrite.TextAlignment.Center, barWidth, index0, chartScale);                            
                        drawstring(l.ToString(), l, 3, pTextFont, pMarkerLowColor, SharpDX.DirectWrite.TextAlignment.Center, barWidth, index0, chartScale);
                    }
                    DrawBarLine(h, pMarkerHighColor, pMarkerOpacity, pMarkerWidth, barWidth, index0, chartControl, chartScale);
                    DrawBarLine(l, pMarkerLowColor, pMarkerOpacity, pMarkerWidth, barWidth, index0, chartControl, chartScale);
                }
                #endregion
            }
            catch (Exception e) { }
            
            RenderTarget.AntialiasMode = OSM;
        }

        //-------------------------- Misc Functions ------------------------------
        private double RTTS(double r) { 
		//	return Instruments[0].MasterInstrument.RoundToTickSize(r); 
			int t = (int)Math.Round(r/TickSize);
			return t*TickSize;
		}

        #region -- drawing functions {AzurITec} --
        private int GetX0(int bars, ChartControl chartControl, bool atMiddle = false) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars) - (atMiddle ? (int)(chartControl.Properties.BarDistance / 2) : 0); }//NEW VERSION NT8
        private void DrawShadow(double cTop, double cBottom, Brush color, int opacity, int barPaintWidth, int index, ChartScale chartScale)
        {
            int xm = GetX0(index, ChartControl);
            int x0 = xm - barPaintWidth;
            int x1 = xm + barPaintWidth;
//            int y1 = (int)chartScale.GetYByValueWpf(cTop);
//            int y0 = (int)chartScale.GetYByValueWpf(cBottom);
            int y1 = (int)chartScale.GetYByValue(cTop);
            int y0 = (int)chartScale.GetYByValue(cBottom);
            Point[] points = { new Point(x0, y1), new Point(x1, y1), new Point(x1, y0), new Point(x0, y0) };

            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            linebrush.Opacity = (float)opacity/100;

            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, linebrush);
            geo1.Dispose();
            sink1.Dispose();
            linebrush.Dispose();
        }
        private void DrawExtendedLine(double value, Brush color, int opacity, int width, int barPaintWidth, int index, ChartControl chartControl, ChartScale chartScale)
        {
            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            linebrush.Opacity = opacity / 100f;
            SharpDX.Direct2D1.DashStyle _dashstyle = SharpDX.Direct2D1.DashStyle.Solid;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

			double p = Convert.ToDouble(chartScale.GetYByValue(value));
            Point p0 = new Point(GetX0(index, chartControl) + barPaintWidth, p);
            Point p1 = new Point(ChartPanel.W, p);
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }
        private void DrawBarLine(double value, Brush color, int opacity, int width, int barPaintWidth, int index, ChartControl chartControl, ChartScale chartScale)
        {
            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            linebrush.Opacity = opacity / 100f;
            SharpDX.Direct2D1.DashStyle _dashstyle = SharpDX.Direct2D1.DashStyle.Solid;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            Point p0 = new Point(GetX0(index, chartControl) - barPaintWidth, chartScale.GetYByValue(value));
            Point p1 = new Point(GetX0(index, chartControl) + barPaintWidth, chartScale.GetYByValue(value));
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }
        private void drawstring(string text, double value, int YOFFSET, SimpleFont font, Brush textBrush, SharpDX.DirectWrite.TextAlignment textAlignment, int barPaintWidth, int index, ChartScale chartScale)
        {
            int xleft = GetX0(index, ChartControl) - barPaintWidth;
//            int y1 = (int)chartScale.GetYByValueWpf(value) + YOFFSET;
            int y1 = (int)chartScale.GetYByValue(value) + YOFFSET;

            SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(xleft, y1);
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                )
            { TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, barPaintWidth*2, float.MaxValue);

            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textBrush.ToDxBrush(RenderTarget), SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
        }
        private float getTextWidth(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }
        #endregion

		internal class LoadFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(Core.Globals.InstallDir,"sounds");
				string search = "*.wav";
				System.IO.DirectoryInfo dirCustom = new System.IO.DirectoryInfo(folder);
				System.IO.FileInfo[] filCustom = dirCustom.GetFiles( search);

				string[] list = new string[filCustom.Length];
				int i = 0;
				foreach (System.IO.FileInfo fi in filCustom)
				{
//					if(fi.Extension.ToLower().CompareTo(".exe")!=0 && fi.Extension.ToLower().CompareTo(".txt")!=0){
					list[i] = fi.Name;
					i++;
//					}
				}
				string[] filteredlist = new string[i];
				for(i = 0; i<filteredlist.Length; i++) filteredlist[i] = list[i];
				return new StandardValuesCollection(filteredlist);
			}
			#endregion
        }

        //-------------------------- Properties ------------------------------
		#region -- Timeframe Parameters --
	//	[NinjaScriptProperty]
		[Display(Name = "Use background BXT bar", GroupName = "Timeframe", Description = "", Order = 10)]
		public bool pUseHigherTimeframe {get;set;}

		//[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "BXT bar Size", GroupName = "Timeframe", Description = "", Order = 20)]
		public int pBXTSize {get;set;}

		//[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "BXT bar Offset", GroupName = "Timeframe", Description = "", Order = 30)]
		public int pBXTOffset {get;set;}

		//[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "BXT bar Reversal", GroupName = "Timeframe", Description = "", Order = 40)]
		public int pBXTReverse {get;set;}
		#endregion

        #region -- Marker Parameters --
        [Display(Name = "Marker Type", GroupName = "Marker Settings", Description = "Display Markers", Order = 0)]
        public ARC_BarCloseMarkerType pDisplayMarkers { get; set; }
        [Display(Name = "Text Font", GroupName = "Marker Settings", Description = "Choose the font style for the price labels.", Order = 1)]
        public SimpleFont pTextFont { get; set; }
        [XmlIgnore]
        [Display(Name = "Bar Close High Color", GroupName = "Marker Settings", Description = "Select Color", Order = 2)]
        public Brush pMarkerHighColor { get; set; }
        [Browsable(false)]
        public string pMarkerHighColorColorSerialize
        {
            get { return Serialize.BrushToString(pMarkerHighColor); }
            set { pMarkerHighColor = Serialize.StringToBrush(value); }
        }
        [XmlIgnore]
        [Display(Name = "Current Price Color", GroupName = "Marker Settings", Description = "Select Color", Order = 3)]
        public Brush pMarkerPriceColor { get; set; }
        [Browsable(false)]
        public string pMarkerPriceColorSerialize
        {
            get { return Serialize.BrushToString(pMarkerPriceColor); }
            set { pMarkerPriceColor = Serialize.StringToBrush(value); }
        }
        [XmlIgnore]
        [Display(Name = "Bar Close Low Color", GroupName = "Marker Settings", Description = "Select Color", Order = 4)]
        public Brush pMarkerLowColor { get; set; }
        [Browsable(false)]
        public string pMarkerLowColorSerialize
        {
            get { return Serialize.BrushToString(pMarkerLowColor); }
            set { pMarkerLowColor = Serialize.StringToBrush(value); }
        }

        [Range(1, int.MaxValue)]
        [Display(Name = "Marker width", GroupName = "Marker Settings", Description = "Marker width", Order = 5)]
        public int pMarkerWidth { get; set; }

        [Range(0, 100)]
        [Display(Name = "Marker Opacity (%)", GroupName = "Marker Settings", Description = "Marker Opacity (%)", Order = 6)]
        public int pMarkerOpacity { get; set; }
        #endregion

        #region -- Shadow Parameters --
        [Display(Name = "Display Shadow", GroupName = "Shadow Settings", Description = "Display Shadow", Order = 0)]
        public bool pDisplayShadow { get; set; }

        [Range(0, 100)]
        [Display(Name = "Shadow Opacity", GroupName = "Shadow Settings", Description = "Shadow Opacity (%)", Order = 1)]
        public int pShadowOpacity { get; set; }

        [XmlIgnore]
        [Display(Name = "Top Shadow Color", GroupName = "Shadow Settings", Description = "Top Shadow Color", Order = 2)]
        public Brush pShadowUpColor { get; set; }
        [Browsable(false)]
        public string pShadowUpColorSerialize
        {
            get { return Serialize.BrushToString(pShadowUpColor); }
            set { pShadowUpColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bottom Shadow Color", GroupName = "Shadow Settings", Description = "Bottom Shadow Color", Order = 3)]
        public Brush pShadowDwColor { get; set; }
        [Browsable(false)]
        public string pShadowDwColorSerialize
        {
            get { return Serialize.BrushToString(pShadowDwColor); }
            set { pShadowDwColor = Serialize.StringToBrush(value); }
        }
        #endregion
    
		private string pBarClosedWAV = "";
		[Description("WAV file to play at the close of each bar")]
        [Category("Audio")]
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadFileList))]
        public string BarClosedWAV
        {
            get { return pBarClosedWAV; }
            set { pBarClosedWAV = value.Replace(" ",string.Empty);
				if(pBarClosedWAV.Length>0 && !pBarClosedWAV.ToLower().Contains(".wav")) pBarClosedWAV = pBarClosedWAV+".wav";
				}
        }

        //--------------------- Plots ----------------------------------
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BarCloseHigh { get { return Values[0]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BarCloseLow { get { return Values[1]; } }
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_BarCloseMarker[] cacheARC_BarCloseMarker;
		public ARC.ARC_BarCloseMarker ARC_BarCloseMarker()
		{
			return ARC_BarCloseMarker(Input);
		}

		public ARC.ARC_BarCloseMarker ARC_BarCloseMarker(ISeries<double> input)
		{
			if (cacheARC_BarCloseMarker != null)
				for (int idx = 0; idx < cacheARC_BarCloseMarker.Length; idx++)
					if (cacheARC_BarCloseMarker[idx] != null &&  cacheARC_BarCloseMarker[idx].EqualsInput(input))
						return cacheARC_BarCloseMarker[idx];
			return CacheIndicator<ARC.ARC_BarCloseMarker>(new ARC.ARC_BarCloseMarker(), input, ref cacheARC_BarCloseMarker);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_BarCloseMarker ARC_BarCloseMarker()
		{
			return indicator.ARC_BarCloseMarker(Input);
		}

		public Indicators.ARC.ARC_BarCloseMarker ARC_BarCloseMarker(ISeries<double> input )
		{
			return indicator.ARC_BarCloseMarker(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_BarCloseMarker ARC_BarCloseMarker()
		{
			return indicator.ARC_BarCloseMarker(Input);
		}

		public Indicators.ARC.ARC_BarCloseMarker ARC_BarCloseMarker(ISeries<double> input )
		{
			return indicator.ARC_BarCloseMarker(input);
		}
	}
}

#endregion
