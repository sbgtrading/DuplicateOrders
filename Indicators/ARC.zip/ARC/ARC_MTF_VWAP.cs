#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public enum ARC_MTF_VWAP_DayWeekMonth {Day,Week,Month}
	[CategoryOrder("Session", 1)]
    [CategoryOrder("Zone1", 10)]
    [CategoryOrder("Zone2", 20)]
    [CategoryOrder("Zone3", 30)]
    [CategoryOrder("Zone4", 35)]
    [CategoryOrder("Indicator Version", 40)]
	public class ARC_MTF_VWAP : Indicator
	{
		public string VERSION = "v1.1 Feb.1.2021";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }
		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "VWAP";
		bool IsDebug = false;

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "21238", "25900", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		double	iCumVolume			= 0;
		double	iCumTypicalVolume	= 0;
		double	iCumVolume1			= 0;
		double	iCumTypicalVolume1	= 0;
		int StartABar       = -1;
		int RegionStartABar = 0;
		private Series<int> Dir;
		private string tag  = "";
//		SMA sma             = null;
//		ATR atr             = null;
		private int FirstDayOfNewSession = -1;
		bool Z1Printable = true;
		bool Z2Printable = true;
		bool Z3Printable = true;
		bool Z4Printable = true;
		private Series<double> zoneID;
		
		private SortedDictionary<DateTime,double[]> HistoricalVwap = new SortedDictionary<DateTime,double[]>();//[0] is vwap, [1] is x (deviation from vwap), [2] is CumVol, [3] is CumTypicalVol
		private bool NeedBackgroundData = true;
        #region -- loadHistoricalBars --
        private Bars loadHistoricalBars(ARC_MTF_VWAP_DayWeekMonth TF)
        {
            //---- Prepa Bars Request ----
			DateTime now = DateTime.Now;
			var dtfrom = now.AddDays(TF == ARC_MTF_VWAP_DayWeekMonth.Day ? -4 :(TF == ARC_MTF_VWAP_DayWeekMonth.Week ? -8 : -30));
			if(TF == ARC_MTF_VWAP_DayWeekMonth.Month) dtfrom = new DateTime(now.Year,now.Month,1).AddDays(-3);
			if(dtfrom > BarsArray[0].GetTime(0)) {
				NeedBackgroundData = false;
				return null;
			}
            BarsRequest barsRequest = new BarsRequest(Bars.Instrument, dtfrom, now) { TradingHours = Bars.TradingHours, IsSplitAdjusted = false/*Bars.IsSplitAdjusted*/, IsDividendAdjusted = Bars.IsDividendAdjusted };
			int val = 5;
			if(BarsArray[0].BarsPeriod.BarsPeriodType==BarsPeriodType.Minute) val = BarsArray[0].BarsPeriod.Value;

			if(TF == ARC_MTF_VWAP_DayWeekMonth.Day){
	            barsRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, MarketDataType = Bars.BarsPeriod.MarketDataType, Value = val };
			}else if(TF == ARC_MTF_VWAP_DayWeekMonth.Week){
	            barsRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, MarketDataType = Bars.BarsPeriod.MarketDataType, Value = val };
			}else if(TF == ARC_MTF_VWAP_DayWeekMonth.Month){
	            barsRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, MarketDataType = Bars.BarsPeriod.MarketDataType, Value = val };
			}

            //---- Request the bars ----
            bool doWait = true;
            Bars retour = null;
            barsRequest.Request(new Action<BarsRequest, ErrorCode, string>((bars, errorCode, errorMessage) =>
            {
                if (errorCode != ErrorCode.NoError) { retour = null; doWait = false; return; }
                else if (bars.Bars == null || bars.Bars.Count == 0) { doWait = false; return; }
                retour = bars.Bars;
                doWait = false;
                return;
            }));
            while (doWait) { System.Threading.Thread.Sleep(10); }//made synchrone cause need request to finish before continuing
            return retour;
        }
        #endregion
		private bool SevereError = false;
        private Bars extraBars = null;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"";
				Name								= "ARC_MTF_VWAP";
				Calculate							= Calculate.OnPriceChange;
				IsOverlay							= true;
				DisplayInDataBox					= true;
				DrawOnPricePanel					= true;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
				PaintPriceMarkers					= true;
				IsAutoScale = false;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive			= true;
				pSessionStartTime = 1800;
				pBandPeriod = 30;
				pBandMult1 = 1.0;
				pBandMult2 = 2.0;
				pBandMult3 = 3.0;
				pBandMult4 = 4.0;
				Zone1Color		= Brushes.Green;
				Zone2Color		= Brushes.Red;
				Zone3Color		= Brushes.Blue;
				Zone4Color		= Brushes.Orange;
				Zone1OpacityBkg = 10;
				Zone2OpacityBkg = 10;
				Zone3OpacityBkg = 10;
				Zone4OpacityBkg = 10;
				pDayWeekMonth = ARC_MTF_VWAP_DayWeekMonth.Day;

				AddPlot(Brushes.Cyan, "PlotVWAP");
				AddPlot(Brushes.Maroon, "Upper");
				AddPlot(Brushes.DarkGreen, "Lower");
				AddPlot(Brushes.Yellow, "Upper2");
				AddPlot(Brushes.Yellow, "Lower2");
				AddPlot(Brushes.Blue, "Upper3");
				AddPlot(Brushes.Blue, "Lower3");
				AddPlot(Brushes.White,   "Upper4");
				AddPlot(Brushes.White,   "Lower4");

			}
			if(State == State.Configure){
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				zoneID    = new Series<double>(this);
				Dir = new Series<int>(this);
				if(Calculate == Calculate.OnEachTick) Calculate = Calculate.OnPriceChange;
			}

			if (State == State.DataLoaded)
			{
//ClearOutputWindow();
				Z1Printable = Zone1OpacityBkg>0 && Zone1Color.ToString() != Brushes.Transparent.ToString();
				Z2Printable = Zone2OpacityBkg>0 && Zone2Color.ToString() != Brushes.Transparent.ToString();
				Z3Printable = Zone3OpacityBkg>0 && Zone3Color.ToString() != Brushes.Transparent.ToString();
				Z4Printable = Zone4OpacityBkg>0 && Zone4Color.ToString() != Brushes.Transparent.ToString();
				var errorData = "Loading of background data is incomplete.\nAre you connected to your datafeed?  Try reloading historical data.";
				extraBars = loadHistoricalBars(this.pDayWeekMonth);//preload bars - sync code
				if (NeedBackgroundData && (extraBars == null || extraBars.Count <= 1))//if no historical data
				{
					Draw.TextFixed(this, "errortag", errorData, TextPosition.Center, Brushes.Red, new NinjaTrader.Gui.Tools.SimpleFont("Arial",14), Brushes.White, Brushes.White, 100);
					SevereError = true;
				}
				else if(extraBars!=null && extraBars.Count>0)
				{
					int start_abar = 0;
					int sT = pSessionStartTime*100;
					for(int abar = 1; abar < extraBars.Count-1; abar++){
						var dt0 = extraBars.GetTime(abar);
						var dt1 = extraBars.GetTime(abar-1);

						var t0 = ToTime(dt0);
						var t1 = ToTime(dt1);
//						if(t1 > t0) t1 = t1-240000;
						bool NewSession = false;
						if(pDayWeekMonth == ARC_MTF_VWAP_DayWeekMonth.Week){
							if(dt0.DayOfWeek < dt1.DayOfWeek || dt0.DayOfWeek == DayOfWeek.Sunday) {
								NewSession = true;
							}
						}else if(pDayWeekMonth == ARC_MTF_VWAP_DayWeekMonth.Month){
							if(dt0.Month != dt1.Month) {
								NewSession = true;
							}
						} else if(dt0.Day != FirstDayOfNewSession) {//daily
							if(t1<t0){//normally, the prior bar is of lower ToTime value than the current bar...except for when t0 is at or after midnight
								if(t1 <= sT && t0 > sT) {
//	Print("1  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
									FirstDayOfNewSession = dt0.Day;
									NewSession = true;
								}
								else if(t0 < t1 && t0 < sT) {
//	Print("2  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
									FirstDayOfNewSession = dt0.Day;
									NewSession = true;
								}
							}else if(t1!=t0){//example, if the prior bar is 2359 and the current bar is 0000.  If the two bars have a different time (sometimes Range bars have the same timestamp...these can be skipped
								if(sT > t1){
//	Print("3  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
									FirstDayOfNewSession = dt0.Day;
									NewSession = true;
								}
							}
						}

						if (NewSession)
						{
							start_abar = abar;
							iCumVolume = extraBars.GetVolume(abar);
							iCumTypicalVolume = extraBars.GetVolume(abar) * ((extraBars.GetHigh(abar) + extraBars.GetLow(abar) + extraBars.GetClose(abar)) / 3);
						}
						else
						{
							iCumVolume = iCumVolume + extraBars.GetVolume(abar);
							iCumTypicalVolume = iCumTypicalVolume + (extraBars.GetVolume(abar) * ((extraBars.GetHigh(abar) + extraBars.GetLow(abar) + extraBars.GetClose(abar)) / 3));
						}
						double vw = (iCumTypicalVolume / iCumVolume);
						if(!HistoricalVwap.ContainsKey(dt0)) HistoricalVwap[dt0] = new double[4]{0,0,0,0};
						HistoricalVwap[dt0][0] = vw;
						HistoricalVwap[dt0][2] = iCumVolume;
						HistoricalVwap[dt0][3] = iCumTypicalVolume;
						double diff = 0;
						double sumSq = 0;
						for(int i = abar; i>start_abar; i--){
							var tx = extraBars.GetTime(i);
							if(HistoricalVwap.ContainsKey(tx)) vw = HistoricalVwap[tx][0];
							diff = extraBars.GetClose(i)-vw;
							sumSq = sumSq + diff*diff;
						}
						HistoricalVwap[dt0][1] = Math.Sqrt(sumSq/Math.Max(1,abar-start_abar));
					}
				}
			}
		}
//==============================================================================================================================
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(SevereError) return;
			if(CurrentBars[0]<3) return;
			var dt0 = Times[0][0];
			var dt1 = Times[0][1];
			var t0 = ToTime(dt0);
			var t1 = ToTime(dt1);
//			if(t1 > t0) t1 = t1-240000;
			bool NewSession = false;
			if(pDayWeekMonth == ARC_MTF_VWAP_DayWeekMonth.Week){
				if(dt0.DayOfWeek < dt1.DayOfWeek || dt0.DayOfWeek == DayOfWeek.Sunday) {
					NewSession = true;
				}
			}else if(pDayWeekMonth == ARC_MTF_VWAP_DayWeekMonth.Month){
				if(dt0.Month != dt1.Month) {
					NewSession = true;
				}
			} else if(dt0.Day != FirstDayOfNewSession) {//daily, and the two bars have a different time (sometimes Range bars have the same timestamp...these can be skipped
				int sT = pSessionStartTime*100;
				if(t1<t0){//normally, the prior bar is of lower ToTime value than the current bar...except for when t0 is at or after midnight
					if(t1 <= sT && t0 > sT) {
//	Print("1  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
						FirstDayOfNewSession = dt0.Day;
						NewSession = true;
					}
					else if(t0 < t1 && t0 < sT) {
//	Print("2  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
						FirstDayOfNewSession = dt0.Day;
						NewSession = true;
					}
				}else if(t1!=t0){//example, if the prior bar is 2359 and the current bar is 0000.  If the two bars have a different time (sometimes Range bars have the same timestamp...these can be skipped
					if(sT > t1){
//	Print("3  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
						FirstDayOfNewSession = dt0.Day;
						NewSession = true;
					}
				}
			}

			if (NewSession)
			{
				if(CurrentBars[0]>0){
					for(int i = 0; i<Values.Length; i++)
						Values[i].Reset(1);
				}
				HistoricalVwap.Clear();
				StartABar = CurrentBars[0];
				iCumVolume = Volumes[0][0];
				iCumTypicalVolume = Volumes[0][0] * ((Highs[0][0] + Lows[0][0] + Closes[0][0]) / 3);
			}
			else
			{
				if(IsFirstTickOfBar){
					if(HistoricalVwap.Count>0 && HistoricalVwap.ContainsKey(Times[0][0])){
						iCumVolume1 = HistoricalVwap[Times[0][0]][2];
						iCumTypicalVolume1 = HistoricalVwap[Times[0][0]][3];
					}else{
						iCumVolume1 = iCumVolume;
						iCumTypicalVolume1 = iCumTypicalVolume;
					}
				}
				iCumVolume = iCumVolume1 + Volumes[0][0];
				iCumTypicalVolume = iCumTypicalVolume1 + (Volumes[0][0] * ((Highs[0][0] + Lows[0][0] + Closes[0][0]) / 3));
			}

			double x = double.MinValue;

			var keys = HistoricalVwap.Keys.Where(k=> k<=Times[0][0]);//.ToList();
			if(keys!=null && keys.Count()>0) {
				PlotVWAP[0] = HistoricalVwap[keys.Max()][0];
				x = HistoricalVwap[keys.Max()][1];
			}else{
				PlotVWAP[0] = (iCumTypicalVolume / iCumVolume);
				if(StartABar==-1) StartABar = CurrentBars[0];
				double diff = 0;
				if(x==double.MinValue)
				{
					double sumSq = 0;
					for(int i = CurrentBars[0]; i>StartABar; i--){
						diff  = Closes[0].GetValueAt(i)-PlotVWAP.GetValueAt(i);
						sumSq = sumSq + diff*diff;
					}
					x = Math.Sqrt(sumSq/Math.Max(1,CurrentBars[0]-StartABar));
				}
			}
			PlotUpper[0]  = PlotVWAP[0] + x * pBandMult1;
			PlotLower[0]  = PlotVWAP[0] - x * pBandMult1;
			PlotUpper2[0] = PlotVWAP[0] + x * pBandMult2;
			PlotLower2[0] = PlotVWAP[0] - x * pBandMult2;
			PlotUpper3[0] = PlotVWAP[0] + x * pBandMult3;
			PlotLower3[0] = PlotVWAP[0] - x * pBandMult3;
			PlotUpper4[0] = PlotVWAP[0] + x * pBandMult4;
			PlotLower4[0] = PlotVWAP[0] - x * pBandMult4;

			if(Closes[0][0] > PlotUpper3[0]) zoneID[0] = 4;
			else if(Closes[0][0] > PlotUpper2[0]) zoneID[0] = 3;
			else if(Closes[0][0] > PlotUpper[0]) zoneID[0] = 2;
			else if(Closes[0][0] > PlotVWAP[0]) zoneID[0] = 1;
			else if(Closes[0][0] > PlotLower[0]) zoneID[0] = -1;
			else if(Closes[0][0] > PlotLower2[0]) zoneID[0] = -2;
			else if(Closes[0][0] > PlotLower3[0]) zoneID[0] = -3;
			else zoneID[0] = -4;

//if(Closes[0][0] > PlotUpper[0]) sig = 1;
//if(Closes[0][0] < PlotLower[0]) sig = -1;
//bool UpBar = Closes[0][0]>Opens[0][0];
//if(Highs[0][0] >= PlotVWAP[0] && Lows[0][0] <= PlotVWAP[0]) sig = 1;
			if(pBandMult1>0 && Z1Printable){
//if(sig<0 && Closes[0][0] < Opens[0][0] && Highs[0][0] > PlotVWAP[0] && Highs[0][1] < PlotVWAP[0]) BackBrushes[0]=Brushes.Red;
//if(sig>0 && Closes[0][0] > Opens[0][0] && Lows[0][1] > PlotVWAP[0] && Lows[0][0] < PlotVWAP[0]) BackBrushes[0]=Brushes.Cyan;
//if(sig!=0 && Closes[0][0] < Opens[0][0] && Highs[0][0] < PlotVWAP[0]){ Draw.ArrowDown(this,CurrentBar.ToString(), false,0,Highs[0][0]+TickSize,Brushes.Red); sig = 0;}
//if(sig!=0 && Closes[0][0] > Opens[0][0] && Lows[0][0] > PlotVWAP[0]){ Draw.ArrowUp(this,CurrentBar.ToString(), false,0,Lows[0][0]-TickSize,Brushes.Cyan); sig = 0;}
				Draw.Region(this, "1", CurrentBars[0], 0, PlotUpper, PlotVWAP, Brushes.Transparent, Zone1Color, Zone1OpacityBkg);
				Draw.Region(this, "2", CurrentBars[0], 0, PlotLower, PlotVWAP, Brushes.Transparent, Zone1Color, Zone1OpacityBkg);
			}
			if(pBandMult2>0 && Z2Printable){
				Draw.Region(this, "3", CurrentBars[0], 0, PlotUpper2, PlotUpper, Brushes.Transparent, Zone2Color, Zone2OpacityBkg);
				Draw.Region(this, "4", CurrentBars[0], 0, PlotLower2, PlotLower, Brushes.Transparent, Zone2Color, Zone2OpacityBkg);
			}
			if(pBandMult3>0 && Z3Printable){
				Draw.Region(this, "5", CurrentBars[0], 0, PlotUpper3, PlotUpper2, Brushes.Transparent, Zone3Color, Zone3OpacityBkg);
				Draw.Region(this, "6", CurrentBars[0], 0, PlotLower3, PlotLower2, Brushes.Transparent, Zone3Color, Zone3OpacityBkg);
			}
			if(pBandMult4>0 && Z4Printable){
				Draw.Region(this, "7", CurrentBars[0], 0, PlotUpper4, PlotUpper3, Brushes.Transparent, Zone4Color, Zone4OpacityBkg);
				Draw.Region(this, "8", CurrentBars[0], 0, PlotLower4, PlotLower3, Brushes.Transparent, Zone4Color, Zone4OpacityBkg);
			}
//if(!UpBar && Lows[0][1] > PlotUpper[1] && Lows[0][0] < PlotUpper[0]){ Draw.ArrowDown(this,CurrentBar.ToString(), false,0,Highs[0][0]+TickSize,Brushes.Red);}
//if(UpBar && Highs[0][1] < PlotLower[1] && Highs[0][0] > PlotLower[0]){ Draw.ArrowUp(this,CurrentBar.ToString(), false,0,Lows[0][0]-TickSize,Brushes.Cyan);}
//if(!UpBar && Lows[0][1] > PlotUpper2[1] && Lows[0][0] < PlotUpper2[0]){ Draw.ArrowDown(this,CurrentBar.ToString(), false,0,Highs[0][0]+TickSize,Brushes.Red);}
//if(UpBar && Highs[0][1] < PlotLower2[1] && Highs[0][0] > PlotLower2[0]){ Draw.ArrowUp(this,CurrentBar.ToString(), false,0,Lows[0][0]-TickSize,Brushes.Cyan);}
//if(!UpBar && Lows[0][1] > PlotUpper3[1] && Lows[0][0] < PlotUpper3[0]){ Draw.ArrowDown(this,CurrentBar.ToString(), false,0,Highs[0][0]+TickSize,Brushes.Red);}
//if(UpBar && Highs[0][1] < PlotLower3[1] && Highs[0][0] > PlotLower3[0]){ Draw.ArrowUp(this,CurrentBar.ToString(), false,0,Lows[0][0]-TickSize,Brushes.Cyan);}
		}
		private int sig = 0;
//==========================================================================================================================
		#region Properties
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bkg color", GroupName = "Zone1", Description = "Background color for up-trending condition", Order = 10)]
		public Brush Zone1Color { get; set; }
					[Browsable(false)]
					public string Zone1ColorSerialize
					{get { return Serialize.BrushToString(Zone1Color); }
			                                        set { Zone1Color = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Opacity", GroupName = "Zone1", Description = "Opacity, 0=transparent, 100=opaque", Order = 20)]
		public int Zone1OpacityBkg { get; set; }

		[Range(0.0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Deviation mult", GroupName = "Zone1", Order = 30)]
		public double pBandMult1
		{ get; set; }


		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bkg color", GroupName = "Zone2", Description = "Background color", Order = 30)]
		public Brush Zone2Color { get; set; }
					[Browsable(false)]
					public string Zone2ColorSerialize
					{get { return Serialize.BrushToString(Zone2Color); }
			                                        set { Zone2Color = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Opacity", GroupName = "Zone2", Description = "Opacity, 0=transparent, 100=opaque", Order = 40)]
		public int Zone2OpacityBkg { get; set; }

		[Range(0.0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Deviation mult", GroupName = "Zone2", Order = 50)]
		public double pBandMult2
		{ get; set; }

		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bkg color", GroupName = "Zone3", Description = "Background color", Order = 60)]
		public Brush Zone3Color { get; set; }
					[Browsable(false)]
					public string Zone3ColorSerialize
					{get { return Serialize.BrushToString(Zone3Color); }
			                                        set { Zone3Color = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Opacity", GroupName = "Zone3", Description = "Opacity of the down-trend background color", Order = 70)]
		public int Zone3OpacityBkg { get; set; }

		[Range(0.0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Deviation mult", GroupName = "Zone3", Order = 80)]
		public double pBandMult3
		{ get; set; }

		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bkg color", GroupName = "Zone4", Description = "Background color", Order = 60)]
		public Brush Zone4Color { get; set; }
					[Browsable(false)]
					public string Zone4ColorSerialize
					{get { return Serialize.BrushToString(Zone4Color); }
			                                        set { Zone4Color = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Opacity", GroupName = "Zone4", Description = "Opacity of the down-trend background color", Order = 70)]
		public int Zone4OpacityBkg { get; set; }

		[Range(0.0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Deviation mult", GroupName = "Zone4", Order = 80)]
		public double pBandMult4
		{ get; set; }


		#region -- Parameters --
		[Display(ResourceType = typeof(Custom.Resource), Name = "Day/Week/Month", GroupName = "Session", Order = 5)]
		public ARC_MTF_VWAP_DayWeekMonth pDayWeekMonth		{ get; set; }

		[Range(1, 2359), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Session Start", GroupName = "Session", Order = 10)]
		public int pSessionStartTime		{ get; set; }

		private int pBandPeriod = 20;
//		[Range(1, int.MaxValue), NinjaScriptProperty]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Band Period", GroupName = "NinjaScriptParameters", Order = 20)]
//		public int pBandPeriod
//		{ get; set; }

		#endregion

		#endregion

		#region Plots
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotVWAP
		{
			get { return Values[0]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotUpper
		{
			get { return Values[1]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotLower
		{
			get { return Values[2]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotUpper2
		{
			get { return Values[3]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotLower2
		{
			get { return Values[4]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotUpper3
		{
			get { return Values[5]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotLower3
		{
			get { return Values[6]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotUpper4
		{
			get { return Values[7]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotLower4
		{
			get { return Values[8]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ZoneID
		{
			get { Update();
				return zoneID; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_MTF_VWAP[] cacheARC_MTF_VWAP;
		public ARC.ARC_MTF_VWAP ARC_MTF_VWAP(double pBandMult1, double pBandMult2, double pBandMult3, double pBandMult4, int pSessionStartTime)
		{
			return ARC_MTF_VWAP(Input, pBandMult1, pBandMult2, pBandMult3, pBandMult4, pSessionStartTime);
		}

		public ARC.ARC_MTF_VWAP ARC_MTF_VWAP(ISeries<double> input, double pBandMult1, double pBandMult2, double pBandMult3, double pBandMult4, int pSessionStartTime)
		{
			if (cacheARC_MTF_VWAP != null)
				for (int idx = 0; idx < cacheARC_MTF_VWAP.Length; idx++)
					if (cacheARC_MTF_VWAP[idx] != null && cacheARC_MTF_VWAP[idx].pBandMult1 == pBandMult1 && cacheARC_MTF_VWAP[idx].pBandMult2 == pBandMult2 && cacheARC_MTF_VWAP[idx].pBandMult3 == pBandMult3 && cacheARC_MTF_VWAP[idx].pBandMult4 == pBandMult4 && cacheARC_MTF_VWAP[idx].pSessionStartTime == pSessionStartTime && cacheARC_MTF_VWAP[idx].EqualsInput(input))
						return cacheARC_MTF_VWAP[idx];
			return CacheIndicator<ARC.ARC_MTF_VWAP>(new ARC.ARC_MTF_VWAP(){ pBandMult1 = pBandMult1, pBandMult2 = pBandMult2, pBandMult3 = pBandMult3, pBandMult4 = pBandMult4, pSessionStartTime = pSessionStartTime }, input, ref cacheARC_MTF_VWAP);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_MTF_VWAP ARC_MTF_VWAP(double pBandMult1, double pBandMult2, double pBandMult3, double pBandMult4, int pSessionStartTime)
		{
			return indicator.ARC_MTF_VWAP(Input, pBandMult1, pBandMult2, pBandMult3, pBandMult4, pSessionStartTime);
		}

		public Indicators.ARC.ARC_MTF_VWAP ARC_MTF_VWAP(ISeries<double> input , double pBandMult1, double pBandMult2, double pBandMult3, double pBandMult4, int pSessionStartTime)
		{
			return indicator.ARC_MTF_VWAP(input, pBandMult1, pBandMult2, pBandMult3, pBandMult4, pSessionStartTime);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_MTF_VWAP ARC_MTF_VWAP(double pBandMult1, double pBandMult2, double pBandMult3, double pBandMult4, int pSessionStartTime)
		{
			return indicator.ARC_MTF_VWAP(Input, pBandMult1, pBandMult2, pBandMult3, pBandMult4, pSessionStartTime);
		}

		public Indicators.ARC.ARC_MTF_VWAP ARC_MTF_VWAP(ISeries<double> input , double pBandMult1, double pBandMult2, double pBandMult3, double pBandMult4, int pSessionStartTime)
		{
			return indicator.ARC_MTF_VWAP(input, pBandMult1, pBandMult2, pBandMult3, pBandMult4, pSessionStartTime);
		}
	}
}

#endregion
