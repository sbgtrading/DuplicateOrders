#define DoLicense
#define MODERATORS

#region Using declarations

using NinjaTrader.Core;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using System.Xml.Serialization;
using Brush = SharpDX.Direct2D1.Brush;
using TextAlignment = SharpDX.DirectWrite.TextAlignment;

#endregion

#region -- public enums --
public enum ARC_SMC_Mapping
{
    Candle_Close,
    Candle_Wick
}
public enum ARC_SMC_SupplyDemandType
{
    Candle,
    Wick
}

public enum ARC_SMC_FibonacciType
{
    Normal,
    Cluster
}

public enum ARC_SMC_PullbackMode
{
    ATR,
    Percentage,
    Ticks
}
public enum ARC_SMC_DisplayType
{
    None,
    LineOnly,
    Text,
    TextAndTimeFrame
}

public enum ARC_SMC_SDBroken
{
    Wick,
    Close,
    PremiumDiscount
}

public enum ARC_SMC_SupplyDemandDisplayType
{
    None,
    Bos,
    ChoCh,
    Both
}

public enum ARC_SMC_TrendPosition
{
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight
}
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{

    [TypeConverter("NinjaTrader.NinjaScript.Indicators.ARC.ARC_SMC_Converter")]
    public class ARC_SMC : Indicator
    {
		private const string VERSION = "v1.09 24.Oct.2022";
		[Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
		public string indicatorVersion { get { return VERSION; } }

		//these variables are for DoLicense enabled
		static bool IsDebug        = false;
		private bool ValidLicense  = false;
		private bool IsExpired     = true;
		private bool LicenseChecked = false;
		private string UserId       = string.Empty;
		private string MachineId    = string.Empty;
		string ModuleName = "SMC";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "21042", "25900", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion


		private static readonly Action EmptyDelegate = delegate { };
        private readonly List<SwingPivot> _allPivots = new List<SwingPivot>();
        private readonly List<PriceBreak> _bos = new List<PriceBreak>();
        private readonly List<PriceBreak> _chocs = new List<PriceBreak>();
        private readonly List<SwingPivot> _hiPivots = new List<SwingPivot>();
        private readonly List<SwingPivot> _lowPivots = new List<SwingPivot>();
        private readonly List<SupplyDemandZone> _zones = new List<SupplyDemandZone>();

        // supply/demand
        private readonly List<SupplyDemandZone> _supplyDemandZones = new List<SupplyDemandZone>();

        private DateTime _currentTime;
        private int _internalHiBar;
        private double _internalHiPrice;
        private DateTime _internalHiTime;
        private int _internalLowBar;

        private double _currentClosePrice, _currentLowPrice, _currentHighPrice;
        private double _internalLowPrice;
        private DateTime _internalLowTime;
        private int _prevAlertBar;
        private int _prevBarBOS;
        private int _prevBarSwing;
        private int _state;
        private SwingPivot _swingHi = new SwingPivot { Price = double.MinValue, IsLow = false, Label = "HH" };
        private int _swingHighBar;
        private double _swingHighPrice;
        private DateTime _swingHighTime;
        private SwingPivot _swingLow = new SwingPivot { Price = double.MaxValue, IsLow = true, Label = "LL" };
        private int _swingLowBar;
        private double _swingLowPrice;
        private DateTime _swingLowTime;
        private int _prevBar;
        private DateTime _now;

        private string _tradingHoursSerializable = string.Empty;
		private StructureBiasClass StructureMgr = null;
		private class StructureBiasClass {
			private const double UP = 1;
			private const double DOWN = -1;
			#region  ----- StructureBias class ----- 
			public SortedDictionary<int,double[]>	AllPivots     = new SortedDictionary<int,double[]>();//one record for each pivot bar.  The first double is the initial swing price, and if there's a final swing price on that bar, the 2nd double will hold that price
			//public SortedDictionary<int,byte>	Bias = new SortedDictionary<int,byte>();
			public int    SwingStrength = 0;
			public bool   isHLBased     = false;
			public double ExtentOfMove = double.NaN;
			public bool   CalculateOnBarClose = false;
			public string StatusMsg = string.Empty;
			public bool z=false;

			#region  ----- properties ----- 
			public SortedDictionary<int, char> Trend = new SortedDictionary<int,char>();
			private NinjaTrader.NinjaScript.IndicatorBase Parent;
			private bool updateHigh=false;
			private bool updateLow=false;
			private bool addHigh=false;
			private bool addLow=false;
			private int offset = 0;
			private ISeries<double> High;
			private ISeries<double> Low;
//			private ISeries<double> Close;
			#endregion

			private double MAX(ISeries<double> series, int lookback, int rbar_offset){
				double max = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) {
						if(i>=series.Count) return max;
						if(i < series.Count)
							max = Math.Max(max, series[i]);
					}
				}catch{}
				return max;
			}
			private double MIN(ISeries<double> series, int lookback, int rbar_offset){
				double min = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) {
						if(i>=series.Count) return min;
						if(i < series.Count)
							min = Math.Min(min, series[i]);
					}
				}catch{}
				return min;
			}
			public void AddToAllPivots(int idx, char current_trend, char new_trend, double price1, double price2=double.NaN){
				if(AllPivots.Count==0) {
					AllPivots[idx] = new double[]{UP, price1, price2};
					return;
				}

				bool IsOutsideBar = double.IsNaN(price2)==false;
				bool IsPriorBarOutside = double.IsNaN(AllPivots.Last().Value[2])==false;//if the prior bar was an outside bar
				double priorleadprice = IsPriorBarOutside ? AllPivots.Last().Value[2] : AllPivots.Last().Value[1];
				double newleadprice = IsOutsideBar ? price2 : price1;
//if(z) Parent.Print("AddToAllPivots:   current_trend: "+current_trend+"  new_trend: "+new_trend);

//if(z) Parent.Print("a AddToAllPivots:   priorleadprice: "+priorleadprice+"  new leadprice: "+newleadprice);
				if(current_trend=='u' && new_trend=='u'){
// TREND CONTINUATION conditions
					if(!IsOutsideBar && newleadprice < priorleadprice) return;//outside bars are interior trend reversals, you must respect the lower low
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
//if(z) Parent.Print("b AddToAllPivots:   PriorBarOutside and current bar outside - adding new swing bar UP");
						AllPivots[idx] = new double[]{UP, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
//if(z) Parent.Print("c AddToAllPivots:   not PriorBarOutside and current bar outside - adding new swing bar UP");
						AllPivots[idx] = new double[]{UP, price1, price2};
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
//if(z) Parent.Print("d AddToAllPivots:   not PriorBarOutside and not current bar outside - removing prior swing bar, adding new swing bar UP");
						var remove_idx = AllPivots.Keys.Max();
						AllPivots.Remove(remove_idx);//a trend continuation is taking place, the prior bar is no longer the max extent of the original trend...so remove it
//						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[idx] = new double[]{UP, price1, price2};
					}else if(IsPriorBarOutside && !IsOutsideBar){
//if(z) Parent.Print("e AddToAllPivots:   PriorBarOutside and not current bar outside - update prior swing bar leading price, adding new swing bar UP");
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[idx] = new double[]{UP, price1, price2};
					}
					else{
//if(z) Parent.Print("f AddToAllPivots:   else - update prior swing bar leading price, adding new swing bar UP");
						AllPivots[idx] = new double[]{UP, price1, price2};
					}

				}else if(current_trend=='d' && new_trend=='d'){
// TREND CONTINUATION conditions
					if(!IsOutsideBar && newleadprice > priorleadprice) return;//outside bars are interior trend reversals, you must respect the higher high
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
//if(z) Parent.Print("b AddToAllPivots:   PriorBarOutside and current bar outside - adding new swing bar DOWN");
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
//if(z) Parent.Print("c AddToAllPivots:   not PriorBarOutside and current bar outside - adding new swing bar DOWN");
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
//if(z) Parent.Print("d AddToAllPivots:   not PriorBarOutside and not current bar outside - removing prior swing bar, adding new swing bar DOWN");
						var remove_idx = AllPivots.Keys.Max();
						AllPivots.Remove(remove_idx);//a trend continuation is taking place, the prior bar is no longer the max extent of the original trend...so remove it
//						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
					else if(IsPriorBarOutside && !IsOutsideBar){
//if(z) Parent.Print("e AddToAllPivots:   PriorBarOutside and not current bar outside - update prior swing bar leading price, adding new swing bar DOWN");
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
					else{
//if(z) Parent.Print("f AddToAllPivots:   else - update prior swing bar leading price, adding new swing bar DOWN");
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
				}else if(current_trend=='d' && new_trend=='u'){//trend reversal occurred from down to up
// TREND REVERSAL conditions
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
//if(z) Parent.Print("ud w AddToAllPivots:   PriorBarOutside and current bar outside - blank out prior ending price, adding new swing bar UP");
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a lower low trend extending price is found on this new outside bar
						AllPivots[idx] = new double[]{UP, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
						if(price1 <= priorleadprice){
//if(z) Parent.Print("du x AddToAllPivots:   Not PriorBarOutside and current bar outside, yes new low made - adding new swing bar UP");
							var remove_idx = AllPivots.Keys.Max();
							AllPivots.Remove(remove_idx);
							AllPivots[idx] = new double[]{UP, price1, price2};
						}else{
//if(z) Parent.Print("du x AddToAllPivots:   Not PriorBarOutside and current bar outside, no new low made - ignoring low of current outside bar, adding new swing bar DOWN");
							AllPivots[idx] = new double[]{UP, price2, double.NaN};
						}
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
						AllPivots[idx] = new double[]{UP, price1, price2};
					}else
						AllPivots[idx] = new double[]{UP, price1, price2};

				}else if(current_trend=='u' && new_trend=='d'){//trend reversal occurred from up to down
// TREND REVERSAL conditions
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
//if(z) Parent.Print("ud w AddToAllPivots:   PriorBarOutside and current bar outside - blank out prior ending price, adding new swing bar DOWN");
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher high trend extending price is found on this new outside bar
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
						if(price1 >= priorleadprice){
//if(z) Parent.Print("ud x AddToAllPivots:   Not PriorBarOutside and current bar outside, yes new high made - adding new swing bar DOWN");
							var remove_idx = AllPivots.Keys.Max();
							AllPivots.Remove(remove_idx);//a trend reversal is taking place on an outside bar, the prior bar is no longer the max extent of the original trend...so remove it
							AllPivots[idx] = new double[]{DOWN, price1, price2};
						}else{
//if(z) Parent.Print("ud x AddToAllPivots:   Not PriorBarOutside and current bar outside, no new high made - ignoring high of current outside bar, adding new swing bar DOWN");
							AllPivots[idx] = new double[]{DOWN, price2, double.NaN};
						}
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
//if(z) Parent.Print("ud y AddToAllPivots:   Not PriorBarOutside and Not current bar outside - adding new swing bar DOWN");
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}else{
//if(z) Parent.Print("ud z AddToAllPivots:   else - adding new swing bar DOWN");
						AllPivots[idx] = new double[]{DOWN, price1, price2};
					}
//if(z) Parent.Print("AddToAllPivots:   New low is put in...deleted the prior swing point, added a new point");
				}
//				var AllPivotsKeys  = new List<int>(AllPivots.Keys);
//				AllPivotsKeys.Reverse();
//				#region Clean up swings when consecutive swings are lows or highs
//				if(false && AllPivots.Count>4){
//					var keysToRemove = new List<int>();
//					if(Trend[idx] == Trend[idx-1]){
//						keysToRemove.Add(idx-1);
//					}
////					for(int i =0; i<3; i++){
////						if(AllPivots[AllPivotsKeys[i]] < 0 && AllPivots[AllPivotsKeys[i+1]] < 0)
////							keysToRemove.Add(AllPivotsKeys[i+1]);
////						else if(AllPivots[AllPivotsKeys[i]] > 0 && AllPivots[AllPivotsKeys[i+1]] > 0)
////							keysToRemove.Add(AllPivotsKeys[i+1]);
////					}
//					if(keysToRemove.Count>0){
//						foreach(int key in keysToRemove){
//							if(AllPivots.ContainsKey(key)) AllPivots.Remove(key);
//						}
////						AllPivotsKeys  = new List<int>(AllPivots.Keys);
////						AllPivotsKeys.Reverse();
//					}
//				}
//				#endregion
//				IsRising = price<0;//if we put in a new swing low, then structure is rising, a new swing high means structure is falling
			}
			public StructureBiasClass(ISeries<double> high, ISeries<double> low, int swingStrength, bool is_hlBased, bool calcOnBarClose, NinjaTrader.NinjaScript.IndicatorBase parent){
				High = high;
				Low = low;
				SwingStrength = swingStrength;
				isHLBased = isHLBased; 
				CalculateOnBarClose = calcOnBarClose; 
				offset = calcOnBarClose ? 0 : 1;
				High   = high; Low = low;
				Parent = parent;
			}


			public void CalculateIt(int CurrentBar, bool IsUpClosing, bool IsFirstTickOfBar, NinjaTrader.NinjaScript.Calculate Calculate, NinjaTrader.NinjaScript.State State, double? atr256=0){
				int bar  = CurrentBar-offset;
//if(z) Parent.Print(Parent.Time.GetValueAt(CurrentBar).ToString()+"  CalculateIt");
				if(Trend.Count==0){
					if(High[offset]>High[offset+1])    {Trend[bar] ='u'; AllPivots.Add(bar, new double[3]{UP, High[offset], double.NaN}); ExtentOfMove=High[offset];}
					else if(Low[offset]<Low[offset+1]) {Trend[bar] ='d'; AllPivots.Add(bar, new double[3]{DOWN, Low[offset],double.NaN}); ExtentOfMove=Low[offset];}
					return;
				}

				double H = MAX(High, SwingStrength, offset+1);
				double L = MIN(Low,  SwingStrength, offset+1);
				if(High[offset]>H && Low[offset]<L)	Trend[bar] ='?';//this is an outside bar...meaning the trend reversal occurs on the same bar
				else if(High[offset]>H)				Trend[bar] ='u';
				else if(Low[offset]<L)				Trend[bar] ='d';
				else								Trend[bar] = Trend[bar-1];
//if(z) Parent.Print("  Trend: "+Trend[bar]);
int line = 1204;
				int i = 1;
				char current_trend = Trend[bar-i];
				if(Trend[bar] == '?'){
					if(IsUpClosing){//an upclosing outside bar
						Trend[bar] = 'u';
						if(Trend[bar-i] == 'u'){//if the most recent trend was Up
							AddToAllPivots(bar, 'u', 'u', Low[offset], High[offset]);//in an uptrend, the outside bar reversal down is first, and the upward finish is second
						}else{//existing trend was down
							AddToAllPivots(bar, 'd', 'u', Low[offset], High[offset]);//in a downtrend, the down move continued, and the upward finish is second
						}
					}else{//a downclosing outside bar
						Trend[bar] = 'd';
						if(Trend[bar-i] == 'd'){//if the most recent trend was Down
							AddToAllPivots(bar, 'd', 'd', High[offset], Low[offset]);//in a downtrend, the outside bar reversal up is first, and the downward finish is second
						}else{//existing trend was up
							AddToAllPivots(bar, 'u', 'd', High[offset], Low[offset]);//in an uptrend, the up move continued, and the downward finish is second
						}
					}
//}catch(Exception ee){parent.Print(line+":  "+ee.ToString());}
				}
				else if(Trend[bar] == 'u'){
					AddToAllPivots(bar, current_trend, 'u', High[offset]);
				}
				else if(Trend[bar] == 'd'){
					AddToAllPivots(bar, current_trend, 'd', Low[offset]);
				}
				
				}

			//================================================================================================
			public void UpdateSessionDate(DateTime t, double high, double low, SessionIterator sessionIterator0){
//				DateTime currentDate = SessionDate.Date;
//				if(sessionIterator0 == null)
//					SessionDate = t.Date;
//				else if(sessionIterator0.IsNewSession(t, true)) {
//					sessionIterator0.CalculateTradingDay(t, true);
//					SessionDate = sessionIterator0.ActualTradingDayExchange.Date;
//				}
			}
			#endregion
		}
        // swing hi/lo
        private bool _warmUpPhase = true;

        #region pull down menu
        private string toolbarname = "MarketStrcutureUI_TB", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private Grid indytoolbar;
        private Menu MenuControlContainer;
        private MenuItem MenuControl;
        private MenuItem miShowSwingHiLo;
        private MenuItem miShowHHLL;
        private MenuItem miBosDisplayType;
        private MenuItem miBosStructureMapping;
        private MenuItem miRecalculate1;
        private TextBox tb_NumberOfBOSToDisplay;
        private Label lbl_NumberOfBOSToDisplay;
        private MenuItem miPullbackDetectionType;
        private TextBox tb_ATRPeriod;
        private Label lbl_ATRPeriod;
        private TextBox tb_ATRMultiplier;
        private Label lbl_ATRMultiplier;
        private TextBox tb_Ticks;
        private Label lbl_Ticks;
        private TextBox tb_Percentage;
        private Label lbl_Percentage;
        private MenuItem miShowInternalHiLo;
        private MenuItem miChoChDisplayType;
        private MenuItem miChoChStructureMapping;
        private TextBox tb_NumberOfChoChToDisplay;
        private Label lbl_NumberOfChoChToDisplay;
        private MenuItem miShowFibRetracements;
        private MenuItem miShowFibNumbers;
        private Grid gridBos;
        private Grid gridCHoch;
        private MenuItem miGridTrend;
        private MenuItem miGridMTF;
        private MenuItem migridBos;
        private MenuItem migridCHoch;

        private MenuItem miShowSDZones;
        private MenuItem miHideBrokenSDZones;
        private TextBox tb_NumberOfSDZonesToDisplay;
        private Label lbl_NumberOfSDZonesToDisplay;
        private Grid gridSDZonesToDisplay;
        private MenuItem miSDZonesToDisplay;
        private MenuItem miSupplyDemandType;
        private MenuItem miSupplyDemandBreakType;

        private MenuItem miUseMTF;
        private MenuItem miMTFBarPeriodPeriodType;
        private MenuItem miFibDisplayType;
        private Grid gridMTF;
        private Label lbl_MTFBarsToLoad;
        private TextBox tb_MTFBarsToLoad;
        private Label lbl_MTFBarPeriod;
        private TextBox tb_MTFBarPeriod;
        private MenuItem miShowTrend;
        private Grid gridTrend;
        private Label lbl_TrendBosCount;
        private TextBox tb_TrendBosCount;
        private Label lbl_TrendXCoordinate;
        private TextBox tb_TrendXCoordinate;
        private Label lbl_TrendYCoordinate;
        private TextBox tb_TrendYCoordinate;
        private MenuItem mi_TrendPosition;
        private MenuItem miPaintBars;
		private TextBox tb_SwingStrength;

        #endregion

        private string _MTFLabel { get; set; }

        #region toolbar
        private void ShowPullbackModeControls()
        {
            lbl_ATRPeriod.Visibility = BOSPullBackType == ARC_SMC_PullbackMode.ATR ? Visibility.Visible : Visibility.Hidden;
            tb_ATRPeriod.Visibility = BOSPullBackType == ARC_SMC_PullbackMode.ATR ? Visibility.Visible : Visibility.Hidden;
            lbl_ATRMultiplier.Visibility = BOSPullBackType == ARC_SMC_PullbackMode.ATR ? Visibility.Visible : Visibility.Hidden;
            tb_ATRMultiplier.Visibility = BOSPullBackType == ARC_SMC_PullbackMode.ATR ? Visibility.Visible : Visibility.Hidden;
            lbl_Ticks.Visibility = BOSPullBackType == ARC_SMC_PullbackMode.Ticks ? Visibility.Visible : Visibility.Hidden;
            tb_Ticks.Visibility = BOSPullBackType == ARC_SMC_PullbackMode.Ticks ? Visibility.Visible : Visibility.Hidden;
            lbl_Percentage.Visibility = BOSPullBackType == ARC_SMC_PullbackMode.Percentage ? Visibility.Visible : Visibility.Hidden;
            tb_Percentage.Visibility = BOSPullBackType == ARC_SMC_PullbackMode.Percentage ? Visibility.Visible : Visibility.Hidden;
        }
        private void addToolBar()
        {
            int rHeight = 30;
            MenuControlContainer = new Menu { Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Center };
            MenuControl = new MenuItem
            {
                BorderThickness = new Thickness(2),
                Header = ButtonText,
                BorderBrush = Brushes.Yellow,
                Foreground = Brushes.Yellow,
                Background = Brushes.MediumBlue,
                VerticalAlignment = VerticalAlignment.Stretch,
                FontWeight = FontWeights.Bold,
                FontSize = 13
            };
            MenuControlContainer.Items.Add(MenuControl);

            #region Show trend
            miShowTrend = new MenuItem { Header = "Show Trend: " + (ShowTrend ? "ON" : "OFF"), Name = "ShowTrend" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true, IsCheckable = true, IsChecked = ShowTrend };
            miShowTrend.Click += delegate (object o, RoutedEventArgs e)
            {
                ShowTrend = !ShowTrend;

                this.miGridTrend.Visibility = this.ShowTrend ? Visibility.Visible : Visibility.Collapsed;
                miPaintBars.Visibility = this.ShowTrend ? Visibility.Visible : Visibility.Collapsed;
                mi_TrendPosition.Visibility = this.ShowTrend ? Visibility.Visible : Visibility.Collapsed;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miShowTrend.Header = "Show Trend: " + (ShowTrend ? "ON" : "OFF");
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miShowTrend.Header = "Show Trend: " + (ShowTrend ? "ON" : "OFF");
                            ForceRefresh();
                        }));
                    }
                }
            };
            miShowTrend.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                ShowTrend = !ShowTrend;
                miPaintBars.Visibility = this.ShowTrend ? Visibility.Visible : Visibility.Collapsed;
                mi_TrendPosition.Visibility = this.ShowTrend ? Visibility.Visible : Visibility.Collapsed;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miShowTrend.Header = "Show Trend: " + (ShowTrend ? "ON" : "OFF");
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miShowTrend.Header = "Show Trend: " + (ShowTrend ? "ON" : "OFF");
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(miShowTrend);
            #endregion

			#region -- Swing Lines --
			MenuItem miSwingLines = new MenuItem { Header = "Swing Lines", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miMarketSwingLines = new MenuItem { Header = pShowSwingLines ? "Swing Lines ON" : "Swing Lines OFF", Name = "miMarketSwingLines"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(!pShowSwingLines) miMarketSwingLines.FontWeight = FontWeights.Light;
			miMarketSwingLines.Click += structureMenuItem_Click;
			miSwingLines.Items.Add(miMarketSwingLines);

			MenuItem miShowSwingLabels = new MenuItem { Header = pShowSwingLabels ? "Swing Labels ON" : "Swing Labels OFF", Name = "miShowSwingLabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(!pShowSwingLabels) miShowSwingLabels.FontWeight = FontWeights.Light;
			miShowSwingLabels.Click += structureMenuItem_Click;
			miSwingLines.Items.Add(miShowSwingLabels);

			miSwingLines.Items.Add(new Separator());
			miSwingLines.Items.Add(createMktStructure_Menu(this.pSwingStrength.ToString(), "", ""));

			MenuControl.Items.Add(miSwingLines);
			#endregion

            #region Trend position
            mi_TrendPosition = new MenuItem { Header = "Trend position: " + TrendPosition.ToString(), Name = "mi_TrendPosition" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            mi_TrendPosition.Click += delegate (object o, RoutedEventArgs e)
            {
                if (TrendPosition == ARC_SMC_TrendPosition.TopLeft)
                    TrendPosition = ARC_SMC_TrendPosition.TopRight;
                else if (TrendPosition == ARC_SMC_TrendPosition.TopRight)
                    TrendPosition = ARC_SMC_TrendPosition.BottomLeft;
                else if (TrendPosition == ARC_SMC_TrendPosition.BottomLeft)
                    TrendPosition = ARC_SMC_TrendPosition.BottomRight;
                else if (TrendPosition == ARC_SMC_TrendPosition.BottomRight)
                    TrendPosition = ARC_SMC_TrendPosition.TopLeft;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        mi_TrendPosition.Header = "Trend position: " + TrendPosition.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            mi_TrendPosition.Header = "Trend position: " + TrendPosition.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            mi_TrendPosition.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                if (TrendPosition == ARC_SMC_TrendPosition.TopLeft)
                    TrendPosition = ARC_SMC_TrendPosition.TopRight;
                else if (TrendPosition == ARC_SMC_TrendPosition.TopRight)
                    TrendPosition = ARC_SMC_TrendPosition.BottomLeft;
                else if (TrendPosition == ARC_SMC_TrendPosition.BottomLeft)
                    TrendPosition = ARC_SMC_TrendPosition.BottomRight;
                else if (TrendPosition == ARC_SMC_TrendPosition.BottomRight)
                    TrendPosition = ARC_SMC_TrendPosition.TopLeft;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        mi_TrendPosition.Header = "Trend position: " + TrendPosition.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            mi_TrendPosition.Header = "Trend position: " + TrendPosition.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(mi_TrendPosition);
            this.mi_TrendPosition.Visibility = this.ShowTrend ? Visibility.Visible : Visibility.Collapsed;
            #endregion

            #region Trend Bars
            miPaintBars = new MenuItem { Header = "Show Trend bars: " + (PaintBars ? "ON" : "OFF"), Name = "ShowTrendBars" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.PaintBars, StaysOpenOnClick = true };
            miPaintBars.Click += delegate (object o, RoutedEventArgs e)
            {
                this.PaintBars = !this.PaintBars;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miPaintBars.IsChecked = PaintBars;
                        miPaintBars.Header = "Show Trend bars: " + (PaintBars ? "ON" : "OFF");
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miPaintBars.IsChecked = PaintBars;
                            miPaintBars.Header = "Show Trend barsLL: " + (PaintBars ? "ON" : "OFF");
                            ForceRefresh();
                        }));
                    }
                }
            };
            MenuControl.Items.Add(miPaintBars);
            miPaintBars.Visibility = this.ShowTrend ? Visibility.Visible : Visibility.Collapsed;
            #endregion

            #region Number of BOS needed for a trend change

            int row = 0;
            gridTrend = new Grid();
            gridTrend.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            gridTrend.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
            gridTrend.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
            lbl_TrendBosCount = new Label() { Name = "lbl_BOSCOunttrendchange" + uID, Content = "Number of BOS needed for trend change ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_TrendBosCount.SetValue(Grid.ColumnProperty, 0);
            lbl_TrendBosCount.SetValue(Grid.RowProperty, row);

            tb_TrendBosCount = new TextBox() { Name = "lbl_MTFBarsLoad" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_TrendBosCount.Text = TrendBosCount.ToString();
            tb_TrendBosCount.KeyDown += menuTxtbox_KeyDownInteger;
            tb_TrendBosCount.ToolTip = "Use mousewheel to change number";

            tb_TrendBosCount.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 1000;
                int min = 0;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.TrendBosCount = (int)x;
                //				ForceRefresh();
            };
            tb_TrendBosCount.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 10000;
                int min = 0;
                int x = tb_TrendBosCount.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_TrendBosCount.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    TrendBosCount = x;
                    tb_TrendBosCount.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    TrendBosCount = x;
                    tb_TrendBosCount.Text = x.ToString();
                }
                //				ForceRefresh();
            };
            tb_TrendBosCount.SetValue(Grid.ColumnProperty, 1);
            tb_TrendBosCount.SetValue(Grid.RowProperty, row);
            gridTrend.Children.Add(lbl_TrendBosCount);
            gridTrend.Children.Add(tb_TrendBosCount);
            miGridTrend = new MenuItem();
            miGridTrend.Header = gridTrend;
            MenuControl.Items.Add(miGridTrend);
            this.miGridTrend.Visibility = this.ShowTrend ? Visibility.Visible : Visibility.Collapsed;
            #endregion

            #region Trend X coordinate

            row++;
            gridTrend.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
            lbl_TrendXCoordinate = new Label() { Name = "lbl_TrendXCoordinate" + uID, Content = "Trend X-offset", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_TrendXCoordinate.SetValue(Grid.ColumnProperty, 0);
            lbl_TrendXCoordinate.SetValue(Grid.RowProperty, row);

            tb_TrendXCoordinate = new TextBox() { Name = "tb_TrendXCoordinate" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_TrendXCoordinate.Text = PositionX.ToString();
            tb_TrendXCoordinate.KeyDown += menuTxtbox_KeyDownInteger;
            tb_TrendXCoordinate.ToolTip = "Use mousewheel to change number";

            tb_TrendXCoordinate.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 1000;
                int min = 0;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.PositionX = (int)x;
                //				ForceRefresh();
            };
            tb_TrendXCoordinate.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 10000;
                int min = 0;
                int x = tb_TrendXCoordinate.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_TrendXCoordinate.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    PositionX = x;
                    tb_TrendXCoordinate.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    PositionX = x;
                    tb_TrendXCoordinate.Text = x.ToString();
                }
                //				ForceRefresh();
            };
            tb_TrendXCoordinate.SetValue(Grid.ColumnProperty, 1);
            tb_TrendXCoordinate.SetValue(Grid.RowProperty, row);
            gridTrend.Children.Add(lbl_TrendXCoordinate);
            gridTrend.Children.Add(tb_TrendXCoordinate);
            #endregion

            #region Trend Y coordinate

            row++;
            gridTrend.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
            lbl_TrendYCoordinate = new Label() { Name = "lbl_TrendYCoordinate" + uID, Content = "Trend Y-offset ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_TrendYCoordinate.SetValue(Grid.ColumnProperty, 0);
            lbl_TrendYCoordinate.SetValue(Grid.RowProperty, row);

            tb_TrendYCoordinate = new TextBox() { Name = "tb_TrendYCoordinate" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_TrendYCoordinate.Text = PositionY.ToString();
            tb_TrendYCoordinate.KeyDown += menuTxtbox_KeyDownInteger;
            tb_TrendYCoordinate.ToolTip = "Use mousewheel to change number";

            tb_TrendYCoordinate.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 1000;
                int min = 0;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.PositionY = (int)x;
                //				ForceRefresh();
            };
            tb_TrendYCoordinate.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 10000;
                int min = 0;
                int x = tb_TrendYCoordinate.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_TrendYCoordinate.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    PositionY = x;
                    tb_TrendYCoordinate.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    PositionY = x;
                    tb_TrendYCoordinate.Text = x.ToString();
                }
                //				ForceRefresh();
            };
            tb_TrendYCoordinate.SetValue(Grid.ColumnProperty, 1);
            tb_TrendYCoordinate.SetValue(Grid.RowProperty, row);
            gridTrend.Children.Add(lbl_TrendYCoordinate);
            gridTrend.Children.Add(tb_TrendYCoordinate);
            #endregion

            MenuControl.Items.Add(new Separator());

            #region Use MTF

            miUseMTF = new MenuItem { Header = "Use MTF: " + (UseMTF ? "ON" : "OFF"), Name = "UseMTF" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.UseMTF, StaysOpenOnClick = true };
            miUseMTF.Click += delegate (object o, RoutedEventArgs e)
            {
                this.UseMTF = !this.UseMTF;
                this.miMTFBarPeriodPeriodType.Visibility = this.UseMTF ? Visibility.Visible : Visibility.Collapsed;
                this.miGridMTF.Visibility = this.UseMTF ? Visibility.Visible : Visibility.Collapsed;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miUseMTF.IsChecked = UseMTF;
                        miUseMTF.Header = "Use MTF: " + (UseMTF ? "ON" : "OFF");
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miUseMTF.IsChecked = UseMTF;
                            miUseMTF.Header = "Use MTF: " + (UseMTF ? "ON" : "OFF");
                            ForceRefresh();
                        }));
                    }
                }
            };
            MenuControl.Items.Add(miUseMTF);
            #endregion

            #region MTF Bar Period Type
            miMTFBarPeriodPeriodType = new MenuItem { Header = "MTF Bar Period Type: " + MTFBarPeriodPeriodType.ToString(), Name = "MTFBarPeriodPeriodType" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miMTFBarPeriodPeriodType.Click += delegate (object o, RoutedEventArgs e)
            {
                if (MTFBarPeriodPeriodType == BarsPeriodType.Tick)
                    MTFBarPeriodPeriodType = BarsPeriodType.Volume;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Volume)
                    MTFBarPeriodPeriodType = BarsPeriodType.Range;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Range)
                    MTFBarPeriodPeriodType = BarsPeriodType.Second;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Second)
                    MTFBarPeriodPeriodType = BarsPeriodType.Minute;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Minute)
                    MTFBarPeriodPeriodType = BarsPeriodType.Day;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Day)
                    MTFBarPeriodPeriodType = BarsPeriodType.Week;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Week)
                    MTFBarPeriodPeriodType = BarsPeriodType.Month;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Month)
                    MTFBarPeriodPeriodType = BarsPeriodType.Year;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Year)
                    MTFBarPeriodPeriodType = BarsPeriodType.Tick;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miMTFBarPeriodPeriodType.Header = "MTF Bar Period Type: " + MTFBarPeriodPeriodType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miMTFBarPeriodPeriodType.Header = "MTF Bar Period Type: " + MTFBarPeriodPeriodType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            miMTFBarPeriodPeriodType.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                if (MTFBarPeriodPeriodType == BarsPeriodType.Tick)
                    MTFBarPeriodPeriodType = BarsPeriodType.Volume;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Volume)
                    MTFBarPeriodPeriodType = BarsPeriodType.Range;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Range)
                    MTFBarPeriodPeriodType = BarsPeriodType.Second;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Second)
                    MTFBarPeriodPeriodType = BarsPeriodType.Minute;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Minute)
                    MTFBarPeriodPeriodType = BarsPeriodType.Day;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Day)
                    MTFBarPeriodPeriodType = BarsPeriodType.Week;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Week)
                    MTFBarPeriodPeriodType = BarsPeriodType.Month;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Month)
                    MTFBarPeriodPeriodType = BarsPeriodType.Year;
                else if (MTFBarPeriodPeriodType == BarsPeriodType.Year)
                    MTFBarPeriodPeriodType = BarsPeriodType.Tick;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miMTFBarPeriodPeriodType.Header = "MTF Bar Period Type: " + MTFBarPeriodPeriodType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miMTFBarPeriodPeriodType.Header = "MTF Bar Period Type: " + MTFBarPeriodPeriodType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(miMTFBarPeriodPeriodType);
            this.miMTFBarPeriodPeriodType.Visibility = this.UseMTF ? Visibility.Visible : Visibility.Collapsed;
            #endregion

            #region MTF bar period value

            row = 0;
            gridMTF = new Grid();
            gridMTF.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            gridMTF.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            gridMTF.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            lbl_MTFBarPeriod = new Label() { Name = "lbl_MTFBarsPeriodValue" + uID, Content = "MTF Bar period value ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_MTFBarPeriod.SetValue(Grid.ColumnProperty, 0);
            lbl_MTFBarPeriod.SetValue(Grid.RowProperty, row);

            tb_MTFBarPeriod = new TextBox() { Name = "tb_MTFBarsPeriodValue" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_MTFBarPeriod.Text = MTFBarPeriodPeriodValue.ToString();
            tb_MTFBarPeriod.KeyDown += menuTxtbox_KeyDownInteger;
            tb_MTFBarPeriod.ToolTip = "Use mousewheel to change number";

            tb_MTFBarPeriod.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 10000;
                int min = 0;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.MTFBarPeriodPeriodValue = (int)x;
                //				ForceRefresh();
            };
            tb_MTFBarPeriod.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 10000;
                int min = 0;
                int x = tb_MTFBarPeriod.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_MTFBarPeriod.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    MTFBarPeriodPeriodValue = x;
                    tb_MTFBarPeriod.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    MTFBarPeriodPeriodValue = x;
                    tb_MTFBarPeriod.Text = x.ToString();
                }
                //				ForceRefresh();
            };
            tb_MTFBarPeriod.SetValue(Grid.ColumnProperty, 1);
            tb_MTFBarPeriod.SetValue(Grid.RowProperty, row);
            gridMTF.Children.Add(lbl_MTFBarPeriod);
            gridMTF.Children.Add(tb_MTFBarPeriod);
            #endregion

            #region number of MTF bars to load

            row++;
            gridMTF.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
            lbl_MTFBarsToLoad = new Label() { Name = "lbl_MTFBarsLoad" + uID, Content = "Number of bars to load ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_MTFBarsToLoad.SetValue(Grid.ColumnProperty, 0);
            lbl_MTFBarsToLoad.SetValue(Grid.RowProperty, row);

            tb_MTFBarsToLoad = new TextBox() { Name = "lbl_MTFBarsLoad" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_MTFBarsToLoad.Text = MTFBarsToLoad.ToString();
            tb_MTFBarsToLoad.KeyDown += menuTxtbox_KeyDownInteger;
            tb_MTFBarsToLoad.ToolTip = "Use mousewheel to change number";

            tb_MTFBarsToLoad.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 10000;
                int min = 0;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.MTFBarsToLoad = (int)x;
                //				ForceRefresh();
            };
            tb_MTFBarsToLoad.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 10000;
                int min = 0;
                int x = tb_MTFBarsToLoad.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_MTFBarsToLoad.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    MTFBarsToLoad = x;
                    tb_MTFBarsToLoad.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    MTFBarsToLoad = x;
                    tb_MTFBarsToLoad.Text = x.ToString();
                }
                //				ForceRefresh();
            };
            tb_MTFBarsToLoad.SetValue(Grid.ColumnProperty, 1);
            tb_MTFBarsToLoad.SetValue(Grid.RowProperty, row);
            gridMTF.Children.Add(lbl_MTFBarsToLoad);
            gridMTF.Children.Add(tb_MTFBarsToLoad);
            miGridMTF = new MenuItem() { Header = gridMTF };
            MenuControl.Items.Add(miGridMTF);
            this.miGridMTF.Visibility = this.UseMTF ? Visibility.Visible : Visibility.Collapsed;
            #endregion

            MenuControl.Items.Add(new Separator());

            #region Show Swing Hi/Lo
            miShowSwingHiLo = new MenuItem { Header = "Show Strong/Weak High/Low: " + (ShowSwingHighLow ? "ON" : "OFF"), Name = "ShowSwingHiLo" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.ShowSwingHighLow, StaysOpenOnClick = true };
            miShowSwingHiLo.Click += delegate (object o, RoutedEventArgs e)
            {
                this.ShowSwingHighLow = !this.ShowSwingHighLow;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miShowSwingHiLo.IsChecked = ShowSwingHighLow;
                        miShowSwingHiLo.Header = "Show Strong/Weak High/Low: " + (ShowSwingHighLow ? "ON" : "OFF");
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miShowSwingHiLo.IsChecked = ShowSwingHighLow;
                            miShowSwingHiLo.Header = "Show Strong/Weak High/Low: " + (ShowSwingHighLow ? "ON" : "OFF");
                            ForceRefresh();
                        }));
                    }
                }
            };
            MenuControl.Items.Add(miShowSwingHiLo);
            #endregion

            #region Show internal hi/lo
            miShowInternalHiLo = new MenuItem { Header = "Show Internal structure High/Low: " + (ShowInternalHighLow ? "ON" : "OFF"), Name = "ShowInternalHiLo" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.ShowInternalHighLow, StaysOpenOnClick = true };
            miShowInternalHiLo.Click += delegate (object o, RoutedEventArgs e)
            {
                this.ShowInternalHighLow = !this.ShowInternalHighLow;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miShowInternalHiLo.IsChecked = ShowInternalHighLow;
                        miShowInternalHiLo.Header = "Show Internal structure High/Low: " + (ShowInternalHighLow ? "ON" : "OFF");
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miShowInternalHiLo.IsChecked = ShowInternalHighLow;
                            miShowInternalHiLo.Header = "Show Internal structure High/Low: " + (ShowInternalHighLow ? "ON" : "OFF");
                            ForceRefresh();
                        }));
                    }
                }
            };
            MenuControl.Items.Add(miShowInternalHiLo);
            #endregion

            #region Show HH/LL
            miShowHHLL = new MenuItem { Header = "Show HH/LL: " + (ShowHHLL ? "ON" : "OFF"), Name = "ShowHHLL" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.ShowHHLL, StaysOpenOnClick = true };
            miShowHHLL.Click += delegate (object o, RoutedEventArgs e)
            {
                this.ShowHHLL = !this.ShowHHLL;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miShowHHLL.IsChecked = ShowHHLL;
                        miShowHHLL.Header = "Show HH/LL: " + (ShowHHLL ? "ON" : "OFF");
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miShowHHLL.IsChecked = ShowHHLL;
                            miShowHHLL.Header = "Show HH/LL: " + (ShowHHLL ? "ON" : "OFF");
                            ForceRefresh();
                        }));
                    }
                }
            };
            MenuControl.Items.Add(miShowHHLL);
            #endregion

            MenuControl.Items.Add(new Separator());

            #region BOS display type
            miBosDisplayType = new MenuItem { Header = "BOS Display type: " + BOSDisplayType.ToString(), Name = "BosDisplayType" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miBosDisplayType.Click += delegate (object o, RoutedEventArgs e)
            {
                if (BOSDisplayType == ARC_SMC_DisplayType.None)
                    BOSDisplayType = ARC_SMC_DisplayType.LineOnly;
                else if (BOSDisplayType == ARC_SMC_DisplayType.LineOnly)
                    BOSDisplayType = ARC_SMC_DisplayType.Text;
                else if (BOSDisplayType == ARC_SMC_DisplayType.Text)
                    BOSDisplayType = ARC_SMC_DisplayType.TextAndTimeFrame;
                else if (BOSDisplayType == ARC_SMC_DisplayType.TextAndTimeFrame)
                    BOSDisplayType = ARC_SMC_DisplayType.None;
                this.migridBos.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                this.miBosStructureMapping.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                this.miBosStructureMapping.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                miPullbackDetectionType.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miBosDisplayType.Header = "BOS Display type: " + BOSDisplayType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miBosDisplayType.Header = "BOS Display type: " + BOSDisplayType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            miBosDisplayType.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                if (BOSDisplayType == ARC_SMC_DisplayType.None)
                    BOSDisplayType = ARC_SMC_DisplayType.LineOnly;
                else if (BOSDisplayType == ARC_SMC_DisplayType.LineOnly)
                    BOSDisplayType = ARC_SMC_DisplayType.Text;
                else if (BOSDisplayType == ARC_SMC_DisplayType.Text)
                    BOSDisplayType = ARC_SMC_DisplayType.TextAndTimeFrame;
                else if (BOSDisplayType == ARC_SMC_DisplayType.TextAndTimeFrame)
                    BOSDisplayType = ARC_SMC_DisplayType.None;
                this.migridBos.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                this.miBosStructureMapping.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                this.miBosStructureMapping.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                miPullbackDetectionType.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miBosDisplayType.Header = "BOS Display type: " + BOSDisplayType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miBosDisplayType.Header = "BOS Display type: " + BOSDisplayType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(miBosDisplayType);
            #endregion

            #region BOS structure mapping
            miBosStructureMapping = new MenuItem { Header = "BOS structure mapping: " + BOSStructureMapping.ToString(), Name = "BosStructureMapping" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miBosStructureMapping.Click += delegate (object o, RoutedEventArgs e)
            {
                if (BOSStructureMapping == ARC_SMC_Mapping.Candle_Close)
                    BOSStructureMapping = ARC_SMC_Mapping.Candle_Wick;
                else if (BOSStructureMapping == ARC_SMC_Mapping.Candle_Wick)
                    BOSStructureMapping = ARC_SMC_Mapping.Candle_Close;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miBosStructureMapping.Header = "BOS structure mapping: " + BOSStructureMapping.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miBosStructureMapping.Header = "BOS structure mapping: " + BOSStructureMapping.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            miBosStructureMapping.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                if (BOSStructureMapping == ARC_SMC_Mapping.Candle_Close)
                    BOSStructureMapping = ARC_SMC_Mapping.Candle_Wick;
                else if (BOSStructureMapping == ARC_SMC_Mapping.Candle_Wick)
                    BOSStructureMapping = ARC_SMC_Mapping.Candle_Close;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miBosStructureMapping.Header = "BOS structure mapping: " + BOSStructureMapping.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miBosStructureMapping.Header = "BOS structure mapping: " + BOSStructureMapping.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(miBosStructureMapping);
            #endregion

            #region Pullback detection mode:
            miPullbackDetectionType = new MenuItem { Header = "BOS Pullback detection mode: " + BOSPullBackType.ToString(), Name = "pullbackMode" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miPullbackDetectionType.Click += delegate (object o, RoutedEventArgs e)
            {
                if (BOSPullBackType == ARC_SMC_PullbackMode.ATR)
                    BOSPullBackType = ARC_SMC_PullbackMode.Percentage;
                else if (BOSPullBackType == ARC_SMC_PullbackMode.Percentage)
                    BOSPullBackType = ARC_SMC_PullbackMode.Ticks;
                else if (BOSPullBackType == ARC_SMC_PullbackMode.Ticks)
                    BOSPullBackType = ARC_SMC_PullbackMode.ATR;
                ShowPullbackModeControls();
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miPullbackDetectionType.Header = "BOS Pullback detection mode: " + BOSPullBackType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miPullbackDetectionType.Header = "BOS Pullback detection mode: " + BOSPullBackType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            miPullbackDetectionType.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                if (BOSPullBackType == ARC_SMC_PullbackMode.ATR)
                    BOSPullBackType = ARC_SMC_PullbackMode.Percentage;
                else if (BOSPullBackType == ARC_SMC_PullbackMode.Percentage)
                    BOSPullBackType = ARC_SMC_PullbackMode.Ticks;
                else if (BOSPullBackType == ARC_SMC_PullbackMode.Ticks)
                    BOSPullBackType = ARC_SMC_PullbackMode.ATR;

                ShowPullbackModeControls();
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miPullbackDetectionType.Header = "BOS Pullback detection mode: " + BOSPullBackType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miPullbackDetectionType.Header = "BOS Pullback detection mode: " + BOSPullBackType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(miPullbackDetectionType);
            #endregion

            #region number of BOS to display

            row = 0;
            gridBos = new Grid();
            gridBos.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            gridBos.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
            gridBos.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            lbl_NumberOfBOSToDisplay = new Label() { Name = "lbl_BosCountDTB" + uID, Content = "Number of BOS to display (0=all) ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_NumberOfBOSToDisplay.SetValue(Grid.ColumnProperty, 0);
            lbl_NumberOfBOSToDisplay.SetValue(Grid.RowProperty, row);

            tb_NumberOfBOSToDisplay = new TextBox() { Name = "nud_BosCountDTB" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_NumberOfBOSToDisplay.Text = NumberOfBOSToDisplay.ToString();
            tb_NumberOfBOSToDisplay.KeyDown += menuTxtbox_KeyDownInteger;
            tb_NumberOfBOSToDisplay.ToolTip = "Use mousewheel to change number";

            tb_NumberOfBOSToDisplay.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 1000;
                int min = 0;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.NumberOfBOSToDisplay = (int)x;
                //				ForceRefresh();
            };
            tb_NumberOfBOSToDisplay.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 1000;
                int min = 0;
                int x = tb_NumberOfBOSToDisplay.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_NumberOfBOSToDisplay.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    NumberOfBOSToDisplay = x;
                    tb_NumberOfBOSToDisplay.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    NumberOfBOSToDisplay = x;
                    tb_NumberOfBOSToDisplay.Text = x.ToString();
                }
                //				ForceRefresh();
            };
            tb_NumberOfBOSToDisplay.SetValue(Grid.ColumnProperty, 1);
            tb_NumberOfBOSToDisplay.SetValue(Grid.RowProperty, row);
            gridBos.Children.Add(lbl_NumberOfBOSToDisplay);
            gridBos.Children.Add(tb_NumberOfBOSToDisplay);
            #endregion

            #region ATR period, percentage, ticks inputs

            row++;
            gridBos.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });


            // ATR period
            lbl_ATRPeriod = new Label() { Name = "lbl_AtrPeriod" + uID, Content = "ATR Period ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_ATRPeriod.SetValue(Grid.ColumnProperty, 0);
            lbl_ATRPeriod.SetValue(Grid.RowProperty, row);

            tb_ATRPeriod = new TextBox() { Name = "nud_AtrPeriod" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_ATRPeriod.Text = BOSATRPeriod.ToString();
            tb_ATRPeriod.KeyDown += menuTxtbox_KeyDownInteger;
            tb_ATRPeriod.ToolTip = "Use mousewheel to change number";

            tb_ATRPeriod.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 1000;
                int min = 1;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.BOSATRPeriod = (int)x;
				this.InformUserAboutRecalculation();
            };
            tb_ATRPeriod.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 1000;
                int min = 1;
                int x = tb_ATRPeriod.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_ATRPeriod.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    NumberOfBOSToDisplay = x;
                    tb_ATRPeriod.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    BOSATRPeriod = x;
                    tb_ATRPeriod.Text = x.ToString();
                }
				this.InformUserAboutRecalculation();
            };
            tb_ATRPeriod.SetValue(Grid.ColumnProperty, 1);
            tb_ATRPeriod.SetValue(Grid.RowProperty, row);
            gridBos.Children.Add(lbl_ATRPeriod);
            gridBos.Children.Add(tb_ATRPeriod);

            // ATR multiplier
            row++;
            gridBos.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
            lbl_ATRMultiplier = new Label() { Name = "lbl_AtrMultiplier" + uID, Content = "ATR Multiplier ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_ATRMultiplier.SetValue(Grid.ColumnProperty, 0);
            lbl_ATRMultiplier.SetValue(Grid.RowProperty, row);

            tb_ATRMultiplier = new TextBox() { Name = "nud_AtrMultiplier" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_ATRMultiplier.Text = BOSATRMultiplier.ToString();
            tb_ATRMultiplier.KeyDown += menuTxtbox_KeyDownDouble;
            tb_ATRMultiplier.ToolTip = "Use mousewheel to change number";
            gridBos.Children.Add(lbl_ATRMultiplier);
            gridBos.Children.Add(tb_ATRMultiplier);

			tb_ATRMultiplier.TextChanged += delegate (object o, TextChangedEventArgs e)
			{
				var tb = (TextBox)o;
			    var max = 1000d;
			    var min = 0.1d;
			    var x = tb.Text.Trim().Length == 0 ? min : Convert.ToDouble(tb.Text);
			    if (x > max)
			    {
			        tb.Text = max.ToString();
			        x = max;
			    }
			    if (x < min)
			    {
			        tb.Text = min.ToString();
			        x = min;
			    }
			    this.BOSATRMultiplier = x;
				this.InformUserAboutRecalculation();
			};
            tb_ATRMultiplier.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                var max = 1000d;
                var min = 0.1d;
                var x = tb_ATRMultiplier.Text.Trim().Length == 0 ? min : Convert.ToDouble(tb_ATRMultiplier.Text);
                if (e.Delta < 0)
                {
                    x = x - 0.1d;
                    x = Math.Max(min, Math.Min(max, x));
                    BOSATRMultiplier = x;
                    tb_ATRMultiplier.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 0.1d;
                    x = Math.Max(min, Math.Min(max, x));
                    BOSATRMultiplier = x;
                    tb_ATRMultiplier.Text = x.ToString();
                }
				this.InformUserAboutRecalculation();
            };
            tb_ATRMultiplier.SetValue(Grid.ColumnProperty, 1);
            tb_ATRMultiplier.SetValue(Grid.RowProperty, row);

            // Ticks
            row = 1;
            lbl_Ticks = new Label() { Name = "lbl_Ticks" + uID, Content = "Ticks ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_Ticks.SetValue(Grid.ColumnProperty, 0);
            lbl_Ticks.SetValue(Grid.RowProperty, row);

            tb_Ticks = new TextBox() { Name = "nud_Ticks" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_Ticks.Text = BOSPullbackTicks.ToString();
            tb_Ticks.KeyDown += menuTxtbox_KeyDownInteger;
            tb_Ticks.ToolTip = "Use mousewheel to change number";
            gridBos.Children.Add(lbl_Ticks);
            gridBos.Children.Add(tb_Ticks);

            tb_Ticks.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 1000;
                int min = 1;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.BOSPullbackTicks = (int)x;
                //				ForceRefresh();
            };
            tb_Ticks.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 1000;
                int min = 1;
                int x = tb_Ticks.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_Ticks.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    BOSPullbackTicks = x;
                    tb_Ticks.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    BOSPullbackTicks = x;
                    tb_Ticks.Text = x.ToString();
                }
                //				ForceRefresh();
            };
            tb_Ticks.SetValue(Grid.ColumnProperty, 1);
            tb_Ticks.SetValue(Grid.RowProperty, row);


            // Percentage
            row = 1;
            lbl_Percentage = new Label() { Name = "lbl_Percentage" + uID, Content = "Percentage ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_Percentage.SetValue(Grid.ColumnProperty, 0);
            lbl_Percentage.SetValue(Grid.RowProperty, row);

            tb_Percentage = new TextBox() { Name = "nud_Percentage" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_Percentage.Text = BOSPullbackPercentage.ToString();
            tb_Percentage.KeyDown += menuTxtbox_KeyDownInteger;
            tb_Percentage.ToolTip = "Use mousewheel to change number";
            gridBos.Children.Add(lbl_Percentage);
            gridBos.Children.Add(tb_Percentage);

            tb_Percentage.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 1000;
                int min = 1;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.BOSPullbackPercentage = (int)x;
                //				ForceRefresh();
            };
            tb_Percentage.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 1000;
                int min = 1;
                int x = tb_Percentage.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_Percentage.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    BOSPullbackPercentage = x;
                    tb_Percentage.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    BOSPullbackPercentage = x;
                    tb_Percentage.Text = x.ToString();
                }
                //				ForceRefresh();
            };
            tb_Percentage.SetValue(Grid.ColumnProperty, 1);
            tb_Percentage.SetValue(Grid.RowProperty, row);
            migridBos = new MenuItem() { Header = gridBos };
            MenuControl.Items.Add(migridBos);
            this.migridBos.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
            this.miBosStructureMapping.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
            this.miBosStructureMapping.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
            miPullbackDetectionType.Visibility = BOSDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
            #endregion

            MenuControl.Items.Add(new Separator());

            #region ChoCh display type
            miChoChDisplayType = new MenuItem { Header = "ChoCh Display type: " + ChoChDisplayType.ToString(), Name = "ChoChDisplayType" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miChoChDisplayType.Click += delegate (object o, RoutedEventArgs e)
            {
                if (ChoChDisplayType == ARC_SMC_DisplayType.None)
                    ChoChDisplayType = ARC_SMC_DisplayType.LineOnly;
                else if (ChoChDisplayType == ARC_SMC_DisplayType.LineOnly)
                    ChoChDisplayType = ARC_SMC_DisplayType.Text;
                else if (ChoChDisplayType == ARC_SMC_DisplayType.Text)
                    ChoChDisplayType = ARC_SMC_DisplayType.TextAndTimeFrame;
                else if (ChoChDisplayType == ARC_SMC_DisplayType.TextAndTimeFrame)
                    ChoChDisplayType = ARC_SMC_DisplayType.None;
                migridCHoch.Visibility = ChoChDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                miChoChStructureMapping.Visibility = ChoChDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miChoChDisplayType.Header = "ChoCh Display type: " + ChoChDisplayType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miChoChDisplayType.Header = "ChoCh Display type: " + ChoChDisplayType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            miChoChDisplayType.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                if (ChoChDisplayType == ARC_SMC_DisplayType.None)
                    ChoChDisplayType = ARC_SMC_DisplayType.LineOnly;
                else if (ChoChDisplayType == ARC_SMC_DisplayType.LineOnly)
                    ChoChDisplayType = ARC_SMC_DisplayType.Text;
                else if (ChoChDisplayType == ARC_SMC_DisplayType.Text)
                    ChoChDisplayType = ARC_SMC_DisplayType.TextAndTimeFrame;
                else if (ChoChDisplayType == ARC_SMC_DisplayType.TextAndTimeFrame)
                    ChoChDisplayType = ARC_SMC_DisplayType.None;
                migridCHoch.Visibility = ChoChDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                miChoChStructureMapping.Visibility = ChoChDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miChoChDisplayType.Header = "ChoCh Display type: " + ChoChDisplayType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miChoChDisplayType.Header = "ChoCh Display type: " + ChoChDisplayType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(miChoChDisplayType);
            #endregion

            #region ChoCh structure mapping
            miChoChStructureMapping = new MenuItem { Header = "ChoCh structure mapping: " + ChoChStructureMapping.ToString(), Name = "ChoChStructureMapping" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miChoChStructureMapping.Click += delegate (object o, RoutedEventArgs e)
            {
                if (ChoChStructureMapping == ARC_SMC_Mapping.Candle_Close)
                    ChoChStructureMapping = ARC_SMC_Mapping.Candle_Wick;
                else if (ChoChStructureMapping == ARC_SMC_Mapping.Candle_Wick)
                    ChoChStructureMapping = ARC_SMC_Mapping.Candle_Close;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miChoChStructureMapping.Header = "ChoCh structure mapping: " + ChoChStructureMapping.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miChoChStructureMapping.Header = "ChoCh structure mapping: " + ChoChStructureMapping.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            miChoChStructureMapping.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                if (ChoChStructureMapping == ARC_SMC_Mapping.Candle_Close)
                    ChoChStructureMapping = ARC_SMC_Mapping.Candle_Wick;
                else if (ChoChStructureMapping == ARC_SMC_Mapping.Candle_Wick)
                    ChoChStructureMapping = ARC_SMC_Mapping.Candle_Close;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miChoChStructureMapping.Header = "ChoCh structure mapping: " + ChoChStructureMapping.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miChoChStructureMapping.Header = "ChoCh structure mapping: " + ChoChStructureMapping.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(miChoChStructureMapping);
            miChoChStructureMapping.Visibility = ChoChDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
            #endregion

            #region number of ChoCh to display

            row = 0;
            gridCHoch = new Grid();
            gridCHoch.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            gridCHoch.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
            gridCHoch.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            lbl_NumberOfChoChToDisplay = new Label() { Name = "lbl_ChoChCountDTB" + uID, Content = "Number of ChoCh to display (0=all) ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_NumberOfChoChToDisplay.SetValue(Grid.ColumnProperty, 0);
            lbl_NumberOfChoChToDisplay.SetValue(Grid.RowProperty, row);

            tb_NumberOfChoChToDisplay = new TextBox() { Name = "nud_ChoChCountDTB" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_NumberOfChoChToDisplay.Text = NumberOfChoChToDisplay.ToString();
            tb_NumberOfChoChToDisplay.KeyDown += menuTxtbox_KeyDownInteger;
            tb_NumberOfChoChToDisplay.ToolTip = "Use mousewheel to change number";

            tb_NumberOfChoChToDisplay.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 1000;
                int min = 0;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.NumberOfChoChToDisplay = (int)x;
                //				ForceRefresh();
            };
            tb_NumberOfChoChToDisplay.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 1000;
                int min = 0;
                int x = tb_NumberOfChoChToDisplay.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_NumberOfChoChToDisplay.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    NumberOfChoChToDisplay = x;
                    tb_NumberOfChoChToDisplay.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    NumberOfChoChToDisplay = x;
                    tb_NumberOfChoChToDisplay.Text = x.ToString();
                }
                //				ForceRefresh();
            };
            tb_NumberOfChoChToDisplay.SetValue(Grid.ColumnProperty, 1);
            tb_NumberOfChoChToDisplay.SetValue(Grid.RowProperty, row);
            gridCHoch.Children.Add(lbl_NumberOfChoChToDisplay);
            gridCHoch.Children.Add(tb_NumberOfChoChToDisplay);
            migridCHoch = new MenuItem() { Header = gridCHoch };
            MenuControl.Items.Add(migridCHoch);
            migridCHoch.Visibility = ChoChDisplayType != ARC_SMC_DisplayType.None ? Visibility.Visible : Visibility.Collapsed;
            #endregion

            MenuControl.Items.Add(new Separator());

            #region Show Fib. retracements
            miShowFibRetracements = new MenuItem { Header = "Show Auction Curve: " + (ShowFibRetracements ? "ON" : "OFF"), Name = "ShowFibRetracements" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.ShowFibRetracements, StaysOpenOnClick = true };
            miShowFibRetracements.Click += delegate (object o, RoutedEventArgs e)
            {
                this.ShowFibRetracements = !this.ShowFibRetracements;
                miFibDisplayType.Visibility = ShowFibRetracements ? Visibility.Visible : Visibility.Collapsed;
                miShowFibNumbers.Visibility = this.ShowFibRetracements ? Visibility.Visible : Visibility.Collapsed;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miShowFibRetracements.IsChecked = ShowFibRetracements;
                        miShowFibRetracements.Header = "Show Auction Curve: " + (ShowFibRetracements ? "ON" : "OFF");
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miShowFibRetracements.IsChecked = ShowFibRetracements;
                            miShowFibRetracements.Header = "Show Auction Curve: " + (ShowFibRetracements ? "ON" : "OFF");
                            ForceRefresh();
                        }));
                    }
                }
            };
            MenuControl.Items.Add(miShowFibRetracements);
            #endregion

            #region Fib display type
            miFibDisplayType = new MenuItem { Header = "Auction curve type: " + FibonacciType.ToString(), Name = "FibDisplayType" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miFibDisplayType.Click += delegate (object o, RoutedEventArgs e)
            {
                if (FibonacciType == ARC_SMC_FibonacciType.Normal)
                    FibonacciType = ARC_SMC_FibonacciType.Cluster;
                else if (FibonacciType == ARC_SMC_FibonacciType.Cluster)
                    FibonacciType = ARC_SMC_FibonacciType.Normal;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miFibDisplayType.Header = "Auction curve Display type: " + FibonacciType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miFibDisplayType.Header = "Auction curve Display type: " + FibonacciType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            miFibDisplayType.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                if (FibonacciType == ARC_SMC_FibonacciType.Normal)
                    FibonacciType = ARC_SMC_FibonacciType.Cluster;
                else if (FibonacciType == ARC_SMC_FibonacciType.Cluster)
                    FibonacciType = ARC_SMC_FibonacciType.Normal;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miFibDisplayType.Header = "Auction curve Display type: " + FibonacciType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miFibDisplayType.Header = "Auction curve Display type: " + FibonacciType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(miFibDisplayType);
            miFibDisplayType.Visibility = ShowFibRetracements ? Visibility.Visible : Visibility.Collapsed;
            #endregion

            #region Show Fib. levels
            miShowFibNumbers = new MenuItem { Header = "Show Auction Curve levels: " + (ShowFibNumbers ? "ON" : "OFF"), Name = "ShowFibNumbers" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.ShowFibNumbers, StaysOpenOnClick = true };
            miShowFibNumbers.Click += delegate (object o, RoutedEventArgs e)
            {
                this.ShowFibNumbers = !this.ShowFibNumbers;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miShowFibNumbers.IsChecked = ShowFibNumbers;
                        miShowFibNumbers.Header = "Show Auction Curve levels: " + (ShowFibNumbers ? "ON" : "OFF");
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miShowFibNumbers.IsChecked = ShowFibNumbers;
                            miShowFibNumbers.Header = "Show Auction Curve levels: " + (ShowFibNumbers ? "ON" : "OFF");
                            ForceRefresh();
                        }));
                    }
                }
            };
            MenuControl.Items.Add(miShowFibNumbers);
            miShowFibNumbers.Visibility = this.ShowFibRetracements ? Visibility.Visible : Visibility.Collapsed;
            #endregion

            MenuControl.Items.Add(new Separator());

            #region Show S&D zones
            miShowSDZones = new MenuItem { Header = "Supply/Demand zones display type: " + SupplyDemandDisplayType.ToString(), Name = "SDZoneDisplayType" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false, StaysOpenOnClick = true };
            miShowSDZones.Click += delegate (object o, RoutedEventArgs e)
            {
                if (this.SupplyDemandDisplayType == ARC_SMC_SupplyDemandDisplayType.None)
                    this.SupplyDemandDisplayType = ARC_SMC_SupplyDemandDisplayType.Bos;
                else if (this.SupplyDemandDisplayType == ARC_SMC_SupplyDemandDisplayType.Bos)
                    this.SupplyDemandDisplayType = ARC_SMC_SupplyDemandDisplayType.ChoCh;
                else if (this.SupplyDemandDisplayType == ARC_SMC_SupplyDemandDisplayType.ChoCh)
                    this.SupplyDemandDisplayType = ARC_SMC_SupplyDemandDisplayType.Both;
                else if (this.SupplyDemandDisplayType == ARC_SMC_SupplyDemandDisplayType.Both)
                    this.SupplyDemandDisplayType = ARC_SMC_SupplyDemandDisplayType.None;

                miHideBrokenSDZones.Visibility = this.SupplyDemandDisplayType != ARC_SMC_SupplyDemandDisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                miSDZonesToDisplay.Visibility = this.SupplyDemandDisplayType != ARC_SMC_SupplyDemandDisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                miSupplyDemandType.Visibility = this.SupplyDemandDisplayType != ARC_SMC_SupplyDemandDisplayType.None ? Visibility.Visible : Visibility.Collapsed;
                miSupplyDemandBreakType.Visibility = this.SupplyDemandDisplayType != ARC_SMC_SupplyDemandDisplayType.None ? Visibility.Visible : Visibility.Collapsed;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miShowSDZones.Header = "Supply/Demand zones display type: " + SupplyDemandDisplayType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miShowSDZones.Header = "Supply/Demand zones display type: " + SupplyDemandDisplayType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            MenuControl.Items.Add(miShowSDZones);
            #endregion

            #region Hide Broken S&D zones
            miHideBrokenSDZones = new MenuItem { Header = "Hide Broken Supply/Demand zones: " + (HideBrokenSupplyDemandZones ? "ON" : "OFF"), Name = "HideBrokenSDZones" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.HideBrokenSupplyDemandZones, StaysOpenOnClick = true };
            miHideBrokenSDZones.Click += delegate (object o, RoutedEventArgs e)
            {
                HideBrokenSupplyDemandZones = !HideBrokenSupplyDemandZones;
                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        miHideBrokenSDZones.IsChecked = HideBrokenSupplyDemandZones;
                        miHideBrokenSDZones.Header = "Hide Broken Supply/Demand zones: " + (HideBrokenSupplyDemandZones ? "ON" : "OFF");
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            miHideBrokenSDZones.IsChecked = HideBrokenSupplyDemandZones;
                            miHideBrokenSDZones.Header = "Hide Broken Supply/Demand zones: " + (HideBrokenSupplyDemandZones ? "ON" : "OFF");
                            ForceRefresh();
                        }));
                    }
                }
            };
            MenuControl.Items.Add(miHideBrokenSDZones);
            #endregion

            #region Supply/Demand type
            miSupplyDemandType = new MenuItem { Header = "Supply/Demand type: " + SupplyDemandType.ToString(), Name = "SupplyDemandType" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miSupplyDemandType.Click += delegate (object o, RoutedEventArgs e)
            {
                if (SupplyDemandType == ARC_SMC_SupplyDemandType.Candle)
                    SupplyDemandType = ARC_SMC_SupplyDemandType.Wick;
                else if (SupplyDemandType == ARC_SMC_SupplyDemandType.Wick)
                    SupplyDemandType = ARC_SMC_SupplyDemandType.Candle;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miSupplyDemandType.Header = "Supply/Demand type: " + SupplyDemandType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miSupplyDemandType.Header = "Supply/Demand type: " + SupplyDemandType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            miSupplyDemandType.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                if (SupplyDemandType == ARC_SMC_SupplyDemandType.Candle)
                    SupplyDemandType = ARC_SMC_SupplyDemandType.Wick;
                else if (SupplyDemandType == ARC_SMC_SupplyDemandType.Wick)
                    SupplyDemandType = ARC_SMC_SupplyDemandType.Candle;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miSupplyDemandType.Header = "Supply/Demand type: " + SupplyDemandType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miSupplyDemandType.Header = "Supply/Demand type: " + SupplyDemandType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(miSupplyDemandType);
            #endregion

            #region Supply/Demand breaks at
            miSupplyDemandBreakType = new MenuItem { Header = "Supply/Demand breaks at: " + SupplyDemandBreakType.ToString(), Name = "SupplyDemandBreakType" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miSupplyDemandBreakType.Click += delegate (object o, RoutedEventArgs e)
            {
                if (SupplyDemandBreakType == ARC_SMC_SDBroken.Close)
                    SupplyDemandBreakType = ARC_SMC_SDBroken.PremiumDiscount;
                else if (SupplyDemandBreakType == ARC_SMC_SDBroken.PremiumDiscount)
                    SupplyDemandBreakType = ARC_SMC_SDBroken.Wick;
                else if (SupplyDemandBreakType == ARC_SMC_SDBroken.Wick)
                    SupplyDemandBreakType = ARC_SMC_SDBroken.Close;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miSupplyDemandBreakType.Header = "Supply/Demand breaks at: " + SupplyDemandBreakType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miSupplyDemandBreakType.Header = "Supply/Demand breaks at: " + SupplyDemandBreakType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };
            miSupplyDemandBreakType.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                if (SupplyDemandBreakType == ARC_SMC_SDBroken.Close)
                    SupplyDemandBreakType = ARC_SMC_SDBroken.PremiumDiscount;
                else if (SupplyDemandBreakType == ARC_SMC_SDBroken.PremiumDiscount)
                    SupplyDemandBreakType = ARC_SMC_SDBroken.Wick;
                else if (SupplyDemandBreakType == ARC_SMC_SDBroken.Wick)
                    SupplyDemandBreakType = ARC_SMC_SDBroken.Close;

                if (ChartControl != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        InformUserAboutRecalculation();
                        miSupplyDemandBreakType.Header = "Supply/Demand breaks at: " + SupplyDemandBreakType.ToString();
                        ForceRefresh();
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            InformUserAboutRecalculation();
                            miSupplyDemandBreakType.Header = "Supply/Demand breaks at: " + SupplyDemandBreakType.ToString();
                            ForceRefresh();
                        }));
                    }
                }
            };

            MenuControl.Items.Add(miSupplyDemandBreakType);
            #endregion

            #region Number of S&D zones to display

            row = 0;
            gridSDZonesToDisplay = new Grid();
            gridSDZonesToDisplay.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            gridSDZonesToDisplay.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
            gridSDZonesToDisplay.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            lbl_NumberOfSDZonesToDisplay = new Label() { Name = "lbl_SDCountDTB" + uID, Content = "Number of S&D zones to display (0=all) ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_NumberOfSDZonesToDisplay.SetValue(Grid.ColumnProperty, 0);
            lbl_NumberOfSDZonesToDisplay.SetValue(Grid.RowProperty, row);

            tb_NumberOfSDZonesToDisplay = new TextBox() { Name = "nud_SDCountDTB" + uID, Background = Brushes.Silver, Foreground = Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            tb_NumberOfSDZonesToDisplay.Text = NumberOfSDZones.ToString();
            tb_NumberOfSDZonesToDisplay.KeyDown += menuTxtbox_KeyDownInteger;
            tb_NumberOfSDZonesToDisplay.ToolTip = "Use mousewheel to change number";

            tb_NumberOfSDZonesToDisplay.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 1000;
                int min = 0;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.NumberOfSDZones = (int)x;
                //				ForceRefresh();
            };
            tb_NumberOfSDZonesToDisplay.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e)
            {
                int max = 1000;
                int min = 0;
                int x = tb_NumberOfSDZonesToDisplay.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb_NumberOfSDZonesToDisplay.Text);
                if (e.Delta < 0)
                {
                    x = x - 1;
                    x = Math.Max(min, Math.Min(max, x));
                    NumberOfSDZones = x;
                    tb_NumberOfSDZonesToDisplay.Text = x.ToString();
                }
                else if (e.Delta > 0)
                {
                    x = x + 1;
                    x = Math.Max(min, Math.Min(max, x));
                    NumberOfSDZones = x;
                    tb_NumberOfSDZonesToDisplay.Text = x.ToString();
                }
                //				ForceRefresh();
            };
            tb_NumberOfSDZonesToDisplay.SetValue(Grid.ColumnProperty, 1);
            tb_NumberOfSDZonesToDisplay.SetValue(Grid.RowProperty, row);
            gridSDZonesToDisplay.Children.Add(lbl_NumberOfSDZonesToDisplay);
            gridSDZonesToDisplay.Children.Add(tb_NumberOfSDZonesToDisplay);
            miSDZonesToDisplay = new MenuItem() { Header = gridSDZonesToDisplay };
            MenuControl.Items.Add(miSDZonesToDisplay);

            miHideBrokenSDZones.Visibility = this.SupplyDemandDisplayType != ARC_SMC_SupplyDemandDisplayType.None ? Visibility.Visible : Visibility.Collapsed;
            miSDZonesToDisplay.Visibility = this.SupplyDemandDisplayType != ARC_SMC_SupplyDemandDisplayType.None ? Visibility.Visible : Visibility.Collapsed;
            miSupplyDemandType.Visibility = this.SupplyDemandDisplayType != ARC_SMC_SupplyDemandDisplayType.None ? Visibility.Visible : Visibility.Collapsed;
            miSupplyDemandBreakType.Visibility = this.SupplyDemandDisplayType != ARC_SMC_SupplyDemandDisplayType.None ? Visibility.Visible : Visibility.Collapsed;
            #endregion
            MenuControl.Items.Add(new Separator());

            #region -- Recalc --
            miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", HorizontalAlignment = HorizontalAlignment.Center, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = false };
            miRecalculate1.Click += delegate (object o, RoutedEventArgs e)
            {
                e.Handled = true;
                ResetRecalculationUI();
                System.Windows.Forms.SendKeys.SendWait("{F5}");
            };
            miRecalculate1.ToolTip = "If this does not refresh your chart, hit your F5 function key instead";
            MenuControl.Items.Add(miRecalculate1);
            #endregion

            indytoolbar.Children.Add(MenuControlContainer);

            ShowPullbackModeControls();
        }
		#region -- support methods for "Swing Lines" menu --
		#region ----- ChangeTextBoxValue -----
		private void ChangeTextValue(string Name, string Value, double Delta){
try{
			Value = Value.Replace("-",string.Empty).Trim();//no negative values allowed
			double incr = 0;
			if(!double.IsNaN(Delta)) {
				incr = Delta > 0 ? 1 : (Delta < 0 ? -1 : 0);
			}
			//Print("Name: "+Name);
			if (Value.Length > 0)
			{
				if (Name.StartsWith("tb_SwingStrength")) {
					Value = Value.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
					if(incr!=0){
						pSwingStrength = Math.Max(1,Math.Min(200,Convert.ToInt32(Value) + (int)incr));
						tb_SwingStrength.Text = pSwingStrength.ToString();
					}else
						tb_SwingStrength.Text = Value;
				}else if(Name.StartsWith("nud_AtrMultiplier")){
						BOSATRMultiplier = Math.Max(0.1,Math.Min(1000,Convert.ToDouble(Value) + Delta));
						tb_ATRMultiplier.Text = BOSATRMultiplier.ToString();
				}
				this.InformUserAboutRecalculation();
			}
}catch(Exception e){Print(e.ToString());}
		}
		#endregion
		#region ----- MouseWheelEventInteger -----
        private void MouseWheelEventInteger(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
			TextBox txtSender = sender as TextBox;
			string intxt = txtSender.Text;
			ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 1 : -1);
        }
		#endregion
		#region  ----- createMktStructure_Menu ----- 
        private Grid createMktStructure_Menu(string tb_Value, string tb_ATRPeriodValue, string tb_ATRMultValue)
        {
			const int rHeight = 26;

			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });

			int row = 0;
			//line 1 - SwingStrength
			#region ----- SwingStrength -----
			Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Swing Strength: " };
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 2);

			tb_SwingStrength = new TextBox() { Name = "tb_SwingStrength" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0)};
			tb_SwingStrength.Text = tb_Value;
			tb_SwingStrength.MouseWheel += MouseWheelEventInteger;
			tb_SwingStrength.KeyDown += menuTxtbox_KeyDownInteger;
            tb_SwingStrength.TextChanged += delegate (object o, TextChangedEventArgs e)
            {
				TextBox tb = (TextBox)o;
                int max = 1000;
                int min = 1;
                int x = tb.Text.Trim().Length == 0 ? min : Convert.ToInt32(tb.Text);
                if (x > max)
                {
                    tb.Text = max.ToString();
                    x = max;
                }
                if (x < min)
                {
                    tb.Text = min.ToString();
                    x = min;
                }
                this.pSwingStrength = (int)x;
				this.InformUserAboutRecalculation();
            };
			tb_SwingStrength.SetValue(Grid.ColumnProperty, 1);
			tb_SwingStrength.SetValue(Grid.RowProperty, row);
			tb_SwingStrength.SetValue(Grid.RowSpanProperty, 2);
			grid.Children.Add(lbl1);
            grid.Children.Add(tb_SwingStrength);
			#endregion

            return grid;
        }
		#endregion

		#region  ----- menuTxtbox_KeyDown ----- 
		private void menuTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			e.Handled = true;
			TextBox txtSender = sender as TextBox;
			int keyVal = (int)e.Key;

			int value = -1;
			if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
				value = keyVal - (int)System.Windows.Input.Key.D0;
			else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
				value = keyVal - (int)System.Windows.Input.Key.NumPad0;

			bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.Decimal;
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.OemPeriod;
			if (isNumeric || e.Key == System.Windows.Input.Key.Back)
			{
				string newText = value != -1 ? value.ToString() : "";
				if(!txtSender.Text.Contains(".")){
					if(e.Key==System.Windows.Input.Key.Decimal) newText = ".";
					else if(e.Key==System.Windows.Input.Key.OemPeriod) newText = ".";
				}
				int tbPosition = txtSender.SelectionStart;
				try{
					if(txtSender.SelectedText.Length==0)
						txtSender.Text = txtSender.Text.Insert(tbPosition, newText);
					else
						txtSender.Text.Replace(txtSender.SelectedText, newText);
				}catch(Exception t){Print(t.ToString());}
				txtSender.Select(tbPosition + 1, 0);
			}
			ChangeTextValue(txtSender.Name, txtSender.Text, 0);
		}
		#endregion

        #region  ----- structureMenuItem_Click ----- 
        private void structureMenuItem_Click(object sender, EventArgs e)
        {
			MenuItem item = sender as MenuItem;
            #region -- showMarketSwingsClick --
            if (item.Name.Contains( "miMarketSwingLines"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.pShowSwingLines = false;
                    item.Header     = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                }
                else
                {
                    this.pShowSwingLines = true;
                    item.Header     = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
            #endregion
            #region -- miShowSwingLabels --
            else if (item.Name.Contains( "miShowSwingLabels"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.pShowSwingLabels = false;
                    item.Header     = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                }
                else
                {
                    this.pShowSwingLabels = true;
                    item.Header     = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
			#endregion
			ChartControl.InvalidateVisual();
        }
        #endregion
		#endregion

        private void menuTxtbox_KeyDownInteger(object sender, System.Windows.Input.KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtBoxSender = sender as TextBox;
            int max = int.MaxValue;
            int min = 0;
            string startval = txtBoxSender.Text;

            //PrintDebug("      max: "+max+"  min: "+min);
            try
            {
                int keyVal = (int)e.Key;
                int value = -1;
                if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9)
                    value = keyVal - (int)System.Windows.Input.Key.D0;
                else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9)
                    value = keyVal - (int)System.Windows.Input.Key.NumPad0;

                bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);

                //PrintDebug("IsNumberic: "+isNumeric.ToString());

                if (isNumeric || e.Key == System.Windows.Input.Key.Back)
                {
                    string newText = value != -1 ? value.ToString() : "";
                    int tbPosition = txtBoxSender.SelectionStart;
                    txtBoxSender.Text = txtBoxSender.SelectedText == "" ? txtBoxSender.Text.Insert(tbPosition, newText) : txtBoxSender.Text.Replace(txtBoxSender.SelectedText, newText);
                    txtBoxSender.Select(tbPosition + 1, 0);
                    int x = string.IsNullOrEmpty(txtBoxSender.Text.Trim()) ? min : Convert.ToInt32(txtBoxSender.Text);
                    x = Math.Max(min, Math.Min(max, x));
                    txtBoxSender.Text = x.ToString();
                    //PrintDebug("     text: "+txtBoxSender.Text);
                }
            }
            catch
            {
                txtBoxSender.Text = startval;
            }
			//ChangeTextValue(txtBoxSender.Name, txtBoxSender.Text, 0);
        }
        private void menuTxtbox_KeyDownDouble(object sender, System.Windows.Input.KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtBoxSender = sender as TextBox;
            double max = int.MaxValue;
            double min = 0;
            string startval = txtBoxSender.Text;

            //PrintDebug("      max: "+max+"  min: "+min);
            try
            {
                int keyVal = (int)e.Key;
                int value = -1;
                if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9)
                    value = keyVal - (int)System.Windows.Input.Key.D0;
                else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9)
                    value = keyVal - (int)System.Windows.Input.Key.NumPad0;

                bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);

                //PrintDebug("IsNumberic: "+isNumeric.ToString());

                if (isNumeric || e.Key==System.Windows.Input.Key.Decimal || e.Key == System.Windows.Input.Key.Back)
                {
                    string newText = value != -1 ? value.ToString() : (e.Key==System.Windows.Input.Key.Decimal ? ".":"");
                    int tbPosition = txtBoxSender.SelectionStart;
                    txtBoxSender.Text = txtBoxSender.SelectedText == "" ? txtBoxSender.Text.Insert(tbPosition, newText) : txtBoxSender.Text.Replace(txtBoxSender.SelectedText, newText);
                    txtBoxSender.Select(tbPosition + 1, 0);
                    double x = string.IsNullOrEmpty(txtBoxSender.Text.Trim()) ? min : Convert.ToDouble(txtBoxSender.Text);
                    x = Math.Max(min, Math.Min(max, x));
                    txtBoxSender.Text = x.ToString();
                    //PrintDebug("     text: "+txtBoxSender.Text);
                }
            }
            catch
            {
                txtBoxSender.Text = startval;
            }
			ChangeTextValue(txtBoxSender.Name, txtBoxSender.Text, 0);
        }

        private void InformUserAboutRecalculation()
        {
            if (ChartControl != null)
            {
                if (ChartControl.Dispatcher.CheckAccess())
                {
                    miRecalculate1.Background = Brushes.Yellow;
                    miRecalculate1.FontWeight = FontWeights.Bold;
                    miRecalculate1.FontStyle = FontStyles.Italic;
                }
                else
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        miRecalculate1.Background = Brushes.Yellow;
                        miRecalculate1.FontWeight = FontWeights.Bold;
                        miRecalculate1.FontStyle = FontStyles.Italic;
                    }));
                }
            }
        }

        private void ResetRecalculationUI()
        {
            if (ChartControl != null)
            {
                if (ChartControl.Dispatcher.CheckAccess())
                {
                    miRecalculate1.FontWeight = FontWeights.Normal;
                    miRecalculate1.FontStyle = FontStyles.Normal;
                    miRecalculate1.Background = null;
                }
                else
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        miRecalculate1.FontWeight = FontWeights.Normal;
                        miRecalculate1.FontStyle = FontStyles.Normal;
                        miRecalculate1.Background = null;
                    }));
                }
            }
        }

        #region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion
        #endregion

        protected override void OnStateChange()
        {
			#region -- OnStateChange --
            if (State == State.SetDefaults)
            {
                Name = "ARC_SMC";
                Calculate = Calculate.OnPriceChange;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = ScaleJustification.Right;
                IsSuspendedWhileInactive = false;
                MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
                ShowTransparentPlotsInDataBox = true;

                ButtonText = "SMC";

                Font = new SimpleFont("Arial", 12);
                TextColor = new Stroke(Brushes.White, DashStyleHelper.Solid, 1, 100);

                // internal structure
                ShowInternalHighLow = true;
                ChoChDisplayType = ARC_SMC_DisplayType.TextAndTimeFrame;
                NumberOfChoChToDisplay = 0;
//                InsideBarStroke = new Stroke(Brushes.White, DashStyleHelper.Solid, 1, 100);
                InternalHiColor = new Stroke(Brushes.White, DashStyleHelper.Dash, 1, 100);
                InternalLowColor = new Stroke(Brushes.White, DashStyleHelper.Dash, 1, 100);
                InternalHighLowFont = new SimpleFont("Arial", 12);
                BullishChOfChColor = new Stroke(Brushes.Yellow, DashStyleHelper.Dash, 2, 100);
                BearishChOfChColor = new Stroke(Brushes.Yellow, DashStyleHelper.Dash, 2, 100);
                ChoChStructureMapping = ARC_SMC_Mapping.Candle_Wick;
                ChoChFont = new SimpleFont("Arial", 12);
                ChoChAlert = false;
                ChoChAlertSound = Path.Combine(Globals.InstallDir, "sounds", "Alert2.wav");

                // market structure
                ShowHHLL = true;
                HHLLTextColor = new Stroke(Brushes.White, DashStyleHelper.Dash, 1, 100);
                HHLLFont = new SimpleFont("Arial", 12);

                BOSDisplayType = ARC_SMC_DisplayType.TextAndTimeFrame;
                NumberOfBOSToDisplay = 0;
                ShowSwingHighLow = true;
                BOSPullBackType = ARC_SMC_PullbackMode.ATR;
                BOSATRMultiplier = 2;
                BOSATRPeriod = 14;
                BOSPullbackPercentage = 30;
                BOSPullbackTicks = 80;
                BOSAlert = false;
                BOSStructureMapping = ARC_SMC_Mapping.Candle_Close;

                StrongSwingHiColor = new Stroke(Brushes.White, DashStyleHelper.Dash, 2, 100);
                StrongSwingLowColor = new Stroke(Brushes.White, DashStyleHelper.Dash, 2, 100);
                WeakSwingHiColor = new Stroke(Brushes.White, DashStyleHelper.Dash, 2, 100);
                WeakSwingLowColor = new Stroke(Brushes.White, DashStyleHelper.Dash, 2, 100);
                SwingHighLowFont = new SimpleFont("Arial", 12);
                BullishBOSColor = new Stroke(Brushes.Blue, DashStyleHelper.Dash, 2, 100);
                BearishBOSColor = new Stroke(Brushes.Blue, DashStyleHelper.Dash, 2, 100);
                BOSFont = new SimpleFont("Arial", 12);
                BOSAlertSound = Path.Combine(Globals.InstallDir, "sounds", "Alert2.wav");

				#region ----- SMC_Swing Defaults -----
				pSwingStrength = 1;
				isHLBased     = true;
				pShowSwingLines  = true;
				pZZUpLineColor   = Brushes.Black;
				pZZDownLineColor = Brushes.Black;
				pZZLineThickness = 2;
				//pSwingLabelFontSize = 12;
				pZZlabelFont = new SimpleFont("Arial",12);
				pShowSwingLabels = false;
				#endregion
                // supply demand
                SupplyDemandDisplayType = ARC_SMC_SupplyDemandDisplayType.Bos;
                SupplyDemandType = ARC_SMC_SupplyDemandType.Wick;
                SupplyDemandBreakType = ARC_SMC_SDBroken.PremiumDiscount;
                HideBrokenSupplyDemandZones = false;
                NumberOfSDZones = 0;

                // multi time frame
                MTFBarPeriodPeriodType = BarsPeriodType.Minute;
                MTFBarPeriodPeriodValue = 15;
                MTFBarsToLoad = 1000;
                UseMTF = false;
                _MTFLabel = "15m";

                // trend
                ShowTrend = true;
                TrendBosCount = 1;
                PositionX = 20;
                PositionY = 50;
                DemandColor = new Stroke(Brushes.Green, DashStyleHelper.Dash, 2f, 65);
                SupplyColor = new Stroke(Brushes.Red, DashStyleHelper.Dash, 2f, 55);

                BullishTrendBar = new Stroke(Brushes.LightGreen, DashStyleHelper.Solid, 2f, 100);
                BearishTrendBar = new Stroke(Brushes.Red, DashStyleHelper.Solid, 2f, 100);

                // fibonacci
                ShowFibRetracements = true;
                ShowFibNumbers = true;
                FibonacciType = ARC_SMC_FibonacciType.Cluster;
                FibRetracement1 = 25;
                FibRetracement1Color = new Stroke(Brushes.Turquoise, DashStyleHelper.Dash, 2f, 100);

                FibRetracement2 = 50;
                FibRetracement2Color = new Stroke(Brushes.Gold, DashStyleHelper.Dash, 2f, 100);

                FibRetracement3 = 75;
                FibRetracement3Color = new Stroke(Brushes.Crimson, DashStyleHelper.Dash, 2f, 100);

                FibRetracementAnchorStroke = new Stroke(Brushes.DimGray, DashStyleHelper.Dash, 1f, 100);
                SupplyDemandCenter = new Stroke(Brushes.Gainsboro, DashStyleHelper.Dash, 1f, 100);

                AddPlot(Brushes.Transparent, "ChangeOfCharacter");
                AddPlot(Brushes.Transparent, "BreakOfStructure");
                AddPlot(Brushes.Transparent, "FibRetracement1");
                AddPlot(Brushes.Transparent, "FibRetracement2");
                AddPlot(Brushes.Transparent, "FibRetracement3");
            }
            else if (State == State.Configure)
            {
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion

				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");

				if (UseMTF)
                {
                    var barsPeriod = new BarsPeriod
                    {
                        BarsPeriodType = MTFBarPeriodPeriodType,
                        Value = MTFBarPeriodPeriodValue
                    };
                    if (!TradingHoursInstance.Name.StartsWith("<"))
                    {
                        AddDataSeries(Instrument.FullName, barsPeriod, MTFBarsToLoad, TradingHoursInstance.Name, true);
                    }
                    else
                    {
                        AddDataSeries(Instrument.FullName, barsPeriod, MTFBarsToLoad, Instrument.MasterInstrument.TradingHours.Name, true);
                    }
                }

                GetMTFLabel(UseMTF
                        ? MTFBarPeriodPeriodType
                        : BarsPeriods[0].BarsPeriodType,
                    UseMTF
                        ? MTFBarPeriodPeriodValue
                        : BarsPeriods[0].Value
                );
            }
            else if (State == State.Terminated)
            {
                if (chartWindow != null && indytoolbar != null)
                {
                    if (ChartControl.Dispatcher.CheckAccess())
                    {
                        chartWindow.MainMenu.Remove(indytoolbar);
                        indytoolbar = null;

                        chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
                        chartWindow = null;
                    }
                    else
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            chartWindow.MainMenu.Remove(indytoolbar);
                            indytoolbar = null;

                            chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
                            chartWindow = null;
                        }));
                    }
                }
            }
            else if (State == State.DataLoaded)
            {
				StructureMgr = new StructureBiasClass(Highs[0], Lows[0], pSwingStrength, isHLBased, Calculate==Calculate.OnBarClose, this);
                uID = Guid.NewGuid().ToString().Replace("-", string.Empty);
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        ChartControl.AllowDrop = false;
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;

                        foreach (DependencyObject item in chartWindow.MainMenu) if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

                            addToolBar();

                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            System.Windows.Automation.AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                }
                #endregion

            }
			#endregion
        }

        private void SendAlert(string sound, string message)
        {
            try
            {
                if (Math.Abs(_prevAlertBar - CurrentBars[0]) <= 1)
                {
                    return;
                }

                _prevAlertBar = CurrentBars[0];
                Alert(string.Empty, Priority.High, message, sound, 0, Brushes.Transparent, Brushes.White);
            }
            catch
            {
            }
        }

        private void GetMTFLabel(BarsPeriodType barPeriodType, int barPeriodValue)
        {
            switch (barPeriodType)
            {
                case BarsPeriodType.Minute:
                    if (barPeriodValue < 60)
                    {
                        _MTFLabel = string.Format("{0}m", barPeriodValue);
                    }
                    else
                    {
                        _MTFLabel = string.Format("{0}H", barPeriodValue / 60);
                    }

                    break;

                case BarsPeriodType.Week:
                    _MTFLabel = barPeriodValue > 1 ? string.Format("{0}W", barPeriodValue) : "W";

                    break;
                case BarsPeriodType.Month:
                    _MTFLabel = barPeriodValue > 1 ? string.Format("{0}M", barPeriodValue) : "M";

                    break;

                case BarsPeriodType.Day:
                    _MTFLabel = barPeriodValue > 1 ? string.Format("{0}D", barPeriodValue) : "D";

                    break;

                case BarsPeriodType.Tick:
                    _MTFLabel = string.Format("{0}T", barPeriodValue);

                    break;

                case BarsPeriodType.Volume:
                    _MTFLabel = string.Format("{0}V", barPeriodValue);

                    break;

                case BarsPeriodType.Range:
                    _MTFLabel = string.Format("{0}R", barPeriodValue);
                    break;

                case BarsPeriodType.Renko:
                    _MTFLabel = string.Format("{0} renko", barPeriodValue);
                    break;

                default:
                    if (!UseMTF)
                        _MTFLabel = string.Format("{0}", BarsPeriods[0].ToString());
                    else
                        _MTFLabel = string.Format("{0}{1}", barPeriodType, barPeriodValue);
                    break;
            }
        }

        protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
            _now = Time[0];
            DetectSwingHiLos();
            DetectBos();
            SetFibLevels();

            if (BarsInProgress == 0 && CurrentBars[0] > 2)
            {
				bool IsUpClosing = High[0]-Close[0] < Close[0]-Low[0];//if the close is nearer to the high, then it's an upclosing bar
				if(IsFirstTickOfBar)
					StructureMgr.CalculateIt(CurrentBar, IsUpClosing, IsFirstTickOfBar, Calculate, State);

				_currentClosePrice = Close[0];
                _currentLowPrice = Low[0];
                _currentHighPrice = High[0];
                DetectBrokenSupplyDemand(1);

                _currentTime = Times[0][0];
                if (_prevBar != CurrentBar)
                {
                    _prevBar = CurrentBar;
                    DetectBosTrend();

                    DetectChangeOfCharacter();
                }
                DoPaintBars();
            }
        }

        private int _trend = 0;

        private void DetectBosTrend()
        {
            var bosCnt = 0;
            for (var i = 0; i < _bos.Count; ++i)
            {
                var bos = _bos[i];

                if (bos.IsBullish)
                {
                    if (bosCnt >= 0) bosCnt++;
                    else bosCnt = 1;
                }
                else
                {
                    if (bosCnt <= 0) bosCnt--;
                    else bosCnt = -1;
                }

                if (Math.Abs(bosCnt) >= TrendBosCount)
                {
                    _trend = bosCnt > 0 ? 1 : -1;
                }
            }
        }

        private void DoPaintBars()
        {
            CandleOutlineBrushes[0] = null;
            BarBrushes[0] = null;
            if (PaintBars)
            {
				if(ChartBars.Properties.ChartStyle.ToString().Contains("CandleStyle")){
					if(_trend > 0){
			            CandleOutlineBrushes[0] = BullishTrendBar.Brush;
		    	        BarBrushes[0] = Closes[0][0] > Opens[0][0] ? Brushes.Transparent : BullishTrendBar.Brush;
					}else{
		            	CandleOutlineBrushes[0] = BearishTrendBar.Brush;
		            	BarBrushes[0] = Closes[0][0] > Opens[0][0] ? Brushes.Transparent : BearishTrendBar.Brush;
					}
				}else{
					if(_trend > 0){
			            CandleOutlineBrushes[0] = BullishTrendBar.Brush;
		    	        BarBrushes[0] = BullishTrendBar.Brush;
					}else{
		            	CandleOutlineBrushes[0] = BearishTrendBar.Brush;
		            	BarBrushes[0] = BearishTrendBar.Brush;
					}
				}
			}
        }

        private void SetFibLevels()
        {
            if (BarsInProgress != 0) return;
            if (_swingLowTime < _swingHighTime)
            {
                //from low->high
                var range = _swingHighPrice - _swingLowPrice;
                FibonacciLevel1[0] = _swingHighPrice - FibRetracement1 / 100d * range;
                FibonacciLevel2[0] = _swingHighPrice - FibRetracement2 / 100d * range;
                FibonacciLevel3[0] = _swingHighPrice - FibRetracement3 / 100d * range;
            }
            else
            {
                //from high-low
                var range = _swingHighPrice - _swingLowPrice;
                FibonacciLevel1[0] = _swingLowPrice + FibRetracement1 / 100d * range;
                FibonacciLevel2[0] = _swingLowPrice + FibRetracement2 / 100d * range;
                FibonacciLevel3[0] = _swingLowPrice + FibRetracement3 / 100d * range;
            }
        }


        #region Supply/Demand Zones
        private void AddSupplyZone(int hiBar, ARC_SMC_SupplyDemandDisplayType sdType)
        {
            // find last buy before the sell
            var series = UseMTF ? 1 : 0;
            var currentBar = CurrentBars[series];
            var barsAgo = currentBar - hiBar;
            var hiBarHigh = Highs[series][barsAgo];
            while (hiBar >= 0)
            {
                barsAgo = currentBar - hiBar;
                var open = Opens[series][barsAgo];
                var close = Closes[series][barsAgo];
                if (close > open)
                {
                    break;
                }

                hiBar--;
            }

            barsAgo = currentBar - hiBar;

            if (hiBar < 0 || hiBar >= currentBar)
            {
                return;
            }

            var time = Times[series][barsAgo];
            var lowPrice = Lows[series][barsAgo];
            var highPrice = Highs[series][barsAgo];
            var openPrice = Opens[series][barsAgo];
            var closePrice = Closes[series][barsAgo];
            var bodyLow = Math.Min(openPrice, closePrice);
            var bodyHigh = Math.Max(openPrice, closePrice);
            var zone = new SupplyDemandZone
            {
                PriceLow = SupplyDemandType == ARC_SMC_SupplyDemandType.Candle ? lowPrice : bodyHigh,
                PriceHigh = Math.Max(hiBarHigh, highPrice),
                StartBar = hiBar,
                StartTime = time,
                EndBar = 0,
                EndTime = DateTime.MinValue,
                IsDemand = false,
                SDType = sdType
            };
            _supplyDemandZones.Add(zone);
            DetectBrokenZone(zone);
        }

        private void AddDemandZone(int lowBar, ARC_SMC_SupplyDemandDisplayType sdType)
        {
            // find last sell before the buy
            var series = UseMTF ? 1 : 0;
            var currentBar = CurrentBars[series];
            var barsAgo = currentBar - lowBar;
            var lowBarLow = Lows[series][barsAgo];

            while (lowBar >= 0)
            {
                barsAgo = currentBar - lowBar;
                var open = Opens[series][barsAgo];
                var close = Closes[series][barsAgo];
                if (close < open)
                {
                    break;
                }

                lowBar--;
            }

            barsAgo = currentBar - lowBar;

            if (lowBar < 0 || lowBar >= CurrentBar)
            {
                return;
            }

            var time = Times[series][barsAgo];
            var lowPrice = Lows[series][barsAgo];
            var highPrice = Highs[series][barsAgo];
            var openPrice = Opens[series][barsAgo];
            var closePrice = Closes[series][barsAgo];
            var bodyLow = Math.Min(openPrice, closePrice);
            var bodyHigh = Math.Max(openPrice, closePrice);

            var zone = new SupplyDemandZone
            {
                PriceLow = Math.Min(lowBarLow, lowPrice),
                PriceHigh = SupplyDemandType == ARC_SMC_SupplyDemandType.Candle ? highPrice : bodyLow,
                StartBar = lowBar,
                StartTime = time,
                EndBar = 0,
                EndTime = DateTime.MinValue,
                IsDemand = true,
                SDType = sdType
            };
            _supplyDemandZones.Add(zone);
            DetectBrokenZone(zone);
        }
        private void DetectBrokenZone(SupplyDemandZone zone)
        {
            if (CurrentBars[0] < 2) return;
            var currentBar = CurrentBars[0];
            for (var bar = 0; bar < currentBar; ++bar)
            {
                var barsAgo = currentBar - bar;
                var time = Times[0][barsAgo];
                if (time > zone.StartTime)
                {
                    DetectIfZoneIsBroken(barsAgo, zone);

                    if (zone.EndBar > 0) return;
                }
            }
        }

        private void DetectBrokenSupplyDemand(int barsAgo)
        {
            var levels = _supplyDemandZones.Where(e => e.EndBar == 0).ToList();
            foreach (var zone in levels)
            {
                DetectIfZoneIsBroken(barsAgo, zone);
            }
        }

        private void DetectIfZoneIsBroken(int barsAgo, SupplyDemandZone zone)
        {
            var close0 = Closes[0][barsAgo];
            var low0 = Lows[0][barsAgo];
            var high0 = Highs[0][barsAgo];
            var currentBar = CurrentBars[0] - barsAgo;
            var time0 = Times[0][barsAgo];

            if (zone.PriceClosedOutsideZone)
            {
                if (SupplyDemandBreakType == ARC_SMC_SDBroken.Close)
                {
                    if (zone.IsDemand && close0 <= zone.PriceLow)
                    {
                        zone.EndBar = currentBar;
                        zone.EndTime = time0;
                    }
                    else if (zone.IsSupply && close0 >= zone.PriceHigh)
                    {
                        zone.EndBar = currentBar;
                        zone.EndTime = time0;
                    }
                }
                else if (SupplyDemandBreakType == ARC_SMC_SDBroken.Wick)
                {
                    if (zone.IsDemand && low0 <= zone.PriceHigh)
                    {
                        zone.EndBar = currentBar;
                        zone.EndTime = time0;
                    }
                    else if (zone.IsSupply && high0 >= zone.PriceLow)
                    {
                        zone.EndBar = currentBar;
                        zone.EndTime = time0;
                    }
                }
                else if (SupplyDemandBreakType == ARC_SMC_SDBroken.PremiumDiscount)
                {
                    var range = Math.Abs(zone.PriceHigh - zone.PriceLow) / 2;
                    if (zone.IsDemand && low0 <= zone.PriceHigh - range)
                    {
                        zone.EndBar = currentBar;
                        zone.EndTime = time0;
                    }
                    else if (zone.IsSupply && high0 >= zone.PriceLow + range)
                    {
                        zone.EndBar = currentBar;
                        zone.EndTime = time0;
                    }
                }
            }
            else
            {
                if ((close0 < zone.PriceLow || close0 > zone.PriceHigh))
                {
                    zone.PriceClosedOutsideZone = true;
                }
            }
        }
        #endregion

        #region properties


        //-------------------------------
		#region -- 01. General --
        [Display(Name = "Show trend", Order = 1, GroupName = "01. General")]
        public bool ShowTrend { get; set; }

        [Display(Name = "Trend position", Order = 2, GroupName = "01. General")]
        public ARC_SMC_TrendPosition TrendPosition { get; set; }

        [Display(Name = "# BOS needed for trend change", Order = 2, GroupName = "01. General")]
        public int TrendBosCount { get; set; }

        [Display(Name = "    X offset (pixels)", Order = 3, GroupName = "01. General")]
        public int PositionX { get; set; }

        [Display(Name = "    Y offset (pixels)", Order = 4, GroupName = "01. General")]
        public int PositionY { get; set; }

        [Display(Name = "Show trend Paint Bars", Order = 5, GroupName = "01. General")]
        public bool PaintBars { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "    Candle Bullish Trend", GroupName = "01. General", Order = 7)]
        public Stroke BullishTrendBar { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "    Candle Bearish Trend", GroupName = "01. General", Order = 8)]
        public Stroke BearishTrendBar { get; set; }
		#endregion

        [Display(Order = 1000, Name = "Button text", GroupName = "Custom Visuals", Description = "")]
        public string ButtonText { get; set; }

		#region -- 02. Multi Timeframe --
        [NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Use MTF", GroupName = "02. Multi Timeframe", Order = 10)]
        public bool UseMTF { get; set; }


        [NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "    MTF Period Type", GroupName = "02. Multi Timeframe", Order = 11)]
        public BarsPeriodType MTFBarPeriodPeriodType { get; set; }


        [NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "    MTF Period value", GroupName = "02. Multi Timeframe", Order = 13)]
        public int MTFBarPeriodPeriodValue { get; set; }


        [NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "    MTF Trading Hours", GroupName = "02. Multi Timeframe", Order = 14)]
        [PropertyEditor("NinjaTrader.Gui.Tools.StringStandardValuesEditorKey")]
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(TradingHoursDataConverter))]
        [XmlIgnore]
        public TradingHours TradingHoursInstance
        {
            get
            {
                if (TradingHoursSerializable.Length > 0)
                {
                    var result = TradingHours.All.FirstOrDefault(t => t.Name == TradingHoursSerializable);
                    if (result != null)
                    {
                        return result;
                    }
                }

                return TradingHours.UseInstrumentSettingsInstance; // return default in case not found (e.g. legacy UseInstrumentSettings in TradingHoursTemplate)
            }

            set { TradingHoursSerializable = value == TradingHours.UseInstrumentSettingsInstance ? string.Empty : value.Name; }
        }

        [Browsable(false)]
        public string TradingHoursSerializable
        {
            get { return _tradingHoursSerializable; }

            set { _tradingHoursSerializable = value; }
        }

        [Display(ResourceType = typeof(Custom.Resource), Name = "    MTF Bars to load", GroupName = "02. Multi Timeframe", Order = 15)]
        public int MTFBarsToLoad { get; set; }
		#endregion
        //-------------------------------

		#region -- 03. Swing structure --
        [NinjaScriptProperty]
        [Display(Name = "Show Strong/Weak High/Low", Order = 1, GroupName = "03. Swing structure")]
        public bool ShowSwingHighLow { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show HH/LL", Order = 2, GroupName = "03. Swing structure")]
        public bool ShowHHLL { get; set; }

        [NinjaScriptProperty]
        [RefreshProperties(RefreshProperties.All)]
        [Display(Name = "BOS display type", Order = 3, GroupName = "03. Swing structure")]
        public ARC_SMC_DisplayType BOSDisplayType { get; set; }

        [Display(Name = "BOS Structure mapping", Order = 4, GroupName = "03. Swing structure")]
        public ARC_SMC_Mapping BOSStructureMapping { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Number of BOS to display (0=all)", Order = 5, GroupName = "03. Swing structure")]
        public int NumberOfBOSToDisplay { get; set; }

        [NinjaScriptProperty]
        [RefreshProperties(RefreshProperties.All)]
        [Display(Name = "BOS Pullback detection mode", Order = 7, GroupName = "03. Swing structure")]
        public ARC_SMC_PullbackMode BOSPullBackType { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "    ATR Period", Order = 8, GroupName = "03. Swing structure")]
        public int BOSATRPeriod { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "    ATR Multiplier", Order = 9, GroupName = "03. Swing structure")]
        public double BOSATRMultiplier { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "    Pullback (%)", Order = 10, GroupName = "03. Swing structure")]
        public double BOSPullbackPercentage { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "    Pullback (ticks)", Order = 11, GroupName = "03. Swing structure")]
        public double BOSPullbackTicks { get; set; }


        [NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "BOS Alert", GroupName = "03. Swing structure", Order = 15)]
        public bool BOSAlert { get; set; }

        [PropertyEditor("NinjaTrader.Gui.Tools.FilePathPicker", Filter = "WAV Files (*.wav)|*.wav")]
        [Display(ResourceType = typeof(Custom.Resource), Name = "BOS Alert Sound", GroupName = "03. Swing structure", Order = 16)]
        public string BOSAlertSound { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Bullish Break of structure (BOS)", Description = "Break of structure", GroupName = "03. Swing structure", Order = 20)]
        public Stroke BullishBOSColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Bearish Break of structure (BOS)", Description = "Break of structure", GroupName = "03. Swing structure", Order = 21)]
        public Stroke BearishBOSColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "BOS Text Font", GroupName = "03. Swing structure", Order = 22)]
        public SimpleFont BOSFont { get; set; }


        [Display(ResourceType = typeof(Custom.Resource), Name = "Strong Swing High Color", GroupName = "03. Swing structure", Order = 23)]
        public Stroke StrongSwingHiColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Strong Swing Low Color", GroupName = "03. Swing structure", Order = 24)]
        public Stroke StrongSwingLowColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Weak Swing High Color", GroupName = "03. Swing structure", Order = 25)]
        public Stroke WeakSwingHiColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Weak Swing Low Color", GroupName = "03. Swing structure", Order = 26)]
        public Stroke WeakSwingLowColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Swing High/Low Text Font", GroupName = "03. Swing structure", Order = 27)]
        public SimpleFont SwingHighLowFont { get; set; }


        [Display(ResourceType = typeof(Custom.Resource), Name = "HH/LL Text Color", GroupName = "03. Swing structure", Order = 28)]
        public Stroke HHLLTextColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "HH/LL Text Font", GroupName = "03. Swing structure", Order = 29)]
        public SimpleFont HHLLFont { get; set; }
		#endregion

        //-------------------------------------------
		#region -- 04. Internal Market Structure --
        [NinjaScriptProperty]
        [Display(Name = "Show Internal structure High/Low", Order = 1, GroupName = "04. Internal Market Structure")]
        public bool ShowInternalHighLow { get; set; }


        [RefreshProperties(RefreshProperties.All)]
        [NinjaScriptProperty]
        [Display(Name = "ChoCh Display type", Order = 2, GroupName = "04. Internal Market Structure")]
        public ARC_SMC_DisplayType ChoChDisplayType { get; set; }

        [Display(Name = "ChoCh Structure mapping", Order = 3, GroupName = "04. Internal Market Structure")]
        public ARC_SMC_Mapping ChoChStructureMapping { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Number of ChoCh to display (0=all)", Order = 4, GroupName = "04. Internal Market Structure")]
        public int NumberOfChoChToDisplay { get; set; }


        [Display(ResourceType = typeof(Custom.Resource), Name = "ChoCh Alert", GroupName = "04. Internal Market Structure", Order = 5)]
        public bool ChoChAlert { get; set; }

        [PropertyEditor("NinjaTrader.Gui.Tools.FilePathPicker", Filter = "WAV Files (*.wav)|*.wav")]
        [Display(ResourceType = typeof(Custom.Resource), Name = "ChoCh Alert Sound", GroupName = "04. Internal Market Structure", Order = 6)]
        public string ChoChAlertSound { get; set; }

//        [Display(Name = "Inside Bar Color", Order = 7, GroupName = "04. Internal Market Structure")]
//        public Stroke InsideBarStroke { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "ChoCh Text Font", GroupName = "04. Internal Market Structure", Order = 8)]
        public SimpleFont ChoChFont { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Bullish Change of Character (ChoCh)", Description = "Change of Character", GroupName = "04. Internal Market Structure", Order = 11)]
        public Stroke BullishChOfChColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Bearish Change of Character (ChoCh)", Description = "Change of Character", GroupName = "04. Internal Market Structure", Order = 12)]
        public Stroke BearishChOfChColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Internal High Color", GroupName = "04. Internal Market Structure", Order = 14)]
        public Stroke InternalHiColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Internal Low Color", GroupName = "04. Internal Market Structure", Order = 15)]
        public Stroke InternalLowColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Internal High/Low Text Font", GroupName = "04. Internal Market Structure", Order = 16)]
        public SimpleFont InternalHighLowFont { get; set; }
		#endregion

		#region -- 05. Supply/Demand --
        [Display(Name = "Show supply/demand", Order = 1, GroupName = "05. Supply/Demand")]
        public ARC_SMC_SupplyDemandDisplayType SupplyDemandDisplayType { get; set; }

        [Display(Name = "Hide broken zones", Order = 4, GroupName = "05. Supply/Demand")]
        public bool HideBrokenSupplyDemandZones { get; set; }


        [Display(Name = "Number of zones to display (0=all)", Order = 4, GroupName = "05. Supply/Demand")]
        public int NumberOfSDZones { get; set; }

        [Display(Name = "Supply/demand type", Order = 5, GroupName = "05. Supply/Demand")]
        public ARC_SMC_SupplyDemandType SupplyDemandType { get; set; }

        [Display(Name = "Supply/demand breaks at", Order = 6, GroupName = "05. Supply/Demand")]
        public ARC_SMC_SDBroken SupplyDemandBreakType { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Supply", Description = "Weak High/Low", GroupName = "05. Supply/Demand", Order = 10)]
        public Stroke SupplyColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Demand", Description = "Weak High/Low", GroupName = "05. Supply/Demand", Order = 11)]
        public Stroke DemandColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Mid", Description = "Mid", GroupName = "05. Supply/Demand", Order = 12)]
        public Stroke SupplyDemandCenter { get; set; }
		#endregion
        //-------------------------------------------------------------------------------------------------------
		#region -- 06. Auction Curve --
        [NinjaScriptProperty]
        [Display(Name = "Show Auction Curve", Order = 1, GroupName = "06. Auction Curve")]
        public bool ShowFibRetracements { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Auction Curve Numbers", Order = 2, GroupName = "06. Auction Curve")]
        public bool ShowFibNumbers { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Auction Curve levels as ", Order = 3, GroupName = "06. Auction Curve")]
        public ARC_SMC_FibonacciType FibonacciType { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "1. Auction Curve % ", Order = 4, GroupName = "06. Auction Curve")]
        public double FibRetracement1 { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "2. Auction Curve % ", Order = 5, GroupName = "06. Auction Curve")]
        public double FibRetracement2 { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "3. Auction Curve % ", Order = 6, GroupName = "06. Auction Curve")]
        public double FibRetracement3 { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "1. Auction Curve Color", GroupName = "06. Auction Curve", Order = 13)]
        public Stroke FibRetracement1Color { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "2. Auction Curve Color", GroupName = "06. Auction Curve", Order = 15)]
        public Stroke FibRetracement2Color { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "3. Auction Curve Color", GroupName = "06. Auction Curve", Order = 17)]
        public Stroke FibRetracement3Color { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Anchor color", GroupName = "06. Auction Curve", Order = 20)]
        public Stroke FibRetracementAnchorStroke { get; set; }
		#endregion
        //-------------------------------------------------------------------------------------------------------
		#region -- 07. SMC_Swing --
		public bool UseSessionDate = true;//{get;set;}

		[Display(Name = "Use Highs/Lows", GroupName = "SwingTrend Parameters", Description = "Use High/Lows or Input", Order = 5)]
		public bool isHLBased { get; set; }

		[Range(1, 200)]
		[Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 10)]
		public int pSwingStrength { get; set; }

		#endregion

		#region Custom Visuals
		[Display(Name = "Show Lines", GroupName = "SwingTrend Parameters", Description = "Show structure trend lines", Order = 20)]
		public bool pShowSwingLines {get;set;}

		[XmlIgnore]
		[Display(Name = "Up-trend line color", GroupName = "SwingTrend Parameters", Description = "Line color for up-trending structure", Order = 30)]
		public System.Windows.Media.Brush pZZUpLineColor { get; set; }
		[Browsable(false)]
		public string zzUpLineColorSerialize
		{get { return Serialize.BrushToString(pZZUpLineColor); }
		                                set { pZZUpLineColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Down-trend line color", GroupName = "SwingTrend Parameters", Description = "Line color for down-trending structure", Order = 40)]
		public System.Windows.Media.Brush pZZDownLineColor { get; set; }
		[Browsable(false)]
		public string zzDownLineColorSerialize
		{get { return Serialize.BrushToString(pZZDownLineColor); }
		                                set { pZZDownLineColor = Serialize.StringToBrush(value); }}
		[Range(1, 10)]
		[Display(Name = "Line Thickness", GroupName = "SwingTrend Parameters", Description = "Thickness of structure lines", Order = 50)]
		public int pZZLineThickness {get;set;}

		[Display(Name = "Show Labels", GroupName = "SwingTrend Parameters", Description = "Show zigzag labels (e.g. 'HH' or 'LH', etc)", Order = 60)]
		public bool pShowSwingLabels{get;set;}

		[Display(Name = "Font size", GroupName = "SwingTrend Parameters", Description = "Font for structure labels", Order = 70)]
        public SimpleFont pZZlabelFont { get; set; }
		#endregion
		#region -- 09. Visual --
        [Display(ResourceType = typeof(Custom.Resource), Name = "Text Color", Description = "Text Color", GroupName = "09. Visual", Order = 17)]
        public Stroke TextColor { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "Text Font", GroupName = "09. Visual", Order = 18)]
        public SimpleFont Font { get; set; }
		#endregion

		#endregion

		#region -- Plots --
        [Browsable(false)]
        [XmlIgnore]
        public Series<double> ChangeOfCharacter
        {
            get { return Values[0]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> BreakOfStructure
        {
            get { return Values[1]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> FibonacciLevel1
        {
            get { return Values[2]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> FibonacciLevel2
        {
            get { return Values[3]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> FibonacciLevel3
        {
            get { return Values[4]; }
        }

        #endregion

        #region Market structure / Break of structure

        private void DetectBos()
        {
            var series = UseMTF ? 1 : 0;

            if (BarsInProgress != series)
            {
                return;
            }

            var currentBar = CurrentBars[series];

            if (currentBar < 2 || CurrentBars[0] < 2)
            {
                return;
            }
            //   NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "dt-l" + CurrentBar, false, 0, _swingLowPrice, Brushes.Red);
            //   NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "dt-h" + CurrentBar, false, 0, _swingHighPrice, Brushes.Lime);

            if (_prevBarBOS != currentBar)
            {
                BreakOfStructure[0] = 0;
                _prevBarBOS = currentBar;
                var close1 = Closes[series][1];
                var low1 = Lows[series][1];
                var high1 = Highs[series][1];
                var lowPivot = _lowPivots.LastOrDefault();

                if (lowPivot != null)
                {
                    var isLowBroken = BOSStructureMapping == ARC_SMC_Mapping.Candle_Close
                      ? close1 < lowPivot.Price
                      : low1 < lowPivot.Price;
                    if (!lowPivot.IsBroken && isLowBroken)
                    {
                        // NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "dt-l" + CurrentBar, false, 0, lowPivot.Price, Brushes.Red);

                        BreakOfStructure[0] = -1;
                        lowPivot.IsBroken = true;
                        var bos = new PriceBreak
                        {
                            StartBar = lowPivot.Bar,
                            StartTime = lowPivot.Time,
                            Price = lowPivot.Price,
                            EndBar = currentBar - 1,
                            EndTime = Times[series][1],
                            IsBullish = false
                        };
                        DetectOverlappingChocs(bos);
                        _bos.Add(bos);

                        //Print(string.Format("{0} {1} Bos Down #{2} {3}", CurrentBar, Time[0], lowPivot.Bar, lowPivot.Price));
                        if (BOSAlert)
                        {
                            SendAlert(BOSAlertSound, string.Format("{0} BOS-{1} Down", Instrument.FullName, _MTFLabel));
                        }
                        var highPivot = _hiPivots.Last();

                        AddSupplyZone(highPivot.Bar, ARC_SMC_SupplyDemandDisplayType.Bos);
                        _swingLowPrice = lowPivot.BarLowPrice;
                        _swingLowTime = lowPivot.Time;
                        _swingLowBar = lowPivot.Bar;
                        _swingLow.PullBack = false;
                        FindSwingHigh();
                    }
                }

                var hiPivot = _hiPivots.LastOrDefault();
                if (hiPivot != null)
                {
                    var isHighBroken = BOSStructureMapping == ARC_SMC_Mapping.Candle_Close
                      ? close1 > hiPivot.Price
                      : high1 > hiPivot.Price;
                    if (!hiPivot.IsBroken && isHighBroken)
                    {
                        BreakOfStructure[0] = 1;
                        hiPivot.IsBroken = true;
                        var bos = new PriceBreak
                        {
                            StartBar = hiPivot.Bar,
                            StartTime = hiPivot.Time,
                            Price = hiPivot.Price,
                            EndBar = currentBar - 1,
                            EndTime = Times[series][1],
                            IsBullish = true
                        };
                        _bos.Add(bos);
                        DetectOverlappingChocs(bos);

                        //Print(string.Format("{0} {1} Bos Up #{2} {3}", CurrentBar, Time[0], hiPivot.Bar, hiPivot.Price));
                        if (BOSAlert)
                        {
                            SendAlert(BOSAlertSound, string.Format("{0} BOS-{1} Up", Instrument.FullName, _MTFLabel));
                        }

                        lowPivot = _lowPivots.Last();

                        AddDemandZone(lowPivot.Bar, ARC_SMC_SupplyDemandDisplayType.Bos);


                        _swingHighPrice = hiPivot.BarHighPrice;
                        _swingHighTime = hiPivot.Time;
                        _swingHighBar = hiPivot.Bar;
                        _swingHi.PullBack = false;
                        FindSwingLow();
                    }
                }
            }

            var low = Lows[series][0];
            var high = Highs[series][0];
            var time = Times[series][0];
            if (low < _swingLowPrice)
            {
                _swingLowPrice = low;
                _swingLowTime = time;
                _swingLowBar = currentBar;
            }

            if (high > _swingHighPrice)
            {
                _swingHighPrice = high;
                _swingHighTime = time;
                _swingHighBar = currentBar;
            }
        }

        private void DetectSwingHiLos()
        {
            var series = UseMTF ? 1 : 0;

            if (BarsInProgress != series)
            {
                return;
            }

            var currentBar = CurrentBars[series];

            if (currentBar < 2)
            {
                return;
            }

            var open0 = Opens[series][1];
            var close0 = Closes[series][1];
            var high0 = Highs[series][1];
            var low0 = Lows[series][1];
            var time = Times[series][1];

            if (_warmUpPhase)
            {
                if (currentBar < 10)
                {
                    // determine swing hi/low 
                    if (low0 < _swingLow.Price)
                    {
                        _swingLow.BarHighPrice = high0;
                        _swingLow.BarLowPrice = low0;
                        _swingLow.BarOpenPrice = open0;
                        _swingLow.BarClosePrice = close0;

                        _swingLow.Price = low0;
                        _swingLow.Bar = currentBar;
                        _swingLow.Time = time;
                    }

                    if (high0 > _swingHi.Price)
                    {
                        _swingHi.BarHighPrice = high0;
                        _swingHi.BarLowPrice = low0;
                        _swingHi.BarOpenPrice = open0;
                        _swingHi.BarClosePrice = close0;
                        _swingHi.Price = high0;
                        _swingHi.Bar = currentBar;
                        _swingHi.Time = time;
                    }

                    return;
                }

                // add swing hi/low
                if (_swingHi.Bar < _swingLow.Bar)
                {
                    // hi occured before the swing low
                    _allPivots.Add(_swingHi);
                    _allPivots.Add(_swingLow);
                }
                else
                {
                    // low occured before the swing high
                    _allPivots.Add(_swingLow);
                    _allPivots.Add(_swingHi);
                }

                _swingHi.PullBack = true;
                _swingLow.PullBack = true;
                _hiPivots.Add(_swingHi);
                _lowPivots.Add(_swingLow);
                _swingHi = _swingHi.Clone();
                _swingLow = _swingLow.Clone();
                _warmUpPhase = false;
            }

            var prevSwingHi = _hiPivots.Last();
            var prevSwingLow = _lowPivots.Last();
            if (_prevBarSwing == currentBar)
            {
                return;
            }

            _prevBarSwing = currentBar;
            //  NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "pdt-l" + CurrentBar, false, 0, prevSwingLow.Price, Brushes.Magenta);
            //    NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "pdt-h" + CurrentBar, false, 0, prevSwingHi.Price, Brushes.Yellow);

            if (low0 < prevSwingLow.Price && close0 < prevSwingLow.Price)
            {
                if (low0 < _swingLow.BarLowPrice)
                {
                    if (_swingLow.Price < prevSwingLow.Price && _swingLow.PullBack)
                    {
                        _swingLow.Label = _swingLow.Price < prevSwingLow.Price ? "LL" : "HL";
                        //Print(string.Format("{0} {1} swing lo prev:#{2} {3} #{4} {5}", CurrentBar, Time[0], prevSwingLow.Bar, prevSwingLow.Price, _swingLow.Bar, _swingLow.Price));
                        _allPivots.Add(_swingLow);
                        _lowPivots.Add(_swingLow);
                        _swingLow = _swingLow.Clone();
                    }

                    _swingLow.BarHighPrice = high0;
                    _swingLow.BarLowPrice = low0;
                    _swingLow.BarOpenPrice = open0;
                    _swingLow.BarClosePrice = close0;
                    _swingLow.Price = low0;
                    _swingLow.Bar = currentBar - 1;
                    _swingLow.Time = time;
                    _swingLow.PullBack = false;
                }
            }
            else if (high0 > prevSwingHi.Price && close0 > prevSwingHi.Price)
            {
                if (high0 > _swingHi.BarHighPrice)
                {
                    if (_swingHi.Price > prevSwingHi.Price && _swingHi.PullBack)
                    {
                        _swingHi.Label = _swingHi.Price > prevSwingHi.Price ? "HH" : "LH";
                        //Print(string.Format("{0} {1} swing hi prev:#{2} {3} > #{4} {5}", CurrentBar, Time[0], prevSwingHi.Bar, prevSwingHi.Price, _swingHi.Bar, _swingHi.Price));
                        _allPivots.Add(_swingHi);
                        _hiPivots.Add(_swingHi);
                        _swingHi = _swingHi.Clone();
                    }
                    _swingHi.BarHighPrice = high0;
                    _swingHi.BarLowPrice = low0;
                    _swingHi.BarOpenPrice = open0;
                    _swingHi.BarClosePrice = close0;
                    _swingHi.Price = high0;
                    _swingHi.Bar = currentBar - 1;
                    _swingHi.Time = time;
                    _swingHi.PullBack = false;
                }
            }
            switch (BOSPullBackType)
            {
                case ARC_SMC_PullbackMode.ATR:
                    {
                        var useBOSATRRange = true;
                        var minBOSRange = ATR(Closes[series], BOSATRPeriod)[0] * BOSATRMultiplier;

                        var threshold = _swingLow.Price + minBOSRange;
                        if (!_swingLow.PullBack)
                        {
                            if (currentBar - 1 > _swingLow.Bar)
                            {
                                if ((useBOSATRRange && high0 >= threshold) || (!useBOSATRRange && close0 > _swingLow.BarHighPrice))
                                {
                                    // NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "atrl" + CurrentBar, false, 0, threshold, Brushes.Magenta);
                                    // Print(string.Format("{0} {1} pullback for swing low low:{2} > {3} prev:{4}", CurrentBar, Time[0], high0, threshold, _swingLow.Bar));
                                    _swingLow.PullBack = true;
                                    //NinjaTrader.NinjaScript.DrawingTools.Draw.Line(this, "atrl" + currentBar, false,
                                    //   currentBar - _swingLow.Bar, _swingLow.Price,
                                    //  1, high0,
                                    //   Brushes.Magenta, DashStyleHelper.Solid, 2);
                                }
                            }
                        }

                        threshold = _swingHi.Price - minBOSRange;
                        if (!_swingHi.PullBack)
                        {
                            if (currentBar - 1 > _swingHi.Bar)
                            {
                                if ((useBOSATRRange && low0 < threshold) || (!useBOSATRRange && close0 < _swingHi.BarLowPrice))
                                {
                                    //  NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "atrh" + CurrentBar, false, 0, threshold, Brushes.Yellow);
                                    //   Print(string.Format("{0} {1} pullback for swing high low:{2} < {3} prev:{4}", CurrentBar, Time[0], low0, threshold, _swingHi.Bar));
                                    _swingHi.PullBack = true;

                                    //NinjaTrader.NinjaScript.DrawingTools.Draw.Line(this, "atrh" + currentBar, false,
                                    //  currentBar - _swingHi.Bar, _swingHi.Price,
                                    //1, low0,
                                    //Brushes.Yellow, DashStyleHelper.Solid, 2);
                                }
                            }
                        }
                    }
                    break;

                case ARC_SMC_PullbackMode.Ticks:
                    {
                        var range = BOSPullbackTicks * TickSize;
                        var threshold = _swingLow.Price + range;
                        if (!_swingLow.PullBack)
                        {
                            if (currentBar > _swingLow.Bar)
                            {
                                if (high0 >= threshold)
                                {
                                    _swingLow.PullBack = true;
                                }
                            }
                        }

                        threshold = _swingHi.Price - range;
                        if (!_swingHi.PullBack)
                        {
                            if (currentBar > _swingHi.Bar)
                            {
                                if (low0 < threshold)
                                {
                                    _swingHi.PullBack = true;
                                }
                            }
                        }
                    }
                    break;
                case ARC_SMC_PullbackMode.Percentage:
                    {
                        if (!_swingLow.PullBack)
                        {
                            var range = (prevSwingHi.Price - _swingLowPrice) * (BOSPullbackPercentage / 100d);
                            var threshold = _swingLowPrice + range;
                            if (currentBar > _swingLow.Bar)
                            {
                                if (high0 >= threshold)
                                {
                                    _swingLow.PullBack = true;
                                    // NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "dt-h" + CurrentBar, false, 0, threshold, Brushes.Red);
                                }
                            }
                        }
                        if (!_swingHi.PullBack)
                        {
                            var range = (_swingHighPrice - prevSwingLow.Price) * (BOSPullbackPercentage / 100d);
                            var threshold = _swingHighPrice - range;
                            if (currentBar > _swingHi.Bar)
                            {
                                if (low0 < threshold)
                                {
                                    _swingHi.PullBack = true;
                                    // NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "dt-h" + CurrentBar, false, 0, threshold, Brushes.Lime);
                                }
                            }
                        }
                    }

                    break;
            }
        }

        private void FindSwingHigh()
        {
            var series = UseMTF ? 1 : 0;
            var currentBar = CurrentBars[series];

            // new swing hi is the highest point between previous swing low and current low
            var prevSwingLow = _lowPivots.Last();
            var maxHighPrice = prevSwingLow.BarHighPrice;
            var maxHighBar = prevSwingLow.Bar;

            for (var bar = prevSwingLow.Bar; bar < CurrentBar - 1; bar++)
            {
                var barsAgo = currentBar - bar;
                var highPrice = Highs[series][barsAgo];
                if (highPrice > maxHighPrice)
                {
                    maxHighPrice = highPrice;
                    maxHighBar = bar;
                }
            }

            var prevSwingHi = _hiPivots.Last();
            if (prevSwingHi.Bar != maxHighBar)
            {
                var pivot = new SwingPivot
                {
                    Bar = maxHighBar,
                    BarHighPrice = Highs[series][currentBar - maxHighBar],
                    BarLowPrice = Lows[series][currentBar - maxHighBar],
                    BarOpenPrice = Opens[series][currentBar - maxHighBar],
                    BarClosePrice = Closes[series][currentBar - maxHighBar],
                    IsLow = false,
                    IsBroken = false,
                    Label = "H",
                    Price = Highs[series][currentBar - maxHighBar],
                    Time = Times[series][currentBar - maxHighBar]
                };
                //Print(string.Format("{0} {1} FindSwingHigh #{2} {3}", CurrentBar, Time[0], pivot.Bar, pivot.Price));

                pivot.Label = pivot.Price > prevSwingHi.Price ? "HH" : "LH";
                _allPivots.Add(pivot);
                _hiPivots.Add(pivot);
                _swingHi = pivot.Clone();
                _swingHi.IsBroken = false;
                _swingHi.PullBack = false;
                _swingHighPrice = pivot.Price;
                _swingHighBar = pivot.Bar;
                _swingHighTime = pivot.Time;

            }
        }

        private void FindSwingLow()
        {
            var series = UseMTF ? 1 : 0;
            var currentBar = CurrentBars[series];

            // new swing low is the lowest point between previous swing high and current high
            var prevSwingHi = _hiPivots.Last();
            var minLowPrice = prevSwingHi.BarLowPrice;
            var maxLowBar = prevSwingHi.Bar;

            for (var bar = prevSwingHi.Bar; bar < currentBar; bar++)
            {
                var barsAgo = currentBar - bar;
                var lowPrice = Lows[series][barsAgo];
                if (lowPrice < minLowPrice)
                {
                    minLowPrice = lowPrice;
                    maxLowBar = bar;
                }
            }

            var prevSwingLo = _lowPivots.Last();
            if (prevSwingLo.Bar != maxLowBar)
            {
                var pivot = new SwingPivot
                {
                    Bar = maxLowBar,
                    BarHighPrice = Highs[series][currentBar - maxLowBar],
                    BarLowPrice = Lows[series][currentBar - maxLowBar],
                    BarOpenPrice = Opens[series][currentBar - maxLowBar],
                    BarClosePrice = Closes[series][currentBar - maxLowBar],
                    IsLow = true,
                    IsBroken = false,
                    Label = "L",
                    Price = Lows[series][currentBar - maxLowBar],
                    Time = Times[series][currentBar - maxLowBar]
                };
                //Print(string.Format("{0} {1} FindSwingLow #{2} {3}", CurrentBar, Time[0], pivot.Bar, pivot.Price));

                pivot.Label = pivot.Price < prevSwingLo.Price ? "LL" : "HL";
                _allPivots.Add(pivot);
                _lowPivots.Add(pivot);
                _swingLow = pivot.Clone();
                _swingLow.IsBroken = false;
                _swingLow.PullBack = false;
                _swingLowPrice = pivot.Price;
                _swingLowBar = pivot.Bar;
                _swingLowTime = pivot.Time;
            }
        }

        #endregion

        #region Internal structure / Change of Character

        private void DetectChangeOfCharacter()
        {
            var series = UseMTF ? 1 : 0;

            if (BarsInProgress != series)
            {
                return;
            }

            var currentBar = CurrentBars[series];
            if (currentBar < 2 || CurrentBars[0] < 2)
            {
                return;
            }

            ChangeOfCharacter[0] = 0;
            var low1 = Lows[series][1];
            var low2 = Lows[series][2];
            var high1 = Highs[series][1];
            var high2 = Highs[series][2];
            var close1 = Closes[series][1];
            var time1 = Times[series][1];
            var brokePrevCandleHigh = high1 > high2;
            var brokePrevCandleLow = low1 < low2;
            var isInsideBar = low1 >= low2 && high1 <= high2;
            var isEngulfingBar = brokePrevCandleHigh && brokePrevCandleLow;


            if (isInsideBar)
            {
                return;
            }

            if (isEngulfingBar)
            {
                if (_state == 1)
                {
                    // trend is up
                    var brokeInternalHigh = false;
                    if (high1 > _internalHiPrice)
                    {
                        brokeInternalHigh = true;
                        _internalHiPrice = high1;
                        _internalHiBar = currentBar - 1;
                        _internalHiTime = time1;
                    }

                    var internalLowBroken = ChoChStructureMapping == ARC_SMC_Mapping.Candle_Close
                      ? close1 < _internalLowPrice
                      : low1 < _internalLowPrice;
                    if (internalLowBroken)
                    {
                        // we broke the internal low
                        // change of character
                        var choc = new PriceBreak
                        {
                            Price = _internalLowPrice,
                            StartBar = _internalLowBar,
                            StartTime = _internalLowTime,
                            EndBar = currentBar - 1,
                            EndTime = time1,
                            IsBullish = false
                        };
                        _chocs.Add(choc);
                        DetectOverlappingBos(choc);
                        if (ChoChAlert)
                        {
                            SendAlert(ChoChAlertSound, string.Format("{0} Bearish ChoCh-{1}", Instrument.FullName, _MTFLabel));
                        }

                        ChangeOfCharacter[0] = -1;

                        AddSupplyZone(currentBar - 1, ARC_SMC_SupplyDemandDisplayType.ChoCh);


                        _state = -1;
                        _internalLowPrice = low1;
                        _internalLowBar = currentBar - 1;
                        _internalLowTime = time1;

                        if (!brokeInternalHigh)
                        {
                            _internalHiPrice = high1;
                            _internalHiBar = currentBar - 1;
                            _internalHiTime = time1;
                        }
                    }
                    else if (brokeInternalHigh)
                    {
                        _internalLowPrice = low1;
                        _internalLowBar = currentBar - 1;
                        _internalLowTime = time1;
                    }
                }
                else if (_state == -1)
                {
                    // trend is down
                    var brokeInternalLow = false;
                    if (low1 < _internalLowPrice)
                    {
                        brokeInternalLow = true;
                        _internalLowPrice = low1;
                        _internalLowBar = currentBar - 1;
                        _internalLowTime = time1;
                    }

                    var internalHiBroken = ChoChStructureMapping == ARC_SMC_Mapping.Candle_Close
                      ? close1 > _internalHiPrice
                      : high1 > _internalHiPrice;
                    if (internalHiBroken)
                    {
                        // change of character
                        var choc = new PriceBreak
                        {
                            Price = _internalHiPrice,
                            StartBar = _internalHiBar,
                            StartTime = _internalHiTime,
                            EndBar = currentBar - 1,
                            EndTime = time1,
                            IsBullish = true
                        };
                        _chocs.Add(choc);
                        DetectOverlappingBos(choc);
                        ChangeOfCharacter[0] = 1;
                        if (ChoChAlert)
                        {
                            SendAlert(ChoChAlertSound, string.Format("{0} Bullish ChoCh-{1}", Instrument.FullName, _MTFLabel));
                        }
                        AddDemandZone(currentBar - 1, ARC_SMC_SupplyDemandDisplayType.ChoCh);



                        _state = 1;
                        // trend is now up
                        _internalHiPrice = high1;
                        _internalHiBar = currentBar - 1;
                        _internalHiTime = time1;
                    }
                    else if (brokeInternalLow)
                    {
                        _internalHiPrice = high1;
                        _internalHiBar = currentBar - 1;
                        _internalHiTime = time1;
                    }
                }
            }
            else
            {
                if (brokePrevCandleHigh)
                {
                    var internalHiBroken = ChoChStructureMapping == ARC_SMC_Mapping.Candle_Close
                      ? close1 > _internalHiPrice
                      : high1 > _internalHiPrice;
                    if (internalHiBroken)
                    {
                        if (_state != 1)
                        {
                            // change of character
                            var choc = new PriceBreak
                            {
                                Price = _internalHiPrice,
                                StartBar = _internalHiBar,
                                StartTime = _internalHiTime,
                                EndBar = currentBar - 1,
                                EndTime = time1,
                                IsBullish = true
                            };
                            _chocs.Add(choc);
                            DetectOverlappingBos(choc);
                            ChangeOfCharacter[0] = 1;
                            if (ChoChAlert)
                            {
                                SendAlert(ChoChAlertSound, string.Format("{0} Bullish ChoCh-{1}", Instrument.FullName, _MTFLabel));
                            }

                            AddDemandZone(currentBar - 1, ARC_SMC_SupplyDemandDisplayType.ChoCh);


                            _state = 1;
                        }

                        FindPreviousInternalLow();
                        // trend continues up
                        _internalHiPrice = high1;
                        _internalHiBar = currentBar - 1;
                        _internalHiTime = time1;
                    }
                }
                else if (brokePrevCandleLow)
                {
                    var internalLowBroken = ChoChStructureMapping == ARC_SMC_Mapping.Candle_Close
                      ? close1 < _internalLowPrice
                      : low1 < _internalLowPrice;
                    // trend continues down
                    if (internalLowBroken)
                    {
                        // we broke the internal low
                        if (_state != -1)
                        {
                            // change of character
                            var choc = new PriceBreak
                            {
                                Price = _internalLowPrice,
                                StartBar = _internalLowBar,
                                StartTime = _internalLowTime,
                                EndBar = currentBar - 1,
                                EndTime = time1,
                                IsBullish = false
                            };
                            _chocs.Add(choc);
                            DetectOverlappingBos(choc);
                            ChangeOfCharacter[0] = -1;
                            if (ChoChAlert)
                            {
                                SendAlert(ChoChAlertSound, string.Format("{0} Bearish ChoCh-{1}", Instrument.FullName, _MTFLabel));
                            }

                            AddSupplyZone(currentBar - 1, ARC_SMC_SupplyDemandDisplayType.ChoCh);

                            _state = -1;
                        }

                        FindPreviousInternalHigh();
                        _internalLowPrice = low1;
                        _internalLowBar = currentBar - 1;
                        _internalLowTime = time1;
                    }
                }
            }
            // NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "dt-l" + CurrentBar, false, 0, _internalLowPrice, Brushes.Red);
            //  NinjaTrader.NinjaScript.DrawingTools.Draw.Dot(this, "dt-h" + CurrentBar, false, 0, _internalHiPrice, Brushes.Lime);

        }

        private void DetectOverlappingBos(PriceBreak choc)
        {
            var bos = this._bos.FirstOrDefault(e => e.StartBar == choc.StartBar && Math.Abs(e.Price - choc.Price) < 4 * TickSize);

            if (bos != null)
            {
                bos.Overlaps = true;
                choc.Overlaps = true;
            }
        }

        private void DetectOverlappingChocs(PriceBreak bos)
        {
            var choc = this._chocs.FirstOrDefault(e => e.StartBar == bos.StartBar && Math.Abs(e.Price - bos.Price) < 4 * TickSize);

            if (choc != null)
            {
                bos.Overlaps = true;
                choc.Overlaps = true;
            }
        }

        private void FindPreviousInternalHigh(int fromBar = 1)
        {
            // new internal high becomes the last candle which fails to
            // break the previous candle low or the high of the first engulfing bar
            var series = UseMTF ? 1 : 0;
            var currentBar = CurrentBars[series];
            var highestPrice = 0d;
            var highestBar = 0;
            for (var barsAgo = fromBar; barsAgo + 1 < currentBar; barsAgo++)
            {
                if (IsEngulfingBar(series, barsAgo))
                {
                    _internalHiPrice = Highs[series][barsAgo];
                    _internalHiBar = currentBar - barsAgo;
                    _internalHiTime = Times[series][barsAgo];

                    return;
                }
                if (Highs[series][barsAgo] >= highestPrice)
                {
                    highestPrice = Highs[series][barsAgo];
                    highestBar = barsAgo;
                }
                if (Lows[series][barsAgo] >= Lows[series][barsAgo + 1])
                {
                    _internalHiPrice = Highs[series][highestBar];
                    _internalHiBar = currentBar - highestBar;
                    _internalHiTime = Times[series][highestBar];

                    return;
                }
            }
        }

        private bool IsEngulfingBar(int series, int barsAgo)
        {
            var low0 = Lows[series][barsAgo + 0];
            var low1 = Lows[series][barsAgo + 1];
            var high0 = Highs[series][barsAgo + 0];
            var high1 = Highs[series][barsAgo + 1];
            var brokePrevHigh = high0 > high1;
            var brokePrevLow = low0 < low1;
            var isEngulfingBar = brokePrevHigh && brokePrevLow;
            return isEngulfingBar;
        }

        private void FindPreviousInternalLow(int fromBar = 1)
        {
            // new internal low becomes the last candle which fails to
            // break the previous candle high
            //or the low of the first engulfing bar
            var series = UseMTF ? 1 : 0;
            var currentBar = CurrentBars[series];
            var lowestPrice = double.MaxValue;
            var lowestBar = 0;
            for (var barsAgo = fromBar; barsAgo + 1 < currentBar; barsAgo++)
            {
                if (IsEngulfingBar(series, barsAgo))
                {
                    _internalLowPrice = Lows[series][barsAgo];
                    _internalLowBar = currentBar - barsAgo;
                    _internalLowTime = Times[series][barsAgo];

                    return;
                }
                if (Lows[series][barsAgo] <= lowestPrice)
                {
                    lowestPrice = Lows[series][barsAgo];
                    lowestBar = barsAgo;
                }
                if (Highs[series][barsAgo] <= Highs[series][barsAgo + 1])
                {
                    _internalLowPrice = Lows[series][lowestBar];
                    _internalLowBar = currentBar - lowestBar;
                    _internalLowTime = Times[series][lowestBar];

                    return;
                }
            }
        }

        #endregion

        #region rendering
		private SharpDX.Direct2D1.Brush lineBrushUp, lineBrushDown;
        public override void OnRenderTargetChanged()
        {
			if(lineBrushUp!=null   && !lineBrushUp.IsDisposed)   {lineBrushUp.Dispose();   lineBrushUp=null;}
			if(lineBrushDown!=null && !lineBrushDown.IsDisposed) {lineBrushDown.Dispose(); lineBrushDown=null;}
			if(RenderTarget!=null) lineBrushUp = this.pZZUpLineColor.ToDxBrush(RenderTarget);
			if(RenderTarget!=null) lineBrushDown = this.pZZDownLineColor.ToDxBrush(RenderTarget);
		}
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
#if DoLicense
		if(!ValidLicense) return;
#endif
int line = 1;
try{
            //base.OnRender(chartControl, chartScale);
			#region -- draw structure --            
			if (pShowSwingLines)
			{
				int rmab = BarsArray[0].GetBar(Times[0].GetValueAt(Math.Min(BarsArray[0].Count-1,ChartBars.ToIndex)));
				if(rmab==BarsArray[0].Count-1 && Calculate == Calculate.OnBarClose) rmab = rmab-1;

				int x1 = 0;
				int y1 = 0;
				int x2 = 0;
				int y2 = 0;
			    RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

				if (rmab >= 2 && StructureMgr.AllPivots.Count>0){
					var SwingLabelBrush = ' ';//fillbrush;
					var keys = new System.Collections.Generic.List<int>(StructureMgr.AllPivots.Keys);
				    int j = keys.Count-1;
					double swingprice2 = Closes[0].GetValueAt(1);
					double swingprice1 = Closes[0].GetValueAt(1);
					double swingpriceOB = 0;  //swing price of an outside bar
					float vTextOffset = 0;
					int swingABar1 = 1;
				    while (j > 0) { 
						j = j - 1;
						if(keys[j] < ChartBars.FromIndex-1) {
							swingABar1 = keys[j];
							swingpriceOB = StructureMgr.AllPivots[swingABar1][2];
							if(!double.IsNaN(swingprice2))
								swingprice1 = swingpriceOB;//swingprice2 contains the last swing price of an outside bar
							else
								swingprice1 = StructureMgr.AllPivots[swingABar1][1];//that bar is a normal (non-outsidebar), therefore the last swing price of that swing bar is in element [1]
							break;
						}
					}//j is now the index of the first swing point prior to the left-most bar on the chart
//try{
					var lineBrush = 'u';
					string zzId0 = "";
					int swingABar0 = keys[j];
					double priorH = StructureMgr.AllPivots[swingABar0][1];
					double priorL = StructureMgr.AllPivots[swingABar0][1];
					if(!double.IsNaN(StructureMgr.AllPivots[swingABar0][2])){
						priorL = StructureMgr.AllPivots[swingABar0][2];
						if(priorH < priorL){
							double temp = priorH;
							priorH = priorL;
							priorL = temp;
						}
					}
					double OB_High = 0;//high price of an outside bar
					double OB_Low = 0;//low price of an outside bar
                    for (int i = j; i<keys.Count && keys[i] <= Bars.Count; i++)
                    {
						swingABar0 = keys[i];
						x1 = ChartControl.GetXByBarIndex(ChartBars, swingABar0);
						x2 = ChartControl.GetXByBarIndex(ChartBars, swingABar1);

						double swingprice = StructureMgr.AllPivots[swingABar0][1];
						swingpriceOB = StructureMgr.AllPivots[swingABar0][2];//Outside Bar swing price at the close of the bar
						bool IsOutsideBar = !double.IsNaN(swingpriceOB);
						if(IsOutsideBar){
							OB_High = Math.Max(swingprice, swingpriceOB);
							OB_Low = Math.Min(swingprice, swingpriceOB);
							y1 = chartScale.GetYByValue(swingprice);
							y2 = chartScale.GetYByValue(swingprice1);
							drawLine(x1, x2, y1, y2, (swingprice1 < swingprice ? lineBrushUp : lineBrushDown), DashStyleHelper.Solid, pZZLineThickness);
							y1 = chartScale.GetYByValue(swingpriceOB);
							y2 = chartScale.GetYByValue(swingprice);
							drawLine(x1, x1, y1, y2, (swingpriceOB > swingprice ? lineBrushUp : lineBrushDown), DashStyleHelper.Solid, pZZLineThickness);
							swingprice = swingpriceOB;
						}else{
							if(swingprice1 > swingprice){//a down swing
								lineBrush = 'd';
							}else{
								lineBrush = 'u';
							}

							y1 = chartScale.GetYByValue(swingprice);
							y2 = chartScale.GetYByValue(swingprice1);

							drawLine(x1, x2, y1, y2, (lineBrush=='u' ? lineBrushUp : lineBrushDown), DashStyleHelper.Solid, pZZLineThickness);
							swingprice1 = swingprice;
						}

						if (pShowSwingLabels){
//try{
							float[] SZ  = getTextHeightAndWidth(zzId0, pZZlabelFont);
							if(!IsOutsideBar){
						    	if (lineBrush == 'u'){
									SwingLabelBrush = 'u';
									vTextOffset = -SZ[0] -3f;
									if(swingprice > priorH) zzId0 = "HH";
									else if(swingprice < priorH) zzId0 = "LH";
									else zzId0 = "DT";
									priorH = swingprice;
								} else {
									SwingLabelBrush = 'd';
									vTextOffset = 3f;
									if(swingprice < priorL) zzId0 = "LL";
									else if(swingprice > priorL) zzId0 = "HL";
									else zzId0 = "DB";
									priorL = swingprice;
								}
//Print("SZ[0]: "+SZ[0]+"  SZ[1]: "+SZ[1]);
							    drawString(zzId0, x1 - SZ[1] / 2, y1 + vTextOffset, pZZlabelFont, (SwingLabelBrush=='u' ? lineBrushUp : lineBrushDown), SharpDX.DirectWrite.TextAlignment.Center);                                            
							}else{//need to draw 2 labels on an outside bar
								SwingLabelBrush = 'u';
								zzId0 = "HH";
								if(OB_High == priorH) zzId0 = "DT";
								else if(OB_High < priorH) zzId0 = "LH";
								priorH = OB_High;
								vTextOffset = -SZ[0] -3f;
							    drawString(zzId0, x1 - SZ[1] / 2, Math.Min(y1,y2) + vTextOffset, pZZlabelFont, (SwingLabelBrush=='u' ? lineBrushUp : lineBrushDown), SharpDX.DirectWrite.TextAlignment.Center);                                            

								SwingLabelBrush = 'd';
								vTextOffset = 3f;
								zzId0 = "LL";
								if(OB_Low == priorL) zzId0 = "DB";
								else if(OB_Low > priorL) zzId0 = "HL";
								priorL = OB_Low;
							    drawString(zzId0, x1 - SZ[1] / 2, Math.Max(y1,y2) + vTextOffset, pZZlabelFont, (SwingLabelBrush=='u' ? lineBrushUp : lineBrushDown), SharpDX.DirectWrite.TextAlignment.Center);                                            
							}
//}catch(Exception onr){Print("OnRender: "+onr.ToString());}
						}
						if(swingABar0 > rmab) break;
						swingprice2 = swingprice1;
						swingprice1 = swingprice;
						swingABar1  = swingABar0;
					}
//}catch(Exception eee){Print(line+"  Error: "+eee.ToString());}
				}
				RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
			}
			#endregion

line=100;
            BearishChOfChColor.RenderTarget = RenderTarget;
            BullishChOfChColor.RenderTarget = RenderTarget;
            TextColor.RenderTarget = RenderTarget;
            InternalHiColor.RenderTarget = RenderTarget;
            InternalLowColor.RenderTarget = RenderTarget;

            StrongSwingHiColor.RenderTarget = RenderTarget;
            StrongSwingLowColor.RenderTarget = RenderTarget;
            WeakSwingHiColor.RenderTarget = RenderTarget;
            WeakSwingLowColor.RenderTarget = RenderTarget;
            BullishBOSColor.RenderTarget = RenderTarget;
            BearishBOSColor.RenderTarget = RenderTarget;
            SupplyColor.RenderTarget = RenderTarget;
            DemandColor.RenderTarget = RenderTarget;
            SupplyDemandCenter.RenderTarget = RenderTarget;
            FibRetracement1Color.RenderTarget = RenderTarget;
            FibRetracement2Color.RenderTarget = RenderTarget;
            FibRetracement3Color.RenderTarget = RenderTarget;
            FibRetracementAnchorStroke.RenderTarget = RenderTarget;
            HHLLTextColor.RenderTarget = RenderTarget;

            RenderSupplyDemandLevels(chartControl, chartScale);
            RenderInternalLowHi(chartControl, chartScale);
            RenderSwingLowHi(chartControl, chartScale);
            RenderPivots(chartControl, chartScale);
            RenderChangeOfCharacter(chartControl, chartScale);
            RenderBreakOfStructure(chartControl, chartScale);
            RenderFibLevels(chartControl, chartScale);

line=200;
            if (ShowTrend && _bos.Count > 0)
            {
                var txt = _MTFLabel;
                var w = 32f;
                var lastBos = _bos.Last();

                if (_trend > 0)
                {
                    txt = _MTFLabel + " Trend Up";
                }
                else
                {
                    txt = _MTFLabel + " Trend Down";
                }

line=300;

                if (_chocs.Count > 0)
                {
                    var lastChoC = _chocs.Last();
                    if (lastChoC.EndBar > lastBos.EndBar)
                    {
                        txt = lastChoC.IsBullish ? " / Bullish ChoCh" : " / Bearish ChoCh";
                    }
                }
line=400;
                var x = 0;
                var y = 0;
                var textW = GetTextWidth(Font, txt);
                var textH = GetTextHeight(Font, txt);
                switch (TrendPosition)
                {
                    case ARC_SMC_TrendPosition.TopLeft:
                        x = PositionX;
                        y = PositionY;
                        break;
                    case ARC_SMC_TrendPosition.TopRight:
                        x = (int)(chartScale.ChartPanel.W - textW - PositionX);
                        y = PositionY;
                        break;

                    case ARC_SMC_TrendPosition.BottomLeft:
                        x = PositionX;
                        y = (int)(chartScale.ChartPanel.H - textH - PositionY); ;
                        break;

                    case ARC_SMC_TrendPosition.BottomRight:
                        x = (int)(chartScale.ChartPanel.W - textW - PositionX);
                        y = (int)(chartScale.ChartPanel.H - textH - PositionY); ;
                        break;
                }
line=500;
                DrawTextLabel(chartControl, chartScale, Font, txt, x, y, textW, TextColor.BrushDX, TextAlignment.Leading);
            }
}catch(Exception ee){Print(line+":  ARC_SMC: "+ee.ToString());}
        }

		#region -- Render support --
		#region -- Draw zz support --
		private float[] getTextHeightAndWidth(string text, SimpleFont font){
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			float[] result = new float[2]{(float)font.Size, textLayout.Metrics.Width};

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return result;
		}
		private float getTextWidth(string text, SimpleFont font)
		{
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

		    float textwidth = textLayout.Metrics.Width;

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return textwidth;
		}
		private float getTextHeight(string text, SimpleFont font)
		{
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

		    float textheight = textLayout.Metrics.Height;

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return textheight;
		}
		#region drawstring
		//Draw a text at {x;y} coordinates in pixel.
		private void drawString(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxTextWidth = -9999f)
		{
		    SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        ) { TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, MaxTextWidth <= 0f ? getTextWidth(text, font) : MaxTextWidth, float.MaxValue);

		    RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

		    textLayout.Dispose();
		    textFormat.Dispose();
		}
		private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.Direct2D1.Brush bkgBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxTextWidth = -9999f, float MaxX = -9999f)
		{
			#region drawstring
			if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
			SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();

			var textFormat = new SharpDX.DirectWrite.TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
			)
				{ TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, (MaxTextWidth>0 ? MaxTextWidth : ChartPanel.W/3), ChartPanel.H);
			if(x<0) x = Math.Abs(x) - textLayout.Metrics.Width - 5;

			if(MaxX>0)
				x = Math.Min(x, MaxX - 3f - textLayout.Metrics.Width);

			y = y - textLayout.Metrics.Height/2.0;
			if (bkgBrush!=null && bkgBrush.Opacity>0) {
				double xl = x - 3;
				double xr = x + textLayout.Metrics.Width + 3;
				double yt = y - 1;
				double yb = y+textLayout.Metrics.Height + 2;
				if(textAlignment==SharpDX.DirectWrite.TextAlignment.Trailing){
					xr = x + textLayout.Metrics.LayoutWidth +3;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				else if(textAlignment==SharpDX.DirectWrite.TextAlignment.Center){
					xr = x + textLayout.Metrics.LayoutWidth/2 + 3 + textLayout.Metrics.Width/2;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				var bkgBox = new System.Windows.Point[]
				{	new System.Windows.Point(xl, yt),
					new System.Windows.Point(xl, yb),
					new System.Windows.Point(xr, yb),
					new System.Windows.Point(xr, yt),
				};
				drawRegion(bkgBox, bkgBrush);
			}
			RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			textLayout.Dispose();
			textFormat.Dispose();
			#endregion
		}
		#endregion
		private void drawRegion(System.Windows.Point[] points, SharpDX.Direct2D1.Brush dxbrush)
		{
		    SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

		    SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
		    SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
		    sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
		    sink1.AddLines(vectors);
		    sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
		    sink1.Close();

		    RenderTarget.FillGeometry(geo1, dxbrush);
		    geo1.Dispose();
		    sink1.Dispose();
		}
		private void drawLine(double x1, double x2, double y1, double y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle = DashStyleHelper.Solid, int width = 1, int opacity = 100)
		{
		    dxbrush.Opacity = opacity / 100f;
		    SharpDX.Direct2D1.DashStyle _dashstyle;
		    if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

		    SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
		    SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

		    RenderTarget.DrawLine(new SharpDX.Vector2((float)x1,(float)y1), new SharpDX.Vector2((float)x2,(float)y2), dxbrush, width, strokestyle);

		    strokestyle.Dispose();
		}
		#endregion
        private void RenderFibLevels(ChartControl chartControl, ChartScale chartScale)
        {
            var chartWidth = (float)chartScale.ChartPanel.W;

            if (ShowFibRetracements && !_warmUpPhase)
            {
                var priceFib1 = 0d;
                var priceFib2 = 0d;
                var priceFib3 = 0d;
                if (_swingLowTime < _swingHighTime)
                {
                    //from low->high
                    var range = _swingHighPrice - _swingLowPrice;
                    priceFib1 = _swingHighPrice - FibRetracement1 / 100d * range;
                    priceFib2 = _swingHighPrice - FibRetracement2 / 100d * range;
                    priceFib3 = _swingHighPrice - FibRetracement3 / 100d * range;
                }
                else
                {
                    //from high-low
                    var range = _swingHighPrice - _swingLowPrice;
                    priceFib1 = _swingLowPrice + FibRetracement1 / 100d * range;
                    priceFib2 = _swingLowPrice + FibRetracement2 / 100d * range;
                    priceFib3 = _swingLowPrice + FibRetracement3 / 100d * range;
                }

                var x1Low = UseMTF
                    ? chartControl.GetXByTime(_swingLowTime)
                    : chartControl.GetXByBarIndex(ChartBars, _swingLowBar);
                var x1High = UseMTF
                    ? chartControl.GetXByTime(_swingHighTime)
                    : chartControl.GetXByBarIndex(ChartBars, _swingHighBar);

                var textH = GetTextHeight(Font, "78.6%");
                var textW = GetTextHeight(Font, "78.6%");
                var x1 = Math.Min(x1Low, x1High);
                var x2 = chartControl.GetXByTime(_currentTime) + (textW + 20);
                var y = chartScale.GetYByValue(priceFib1);
                if (FibonacciType == ARC_SMC_FibonacciType.Cluster)
                {
                    x1 = chartControl.GetXByTime(_currentTime) + 20;
                    x2 = x1 + 100;
                }

                RenderTarget.DrawLine(new Vector2(x1, y), new Vector2(x2 - 20, y), FibRetracement1Color.BrushDX, FibRetracement1Color.Width, FibRetracement1Color.StrokeStyle);
                if (ShowFibNumbers)
                {
                    DrawTextLabel(chartControl, chartScale, Font, string.Format("{0:0.00}%", FibRetracement1), x2, y - textH / 2f, textW, FibRetracement1Color.BrushDX, TextAlignment.Leading);
                }

                y = chartScale.GetYByValue(priceFib2);
                RenderTarget.DrawLine(new Vector2(x1, y), new Vector2(x2 - 20, y), FibRetracement2Color.BrushDX, FibRetracement2Color.Width, FibRetracement2Color.StrokeStyle);
                if (ShowFibNumbers)
                {
                    DrawTextLabel(chartControl, chartScale, Font, string.Format("{0:0.00}%", FibRetracement2), x2, y - textH / 2f, textW, FibRetracement2Color.BrushDX, TextAlignment.Leading);
                }

                y = chartScale.GetYByValue(priceFib3);
                RenderTarget.DrawLine(new Vector2(x1, y), new Vector2(x2 - 20, y), FibRetracement3Color.BrushDX, FibRetracement3Color.Width, FibRetracement3Color.StrokeStyle);
                if (ShowFibNumbers)
                {
                    DrawTextLabel(chartControl, chartScale, Font, string.Format("{0:0.00}%", FibRetracement3), x2, y - textH / 2f, textW, FibRetracement3Color.BrushDX, TextAlignment.Leading);
                }
                if (FibonacciType == ARC_SMC_FibonacciType.Normal)
                {
                    if (_swingLowTime < _swingHighTime)
                    {
                        var y1 = chartScale.GetYByValue(_swingLowPrice);
                        var y2 = chartScale.GetYByValue(_swingHighPrice);
                        RenderTarget.DrawLine(new Vector2(x1, y1), new Vector2(x2 - 20, y2), FibRetracementAnchorStroke.BrushDX, FibRetracementAnchorStroke.Width, FibRetracementAnchorStroke.StrokeStyle);
                    }
                    else
                    {
                        var y1 = chartScale.GetYByValue(_swingHighPrice);
                        var y2 = chartScale.GetYByValue(_swingLowPrice);
                        RenderTarget.DrawLine(new Vector2(x1, y1), new Vector2(x2 - 20, y2), FibRetracementAnchorStroke.BrushDX, FibRetracementAnchorStroke.Width, FibRetracementAnchorStroke.StrokeStyle);
                    }
                }
            }
        }

        private void RenderSupplyDemandLevels(ChartControl chartControl, ChartScale chartScale)
        {
            //bos
            if (SupplyDemandDisplayType == ARC_SMC_SupplyDemandDisplayType.Bos ||
                SupplyDemandDisplayType == ARC_SMC_SupplyDemandDisplayType.Both)
            {
                if (NumberOfSDZones > 0)
                {
                    var zonesAbove = _supplyDemandZones.Where(e => e.SDType == ARC_SMC_SupplyDemandDisplayType.Bos && e.IsSupply && e.EndBar <= 0 && _currentClosePrice < e.PriceHigh)
                        .OrderBy(e => e.PriceHigh)
                        .ToList();
                    var zonesBelow = _supplyDemandZones.Where(e => e.SDType == ARC_SMC_SupplyDemandDisplayType.Bos && e.IsDemand && e.EndBar <= 0 && _currentClosePrice > e.PriceLow)
                        .OrderByDescending(e => e.PriceLow)
                        .ToList();

                    if (HideBrokenSupplyDemandZones)
                    {
                        zonesAbove = zonesAbove.Where(e => !e.IsBroken).ToList();
                        zonesBelow = zonesBelow.Where(e => !e.IsBroken).ToList();
                    }
                    ShowZones(chartControl, chartScale, zonesAbove.Take(NumberOfSDZones).ToList());
                    ShowZones(chartControl, chartScale, zonesBelow.Take(NumberOfSDZones).ToList());
                }
                else
                {
                    var zones = _supplyDemandZones.Where(e => e.SDType == ARC_SMC_SupplyDemandDisplayType.Bos).ToList();

                    if (HideBrokenSupplyDemandZones)
                    {
                        zones = zones.Where(e => !e.IsBroken).ToList();
                    }
                    ShowZones(chartControl, chartScale, zones);
                }
            }

            //chocs
            if (SupplyDemandDisplayType == ARC_SMC_SupplyDemandDisplayType.ChoCh ||
                SupplyDemandDisplayType == ARC_SMC_SupplyDemandDisplayType.Both)
            {
                if (NumberOfSDZones > 0)
                {
                    var zonesAbove = _supplyDemandZones.Where(e => e.SDType == ARC_SMC_SupplyDemandDisplayType.ChoCh && e.IsSupply && e.EndBar <= 0 && _currentClosePrice < e.PriceHigh)
                      .OrderBy(e => e.PriceHigh)
                      .ToList();
                    var zonesBelow = _supplyDemandZones.Where(e => e.SDType == ARC_SMC_SupplyDemandDisplayType.ChoCh && e.IsDemand && e.EndBar <= 0 && _currentClosePrice > e.PriceLow)
                      .OrderByDescending(e => e.PriceLow)
                      .ToList();

                    if (HideBrokenSupplyDemandZones)
                    {
                        zonesAbove = zonesAbove.Where(e => !e.IsBroken).ToList();
                        zonesBelow = zonesBelow.Where(e => !e.IsBroken).ToList();
                    }
                    ShowZones(chartControl, chartScale, zonesAbove.Take(NumberOfSDZones).ToList());
                    ShowZones(chartControl, chartScale, zonesBelow.Take(NumberOfSDZones).ToList());
                }
                else
                {
                    var zones = _supplyDemandZones.Where(e => e.SDType == ARC_SMC_SupplyDemandDisplayType.ChoCh).ToList();

                    if (HideBrokenSupplyDemandZones)
                    {
                        zones = zones.Where(e => !e.IsBroken).ToList();
                    }
                    ShowZones(chartControl, chartScale, zones);
                }
            }

        }
        private void ShowZones(ChartControl chartControl, ChartScale chartScale, List<SupplyDemandZone> zones)
        {
            var textH = GetTextHeight(Font, _MTFLabel);
            var textW = GetTextHeight(Font, _MTFLabel);
            for (var i = 0; i < zones.Count; ++i)
            {
                var level = zones[i];

                if (level.EndBar > 0 && level.EndTime < chartControl.FirstTimePainted)
                {
                    continue;
                }

                if (level.StartTime > chartControl.LastTimePainted)
                {
                    continue;
                }

                if (level.EndBar > 0 && HideBrokenSupplyDemandZones)
                {
                    continue;
                }

                var x1 = chartControl.GetXByTime(level.StartTime);
                var x2 = chartControl.GetXByTime(level.EndBar > 0 ? level.EndTime : chartControl.LastTimePainted);
                var y1 = chartScale.GetYByValue(level.PriceLow);
                var y2 = chartScale.GetYByValue(level.PriceHigh);
                RenderTarget.FillRectangle(new RectangleF(x1, y1, x2 - x1, y2 - y1), level.IsDemand ? DemandColor.BrushDX : SupplyColor.BrushDX);


                var ym = chartScale.GetYByValue(level.PriceLow + (level.PriceHigh - level.PriceLow) / 2d);
                RenderTarget.DrawLine(new Vector2(x1, ym), new Vector2(x2, ym), SupplyDemandCenter.BrushDX, SupplyDemandCenter.Width, SupplyDemandCenter.StrokeStyle);

                if (UseMTF)
                {
                    var h = (y2 - y1) / 2f;
                    h += textH / 2f;
                    DrawTextLabel(chartControl, chartScale, Font, _MTFLabel, x2 - textW * 1.5f, y2 - h, textW, TextColor.BrushDX, TextAlignment.Trailing);
                }
            }
        }

        private void RenderPivots(ChartControl chartControl, ChartScale chartScale)
        {
            if (!ShowHHLL)
            {
                return;
            }

            var textW = GetTextWidth(HHLLFont, "HH");
            var textH = GetTextHeight(HHLLFont, "HH");
            for (var i = 0; i < _allPivots.Count; ++i)
            {
                var pivot = _allPivots[i];

                if (pivot.Time < chartControl.FirstTimePainted)
                {
                    continue;
                }

                if (pivot.Time > chartControl.LastTimePainted)
                {
                    continue;
                }

                var x1 = chartControl.GetXByTime(pivot.Time);
                var y = chartScale.GetYByValue(pivot.Price);
                y = pivot.IsLow ? (int)(y + textH) : (int)(y - textH);
                DrawTextLabel(chartControl, chartScale, HHLLFont, pivot.Label, x1 - textW / 2f, y, textW, HHLLTextColor.BrushDX);
            }
        }


        private void RenderBreakOfStructure(ChartControl chartControl, ChartScale chartScale)
        {
            if (BOSDisplayType == ARC_SMC_DisplayType.None)
            {
                return;
            }

            var textSmall = BOSDisplayType == ARC_SMC_DisplayType.TextAndTimeFrame ? _MTFLabel : "";
            var textWSmall = GetTextWidth(BOSFont, textSmall);

            var text = "BOS" + ((BOSDisplayType == ARC_SMC_DisplayType.TextAndTimeFrame) ? "-" + _MTFLabel : "");
            var textH = GetTextHeight(BOSFont, text);
            var textW = GetTextWidth(BOSFont, text);

            var rendered = 0;

            for (var i = _bos.Count - 1; i >= 0; i--)
            {
                var bos = _bos[i];

                if (bos.StartTime > chartControl.LastTimePainted)
                {
                    continue;
                }

                if (bos.EndTime < chartControl.FirstTimePainted)
                {
                    continue;
                }

                var x1 = chartControl.GetXByTime(bos.StartTime);
                var x2 = chartControl.GetXByTime(bos.EndTime);
                var y = chartScale.GetYByValue(bos.Price);
                var w = x2 - x1;

                var stroke = bos.IsBullish ? BullishBOSColor : BearishBOSColor;
                RenderTarget.DrawLine(new Vector2(x1, y), new Vector2(x2, y), stroke.BrushDX, stroke.Width, stroke.StrokeStyle);
                if (BOSDisplayType != ARC_SMC_DisplayType.LineOnly)
                {
                    if (w > textW + 30)
                    {
                        DrawTextLabel(chartControl, chartScale, BOSFont, text, x1, y - textH, x2 - x1, stroke.BrushDX);
                    }
                    else if (w > textWSmall + 30)
                    {
                        DrawTextLabel(chartControl, chartScale, BOSFont, textSmall, x1, y - textH, x2 - x1, stroke.BrushDX);
                    }
                }
                rendered++;

                if (NumberOfBOSToDisplay > 0 && rendered >= NumberOfBOSToDisplay)
                {
                    return;
                }
            }
        }

        private void RenderInternalLowHi(ChartControl chartControl, ChartScale chartScale)
        {
            var textSwingHi = "Internal High" + (UseMTF ? "-" + _MTFLabel : string.Empty);
            var textSwingLow = "Internal Low" + (UseMTF ? "-" + _MTFLabel : string.Empty);
            var textH = GetTextHeight(InternalHighLowFont, textSwingHi);
            var textW = GetTextWidth(InternalHighLowFont, textSwingHi);
            var chartWidth = (float)chartScale.ChartPanel.W;

            if (ShowInternalHighLow)
            {

                var x1Low = UseMTF
                    ? chartControl.GetXByTime(_internalLowTime)
                    : chartControl.GetXByBarIndex(ChartBars, _internalLowBar);
                var x1High = UseMTF
                    ? chartControl.GetXByTime(_internalHiTime)
                    : chartControl.GetXByBarIndex(ChartBars, _internalHiBar);

                if (x1Low < chartWidth - (textW + 20) || x1High < chartWidth - (textW + 20))
                {
                    var x2 = chartWidth - (textW + 20);
                    var yInternalLo = chartScale.GetYByValue(Math.Min(_currentLowPrice, _internalLowPrice));
                    var yInternalHi = chartScale.GetYByValue(Math.Max(_currentHighPrice, _internalHiPrice));
                    RenderTarget.DrawLine(new Vector2(x1Low, yInternalLo), new Vector2(x2 - 20, yInternalLo), InternalLowColor.BrushDX, InternalLowColor.Width, InternalLowColor.StrokeStyle);
                    RenderTarget.DrawLine(new Vector2(x1High, yInternalHi), new Vector2(x2 - 20, yInternalHi), InternalHiColor.BrushDX, InternalHiColor.Width, InternalHiColor.StrokeStyle);

                    if (ShowSwingHighLow && !_warmUpPhase)
                    {
                        var ySwingLo = chartScale.GetYByValue(_swingLowPrice);
                        var ySwingHi = chartScale.GetYByValue(_swingHighPrice);

                        var range = ySwingLo - yInternalLo;

                        if (Math.Abs(range) <= textH)
                        {
                            yInternalLo = range < 0 ? (int)(yInternalLo + textH / 2f) : (int)(yInternalLo - textH / 2f);
                        }
                        range = ySwingHi - yInternalHi;

                        if (Math.Abs(range) <= textH)
                        {
                            yInternalHi = range < 0 ? (int)(yInternalHi + textH / 2f) : (int)(yInternalHi - textH / 2f);
                        }
                    }

                    DrawTextLabel(chartControl, chartScale, InternalHighLowFont, textSwingLow, x2, yInternalLo - textH / 2f, textW, InternalLowColor.BrushDX, TextAlignment.Leading);
                    DrawTextLabel(chartControl, chartScale, InternalHighLowFont, textSwingHi, x2, yInternalHi - textH / 2f, textW, InternalHiColor.BrushDX, TextAlignment.Leading);
                }
            }
        }

        private void RenderSwingLowHi(ChartControl chartControl, ChartScale chartScale)
        {

            if (ShowSwingHighLow && !_warmUpPhase)
            {
                var prevLow = _lowPivots.Last();
                var prevHigh = _hiPivots.Last();

                var isWeakHigh = prevHigh.Bar != _swingHighBar;
                var isWeakLow = prevLow.Bar != _swingLowBar;
                var textSwingHi = isWeakHigh
                  ? "Weak High" + (UseMTF ? "-" + _MTFLabel : string.Empty)
                  : "Strong High" + (UseMTF ? "-" + _MTFLabel : string.Empty);
                var textSwingLow = isWeakLow
                  ? "Weak Low" + (UseMTF ? "-" + _MTFLabel : string.Empty)
                  : "Strong Low" + (UseMTF ? "-" + _MTFLabel : string.Empty);
                var textH = GetTextHeight(SwingHighLowFont, textSwingHi);
                var textW = GetTextWidth(SwingHighLowFont, textSwingHi);
                var chartWidth = (float)chartScale.ChartPanel.W;

                var x1Low = UseMTF
                    ? chartControl.GetXByTime(_swingLowTime)
                    : chartControl.GetXByBarIndex(ChartBars, _swingLowBar);
                var x1High = UseMTF
                    ? chartControl.GetXByTime(_swingHighTime)
                    : chartControl.GetXByBarIndex(ChartBars, _swingHighBar);

                if (x1Low < chartWidth - (textW + 20) || x1High < chartWidth - (textW + 20))
                {
                    var x2 = chartWidth - (textW + 20);
                    var ySwingLo = chartScale.GetYByValue(_swingLowPrice);
                    var ySwingHi = chartScale.GetYByValue(_swingHighPrice);
                    var stroke = isWeakLow ? WeakSwingLowColor : StrongSwingLowColor;

                    RenderTarget.DrawLine(new Vector2(x1Low, ySwingLo), new Vector2(x2 - 20, ySwingLo), stroke.BrushDX, stroke.Width, stroke.StrokeStyle);

                    stroke = isWeakHigh ? WeakSwingHiColor : StrongSwingHiColor;
                    RenderTarget.DrawLine(new Vector2(x1High, ySwingHi), new Vector2(x2 - 20, ySwingHi), stroke.BrushDX, stroke.Width, stroke.StrokeStyle);


                    if (ShowInternalHighLow)
                    {
                        var yInternalLo = chartScale.GetYByValue(Math.Min(_currentLowPrice, _internalLowPrice));
                        var yInternalHi = chartScale.GetYByValue(Math.Max(_currentHighPrice, _internalHiPrice));

                        var range = ySwingLo - yInternalLo;

                        if (Math.Abs(range) <= textH)
                        {
                            ySwingLo = range < 0 ? (int)(ySwingLo - textH / 2f) : (int)(ySwingLo + textH / 2f);
                        }
                        range = ySwingHi - yInternalHi;

                        if (Math.Abs(range) <= textH)
                        {
                            ySwingHi = range < 0 ? (int)(ySwingHi - textH / 2f) : (int)(yInternalHi + textH / 2f);
                        }
                    }

                    stroke = isWeakLow ? WeakSwingLowColor : StrongSwingLowColor;
                    DrawTextLabel(chartControl, chartScale, SwingHighLowFont, textSwingLow, x2, ySwingLo - textH / 2f, textW, stroke.BrushDX, TextAlignment.Leading);
                    stroke = isWeakHigh ? WeakSwingHiColor : StrongSwingHiColor;
                    DrawTextLabel(chartControl, chartScale, SwingHighLowFont, textSwingHi, x2, ySwingHi - textH / 2f, textW, stroke.BrushDX, TextAlignment.Leading);

                }
            }
        }

        private void RenderChangeOfCharacter(ChartControl chartControl, ChartScale chartScale)
        {
            if (ChoChDisplayType == ARC_SMC_DisplayType.None)
            {
                return;
            }

            var textSmall = (ChoChDisplayType == ARC_SMC_DisplayType.TextAndTimeFrame) ? _MTFLabel : "";
            var textWSmall = GetTextWidth(ChoChFont, textSmall);
            var text = "ChoCh" + ((ChoChDisplayType == ARC_SMC_DisplayType.TextAndTimeFrame) ? "-" + _MTFLabel : "");
            var textH = GetTextHeight(ChoChFont, text);
            var textW = GetTextWidth(ChoChFont, text);

            var rendered = 0;
            for (var i = _chocs.Count - 1; i >= 0; i--)
            {
                var choc = _chocs[i];

                if (choc.StartTime > chartControl.LastTimePainted)
                {
                    continue;
                }

                if (choc.EndTime < chartControl.FirstTimePainted)
                {
                    continue;
                }

                var x1 = UseMTF
                    ? chartControl.GetXByTime(choc.StartTime)
                    : chartControl.GetXByBarIndex(ChartBars, choc.StartBar);
                var x2 = UseMTF
                    ? chartControl.GetXByTime(choc.EndTime)
                    : chartControl.GetXByBarIndex(ChartBars, choc.EndBar);
                var y = chartScale.GetYByValue(choc.Price);

                var w = x2 - x1;
                var stroke = choc.IsBullish ? BullishChOfChColor : BearishChOfChColor;
                RenderTarget.DrawLine(new Vector2(x1, y), new Vector2(x2, y), stroke.BrushDX, stroke.Width, stroke.StrokeStyle);
                if (ChoChDisplayType != ARC_SMC_DisplayType.LineOnly)
                {
                    if (choc.Overlaps)
                    {
                        y += (int)(textH + 5);
                    }
                    if (w > textW + 30)
                    {
                        DrawTextLabel(chartControl, chartScale, ChoChFont, text, x1, y - textH, x2 - x1, stroke.BrushDX);
                    }
                    else if (w > textWSmall + 30)
                    {
                        DrawTextLabel(chartControl, chartScale, ChoChFont, textSmall, x1, y - textH, x2 - x1, stroke.BrushDX);
                    }
                }
                rendered++;

                if (NumberOfChoChToDisplay > 0 && rendered > NumberOfChoChToDisplay)
                {
                    return; ;
                }
            }
        }

        private void DrawTextLabel(ChartControl chartControl, ChartScale chartScale, SimpleFont font, string text, float x, float y, float width, Brush fontBrush, TextAlignment textAlignment = TextAlignment.Center)
        {
            //y -= Font.TextFormatHeight / 2;
            //x += 5;

            var textFormat = font.ToDirectWriteTextFormat();
            textFormat.TextAlignment = textAlignment;
            textFormat.WordWrapping = WordWrapping.NoWrap;
            var textLayout = new TextLayout(Globals.DirectWriteFactory, text, textFormat, width, textFormat.FontSize);

            RenderTarget.DrawTextLayout(new Vector2(x, y - 2), textLayout, fontBrush, DrawTextOptions.NoSnap);
            textFormat.Dispose();
            textLayout.Dispose();
        }

        private float GetTextWidth(SimpleFont font, string text)
        {
            var textFormat = font.ToDirectWriteTextFormat();
            textFormat.TextAlignment = TextAlignment.Center;
            textFormat.WordWrapping = WordWrapping.NoWrap;
            var textLayout = new TextLayout(Globals.DirectWriteFactory, text, textFormat, 200, textFormat.FontSize);
            var w = textLayout.Metrics.Width;
            textLayout.Dispose();

            return w;
        }

        private float GetTextHeight(SimpleFont font, string text)
        {
            var textFormat = font.ToDirectWriteTextFormat();
            textFormat.TextAlignment = TextAlignment.Center;
            textFormat.WordWrapping = WordWrapping.NoWrap;
            var textLayout = new TextLayout(Globals.DirectWriteFactory, text, textFormat, 200, textFormat.FontSize);
            var h = textLayout.Metrics.Height;
            textLayout.Dispose();

            return h;
        }
		#endregion

        #endregion

        #region helper classes

        public class SwingPivot
        {
            public double Price { get; set; }

            public int Bar { get; set; }

            public DateTime Time { get; set; }

            public bool IsLow { get; set; }

            public bool IsHigh
            {
                get { return !IsLow; }
            }

            public string Label { get; set; }

            public bool IsBroken { get; set; }

            public double BarHighPrice { get; set; }

            public double BarLowPrice { get; set; }

            public double BarOpenPrice { get; set; }

            public double BarClosePrice { get; set; }

            public bool PullBack { get; set; }

            public SwingPivot Clone()
            {
                return new SwingPivot
                {
                    Price = Price,
                    Bar = Bar,
                    Time = Time,
                    IsLow = IsLow,
                    Label = Label,
                    IsBroken = IsBroken,
                    BarHighPrice = BarHighPrice,
                    BarLowPrice = BarLowPrice,
                    BarOpenPrice = BarOpenPrice,
                    BarClosePrice = BarClosePrice
                };
            }
        }

        private class PriceBreak
        {
            public double Price { get; set; }

            public int StartBar { get; set; }

            public int EndBar { get; set; }

            public DateTime StartTime { get; set; }

            public DateTime EndTime { get; set; }

            public bool IsBullish { get; set; }

            public double Range { get; set; }
            public bool Overlaps { get; set; }
        }

        private class SupplyDemandZone
        {
            public double PriceLow { get; set; }

            public double PriceHigh { get; set; }

            public int StartBar { get; set; }
            public int ThrustBar { get; set; }

            public DateTime StartTime { get; set; }

            public int EndBar { get; set; }

            public DateTime EndTime { get; set; }

            public bool IsDemand { get; set; }

            public bool PriceClosedOutsideZone { get; set; }

            public bool IsSupply
            {
                get { return !IsDemand; }
            }

            public bool IsBroken { get; set; }
            public bool IsTested { get; set; }
            public ARC_SMC_SupplyDemandDisplayType SDType { get; set; }
        }

        #endregion
    }

    public class ARC_SMC_Converter : IndicatorBaseConverter // or StrategyBaseConverter
    {
        public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object component, Attribute[] attrs)
        {
            var indicator = component as ARC_SMC;
            var propertyDescriptorCollection = base.GetPropertiesSupported(context)
                ? base.GetProperties(context, component, attrs)
                : TypeDescriptor.GetProperties(component, attrs);

            if (indicator == null || propertyDescriptorCollection == null)
            {
                return propertyDescriptorCollection;
            }

            var bosATRPeriod = propertyDescriptorCollection["BOSATRPeriod"];
            var bosATRMultiplier = propertyDescriptorCollection["BOSATRMultiplier"];
            var bosPullbackPercentage = propertyDescriptorCollection["BOSPullbackPercentage"];
            var bosSPullbackTicks = propertyDescriptorCollection["BOSPullbackTicks"];
            var bosMapping = propertyDescriptorCollection["BOSStructureMapping"];
            var bosCount = propertyDescriptorCollection["NumberOfBOSToDisplay"];

            propertyDescriptorCollection.Remove(bosATRPeriod);
            propertyDescriptorCollection.Remove(bosATRMultiplier);
            propertyDescriptorCollection.Remove(bosPullbackPercentage);
            propertyDescriptorCollection.Remove(bosSPullbackTicks);
            propertyDescriptorCollection.Remove(bosMapping);
            propertyDescriptorCollection.Remove(bosCount);

            if (indicator.BOSPullBackType == ARC_SMC_PullbackMode.ATR)
            {
                propertyDescriptorCollection.Add(bosATRPeriod);
                propertyDescriptorCollection.Add(bosATRMultiplier);
            }
            else if (indicator.BOSPullBackType == ARC_SMC_PullbackMode.Percentage)
            {
                propertyDescriptorCollection.Add(bosPullbackPercentage);
            }
            else if (indicator.BOSPullBackType == ARC_SMC_PullbackMode.Ticks)
            {
                propertyDescriptorCollection.Add(bosSPullbackTicks);
            }


            if (indicator.BOSDisplayType != ARC_SMC_DisplayType.None)
            {
                propertyDescriptorCollection.Add(bosCount);
                propertyDescriptorCollection.Add(bosMapping);

            }

            var chofchCount = propertyDescriptorCollection["NumberOfChoChToDisplay"];
            var chofchMapping = propertyDescriptorCollection["ChoChStructureMapping"];
            propertyDescriptorCollection.Remove(chofchCount);

            propertyDescriptorCollection.Remove(chofchMapping);

            if (indicator.ChoChDisplayType != ARC_SMC_DisplayType.None)
            {
                propertyDescriptorCollection.Add(chofchCount);
                propertyDescriptorCollection.Add(chofchMapping);

            }

            return propertyDescriptorCollection;
        }

        // Important: This must return true otherwise the type convetor will not be called
        public override bool GetPropertiesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_SMC[] cacheARC_SMC;
		public ARC.ARC_SMC ARC_SMC(bool useMTF, BarsPeriodType mTFBarPeriodPeriodType, int mTFBarPeriodPeriodValue, TradingHours tradingHoursInstance, bool showSwingHighLow, bool showHHLL, ARC_SMC_DisplayType bOSDisplayType, int numberOfBOSToDisplay, ARC_SMC_PullbackMode bOSPullBackType, int bOSATRPeriod, double bOSATRMultiplier, double bOSPullbackPercentage, double bOSPullbackTicks, bool bOSAlert, bool showInternalHighLow, ARC_SMC_DisplayType choChDisplayType, int numberOfChoChToDisplay, bool showFibRetracements, bool showFibNumbers, ARC_SMC_FibonacciType fibonacciType, double fibRetracement1, double fibRetracement2, double fibRetracement3)
		{
			return ARC_SMC(Input, useMTF, mTFBarPeriodPeriodType, mTFBarPeriodPeriodValue, tradingHoursInstance, showSwingHighLow, showHHLL, bOSDisplayType, numberOfBOSToDisplay, bOSPullBackType, bOSATRPeriod, bOSATRMultiplier, bOSPullbackPercentage, bOSPullbackTicks, bOSAlert, showInternalHighLow, choChDisplayType, numberOfChoChToDisplay, showFibRetracements, showFibNumbers, fibonacciType, fibRetracement1, fibRetracement2, fibRetracement3);
		}

		public ARC.ARC_SMC ARC_SMC(ISeries<double> input, bool useMTF, BarsPeriodType mTFBarPeriodPeriodType, int mTFBarPeriodPeriodValue, TradingHours tradingHoursInstance, bool showSwingHighLow, bool showHHLL, ARC_SMC_DisplayType bOSDisplayType, int numberOfBOSToDisplay, ARC_SMC_PullbackMode bOSPullBackType, int bOSATRPeriod, double bOSATRMultiplier, double bOSPullbackPercentage, double bOSPullbackTicks, bool bOSAlert, bool showInternalHighLow, ARC_SMC_DisplayType choChDisplayType, int numberOfChoChToDisplay, bool showFibRetracements, bool showFibNumbers, ARC_SMC_FibonacciType fibonacciType, double fibRetracement1, double fibRetracement2, double fibRetracement3)
		{
			if (cacheARC_SMC != null)
				for (int idx = 0; idx < cacheARC_SMC.Length; idx++)
					if (cacheARC_SMC[idx] != null && cacheARC_SMC[idx].UseMTF == useMTF && cacheARC_SMC[idx].MTFBarPeriodPeriodType == mTFBarPeriodPeriodType && cacheARC_SMC[idx].MTFBarPeriodPeriodValue == mTFBarPeriodPeriodValue && cacheARC_SMC[idx].TradingHoursInstance == tradingHoursInstance && cacheARC_SMC[idx].ShowSwingHighLow == showSwingHighLow && cacheARC_SMC[idx].ShowHHLL == showHHLL && cacheARC_SMC[idx].BOSDisplayType == bOSDisplayType && cacheARC_SMC[idx].NumberOfBOSToDisplay == numberOfBOSToDisplay && cacheARC_SMC[idx].BOSPullBackType == bOSPullBackType && cacheARC_SMC[idx].BOSATRPeriod == bOSATRPeriod && cacheARC_SMC[idx].BOSATRMultiplier == bOSATRMultiplier && cacheARC_SMC[idx].BOSPullbackPercentage == bOSPullbackPercentage && cacheARC_SMC[idx].BOSPullbackTicks == bOSPullbackTicks && cacheARC_SMC[idx].BOSAlert == bOSAlert && cacheARC_SMC[idx].ShowInternalHighLow == showInternalHighLow && cacheARC_SMC[idx].ChoChDisplayType == choChDisplayType && cacheARC_SMC[idx].NumberOfChoChToDisplay == numberOfChoChToDisplay && cacheARC_SMC[idx].ShowFibRetracements == showFibRetracements && cacheARC_SMC[idx].ShowFibNumbers == showFibNumbers && cacheARC_SMC[idx].FibonacciType == fibonacciType && cacheARC_SMC[idx].FibRetracement1 == fibRetracement1 && cacheARC_SMC[idx].FibRetracement2 == fibRetracement2 && cacheARC_SMC[idx].FibRetracement3 == fibRetracement3 && cacheARC_SMC[idx].EqualsInput(input))
						return cacheARC_SMC[idx];
			return CacheIndicator<ARC.ARC_SMC>(new ARC.ARC_SMC(){ UseMTF = useMTF, MTFBarPeriodPeriodType = mTFBarPeriodPeriodType, MTFBarPeriodPeriodValue = mTFBarPeriodPeriodValue, TradingHoursInstance = tradingHoursInstance, ShowSwingHighLow = showSwingHighLow, ShowHHLL = showHHLL, BOSDisplayType = bOSDisplayType, NumberOfBOSToDisplay = numberOfBOSToDisplay, BOSPullBackType = bOSPullBackType, BOSATRPeriod = bOSATRPeriod, BOSATRMultiplier = bOSATRMultiplier, BOSPullbackPercentage = bOSPullbackPercentage, BOSPullbackTicks = bOSPullbackTicks, BOSAlert = bOSAlert, ShowInternalHighLow = showInternalHighLow, ChoChDisplayType = choChDisplayType, NumberOfChoChToDisplay = numberOfChoChToDisplay, ShowFibRetracements = showFibRetracements, ShowFibNumbers = showFibNumbers, FibonacciType = fibonacciType, FibRetracement1 = fibRetracement1, FibRetracement2 = fibRetracement2, FibRetracement3 = fibRetracement3 }, input, ref cacheARC_SMC);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_SMC ARC_SMC(bool useMTF, BarsPeriodType mTFBarPeriodPeriodType, int mTFBarPeriodPeriodValue, TradingHours tradingHoursInstance, bool showSwingHighLow, bool showHHLL, ARC_SMC_DisplayType bOSDisplayType, int numberOfBOSToDisplay, ARC_SMC_PullbackMode bOSPullBackType, int bOSATRPeriod, double bOSATRMultiplier, double bOSPullbackPercentage, double bOSPullbackTicks, bool bOSAlert, bool showInternalHighLow, ARC_SMC_DisplayType choChDisplayType, int numberOfChoChToDisplay, bool showFibRetracements, bool showFibNumbers, ARC_SMC_FibonacciType fibonacciType, double fibRetracement1, double fibRetracement2, double fibRetracement3)
		{
			return indicator.ARC_SMC(Input, useMTF, mTFBarPeriodPeriodType, mTFBarPeriodPeriodValue, tradingHoursInstance, showSwingHighLow, showHHLL, bOSDisplayType, numberOfBOSToDisplay, bOSPullBackType, bOSATRPeriod, bOSATRMultiplier, bOSPullbackPercentage, bOSPullbackTicks, bOSAlert, showInternalHighLow, choChDisplayType, numberOfChoChToDisplay, showFibRetracements, showFibNumbers, fibonacciType, fibRetracement1, fibRetracement2, fibRetracement3);
		}

		public Indicators.ARC.ARC_SMC ARC_SMC(ISeries<double> input , bool useMTF, BarsPeriodType mTFBarPeriodPeriodType, int mTFBarPeriodPeriodValue, TradingHours tradingHoursInstance, bool showSwingHighLow, bool showHHLL, ARC_SMC_DisplayType bOSDisplayType, int numberOfBOSToDisplay, ARC_SMC_PullbackMode bOSPullBackType, int bOSATRPeriod, double bOSATRMultiplier, double bOSPullbackPercentage, double bOSPullbackTicks, bool bOSAlert, bool showInternalHighLow, ARC_SMC_DisplayType choChDisplayType, int numberOfChoChToDisplay, bool showFibRetracements, bool showFibNumbers, ARC_SMC_FibonacciType fibonacciType, double fibRetracement1, double fibRetracement2, double fibRetracement3)
		{
			return indicator.ARC_SMC(input, useMTF, mTFBarPeriodPeriodType, mTFBarPeriodPeriodValue, tradingHoursInstance, showSwingHighLow, showHHLL, bOSDisplayType, numberOfBOSToDisplay, bOSPullBackType, bOSATRPeriod, bOSATRMultiplier, bOSPullbackPercentage, bOSPullbackTicks, bOSAlert, showInternalHighLow, choChDisplayType, numberOfChoChToDisplay, showFibRetracements, showFibNumbers, fibonacciType, fibRetracement1, fibRetracement2, fibRetracement3);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_SMC ARC_SMC(bool useMTF, BarsPeriodType mTFBarPeriodPeriodType, int mTFBarPeriodPeriodValue, TradingHours tradingHoursInstance, bool showSwingHighLow, bool showHHLL, ARC_SMC_DisplayType bOSDisplayType, int numberOfBOSToDisplay, ARC_SMC_PullbackMode bOSPullBackType, int bOSATRPeriod, double bOSATRMultiplier, double bOSPullbackPercentage, double bOSPullbackTicks, bool bOSAlert, bool showInternalHighLow, ARC_SMC_DisplayType choChDisplayType, int numberOfChoChToDisplay, bool showFibRetracements, bool showFibNumbers, ARC_SMC_FibonacciType fibonacciType, double fibRetracement1, double fibRetracement2, double fibRetracement3)
		{
			return indicator.ARC_SMC(Input, useMTF, mTFBarPeriodPeriodType, mTFBarPeriodPeriodValue, tradingHoursInstance, showSwingHighLow, showHHLL, bOSDisplayType, numberOfBOSToDisplay, bOSPullBackType, bOSATRPeriod, bOSATRMultiplier, bOSPullbackPercentage, bOSPullbackTicks, bOSAlert, showInternalHighLow, choChDisplayType, numberOfChoChToDisplay, showFibRetracements, showFibNumbers, fibonacciType, fibRetracement1, fibRetracement2, fibRetracement3);
		}

		public Indicators.ARC.ARC_SMC ARC_SMC(ISeries<double> input , bool useMTF, BarsPeriodType mTFBarPeriodPeriodType, int mTFBarPeriodPeriodValue, TradingHours tradingHoursInstance, bool showSwingHighLow, bool showHHLL, ARC_SMC_DisplayType bOSDisplayType, int numberOfBOSToDisplay, ARC_SMC_PullbackMode bOSPullBackType, int bOSATRPeriod, double bOSATRMultiplier, double bOSPullbackPercentage, double bOSPullbackTicks, bool bOSAlert, bool showInternalHighLow, ARC_SMC_DisplayType choChDisplayType, int numberOfChoChToDisplay, bool showFibRetracements, bool showFibNumbers, ARC_SMC_FibonacciType fibonacciType, double fibRetracement1, double fibRetracement2, double fibRetracement3)
		{
			return indicator.ARC_SMC(input, useMTF, mTFBarPeriodPeriodType, mTFBarPeriodPeriodValue, tradingHoursInstance, showSwingHighLow, showHHLL, bOSDisplayType, numberOfBOSToDisplay, bOSPullBackType, bOSATRPeriod, bOSATRMultiplier, bOSPullbackPercentage, bOSPullbackTicks, bOSAlert, showInternalHighLow, choChDisplayType, numberOfChoChToDisplay, showFibRetracements, showFibNumbers, fibonacciType, fibRetracement1, fibRetracement2, fibRetracement3);
		}
	}
}

#endregion
