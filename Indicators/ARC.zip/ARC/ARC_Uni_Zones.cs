#define DoLicense
#define MODERATORS
#define INCLUDE_GLOBALIZATION

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

public enum ARC_Uni_Zones_MAType		{SMA,EMA}
//public enum ARC_Uni_Zones_Mode {PricePullback, VolumePullback, VolumeMomentum}
public enum ARC_Uni_Zones_ZoneCalcModes	{Structure, PriceAction}
public enum ARC_Uni_Zones_ATRModeEnum	{Ticks, Points}
public enum ARC_Uni_Zones_InputType		{High_Low, Close}
public enum ARC_Uni_Zones_MarkerType	{None, Arrow, Dot, Square, Diamond, Triangle}
public enum ARC_Uni_Zones_DistanceBasis	{TickDistance, ATRmultiple}
public enum ARC_Uni_Zones_BarBasis		{Full, Partial, BarClose}
public enum ARC_Uni_Zones_OverlapBasis	{ShowAll, NoOverlaps, ShortBias, LongBias, Replacements}
public enum ARC_Uni_Zones_SuppResBoth	{SupportOnly, ResistanceOnly, Both}
public enum ARC_Uni_Zones_EntryPriceBasis		{PivotBarOpen, PivotBarClose, OpenOfPriorBar, FullBar}
public enum ARC_Uni_Zones_BasingZoneSizeBasis	{FullBase, Body}
public enum ARC_Uni_Zones_GapMeasurements		{Ticks, ATR}

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	//Launch video Sept 2022:  https://youtu.be/NtKZ8elRwYc

    [CategoryOrder("Parameters",         5)]
    [CategoryOrder("PriceAction Params", 8)]
    [CategoryOrder("Trap Params",        9)]
    [CategoryOrder("Swing Parameters",  10)]
    [CategoryOrder("Zone Creation",     20)]
    [CategoryOrder("Zone Breaking",     30)]
    [CategoryOrder("Zones",			    40)]
    [CategoryOrder("Global Zones",      50)]
    [CategoryOrder("Custom Visuals",    70)]
	[CategoryOrder("Indicator Version", 1100)]

	public class ARC_Uni_Zones : Indicator, ICustomTypeDescriptor
	{
		private const string VERSION = "v1.22 28.Sept.2023";
		[Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
		public string indicatorVersion { get { return VERSION; } }

		//v1.21 - added "Thrust Bars Delay" parameter.  This permits a number of inside bars to print before a valid thrust bar close breaks out from the basing bar high or low

		//these variables are for DoLicense enabled
		static bool IsDebug        = false;
		private bool ValidLicense  = false;
		private bool IsExpired     = true;
		private bool LicenseChecked = false;
		private string UserId       = string.Empty;
		private string MachineId    = string.Empty;
		string ModuleName = "UniZones";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "20440", "25900", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		private const byte HH = 1;
		private const byte LL = 2;
		private const byte HL = 3;
		private const byte LH = 4;
		private const int LONG = 1;
		private const int EITHER = 0;
		private const int FLAT = 0;
		private const int SHORT = -1;


        #region -- Structure BIAS + Swings --
        private List<int> sequence = new List<int>(3);//#STRBIAS
        private int SRType, preSRType;//#STRBIAS  
        #endregion

        #region -- zigzag indicator -- 
        private int lastHighIdx = 0;
        private int lastLowIdx = 0;
        private int priorSwingHighIdx = 0;
        private int priorSwingLowIdx = 0;
        private int highCount = 0;
        private int lowCount = 0;
        private int preLastHighIdx = 0;
        private int preLastLowIdx = 0;
        private double zigzagDeviation = 0.0;
        private double currentHigh = 0.0;
        private double currentLow = 0.0;
        private double swingMax = 0.0;
        private double swingMin = 0.0;
        private double preCurrentHigh = 0.0;
        private double preCurrentLow = 0.0;
        private bool addHigh = false;
        private bool updateHigh = false;
        private bool addLow = false;
        private bool updateLow = false;
        private bool intraBarAddHigh = false;
        private bool intraBarUpdateHigh = false;
        private bool intraBarAddLow = false;
        private bool intraBarUpdateLow = false;
		private Series<double> structureBiasState;
//		private Series<double> swingHighsState;
//		private Series<double> swingLowsState;
        private bool drawSwingLegUp = false;
        private bool drawSwingLegDown = false;

		DateTime StartTime1 = DateTime.MinValue;
		DateTime EndTime1   = DateTime.MinValue;
		double Session1LengthHrs = 0;
		bool ParameterError      = false;

        private Brush upColor   = Brushes.LimeGreen;//##HARD CODED##
        private Brush downColor = Brushes.Red;      //##HARD CODED##
//        private Brush doubleTopBottomColor = Brushes.Yellow;   //##HARD CODED##
//        private string dotString = "n";              //##HARD CODED##

        private ATR avgTrueRange;
        private Series<double> swingInput;
        private Series<int> pre_swingHighType;
        private Series<int> pre_swingLowType;
//        private Series<int> swingHighType;
//        private Series<int> swingLowType;
        private Series<bool> upTrend;
        #endregion

		#region -- Toolbar variables --
		private string toolbarname = "ARC_Uni_Zones_TB", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;

		private Menu MenuControlContainer;
		private MenuItem MenuControl, miZoneCalcMethod, miZigZagOnOff, miDelAllGlobals, miBackfillZonesToOrigin, miShowPriceActionZonesOnOff, miShowOrderblockZonesOnOff, miShowTrapZonesOnOff;
		private Label   lbl_SwingStrength, lbl_MultiplierDTB, lbl_MaxBodyPct;
		private TextBox nud_SwingStrength, nud_MultiplierDTB, nud_MaxBodyPct;
		private MenuItem miShowFreshZones, miShowTestedZones, miShowBrokenZones, miShowDeadZones;
		private MenuItem miGlobalizeFreshZones, miGlobalizeTestedZones, miGlobalizeBrokenZones, miGlobalizeDeadZones;
		private MenuItem miSuppResBoth, miOverlapBasis;

		private MenuItem miRecalculate1;
		#endregion
	#region -- addToolBar --
		private void addToolBar()
		{
			int rHeight = 26;
			MenuControlContainer = new Menu { Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Center };
			MenuControl          = new MenuItem { BorderThickness = new Thickness(2), Header = pButtonText, BorderBrush = Brushes.Magenta, Foreground = Brushes.Lime, Background = Brushes.Navy, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);

			#region -- ZoneCalcMode switch --
			miZoneCalcMethod      = new MenuItem { Header = "Zone Calc Mode: "+pZoneCalcMode.ToString(), Name = "ZoneCalcMode"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal,    StaysOpenOnClick = true };
			miZoneCalcMethod.Click += delegate (object o, RoutedEventArgs e)
			{
				if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction)
					pZoneCalcMode = ARC_Uni_Zones_ZoneCalcModes.Structure;
				else if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure)
					pZoneCalcMode = ARC_Uni_Zones_ZoneCalcModes.PriceAction;

				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miZoneCalcMethod.Header = "Zone Calc Mode: "+pZoneCalcMode.ToString();
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miZoneCalcMethod.Header = "Zone Calc Mode: "+pZoneCalcMode.ToString();
							ForceRefresh();
						}));
					}
				}
			};
			miZoneCalcMethod.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction)
					pZoneCalcMode = ARC_Uni_Zones_ZoneCalcModes.Structure;
				else if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure)
					pZoneCalcMode = ARC_Uni_Zones_ZoneCalcModes.PriceAction;

				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miZoneCalcMethod.Header = "Zone Calc Mode: "+pZoneCalcMode.ToString();
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miZoneCalcMethod.Header = "Zone Calc Mode: "+pZoneCalcMode.ToString();
							ForceRefresh();
						}));
					}
				}
			};

			MenuControl.Items.Add(miZoneCalcMethod);
			#endregion

			if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction){
				#region -- pShowSandDZones switch --
				miShowPriceActionZonesOnOff      = new MenuItem { Header = "S & D: "+(pShowSandDZones ? "ON":"OFF"), Name = "pShowSandDZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pShowSandDZones,    StaysOpenOnClick = true };
				miShowPriceActionZonesOnOff.Click += delegate (object o, RoutedEventArgs e)
				{
					pShowSandDZones = !pShowSandDZones;
					if(ChartControl != null){
						if (ChartControl.Dispatcher.CheckAccess()) {
							InformUserAboutRecalculation();
							miShowPriceActionZonesOnOff.IsChecked = pShowSandDZones;
							miShowPriceActionZonesOnOff.Header = "S & D: "+(pShowSandDZones ? "ON":"OFF");
							ForceRefresh();
						}else{
							Dispatcher.BeginInvoke(new Action(() =>
							{
								InformUserAboutRecalculation();
								miShowPriceActionZonesOnOff.IsChecked = pShowSandDZones;
								miShowPriceActionZonesOnOff.Header = "S & D: "+(pShowSandDZones ? "ON":"OFF");
								ForceRefresh();
							}));
						}
					}
				};
				miShowPriceActionZonesOnOff.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e)
				{
					pShowSandDZones = !pShowSandDZones;
					if(ChartControl != null){
						if (ChartControl.Dispatcher.CheckAccess()) {
							InformUserAboutRecalculation();
							miShowPriceActionZonesOnOff.IsChecked = pShowSandDZones;
							miShowPriceActionZonesOnOff.Header = "S & D: "+(pShowSandDZones ? "ON":"OFF");
							ForceRefresh();
						}else{
							Dispatcher.BeginInvoke(new Action(() =>
							{
								InformUserAboutRecalculation();
								miShowPriceActionZonesOnOff.IsChecked = pShowSandDZones;
								miShowPriceActionZonesOnOff.Header = "S & D: "+(pShowSandDZones ? "ON":"OFF");
								ForceRefresh();
							}));
						}
					}
				};

				MenuControl.Items.Add(miShowPriceActionZonesOnOff);
				#endregion
				#region -- pShowOrderblockZones switch --
				miShowOrderblockZonesOnOff      = new MenuItem { Header = "Orderblocks: "+(pShowOrderblockZones ? "ON":"OFF"), Name = "pShowOrderblockZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pShowOrderblockZones,    StaysOpenOnClick = true };
				miShowOrderblockZonesOnOff.Click += delegate (object o, RoutedEventArgs e)
				{
					pShowOrderblockZones = !pShowOrderblockZones;
					if(ChartControl != null){
						if (ChartControl.Dispatcher.CheckAccess()) {
							InformUserAboutRecalculation();
							miShowOrderblockZonesOnOff.IsChecked = pShowOrderblockZones;
							miShowOrderblockZonesOnOff.Header = "Orderblocks: "+(pShowOrderblockZones ? "ON":"OFF");
							ForceRefresh();
						}else{
							Dispatcher.BeginInvoke(new Action(() =>
							{
								InformUserAboutRecalculation();
								miShowOrderblockZonesOnOff.IsChecked = pShowOrderblockZones;
								miShowOrderblockZonesOnOff.Header = "Orderblocks: "+(pShowOrderblockZones ? "ON":"OFF");
								ForceRefresh();
							}));
						}
					}
				};
				miShowOrderblockZonesOnOff.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e)
				{
					pShowOrderblockZones = !pShowOrderblockZones;
					if(ChartControl != null){
						if (ChartControl.Dispatcher.CheckAccess()) {
							InformUserAboutRecalculation();
							miShowOrderblockZonesOnOff.IsChecked = pShowOrderblockZones;
							miShowOrderblockZonesOnOff.Header = "Orderblocks: "+(pShowOrderblockZones ? "ON":"OFF");
							ForceRefresh();
						}else{
							Dispatcher.BeginInvoke(new Action(() =>
							{
								InformUserAboutRecalculation();
								miShowOrderblockZonesOnOff.IsChecked = pShowOrderblockZones;
								miShowOrderblockZonesOnOff.Header = "Orderblocks: "+(pShowOrderblockZones ? "ON":"OFF");
								ForceRefresh();
							}));
						}
					}
				};

				MenuControl.Items.Add(miShowOrderblockZonesOnOff);
				#endregion
				#region -- pShowTrapZones switch --
				miShowTrapZonesOnOff      = new MenuItem { Header = "Traps: "+(pShowTrapZones ? "ON":"OFF"), Name = "pShowTrapZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pShowTrapZones,    StaysOpenOnClick = true };
				miShowTrapZonesOnOff.Click += delegate (object o, RoutedEventArgs e)
				{
					pShowTrapZones = !pShowTrapZones;
					if(ChartControl != null){
						if (ChartControl.Dispatcher.CheckAccess()) {
							InformUserAboutRecalculation();
							miShowTrapZonesOnOff.IsChecked = pShowTrapZones;
							miShowTrapZonesOnOff.Header = "Traps: "+(pShowTrapZones ? "ON":"OFF");
							ForceRefresh();
						}else{
							Dispatcher.BeginInvoke(new Action(() =>
							{
								InformUserAboutRecalculation();
								miShowTrapZonesOnOff.IsChecked = pShowTrapZones;
								miShowTrapZonesOnOff.Header = "Traps: "+(pShowTrapZones ? "ON":"OFF");
								ForceRefresh();
							}));
						}
					}
				};
				miShowTrapZonesOnOff.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e)
				{
					pShowTrapZones = !pShowTrapZones;
					if(ChartControl != null){
						if (ChartControl.Dispatcher.CheckAccess()) {
							InformUserAboutRecalculation();
							miShowTrapZonesOnOff.IsChecked = pShowTrapZones;
							miShowTrapZonesOnOff.Header = "Orderblocks: "+(pShowTrapZones ? "ON":"OFF");
							ForceRefresh();
						}else{
							Dispatcher.BeginInvoke(new Action(() =>
							{
								InformUserAboutRecalculation();
								miShowTrapZonesOnOff.IsChecked = pShowTrapZones;
								miShowTrapZonesOnOff.Header = "Orderblocks: "+(pShowTrapZones ? "ON":"OFF");
								ForceRefresh();
							}));
						}
					}
				};

				MenuControl.Items.Add(miShowTrapZonesOnOff);
				#endregion
			}
			#region -- Zigzag lines On/Off switch --
			miZigZagOnOff      = new MenuItem { Header = "ZigZag "+(pShowZigzagLegs ? "ON":"OFF"), Name = "ZigZagOnOff"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pShowZigzagLegs,    StaysOpenOnClick = true };
			miZigZagOnOff.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pShowZigzagLegs = !this.pShowZigzagLegs;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						//InformUserAboutRecalculation();
						miZigZagOnOff.IsChecked = pShowZigzagLegs;
						miZigZagOnOff.Header = "ZigZag "+(pShowZigzagLegs ? "ON":"OFF");
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							//InformUserAboutRecalculation();
							miZigZagOnOff.IsChecked = pShowZigzagLegs;
							miZigZagOnOff.Header = "ZigZag "+(pShowZigzagLegs ? "ON":"OFF");
							ForceRefresh();
						}));
					}
				}
			};
			MenuControl.Items.Add(miZigZagOnOff);
			#endregion

			MenuControl.Items.Add(new Separator());

			int row = 0;
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = new GridLength(40) });
//			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });

			//grid = new Grid(); row = 0;
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = new GridLength(40) });

			#region -- MultiplierDTB numerical box --
				grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });

				lbl_MultiplierDTB = new Label() { Name = "lbl_MultiplierDTB"+uID,  Content = "Sensitivity DT/DB ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
	            lbl_MultiplierDTB.SetValue(Grid.ColumnProperty, 0);
	            lbl_MultiplierDTB.SetValue(Grid.RowProperty, row);

				nud_MultiplierDTB = new TextBox() { Name = "nud_MultiplierDTB"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
	            nud_MultiplierDTB.Text = pMultiplierDTB.ToString();
				nud_MultiplierDTB.KeyDown += menuTxtbox_KeyDownInteger;
				nud_MultiplierDTB.ToolTip = "Use mousewheel to change number";
	            nud_MultiplierDTB.TextChanged += delegate(object o, TextChangedEventArgs e){
					InformUserAboutRecalculation();
					double max = 1000;
					double min = 0;
					double x = nud_MultiplierDTB.Text.Trim().Length==0 ? min : Convert.ToDouble(nud_MultiplierDTB.Text);
					if(x>max) {
						nud_MultiplierDTB.Text = max.ToString();
						x=max;
					}
					if(x<min) {
						nud_MultiplierDTB.Text = min.ToString();
						x=min;
					}
					this.pMultiplierDTB = x;
	//				ForceRefresh();
				};
				nud_MultiplierDTB.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
					InformUserAboutRecalculation();
	//				e.Handled = true;
					double max = 1000;
					double min = 0;
					double x = nud_MultiplierDTB.Text.Trim().Length==0 ? min : Convert.ToDouble(nud_MultiplierDTB.Text);
					if(e.Delta<0){
						x = x - 0.1;
						x = Math.Max(min, Math.Min(max,x));
						pMultiplierDTB = x;
						nud_MultiplierDTB.Text = x.ToString();
					}else if(e.Delta>0){
						x = x + 0.1;
						x = Math.Max(min, Math.Min(max,x));
						pMultiplierDTB = x;
						nud_MultiplierDTB.Text = x.ToString();
					}
	//				ForceRefresh();
				};
				nud_MultiplierDTB.SetValue(Grid.ColumnProperty, 1);
	            nud_MultiplierDTB.SetValue(Grid.RowProperty, row);
	            grid.Children.Add(lbl_MultiplierDTB);
	            grid.Children.Add(nud_MultiplierDTB);
			#endregion
			#region -- Swing Strength numerical box --
				grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });
				row++;

				lbl_SwingStrength = new Label() { Name = "lbl_SwingStrength"+uID,  Content = "Swing Strength ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
	            lbl_SwingStrength.SetValue(Grid.ColumnProperty, 0);
	            lbl_SwingStrength.SetValue(Grid.RowProperty, row);

				nud_SwingStrength = new TextBox() { Name = "nud_SwingStrength"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
	            nud_SwingStrength.Text = pSwingStrength.ToString();
				nud_SwingStrength.KeyDown += menuTxtbox_KeyDownInteger;
				nud_SwingStrength.ToolTip = "Use mousewheel to change number";
	            nud_SwingStrength.TextChanged += delegate(object o, TextChangedEventArgs e){
					InformUserAboutRecalculation();
					int max = 1000;
					int min = 1;
					int x = nud_SwingStrength.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_SwingStrength.Text);
					if(x>max) {
						nud_SwingStrength.Text = max.ToString();
						x=max;
					}
					if(x<min) {
						nud_SwingStrength.Text = min.ToString();
						x=min;
					}
					this.pSwingStrength = x;
					//ForceRefresh();
				};
				nud_SwingStrength.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
					InformUserAboutRecalculation();
					int max = 1000;
					int min = 1;
					int x = nud_SwingStrength.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_SwingStrength.Text);
					if(e.Delta<0){
						x = x - 1;
						x = Math.Max(min, Math.Min(max,x));
						pSwingStrength = x;
						nud_SwingStrength.Text = x.ToString();
					}else if(e.Delta>0){
						x = x + 1;
						x = Math.Max(min, Math.Min(max,x));
						pSwingStrength = x;
						nud_SwingStrength.Text = x.ToString();
					}
					//ForceRefresh();
				};
				nud_SwingStrength.SetValue(Grid.ColumnProperty, 1);
	            nud_SwingStrength.SetValue(Grid.RowProperty, row);
	            grid.Children.Add(lbl_SwingStrength);
	            grid.Children.Add(nud_SwingStrength);
			#endregion

			if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction){
				#region -- Max body pct --
				grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });
				row++;

				lbl_MaxBodyPct = new Label() { Name = "lbl_MaxBodyPct"+uID,  Content = "Max Body % ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
	            lbl_MaxBodyPct.SetValue(Grid.ColumnProperty, 0);
	            lbl_MaxBodyPct.SetValue(Grid.RowProperty, row);

				nud_MaxBodyPct = new TextBox() { Name = "nud_MaxBodyPct"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
	            nud_MaxBodyPct.Text = pMaxBodyPct.ToString();
				nud_MaxBodyPct.KeyDown += menuTxtbox_KeyDownInteger;
				nud_MaxBodyPct.ToolTip = "Use mousewheel to change number";
	            nud_MaxBodyPct.TextChanged += delegate(object o, TextChangedEventArgs e){
					InformUserAboutRecalculation();
					int max = 100;
					int min = 1;
					int x = nud_MaxBodyPct.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_MaxBodyPct.Text);
					if(x>max) {
						nud_MaxBodyPct.Text = max.ToString();
						x=max;
					}
					if(x<min) {
						nud_MaxBodyPct.Text = min.ToString();
						x=min;
					}
					this.pMaxBodyPct = x;
					//ForceRefresh();
				};
				nud_MaxBodyPct.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
					InformUserAboutRecalculation();
					int max = 100;
					int min = 1;
					int x = nud_MaxBodyPct.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_MaxBodyPct.Text);
					if(e.Delta<0){
						x = x - 1;
						x = Math.Max(min, Math.Min(max,x));
						pMaxBodyPct = x;
						nud_MaxBodyPct.Text = x.ToString();
					}else if(e.Delta>0){
						x = x + 1;
						x = Math.Max(min, Math.Min(max,x));
						pMaxBodyPct = x;
						nud_MaxBodyPct.Text = x.ToString();
					}
					//ForceRefresh();
				};
				nud_MaxBodyPct.SetValue(Grid.ColumnProperty, 1);
	            nud_MaxBodyPct.SetValue(Grid.RowProperty, row);
	            grid.Children.Add(lbl_MaxBodyPct);
	            grid.Children.Add(nud_MaxBodyPct);
				#endregion
			}

			#region -- pSuppResBoth switch --
			miSuppResBoth      = new MenuItem { Header = "Supp/Res/Both: "+pSuppResBoth.ToString(), Name = "pSuppResBoth"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal,    StaysOpenOnClick = true };
			miSuppResBoth.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				if(e.Delta>0){
					if(pSuppResBoth == ARC_Uni_Zones_SuppResBoth.SupportOnly)
						pSuppResBoth = ARC_Uni_Zones_SuppResBoth.ResistanceOnly;
					else if(pSuppResBoth == ARC_Uni_Zones_SuppResBoth.ResistanceOnly)
						pSuppResBoth = ARC_Uni_Zones_SuppResBoth.Both;
					else if(pSuppResBoth == ARC_Uni_Zones_SuppResBoth.Both)
						pSuppResBoth = ARC_Uni_Zones_SuppResBoth.SupportOnly;
				}else{
					if(pSuppResBoth == ARC_Uni_Zones_SuppResBoth.ResistanceOnly)
						pSuppResBoth = ARC_Uni_Zones_SuppResBoth.SupportOnly;
					else if(pSuppResBoth == ARC_Uni_Zones_SuppResBoth.Both)
						pSuppResBoth = ARC_Uni_Zones_SuppResBoth.ResistanceOnly;
					else if(pSuppResBoth == ARC_Uni_Zones_SuppResBoth.SupportOnly)
						pSuppResBoth = ARC_Uni_Zones_SuppResBoth.Both;
				}

				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miSuppResBoth.Header = "Supp/Res/Both: "+pSuppResBoth.ToString();
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miSuppResBoth.Header = "Supp/Res/Both: "+pSuppResBoth.ToString();
							ForceRefresh();
						}));
					}
				}
			};
			miSuppResBoth.Click += delegate (object o, RoutedEventArgs e)
			{
				if(pSuppResBoth == ARC_Uni_Zones_SuppResBoth.SupportOnly)
					pSuppResBoth = ARC_Uni_Zones_SuppResBoth.ResistanceOnly;
				else if(pSuppResBoth == ARC_Uni_Zones_SuppResBoth.ResistanceOnly)
					pSuppResBoth = ARC_Uni_Zones_SuppResBoth.Both;
				else if(pSuppResBoth == ARC_Uni_Zones_SuppResBoth.Both)
					pSuppResBoth = ARC_Uni_Zones_SuppResBoth.SupportOnly;

				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miSuppResBoth.Header = "Supp/Res/Both: "+pSuppResBoth.ToString();
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miSuppResBoth.Header = "Supp/Res/Both: "+pSuppResBoth.ToString();
							ForceRefresh();
						}));
					}
				}
			};
			MenuControl.Items.Add(miSuppResBoth);
			#endregion
			#region -- pOverlapBasis switch -- ARC_Uni_Zones_OverlapBasis pOverlapBasis
			if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure){
				miOverlapBasis      = new MenuItem { Header = "Overlap Basis:  "+pOverlapBasis.ToString(), Name = "pOverlapBasis"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal,    StaysOpenOnClick = true };
				miOverlapBasis.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
					if(e.Delta>0){
						if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.ShowAll)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.NoOverlaps;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.NoOverlaps)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.ShortBias;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.ShortBias)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.LongBias;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.LongBias)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.Replacements;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.Replacements)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.ShowAll;
					}else{
						if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.NoOverlaps)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.ShowAll;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.ShortBias)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.NoOverlaps;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.LongBias)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.ShortBias;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.Replacements)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.LongBias;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.ShowAll)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.Replacements;
					}

					if(ChartControl != null){
						if (ChartControl.Dispatcher.CheckAccess()) {
							InformUserAboutRecalculation();
							miOverlapBasis.Header = "Overlap Basis:  "+pOverlapBasis.ToString();
							ForceRefresh();
						}else{
							Dispatcher.BeginInvoke(new Action(() =>
							{
								InformUserAboutRecalculation();
								miOverlapBasis.Header = "Overlap Basis:  "+pOverlapBasis.ToString();
								ForceRefresh();
							}));
						}
					}
				};
				miOverlapBasis.Click += delegate (object o, RoutedEventArgs e)
				{
						if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.LongBias)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.ShortBias;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.ShortBias)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.Replacements;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.Replacements)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.ShowAll;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.ShowAll)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.NoOverlaps;
						else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.NoOverlaps)
							pOverlapBasis = ARC_Uni_Zones_OverlapBasis.LongBias;

					if(ChartControl != null){
						if (ChartControl.Dispatcher.CheckAccess()) {
							InformUserAboutRecalculation();
							miOverlapBasis.Header = "Overlap Basis:  "+pOverlapBasis.ToString();
							ForceRefresh();
						}else{
							Dispatcher.BeginInvoke(new Action(() =>
							{
								InformUserAboutRecalculation();
								miOverlapBasis.Header = "Overlap Basis:  "+pOverlapBasis.ToString();
								ForceRefresh();
							}));
						}
					}
				};
				MenuControl.Items.Add(miOverlapBasis);
			}
			#endregion

			MenuControl.Items.Add(grid);

			#region -- Recalc --
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			miRecalculate1.ToolTip="If this does not refresh your chart, hit your F5 function key instead";
			MenuControl.Items.Add(miRecalculate1);
			#endregion

			MenuControl.Items.Add(new Separator());

			#region -- pBackfillZonesToOrigin switch --
			if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure){
				miBackfillZonesToOrigin      = new MenuItem { Header = "Backfill To Origin", Name = "pBackfillZonesToOrigin"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal,IsCheckable = true, IsChecked = this.pBackfillZonesToOrigin, StaysOpenOnClick = true };
				miBackfillZonesToOrigin.Click += delegate (object o, RoutedEventArgs e)
				{
					this.pBackfillZonesToOrigin = !this.pBackfillZonesToOrigin;
					ForceRefresh();
//				if(ChartControl != null){
//					if (ChartControl.Dispatcher.CheckAccess()) {
//						ForceRefresh();
//					}else{
//						Dispatcher.BeginInvoke(new Action(() =>
//						{
//							ForceRefresh();
//						}));
//					}
//				}
			};
				MenuControl.Items.Add(miBackfillZonesToOrigin);
			}
			#endregion
			#region -- ShowFreshZones switch --
			miShowFreshZones      = new MenuItem { Header = "Show Fresh Zones", Name = "pShowFreshZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal,IsCheckable = true, IsChecked = this.pShowFreshZones, StaysOpenOnClick = true };
			miShowFreshZones.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pShowFreshZones = !this.pShowFreshZones;
				ForceRefresh();
			};
			MenuControl.Items.Add(miShowFreshZones);
			#endregion
			#region -- ShowTestedZones switch --
			miShowTestedZones      = new MenuItem { Header = "Show Tested Zones", Name = "pShowTestedZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal,IsCheckable = true, IsChecked = this.pShowTestedZones, StaysOpenOnClick = true };
			miShowTestedZones.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pShowTestedZones = !this.pShowTestedZones;
				ForceRefresh();
			};
			MenuControl.Items.Add(miShowTestedZones);
			#endregion
			#region -- ShowBrokenZones switch --
			miShowBrokenZones      = new MenuItem { Header = "Show Broken Zones", Name = "pShowBrokenZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal,IsCheckable = true, IsChecked = this.pShowBrokenZones, StaysOpenOnClick = true };
			miShowBrokenZones.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pShowBrokenZones = !this.pShowBrokenZones;
				ForceRefresh();
			};
			MenuControl.Items.Add(miShowBrokenZones);
			#endregion
			#region -- ShowDeadZones switch --
			if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure){
				miShowDeadZones      = new MenuItem { Header = "Show Dead Zones", Name = "pShowDeadZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal,IsCheckable = true, IsChecked = this.pShowDeadZones, StaysOpenOnClick = true };
				miShowDeadZones.Click += delegate (object o, RoutedEventArgs e)
				{
					this.pShowDeadZones = !this.pShowDeadZones;
					ForceRefresh();
				};
				MenuControl.Items.Add(miShowDeadZones);
			}
			#endregion

			MenuControl.Items.Add(new Separator());

#if INCLUDE_GLOBALIZATION
			#region -- GlobalizeFreshZones switch --
			miGlobalizeFreshZones      = new MenuItem { Header = "Globalize Fresh Zones", Name = "pGlobalizeFreshZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pGlobalizeFreshZones, StaysOpenOnClick = true };
			miGlobalizeFreshZones.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pGlobalizeFreshZones = !this.pGlobalizeFreshZones;
				miGlobalizeFreshZones.IsChecked = pGlobalizeFreshZones;
				if(ChartControl != null){
					var zones = Zones.Where(k=>k.Value.Status == 'F');
					if(zones!=null){
						foreach(var z in zones){
							if(!pGlobalizeFreshZones) RemoveDrawObject(z.Value.Tag);
							else DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin || pZoneCalcMode==ARC_Uni_Zones_ZoneCalcModes.PriceAction ? z.Key:z.Value.ConfirmedABar);
						}
					}
				}
				ForceRefresh();
			};
			MenuControl.Items.Add(miGlobalizeFreshZones);
			#endregion
			#region -- GlobalizeTestedZones switch --
			miGlobalizeTestedZones      = new MenuItem { Header = "Globalize Tested Zones", Name = "pGlobalizeTestedZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pGlobalizeTestedZones, StaysOpenOnClick = true };
			miGlobalizeTestedZones.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pGlobalizeTestedZones = !this.pGlobalizeTestedZones;
				miGlobalizeTestedZones.IsChecked = pGlobalizeTestedZones;
				if(ChartControl != null){
					var zones = Zones.Where(k=>k.Value.Status == 'T');
					if(zones!=null){
						foreach(var z in zones){
							if(!pGlobalizeTestedZones) RemoveDrawObject(z.Value.Tag);
							else DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin || pZoneCalcMode==ARC_Uni_Zones_ZoneCalcModes.PriceAction ? z.Key:z.Value.ConfirmedABar);
						}
					}
				}
				ForceRefresh();
			};
			MenuControl.Items.Add(miGlobalizeTestedZones);
			#endregion
			#region -- GlobalizeBrokenZones switch --
			miGlobalizeBrokenZones      = new MenuItem { Header = "Globalize Broken Zones", Name = "pGlobalizeBrokenZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pGlobalizeBrokenZones, StaysOpenOnClick = true };
			miGlobalizeBrokenZones.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pGlobalizeBrokenZones = !this.pGlobalizeBrokenZones;
				miGlobalizeBrokenZones.IsChecked = pGlobalizeBrokenZones;
				if(ChartControl != null){
					var zones = Zones.Where(k=>k.Value.Status == 'B');
					if(zones!=null){
						foreach(var z in zones){
							if(!pGlobalizeBrokenZones) RemoveDrawObject(z.Value.Tag);
							else DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin || pZoneCalcMode==ARC_Uni_Zones_ZoneCalcModes.PriceAction ? z.Key:z.Value.ConfirmedABar);
						}
					}
				}
				ForceRefresh();
			};
			MenuControl.Items.Add(miGlobalizeBrokenZones);
			#endregion
			#region -- GlobalizeDeadZones switch --
			if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure){
				miGlobalizeDeadZones      = new MenuItem { Header = "Globalize Dead Zones", Name = "pGlobalizeDeadZones"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pGlobalizeDeadZones, StaysOpenOnClick = true };
				miGlobalizeDeadZones.Click += delegate (object o, RoutedEventArgs e)
				{
					this.pGlobalizeDeadZones = !this.pGlobalizeDeadZones;
					miGlobalizeDeadZones.IsChecked = pGlobalizeDeadZones;
					if(ChartControl != null){
						var zones = Zones.Where(k=>k.Value.Status == 'D');
						if(zones!=null){
							foreach(var z in zones){
								if(!pGlobalizeDeadZones) RemoveDrawObject(z.Value.Tag);
								else DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin || pZoneCalcMode==ARC_Uni_Zones_ZoneCalcModes.PriceAction ? z.Key:z.Value.ConfirmedABar);
							}
						}
					}
					ForceRefresh();
				};
				MenuControl.Items.Add(miGlobalizeDeadZones);
			}
			#endregion

			#region -- Delete all global zone objects --
			miDelAllGlobals      = new MenuItem { Header = "Delete globals", Name = "DelAllGlobals"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false,    StaysOpenOnClick = true };
			miDelAllGlobals.Click += delegate (object o, RoutedEventArgs e)
			{
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						foreach(var z in Zones) RemoveDrawObject(z.Value.Tag);
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							foreach(var z in Zones) RemoveDrawObject(z.Value.Tag);
						}));
					}
					this.pGlobalizeFreshZones = false;
					miGlobalizeFreshZones.IsChecked = false;
					this.pGlobalizeTestedZones = false;
					miGlobalizeTestedZones.IsChecked = false;
					this.pGlobalizeBrokenZones = false;
					miGlobalizeBrokenZones.IsChecked = false;
					this.pGlobalizeDeadZones = false;
					if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure){
						miGlobalizeDeadZones.IsChecked = false;
					}
					ForceRefresh();
				}
			};
			MenuControl.Items.Add(miDelAllGlobals);
			#endregion
#endif

			indytoolbar.Children.Add(MenuControlContainer);
		}
	#endregion

		#region Recalculate methods
//=====================================================================================================
		private void InformUserAboutRecalculation(){
			if(ChartControl != null){
				if (ChartControl.Dispatcher.CheckAccess()) {
					miRecalculate1.Background = Brushes.Yellow;
					miRecalculate1.FontWeight = FontWeights.Bold;
					miRecalculate1.FontStyle  = FontStyles.Italic;
				}else{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						miRecalculate1.Background = Brushes.Yellow;
						miRecalculate1.FontWeight = FontWeights.Bold;
						miRecalculate1.FontStyle  = FontStyles.Italic;
					}));
				}
			}
		}
		private void ResetRecalculationUI(){
			if(ChartControl != null){
				if (ChartControl.Dispatcher.CheckAccess()) {
					miRecalculate1.FontWeight = FontWeights.Normal;
					miRecalculate1.FontStyle  = FontStyles.Normal;
					miRecalculate1.Background = null;
				}else{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						miRecalculate1.FontWeight = FontWeights.Normal;
						miRecalculate1.FontStyle  = FontStyles.Normal;
						miRecalculate1.Background = null;
					}));
				}
			}
		}
		#endregion
 
		#region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}
		#endregion
        #region private void menuTxtbox_KeyDownInteger()
        private void menuTxtbox_KeyDownInteger(object sender, System.Windows.Input.KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtBoxSender = sender as TextBox;
			int max = int.MaxValue;
			int min = 0;
			string startval = txtBoxSender.Text;

//PrintDebug("      max: "+max+"  min: "+min);
			try{
	            int keyVal = (int)e.Key;
	            int value = -1;
	            if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
					value = keyVal - (int)System.Windows.Input.Key.D0;
	            else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
					value = keyVal - (int)System.Windows.Input.Key.NumPad0;

	            bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);

//PrintDebug("IsNumberic: "+isNumeric.ToString());

				if (isNumeric || e.Key == System.Windows.Input.Key.Back)
    	        {
	                string newText    = value != -1 ? value.ToString() : "";
    	            int tbPosition    = txtBoxSender.SelectionStart;
        	        txtBoxSender.Text = txtBoxSender.SelectedText == "" ? txtBoxSender.Text.Insert(tbPosition, newText) : txtBoxSender.Text.Replace(txtBoxSender.SelectedText, newText);
            	    txtBoxSender.Select(tbPosition + 1, 0);
					int x = string.IsNullOrEmpty(txtBoxSender.Text.Trim()) ? min : Convert.ToInt32(txtBoxSender.Text);
					x = Math.Max(min, Math.Min(max,x));
					txtBoxSender.Text = x.ToString();
//PrintDebug("     text: "+txtBoxSender.Text);
				}
			}catch{
				txtBoxSender.Text = startval;
            }
        }
        #endregion
        #region private void menuTxtbox_KeyDownDouble()
        private void menuTxtbox_KeyDownDouble(object sender, System.Windows.Input.KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtBoxSender = sender as TextBox;
			double max = double.MaxValue;
			double min = 0;
			string startval = txtBoxSender.Text;

//PrintDebug("      max: "+max+"  min: "+min);
			try{
	            int keyVal = (int)e.Key;
	            double value = -1;
	            if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
					value = keyVal - (int)System.Windows.Input.Key.D0;
	            else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
					value = keyVal - (int)System.Windows.Input.Key.NumPad0;

	            bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);

//PrintDebug("IsNumeric: "+isNumeric.ToString()+"  e.Key: "+e.Key.ToString());

				if (isNumeric || e.Key == System.Windows.Input.Key.OemPeriod || e.Key == System.Windows.Input.Key.Back)
    	        {
	                string newText    = e.Key == System.Windows.Input.Key.OemPeriod ? "." : (value != -1 ? value.ToString() : "");
//    	            int tbPosition    = txtBoxSender.SelectionStart;
//        	        txtBoxSender.Text = txtBoxSender.SelectedText == "" ? txtBoxSender.Text.Insert(tbPosition, newText) : txtBoxSender.Text.Replace(txtBoxSender.SelectedText, newText);
//            	    txtBoxSender.Select(tbPosition + 1, 0);
					double x = string.IsNullOrEmpty(txtBoxSender.Text.Trim()) ? min : Convert.ToDouble(txtBoxSender.Text);
//					x = Math.Max(min, Math.Min(max,x));
//					txtBoxSender.Text = x.ToString();
//PrintDebug("     text: "+txtBoxSender.Text);
				}
			}catch{
				txtBoxSender.Text = startval;
            }
        }
        #endregion
        //public override string DisplayName { get { return "ARC_PA Zones"; } }
		private double MaxBodyPct = 0;
		private Brush basingUpbrush;
		private Brush basingDownbrush;
		private Brush thrustUpbrush;
		private Brush thrustDownbrush;
		private Brush orderblockUpbrush;
		private Brush orderblockDownbrush;
		private void PrintDebug(string s){if(IsDebug && inzone)Print(s);}
//=====================================================================================================
		protected override void OnStateChange()
		{
			#region -- OnStateChange --
			if (State == State.SetDefaults)
			{
				Description					= "";
				Name						= "ARC_Uni Zones";
				IsSuspendedWhileInactive	= false;
				Calculate			= Calculate.OnPriceChange;
				IsAutoScale         = false;
				IsOverlay           = true;
				BarsRequiredToPlot	= 20;
				SetZOrder(-9999);

				pZoneCalcMode = ARC_Uni_Zones_ZoneCalcModes.Structure;
				pBasingZoneSizeBasis = ARC_Uni_Zones_BasingZoneSizeBasis.FullBase;
				pShowOrderblockZones = false;

				pShowTrapZones = false;
				pGapTicksMin		= 8;
				pGapTicksMax		= 50;
				pGapMinATRMultiple	= 0.5;
				pGapMaxATRMultiple	= 3.5;
				pATRPeriod			= 14;
				pGapMeasurement		= ARC_Uni_Zones_GapMeasurements.ATR;

                #region Swing Parameters 
                pSwingStrength     = 3;
                pMultiplierMD      = 0.0;
                pMultiplierDTB     = 0.0;
                pShowZigzagLegs    = true;
                pSwingLegWidth     = 2;
				pRisingZZlegBrush  = Brushes.Black;
				pFallingZZlegBrush = Brushes.Black;
				pThisInputType = ARC_Uni_Zones_InputType.High_Low;
                #endregion
				pMaxBodyPct				= 50;
				pBasingBarUpBrush		= Brushes.White;
				pBasingBarUpOpacity		= 50;
				pBasingBarDownBrush		= Brushes.White;
				pBasingBarDownOpacity	= 50;
				pThrustBarUpBrush		= Brushes.Lime;
				pThrustBarUpOpacity		= 90;
				pThrustBarDownBrush		= Brushes.Red;
				pThrustBarDownOpacity	= 90;
				pOrderblockBarUpBrush		= Brushes.Lime;
				pOrderblockBarUpOpacity		= 90;
				pOrderblockBarDownBrush		= Brushes.Red;
				pOrderblockBarDownOpacity	= 90;
				pThrustBarsDelay = 0; //added v1.21 - additional number of inside bars permitted between OrderBlock basing bar and thrust bar
				#region -- Zones --
				pShowFreshZones    = true;
				pShowTestedZones   = true;
				pShowBrokenZones   = true;
				pShowDeadZones     = false;
				pTerminateOnBroken = false;

				pFreshSup_Brush        = Brushes.Lime;
				pFreshSup_Opacity      = 50;
				pFreshSupOutline_Brush = Brushes.Black;
				pFreshSupOutline_Width = 1;
				pFreshRes_Brush        = Brushes.Red;
				pFreshRes_Opacity      = 50;
				pFreshResOutline_Brush = Brushes.Black;
				pFreshResOutline_Width = 1;
				pTestedSup_Brush       = Brushes.Green;
				pTestedSup_Opacity     = 20;
				pTestedSupOutline_Brush = Brushes.Black;
				pTestedSupOutline_Width = 1;
				pTestedRes_Brush        = Brushes.Maroon;
				pTestedRes_Opacity      = 25;
				pTestedResOutline_Brush = Brushes.Black;
				pTestedResOutline_Width = 1;
				pBrokenSup_Brush        = Brushes.Cyan;
				pBrokenSup_Opacity      = 25;
				pBrokenSupOutline_Brush = Brushes.Black;
				pBrokenSupOutline_Width = 1;
				pBrokenRes_Brush        = Brushes.LightCoral;
				pBrokenRes_Opacity      = 25;
				pBrokenResOutline_Brush = Brushes.Black;
				pBrokenResOutline_Width = 1;
				pDeadSup_Brush          = Brushes.Black;
				pDeadSup_Opacity        = 20;
				pDeadSupOutline_Brush   = Brushes.Black;
				pDeadSupOutline_Width   = 1;
				pDeadRes_Brush          = Brushes.Black;
				pDeadRes_Opacity        = 35;
				pDeadResOutline_Brush   = Brushes.Black;
				pDeadResOutline_Width   = 1;

				pMaxDaysAgo = 3;
				pCreationBasis         = ARC_Uni_Zones_BarBasis.Full;
				pCreationDistanceBasis = ARC_Uni_Zones_DistanceBasis.TickDistance;
				this.pTicksZoneCreation    = 0;
				this.pATRmultZoneCreation  = 0;
				pBreakBasis         = ARC_Uni_Zones_BarBasis.Full;
				pBreakDistanceBasis = ARC_Uni_Zones_DistanceBasis.TickDistance;
				this.pTicksZoneBreak    = 0;
				this.pATRmultZoneBreak  = 0;

#if INCLUDE_GLOBALIZATION
				pFreshResistanceRectangleTemplate  = "Default";
				pFreshSupportRectangleTemplate     = "Default";
				pTestedResistanceRectangleTemplate = "Default";
				pTestedSupportRectangleTemplate    = "Default";
				pBrokenResistanceRectangleTemplate = "Default";
				pBrokenSupportRectangleTemplate    = "Default";
				pDeadResistanceRectangleTemplate   = "Default";
				pDeadSupportRectangleTemplate      = "Default";
#endif
				pSuppResBoth            = ARC_Uni_Zones_SuppResBoth.Both;
				pOverlapBasis			= ARC_Uni_Zones_OverlapBasis.NoOverlaps;
				pEntryPriceBasis        = ARC_Uni_Zones_EntryPriceBasis.PivotBarClose;
				pOffsetAdjustmentTicks  = 0;
				#endregion

			}
			else if (State == State.Configure)
			{
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion

				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");
				if(Calculate==Calculate.OnEachTick) Calculate = Calculate.OnPriceChange;
                useHL = pThisInputType == ARC_Uni_Zones_InputType.High_Low;
			}
			else if (State == State.DataLoaded)
			{
				atr = ATR(Closes[0], 14);
				atrTraps = ATR(Closes[0], pATRPeriod);

				swingInput         = new Series<double>(this);
				pre_swingHighType  = new Series<int>(this);
				pre_swingLowType   = new Series<int>(this);
				upTrend            = new Series<bool>(this);
				structureBiasState = new Series<double>(this, MaximumBarsLookBack.Infinite);//#STRBIAS
				avgTrueRange = ATR(256);
				minpts_Traps = pGapTicksMin*TickSize;
				maxpts_Traps = pGapTicksMax*TickSize;

				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
//				if(ChartPanel!=null && IsDebug){
//					ChartPanel.MouseMove  += OnMouseMove;
//					ChartPanel.MouseUp    += OnMouseUp;
//				}
				#region -- Add Custom Toolbar --
				if (!isToolBarButtonAdded && ChartControl != null)
				{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						ChartControl.AllowDrop = false;
						chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
						if (chartWindow == null) return;

						foreach (DependencyObject item in chartWindow.MainMenu) if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

						if (!isToolBarButtonAdded)
						{
							indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

							addToolBar();

							chartWindow.MainMenu.Add(indytoolbar);
							chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

							foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
							System.Windows.Automation.AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
						}
					}));
				}
				#endregion
				MaxBodyPct  = pMaxBodyPct/100.0;
				orderblockUpbrush = pOrderblockBarUpBrush.Clone();
				orderblockUpbrush.Opacity = pOrderblockBarUpOpacity/100.0;
				orderblockUpbrush.Freeze();
				orderblockDownbrush = pOrderblockBarDownBrush.Clone();
				orderblockDownbrush.Opacity = pOrderblockBarDownOpacity/100.0;
				orderblockDownbrush.Freeze();

				thrustUpbrush = pThrustBarUpBrush.Clone();
				thrustUpbrush.Opacity = pThrustBarUpOpacity/100.0;
				thrustUpbrush.Freeze();
				thrustDownbrush = pThrustBarDownBrush.Clone();
				thrustDownbrush.Opacity = pThrustBarDownOpacity/100.0;
				thrustDownbrush.Freeze();

				basingUpbrush = pBasingBarUpBrush.Clone();
				basingUpbrush.Opacity = pBasingBarUpOpacity/100.0;
				basingUpbrush.Freeze();
				basingDownbrush = pBasingBarDownBrush.Clone();
				basingDownbrush.Opacity = pBasingBarDownOpacity/100.0;
				basingDownbrush.Freeze();

			}else if(State == State.Realtime){
#if INCLUDE_GLOBALIZATION
				if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure){
					foreach(var z in Zones){
						if(     z.Value.Status=='F' && pGlobalizeFreshZones)  DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin ? z.Key:z.Value.ConfirmedABar);
						else if(z.Value.Status=='T' && pGlobalizeTestedZones) DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin ? z.Key:z.Value.ConfirmedABar);
						else if(z.Value.Status=='B' && pGlobalizeBrokenZones) DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin ? z.Key:z.Value.ConfirmedABar);
						else if(z.Value.Status=='D' && pGlobalizeDeadZones)   DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin ? z.Key:z.Value.ConfirmedABar);
					}
				}
				else if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction){
					foreach(var z in Zones){
						if(     z.Value.Status=='F' && pGlobalizeFreshZones)  DrawGlobalZone(z.Value, z.Key);
						else if(z.Value.Status=='T' && pGlobalizeTestedZones) DrawGlobalZone(z.Value, z.Key);
						else if(z.Value.Status=='B' && pGlobalizeBrokenZones) DrawGlobalZone(z.Value, z.Key);
						else if(z.Value.Status=='D' && pGlobalizeDeadZones)   DrawGlobalZone(z.Value, z.Key);
					}
				}
#endif
			}else if(State == State.Terminated){
//				if(ChartPanel!=null && IsDebug){
//					ChartPanel.MouseMove -= OnMouseMove;
//					ChartPanel.MouseUp -= OnMouseUp;
//				}
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
			}
			#endregion
		}
//===================       ==============================================================

		private bool useHL = true;
		int line = 0;
		private List<Tuple<int,double>> SwingHighABars = new List<Tuple<int,double>>(){new Tuple<int,double>(0,0)};//new nodes are added at the 0 element
		private List<Tuple<int,double>> SwingLowABars  = new List<Tuple<int,double>>(){new Tuple<int,double>(0,0)};//new nodes are added at the 0 element
		private List<Tuple<int,byte>> NodeTypes        = new List<Tuple<int,byte>>();//1 = HH, 2 = LL, 3 = HL, 4 = LH
        private bool drawHigherHighLabel   = false;
        private bool drawLowerHighLabel    = false;
        private bool drawDoubleTopLabel    = false;
        private bool drawLowerLowLabel     = false;
        private bool drawHigherLowLabel    = false;
        private bool drawDoubleBottomLabel = false;
		private DateTime now                = DateTime.MinValue;
		private DateTime PriorDTnow         = DateTime.MinValue;
		private List<string> TagsDrawn      = new List<string>();
		private List<DateTime> DaysOnChart  = new List<DateTime>();
		private ATR atr, atrTraps;
		private double atrval = 0;
		private double minpts_Traps = 0;
		private double maxpts_Traps = 0;
	
		private class Zone{
			public double ConfirmationPrice = double.MinValue;
			public double TopPrice   = 0;
			public double BotPrice   = 0;
			public double BreakPrice = 0;
			public double DeadPrice  = 0;
			public bool DeadEnabled  = false;//once a zone is broken, and price clears out of the zone, that zone is now a candidate to "die"...price must retrace and break the opposite side of the zone to become "Dead"
//			public int BirthABar     = -1;//abar when zone first became a possible zone
			public int ConfirmedABar = -1;//abar when zone was confirmed by a full breakout of the support/resistance level, or in PriceAction mode, this is the Thrust bar
			public int TestedABar    = -1;
			public int BrokenABar    = -1;
			public int EndABar = -1;
			public char Type   = ' '; //S for support or R for resistance
			public char Status = 'F';//Fresh, Tested, Broken, Dead
			public string Tag  = "";
			public Zone(char type, int birthabar, double topPrice, double botPrice){
				Type=type; TopPrice=topPrice; BotPrice=botPrice;
//				BirthABar = birthabar;//current bar at the time the zone was identified by a structure break
				//if(type=='R') DeadPrice = botPrice; else DeadPrice = topPrice;
			}
			public Zone(Zone unconfirmed){
				ConfirmationPrice = unconfirmed.ConfirmationPrice;
				TopPrice = unconfirmed.TopPrice;
				BotPrice = unconfirmed.BotPrice;
				BreakPrice = unconfirmed.BreakPrice;
				DeadPrice = unconfirmed.DeadPrice;
				DeadEnabled = unconfirmed.DeadEnabled;
//				BirthABar = unconfirmed.BirthABar;
				ConfirmedABar = unconfirmed.ConfirmedABar;
				TestedABar = unconfirmed.TestedABar;
				BrokenABar = unconfirmed.BrokenABar;
				EndABar = unconfirmed.EndABar;
				Type = unconfirmed.Type;
				Status = unconfirmed.Status;
				Tag = unconfirmed.Tag;
			}
		}
		private SortedDictionary<int,Zone> UnconfirmedZones = new SortedDictionary<int,Zone>();
		private SortedDictionary<int,Zone> Zones = new SortedDictionary<int,Zone>();
//=====================================================================================================================
		private void CalculateZonesBreakAndDeadPrices(Zone z, ARC_Uni_Zones_DistanceBasis basis, double TickDistPts, double AtrDistPts, bool PrintIt=false){
			if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction) {TickDistPts = 0; AtrDistPts = 0;}
//if(inzone)Print("CalculateZonesBreakAndDeadPrices: "+z.Tag+"   top: "+z.TopPrice+" bot: "+z.BotPrice);
			#region -- CalculateZonesBreakAndDeadPrices --
			if(z.Type == 'R'){
				if(basis == ARC_Uni_Zones_DistanceBasis.TickDistance){
					z.BreakPrice = z.TopPrice + TickDistPts;
					z.DeadPrice  = z.BotPrice - TickDistPts;
				}else if(basis == ARC_Uni_Zones_DistanceBasis.ATRmultiple){
					z.BreakPrice = z.TopPrice + AtrDistPts;
					z.DeadPrice  = z.BotPrice - AtrDistPts;
				}
			}else if(z.Type == 'S'){
				if(basis == ARC_Uni_Zones_DistanceBasis.TickDistance){
					z.BreakPrice = z.BotPrice - TickDistPts;
					z.DeadPrice  = z.TopPrice + TickDistPts;
				}else if(basis == ARC_Uni_Zones_DistanceBasis.ATRmultiple){
					z.BreakPrice = z.BotPrice - AtrDistPts;
					z.DeadPrice  = z.TopPrice + AtrDistPts;
				}
			}
			#endregion
		}
//=====================================================================================================================
		private bool CheckForZoneBreak(ARC_Uni_Zones_BarBasis basis, Zone z, double H, double L, double C){
			#region -- CheckForZoneBreak --
			if(z.Status=='B' || z.Status=='D' || CurrentBars[0]<z.ConfirmedABar) return false;
			bool result = false;
			if(z.Type=='R'){
				if(basis == ARC_Uni_Zones_BarBasis.Partial || pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction)
					result = H > z.BreakPrice;
				else if(basis == ARC_Uni_Zones_BarBasis.Full)
					result = L > z.BreakPrice;
				else if(basis == ARC_Uni_Zones_BarBasis.BarClose)
					result = C > z.BreakPrice;
			}else if(z.Type=='S'){
				if(basis == ARC_Uni_Zones_BarBasis.Partial || pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction)
					result = L < z.BreakPrice;
				else if(basis == ARC_Uni_Zones_BarBasis.Full)
					result = H < z.BreakPrice;
				else if(basis == ARC_Uni_Zones_BarBasis.BarClose)
					result = C < z.BreakPrice;
			}
			return result;
			#endregion
		}
//=====================================================================================================================
		private bool CheckForDeadBreak(ARC_Uni_Zones_BarBasis basis, Zone z, double H, double L, double C){
			#region -- CheckForDeadBreak --
			if(pZoneCalcMode==ARC_Uni_Zones_ZoneCalcModes.PriceAction && z.Status=='B') return true;
			if(pTerminateOnBroken && z.Status=='B') return true;
			if(z.DeadEnabled && z.Status=='D') return false;
			bool result = false;
			if(z.Type=='R'){
				if(basis == ARC_Uni_Zones_BarBasis.Full)
					result = Highs[0][0] < z.DeadPrice;
				else if(basis == ARC_Uni_Zones_BarBasis.Partial)
					result = Lows[0][0] < z.DeadPrice;
			}else if(z.Type=='S'){
				if(basis == ARC_Uni_Zones_BarBasis.Full)
					result = Lows[0][0] > z.DeadPrice;
				else if(basis == ARC_Uni_Zones_BarBasis.Partial)
					result = Highs[0][0] > z.DeadPrice;
			}
			return result;
			#endregion
		}
//=====================================================================================================================
		private double Rnd2Tick(double p){
			return Instrument.MasterInstrument.RoundToTickSize(p);
		}
//=====================================================================================================================
		DateTime dd = new DateTime(2023, 7,13,13,0,0);
		DateTime dd1 = new DateTime(2023, 7,13,14,0,0);
		private bool CreateIfNotOverlapping(string zoneAlgo, SortedDictionary<int,Zone> Z, int abar, int rbar, int birthbar, double HighLevel, double LowLevel, char Type){
			#region -- CreateIfNotOverlapping --
			bool exit_with_false=true;//this will return from this method if the zone is attempting to print on the first bar of the session
//if(IsDebug && (Times[0].GetValueAt(abar)<dd || Times[0].GetValueAt(abar)>dd1)) return false;
//if(IsDebug && (Times[0].GetValueAt(abar)<dd || Times[0].GetValueAt(abar)>dd1)) return false;
			if(HighLevel<=LowLevel) return false;//if the user has a large negative pOffsetAdjustmentTicks, then a zone levels might become inverted, and in that case, do not create the zone
			if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.ShowAll){
				//if(Bars.IsFirstBarOfSessionByIndex(abar+1)) {if(IsDebug)BackBrushes[0]=Brushes.Yellow;  if(exit_with_false)return false;}
				if(UnconfirmedZones.ContainsKey(abar)){
					Z[abar] = new Zone(UnconfirmedZones[abar]);
if(IsDebug)Print(Times[0][0].ToString()+"  "+abar+" new zone confirmed zone");
				}else{
					Z[abar] = new Zone(Type, birthbar, HighLevel, LowLevel);
if(IsDebug)Print(Times[0][0].ToString()+"  "+abar+" new zone unconfirmed zone");
				}
				return true;
			}else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.NoOverlaps){
				if(Bars.IsFirstBarOfSessionByIndex(abar+1)) {if(IsDebug)BackBrushes[0]=Brushes.Yellow;  if(exit_with_false)return false;}
				var count = Zones.Count(k=>k.Value.EndABar<=0 
					&& (   (k.Value.TopPrice <= HighLevel && k.Value.TopPrice >= LowLevel)
						|| (k.Value.BotPrice <= HighLevel && k.Value.BotPrice >= LowLevel)
						|| (k.Value.TopPrice >= HighLevel && k.Value.BotPrice <= LowLevel)
					));
				if(count==null || count==0){
					if(UnconfirmedZones.ContainsKey(abar)){
						Z[abar] = new Zone(UnconfirmedZones[abar]);
if(IsDebug)Print(Times[0][0].ToString()+"  "+abar+" new zone confirmed zone");
					}else{
						Z[abar] = new Zone(Type, birthbar, HighLevel, LowLevel);
if(IsDebug)Print(Times[0][0].ToString()+"  "+abar+" new zone unconfirmed zone");
					}
					return true;
				}//else Print("Overlapping zone found "+Times[0][0].ToString());
			}else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.Replacements){
				if(Bars.IsFirstBarOfSessionByIndex(abar+1)) {if(IsDebug)BackBrushes[0]=Brushes.Yellow;  if(exit_with_false)return false;}
				#region this code is for terminating a zone when it overlaps a new zone
				List<int> keys = Z.Where(k=>k.Value.EndABar<=0  //'zones' list is the candidate zones that overlap in price
					&& (   (k.Value.TopPrice <= HighLevel && k.Value.TopPrice >= LowLevel)
						|| (k.Value.BotPrice <= HighLevel && k.Value.BotPrice >= LowLevel)
						|| (k.Value.TopPrice >= HighLevel && k.Value.BotPrice <= LowLevel)
					)).Select(k=>k.Key).ToList();
				try{
				foreach(var z in keys){
					try{
						Z[z].Status = 'D';
						Z[z].EndABar = abar;
					}catch(Exception ee){Print("line: "+line+"  "+ee.ToString());}
				}
				}catch(Exception xe){Print("line: "+line+"  "+xe.ToString());}
				Z[abar] = new Zone(Type, birthbar, HighLevel, LowLevel);
				Z[abar].Tag = string.Format("{2}UniZone{0} {1}", abar, Type, zoneAlgo);
				return true;
				#endregion
			}else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.ShortBias){
				if(Bars.IsFirstBarOfSessionByIndex(abar+1)) {if(IsDebug)BackBrushes[0]=Brushes.Yellow;  if(exit_with_false)return false;}
				List<Zone> zones = Zones.Where(k=>k.Value.EndABar<=0  //'zones' list is the candidate zones that overlap in price
					&& (   (k.Value.TopPrice <= HighLevel && k.Value.TopPrice >= LowLevel)
						|| (k.Value.BotPrice <= HighLevel && k.Value.BotPrice >= LowLevel)
						|| (k.Value.TopPrice >= HighLevel && k.Value.BotPrice <= LowLevel)
					)).Select(k=>k.Value).ToList();
				if(zones == null || zones.Count==0){
					if(UnconfirmedZones.ContainsKey(abar))
						Z[abar] = new Zone(UnconfirmedZones[abar]);
					else
						Z[abar] = new Zone(Type, birthbar, HighLevel, LowLevel);
					return true;
				}else{
					if(Type == 'S') return false;//in short bias, new Support zones cannot overlap any zones
					foreach(var z in zones){
						if(Type == 'R' && z.Type=='S' && z.Status == 'T'){//if the new zone is Resistance, and we find an overlapping T Support zone, then this new zone is overlapping and it's not drawn
							return false;
						}
						//otherwise, if the new zone is Resistance, and we find an overlapping Broken or Dead Support zone, then this new zone is printed
						if(UnconfirmedZones.ContainsKey(abar))
							Z[abar] = new Zone(UnconfirmedZones[abar]);
						else
							Z[abar] = new Zone(Type, birthbar, HighLevel, LowLevel);
						return true;
					}
				}
			}else if(pOverlapBasis == ARC_Uni_Zones_OverlapBasis.LongBias){
				if(Bars.IsFirstBarOfSessionByIndex(abar+1)) {if(IsDebug)BackBrushes[0]=Brushes.Yellow;  if(exit_with_false)return false;}
				List<Zone> zones = Zones.Where(k=>k.Value.EndABar<=0 //'zones' list is the candidate zones that overlap in price
					&& (   (k.Value.TopPrice <= HighLevel && k.Value.TopPrice >= LowLevel)
						|| (k.Value.BotPrice <= HighLevel && k.Value.BotPrice >= LowLevel)
						|| (k.Value.TopPrice >= HighLevel && k.Value.BotPrice <= LowLevel)
					)).Select(k=>k.Value).ToList();
				if(zones == null || zones.Count==0){
					if(UnconfirmedZones.ContainsKey(abar))
						Z[abar] = new Zone(UnconfirmedZones[abar]);
					else
						Z[abar] = new Zone(Type, birthbar, HighLevel, LowLevel);
					return true;
				}else{
					if(Type == 'R') return false;//in long bias, new Resistance zones cannot overlap any zones
					foreach(var z in zones){
						if(Type == 'S' && z.Type=='R' && z.Status == 'T'){//if the new zone is Support, and we find an overlapping T Resistance zone, then this new zone is overlapping and it's not drawn
							return false;
						}
						//otherwise, if the new zone is Support, and we find an overlapping Broken or Dead Resistance zone, then this new zone is printed
						if(UnconfirmedZones.ContainsKey(abar))
							Z[abar] = new Zone(UnconfirmedZones[abar]);
						else
							Z[abar] = new Zone(Type, birthbar, HighLevel, LowLevel);
						return true;
					}
				}
			}
			#endregion
			return false;
		}
		private void CalcHighAndLowLevelsBasedOnEntryPriceBasis(char Type, ref double HighLevel, ref double LowLevel, double CurrentOpen, double CurrentHigh, double CurrentLow, double CurrentClose, double PriorOpen, int OffsetAdjustmentTicks){
			#region -- CalcHighAndLowLevelsBasedOnEntryPriceBasis --
			if(Type == 'R'){
				switch(pEntryPriceBasis){
					case ARC_Uni_Zones_EntryPriceBasis.OpenOfPriorBar:	LowLevel = PriorOpen;	 break;
					case ARC_Uni_Zones_EntryPriceBasis.PivotBarOpen:	LowLevel = CurrentOpen;  break;
					case ARC_Uni_Zones_EntryPriceBasis.PivotBarClose:	LowLevel = CurrentClose; break;
					case ARC_Uni_Zones_EntryPriceBasis.FullBar:			LowLevel = CurrentLow;   break;
				}
				if(OffsetAdjustmentTicks!=0) LowLevel = LowLevel - OffsetAdjustmentTicks*TickSize;
			}
			else if(Type == 'S'){
				switch(pEntryPriceBasis){
					case ARC_Uni_Zones_EntryPriceBasis.OpenOfPriorBar:	HighLevel = PriorOpen;	  break;
					case ARC_Uni_Zones_EntryPriceBasis.PivotBarOpen:	HighLevel = CurrentOpen;  break;
					case ARC_Uni_Zones_EntryPriceBasis.PivotBarClose:	HighLevel = CurrentClose; break;
					case ARC_Uni_Zones_EntryPriceBasis.FullBar:			HighLevel = CurrentHigh;  break;
				}
				if(OffsetAdjustmentTicks!=0) HighLevel = HighLevel + OffsetAdjustmentTicks*TickSize;
			}
			#endregion
		}
		private double CalculateZoneCreationBufferSize(double TickdistZoneCreation, double ATRdistZoneCreation){
			if(this.pCreationDistanceBasis == ARC_Uni_Zones_DistanceBasis.TickDistance) return TickdistZoneCreation;
			else return ATRdistZoneCreation;
		}
//=====================================================================================================================
		bool inzone        = false;
		bool IsEntryBar    = false;
		int LastSignalABar = 0;
		int FirstPermittedABar = 0;
		private List<int> BasingBarsList = new List<int>();
		int OrderblockZoneABar = -1;
		protected override void OnBarUpdate()
		{
try{
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
//			if(pEnableSession1 && ParameterError) return;
if(IsDebug){
	inzone = Times[0][0] > dd && Times[0][0] < dd1;
}

			if(CurrentBars[0]<6) return;
			atrval = atr[0];
line=1108;
			if(BarsInProgress == 0){
				if(!DaysOnChart.Contains(Times[0][0].Date)) {
					DaysOnChart.Insert(0,Times[0][0].Date);
				}
				if(CurrentBars[0] >= BarsArray[0].Count-2 && DaysOnChart.Count > pMaxDaysAgo){
					var FirstPermittedDate = DaysOnChart[Math.Min(this.pMaxDaysAgo,DaysOnChart.Count-1)];
					//FirstPermittedDate = new DateTime(FirstPermittedDate.Year, FirstPermittedDate.Month, FirstPermittedDate.Day, Times[0][0].Hour, Times[0][0].Minute, Times[0][0].Second);
					FirstPermittedABar = BarsArray[0].GetBar(FirstPermittedDate);
					var keys = Zones.Keys.Where(k=>k < FirstPermittedABar).ToList();
					foreach(var k in keys) Zones.Remove(k);//removing all zones that started prior to the first permitted date
					ForceRefresh();
					DaysOnChart.Clear();
				}
	            #region --- Calculate and Draw ZigZag + Intrabar Structure BIAS ---
	            if (pThisInputType == ARC_Uni_Zones_InputType.High_Low)
	                swingInput[0] = Input[0];
	            else if (pThisInputType == ARC_Uni_Zones_InputType.Close)
	                swingInput[0] = Closes[0][0];

line=1515;
	            #region -- Init zigzag states --    
	            if (CurrentBar < 2)
	            {
	                upTrend[0] = true;
	                pre_swingHighType[0] = 0;
	                pre_swingLowType[0] = 0;
	            }
	            #endregion

	            #region else if (Calculate == Calculate.OnBarClose)
	            else if (Calculate == Calculate.OnBarClose)
	            {
	                zigzagDeviation = pMultiplierMD * avgTrueRange[0];
	                swingMax = MAX(useHL ? Highs[0] : Input, pSwingStrength)[1];
	                swingMin = MIN(useHL ? Lows[0]  : Input, pSwingStrength)[1];

	                pre_swingHighType[0] = 0;
	                pre_swingLowType[0]  = 0;
	                //swingHighType[0] = 0;
	                //swingLowType[0]  = 0;

	                updateHigh =  upTrend[1] &&   (useHL ? Highs[0][0] : swingInput[0]) > currentHigh;
	                updateLow  = !upTrend[1] &&   (useHL ? Lows[0][0]  : swingInput[0]) < currentLow;
	                addHigh    = !upTrend[1] && !((useHL ? Lows[0][0]  : swingInput[0]) < currentLow)  && (useHL ? Highs[0][0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
	                addLow     =  upTrend[1] && !((useHL ? Highs[0][0] : swingInput[0]) > currentHigh) && (useHL ? Lows[0][0]  : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

	                upTrend[0] = upTrend[1];
line=1144;

	                #region -- New High --
	                if (addHigh)
	                {
	                    upTrend[0] = true;
//	                    int lookback = CurrentBar - lastLowIdx;
	                    //swingLowType[lookback] = pre_swingLowType[lookback];
	                    double newHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - lastLowIdx; i++)
	                    {
	                        if ((useHL ? Highs[0][i] : swingInput[i]) > newHigh)
	                        {
	                            newHigh = (useHL ? Highs[0][i] : swingInput[i]);
	                            j = i;
	                        }
	                    }
						newHigh = Instrument.MasterInstrument.RoundToTickSize(newHigh);
	                    priorSwingHighIdx = lastHighIdx;
	                    lastHighIdx = CurrentBar - j;
						currentHigh = newHigh;
						SwingHighABars.Insert(0, new Tuple<int,double>(lastHighIdx, newHigh));
line=1166;
						byte swtype = HH;
						if(SwingHighABars.Count>1) swtype = newHigh > SwingHighABars[1].Item2 ? HH : LH;
						NodeTypes.Insert(0, new Tuple<int,byte>(lastHighIdx, swtype));
						int abar = SwingLowABars[0].Item1;
						bool IsUpClose = true;//Closes[0].GetValueAt(abar) > Opens[0].GetValueAt(abar);
						if(IsUpClose
								&& pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure
								&& abar>2
								&& swtype == HH
								&& !UnconfirmedZones.ContainsKey(abar)
								&& !Zones.ContainsKey(abar)
								&& pSuppResBoth != ARC_Uni_Zones_SuppResBoth.ResistanceOnly){
							int rbar = CurrentBars[0]-abar;
							double HighLevel = Rnd2Tick(Math.Max(Opens[0][rbar], Closes[0][rbar]));
							double LowLevel = Rnd2Tick(Lows[0][rbar]);
							CalcHighAndLowLevelsBasedOnEntryPriceBasis('S', ref HighLevel, ref LowLevel, Opens[0][rbar], Highs[0][rbar], Lows[0][rbar], Closes[0][rbar], Rnd2Tick(Opens[0][rbar+1]), pOffsetAdjustmentTicks); 
//if(IsDebug && (Times[0].GetValueAt(abar)<dd || Times[0].GetValueAt(abar)>dd1)) {
//	Draw.Diamond(this,"DDD"+abar.ToString(),false,0,(HighLevel+LowLevel)/2.0, Brushes.Yellow);
//	Draw.Diamond(this,"SHD"+abar.ToString(),false,0,SwingHighABars[1].Item2 , Brushes.Green);
//}
							bool ZoneCreated = CreateIfNotOverlapping("struct", UnconfirmedZones, abar, rbar, CurrentBars[0], HighLevel, LowLevel, 'S');
							if(ZoneCreated){
//	Draw.Diamond(this,"DDD"+abar.ToString(),false,0,(HighLevel+LowLevel)/2.0, Brushes.Yellow);
//	Draw.Diamond(this,"SHD"+abar.ToString(),false,0,SwingHighABars[1].Item2 , Brushes.Green);
								UnconfirmedZones[abar].ConfirmationPrice = SwingHighABars[1].Item2 + CalculateZoneCreationBufferSize(this.pTicksZoneCreation*TickSize, this.pATRmultZoneCreation*atrval);
								CalculateZonesBreakAndDeadPrices(UnconfirmedZones[abar], pBreakDistanceBasis, pTicksZoneBreak*TickSize, pATRmultZoneBreak*atrval);
								UnconfirmedZones[abar].Tag = string.Format("structUniZone{0} {1}", abar, 'S');
							}
						}
	                }
	                #endregion

	                #region -- uptrend --
	                else if (updateHigh)
	                {
	                    upTrend[0] = true;
	                    pre_swingHighType[CurrentBar - lastHighIdx] = 0;

						currentHigh = Instrument.MasterInstrument.RoundToTickSize(useHL ? Highs[0][0] : swingInput[0]);
	                    lastHighIdx = CurrentBar;
						SwingHighABars[0] = new Tuple<int,double>(lastHighIdx, currentHigh);

						byte swtype = HH;
						if(SwingHighABars.Count>1) swtype = currentHigh > SwingHighABars[1].Item2 ? HH : LH;
						if(NodeTypes.Count>0) NodeTypes[0] = new Tuple<int,byte>(lastHighIdx, swtype);
						int abar = SwingLowABars[0].Item1;
						bool IsUpClose = true;//Closes[0].GetValueAt(abar) > Opens[0].GetValueAt(abar);
						if(IsUpClose
								&& pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure
								&& abar>2
								&& swtype == HH
								&& !UnconfirmedZones.ContainsKey(abar)
								&& !Zones.ContainsKey(abar)
								&& pSuppResBoth != ARC_Uni_Zones_SuppResBoth.ResistanceOnly){
							int rbar = CurrentBars[0]-abar;
							double HighLevel = Rnd2Tick(Math.Max(Opens[0][rbar], Closes[0][rbar]));
							double LowLevel = Rnd2Tick(Lows[0][rbar]);
							CalcHighAndLowLevelsBasedOnEntryPriceBasis('S', ref HighLevel, ref LowLevel, Opens[0][rbar], Highs[0][rbar], Lows[0][rbar], Closes[0][rbar], Rnd2Tick(Opens[0][rbar+1]), pOffsetAdjustmentTicks); 
							bool ZoneCreated = CreateIfNotOverlapping("struct", UnconfirmedZones, abar, rbar, CurrentBars[0], HighLevel, LowLevel, 'S');
							if(ZoneCreated){
//	Draw.Diamond(this,"DDD"+abar.ToString(),false,0,(HighLevel+LowLevel)/2.0, Brushes.Yellow);
//	Draw.Diamond(this,"SHD"+abar.ToString(),false,0,SwingHighABars[1].Item2 , Brushes.Green);
								bool tf = UnconfirmedZones.ContainsKey(abar);
//								Print("Does UnconfirmedZones contain: "+abar+"?:   "+tf);
								UnconfirmedZones[abar].ConfirmationPrice = SwingHighABars[1].Item2 + CalculateZoneCreationBufferSize(this.pTicksZoneCreation*TickSize, this.pATRmultZoneCreation*atrval);
								CalculateZonesBreakAndDeadPrices(UnconfirmedZones[abar], pBreakDistanceBasis, pTicksZoneBreak*TickSize, pATRmultZoneBreak*atrval);
								UnconfirmedZones[abar].Tag = string.Format("structUniZone{0} {1}", abar, 'S');
							}
						}
	                }

	                #endregion

	                #region -- New Low --
	                else if (addLow)
	                {
	                    upTrend[0] = false;
//	                    int lookback = CurrentBar - lastHighIdx;
	                    //swingHighType[lookback] = pre_swingHighType[lookback];
	                    double newLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - lastHighIdx; i++)
	                    {
	                        if ((useHL ? Lows[0][i] : swingInput[i]) < newLow)
	                        {
	                            newLow = (useHL ? Lows[0][i] : swingInput[i]);
	                            j = i;
	                        }
	                    }
						newLow = Instrument.MasterInstrument.RoundToTickSize(newLow);
	                    priorSwingLowIdx = lastLowIdx;
	                    lastLowIdx = CurrentBar - j;
						currentLow = newLow;
						SwingLowABars.Insert(0, new Tuple<int,double>(lastLowIdx, newLow));

						byte swtype = LL;
						if(SwingLowABars.Count>1) swtype = newLow < SwingLowABars[1].Item2 ? LL : HL;
						NodeTypes.Insert(0, new Tuple<int,byte>(lastLowIdx, swtype));
						int abar = SwingHighABars[0].Item1;
						bool IsDownClose = true;//Closes[0].GetValueAt(abar) < Opens[0].GetValueAt(abar);
						if(IsDownClose
								&& pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure
								&& abar>2
								&& swtype==LL
								&& !UnconfirmedZones.ContainsKey(abar)
								&& !Zones.ContainsKey(abar)
								&& pSuppResBoth != ARC_Uni_Zones_SuppResBoth.SupportOnly){
							int rbar = CurrentBars[0]-abar;
							double LowLevel = Rnd2Tick(Math.Min(Opens[0][rbar], Closes[0][rbar]));
							double HighLevel = Rnd2Tick(Highs[0][rbar]);
							CalcHighAndLowLevelsBasedOnEntryPriceBasis('R', ref HighLevel, ref LowLevel, Opens[0][rbar], Highs[0][rbar], Lows[0][rbar], Closes[0][rbar], Rnd2Tick(Opens[0][rbar+1]), pOffsetAdjustmentTicks); 
							bool ZoneCreated = CreateIfNotOverlapping("struct", UnconfirmedZones, abar, rbar, CurrentBars[0], HighLevel, LowLevel, 'R');
							if(ZoneCreated){
//	Draw.Diamond(this,"SHD"+abar.ToString(),false,0,SwingLowABars[1].Item2 , Brushes.Yellow);
								UnconfirmedZones[abar].ConfirmationPrice = SwingLowABars[1].Item2 - CalculateZoneCreationBufferSize(this.pTicksZoneCreation*TickSize, this.pATRmultZoneCreation*atrval);
								CalculateZonesBreakAndDeadPrices(UnconfirmedZones[abar], pBreakDistanceBasis, pTicksZoneBreak*TickSize, pATRmultZoneBreak*atrval);
								UnconfirmedZones[abar].Tag = string.Format("structUniZone{0} {1}", abar, 'R');
							}
						}
	                }
	                #endregion

	                #region -- dwtrend --
	                else if (updateLow)
	                {
	                    upTrend[0] = false;
	                    pre_swingLowType[CurrentBar - lastLowIdx] = 0;

						currentLow = Instrument.MasterInstrument.RoundToTickSize(useHL ? Lows[0][0] : swingInput[0]);
	                    lastLowIdx = CurrentBar;
						SwingLowABars[0] = new Tuple<int,double>(lastLowIdx, currentLow);

						byte swtype = LL;
						if(SwingLowABars.Count>1) swtype = currentLow < SwingLowABars[1].Item2 ? LL : HL;
						if(NodeTypes.Count>0) NodeTypes[0] = new Tuple<int,byte>(lastLowIdx, swtype);
						int abar = SwingHighABars[0].Item1;
						bool IsDownClose = true;//Closes[0].GetValueAt(abar) < Opens[0].GetValueAt(abar);
						if(IsDownClose
								&& pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure
								&& abar>2
								&& swtype==LL
								&& !UnconfirmedZones.ContainsKey(abar)
								&& !Zones.ContainsKey(abar)
								&& pSuppResBoth != ARC_Uni_Zones_SuppResBoth.SupportOnly){
							int rbar = CurrentBars[0]-abar;
							double LowLevel = Rnd2Tick(Math.Min(Opens[0][rbar], Closes[0][rbar]));
							double HighLevel = Rnd2Tick(Highs[0][rbar]);
							CalcHighAndLowLevelsBasedOnEntryPriceBasis('R', ref HighLevel, ref LowLevel, Opens[0][rbar], Highs[0][rbar], Lows[0][rbar], Closes[0][rbar], Rnd2Tick(Opens[0][rbar+1]), pOffsetAdjustmentTicks); 
line=1266;
							bool ZoneCreated = CreateIfNotOverlapping("struct", UnconfirmedZones, abar, rbar, CurrentBars[0], HighLevel, LowLevel, 'R');
							if(ZoneCreated){
//	Draw.Diamond(this,"SHD"+abar.ToString(),false,0,SwingLowABars[1].Item2 , Brushes.Yellow);
								UnconfirmedZones[abar].ConfirmationPrice = SwingLowABars[1].Item2 - CalculateZoneCreationBufferSize(this.pTicksZoneCreation*TickSize, this.pATRmultZoneCreation*atrval);
line=1268;
								CalculateZonesBreakAndDeadPrices(UnconfirmedZones[abar], pBreakDistanceBasis, pTicksZoneBreak*TickSize, pATRmultZoneBreak*atrval);
line=1270;
								UnconfirmedZones[abar].Tag = string.Format("structUniZone{0} {1}", abar, 'R');
							}
line=1275;
						}
	                }
	                #endregion

					drawHigherHighLabel = false;
					drawLowerHighLabel = false;
					drawDoubleTopLabel = false;
					drawLowerLowLabel = false;
					drawHigherLowLabel = false;
					drawDoubleBottomLabel = false;

	                #region -- UP || HH --
	                if (addHigh || updateHigh)
	                {
line=1502;
	                    int priorHighCount = CurrentBar - priorSwingHighIdx;
	                    int priorLowCount = CurrentBar - priorSwingLowIdx;
	                    highCount = CurrentBar - lastHighIdx;
	                    lowCount = CurrentBar - lastLowIdx;

	                    double marginUp   = (useHL ? Highs[0][priorHighCount] : swingInput[priorHighCount]) + pMultiplierDTB * avgTrueRange[highCount];
	                    double marginDown = (useHL ? Highs[0][priorHighCount] : swingInput[priorHighCount]) - pMultiplierDTB * avgTrueRange[highCount];

						if (currentHigh > marginUp)			drawHigherHighLabel = true;
						else if (currentHigh < marginDown)	drawLowerHighLabel = true;
						else								drawDoubleTopLabel = true;
//PrintDebug(Times[0][0].ToString()+"  marginUp: "+marginUp+"  currentHigh: "+currentHigh+"  HHLabel? "+drawHigherHighLabel.ToString());

	                    #region -- Set NEW drawing states --
	                    if (currentHigh > marginUp)
	                        pre_swingHighType[highCount] = 3;
	                    else if (currentHigh < marginDown)
	                        pre_swingHighType[highCount] = 1;
	                    else
	                        pre_swingHighType[highCount] = 2;
	                    #endregion
	                }
	                #endregion

	                #region -- DW || LL --
	                else if (addLow || updateLow)
	                {
line=1530;
	                    int priorLowCount  = CurrentBar - priorSwingLowIdx;
	                    int priorHighCount = CurrentBar - priorSwingHighIdx;
	                    lowCount  = CurrentBar - lastLowIdx;
	                    highCount = CurrentBar - lastHighIdx;

	                    double marginDown = (useHL ? Lows[0][priorLowCount] : swingInput[priorLowCount]) - pMultiplierDTB * avgTrueRange[lowCount];
	                    double marginUp   = (useHL ? Lows[0][priorLowCount] : swingInput[priorLowCount]) + pMultiplierDTB * avgTrueRange[lowCount];

						if (currentLow < marginDown)	drawLowerLowLabel = true;
						else if (currentLow > marginUp)	drawHigherLowLabel = true;
						else							drawDoubleBottomLabel = true;

	                    #region -- Set NEW drawing states --
	                    if (currentLow < marginDown)
	                        pre_swingLowType[lowCount] = -3;
	                    else if (currentLow > marginUp)
	                        pre_swingLowType[lowCount] = -1;
	                    else
	                        pre_swingLowType[lowCount] = -2;
	                    #endregion
	                }
	                #endregion
	            }
	            #endregion

	            #region else if (IsFirstTickOfBar)
	            else if (IsFirstTickOfBar)
	            {
line=1774;
	                zigzagDeviation = pMultiplierMD * avgTrueRange[1];
	                swingMax = MAX(useHL ? High : Input, pSwingStrength)[2];
	                swingMin = MIN(useHL ? Low : Input, pSwingStrength)[2];

	                pre_swingHighType[0] = 0;
	                pre_swingLowType[0]  = 0;

	                updateHigh = upTrend[1] && (useHL ? Highs[0][1] : swingInput[1]) > currentHigh;
	                updateLow  = !upTrend[1] && (useHL ? Lows[0][1] : swingInput[1]) < currentLow;
	                addHigh    = !upTrend[1] && !((useHL ? Lows[0][1] : swingInput[1]) < currentLow) && (useHL ? Highs[0][1] : swingInput[1]) > Math.Max(swingMax, currentLow + zigzagDeviation);
	                addLow     = upTrend[1] && !((useHL ? Highs[0][1] : swingInput[1]) > currentHigh) && (useHL ? Lows[0][1] : swingInput[1]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

	                upTrend[0] = upTrend[1];

	                #region -- New High --
	                if (addHigh)
	                {
line=1575;
	                    upTrend[0] = true;
	                    int lookback = CurrentBar - lastLowIdx;
	                    //swingLowType[lookback] = pre_swingLowType[lookback];
	                    double newHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 1; i < CurrentBar - lastLowIdx; i++)
	                    {
	                        if ((useHL ? Highs[0][i] : swingInput[i]) > newHigh)
	                        {
	                            newHigh = (useHL ? Highs[0][i] : swingInput[i]);
	                            j = i;
	                        }
	                    }
						newHigh = Instrument.MasterInstrument.RoundToTickSize(newHigh);
	                    priorSwingHighIdx = lastHighIdx;
	                    lastHighIdx = CurrentBar - j;
	                    currentHigh = newHigh;
						SwingHighABars.Insert(0, new Tuple<int,double>(lastHighIdx, newHigh));
line=1592;
						byte swtype = HH;
						if(SwingHighABars.Count>1) swtype = newHigh > SwingHighABars[1].Item2 ? HH : LH;
						NodeTypes.Insert(0, new Tuple<int,byte>(lastHighIdx, swtype));
						int abar = SwingLowABars[0].Item1;
						bool IsUpClose = true;//Closes[0].GetValueAt(abar) > Opens[0].GetValueAt(abar);
						if(IsUpClose
								&& pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure
								&& abar>2
								&& swtype == HH
								&& !UnconfirmedZones.ContainsKey(abar)
								&& !Zones.ContainsKey(abar)
								&& pSuppResBoth != ARC_Uni_Zones_SuppResBoth.ResistanceOnly){
							int rbar = CurrentBars[0]-abar;
							double HighLevel = Rnd2Tick(Math.Max(Opens[0][rbar], Closes[0][rbar]));
							double LowLevel = Rnd2Tick(Lows[0][rbar]);
							CalcHighAndLowLevelsBasedOnEntryPriceBasis('S', ref HighLevel, ref LowLevel, Opens[0][rbar], Highs[0][rbar], Lows[0][rbar], Closes[0][rbar], Rnd2Tick(Opens[0][rbar+1]), pOffsetAdjustmentTicks); 
							bool ZoneCreated = CreateIfNotOverlapping("struct", UnconfirmedZones, abar, rbar, CurrentBars[0], HighLevel, LowLevel, 'S');
							if(ZoneCreated){
								UnconfirmedZones[abar].ConfirmationPrice = SwingHighABars[1].Item2 + CalculateZoneCreationBufferSize(this.pTicksZoneCreation*TickSize, this.pATRmultZoneCreation*atrval);
								CalculateZonesBreakAndDeadPrices(UnconfirmedZones[abar], pBreakDistanceBasis, pTicksZoneBreak*TickSize, pATRmultZoneBreak*atrval);
								UnconfirmedZones[abar].Tag = string.Format("structUniZone{0} {1}", abar, 'S');
							}
						}
	                }
	                #endregion

	                #region -- UPtrend --
	                else if (updateHigh)
	                {
	                    upTrend[0] = true;
	                    pre_swingHighType[CurrentBar - lastHighIdx] = 0;

	                    currentHigh = (useHL ? Highs[0][1] : swingInput[1]);
	                    lastHighIdx = CurrentBar - 1;
						SwingHighABars[0] = new Tuple<int,double>(lastHighIdx, currentHigh);

						byte swtype = HH;
						if(SwingHighABars.Count>1) swtype = currentHigh > SwingHighABars[1].Item2 ? HH : LH;
						if(NodeTypes.Count>0) NodeTypes[0] = new Tuple<int,byte>(lastHighIdx, swtype);
						int abar = SwingLowABars[0].Item1;
						bool IsUpClose = true;//Closes[0].GetValueAt(abar) > Opens[0].GetValueAt(abar);
						if(IsUpClose
								&& pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure
								&& abar>2
								&& swtype == HH
								&& !UnconfirmedZones.ContainsKey(abar)
								&& !Zones.ContainsKey(abar)
								&& pSuppResBoth != ARC_Uni_Zones_SuppResBoth.ResistanceOnly){
							int    rbar      = CurrentBars[0]-abar;
							double HighLevel = Rnd2Tick(Math.Max(Opens[0][rbar], Closes[0][rbar]));
							double LowLevel  = Rnd2Tick(Lows[0][rbar]);
							CalcHighAndLowLevelsBasedOnEntryPriceBasis('S', ref HighLevel, ref LowLevel, Opens[0][rbar], Highs[0][rbar], Lows[0][rbar], Closes[0][rbar], Rnd2Tick(Opens[0][rbar+1]), pOffsetAdjustmentTicks); 
							bool ZoneCreated = CreateIfNotOverlapping("struct", UnconfirmedZones, abar, rbar, CurrentBars[0], HighLevel, LowLevel, 'S');
							if(ZoneCreated){
								UnconfirmedZones[abar].ConfirmationPrice = SwingHighABars[1].Item2 + CalculateZoneCreationBufferSize(this.pTicksZoneCreation*TickSize, this.pATRmultZoneCreation*atrval);
								CalculateZonesBreakAndDeadPrices(UnconfirmedZones[abar], pBreakDistanceBasis, pTicksZoneBreak*TickSize, pATRmultZoneBreak*atrval);
								UnconfirmedZones[abar].Tag = string.Format("structUniZone{0} {1}", abar, 'S');
							}
						}
	                }
	                #endregion

	                #region -- New Low --
	                else if (addLow)
	                {
	                    upTrend[0] = false;
	                    int lookback = CurrentBar - lastHighIdx;
	                    //swingHighType[lookback] = pre_swingHighType[lookback];
	                    double newLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 1; i < CurrentBar - lastHighIdx; i++)
	                    {
	                        if ((useHL ? Lows[0][i] : swingInput[i]) < newLow)
	                        {
	                            newLow = (useHL ? Lows[0][i] : swingInput[i]);
	                            j = i;
	                        }
	                    }
						newLow = Instrument.MasterInstrument.RoundToTickSize(newLow);
	                    priorSwingLowIdx = lastLowIdx;
	                    lastLowIdx = CurrentBar - j;
line=1635;
						currentLow = newLow;
						SwingLowABars.Insert(0, new Tuple<int,double>(lastLowIdx, currentLow));

						byte swtype = LL;
						if(SwingLowABars.Count>1) swtype = newLow < SwingLowABars[1].Item2 ? LL : HL;
						NodeTypes.Insert(0, new Tuple<int,byte>(lastLowIdx, swtype));
						int abar = SwingHighABars[0].Item1;
//if(inzone) {
//	Print(Times[0][0].ToString()+"  2683 swtype: "+(swtype==LL ? "LL" : (swtype==HL ? "HL":"unknown")));
//}
						bool IsDownClose = true;//Closes[0].GetValueAt(abar) < Opens[0].GetValueAt(abar);
						if(IsDownClose
								&& pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure
								&& abar>2
								&& swtype==LL
								&& pSuppResBoth != ARC_Uni_Zones_SuppResBoth.SupportOnly){
//if(inzone) {
//	Print("   new low");
//}
							int rbar = CurrentBars[0]-abar;
							double LowLevel = Rnd2Tick(Math.Min(Opens[0][rbar], Closes[0][rbar]));
							double HighLevel = Rnd2Tick(Highs[0][rbar]);
							CalcHighAndLowLevelsBasedOnEntryPriceBasis('R', ref HighLevel, ref LowLevel, Opens[0][rbar], Highs[0][rbar], Lows[0][rbar], Closes[0][rbar], Rnd2Tick(Opens[0][rbar+1]), pOffsetAdjustmentTicks); 
							bool ZoneCreated = CreateIfNotOverlapping("struct", UnconfirmedZones, abar, rbar, CurrentBars[0], HighLevel, LowLevel, 'R');
//if(inzone) Print("   ZoneCreated: "+ZoneCreated.ToString()+"   abar: "+Times[0].GetValueAt(abar).ToString());
							if(ZoneCreated){
								UnconfirmedZones[abar].ConfirmationPrice = SwingLowABars[1].Item2 - CalculateZoneCreationBufferSize(this.pTicksZoneCreation*TickSize, this.pATRmultZoneCreation*atrval);
								CalculateZonesBreakAndDeadPrices(UnconfirmedZones[abar], pBreakDistanceBasis, pTicksZoneBreak*TickSize, pATRmultZoneBreak*atrval);
								UnconfirmedZones[abar].Tag = string.Format("structUniZone{0} {1}", abar, 'R');
							}
						}
	                }
	                #endregion

	                #region -- DWtrend --
	                else if (updateLow)
	                {
	                    upTrend[0] = false;
	                    pre_swingLowType[CurrentBar - lastLowIdx] = 0;

	                    currentLow = Instrument.MasterInstrument.RoundToTickSize(useHL ? Lows[0][1] : swingInput[1]);
	                    lastLowIdx = CurrentBar - 1;
						SwingLowABars[0] = new Tuple<int,double>(lastLowIdx, currentLow);
line=1654;

						byte swtype = LL;
						if(SwingLowABars.Count>1) swtype = currentLow < SwingLowABars[1].Item2 ? LL : HL;
						if(NodeTypes.Count>0) NodeTypes[0] = new Tuple<int,byte>(lastLowIdx, swtype);
						int abar = SwingHighABars[0].Item1;
//if(inzone) {
//	Print(Times[0][0].ToString()+"  2726 swtype: "+(swtype==LL ? "LL" : (swtype==HL ? "HL":"unknown")));
//}
						bool IsDownClose = true;//Closes[0].GetValueAt(abar) < Opens[0].GetValueAt(abar);
						if(IsDownClose
								&& pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure
								&& abar>2
								&& swtype==LL
								&& !Zones.ContainsKey(abar)
								&& pSuppResBoth != ARC_Uni_Zones_SuppResBoth.SupportOnly){
//if(inzone) Print(Times[0][0].ToString()+"   updated low");
							int rbar = CurrentBars[0]-abar;
							double LowLevel = Rnd2Tick(Math.Min(Opens[0][rbar], Closes[0][rbar]));
							double HighLevel = Rnd2Tick(Highs[0][rbar]);
							CalcHighAndLowLevelsBasedOnEntryPriceBasis('R', ref HighLevel, ref LowLevel, Opens[0][rbar], Highs[0][rbar], Lows[0][rbar], Closes[0][rbar], Rnd2Tick(Opens[0][rbar+1]), pOffsetAdjustmentTicks); 
							bool ZoneCreated = CreateIfNotOverlapping("struct", UnconfirmedZones, abar, rbar, CurrentBars[0], HighLevel, LowLevel, 'R');
//if(inzone) Print("   ZoneCreated: "+ZoneCreated.ToString()+"   abar: "+Times[0].GetValueAt(abar).ToString());
							if(ZoneCreated){
								UnconfirmedZones[abar].ConfirmationPrice = SwingLowABars[1].Item2 - CalculateZoneCreationBufferSize(this.pTicksZoneCreation*TickSize, this.pATRmultZoneCreation*atrval);
								CalculateZonesBreakAndDeadPrices(UnconfirmedZones[abar], pBreakDistanceBasis, pTicksZoneBreak*TickSize, pATRmultZoneBreak*atrval);
								UnconfirmedZones[abar].Tag = string.Format("structUniZone{0} {1}", abar, 'R');
							}
						}
	                }
	                #endregion

					drawHigherHighLabel = false;
					drawLowerHighLabel = false;
					drawDoubleTopLabel = false;
					drawLowerLowLabel = false;
					drawHigherLowLabel = false;
					drawDoubleBottomLabel = false;

	                #region -- BUY || HH --
	                if (addHigh || updateHigh)
	                {
	                    int priorHighCount = CurrentBar - priorSwingHighIdx;
	                    highCount = CurrentBar - lastHighIdx;
	                    lowCount = CurrentBar - lastLowIdx;

	                    double marginUp   = (useHL ? Highs[0][priorHighCount] : swingInput[priorHighCount]) + pMultiplierDTB * avgTrueRange[highCount];
	                    double marginDown = (useHL ? Highs[0][priorHighCount] : swingInput[priorHighCount]) - pMultiplierDTB * avgTrueRange[highCount];

						if (currentHigh > marginUp)			drawHigherHighLabel = true;
						else if (currentHigh < marginDown)	drawLowerHighLabel = true;
						else								drawDoubleTopLabel = true;

	                    #region -- Set NEW drawing states --
	                    if (currentHigh > marginUp)
	                        pre_swingHighType[highCount] = 3;
	                    else if (currentHigh < marginDown)
	                        pre_swingHighType[highCount] = 1;
	                    else
	                        pre_swingHighType[highCount] = 2;
	                    #endregion
	                }
	                #endregion

	                #region -- DW || LL --
	                else if (addLow || updateLow)
	                {
	                    int priorLowCount = CurrentBar - priorSwingLowIdx;
	                    lowCount = CurrentBar - lastLowIdx;
	                    highCount = CurrentBar - lastHighIdx;

	                    double marginDown = (useHL ? Lows[0][priorLowCount] : swingInput[priorLowCount]) - pMultiplierDTB * avgTrueRange[lowCount];
	                    double marginUp   = (useHL ? Lows[0][priorLowCount] : swingInput[priorLowCount]) + pMultiplierDTB * avgTrueRange[lowCount];

						if (currentLow < marginDown)	drawLowerLowLabel = true;
						else if (currentLow > marginUp)	drawHigherLowLabel = true;
						else							drawDoubleBottomLabel = true;

	                    #region -- Set NEW drawing states --
	                    if (currentLow < marginDown)
	                        pre_swingLowType[lowCount] = -3;
	                    else if (currentLow > marginUp)
	                        pre_swingLowType[lowCount] = -1;
	                    else
	                        pre_swingLowType[lowCount] = -2;
	                    #endregion
	                }
	                #endregion
	            }
	            #endregion
line=1990;
				#region if (Calculate != Calculate.OnBarClose)
	            if (Calculate != Calculate.OnBarClose)
	            {
	                intraBarUpdateHigh = upTrend[0] && (useHL ? Highs[0][0] : swingInput[0]) > currentHigh;
	                intraBarUpdateLow = !upTrend[0] && (useHL ? Lows[0][0] : swingInput[0]) < currentLow;
	                intraBarAddHigh = !upTrend[0] && !((useHL ? Lows[0][0] : swingInput[0]) < currentLow) && (useHL ? Highs[0][0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
	                intraBarAddLow  = upTrend[0] && !((useHL ? Highs[0][0] : swingInput[0]) > currentHigh) && (useHL ? Lows[0][0] : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

	                #region -- new HH --
	                if (intraBarAddHigh)
	                {
	                    double newHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - lastLowIdx; i++)
	                    {
	                        if ((useHL ? Highs[0][i] : swingInput[i]) > newHigh)
	                        {
	                            newHigh = (useHL ? Highs[0][i] : swingInput[i]);
	                            j = i;
	                        }
	                    }
	                    preCurrentHigh = newHigh;
	                    preLastHighIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- uptrend --
	                else if (intraBarUpdateHigh)
	                {
	                    preCurrentHigh = (useHL ? Highs[0][0] : swingInput[0]);
	                    preLastHighIdx = CurrentBar;
	                }
	                #endregion

	                #region -- new LL --
	                if (intraBarAddLow)
	                {
	                    double newLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - lastHighIdx; i++)
	                    {
	                        if ((useHL ? Lows[0][i] : swingInput[i]) < newLow)
	                        {
	                            newLow = useHL ? Lows[0][i] : swingInput[i];
	                            j = i;
	                        }
	                    }
	                    preCurrentLow = newLow;
	                    preLastLowIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- dwtrend --
	                else if (intraBarUpdateLow)
	                {
	                    preCurrentLow = (useHL ? Lows[0][0] : swingInput[0]);
	                    preLastLowIdx = CurrentBar;
	                }
	                #endregion

	                #region -- UP || HH --
	                if (intraBarAddHigh || intraBarUpdateHigh)
	                {
	                    int prePriorHighCount = intraBarAddHigh ? CurrentBar - lastHighIdx : CurrentBar - priorSwingHighIdx;
	                    int preHighCount = CurrentBar - preLastHighIdx;
	                    int prePriorLowCount = CurrentBar - priorSwingLowIdx;
	                    int preLowCount = CurrentBar - lastLowIdx;

	                    #region ---- StructureBias RealTime ---
	                    double marginUp, marginDown;
	                    if (useHL)
	                    {
	                        marginUp = Highs[0][prePriorHighCount] + pMultiplierDTB * avgTrueRange[preHighCount];
	                        marginDown = Highs[0][prePriorHighCount] - pMultiplierDTB * avgTrueRange[preHighCount];
	                    }
	                    else
	                    {
	                        marginUp = swingInput[prePriorHighCount] + pMultiplierDTB * avgTrueRange[preHighCount];
	                        marginDown = swingInput[prePriorHighCount] - pMultiplierDTB * avgTrueRange[preHighCount];
	                    }

	                    if (preCurrentHigh > marginUp) preSRType = 3;//#STRBIAS
	                    else if (preCurrentHigh < marginDown) preSRType = Math.Max(preSRType, 2);//#STRBIAS
	                    else preSRType = Math.Max(preSRType, 1);//#STRBIAS
	                    #endregion
	                }
	                #endregion

	                #region -- DW || LL --
	                else if (intraBarAddLow || intraBarUpdateLow)
	                {
	                    int prePriorLowCount = intraBarAddLow ? CurrentBar - lastLowIdx : CurrentBar - priorSwingLowIdx;
	                    int preLowCount = CurrentBar - preLastLowIdx;
	                    int prePriorHighCount = CurrentBar - priorSwingHighIdx;
	                    int preHighCount = CurrentBar - lastHighIdx;

	                    #region ---- StructureBias RealTime ---
	                    double marginUp, marginDown;
	                    if (useHL)
	                    {
	                        marginDown = Lows[0][prePriorLowCount] - pMultiplierDTB * avgTrueRange[preLowCount];
	                        marginUp = Lows[0][prePriorLowCount] + pMultiplierDTB * avgTrueRange[preLowCount];
	                    }
	                    else
	                    {
	                        marginDown = swingInput[prePriorLowCount] - pMultiplierDTB * avgTrueRange[preLowCount];
	                        marginUp = swingInput[prePriorLowCount] + pMultiplierDTB * avgTrueRange[preLowCount];
	                    }
	                    if (preCurrentLow < marginDown) preSRType = -3;//#STRBIAS
	                    else if (preCurrentLow > marginUp) preSRType = Math.Min(preSRType, -2);//#STRBIAS
	                    else preSRType = Math.Min(preSRType, -1);//#STRBIAS
	                    #endregion
	                }
	                #endregion

	                //Is it possible ??
	                else
	                {
	                    preSRType = 0;//#STRBIAS
	                }

	                #region ---- StructureBias RealTime ---
	                if (CurrentBar < 2) 
						structureBiasState[0] = 0;
	                else
	                {
	                    if (preSRType == 0) structureBiasState[0] = structureBiasState[1];

	                    #region -- Oscillation State --
	                    else if (structureBiasState[1] == 0)
	                    {
	                        //Oscillation State
	                        //Need HH/!LL/HH to go to Up Trend
	                        //{NEW} !LL/High/!LL/HH to go to Up Trend
	                        //Need LL/!HH/LL to go to Dw Trend
	                        //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
	                        if (sequence.Count < 2) structureBiasState[0] = 0;
	                        else if (sequence.Count < 3)
	                        {
	                            if (sequence[0] == 3 && sequence[1] != -3 && preSRType == 3)		structureBiasState[0] = 1;
	                            else if (sequence[0] == -3 && sequence[1] != 3 && preSRType == -3)	structureBiasState[0] = -1;
	                            else																structureBiasState[0] = 0;
	                        }
	                        else
	                        {
	                            if (sequence[1] == 3 && sequence[2] != -3 && preSRType == 3)		structureBiasState[0] = 1;
	                            else if (sequence[1] == -3 && sequence[2] != 3 && preSRType == -3)	structureBiasState[0] = -1;
	                            //{NEW} HL/LH/HL/HH to go to Up Trend
	                            else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && preSRType == 3) structureBiasState[0] = 1;
	                            //{NEW} LH/HL/LH/LL to go to Up Trend
	                            else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && preSRType == -3)	structureBiasState[0] = -1;
	                            else																					structureBiasState[0] = 0;
	                        }
	                    }
	                    #endregion

	                    #region -- UpTrend State --
	                    else if (structureBiasState[1] > 0)
	                    {
	                        //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
	                        if (preSRType == -3) structureBiasState[0] = 0;
	                        else structureBiasState[0] = 1;
	                    }
	                    #endregion

	                    #region -- DwTrend State --
	                    else if (structureBiasState[1] < 0)
	                    {
	                        //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
	                        if (preSRType == 3) structureBiasState[0] = 0;
	                        else structureBiasState[0] = -1;
	                    }
	                    #endregion

	                    else structureBiasState[0] = structureBiasState[1];
	                }
	                #endregion

	            }
	            #endregion
				#endregion
				#region -- Calculate PriceAction bars, OrderBlocks, Traps --
				if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction){
					int offset = (Calculate != Calculate.OnBarClose ? 1 : 0);
					int ThrustCandidateABar = CurrentBars[0]-offset;
					double ThrustCandidateClosePrice = Closes[0].GetValueAt(ThrustCandidateABar);
					int abar = CurrentBars[0];
					if(pShowTrapZones){
						#region -- ShowTrapZones --
						if(pGapMeasurement == ARC_Uni_Zones_GapMeasurements.ATR){
							minpts_Traps = atrTraps[0] * pGapMinATRMultiple;
							maxpts_Traps = atrTraps[0] * pGapMaxATRMultiple;
						}

						double diffpts = Lows[0][0] - Highs[0][2];
						if(diffpts > 0 && diffpts > minpts_Traps && diffpts < maxpts_Traps && pSuppResBoth != ARC_Uni_Zones_SuppResBoth.ResistanceOnly) //Breakout is upward...this is a support zone
						{
							Zones[abar-offset] = new Zone('S', abar, Lows[0][0], Highs[0][2]);
							CalculateZonesBreakAndDeadPrices(Zones[abar-offset], pBreakDistanceBasis, 0, 0);
							Zones[abar-offset].Tag = string.Format("trapUniZone{0} {1}", abar-offset, 'S');
							Zones[abar-offset].ConfirmedABar = abar-offset;
#if INCLUDE_GLOBALIZATION
							if(pGlobalizeFreshZones) DrawGlobalZone(Zones[abar-offset], abar);
#endif
						}
						diffpts = Lows[0][2] - Highs[0][0];
						if(diffpts > 0 && diffpts > minpts_Traps && diffpts < maxpts_Traps && pSuppResBoth != ARC_Uni_Zones_SuppResBoth.SupportOnly) //Breakout is downward...this is a resistance zone
						{
							Zones[abar-offset] = new Zone('R', abar, Lows[0][2], Highs[0][0]);
							CalculateZonesBreakAndDeadPrices(Zones[abar-offset], pBreakDistanceBasis, 0, 0);
							Zones[abar-offset].Tag = string.Format("trapUniZone{0} {1}", abar-offset, 'S');
							Zones[abar-offset].ConfirmedABar = abar-offset;
#if INCLUDE_GLOBALIZATION
							if(pGlobalizeFreshZones) DrawGlobalZone(Zones[abar-offset], abar);
#endif
						}
						#endregion
					}

//if(inzone)Print(timeofday(Times[0][0]));
					if(pShowSandDZones){
						#region -- S&D Zone creation --
line=3035;
						bool CheckForBasingZone = CurrentBars[0]-offset > OrderblockZoneABar;
						double bodysize = Math.Abs(Opens[0][offset]-Closes[0][offset]);
						bool IsSmallBody = bodysize / (Highs[0][offset]-Lows[0][offset]) < MaxBodyPct;
//if(inzone && IsSmallBody) BackBrushes[offset] = Brushes.Blue;
//if(inzone)Print("     bodysize/Range: "+bodysize/(Highs[0][offset]-Lows[0][offset])+"  high: "+Highs[0][offset]+"  cb-OrderblockZoneABar: "+(CurrentBars[0]-OrderblockZoneABar));
						if(CheckForBasingZone && IsSmallBody){
line=3042;
							if(pBasingBarUpBrush   !=Brushes.Transparent && pBasingBarUpOpacity>0   && Closes[0][offset] > Opens[0][offset]) BarBrushes[offset] = basingUpbrush;
							if(pBasingBarDownBrush !=Brushes.Transparent && pBasingBarDownOpacity>0 && Closes[0][offset] < Opens[0][offset]) BarBrushes[offset] = basingDownbrush;
							BasingBarsList.Add(CurrentBars[0]-offset);
//if(inzone && CheckForBasingZone) BackBrushes[offset]=Brushes.Maroon;
						}
						if(!BasingBarsList.Contains(ThrustCandidateABar) && BasingBarsList.Contains(ThrustCandidateABar-1)){
line=3049;
							int LastBasingCandidateABar = ThrustCandidateABar-1;
							double Hwick = Highs[0].GetValueAt(LastBasingCandidateABar);
							double Lwick = Lows[0].GetValueAt(LastBasingCandidateABar);
							double Hbody = Math.Max(Closes[0].GetValueAt(LastBasingCandidateABar),Opens[0].GetValueAt(LastBasingCandidateABar));
							double Lbody = Math.Min(Closes[0].GetValueAt(LastBasingCandidateABar),Opens[0].GetValueAt(LastBasingCandidateABar));
//if(inzone && LastBasingCandidateABar>0 && OrderblockZoneABar>0)Print("LastBasingCandidate: "+timeofday(Times[0].GetValueAt(LastBasingCandidateABar))+"  OrderblockZone: "+timeofday(Times[0].GetValueAt(OrderblockZoneABar)));
line=3056;
							if(LastBasingCandidateABar == OrderblockZoneABar){
								abar = LastBasingCandidateABar + (pShowOrderblockZones ? 0:1);
							}else{
								for(int i = LastBasingCandidateABar; i>OrderblockZoneABar; i--){
//								for(int i = LastBasingCandidateABar; i>0; i--){
									if(!BasingBarsList.Contains(i)){
										abar = i+1;//abar points to the leftmost bar of the group of one or more basing candles
										//BasingBarsList.Clear();
//if(inzone)Print("Breaking out");
										break;
									}
									Hwick = Math.Max(Hwick, Highs[0].GetValueAt(i));
									Lwick = Math.Min(Lwick, Lows[0].GetValueAt(i));
									Hbody = Math.Max(Hbody, Math.Max(Closes[0].GetValueAt(i),Opens[0].GetValueAt(i)));
									Lbody = Math.Min(Lbody, Math.Min(Closes[0].GetValueAt(i),Opens[0].GetValueAt(i)));
									abar = i + (pShowOrderblockZones ? 0:1);
//if(inzone)Print("   finding Hwick: "+Hwick+"  Lwick: "+Lwick+"   Hbody: "+Hbody+"  Lbody: "+Lbody);
								}
							}
							if(!Zones.ContainsKey(abar)){
line=3073;
//if(inzone)Print("Hwick: "+Hwick+"  Lwick: "+Lwick+"   Hbody: "+Hbody+"  Lbody: "+Lbody);
								bool c1 = false;
								if(pBasingZoneSizeBasis == ARC_Uni_Zones_BasingZoneSizeBasis.Body) c1 = ThrustCandidateClosePrice > Hbody;
								else if(pBasingZoneSizeBasis == ARC_Uni_Zones_BasingZoneSizeBasis.FullBase) c1 = ThrustCandidateClosePrice > Hwick;
								if(c1 && pSuppResBoth != ARC_Uni_Zones_SuppResBoth.ResistanceOnly){//Breakout is upward...this is a support zone
									if(pThrustBarUpBrush   !=Brushes.Transparent && pThrustBarUpOpacity>0   && Closes[0][offset] > Opens[0][offset]) BarBrushes[offset] = thrustUpbrush;
									if(pThrustBarDownBrush !=Brushes.Transparent && pThrustBarDownOpacity>0 && Closes[0][offset] < Opens[0][offset]) BarBrushes[offset] = thrustDownbrush;
									Zones[abar] = new Zone('S', CurrentBars[0]+1, pBasingZoneSizeBasis == ARC_Uni_Zones_BasingZoneSizeBasis.FullBase ? Hwick:Hbody, Math.Min(Lows[0].GetValueAt(ThrustCandidateABar),Lwick));
//if(inzone)BackBrushes[0]=Brushes.Pink;
									CalculateZonesBreakAndDeadPrices(Zones[abar], pBreakDistanceBasis, 0, 0);
									Zones[abar].Tag = string.Format("s&dUniZone{0} {1}", abar, 'S');
									Zones[abar].ConfirmedABar = ThrustCandidateABar;
//if(inzone)Print(timeofday(Times[0].GetValueAt(abar))+"-key, new S&D Supp zone , birthbar: "+timeofday(Times[0].GetValueAt(CurrentBars[0]+1))+"    ConfirmedABar: "+timeofday(Times[0].GetValueAt(ThrustCandidateABar))+"  High: "+Zones[abar].TopPrice+" bot: "+Zones[abar].BotPrice);
#if INCLUDE_GLOBALIZATION
									if(pGlobalizeFreshZones)  DrawGlobalZone(Zones[abar], abar);
#endif
								}else{
									c1 = false;
									if(pBasingZoneSizeBasis == ARC_Uni_Zones_BasingZoneSizeBasis.Body) c1 = ThrustCandidateClosePrice < Lbody;
									else if(pBasingZoneSizeBasis == ARC_Uni_Zones_BasingZoneSizeBasis.FullBase) c1 = ThrustCandidateClosePrice < Lwick;
									if (c1 && pSuppResBoth != ARC_Uni_Zones_SuppResBoth.SupportOnly){//Breakout is downward...this is a resistance zone
										if(pThrustBarUpBrush   !=Brushes.Transparent && pThrustBarUpOpacity>0   && Closes[0][offset] > Opens[0][offset]) BarBrushes[offset] = thrustUpbrush;
										if(pThrustBarDownBrush !=Brushes.Transparent && pThrustBarDownOpacity>0 && Closes[0][offset] < Opens[0][offset]) BarBrushes[offset] = thrustDownbrush;
										Zones[abar] = new Zone('R', CurrentBars[0]+1, Math.Max(Highs[0].GetValueAt(ThrustCandidateABar),Hwick), pBasingZoneSizeBasis == ARC_Uni_Zones_BasingZoneSizeBasis.FullBase ? Lwick:Lbody);
//if(inzone)BackBrushes[0]=Brushes.Goldenrod;
										CalculateZonesBreakAndDeadPrices(Zones[abar], pBreakDistanceBasis, 0, 0);
										Zones[abar].Tag = string.Format("s&dUniZone{0} {1}", abar, 'R');
										Zones[abar].ConfirmedABar = ThrustCandidateABar;
//if(inzone)Print(timeofday(Times[0].GetValueAt(abar))+"-key, new S&D Demand zone , birthbar: "+timeofday(Times[0].GetValueAt(CurrentBars[0]+1))+"    ConfirmedABar: "+timeofday(Times[0].GetValueAt(ThrustCandidateABar))+"  High: "+Zones[abar].TopPrice+" bot: "+Zones[abar].BotPrice);
#if INCLUDE_GLOBALIZATION
										if(pGlobalizeFreshZones)  DrawGlobalZone(Zones[abar], abar);
#endif
									}
								}
							}
						}
						#endregion
					}
		//====================================================================
					if(pShowOrderblockZones && IsFirstTickOfBar && !Zones.ContainsKey(abar)){
						#region -- Orderblock Zone creation --
//						OrderblockZoneABar = -1;
						double HighestClosePrice = double.MinValue;
						int LastBasingCandidateABar = FindMostRecentDownClosingBar(ThrustCandidateABar, pThrustBarsDelay+1, ref HighestClosePrice);
//if(inzone)Print("Last downclosing basing candidate:  "+(LastBasingCandidateABar<0? "Infinite" : Times[0].GetValueAt(LastBasingCandidateABar).ToString()));
						bool c1 = false;
						bool c2 = false;
						if(LastBasingCandidateABar != int.MinValue && !Zones.ContainsKey(LastBasingCandidateABar)){
							c1 = HighestClosePrice > Highs[0].GetValueAt(LastBasingCandidateABar);
							if(c1 && pSuppResBoth != ARC_Uni_Zones_SuppResBoth.ResistanceOnly){//Breakout is upward...this is a support zone
//if(inzone)BackBrushes.Set(ThrustCandidateABar, Brushes.Pink);
								Zones[LastBasingCandidateABar] = new Zone('S', CurrentBars[0]+1, Highs[0].GetValueAt(LastBasingCandidateABar), Math.Min(Lows[0].GetValueAt(ThrustCandidateABar), Lows[0].GetValueAt(LastBasingCandidateABar)));
								CalculateZonesBreakAndDeadPrices(Zones[LastBasingCandidateABar], pBreakDistanceBasis, 0, 0);
								Zones[LastBasingCandidateABar].Tag = string.Format("obkUniZone{0} {1}", LastBasingCandidateABar, 'S');
								Zones[LastBasingCandidateABar].ConfirmedABar = ThrustCandidateABar;
//if(inzone)Print(timeofday(Times[0].GetValueAt(LastBasingCandidateABar))+"-key, new OBK Supp zone , birthbar: "+timeofday(Times[0].GetValueAt(CurrentBars[0]+1))+"    ConfirmedABar: "+timeofday(Times[0].GetValueAt(ThrustCandidateABar)));
								OrderblockZoneABar = LastBasingCandidateABar;
								if(orderblockUpbrush!=Brushes.Transparent && pOrderblockBarUpOpacity>0) BarBrushes.Set(ThrustCandidateABar, orderblockUpbrush);
#if INCLUDE_GLOBALIZATION
								if(pGlobalizeFreshZones) DrawGlobalZone(Zones[LastBasingCandidateABar], abar);
#endif
							}
						}
						double LowestClosePrice = double.MaxValue;
						LastBasingCandidateABar = FindMostRecentUpClosingBar(ThrustCandidateABar, pThrustBarsDelay+1, ref LowestClosePrice);
//if(inzone)Print("Last upclosing basing candidate:  "+(LastBasingCandidateABar<0 ? "Infinite":Times[0].GetValueAt(LastBasingCandidateABar).ToString()));
						if(LastBasingCandidateABar != int.MinValue && !Zones.ContainsKey(LastBasingCandidateABar)){
							c1 = LowestClosePrice < Lows[0].GetValueAt(LastBasingCandidateABar);
							if(c1 && pSuppResBoth != ARC_Uni_Zones_SuppResBoth.SupportOnly){//Breakout is downward...this is a resistance zone
								Zones[LastBasingCandidateABar] = new Zone('R', CurrentBars[0]+1, Math.Max(Highs[0].GetValueAt(ThrustCandidateABar), Highs[0].GetValueAt(LastBasingCandidateABar)), Lows[0].GetValueAt(LastBasingCandidateABar));
								CalculateZonesBreakAndDeadPrices(Zones[LastBasingCandidateABar], pBreakDistanceBasis, 0, 0);
								Zones[LastBasingCandidateABar].Tag = string.Format("obkUniZone{0} {1}", LastBasingCandidateABar, 'R');
								Zones[LastBasingCandidateABar].ConfirmedABar = ThrustCandidateABar;
//if(inzone)Print(timeofday(Times[0].GetValueAt(LastBasingCandidateABar))+"-key, new OBK Res zone , birthbar: "+timeofday(Times[0].GetValueAt(CurrentBars[0]+1))+"    ConfirmedABar: "+timeofday(Times[0].GetValueAt(ThrustCandidateABar)));
								OrderblockZoneABar = LastBasingCandidateABar;
								if(orderblockDownbrush!=Brushes.Transparent && pOrderblockBarDownOpacity>0) BarBrushes.Set(ThrustCandidateABar, orderblockDownbrush);
#if INCLUDE_GLOBALIZATION
								if(pGlobalizeFreshZones) DrawGlobalZone(Zones[LastBasingCandidateABar], abar);
#endif
							}
						}
						#endregion
					}
//if(inzone){
//	Print("");
//	var tz = Zones.Where(k=>k.Value.BotPrice==3744.25 && k.Value.TopPrice==3749);
//	foreach(var xxx in tz) Print(Times[0][0].ToString()+"  key:"+Times[0].GetValueAt(xxx.Key).ToString()+"   status: "+xxx.Value.Status+"  ConfirmedABar: "+Times[0].GetValueAt(xxx.Value.ConfirmedABar).ToString());
//}
				}
				#endregion

				#region -- Create Structure zones, Update Zone Statuses --
				var ZoneKeysToDelete = new List<int>();
				#region -- For Structure zones only:  Confirm zones when price breaks their ConfirmationPrice value --
				foreach(var zone in UnconfirmedZones){
					if(zone.Value.Type == 'R'){
						double price = pCreationBasis == ARC_Uni_Zones_BarBasis.Full ? Highs[0][0] : Lows[0][0];
						if(price < zone.Value.ConfirmationPrice){
							bool ZoneCreated = CreateIfNotOverlapping("struct", Zones, zone.Key, CurrentBars[0]-zone.Key, 0/*zone.Value.BirthABar*/, zone.Value.TopPrice, zone.Value.BotPrice, zone.Value.Type);
							if(ZoneCreated) {
								Zones[zone.Key].ConfirmedABar = CurrentBars[0];
								Zones[zone.Key].Tag = string.Format("structUniZone{0} {1}", zone.Key, 'R');
							}
//Print(abar+":  "+Times[0][0].ToString()+"  high: "+Z[abar].TopPrice+"  confirmbar: "+Z[abar].ConfirmedABar);
//							if(ZoneCreated && IsRealTime && pGlobalizeFreshZones) DrawGlobalZone(Zones[zone.Key], zone.Key);
							ZoneKeysToDelete.Add(zone.Key);
						}
					}else if(zone.Value.Type == 'S'){
						double price = pCreationBasis == ARC_Uni_Zones_BarBasis.Full ? Lows[0][0] : Highs[0][0];
						if(price > zone.Value.ConfirmationPrice){
							bool ZoneCreated = CreateIfNotOverlapping("struct", Zones, zone.Key, CurrentBars[0]-zone.Key, 0/*zone.Value.BirthABar*/, zone.Value.TopPrice, zone.Value.BotPrice, zone.Value.Type);
							if(ZoneCreated){
								Zones[zone.Key].ConfirmedABar = CurrentBars[0];
								Zones[zone.Key].Tag = string.Format("structUniZone{0} {1}", zone.Key, 'S');
							}
							ZoneKeysToDelete.Add(zone.Key);
						}
					}
				}
				foreach(var del_this in ZoneKeysToDelete) UnconfirmedZones.Remove(del_this);
				#endregion
				bool IsRealTime = CurrentBars[0] >= Bars.Count-2;
				if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure){
					#region -- Update existing globalized F and T zones on the first tick of a bar --
#if INCLUDE_GLOBALIZATION
					if(IsRealTime && IsFirstTickOfBar && (pGlobalizeFreshZones || pGlobalizeTestedZones)){
						if(pGlobalizeFreshZones){
							var zo = Zones.Where(k=>k.Value.Status == 'F' && k.Value.ConfirmedABar>0 && k.Value.ConfirmedABar < CurrentBars[0]).ToList();
							foreach(var z in zo) DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin ? z.Key:z.Value.ConfirmedABar);
						}
						if(pGlobalizeTestedZones){
							var zo = Zones.Where(k=>k.Value.Status == 'T').ToList();
							foreach(var z in zo) DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin ? z.Key:z.Value.ConfirmedABar);
						}
					}
#endif
					#endregion
					var zones = Zones.Where(k=>k.Value.Status != 'D' && k.Value.ConfirmedABar>0 && k.Value.ConfirmedABar < CurrentBars[0]).ToList();
//if(IsDebug) zones = Zones.Where(k=>k.Value.Status != 'D').ToList();
					#region -- Update status for Structure zones --
					foreach(var z in zones){
//DateTime t = Times[0].GetValueAt(z.Key);
//bool c = IsDebug && t.Day==28 && t.Month==9 && t.Hour==9 && t.Minute<10 && t.Minute>5;
						bool T_Updated = false;
						bool B_Updated = false;
						bool D_Updated = false;
//if(xx && (z.Value.Status=='F'||z.Value.Status=='T')) z.Value.ConfirmedABar=CurrentBars[0];
//if(c)Print("\n"+z.Key+": "+t.ToString()+"  "+z.Value.Type+"   BreakPrice: "+z.Value.BreakPrice+"   EndABar: "+z.Value.EndABar);
						if(z.Value.Type=='R') {
							if(CheckForZoneBreak(pBreakBasis, z.Value, Highs[0][0], Lows[0][0], Closes[0][0])) {
								z.Value.BrokenABar = CurrentBars[0];
//if(c)Print("      R zone    BrokenABar: "+z.Value.BrokenABar+"   time: "+Times[0][0].ToString());
	//Draw.Diamond(this,"Broken"+z.Key, false,0,z.Value.BreakPrice,Brushes.Magenta);
								z.Value.Status = 'B';
								RemoveZoneIfNecessary(z.Value, z.Key);
								B_Updated = true;
							}else if(Highs[0][0] > z.Value.BotPrice && z.Value.Status=='F'){
								z.Value.Status = 'T';
								RemoveZoneIfNecessary(z.Value, z.Key);
								z.Value.TestedABar = CurrentBars[0];
								T_Updated = true;
							}
							if(z.Value.Status=='B'){
								if(Lows[0][0] > z.Value.TopPrice) z.Value.DeadEnabled = true;//This zone is now a candidate to become Dead
								if(((pTerminateOnBroken || z.Value.DeadEnabled) && CheckForDeadBreak(pBreakBasis, z.Value, Highs[0][0], Lows[0][0], Closes[0][0]))){
									z.Value.EndABar = CurrentBars[0];
//if(c)Print("      R zone    EndABar: "+z.Value.EndABar+"   time: "+Times[0][0].ToString());
									z.Value.Status = 'D';
									RemoveZoneIfNecessary(z.Value, z.Key);
									D_Updated = true;
								}
							}
						}
						else if(z.Value.Type=='S') {
							if(CheckForZoneBreak(pBreakBasis, z.Value, Highs[0][0], Lows[0][0], Closes[0][0])) {
								z.Value.BrokenABar = CurrentBars[0];
//if(c)Print("      S zone    BrokenABar: "+z.Value.BrokenABar+"   time: "+Times[0][0].ToString());
								z.Value.Status = 'B';
								RemoveZoneIfNecessary(z.Value, z.Key);
								B_Updated = true;
							}else if(Lows[0][0] < z.Value.TopPrice && z.Value.Status=='F'){
//Draw.Diamond(this,"Tested"+z.Key, false,0,z.Value.TopPrice,Brushes.Magenta);
								z.Value.Status = 'T';
								RemoveZoneIfNecessary(z.Value, z.Key);
								z.Value.TestedABar = CurrentBars[0];
								T_Updated = true;
							}
							if(z.Value.Status=='B'){
								if(Highs[0][0] < z.Value.BotPrice) z.Value.DeadEnabled = true;//This zone is now a candidate to become Dead
								if(((pTerminateOnBroken || z.Value.DeadEnabled) && CheckForDeadBreak(pBreakBasis, z.Value, Highs[0][0], Lows[0][0], Closes[0][0]))){
									z.Value.EndABar = CurrentBars[0];
//if(c)Print("      S zone    EndABar: "+z.Value.EndABar+"   time: "+Times[0][0].ToString());
									z.Value.Status = 'D';
									RemoveZoneIfNecessary(z.Value, z.Key);
									D_Updated = true;
								}
							}
						}
						if(IsRealTime){
#if INCLUDE_GLOBALIZATION
//							if(z.Value.Status == 'F' && pGlobalizeFreshZones && F_Updated)  DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin ? z.Key:z.Value.ConfirmedABar);
							if(z.Value.Status == 'T' && pGlobalizeTestedZones && T_Updated) DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin ? z.Key:z.Value.ConfirmedABar);
							if(z.Value.Status == 'B' && pGlobalizeBrokenZones && B_Updated) DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin ? z.Key:z.Value.ConfirmedABar);
							if(z.Value.Status == 'D' && pGlobalizeDeadZones && D_Updated)   DrawGlobalZone(z.Value, this.pBackfillZonesToOrigin ? z.Key:z.Value.ConfirmedABar);
#endif
						}
						T_Updated = false;
						B_Updated = false;
						D_Updated = false;
					}
					#endregion
				}else if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction){
					#region -- Update existing globalized F and T zones on the first tick of a bar --
#if INCLUDE_GLOBALIZATION
					if(IsRealTime && IsFirstTickOfBar && (pGlobalizeFreshZones || pGlobalizeTestedZones)){
						if(pGlobalizeFreshZones){
							var zo = Zones.Where(k=>k.Value.Status == 'F' && k.Value.ConfirmedABar>0 && k.Value.ConfirmedABar < CurrentBars[0]).ToList();
							foreach(var z in zo) DrawGlobalZone(z.Value, z.Key);
						}
						if(pGlobalizeTestedZones){
							var zo = Zones.Where(k=>k.Value.Status == 'T').ToList();
							foreach(var z in zo) {
//if(z.Key>BarsArray[0].Count-20) Print(z.Key+" "+Times[0].GetValueAt(z.Key).ToString()+"   top: "+z.Value.TopPrice+" / Bot: "+z.Value.BotPrice);
								DrawGlobalZone(z.Value, z.Key);
							}
						}
					}
#endif
					#endregion
					var zones = Zones.Where(k=>k.Value.Status != 'D' && k.Value.ConfirmedABar>0 && k.Value.ConfirmedABar < CurrentBars[0]).ToList();
					#region -- Update status for PriceAction (Basing) zones --
					foreach(var z in zones){
//DateTime t = Times[0].GetValueAt(z.Key);
//bool c = IsDebug && t.Day==28 && t.Month==9 && t.Hour==9 && t.Minute<10 && t.Minute>0 && z.Value.EndABar<0;
//if(z.Key>BarsArray[0].Count-6) Print(z.Key+" "+Times[0].GetValueAt(z.Key).ToString()+"   top: "+z.Value.TopPrice+" / Bot: "+z.Value.BotPrice+"  status: "+z.Value.Status);
						bool T_Updated = false;
						bool B_Updated = false;
//if(c)Print("\n"+z.Key+": "+t.ToString()+"  "+z.Value.Type+" zone    BreakPrice: "+z.Value.BreakPrice+"   EndABar: "+z.Value.EndABar);
						if(z.Value.Type=='R') {
							if(CheckForZoneBreak(pBreakBasis, z.Value, Highs[0][0], Lows[0][0], Closes[0][0])) {
								z.Value.BrokenABar = CurrentBars[0];
//Draw.Diamond(this,"Broken"+z.Key, false,0,z.Value.BreakPrice,Brushes.Magenta);
								z.Value.Status = 'B';
								RemoveZoneIfNecessary(z.Value, z.Key);
								z.Value.EndABar = CurrentBars[0];
//if(c)Print("      R zone    BrokenABar and Ended at: "+z.Value.BrokenABar+"   time: "+Times[0][0].ToString());
								B_Updated = true;
							}else if(Highs[0][0] > z.Value.BotPrice && z.Value.Status=='F'){
								z.Value.Status = 'T';
								RemoveZoneIfNecessary(z.Value, z.Key);
								z.Value.TestedABar = CurrentBars[0];
								T_Updated = true;
							}
						}
						else if(z.Value.Type=='S') {
							if(CheckForZoneBreak(pBreakBasis, z.Value, Highs[0][0], Lows[0][0], Closes[0][0])) {
								z.Value.BrokenABar = CurrentBars[0];
								z.Value.Status = 'B';
								RemoveZoneIfNecessary(z.Value, z.Key);
								z.Value.EndABar = CurrentBars[0];
//if(c)Print("      S zone    BrokenABar and Ended at: "+z.Value.BrokenABar+"   time: "+Times[0][0].ToString());
								B_Updated = true;
							}else if(Lows[0][0] < z.Value.TopPrice && z.Value.Status=='F'){
//Draw.Diamond(this,"Tested"+z.Key, false,0,z.Value.TopPrice,Brushes.Magenta);
								z.Value.Status = 'T';
								RemoveZoneIfNecessary(z.Value, z.Key);
								z.Value.TestedABar = CurrentBars[0];
								T_Updated = true;
							}
						}
						if(IsRealTime){
							//if(z.Value.Status == 'F' && pGlobalizeFreshZones)  DrawGlobalZone(z.Value, z.Key);
//if(z.Key==421) Print(z.Key+"  Zones[421].Status: "+z.Value.Status+"   z.Value.Status: "+z.Value.Status);
#if INCLUDE_GLOBALIZATION
							if(pGlobalizeTestedZones && T_Updated){
//if(z.Key==421) Print(z.Key+"  Drawing global rectangle: "+z.Value.Status);
								DrawGlobalZone(z.Value, z.Key);
								//else Draw.Rectangle(this, z.Value.Tag, 5, z.Value.TopPrice, 0, z.Value.BotPrice, true, "Default");

							}
							if(pGlobalizeBrokenZones && B_Updated) DrawGlobalZone(z.Value, z.Key);
#endif
						}
						T_Updated = false;
						B_Updated = false;
					}
					#endregion
				}
#if INCLUDE_GLOBALIZATION
				if(pGlobalizeTestedZones){
					var dotags = DrawObjects.Select(k=>k.Tag).ToList();
					var Tz = Zones.Where(k=>k.Value.Status == 'T' && !dotags.Contains(string.Format("@{0}",k.Value.Tag))).ToList();
					foreach(var z in Tz){
					//Print("Rect should be drawn, but is not: "+z.Value.Tag+"  "+z.Value.Status+"  tested bar: "+z.Value.TestedABar);
						DrawGlobalZone(z.Value, z.Key);
					}
				}
#endif
				#endregion
line=1802;
				#region -- Update Structure bias --
				int cutoffIdx = int.MinValue;
				int cb = CurrentBars[0];
				if(State==State.Historical) cb = Bars.Count;
				if(SwingHighABars.Count>1 && SwingLowABars.Count>1){
					double h1 = SwingHighABars[1].Item2;
					double L1 = SwingLowABars[1].Item2;

					if(Highs[0][0] > h1)     structureBiasState[0] = LONG; //swing nodes rising?  Initial filter is LONG, now check to see if price pushed down
					else if(Lows[0][0] < L1) structureBiasState[0] = SHORT;//swing nodes falling?  Initial filter is SHORT, now check to see if price pushed up

					if(structureBiasState[0]      == LONG  && Lows[0][0]  < L1) structureBiasState[0] = SHORT;//if the low goes below the prior swing low, we're SHORT filtering
					else if(structureBiasState[0] == SHORT && Highs[0][0] > h1) structureBiasState[0] = LONG;//if the high goes above the prior swing high, we're LONG filtering
				}
	            #endregion
			}

}catch(Exception ex){PrintDebug(line+": "+ex.ToString());}
		}
		//=======================================================================================
		private int FindMostRecentDownClosingBar(int StartABar, int MaxLookback, ref double HighestClose){
			int result = StartABar;
			while(result > MaxLookback+2 && Closes[0].GetValueAt(result) > Opens[0].GetValueAt(result)){
				HighestClose = Math.Max(HighestClose, Closes[0].GetValueAt(result));
				result--;
			}
			if(StartABar-result > MaxLookback) return int.MinValue;
			return result;
		}
		//=======================================================================================
		private int FindMostRecentUpClosingBar(int StartABar, int MaxLookback, ref double LowestClose){
			int result = StartABar;
			while(result > MaxLookback+2 && Closes[0].GetValueAt(result) < Opens[0].GetValueAt(result)){
				LowestClose = Math.Min(LowestClose, Closes[0].GetValueAt(result));
				result--;
			}
			if(StartABar-result > MaxLookback) return int.MinValue;
			return result;
		}
		//=======================================================================================

		#region -- DrawSpecificMarkerType --
		private string DrawSpecificMarkerType(int Signal_ID, ARC_Uni_Zones_MarkerType MarkerType, char Type, char Dir, int abar, double price, Brush clr){
			if(ChartControl == null) return null;
			var t = Times[0].GetValueAt(abar);
			var info = Type == 'A'? "Aggr":"Cons";
			var tag = string.Format("wh_{0}_{1}_{2}-w{3}", abar, info, Dir, Math.Abs(Signal_ID));
			if(IsFirstTickOfBar) TagsDrawn.Clear();
			if (ChartControl.Dispatcher.CheckAccess()) {
//PrintDebug("CheckAccess = true  Dir: "+Dir);
				if(MarkerType == ARC_Uni_Zones_MarkerType.Dot){
					Draw.Dot(this, tag, true, t, price, clr);
					TagsDrawn.Add(tag);
				}else if(MarkerType == ARC_Uni_Zones_MarkerType.Diamond){
					Draw.Diamond(this, tag, true, t, price, clr);
					TagsDrawn.Add(tag);
				}else if(MarkerType == ARC_Uni_Zones_MarkerType.Square){
					Draw.Square(this, tag, true, t, price, clr);
					TagsDrawn.Add(tag);
				}else if(MarkerType == ARC_Uni_Zones_MarkerType.Arrow){
					if(Dir=='L')
						Draw.ArrowUp(this, tag, true, t, price, clr);
					else
						Draw.ArrowDown(this, tag, true, t, price, clr);
					TagsDrawn.Add(tag);
				}else if(MarkerType == ARC_Uni_Zones_MarkerType.Triangle){
					if(Dir=='L')
						Draw.TriangleUp(this, tag, true, t, price, clr);
					else
						Draw.TriangleDown(this, tag, true, t, price, clr);
					TagsDrawn.Add(tag);
				}
			}else{
				Dispatcher.BeginInvoke(new Action(() =>
				{
//PrintDebug("CheckAccess = false  Dir: "+Dir);
					if(MarkerType == ARC_Uni_Zones_MarkerType.Dot){
						TriggerCustomEvent(o2 =>{	
							Draw.Dot(this, tag, true, t, price, clr);
						},0,null);
						TagsDrawn.Add(tag);
					}else if(MarkerType == ARC_Uni_Zones_MarkerType.Diamond){
						TriggerCustomEvent(o2 =>{	
							Draw.Diamond(this, tag, true, t, price, clr);
						},0,null);
						TagsDrawn.Add(tag);
					}else if(MarkerType == ARC_Uni_Zones_MarkerType.Square){
						TriggerCustomEvent(o2 =>{	
							Draw.Square(this, tag, true, t, price, clr);
						},0,null);
						TagsDrawn.Add(tag);
					}else if(MarkerType == ARC_Uni_Zones_MarkerType.Arrow){
						if(Dir=='L')
							TriggerCustomEvent(o2 =>{	
								Draw.ArrowUp(this, tag, true, t, price, clr);
							},0,null);
						else
							TriggerCustomEvent(o2 =>{	
								Draw.ArrowDown(this, tag, true, t, price, clr);
							},0,null);
						TagsDrawn.Add(tag);
					}else if(MarkerType == ARC_Uni_Zones_MarkerType.Triangle){
						if(Dir=='L')
							TriggerCustomEvent(o2 =>{	
								Draw.TriangleUp(this, tag, true, t, price, clr);
							},0,null);
						else
							TriggerCustomEvent(o2 =>{	
								Draw.TriangleDown(this, tag, true, t, price, clr);
							},0,null);
						TagsDrawn.Add(tag);
					}
				}));
			}

			return tag;
		}
		#endregion
		private string timeofday(DateTime t){
			var s = t.TimeOfDay.ToString().ToCharArray();
			int i = s.Length-1;
			while(i>0 && s[i]=='0') {s[i]=' '; i--;}
			var sb = new StringBuilder();
			sb.Append(s);
			return sb.ToString().Trim();
		}
		private string GetNodeType(byte type){
			if(type == HH) return "HH";
			if(type == HL) return "HL";
			if(type == LH) return "LH";
			if(type == LL) return "LL";
			return "";
		}
		private string GetNodeType(int nodeid){
			if(NodeTypes[nodeid].Item2 == HH) return "HH";
			if(NodeTypes[nodeid].Item2 == HL) return "HL";
			if(NodeTypes[nodeid].Item2 == LH) return "LH";
			if(NodeTypes[nodeid].Item2 == LL) return "LL";
			return "";
		}
//=================================================================================================================
		private void DrawGlobalZone(Zone z, int LeftAbarOfRectangle){
			#region -- DrawGlobalZone --
#if INCLUDE_GLOBALIZATION
//Print("In zone? "+inzone.ToString());
			if(State != State.Realtime) return;
			var lefttime = Times[0].GetValueAt(LeftAbarOfRectangle);
			var righttime = BarsArray[0].LastBarTime;//Times[0][0];
//if(inzone)Print(LeftAbarOfRectangle+":  Status: "+z.Status+"   lefttime: "+lefttime+"   righttime: "+righttime+"  top: "+z.TopPrice+" bot: "+z.BotPrice);
			if(z.EndABar > 0) righttime = Times[0].GetValueAt(z.EndABar);
			string tplname = "Default";
			if(z.Status == 'F' && z.Type=='R') tplname = pFreshResistanceRectangleTemplate;
			if(z.Status == 'F' && z.Type=='S') tplname = pFreshSupportRectangleTemplate;
			if(z.Status == 'T' && z.Type=='R') tplname = pTestedResistanceRectangleTemplate;
			if(z.Status == 'T' && z.Type=='S') tplname = pTestedSupportRectangleTemplate;
			if(z.Status == 'B' && z.Type=='R') tplname = pBrokenResistanceRectangleTemplate;
			if(z.Status == 'B' && z.Type=='S') tplname = pBrokenSupportRectangleTemplate;
			if(z.Status == 'D' && z.Type=='R') tplname = pDeadResistanceRectangleTemplate;
			if(z.Status == 'D' && z.Type=='S') tplname = pDeadSupportRectangleTemplate;
//Print("zone tag: "+z.Tag);
			if (ChartControl.Dispatcher.CheckAccess()) {
//Print("CheckAccess is TRUE");
				Draw.Rectangle(this, z.Tag, lefttime, z.TopPrice, righttime, z.BotPrice, true, tplname);
			}else{
				//Dispatcher.BeginInvoke(new Action(() =>
				//{
//Print("CheckAccess is FALSE");
					TriggerCustomEvent(o2 =>{
						Draw.Rectangle(this, z.Tag, lefttime, z.TopPrice, righttime, z.BotPrice, true, tplname);
					},0,null);
				//}));
			}
#endif
			#endregion
		}
		private void RemoveZoneIfNecessary(Zone z, int key){
#if INCLUDE_GLOBALIZATION
			if(z.Status=='F' && !pGlobalizeFreshZones) 
				RemoveDrawObject(z.Tag);
			else if(z.Status=='T' && !pGlobalizeTestedZones)
				RemoveDrawObject(z.Tag);
			else if(z.Status=='B' && !pGlobalizeBrokenZones)
				RemoveDrawObject(z.Tag);
			else if(z.Status=='D' && !pGlobalizeDeadZones)
				RemoveDrawObject(z.Tag);
#endif
		}

//=================================================================================================================
//=================================================================================================================
		#region -- SharpDX brushes and vectors --
		private SharpDX.Direct2D1.Brush UpBkgBrushDX      = null;
		private SharpDX.Direct2D1.Brush DownBkgBrushDX    = null;
		private SharpDX.Direct2D1.Brush HTFUpBkgBrushDX   = null;
		private SharpDX.Direct2D1.Brush HTFDownBkgBrushDX = null;
		private SharpDX.Direct2D1.Brush WhiteBrushDX      = null;
		private SharpDX.Direct2D1.Brush DarkBlueBrushDX   = null;
		private SharpDX.Direct2D1.Brush DarkGreenBrushDX  = null;
		private SharpDX.Direct2D1.Brush DimGrayBrushDX    = null;
		private SharpDX.Direct2D1.Brush DarkRedBrushDX    = null;
		private SharpDX.Direct2D1.Brush PinkBrushDX       = null;
		private SharpDX.Direct2D1.Brush ZigZagUpBrushDX   = null;
		private SharpDX.Direct2D1.Brush ZigZagDnBrushDX   = null;

		private SharpDX.Direct2D1.Brush FreshResOutline_BrushDX = null;
		private SharpDX.Direct2D1.Brush FreshSupOutline_BrushDX = null;
		private SharpDX.Direct2D1.Brush BrokenResOutline_BrushDX = null;
		private SharpDX.Direct2D1.Brush BrokenSupOutline_BrushDX = null;
		private SharpDX.Direct2D1.Brush TestedResOutline_BrushDX = null;
		private SharpDX.Direct2D1.Brush TestedSupOutline_BrushDX = null;
		private SharpDX.Direct2D1.Brush DeadResOutline_BrushDX = null;
		private SharpDX.Direct2D1.Brush DeadSupOutline_BrushDX = null;

		private SharpDX.Direct2D1.Brush FreshRes_BrushDX = null;
		private SharpDX.Direct2D1.Brush FreshSup_BrushDX = null;
		private SharpDX.Direct2D1.Brush BrokenRes_BrushDX = null;
		private SharpDX.Direct2D1.Brush BrokenSup_BrushDX = null;
		private SharpDX.Direct2D1.Brush TestedRes_BrushDX = null;
		private SharpDX.Direct2D1.Brush TestedSup_BrushDX = null;
		private SharpDX.Direct2D1.Brush DeadRes_BrushDX = null;
		private SharpDX.Direct2D1.Brush DeadSup_BrushDX = null;

		SharpDX.Vector2 v0 = new SharpDX.Vector2(0,0);
		SharpDX.Vector2 v1 = new SharpDX.Vector2(0,0);
		#endregion

	protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
		#region -- OnRender --
line=1;
//try{
#if DoLicense
		if(!ValidLicense) return;
#endif
		if (!IsVisible) return;
		if(RenderTarget == null) return;

		//base.OnRender(chartControl, chartScale);
		SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
		RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
		int lmab = Math.Max(3, ChartBars.FromIndex);
		int rmab = Math.Min(BarsArray[0].Count-1, ChartBars.ToIndex);
//		var textFormat = this.pTrendBandFont.ToDirectWriteTextFormat();
		int x1=0, y0=0, y1=0;

		if(pShowFreshZones || pShowTestedZones || pShowBrokenZones || pShowDeadZones){
			var keys = Zones.Where(
					k=>k.Key < rmab && k.Key>FirstPermittedABar && k.Value.BotPrice < chartScale.MaxValue
					&& k.Value.TopPrice > chartScale.MinValue
					&& (k.Value.EndABar<0 || k.Value.EndABar > lmab)
					&& (
						   (k.Value.Status=='F' && pShowFreshZones)
						|| (k.Value.Status=='T' && pShowTestedZones)
						|| (k.Value.Status=='B' && pShowBrokenZones)
						|| (k.Value.Status=='D' && pShowDeadZones)
					)
				).Select(k=>k.Key).ToList();
			foreach(var k in keys){
//var dt = Times[0].GetValueAt(k);
//var iz = (dt>dd && dt<dd1 && Zones[k].TopPrice == 12312.75);
//Print("Zones["+Times[0].GetValueAt(k).ToString()+"] "+Zones[k].Status+"  "+Zones[k].TopPrice+"  BreakPrice "+Zones[k].BreakPrice+"  Top/BotPrice "+Zones[k].TopPrice+"/"+Zones[k].BotPrice);
				int zone_lmb = pBackfillZonesToOrigin||pZoneCalcMode==ARC_Uni_Zones_ZoneCalcModes.PriceAction ? k :Zones[k].ConfirmedABar;
//if(iz){
//	Print(dt.ToString()+"   Top: "+Zones[k].TopPrice);
//	Print(" zone_lmb: "+zone_lmb);
//	Print("   key ABar: "+k+"  ConfirmedABar: "+Zones[k].ConfirmedABar);
//}
				x1 = Math.Max(0, ChartControl.GetXByBarIndex (ChartBars, zone_lmb));
				y1 = chartScale.GetYByValue      (Zones[k].TopPrice);
				float h = chartScale.GetYByValue(Zones[k].BotPrice) - y1;
				float w = Zones[k].EndABar<0? ChartPanel.W : ChartControl.GetXByBarIndex (ChartBars, Zones[k].EndABar) - x1;
				var rect = new SharpDX.RectangleF(x1, y1, w, h);
				switch(Zones[k].Status){
					case 'F': 
						switch(Zones[k].Type){
							case 'S': 
								if(pFreshSupOutline_Width>0) RenderTarget.DrawRectangle(rect, FreshSupOutline_BrushDX, pFreshSupOutline_Width);
								RenderTarget.FillRectangle(new SharpDX.RectangleF(x1, y1, w, h), FreshSup_BrushDX);
								break;
							case 'R':
								if(pFreshResOutline_Width>0) RenderTarget.DrawRectangle(rect, FreshResOutline_BrushDX, pFreshResOutline_Width);
								RenderTarget.FillRectangle(new SharpDX.RectangleF(x1, y1, w, h), FreshRes_BrushDX);
								break;
						}
						break;
					case 'T': 
						switch(Zones[k].Type){
							case 'S': 
								if(pTestedSupOutline_Width>0) RenderTarget.DrawRectangle(rect, TestedSupOutline_BrushDX, pTestedSupOutline_Width);
								RenderTarget.FillRectangle(rect, TestedSup_BrushDX);
								break;
							case 'R':
								if(pTestedResOutline_Width>0) RenderTarget.DrawRectangle(rect, TestedResOutline_BrushDX, pTestedResOutline_Width);
								RenderTarget.FillRectangle(rect, TestedRes_BrushDX);
								break;
						}
						break;
					case 'B':
						switch(Zones[k].Type){
							case 'S': 
								if(pBrokenSupOutline_Width>0) RenderTarget.DrawRectangle(rect, BrokenSupOutline_BrushDX, pBrokenSupOutline_Width);
								RenderTarget.FillRectangle(rect, BrokenSup_BrushDX);
								break;
							case 'R':
								if(pBrokenResOutline_Width>0) RenderTarget.DrawRectangle(rect, BrokenResOutline_BrushDX, pBrokenResOutline_Width);
								RenderTarget.FillRectangle(rect, BrokenRes_BrushDX);
								break;
						}
						break;
					case 'D': 
						switch(Zones[k].Type){
							case 'S': 
								if(pDeadSupOutline_Width>0) RenderTarget.DrawRectangle(rect, DeadSupOutline_BrushDX, pBrokenSupOutline_Width);
								RenderTarget.FillRectangle(rect, DeadSup_BrushDX);
								break;
							case 'R': 
								if(pDeadResOutline_Width>0) RenderTarget.DrawRectangle(rect, DeadResOutline_BrushDX, pBrokenResOutline_Width);
								RenderTarget.FillRectangle(rect, DeadRes_BrushDX);
								break;
						}
						break;
				}
			}
		}
		if(pShowZigzagLegs && SwingHighABars!=null && SwingLowABars!=null){
			#region -- Show zigzag lines --
			int idxH = SwingHighABars.Count-1;
			int idxL = SwingLowABars.Count-1;
			var SwingH = SwingHighABars.Where(k=>k.Item1 < lmab).ToList();//this selects the swing abar which is just off the left edge of the chart
			var SwingL = SwingLowABars.Where(k=>k.Item1 < lmab).ToList();//this selects the swing abar which is just off the left edge of the chart
			if(SwingH != null) idxH = idxH-(SwingH.Count-1);
			if(SwingL != null) idxL = idxL-(SwingL.Count-1);
			var Dict = new SortedDictionary<int,Tuple<char,double>>();
//PrintDebug("Highs.Count: "+SwingHighABars.Count+"  idxH: "+idxH);
			for(int i = 0; i<idxH; i++){
				Dict[SwingHighABars[i].Item1] = new Tuple<char,double>('H',SwingHighABars[i].Item2);
			}
			for(int i = 0; i<idxL; i++){
//PrintDebug("Lows "+i);
				Dict[SwingLowABars[i].Item1]  = new Tuple<char,double>('L',SwingLowABars[i].Item2);
			}

			char type = SwingHighABars[0].Item1 < SwingLowABars[0].Item1 ? 'H' : 'L';//the first swing node, is it a High swing or a Low swing?
//try{
			v0.X = 0; v0.Y=0;
			v1.X = float.MinValue; v1.Y=0;
			foreach(var kvp in Dict){
				if(kvp.Value.Item1 == 'H'){//this is an uptrending swing line
					v0.X = v1.X;
					v0.Y = v1.Y;
					v1.X = ChartControl.GetXByBarIndex (ChartBars, kvp.Key);
					v1.Y = chartScale.GetYByValue      (kvp.Value.Item2);
					if(v0.X != float.MinValue) RenderTarget.DrawLine(v0, v1, ZigZagUpBrushDX, pSwingLegWidth);
				}else{//this is a downtrending swing line
					v0.X = v1.X;
					v0.Y = v1.Y;
					v1.X = ChartControl.GetXByBarIndex (ChartBars, kvp.Key);
					v1.Y = chartScale.GetYByValue      (kvp.Value.Item2);
					if(v0.X != float.MinValue) RenderTarget.DrawLine(v0, v1, ZigZagDnBrushDX, pSwingLegWidth);
				}
				if(kvp.Key > rmab) break;
			}
//}catch(Exception dd){PrintDebug(dd.ToString());}
			#endregion --------------------------------------------
		}
		RenderTarget.AntialiasMode = OSM;

		#endregion
//}catch(Exception eee){PrintDebug(line+": "+eee.ToString());}
	}
	public override void OnRenderTargetChanged()
	{
			#region -- OnRenderTargetChanged --
			if(FreshSupOutline_BrushDX!=null && !FreshSupOutline_BrushDX.IsDisposed)   FreshSupOutline_BrushDX.Dispose();   FreshSupOutline_BrushDX   = null;
			if(RenderTarget!=null){
				FreshSupOutline_BrushDX         = pFreshSupOutline_Brush.ToDxBrush(RenderTarget);
//				FreshSupOutline_BrushDX.Opacity = pFreshSupOutline_Opacity/100f;
			}
			if(FreshResOutline_BrushDX!=null && !FreshResOutline_BrushDX.IsDisposed)   FreshResOutline_BrushDX.Dispose();   FreshResOutline_BrushDX   = null;
			if(RenderTarget!=null){
				FreshResOutline_BrushDX         = pFreshResOutline_Brush.ToDxBrush(RenderTarget);
//				FreshResOutline_BrushDX.Opacity = pFreshResOutline_Opacity/100f;
			}
			if(FreshSup_BrushDX!=null && !FreshSup_BrushDX.IsDisposed)   FreshSup_BrushDX.Dispose();   FreshSup_BrushDX   = null;
			if(RenderTarget!=null){
				FreshSup_BrushDX         = pFreshSup_Brush.ToDxBrush(RenderTarget);
				FreshSup_BrushDX.Opacity = pFreshSup_Opacity/100f;
			}
			if(FreshRes_BrushDX!=null && !FreshRes_BrushDX.IsDisposed)   FreshRes_BrushDX.Dispose();   FreshRes_BrushDX   = null;
			if(RenderTarget!=null){
				FreshRes_BrushDX         = pFreshRes_Brush.ToDxBrush(RenderTarget);
				FreshRes_BrushDX.Opacity = pFreshRes_Opacity/100f;
			}

			if(TestedSupOutline_BrushDX!=null && !TestedSupOutline_BrushDX.IsDisposed)   TestedSupOutline_BrushDX.Dispose();   TestedSupOutline_BrushDX   = null;
			if(RenderTarget!=null){
				TestedSupOutline_BrushDX         = pTestedSupOutline_Brush.ToDxBrush(RenderTarget);
//				TestedSupOutline_BrushDX.Opacity = pTestedSupOutline_Opacity/100f;
			}
			if(TestedResOutline_BrushDX!=null && !TestedResOutline_BrushDX.IsDisposed)   TestedResOutline_BrushDX.Dispose();   TestedResOutline_BrushDX   = null;
			if(RenderTarget!=null){
				TestedResOutline_BrushDX         = pTestedResOutline_Brush.ToDxBrush(RenderTarget);
//				TestedResOutline_BrushDX.Opacity = pTestedResOutline_Opacity/100f;
			}

			if(TestedSup_BrushDX!=null && !TestedSup_BrushDX.IsDisposed)   TestedSup_BrushDX.Dispose();   TestedSup_BrushDX   = null;
			if(RenderTarget!=null){
				TestedSup_BrushDX         = pTestedSup_Brush.ToDxBrush(RenderTarget);
				TestedSup_BrushDX.Opacity = pTestedSup_Opacity/100f;
			}
			if(TestedRes_BrushDX!=null && !TestedRes_BrushDX.IsDisposed)   TestedRes_BrushDX.Dispose();   TestedRes_BrushDX   = null;
			if(RenderTarget!=null){
				TestedRes_BrushDX         = pTestedRes_Brush.ToDxBrush(RenderTarget);
				TestedRes_BrushDX.Opacity = pTestedRes_Opacity/100f;
			}

			if(BrokenSupOutline_BrushDX!=null && !BrokenSupOutline_BrushDX.IsDisposed)   BrokenSupOutline_BrushDX.Dispose();   BrokenSupOutline_BrushDX   = null;
			if(RenderTarget!=null){
				BrokenSupOutline_BrushDX         = pBrokenSupOutline_Brush.ToDxBrush(RenderTarget);
//				BrokenSupOutline_BrushDX.Opacity = pBrokenSupOutline_Opacity/100f;
			}
			if(BrokenResOutline_BrushDX!=null && !BrokenResOutline_BrushDX.IsDisposed)   BrokenResOutline_BrushDX.Dispose();   BrokenResOutline_BrushDX   = null;
			if(RenderTarget!=null){
				BrokenResOutline_BrushDX         = pBrokenResOutline_Brush.ToDxBrush(RenderTarget);
//				BrokenResOutline_BrushDX.Opacity = pBrokenResOutline_Opacity/100f;
			}

			if(BrokenSup_BrushDX!=null && !BrokenSup_BrushDX.IsDisposed)   BrokenSup_BrushDX.Dispose();   BrokenSup_BrushDX   = null;
			if(RenderTarget!=null){
				BrokenSup_BrushDX         = pBrokenSup_Brush.ToDxBrush(RenderTarget);
				BrokenSup_BrushDX.Opacity = pBrokenSup_Opacity/100f;
			}
			if(BrokenRes_BrushDX!=null && !BrokenRes_BrushDX.IsDisposed)   BrokenRes_BrushDX.Dispose();   BrokenRes_BrushDX   = null;
			if(RenderTarget!=null){
				BrokenRes_BrushDX         = pBrokenRes_Brush.ToDxBrush(RenderTarget);
				BrokenRes_BrushDX.Opacity = pBrokenRes_Opacity/100f;
			}

			if(DeadSupOutline_BrushDX!=null && !DeadSupOutline_BrushDX.IsDisposed)   DeadSupOutline_BrushDX.Dispose();   DeadSupOutline_BrushDX   = null;
			if(RenderTarget!=null){
				DeadSupOutline_BrushDX         = pDeadSupOutline_Brush.ToDxBrush(RenderTarget);
//				DeadSupOutline_BrushDX.Opacity = pDeadSupOutline_Opacity/100f;
			}
			if(DeadResOutline_BrushDX!=null && !DeadResOutline_BrushDX.IsDisposed)   DeadResOutline_BrushDX.Dispose();   DeadResOutline_BrushDX   = null;
			if(RenderTarget!=null){
				DeadResOutline_BrushDX         = pDeadResOutline_Brush.ToDxBrush(RenderTarget);
//				DeadResOutline_BrushDX.Opacity = pDeadResOutline_Opacity/100f;
			}
			if(DeadSup_BrushDX!=null && !DeadSup_BrushDX.IsDisposed)   DeadSup_BrushDX.Dispose();   DeadSup_BrushDX   = null;
			if(RenderTarget!=null){
				DeadSup_BrushDX         = pDeadSup_Brush.ToDxBrush(RenderTarget);
				DeadSup_BrushDX.Opacity = pDeadSup_Opacity/100f;
			}
			if(DeadRes_BrushDX!=null && !DeadRes_BrushDX.IsDisposed)   DeadRes_BrushDX.Dispose();   DeadRes_BrushDX   = null;
			if(RenderTarget!=null){
				DeadRes_BrushDX         = pDeadRes_Brush.ToDxBrush(RenderTarget);
				DeadRes_BrushDX.Opacity = pDeadRes_Opacity/100f;
			}
//			if(dx!=null && !dx.IsDisposed)   dx.Dispose();   dx   = null;
//			if(RenderTarget!=null){
//				dx         = dx.ToDxBrush(RenderTarget);
//				dx.Opacity = dx_Opacity/100f;
//			}
			
			if(DarkGreenBrushDX!=null && !DarkGreenBrushDX.IsDisposed)	DarkGreenBrushDX.Dispose();	DarkGreenBrushDX=null;
			if(RenderTarget!=null) DarkGreenBrushDX = Brushes.DarkGreen.ToDxBrush(RenderTarget);

			if(WhiteBrushDX!=null && !WhiteBrushDX.IsDisposed)      WhiteBrushDX.Dispose();       WhiteBrushDX = null;
			if(RenderTarget!=null) WhiteBrushDX    = Brushes.White.ToDxBrush(RenderTarget);

			if(PinkBrushDX!=null	&& !PinkBrushDX.IsDisposed)    PinkBrushDX.Dispose();   PinkBrushDX    = null;
			if(RenderTarget!=null) PinkBrushDX  = Brushes.Pink.ToDxBrush(RenderTarget);

			if(DarkRedBrushDX!=null	&& !DarkRedBrushDX.IsDisposed)    DarkRedBrushDX.Dispose();   DarkRedBrushDX    = null;
			if(RenderTarget!=null) DarkRedBrushDX  = Brushes.DarkRed.ToDxBrush(RenderTarget);

			if(DimGrayBrushDX!=null && !DimGrayBrushDX.IsDisposed)		DimGrayBrushDX.Dispose(); DimGrayBrushDX = null;
			if(RenderTarget!=null) DimGrayBrushDX = Brushes.DimGray.ToDxBrush(RenderTarget);

			if(DarkBlueBrushDX!=null && !DarkBlueBrushDX.IsDisposed)   DarkBlueBrushDX.Dispose(); DarkBlueBrushDX = null;
			if(RenderTarget!=null) DarkBlueBrushDX = Brushes.DarkBlue.ToDxBrush(RenderTarget);

			if(ZigZagUpBrushDX!=null && !ZigZagUpBrushDX.IsDisposed)	 ZigZagUpBrushDX.Dispose();	  ZigZagUpBrushDX = null;
			if(RenderTarget!=null) ZigZagUpBrushDX = pRisingZZlegBrush.ToDxBrush(RenderTarget);

			if(ZigZagDnBrushDX!=null && !ZigZagDnBrushDX.IsDisposed)	 ZigZagDnBrushDX.Dispose();	  ZigZagDnBrushDX = null;
			if(RenderTarget!=null) ZigZagDnBrushDX = pFallingZZlegBrush.ToDxBrush(RenderTarget);

			#endregion
	}

	#region Plots

//		[Browsable(false)]
//		[XmlIgnore()]
//		public Series<double> BuyStop
//		{
//			get { return Values[0]; }
//		}
//		[Browsable(false)]
//		[XmlIgnore()]
//		public Series<double> SellStop
//		{
//			get { return Values[1]; }
//		}

//		[Browsable(false)]
//		[XmlIgnore()]
//		public Series<double> BuyMkt
//		{
//			get { return Values[2]; }
//		}
//		[Browsable(false)]
//		[XmlIgnore()]
//		public Series<double> SellMkt
//		{
//			get { return Values[3]; }
//		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> MA
		{
			get { return Values[0]; }
		}
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> HTFMA
		{
			get { return Values[1]; }
		}
		#endregion

		#region -- Properties --
        [RefreshProperties(RefreshProperties.All)]
		[Display(Order = 10, Name = "Zone calculation mode", GroupName = "Parameters", Description = "")]
		public ARC_Uni_Zones_ZoneCalcModes pZoneCalcMode		{get;set;}

		#region -- PriceAction Params --
		[Range(1, 100)]
		[Display(Order = 10, Name = "Max Body Pct", GroupName = "S&D Params", Description="Max body height as a percentage of the Hi-Lo range of that bar", ResourceType = typeof(Custom.Resource))]
		public int pMaxBodyPct				{ get; set; }

		[Display(Order = 20, Name = "S&D Zone size", GroupName = "PriceAction Params", Description="", ResourceType = typeof(Custom.Resource))]
		public ARC_Uni_Zones_BasingZoneSizeBasis pBasingZoneSizeBasis		{ get; set; }

		[XmlIgnore]
		[Display(Order = 30, Name = "Basing Bar Up Close", GroupName = "PriceAction Params")]
		public Brush pBasingBarUpBrush
		{ get; set; }
				[Browsable(false)]
				public string pBasingBarUpBrushSerializable { get { return Serialize.BrushToString(pBasingBarUpBrush); } set { pBasingBarUpBrush = Serialize.StringToBrush(value); }        }
		[Range(0, 100)]
		[Display(Order = 31, Name = "Basing Bar Up Opacity", GroupName = "PriceAction Params", Description="", ResourceType = typeof(Custom.Resource))]
		public int pBasingBarUpOpacity				{ get; set; }

		[XmlIgnore]
		[Display(Order = 32, Name = "Basing Bar Down Close", GroupName = "PriceAction Params")]
		public Brush pBasingBarDownBrush
		{ get; set; }
				[Browsable(false)]
				public string pBasingBarDownBrushSerializable { get { return Serialize.BrushToString(pBasingBarDownBrush); } set { pBasingBarDownBrush = Serialize.StringToBrush(value); }        }

		[Range(0, 100)]
		[Display(Order = 33, Name = "Basing Bar Down Opacity", GroupName = "PriceAction Params", Description="", ResourceType = typeof(Custom.Resource))]
		public int pBasingBarDownOpacity				{ get; set; }

		#region -- ThrustBar up/down color/opacity --
		[XmlIgnore]
		[Display(Order = 40, Name = "Thrust Bar Up Close", GroupName = "PriceAction Params")]
		public Brush pThrustBarUpBrush
		{ get; set; }
				[Browsable(false)]
				public string pThrustBarUpBrushSerializable { get { return Serialize.BrushToString(pThrustBarUpBrush); } set { pThrustBarUpBrush = Serialize.StringToBrush(value); }        }
		[Range(0, 100)]
		[Display(Order = 41, Name = "Thrust Bar Up Opacity", GroupName = "PriceAction Params", Description="", ResourceType = typeof(Custom.Resource))]
		public int pThrustBarUpOpacity				{ get; set; }

		[XmlIgnore]
		[Display(Order = 42, Name = "Thrust Bar Down Close", GroupName = "PriceAction Params")]
		public Brush pThrustBarDownBrush
		{ get; set; }
				[Browsable(false)]
				public string pThrustBarDownBrushSerializable { get { return Serialize.BrushToString(pThrustBarDownBrush); } set { pThrustBarDownBrush = Serialize.StringToBrush(value); }        }

		[Range(0, 100)]
		[Display(Order = 43, Name = "Thrust Bar Down Opacity", GroupName = "PriceAction Params", Description="", ResourceType = typeof(Custom.Resource))]
		public int pThrustBarDownOpacity				{ get; set; }
		#endregion

		[Display(Order = 50, Name = "Show S&D Zones?", GroupName = "PriceAction Params", Description="", ResourceType = typeof(Custom.Resource))]
		public bool pShowSandDZones {get;set;}

		[Display(Order = 60, Name = "Show Orderblock Zones?", GroupName = "PriceAction Params", Description="", ResourceType = typeof(Custom.Resource))]
		public bool pShowOrderblockZones {get;set;}
		#endregion

		#region -- Orderblock up/down color/opacity --
		[Display(Order = 70, Name = "Thrust bars delay", GroupName = "PriceAction Params", Description = "How many extra bars are permitted on OrderBlocks, between basing bar and the Thrust bar")]
		public int pThrustBarsDelay {get;set;}

		[XmlIgnore]
		[Display(Order = 71, Name = "Orderblock Bar Up Close", GroupName = "PriceAction Params")]
		public Brush pOrderblockBarUpBrush
		{ get; set; }
				[Browsable(false)]
				public string pOrderblockBarUpBrushSerializable { get { return Serialize.BrushToString(pOrderblockBarUpBrush); } set { pOrderblockBarUpBrush = Serialize.StringToBrush(value); }        }
		[Range(0, 100)]
		[Display(Order = 72, Name = "Orderblock Bar Up Opacity", GroupName = "PriceAction Params", Description="", ResourceType = typeof(Custom.Resource))]
		public int pOrderblockBarUpOpacity				{ get; set; }

		[XmlIgnore]
		[Display(Order = 73, Name = "Orderblock Bar Down Close", GroupName = "PriceAction Params")]
		public Brush pOrderblockBarDownBrush
		{ get; set; }
				[Browsable(false)]
				public string pOrderblockBarDownBrushSerializable { get { return Serialize.BrushToString(pOrderblockBarDownBrush); } set { pOrderblockBarDownBrush = Serialize.StringToBrush(value); }        }

		[Range(0, 100)]
		[Display(Order = 74, Name = "Orderblock Bar Down Opacity", GroupName = "PriceAction Params", Description="", ResourceType = typeof(Custom.Resource))]
		public int pOrderblockBarDownOpacity				{ get; set; }
		#endregion


		#region -- Traps Params --
		[Display(Order = 10, Name = "Show Trap Zones?", GroupName = "Trap Params", Description="", ResourceType = typeof(Custom.Resource))]
		public bool pShowTrapZones {get;set;}
        [RefreshProperties(RefreshProperties.All)]
		[Display(Name="Measurement", Description="How to measure the gap", Order=20, GroupName="Trap Params")]
		public ARC_Uni_Zones_GapMeasurements pGapMeasurement
		{ get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name="Gap Ticks (min)", Description="Minimum Gap in ticks", Order=30, GroupName="Trap Params")]
		public int pGapTicksMin
		{ get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name="Gap Ticks (max)", Description="Minimum Gap in ticks", Order=35, GroupName="Trap Params")]
		public int pGapTicksMax
		{ get; set; }

		[Range(0.01, double.MaxValue)]
		[Display(Name="Min Gap ATR Multiple", Description="Minimum Gap in ATR multiples", Order=40, GroupName="Trap Params")]
		public double pGapMinATRMultiple
		{ get; set; }

		[Range(0.01, double.MaxValue)]
		[Display(Name="Max Gap ATR Multiple", Description="Max Gap in ATR multiples", Order=41, GroupName="Trap Params")]
		public double pGapMaxATRMultiple
		{ get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name="ATR Period", Description="Used when ATR is chosen for size type", Order=50, GroupName="Trap Params")]
		public int pATRPeriod
		{ get; set; }

		#endregion

        #region -- Swing Parameters --
        [Range(1, int.MaxValue)]
        [Display(Name = "Swing strength", GroupName = "Swing Parameters", Description = "Number of bars used to identify a swing high or low", Order = 10)]
        public int pSwingStrength { get; set; }

        [Display(Name = "Select data input for swings", GroupName = "Swing Parameters", Description = "Select data input for swing highs and lows", Order = 15)]
        public ARC_Uni_Zones_InputType pThisInputType { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Deviation multiplier", GroupName = "Swing Parameters", Description = "Multiplier used to calculate minimum deviation as an ATR multiple", Order = 20)]
        public double pMultiplierMD { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Sensitivity double tops/bottoms", GroupName = "Swing Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 30)]
        public double pMultiplierDTB { get; set; }

        [Display(Name = "Show swing lines", GroupName = "Swing Parameters", Description = "Show swing legs connecting swing highs and lows", Order = 40)]
        public bool pShowZigzagLegs { get; set; }

		[Range(1, int.MaxValue)]
        [Display(Name = "Width swing lines", GroupName = "Swing Parameters", Description = "Select thickness of swing legs connecting swing highs and lows", Order = 50)]
        public int pSwingLegWidth { get; set; }

		[XmlIgnore]
		[Display(Name = "Rising line color", GroupName = "Swing Parameters", Description = "Select Color of a rising swing leg line", Order = 70)]
		public Brush pRisingZZlegBrush { get; set; }
				[Browsable(false)]
				public string RisingZZlegBrushSerialize {get { return Serialize.BrushToString(pRisingZZlegBrush); }set { pRisingZZlegBrush = Serialize.StringToBrush(value); } }

		[XmlIgnore]
		[Display(Name = "Falling line color", GroupName = "Swing Parameters", Description = "Select Color of a falling swing leg line", Order = 80)]
		public Brush pFallingZZlegBrush { get; set; }
				[Browsable(false)]
				public string FallingZZlegBrushSerialize {get { return Serialize.BrushToString(pFallingZZlegBrush); }set { pFallingZZlegBrush = Serialize.StringToBrush(value); } }

        #endregion

		#region -- Zone Creation --
		[RefreshProperties(RefreshProperties.All)]
		[Display(Order = 55, Name = "Creation basis", GroupName = "Zone Creation", Description = "")]
		public ARC_Uni_Zones_BarBasis pCreationBasis		{get;set;}

		[Display(Order = 60, Name = "Creation Distance basis", GroupName = "Zone Creation", Description = "")]
		public ARC_Uni_Zones_DistanceBasis pCreationDistanceBasis		{get;set;}

		[Display(Order = 70, Name = "Distance (in ticks)", GroupName = "Zone Creation", Description = "If Break Distance is ticks, enter the number of ticks")]
		public int pTicksZoneCreation		{get;set;}

		[Display(Order = 80, Name = "Distance (in ATR mults)", GroupName = "Zone Creation", Description = "If Break Distance is ATR mults, enter the multiplier")]
		public double pATRmultZoneCreation		{get;set;}
		#endregion

		#region -- Zone Breaking --
		[Display(Order = 50, Name = "Terminate when Broken?", GroupName = "Zone Breaking", Description = "Terminate a zone based on being Broken?  Otherwise, a zone will terminate after a 2nd break in the opposite direction")]
		public bool pTerminateOnBroken		{get;set;}

        [RefreshProperties(RefreshProperties.All)]
		[Display(Order = 55, Name = "Break basis", GroupName = "Zone Breaking", Description = "")]
		public ARC_Uni_Zones_BarBasis pBreakBasis		{get;set;}

		[Display(Order = 60, Name = "Break Distance basis", GroupName = "Zone Breaking", Description = "")]
		public ARC_Uni_Zones_DistanceBasis pBreakDistanceBasis		{get;set;}

		[Display(Order = 70, Name = "Distance (in ticks)", GroupName = "Zone Breaking", Description = "If Break Distance is ticks, enter the number of ticks")]
		public int pTicksZoneBreak		{get;set;}

		[Display(Order = 80, Name = "Distance (in ATR mults)", GroupName = "Zone Breaking", Description = "If Break Distance is ATR mults, enter the multiplier")]
		public double pATRmultZoneBreak		{get;set;}
		#endregion
		
		#region -- Zones --
		[Display(Order = 5, Name = "Backfill to origin?", GroupName = "Zones", Description = "")]
		public bool pBackfillZonesToOrigin		{get;set;}
		[Display(Order = 10, Name = "Show Fresh Zones?", GroupName = "Zones", Description = "")]
		public bool pShowFreshZones		{get;set;}
		[Display(Order = 20, Name = "Show Tested Zones?", GroupName = "Zones", Description = "")]
		public bool pShowTestedZones		{get;set;}
		[Display(Order = 30, Name = "Show Broken Zones?", GroupName = "Zones", Description = "")]
		public bool pShowBrokenZones		{get;set;}
		[Display(Order = 40, Name = "Show Dead Zones?", GroupName = "Zones", Description = "")]
		public bool pShowDeadZones		{get;set;}
		[Display(Order = 45, Name = "Supp/Res/Both?", GroupName = "Zones", Description = "")]
		public ARC_Uni_Zones_SuppResBoth pSuppResBoth		{get;set;}
		[Display(Order = 50, Name = "Overlapping zones?", GroupName = "Zones", Description = "")]
		public ARC_Uni_Zones_OverlapBasis pOverlapBasis		{get;set;}

		[Display(Order = 90, Name = "Entry Price basis", GroupName = "Zones", Description = "")]
		public ARC_Uni_Zones_EntryPriceBasis pEntryPriceBasis		{get;set;}
		[Display(Order = 100, Name = "Entry Price offset (ticks)", GroupName = "Zones", Description = "Positive moves toward the current market price (enlarging the zone height), negative moves away from current market price (reducing the zone height)")]
		public int pOffsetAdjustmentTicks		{get;set;}

		[Range(1,int.MaxValue)]
		[Display(Order = 110, Name = "Days ago", GroupName = "Zones", Description = "Ignore any zones created prior to these number of charted days ago")]
		public int pMaxDaysAgo
		{get;set;}
		[XmlIgnore]
		[Display(Order = 120, Name = "Fresh Support Color", GroupName = "Zones", Description = "Select Color of fresh zone")]
		public Brush pFreshSup_Brush { get; set; }
				[Browsable(false)]
				public string pFreshSup_BrushSerialize {get { return Serialize.BrushToString(pFreshSup_Brush); }set { pFreshSup_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 130, Name = "Fresh Support Opacity", GroupName = "Zones", Description = "")]
		public int pFreshSup_Opacity
		{get;set;}
		[XmlIgnore]
		[Display(Order = 131, Name = "Fresh Sup Outline Color", GroupName = "Zones", Description = "Select Color of fresh zone outline")]
		public Brush pFreshSupOutline_Brush { get; set; }
				[Browsable(false)]
				public string pFreshSupOutline_BrushSerialize {get { return Serialize.BrushToString(pFreshSupOutline_Brush); }set { pFreshSupOutline_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 132, Name = "Fresh Sup Outline Width", GroupName = "Zones", Description = "")]
		public int pFreshSupOutline_Width
		{get;set;}

		[XmlIgnore]
		[Display(Order = 140, Name = "Fresh Resistance Color", GroupName = "Zones", Description = "Select Color of fresh zone")]
		public Brush pFreshRes_Brush { get; set; }
				[Browsable(false)]
				public string pFreshRes_BrushSerialize {get { return Serialize.BrushToString(pFreshRes_Brush); }set { pFreshRes_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 150, Name = "Fresh Resistance Opacity", GroupName = "Zones", Description = "")]
		public int pFreshRes_Opacity
		{get;set;}
		[XmlIgnore]
		[Display(Order = 151, Name = "Fresh Res Outline Color", GroupName = "Zones", Description = "Select Color of fresh zone outline")]
		public Brush pFreshResOutline_Brush { get; set; }
				[Browsable(false)]
				public string pFreshResOutline_BrushSerialize {get { return Serialize.BrushToString(pFreshResOutline_Brush); }set { pFreshResOutline_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 152, Name = "Fresh Res Outline Width", GroupName = "Zones", Description = "")]
		public int pFreshResOutline_Width
		{get;set;}

		[XmlIgnore]
		[Display(Order = 160, Name = "Tested Support Color", GroupName = "Zones", Description = "Select Color of tested zone")]
		public Brush pTestedSup_Brush { get; set; }
				[Browsable(false)]
				public string pTestedSup_BrushSerialize {get { return Serialize.BrushToString(pTestedSup_Brush); }set { pTestedSup_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 170, Name = "Tested Support Opacity", GroupName = "Zones", Description = "")]
		public int pTestedSup_Opacity
		{get;set;}
		[XmlIgnore]
		[Display(Order = 171, Name = "Tested Sup Outline Color", GroupName = "Zones", Description = "Select Color of tested zone outline")]
		public Brush pTestedSupOutline_Brush { get; set; }
				[Browsable(false)]
				public string pTestedSupOutline_BrushSerialize {get { return Serialize.BrushToString(pTestedSupOutline_Brush); }set { pTestedSupOutline_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 172, Name = "Tested Sup Outline Width", GroupName = "Zones", Description = "")]
		public int pTestedSupOutline_Width
		{get;set;}

		[XmlIgnore]
		[Display(Order = 180, Name = "Tested Resistance Color", GroupName = "Zones", Description = "Select Color of tested zone")]
		public Brush pTestedRes_Brush { get; set; }
				[Browsable(false)]
				public string pTestedRes_BrushSerialize {get { return Serialize.BrushToString(pTestedRes_Brush); }set { pTestedRes_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 190, Name = "Tested Resistance Opacity", GroupName = "Zones", Description = "")]
		public int pTestedRes_Opacity
		{get;set;}
		[XmlIgnore]
		[Display(Order = 191, Name = "Tested Res Outline Color", GroupName = "Zones", Description = "Select Color of tested zone outline")]
		public Brush pTestedResOutline_Brush { get; set; }
				[Browsable(false)]
				public string pTestedResOutline_BrushSerialize {get { return Serialize.BrushToString(pTestedResOutline_Brush); }set { pTestedResOutline_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 192, Name = "Tested Res Outline Width", GroupName = "Zones", Description = "")]
		public int pTestedResOutline_Width
		{get;set;}

		[XmlIgnore]
		[Display(Order = 200, Name = "Broken Support Color", GroupName = "Zones", Description = "Select Color of broken zone")]
		public Brush pBrokenSup_Brush { get; set; }
				[Browsable(false)]
				public string pBrokenSup_BrushSerialize {get { return Serialize.BrushToString(pBrokenSup_Brush); }set { pBrokenSup_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 210, Name = "Broken Support Opacity", GroupName = "Zones", Description = "")]
		public int pBrokenSup_Opacity
		{get;set;}
		[XmlIgnore]
		[Display(Order = 211, Name = "Broken Sup Outline Color", GroupName = "Zones", Description = "Select Color of broken zone outline")]
		public Brush pBrokenSupOutline_Brush { get; set; }
				[Browsable(false)]
				public string pBrokenSupOutline_BrushSerialize {get { return Serialize.BrushToString(pBrokenSupOutline_Brush); }set { pBrokenSupOutline_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 212, Name = "Broken Sup Outline Width", GroupName = "Zones", Description = "")]
		public int pBrokenSupOutline_Width
		{get;set;}

		[XmlIgnore]
		[Display(Order = 220, Name = "Broken Resistance Color", GroupName = "Zones", Description = "Select Color of broken zone")]
		public Brush pBrokenRes_Brush { get; set; }
				[Browsable(false)]
				public string pBrokenRes_BrushSerialize {get { return Serialize.BrushToString(pBrokenRes_Brush); }set { pBrokenRes_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 230, Name = "Broken Resistance Opacity", GroupName = "Zones", Description = "")]
		public int pBrokenRes_Opacity
		{get;set;}
		[XmlIgnore]
		[Display(Order = 231, Name = "Broken Res Outline Color", GroupName = "Zones", Description = "Select Color of broken zone outline")]
		public Brush pBrokenResOutline_Brush { get; set; }
				[Browsable(false)]
				public string pBrokenResOutline_BrushSerialize {get { return Serialize.BrushToString(pBrokenResOutline_Brush); }set { pBrokenResOutline_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 232, Name = "Broken Res Outline Width", GroupName = "Zones", Description = "")]
		public int pBrokenResOutline_Width
		{get;set;}

		[XmlIgnore]
		[Display(Order = 240, Name = "Dead Support Color", GroupName = "Zones", Description = "Select Color of dead zone")]
		public Brush pDeadSup_Brush { get; set; }
				[Browsable(false)]
				public string pDeadSup_BrushSerialize {get { return Serialize.BrushToString(pDeadSup_Brush); }set { pDeadSup_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 250, Name = "Dead Support Opacity", GroupName = "Zones", Description = "")]
		public int pDeadSup_Opacity
		{get;set;}
		[XmlIgnore]
		[Display(Order = 251, Name = "Dead Sup Outline Color", GroupName = "Zones", Description = "Select Color of dead zone outline")]
		public Brush pDeadSupOutline_Brush { get; set; }
				[Browsable(false)]
				public string pDeadSupOutline_BrushSerialize {get { return Serialize.BrushToString(pDeadSupOutline_Brush); }set { pDeadSupOutline_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 252, Name = "Dead Sup Outline Width", GroupName = "Zones", Description = "")]
		public int pDeadSupOutline_Width
		{get;set;}

		[XmlIgnore]
		[Display(Order = 260, Name = "Dead Resistance Color", GroupName = "Zones", Description = "Select Color of dead zone")]
		public Brush pDeadRes_Brush { get; set; }
				[Browsable(false)]
				public string pDeadRes_BrushSerialize {get { return Serialize.BrushToString(pDeadRes_Brush); }set { pDeadRes_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 270, Name = "Dead Resistance Opacity", GroupName = "Zones", Description = "")]
		public int pDeadRes_Opacity
		{get;set;}
		[XmlIgnore]
		[Display(Order = 271, Name = "Dead Res Outline Color", GroupName = "Zones", Description = "Select Color of dead zone outline")]
		public Brush pDeadResOutline_Brush { get; set; }
				[Browsable(false)]
				public string pDeadResOutline_BrushSerialize {get { return Serialize.BrushToString(pDeadResOutline_Brush); }set { pDeadResOutline_Brush = Serialize.StringToBrush(value); } }
		[Range(0, 100)]
		[Display(Order = 272, Name = "Dead Res Outline Width", GroupName = "Zones", Description = "")]
		public int pDeadResOutline_Width
		{get;set;}

		#endregion

		#region -- Global Zones --
#if INCLUDE_GLOBALIZATION
		[Display(Order = 10, Name = "Globalize fresh zones?", GroupName = "Global Zones", Description = "")]
		public bool pGlobalizeFreshZones
		{get;set;}
		[Display(Order = 20, Name = "Globalize tested zones?", GroupName = "Global Zones", Description = "")]
		public bool pGlobalizeTestedZones
		{get;set;}
		[Display(Order = 30, Name = "Globalize broken zones?", GroupName = "Global Zones", Description = "")]
		public bool pGlobalizeBrokenZones
		{get;set;}
		[Display(Order = 40, Name = "Globalize dead zones?", GroupName = "Global Zones", Description = "")]
		public bool pGlobalizeDeadZones
		{get;set;}
#endif

		#region -- LoadZoneTemplates --
		internal class LoadZoneTemplates : StringConverter
		{
			#region LoadZoneTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Rectangle"};
				string templates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(templates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
		#endregion
//======
#if INCLUDE_GLOBALIZATION
		[Display(Order = 50, Name = "Fresh Resistance zone template", GroupName = "Global Zones", Description = "Rectangle drawing template for globalized zones")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pFreshResistanceRectangleTemplate
		{get;set;}

		[Display(Order = 60, Name = "Fresh Support zone template", GroupName = "Global Zones", Description = "Rectangle drawing template for globalized zones")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pFreshSupportRectangleTemplate
		{get;set;}
//======
		[Display(Order = 50, Name = "Tested Resistance zone template", GroupName = "Global Zones", Description = "Rectangle drawing template for globalized zones")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pTestedResistanceRectangleTemplate
		{get;set;}

		[Display(Order = 60, Name = "Tested Support zone template", GroupName = "Global Zones", Description = "Rectangle drawing template for globalized zones")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pTestedSupportRectangleTemplate
		{get;set;}
//======
		[Display(Order = 50, Name = "Broken Resistance zone template", GroupName = "Global Zones", Description = "Rectangle drawing template for globalized zones")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pBrokenResistanceRectangleTemplate
		{get;set;}

		[Display(Order = 60, Name = "Broken Support zone template", GroupName = "Global Zones", Description = "Rectangle drawing template for globalized zones")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pBrokenSupportRectangleTemplate
		{get;set;}
//======
		[Display(Order = 50, Name = "Dead Resistance zone template", GroupName = "Global Zones", Description = "Rectangle drawing template for globalized zones")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pDeadResistanceRectangleTemplate
		{get;set;}

		[Display(Order = 60, Name = "DeadSupport zone template", GroupName = "Global Zones", Description = "Rectangle drawing template for globalized zones")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pDeadSupportRectangleTemplate
		{get;set;}
#endif
		#endregion

		private string pButtonText = "UniZones";
        [Display(Order=1000, Name = "Button text", GroupName="Custom Visuals", Description = "")]       
		public string ButtonText
        {
            get { return pButtonText; }
            set { pButtonText = value; }
        }

		#endregion

        #region Custom Property Manipulation
        private void ModifyProperties(PropertyDescriptorCollection col)
        {
			if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.Structure){
				col.Remove(col.Find("pBasingZoneSizeBasis",true));
				col.Remove(col.Find("pMaxBodyPct",true));
				col.Remove(col.Find("pThrustBarUpBrush",true));
				col.Remove(col.Find("pThrustBarUpOpacity",true));
				col.Remove(col.Find("pThrustBarDownBrush",true));
				col.Remove(col.Find("pThrustBarDownOpacity",true));
				col.Remove(col.Find("pBasingBarUpBrush",true));
				col.Remove(col.Find("pBasingBarUpOpacity",true));
				col.Remove(col.Find("pBasingBarDownBrush",true));
				col.Remove(col.Find("pBasingBarDownOpacity",true));
				col.Remove(col.Find("pShowSandDZones",true));
				col.Remove(col.Find("pShowOrderblockZones",true));
				col.Remove(col.Find("pGapTicksMax",true));
				col.Remove(col.Find("pGapTicksMin",true));
				col.Remove(col.Find("pShowTrapZones",true));
				col.Remove(col.Find("pGapTicksMax",true));
				col.Remove(col.Find("pGapTicksMax",true));
				col.Remove(col.Find("pGapMeasurement",true));
				col.Remove(col.Find("pGapMinATRMultiple",true));
				col.Remove(col.Find("pGapMaxATRMultiple",true));
				col.Remove(col.Find("pATRperiod",true));
				col.Remove(col.Find("pOrderblockBarUpBrush",true));
				col.Remove(col.Find("pOrderblockBarDownBrush",true));
				col.Remove(col.Find("pOrderblockBarUpOpacity",true));
				col.Remove(col.Find("pOrderblockBarDownOpacity",true));
//				col.Remove(col.Find("",true));
//				col.Remove(col.Find("",true));
//				col.Remove(col.Find("",true));
			}
			if(pGapMeasurement == ARC_Uni_Zones_GapMeasurements.ATR){
				col.Remove(col.Find("pGapTicksMin",true));
				col.Remove(col.Find("pGapTicksMax",true));
			}
			if(pGapMeasurement == ARC_Uni_Zones_GapMeasurements.Ticks){
				col.Remove(col.Find("pGapMinATRMultiple",true));
				col.Remove(col.Find("pGapMaxATRMultiple",true));
				col.Remove(col.Find("pATRPeriod",true));
			}
			if(pZoneCalcMode == ARC_Uni_Zones_ZoneCalcModes.PriceAction){
				col.Remove(col.Find("pBackfillZonesToOrigin",true));
                col.Remove(col.Find("pCreationDistanceBasis", true));
                col.Remove(col.Find("pTicksZoneCreation", true));
                col.Remove(col.Find("pATRmultZoneCreation", true));
				col.Remove(col.Find("pCreationBasis",true));
				col.Remove(col.Find("pCreationDistanceBasis",true));
				col.Remove(col.Find("pTicksZoneCreation",true));
				col.Remove(col.Find("pEntryPriceBasis",true));
				col.Remove(col.Find("pTerminateOnBroken",true));
				col.Remove(col.Find("pOffsetAdjustmentTicks",true));
				col.Remove(col.Find("pOverlapBasis",true));
				col.Remove(col.Find("pShowDeadZones",true));
				col.Remove(col.Find("pGlobalizeDeadZones",true));
				col.Remove(col.Find("pDeadResOutline_Brush",true));
				col.Remove(col.Find("pDeadResOutline_Width",true));
				col.Remove(col.Find("pDeadRes_Brush",true));
				col.Remove(col.Find("pDeadRes_Opacity",true));
				col.Remove(col.Find("pDeadSupOutline_Brush",true));
				col.Remove(col.Find("pDeadSupOutline_Width",true));
				col.Remove(col.Find("pDeadSup_Brush",true));
				col.Remove(col.Find("pDeadSup_Opacity",true));
				col.Remove(col.Find("pDeadResistanceRectangleTemplate",true));
				col.Remove(col.Find("pDeadSupportRectangleTemplate",true));
				col.Remove(col.Find("pBreakBasis",true));
                col.Remove(col.Find("pBreakDistanceBasis", true));
				col.Remove(col.Find("pTicksZoneBreak",true));
				col.Remove(col.Find("pATRmultZoneBreak",true));
			}else{
			}
            if (pBreakBasis == ARC_Uni_Zones_BarBasis.Full)
            {
                col.Remove(col.Find("pBreakDistanceBasis", true));
                col.Remove(col.Find("pTicksZoneBreak", true));
                col.Remove(col.Find("pATRmultZoneBreak", true));
            }
            if (pCreationBasis == ARC_Uni_Zones_BarBasis.Full)
            {
                col.Remove(col.Find("pCreationDistanceBasis", true));
                col.Remove(col.Find("pTicksZoneCreation", true));
                col.Remove(col.Find("pATRmultZoneCreation", true));
            }

        }
        #endregion
        #region ICustomTypeDescriptor Members
        public PropertyDescriptorCollection GetProperties() { return TypeDescriptor.GetProperties(GetType()); }
        public object GetPropertyOwner(PropertyDescriptor pd) { return this; }
        public AttributeCollection GetAttributes() { return TypeDescriptor.GetAttributes(GetType()); }
        public string GetClassName() { return TypeDescriptor.GetClassName(GetType()); }
        public string GetComponentName() { return TypeDescriptor.GetComponentName(GetType()); }
        public TypeConverter GetConverter() { return TypeDescriptor.GetConverter(GetType()); }
        public EventDescriptor GetDefaultEvent() { return TypeDescriptor.GetDefaultEvent(GetType()); }
        public PropertyDescriptor GetDefaultProperty() { return TypeDescriptor.GetDefaultProperty(GetType()); }
        public object GetEditor(Type editorBaseType) { return TypeDescriptor.GetEditor(GetType(), editorBaseType); }
        public EventDescriptorCollection GetEvents(Attribute[] attributes) { return TypeDescriptor.GetEvents(GetType(), attributes); }
        public EventDescriptorCollection GetEvents() { return TypeDescriptor.GetEvents(GetType()); }
        public PropertyDescriptorCollection GetProperties(Attribute[] attributes)
        {
            PropertyDescriptorCollection orig = GetFilteredIndicatorProperties(TypeDescriptor.GetProperties(GetType(), attributes), this.IsOwnedByChart, this.IsCreatedByStrategy);
            PropertyDescriptor[] arr = new PropertyDescriptor[orig.Count];
            orig.CopyTo(arr, 0);
            PropertyDescriptorCollection col = new PropertyDescriptorCollection(arr);
            ModifyProperties(col);
            return col;
        }
        public static PropertyDescriptorCollection GetFilteredIndicatorProperties(PropertyDescriptorCollection origProperties, bool isOwnedByChart, bool isCreatedByStrategy)
        {
            List<PropertyDescriptor> allProps = new List<PropertyDescriptor>();
            foreach (PropertyDescriptor pd in origProperties) { allProps.Add(pd); }
            Type[] excludedTypes = new Type[] { typeof(System.Windows.Media.Brush), typeof(NinjaTrader.Gui.Stroke), typeof(System.Windows.Media.Color), typeof(System.Windows.Media.Pen) };
            Func<Type, bool> IsNotAVisualType = (Type propType) => {
                foreach (Type testType in excludedTypes) { if (testType.IsAssignableFrom(propType)) return false; }
                return true;
            };
            IEnumerable<string> baseIndProperties = from bp in typeof(IndicatorBase).GetProperties(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public) select bp.Name;
            IEnumerable<PropertyDescriptor> filteredProps = from p in allProps where p.IsBrowsable && (!isOwnedByChart && !isCreatedByStrategy ? (!baseIndProperties.Contains(p.Name) && p.Name != "Calculate" && p.Name != "Displacement" && IsNotAVisualType(p.PropertyType)) : true) select p;
            return new PropertyDescriptorCollection(filteredProps.ToArray());
        }
        #endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_Uni_Zones[] cacheARC_Uni_Zones;
		public ARC.ARC_Uni_Zones ARC_Uni_Zones()
		{
			return ARC_Uni_Zones(Input);
		}

		public ARC.ARC_Uni_Zones ARC_Uni_Zones(ISeries<double> input)
		{
			if (cacheARC_Uni_Zones != null)
				for (int idx = 0; idx < cacheARC_Uni_Zones.Length; idx++)
					if (cacheARC_Uni_Zones[idx] != null &&  cacheARC_Uni_Zones[idx].EqualsInput(input))
						return cacheARC_Uni_Zones[idx];
			return CacheIndicator<ARC.ARC_Uni_Zones>(new ARC.ARC_Uni_Zones(), input, ref cacheARC_Uni_Zones);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_Uni_Zones ARC_Uni_Zones()
		{
			return indicator.ARC_Uni_Zones(Input);
		}

		public Indicators.ARC.ARC_Uni_Zones ARC_Uni_Zones(ISeries<double> input )
		{
			return indicator.ARC_Uni_Zones(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_Uni_Zones ARC_Uni_Zones()
		{
			return indicator.ARC_Uni_Zones(Input);
		}

		public Indicators.ARC.ARC_Uni_Zones ARC_Uni_Zones(ISeries<double> input )
		{
			return indicator.ARC_Uni_Zones(input);
		}
	}
}

#endregion
