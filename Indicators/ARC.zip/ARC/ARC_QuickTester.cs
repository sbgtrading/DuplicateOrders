
#region -- Using --
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using Brush = System.Windows.Media.Brush;
using Brushes = System.Windows.Media.Brushes;
using Button = System.Windows.Controls.Button;
using Clipboard = System.Windows.Clipboard;
using HorizontalAlignment = System.Windows.HorizontalAlignment;
using PixelFormat = System.Drawing.Imaging.PixelFormat;
using Point = System.Drawing.Point;
using TextDataFormat = System.Windows.TextDataFormat;
using SummaryPart = NinjaTrader.NinjaScript.DrawingTools.ARC.ARC_QuickTester_ManualTestTrade.SummaryPart;
using NinjaTrader.NinjaScript.DrawingTools.ARC;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using NinjaTrader.Core;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui.HotKeys;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using Screen = System.Windows.Forms.Screen;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[Browsable(true)]
	[CategoryOrder(DayOfWeekParametersGroupName, 0)]
	[CategoryOrder(TimeParametersGroupName, 1)]
	[CategoryOrder(MenuParametersGroupName, 2)]
	[CategoryOrder(ButtonParametersGroupName, 3)]
	[CategoryOrder(MiscParametersGroupName, 4)]
	[CategoryOrder(DisplayParametersGroupName, 5)]
	[ARC_QuickTester_CoLicenses(typeof(ARC_QuickTester_ManualShortTrade), typeof(ARC_QuickTester_ManualLongTrade))]
	public class ARC_QuickTester : ARC_QuickTester_ARCIndicatorBase
	{
		public override string ProductVersion { get { return "v1.0.11 (4/18/2023)"; } }
		public override string ProductInfusionSoftTag { get { return "23674"; } }

		private Chart chartWindow;
		private readonly Random rnd = new Random();
		private const int ScrollToBarMargin = 3;
		private bool reachedHistorical;
		private const string IconFontResourceName = "QuickTesterIcons";
		private const string HostGridName = "ManualBoosterHostGrid";

		private Grid uiFloatingGrid;

		private static SummaryPart[] HeaderParts
		{
			get
			{
				return (SummaryPart[])Enum.GetValues(typeof(SummaryPart));
			}
		}

		private enum ButtonType
		{
			Buy,
			Sell,
			UploadChartCapture,
			UploadScreenCapture,
			RandomizeTime,
			PreviousValidTime,
			NextValidTime,
			MassCapture,
			PreviousTrade,
			NextTrade,
			ImportTrades,
			DeleteTrades,
			OpenTemplateSpreadsheet
		}

		private readonly Dictionary<ButtonType, bool> buttonIsVisible = Enum.GetValues(typeof(ButtonType))
			.OfType<ButtonType>()
			.ToDictionary(b => b, b => b == ButtonType.Buy || b == ButtonType.Sell);

		private Series<bool> sessionChange;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State == State.SetDefaults)
			{
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				DisplayInDataBox = false;
				DrawOnPricePanel = true;
				PaintPriceMarkers = false;
				ScaleJustification = ScaleJustification.Right;
				IsChartOnly = true;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive = false;

				MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				AllowRemovalOfDrawObjects = true;

				LimitTimeOfDay = false;
				WindowStartHr = 0;
				WindowStartMinute = 0;
				WindowEndHr = 23;
				WindowEndMinute = 59;

				IncludeMondays = true;
				IncludeTuesday = true;
				IncludeWednesday = true;
				IncludeThursday = true;
				IncludeFriday = true;
				IncludeSaturday = true;
				IncludeSunday = true;

				MfeBrush = Brushes.Cyan;
				MaeBrush = Brushes.Magenta;
				WinningConnectorBrush = Brushes.Lime;
				LosingConnectorBrush = Brushes.Red;
				StopLossBrush = Brushes.Red;
				StopLossConnectorBrush = Brushes.White;
				EntryMarkerBrush = Brushes.White;
				ExitMarkerBrush = Brushes.Black;
				LabelBrush = Brushes.White;
				LongEntryArrowBrush = Brushes.Lime;
				ShortEntryArrowBrush = Brushes.Red;
				Opacity = 100;

				MenuLocation = ARC_QuickTester_ParentAnchorPoint.TopLeft;
				MenuOrientation = ARC_QuickTester_ControlOrientation.Vertical;

				foreach (var type in Enum.GetValues(typeof(ButtonType)).OfType<ButtonType>())
					buttonIsVisible[type] = true;

				IncludeHeadersInMassCopy = false;
				IncludeAllInstrumentsInMassCopy = false;
			}
			else if (State == State.DataLoaded)
			{
				sessionChange = new Series<bool>(this, MaximumBarsLookBack.Infinite);
				ResetHotKeysIfNotSet();
			}
			else if (State == State.Historical)
			{
				reachedHistorical = true;
				if (ChartControl == null)
					return;

				ChartControl.OwnerChart.MainTabControl.SelectionChanged += MainTabControl_SelectionChanged;
				ChartControl.Dispatcher.InvokeAsync(() =>
				{
					//Obtain the Chart on which the indicator is configured
					chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
					if (chartWindow == null)
					{
						Print("chartWindow == null");
						return;
					}

					var selectedTab = ChartControl.OwnerChart.MainTabControl.SelectedItem as TabItem;
					if (selectedTab != null && ReferenceEquals(selectedTab.Content, ChartControl.ChartTab))
						CreateButtons();
				});
			}
			else if (State == State.Realtime)
			{
				if (ChartPanel != null)
					UpdateAllManualTradeColors();
			}
			else if (State == State.Terminated)
			{
				if (!reachedHistorical)
					return;

				if (ChartControl == null)
					return;

				if (ChartControl.OwnerChart != null && ChartControl.OwnerChart.MainTabControl != null)
					ChartControl.OwnerChart.MainTabControl.SelectionChanged -= MainTabControl_SelectionChanged;

				ChartControl.Dispatcher.InvokeAsync(() =>
				{
					//Obtain the Chart on which the indicator is configured
					if (ChartControl == null)
						return;

					DestroyButtons();
				});
			}
		}

		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_QuickTester_IsLicensed())
				return;

			if (CurrentBar == 0)
				return;

			var sessionChanged = LimitTimeOfDay || !IncludeMondays || !IncludeTuesday || !IncludeWednesday || !IncludeThursday || !IncludeFriday ?
				IsValidTradeTime(Time[0]) && !IsValidTradeTime(Time[1])
				: Time[0].Date != Time[1].Date;

			if (sessionChanged)
				sessionChange[0] = true;
		}

		private void DestroyButtons()
		{
			var panelGrid = ChartPanel == null ? null : ChartPanel.Content as Grid;
			if (panelGrid == null)
				return;

			var hostGrids = panelGrid.Children
				.OfType<Grid>()
				.Where(g => g.Name == HostGridName)
				.ToList();

			foreach (var grid in hostGrids)
				panelGrid.Children.Remove(grid);
		}

		private void CreateButtons()
		{
			if (!this.ARC_QuickTester_IsLicensed())
				return;

			// Obtain the panel on which the indicator is configured
			var panelGrid = ChartPanel == null ? null : ChartPanel.Content as Grid;
			if (panelGrid == null)
			{
				Print("chartWindow == null");
				return;
			}

			uiFloatingGrid = new Grid
			{
				Name = HostGridName,
				Margin = new Thickness(ARC_QuickTester_SkinResourceHelper.ARC_QuickTester_GetResource(ARC_QuickTester_DoubleResourceKeys.MarginBase))
			};

			switch (MenuLocation)
			{
			case ARC_QuickTester_ParentAnchorPoint.TopLeft:
			case ARC_QuickTester_ParentAnchorPoint.Left:
			case ARC_QuickTester_ParentAnchorPoint.BottomLeft:
				uiFloatingGrid.HorizontalAlignment = HorizontalAlignment.Left;
				break;
			case ARC_QuickTester_ParentAnchorPoint.Bottom:
			case ARC_QuickTester_ParentAnchorPoint.Top:
				uiFloatingGrid.HorizontalAlignment = HorizontalAlignment.Center;
				break;
			case ARC_QuickTester_ParentAnchorPoint.BottomRight:
			case ARC_QuickTester_ParentAnchorPoint.Right:
			case ARC_QuickTester_ParentAnchorPoint.TopRight:
				uiFloatingGrid.HorizontalAlignment = HorizontalAlignment.Right;
				break;
			default:
				throw new ArgumentOutOfRangeException();
			}

			switch (MenuLocation)
			{
			case ARC_QuickTester_ParentAnchorPoint.TopRight:
			case ARC_QuickTester_ParentAnchorPoint.Top:
			case ARC_QuickTester_ParentAnchorPoint.TopLeft:
				uiFloatingGrid.VerticalAlignment = VerticalAlignment.Top;
				break;
			case ARC_QuickTester_ParentAnchorPoint.Left:
			case ARC_QuickTester_ParentAnchorPoint.Right:
				uiFloatingGrid.VerticalAlignment = VerticalAlignment.Center;
				break;
			case ARC_QuickTester_ParentAnchorPoint.BottomLeft:
			case ARC_QuickTester_ParentAnchorPoint.Bottom:
			case ARC_QuickTester_ParentAnchorPoint.BottomRight:
				uiFloatingGrid.VerticalAlignment = VerticalAlignment.Bottom;
				break;
			default:
				throw new ArgumentOutOfRangeException();
			}

			// Offset the grid to avoid collision with move to end of chart button
			if (MenuLocation == ARC_QuickTester_ParentAnchorPoint.TopRight || MenuLocation == ARC_QuickTester_ParentAnchorPoint.Right || MenuLocation == ARC_QuickTester_ParentAnchorPoint.BottomRight)
				uiFloatingGrid.Margin = MenuOrientation == ARC_QuickTester_ControlOrientation.Vertical
					? new Thickness(uiFloatingGrid.Margin.Left, uiFloatingGrid.Margin.Top + ARC_QuickTester_SkinResourceHelper.ARC_QuickTester_GetResource(ARC_QuickTester_DoubleResourceKeys.SizeWindowControl) * 2, uiFloatingGrid.Margin.Right, uiFloatingGrid.Margin.Bottom)
					: new Thickness(uiFloatingGrid.Margin.Left, uiFloatingGrid.Margin.Top, uiFloatingGrid.Margin.Right + ARC_QuickTester_SkinResourceHelper.ARC_QuickTester_GetResource(ARC_QuickTester_DoubleResourceKeys.SizeWindowControl) * 2, uiFloatingGrid.Margin.Bottom);

			panelGrid.Children.Add(uiFloatingGrid);

			foreach (var buttonType in (ButtonType[])Enum.GetValues(typeof(ButtonType)))
			{
				if (!buttonIsVisible[buttonType])
					continue;

				// Style and create our button
				var button = new Button
				{
					Name = buttonType + "ManualBoosterButton",
					FontSize = 17,
					MinWidth = 0
				};

				switch (buttonType)
				{
				case ButtonType.Buy:
					button.Click += BuyButton_Click;
					button.ToolTip = "Add Manual Long Trade";
					button.ARC_QuickTester_SetIcon(Icons.DrawArrowUp);
					break;
				case ButtonType.Sell:
					button.Click += SellButton_Click;
					button.ToolTip = "Add Manual Short Trade";
					button.ARC_QuickTester_SetIcon(Icons.DrawArrowDown);
					break;
				case ButtonType.UploadChartCapture:
					button.Click += UploadChartImageButton_Click;
					button.ToolTip = "Upload Chart Screenshot";
					button.ARC_QuickTester_SetIcon("\uE710", IconFontResourceName);
					break;
				case ButtonType.UploadScreenCapture:
					button.Click += UploadScreenCaptureButton_Click;
					button.ToolTip = "Upload Monitor Screen Capture";
					button.ARC_QuickTester_SetIcon("\uE700", IconFontResourceName);
					break;
				case ButtonType.RandomizeTime:
					button.Click += RandomizeTimeButton_Click;
					button.ToolTip = "Randomize Time";
					button.ARC_QuickTester_SetIcon(Icons.MessageBoxQuestion);
					break;
				case ButtonType.PreviousValidTime:
					button.Click += (_, __) => MoveToNeighboringValidTime(-1, ChartBars.FromIndex);
					button.ToolTip = "Previous Valid Time";
					button.ARC_QuickTester_SetIcon("\uE50E", IconFontResourceName);
					break;
				case ButtonType.NextValidTime:
					button.Click += (_, __) => MoveToNeighboringValidTime(1, ChartBars.ToIndex);
					button.ToolTip = "Next Valid Time";
					button.ARC_QuickTester_SetIcon("\uE70C", IconFontResourceName);
					break;
				case ButtonType.MassCapture:
					button.Click += MassCaptureButton_Click;
					button.ToolTip = "Copy Trade Summaries to Clipboard";
					button.ARC_QuickTester_SetIcon("\uE046");
					break;
				case ButtonType.PreviousTrade:
					button.Click += PreviousTradeButton_Click;
					button.ToolTip = "Previous Trade";
					button.ARC_QuickTester_SetIcon("\uE90A", IconFontResourceName);
					break;
				case ButtonType.NextTrade:
					button.Click += NextTradeButton_Click;
					button.ToolTip = "Next Trade";
					button.ARC_QuickTester_SetIcon("\uE705", IconFontResourceName);
					break;
				case ButtonType.ImportTrades:
					button.Click += ImportTradesButton_Click;
					button.ToolTip = "Import Trades";
					button.ARC_QuickTester_SetIcon("\uE714", IconFontResourceName);
					break;
				case ButtonType.DeleteTrades:
					button.Click += DeleteTradesButton_Click;
					button.ToolTip = "ARC_QuickTester_Delete Trades";
					button.ARC_QuickTester_SetIcon("\uE70f", IconFontResourceName);
					break;
				case ButtonType.OpenTemplateSpreadsheet:
					button.Click += OpenTemplateSpreadsheetButton_Click;
					button.ToolTip = "Open Template Spreadsheet";
					button.ARC_QuickTester_SetIcon("\uE709", IconFontResourceName);
					break;
				default:
					throw new ArgumentOutOfRangeException();
				}

				if (MenuOrientation == ARC_QuickTester_ControlOrientation.Vertical)
				{
					uiFloatingGrid.RowDefinitions.Add(new RowDefinition());
					uiFloatingGrid.ARC_QuickTester_SetChildRowColumn(button, uiFloatingGrid.RowDefinitions.Count - 1, 0);
				}
				else
				{
					uiFloatingGrid.ColumnDefinitions.Add(new ColumnDefinition());
					uiFloatingGrid.ARC_QuickTester_SetChildRowColumn(button, 0, uiFloatingGrid.ColumnDefinitions.Count - 1);
				}
			}
		}

		#region Callbacks
		private void MainTabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			var tabVisible = e.AddedItems
				.OfType<TabItem>()
				.Select(t => t.Content)
				.Contains(ChartControl.ChartTab);
			if (tabVisible)
				CreateButtons();
			else
				DestroyButtons();
		}

		private void PreviousTradeButton_Click(object sender, RoutedEventArgs e)
		{
			MoveToTrade(-1);
		}

		private void NextTradeButton_Click(object sender, RoutedEventArgs e)
		{
			MoveToTrade(1);
		}

		private void RandomizeTimeButton_Click(object sender, RoutedEventArgs e)
		{
			// Randomize our start
			var bar = (int)Math.Round(rnd.NextDouble() * CurrentBar);

			// Sweep forward and back, looking for the closest valid range near our random start
			var actualBar = GetNeighboringValidTime(1, bar);
			if (actualBar == -1)
				actualBar = GetNeighboringValidTime(-1, bar);

			if (actualBar == -1)
			{
				NTMessageBox.ShowFitToContent("No valid periods found in loaded bars!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
				return;
			}

			ScrollToBar(actualBar, ARC_QuickTester_SubjectAlignment.Right);
		}

		private void MassCaptureButton_Click(object sender, RoutedEventArgs e)
		{
			var headers = new List<string>();
			foreach (var stat in HeaderParts)
				switch (stat)
				{
				case SummaryPart.Symbol:
					headers.Add("Symbol");
					continue;
				case SummaryPart.InitialStop:
					headers.Add("Initial SL Price");
					continue;
				case SummaryPart.Direction:
					headers.Add("Direction");
					continue;
				case SummaryPart.Mfe:
					headers.Add("MFE");
					continue;
				case SummaryPart.Mae:
					headers.Add("MAE");
					continue;
				case SummaryPart.Entry:
				case SummaryPart.Exit:
					var headerPrefix = stat == SummaryPart.Entry ? "Entry" : "Exit";
					headers.Add(headerPrefix + " Time");
					headers.Add(headerPrefix + " Price");
					break;
				default:
					throw new ArgumentOutOfRangeException();
				}

			var lines = new List<string>();
			if (IncludeHeadersInMassCopy)
				lines.Add(string.Join("\t", headers.ToArray()));

			var failures = 0;
			var allTrades = ChartPanel.ChartObjects
				.OfType<ARC_QuickTester_ManualTestTrade>()
				.Where(o => IncludeAllInstrumentsInMassCopy || o.AttachedTo.Instrument == Instrument)
				.ToArray();
			foreach (var t in allTrades)
				try
				{
					lines.Add(t.GetSummary());
				}
				catch (Exception ex)
				{
					Debug.WriteLine(ex);
					failures++;
				}

			Clipboard.SetText(string.Join(Environment.NewLine, lines), TextDataFormat.Text);
			if (failures != 0)
				Log("Failed to Copy in " + failures + " trades.", LogLevel.Alert);
		}

		private void UploadScreenCaptureButton_Click(object sender, RoutedEventArgs e)
		{
			var lastClick = ChartControl.PointToScreen(ChartControl.MouseDownPoint);
			var screen = Screen.FromPoint(new Point((int)lastClick.X, (int)lastClick.Y));
			var scalingFactor = screen.ARC_QuickTester_ScalingPercent() / 100f;

			//Create a new bitmap
			var actualSize = new System.Drawing.Size
			{
				Width = (int)(screen.Bounds.Width * scalingFactor),
				Height = (int)(screen.Bounds.Height * scalingFactor)
			};

			using (var bmpScreenShot = new Bitmap(actualSize.Width, actualSize.Height, PixelFormat.Format32bppArgb))
			{
				// Create a graphics object from the bitmap.
				using (var g = Graphics.FromImage(bmpScreenShot))
					g.CopyFromScreen(screen.Bounds.X, screen.Bounds.Y, 0, 0, actualSize, CopyPixelOperation.SourceCopy);

				var ms = new MemoryStream();
				bmpScreenShot.Save(ms, ImageFormat.Png);
				var image = new BitmapImage();
				image.BeginInit();
				ms.Seek(0, SeekOrigin.Begin);
				image.StreamSource = ms;
				image.EndInit();

				// Start the task, signaling it's start and end by changing the buttons color
				SignalTaskWithButton(sender as Button, async () =>
				{
					await Task.Delay(250);
					await ARC_QuickTester_ManualTestTrade.ARC_QuickTester_CopyImageLinkToClipboard(ChartControl.OwnerChart, image, true);
					ms.Dispose();
				});
			}
		}

		private void UploadChartImageButton_Click(object sender, RoutedEventArgs e)
		{
			SignalTaskWithButton(sender as Button, () =>
			{
				var screenShot = ChartControl.OwnerChart.GetScreenshot(ShareScreenshotType.Chart);
				return ARC_QuickTester_ManualTestTrade.ARC_QuickTester_CopyImageLinkToClipboard(ChartControl.OwnerChart, screenShot, true);
			});
		}

		private void BuyButton_Click(object sender, RoutedEventArgs e)
		{
			ChartControl.TryStartDrawing(typeof(ARC_QuickTester_ManualLongTrade).FullName);
		}

		private void SellButton_Click(object sender, RoutedEventArgs e)
		{
			ChartControl.TryStartDrawing(typeof(ARC_QuickTester_ManualShortTrade).FullName);
		}

		private void ImportTradesButton_Click(object sender, RoutedEventArgs e)
		{
			var optionsWindow = new ARC_QuickTester_ImportTradesWindow();
			if (optionsWindow.ShowDialog() != true)
				return;

			var offsetHours = optionsWindow.TimeOffset;
			var roundTimes = optionsWindow.RoundTimes;

			var clipboardTxt = Clipboard.GetText(TextDataFormat.Text);
			var lines = clipboardTxt
				.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
				.Where(s => !string.IsNullOrWhiteSpace(s))
				.Select(l => l.Split(new[] { '\t' }, StringSplitOptions.RemoveEmptyEntries))
				.ToArray();
			if (lines.Length == 0)
			{
				NTMessageBoxSimple.Show(chartWindow, "No trades in clipboard!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
				return;
			}

			// Scrub the lines whose instrument isn't a match
			lines = lines
				.Where(t => InstrumentsMatch(t[0], Instrument.FullName, true))
				.ToArray();

			if (lines.Length == 0)
			{
				NTMessageBoxSimple.Show(chartWindow, "No trades matching the instrument in clipboard!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
				return;
			}

			// TODO Make this more permissive, the same way portfolio mesh allows flexible columning in imports
			var indexMap = HeaderParts.Aggregate(new Dictionary<SummaryPart, int>(), (map, h) =>
			{
				if (map.Count == 0)
				{
					map[h] = 0;
				}
				else
				{
					var lastPart = map.Keys.Last();
					map[h] = map[lastPart] + (lastPart == SummaryPart.Entry || lastPart == SummaryPart.Exit ? 2 : 1);
				}

				return map;
			});

			foreach (var pos in new[] { MarketPosition.Long, MarketPosition.Short })
			{
				var trades = lines
					.Where(l => l[indexMap[SummaryPart.Direction]].ToLower() == pos.ToString().ToLower())
					.ToArray();
				foreach (var trade in trades)
				{
					DateTime entryTime;
					if (!TryDecodeTradeDateTime(trade[indexMap[SummaryPart.Entry]], out entryTime))
						continue;

					DateTime exitTime;
					if (!TryDecodeTradeDateTime(trade[indexMap[SummaryPart.Exit]], out exitTime))
						continue;

					if (offsetHours != 0)
					{
						entryTime = entryTime.AddHours(-offsetHours);
						exitTime = exitTime.AddHours(-offsetHours);
					}

					if (roundTimes)
					{
						entryTime = RoundToBarTime(entryTime);
						exitTime = RoundToBarTime(exitTime);
					}

					var anchors = new Dictionary<SummaryPart, ChartAnchor>();
					foreach (var part in new[] { SummaryPart.Entry, SummaryPart.Exit, SummaryPart.InitialStop })
					{
						int valueIdx;
						DateTime time;
						switch (part)
						{
						case SummaryPart.Entry:
							valueIdx = indexMap[SummaryPart.Entry] + 1;
							time = entryTime;
							break;
						case SummaryPart.InitialStop:
							valueIdx = indexMap[SummaryPart.InitialStop];
							time = entryTime;
							break;
						case SummaryPart.Exit:
							valueIdx = indexMap[SummaryPart.Exit] + 1;
							time = exitTime;
							break;
						default:
							throw new ArgumentOutOfRangeException();
						}

						double price;
						anchors[part] = double.TryParse(trade[valueIdx], out price) ? new ChartAnchor(time, double.Parse(trade[valueIdx]), ChartControl) : null;
					}

					if (anchors.Values.Any(v => v == null))
						continue;

					var tradeDrawing = (ARC_QuickTester_ManualTestTrade)DrawingTool.GetByTagOrNew(this, pos == MarketPosition.Long ? typeof(ARC_QuickTester_ManualLongTrade) : typeof(ARC_QuickTester_ManualShortTrade), string.Join("\t", trade), "");
					if (tradeDrawing == null)
						continue;

					SetManualTradeColors(tradeDrawing);
					DrawingTool.SetDrawingToolCommonValues(tradeDrawing, Guid.NewGuid().ToString(), true, this, false);
					tradeDrawing.EntryAnchor = anchors[SummaryPart.Entry];
					tradeDrawing.InitialStopLossAnchor = anchors[SummaryPart.InitialStop];
					tradeDrawing.ExitAnchor = anchors[SummaryPart.Exit];
					tradeDrawing.SetState(State.Active);
				}
			}

			ForceRefresh();
		}

		private void DeleteTradesButton_Click(object sender, RoutedEventArgs e)
		{
			foreach (var t in ChartPanel.ChartObjects.OfType<ARC_QuickTester_ManualTestTrade>().ToList())
			{
				// Can only delete the drawings attached to the indicator, so we attach before deleting
				t.AttachedTo = new DrawingToolAttachedTo
				{
					ChartObject = this,
					Instrument = Instrument
				};
				RemoveDrawObject(t.Tag);
			}
		}

		private void OpenTemplateSpreadsheetButton_Click(object sender, RoutedEventArgs e)
		{
			Process.Start("https://docs.google.com/spreadsheets/d/1CvhHtH5y7d842IohRIpaDG9by_Qsa0t0QTERLqCxQqY");
		}
		#endregion

		#region Hotkey
		private static string HotKeyWasSetFile { get { return Path.Combine(Globals.UserDataDir, "ARC Temp", "QuickTesterHotKeysSet"); } }
		private static object hotKeyInitializationLock = new object();
		private void ResetHotKeysIfNotSet()
		{
			if (File.Exists(HotKeyWasSetFile))
				return;

			if (Monitor.IsEntered(hotKeyInitializationLock))
				return;

			Monitor.Enter(hotKeyInitializationLock);
			try
			{
				Globals.CreateSubDirs(HotKeyWasSetFile);
				File.Create(HotKeyWasSetFile);
				for (var dir = -1; dir <= 1; dir += 2)
				{
					var idealHotKey = new KeyGesture(dir == 1 ? Key.Up : Key.Down, ModifierKeys.Alt | ModifierKeys.Shift);
					var hotKeyTaken = HotKeysManager.ChartHotKeys.GetKeyGestures()
						.Select(hk => hk.GetDisplayStringForCulture(CultureInfo.CurrentCulture))
						.Contains(idealHotKey.GetDisplayStringForCulture(CultureInfo.CurrentCulture));
					if (hotKeyTaken)
						continue;

					HotKeysManager.ChartHotKeys.DrawingToolHotKeys.Add(new DrawingToolHotKey((dir == 1 ? typeof(ARC_QuickTester_ManualLongTrade) : typeof(ARC_QuickTester_ManualShortTrade)).FullName, idealHotKey));
				}

				HotKeysManager.SaveToXml();
				HotKeysManager.LoadFromXml();
			}
			finally
			{
				Monitor.Exit(hotKeyInitializationLock);
			}
		}
		#endregion

		private void UpdateAllManualTradeColors()
		{
			foreach (var t in ChartPanel.ChartObjects.OfType<ARC_QuickTester_ManualTestTrade>())
				SetManualTradeColors(t);
		}

		internal void SetManualTradeColors(ARC_QuickTester_ManualTestTrade t)
		{
			t.MfeBrush = MfeBrush;
			t.MaeBrush = MaeBrush;
			t.WinningConnectorBrush = WinningConnectorBrush;
			t.LosingConnectorBrush = LosingConnectorBrush;
			t.StopLossBrush = StopLossBrush;
			t.StopLossConnectorBrush = StopLossConnectorBrush;
			t.EntryMarkerBrush = EntryMarkerBrush;
			t.ExitMarkerBrush = ExitMarkerBrush;
			t.LabelBrush = LabelBrush;
			t.LongEntryArrowBrush = LongEntryArrowBrush;
			t.ShortEntryArrowBrush = ShortEntryArrowBrush;
			t.Opacity = Opacity;
		}

		private void SignalTaskWithButton(Button btn, Func<Task> task)
		{
			var prevForeground = btn.Foreground;
			btn.IsEnabled = false;
			btn.Foreground = Brushes.Red;

			ChartControl.Dispatcher.InvokeAsync(async () =>
			{
				try
				{
					await task();
				}
				finally
				{
					btn.Foreground = prevForeground;
					btn.IsEnabled = true;
				}
			});
		}

		private void ScrollToBar(int barIdx, ARC_QuickTester_SubjectAlignment alignment = ARC_QuickTester_SubjectAlignment.Center)
		{
			if (ChartControl == null || ChartControl.OwnerChart == null)
				return;

			if (State != State.Realtime && State != State.Historical)
			{
				NTMessageBoxSimple.Show(chartWindow, "Bars not loaded!", "Error!", MessageBoxButton.OK, MessageBoxImage.Error);
				return;
			}

			// Check if the active chart has a data series loaded
			var primaryBars = ChartControl.PrimaryBars;
			if (primaryBars == null)
			{
				NTMessageBoxSimple.Show(chartWindow, "No primary bars series found in chart control.", "Missing Primary Bars!", MessageBoxButton.OK, MessageBoxImage.Error);
				return;
			}

			ChartControl.ARC_QuickTester_ScrollToBar(barIdx, alignment);
		}

		private void MoveToTrade(int dir)
		{
			var trades = ChartPanel.ChartObjects
				.OfType<ARC_QuickTester_ManualTestTrade>()
				.OrderBy(t => t.ExitAnchor.Time)
				.ToArray();
			if (trades.Length == 0)
			{
				NTMessageBoxSimple.Show(chartWindow, "No trades yet!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
				return;
			}

			var targetScrollBar = ChartControl.ARC_QuickTester_GetScrollbar().Value - ScrollToBarMargin;
			var nextTrade = dir == 1
				? trades
					.SkipWhile(t => Bars.GetBar(t.ExitAnchor.Time) <= targetScrollBar)
					.FirstOrDefault()
				: trades
					.Reverse()
					.SkipWhile(t => Bars.GetBar(t.ExitAnchor.Time) >= targetScrollBar)
					.FirstOrDefault();

			if (nextTrade == null)
			{
				NTMessageBoxSimple.Show(chartWindow, "No trades " + (dir == 1 ? "ahead" : "behind") + "!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
				return;
			}

			var entryBar = Bars.GetBar(nextTrade.EntryAnchor.Time);
			var exitBar = Bars.GetBar(nextTrade.ExitAnchor.Time);
			ChartControl.ARC_QuickTester_SetViewportWidth(Math.Max(0, (exitBar - entryBar) + 1) + 10);
			ScrollToBar(exitBar + ScrollToBarMargin, ARC_QuickTester_SubjectAlignment.Right);
		}

		private bool TryDecodeTradeDateTime(string dateTimeStr, out DateTime result)
		{
			var dateStr = dateTimeStr.Split(' ')[0];
			if (!DateTime.TryParseExact(dateStr, new[] { "yyyy-MM-dd" }, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out result))
				return false;

			var timeStr = dateTimeStr.Split(' ')[1];
			TimeSpan time;
			if (!TimeSpan.TryParse(timeStr, out time))
				return false;
			result += time;
			return true;
		}

		private int GetNeighboringValidTime(int dir, int startBar)
		{
			if (sessionChange.GetValueAt(startBar))
				startBar += dir;

			for (var i = startBar; dir == 1 ? i <= CurrentBar : i > 0; i += dir)
				if (sessionChange.GetValueAt(i))
					return i;

			return -1;
		}

		private void MoveToNeighboringValidTime(int dir, int startBar)
		{
			var bar = GetNeighboringValidTime(dir, startBar);
			if (bar == -1)
			{
				NTMessageBox.ShowFitToContent("No more valid periods " + (dir == 1 ? "after" : "before") + " visible bars!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
				return;
			}

			ScrollToBar(bar, ARC_QuickTester_SubjectAlignment.Right);
		}

		private bool IsValidTradeTime(DateTime dt)
		{
			if (LimitTimeOfDay && !dt.ARC_QuickTester_InRange(WindowStartHr, WindowStartMinute, WindowEndHr, WindowEndMinute))
				return false;

			switch (dt.DayOfWeek)
			{
			case DayOfWeek.Monday:
				return IncludeMondays;
			case DayOfWeek.Tuesday:
				return IncludeTuesday;
			case DayOfWeek.Wednesday:
				return IncludeWednesday;
			case DayOfWeek.Thursday:
				return IncludeThursday;
			case DayOfWeek.Friday:
				return IncludeFriday;
			case DayOfWeek.Saturday:
				return IncludeSaturday;
			case DayOfWeek.Sunday:
				return IncludeSunday;
			default:
				throw new ArgumentOutOfRangeException();
			}
		}

		private DateTime RoundToBarTime(DateTime time)
		{
			var slotIdx = Math.Ceiling(ChartControl.GetSlotIndexByTime(time));
			return ChartControl.GetTimeBySlotIndex(slotIdx);
		}

		private bool InstrumentsMatch(string name1, string name2, bool allowMiniMicroMismatch)
		{
			var regexBreakdown = new[] { name1, name2 }
				.Select(n => Regex.Match(n, @"(?<symbol>\w[\w\d]) (?<expiry>\w[\w\d])?"))
				.ToArray();

			// Both instruments must either be futures, with an expiry, or another type, without one. If one has an expiry and the other doesn't, they can't match
			if (regexBreakdown[0].Groups["expiry"].Value != regexBreakdown[1].Groups["expiry"].Value)
				return false;

			// If both instruments symbol without expiry matches, return true
			var symbols = regexBreakdown
				.Select(r => r.Groups["symbol"].Value)
				.ToArray();
			if (symbols[0] == symbols[1])
				return true;

			if (!allowMiniMicroMismatch)
				return false;

			// If one instrument is the mini and the other the micro, of the same underlying asset, they count as a match
			var miniMicroPairs = new[] { new[] { "MYM", "YM" }, new[] { "M2K", "RTY" }, new[] { "MES", "ES" }, new[] { "MNQ", "NQ" } };
			return miniMicroPairs.Any(pair => !pair.Except(symbols).Any());
		}

		#region Parameters
		#region Time Window Parameters
		public const string TimeParametersGroupName = "Parameters (Trade Times)";

		[NinjaScriptProperty]
		[Display(Name = "Limit Time of Day", GroupName = TimeParametersGroupName, Order = 0)]
		public bool LimitTimeOfDay { get; set; }

		[Range(0, 23), NinjaScriptProperty]
		[Display(Name = "Window Start Hr", GroupName = TimeParametersGroupName, Order = 1)]
		public int WindowStartHr { get; set; }

		[Range(0, 59), NinjaScriptProperty]
		[Display(Name = "Window Start Minute", GroupName = TimeParametersGroupName, Order = 2)]
		public int WindowStartMinute { get; set; }

		[Range(0, 23), NinjaScriptProperty]
		[Display(Name = "Window End Hr", GroupName = TimeParametersGroupName, Order = 3)]
		public int WindowEndHr { get; set; }

		[Range(0, 59), NinjaScriptProperty]
		[Display(Name = "Window End Minute", GroupName = TimeParametersGroupName, Order = 4)]
		public int WindowEndMinute { get; set; }
		#endregion

		#region Weekday Inclusion Parameters
		public const string DayOfWeekParametersGroupName = "Parameters (Days of the Week)";

		[NinjaScriptProperty, Display(Name = "Include Mondays", GroupName = DayOfWeekParametersGroupName, Order = 0)]
		public bool IncludeMondays { get; set; }

		[NinjaScriptProperty, Display(Name = "Include Tuesday", GroupName = DayOfWeekParametersGroupName, Order = 1)]
		public bool IncludeTuesday { get; set; }

		[NinjaScriptProperty, Display(Name = "Include Wednesday", GroupName = DayOfWeekParametersGroupName, Order = 2)]
		public bool IncludeWednesday { get; set; }

		[NinjaScriptProperty, Display(Name = "Include Thursday", GroupName = DayOfWeekParametersGroupName, Order = 3)]
		public bool IncludeThursday { get; set; }

		[NinjaScriptProperty, Display(Name = "Include Friday", GroupName = DayOfWeekParametersGroupName, Order = 4)]
		public bool IncludeFriday { get; set; }

		[NinjaScriptProperty, Display(Name = "Include Saturday", GroupName = DayOfWeekParametersGroupName, Order = 5)]
		public bool IncludeSaturday { get; set; }

		[NinjaScriptProperty, Display(Name = "Include Sunday", GroupName = DayOfWeekParametersGroupName, Order = 6)]
		public bool IncludeSunday { get; set; }
		#endregion

		#region Display Parameters
		public const string DisplayParametersGroupName = "Parameters (Display)";

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "MFE Color", GroupName = DisplayParametersGroupName, Order = 0)]
		public Brush MfeBrush { get; set; }

		[Browsable(false)]
		public string MfeBrushSerializable
		{
			get { return Serialize.BrushToString(MfeBrush); }
			set { MfeBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "MAE Color", GroupName = DisplayParametersGroupName, Order = 1)]
		public Brush MaeBrush { get; set; }

		[Browsable(false)]
		public string MaeBrushSerializable
		{
			get { return Serialize.BrushToString(MaeBrush); }
			set { MaeBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Winning Trade Line Color", GroupName = DisplayParametersGroupName, Order = 2)]
		public Brush WinningConnectorBrush { get; set; }

		[Browsable(false)]
		public string WinningConnectorBrushSerializable
		{
			get { return Serialize.BrushToString(WinningConnectorBrush); }
			set { WinningConnectorBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Losing Trade Line Color", GroupName = DisplayParametersGroupName, Order = 3)]
		public Brush LosingConnectorBrush { get; set; }

		[Browsable(false)]
		public string LosingConnectorBrushSerializable
		{
			get { return Serialize.BrushToString(LosingConnectorBrush); }
			set { LosingConnectorBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Stop Loss Color", GroupName = DisplayParametersGroupName, Order = 4)]
		public Brush StopLossBrush { get; set; }

		[Browsable(false)]
		public string StopLossBrushSerializable
		{
			get { return Serialize.BrushToString(StopLossBrush); }
			set { StopLossBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Stop Loss Connector Color", GroupName = DisplayParametersGroupName, Order = 5)]
		public Brush StopLossConnectorBrush { get; set; }

		[Browsable(false)]
		public string StopLossConnectorBrushSerializable
		{
			get { return Serialize.BrushToString(StopLossConnectorBrush); }
			set { StopLossConnectorBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Entry Marker Color", GroupName = DisplayParametersGroupName, Order = 6)]
		public Brush EntryMarkerBrush { get; set; }

		[Browsable(false)]
		public string EntryMarkerBrushSerializable
		{
			get { return Serialize.BrushToString(EntryMarkerBrush); }
			set { EntryMarkerBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Exit Marker Color", GroupName = DisplayParametersGroupName, Order = 7)]
		public Brush ExitMarkerBrush { get; set; }

		[Browsable(false)]
		public string ExitMarkerBrushSerializable
		{
			get { return Serialize.BrushToString(ExitMarkerBrush); }
			set { ExitMarkerBrush = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Label Brush", GroupName = DisplayParametersGroupName, Order = 8)]
		public Brush LabelBrush { get; set; }

		[Browsable(false)]
		public string LabelBrushSerializable
		{
			get { return LabelBrush == null ? "" : Serialize.BrushToString(LabelBrush); }
			set { LabelBrush = string.IsNullOrWhiteSpace(value) ? null : Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Long Entry Arrow Brush", GroupName = DisplayParametersGroupName, Order = 9)]
		public Brush LongEntryArrowBrush { get; set; }

		[Browsable(false)]
		public string LongEntryArrowBrushSerializable
		{
			get { return LongEntryArrowBrush == null ? "" : Serialize.BrushToString(LongEntryArrowBrush); }
			set { LongEntryArrowBrush = string.IsNullOrWhiteSpace(value) ? null : Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Short Entry Arrow Brush", GroupName = DisplayParametersGroupName, Order = 10)]
		public Brush ShortEntryArrowBrush { get; set; }

		[Browsable(false)]
		public string ShortEntryArrowBrushSerializable
		{
			get { return ShortEntryArrowBrush == null ? "" : Serialize.BrushToString(ShortEntryArrowBrush); }
			set { ShortEntryArrowBrush = string.IsNullOrWhiteSpace(value) ? null : Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[Range(1, 100)]
		[Display(Name = "Opacity", GroupName = DisplayParametersGroupName, Order = 11)]
		public float Opacity { get; set; }
		#endregion

		#region Menu Placement Parameters
		public const string MenuParametersGroupName = "Parameters (Menu Placement)";

		[NinjaScriptProperty]
		[Display(Name = "Menu Location", GroupName = MenuParametersGroupName, Order = 0)]
		public ARC_QuickTester_ParentAnchorPoint MenuLocation { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Menu Orientation", GroupName = MenuParametersGroupName, Order = 1)]
		public ARC_QuickTester_ControlOrientation MenuOrientation { get; set; }
		#endregion

		#region Button Parameters
		public const string ButtonParametersGroupName = "Parameters (Visible Menu Buttons)";

		[NinjaScriptProperty]
		[Display(Name = "Upload Chart Capture", GroupName = ButtonParametersGroupName, Order = 0)]
		public bool ShowUploadChartCaptureButton
		{
			get { return buttonIsVisible[ButtonType.UploadChartCapture]; }
			set { buttonIsVisible[ButtonType.UploadChartCapture] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Upload Screen Capture", GroupName = ButtonParametersGroupName, Order = 1)]
		public bool ShowUploadScreenCaptureButton
		{
			get { return buttonIsVisible[ButtonType.UploadScreenCapture]; }
			set { buttonIsVisible[ButtonType.UploadScreenCapture] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Randomize Time", GroupName = ButtonParametersGroupName, Order = 2)]
		public bool ShowRandomizeTimeButton
		{
			get { return buttonIsVisible[ButtonType.RandomizeTime]; }
			set { buttonIsVisible[ButtonType.RandomizeTime] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Previous Valid Time", GroupName = ButtonParametersGroupName, Order = 3)]
		public bool ShowPreviousValidTimeButton
		{
			get { return buttonIsVisible[ButtonType.PreviousValidTime]; }
			set { buttonIsVisible[ButtonType.PreviousValidTime] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Next Valid Time", GroupName = ButtonParametersGroupName, Order = 4)]
		public bool ShowNextValidTimeButton
		{
			get { return buttonIsVisible[ButtonType.NextValidTime]; }
			set { buttonIsVisible[ButtonType.NextValidTime] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Mass Capture", GroupName = ButtonParametersGroupName, Order = 5)]
		public bool ShowMassCaptureButton
		{
			get { return buttonIsVisible[ButtonType.MassCapture]; }
			set { buttonIsVisible[ButtonType.MassCapture] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Previous Trade", GroupName = ButtonParametersGroupName, Order = 6)]
		public bool ShowPreviousTradeButton
		{
			get { return buttonIsVisible[ButtonType.PreviousTrade]; }
			set { buttonIsVisible[ButtonType.PreviousTrade] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Next Trade", GroupName = ButtonParametersGroupName, Order = 7)]
		public bool ShowNextTradeButton
		{
			get { return buttonIsVisible[ButtonType.NextTrade]; }
			set { buttonIsVisible[ButtonType.NextTrade] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Import Trades", GroupName = ButtonParametersGroupName, Order = 8)]
		public bool ShowImportTradesButton
		{
			get { return buttonIsVisible[ButtonType.ImportTrades]; }
			set { buttonIsVisible[ButtonType.ImportTrades] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Open Template Spreadsheet", GroupName = ButtonParametersGroupName, Order = 9)]
		public bool ShowOpenTemplateSpreadsheetButton
		{
			get { return buttonIsVisible[ButtonType.OpenTemplateSpreadsheet]; }
			set { buttonIsVisible[ButtonType.OpenTemplateSpreadsheet] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Delete Trades", GroupName = ButtonParametersGroupName, Order = 10)]
		public bool ShowDeleteTradesButton
		{
			get { return buttonIsVisible[ButtonType.DeleteTrades]; }
			set { buttonIsVisible[ButtonType.DeleteTrades] = value; }
		}
		#endregion

		#region Misc Parameters
		public const string MiscParametersGroupName = "Parameters";

		[NinjaScriptProperty]
		[Display(Name = "Include Headers in Mass Copy", GroupName = MiscParametersGroupName, Order = 0)]
		public bool IncludeHeadersInMassCopy { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Include All Instruments in Mass Copy", GroupName = MiscParametersGroupName, Order = 1, Description = "If true will include trades made on other charts on other instruments, otherwise will only include trades made against this symbol")]
		public bool IncludeAllInstrumentsInMassCopy { get; set; }
		#endregion
		#endregion
	}
}

internal class ARC_QuickTester_ImportTradesWindow : NTWindow, INotifyPropertyChanged
{
	public event PropertyChangedEventHandler PropertyChanged;

	public int TimeOffset
	{
		get { return timeOffset; }
		set
		{
			if (value == timeOffset)
				return;
			timeOffset = value;
			OnPropertyChanged();
		}
	}
	private int timeOffset;

	public bool RoundTimes
	{
		get { return roundTimes; }
		set
		{
			if (value == roundTimes)
				return;
			roundTimes = value;
			OnPropertyChanged();
		}
	}
	private bool roundTimes = true;

	public ARC_QuickTester_ImportTradesWindow()
	{
		Title = "Import Trades";
		Topmost = true;
		SizeToContent = SizeToContent.WidthAndHeight;
		ResizeMode = ResizeMode.NoResize;
		IsMaximizeEnabled = false;

		// Setup the main grid, and child placement in it
		var mainGrid = new Grid
		{
			ColumnDefinitions =
			{
				new ColumnDefinition {Width = new GridLength(1, GridUnitType.Star), MinWidth = 100},
				new ColumnDefinition {Width = GridLength.Auto},
				new ColumnDefinition {Width = GridLength.Auto}
			},
			RowDefinitions =
			{
				new RowDefinition {Height = new GridLength(5)},
				new RowDefinition {Height = GridLength.Auto},
				new RowDefinition {Height = new GridLength(10)},
				new RowDefinition {Height = GridLength.Auto}
			}
		};

		var settingStackPanel = new StackPanel { Orientation = Orientation.Horizontal };
		Grid.SetRow(settingStackPanel, 1);
		Grid.SetColumn(settingStackPanel, 0);
		Grid.SetColumnSpan(settingStackPanel, 3);
		mainGrid.Children.Add(settingStackPanel);

		// Time zone offset handling
		var offsetTooltip = "Add/Subtract this many hours from your entry and exit times";
		settingStackPanel.Children.Add(new Label
		{
			Content = "Import Time Adjustment",
			Foreground = ARC_QuickTester_SkinResourceHelper.ARC_QuickTester_GetResource(ARC_QuickTester_BrushResourceKeys.PropertiesSlimText),
			Margin = new Thickness(10, 0, 5, 0),
			ToolTip = offsetTooltip
		});

		var timeOffsetComboBox = new ComboBox
		{
			ItemsSource = new[]
			{
				-12,
				-11,
				-10,
				-9,
				-8,
				-7,
				-6,
				-5,
				-4,
				-3,
				-2,
				-1,
				0,
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8,
				9,
				10,
				11,
				12,
			},
			ToolTip = offsetTooltip
		};
		var timeOffsetBinding = new Binding
		{
			Source = this,
			Path = new PropertyPath("TimeOffset"),
			Mode = BindingMode.TwoWay
		};
		timeOffsetComboBox.SetBinding(Selector.SelectedItemProperty, timeOffsetBinding);
		settingStackPanel.Children.Add(timeOffsetComboBox);

		// Time rounding handling
		var roundTimesCheckBox = new CheckBox
		{
			IsChecked = true,
			Content = "Round Times",
			Margin = new Thickness(20, 0, 0, 0),
			ToolTip = "Centers trades horizontally on the closest available bar"
		};
		var roundTimesBinding = new Binding
		{
			Source = this,
			Path = new PropertyPath("RoundTimes"),
			Mode = BindingMode.TwoWay
		};
		roundTimesCheckBox.SetBinding(ToggleButton.IsCheckedProperty, roundTimesBinding);
		settingStackPanel.Children.Add(roundTimesCheckBox);

		// Setup ok and cancel buttons
		var okButton = new Button { Content = "Ok", IsDefault = true };
		okButton.Click += OkButton_Click;
		Grid.SetRow(okButton, 3);
		Grid.SetColumn(okButton, 1);
		mainGrid.Children.Add(okButton);

		var cancelButton = new Button { Content = "Cancel", IsCancel = true, Margin = new Thickness(20, 0, 0, 0) };
		okButton.Click += CancelButton_Click;
		Grid.SetRow(cancelButton, 3);
		Grid.SetColumn(cancelButton, 2);
		mainGrid.Children.Add(cancelButton);

		Content = mainGrid;
	}

	private void CancelButton_Click(object sender, RoutedEventArgs e)
	{
		Close();
	}

	private void OkButton_Click(object sender, RoutedEventArgs e)
	{
		DialogResult = true;
		Close();
	}

	protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
	{
		var handler = PropertyChanged;
		if (handler != null)
			handler(this, new PropertyChangedEventArgs(propertyName));
	}
}

public enum ARC_QuickTester_ParentAnchorPoint
{
	TopLeft,
	Left,
	BottomLeft,
	Bottom,
	BottomRight,
	Right,
	TopRight,
	Top
}

public enum ARC_QuickTester_ControlOrientation
{
	Horizontal,
	Vertical
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_QuickTester[] cacheARC_QuickTester;
		public ARC.ARC_QuickTester ARC_QuickTester(bool limitTimeOfDay, int windowStartHr, int windowStartMinute, int windowEndHr, int windowEndMinute, bool includeMondays, bool includeTuesday, bool includeWednesday, bool includeThursday, bool includeFriday, bool includeSaturday, bool includeSunday, Brush mfeBrush, Brush maeBrush, Brush winningConnectorBrush, Brush losingConnectorBrush, Brush stopLossBrush, Brush stopLossConnectorBrush, Brush entryMarkerBrush, Brush exitMarkerBrush, Brush labelBrush, Brush longEntryArrowBrush, Brush shortEntryArrowBrush, float opacity, ARC_QuickTester_ParentAnchorPoint menuLocation, ARC_QuickTester_ControlOrientation menuOrientation, bool showUploadChartCaptureButton, bool showUploadScreenCaptureButton, bool showRandomizeTimeButton, bool showPreviousValidTimeButton, bool showNextValidTimeButton, bool showMassCaptureButton, bool showPreviousTradeButton, bool showNextTradeButton, bool showImportTradesButton, bool showOpenTemplateSpreadsheetButton, bool showDeleteTradesButton, bool includeHeadersInMassCopy, bool includeAllInstrumentsInMassCopy)
		{
			return ARC_QuickTester(Input, limitTimeOfDay, windowStartHr, windowStartMinute, windowEndHr, windowEndMinute, includeMondays, includeTuesday, includeWednesday, includeThursday, includeFriday, includeSaturday, includeSunday, mfeBrush, maeBrush, winningConnectorBrush, losingConnectorBrush, stopLossBrush, stopLossConnectorBrush, entryMarkerBrush, exitMarkerBrush, labelBrush, longEntryArrowBrush, shortEntryArrowBrush, opacity, menuLocation, menuOrientation, showUploadChartCaptureButton, showUploadScreenCaptureButton, showRandomizeTimeButton, showPreviousValidTimeButton, showNextValidTimeButton, showMassCaptureButton, showPreviousTradeButton, showNextTradeButton, showImportTradesButton, showOpenTemplateSpreadsheetButton, showDeleteTradesButton, includeHeadersInMassCopy, includeAllInstrumentsInMassCopy);
		}

		public ARC.ARC_QuickTester ARC_QuickTester(ISeries<double> input, bool limitTimeOfDay, int windowStartHr, int windowStartMinute, int windowEndHr, int windowEndMinute, bool includeMondays, bool includeTuesday, bool includeWednesday, bool includeThursday, bool includeFriday, bool includeSaturday, bool includeSunday, Brush mfeBrush, Brush maeBrush, Brush winningConnectorBrush, Brush losingConnectorBrush, Brush stopLossBrush, Brush stopLossConnectorBrush, Brush entryMarkerBrush, Brush exitMarkerBrush, Brush labelBrush, Brush longEntryArrowBrush, Brush shortEntryArrowBrush, float opacity, ARC_QuickTester_ParentAnchorPoint menuLocation, ARC_QuickTester_ControlOrientation menuOrientation, bool showUploadChartCaptureButton, bool showUploadScreenCaptureButton, bool showRandomizeTimeButton, bool showPreviousValidTimeButton, bool showNextValidTimeButton, bool showMassCaptureButton, bool showPreviousTradeButton, bool showNextTradeButton, bool showImportTradesButton, bool showOpenTemplateSpreadsheetButton, bool showDeleteTradesButton, bool includeHeadersInMassCopy, bool includeAllInstrumentsInMassCopy)
		{
			if (cacheARC_QuickTester != null)
				for (int idx = 0; idx < cacheARC_QuickTester.Length; idx++)
					if (cacheARC_QuickTester[idx] != null && cacheARC_QuickTester[idx].LimitTimeOfDay == limitTimeOfDay && cacheARC_QuickTester[idx].WindowStartHr == windowStartHr && cacheARC_QuickTester[idx].WindowStartMinute == windowStartMinute && cacheARC_QuickTester[idx].WindowEndHr == windowEndHr && cacheARC_QuickTester[idx].WindowEndMinute == windowEndMinute && cacheARC_QuickTester[idx].IncludeMondays == includeMondays && cacheARC_QuickTester[idx].IncludeTuesday == includeTuesday && cacheARC_QuickTester[idx].IncludeWednesday == includeWednesday && cacheARC_QuickTester[idx].IncludeThursday == includeThursday && cacheARC_QuickTester[idx].IncludeFriday == includeFriday && cacheARC_QuickTester[idx].IncludeSaturday == includeSaturday && cacheARC_QuickTester[idx].IncludeSunday == includeSunday && cacheARC_QuickTester[idx].MfeBrush == mfeBrush && cacheARC_QuickTester[idx].MaeBrush == maeBrush && cacheARC_QuickTester[idx].WinningConnectorBrush == winningConnectorBrush && cacheARC_QuickTester[idx].LosingConnectorBrush == losingConnectorBrush && cacheARC_QuickTester[idx].StopLossBrush == stopLossBrush && cacheARC_QuickTester[idx].StopLossConnectorBrush == stopLossConnectorBrush && cacheARC_QuickTester[idx].EntryMarkerBrush == entryMarkerBrush && cacheARC_QuickTester[idx].ExitMarkerBrush == exitMarkerBrush && cacheARC_QuickTester[idx].LabelBrush == labelBrush && cacheARC_QuickTester[idx].LongEntryArrowBrush == longEntryArrowBrush && cacheARC_QuickTester[idx].ShortEntryArrowBrush == shortEntryArrowBrush && cacheARC_QuickTester[idx].Opacity == opacity && cacheARC_QuickTester[idx].MenuLocation == menuLocation && cacheARC_QuickTester[idx].MenuOrientation == menuOrientation && cacheARC_QuickTester[idx].ShowUploadChartCaptureButton == showUploadChartCaptureButton && cacheARC_QuickTester[idx].ShowUploadScreenCaptureButton == showUploadScreenCaptureButton && cacheARC_QuickTester[idx].ShowRandomizeTimeButton == showRandomizeTimeButton && cacheARC_QuickTester[idx].ShowPreviousValidTimeButton == showPreviousValidTimeButton && cacheARC_QuickTester[idx].ShowNextValidTimeButton == showNextValidTimeButton && cacheARC_QuickTester[idx].ShowMassCaptureButton == showMassCaptureButton && cacheARC_QuickTester[idx].ShowPreviousTradeButton == showPreviousTradeButton && cacheARC_QuickTester[idx].ShowNextTradeButton == showNextTradeButton && cacheARC_QuickTester[idx].ShowImportTradesButton == showImportTradesButton && cacheARC_QuickTester[idx].ShowOpenTemplateSpreadsheetButton == showOpenTemplateSpreadsheetButton && cacheARC_QuickTester[idx].ShowDeleteTradesButton == showDeleteTradesButton && cacheARC_QuickTester[idx].IncludeHeadersInMassCopy == includeHeadersInMassCopy && cacheARC_QuickTester[idx].IncludeAllInstrumentsInMassCopy == includeAllInstrumentsInMassCopy && cacheARC_QuickTester[idx].EqualsInput(input))
						return cacheARC_QuickTester[idx];
			return CacheIndicator<ARC.ARC_QuickTester>(new ARC.ARC_QuickTester(){ LimitTimeOfDay = limitTimeOfDay, WindowStartHr = windowStartHr, WindowStartMinute = windowStartMinute, WindowEndHr = windowEndHr, WindowEndMinute = windowEndMinute, IncludeMondays = includeMondays, IncludeTuesday = includeTuesday, IncludeWednesday = includeWednesday, IncludeThursday = includeThursday, IncludeFriday = includeFriday, IncludeSaturday = includeSaturday, IncludeSunday = includeSunday, MfeBrush = mfeBrush, MaeBrush = maeBrush, WinningConnectorBrush = winningConnectorBrush, LosingConnectorBrush = losingConnectorBrush, StopLossBrush = stopLossBrush, StopLossConnectorBrush = stopLossConnectorBrush, EntryMarkerBrush = entryMarkerBrush, ExitMarkerBrush = exitMarkerBrush, LabelBrush = labelBrush, LongEntryArrowBrush = longEntryArrowBrush, ShortEntryArrowBrush = shortEntryArrowBrush, Opacity = opacity, MenuLocation = menuLocation, MenuOrientation = menuOrientation, ShowUploadChartCaptureButton = showUploadChartCaptureButton, ShowUploadScreenCaptureButton = showUploadScreenCaptureButton, ShowRandomizeTimeButton = showRandomizeTimeButton, ShowPreviousValidTimeButton = showPreviousValidTimeButton, ShowNextValidTimeButton = showNextValidTimeButton, ShowMassCaptureButton = showMassCaptureButton, ShowPreviousTradeButton = showPreviousTradeButton, ShowNextTradeButton = showNextTradeButton, ShowImportTradesButton = showImportTradesButton, ShowOpenTemplateSpreadsheetButton = showOpenTemplateSpreadsheetButton, ShowDeleteTradesButton = showDeleteTradesButton, IncludeHeadersInMassCopy = includeHeadersInMassCopy, IncludeAllInstrumentsInMassCopy = includeAllInstrumentsInMassCopy }, input, ref cacheARC_QuickTester);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_QuickTester ARC_QuickTester(bool limitTimeOfDay, int windowStartHr, int windowStartMinute, int windowEndHr, int windowEndMinute, bool includeMondays, bool includeTuesday, bool includeWednesday, bool includeThursday, bool includeFriday, bool includeSaturday, bool includeSunday, Brush mfeBrush, Brush maeBrush, Brush winningConnectorBrush, Brush losingConnectorBrush, Brush stopLossBrush, Brush stopLossConnectorBrush, Brush entryMarkerBrush, Brush exitMarkerBrush, Brush labelBrush, Brush longEntryArrowBrush, Brush shortEntryArrowBrush, float opacity, ARC_QuickTester_ParentAnchorPoint menuLocation, ARC_QuickTester_ControlOrientation menuOrientation, bool showUploadChartCaptureButton, bool showUploadScreenCaptureButton, bool showRandomizeTimeButton, bool showPreviousValidTimeButton, bool showNextValidTimeButton, bool showMassCaptureButton, bool showPreviousTradeButton, bool showNextTradeButton, bool showImportTradesButton, bool showOpenTemplateSpreadsheetButton, bool showDeleteTradesButton, bool includeHeadersInMassCopy, bool includeAllInstrumentsInMassCopy)
		{
			return indicator.ARC_QuickTester(Input, limitTimeOfDay, windowStartHr, windowStartMinute, windowEndHr, windowEndMinute, includeMondays, includeTuesday, includeWednesday, includeThursday, includeFriday, includeSaturday, includeSunday, mfeBrush, maeBrush, winningConnectorBrush, losingConnectorBrush, stopLossBrush, stopLossConnectorBrush, entryMarkerBrush, exitMarkerBrush, labelBrush, longEntryArrowBrush, shortEntryArrowBrush, opacity, menuLocation, menuOrientation, showUploadChartCaptureButton, showUploadScreenCaptureButton, showRandomizeTimeButton, showPreviousValidTimeButton, showNextValidTimeButton, showMassCaptureButton, showPreviousTradeButton, showNextTradeButton, showImportTradesButton, showOpenTemplateSpreadsheetButton, showDeleteTradesButton, includeHeadersInMassCopy, includeAllInstrumentsInMassCopy);
		}

		public Indicators.ARC.ARC_QuickTester ARC_QuickTester(ISeries<double> input , bool limitTimeOfDay, int windowStartHr, int windowStartMinute, int windowEndHr, int windowEndMinute, bool includeMondays, bool includeTuesday, bool includeWednesday, bool includeThursday, bool includeFriday, bool includeSaturday, bool includeSunday, Brush mfeBrush, Brush maeBrush, Brush winningConnectorBrush, Brush losingConnectorBrush, Brush stopLossBrush, Brush stopLossConnectorBrush, Brush entryMarkerBrush, Brush exitMarkerBrush, Brush labelBrush, Brush longEntryArrowBrush, Brush shortEntryArrowBrush, float opacity, ARC_QuickTester_ParentAnchorPoint menuLocation, ARC_QuickTester_ControlOrientation menuOrientation, bool showUploadChartCaptureButton, bool showUploadScreenCaptureButton, bool showRandomizeTimeButton, bool showPreviousValidTimeButton, bool showNextValidTimeButton, bool showMassCaptureButton, bool showPreviousTradeButton, bool showNextTradeButton, bool showImportTradesButton, bool showOpenTemplateSpreadsheetButton, bool showDeleteTradesButton, bool includeHeadersInMassCopy, bool includeAllInstrumentsInMassCopy)
		{
			return indicator.ARC_QuickTester(input, limitTimeOfDay, windowStartHr, windowStartMinute, windowEndHr, windowEndMinute, includeMondays, includeTuesday, includeWednesday, includeThursday, includeFriday, includeSaturday, includeSunday, mfeBrush, maeBrush, winningConnectorBrush, losingConnectorBrush, stopLossBrush, stopLossConnectorBrush, entryMarkerBrush, exitMarkerBrush, labelBrush, longEntryArrowBrush, shortEntryArrowBrush, opacity, menuLocation, menuOrientation, showUploadChartCaptureButton, showUploadScreenCaptureButton, showRandomizeTimeButton, showPreviousValidTimeButton, showNextValidTimeButton, showMassCaptureButton, showPreviousTradeButton, showNextTradeButton, showImportTradesButton, showOpenTemplateSpreadsheetButton, showDeleteTradesButton, includeHeadersInMassCopy, includeAllInstrumentsInMassCopy);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_QuickTester ARC_QuickTester(bool limitTimeOfDay, int windowStartHr, int windowStartMinute, int windowEndHr, int windowEndMinute, bool includeMondays, bool includeTuesday, bool includeWednesday, bool includeThursday, bool includeFriday, bool includeSaturday, bool includeSunday, Brush mfeBrush, Brush maeBrush, Brush winningConnectorBrush, Brush losingConnectorBrush, Brush stopLossBrush, Brush stopLossConnectorBrush, Brush entryMarkerBrush, Brush exitMarkerBrush, Brush labelBrush, Brush longEntryArrowBrush, Brush shortEntryArrowBrush, float opacity, ARC_QuickTester_ParentAnchorPoint menuLocation, ARC_QuickTester_ControlOrientation menuOrientation, bool showUploadChartCaptureButton, bool showUploadScreenCaptureButton, bool showRandomizeTimeButton, bool showPreviousValidTimeButton, bool showNextValidTimeButton, bool showMassCaptureButton, bool showPreviousTradeButton, bool showNextTradeButton, bool showImportTradesButton, bool showOpenTemplateSpreadsheetButton, bool showDeleteTradesButton, bool includeHeadersInMassCopy, bool includeAllInstrumentsInMassCopy)
		{
			return indicator.ARC_QuickTester(Input, limitTimeOfDay, windowStartHr, windowStartMinute, windowEndHr, windowEndMinute, includeMondays, includeTuesday, includeWednesday, includeThursday, includeFriday, includeSaturday, includeSunday, mfeBrush, maeBrush, winningConnectorBrush, losingConnectorBrush, stopLossBrush, stopLossConnectorBrush, entryMarkerBrush, exitMarkerBrush, labelBrush, longEntryArrowBrush, shortEntryArrowBrush, opacity, menuLocation, menuOrientation, showUploadChartCaptureButton, showUploadScreenCaptureButton, showRandomizeTimeButton, showPreviousValidTimeButton, showNextValidTimeButton, showMassCaptureButton, showPreviousTradeButton, showNextTradeButton, showImportTradesButton, showOpenTemplateSpreadsheetButton, showDeleteTradesButton, includeHeadersInMassCopy, includeAllInstrumentsInMassCopy);
		}

		public Indicators.ARC.ARC_QuickTester ARC_QuickTester(ISeries<double> input , bool limitTimeOfDay, int windowStartHr, int windowStartMinute, int windowEndHr, int windowEndMinute, bool includeMondays, bool includeTuesday, bool includeWednesday, bool includeThursday, bool includeFriday, bool includeSaturday, bool includeSunday, Brush mfeBrush, Brush maeBrush, Brush winningConnectorBrush, Brush losingConnectorBrush, Brush stopLossBrush, Brush stopLossConnectorBrush, Brush entryMarkerBrush, Brush exitMarkerBrush, Brush labelBrush, Brush longEntryArrowBrush, Brush shortEntryArrowBrush, float opacity, ARC_QuickTester_ParentAnchorPoint menuLocation, ARC_QuickTester_ControlOrientation menuOrientation, bool showUploadChartCaptureButton, bool showUploadScreenCaptureButton, bool showRandomizeTimeButton, bool showPreviousValidTimeButton, bool showNextValidTimeButton, bool showMassCaptureButton, bool showPreviousTradeButton, bool showNextTradeButton, bool showImportTradesButton, bool showOpenTemplateSpreadsheetButton, bool showDeleteTradesButton, bool includeHeadersInMassCopy, bool includeAllInstrumentsInMassCopy)
		{
			return indicator.ARC_QuickTester(input, limitTimeOfDay, windowStartHr, windowStartMinute, windowEndHr, windowEndMinute, includeMondays, includeTuesday, includeWednesday, includeThursday, includeFriday, includeSaturday, includeSunday, mfeBrush, maeBrush, winningConnectorBrush, losingConnectorBrush, stopLossBrush, stopLossConnectorBrush, entryMarkerBrush, exitMarkerBrush, labelBrush, longEntryArrowBrush, shortEntryArrowBrush, opacity, menuLocation, menuOrientation, showUploadChartCaptureButton, showUploadScreenCaptureButton, showRandomizeTimeButton, showPreviousValidTimeButton, showNextValidTimeButton, showMassCaptureButton, showPreviousTradeButton, showNextTradeButton, showImportTradesButton, showOpenTemplateSpreadsheetButton, showDeleteTradesButton, includeHeadersInMassCopy, includeAllInstrumentsInMassCopy);
		}
	}
}

#endregion
