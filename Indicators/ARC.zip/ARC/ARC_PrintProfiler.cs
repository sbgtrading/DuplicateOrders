#define DoLicense
#define MODERATORS
//#define ENABLE_TRYCATCH_OBU
//#define STOPWATCH_OUTPUT
//#define USE_WPF_COORDS
//#define VOLUME_AVERAGES_ON_TRANSACTION_VOLUME 

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using System.Windows.Controls;
using System.Windows.Automation;
using System.Diagnostics;
using SharpDX.DirectWrite;
using NinjaTrader.Gui.NinjaScript;
using System.Reflection;
using System.Windows.Automation.Peers;
using System.Windows.Automation.Provider;
#endregion

#region -- Author / Infos version --
/*********************************************************************
************************* NSTA ************************
**********************************************************************
* Authors NT7 : xxx / Kriss { AzurITec }
* Author NT8 : Kriss { AzurITec }
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
v1.00   - 23.09.2016    + Conversion from NT7 to NT8b13 RC1 "as is".
                        + from original code not MC.NET modified code
                        + bench OBU with profile40 : 
                            => Loading Time : 9564ms on 2331 bars => 4,10ms/bar
                            => Loading Time : 9487ms on 2333 bars => 4,07ms/bar
                            => Loading Time : 9429ms on 2337 bars => 4,03ms/bar
                        + bench OBU with profile41 : 
                            => Loading Time : 10739ms on 2323 bars => 4,62ms/bar
                            => Loading Time : 10624ms on 2323 bars => 4,57ms/bar
                            => Loading Time : 10692ms on 2323 bars => 4,60ms/bar
----------------------------------------------------------------------
v1.01   - 31.10.2016    + Conversion from NT7 to NT8b14 RC2 "as is", with code optimization/sanity
----------------------------------------------------------------------
v1.02   - 02.11.2016    + Debug Toolbar problem 
                        + Removed Bench Print
----------------------------------------------------------------------
v1.03   - 15.11.2016    + #BUG001 : Bug fixed - TickSize made global -> Contacted NT support but response is crazy
                        + Bug fixed - CurrentBar inside Render is now CurrentBars[0]
                        + Compatible NT8.0.1
----------------------------------------------------------------------
v1.04   - 17.11.2016    + Bug fixed - OnMarketDepth #BUG002
----------------------------------------------------------------------
v1.05   - 18.11.2016    + Bug Fixed - #BUG003 : restore correct AntialiasMode
----------------------------------------------------------------------
v1.06   - 30.11.2016    + #RJBug001 fixed - WPF controls can't be initialized in global area because main thread is not STA => crash when opened in MarketAnalyzer
----------------------------------------------------------------------
v1.07   - 28.02.2017    + Added Compilation Licensing code
                        + Tested with 8.0.4.0
----------------------------------------------------------------------
v1.08   - 08.03.2017    + DD Menu Cyan
                        + New code for DD Menu on KeyDown Event
                        + Developping Profile overlay Fixed
----------------------------------------------------------------------
######################################################################
~~~~~~~~~~~~~~~~~~~~~~~~~ BUGS/ LIMITATIONS ~~~~~~~~~~~~~~~~~~~~~~~~~~
----------------------------------------------------------------------
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Tested So FAR ~~~~~~~~~~~~~~~~~~~~~~~~~~
Composite Setting {99%} => Conform to NT7 however I don't understand the start Hour setting on NT7 and 8
----------------------------------------------------------------------
v1.09   - 11.21.2017    + JQ
                        + Part 1 of BUG 12536 Fixed. When the " Demand Zone" (green area) has been partially tested, 
                          the tested price level within the zone is NOT changing color (Light Green). 
					    + This bug also fixes BUG 12639
                        + Added indicator version number on the property window.
----------------------------------------------------------------------
v1.10   - 12.09.2017    + JQ 12.09.2017
                        + Removed the following code as it's causing the PP to shift away from the SDV bar when the two bars
                        + SDV + PP + VMD are added to the same chart and the SDV are set to be seen infront of the PP. 
                        + Bug 12782, 12670
                        + Updated version from v1.09.11.21.2017 to v1.10.12.09.2017
----------------------------------------------------------------------    
v1.11   - 01.05.2018    + JQ
                        + BUG 13737 - Enhancement to have the ZOrder for PP to be in the background
                        + Updated version from v1.10.12.09.2017 to v1.11.01.05.2018
----------------------------------------------------------------------
v1.12   - 01.18.2018    + Ben Letto
			+ Permitted user to change font size of NetDeltaFont (netDeltaFont)
----------------------------------------------------------------------
v1.13   - 02.07.2018    + Ben Letto
			+ Added Stopwatch benchmarking to observe long load times - OnBarUpdate taking 15 to 30 minutes to complete
			+ Added try-catch block around OnBarUpdate to catch problem with DTN datafeed for Pamela Ludwig
----------------------------------------------------------------------
v1.14   - 02.13.2018    + Ben Letto
			+ Added "dynamic rect" code as a workaround for malfunctioning encrypted DLL version of indicator.  Manual Profile rectangles were not being recognized in DLL version of indicator, NT programming support gave workaround code
			+ In ChartPanel_MouseMove event, implemented ChartingExtensions call for accurate determination of mouse location
----------------------------------------------------------------------
v1.15   - 02.22.2018    + Ben Letto
	+ Overhaulled DXBrushes, making them global variables and instantiating them at the beginning of OnRender, disposing them at the end of OnRender
	+ Benchmarked TextFormat and TextLayout globalization and Disposing...found the optimum to be instantiating/disposing to be most efficient within the drawstring methods
	+ When BarWidth == 1, the bid/ask rectangles on bars are hidden, greatly improving performance when such data is unreadable
	+ Outlining of bars occurs only when there are less than 100 bars printing...greatly improves performance for minor visual detriment
----------------------------------------------------------------------
v1.16   - 03.11.2018    + Ben Letto
	+ Cleaned up Composite and Auto histograms, Text not printing in contrasting colors, removed repetitive comparisons to "Left", "Right", "Shape" with boolean variables
	+ Restored lost functionality of iCPHistogramOpacity on Composite histogram coloring
	+ Changed hardcoding: ChartControl.Properties.SnapMode = SnapMode.BarAndPrice to SnapMode.Bar
----------------------------------------------------------------------
v1.17   - 05.2.2018    + Ben Letto
	+ When price scale was condensed, the Composite profile would dropout if the "y3" went to 0.  I added a limit, y3 is always 1 or greater...this prevents the composite histo from dropping out
----------------------------------------------------------------------
*/
#endregion
/*
v1.17   - 07.28.2018   + Ben Letto
	+ Added audible alerts to TrappedTraders, DeltaDivergence and VolumeDivergence (AudibleAlerts class)
	+ Added TotVolume number above Delta volume numbers
	+ Added Net Delta heat box at bottom of chartf
v1.2   - 09.13.2018   + Ben Letto
	+ SortedLists changed to SortedDictionary - RoundToWholePip was changed to round all incoming price data to nearest tick
v1.3   - 09.20.2018   + Ben Letto
	+ tmpBarDataCollection changed to BarData_ABar...and it is being calculated only when necessary, to reduce UnhandledExceptions when collection changes after enumerator is established
v1.4   - 09.20.2018   + Ben Letto
	+ Corrected minor brush issue, the iIBBidColor3 was not being used in the OnRender method
v1.5 - found a brushDX that was not being disposed
1.6 -  Fixed DrawComp method, accessing lists while the index changed.
	   Added public series NearestDemandZoneHigh and NearestSupplyZoneLow
1.62 - Changed OnMarketDepth, converting Asks and Bids .ToArray() to eliminate multithreading issue
1.63 - Added "pMaxSizeForBigMoneySignal" parameter to limit volume spikes in the BigMoney calculation
----------------------------------------------------------------------
*/

//Search for #REMARQUE / #OVERLAY
public enum ARC_PrintProfiler_DataLimitType {Minutes,Bars,NoLimit}
public enum ARC_PrintProfiler_BidAskHistoScaling {IndividualBar, AllVisibleBars}
public enum ARC_PrintProfiler_DataBasis {Tick1=0, Second1=1, Second5=2, Second30=3, Minute1=4, Minute2=5, Minute3=6, Minute4=7, Minute5=8}
public enum ARC_PrintProfiler_ChartMarkers {Arrow, Triangle, Dot, Square, Diamond}
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public enum ARC_PrintProfiler_SignalTimingTypes {OnTick,OnClose,NoAlerts}

    #region -- Category Order --
    [CategoryOrder("Data", 0)]
    [CategoryOrder("Indicator Display",          10)]
    [CategoryOrder("Bar Display",                20)]
    [CategoryOrder("Print Display",              30)]
    [CategoryOrder("Bid/Ask Volume Visuals",     35)]
    [CategoryOrder("Inventory Display",          40)]
    [CategoryOrder("Profile (Bar)",              50)]
    [CategoryOrder("Profile (Composite)",        60)]
    [CategoryOrder("Profile (Manual)",           70)]
    [CategoryOrder("Profile (All)",              80)]
    [CategoryOrder("Volume Averages Set 1",      90)]
    [CategoryOrder("Volume Averages Set 2",     100)]
    [CategoryOrder("Zones Display",             110)]
    [CategoryOrder("Avg Stop Loss Calculators", 120)]
    [CategoryOrder("Signals Display",           130)]
    [CategoryOrder("Table Display",             135)]
    [CategoryOrder("BidAsk Histos",             140)]
    [CategoryOrder("ChartMarker Signals",       145)]
    [CategoryOrder("OrderFlowConfluence Signals", 150)]
    [CategoryOrder("Trapped Trader / Delta Divergence / Volume Divergence Signals", 160)]
    [CategoryOrder("BigMoney Signals",          170)]
	[CategoryOrder("UnfinishedBiz Signals",     180)]
    [CategoryOrder("VCR Alert",                 190)]
    [CategoryOrder("Bid/Ask Imbalances", 200)]
    [CategoryOrder("Block Trades",       210)]
	[CategoryOrder("DSA Alert",          220)]
    [CategoryOrder("Indicator Version",  500)]

    #endregion
    public class ARC_PrintProfiler : Indicator
    {
		private const int BUY = 1;
		private const int SELL = -1;
		private const int FLAT = 0;
        //-------------------------------- Variables -----------------------------
		private bool IsDebug = false;
		private bool IsRodneyJ = false;
		private DateTime LaunchedAt = DateTime.Now;

		private float BARRIER_LINE_HEIGHT = 22f;
		private double atr30_pts = 0;

		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "PrintProfiler";

//		private const string VERSION = "v1.63 6-Jun-2022";
//		private const string VERSION = "v1.7 17-Nov-2022";
//		private const string VERSION = "v1.8e ";  Removed the OFCL and OFCS, now just OFC.  Removed the WAV files for OFCL and OFCS, now just one WAV alert
		private const string VERSION = "v1.8 22-Feb-2023";
		[Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
		public string indicatorVersion { get { return VERSION; } }

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "721", "1043", "25900", "819", "27405"};//27405 is Annual Membership and 819 is old mastery program
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsTerminated = false;

#if STOPWATCH_OUTPUT
		private SortedDictionary<string,TimeSpan> BenStopwatch = new SortedDictionary<string,TimeSpan>();
#endif
        private const int pFOREXD       = 100000;
		private DateTime dt;
		private bool RunningFirstBar    = true;
		private int  ErrorCount         = 0;
		private int  LowBarWarningCount = 0;
		private int  line = 0;

        #region -- Variables --
        private int pVADPercent = 50;
        private int pAPLineWidth = 2;
        private bool pOutlineZones = true;
        private Brush pBidOutColor2 = Brushes.DarkRed;
        private DashStyleHelper pDashStyle1 = DashStyleHelper.Solid;
        private int pXOffset = 10;
        private int pArrowHeight = 0;
        private int pArrowBarWidth = 4;
        private int pArrowTipAdjust = 2;
        private int pBoxSpace = 1;
		private int fbi = 0;
		private int lbi = 0;
		private int MINFONTSIZE = 5;

        //-- composite profile --
        private DateTime R1Time = new DateTime(0), CurrentTime;
        private int CompositeStartBar = 0;
        SortedList<int, VolumeProfileS> CompositeProfiles = new SortedList<int, VolumeProfileS>();
		private int LastCompositeProfilesCount = 0;
        SortedDictionary<double, VolumeAtBA> compositeData = new SortedDictionary<double, VolumeAtBA>();

        //-- zones --
        private double TotalWidthOfAllZones = 0;
        private int TotalNumberOfZones = 0;
        private SortedList<int, List<Zone>> SupplyZones = new SortedList<int, List<Zone>>();
        private SortedList<int, List<Zone>> DemandZones = new SortedList<int, List<Zone>>();
        private List<double> AllPrices = new List<double>();
        private List<double> AllPrices2 = new List<double>();

        //-- others --
        private MouseManager MM;
        private int CBB = 0;
        private bool IsCurrentBar = false;
        private double PreviousVolume = 0;
        private int y1, y2, y3, y4, y5, y6, y7, y8, y9 = 0;
        private int x1, x2, x3, x4, x5, x6, x7, x8, x9 = 0;
        private Rect BidRectF2 = new Rect(0, 0, 0, 0);
        private Rect B1 = new Rect(0, 0, 0, 0);
        private Rect B2 = new Rect(0, 0, 0, 0);
        private Rect B3 = new Rect(0, 0, 0, 0);
        private List<Point> AboveVA = new List<Point>();
        private List<Point> InVA = new List<Point>();
        private List<Point> BelowVA = new List<Point>();
        private int gx = 0;

        private bool ReadyToClose = false;
        private SortedDictionary<int, SortedDictionary<double, PrintLevelDetails>> BarDataCollection = new SortedDictionary<int, SortedDictionary<double, PrintLevelDetails>>();
        private int ThisCurrentBar = 0;
        private SortedDictionary<double, PrintLevelDetails> thisBarData = new SortedDictionary<double, PrintLevelDetails>();
        private bool Initialized = false;
        private int TickDirection = 0;
        private List<double> TickLevels = new List<double>();
        private long PLastVolume;

        private SortedList<int, BarTotal> BarDataTotals = new SortedList<int, BarTotal>();
        private SortedList<int, VolumeProfileS> BarProfiles = new SortedList<int, VolumeProfileS>();

        private int MouseBarIndex = 0;
        private SortedDictionary<double, PriceBox> PriceBoxes = new SortedDictionary<double, PriceBox>();//#REMARQUE : can be simple list not sorted
        private int AverageBoxHeight = 0;
        private int TotalBoxHeight = 0;
        private int maxBarWidth = 1000;
        private int maxBarHeight = 1000;
        private int minBarHeight = 1;
		private double PriorTopPrice = 0;
		private double PriorBottomPrice = 0;
		private double TopPrice = 0;
		private double BottomPrice = 0;
        private SimpleFont GeneralFont = new SimpleFont("Arial", 12);
        private int AdjustFontAmount = 0;
        private int diff = 0;
        private int FinalDesiredMargin = 0;
        private int lastBarIndex = 0;
        private int ClickedZoneBar = 0;
        private double ClickedZoneTop = 0;
        private double ClickedZoneBottom = 0;
        private int XE = 0;
        private Rect BidRect = new Rect(0, 0, 0, 0);
        private Rect BidORect = new Rect(0, 0, 0, 0);
        private Rect BidRectF = new Rect(0, 0, 0, 0);
        private Rect BidRect5 = new Rect(0, 0, 0, 0);
        private const int bsp = 0;
        private const int bsp2 = 8;
        private Pen ZoneH = new Pen(Brushes.Black, 3), ButtonPen = new Pen(Brushes.Black, 1);
        private Brush ButtonBrush = Brushes.LightGray;
        private Brush ButtonTextBrush = Brushes.Black;

		private SimpleFont barprintFont = null;
        private SimpleFont ButtonFont = new SimpleFont("Arial", 12) { Bold = true };
        //-- Ladder --
        private bool FirstOnMarketDepthRun = false;
        private List<LadderRow> askRows = new List<LadderRow>();
        private List<LadderRow> bidRows = new List<LadderRow>();

        //--- curve
//        private double Price100P = 0;
//        private double Price0P = 0;
//        private int pOpacity1 = 100;
//        private int pButtonSpace = 6;
//        private SortedDictionary<double, int> AllLevels = new SortedDictionary<double, int>();
//        private int CB = 0;
//        private double CH = 0;
//        private double CL = 0;
//        private bool ZoneSnapHover = false;
//        private bool ZoneSnapHover2 = false;

        //------ used for calculations --
        private int PriceDigits = 0;
//        private string PriceString;
        private bool BarsAreMinute = false;

        private VolumeProfileS AP;

        //---------- print -------------
        private bool InButton1 = false;
        private bool InButton2 = false;
        List<int> PrintIndividualBars = new List<int>();
        List<int> ProfileIndividualBars = new List<int>();
        private int LastBlockWidth2 = 0;
        private int MaxTextWidth2 = 0;
        private double x1cp, x2cp, x4cp = 0;
        private Rect ThisRect = new Rect(0, 0, 0, 0);
        private Rect AskRect  = new Rect(0, 0, 0, 0);
        private Rect AskORect = new Rect(0, 0, 0, 0);

        private bool OverrideFill1 = false;
        private Rect BidSignalRect = new Rect(0, 0, 0, 0);
        private Rect AskSignalRect = new Rect(0, 0, 0, 0);

        //-------- Manual Profile --------------
		private const string MANUAL_PROFILE_TAG_SUFFIX = "_ManualProfile";
        private string HoveredRectangleTag = string.Empty;
        private int HoveredRectangleButton = 0;
        private SortedList<string, VolumeProfileS> ManualProfiles = new SortedList<string, VolumeProfileS>();
        private SortedList<string, int> ManualProfilesVE = new SortedList<string, int>();
        private SortedList<string, int> ManualProfilesLE = new SortedList<string, int>();
        private Rect BidRectF25 = new Rect(0, 0, 0, 0);
        private List<string> AllRectangles = new List<string>();
        private SortedList<string, int> ManualProfilesCB = new SortedList<string, int>();
        #endregion
		private bool   IsForex  = false;
		private double Opens00  = 0;
		private double Highs00  = 0;
		private double Lows00   = 0;
		private double Closes00 = 0;
		private double Highs01  = 0;
		private double Lows01   = 0;
		private double Highs10  = 0;
		private double Lows10   = 0;
		private double Closes10 = 0;
		private int BKG_DATA_ID = 1;

		private EMA ema_ma1, ema_ma2;
		private SMA sma_ma1, sma_ma2;
		private DateTime DataStartTime = DateTime.MinValue;
		private int DataStartBar = 1;
		private bool ImposeDataLimit = false;
		private int SoundAlertBar = 0;


        #region -- Variables Series --
        private Series<double> AllPivots;
        private Series<double> FinalHigh;
        private Series<double> FinalLow;
        private Series<double> CurveLow;
        private Series<double> CurveHigh;
        private Series<double> CurveLowZ;
        private Series<double> CurveHighZ;
        private Series<double> CurveLowF;
        private Series<double> CurveHighF;
        private Series<double> CurveBar;
        private Series<double> CurveBar2;
        private Series<double> lastDemandZoneHigh;//ben
        private Series<double> lastSupplyZoneLow;//ben
		private Series<double> nearestDemandZoneHigh;
		private Series<double> nearestSupplyZoneLow;
        private Series<double> BodyHigh, BodyLow;
        private Series<double> Direction;
        private Series<double> BARCL;
		private Series<double> BigMoneyBidAvg;
		private Series<double> BigMoneyAskAvg;
		private double CurrentBigMoneyBidAvg = 0;
		private double CurrentBigMoneyAskAvg = 0;
        #endregion
		private List<double> DynamicBlocks = new List<double>();
		private double AvgDynamicBlock = -1;//keep at -1 default
		private int DynBlockCalculationsCompleted = 0;
		private int MaxDynamicBlocksizeLookback = 0;
		private bool pEnableContinuousDynBlockSizeCalc = false;

        #region -- Stamp Series --
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
		private int iVA1StartBar = int.MaxValue;
		private int iVA2StartBar = int.MaxValue;
        private Series<double> MAVWAP;
        private Series<double> MAPOC;
        private Series<double> MACL;
        private Series<double> MACLH;
        private Series<double> MACLL;

        private Series<double> MA2VWAP;
        private Series<double> MA2POC;
        private Series<double> MA2CL;
        private Series<double> MA2CLH;
        private Series<double> MA2CLL;
#endif
        #endregion

        #region -- Exposed Series --
        private Series<double> CompPOC;
        private Series<double> CompVWAP;
        private Series<double> CompVAH1;
        private Series<double> CompVAL1;
        private Series<double> CompVAH2;
        private Series<double> CompVAL2;
        private Series<double> trappedtraderDefault;
        private Series<double> deltadivergenceDefault;
        private Series<double> volumedivergenceDefault;
        private Series<double> longSignalDefault;
        private Series<double> shortSignalDefault;
        private Series<double> longSignalsDefault;
        private Series<double> shortSignalsDefault;
        private Series<double> longSignalAllDefault;
        private Series<double> shortSignalAllDefault;
        private Series<double> longSignalsAllDefault;
        private Series<double> shortSignalsAllDefault;
        private Series<double> vCurve1;
        private Series<double> vCurve2;
        private Series<double> vCurve3;
        private Series<double> vCurve4;
        private Series<double> vCurve5;
        private Series<double> vCurveStatus;
        private Series<double> BARVAH;
        private Series<double> BARVAL;
        private Series<double> NETDELTA;
        private Series<double> VDSIGNALS;
        private Series<double> OFCSIGNALS;
        private Series<double> VCRSIGNALS;
        private Series<double> ManVWAP;

        private Series<double> BARVWAP;
        private Series<double> BARPOC;
        private Series<double> BARCLH;
        private Series<double> BARCLL;
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
		SMA sma_BARVWAP1;
		SMA sma_BARPOC1;
		SMA sma_BARCL1;
		SMA sma_BARCLH1;
		SMA sma_BARCLL1;
		SMA sma_BARVWAP2;
		SMA sma_BARPOC2;
		SMA sma_BARCL2;
		SMA sma_BARCLH2;
		SMA sma_BARCLL2;

		EMA ema_BARVWAP1;
		EMA ema_BARPOC1;
		EMA ema_BARCL1;
		EMA ema_BARCLH1;
		EMA ema_BARCLL1;
		EMA ema_BARVWAP2;
		EMA ema_BARPOC2;
		EMA ema_BARCL2;
		EMA ema_BARCLH2;
		EMA ema_BARCLL2;
#endif

        #endregion

        #region -- External Series --       
        private ATR avgTrueRange;
        #endregion

        #region -- Toolbar --
        private string toolbarname = "ARCPPToolBar", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private Grid indytoolbar;

        private Menu MenuControlContainer;
        private MenuItem MenuControl, miAvgStopFirstTouch, miShow_DSASignal, miDSA_Sensitivity, miDSA_OpacityOnBar, miDSA_OpacityOnHeatMapHisto, miDSA_OutlineWidthOnHeatMapHisto, miEnable_VCRSignal, miShow_VCR2Bar, miShow_VCR3Bar, miAbsolute_VCR3Bar;
		private MenuItem miShowImbalance, miShowImbalanceDots, miShowImbalanceTxt, miShowUnfinishedBiz, miBidAskHistoOpacity, miShowTable, miShowBigMoney, miBigMoneyAvgAsk, miBigMoneyAvgBid, miDynamicBlockAvgCalc;
        private TextBox nudMST1, nudMST2, nudCRV1, nudCRV2, nudPCS1, nudPCS2, nudPCS3, nudVA1, nudVA2;
        private ComboBox CompTypeCombo, VA1Combo, VA2Combo;
        private Button gCmdup;
        private Button gCmddw;
        private Label gLabel;
        private MenuItem miRecalculate1, miRecalculate2;
        #endregion
		private bool IsHistorical = true;

		SolidColorBrush[] NetDHeatMap_Brushes = new SolidColorBrush[20];
		SharpDX.Direct2D1.Brush[] NetDHeatMap_DXBrushes = new SharpDX.Direct2D1.Brush[20];
		SharpDX.Direct2D1.Brush DSA_BrushDX = null;//brush used to color the DSA signal rectangle around the HeatMap histo bars, and the price bar
		private Series<int> DSA_Signals;

		#region -- SharpDX brushes --
		SharpDX.Direct2D1.Brush iTxtBrushDX_BidAskVol = null;
		SharpDX.Direct2D1.Brush iTxtBrushDX_AskImbalance = null;
		SharpDX.Direct2D1.Brush iTxtBrushDX_BidImbalance = null;
		SharpDX.Direct2D1.Brush iTxtBrushDX_SmallBidAskVol = null;
		SharpDX.Direct2D1.Brush iTxtBrushDX_SmallAskImbalance = null;
		SharpDX.Direct2D1.Brush iTxtBrushDX_SmallBidImbalance = null;
		SharpDX.Direct2D1.Brush AxisDXBrush = null;
		SharpDX.Direct2D1.Brush iMPHistogramClusterDXBrush2=null;
		SharpDX.Direct2D1.Brush iBlocksDXBrush = null;
		SharpDX.Direct2D1.Brush iBlocks2DXBrush = null;
		SharpDX.Direct2D1.Brush ChartBackgroundBrushDX = null;

		SharpDX.Direct2D1.Brush OverrideBrush = null; 
//		SharpDX.Direct2D1.Brush iIBBidDXBrush = null;
		SharpDX.Direct2D1.Brush iIBBidDXBrush3 = null;
//		SharpDX.Direct2D1.Brush iIBAskDXBrush = null;
		SharpDX.Direct2D1.Brush iIBAskDXBrush3 = null;
//
//		SharpDX.Direct2D1.Brush iMPBarPOCDXBrush = null;
//		SharpDX.Direct2D1.Brush iMPBarVAHDXBrush = null;
//		SharpDX.Direct2D1.Brush iMPBarVALDXBrush = null;
//		SharpDX.Direct2D1.Brush iMPBarVADXBrush = null;
//		SharpDX.Direct2D1.Brush iMPBarVWAPDXBrush = null;
//		SharpDX.Direct2D1.Brush iMPBarClusterDXBrush = null;
//		SharpDX.Direct2D1.Brush CurrentBrush = null;
		SharpDX.Direct2D1.Brush iVAFillDXBrush = null;
		SharpDX.Direct2D1.Brush iEXFillDXBrush = null;

//		SharpDX.Direct2D1.Brush OverridePOCDXBrush = null;
//		SharpDX.Direct2D1.Brush iBarProfileVAHDXBrush = null;
//		SharpDX.Direct2D1.Brush iBarProfileVALDXBrush = null;
//		SharpDX.Direct2D1.Brush iBarProfileVADXBrush = null;
//		SharpDX.Direct2D1.Brush iBarProfileVWAPDXBrush = null;
//
	    SharpDX.Direct2D1.Brush RectangleFillDXBrush = null;
        SharpDX.Direct2D1.Brush HistogramDXBrush = null;

        SharpDX.Direct2D1.Brush PenMDXBrush   = null;

        SharpDX.Direct2D1.Brush BrushMDXBrush = null;
//        SharpDX.Direct2D1.Brush BrushTDXBrush = null;

		SharpDX.Direct2D1.Brush ZoneHDXBrush = null;
		int ZoneHLineWidth = 0;
		SharpDX.Direct2D1.Brush ButtonDXBrush = null;
		SharpDX.Direct2D1.Brush ButtonPenDXBrush = null;
		SharpDX.Direct2D1.Brush ButtonTextDXBrush = null;
		SharpDX.Direct2D1.Brush DXBrushes_Black = null;
		SharpDX.Direct2D1.Brush DXBrushes_LightGreen = null;
		SharpDX.Direct2D1.Brush DXBrushes_LightGray = null;
        SharpDX.Direct2D1.Brush RectangleDXBrush = null;
		SharpDX.Direct2D1.Brush iBarProfilePOCDXBrush = null;
		SharpDX.Direct2D1.Brush iBarProfileVAHDXBrush = null;
		SharpDX.Direct2D1.Brush iBarProfileVALDXBrush = null;
		SharpDX.Direct2D1.Brush iBarProfileVADXBrush = null;
		SharpDX.Direct2D1.Brush iBarProfileVWAPDXBrush = null;
		SharpDX.Direct2D1.Brush iBarProfileClusterDXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistogramPOCDXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistogramVAHDXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistogramVALDXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistogramVWAPDXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistoPOCContrastDXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistoVAHContrastDXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistoVALContrastDXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistoVWAPContrastDXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistogramVADXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistogramMDXBrush = null;
        SharpDX.Direct2D1.Brush iMPHistogramClusterDXBrush = null;
        SharpDX.Direct2D1.Brush iCPHistogramVWAPDXBrush = null;
		SharpDX.Direct2D1.Brush iCPHistogramPOCDXBrush = null;
		SharpDX.Direct2D1.Brush iCPHistogramVAHDXBrush = null;
		SharpDX.Direct2D1.Brush iCPHistogramVALDXBrush = null;
		SharpDX.Direct2D1.Brush iCPHistogramVADXBrush = null;
		SharpDX.Direct2D1.Brush iCPHistogramMDXBrush = null;
		SharpDX.Direct2D1.Brush iCPHistogramVAH2DXBrush = null;
		SharpDX.Direct2D1.Brush iCPHistogramVAL2DXBrush = null;
		SharpDX.Direct2D1.Brush iCPHistogramClusterDXBrush = null;
		int RectangleLineWidth = 1;

        SharpDX.Direct2D1.Brush HistogramDXBrush2 = null;
        SharpDX.Direct2D1.Brush DXBrushM2 = null;
		SharpDX.Direct2D1.Brush PenM2DXBrush = null;

		private SharpDX.Direct2D1.Brush iSupplyZDXBrushFresh, iSupplyZDXBrushTested, iSupplyZDXBrushBroken, iSupplyZOLDXBrushFresh, iSupplyZOLDXBrushTested, iSupplyZOLDXBrushBroken;
		private SharpDX.Direct2D1.Brush iDemandZDXBrushFresh, iDemandZDXBrushTested, iDemandZDXBrushBroken, iDemandZOLDXBrushFresh, iDemandZOLDXBrushTested, iDemandZOLDXBrushBroken;
		private SharpDX.Direct2D1.Brush iArrowUpDXBrush, iArrowDnDXBrush, iArrowUpODXBrush, iArrowDnODXBrush, iTM_DXBrush, iVCRArrowUpDXBrush, iVCRArrowDnDXBrush;
		private SharpDX.Direct2D1.Brush iAskHistDXBrush1, iAskHistDXBrush2, iBidHistDXBrush1, iBidHistDXBrush2, iAskOutDXBrush1, iBidOutDXBrush1;
		private SharpDX.Direct2D1.Brush iDPDXBrush, iDNDXBrush;

		private SharpDX.Direct2D1.Brush iVA1Line_DXBrush=null;
		private SharpDX.Direct2D1.Brush iVA2Line_DXBrush=null;
		private SharpDX.Direct2D1.Brush iVA1_fillDXBrush=null;
		private SharpDX.Direct2D1.Brush iVA2_fillDXBrush=null;
		

		private SharpDX.Direct2D1.Brush BigMoneyBidRectangleFillDXBrush=null;
		private SharpDX.Direct2D1.Brush BigMoneyAskRectangleFillDXBrush=null;
		
//		private SharpDX.Direct2D1.Brush UnfinishedBizDotDXBrush = null;

		private int iVA1Width = 2;
		private int iVA2Width = 2;
		private DashStyleHelper iVA1DashStyle = DashStyleHelper.Solid;
		private DashStyleHelper iVA2DashStyle = DashStyleHelper.Solid;

		#endregion


		private class SmartMax{
			public int Period = 0;
			public SortedDictionary<int,long> Vals;//sequential list of the last Period-number of values
			public SortedDictionary<int,long> Avgs;//sequential list of averages for all bars
			public SortedDictionary<int,long> Maxs;//bar-by-bar history of Max values
			private long MaxVal = 0;
			private int KeyOfMaxVal = -1;
			public bool Initialized = false;
			public string Status = string.Empty;
 
			#region Methods
			public SmartMax(int period){
				Period = period;
				Vals = new SortedDictionary<int,long>();
				Maxs = new SortedDictionary<int,long>();
				Avgs = new SortedDictionary<int,long>();
			}
			public long GetMax(){ 
				if(!Initialized) return int.MinValue;
				return MaxVal;
			}
			public long GetMax(int abar){ 
				if(Initialized && Maxs.ContainsKey(abar)) return Maxs[abar];
				return int.MinValue;
			}
			public long GetAverage(){ 
				if(!Initialized) return int.MinValue;
				if(Avgs.Count==0) return int.MinValue;
//				var k = Avgs.Keys.ToList().Last;
				return Avgs[Avgs.Keys.ToList().Max()];
			}
			public long GetAverage(int last_abar){ 
				if(!Initialized) return int.MinValue;
				if(Avgs.ContainsKey(last_abar)) return Avgs[last_abar];
				else return int.MinValue;
			}
			public long CalcAverage(){ 
				if(!Initialized) return int.MinValue;
				else if(Vals.Count>0){
try{
					var k = Vals.Keys.ToList();
					var avg = Convert.ToInt64(Vals.Values.Average());
					Avgs[k[k.Count-1]]= avg;
					return avg;
}catch(Exception e){Status="Line 963 "+e.ToString(); return int.MinValue;}
				}else return int.MinValue;
			}
			public long CalcAverage(int last_abar){ 
				if(!Initialized) return int.MinValue;
				else{
					if(Vals.Count>0) {
						var keys = Vals.Keys.ToList();
						double sum = 0;
						int i = 0;
//Status = keys.Count+"-keys";
						while(keys[i]<=last_abar){
							sum = sum + Vals[keys[i]];
//Status = string.Format("{0},  {1}",Status, Vals[keys[i]].ToString());
							i++;
						}
//Status = string.Format("{0}  sum:{1}",Status, sum);
						if(i>0) {
							var avg = Convert.ToInt64(sum/i);
							Avgs[last_abar] = avg;
							return avg;
						}else return 0;
					}else return 0;
				}
				return int.MinValue;
			}
			public void NoChange(int abar){
				Maxs[abar] = MaxVal;
				Avgs[abar] = GetAverage();
			}
			public void AddLong(long v, int abar){
				Status=string.Empty;
				try{
				if(!Initialized) {
					MaxVal = v;
					Vals[abar] = v;
					KeyOfMaxVal = abar;
					Initialized = true;
				}else{
					if(Vals.ContainsKey(abar)){
						Vals[abar] = v;
						if(v > MaxVal){
							MaxVal = v;
							KeyOfMaxVal = abar;
						}
					}else{
						Vals[abar] = v;
						if(Vals.Count > Period){
							var keys = Vals.Keys.ToList();
							if(keys[0]>keys[keys.Count-1]) keys.Reverse();//make sure the 0-element is the lowest
							while(keys.Count>0 && keys.Count > Period){
								if(keys[0]==KeyOfMaxVal) KeyOfMaxVal = int.MinValue;//search for max only when the Key of the prior max value has dropped off the period
								Vals.Remove(keys[0]);
								keys.RemoveAt(0);
							}
						}
						//if(KeyOfMaxVal==int.MinValue) Status = "-------------------   it's reset! -----  ";
						if(v > MaxVal){
							MaxVal = v;
							KeyOfMaxVal = abar;
						}else if(KeyOfMaxVal==int.MinValue){//search for max only when the Key of the prior max value has dropped off the period
							MaxVal = v;
							foreach(var kvp in Vals){
								if(kvp.Value >= MaxVal) {
									MaxVal = kvp.Value;
									KeyOfMaxVal = kvp.Key;
								}
							}
						}
						//if(Status.Length>0) Status = Status + "  it is now: "+KeyOfMaxVal.ToString();
						//Status = "Key is now: "+KeyOfMaxVal.ToString();
					}
				}
				Maxs[abar] = MaxVal;
				CalcAverage();
//Status = Status+"    Avg at "+abar+" is now: "+GetAverage().ToString();
				}catch(Exception e){Status = "line 1039: "+e.ToString();}
			}
			#endregion
 
		}
		private SmartMax NetD_MaxMgr = null;
		private SmartMax NetD_MinMgr = null;
		private SortedDictionary<int,int> HeatMapBarToColor = new SortedDictionary<int,int>();//each price bar has a HeatMap color index value from 0 to 19 for the 20 different shades of green-to-red
		private SortedDictionary<int,float> VolumeAverage = new SortedDictionary<int,float>();//vertical size of the heatmap rectangles are based on current volume as a multiple of recent average volume
		                                                                                      //		private System.Collections.Generic.IEnumerable<KeyValuePair<int,SortedDictionary<double,PrintLevelDetails>>> BarData_VisibleBars = null;
		private class AudibleAlerts{
			#region AudibleAlerts
			public int TTabar = 0;
			public int DDabar = 0;
			public int VDabar = 0;
			public int CSabar = 0;
			public int VCabar = 0;
			public int OFCabar = 0;
			public string TT_WAV_Sell = "";
			public string DD_WAV_Sell = "";
			public string VD_WAV_Sell = "";
			public string CS_WAV_Sell = "";
			public string VC_WAV_Sell = "";
			public string TT_WAV_Buy = "";
			public string DD_WAV_Buy = "";
			public string VD_WAV_Buy = "";
			public string CS_WAV_Buy = "";
			public string VC_WAV_Buy = "";
			public string OFC_WAV = "";
			private bool TT_WAV_Sell_Verified = false;
			private bool TT_WAV_Buy_Verified = false;
			private bool DD_WAV_Sell_Verified = false;
			private bool DD_WAV_Buy_Verified = false;
			private bool VD_WAV_Sell_Verified = false;
			private bool VD_WAV_Buy_Verified = false;
			private bool CS_WAV_Sell_Verified = false;
			private bool CS_WAV_Buy_Verified = false;
			private bool VC_WAV_Sell_Verified = false;
			private bool VC_WAV_Buy_Verified = false;
			private bool OFC_WAV_Verified = false;
			//public List<DateTime> AlertTimes = new List<DateTime>();
			public AudibleAlerts(string TTwavBuy, string DDwavBuy, string VDwavBuy, string CSwavBuy, string VCwavBuy, string OFCwav, string TTwavSell, string DDwavSell, string VDwavSell, string CSwavSell, string VCwavSell, string InstName)
			{
				#region constructor
				if(TTwavBuy.Contains("<inst>"))  TTwavBuy = TTwavBuy.Replace("<inst>",InstName);
				if(TTwavSell.Contains("<inst>")) TTwavSell = TTwavSell.Replace("<inst>",InstName);
				if(DDwavBuy.Contains("<inst>"))  DDwavBuy = DDwavBuy.Replace("<inst>",InstName);
				if(DDwavSell.Contains("<inst>")) DDwavSell = DDwavSell.Replace("<inst>",InstName);
				if(VDwavBuy.Contains("<inst>"))  VDwavBuy = VDwavBuy.Replace("<inst>",InstName);
				if(VDwavSell.Contains("<inst>")) VDwavSell = VDwavSell.Replace("<inst>",InstName);
				if(CSwavBuy.Contains("<inst>"))  CSwavBuy = CSwavBuy.Replace("<inst>",InstName);
				if(CSwavSell.Contains("<inst>")) CSwavSell = CSwavSell.Replace("<inst>",InstName);
				if(VCwavBuy.Contains("<inst>"))  VCwavBuy = VCwavBuy.Replace("<inst>",InstName);
				if(VCwavSell.Contains("<inst>")) VCwavSell = VCwavSell.Replace("<inst>",InstName);
				if(OFCwav.Contains("<inst>")) OFCwav = OFCwav.Replace("<inst>",InstName);
				TT_WAV_Sell = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", TTwavSell.Trim());
				DD_WAV_Sell = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", DDwavSell.Trim());
				VD_WAV_Sell = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", VDwavSell.Trim());
				CS_WAV_Sell = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", CSwavSell.Trim());
				VC_WAV_Sell = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", VCwavSell.Trim());
				TT_WAV_Buy = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", TTwavBuy.Trim());
				DD_WAV_Buy = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", DDwavBuy.Trim());
				VD_WAV_Buy = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", VDwavBuy.Trim());
				CS_WAV_Buy = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", CSwavBuy.Trim());
				VC_WAV_Buy = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", VCwavBuy.Trim());
				OFC_WAV = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", OFCwav.Trim());
				this.TT_WAV_Sell_Verified = System.IO.File.Exists(TT_WAV_Sell);
				this.TT_WAV_Buy_Verified = System.IO.File.Exists(TT_WAV_Buy);
				this.DD_WAV_Sell_Verified = System.IO.File.Exists(DD_WAV_Sell);
				this.DD_WAV_Buy_Verified = System.IO.File.Exists(DD_WAV_Buy);
				this.VD_WAV_Sell_Verified = System.IO.File.Exists(VD_WAV_Sell);
				this.VD_WAV_Buy_Verified = System.IO.File.Exists(VD_WAV_Buy);
				this.CS_WAV_Sell_Verified = System.IO.File.Exists(CS_WAV_Sell);
				this.CS_WAV_Buy_Verified = System.IO.File.Exists(CS_WAV_Buy);
				this.VC_WAV_Sell_Verified = System.IO.File.Exists(VC_WAV_Sell);
				this.VC_WAV_Buy_Verified = System.IO.File.Exists(VC_WAV_Buy);
				this.OFC_WAV_Verified = System.IO.File.Exists(OFC_WAV);
				#endregion
			}
			public void Play(Indicator parent, int direction, string type, int signalbar)
			{
			    if (direction < 0)
			    {//Sell signal
			        if (type.StartsWith("DD") && DDabar != signalbar && DD_WAV_Sell.ToLower().Contains(".wav"))
			        {
			            if (!DD_WAV_Sell_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+DD_WAV_Sell);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Delta Div SELL sound not found", "", 0, Brushes.DimGray, Brushes.White);
			            }else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Delta Div SELL", DD_WAV_Sell, 0, Brushes.DimGray, Brushes.White);
//			                parent.PlaySound(DD_WAV_Sell);
			            DDabar = signalbar;
			        }

			        else if (type.StartsWith("TT") && TTabar != signalbar && TT_WAV_Sell.ToLower().Contains(".wav"))
			        {
			            if (!TT_WAV_Sell_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+TT_WAV_Sell);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "TrappedTrader SELL sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "TrappedTrader SELL", TT_WAV_Sell, 0, Brushes.Red, Brushes.White);
//			                parent.PlaySound(TT_WAV_Sell);
			            //parent.Pit("   "+TT_WAV_Sell);
			            TTabar = signalbar;
			        }
			        else if (type.StartsWith("VD") && VDabar != signalbar && VD_WAV_Sell.ToLower().Contains(".wav"))
			        {
			            if (!VD_WAV_Sell_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+VD_WAV_Sell);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Volume Div SELL sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Volume Div SELL", VD_WAV_Sell, 0, Brushes.Red, Brushes.White);
//			                parent.PlaySound(VD_WAV_Sell);
			            //parent.Pit("   "+VD_WAV_Sell);
			            VDabar = signalbar;
			        }
			        else if (type.StartsWith("CS") && CSabar != signalbar && CS_WAV_Sell.ToLower().Contains(".wav"))
			        {
			            if (!CS_WAV_Sell_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+CS_WAV_Sell);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Combined SELL sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Combined SELL", CS_WAV_Sell, 0, Brushes.Red, Brushes.White);
//			                parent.PlaySound(CS_WAV_Sell);
			            //parent.Pit("   "+CS_WAV_Sell);
			            CSabar = signalbar;
			        }
			        else if (type.StartsWith("VC") && VCabar != signalbar && VC_WAV_Sell.ToLower().Contains(".wav"))
			        {
			            if (!VC_WAV_Sell_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+VC_WAV_Sell);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Volume Cluster SELL sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Volume Cluster SELL", VC_WAV_Sell, 0, Brushes.Red, Brushes.White);
//			                parent.PlaySound(VC_WAV_Sell);
			            VCabar = signalbar;
			        }
			        else if (type.StartsWith("OFC") && OFCabar != signalbar && OFC_WAV.ToLower().Contains(".wav"))
			        {
			            if (!OFC_WAV_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+OFC_WAV);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "OrderFlow Confluence sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "OrderFlow Confluence", "OFC_WAV", 0, Brushes.Red, Brushes.White);
//			                parent.PlaySound(OFC_WAV);
			            OFCabar = signalbar;
			        }
			    }

			    if (direction > 0)
			    {
			        if (type.StartsWith("DD") && DDabar != signalbar && DD_WAV_Buy.ToLower().Contains(".wav"))
			        {
			            if (!DD_WAV_Buy_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+DD_WAV_Buy);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Delta Div BUY sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Delta Div BUY", DD_WAV_Buy, 0, Brushes.Green, Brushes.White);
//			                parent.PlaySound(DD_WAV_Buy);
			            //parent.Pit("   "+DD_WAV_Buy);
			            DDabar = signalbar;
			        }
			        else if (type.StartsWith("TT") && TTabar != signalbar && TT_WAV_Buy.ToLower().Contains(".wav"))
			        {
			            if (!TT_WAV_Buy_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+TT_WAV_Buy);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Trapped Trader BUY sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Trapped Trader BUY", TT_WAV_Buy, 0, Brushes.Green, Brushes.White);
//			                parent.PlaySound(TT_WAV_Buy);
			            //parent.Pit("   "+TT_WAV_Buy);
			            TTabar = signalbar;
			        }
			        else if (type.StartsWith("VD") && VDabar != signalbar && VD_WAV_Buy.ToLower().Contains(".wav"))
			        {
			            if (!VD_WAV_Buy_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+VD_WAV_Buy);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Volume Div BUY sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Volume Div BUY", VD_WAV_Buy, 0, Brushes.Green, Brushes.White);
//			                parent.PlaySound(VD_WAV_Buy);
			            //parent.Pit("   "+VD_WAV_Buy);
			            VDabar = signalbar;
			        }
			        else if (type.StartsWith("CS") && CSabar != signalbar && CS_WAV_Buy.ToLower().Contains(".wav"))
			        {
			            if (!CS_WAV_Buy_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+CS_WAV_Buy);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Combined BUY sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Combined BUY", CS_WAV_Buy, 0, Brushes.Green, Brushes.White);
//			                parent.PlaySound(CS_WAV_Buy);
			            //parent.Pit("   "+CS_WAV_Buy);
			            CSabar = signalbar;
			        }
			        else if (type.StartsWith("VC") && VCabar != signalbar && VC_WAV_Buy.ToLower().Contains(".wav"))
			        {
			            if (!VC_WAV_Buy_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+VC_WAV_Buy);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Volume Cluster BUY sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "Volume Cluster BUY", VC_WAV_Buy, 0, Brushes.Green, Brushes.White);
//			                parent.PlaySound(VC_WAV_Buy);
			            VCabar = signalbar;
			        }
			        else if (type.StartsWith("OFC") && OFCabar != signalbar && OFC_WAV.ToLower().Contains(".wav"))
			        {
			            if (!OFC_WAV_Verified){
			                parent.Print("PrintProfiler did not find wav:   "+OFC_WAV);
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "OrderFlow Confluence sound not found", "", 0, Brushes.DimGray, Brushes.White);
						}else
			                parent.Alert(DateTime.Now.ToString(), Priority.Low, "OrderFlow Confluence", OFC_WAV, 0, Brushes.Green, Brushes.White);
//			                parent.PlaySound(OFC_WAV);
			            OFCabar = signalbar;
			        }
			    }
			}
			#endregion
		}
		private AudibleAlerts AudibleAlertMgr = null;

		//------------------------------ Virtuals ---------------------------------
		public override string DisplayName { get { return "ARC_PrintProfiler"; } }
		private byte ToByte(int i){return (byte)(Math.Max(0, Math.Min(255,i)));}
		private double gbTickSize = 0;
		SessionIterator sessionIterator=null;
//==========================================================================================================
		protected override void OnStateChange()
		{
			IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
//if(State!=null)Print("PP State: "+State.ToString());
			#region --------- protected override void OnStateChange() ------------
			dt = DateTime.Now;
			#region --SetDefaults--
			if (State == State.SetDefaults)
{
if(IsDebug) ClearOutputWindow();
if(IsDebug) Print(1696);
				Description = @"ARC_PrintProfiler";
				Name = "ARC_PrintProfiler";
				IsAutoScale = false;//to ensure OnCalculateMinMax is called

				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);

                #region -- UI Settings --
                IsOverlay = true;
                ArePlotsConfigurable = false;

                DisplayInDataBox    = false;
                PaintPriceMarkers   = false;
                MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
                ScaleJustification  = ScaleJustification.Right;
//                IsSuspendedWhileInactive = false;
                BarsRequiredToPlot  = 1;

                Calculate = Calculate.OnEachTick;//force to on each tick
                #endregion
if(IsDebug) Print(1716);

#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA1CLL");
				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA1CLH");
				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA1VWAP");
				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA1POC");
				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA2CLL");
				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA2CLH");
				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA2VWAP");
				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA2POC");
#endif
				AddPlot(Brushes.Black, "MA1 High");
				AddPlot(Brushes.Black, "MA1 Low");
				AddPlot(Brushes.Black, "MA2 High");
				AddPlot(Brushes.Black, "MA2 Low");
				//AddPlot(new Stroke(Brushes.Plum), PlotStyle.Line, "CWAPMAN");
				//AddPlot(new Stroke(Brushes.Plum), PlotStyle.Line, "CWAPCOMP");

if(IsDebug) Print(1735);
				#region -- Default Values --
				pRoundForexToWholePip = false;
				#region -- Category Bid/Ask Imbalances --
				iTxtBrush_AskImbalance = Brushes.Green;
				iTxtBrush_BidImbalance = Brushes.Red;
//                iIBAskColor = Brushes.Green;
//                iIBBidColor = Brushes.Red;
//                iIBFS = true;
//                iIpButtonSizeI = 2;
//                iOpacityUp2 = 75;
//                iOpacityDn2 = 75;
				iImbalanceOffset = 3;
				iVolumeQualifier = 0;
				iRSSize = 4;
				iBlocksO = 100;
				iBlocksColor = Brushes.Black;
				iBlocks2Color = Brushes.Yellow;
				iShowImbalanceText = false;
				iShowImbalanceA = false;
				iShowImbalance = false;
				pImbalancesDotMode = "Outside";
				#endregion

				pSignalTiming = ARC_PrintProfiler_SignalTimingTypes.OnClose;
				TT_SellAlertWav = "SOUND OFF";
				DD_SellAlertWav = "SOUND OFF";
				VD_SellAlertWav = "SOUND OFF";
				CS_SellAlertWav = "SOUND OFF";
				VC_SellAlertWav = "SOUND OFF";
				OFC_AlertWav = "SOUND OFF";

				TT_BuyAlertWav = "SOUND OFF";
				DD_BuyAlertWav = "SOUND OFF";
				VD_BuyAlertWav = "SOUND OFF";
				CS_BuyAlertWav = "SOUND OFF";
				VC_BuyAlertWav = "SOUND OFF";

				#region -- Indicator Display --
				pButtonText = "Print Profiler";
				#endregion
                
				#region -- Profile (Manual) --
				iManualProfileHD = "Left";
				iMPLabels = false;
				iMPONTOP = false;
				iMPFillColor = Brushes.White;
				iMPOutlineColor = Brushes.Black;
				iMPLineWidth = 2;
				iMPFillOpacity = 0;
				iButtonSize = 13;
				iMPHistogramOpacity = 60;
				iMPHistogramMColor = Brushes.White;
				iMPHistogramVAColor = Brushes.Maroon;
				iMPHistogramClusterColor = Brushes.Black;
				iMPHistogramPOCColor = Brushes.Yellow;
				iMPHistogramVAHColor = Brushes.Fuchsia;
				iMPHistogramVALColor = Brushes.Lime;
				iMPHistogramVWAPColor = Brushes.Cyan;
				iMPDisplay = "Histogram";
				/*iCwapManColor = Brushes.Plum;
				iCwapManDashStyle = DashStyleHelper.Solid;
				iCwapManWidth = 2;*/
				#endregion

				#region -- Profile (Composite) --
				iCompDevLevel = false;
				iCompDevHLevel = true;
				iCompDevCLevel = true;
				iCompDevEX = true;
				iCompDevPOC = true;
				iCompDevVA = true;
				iCompDevVWAP = true;
				iCompositeProfileHD = "Left";
				iCompDevLevelArea = true;
				iVAFillColor = Brushes.SteelBlue;
				iEXFillColor = Brushes.Yellow;
				iFillAreaOpacity = 30;
				iCompLineExtend = true;
				iCompLineLabels = true;
				iCCompositeEnabled = true;
				iHCompositeEnabled = true;
				iDrawCText = true;
				iCPONTOP = false;
				iCPLineWidth = 2;
				iCPHistogramOpacity = 60;
				iCPHistogramMColor = Brushes.White;
				iCPHistogramVAColor = Brushes.Maroon;
				iCPHistogramClusterColor = Brushes.Black;
				iCPHistogramPOCColor = Brushes.Yellow;
				iCPHistogramVAHColor = Brushes.Fuchsia;
				iCPHistogramVALColor = Brushes.Lime;
				iCPHistogramVAH2Color = Brushes.DarkRed;
				iCPHistogramVAL2Color = Brushes.DarkGreen;
				iCPHistogramVWAPColor = Brushes.Cyan;
				iCompositeType = "Day";
				iResetTime = new TimeSpan(9, 30, 0);
				iResetMinutes = 60;
				iCompositeEnabled = false;
				iCPDisplay = "Histogram";
				iCompLength = 100;
				/*iCwapCompColor = Brushes.Plum;
				iCwapCompDashStyle = DashStyleHelper.Solid;
				iCwapCompWidth = 2;*/
				#endregion

				#region -- Profile (Bar) --
				iDisplayVWAP = true;
				iDisplayVA   = false;
				iDisplayCL   = true;
				iDisplayPOC  = true;
				iBarPW = 3;
				iMPHistogramClusterColor2 = Brushes.Black;
				iMPBarOpacity2 = 50;
				iMPBarOpacity  = 100;
				iMPBarMColor   = Brushes.White;
				iMPBarVAColor  = Brushes.Maroon;
				iMPBarClusterColor = Brushes.Black;
				iMPBarPOCColor     = Brushes.Yellow;
				iMPBarVAHColor     = Brushes.Fuchsia;
				iMPBarVALColor     = Brushes.Lime;
				iMPBarVWAPColor    = Brushes.Cyan;
				iBarCompositeEnabled = false;
				pShow_VCRSignal    = false;
				pShow_VCR2b        = true;
				pShow_VCR3b        = true;
				pShow_Absolute3Bar = true;
				iArrowWidthVCR = 7;
				iSeparationVCR = 0;
				iArrowUpColorVCR = Brushes.Lime;
				iArrowDnColorVCR = Brushes.Red;
				iSignalNameVCR2  = @"2BR";
				iSignalNameVCR3  = @"3BR";
				VC_BuyAlertWav   = "SOUND OFF";
				VC_SellAlertWav  = "SOUND OFF";
				#endregion

				#region -- Profile (All) --
				iVAPercent = 70;
				#endregion

#if VOLUME_AVERGES
				#region -- Volume Averages Set 1 --
				iVA1Enabled = false;
				iVA1Period = 20;
				iVA1Mode      = "EMA";
				iVA1Enabled1  = true;
				iVA1Enabled2  = true;
				iVA1Enabled3  = true;
				iVA1Color     = Brushes.Yellow;
				iVA1DashStyle = DashStyleHelper.Solid;
				iVA1Width   = 2;
				iVA2Color   = Brushes.Cyan;
				iVA2DashStyle = DashStyleHelper.Solid;
				iVA2Width   = 2;
				iVA3Color   = Brushes.Black;
				iVA33Color  = Brushes.Black;
				iVA3Opacity = 20;
				iVA1DashStyle = DashStyleHelper.Solid;
				iVA1Width = 2;
				#endregion

				#region -- Volume Averages Set 2 --
				iVA2Enabled = false;
				iVA2Period = 50;
				iVA2Mode = "SMA";
				iVA2Enabled1 = true;
				iVA2Enabled2 = true;
				iVA2Enabled3 = true;
				iVAS1Color = Brushes.Yellow;
				iVAS1DashStyle = DashStyleHelper.Solid;
				iVAS1Width = 2;
				iVAS2Color = Brushes.Cyan;
				iVAS2DashStyle = DashStyleHelper.Solid;
				iVAS2Width = 2;
				iVAS3Color = Brushes.Black;
				iVAS33Color = Brushes.Black;
				iVAS3Opacity = 20;
				iVA2DashStyle = DashStyleHelper.Solid;
				iVA2Width = 2;
				#endregion
#else
				#region -- Volume Averages Set 1 --
				iVA1Enabled    = false;
				iVA1Period     = 20;
				iVA1Mode       = "EMA";
//                iVA1Enabled3   = true;
				iVA1_Color     = Brushes.Black;
				iVA1_FillColor = Brushes.Black;
				iVA3Opacity    = 20;
				iVA1_ClusterSizeTicks = 3;
				//iVA1DashStyle = DashStyleHelper.Solid;
				//iVA1Width     = 2;
				#endregion

				#region -- Volume Averages Set 2 --
				iVA2Enabled    = false;
				iVA2Period     = 50;
				iVA2Mode       = "SMA";
//                iVA2Enabled3   = true;
				iVA2_Color     = Brushes.Black;
				iVA2_FillColor    = Brushes.Black;
				iVA2_ClusterSizeTicks = 3;
				iVAS3Opacity   = 20;
				//iVA2DashStyle = DashStyleHelper.Solid;
				// iVA2Width     = 2;
				#endregion
#endif

				#region -- Zones Display --
				iZonesEnabled = false;
				iZonesTMEnabled = true;
				iZonesTSEnabled = false;
				iTickLevelWidth = 1;
				iShowDemandZones = true;
				iShowSupplyZones = true;
				iShowFreshZones = true;
				iShowTestedZones = true;
				iShowBrokenZones = true;
				iMinZWidth = 4;
				iExtendZonesRight = true;
				iSupplyZColorFresh = Brushes.Red;
				iSupplyZColorTested = Brushes.LightPink;
				iSupplyZColorBroken = Brushes.Fuchsia;
				iDemandZColorFresh = Brushes.Green;
				iDemandZColorTested = Brushes.LightGreen;
				iDemandZColorBroken = Brushes.Cyan;
				iSupplyZOLColorFresh = Brushes.Black;
				iSupplyZOLColorTested = Brushes.Black;
				iSupplyZOLColorBroken = Brushes.Black;
				iDemandZOLColorFresh = Brushes.Black;
				iDemandZOLColorTested = Brushes.Black;
				iDemandZOLColorBroken = Brushes.Black;
				iSupplyZOpacityFresh = 75;
				iSupplyZOpacityTested = 75;
				iSupplyZOpacityBroken = 40;
				iDemandZOpacityFresh = 75;
				iDemandZOpacityTested = 75;
				iDemandZOpacityBroken = 40;
				iTMColor = Brushes.White;
				iTMOpacity = 100;
				iTMWidth = 3;
				#endregion

				#region -- Print Display --
				iTxtBrush_BidAskVol = Brushes.Black;
				iBarPrintFont = new SimpleFont("Arial", 12) { Bold = true };
				barprintFont  = (SimpleFont)iBarPrintFont.Clone();
				iPrintEnabled = false;
				iDPColor      = Brushes.DarkGreen;
				iDNColor      = Brushes.DarkRed;
				iNetDeltaFont = new SimpleFont("Arial", 12) { Bold = true };
				iShowNetDelta             = true;
				iShowNetDeltaHeatMap      = true;
				pHeatMapHeightPeriod      = 3;
				pHeatMapColorPeriod       = 10;
				iShowTotalVolumeInHeatMap = false;
				iShowTotalVolumeAsPct     = false;
				pHeatMap_PositiveColor    = Brushes.DarkGreen;
				pHeatMap_NegativeColor    = Brushes.DarkRed;
				pUseSkinnyHeatmapBars     = false;
				pHeatMap_MinimumLineColor = Brushes.Black;
				pHeatMap_MinLineThickness = 1;

				pShow_Table      = true;
				pTableTxt_LabelColumn_Brush = Brushes.Black;
				pTableTxt_SignalUp_Brush = Brushes.Black;
				pTableTxt_SignalDown_Brush = Brushes.Black;
				pTableTxt_DeltaPos_Brush = Brushes.Black;
				pTableTxt_DeltaNeg_Brush = Brushes.Black;
				pTableTxt_CumDeltaPos_Brush = Brushes.Black;
				pTableTxt_CumDeltaNeg_Brush = Brushes.Black;
				pTableTxt_DeltaPct_Brush = Brushes.Black;
				pTableTxt_Volume_Brush = Brushes.Black;
				pTableTxt_BidVol_Brush = Brushes.Black;
				pTableTxt_AskVol_Brush = Brushes.Black;

				pTableFill_LabelColumn_Brush = Brushes.Yellow;
				pTableFill_SignalUp_Brush = Brushes.Green;
				pTableFill_SignalDown_Brush = Brushes.Firebrick;
				pTableFill_DeltaPos_Brush = Brushes.Green;
				pTableFill_DeltaNeg_Brush = Brushes.Firebrick;
				pTableFill_CumDeltaPos_Brush = Brushes.Green;
				pTableFill_CumDeltaNeg_Brush = Brushes.Firebrick;
				pTableFill_DeltaPct_Brush = Brushes.DimGray;
				pTableFill_Volume_Brush = Brushes.DimGray;
				pTableFill_BidVol_Brush = Brushes.Red;
				pTableFill_AskVol_Brush = Brushes.DarkGreen;
				//pTableTxtBrush  = Brushes.White;
				//pPosTableValueBrush = Brushes.Green;
				//pNegTableValueBrush = Brushes.Crimson;
				pTableFont      = new SimpleFont("Arial", 12) { Bold = false };

				iCurrentBarEnabled    = false;
				iShowVolAtPrice       = false;
				#endregion

				pSmallVolumeThreshold   = 0;
				pSmallVolumeTextOpacity = 50;
				pVisualVolumeDivisor    = 1;

				pShow_UnfinishedBizSignal = false;
//				pUnfinishedBizFillColor = Brushes.Cyan;
				pUnfinishedBizStrokeStyle = new Stroke(Brushes.Cyan, DashStyleHelper.Dash, 2);

				#region -- BigMoney --
				pShow_BigMoneySignal  = false;
				pBigMoneyMultiplier   = 2.5;
				pBigMoneyLookbackBars = 20;
				pMaxSizeForBigMoneySignal = -1;
				pBigMoneyAskRectangleFillColor = Brushes.LightGreen;
				pBigMoneyBidRectangleFillColor = Brushes.Pink;
				#endregion

				#region -- Bar Display --
				iMaxBarSpacePixels = 15;
				iMinBarSpacePixels = 2;
				iRightSideMarginMin = 100;
				iRightSidePaddingMin = 15;
				#endregion

				#region -- Block Trades --
				iBlockSize = 20;
				pDynBlockSizePercentile = 0.01;
				pDynBlockSizeLookbackBars = 20;
//				pEnableContinuousDynBlockSizeCalc = false;
				iIBAskColor3 = Brushes.Black;
				iIBBidColor3 = Brushes.Black;
				iOpacityUp3 = 100;
				iOpacityDn3 = 100;
				pShow_Blocks = false;
				iTriSize = 5;
				iTriMode = "Inside";
				#endregion

				#region -- Avg Stop Loss Calculators --
				iAvgStopLossOffset = 3;
				#endregion

				#region -- Inventory Display --
				iInventoryEnabled = false;
				iAskHistColor1 = Brushes.Red;
				iAskHistColor2 = Brushes.Maroon;
				iBidHistColor1 = Brushes.Green;
				iBidHistColor2 = Brushes.Lime;
				iAskOutColor1 = Brushes.Black;
				iBidOutColor1 = Brushes.Black;
				iDisplayTotal = true;
				iTriMode2 = "Both";
				iSwingOpacity2 = 80;
				iSwingOpacity = 80;
				iInvLength = 100;
				imaxRows = 10;
				ioutlineHistBars = false;
				#endregion

				#region -- ChartMarker Signals --
				pEnableChartMarkers   = false;
				pBuyChartMarkers      = ARC_PrintProfiler_ChartMarkers.Arrow;
				pBuyBrushChartMarker  = Brushes.Lime;
				pSellChartMarkers     = ARC_PrintProfiler_ChartMarkers.Arrow;
				pSellBrushChartMarker = Brushes.Magenta;
				pMarkerTicks          = 20;
				#endregion

				#region -- Data --
				iPCalcM = ARC_PrintProfiler_DataBasis.Tick1;
				DataLimitType = ARC_PrintProfiler_DataLimitType.Minutes;
				DataLimitQty = 240;
				#endregion

				pShow_OFCSignal = false;
				#region -- Trapped Trader / Delta Divergence Signals --
				pShow_VDSignal = true;
				pShow_TTSignal = false;
				iHighLowRangeFilter = true;
				iArrowUpColor = Brushes.Lime;
				iArrowUpOColor = Brushes.Black;
				iArrowDnColor = Brushes.Red;
				iArrowDnOColor = Brushes.Black;
				iArrowShade = 100;
				iDiamondSeparationVDS = 0;
				iDiamondSeparationOFC = 0;
				iDotWidthOFC = 5;
				iArrowSeparation = 0;
				iDotWidthVDS = 5;
				iArrowWidth = 7;
				iMinimumDecliningLevels = 3;
				iLabelsEnabled = true;
				iFontText2 = new SimpleFont("Arial", 12) { Bold = true };
				iSignalNameTTL = @"TL";
				iSignalNameTTS = @"TS";
				pShow_CCSignal = false;
				pShow_DDSignal = false;
				iLookBack = 3;
				iSignalNameDDL = @"DL";
				iSignalNameDDS = @"DS";
				iSignalNameCSL = @"TDL";
				iSignalNameCSS = @"TDS";
				iSignalNameVDL = @"VDL";
				iSignalNameVDS = @"VDS";
				iSignalNameOFC = @"";
				#endregion

				#region -- Delta Spread Analysis visuals --
				pShow_DSASignal = true;
				pDSA_Sensitivity = 8;
				pDSA_OpacityOnHeatMap  = 100;
				pDSA_OpacityOnPriceBar = 100;
				pSell_DSABrush = Brushes.Red;
				pBuy_DSABrush  = Brushes.Lime;
				//pDSA_OverprintPriceBar = true;
				pDSA_HistoOutlineThickness = 4f;
				#endregion

				#region -- Signal Settgins --
				iLongsEnabled = true;
				iShortsEnabled = true;
				#endregion

				pBidAskHistoOpacity = 0f;
				pAskHistoBrush = Brushes.DarkGreen;
				pBidHistoBrush = Brushes.DarkRed;
				#endregion

#if STOPWATCH_OUTPUT
				BenStopwatch["SetDefaults"] = new TimeSpan(DateTime.Now.Ticks-dt.Ticks);
#endif
			}
			#endregion

			#region --Configure--
			else if (State == State.Configure)
			{
if(IsDebug) Print(1169);
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				AudibleAlertMgr = new AudibleAlerts(TT_BuyAlertWav, DD_BuyAlertWav, VD_BuyAlertWav, CS_BuyAlertWav, VC_BuyAlertWav, OFC_AlertWav, TT_SellAlertWav, DD_SellAlertWav, VD_SellAlertWav, CS_SellAlertWav, VC_SellAlertWav, Instrument.MasterInstrument.Name);

				NetD_MaxMgr = new SmartMax(pHeatMapColorPeriod);
				NetD_MinMgr = new SmartMax(pHeatMapColorPeriod);

				Color myRgbColor = new Color();
				var c = ((System.Windows.Media.SolidColorBrush)pHeatMap_PositiveColor).Color;
				byte R = c.R;
				byte G = c.G;
				byte B = c.B;
if(IsDebug) Print(1190);

				bool midpointreached = false;
				double half = NetDHeatMap_Brushes.Length/2.0;
				int Rstep = Convert.ToInt32((255-R)/half-1);
				int Gstep = Convert.ToInt32((255-G)/half-1);
				int Bstep = Convert.ToInt32((255-B)/half-1);
				for(int brptr = 0; brptr<NetDHeatMap_Brushes.Length; brptr++){
					if(brptr < half){
						myRgbColor = Color.FromRgb(R, G, B);
						R = ToByte(R+Rstep);
						G = ToByte(G+Gstep);
						B = ToByte(B+Bstep);
					}else{
						if(!midpointreached) {
							midpointreached = true;
							R = 255;
							G = 255;
							B = 255;
							c = ((System.Windows.Media.SolidColorBrush)pHeatMap_NegativeColor).Color;
							Rstep = Convert.ToInt32((255-c.R)/half-1);
							Gstep = Convert.ToInt32((255-c.G)/half-1);
							Bstep = Convert.ToInt32((255-c.B)/half-1);
						}
						if(brptr == NetDHeatMap_Brushes.Length-1)
							myRgbColor = c;
						else{
							myRgbColor = Color.FromRgb(R, G, B);
							R = ToByte(R-Rstep);
							G = ToByte(G-Gstep);
							B = ToByte(B-Bstep);
						}
					}
					var scb = new SolidColorBrush(myRgbColor);
					NetDHeatMap_Brushes[brptr] = new SolidColorBrush(myRgbColor);
					maxBigMoneyVolume = pMaxSizeForBigMoneySignal == -1 ? double.MaxValue : pMaxSizeForBigMoneySignal;
				}

//				BKG_DATA_ID = 1;
//				AddDataSeries(BarsPeriodType.Minute, 5);
if(IsDebug) Print(1230);

				ImposeDataLimit = true;
                if (Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1) {
					AddDataSeries(BarsPeriodType.Tick, 1);
					BKG_DATA_ID = 1;
					Calculate = Calculate.OnEachTick;//force to on each tick    
					BarsAreMinute = false;
				}else{ 
					if(     iPCalcM == ARC_PrintProfiler_DataBasis.Second1)  {AddDataSeries(BarsPeriodType.Second, 1);  BKG_DATA_ID=1;}
					else if(iPCalcM == ARC_PrintProfiler_DataBasis.Second5)  {AddDataSeries(BarsPeriodType.Second, 5);  BKG_DATA_ID=1;}
					else if(iPCalcM == ARC_PrintProfiler_DataBasis.Second30) {AddDataSeries(BarsPeriodType.Second, 30); BKG_DATA_ID=1;}
					else if(iPCalcM == ARC_PrintProfiler_DataBasis.Minute1)  {AddDataSeries(BarsPeriodType.Minute, 1);  BKG_DATA_ID=1;}
					else if(iPCalcM == ARC_PrintProfiler_DataBasis.Minute2)  {AddDataSeries(BarsPeriodType.Minute, 2);  BKG_DATA_ID=1;}
					else if(iPCalcM == ARC_PrintProfiler_DataBasis.Minute3)  {AddDataSeries(BarsPeriodType.Minute, 3);  BKG_DATA_ID=1;}
					else if(iPCalcM == ARC_PrintProfiler_DataBasis.Minute4)  {AddDataSeries(BarsPeriodType.Minute, 4);  BKG_DATA_ID=1;}
					else if(iPCalcM == ARC_PrintProfiler_DataBasis.Minute5)  {AddDataSeries(BarsPeriodType.Minute, 5);  BKG_DATA_ID=1;}
					ImposeDataLimit       = false;
					DataStartTime         = DateTime.MinValue;
					iShowNetDelta         = false;
					iShowTotalVolumeAsPct = false;
					iShowVolAtPrice       = false;
					iPrintEnabled         = false;
					iCurrentBarEnabled    = false;
					iInventoryEnabled     = false;
					iShowNetDeltaHeatMap  = false;
					pShow_DSASignal       = false;
					Calculate = Calculate.OnBarClose;
					BarsAreMinute = true;
				}
BKG_DATA_ID = 1;

if(IsDebug) Print(1262);

				#region -- Init Plot Display --
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
				Plots[0].Brush = iVA3Color;
				Plots[0].DashStyleHelper = iVA1DashStyle;
				Plots[0].Width = iVA1Width;

				Plots[1].Brush = iVA3Color;
				Plots[1].DashStyleHelper = iVA1DashStyle;
				Plots[1].Width = iVA1Width;

				Plots[2].Brush = iVA2Color;
				Plots[2].DashStyleHelper = iVA2DashStyle;
				Plots[2].Width = iVA2Width;

				Plots[3].Brush = iVA1Color;
				Plots[3].DashStyleHelper = iVA1DashStyle;
				Plots[3].Width = iVA1Width;

				Plots[4].Brush = iVAS3Color;
				Plots[4].DashStyleHelper = iVA2DashStyle;
				Plots[4].Width = iVA2Width;

				Plots[5].Brush = iVAS3Color;
				Plots[5].DashStyleHelper = iVA2DashStyle;
				Plots[5].Width = iVA2Width;

				Plots[6].Brush = iVAS3Color;
				Plots[6].DashStyleHelper = iVAS2DashStyle;
				Plots[6].Width = iVAS2Width;

				Plots[7].Brush = iVAS1Color;
				Plots[7].DashStyleHelper = iVAS1DashStyle;
				Plots[7].Width = iVAS1Width;
#endif
				//Plots[8].Brush = iCwapManColor;
				//Plots[8].DashStyleHelper = iCwapManDashStyle;
				//Plots[8].Width = iCwapManWidth;

				//Plots[9].Brush = iCwapCompColor;
				//Plots[9].DashStyleHelper = iCwapCompDashStyle;
				//Plots[9].Width = iCwapCompWidth;
				#endregion
if(IsDebug) Print(1306);

				MM = new MouseManager();
#if STOPWATCH_OUTPUT
				BenStopwatch["Configure"] = new TimeSpan(DateTime.Now.Ticks-dt.Ticks);
#endif
			}
			#endregion

			#region --DataLoaded--
			else if (State == State.DataLoaded){
				sessionIterator				=	new SessionIterator(BarsArray[BKG_DATA_ID]);

				TableTxtBrushDX["LabelColumn"] =null;
				TableTxtBrushDX["Signal+"]     =null;
				TableTxtBrushDX["Signal-"]     =null;
				TableTxtBrushDX["Delta+"]      =null;
				TableTxtBrushDX["Delta-"]      =null;
				TableTxtBrushDX["Cum Delta+"]  =null;
				TableTxtBrushDX["Cum Delta-"]  =null;
				TableTxtBrushDX["Volume"]      =null;
				TableTxtBrushDX["Bid Vol"]     =null;
				TableTxtBrushDX["Ask Vol"]     =null;
				TableFillBrushDX["LabelColumn"] =null;
				TableFillBrushDX["Signal+"]     =null;
				TableFillBrushDX["Signal-"]     =null;
				TableFillBrushDX["Delta+"]      =null;
				TableFillBrushDX["Delta-"]      =null;
				TableFillBrushDX["Cum Delta+"]  =null;
				TableFillBrushDX["Cum Delta-"]  =null;
				TableFillBrushDX["Volume"]      =null;
				TableFillBrushDX["Bid Vol"]     =null;
				TableFillBrushDX["Ask Vol"]     =null;

//Print("Bars.IsTickReplay: "+Bars.IsTickReplay.ToString());
line=2172;//Pit(line);
//int i = 0;
//foreach(var ds in BarsArray){
//	Print(i+":  Bars.Count: "+ds.Count+"  FirstDate: "+ds.FromDate.ToString()+" :   "+ds.BarsPeriod.ToString());
//	i++;
//}
				if(Bars.IsTickReplay && pUseTickReplayData) TickReplayData = new List<TickReplayClass>(); else TickReplayData = null;

				#region -- Set start of orderflow tick data --
				DataLimitQty = Math.Abs(DataLimitQty);
				if(ImposeDataLimit){
					if(this.DataLimitType != ARC_PrintProfiler_DataLimitType.NoLimit){
						//if(DataLimitType == ARC_PrintProfiler_DataLimitType.Ticks && CurrentBars[1] < BarsArray[1].Count-DataLimitQty) {
						//	var Data1StartBar = BarsArray[1].Count-(int)Math.Round(DataLimitQty,0);
						//	DataStartTime = BarsArray[1].GetTime(Data1StartBar);
						//}
						//else
line=2187;//Pit(line);
						if(DataLimitType == ARC_PrintProfiler_DataLimitType.Minutes){
							DataStartTime = BarsArray[0].GetTime(BarsArray[0].Count-1).AddMinutes(-DataLimitQty);
						}
						else if(DataLimitType == ARC_PrintProfiler_DataLimitType.Bars){
line=2192;//Pit(line);
							DataStartTime = BarsArray[0].GetTime(Math.Max(0,BarsArray[0].Count-(int)Math.Round(DataLimitQty)));
						}
					}
				}
line=2197;//Pit(line);
				#endregion
				gbTickSize = TickSize;//#BUG001 : bug fix
				IsForex = Instrument.MasterInstrument.InstrumentType == NinjaTrader.Cbi.InstrumentType.Forex;
				if(IsForex && pRoundForexToWholePip)
					gbTickSize = TickSize * 10;

//				string FS = gbTickSize.ToString();
//				if (FS.Contains("E-"))
//				{
//                    FS = FS.Substring(FS.IndexOf("E-") + 2);
//                    PriceDigits = int.Parse(FS);
//				}
//				else PriceDigits = Math.Max(0, FS.Length - 2);
//				PriceString = "n" + PriceDigits;

				#region -- Init Exposed Series --
				CompPOC = new Series<double>(this, MaximumBarsLookBack.Infinite);
				CompVWAP = new Series<double>(this, MaximumBarsLookBack.Infinite);
				CompVAH1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				CompVAL1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				CompVAH2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				CompVAL2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				trappedtraderDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				deltadivergenceDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				volumedivergenceDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				longSignalDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				shortSignalDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				longSignalsDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				shortSignalsDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				longSignalAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				shortSignalAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				longSignalsAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				shortSignalsAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
				vCurve1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				vCurve2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				vCurve3 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				vCurve4 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				vCurve5 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				vCurveStatus = new Series<double>(this, MaximumBarsLookBack.Infinite);
				BARVAL = new Series<double>(this, MaximumBarsLookBack.Infinite);
				BARVAH = new Series<double>(this, MaximumBarsLookBack.Infinite);
				NETDELTA = new Series<double>(this, MaximumBarsLookBack.Infinite);
				VDSIGNALS = new Series<double>(this, MaximumBarsLookBack.Infinite);
				VCRSIGNALS = new Series<double>(this, MaximumBarsLookBack.Infinite);
				OFCSIGNALS = new Series<double>(this, MaximumBarsLookBack.Infinite);
				#endregion
				DSA_Signals = new Series<int>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				BARVWAP = new Series<double>(this, MaximumBarsLookBack.Infinite);
				BARPOC = new Series<double>(this, MaximumBarsLookBack.Infinite);
				BARCL = new Series<double>(this, MaximumBarsLookBack.Infinite);
				BARCLH = new Series<double>(this, MaximumBarsLookBack.Infinite);
				BARCLL = new Series<double>(this, MaximumBarsLookBack.Infinite);
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
				sma_BARVWAP1 = SMA(BARVWAP, iVA1Period);
				sma_BARPOC1  = SMA(BARPOC,  iVA1Period);
				sma_BARCL1   = SMA(BARCL,   iVA1Period);
				sma_BARCLH1  = SMA(BARCLH,  iVA1Period);
				sma_BARCLL1  = SMA(BARCLL,  iVA1Period);
				sma_BARVWAP2 = SMA(BARVWAP, iVA2Period);
				sma_BARPOC2  = SMA(BARPOC,  iVA2Period);
				sma_BARCL2   = SMA(BARCL,   iVA2Period);
				sma_BARCLH2  = SMA(BARCLH,  iVA2Period);
				sma_BARCLL2  = SMA(BARCLL,  iVA2Period);

				ema_BARVWAP1 = EMA(BARVWAP, iVA1Period);
				ema_BARPOC1  = EMA(BARPOC,  iVA1Period);
				ema_BARCL1   = EMA(BARCL,   iVA1Period);
				ema_BARCLH1  = EMA(BARCLH,  iVA1Period);
				ema_BARCLL1  = EMA(BARCLL,  iVA1Period);
				ema_BARVWAP2 = EMA(BARVWAP, iVA2Period);
				ema_BARPOC2  = EMA(BARPOC,  iVA2Period);
				ema_BARCL2   = EMA(BARCL,   iVA2Period);
				ema_BARCLH2  = EMA(BARCLH,  iVA2Period);
				ema_BARCLL2  = EMA(BARCLL,  iVA2Period);
#else
				ema_ma1 = EMA(Typical, iVA1Period);
				ema_ma2 = EMA(Typical, iVA2Period);
				sma_ma1 = SMA(Typical, iVA1Period);
				sma_ma2 = SMA(Typical, iVA2Period);
				ema_ma1.Calculate = Calculate.OnPriceChange;
				ema_ma2.Calculate = Calculate.OnPriceChange;
				sma_ma1.Calculate = Calculate.OnPriceChange;
				sma_ma2.Calculate = Calculate.OnPriceChange;
#endif

                #region -- Stamp Series --
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
				MAVWAP = new Series<double>(this, MaximumBarsLookBack.Infinite);
				MAPOC = new Series<double>(this, MaximumBarsLookBack.Infinite);
				MACL = new Series<double>(this, MaximumBarsLookBack.Infinite);
				MACLH = new Series<double>(this, MaximumBarsLookBack.Infinite);
				MACLL = new Series<double>(this, MaximumBarsLookBack.Infinite);

				MA2VWAP = new Series<double>(this, MaximumBarsLookBack.Infinite);
				MA2POC = new Series<double>(this, MaximumBarsLookBack.Infinite);
				MA2CL = new Series<double>(this, MaximumBarsLookBack.Infinite);
				MA2CLH = new Series<double>(this, MaximumBarsLookBack.Infinite);
				MA2CLL = new Series<double>(this, MaximumBarsLookBack.Infinite);
#endif
                #endregion

                #region -- Variables Series --
                AllPivots = new Series<double>(this, MaximumBarsLookBack.Infinite);
                FinalHigh = new Series<double>(this, MaximumBarsLookBack.Infinite);
                FinalLow = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveLow = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveHigh = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveLowZ = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveHighZ = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveLowF = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveHighF = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveBar = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveBar2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                lastDemandZoneHigh = new Series<double>(this, MaximumBarsLookBack.Infinite);
                lastSupplyZoneLow = new Series<double>(this, MaximumBarsLookBack.Infinite);
				nearestDemandZoneHigh = new Series<double>(this, MaximumBarsLookBack.Infinite);
				nearestSupplyZoneLow = new Series<double>(this, MaximumBarsLookBack.Infinite);
                BodyHigh = new Series<double>(this, MaximumBarsLookBack.Infinite);
                BodyLow = new Series<double>(this, MaximumBarsLookBack.Infinite);
                Direction = new Series<double>(this, MaximumBarsLookBack.Infinite);
				BigMoneyBidAvg = new Series<double>(this, MaximumBarsLookBack.Infinite);
				BigMoneyAskAvg = new Series<double>(this, MaximumBarsLookBack.Infinite);
                #endregion
            }
            #endregion

            #region --Historical--
            else if (State == State.Historical)
            {
if(IsDebug) Print(1501);
                SetZOrder(1001);
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        ChartControl.AllowDrop = false;
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;

                        foreach (DependencyObject item in chartWindow.MainMenu) {
							if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;
						}

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };
                            addToolBar();

                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                            ChartPanel.MouseMove += ChartPanel_MouseMove;
                            ChartPanel.MouseDown += ChartPanel_MouseDown;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion
            }
            #endregion

			#region --Realtime--
			else if(State == State.Realtime){
if(IsDebug) Print(1536);

				IsHistorical = false;
				if(pEnableChartMarkers){
					for(int abar = 0; abar<BarsArray[0].Count; abar++){
						int StackCount = 1;
						int DDsignal = deltadivergenceDefault.IsValidDataPointAt(abar) ? Convert.ToInt32(deltadivergenceDefault.GetValueAt(abar)) : 0;
						int TTsignal = trappedtraderDefault.IsValidDataPointAt(abar)   ? Convert.ToInt32(trappedtraderDefault.GetValueAt(abar)) : 0;
						int CSsignal = 0;
						if (pShow_CCSignal && DDsignal == TTsignal) CSsignal = DDsignal;
						int VDsignal = pShow_VDSignal  && VDSIGNALS.IsValidDataPointAt(abar)  ? Convert.ToInt32(VDSIGNALS.GetValueAt(abar)) : 0;
						int OFCsignal = pShow_OFCSignal  && OFCSIGNALS.IsValidDataPointAt(abar)  ? Convert.ToInt32(OFCSIGNALS.GetValueAt(abar)) : 0;
						if(CSsignal!=0 && pShow_CCSignal) {
							DrawChartMarker(abar, CSsignal, "CS", ref StackCount);
							var tag = string.Format("Signal{0}_{1}",abar,"TT");
							RemoveDrawObject(tag);
							tag = string.Format("Signal{0}_{1}",abar,"DD");
							RemoveDrawObject(tag);
						}else{
							if(DDsignal!=0 && pShow_DDSignal) DrawChartMarker(abar, DDsignal, "DD", ref StackCount);
							if(TTsignal!=0 && pShow_TTSignal) DrawChartMarker(abar, TTsignal, "TT", ref StackCount);
						}
						if(VDsignal!=0) {
							DrawChartMarker(abar, VDsignal, "VD", ref StackCount);
						}
						if(pShow_VCRSignal){
							int CRsignal = VCRSIGNALS.IsValidDataPointAt(abar) ? Convert.ToInt32(VCRSIGNALS.GetValueAt(abar)) : 0;
							if(pShow_VCR2b && (CRsignal==1 || CRsignal==-1)) DrawChartMarker(abar, CRsignal>=BUY?BUY:SELL, "VC", ref StackCount);
							if(pShow_VCR3b && (CRsignal==2 || CRsignal==-2)) DrawChartMarker(abar, CRsignal>=BUY?BUY:SELL, "VC", ref StackCount);
						}
						if(pShow_OFCSignal && OFCsignal!=0){
//Print("Found OFC signal at "+Times[0].GetValueAt(abar).ToString());
							DrawChartMarker(abar, OFCsignal >0 ?BUY:SELL, "OFC", ref StackCount);
						}
					}
				}
if(IsDebug) Print(1572);

				var VDS = new SortedDictionary<int,double[]>();
				IEnumerable<int> keys = null;
				if(IsDebug && false){
					for(int abar = 0; abar<BarsArray[0].Count; abar++){
						int VDsignal = pShow_VDSignal  && VDSIGNALS.IsValidDataPointAt(abar)  ? Convert.ToInt32(VDSIGNALS.GetValueAt(abar)) : 0;
						double H = Highs[0].GetValueAt(abar);
						double L = Highs[0].GetValueAt(abar);
						keys = VDS.Where(k=>k.Value[0]==1).Select(k=>k.Key);
						if(keys!=null)
						foreach(var k in keys){//long unfilled positions
							if(k==abar-1 && H <= VDS[k][1]) VDS[k][0] = 0;//no trade if the prior bar high didn't exceed the entry price
							else VDS[k][0] = 2;
						}
						keys = VDS.Where(k=>k.Value[0]==-1).Select(k=>k.Key);
						if(keys!=null)
						foreach(var k in keys){//short unfilled positions
							if(k==abar-1 && L >= VDS[k][1]) VDS[k][0] = 0;//no trade if the prior bar low didn't exceed the entry price
							else VDS[k][0] = -2;
						}
						keys = VDS.Where(k=>k.Value[0]==2 && k.Value[4]==double.MinValue).Select(k=>k.Key);
						if(keys!=null)
						foreach(var k in keys){//long open positions
							if(H >= VDS[k][3]) VDS[k][4] = VDS[k][3]-VDS[k][1];//hit the T1
							if(L <= VDS[k][2]) VDS[k][4] = VDS[k][2]-VDS[k][1];//hit the SL
						}
						keys = VDS.Where(k=>k.Value[0]==-2 && k.Value[4]==double.MinValue).Select(k=>k.Key);
						if(keys!=null)
						foreach(var k in keys){//short open positions
							if(L <= VDS[k][3]) VDS[k][4] = VDS[k][1]-VDS[k][3];//hit the T1
							if(H >= VDS[k][2]) VDS[k][4] = VDS[k][1]-VDS[k][2];//hit the SL
						}
//array is Status (+2 long trade taken, -2 short trade taken, 0 no trade, +1 long unfilled, -1 short unfilled), Entry price, SLprice, T1, PnL points
						if(VDsignal!=0) {
							if(VDsignal==BUY)  VDS[abar] = new double[5]{1,  H+TickSize, L, H + (H-L), double.MinValue};//array is Status (+2 long trade taken, -2 short trade taken, 0 no trade, +1 long unfilled, -1 short unfilled), Entry price, SLprice, T1, PnL points
							if(VDsignal==SELL) VDS[abar] = new double[5]{-1, L-TickSize, H, L - (H-L), double.MinValue};//array is Status (+2 long trade taken, -2 short trade taken, 0 no trade, +1 long unfilled, -1 short unfilled), Entry price, SLprice, T1, PnL points
						}
					}
				}
if(IsDebug) Print(1612);
				if(VDS.Count>0){
					keys = VDS.Where(k=>k.Value[4]!=double.MinValue).Select(k=>k.Key);
					double wins = 0;
					double losses = 0;
					double WinPts = 0;
					double LossPts = 0;
					int MissedTrades = 0;
					foreach(var k in keys){
						if(VDS[k][0] == 0) MissedTrades++;
						else{
							if(VDS[k][4] > 0){
								wins = wins+1;
								WinPts = WinPts + VDS[k][4];
							}
							if(VDS[k][4] < 0){
								losses = losses+1;
								LossPts = LossPts + VDS[k][4];
							}
						}
					}
					if(wins+losses==0) Print("No Trades in PrintProfiler");
					else{
						double winpct = wins/(wins+losses);
						Print("Wins: "+wins);
						Print("Losses: "+losses);
						Print("Win %: "+winpct.ToString("0%"));
						Print("Net PnL: "+((WinPts+LossPts)*Instrument.MasterInstrument.PointValue).ToString("C"));
					}
				}
			}
			#endregion

            #region --Transition--
            else if (State == State.Transition)
            {
                //bench.Stop();
                //Print(String.Format("Loading Time : {0}ms on {1} bars => {2:n}ms/bar", bench.ElapsedMilliseconds, CurrentBars[0], bench.ElapsedMilliseconds / (double)CurrentBars[0]));
            }
            #endregion

            #region --Terminated--
            else if (State == State.Terminated)
            {
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
						indytoolbar = null;
						try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
							indytoolbar = null;
							try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
							chartWindow = null;
						}));
					}
				}

                if (this.ChartControl != null)
                {
                    ChartPanel.MouseMove -= ChartPanel_MouseMove;
                    ChartPanel.MouseDown -= ChartPanel_MouseDown;
                }
            }
            #endregion
			#endregion
        }
//==========================================================================================================
	private class TickReplayClass{
		public int Dir = 0;
		public double Price;
		public double Vol;
		public int ChartABar;
		public DateTime T;
		public TickReplayClass(int dir, double price, double vol, DateTime t, int chartABar){
			Dir = dir; Price = price; Vol = vol; T = t; ChartABar = chartABar;
		}
	}
	private List<TickReplayClass> TickReplayData = null;
	long cum_deltavolume = long.MinValue;
	bool IsNewSession = false;
	protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
	{
		// TickReplay events only occur on the "Last" market data type
		if (marketDataUpdate.MarketDataType == MarketDataType.Last){
            if (sessionIterator.IsNewSession(marketDataUpdate.Time,true))
			{
				sessionIterator.CalculateTradingDay(marketDataUpdate.Time,true);
				cum_deltavolume = 0;
				IsNewSession = true;
			}
			if (Bars.IsTickReplay && this.pUseTickReplayData)// && marketDataUpdate.Price==1.2112)
			{
				if(CurrentBars==null || CurrentBars[0]<5) return;
				if (marketDataUpdate.Price >= marketDataUpdate.Ask)
				{
					cum_deltavolume += marketDataUpdate.Volume;
					//Print(string.Format("{0} contracts traded at asking price {1}  {2}", marketDataUpdate.Volume, marketDataUpdate.Ask, marketDataUpdate.Time.ToString()));
					TickReplayData.Add(new TickReplayClass(1, RoundToWholePip(marketDataUpdate.Price), marketDataUpdate.Volume, marketDataUpdate.Time, CurrentBars[0]));
				}
				else if (marketDataUpdate.Price <= marketDataUpdate.Bid)
				{
					cum_deltavolume -= marketDataUpdate.Volume;
					//Print(string.Format("{0} contracts traded at bid price {1}  {2}", marketDataUpdate.Volume, marketDataUpdate.Bid, marketDataUpdate.Time.ToString()));
					TickReplayData.Add(new TickReplayClass(-1, RoundToWholePip(marketDataUpdate.Price), marketDataUpdate.Volume, marketDataUpdate.Time, CurrentBars[0]));
				}
			}else{   // otherwise, get the real-time market data price during MarketDataType.Ask event
//				if(marketDataUpdate.MarketDataType == MarketDataType.Ask) askPrice = marketDataUpdate.Price;
//				if(marketDataUpdate.MarketDataType == MarketDataType.Bid) bidPrice = marketDataUpdate.Price;
			}
		}
	}
	private void PrintIt(int L){Print("Line: "+L);}
	private void PrintIt(string S){Print(S);}
//==========================================================================================================
		int ABarOfLastTick = 0;
		long LastVolume = 0;
bool z = false;
		string IsTickReplayWarningMsg = string.Empty;
        protected override void OnBarUpdate()
        {
			if(IsTerminated) return;
	        #region --------- OnBarUpdate() ------------
//PrintIt("- - - - - - - - - On Bar Update");
line=2459;//PrintIt(line);
#if ENABLE_TRYCATCH_OBU
try{
#endif
            if (Instruments[0] == null || Instruments[1] == null || Instruments[0].FullName != Instruments[1].FullName) return;
			#region Stopwatch
#if STOPWATCH_OUTPUT
			if(!BenStopwatch.ContainsKey("FirstBarToCurrentBar")){
				if(RunningFirstBar){
					dt = DateTime.Now;
					RunningFirstBar=false;
				}
				if(CurrentBar>Bars.Count-4){
					BenStopwatch["FirstBarToCurrentBar"] = new TimeSpan(DateTime.Now.Ticks-dt.Ticks);
					Print("-------------------------------------------------");
					Print("Bar count: "+Bars.Count);
					Print(Bars.BarsPeriod.ToString());
					Print("Stopwatch results (seconds):");
					foreach(string strkey in BenStopwatch.Keys){
						Print(strkey+":   "+BenStopwatch[strkey].TotalSeconds.ToString("0.000"));
					}
					Print("");
					Print("done");
					Print("-------------------------------------------------");
				}
			}
#endif
			#endregion
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
line=2502;//PrintIt(line);
			if(CurrentBars==null || CurrentBars[0]<1) return;
			if(CurrentBars[0]<0 || (DataStartTime!=DateTime.MinValue && Times[0].GetValueAt(CurrentBars[0])<DataStartTime)) {
				return;
			}
line=2506;//PrintIt(line);
           if (cum_deltavolume == long.MinValue && sessionIterator.IsNewSession(Times[0].GetValueAt(CurrentBars[0]),true))
			{
				sessionIterator.CalculateTradingDay(Times[0].GetValueAt(CurrentBars[0]),true);
				IsNewSession = true;
			}
//z = Times[0][0].Day==25 && Times[0][0].Hour==13 && Times[0][0].Minute==23 && (Times[0][0].Second==40 || Times[0][0].Second==30 || Times[0][0].Second==50);
			if(pUseTickReplayData && !Bars.IsTickReplay){
				if(IsTickReplayWarningMsg == string.Empty){
					IsTickReplayWarningMsg = "You must enable 'Tick Replay' in the DataSeries dialog window";
					Log(IsTickReplayWarningMsg, NinjaTrader.Cbi.LogLevel.Error);
				}
				Draw.TextFixed(this, "tickdatawarning",IsTickReplayWarningMsg, TextPosition.Center);
			}
			if(CurrentBars[0]>0 && Opens.Length>=0 && Opens[0].Count>0){
				Opens00  = RoundToWholePip(Opens[0][0]);
				Highs00  = RoundToWholePip(Highs[0][0]);
				Lows00   = RoundToWholePip(Lows[0][0]);
				Closes00 = RoundToWholePip(Closes[0][0]);
line=2512;//PrintIt(line);
				if(CurrentBars[0]>0){
					Highs01  = RoundToWholePip(Highs[0][1]);
					Lows01   = RoundToWholePip(Lows[0][1]);
				}else{
					Highs01 = Highs00;
					Lows01  = Lows00;
				}
				Highs10  = RoundToWholePip(Highs[BKG_DATA_ID][0]);
				Lows10   = RoundToWholePip(Lows[BKG_DATA_ID][0]);
				Closes10 = RoundToWholePip(Closes[BKG_DATA_ID][0]);
			}


line=2535;//PrintIt(line);
			//-- Memorize main series volume only in realtime --
            IsCurrentBar = CurrentBars[0] + 1 == BarsArray[0].Count;
            CBB = IsCurrentBar ? 1 : 0;
            if ((Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1) && IsCurrentBar)
            {
                if (Volumes[0][0] == PreviousVolume) return;
                if (BarsInProgress == 1) PreviousVolume = Volumes[0][0];
            }

line=2545;//PrintIt(line);
            #region -- composite profile reset --
            if (this.iCompositeEnabled && BarsInProgress == 0)
            {
                if (iCompositeType == "Time")
                {
                    if (R1Time.Ticks == 0)
                    {
                        R1Time = new DateTime(Times[0][0].Year, Times[0][0].Month, Times[0][0].Day, iResetTime.Hours, iResetTime.Minutes, 0);
                        R1Time = R1Time.AddMinutes(iResetMinutes);
                    }
                    CurrentTime = Times[0][0];

                    while (CurrentTime.Ticks >= R1Time.Ticks)
                    {
                        R1Time = R1Time.AddMinutes(iResetMinutes);
                        if (CompositeStartBar != 0) CompositeProfiles[CompositeStartBar] = CalculateProfile3(new SortedDictionary<double, VolumeAtBA>(compositeData));
                        compositeData.Clear();
                        CompositeStartBar = Math.Max(0, CurrentBars[0]);
                    }
                }

                if ((iCompositeType == "Day" || iCompositeType == "Time") && BarsArray[0].IsFirstBarOfSession)
                {
                    if (CompositeStartBar != 0) CompositeProfiles[CompositeStartBar] = CalculateProfile3(new SortedDictionary<double, VolumeAtBA>(compositeData));
                    compositeData.Clear();
                    CompositeStartBar = Math.Max(0, CurrentBars[0]);
                }
            }
            #endregion

            if (BarsInProgress == 0 && CurrentBars[0] > 0)
            {
				atr30_pts = SUM(Range(),30)[0]/30.0;
				if(pHeatMapHeightPeriod>1 && CurrentBars[0]>pHeatMapHeightPeriod){
					double sum = 0;
					for(int i=0; i<pHeatMapHeightPeriod; i++) sum = sum+Volumes[0][i];
					VolumeAverage[CurrentBars[0]] = Convert.ToSingle(sum/pHeatMapHeightPeriod / (IsForex ? pFOREXD : 1));
				}
                BodyHigh[0]  = RTTS(Math.Max(Closes00, Opens00));
                BodyLow[0]   = RTTS(Math.Min(Closes00, Opens00));
                Direction[0] = Closes00 > Opens00 ? 1 : Closes00 < Opens00 ? -1 : Direction[1];

				#region -- Calc UnfinishedBiz signal --
				if(IsFirstTickOfBar && BarDataCollection.ContainsKey(CurrentBars[0]-1)){
					int type = 0;
					int abar = CurrentBars[0]-1;
					double Highs0CB = this.RTTS(Highs[0].GetValueAt(abar));
					double Lows0CB = this.RTTS(Lows[0].GetValueAt(abar));
					if(BarDataCollection[abar].ContainsKey(Highs0CB) && BarDataCollection[abar][Highs0CB].AskSize>0 && BarDataCollection[abar][Highs0CB].BidSize>0){
						type = 1;
						if(!UnfinishedBizLocs.ContainsKey(abar))
							UnfinishedBizLocs[abar] = new UnfinishedBizData(Highs0CB, 'H');
						else
							UnfinishedBizLocs[abar].HighPrice = Highs0CB;
					}
					if(BarDataCollection[abar].ContainsKey(Lows0CB) && BarDataCollection[abar][Lows0CB].AskSize>0 && BarDataCollection[abar][Lows0CB].BidSize>0){
						type = -1;
						if(!UnfinishedBizLocs.ContainsKey(abar)) 
							UnfinishedBizLocs[abar] = new UnfinishedBizData(Lows0CB, 'L');
						else
							UnfinishedBizLocs[abar].LowPrice = Lows0CB;
					}
					if(type==0){
						UnfinishedBizLocs.Remove(abar);
					}
					double MidPrice1 = (Highs[0].GetValueAt(abar-1)+Lows[0].GetValueAt(abar-1))/2;
					var ufb = UnfinishedBizLocs.Where(k=>k.Value.WasHighHitABar==0 && k.Key < abar).ToList();
					foreach(var u in ufb){
						if(MidPrice1 <= u.Value.HighPrice && Highs0CB >= u.Value.HighPrice){
							UnfinishedBizLocs[u.Key].WasHighHitABar = Math.Max(u.Key+1, abar);
						}
					}
					ufb = UnfinishedBizLocs.Where(k=>k.Value.WasLowHitABar==0 && k.Key < abar).ToList();
					foreach(var u in ufb){
						if(MidPrice1 >= u.Value.LowPrice && Lows0CB <= u.Value.LowPrice){
							UnfinishedBizLocs[u.Key].WasLowHitABar = Math.Max(u.Key+1, abar);
						}
					}
				}
				#endregion
            }

line=2589;//PrintIt(line);
            if (Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
            {
                #region -- update bar levels --
                if (BarsInProgress == 0)
                {
                    ReadyToClose = true;
                    if (IsFirstTickOfBar && BarDataCollection.ContainsKey(CurrentBars[0] - 1))
                    {
						int abar = CurrentBars[0]-1;
                        double StartPrice = Highs01;
                        do
                        {
                            if (!BarDataCollection[abar].ContainsKey(StartPrice))
                            {
                                BarDataCollection[abar][StartPrice] = new PrintLevelDetails();
                                BarDataCollection[abar][StartPrice].AskSize = 0;
                                BarDataCollection[abar][StartPrice].BidSize = 0;
                                BarDataCollection[abar][StartPrice].AskSizeReduced = 0;
                                BarDataCollection[abar][StartPrice].BidSizeReduced = 0;
                            }
                            StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                        }
                        while (StartPrice >= Lows01);
                    }
                }
                #endregion
				#region Tick
                if (!BarsAreMinute && BarsInProgress == 1 && ReadyToClose && BarsArray[BKG_DATA_ID].Count>1 & BarsArray[0].Count>CBB)
                {
					#region --A--
                    bool PriceDone = Closes[BKG_DATA_ID][0] < Lows[0][CBB] || Closes[BKG_DATA_ID][0] > Highs[0][CBB];
                    bool TimeDone = Times[BKG_DATA_ID][0] > Times[0][CBB];

                    if (TimeDone || PriceDone){
                        ReadyToClose = false;
                        if (State == State.Historical)
                        {
                            ThisCurrentBar = CurrentBars[0];
                            var AI = ProcessFootSignals(thisBarData);
if(z){
	Print(Times[0][0].ToString());
	foreach(var kk in AI){
		Print(string.Format("     {0} :  {1} / {2}",kk.Key, kk.Value.BidSize, kk.Value.AskSize));
	}
}
                            if (CurrentBars[0] > 1) BarDataCollection[ThisCurrentBar] = new SortedDictionary<double, PrintLevelDetails>(AI);

                            //-- add new level --
                            if (BarDataCollection.ContainsKey(ThisCurrentBar))
                            {
                                double StartPrice = Highs00;
                                do
                                {
                                    if (!BarDataCollection[ThisCurrentBar].ContainsKey(StartPrice))
                                    {
                                        BarDataCollection[ThisCurrentBar].Add(StartPrice, new PrintLevelDetails());
                                        BarDataCollection[ThisCurrentBar][StartPrice].AskSize = 0;
                                        BarDataCollection[ThisCurrentBar][StartPrice].BidSize = 0;
		                                BarDataCollection[ThisCurrentBar][StartPrice].AskSizeReduced = 0;
        		                        BarDataCollection[ThisCurrentBar][StartPrice].BidSizeReduced = 0;
                                    }
                                    StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                                }
                                while (StartPrice >= Lows00);
                            }

                            if (!Initialized && !IsCurrentBar) thisBarData.Clear();
                        }
                    }
					#endregion
                }

                if (BarsInProgress == 0 && CurrentBars[0] > 0)
                {
                    if (BarsAreMinute)
                    {
                        if (State == State.Historical)
                        {
                            var AI = ProcessFootSignals(thisBarData);
                            if (CurrentBars[0] > 1) BarDataCollection[CurrentBars[0]] = new SortedDictionary<double, PrintLevelDetails>(AI);
                            if (!Initialized && !IsCurrentBar) thisBarData.Clear();
                        }

                        if (IsFirstTickOfBar && IsCurrentBar)
                        {
                            if (Initialized) thisBarData.Clear();
                            Initialized = true;
                        }

                        if (BarDataCollection.ContainsKey(CurrentBars[0]))
                        {
                            double StartPrice = Highs00;
                            do
                            {
                                if (!BarDataCollection[CurrentBars[0]].ContainsKey(StartPrice))
                                {
                                    BarDataCollection[CurrentBars[0]].Add(StartPrice, new PrintLevelDetails());
                                    BarDataCollection[CurrentBars[0]][StartPrice].AskSize = 0;
                                    BarDataCollection[CurrentBars[0]][StartPrice].BidSize = 0;
	                                BarDataCollection[CurrentBars[0]][StartPrice].AskSizeReduced = 0;
    	                            BarDataCollection[CurrentBars[0]][StartPrice].BidSizeReduced = 0;
                                }
                                StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                            }
                            while (StartPrice >= Lows00);
                        }
                    }
                    else
                    {
                        if (State == State.Historical && CurrentBars[0] > 1 && !BarDataCollection.ContainsKey(CurrentBars[0]))
                        {
                            BarDataCollection[CurrentBars[0]] = new SortedDictionary<double, PrintLevelDetails>();
                            double StartPrice = Highs00;
                            do
                            {
                                BarDataCollection[CurrentBars[0]].Add(StartPrice, new PrintLevelDetails());
                                BarDataCollection[CurrentBars[0]][StartPrice].AskSize = 0;
                                BarDataCollection[CurrentBars[0]][StartPrice].BidSize = 0;
                                BarDataCollection[CurrentBars[0]][StartPrice].AskSizeReduced = 0;
                                BarDataCollection[CurrentBars[0]][StartPrice].BidSizeReduced = 0;
                                StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                            }
                            while (StartPrice >= Lows00);

line=2711;
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
							#region -- VA's based on transaction volume
                            if (iVAEnabled)
                            {
                                if (iVAEnabled1 && MAPOC.IsValidDataPoint(0))  Values[3][0] = MAPOC[0];
                                if (iVAEnabled2 && MAVWAP.IsValidDataPoint(0)) Values[2][0] = MAVWAP[0];
                                if (iVAEnabled3 && MACLH.IsValidDataPoint(0) && MACLL.IsValidDataPoint(0))
                                {
                                    Values[1][0] = MACLH[0];
                                    Values[0][0] = MACLL[0];
                                }
                            }

                            if (iVA2Enabled)
                            {
                                if (iVA2Enabled1) Values[7][0] = MA2POC[0];
                                if (iVA2Enabled2) Values[6][0] = MA2VWAP[0];
                                if (iVA2Enabled3)
                                {
                                    Values[5][0] = MA2CLH[0];
                                    Values[4][0] = MA2CLL[0];
                                }
                            }
							#endregion
#endif
                        }

                        if (IsFirstTickOfBar && IsCurrentBar)
                        {
                            ThisCurrentBar = CurrentBars[0];
                            if (Initialized) thisBarData.Clear();
                            Initialized = true;
                        }
                    }
                    ProcessZones();
//if(false && IsDebug){
//	try{
////		Print(Times[0][0].ToString()+"  nearestSupplyZoneLow[0]: "+nearestSupplyZoneLow[0]);
//		Draw.Dot(this,string.Format("nSZL{0}",CurrentBars[0]),false,0,nearestSupplyZoneLow[0],Brushes.Yellow);
////		Print("       nearestDemandZoneHigh[0]: "+nearestDemandZoneHigh[0]);
//		Draw.Dot(this,string.Format("nDZH{0}",CurrentBars[0]),false,0,nearestDemandZoneHigh[0],Brushes.Cyan);
//	}catch(Exception eee){Print(eee.ToString());}
//}
                }

line=2757;
                if (BarsInProgress == BKG_DATA_ID)
                {
					if (CurrentBars[BKG_DATA_ID] < 1) return;
//					if (iPCalcM != ARC_PrintProfiler_DataBasis.Tick1){
//						TickDirection = Closes[BKG_DATA_ID][0] > Closes[BKG_DATA_ID][1] ? 1 : Closes[BKG_DATA_ID][0] < Closes[BKG_DATA_ID][1] ? -1 : TickDirection;
//						LastVolume = (long)Volumes[BKG_DATA_ID][0];
//					}
					if (IsForex && LastVolume >= pFOREXD) LastVolume = LastVolume / pFOREXD;// FOREX divide by 100000
//Print(string.Format("    TickDirection {0}   Vol: {1}",TickDirection, LastVolume));


					#region -- Process Print --
					TickLevels.Clear();
					if(TickReplayData==null){//no TickReplayData found
						//TickLevels.Add(Closes10);
						double LastPrice = Closes10;
						TickDirection = Closes[BKG_DATA_ID][0] > Closes[BKG_DATA_ID][1] ? 1 : Closes[BKG_DATA_ID][0] < Closes[BKG_DATA_ID][1] ? -1 : TickDirection;
						LastVolume = (long)Volumes[BKG_DATA_ID][0];
						#region -- Process COMPOSITE --
						if(this.iCompositeEnabled){
							#region -- update ask --
							if (TickDirection == 1)
							{
	line=2772;
								//foreach (double LastPrice in TickLevels)
								{
									if (compositeData.ContainsKey(LastPrice))
									{
//if(z) Print(Times[0][0].ToString()+"   TickDir = 1: "+LastPrice);
										compositeData[LastPrice].AskSize = compositeData[LastPrice].AskSize + LastVolume;
									}
									else
									{
//if(z) Print(Times[0][0].ToString()+"  New level TickDir = 1: "+LastPrice);
										compositeData.Add(LastPrice, new VolumeAtBA());
										compositeData[LastPrice].AskSize = LastVolume;
									}
								}
							}
							#endregion
							#region -- update bid --
							else
							{
	line=2790;
								//foreach (double LastPrice in TickLevels)
								{
									if (compositeData.ContainsKey(LastPrice))
									{
	//if(z) Print(Times[0][0].ToString()+"   TickDir = -1: "+LastPrice);
										compositeData[LastPrice].BidSize = compositeData[LastPrice].BidSize + LastVolume;
									}
									else
									{
	//if(z) Print(Times[0][0].ToString()+"  New level TickDir = -1: "+LastPrice);
										compositeData.Add(LastPrice, new VolumeAtBA());
										compositeData[LastPrice].BidSize = LastVolume;
									}
		//if(zone)Print(LastPrice+"   Bid: "+compositeData[LastPrice].BidSize+"  ask "+compositeData[LastPrice].AskSize);
								}
							}
							#endregion
						}
line=2769;
	                    if (IsCurrentBar && this.iCompositeEnabled) CompositeProfiles[CompositeStartBar] = CalculateProfile3(new SortedDictionary<double, VolumeAtBA>(compositeData));
	                    #endregion
	                    #region -- update ask --
	                    if (TickDirection == 1)
	                    {
//if(z) Print(string.Format("Up - TickLevels.count: {0}", TickLevels.Count));
	                        //foreach (double lastPrice in TickLevels)
	                        {
	                            //double LastPrice = RoundToWholePip(lastPrice);//##Modif by Kriss AzurITec## - BUGPP002 FIXED 07.04.2016
if(z) Print(string.Format("{4}   {3}    Dir {0}   Vol: {1}  Price: {2}", 1, LastVolume, LastPrice, TickLevels.Count, Times[1][0].ToString("HH:mm:ss.fff")));
	                            if (thisBarData.ContainsKey(LastPrice))
	                            {
	                                thisBarData[LastPrice].AskSize = thisBarData[LastPrice].AskSize + LastVolume;
	                                thisBarData[LastPrice].AskSizeReduced = thisBarData[LastPrice].AskSize / pVisualVolumeDivisor;
	                            }
	                            else
	                            {
	                                thisBarData.Add(LastPrice, new PrintLevelDetails());
	                                thisBarData[LastPrice].AskSize = LastVolume;
	                                thisBarData[LastPrice].AskSizeReduced = LastVolume / pVisualVolumeDivisor;
	                            }
								if (LastVolume >= iBlockSize) thisBarData[LastPrice].AskBlocks.Add(LastVolume);
	                        }
	                    }
	                    #endregion
	                    #region -- update bid --
	                    else if (TickDirection == -1)
	                    {
line=2800;
//	Print(string.Format("Down - TickLevels.count: {0}", TickLevels.Count));
	                        //foreach (double lastPrice in TickLevels)
	                        {
	                            //double LastPrice = RoundToWholePip(lastPrice);//##Modif by Kriss AzurITec## - BUGPP002 FIXED 07.04.2016
//Print(string.Format("{4}   {3}    Dir {0}   Vol: {1}  Price: {2}", -1, LastVolume, LastPrice, TickLevels.Count, Times[1][0].ToString("HH:mm:ss.fff")));
	                            if (thisBarData.ContainsKey(LastPrice))
	                            {
	                                thisBarData[LastPrice].BidSize = (thisBarData[LastPrice].BidSize + LastVolume);
	                                thisBarData[LastPrice].BidSizeReduced = thisBarData[LastPrice].BidSize / pVisualVolumeDivisor;
	                            }
	                            else
	                            {
	                                thisBarData.Add(LastPrice, new PrintLevelDetails());
	                                thisBarData[LastPrice].BidSize = LastVolume;
	                                thisBarData[LastPrice].BidSizeReduced = LastVolume / pVisualVolumeDivisor;
	                            }
								if (LastVolume >= iBlockSize) thisBarData[LastPrice].BidBlocks.Add(LastVolume);
	                        }
	                    }
	                    #endregion
					}else{
						var trd = TickReplayData.Where(k=>k.ChartABar == CurrentBars[0]).ToList();
						while(trd!=null && trd.Count>0){
							#region -- Process COMPOSITE --
							if(this.iCompositeEnabled){
								#region -- update ask --
								if (trd[0].Dir == 1)
								{
line=2772;
									if (compositeData.ContainsKey(trd[0].Price))
									{
										compositeData[trd[0].Price].AskSize = compositeData[trd[0].Price].AskSize + trd[0].Vol;
									}
									else
									{
										compositeData.Add(trd[0].Price, new VolumeAtBA());
										compositeData[trd[0].Price].AskSize = trd[0].Vol;
									}
								}
								#endregion
								#region -- update bid --
								else
								{
line=2790;
									if (compositeData.ContainsKey(trd[0].Price))
									{
										compositeData[trd[0].Price].BidSize = compositeData[trd[0].Price].BidSize + trd[0].Vol;
									}
									else
									{
										compositeData.Add(trd[0].Price, new VolumeAtBA());
										compositeData[trd[0].Price].BidSize = trd[0].Vol;
									}
								}
								#endregion
							}
line=2769;
		                    if (IsCurrentBar && this.iCompositeEnabled) CompositeProfiles[CompositeStartBar] = CalculateProfile3(new SortedDictionary<double, VolumeAtBA>(compositeData));
		                    #endregion
//Print(string.Format("{4}   {3}    Dir {0}   Vol: {1}  Price: {2}", trd[0].Dir, trd[0].Vol, trd[0].Price, trd.Count, trd[0].T.ToString("HH:mm:ss.fff")));
							#region -- update ask --
							if (trd[0].Dir == 1)//process as an Ask tick
							{
								if (thisBarData.ContainsKey(trd[0].Price))
								{
									thisBarData[trd[0].Price].AskSize = thisBarData[trd[0].Price].AskSize + trd[0].Vol;
									thisBarData[trd[0].Price].AskSizeReduced = thisBarData[trd[0].Price].AskSize / pVisualVolumeDivisor;
								}
								else
								{
									thisBarData.Add(trd[0].Price, new PrintLevelDetails());
									thisBarData[trd[0].Price].AskSize = trd[0].Vol;
									thisBarData[trd[0].Price].AskSizeReduced = trd[0].Vol / pVisualVolumeDivisor;
								}
								if (trd[0].Vol >= iBlockSize) thisBarData[trd[0].Price].AskBlocks.Add(trd[0].Vol);
		                    }
	    	                #endregion
	        	            #region -- update bid --
		                    else if (trd[0].Dir == -1)//process as a Bid tick
		                    {
								if (thisBarData.ContainsKey(trd[0].Price))
								{
								    thisBarData[trd[0].Price].BidSize = (thisBarData[trd[0].Price].BidSize + trd[0].Vol);
								    thisBarData[trd[0].Price].BidSizeReduced = thisBarData[trd[0].Price].BidSize / pVisualVolumeDivisor;
								}
								else
								{
								    thisBarData.Add(trd[0].Price, new PrintLevelDetails());
								    thisBarData[trd[0].Price].BidSize = trd[0].Vol;
								    thisBarData[trd[0].Price].BidSizeReduced = trd[0].Vol / pVisualVolumeDivisor;
								}
								if (trd[0].Vol >= iBlockSize) thisBarData[trd[0].Price].BidBlocks.Add(trd[0].Vol);
	            	        }
		                    #endregion
							trd.RemoveAt(0);
						}
						while(TickReplayData.Count>0 && TickReplayData[0].ChartABar <= CurrentBars[0]) TickReplayData.RemoveAt(0);
					}
//					if (IsForex){
//						foreach(var kvp in thisBarData){
//							//thisBarData[kvp.Key].AskSize = thisBarData[kvp.Key].AskSize / pFOREXD;
//							thisBarData[kvp.Key].BidSize = thisBarData[kvp.Key].BidSize / pFOREXD;
//						}
//					}

line=2827;
                    if (IsCurrentBar)
                    {
                        double StartPrice = RoundToWholePip(Highs[0][CurrentBars[0] - ThisCurrentBar]);//##Modif by Kriss AzurITec## - BUGPP002 FIXED 02.04.2016
                        do
                        {
                            if (!thisBarData.ContainsKey(StartPrice))
                            {
                                thisBarData.Add(StartPrice, new PrintLevelDetails());
                                thisBarData[StartPrice].AskSize = 0;
                                thisBarData[StartPrice].BidSize = 0;
                                thisBarData[StartPrice].AskSizeReduced = 0;
                                thisBarData[StartPrice].BidSizeReduced = 0;
                            }
                            StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                        }
                        while (StartPrice >= RoundToWholePip(Lows[0][CurrentBars[0] - ThisCurrentBar]));

line=2843;
                        var AI = ProcessFootSignals(thisBarData);
                        if (BarsAreMinute) 
							BarDataCollection[CurrentBars[0]] = new SortedDictionary<double, PrintLevelDetails>(AI);
                        else 
							BarDataCollection[ThisCurrentBar] = new SortedDictionary<double, PrintLevelDetails>(AI);

                        StartPrice = Highs00;
                        if (BarDataCollection.ContainsKey(CurrentBars[0]))
                        {
line=2853;
                            do
                            {
                                if (!BarDataCollection[CurrentBars[0]].ContainsKey(StartPrice))
                                {
                                    BarDataCollection[CurrentBars[0]].Add(StartPrice, new PrintLevelDetails());
                                    BarDataCollection[CurrentBars[0]][StartPrice].AskSize = 0;
                                    BarDataCollection[CurrentBars[0]][StartPrice].BidSize = 0;
                                    BarDataCollection[CurrentBars[0]][StartPrice].AskSizeReduced = 0;
                                    BarDataCollection[CurrentBars[0]][StartPrice].BidSizeReduced = 0;
                                }
                                StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                            }
                            while (StartPrice >= Lows00);
                        }
                    }
                    #endregion
                }
				#endregion
            }
            else
			{
				#region -- VolumeProfileOnly --
line=2874;
                if (BarsInProgress == 0 && CurrentBars[0] > 0)
                {
                    if (IsFirstTickOfBar) BarDataCollection[CurrentBars[0]] = new SortedDictionary<double, PrintLevelDetails>(thisBarData);
                    thisBarData.Clear();
					if(iVA1Mode[0]=='E'){
						MA1High[0] = ema_ma1[0] + iVA1_ClusterSizeTicks/2.0*TickSize;
						MA1Low[0]  = ema_ma1[0] - iVA1_ClusterSizeTicks/2.0*TickSize;
					}
					else if(iVA1Mode[0]=='S'){
						MA1High[0] = sma_ma1[0] + iVA1_ClusterSizeTicks/2.0*TickSize;
						MA1Low[0]  = sma_ma1[0] - iVA1_ClusterSizeTicks/2.0*TickSize;
					}
					if(iVA2Mode[0]=='E'){
						MA2High[0] = ema_ma2[0] + iVA2_ClusterSizeTicks/2.0*TickSize;
						MA2Low[0]  = ema_ma2[0] - iVA2_ClusterSizeTicks/2.0*TickSize;
					}
					else if(iVA2Mode[0]=='S'){
						MA2High[0] = sma_ma2[0] + iVA2_ClusterSizeTicks/2.0*TickSize;
						MA2Low[0]  = sma_ma2[0] - iVA2_ClusterSizeTicks/2.0*TickSize;
					}
                }

                if (BarsInProgress == BKG_DATA_ID)
                {
line=2899;
                    if (CurrentBars[BKG_DATA_ID] < 1) return;
                    TickDirection = Closes[BKG_DATA_ID][0] > Closes[BKG_DATA_ID][1] ? 1 : Closes[BKG_DATA_ID][0] < Closes[BKG_DATA_ID][1] ? -1 : TickDirection;

					LastVolume = (long)Volumes[BKG_DATA_ID][0];
                    TickLevels.Clear();

                    if (IsCurrentBar)
                    {
                        TickLevels.Add(Closes10);
                        LastVolume = (long)Volumes[BKG_DATA_ID][0] - PLastVolume;
                        if (LastVolume <= 0) LastVolume = (long)Volumes[BKG_DATA_ID][0];
                        PLastVolume = (long)Volumes[BKG_DATA_ID][0];
                    }
                    else
                    {
line=2915;
                        double StartPrice2 = Highs10;
                        do
                        {
                            TickLevels.Add(StartPrice2);
                            StartPrice2 = (StartPrice2 - gbTickSize);
                        }
                        while (StartPrice2 >= Lows10);
                        LastVolume = (int)(Volumes[BKG_DATA_ID][0] / TickLevels.Count);
                    }

                    if (IsForex && LastVolume >= pFOREXD) LastVolume = LastVolume / pFOREXD;// FOREX divide by 100000

                    foreach (double LastPrice in TickLevels)
                    {
line=2930;
						if(this.iCompositeEnabled){
	                        if (compositeData.ContainsKey(LastPrice))
        	                {
            	                compositeData[LastPrice].AskSize = compositeData[LastPrice].AskSize + LastVolume;
                	        }
                    	    else
                        	{
                            	compositeData.Add(LastPrice, new VolumeAtBA());
	                            compositeData[LastPrice].AskSize = LastVolume;
    	                    }
						}

                        if (thisBarData.ContainsKey(LastPrice))
                        {
                            thisBarData[LastPrice].AskSize = thisBarData[LastPrice].AskSize + LastVolume;
                        }
                        else
                        {
                            thisBarData.Add(LastPrice, new PrintLevelDetails());
                            thisBarData[LastPrice].AskSize = LastVolume;
                        }
                    }

                    if (IsCurrentBar && this.iCompositeEnabled) {
						CompositeProfiles[CompositeStartBar] = CalculateProfile3(new SortedDictionary<double, VolumeAtBA>(compositeData));
					}
                }
				#endregion
            }

            #region -- Update Composite Series --
            if (this.iCompositeEnabled && BarsInProgress == 0 && CurrentBar > 0)
            {
                CompositeProfiles[CompositeStartBar] = CalculateProfile3(new SortedDictionary<double, VolumeAtBA>(compositeData));
                CompPOC[0] = CompositeProfiles[CompositeStartBar].POCPrice == 0 ? CompPOC[1] : CompositeProfiles[CompositeStartBar].POCPrice;
                CompVWAP[0] = CompositeProfiles[CompositeStartBar].VWAP == 0 ? CompVWAP[1] : CompositeProfiles[CompositeStartBar].VWAP;
                CompVAH1[0] = CompositeProfiles[CompositeStartBar].VAH == 0 ? CompVAH1[1] : CompositeProfiles[CompositeStartBar].VAH;
                CompVAL1[0] = CompositeProfiles[CompositeStartBar].VAL == 0 ? CompVAL1[1] : CompositeProfiles[CompositeStartBar].VAL;
                CompVAH2[0] = CompositeProfiles[CompositeStartBar].VAH2 == 0 ? CompVAH2[1] : CompositeProfiles[CompositeStartBar].VAH2;
                CompVAL2[0] = CompositeProfiles[CompositeStartBar].VAL2 == 0 ? CompVAL2[1] : CompositeProfiles[CompositeStartBar].VAL2;

            }
            #endregion

            #region -- update trapped trader and delta divergence Series --
            if (CurrentBars[0] > 1)
            {
                for (int u = 0; u <= (!BarsAreMinute ? 1 : 0); u++)
                {
                    trappedtraderDefault[u] = FLAT;
                    int barago = CurrentBars[0] - u;

                    // trapped trader and delta divergence 
                    if (BarDataTotals.ContainsKey(barago))
                    {
                        if (BarDataTotals[barago].TrappedTraderN > 0) {
//if(IsDebug) Print("TrappedTrader BUY barago: "+barago);
							trappedtraderDefault[u] = BUY;
						}
                        if (BarDataTotals[barago].TrappedTraderN < 0) {
//if(IsDebug) Print("TrappedTrader SELL barago: "+barago);
							trappedtraderDefault[u] = SELL;
						}
                        if (BarDataTotals[barago].POC > 0) deltadivergenceDefault[u] = BUY;
                        if (BarDataTotals[barago].POC < 0) deltadivergenceDefault[u] = SELL;
                    }
                }
            }
            #endregion

            #region -- Reset and Create new BarDataCollection --
			if(Bars.Count<5 && LowBarWarningCount<3) {
				Log(string.Format("{0} {1}: has only {2}-bars on the chart",Instrument.MasterInstrument.Name,Bars.BarsPeriod.ToString(), Bars.Count), NinjaTrader.Cbi.LogLevel.Information);
				LowBarWarningCount++;
			}
            if (Bars.Count>5 && IsCurrentBar && BarsInProgress == 0 && IsFirstTickOfBar && !BarDataCollection.ContainsKey(CurrentBars[0] - 1))
            {
				int abar = CurrentBars[0]-1;
                BarDataCollection[abar] = new SortedDictionary<double, PrintLevelDetails>();
                double StartPrice = Highs01;
                do
                {
                    BarDataCollection[abar].Add(StartPrice, new PrintLevelDetails());
                    BarDataCollection[abar][StartPrice].AskSize = 0;
                    BarDataCollection[abar][StartPrice].BidSize = 0;
                    BarDataCollection[abar][StartPrice].AskSizeReduced = 0;
                    BarDataCollection[abar][StartPrice].BidSizeReduced = 0;
                    StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                }
                while (StartPrice >= Lows01);
            }
            #endregion

			#region -- Calc BigMoney level --
			if(BarsInProgress == 0){// && CurrentBars[0] > BarsArray[0].Count-3){
				double sumBid = 0;
				int countBid = 0;
				double sumAsk = 0;
				int countAsk = 0;
//var dt = Times[0].GetValueAt(CurrentBars[0]);
//var z = dt.Day==6 && dt.Hour==7 && dt.Minute==52;
				for(int i = CurrentBars[0]-1; i>=CurrentBars[0]-this.pBigMoneyLookbackBars; i--){
					if(!BarDataCollection.ContainsKey(i)) continue;
					var BarData_ABar = BarDataCollection[i].ToList();
					var bardata_ptr  = BarData_ABar.GetEnumerator();
line=3032;
//if(z)Print(Environment.NewLine+dt.ToString());
					while(bardata_ptr.MoveNext())
				    {
						var kvp2 = bardata_ptr.Current;
						if(kvp2.Value.AskSize>0){countAsk++; sumAsk = sumAsk + kvp2.Value.AskSize;}
//else if(z) Print("rejected Ask: "+kvp2.Value.AskSize+"  sum: "+sumAsk+"   count: "+countAsk);
						if(kvp2.Value.BidSize>0){countBid++; sumBid = sumBid + kvp2.Value.BidSize;}
//else if(z) Print("rejected Bid: "+kvp2.Value.BidSize+"  sum: "+sumBid+"   count: "+countBid);
					}
				}
line=3044;
				if(countBid>0) {
					CurrentBigMoneyBidAvg = sumBid/countBid;
					BigMoneyBidAvg[0] = CurrentBigMoneyBidAvg * pBigMoneyMultiplier;
				}
				if(countAsk>0) {
					CurrentBigMoneyAskAvg = sumAsk/countAsk;
					BigMoneyAskAvg[0] = CurrentBigMoneyAskAvg * pBigMoneyMultiplier;
//if(z)Print("BigMoneyAskAvg: "+BigMoneyAskAvg[0]);
				}
			}
			#endregion

			#region -- Calculate OrderFlowConfluence Signal --
//delta = BarDataTotals[abar].AskTotal - BarDataTotals[abar].BidTotal;
//Math.Abs(BarDataTotals[abar].CumDelta);
//v = (BarDataTotals[abar].BidTotal > BarDataTotals[abar].AskTotal ? -BarDataTotals[abar].BidTotal : BarDataTotals[abar].AskTotal) / Volumes[0].GetValueAt(abar);
            if (Bars.Count>5 && BarsInProgress == 0 && IsFirstTickOfBar && BarDataTotals.ContainsKey(CurrentBars[0] - 1))
            {
				int abar = CurrentBars[0]-1;
				bool c1 = BarDataTotals[abar].AskTotal > BarDataTotals[abar].BidTotal;
				bool c2 = BarDataTotals[abar].CumDelta > 0;
				if(c1 && c2) OFCSIGNALS[1] = 1;
				else if(!c1 && !c2) OFCSIGNALS[1] = -1;
				else OFCSIGNALS.Reset(1);
//				if (AudibleAlertMgr!=null && lastBarIndex>=CurrentBars[0]- 1 && DirectionOfSignal != 0){
//					if(pSignalTiming == ARC_PrintProfiler_SignalTimingTypes.OnTick && abar==lastBarIndex)
//						AudibleAlertMgr.Play(this, DirectionOfSignal>0?BUY:SELL, SignalOnBar.Count>0 ? SignalOnBar[0]:"", abar);
//				}
			}

			#endregion

			#region -- Dynamic BlockSize calc --
			if(BarsInProgress == 1 && CurrentBars[0] > BarsArray[0].Count - pDynBlockSizeLookbackBars && BarsArray.Length>=2){
line=3059;
				DynBlockCalculationsCompleted++;
				if(IsHistorical || pEnableContinuousDynBlockSizeCalc){
					if(Volumes[BKG_DATA_ID][0]>2) {
						DynamicBlocks.Add(Volumes[BKG_DATA_ID][0]);
						if(IsHistorical) MaxDynamicBlocksizeLookback = DynamicBlocks.Count;
						else
							while(DynamicBlocks.Count > MaxDynamicBlocksizeLookback) DynamicBlocks.RemoveAt(DynamicBlocks.Count-1);
//Print("Historical Blocks in list: "+DynamicBlocks.Count);
					}
				}
				bool c1 = (!IsHistorical && IsFirstTickOfBar) || DynBlockCalculationsCompleted > pDynBlockSizeLookbackBars;
				if(c1 && (pEnableContinuousDynBlockSizeCalc || AvgDynamicBlock==-1) && CurrentBars[0] > BarsArray[0].Count-5){
//Print("Blocks in list: "+DynamicBlocks.Count);
					DynBlockCalculationsCompleted = int.MinValue;
					var blocks = new List<double>(DynamicBlocks);
					blocks.Sort();
line=3076;
					if(blocks.Count>0){
						if(blocks[0] > blocks.Last()) blocks.Reverse();
						int removal_size = Convert.ToInt32(blocks.Count *(1.0-pDynBlockSizePercentile));
						if(removal_size == blocks.Count) removal_size = blocks.Count-1;
						blocks.RemoveRange(0, removal_size);
//Print("blocks.Count after removal: "+blocks.Count+"  removal_size: "+removal_size);
line=3083;

						AvgDynamicBlock = blocks.Average();
					}
//foreach(var x in blocks)Print("Bloc: "+x);
				}
			}
			#endregion
			#region -- For DEBUG only:  Sound Alert on DSA signal --
			if(IsDebug && SoundAlertBar != CurrentBars[0] && State != State.Historical && CurrentBars[0]>5 &&  DSA_Signals[1]!=0){
				var buywav = AddSoundFolder(Instrument.MasterInstrument.Name+"_Buy_DSA.wav");
				var sellwav = AddSoundFolder(Instrument.MasterInstrument.Name+"_Sell_DSA.wav");
				//Print("Looking for Buy: "+buywav+"  Sell: "+sellwav);
				if(System.IO.File.Exists(buywav)  && DSA_Signals[1] == 1)  Alert("buy",  Priority.High, "DSA Buy",  buywav, 1,  Brushes.Green, Brushes.White);
				if(System.IO.File.Exists(sellwav) && DSA_Signals[1] == -1) Alert("sell", Priority.High, "DSA Sell", sellwav, 1, Brushes.Red,   Brushes.White);
				SoundAlertBar = CurrentBars[0];
			}
			#endregion


line=3105;//PrintIt(line);
#if ENABLE_TRYCATCH_OBU
}catch(Exception obuerr){
	ErrorCount++;
	if(ErrorCount<9995){
		Print(string.Format("  {0}: OnBarUpdate {1}",line,obuerr.ToString()));
		Log  (string.Format("  {0}: OnBarUpdate {1}",line,obuerr.ToString()), NinjaTrader.Cbi.LogLevel.Information);
	}
}
#endif
	        #endregion
        }
//==========================================================================================================
        #region --------- OnMarketDepth() ------------
        protected override void OnMarketDepth(MarketDepthEventArgs e)
        {
//			if(ChartControl==null) return;
//if(IsDebug)Print(string.Format("{0}  {1}",e.Time.ToString(),"  OMDepth"));
			if(DataStartTime!=DateTime.MinValue && e.Time<DataStartTime) return;
//			else if(Data1StartBar>0 && CurrentBars[1]<Data1StartBar) return;

//Print("iInventoryEnabled: "+iInventoryEnabled.ToString()+"  !FirstOnMarketDepthRun:" + (!FirstOnMarketDepthRun).ToString());
            if ((iInventoryEnabled || !FirstOnMarketDepthRun) && e.Instrument.MarketDepth!=null && e.Instrument.MarketDepth.Bids!=null)
            {
				#region -- Inventory --
                askRows.Clear();
                bidRows.Clear();
//				MarketDepthRow mdra;

				int imax = 0;
				if(e.Instrument.MarketDepth.Asks!=null){
					var a = e.Instrument.MarketDepth.Asks.ToArray();
	                imax = Math.Min(10, e.Instrument.MarketDepth.Asks.Count);
	                for (int i = 0; i < imax; i++)
	                {
//	                    try
	                    {
//	                        mdra = a[i];
	                        askRows.Add(new LadderRow(a[i].Price, a[i].Volume, e.MarketMaker));
	                    }
//	                    catch (Exception e1) {
//							if(IsRodneyJ) Log(string.Format("{0}: {1}",line,e1.ToString()), NinjaTrader.Cbi.LogLevel.Information);
//							else Print(line+": "+e1.ToString());
//						}//#BUG002 : due to multithreading, Asks.count can change during the loop and be less than imax, causing exception
	                }
				}

				if(e.Instrument.MarketDepth.Bids!=null){
					var b = e.Instrument.MarketDepth.Bids.ToArray();
	                imax = Math.Min(10, b.Length);
	                for (int i = 0; i < imax; i++)
	                {
//	                    try
	                    {
//	                        mdra = b[i];
	                        bidRows.Add(new LadderRow(b[i].Price, b[i].Volume, e.MarketMaker));
	                    }
//	                    catch (Exception e2) {
//							if(IsRodneyJ) Log(string.Format("{0}: {1}",line,e2.ToString()), NinjaTrader.Cbi.LogLevel.Information);
//							else Print(line+": "+e2.ToString());
//						}//#BUG002 : due to multithreading, Bids.count can change during the loop and be less than imax, causing exception
	                }
				}
//Print("askRows: "+askRows.Count+"  bidRows: "+bidRows.Count);
                if (!FirstOnMarketDepthRun)
                {
                    FirstOnMarketDepthRun = true;
                    ForceRefresh();
                }
				#endregion
            }
        }
        #endregion
private void Pit(int i){if(IsDebug)Print("Line: "+i);}

//		private double PriceOfTableTop = 0;
//		public override void OnCalculateMinMax()
//		{
////Print("OnCalcMinMax PriceOfTableTop: "+PriceOfTableTop);
//			if(!this.pShow_Table)
//			{
//				base.OnCalculateMinMax();
//				return;
//			}
//			double LL = double.MaxValue;
//			double HH = double.MinValue;

//			for (int index = ChartBars.FromIndex; index <= ChartBars.ToIndex; index++)
//			{
//				LL = Math.Min(LL, Lows[0].GetValueAt(index));
//				HH = Math.Max(HH, Highs[0].GetValueAt(index));
//			}
//			MinValue = RTTS(LL < PriceOfTableTop ? PriceOfTableTop : LL);// - 5 * TickSize;
//			MaxValue = RTTS(HH);// + 5 * TickSize;
//Print("OnCalcMinMax MinPrice "+MinValue);
//		}
//==========================================================================================================
		private SharpDX.Direct2D1.Brush DXBrushes_Red, DXBrushes_White, DXBrushes_DimGray, BidHistoBrushDX, AskHistoBrushDX;
		private SortedDictionary<string, SharpDX.Direct2D1.Brush> TableTxtBrushDX = new SortedDictionary<string, SharpDX.Direct2D1.Brush>();
		private SortedDictionary<string, SharpDX.Direct2D1.Brush> TableFillBrushDX = new SortedDictionary<string, SharpDX.Direct2D1.Brush>();
		SharpDX.Direct2D1.Brush NegTableValueBrushDX = null;
		SharpDX.Direct2D1.Brush PosTableValueBrushDX = null;
		SharpDX.Direct2D1.Brush UnfinishedBizLineBrushDX = null;
		public override void OnRenderTargetChanged()
		{
			#region -- OnRenderTargetChanged --
line=3173;//Pit(line);
			#region -- Brush disposal --
			if(DXBrushes_Red     !=null && !DXBrushes_Red.IsDisposed)     DXBrushes_Red.Dispose();     DXBrushes_Red   = null;
			if(DXBrushes_White   !=null && !DXBrushes_White.IsDisposed)   DXBrushes_White.Dispose();   DXBrushes_White   = null;
			if(DXBrushes_DimGray !=null && !DXBrushes_DimGray.IsDisposed) DXBrushes_DimGray.Dispose(); DXBrushes_DimGray = null;
			if(DXBrushes_Black      !=null && !DXBrushes_Black.IsDisposed) 	    DXBrushes_Black.Dispose();      DXBrushes_Black = null;
			if(DXBrushes_LightGreen !=null && !DXBrushes_LightGreen.IsDisposed) DXBrushes_LightGreen.Dispose(); DXBrushes_LightGreen = null;
			if(DXBrushes_LightGray  !=null&& !DXBrushes_LightGray.IsDisposed) 	DXBrushes_LightGray.Dispose();  DXBrushes_LightGray = null;

			var keys = TableTxtBrushDX.Keys.ToList();
			foreach(var b in keys){
				if(TableTxtBrushDX[b]!=null && !TableTxtBrushDX[b].IsDisposed) TableTxtBrushDX[b].Dispose(); TableTxtBrushDX[b] = null;
				if(TableFillBrushDX[b]!=null && !TableFillBrushDX[b].IsDisposed) TableFillBrushDX[b].Dispose(); TableFillBrushDX[b] = null;
			}
			if(UnfinishedBizLineBrushDX  !=null&& !UnfinishedBizLineBrushDX.IsDisposed) 	UnfinishedBizLineBrushDX.Dispose();  UnfinishedBizLineBrushDX = null;
			if(BidHistoBrushDX  !=null && !BidHistoBrushDX.IsDisposed) BidHistoBrushDX.Dispose();   BidHistoBrushDX = null;
			if(AskHistoBrushDX  !=null && !AskHistoBrushDX.IsDisposed) AskHistoBrushDX.Dispose();   AskHistoBrushDX = null;

			if(iArrowUpDXBrush  !=null && !iArrowUpDXBrush.IsDisposed)  iArrowUpDXBrush.Dispose();  iArrowUpDXBrush  = null;
line=3176;//Pit(line);
			if(iArrowDnDXBrush  !=null && !iArrowDnDXBrush.IsDisposed)  iArrowDnDXBrush.Dispose();  iArrowDnDXBrush  = null;
			if(iArrowUpODXBrush !=null && !iArrowUpODXBrush.IsDisposed) iArrowUpODXBrush.Dispose(); iArrowUpODXBrush = null;
			if(iArrowDnODXBrush !=null && !iArrowDnODXBrush.IsDisposed) iArrowDnODXBrush.Dispose(); iArrowDnODXBrush = null;
			if(iSupplyZDXBrushFresh!=null && !iSupplyZDXBrushFresh.IsDisposed) 	iSupplyZDXBrushFresh.Dispose(); iSupplyZDXBrushFresh = null;
			if(iSupplyZDXBrushTested!=null && !iSupplyZDXBrushTested.IsDisposed) 	iSupplyZDXBrushTested.Dispose(); iSupplyZDXBrushTested = null;
			if(iSupplyZDXBrushBroken!=null && !iSupplyZDXBrushBroken.IsDisposed) 	iSupplyZDXBrushBroken.Dispose(); iSupplyZDXBrushBroken = null;
			if(iSupplyZOLDXBrushFresh!=null && !iSupplyZOLDXBrushFresh.IsDisposed) 	iSupplyZOLDXBrushFresh.Dispose(); iSupplyZOLDXBrushFresh = null;
			if(iSupplyZOLDXBrushTested!=null && !iSupplyZOLDXBrushTested.IsDisposed) 	iSupplyZOLDXBrushTested.Dispose(); iSupplyZOLDXBrushTested = null;
			if(iSupplyZOLDXBrushBroken!=null && !iSupplyZOLDXBrushBroken.IsDisposed) 	iSupplyZOLDXBrushBroken.Dispose(); iSupplyZOLDXBrushBroken = null;
			if(iDemandZDXBrushFresh!=null && !iDemandZDXBrushFresh.IsDisposed) 	iDemandZDXBrushFresh.Dispose(); iDemandZDXBrushFresh = null;
			if(iDemandZDXBrushTested!=null && !iDemandZDXBrushTested.IsDisposed) 	iDemandZDXBrushTested.Dispose(); iDemandZDXBrushTested = null;
			if(iDemandZDXBrushBroken!=null && !iDemandZDXBrushBroken.IsDisposed) 	iDemandZDXBrushBroken.Dispose(); iDemandZDXBrushBroken = null;
			if(iDemandZOLDXBrushFresh!=null && !iDemandZOLDXBrushFresh.IsDisposed) 	iDemandZOLDXBrushFresh.Dispose(); iDemandZOLDXBrushFresh = null;
			if(iDemandZOLDXBrushTested!=null && !iDemandZOLDXBrushTested.IsDisposed) 	iDemandZOLDXBrushTested.Dispose(); iDemandZOLDXBrushTested = null;
			if(iDemandZOLDXBrushBroken!=null && !iDemandZOLDXBrushBroken.IsDisposed) 	iDemandZOLDXBrushBroken.Dispose(); iDemandZOLDXBrushBroken = null;
			if(iBidHistDXBrush1!=null && !iBidHistDXBrush1.IsDisposed) 	iBidHistDXBrush1.Dispose(); iBidHistDXBrush1 = null;
			if(iBidHistDXBrush2!=null && !iBidHistDXBrush2.IsDisposed) 	iBidHistDXBrush2.Dispose(); iBidHistDXBrush2 = null;
			if(iAskHistDXBrush1!=null && !iAskHistDXBrush1.IsDisposed) 	iAskHistDXBrush1.Dispose(); iAskHistDXBrush1 = null;
			if(iAskHistDXBrush2!=null && !iAskHistDXBrush2.IsDisposed) 	iAskHistDXBrush2.Dispose(); iAskHistDXBrush2 = null;
			if(iAskOutDXBrush1!=null && !iAskOutDXBrush1.IsDisposed) 	iAskOutDXBrush1.Dispose(); iAskOutDXBrush1 = null;
			if(iBidOutDXBrush1!=null && !iBidOutDXBrush1.IsDisposed) 	iBidOutDXBrush1.Dispose(); iBidOutDXBrush1 = null;
			if(iTxtBrushDX_BidAskVol!=null && !iTxtBrushDX_BidAskVol.IsDisposed) 	iTxtBrushDX_BidAskVol.Dispose(); iTxtBrushDX_BidAskVol = null;
			if(iTxtBrushDX_AskImbalance!=null && !iTxtBrushDX_AskImbalance.IsDisposed) 	iTxtBrushDX_AskImbalance.Dispose(); iTxtBrushDX_AskImbalance = null;
			if(iTxtBrushDX_BidImbalance!=null && !iTxtBrushDX_BidImbalance.IsDisposed) 	iTxtBrushDX_BidImbalance.Dispose(); iTxtBrushDX_BidImbalance = null;
			if(iTxtBrushDX_SmallBidAskVol!=null && !iTxtBrushDX_SmallBidAskVol.IsDisposed) 	iTxtBrushDX_SmallBidAskVol.Dispose(); iTxtBrushDX_BidAskVol = null;
			if(iTxtBrushDX_SmallAskImbalance!=null && !iTxtBrushDX_SmallAskImbalance.IsDisposed) 	iTxtBrushDX_SmallAskImbalance.Dispose(); iTxtBrushDX_SmallAskImbalance = null;
			if(iTxtBrushDX_SmallBidImbalance!=null && !iTxtBrushDX_SmallBidImbalance.IsDisposed) 	iTxtBrushDX_SmallBidImbalance.Dispose(); iTxtBrushDX_SmallBidImbalance = null;
//			if(TextBrushDX!=null && !TextBrushDX.IsDisposed) 	TextBrushDX.Dispose(); TextBrushDX = null;
			if(iTM_DXBrush!=null && !iTM_DXBrush.IsDisposed) iTM_DXBrush.Dispose(); iTM_DXBrush = null;
			if(PenMDXBrush!=null && !PenMDXBrush.IsDisposed) PenMDXBrush.Dispose();  PenMDXBrush=null;
			if(BrushMDXBrush!=null && !BrushMDXBrush.IsDisposed) {BrushMDXBrush.Dispose(); BrushMDXBrush=null;}
			if(HistogramDXBrush !=null  && !HistogramDXBrush.IsDisposed)  { HistogramDXBrush.Dispose();  HistogramDXBrush = null;}
			if(HistogramDXBrush2 !=null && !HistogramDXBrush2.IsDisposed) {	HistogramDXBrush2.Dispose(); HistogramDXBrush2 = null;}
			if(BigMoneyBidRectangleFillDXBrush !=null && !BigMoneyBidRectangleFillDXBrush.IsDisposed) {	BigMoneyBidRectangleFillDXBrush.Dispose(); BigMoneyBidRectangleFillDXBrush = null;}
			if(BigMoneyAskRectangleFillDXBrush !=null && !BigMoneyAskRectangleFillDXBrush.IsDisposed) {	BigMoneyAskRectangleFillDXBrush.Dispose(); BigMoneyAskRectangleFillDXBrush = null;}
			//if(UnfinishedBizDotDXBrush !=null && !UnfinishedBizDotDXBrush.IsDisposed) {	UnfinishedBizDotDXBrush.Dispose(); UnfinishedBizDotDXBrush = null;}
//			if( !=null && !.IsDisposed) {	.Dispose();  = null;}
			if(iVCRArrowUpDXBrush !=null && !iVCRArrowUpDXBrush.IsDisposed) {	iVCRArrowUpDXBrush.Dispose(); iVCRArrowUpDXBrush = null;}
			if(iVCRArrowDnDXBrush !=null && !iVCRArrowDnDXBrush.IsDisposed) {	iVCRArrowDnDXBrush.Dispose(); iVCRArrowDnDXBrush = null;}
			
line=3213;//Pit(line);
			for(int brptr = 0; brptr<NetDHeatMap_DXBrushes.Length; brptr++){
				if(NetDHeatMap_DXBrushes[brptr] != null && !NetDHeatMap_DXBrushes[brptr].IsDisposed){
					NetDHeatMap_DXBrushes[brptr].Dispose();
					NetDHeatMap_DXBrushes[brptr] = null;
				}
			}
line=3220;//Pit(line);
			if(iBlocksDXBrush!=null && !iBlocksDXBrush.IsDisposed) 	iBlocksDXBrush.Dispose(); iBlocksDXBrush = null;
line=3222;//Pit(line);
			if(iBlocks2DXBrush!=null && !iBlocks2DXBrush.IsDisposed) 	iBlocks2DXBrush.Dispose(); iBlocks2DXBrush = null;
			if(iIBBidDXBrush3!=null && !iIBBidDXBrush3.IsDisposed) 	iIBBidDXBrush3.Dispose(); iIBBidDXBrush3 = null;
			if(iIBAskDXBrush3!=null && !iIBAskDXBrush3.IsDisposed) 	iIBAskDXBrush3.Dispose(); iIBAskDXBrush3 = null;
			if(OverrideBrush!=null && !OverrideBrush.IsDisposed) 	OverrideBrush.Dispose(); OverrideBrush = null;
			if(iDPDXBrush!=null && !iDPDXBrush.IsDisposed) 	iDPDXBrush.Dispose(); iDPDXBrush = null;
			if(iDNDXBrush!=null && !iDNDXBrush.IsDisposed) 	iDNDXBrush.Dispose();  iDNDXBrush = null;
line=3229;//Pit(line);
			if(ZoneHDXBrush!=null && !ZoneHDXBrush.IsDisposed) 	ZoneHDXBrush.Dispose(); ZoneHDXBrush = null;
			if(ButtonDXBrush!=null && !ButtonDXBrush.IsDisposed) 	ButtonDXBrush.Dispose(); ButtonDXBrush = null;
			if(ButtonPenDXBrush!=null && !ButtonPenDXBrush.IsDisposed) 	ButtonPenDXBrush.Dispose(); ButtonPenDXBrush = null;
			if(ButtonTextDXBrush!=null && !ButtonTextDXBrush.IsDisposed) 	ButtonTextDXBrush.Dispose(); ButtonTextDXBrush = null;
			if(DXBrushM2!=null && !DXBrushM2.IsDisposed) 	DXBrushM2.Dispose(); DXBrushM2 = null;
			if(PenM2DXBrush!=null && !PenM2DXBrush.IsDisposed) 	PenM2DXBrush.Dispose(); PenM2DXBrush = null;
			if(AxisDXBrush!=null && !AxisDXBrush.IsDisposed) 	AxisDXBrush.Dispose(); AxisDXBrush = null;

line=3241;//Pit(line);
			if(iCPHistogramVWAPDXBrush!=null    && !iCPHistogramVWAPDXBrush.IsDisposed) iCPHistogramVWAPDXBrush.Dispose(); iCPHistogramVWAPDXBrush = null;
			if(iCPHistogramPOCDXBrush!=null     && !iCPHistogramPOCDXBrush.IsDisposed)  iCPHistogramPOCDXBrush.Dispose(); iCPHistogramPOCDXBrush = null;
			if(iCPHistogramVAHDXBrush!=null     && !iCPHistogramVAHDXBrush.IsDisposed)  iCPHistogramVAHDXBrush.Dispose(); iCPHistogramVAHDXBrush = null;
			if(iCPHistogramVALDXBrush!=null     && !iCPHistogramVALDXBrush.IsDisposed)  iCPHistogramVALDXBrush.Dispose(); iCPHistogramVALDXBrush = null;
			if(iCPHistogramVAH2DXBrush!=null    && !iCPHistogramVAH2DXBrush.IsDisposed) iCPHistogramVAH2DXBrush.Dispose(); iCPHistogramVAH2DXBrush = null;
			if(iCPHistogramVAL2DXBrush!=null    && !iCPHistogramVAL2DXBrush.IsDisposed) iCPHistogramVAL2DXBrush.Dispose(); iCPHistogramVAL2DXBrush = null;
			if(iCPHistogramVADXBrush!=null      && !iCPHistogramVADXBrush.IsDisposed)   iCPHistogramVADXBrush.Dispose();   iCPHistogramVADXBrush = null;
			if(iCPHistogramMDXBrush!=null       && !iCPHistogramMDXBrush.IsDisposed)       iCPHistogramMDXBrush.Dispose();    iCPHistogramMDXBrush  = null;
			if(iCPHistogramClusterDXBrush!=null && !iCPHistogramClusterDXBrush.IsDisposed) iCPHistogramClusterDXBrush.Dispose(); iCPHistogramClusterDXBrush = null;

line=3252;//Pit(line);
			if(iVA1Line_DXBrush!=null && !iVA1Line_DXBrush.IsDisposed) iVA1Line_DXBrush.Dispose(); iVA1Line_DXBrush=null;
			if(iVA1_fillDXBrush!=null && !iVA1_fillDXBrush.IsDisposed) iVA1_fillDXBrush.Dispose(); iVA1_fillDXBrush=null;
			if(iVA2_fillDXBrush!=null && !iVA2_fillDXBrush.IsDisposed) iVA2_fillDXBrush.Dispose(); iVA2_fillDXBrush=null;
			if(iVA2Line_DXBrush!=null && !iVA2Line_DXBrush.IsDisposed) iVA2Line_DXBrush.Dispose(); iVA2Line_DXBrush=null;
			if(RectangleDXBrush!=null && !RectangleDXBrush.IsDisposed) RectangleDXBrush.Dispose(); RectangleDXBrush=null;
			if(RectangleFillDXBrush!=null && !RectangleFillDXBrush.IsDisposed) RectangleFillDXBrush.Dispose(); RectangleFillDXBrush=null;

line=3260;//Pit(line);
			if(iMPHistogramVWAPDXBrush!=null && !iMPHistogramVWAPDXBrush.IsDisposed) iMPHistogramVWAPDXBrush.Dispose(); iMPHistogramVWAPDXBrush= null;
			if(iMPHistogramVADXBrush!=null && !iMPHistogramVADXBrush.IsDisposed)   iMPHistogramVADXBrush.Dispose();   iMPHistogramVADXBrush= null;
			if(iMPHistogramVAHDXBrush!=null && !iMPHistogramVAHDXBrush.IsDisposed)  iMPHistogramVAHDXBrush.Dispose();  iMPHistogramVAHDXBrush= null;
			if(iMPHistogramVALDXBrush!=null && !iMPHistogramVALDXBrush.IsDisposed)  iMPHistogramVALDXBrush.Dispose();  iMPHistogramVALDXBrush= null;
			if(iMPHistogramPOCDXBrush!=null && !iMPHistogramPOCDXBrush.IsDisposed)  iMPHistogramPOCDXBrush.Dispose();  iMPHistogramPOCDXBrush= null;
			if(iMPHistoPOCContrastDXBrush!=null && !iMPHistoPOCContrastDXBrush.IsDisposed)  iMPHistoPOCContrastDXBrush.Dispose();  iMPHistoPOCContrastDXBrush= null;
			if(iMPHistoVWAPContrastDXBrush!=null && !iMPHistoVWAPContrastDXBrush.IsDisposed)  iMPHistoVWAPContrastDXBrush.Dispose();  iMPHistoVWAPContrastDXBrush= null;
			if(iMPHistoVAHContrastDXBrush!=null && !iMPHistoVAHContrastDXBrush.IsDisposed)  iMPHistoVAHContrastDXBrush.Dispose();  iMPHistoVAHContrastDXBrush= null;
			if(iMPHistoVALContrastDXBrush!=null && !iMPHistoVALContrastDXBrush.IsDisposed)  iMPHistoVALContrastDXBrush.Dispose();  iMPHistoVALContrastDXBrush= null;

			if(iMPHistogramMDXBrush!=null && !iMPHistogramMDXBrush.IsDisposed)    iMPHistogramMDXBrush.Dispose();    iMPHistogramMDXBrush= null;
			if(iMPHistogramClusterDXBrush!=null && !iMPHistogramClusterDXBrush.IsDisposed) iMPHistogramClusterDXBrush.Dispose(); iMPHistogramClusterDXBrush= null;
//			if(HistogramDXBrush2!=null && !HistogramDXBrush2.IsDisposed){  HistogramDXBrush2.Dispose();  HistogramDXBrush2 = null;}
			if(ChartBackgroundBrushDX!=null && !ChartBackgroundBrushDX.IsDisposed) ChartBackgroundBrushDX.Dispose(); ChartBackgroundBrushDX=null;

			if(iBarProfilePOCDXBrush!=null       && !iBarProfilePOCDXBrush.IsDisposed)       iBarProfilePOCDXBrush.Dispose();    iBarProfilePOCDXBrush=null;
			if(iBarProfileVAHDXBrush!=null       && !iBarProfileVAHDXBrush.IsDisposed)       iBarProfileVAHDXBrush.Dispose();    iBarProfileVAHDXBrush=null;
			if(iBarProfileVALDXBrush!=null       && !iBarProfileVALDXBrush.IsDisposed)       iBarProfileVALDXBrush.Dispose();    iBarProfileVALDXBrush=null;
			if(iBarProfileVADXBrush!=null        && !iBarProfileVADXBrush.IsDisposed)        iBarProfileVADXBrush.Dispose();     iBarProfileVADXBrush=null;
			if(iBarProfileVWAPDXBrush!=null      && !iBarProfileVWAPDXBrush.IsDisposed)      iBarProfileVWAPDXBrush.Dispose();   iBarProfileVWAPDXBrush=null;
			if(iBarProfileClusterDXBrush!=null   && !iBarProfileClusterDXBrush.IsDisposed)   iBarProfileClusterDXBrush.Dispose(); iBarProfileClusterDXBrush=null;
			if(iMPHistogramClusterDXBrush2!=null && !iMPHistogramClusterDXBrush2.IsDisposed) iMPHistogramClusterDXBrush2.Dispose(); iMPHistogramClusterDXBrush2=null;

line=3284;//Pit(line);
			if(iVAFillDXBrush!=null){ iVAFillDXBrush.Dispose(); iVAFillDXBrush = null;}
			if(iEXFillDXBrush!=null){ iEXFillDXBrush.Dispose(); iEXFillDXBrush = null;}
			#endregion

			if(RenderTarget!=null){
line=3290;//Pit(line);
				DXBrushes_Red = Brushes.Red.ToDxBrush(RenderTarget);
				DXBrushes_White   = Brushes.White.ToDxBrush(RenderTarget);
				DXBrushes_DimGray = Brushes.DimGray.ToDxBrush(RenderTarget);
				DXBrushes_Black = Brushes.Black.ToDxBrush(RenderTarget);
				DXBrushes_LightGreen = Brushes.LightGreen.ToDxBrush(RenderTarget);
				DXBrushes_LightGray  = Brushes.LightGray.ToDxBrush(RenderTarget);
				TableTxtBrushDX["LabelColumn"] = pTableTxt_LabelColumn_Brush.ToDxBrush(RenderTarget);
				TableTxtBrushDX["Signal+"]     = pTableTxt_SignalUp_Brush.ToDxBrush(RenderTarget);
				TableTxtBrushDX["Signal-"]     = pTableTxt_SignalDown_Brush.ToDxBrush(RenderTarget);
				TableTxtBrushDX["Delta+"]      = pTableTxt_DeltaPos_Brush.ToDxBrush(RenderTarget);
				TableTxtBrushDX["Delta-"]      = pTableTxt_DeltaNeg_Brush.ToDxBrush(RenderTarget);
				TableTxtBrushDX["Cum Delta+"]  = pTableTxt_CumDeltaPos_Brush.ToDxBrush(RenderTarget);
				TableTxtBrushDX["Cum Delta-"]  = pTableTxt_CumDeltaNeg_Brush.ToDxBrush(RenderTarget);
				TableTxtBrushDX["Volume"]      = pTableTxt_Volume_Brush.ToDxBrush(RenderTarget);
				TableTxtBrushDX["Bid Vol"]     = pTableTxt_BidVol_Brush.ToDxBrush(RenderTarget);
				TableTxtBrushDX["Ask Vol"]     = pTableTxt_AskVol_Brush.ToDxBrush(RenderTarget);
				TableFillBrushDX["LabelColumn"]   = pTableFill_LabelColumn_Brush.ToDxBrush(RenderTarget);
				TableFillBrushDX["Signal+"]       = pTableFill_SignalUp_Brush.ToDxBrush(RenderTarget);
				TableFillBrushDX["Signal-"]       = pTableFill_SignalDown_Brush.ToDxBrush(RenderTarget);
				TableFillBrushDX["Delta+"]        = pTableFill_DeltaPos_Brush.ToDxBrush(RenderTarget);
				TableFillBrushDX["Delta-"]        = pTableFill_DeltaNeg_Brush.ToDxBrush(RenderTarget);
				TableFillBrushDX["Cum Delta+"]    = pTableFill_CumDeltaPos_Brush.ToDxBrush(RenderTarget);
				TableFillBrushDX["Cum Delta-"]    = pTableFill_CumDeltaNeg_Brush.ToDxBrush(RenderTarget);
				TableFillBrushDX["Volume"]        = pTableFill_Volume_Brush.ToDxBrush(RenderTarget);
				TableFillBrushDX["Bid Vol"]       = pTableFill_BidVol_Brush.ToDxBrush(RenderTarget);
				TableFillBrushDX["Ask Vol"]       = pTableFill_AskVol_Brush.ToDxBrush(RenderTarget);
				UnfinishedBizLineBrushDX = pUnfinishedBizStrokeStyle.Brush.ToDxBrush(RenderTarget);  UnfinishedBizLineBrushDX.Opacity = pUnfinishedBizStrokeStyle.Opacity/100f;

				BidHistoBrushDX = pBidHistoBrush.ToDxBrush(RenderTarget); BidHistoBrushDX.Opacity = pBidAskHistoOpacity/100f;
				AskHistoBrushDX = pAskHistoBrush.ToDxBrush(RenderTarget); AskHistoBrushDX.Opacity = pBidAskHistoOpacity/100f;

				iArrowUpDXBrush  = iArrowUpColor.ToDxBrush(RenderTarget);  iArrowUpDXBrush.Opacity=iArrowShade/100f;
				iArrowDnDXBrush  = iArrowDnColor.ToDxBrush(RenderTarget);  iArrowDnDXBrush.Opacity=iArrowShade/100f;
				iArrowUpODXBrush = iArrowUpOColor.ToDxBrush(RenderTarget); iArrowUpODXBrush.Opacity=iArrowShade/100f;
				iArrowDnODXBrush = iArrowDnOColor.ToDxBrush(RenderTarget); iArrowDnODXBrush.Opacity=iArrowShade/100f;
				iVCRArrowUpDXBrush = iArrowUpColorVCR.ToDxBrush(RenderTarget);
				iVCRArrowDnDXBrush = iArrowDnColorVCR.ToDxBrush(RenderTarget);
				#region -- initialize brushes --
				iSupplyZDXBrushFresh = iSupplyZColorFresh.ToDxBrush(RenderTarget);
			    iSupplyZDXBrushFresh.Opacity = iSupplyZOpacityFresh / 100f;
				iSupplyZDXBrushTested = iSupplyZColorTested.ToDxBrush(RenderTarget);
			    iSupplyZDXBrushTested.Opacity = iSupplyZOpacityTested / 100f;
				iSupplyZDXBrushBroken = iSupplyZColorBroken.ToDxBrush(RenderTarget);
			    iSupplyZDXBrushBroken.Opacity = iSupplyZOpacityBroken / 100f;
				iSupplyZOLDXBrushFresh = iSupplyZOLColorFresh.ToDxBrush(RenderTarget);
				iSupplyZOLDXBrushTested = iSupplyZOLColorTested.ToDxBrush(RenderTarget);
				iSupplyZOLDXBrushBroken = iSupplyZOLColorBroken.ToDxBrush(RenderTarget);

				iDemandZDXBrushFresh = iDemandZColorFresh.ToDxBrush(RenderTarget);
			    iDemandZDXBrushFresh.Opacity = iDemandZOpacityFresh / 100f;
				iDemandZDXBrushTested = iDemandZColorTested.ToDxBrush(RenderTarget);
			    iDemandZDXBrushTested.Opacity = iDemandZOpacityTested / 100f;
				iDemandZDXBrushBroken = iDemandZColorBroken.ToDxBrush(RenderTarget);
			    iDemandZDXBrushBroken.Opacity = iDemandZOpacityBroken / 100f;
				iDemandZOLDXBrushFresh  = iDemandZOLColorFresh.ToDxBrush(RenderTarget);
				iDemandZOLDXBrushTested = iDemandZOLColorTested.ToDxBrush(RenderTarget);
				iDemandZOLDXBrushBroken = iDemandZOLColorBroken.ToDxBrush(RenderTarget);

line=3318;//Pit(line);
				if(ChartControl != null)
				{
					AxisDXBrush = ChartControl.Properties.AxisPen.Brush.ToDxBrush(RenderTarget);
					ChartBackgroundBrushDX = ChartControl.Properties.ChartBackground.ToDxBrush(RenderTarget);
				}
				ZoneHDXBrush = ZoneH.Brush.ToDxBrush(RenderTarget);
				ButtonDXBrush = ButtonBrush.ToDxBrush(RenderTarget);
				ButtonPenDXBrush = ButtonPen.Brush.ToDxBrush(RenderTarget);
				ButtonTextDXBrush = ButtonTextBrush.ToDxBrush(RenderTarget);

				int RectangleLineWidth = 1;

				iBlocksDXBrush  = iBlocksColor.ToDxBrush(RenderTarget); iBlocksDXBrush.Opacity=iBlocksO/100f;
				iBlocks2DXBrush = iBlocks2Color.ToDxBrush(RenderTarget); iBlocks2DXBrush.Opacity=iBlocksO/100f;

				OverrideBrush  = iBlocks2DXBrush;//iMPBarOpacity 
//				iIBBidDXBrush  = iIBBidColor.ToDxBrush(RenderTarget);
				iIBBidDXBrush3 = iIBBidColor3.ToDxBrush(RenderTarget);  iIBBidDXBrush3.Opacity = iOpacityDn3/100f;
//				iIBAskDXBrush  = iIBAskColor.ToDxBrush(RenderTarget);
				iIBAskDXBrush3 = iIBAskColor3.ToDxBrush(RenderTarget);  iIBAskDXBrush3.Opacity = iOpacityUp3/100f;
				PenMDXBrush    = Brushes.Black.ToDxBrush(RenderTarget);

				DXBrushM2 = Brushes.Gray.ToDxBrush(RenderTarget);
				PenM2DXBrush = Brushes.Black.ToDxBrush(RenderTarget);
				iTM_DXBrush = iTMColor.ToDxBrush(RenderTarget); iTM_DXBrush.Opacity = iTMOpacity/100f;
				for(int brptr = 0; brptr<NetDHeatMap_DXBrushes.Length; brptr++)
					NetDHeatMap_DXBrushes[brptr] = NetDHeatMap_Brushes[brptr].ToDxBrush(RenderTarget);

line=3350;//Pit(line);
				iAskHistDXBrush2 = iAskHistColor2.ToDxBrush(RenderTarget); iAskHistDXBrush2.Opacity=iSwingOpacity/100f;
				iAskHistDXBrush1 = iAskHistColor1.ToDxBrush(RenderTarget); iAskHistDXBrush1.Opacity=iSwingOpacity/100f;

				iBidHistDXBrush2 = iBidHistColor2.ToDxBrush(RenderTarget); iBidHistDXBrush2.Opacity=iSwingOpacity2/100f;
				iBidHistDXBrush1 = iBidHistColor1.ToDxBrush(RenderTarget); iBidHistDXBrush1.Opacity=iSwingOpacity2/100f;

				iAskOutDXBrush1 = iAskOutColor1.ToDxBrush(RenderTarget);
				iBidOutDXBrush1 = iBidOutColor1.ToDxBrush(RenderTarget);

				iTxtBrushDX_BidAskVol    = iTxtBrush_BidAskVol.ToDxBrush(RenderTarget);
				iTxtBrushDX_AskImbalance = iTxtBrush_AskImbalance.ToDxBrush(RenderTarget);
				iTxtBrushDX_BidImbalance = iTxtBrush_BidImbalance.ToDxBrush(RenderTarget);
				iTxtBrushDX_SmallBidAskVol    = iTxtBrush_BidAskVol.ToDxBrush(RenderTarget);
				iTxtBrushDX_SmallBidAskVol.Opacity = pSmallVolumeTextOpacity/100f;
				iTxtBrushDX_SmallAskImbalance      = iTxtBrush_AskImbalance.ToDxBrush(RenderTarget);
				iTxtBrushDX_SmallAskImbalance.Opacity = pSmallVolumeTextOpacity/100f;
				iTxtBrushDX_SmallBidImbalance         = iTxtBrush_BidImbalance.ToDxBrush(RenderTarget);
				iTxtBrushDX_SmallBidImbalance.Opacity = pSmallVolumeTextOpacity/100f;

				iDPDXBrush = iDPColor.ToDxBrush(RenderTarget);
				iDNDXBrush = iDNColor.ToDxBrush(RenderTarget);

				iVA1Line_DXBrush = iVA1_Color.ToDxBrush(RenderTarget);
				iVA1_fillDXBrush = iVA1_FillColor.ToDxBrush(RenderTarget); iVA1_fillDXBrush.Opacity = iVA3Opacity/100f;
				iVA2Line_DXBrush = iVA2_Color.ToDxBrush(RenderTarget);
				iVA2_fillDXBrush = iVA2_FillColor.ToDxBrush(RenderTarget); iVA2_fillDXBrush.Opacity = iVAS3Opacity/100f;

line=3372;//Pit(line);
				iCPHistogramVWAPDXBrush = iCPHistogramVWAPColor.ToDxBrush(RenderTarget);
				iCPHistogramPOCDXBrush  = iCPHistogramPOCColor.ToDxBrush(RenderTarget);
				iCPHistogramVAHDXBrush  = iCPHistogramVAHColor.ToDxBrush(RenderTarget);
				iCPHistogramVALDXBrush  = iCPHistogramVALColor.ToDxBrush(RenderTarget);

				iCPHistogramVAH2DXBrush = iCPHistogramVAH2Color.ToDxBrush(RenderTarget);
				iCPHistogramVAL2DXBrush = iCPHistogramVAL2Color.ToDxBrush(RenderTarget);
				iCPHistogramVADXBrush   = iCPHistogramVAColor.ToDxBrush(RenderTarget); iCPHistogramVADXBrush.Opacity = iCPHistogramOpacity/100f;
				iCPHistogramMDXBrush    = iCPHistogramMColor.ToDxBrush(RenderTarget); iCPHistogramMDXBrush.Opacity = iCPHistogramOpacity/100f;
				iCPHistogramClusterDXBrush = iCPHistogramClusterColor.ToDxBrush(RenderTarget);
				RectangleDXBrush = iMPOutlineColor.ToDxBrush(RenderTarget);
       			RectangleFillDXBrush = iMPFillColor.ToDxBrush(RenderTarget); RectangleFillDXBrush.Opacity = iMPFillOpacity/100f;

line=3386;//Pit(line);
				iMPHistogramPOCDXBrush  = iMPHistogramPOCColor.ToDxBrush(RenderTarget);
				iMPHistogramVADXBrush   = iMPHistogramVAColor.ToDxBrush(RenderTarget);
				iMPHistogramVAHDXBrush  = iMPHistogramVAHColor.ToDxBrush(RenderTarget);
				iMPHistogramVALDXBrush  = iMPHistogramVALColor.ToDxBrush(RenderTarget);
				iMPHistogramVWAPDXBrush = iMPHistogramVWAPColor.ToDxBrush(RenderTarget);
				iMPHistoPOCContrastDXBrush = ContrastingColor((SolidColorBrush)iMPHistogramPOCColor).ToDxBrush(RenderTarget);
				iMPHistoVAHContrastDXBrush = ContrastingColor((SolidColorBrush)iMPHistogramVAHColor).ToDxBrush(RenderTarget);
				iMPHistoVALContrastDXBrush = ContrastingColor((SolidColorBrush)iMPHistogramVALColor).ToDxBrush(RenderTarget);
				iMPHistoVWAPContrastDXBrush = ContrastingColor((SolidColorBrush)iMPHistogramVWAPColor).ToDxBrush(RenderTarget);

				iMPHistogramMDXBrush = iMPHistogramMColor.ToDxBrush(RenderTarget); iMPHistogramMDXBrush.Opacity=iMPHistogramOpacity/100f;
				iMPHistogramClusterDXBrush = iMPHistogramClusterColor.ToDxBrush(RenderTarget); 
				iMPHistogramClusterDXBrush2 = iMPHistogramClusterColor2.ToDxBrush(RenderTarget);
				iMPHistogramClusterDXBrush2.Opacity = iMPBarOpacity2/100f;

				iVAFillDXBrush = iVAFillColor.ToDxBrush(RenderTarget); iVAFillDXBrush.Opacity = iFillAreaOpacity/100f;
				iEXFillDXBrush = iEXFillColor.ToDxBrush(RenderTarget); iEXFillDXBrush.Opacity = iFillAreaOpacity/100f;
//	            HistogramDXBrush = iMPHistogramMColor.ToDxBrush(RenderTarget);
//				HistogramDXBrush2 = iCPHistogramMColor.ToDxBrush(RenderTarget); HistogramDXBrush2.Opacity = iCPHistogramOpacity/100f;

				iBarProfilePOCDXBrush  = iMPBarPOCColor.ToDxBrush(RenderTarget);
				iBarProfileVAHDXBrush  = iMPBarVAHColor.ToDxBrush(RenderTarget);
				iBarProfileVALDXBrush  = iMPBarVALColor.ToDxBrush(RenderTarget);
				iBarProfileVADXBrush   = iMPBarVAColor.ToDxBrush(RenderTarget);
				iBarProfileVWAPDXBrush = iMPBarVWAPColor.ToDxBrush(RenderTarget);
				iBarProfileClusterDXBrush = iMPBarClusterColor.ToDxBrush(RenderTarget);
				BigMoneyAskRectangleFillDXBrush = pBigMoneyAskRectangleFillColor.ToDxBrush(RenderTarget);
				BigMoneyBidRectangleFillDXBrush = pBigMoneyBidRectangleFillColor.ToDxBrush(RenderTarget);
//				UnfinishedBizDotDXBrush = pUnfinishedBizFillColor.ToDxBrush(RenderTarget);
				#endregion
			}
line=3417;//Pit(line);
			#endregion
		}

        //private Stopwatch benchOR = new Stopwatch();
        private bool IsDebugchOnRenderDone = false;
		private double maxBigMoneyVolume = 0;
		private Dictionary<string, int> TableLocations = new Dictionary<string, int>();
		private class UnfinishedBizData{
			public double HighPrice=double.MinValue;
			public double LowPrice=double.MinValue;
			public int WasHighHitABar = 0;//when price returns to this Price, the line is "Hit" and stops printing at that bar
			public int WasLowHitABar = 0;//when price returns to this Price, the line is "Hit" and stops printing at that bar
			public UnfinishedBizData(double p, char HL){ 
				if(HL=='H')
					HighPrice = p;
				if(HL=='L')
					LowPrice = p;
			}
		}
		SortedDictionary<int, UnfinishedBizData> UnfinishedBizLocs = new SortedDictionary<int, UnfinishedBizData>();
		int fontheight = 0;
		int cellWidth = 0;
		int y = 0;
		int x = 0;
		int i = 0;
		int xRight = 0;
		int ColNumber = 0;
		int yTop = 0;
		int TableRows = 6;//Signal, Delta, CumDelta, Bid/Ask %, Delta%, Volume
		StringBuilder sb = new StringBuilder();
//==========================================================================================================
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
try{
line=3425;//Pit(line);
if(LaunchedAt!=DateTime.MinValue){
	//ClearOutputWindow();
	var tss = new TimeSpan(DateTime.Now.Ticks - LaunchedAt.Ticks);
	Print("Load time: "+tss.TotalMinutes.ToString("0.00")+"-minutes   Number of ticks in 1-tick datafeed: "+BarsArray[1].Count);
	LaunchedAt=DateTime.MinValue;
}
	        #region --------- OnRender() ------------
			bool EXECUTE = false;
			int abar = 0;
//try
{
				if(IsTickReplayWarningMsg!=string.Empty) drawstring(IsTickReplayWarningMsg, 10,100, new SimpleFont("Arial",20), DXBrushes_White, DXBrushes_Red, SharpDX.DirectWrite.TextAlignment.Leading);
//				Print(chartControl.BarWidth.ToString("0.00"));
                RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
				bool IsMinuteBar = iPCalcM != ARC_PrintProfiler_DataBasis.Tick1;

                gbChartScale = chartScale;

line=3514;
                #region -- conditions to return --
                if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot || chartControl == null) return;
                if (Bars == null || BarsArray[0].Count == 0 || BarsArray[BKG_DATA_ID].Count == 0)
                {
					string msg = string.Empty;
					if(BarsArray[0].Count==0) msg = "No bars on chart";
					if(BarsArray[BKG_DATA_ID].Count==0) {
						if(msg.Length>0) msg = msg+Environment.NewLine+"No bars in background timeframe";
						else msg = "No bars in background timeframe";
					}
					if(AxisDXBrush!=null) drawstring(string.Format("Data is missing...attempt to load more days of data, Repair DB, or restart NT{0}{1}",Environment.NewLine,msg), ChartPanel.X + 50, ChartPanel.Y + ChartPanel.H/2, new SimpleFont("Arial", 14), AxisDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
                    return;
                }
                if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
                #endregion
                SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
                RenderTarget.AntialiasMode          = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
				
				int ZoneHLineWidth = (int)ZoneH.Thickness;
				int RectangleLineWidth = 1;

				#region -- Preliminary Calculation --
				if(DataStartTime != DateTime.MinValue) DataStartBar = BarsArray[0].GetBar(this.DataStartTime);
                lastBarIndex = Math.Min(CurrentBars[0], ChartBars.ToIndex);//RIGHT BAR idx (slot)
                int firstBarIndex = Math.Max(0, ChartBars.FromIndex);//Math.Max(Math.Max(DataStartBar, BarsRequiredToPlot), Math.Max(2,ChartBars.FromIndex));// BarsRequiredToPlot;//FIRST LEFT BAR idx (slot)
                int RemainBars = Math.Max(firstBarIndex, ChartBars.ToIndex);

				//---------------
                if (lastBarIndex < 0 || firstBarIndex < 0 || CurrentBars[0] < 0) return;
                bool ISHardRight = lastBarIndex == CurrentBars[0];
                MouseBarIndex = CurrentBars[0] - (int)chartControl.GetSlotIndexByX(MM.X);
                if (Calculate != Calculate.OnBarClose) MouseBarIndex = MouseBarIndex - 1;

line=3523;
                double ActualTopPrice    = chartScale.MaxValue;
                double ActualBottomPrice = chartScale.MinValue;
                #region -- Fill PriceBoxes List --
                double PercentExpand = 20, MinTicksExpand = 50;
				//if(ActualTopPrice != PriorTopPrice || ActualBottomPrice != PriorBottomPrice)
                {
					PriorTopPrice      = ActualTopPrice;
					PriorBottomPrice   = ActualBottomPrice;
	                double TotalExpand = Math.Max(chartScale.MaxMinusMin * PercentExpand / 100, MinTicksExpand * gbTickSize);
    	            TopPrice      = RTTS(ActualTopPrice + TotalExpand);
        	        BottomPrice   = RTTS(ActualBottomPrice - TotalExpand);

line=3536;
	                PriceBoxes.Clear();
    	            AverageBoxHeight = 0;
        	        TotalBoxHeight   = 0;
            	    double currentPrice = BottomPrice;
                	while (currentPrice <= TopPrice)
	                {
	                    int yCPrice = chartScale.GetYByValue(currentPrice);
	                    int yCPm1 = chartScale.GetYByValue(currentPrice - gbTickSize);
	                    int height = Math.Max(minBarHeight, Math.Min(maxBarHeight, Math.Abs(yCPm1 - yCPrice) - pBoxSpace));
	                    int halfHeight = height / 2;

	                    if (!PriceBoxes.ContainsKey(currentPrice))
	                    {
	                        PriceBoxes[currentPrice] = new PriceBox();//##Modif by Kriss AzurITec## : BUGPP001 with CL [FIXED]. StartPrice always the same because never incremented due to NT BUG. See function RTTS for bug fix (line 12939). CRASHES HERE due to duplicate key
	                        PriceBoxes[currentPrice].Top = yCPrice - halfHeight;
	                        PriceBoxes[currentPrice].Bottom = yCPrice + halfHeight;
	                        PriceBoxes[currentPrice].Height = height;
	                    }
	                    TotalBoxHeight = TotalBoxHeight + height;
	                    currentPrice = RTTS(currentPrice + gbTickSize);//##Modif by Kriss AzurITec## : BUGPP001 with CL [FIXED]. No increment due to NT7 bug						
	                }
				}
line=3559;
                if (PriceBoxes.Count == 0) return;
                AverageBoxHeight = TotalBoxHeight / PriceBoxes.Count;
                #endregion

line=3564;
                #region -- Calculate Chart Variables (barwidth / bar margin right...) --
                int barWidth = chartControl.GetBarPaintWidth(ChartBars);
                //int PixelsBetweenBars = (int)(chartControl.Properties.BarDistance - chartControl.BarWidth);
                barWidth = Math.Max(barWidth, (int)(chartControl.Properties.BarDistance - iMaxBarSpacePixels)) / 2;

                diff = barWidth - (int)(chartControl.BarWidth / 2);
                FinalDesiredMargin = iRightSideMarginMin + diff;// adjust the right side margin based on this number. add it.
				int systemBarWidth = chartControl.GetBarPaintWidth(ChartBars);
                #endregion

line=3576;
				#region -- automatically Calculate Fontsize --
				//reset GeneralFont to user settings
				GeneralFont.FamilySerialize = iBarPrintFont.FamilySerialize;
				GeneralFont.Size = iBarPrintFont.Size;
				GeneralFont.Bold = iBarPrintFont.Bold;

				//Calulate Font size for print inside bars
line=3584;
				if(firstBarIndex!=fbi || lastBarIndex!=lbi){
					#region -- original (error prone) Calculate barprintFont --
//					fbi = firstBarIndex;
//					lbi = lastBarIndex;
////					var BarData_VisibleBars = BarDataCollection.Where(p => p.Key >= firstBarIndex - 1 && p.Key <= lastBarIndex).ToList();
//					var BarData_VisibleBars = BarDataCollection.Where(p => p.Key >= firstBarIndex - 1 && p.Key <= lastBarIndex && (p.Value!=null && p.Value.Count>0)).ToDictionary(entry => entry.Key, entry => entry.Value);
//					long maxV = 99;
////return;
//					if(BarData_VisibleBars !=null){
//							maxV = IsMinuteBar ? 99 : Math.Max(
//															BarData_VisibleBars.Max(p => p.Value.Max(x => x.Value.AskSize)), 
//															BarData_VisibleBars.Max(p => p.Value.Max(x => x.Value.BidSize)));//get max bid/ask value
//					}
//					barprintFont.Size = this.iBarPrintFont.Size;
//					barprintFont.Size = CalculateOptimalFontSize(barWidth - 1, maxV.ToString(), barprintFont);
					#endregion -------------------
					#region -- Calculate barprintFont --
					fbi = firstBarIndex;
					lbi = lastBarIndex;
//					var BarData_VisibleBars = BarDataCollection.Where(p => p.Key >= firstBarIndex - 1 && p.Key <= lastBarIndex).ToList();
//					var BarData_VisibleBars = BarDataCollection.Where(p => p.Key >= firstBarIndex - 1 && p.Key <= lastBarIndex && (p.Value!=null && p.Value.Count>0)).ToDictionary(entry => entry.Key, entry => entry.Value);
					double maxV = 99;
line=3607;////Print(line);
					if(!IsMinuteBar)
					{
						double maxAsk = -1;
						double maxBid = -1;
						var keys = BarDataTotals.Keys.ToList();
						foreach(var p in keys) {
line=3615;////Print(line);
							if(p >= firstBarIndex - 1 && p <= lastBarIndex) {
								maxAsk = Math.Max(maxAsk, BarDataTotals[p].MaxAsk);
								maxBid = Math.Max(maxBid, BarDataTotals[p].MaxBid);
							}
						}
line=3622;////Print(line);
						if(maxAsk>=0 && maxBid>=0){
							maxV = Math.Max(maxAsk, maxBid);
//													Math.Max(
//															BarData_VisibleBars.Max(p => p.Value.Max(x => x.Value.AskSize)), 
//															BarData_VisibleBars.Max(p => p.Value.Max(x => x.Value.BidSize)));//get max bid/ask value
						}
					}
line=3630;////Print(line);
					barprintFont.Size = this.iBarPrintFont.Size;
					barprintFont.Size = CalculateOptimalFontSize(barWidth - 1, maxV.ToString(), barprintFont);
					#endregion ----------------
				}
line=3635;
				//Calulate Font size for NetDelta
				var netDeltaFont = (SimpleFont)iNetDeltaFont.Clone();
				//var tmpBarDataTotals = BarDataTotals.ToList();
				//var tmpND = tmpBarDataTotals.Where(p => p.Key >= firstBarIndex - 1 && p.Key <= lastBarIndex);
				//long maxND = IsMinuteBar ? 99 : tmpND.Max(p => Math.Abs(p.Value.AskTotal + p.Value.BidTotal));//get max |netdelta| value
				//v1.12/ netDeltaFont.Size = CalculateOptimalFontSize(chartControl.Properties.BarDistance, maxND.ToString(), netDeltaFont);
				//bool drawNetDeltaText = true;//v1.12/ netDeltaFont.Size >= MINFONTSIZE + 2;

				//calculate vertical adjustment
line=3645;
				AdjustFontAmount = 0;
				int adjustpoint = 5;// increase number to make it more sensitive, higher the number quicker the numbers get smaller
				if (GeneralFont.Size - adjustpoint > AverageBoxHeight) AdjustFontAmount = (int)Math.Round((iBarPrintFont.Size - adjustpoint - AverageBoxHeight) / 2, 0);
                #endregion
line=3647;
                #endregion
				int yOfTableTop = ChartPanel.H;
//pShow_Table = true;
				#region -- Draw table --
				if(pShow_Table && RenderTarget!=null){
					if(TableTxtBrushDX["LabelColumn"]==null) TableTxtBrushDX["LabelColumn"] = pTableTxt_LabelColumn_Brush.ToDxBrush(RenderTarget);
					if(TableTxtBrushDX["Signal+"]==null)     TableTxtBrushDX["Signal+"]     = pTableTxt_SignalUp_Brush.ToDxBrush(RenderTarget);
					if(TableTxtBrushDX["Signal-"]==null)     TableTxtBrushDX["Signal-"]     = pTableTxt_SignalDown_Brush.ToDxBrush(RenderTarget);
					if(TableTxtBrushDX["Delta+"]==null)      TableTxtBrushDX["Delta+"]      = pTableTxt_DeltaPos_Brush.ToDxBrush(RenderTarget);
					if(TableTxtBrushDX["Delta-"]==null)      TableTxtBrushDX["Delta-"]      = pTableTxt_DeltaNeg_Brush.ToDxBrush(RenderTarget);
					if(TableTxtBrushDX["Cum Delta+"]==null)  TableTxtBrushDX["Cum Delta+"]  = pTableTxt_CumDeltaPos_Brush.ToDxBrush(RenderTarget);
					if(TableTxtBrushDX["Cum Delta-"]==null)  TableTxtBrushDX["Cum Delta-"]  = pTableTxt_CumDeltaNeg_Brush.ToDxBrush(RenderTarget);
					if(TableTxtBrushDX["Volume"]==null)      TableTxtBrushDX["Volume"]      = pTableTxt_Volume_Brush.ToDxBrush(RenderTarget);
					if(TableTxtBrushDX["Bid Vol"]==null)     TableTxtBrushDX["Bid Vol"]     = pTableTxt_BidVol_Brush.ToDxBrush(RenderTarget);
					if(TableTxtBrushDX["Ask Vol"]==null)     TableTxtBrushDX["Ask Vol"]     = pTableTxt_AskVol_Brush.ToDxBrush(RenderTarget);
					if(TableFillBrushDX["LabelColumn"]==null) TableFillBrushDX["LabelColumn"]   = pTableFill_LabelColumn_Brush.ToDxBrush(RenderTarget);
					if(TableFillBrushDX["Signal+"]==null)     TableFillBrushDX["Signal+"]       = pTableFill_SignalUp_Brush.ToDxBrush(RenderTarget);
					if(TableFillBrushDX["Signal-"]==null)     TableFillBrushDX["Signal-"]       = pTableFill_SignalDown_Brush.ToDxBrush(RenderTarget);
					if(TableFillBrushDX["Delta+"]==null)      TableFillBrushDX["Delta+"]        = pTableFill_DeltaPos_Brush.ToDxBrush(RenderTarget);
					if(TableFillBrushDX["Delta-"]==null)      TableFillBrushDX["Delta-"]        = pTableFill_DeltaNeg_Brush.ToDxBrush(RenderTarget);
					if(TableFillBrushDX["Cum Delta+"]==null)  TableFillBrushDX["Cum Delta+"]    = pTableFill_CumDeltaPos_Brush.ToDxBrush(RenderTarget);
					if(TableFillBrushDX["Cum Delta-"]==null)  TableFillBrushDX["Cum Delta-"]    = pTableFill_CumDeltaNeg_Brush.ToDxBrush(RenderTarget);
					if(TableFillBrushDX["Volume"]==null)      TableFillBrushDX["Volume"]        = pTableFill_Volume_Brush.ToDxBrush(RenderTarget);
					if(TableFillBrushDX["Bid Vol"]==null)     TableFillBrushDX["Bid Vol"]       = pTableFill_BidVol_Brush.ToDxBrush(RenderTarget);
					if(TableFillBrushDX["Ask Vol"]==null)     TableFillBrushDX["Ask Vol"]       = pTableFill_AskVol_Brush.ToDxBrush(RenderTarget);
					if(UnfinishedBizLineBrushDX == null) {UnfinishedBizLineBrushDX = pUnfinishedBizStrokeStyle.Brush.ToDxBrush(RenderTarget);   UnfinishedBizLineBrushDX.Opacity = pUnfinishedBizStrokeStyle.Opacity/100f;}

					fontheight = (int)pTableFont.Size+4;
                    yTop  = ChartPanel.H - TableRows * fontheight - 14;//-14 moves the table above the NinjaTrader tag line at bottom left of chart
					yOfTableTop = yTop;
					int xLeft = 0;
					xRight = chartControl.GetXByBarIndex(ChartBars, ChartBars.FromIndex);
					cellWidth  = xRight-xLeft;
					x = 0;
					y = yTop;

line=4067;
					i = 0;
					if(ChartBackgroundBrushDX!=null) RenderTarget.FillRectangle(new SharpDX.RectangleF(xRight, y, ChartPanel.W, TableRows * fontheight - 14), ChartBackgroundBrushDX);//full black background behind the table
					#region -- Calculate TableLocations --
					string txt = "";
					for(i = 0; i<TableRows; i++){
						if(i==0)      txt = "Signal";
						else if(i==1) txt = "Delta";
						else if(i==2) txt = "Cum Delta";
						else if(i==3) txt = "Bid/Ask %";
						else if(i==4) txt = "Delta %";
						else if(i==5) txt = "Volume";
						TableLocations[txt] = y+1; //the zero element contains the Y of that row, the other elements in the int array are the X locations of each column
						y += fontheight;
					}
					#endregion

					abar = ChartBars.FromIndex;
					ColNumber = 0;
					y = yOfTableTop;
					int halfBarWidth = (chartControl.GetXByBarIndex(ChartBars, ChartBars.FromIndex) - chartControl.GetXByBarIndex(ChartBars, ChartBars.FromIndex-1))/2;
					while(abar <= ChartBars.ToIndex){
						xRight = chartControl.GetXByBarIndex(ChartBars, abar);
						cellWidth = xRight-x;
						x = xRight - cellWidth/2;//temporarily set x to be the center of the column
//						if(ColNumber>0) RenderTarget.DrawLine(new SharpDX.Vector2(x, yTop), new SharpDX.Vector2(x, yOfTableTop), DXBrushes_White);
						if(ColNumber>0 && BarDataTotals.ContainsKey(abar)) {
							#region -- Delta --
							double delta = BarDataTotals[abar].AskTotal - BarDataTotals[abar].BidTotal;
							if(TableFillBrushDX["Delta+"]!=null) TableFillBrushDX["Delta+"].Opacity = 1f;
							if(TableFillBrushDX["Delta-"]!=null) TableFillBrushDX["Delta-"].Opacity = 1f;
							RenderTarget.FillRectangle(new SharpDX.RectangleF(x, TableLocations["Delta"], cellWidth, fontheight),
								delta>0 ? 
									(TableFillBrushDX["Delta+"]==null ? DXBrushes_Black : TableFillBrushDX["Delta+"]) : 
									(TableFillBrushDX["Delta-"]==null ? DXBrushes_Black : TableFillBrushDX["Delta-"])
							);
							txt = delta.ToString();
							drawstring(txt, xRight -getTextWidth(txt, pTableFont)/2, TableLocations["Delta"], pTableFont, 
								delta>0? 
									(TableTxtBrushDX["Delta+"]==null ? DXBrushes_White : TableTxtBrushDX["Delta+"]) : 
									(TableTxtBrushDX["Delta-"]==null ? DXBrushes_White : TableTxtBrushDX["Delta-"]),
								SharpDX.DirectWrite.TextAlignment.Center
							);
							#endregion

							#region -- CumDelta --
							RenderTarget.FillRectangle(new SharpDX.RectangleF(x, TableLocations["Cum Delta"], cellWidth, fontheight), 
								BarDataTotals[abar].CumDelta>0 ? (TableFillBrushDX["Cum Delta+"]==null ? DXBrushes_Black : TableFillBrushDX["Cum Delta+"]): (TableFillBrushDX["Cum Delta-"]==null ? DXBrushes_Black : TableFillBrushDX["Cum Delta-"])
							);
							long cd = Math.Abs(BarDataTotals[abar].CumDelta);
							if(cd>1000000) txt = (cd/1000000.0).ToString("0.00m");
							else if(cd>100000) txt = (cd/1000.0).ToString("0.00k");
							else txt = cd.ToString("0");
							if(BarDataTotals[abar].CumDelta<0) txt = string.Format("-{0}",txt);
							drawstring(txt, xRight-getTextWidth(txt, pTableFont)/2, TableLocations["Cum Delta"], pTableFont, 
								BarDataTotals[abar].CumDelta>0 ? (TableTxtBrushDX["Cum Delta+"]==null ? DXBrushes_White : TableTxtBrushDX["Cum Delta+"]): (TableTxtBrushDX["Cum Delta-"]==null ? DXBrushes_White : TableTxtBrushDX["Cum Delta-"]),
								SharpDX.DirectWrite.TextAlignment.Center
							);
							#endregion

							#region -- Bid/Ask Vol % --
							var v = (BarDataTotals[abar].BidTotal > BarDataTotals[abar].AskTotal ? -BarDataTotals[abar].BidTotal : BarDataTotals[abar].AskTotal) / Volumes[0].GetValueAt(abar);
							txt = v.ToString("0%");

							if(v<0){
								if(TableFillBrushDX["Bid Vol"]!=null) TableFillBrushDX["Bid Vol"].Opacity = Convert.ToSingle(Math.Abs(v));
								RenderTarget.FillRectangle(new SharpDX.RectangleF(x, TableLocations["Bid/Ask %"], cellWidth, fontheight), 
									(TableFillBrushDX["Bid Vol"]==null ? DXBrushes_Black : TableFillBrushDX["Bid Vol"])
								);
								drawstring(txt, xRight-getTextWidth(txt, pTableFont)/2, TableLocations["Bid/Ask %"], pTableFont, 
									(TableTxtBrushDX["Bid Vol"]==null ? DXBrushes_White : TableTxtBrushDX["Bid Vol"]),
									SharpDX.DirectWrite.TextAlignment.Center
								);
							}else{
								if(TableFillBrushDX["Ask Vol"]!=null) TableFillBrushDX["Ask Vol"].Opacity = Convert.ToSingle(Math.Abs(v));
								RenderTarget.FillRectangle(new SharpDX.RectangleF(x, TableLocations["Bid/Ask %"], cellWidth, fontheight), 
									(TableFillBrushDX["Ask Vol"]==null ? DXBrushes_Black : TableFillBrushDX["Ask Vol"])
								);
								drawstring(txt, xRight-getTextWidth(txt, pTableFont)/2, TableLocations["Bid/Ask %"], pTableFont, 
									(TableTxtBrushDX["Ask Vol"]==null ? DXBrushes_White : TableTxtBrushDX["Ask Vol"]),
									SharpDX.DirectWrite.TextAlignment.Center
								);
							}
							#endregion

							#region -- Delta % --
							txt = (delta / Volumes[0].GetValueAt(abar)).ToString("0.0%");
							if(delta>0) {
								if(TableFillBrushDX["Delta+"]!=null) TableFillBrushDX["Delta+"].Opacity = Convert.ToSingle(delta / Volumes[0].GetValueAt(abar));
								RenderTarget.FillRectangle(new SharpDX.RectangleF(x, TableLocations["Delta %"], cellWidth, fontheight),
									TableFillBrushDX["Delta+"]==null ? DXBrushes_Black : TableFillBrushDX["Delta+"]
								);
								drawstring(txt, xRight-getTextWidth(txt, pTableFont)/2, TableLocations["Delta %"], pTableFont, 
									(TableTxtBrushDX["Delta+"]==null? DXBrushes_White : TableTxtBrushDX["Delta+"]),
									SharpDX.DirectWrite.TextAlignment.Center
								);
							}else{
								if(TableFillBrushDX["Delta-"]!=null) TableFillBrushDX["Delta-"].Opacity = Convert.ToSingle(delta / Volumes[0].GetValueAt(abar));
								RenderTarget.FillRectangle(new SharpDX.RectangleF(x, TableLocations["Delta %"], cellWidth, fontheight),
									TableFillBrushDX["Delta-"]==null ? DXBrushes_Black : TableFillBrushDX["Delta-"]
								);
								drawstring(txt, xRight-getTextWidth(txt, pTableFont)/2, TableLocations["Delta %"], pTableFont, 
									(TableTxtBrushDX["Delta-"]==null? DXBrushes_White : TableTxtBrushDX["Delta-"]),
									SharpDX.DirectWrite.TextAlignment.Center
								);
							}
							#endregion

							#region -- Volume --
							RenderTarget.FillRectangle(new SharpDX.RectangleF(x, TableLocations["Volume"], cellWidth, fontheight), (TableFillBrushDX["Volume"]==null ? DXBrushes_Black : TableFillBrushDX["Volume"]));
							v = Volumes[0].GetValueAt(abar);
							if(v>1000000) txt = (v/1000000.0).ToString("0.00m");
							else if(v>100000) txt = (v/1000.0).ToString("0.00k");
							else txt = v.ToString("0");
							drawstring(txt, xRight-getTextWidth(txt, pTableFont)/2, TableLocations["Volume"], pTableFont, 
								(TableTxtBrushDX["Volume"]==null ? DXBrushes_White : TableTxtBrushDX["Volume"]),
								SharpDX.DirectWrite.TextAlignment.Center
							);
							#endregion
						}
						x = xRight;
						abar++;
						ColNumber++;
					}
					//yOfTableTop = yOfTableTop - TableRows * fontheight;//yOfTableTop is used when rendering other profiles and data, and nothing else must print below yOfTableTop
				}
				#endregion
//				PriceOfTableTop = chartScale.GetValueByY(yOfTableTop);//this is used in OnCalculateMinMax
//Print("OnRender PriceOfTableTop: "+PriceOfTableTop);
                #region -- Draw NetDelta HeatMap --
                if (!IsInHitTest)
                {
                    float dsa_rect_linewidth = pDSA_HistoOutlineThickness;//Math.Max(chartControl.Properties.BarDistance/4f, pDSA_HistoOutlineThickness);
                    int barpaintwidth = chartControl.GetBarPaintWidth(chartControl.BarsArray[0]);

                    int midbrushIdx     = NetDHeatMap_Brushes.Length / 2;
                    int hm_color_ptr    = midbrushIdx;
                    float barDistance   = chartControl.Properties.BarDistance;
                    var HalfBarDistance = barDistance / 2f;
                    for (int hmabar = firstBarIndex; hmabar <= lastBarIndex; hmabar++)
                    {
						if(Times[0].GetValueAt(hmabar)<DataStartTime)
							continue;
                        {
                            if (hmabar == CurrentBars[0] || !HeatMapBarToColor.ContainsKey(hmabar))
                            {
line=3671;
                                long lowest_bid  = -NetD_MinMgr.GetAverage(hmabar - 1);
                                long highest_ask = NetD_MaxMgr.GetAverage(hmabar - 1);
                                long L_spread = Math.Abs(highest_ask - lowest_bid);
                                long L_step   = (long)Math.Abs(Math.Ceiling((double)L_spread / NetDHeatMap_DXBrushes.Length));
                                double current_netd = NETDELTA.GetValueAt(hmabar);
                                hm_color_ptr = 0;//0 is the full-green or Highest value
                                if (current_netd > 0)
                                {
                                    while (hm_color_ptr < midbrushIdx)
                                    {//L_step*2 to make sure we step past the lowest bid, for a bright-red bar if applicable
                                        if (current_netd >= highest_ask) break;
                                        highest_ask = highest_ask - L_step;
                                        hm_color_ptr++;
                                    }
                                    //if(IsDebug && hmabar==ChartBars.ToIndex) Print(Times[0].GetValueAt(hmabar).ToString()+"  ptr: "+hm_color_ptr+"   "+current_netd+"   avg asks: "+highest_ask);
                                }
                                else
                                {
                                    hm_color_ptr = NetDHeatMap_Brushes.Length - 1;
                                    while (hm_color_ptr > midbrushIdx)
                                    {//L_step*2 to make sure we step past the lowest bid, for a bright-red bar if applicable
                                        if (current_netd <= lowest_bid) break;
                                        hm_color_ptr--;
                                        lowest_bid = lowest_bid + L_step;
                                    }
                                    //if(IsDebug && hmabar==ChartBars.ToIndex) Print(Times[0].GetValueAt(hmabar).ToString()+"  ptr: "+hm_color_ptr+"   "+current_netd+"   avg bids: "+lowest_bid);
                                }
                                hm_color_ptr = Math.Max(0, Math.Min(NetDHeatMap_Brushes.Length - 1, hm_color_ptr));
                                HeatMapBarToColor[hmabar] = Math.Max(0, Math.Min(hm_color_ptr, NetDHeatMap_Brushes.Length - 1));//set the Index to the current color shade ptr
							}
                        }
                        float rx = chartControl.GetXByBarIndex(ChartBars, hmabar);
                        float ry = yOfTableTop - BARRIER_LINE_HEIGHT;
                        float max_histo_height = yOfTableTop / 7f;
                        hm_color_ptr = HeatMapBarToColor[hmabar];
                        {
							float vol0 = Convert.ToSingle(IsForex ? Volumes[0].GetValueAt(hmabar) / pFOREXD : Volumes[0].GetValueAt(hmabar));
							float vavg = Convert.ToSingle(Volumes[0].GetValueAt(hmabar-1 > Volumes[0].Count? hmabar - 1 : hmabar));
							if (IsForex)
							{
							    if (this.pHeatMapHeightPeriod > 1) vavg = vavg / pFOREXD;
							    else vavg = vavg / pFOREXD;
							}
							else
							{
							    if (this.pHeatMapHeightPeriod > 1 && VolumeAverage.ContainsKey(hmabar-1)) vavg = VolumeAverage[hmabar - 1];
							}
//								float vol0 = (float)(IsForex ? Volumes[0].GetValueAt(hmabar) / pFOREXD: Volumes[0].GetValueAt(hmabar));
//								float vavg = vol0;
//								if(this.pHeatMapHeightPeriod>1) vavg = VolumeAverage[hmabar-1];
//								else vavg = (float)(IsForex ? Volumes[0].GetValueAt(hmabar-1) / pFOREXD: Volumes[0].GetValueAt(hmabar-1));
							float ryVolAdjuster = vol0 / vavg;
							float rheight = BARRIER_LINE_HEIGHT;
							float ryRect = ChartPanel.Y + yOfTableTop - rheight;
							SharpDX.RectangleF heatmapRect;
							if (pUseSkinnyHeatmapBars)
							{
							    if (iShowNetDeltaHeatMap) RenderTarget.FillRectangle(new SharpDX.RectangleF(rx - HalfBarDistance, ryRect, barDistance - 1f, rheight), NetDHeatMap_DXBrushes[HeatMapBarToColor[hmabar]]);
							    rheight = Math.Min(max_histo_height, Math.Max(rheight, rheight * ryVolAdjuster));
							    ryRect = ChartPanel.Y + yOfTableTop - rheight;
							    //if(IsDebug && hmabar>=ChartBars.ToIndex-5) Print(Times[0].GetValueAt(hmabar).ToString()+"  rheight: "+rheight+"  ryRect: "+ryRect);
							    heatmapRect = new SharpDX.RectangleF(rx - HalfBarDistance, ryRect, barDistance * 0.2f, rheight);
							    if (iShowNetDeltaHeatMap) RenderTarget.FillRectangle(heatmapRect, NetDHeatMap_DXBrushes[HeatMapBarToColor[hmabar]]);
							}
							else
							{
							    rheight = Math.Min(max_histo_height, Math.Max(rheight, rheight * ryVolAdjuster));
							    ryRect = ChartPanel.Y + yOfTableTop - rheight;
							    //if(IsDebug && hmabar>=ChartBars.ToIndex-5) Print(Times[0].GetValueAt(hmabar).ToString()+"  rheight: "+rheight+"  ryRect: "+ryRect);
							    heatmapRect = new SharpDX.RectangleF(rx - HalfBarDistance, ryRect, barDistance - 1f, rheight);
							    if (iShowNetDeltaHeatMap) RenderTarget.FillRectangle(heatmapRect, NetDHeatMap_DXBrushes[HeatMapBarToColor[hmabar]]);
							}
							if (iShowTotalVolumeInHeatMap)
							{
								string vstr = "";
								if (vol0 > 99999)
								{
								    if (vol0 > 999999)
								    {
								        vstr = string.Format("{0}m", (vol0 / 1000000).ToString("0.0"));
								    }
								    else
								        vstr = string.Format("{0}k", (vol0 / 1000).ToString("0.0"));
								}
								else
								    vstr = string.Format("{0}", vol0.ToString());
//Print(Times[0].GetValueAt(hmabar)+"   vol: "+vol0+"   vavg: "+vavg+"   mult: "+ryVolAdjuster.ToString("0.00")+"   h: "+rheight);
								drawstring(vstr, rx - getTextWidth(vstr, netDeltaFont) / 2, ChartPanel.Y + yOfTableTop - netDeltaFont.Size - pDSA_HistoOutlineThickness, netDeltaFont, this.DXBrushes_Black, SharpDX.DirectWrite.TextAlignment.Center);
							}
							if (pShow_DSASignal)
							{
								DSA_Signals[0] = 0;
                                #region -- Print DSA Signals on price bar and/or on HeatMap histo bar --
                                if (rheight > BARRIER_LINE_HEIGHT)
                                {
                                    int mid = NetDHeatMap_Brushes.Length / 2;
                                    bool IsSignalBar = false;
									int DSA_direction = 0;
                                    if (hm_color_ptr < (mid + 1) - pDSA_Sensitivity && Closes[0].GetValueAt(hmabar) > Opens[0].GetValueAt(hmabar))
                                    {
                                        IsSignalBar = true;
                                        DSA_BrushDX = pBuy_DSABrush.ToDxBrush(RenderTarget);
										DSA_direction = 1;
										DSA_Signals[0] = DSA_direction;
                                    }
                                    if (hm_color_ptr > (mid - 1) + pDSA_Sensitivity && Closes[0].GetValueAt(hmabar) < Opens[0].GetValueAt(hmabar))
                                    {
                                        IsSignalBar = true;
                                        DSA_BrushDX = pSell_DSABrush.ToDxBrush(RenderTarget);
										DSA_direction = -1;
										DSA_Signals[0] = DSA_direction;
                                    }
                                    if (IsSignalBar)
                                    {
                                        if (iShowNetDeltaHeatMap && pDSA_OpacityOnHeatMap > 0)
                                        {
                                            DSA_BrushDX.Opacity = pDSA_OpacityOnHeatMap / 100.0f;
                                            heatmapRect.X = heatmapRect.X + pDSA_HistoOutlineThickness / 2f;
                                            heatmapRect.Y = heatmapRect.Y + pDSA_HistoOutlineThickness / 2f;
                                            heatmapRect.Width = heatmapRect.Width - pDSA_HistoOutlineThickness;
                                            heatmapRect.Height = heatmapRect.Height - pDSA_HistoOutlineThickness;
                                            RenderTarget.DrawRectangle(heatmapRect, DSA_BrushDX, pDSA_HistoOutlineThickness);
                                        }
                                        if (pDSA_OpacityOnPriceBar > 0)
                                        {
                                            DSA_BrushDX.Opacity = pDSA_OpacityOnPriceBar / 100.0f;
//											if(pDSA_OverprintPriceBar)
                                            {
                                                rx = chartControl.GetXByBarIndex(ChartBars, hmabar) - barpaintwidth * 0.5f;
                                                double p1 = RTTS(Math.Max(Opens[0].GetValueAt(hmabar), Closes[0].GetValueAt(hmabar)));
                                                double p2 = RTTS(Math.Min(Opens[0].GetValueAt(hmabar), Closes[0].GetValueAt(hmabar)));
                                                if (pRoundForexToWholePip)
                                                {
                                                    p1 = this.RoundToWholePip(p1);// + TickSize/2.0);
                                                    p2 = this.RoundToWholePip(p2);// - TickSize/2.0);
                                                }
                                                //							if(tt.Hour==18 && tt.Minute==55) Print("H: "+p1+"  L: "+p2+"  Tick: "+TickSize);
                                                var ry1 = Math.Min(yOfTableTop, chartScale.GetYByValue(p1));// GetBoxPixel(p1, 'T');
                                                var ry2 = Math.Min(yOfTableTop, chartScale.GetYByValue(p2)); //GetBoxPixel(p2, 'B');
                                                rheight = ry2 - ry1 - 1f;
                                                RenderTarget.FillRectangle(new SharpDX.RectangleF(rx, ry1, barpaintwidth - 1f, rheight), DSA_BrushDX);
                                            }
//											else
//											{
//												rx = chartControl.GetXByBarIndex(ChartBars, hmabar) - chartControl.Properties.BarDistance/2f;
//												rheight = chartScale.GetYByValue(0) - chartScale.GetYByValue(atr30_pts);
//												var ryH = chartScale.GetYByValue(Highs[0].GetValueAt(hmabar));
//												var ryL = chartScale.GetYByValue(Lows[0].GetValueAt(hmabar));
//												RenderTarget.FillRectangle(new SharpDX.RectangleF(rx, ryH-rheight-25f, chartControl.Properties.BarDistance, rheight), DSA_BrushDX);
//												RenderTarget.FillRectangle(new SharpDX.RectangleF(rx, ryL+25f, chartControl.Properties.BarDistance, rheight), DSA_BrushDX);
//											}
                                        }
                                    }
                                    if (DSA_BrushDX != null && !DSA_BrushDX.IsDisposed) DSA_BrushDX.Dispose(); DSA_BrushDX = null;
                                }
                                #endregion -------------------------------
                            }
                        }
                    }

					if (iShowNetDeltaHeatMap && pHeatMap_MinLineThickness > 0 && pHeatMap_MinimumLineColor != Brushes.Transparent)
					{
						var HeatMap_MinimumLineDXBrush = pHeatMap_MinimumLineColor.ToDxBrush(RenderTarget);
						RenderTarget.DrawLine(new SharpDX.Vector2(0, ChartPanel.Y + yOfTableTop - BARRIER_LINE_HEIGHT), new SharpDX.Vector2(ChartPanel.W, ChartPanel.Y + yOfTableTop - BARRIER_LINE_HEIGHT), HeatMap_MinimumLineDXBrush, pHeatMap_MinLineThickness);
						HeatMap_MinimumLineDXBrush.Dispose();
						HeatMap_MinimumLineDXBrush = null;
				    }
				}
				#endregion
				#region -- Draw Volume Moving Averages --
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
				#region VA's based on transaction volume
				if ((iVA1Enabled || iVA2Enabled))
				{
					var iVA1DXBrush = iVA1Color.ToDxBrush(RenderTarget);
					var iVA2DXBrush = iVA2Color.ToDxBrush(RenderTarget);
					var iVA1Line_DXBrush = iVA3Color.ToDxBrush(RenderTarget);
					var iVAS1DXBrush = iVAS1Color.ToDxBrush(RenderTarget);
					var iVAS2DXBrush = iVAS2Color.ToDxBrush(RenderTarget);
					var iVA2Line_DXBrush = iVAS3Color.ToDxBrush(RenderTarget);
					var iVA1_fillDXBrush = iVA1_FillColor.ToDxBrush(RenderTarget); iVA1_fillDXBrush.Opacity = iVA3Opacity/100f;
					var iVA2_fillDXBrush = iVA2_FillColor.ToDxBrush(RenderTarget); iVA2_fillDXBrush.Opacity = iVAS3Opacity/100f;
					for (int i = lastBarIndex; i > firstBarIndex; i--)
					{
                        #region -- draw MA1 --
                        if (iVA1Enabled)
                        {
							if(i>iVA1StartBar){
								if (iVA1Enabled1 && MAPOC.GetValueAt(i) > chartScale.MinValue)  drawLine(MAPOC.GetValueAt(i), MAPOC.GetValueAt(i - 1), i, i - 1, iVA1DXBrush, iVA1DashStyle, iVA1Width, chartControl, chartScale);
								if (iVA1Enabled2 && MAVWAP.GetValueAt(i) > chartScale.MinValue) drawLine(MAVWAP.GetValueAt(i), MAVWAP.GetValueAt(i - 1), i, i - 1, iVA2DXBrush, iVA2DashStyle, iVA2Width, chartControl, chartScale);
								if (iVA1Enabled3)
								{
	                                if (MACLH.GetValueAt(i) > chartScale.MinValue) drawLine(MACLH.GetValueAt(i), MACLH.GetValueAt(i - 1), i, i - 1, iVA1Line_DXBrush, iVA1DashStyle, iVA1Width, chartControl, chartScale);
	                                if (MACLL.GetValueAt(i) > chartScale.MinValue) drawLine(MACLL.GetValueAt(i), MACLL.GetValueAt(i - 1), i, i - 1, iVA1Line_DXBrush, iVA1DashStyle, iVA1Width, chartControl, chartScale);
	                                if (MACLH.GetValueAt(i) > chartScale.MinValue && MACLL.GetValueAt(i) > chartScale.MinValue) 
										drawRegion(
											new double[] { MACLL.GetValueAt(i), MACLL.GetValueAt(i - 1), MACLH.GetValueAt(i - 1), MACLH.GetValueAt(i) }, 
											new int[] { i, i - 1, i - 1, i }, 
											iVA33DXBrush, chartControl, chartScale);
	                            }
							}
                        }
                        #endregion

                        #region -- draw MA2 --
                        if (iVA2Enabled)
                        {
							if(i>iVA2StartBar){
								if (iVA2Enabled1 && MA2POC.GetValueAt(i) > chartScale.MinValue) drawLine(MA2POC.GetValueAt(i), MA2POC.GetValueAt(i - 1), i, i - 1, iVAS1DXBrush, iVAS1DashStyle, iVA1Width, chartControl, chartScale);
	                            if (iVA2Enabled2 && MA2VWAP.GetValueAt(i) > chartScale.MinValue) drawLine(MA2VWAP.GetValueAt(i), MA2VWAP.GetValueAt(i - 1), i, i - 1, iVAS2DXBrush, iVAS2DashStyle, iVA2Width, chartControl, chartScale);
	                            if (iVA2Enabled3)
	                            {
	                                if (MA2CLH.GetValueAt(i) > chartScale.MinValue) drawLine(MA2CLH.GetValueAt(i), MA2CLH.GetValueAt(i - 1), i, i - 1, iVA2Line_DXBrush, iVA2DashStyle, iVA2Width, chartControl, chartScale);
	                                if (MA2CLL.GetValueAt(i) > chartScale.MinValue) drawLine(MA2CLL.GetValueAt(i), MA2CLL.GetValueAt(i - 1), i, i - 1, iVA2Line_DXBrush, iVA2DashStyle, iVA2Width, chartControl, chartScale);
	                                if (MA2CLH.GetValueAt(i) > chartScale.MinValue && MA2CLL.GetValueAt(i) > chartScale.MinValue) 
										drawRegion(
											new double[] { MA2CLL.GetValueAt(i), MA2CLL.GetValueAt(i - 1), MA2CLH.GetValueAt(i - 1), MA2CLH.GetValueAt(i) }, 
											new int[] { i, i - 1, i - 1, i }, 
											iVA33DXBrush, chartControl, chartScale);
	                            }
							}
                        }
                        #endregion
                    }
					iVA1DXBrush.Dispose(); iVA1DXBrush=null;
					iVA2DXBrush.Dispose(); iVA2DXBrush=null;
					iVA1Line_DXBrush.Dispose(); iVA1Line_DXBrush=null;
					iVAS1DXBrush.Dispose(); iVAS1DXBrush=null;
					iVAS2DXBrush.Dispose(); iVAS2DXBrush=null;
					iVA2Line_DXBrush.Dispose(); iVA2Line_DXBrush=null;
                }
				#endregion
#else
				if ((iVA1Enabled || iVA2Enabled))
				{
					var p1_array = new double[]{-1,-1,-1,-1};
					var p2_array = new double[]{-1,-1,-1,-1};
//					var b1_array = new int[]{0,0,0,0};
					for (int i = lastBarIndex; i >= firstBarIndex; i--)
					{
	                    #region -- draw MA1 --
	                    if (iVA1Enabled)
	                    {
//var dt = Times[0].GetValueAt(i);
//if(i==lastBarIndex){//dt.Hour==16 && dt.Minute>40){
//	Print("M1High: "+MA1High.GetValueAt(i).ToString()+"  M1Low: "+MA1Low.GetValueAt(i).ToString());
//	Print("  p1[0]: "+p1_array[0]+"   p1[1]: "+p1_array[1]);
//	Print("  p1[2]: "+p1_array[2]+"   p1[3]: "+p1_array[3]);
//}
							p1_array[0] = (MA1High.GetValueAt(i)>0   ? MA1High.GetValueAt(i)   : p1_array[0]);
							p1_array[1] = (MA1High.GetValueAt(i-1)>0 ? MA1High.GetValueAt(i-1) : p1_array[1]);
							p1_array[2] = (MA1Low.GetValueAt(i)>0    ? MA1Low.GetValueAt(i)    : p1_array[2]);
							p1_array[3] = (MA1Low.GetValueAt(i-1)>0  ? MA1Low.GetValueAt(i-1)  : p1_array[3]);
	                        if (p1_array[0]>0 && p1_array[1]>0) 
								drawLine(p1_array[0], p1_array[1], i, i - 1, iVA1Line_DXBrush, iVA1DashStyle, iVA1Width, chartControl, chartScale);
	                        if (p1_array[2]>0 && p1_array[3]>0) 
								drawLine(p1_array[2], p1_array[3], i, i - 1, iVA1Line_DXBrush, iVA1DashStyle, iVA1Width, chartControl, chartScale);
	                        if (p1_array[0]>0 && p1_array[1]>0 && p1_array[2]>0 && p1_array[3]>0 && iVA3Opacity>0) //MA1High.GetValueAt(i) > chartScale.MinValue && MA1Low.GetValueAt(i) > chartScale.MinValue) 
								drawRegion(
									new double[] { p1_array[2], p1_array[3], p1_array[1], p1_array[0] }, 
									new int[] { i, i - 1, i - 1, i }, 
									iVA1_fillDXBrush, chartControl, chartScale);
						}
						#endregion

						#region -- draw MA2 --
						if (iVA2Enabled)
						{
							p2_array[0] = (MA2High.GetValueAt(i)>0   ? MA2High.GetValueAt(i)   : p2_array[0]);
							p2_array[1] = (MA2High.GetValueAt(i-1)>0 ? MA2High.GetValueAt(i-1) : p2_array[1]);
							p2_array[2] = (MA2Low.GetValueAt(i)>0    ? MA2Low.GetValueAt(i)    : p2_array[2]);
							p2_array[3] = (MA2Low.GetValueAt(i-1)>0  ? MA2Low.GetValueAt(i-1)  : p2_array[3]);
							if (p2_array[0]>0 && p2_array[1]>0) 
								drawLine(p2_array[0], p2_array[1], i, i - 1, iVA2Line_DXBrush, iVA2DashStyle, iVA2Width, chartControl, chartScale);
	                        if (p2_array[2]>0 && p2_array[3]>0) 
								drawLine(p2_array[2], p2_array[3], i, i - 1, iVA2Line_DXBrush, iVA2DashStyle, iVA2Width, chartControl, chartScale);
							if (p2_array[0]>0 && p2_array[1]>0 && p2_array[2]>0 && p2_array[3]>0 && iVAS3Opacity>0)//MA2High.GetValueAt(i) > chartScale.MinValue && MA2Low.GetValueAt(i) > chartScale.MinValue) 
								drawRegion(
									new double[] { p2_array[2], p2_array[3], p2_array[1], p2_array[0] }, 
									new int[] { i, i - 1, i - 1, i }, 
									iVA2_fillDXBrush, chartControl, chartScale);
	                    }
	                    #endregion
	                }
	            }
#endif
                #endregion
				if (!iCPONTOP && iCompositeEnabled) DrawComp(chartControl, chartScale);//Draw Composite Profile
                if (!iMPONTOP) DrawManualP(chartControl, chartScale, ZoneHDXBrush, ZoneHLineWidth);//Draw Manual Profile
                #region -- DRAW ZONES --
                if ((Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1) && iZonesEnabled && (iShowSupplyZones || iShowDemandZones))
                {
					ClickedZoneBar=-1;
                    SharpDX.Direct2D1.Brush ThisBrush = null;
					SharpDX.Direct2D1.Brush ThisPen = null;
					#region -- Display Supply Zones --            	
					if (iShowSupplyZones)
					{
						var tmpSupplyZones = SupplyZones.ToList();
						foreach (KeyValuePair<int, List<Zone>> supZone in tmpSupplyZones)
						{
						    if (supZone.Key == CurrentBars[0]) continue;
						    if (supZone.Key >= RemainBars + 1) continue;

						    XE = !pOutlineZones ? 1 : 0;
						    x1 = chartControl.GetXByBarIndex(ChartBars, supZone.Key);
						    foreach (Zone zone in supZone.Value)
						    {
						        if (zone.BottomPrice >= TopPrice) continue;
						        if (zone.TopPrice <= BottomPrice) continue;
						        if (zone.EndBar != 0 && !iShowBrokenZones) continue;
						        if (zone.EndBar == 0 && zone.TestedPrice == 0 && !iShowFreshZones) continue;
						        if (zone.TestedPrice != 0 && !iShowTestedZones) continue;
						        if (zone.IsHidden) continue;
						        if (zone.EndBar != 0 && zone.EndBar < firstBarIndex) continue;
						        ThisBrush = iSupplyZDXBrushFresh;
						        ThisPen = iSupplyZOLDXBrushFresh;

						        x2 = chartControl.GetXByBarIndex(ChartBars, RemainBars) + XE;
						        if (iExtendZonesRight) x2 = x2 + chartControl.Properties.BarMarginRight;

						        if (zone.EndBar != 0)
						        {
						            ThisBrush = iSupplyZDXBrushBroken;
						            ThisPen = iSupplyZOLDXBrushBroken;

						            // change to draw to right side of the bar that broke the zone
						            x2 = Math.Min(chartControl.GetXByBarIndex(ChartBars, zone.EndBar) + XE, chartControl.GetXByBarIndex(ChartBars, RemainBars) + XE);
						            if (iExtendZonesRight && RemainBars < zone.EndBar) x2 = x2 + chartControl.Properties.BarMarginRight;
						        }
						        if (zone.TestedPrice != 0)
						        {
						            ThisBrush = iSupplyZDXBrushTested;
						            ThisPen = iSupplyZOLDXBrushTested;
						        }

						        y1 = chartScale.GetYByValue(zone.TopPrice);
						        y2 = chartScale.GetYByValue(zone.BottomPrice);
						        y3 = y2 - y1;

						        bool canCreateRec = y3 > 0;
						        bool canCreateRecF = y3 > 0;
						        if (canCreateRec) BidRect = new Rect(x1, y1, x2 - x1, y3);
						        if (canCreateRecF) BidRectF = new Rect(x1, y1, x2 - x1 + 1, y3 + 1);

						        if (zone.TicksWidth > 1) // is zone
						        {
						            if (zone.TestedPrice == 0 || !iZonesTSEnabled)
						            {
						                if (!IsInHitTest && canCreateRec) drawRegion(BidRect, ThisBrush);
						            }
						            else
						            {
						                if (zone.TestedPrice == zone.TopPrice)
						                {
						                    if (!IsInHitTest && canCreateRec) drawRegion(BidRect, ThisBrush);
						                }
						                else
						                {
						                    // PARTIALLY TESTED
					                        y1 = chartScale.GetYByValue(zone.TopPrice);
					                        y2 = chartScale.GetYByValue(zone.TestedPrice);
					                        y3 = y2 - y1;
					                        y4 = chartScale.GetYByValue(zone.TestedPrice);
					                        y5 = chartScale.GetYByValue(zone.BottomPrice);
					                        y6 = y5 - y4;
						                    if (x2 - x1 > 0 && y3 > 0)
						                    {
						                        BidRect5 = new Rect(x1, y1, x2 - x1, y3);
						                        ThisBrush = iSupplyZDXBrushFresh;
						                        if (!IsInHitTest) drawRegion(BidRect5, ThisBrush);
						                    }

						                    // TESTED
						                    if (x2 - x1 > 0 && y6 > 0)
						                    {
						                        BidRect5 = new Rect(x1, y4, x2 - x1, y6);
						                        ThisBrush = iSupplyZDXBrushTested;
						                        if (!IsInHitTest) drawRegion(BidRect5, ThisBrush);
						                    }
						                }
						            }
						            if (!IsInHitTest && pOutlineZones && canCreateRec) drawRectangle(BidRect, ThisPen, iTickLevelWidth);
						        }
						        else if (!IsInHitTest) drawLine(x1, x2, y1, y1, ThisBrush, DashStyleHelper.Solid, iTickLevelWidth);// is line

								if (iZonesTMEnabled && zone.TestedPrice != 0)
						        {
						            y2 = chartScale.GetYByValue(zone.TestedPrice);
//                                    SharpDX.Direct2D1.Brush WhitePen = iTM_DXBrush;//.Clone();
//                                    WhitePen.Opacity = iTMOpacity / 100f;
//                                    WhitePen.Freeze();
                                    if (!IsInHitTest) drawLine(x1, x2, y2, y2, iTM_DXBrush, DashStyleHelper.Solid, iTMWidth);
                                }

                            }
                        }
                    }
                    #endregion

                    #region -- Display Demand Zones --
                    if (iShowDemandZones)
                    {
                        var tmpDemandZones = DemandZones.ToList();
                        foreach (KeyValuePair<int, List<Zone>> demZone in tmpDemandZones)
                        {
                            if (demZone.Key == CurrentBars[0]) continue;
                            if (demZone.Key >= RemainBars + 1) continue;

                            XE = !pOutlineZones ? 1 : 0;
                            x1 = chartControl.GetXByBarIndex(ChartBars, demZone.Key);
                            foreach (Zone zone in demZone.Value)
                            {
                                if (zone.BottomPrice >= TopPrice) continue;
                                if (zone.TopPrice <= BottomPrice) continue;
                                if (zone.EndBar != 0 && !iShowBrokenZones) continue;
                                if (zone.EndBar == 0 && zone.TestedPrice == 0 && !iShowFreshZones) continue;
                                if (zone.TestedPrice != 0 && !iShowTestedZones) continue;
                                if (zone.IsHidden) continue;
                                if (zone.EndBar != 0 && zone.EndBar < firstBarIndex) continue;

                                ThisBrush = iDemandZDXBrushFresh;
                                ThisPen = iDemandZOLDXBrushFresh;

                                x2 = chartControl.GetXByBarIndex(ChartBars, RemainBars) + XE;
                                if (iExtendZonesRight) x2 = x2 + chartControl.Properties.BarMarginRight;

                                if (zone.EndBar != 0)
                                {
                                    ThisBrush = iDemandZDXBrushBroken;
                                    ThisPen = iDemandZOLDXBrushBroken;

                                    // change to draw to right side of the bar that broke the zone
                                    x2 = Math.Min(chartControl.GetXByBarIndex(ChartBars, zone.EndBar) + XE, chartControl.GetXByBarIndex(ChartBars, RemainBars) + XE);
                                    if (iExtendZonesRight && RemainBars < zone.EndBar) x2 = x2 + chartControl.Properties.BarMarginRight;
                                }

                                if (zone.TestedPrice != 0)
                                {
                                    ThisBrush = iDemandZDXBrushTested;
                                    ThisPen = iDemandZOLDXBrushTested;
                                }
                                y1 = chartScale.GetYByValue(zone.TopPrice);
                                y2 = chartScale.GetYByValue(zone.BottomPrice);
                                y3 = y2 - y1;

                                bool canCreateRec  = y3 > 0;
                                bool canCreateRecF = y3 > 0;
                                if (canCreateRec)  BidRect  = new Rect(x1, y1, x2 - x1, y3);
                                if (canCreateRecF) BidRectF = new Rect(x1, y1, x2 - x1 + 1, y3 + 1);

                                if (zone.TicksWidth > 1) // is zone
                                {
                                    if (zone.TestedPrice == 0 || !iZonesTSEnabled)
                                    {
                                        if (!IsInHitTest && canCreateRec) drawRegion(BidRect, ThisBrush);
                                    }
                                    else
                                    {
                                        if (zone.TestedPrice == zone.BottomPrice)
                                        {
                                            if (!IsInHitTest && canCreateRec) drawRegion(BidRect, ThisBrush);
                                        }
                                        else
                                        {
                                            // PARTIALLY TESTED
                                            y1 = chartScale.GetYByValue(zone.TopPrice);
                                            y2 = chartScale.GetYByValue(zone.TestedPrice);
                                            y3 = y2 - y1;
                                            y4 = chartScale.GetYByValue(zone.TestedPrice);
                                            y5 = chartScale.GetYByValue(zone.BottomPrice);
                                            y6 = y5 - y4;
                                            if (x2 - x1 > 0 && y3 > 0)
                                            {
                                                BidRect5 = new Rect(x1, y1, x2 - x1, y3);
                                                //JQ 11.21.2017
                                                // Part 1 of BUG 12536 Fixed. When the " Demand Zone" (green area) has been partially tested, 
                                                // the tested price level within the zone is NOT changing color(Light Green).
                                                //--start--
                                                ThisBrush = iDemandZDXBrushTested;
                                                //--End
                                                if (!IsInHitTest) drawRegion(BidRect5, ThisBrush);
                                            }

                                            // TESTED
                                            if (x2 - x1 > 0 && y6 > 0)
                                            {
                                                BidRect5 = new Rect(x1, y4, x2 - x1, y6);
                                                ThisBrush = iDemandZDXBrushFresh;
                                                if (!IsInHitTest) drawRegion(BidRect5, ThisBrush);
                                            }
                                        }
                                    }
                                    if (!IsInHitTest && pOutlineZones && canCreateRec) drawRectangle(BidRect, ThisPen, iTickLevelWidth);
                                }
                                else if (!IsInHitTest) drawLine(x1, x2, y1, y1, ThisBrush, DashStyleHelper.Solid, iTickLevelWidth);// is line

                                if (iZonesTMEnabled && zone.TestedPrice != 0)
                                {
                                    y2 = chartScale.GetYByValue(zone.TestedPrice);
//                                    Brush WhitePen = iTM_DXBrush;//.Clone();
//                                    WhitePen.Opacity = iTMOpacity / 100d;
//                                    WhitePen.Freeze();
                                    if (!IsInHitTest) drawLine(x1, x2, y2, y2, iTM_DXBrush, DashStyleHelper.Solid, iTMWidth);
                                }

                            }
                        }
                    }
                    #endregion
                }
                #endregion
                #region -- INVENTORY --
                if (iInventoryEnabled && ISHardRight)
                {
                    List<LadderRow> tmpAskRows = askRows.ToList();//due to MultiThreading need to work with list copy
                    List<LadderRow> tmpBidRows = bidRows.ToList();//due to MultiThreading need to work with list copy

                    int DesiredMargin = iInvLength + diff + iRightSidePaddingMin;
                    FinalDesiredMargin = Math.Max(FinalDesiredMargin, DesiredMargin);

                    // find longest bar 
                    int largestVol = 0;
                    int largestBidVol = 0;
                    int largestAskVol = 0;
                    int largestAskVolidx = 0;
                    int largestBidVolidx = 0;

                    #region -- get largest bid + index --
                    for (int x = 0; x < tmpBidRows.Count; x++)
                    {
                        if (largestBidVol < tmpBidRows[x].Volume)
                        {
                            largestBidVol = (int)tmpBidRows[x].Volume;
                            largestBidVolidx = x;
                        }
                    }
                    #endregion

                    #region -- get largest ask + index --
                    for (int x = 0; x < tmpAskRows.Count; x++)
                    {
                        if (largestAskVol < tmpAskRows[x].Volume)
                        {
                            largestAskVol = (int)tmpAskRows[x].Volume;
                            largestAskVolidx = x;
                        }
                    }
                    #endregion

                    largestVol = Math.Max(largestAskVol, largestBidVol);

                    GeneralFont.Size = iBarPrintFont.Size - AdjustFontAmount;

                    #region -- Draw ask and bid rows --
                    int barWidth2 = 0, idx = 0, totAVol = 0, totBVol = 0;
                    x1 = chartControl.CanvasRight;
                    int bigwidth = iInvLength;
                    for (idx = 0; idx < tmpAskRows.Count && idx < imaxRows; idx++)
                    {
                        barWidth2 = (int)(bigwidth * (double)tmpAskRows[idx].Volume / largestVol);
                        barWidth2 = Math.Max(barWidth2, (int)getTextWidth(tmpAskRows[idx].Volume.ToString(), GeneralFont) + 5);
                        totAVol += (int)tmpAskRows[idx].Volume;

                        y2 = GetBoxPixel(tmpAskRows[idx].Price, 'T');
                        y1 = GetBoxPixel(tmpAskRows[idx].Price, 'H');

                        if (y1 <= 0 || y2 <= 0) continue;

                        Rect rect2 = new Rect(x1 - barWidth2, y2, barWidth2, y1);
                        Rect rect3 = new Rect(x1 - barWidth2 + 2, y2, barWidth2, y1);

                        if (!IsInHitTest) {
	                        if (largestAskVolidx == idx) 
								drawRegion(rect2, iAskHistDXBrush2);
    	                    else 
								drawRegion(rect2, iAskHistDXBrush1);
						}
                        if (ioutlineHistBars && !IsInHitTest) drawRectangle(rect2, iAskOutDXBrush1, 1);
                        if (!IsInHitTest) drawstring(tmpAskRows[idx].Volume.ToString(), rect3.X, rect3.Y + (rect3.Height - GeneralFont.Size) / 2, GeneralFont, DXBrushes_Black, SharpDX.DirectWrite.TextAlignment.Center);
                    }

                    barWidth2 = 0;
                    for (idx = 0; idx < tmpBidRows.Count && idx < imaxRows; idx++)
                    {
                        barWidth2 = (int)(bigwidth * (double)tmpBidRows[idx].Volume / largestVol);
                        barWidth2 = Math.Max(barWidth2, (int)getTextWidth(tmpBidRows[idx].Volume.ToString(), GeneralFont) + 5);
                        totBVol += (int)tmpBidRows[idx].Volume;

                        y2 = GetBoxPixel(tmpBidRows[idx].Price, 'T');
                        y1 = GetBoxPixel(tmpBidRows[idx].Price, 'H');

                        if (y1 <= 0 || y2 <= 0) continue;

                        Rect rect2 = new Rect(x1 - barWidth2, y2, barWidth2, y1);
                        Rect rect3 = new Rect(x1 - barWidth2 + 2, y2, barWidth2, y1);

                        if (!IsInHitTest) {
	                        if (largestBidVolidx == idx) 
								drawRegion(rect2, iBidHistDXBrush2);
    	                    else 
								drawRegion(rect2, iBidHistDXBrush1);
						}
                        if (ioutlineHistBars && !IsInHitTest) drawRectangle(rect2, iBidOutDXBrush1, 1);
                        if (!IsInHitTest) drawstring(tmpBidRows[idx].Volume.ToString(), rect3.X, rect3.Y + (rect3.Height - GeneralFont.Size) / 2, GeneralFont, DXBrushes_Black, SharpDX.DirectWrite.TextAlignment.Center);
                    }
					#endregion

                    #region -- display totals --
                    double totVol = totAVol + totBVol;
                    if (totVol > 0 && iDisplayTotal)
                    {
                        double pAVol = Math.Round(totAVol / totVol * 100, 1);
                        double pBVol = Math.Round(totBVol / totVol * 100, 1);

                        if (tmpAskRows.Count > 0)
                        {
                            string FS = iTriMode2 == "Contracts" ? totAVol.ToString() : iTriMode2 == "Percent" ? string.Format("{0}%",pAVol.ToString("n1")) : string.Format("{0}  ({1}%)",totAVol, pAVol.ToString("n1"));
                            int sizeFS = (int)getTextWidth(FS, iBarPrintFont);
                            int askTotY = chartScale.GetYByValue(tmpAskRows.Last().Price + 1 * gbTickSize);
                            if (!IsInHitTest) drawstring(FS, x1 - sizeFS - 1, askTotY - iBarPrintFont.Size / 2, iBarPrintFont, DXBrushes_Black, SharpDX.DirectWrite.TextAlignment.Leading);
                        }
                        if (tmpBidRows.Count > 0)
                        {
                            string FS = iTriMode2 == "Contracts" ? totBVol.ToString() : iTriMode2 == "Percent" ? string.Format("{0}%",pBVol.ToString("n1")) : string.Format("{0}  ({1}%)",totBVol, pBVol.ToString("n1"));
                            int sizeFS = (int)getTextWidth(FS, iBarPrintFont);
                            int bidTotY = chartScale.GetYByValue(tmpBidRows.Last().Price - 1 * gbTickSize);
                            if (!IsInHitTest) drawstring(FS, x1 - sizeFS - 1, bidTotY - iBarPrintFont.Size / 2, iBarPrintFont, DXBrushes_Black, SharpDX.DirectWrite.TextAlignment.Leading);
                        }
                    }
                    #endregion
                }
                #endregion
				if(iCompDevLevel){
					for (abar = firstBarIndex; abar<=lastBarIndex; abar++){
						#region -- Bar Composite Profile --
						if (iCompDevLevel && ((iCompDevCLevel && abar > CompositeStartBar) || (iCompDevHLevel && abar <= CompositeStartBar)))
						{
						    // Composite Profile Boxes Lines
						    x1cp = GetX0(abar, chartControl, true);//#OVERLAY
						    x2cp = GetX0(abar + 1, chartControl, true);
						    x4cp = Math.Abs(x2cp - x1cp);

						    // devco
							#region -- ComDev Region Fill --
							if (iCompDevLevelArea)
							{
							    #region -- Dev Composite VA / EX --
							    if (iCompDevVA)
							    {
							        y1 = chartScale.GetYByValue(CompVAH1.GetValueAt(abar));
							        y2 = chartScale.GetYByValue(CompVAL1.GetValueAt(abar));
							        if (y2 - y1 > 0)
							        {
							            ThisRect = new Rect(x1cp, y1, x4cp, y2 - y1);
							            if (!IsInHitTest) drawRegion(ThisRect, iVAFillDXBrush);//, iFillAreaOpacity);
							        }
								}

						        if (iCompDevEX)
						        {
						            y1 = chartScale.GetYByValue(CompVAH2.GetValueAt(abar));
						            y2 = chartScale.GetYByValue(CompVAH1.GetValueAt(abar));
						            if (y2 - y1 > 0)
						            {
										ThisRect = new Rect(x1cp, y1, x4cp, y2 - y1);
						                if (!IsInHitTest) drawRegion(ThisRect, iEXFillDXBrush);//, iFillAreaOpacity);
						            }

						            y1 = chartScale.GetYByValue(CompVAL1.GetValueAt(abar));
						            y2 = chartScale.GetYByValue(CompVAL2.GetValueAt(abar));
						            if (y2 - y1 > 0)
						            {
						                ThisRect = new Rect(x1cp, y1, x4cp, y2 - y1);
						                if (!IsInHitTest) drawRegion(ThisRect, iEXFillDXBrush);
						            }
						        }
							    #endregion
							}
                            #endregion

                            #region -- Dev Composite VWAP --
                            if (!IsInHitTest && iCompDevVWAP && CompVWAP.GetValueAt(abar) >= ActualBottomPrice - gbTickSize && CompVWAP.GetValueAt(abar) <= ActualTopPrice + gbTickSize)
                            {
                                y1 = GetBoxPixel(CompVWAP.GetValueAt(abar), 'T');
                                y2 = GetBoxPixel(CompVWAP.GetValueAt(abar), 'B');
                                y3 = chartScale.GetYByValue(CompVWAP.GetValueAt(abar));
                                drawLine(x1cp, x2cp, y3, y3, iCPHistogramVWAPDXBrush, DashStyleHelper.Solid, iCPLineWidth);
                            }
                            #endregion

                            #region -- Dev Composite POC --
                            if (!IsInHitTest && iCompDevPOC && CompPOC.GetValueAt(abar) >= ActualBottomPrice - gbTickSize && CompPOC.GetValueAt(abar) <= ActualTopPrice + gbTickSize)
							{
							    y1 = GetBoxPixel(CompPOC.GetValueAt(abar), 'T');
							    y2 = GetBoxPixel(CompPOC.GetValueAt(abar), 'B');
							    y3 = chartScale.GetYByValue(CompPOC.GetValueAt(abar));
							    drawLine(x1cp, x2cp, y3, y3, iCPHistogramPOCDXBrush, DashStyleHelper.Solid, iCPLineWidth);
							}
							#endregion

							#region -- Dev Composite VAH --
							if (!IsInHitTest && iCompDevVA && CompVAH1.GetValueAt(abar) >= ActualBottomPrice - gbTickSize && CompVAH1.GetValueAt(abar) <= ActualTopPrice + gbTickSize)
							{
							    y1 = GetBoxPixel(CompVAH1.GetValueAt(abar), 'T');
							    y2 = GetBoxPixel(CompVAH1.GetValueAt(abar), 'B');
							    y3 = chartScale.GetYByValue(CompVAH1.GetValueAt(abar));
							    drawLine(x1cp, x2cp, y3, y3, iCPHistogramVAHDXBrush, DashStyleHelper.Solid, iCPLineWidth);
							}
							#endregion

							#region -- Dev Composite VAL --
							if (!IsInHitTest && iCompDevVA && CompVAL1.GetValueAt(abar) >= ActualBottomPrice - gbTickSize && CompVAL1.GetValueAt(abar) <= ActualTopPrice + gbTickSize)
							{
							    y1 = GetBoxPixel(CompVAL1.GetValueAt(abar), 'T');
							    y2 = GetBoxPixel(CompVAL1.GetValueAt(abar), 'B');
							    y3 = chartScale.GetYByValue(CompVAL1.GetValueAt(abar));
							    drawLine(x1cp, x2cp, y3, y3, iCPHistogramVALDXBrush, DashStyleHelper.Solid, iCPLineWidth);
							}
							#endregion
							#region -- Dev Composite VAH2 --
							if (!IsInHitTest && iCompDevEX && CompVAH2.GetValueAt(abar) >= ActualBottomPrice - gbTickSize && CompVAH2.GetValueAt(abar) <= ActualTopPrice + gbTickSize)
							{
							    y1 = GetBoxPixel(CompVAH2.GetValueAt(abar), 'T');
							    y2 = GetBoxPixel(CompVAH2.GetValueAt(abar), 'B');
							    y3 = chartScale.GetYByValue(CompVAH2.GetValueAt(abar));
							    drawLine(x1cp, x2cp, y3, y3, iCPHistogramVAH2DXBrush, DashStyleHelper.Solid, iCPLineWidth);
							}
							#endregion

						    #region -- Dev Composite VAL2 --
						    if (!IsInHitTest && iCompDevEX && CompVAL2.GetValueAt(abar) >= ActualBottomPrice - gbTickSize && CompVAL2.GetValueAt(abar) <= ActualTopPrice + gbTickSize)
						    {
						        y1 = GetBoxPixel(CompVAL2.GetValueAt(abar), 'T');
						        y2 = GetBoxPixel(CompVAL2.GetValueAt(abar), 'B');
						        y3 = chartScale.GetYByValue(CompVAL2.GetValueAt(abar));
						        drawLine(x1cp, x2cp, y3, y3, iCPHistogramVAL2DXBrush, DashStyleHelper.Solid, iCPLineWidth);
						    }
						    #endregion
						}
						#endregion
					}
				}
                #region -- DRAW BARS AND PRINT and BidAsk Histos --
                //if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
                {
                    InButton1 = false;
                    InButton2 = false;
                    int FirstBarDrawn = 99999999;
					double Highs0CB = 0;
					double Lows0CB = 0;
//                    foreach (KeyValuePair<int, SortedList<double, PrintLevelDetails>> kvp in tmpBarDataCollection)
//                    for(int abar = firstBarIndex; abar<=lastBarIndex; abar++)//KeyValuePair<int, SortedList<double, PrintLevelDetails>> kvp in tmpBarDataCollection)
					VolumeProfileS TPRO = null;
					double HistoMaxBidAsk = 0;
					bool showBidHistos = pBidAskHistoOpacity>0 && pBidHistoBrush!=Brushes.Transparent;
					bool showAskHistos = pBidAskHistoOpacity>0 && pAskHistoBrush!=Brushes.Transparent;
					if(pBiAskHistoScalingBasis == ARC_PrintProfiler_BidAskHistoScaling.AllVisibleBars && showBidHistos && showAskHistos){
	                    for (abar = firstBarIndex; abar<=lastBarIndex; abar++)
						{//calculating the HistoMaxBidAsk over all visible bars on chart, so that the histos will be relative sized to that max bid/ask value
							//this will help traders get right perspective of what bars had the biggest bid/ask volume and where
							//If we calculated the HistoMaxBidAsk value for each bar independently, then the rectangles wouldn't give perspective when viewing all bars at once
							if(BarDataTotals.ContainsKey(abar))
								HistoMaxBidAsk = Math.Max(HistoMaxBidAsk, Math.Max(BarDataTotals[abar].MaxBid, BarDataTotals[abar].MaxAsk));
						}
					}
//Print("HistoMaxBidAsk:   "+HistoMaxBidAsk+"   fbi: "+firstBarIndex+"  lbi: "+lastBarIndex);
					AskRect  = new Rect(0,0,barWidth-1,GetBoxPixel(RoundToWholePip(Highs[0].GetValueAt(ChartBars.FromIndex)), 'H'));
					AskORect = new Rect(0,0,barWidth+1,AskRect.Height);
					BidRect  = new Rect(0,0,barWidth-1,AskRect.Height);
					BidORect = new Rect(0,0,barWidth+1,AskRect.Height);
					int maxdotsize = Math.Min(7, barWidth);
					List<KeyValuePair<double,PrintLevelDetails>> BarData_ABar = null;
					bool IsDotModeIsOutside = pImbalancesDotMode.CompareTo("Outside")==0;

                    for (abar = firstBarIndex; abar<=lastBarIndex; abar++)
					{
						Highs0CB = RoundToWholePip(Highs[0].GetValueAt(abar));
						Lows0CB  = RoundToWholePip(Lows[0].GetValueAt(abar));
                        bool PrintThisBar   = (Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1) && ((iPrintEnabled && !PrintIndividualBars.Contains(abar)) || (!iPrintEnabled && PrintIndividualBars.Contains(abar)) || (iCurrentBarEnabled && abar == CurrentBars[0]));
						bool ProfileThisBar = ((iBarCompositeEnabled && !ProfileIndividualBars.Contains(abar)) || (!iBarCompositeEnabled && ProfileIndividualBars.Contains(abar)));
						bool IsValidBarDataTotals = BarDataTotals.ContainsKey(abar);
						bool IsValidBarDataCollection = BarDataCollection.ContainsKey(abar);
//Print("PrintThisBar: "+PrintThisBar.ToString());
                        // composite at left adjustment
                        FirstBarDrawn = Math.Min(FirstBarDrawn, abar);
						BarData_ABar = null;
						TPRO = null;

						if (ProfileThisBar && BarProfiles.ContainsKey(abar)) TPRO = BarProfiles[abar];
//Print(abar+"  BarProfiles[abar]: "+(BarProfiles.ContainsKey(abar)? BarProfiles[abar].VWAP.ToString(): BarProfiles.Count.ToString()));
						y1 = PrintThisBar ? GetBoxPixel(Highs0CB, 'T') - 1 : chartScale.GetYByValue(Highs0CB);
						y2 = PrintThisBar ? GetBoxPixel(BodyHigh.GetValueAt(abar), 'T') - 1 : chartScale.GetYByValue(BodyHigh.GetValueAt(abar));
						y3 = PrintThisBar ? GetBoxPixel(BodyLow.GetValueAt(abar), 'B') : chartScale.GetYByValue(BodyLow.GetValueAt(abar)) + 1;
						y4 = PrintThisBar ? GetBoxPixel(Lows0CB, 'B') : chartScale.GetYByValue(Lows0CB) + 1;
						x1 = chartControl.GetXByBarIndex(ChartBars, abar);

//						Rect BodyRect   = new Rect(x1 - barWidth, y2, barWidth * 2, Math.Max(1,y3 - y2));
//						Rect CandleRect = new Rect(x1 - barWidth, y1 - 1, barWidth * 2, Math.Max(1,y4 - y1));

//						if(chartControl.BarWidth>1)
//							drawRegion(BodyRect, ChartBackgroundBrushDX);//Put a mask over the original chart bars
						#region -- Show Unfinished Biz Signal --
						if(pShow_UnfinishedBizSignal && IsValidBarDataCollection){
line=3752;
							int yy = chartScale.GetYByValue(Highs0CB);
							if(BarDataCollection[abar].ContainsKey(Highs0CB) && BarDataCollection[abar][Highs0CB].AskSize>0 && BarDataCollection[abar][Highs0CB].BidSize>0){
								if(yy<yOfTableTop) RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x1, yy), maxdotsize, maxdotsize), UnfinishedBizLineBrushDX != null ? UnfinishedBizLineBrushDX : DXBrushes_White);
							}
							if(BarDataCollection[abar].ContainsKey(Lows0CB) && BarDataCollection[abar][Lows0CB].AskSize>0 && BarDataCollection[abar][Lows0CB].BidSize>0){
								yy = chartScale.GetYByValue(Lows0CB);
								if(yy<yOfTableTop) RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x1, yy), maxdotsize, maxdotsize), UnfinishedBizLineBrushDX != null ? UnfinishedBizLineBrushDX : DXBrushes_White);
							}
line=3753;
							if(pUnfinishedBizStrokeStyle.Width>0){
								var ufb = UnfinishedBizLocs.Where(k=>k.Key < ChartBars.ToIndex && 
										(k.Value.HighPrice > chartScale.MinValue && k.Value.HighPrice < chartScale.MaxValue || 
										 k.Value.LowPrice  < chartScale.MaxValue && k.Value.LowPrice  > chartScale.MinValue)).ToList();
								foreach(var u in ufb){
									if(u.Value.HighPrice != double.MinValue){
										yy = chartScale.GetYByValue(u.Value.HighPrice);
										if(yy<yOfTableTop){
											var xx = chartControl.GetXByBarIndex(ChartBars, u.Key);
											var xx1 = u.Value.WasHighHitABar == 0 ? ChartPanel.W : chartControl.GetXByBarIndex(ChartBars, u.Value.WasHighHitABar);
											RenderTarget.DrawLine(new SharpDX.Vector2(xx,yy), new SharpDX.Vector2(xx1, yy), UnfinishedBizLineBrushDX != null ? UnfinishedBizLineBrushDX : DXBrushes_White, pUnfinishedBizStrokeStyle.Width, pUnfinishedBizStrokeStyle.StrokeStyle);
										}
									}
									if(u.Value.LowPrice != double.MinValue){
										yy = chartScale.GetYByValue(u.Value.LowPrice);
										if(yy<yOfTableTop){
											var xx = chartControl.GetXByBarIndex(ChartBars, u.Key);
											var xx1 = u.Value.WasLowHitABar == 0 ? ChartPanel.W : chartControl.GetXByBarIndex(ChartBars, u.Value.WasLowHitABar);
											RenderTarget.DrawLine(new SharpDX.Vector2(xx,yy), new SharpDX.Vector2(xx1, yy), UnfinishedBizLineBrushDX != null ? UnfinishedBizLineBrushDX : DXBrushes_White, pUnfinishedBizStrokeStyle.Width, pUnfinishedBizStrokeStyle.StrokeStyle);
										}
									}
								}
							}
						}
						#endregion
						#region -- Fill the cells + Profile --
						if (!IsInHitTest && (PrintThisBar || pBidAskHistoOpacity>0 || pShow_Blocks) && chartControl.BarWidth>1 && IsValidBarDataCollection)
						{
//							AskRect      = new Rect(x1, GetBoxPixel(Highs0CB, 'T') - 1, barWidth - 1, GetBoxPixel(Highs0CB, 'H'));
//							AskORect = new Rect(AskRect.X, AskRect.Y, AskRect.Width + 1, AskRect.Height);
//							BidRect      = new Rect(x1 - barWidth, GetBoxPixel(Lows0CB, 'T') - 1, barWidth - 1, GetBoxPixel(Lows0CB, 'H'));
//							BidORect = new Rect(BidRect.X, BidRect.Y, BidRect.Width + 1, BidRect.Height);

					        AskRect.X  = x1;
							AskORect.X = x1;
							BidRect.X  = x1 - barWidth;
							BidORect.X = BidRect.X;

							if(BarData_ABar==null) BarData_ABar = BarDataCollection[abar].ToList();
							var bardata_ptr = BarData_ABar.GetEnumerator();
							while(bardata_ptr.MoveNext())
						    {
								var kvp2 = bardata_ptr.Current;
						        if (abar != ThisCurrentBar && (kvp2.Key > ActualTopPrice || kvp2.Key < ActualBottomPrice)) continue;
						        double thePrice = kvp2.Key;// new order flow coloring

						        if (GetBoxPixel(thePrice, 'H') <= 0) continue;

//						        AskRect.X  = x1;
								AskRect.Y = GetBoxPixel(thePrice, 'T') - 1;
//								AskRect.Width = barWidth - 1;
//								AskRect.Height = GetBoxPixel(thePrice, 'H');

//								AskORect.X = x1;
								AskORect.Y = AskRect.Y;
//								AskORect.Width = AskRect.Width + 1;
//								AskORect.Height = AskRect.Height;

//								BidRect.X  = x1 - barWidth;
								BidRect.Y = AskRect.Y;//GetBoxPixel(thePrice, 'T') - 1;
//								BidRect.Width = barWidth - 1;
//								BidRect.Height = GetBoxPixel(thePrice, 'H');

//								BidORect.X = BidRect.X;
								BidORect.Y = BidRect.Y;
//								BidORect.Width = BidRect.Width + 1;
//								BidORect.Height = BidRect.Height;

								if(AskRect.Y+AskRect.Height > yOfTableTop) continue;//don't print any numbers that overlap the Table
						        var bidAtPrice = kvp2.Value.BidSize;
						        var askAtPrice = kvp2.Value.AskSize;
								if(pBiAskHistoScalingBasis == ARC_PrintProfiler_BidAskHistoScaling.IndividualBar && IsValidBarDataTotals)
									HistoMaxBidAsk = Math.Max(BarDataTotals[abar].MaxBid, BarDataTotals[abar].MaxAsk);

						        var TextBrushDX = iTxtBrushDX_BidAskVol;

						        OverrideFill1 = false;

								#region -- BID SIDE --
						        #region -- set brush and opacity --
//						        if (iShowImbalance && kvp2.Value.BidImbalance != 0)
//						        {
//						            CurrentBrush = iIBBidDXBrush;
//									CurrentBrush.Opacity = iOpacityDn2/100f;
//						            CurrentBrushOpacity = iOpacityDn2;
//						        }
						        /*else if (Direction.GetValueAt(abar) == 1)
						        {
						            CurrentBrush = iDXBrushBarUp;
						        }
						        else
						        {
						            CurrentBrush = iDXBrushBarDn;
						        }*/
						        #endregion

						        if (OverrideFill1) {
									drawRegion(BidRect, OverrideBrush);
								}
//						        else if (thePrice >= BodyLow.GetValueAt(abar) && thePrice <= BodyHigh.GetValueAt(abar)) {
//									drawRegion(BidRect, CurrentBrush);
//								}
//						        else if (kvp2.Value.BidImbalance != 0 && iShowImbalance && iShowImbalanceB) {
//									drawRegion(BidRect, CurrentBrush);
//								}

//						        if (thePrice >= BodyLow.GetValueAt(abar) && thePrice <= BodyHigh.GetValueAt(abar)) {
//									drawRectangle(BidORect, tmpODXBrush, 1);
//								}

								if(showBidHistos && bidAtPrice>0){
									var histowidthPx = bidAtPrice/HistoMaxBidAsk * barWidth;
									BidHistoBrushDX.Opacity = pBidAskHistoOpacity/100f;
//									drawRectangle(BidRect.X + BidRect.Width - chartControl.BarWidth, BidRect.Y, -histowidthPx, BidRect.Height, BidHistoBrushDX, DashStyleHelper.Solid, 1);
									drawRegion(BidRect.X + BidRect.Width - chartControl.BarWidth, BidRect.Y, -histowidthPx, BidRect.Height, BidHistoBrushDX);
								}
						        if (PrintThisBar && iShowVolAtPrice && bidAtPrice > 0 && barprintFont.Size >= MINFONTSIZE){
									if(iShowImbalance && iShowImbalanceText && kvp2.Value.BidImbalance != 0){
								        TextBrushDX = bidAtPrice > pSmallVolumeThreshold ? iTxtBrushDX_BidImbalance : iTxtBrushDX_SmallBidImbalance;
									}else
										TextBrushDX = bidAtPrice > pSmallVolumeThreshold ? iTxtBrushDX_BidAskVol : iTxtBrushDX_SmallBidAskVol;
									if(this.pShow_BigMoneySignal && bidAtPrice > BigMoneyBidAvg.GetValueAt(abar) && BigMoneyBidAvg.GetValueAt(abar)>0 && bidAtPrice<maxBigMoneyVolume)
										drawRegion(BidRect.X, BidRect.Y, Math.Max(5,BidRect.Width - systemBarWidth/2), BidRect.Height, BigMoneyBidRectangleFillDXBrush);
									drawstring(kvp2.Value.BidSizeReduced.ToString("0"), BidRect.X - systemBarWidth/2 - 3, BidRect.Y + (BidRect.Height - barprintFont.Size) / 2, 
												barprintFont, TextBrushDX, SharpDX.DirectWrite.TextAlignment.Trailing, Convert.ToSingle(BidRect.Width));
//if(kvp2.Value.BidSize != kvp2.Value.BidSizeReduced * pVisualVolumeDivisor) Print("PrintProfiler Error");
								}
						        #endregion
						        #region -- ASK SIDE --
						        #region -- set brush and opacity --
//						        if (iShowImbalance && kvp2.Value.AskImbalance != 0)
//						        {
//						            CurrentBrush = iIBAskDXBrush;
									//CurrentBrush.Opacity = iOpacityUp2/100f;
//                                    CurrentBrushOpacity = iOpacityUp2;
//						        }
						        #endregion

						        if (OverrideFill1) drawRegion(AskRect, OverrideBrush);//, iMPBarOpacity);
//						        else if (thePrice >= BodyLow.GetValueAt(abar) && thePrice <= BodyHigh.GetValueAt(abar)) 
//									drawRegion(AskRect, CurrentBrush);//, CurrentBrushOpacity);
//						        else if (kvp2.Value.AskImbalance != 0 && iShowImbalance && iShowImbalanceB) 
//									drawRegion(AskRect, CurrentBrush);//, CurrentBrushOpacity);

//						        if (thePrice >= BodyLow.GetValueAt(abar) && thePrice <= BodyHigh.GetValueAt(abar)) 
//									drawRectangle(AskORect, tmpODXBrush, 1);

//						        if (iShowVolAtPrice && askAtPrice>0 && barprintFont.Size >= MINFONTSIZE) {
//									drawstring(askAtPrice.ToString(), AskRect.X + systemBarWidth/2 + 3, AskRect.Y + (AskRect.Height - barprintFont.Size) / 2, barprintFont, TextBrushDX, SharpDX.DirectWrite.TextAlignment.Leading, Convert.ToSingle(AskRect.Width));
//								}
								if(showAskHistos && askAtPrice>0){
									var histowidthPx = askAtPrice/HistoMaxBidAsk * barWidth;
									AskHistoBrushDX.Opacity = pBidAskHistoOpacity/100f;
//									drawRectangle(AskRect.X+chartControl.BarWidth, AskRect.Y, histowidthPx, AskRect.Height, AskHistoBrushDX, DashStyleHelper.Solid, 1);
									drawRegion(AskRect.X+chartControl.BarWidth, AskRect.Y, histowidthPx, AskRect.Height, AskHistoBrushDX);
								}
						        if (PrintThisBar && iShowVolAtPrice && askAtPrice > 0 && barprintFont.Size >= MINFONTSIZE){
									if(iShowImbalance && iShowImbalanceText && kvp2.Value.AskImbalance != 0){
								        TextBrushDX = askAtPrice > pSmallVolumeThreshold ? iTxtBrushDX_AskImbalance : iTxtBrushDX_SmallAskImbalance;
									}else
										TextBrushDX = askAtPrice > pSmallVolumeThreshold ? iTxtBrushDX_BidAskVol : iTxtBrushDX_SmallBidAskVol;
									if(this.pShow_BigMoneySignal && askAtPrice > BigMoneyAskAvg.GetValueAt(abar) && BigMoneyAskAvg.GetValueAt(abar)>0 && askAtPrice<maxBigMoneyVolume)
										drawRegion(AskRect.X+systemBarWidth/2+3, AskRect.Y, Math.Max(5,AskRect.Width - systemBarWidth/2), AskRect.Height, BigMoneyAskRectangleFillDXBrush);
									drawstring(kvp2.Value.AskSizeReduced.ToString("0"), AskRect.X + systemBarWidth/2 + 3, AskRect.Y + (AskRect.Height - barprintFont.Size) / 2, 
												barprintFont, TextBrushDX, SharpDX.DirectWrite.TextAlignment.Leading, Convert.ToSingle(AskRect.Width));
								}
						        #endregion
						    }
						}
						#endregion
                        #region -- commented out - DRAW The BAR --
//						if (!IsInHitTest && chartControl.BarWidth>1)
//						{
//							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;

//							bool isDirectionUp = Direction.GetValueAt(abar) == 1;
//							y1 = PrintThisBar ? GetBoxPixel(Highs0CB, 'T') - 1 : chartScale.GetYByValue(Highs0CB);
//							y2 = PrintThisBar ? GetBoxPixel(BodyHigh.GetValueAt(abar), 'T') - 1 : chartScale.GetYByValue(BodyHigh.GetValueAt(abar));
//							y3 = PrintThisBar ? GetBoxPixel(BodyLow.GetValueAt(abar), 'B') : chartScale.GetYByValue(BodyLow.GetValueAt(abar));
//							y4 = PrintThisBar ? GetBoxPixel(Lows0CB, 'B') : chartScale.GetYByValue(Lows0CB);

//							if (Highs0CB != BodyHigh.GetValueAt(abar))
//							{
//								Rect ShadowRect = new Rect(x1 - 1, y1, 2, y2 - y1);
//								drawRegion(ShadowRect, ChartBackgroundBrushDX);//Put a mask over the original chart bars
//								drawLine(x1, x1, y1, y2, isDirectionUp ? iDXBrushBar2Up : iDXBrushBar2Dn, DashStyleHelper.Solid, 1);//up shadow
//							}
//							if (Lows0CB != BodyLow.GetValueAt(abar) && ChartBackgroundBrushDX!=null)
//							{
//								var ShadowRect = new Rect(x1 - 1, y3, 2, y4 - y3);
//								drawRegion(ShadowRect, ChartBackgroundBrushDX);//Put a mask over the original chart bars
//								drawLine(x1, x1, y3, y4, isDirectionUp ? iDXBrushBar2Up : iDXBrushBar2Dn, DashStyleHelper.Solid, 1);//dw shadow
//							}

//							if (!PrintThisBar && y2 != y3) drawRegion(BodyRect, isDirectionUp ? iDXBrushBarUp : iDXBrushBarDn);//, isDirectionUp ? iOpacityUp : iOpacityDn);

//							// OVERALL BAR OUTLINE
//							if(lastBarIndex-firstBarIndex < 100){
//								if (!PrintThisBar && Opens[0].GetValueAt(abar) == Closes[0].GetValueAt(abar)) drawLine(x1 - barWidth, (x1 - barWidth) + (barWidth * 2), y2, y2, isDirectionUp ? iDXBrushBar2Up : iDXBrushBar2Dn, DashStyleHelper.Solid, 1);
//								else drawRectangle(BodyRect, isDirectionUp ? iDXBrushBar2Up : iDXBrushBar2Dn, 1);
//							}

//							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
//						}
						#endregion

						if(!IsInHitTest && /*drawNetDeltaText &&*/ IsValidBarDataTotals){
							double netdv = NETDELTA.GetValueAt(abar);
							double dy = 0;
//if(IsDebug) Print(abar+"  NetDelta: "+netdv);
							string vstr1 = string.Empty;
							string vstr2 = string.Empty;
							double dist_mult = 1.1;
							if(iShowTotalVolumeAsPct){
								double pct = Math.Abs(netdv/(IsForex ? Volumes[0].GetValueAt(abar)/pFOREXD : Volumes[0].GetValueAt(abar)));
								vstr1 = pct.ToString("0%");
							}
line=3760;
							#region -- NET DELTA --
							if (iShowNetDelta)
								vstr2 = netdv.ToString("0");
							if(vstr1.Length>0 && vstr2.Length>0){
								dist_mult = 2.5;
//								vstr1 = string.Format("{0}\n{1}", vstr1, vstr2);
								if (netdv >= 0){
									dy = GetBoxPixel(Highs0CB, 'T') - netDeltaFont.Size*dist_mult;
									if(dy+netDeltaFont.Size < yOfTableTop)//don't print any numbers that overlap the Table
										drawstring(vstr1, x1 - getTextWidth(vstr1, netDeltaFont) / 2, dy, netDeltaFont, iDPDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
									dy = GetBoxPixel(Highs0CB, 'T') - netDeltaFont.Size-5;
									if(dy+netDeltaFont.Size < yOfTableTop)//don't print any numbers that overlap the Table
										drawstring(vstr2, x1 - getTextWidth(vstr1, netDeltaFont) / 2, dy, netDeltaFont, iDPDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
							    }else{
									dy = GetBoxPixel(Lows0CB, 'B')+5;
									if(dy+netDeltaFont.Size < yOfTableTop)//don't print any numbers that overlap the Table
										drawstring(vstr1, x1 - getTextWidth(vstr1, netDeltaFont) / 2, dy, netDeltaFont, iDNDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
									dy =  GetBoxPixel(Lows0CB, 'B')+6+netDeltaFont.Size;
										drawstring(vstr2, x1 - getTextWidth(vstr1, netDeltaFont) / 2, dy, netDeltaFont, iDNDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
								}
							}else{
								if(vstr2.Length>0) vstr1 = vstr2;
								if(vstr1.Length>0){
									if (netdv >= 0){
										dy = GetBoxPixel(Highs0CB, 'T') - netDeltaFont.Size-5;
										if(dy+netDeltaFont.Size < yOfTableTop)//don't print any numbers that overlap the Table
											drawstring(vstr1, x1 - getTextWidth(vstr1, netDeltaFont) / 2, dy, netDeltaFont, iDPDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
								    }else{
										dy = GetBoxPixel(Lows0CB, 'B')+5;
										if(dy+netDeltaFont.Size < yOfTableTop)//don't print any numbers that overlap the Table
											drawstring(vstr1, x1 - getTextWidth(vstr1, netDeltaFont) / 2, dy, netDeltaFont, iDNDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
									}
								}
							}
							#endregion
						}
                        #region -- BAR PROFILES --
                        if (TPRO!=null && ProfileThisBar && chartControl.BarWidth>1)
                        {
                            int halfbar = systemBarWidth / 2;

                            #region -- Cluster Box --
                            if (iDisplayCL)
                            {
                                int hig = chartScale.GetYByValue(TPRO.ClusterBottom) - chartScale.GetYByValue(TPRO.ClusterTop) + 1;
                                Rect ClusterBox = new Rect(x1 - halfbar, chartScale.GetYByValue(TPRO.ClusterTop), systemBarWidth - 2, hig);
                                drawRegion(ClusterBox, iMPHistogramClusterDXBrush2);
                            }
                            #endregion

                            var HistogramBrush2 = iMPHistogramMDXBrush;

                            #region -- BAR PROFILES --
//                          foreach (KeyValuePair<double, VolumeAtBA> allvolumes in TPRO.AllVolume)
                            {
                                if (TPRO.ProfileStart > lastBarIndex) continue;
                                //if (allvolumes.Key > Highs0CB || allvolumes.Key < Lows0CB) continue;
								var xLeft = x1-halfbar;
								var xRight = x1+halfbar-1;
                                if (iDisplayCL){
									HistogramBrush2 = iBarProfileClusterDXBrush;
									HistogramBrush2.Opacity = iMPBarOpacity/100f;
									double ptr = RTTS(TPRO.ClusterTop);
									while(ptr>=RTTS(TPRO.ClusterBottom) && ptr > Lows0CB){
		                                y4 = chartScale.GetYByValue(ptr);
	                                    drawLine(xLeft, xRight, y4, y4, HistogramBrush2, DashStyleHelper.Solid, iBarPW);
										ptr = ptr - TickSize;
									}
								}
                                if (iDisplayPOC){
									HistogramBrush2 = iBarProfilePOCDXBrush;
									HistogramBrush2.Opacity = iMPBarOpacity/100f;
	                                y4 = chartScale.GetYByValue(TPRO.POCPrice);
                                    drawLine(xLeft, xRight, y4, y4, HistogramBrush2, DashStyleHelper.Solid, iBarPW);
								}
                                if (iDisplayVWAP) {
									HistogramBrush2 = iBarProfileVWAPDXBrush;
									HistogramBrush2.Opacity = iMPBarOpacity/100f;
	                                y4 = chartScale.GetYByValue(TPRO.VWAP);
                                    drawLine(xLeft, xRight, y4, y4, HistogramBrush2, DashStyleHelper.Solid, iBarPW);
								}
                                if (iDisplayVA){
									HistogramBrush2 = iBarProfileVAHDXBrush;
									HistogramBrush2.Opacity = iMPBarOpacity/100f;
	                                y4 = chartScale.GetYByValue(TPRO.VAH);
                                    drawLine(xLeft, xRight, y4, y4, HistogramBrush2, DashStyleHelper.Solid, iBarPW);
									HistogramBrush2 = iBarProfileVALDXBrush;
									HistogramBrush2.Opacity = iMPBarOpacity/100f;
	                                y4 = chartScale.GetYByValue(TPRO.VAL);
                                    drawLine(xLeft, xRight, y4, y4, HistogramBrush2, DashStyleHelper.Solid, iBarPW);
								}
                            }
                            #endregion
                        }
                        #endregion
						#region -- Bid/Ask Imbalance Dots + Blocks --
						if(!IsInHitTest && chartControl.BarWidth>1 && IsValidBarDataCollection && (pShow_Blocks || (iShowImbalance && iShowImbalanceA))){
							if(BarData_ABar==null) BarData_ABar = BarDataCollection[abar].ToList();
							var bardata_ptr = BarData_ABar.GetEnumerator();
							while(bardata_ptr.MoveNext())
						    {
								var kvp2 = bardata_ptr.Current;
						        // hide dots that are saved on range bars outside of the bar on the chart
						        if (kvp2.Key > ActualTopPrice || kvp2.Key < ActualBottomPrice) continue;
						        y5 = chartScale.GetYByValue(kvp2.Key) - iRSSize;
						        y6 = chartScale.GetYByValue(kvp2.Key);
								double minXr = x1;
								double minXl = x1;

								//ok
								#region -- show BLOCK TRADES --
								if (pShow_Blocks)
								{
								    if (kvp2.Value.AskBlocks.Count > 0)
								    {
								        Point[] points2 = DrawTri(x1, y6, 0, iTriSize, 1);
								        fillPolygon(points2, iIBAskDXBrush3);//, iOpacityUp3);
										minXr += iTriSize + 2;
Print("Ask Block trade at "+Times[0].GetValueAt(abar).ToString());
								    }
								    if (kvp2.Value.BidBlocks.Count > 0)
								    {
                                        //Point[] points2 = iTriMode != "Inside" ? DrawTri(x2, y6, 0, iTriSize, 1) : DrawTri(btX2, y6, 0, iTriSize, -1);
                                        //Print(x2);
                                        Point[] points2 = DrawTri(x1, y6, 0, iTriSize, -1);
                                        fillPolygon(points2, iIBBidDXBrush3);//, iOpacityDn3);
										minXl -= iTriSize + 2;
Print("Bid Block trade at "+Times[0].GetValueAt(abar).ToString());
								    }
								}
								#endregion
								
                                if (IsDotModeIsOutside)
						        {
						            //x1 = (int)
						            //x2 = (int)btX2 + systemBarWidth;
						            BidSignalRect = new Rect(x1 - systemBarWidth/2, y5, iRSSize + iRSSize + 1, iRSSize + iRSSize + 1);
						            AskSignalRect = new Rect(x1 + systemBarWidth/2 - iRSSize * 2, y5, iRSSize + iRSSize + 1, iRSSize + iRSSize + 1);
						        }
						        else
						        {
						            BidSignalRect = new Rect(x1 - iRSSize - iRSSize - 1 - 1, y5, iRSSize + iRSSize + 1, iRSSize + iRSSize + 1);
						            AskSignalRect = new Rect(x1 + 1, y5, iRSSize + iRSSize + 1, iRSSize + iRSSize + 1);
						        }
								if(AskSignalRect.X < minXr)
								{
									AskSignalRect.Offset(minXr - AskSignalRect.X, 0);
								}
								if(BidSignalRect.X > minXl)
								{
									BidSignalRect.Offset(minXl - BidSignalRect.X, 0);
								}

                                //Imbalance DOTS
                                if (iShowImbalance && iShowImbalanceA)
						        {
						            if (kvp2.Value.AskImbalance != 0)
                                    {
                                        fillEllipse(AskSignalRect, iBlocksDXBrush);
                                    }

                                    if (kvp2.Value.BidImbalance != 0)
                                    {
                                        fillEllipse(BidSignalRect, iBlocks2DXBrush);
                                    }
                                }
	                        }
                        }
                        #endregion
                    }
				}
                #endregion

				#region -- Signals labels --
                if (!IsMinuteBar)
                {
					int ABOVE = 1;
					int BELOW = -1;
					List<string> SignalOnBar = new List<string>();
					Point[] points = null;
					string sigName="";
					double xname = 0, yname = 0;

line=4802;//Pit(line);
					for (abar = lastBarIndex; abar > firstBarIndex; abar--)
					{
						double H = Highs[0].GetValueAt(abar);
						double L = Lows[0].GetValueAt(abar);
						var LowIsOffChart  = L > chartScale.MaxValue || L < chartScale.MinValue;
						var HighIsOffChart = H < chartScale.MinValue || H > chartScale.MaxValue;
						int netdeltaside = 0;
						if ((iShowNetDelta || this.iShowTotalVolumeAsPct) && !IsInHitTest && /*drawNetDeltaText &&*/ BarDataTotals.ContainsKey(abar))
						{
							netdeltaside = NETDELTA.GetValueAt(abar) >= 0 ? ABOVE : BELOW;//v1.012 ##Modif by Kriss AzurITec## for auto offset
						}

line=4815;//Pit(line);
						int OverallSignalDirection = 0;
						SignalOnBar.Clear();
						int DirectionOfSignal = 0;
						x = 0;

						int yHigh = GetBoxPixel(H, 'T', netdeltaside == ABOVE)-5;
						int yLow  = GetBoxPixel(L, 'B',  netdeltaside == BELOW)+5;
						int startingYHigh = yHigh;
						int startingYLow  = yLow;
						y = yHigh;
						points = null;
						sigName="";
						int DDsignal = deltadivergenceDefault.IsValidDataPointAt(abar) ? Convert.ToInt32(deltadivergenceDefault.GetValueAt(abar)) : 0;
						int TTsignal = trappedtraderDefault.IsValidDataPointAt(abar)   ? Convert.ToInt32(trappedtraderDefault.GetValueAt(abar)) : 0;
						int CSsignal = 0;
						if (pShow_CCSignal && DDsignal == TTsignal) CSsignal = DDsignal;
						int VDsignal = pShow_VDSignal  && VDSIGNALS.IsValidDataPointAt(abar)  ? Convert.ToInt32(VDSIGNALS.GetValueAt(abar)) : 0;
						int CRsignal = pShow_VCRSignal && VCRSIGNALS.IsValidDataPointAt(abar) ? Convert.ToInt32(VCRSIGNALS.GetValueAt(abar)) : 0;
						int OFCsignal = pShow_OFCSignal && OFCSIGNALS.IsValidDataPointAt(abar) ? Convert.ToInt32(OFCSIGNALS.GetValueAt(abar)) : 0;
//Print(Times[0].GetValueAt(abar)+"   CRsignal: "+CRsignal+"    pShow_VCRSignal: "+pShow_VCRSignal.ToString()+"  VCRSIGNALS: "+VCRSIGNALS.GetValueAt(abar));
//CSsignal=0;
//DDsignal = SELL;
//TTsignal = SELL;
//VDsignal = SELL;
//CRsignal = SELL;

line=4840;//Pit(line);
                        if(!iLongsEnabled)
                        {
							if (DDsignal == BUY) DDsignal = 0;
							if (TTsignal == BUY) TTsignal = 0;
							if (CSsignal == BUY) CSsignal = 0;
							if (VDsignal == BUY) VDsignal = 0;
							if (CRsignal == BUY) CRsignal = 0;
							if (OFCsignal == BUY) OFCsignal = 0;
                        }

                        if (!iShortsEnabled)
                        {
							if (DDsignal == SELL) DDsignal = 0;
							if (TTsignal == SELL) TTsignal = 0;
							if (CSsignal == SELL) CSsignal = 0;
							if (VDsignal == SELL) VDsignal = 0;
							if (CRsignal == SELL) CRsignal = 0;
							if (OFCsignal == SELL) OFCsignal = 0;
                        }
						if(abar == lastBarIndex && pEnableChartMarkers) DeleteChartMarker(abar);//clear the bar of all markers
						int StackCount = 1;
//var time = Times[0].GetValueAt(abar);
//bool zz = (time.Day==29 && time.Hour==10 && time.Minute==0);
//if(zz)Print("Netdelta side: "+netdeltaside+"    NetDelta: "+NETDELTA.GetValueAt(abar)+"   BarDataToals.Contains(abar):"+BarDataTotals.ContainsKey(abar).ToString()+"  drawNetDeltaText: "+drawNetDeltaText.ToString());
line=4863;//Pit(line);
						#region -- COMBINED labels --
						if (pShow_CCSignal && CSsignal!=0)
						{
                            int SIG = CSsignal;
                            if (!IsInHitTest)
                            {
								y = yOfTableTop;
								sigName = string.Empty;
								if (SIG == BUY)
								{
									OverallSignalDirection = SIG;
									sigName = iSignalNameCSL;
									if(!LowIsOffChart){
										x     = chartControl.GetXByBarIndex(ChartBars, abar) - iArrowWidth;
										y     = startingYLow + iArrowSeparation;// + offset;
									}
								}
								else if(SIG == SELL)
								{
									OverallSignalDirection = SIG;
									sigName = iSignalNameCSS;
									if(!HighIsOffChart){
										x    = chartControl.GetXByBarIndex(ChartBars, abar) - iArrowWidth;
										y    = startingYHigh - iArrowSeparation;// - offset;
									}
                                }
								if(sigName.Length>0){
									int temp = y;
									if(y<yOfTableTop){
										points  = DrawArrow(x, ref temp, SIG, pArrowHeight, iArrowWidth);
										fillPolygon(points, SIG == BUY ? iArrowUpDXBrush  : iArrowDnDXBrush);
										drawPolygon(points, SIG == BUY ? iArrowUpODXBrush : iArrowDnODXBrush, 1);

										yname = SIG == BUY ? temp + 2 : temp - iFontText2.Size - 2;
										xname = SIG == BUY ? x - (getTextWidth(sigName, iFontText2) / 2) + iArrowWidth + 2 : x - (getTextWidth(sigName, iFontText2) / 2) + iArrowWidth + 1;
										if (iLabelsEnabled && AxisDXBrush!=null) drawstring(sigName, xname, yname, iFontText2, AxisDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
										if(SIG==BUY)  yLow  = Convert.ToInt32(yname + iFontText2.Size)+5;
										if(SIG==SELL) yHigh = Convert.ToInt32(yname)-5;
									}
									SignalOnBar.Add(sigName);
									DirectionOfSignal = SIG;
									if(pEnableChartMarkers && abar==lastBarIndex) DrawChartMarker(abar, DirectionOfSignal, "CS", ref StackCount);
								}
                            }
						}
						#endregion
						if(CSsignal == 0){
line=4902;//Pit(line);
							#region -- Trapped Trader labels --
							if (pShow_TTSignal && TTsignal!=0 && !IsInHitTest)
							{
								y = yOfTableTop;
								sigName = string.Empty;
								int SIG = TTsignal;//trappedtraderDefault.IsValidDataPointAt(abar) ? trappedtraderDefault.GetValueAt(abar) : 0;
								int movea = (barWidth) / 2;
								if (SIG == BUY)
								{
									if(OverallSignalDirection == SELL) OverallSignalDirection = int.MinValue;
									if(OverallSignalDirection != int.MinValue) OverallSignalDirection = SIG;

									sigName = iSignalNameTTL;
									if(!LowIsOffChart){
										x      = chartControl.GetXByBarIndex(ChartBars, abar) - iArrowWidth - movea;
										y      = startingYLow;// + offset;
//										yLow   = y + iArrowWidth*2 + 2 + Convert.ToInt32(iFontText2.Size);
									}
								}
								else if (SIG == SELL)
								{
									if(OverallSignalDirection == BUY) OverallSignalDirection = int.MinValue;
									if(OverallSignalDirection != int.MinValue) OverallSignalDirection = SIG;

									sigName = iSignalNameTTS;
									if(!HighIsOffChart){
										x       = chartControl.GetXByBarIndex(ChartBars, abar) - iArrowWidth + movea;
										y       = startingYHigh;// - offset;
	//									yHigh   = y - iArrowWidth*2 - 2 - Convert.ToInt32(iFontText2.Size);
									}
								}
								if(sigName.Length>0){
									if(y<yOfTableTop){
										points = DrawArrow(x, ref y, SIG, pArrowHeight, iArrowWidth);
										fillPolygon(points, SIG == BUY ? iArrowUpDXBrush  : iArrowDnDXBrush);
										drawPolygon(points, SIG == BUY ? iArrowUpODXBrush : iArrowDnODXBrush, 1);

//										yname = SIG == BUY ? y + pArrowHeight + iArrowWidth + 2 : y - iFontText2.Size - pArrowHeight - iArrowWidth - 2;
										yname = SIG == BUY ? y + 2 : y - iFontText2.Size - 2;
										xname = SIG == BUY ? x - (getTextWidth(sigName, iFontText2) / 2) + iArrowWidth + 2 : x - (getTextWidth(sigName, iFontText2) / 2) + iArrowWidth + 1;
										if (iLabelsEnabled && AxisDXBrush!=null) drawstring(sigName, xname, yname, iFontText2, AxisDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
										if(SIG==BUY)  yLow  = Convert.ToInt32(yname + iFontText2.Size)+5;
										if(SIG==SELL) yHigh = Convert.ToInt32(yname)-5;
									}
									SignalOnBar.Add(sigName);
									DirectionOfSignal = SIG;
									if(pEnableChartMarkers && abar==lastBarIndex) DrawChartMarker(abar, DirectionOfSignal, "TT", ref StackCount);
								}
							}
							#endregion

line=4942;//Pit(line);
							#region -- Delta Divergence labels --
							if (pShow_DDSignal && DDsignal != 0 && !IsInHitTest)
							{
								y = yOfTableTop;
								sigName = string.Empty;
								int SIG = DDsignal;
//if(zz)Print("DDSignal: "+(SIG==BUY?"Buy":"Sell")+"   yLow: "+yLow+"   startingYLow: "+startingYLow+"   SignalOnBar.Contains(TT)? "+SignalOnBar.Contains("TT").ToString());
								int movea = (barWidth) / 2;
								if (SIG == BUY)
								{
									if(OverallSignalDirection == SELL) OverallSignalDirection = int.MinValue;
									if(OverallSignalDirection != int.MinValue) OverallSignalDirection = SIG;

									sigName = iSignalNameDDL;
									if(!LowIsOffChart){
										x = chartControl.GetXByBarIndex(ChartBars, abar) - iArrowWidth + movea;
										if(SignalOnBar.Contains("TT")){
											y    = startingYLow;// + offset;
											yLow = startingYLow;
//if(zz)Print("      yLow reset to: "+yLow);
										}else
											y = startingYLow;
										if(pEnableChartMarkers && abar==lastBarIndex) DrawChartMarker(abar, DirectionOfSignal, "TT", ref StackCount);
									}
								}
								else if(SIG == SELL)
								{
									if(OverallSignalDirection == BUY) OverallSignalDirection = int.MinValue;
									if(OverallSignalDirection != int.MinValue) OverallSignalDirection = SIG;

									sigName = iSignalNameDDS;
									if(!HighIsOffChart){
										x       = chartControl.GetXByBarIndex(ChartBars, abar) - iArrowWidth - movea;
										if(SignalOnBar.Contains("TT")){
											y     = startingYHigh;// - offset;
											yHigh = startingYHigh;
										}else
											y = startingYHigh;
										if(pEnableChartMarkers && abar==lastBarIndex) DrawChartMarker(abar, DirectionOfSignal, "TT", ref StackCount);
									}
								}
								if(sigName.Length>0){
									if(y<yOfTableTop){
										points = DrawArrow(x, ref y, SIG, pArrowHeight, iArrowWidth);
										fillPolygon(points, SIG == BUY ? iArrowUpDXBrush  : iArrowDnDXBrush);
										drawPolygon(points, SIG == BUY ? iArrowUpODXBrush : iArrowDnODXBrush, 1);

//										yname = SIG == BUY ? 
//												y + pArrowHeight + iArrowWidth + 2 : 
//												y - iFontText2.Size - pArrowHeight - iArrowWidth - 2;
										yname = SIG == BUY ? y + 2 : y - iFontText2.Size - 2;
										xname = SIG == BUY ? x - (getTextWidth(sigName, iFontText2) / 2) + iArrowWidth + 2 : x - (getTextWidth(sigName, iFontText2) / 2) + iArrowWidth + 1;
										if (iLabelsEnabled && AxisDXBrush!=null) drawstring(sigName, xname, yname, iFontText2, AxisDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
										if(SIG==BUY)  yLow = Convert.ToInt32(yname + iFontText2.Size)+5;
										if(SIG==SELL) yHigh = Convert.ToInt32(yname)-5;
									}
									SignalOnBar.Add(sigName);
									DirectionOfSignal = SIG;
									if(pEnableChartMarkers && abar==lastBarIndex) DrawChartMarker(abar, DirectionOfSignal, "DD", ref StackCount);
								}
							}
							#endregion
						}
						x = chartControl.GetXByBarIndex(ChartBars, abar);

line=4996;//Pit(line);
						#region -- OFC Signals --
						if (pShow_OFCSignal && iSignalNameOFC.Trim().Length>0)
						{
							y = yOfTableTop;
							int SIG = OFCsignal;
							if (SIG != 0 && !IsInHitTest)
							{
								sigName = string.Empty;
								if(SIG == BUY){
									if(OverallSignalDirection == SELL) OverallSignalDirection = int.MinValue;
									if(OverallSignalDirection != int.MinValue) OverallSignalDirection = SIG;

									sigName = iSignalNameOFC;
									if(!LowIsOffChart){
										if(startingYLow == yLow)
										    y   = startingYLow + iDiamondSeparationOFC;
										else
										    y   = yLow + iDiamondSeparationOFC;
									}
								}else if(SIG == SELL){
									if(OverallSignalDirection == BUY) OverallSignalDirection = int.MinValue;
									if(OverallSignalDirection != int.MinValue) OverallSignalDirection = SIG;

									sigName = iSignalNameOFC;
									if(!HighIsOffChart){
										if(startingYHigh == yHigh)
										    y   = startingYHigh - iDiamondSeparationOFC;
										else
										    y   = yHigh - iDiamondSeparationOFC;
									}
								}

								if(sigName.Length>0){
									if(y<yOfTableTop){
										points = new Point[] { new Point(x, y + iDotWidthOFC), new Point(x + iDotWidthOFC, y), new Point(x, y - iDotWidthOFC), new Point(x - iDotWidthOFC, y)};
										fillPolygon(points, SIG == BUY ? iArrowUpDXBrush : iArrowDnDXBrush);
										drawPolygon(points, SIG == BUY ? iArrowUpODXBrush : iArrowDnODXBrush, 1);

										yname = SIG == BUY ? 
											y + iDotWidthOFC + 2 : 
											y - iFontText2.Size - iDotWidthOFC - 2;
										xname = SIG == BUY ? x - (getTextWidth(sigName, iFontText2) / 2) : x - (getTextWidth(sigName, iFontText2) / 2);
										if (iLabelsEnabled && AxisDXBrush!=null) drawstring(sigName, xname, yname, iFontText2, AxisDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
										if(SIG==BUY)  yLow  = Convert.ToInt32(yname + iFontText2.Size)+5;
										if(SIG==SELL) yHigh = Convert.ToInt32(yname)-5;
									}
									SignalOnBar.Add(sigName);
									DirectionOfSignal = SIG;
									if(pEnableChartMarkers && abar==lastBarIndex) DrawChartMarker(abar, DirectionOfSignal, "OFC", ref StackCount);
								}
                            }
                        }
						#endregion
						#region -- VD Signals --
						if (pShow_VDSignal)
						{
							y = yOfTableTop;
							int SIG = VDsignal;
							if (SIG != 0 && !IsInHitTest)
							{
								sigName = string.Empty;
								if(SIG == BUY){
									if(OverallSignalDirection == SELL) OverallSignalDirection = int.MinValue;
									if(OverallSignalDirection != int.MinValue) OverallSignalDirection = SIG;

									sigName = iSignalNameVDL;
									if(!LowIsOffChart){
										if(startingYLow == yLow)
										    y   = startingYLow + iDiamondSeparationVDS;// + offset;
										else
										    y   = yLow + iDiamondSeparationVDS;
									}
								}else if(SIG == SELL){
									if(OverallSignalDirection == BUY) OverallSignalDirection = int.MinValue;
									if(OverallSignalDirection != int.MinValue) OverallSignalDirection = SIG;

									sigName = iSignalNameVDS;
									if(!HighIsOffChart){
										if(startingYHigh == yHigh)
										    y   = startingYHigh - iDiamondSeparationVDS;// - offset;
										else
										    y   = yHigh - iDiamondSeparationVDS;
									}
								}

								if(sigName.Length>0){
									if(y<yOfTableTop){
										points = new Point[] { new Point(x, y + iDotWidthVDS), new Point(x + iDotWidthVDS, y), new Point(x, y - iDotWidthVDS), new Point(x - iDotWidthVDS, y)};
										fillPolygon(points, SIG == BUY ? iArrowUpDXBrush : iArrowDnDXBrush);
										drawPolygon(points, SIG == BUY ? iArrowUpODXBrush : iArrowDnODXBrush, 1);

										yname = SIG == BUY ? 
											y + iDotWidthVDS + 2 : 
											y - iFontText2.Size - iDotWidthVDS - 2;
										xname = SIG == BUY ? x - (getTextWidth(sigName, iFontText2) / 2) : x - (getTextWidth(sigName, iFontText2) / 2);
										if (iLabelsEnabled && AxisDXBrush!=null) drawstring(sigName, xname, yname, iFontText2, AxisDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
										if(SIG==BUY)  yLow  = Convert.ToInt32(yname + iFontText2.Size)+5;
										if(SIG==SELL) yHigh = Convert.ToInt32(yname)-5;
									}
									SignalOnBar.Add(sigName);
									DirectionOfSignal = SIG;
									if(pEnableChartMarkers && abar==lastBarIndex) DrawChartMarker(abar, DirectionOfSignal, "VD", ref StackCount);
								}
                            }
                        }
						#endregion
//continue;
line=5040;//Pit(line);
						#region -- VCR Signals --
						if (pShow_VCRSignal && !IsInHitTest && CRsignal!=0)
						{
							y = yOfTableTop;
							x = chartControl.GetXByBarIndex(ChartBars, abar) - iArrowWidthVCR;
							int SIG = CRsignal;
//							if(!IsInHitTest)
							{
line=5048;//Pit(line);
								if (!pShow_VCR2b && Math.Abs(SIG) == 1)		    SIG = 0;
								else if (!pShow_VCR3b && Math.Abs(SIG) == 2)    SIG = 0;
								else{
									if(!iLongsEnabled && SIG >= BUY) SIG = 0;
									if(!iShortsEnabled && SIG <= SELL) SIG = 0;
									sigName = Math.Abs(SIG) == 1 ? iSignalNameVCR2 : iSignalNameVCR3;
									if(SIG >= BUY){
										if(OverallSignalDirection <= SELL) OverallSignalDirection = int.MinValue;
										if(OverallSignalDirection != int.MinValue) OverallSignalDirection = SIG;

										if(!LowIsOffChart){
											if(startingYLow == yLow)
											    y     = startingYLow + iSeparationVCR;// + offset;
											else
												y     = yLow + iSeparationVCR;
										}
									}else if(iShortsEnabled && SIG <= SELL){
										if(OverallSignalDirection >= BUY) OverallSignalDirection = int.MinValue;
										if(OverallSignalDirection != int.MinValue) OverallSignalDirection = SIG;

										if(!HighIsOffChart){
											if(startingYHigh == yHigh)
												y     = startingYHigh - iSeparationVCR;// - offset;
											else
												y     = yHigh - iSeparationVCR;
										}
									}
									if(y<yOfTableTop){
										points = DrawArrow(x, ref y, SIG, pArrowHeight, iArrowWidthVCR);
									    fillPolygon(points, SIG >= BUY ? iVCRArrowUpDXBrush : iVCRArrowDnDXBrush);
									    drawPolygon(points, SIG >= BUY ? iArrowUpODXBrush : iArrowDnODXBrush, 1);
										yname = SIG >= BUY ? y + 2 : y - iFontText2.Size - 2;
									    xname = x - (getTextWidth(sigName, iFontText2) / 2) + iArrowWidthVCR + 2;
									    if (iLabelsEnabled && AxisDXBrush!=null) drawstring(sigName, xname, yname, iFontText2, AxisDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
									}
								    DirectionOfSignal = SIG>=BUY ? BUY : SELL;
								    SignalOnBar.Add(sigName + (DirectionOfSignal >= BUY ? "L" : "S"));
									if(pEnableChartMarkers && abar==lastBarIndex) DrawChartMarker(abar, DirectionOfSignal, "VC", ref StackCount);
								}
							}
						}
						#endregion

						if (AudibleAlertMgr!=null && SignalOnBar.Count>0 && lastBarIndex>=CurrentBars[0]- 1 && OverallSignalDirection != int.MinValue)
						{
							if(pSignalTiming == ARC_PrintProfiler_SignalTimingTypes.OnTick && abar==lastBarIndex){
								BackBrushes[0]=Brushes.Yellow;
								AudibleAlertMgr.Play(this, OverallSignalDirection>0 ?BUY:SELL, SignalOnBar.Count>0 ? SignalOnBar[0]:"", abar);
							}else if(pSignalTiming == ARC_PrintProfiler_SignalTimingTypes.OnClose && abar==lastBarIndex-1){
								AudibleAlertMgr.Play(this, OverallSignalDirection>0 ?BUY:SELL, SignalOnBar.Count>0 ? SignalOnBar[0]:"", abar-1);
							}
 						}
						if(pShow_Table && SignalOnBar.Count>0){
							sb.Clear();
							for(int ss = 0; ss<SignalOnBar.Count; ss++){
								if(ss>0) sb.Append(",");
								sb.Append(SignalOnBar[ss]);
							}
							int xRight = chartControl.GetXByBarIndex(ChartBars, abar);
							if(OverallSignalDirection != int.MinValue){
								var txt = sb.ToString();
								RenderTarget.FillRectangle(new SharpDX.RectangleF(xRight-cellWidth/2, TableLocations["Signal"], cellWidth, fontheight), 
									OverallSignalDirection>0 ? (TableFillBrushDX["Signal+"]==null? DXBrushes_Black : TableFillBrushDX["Signal+"]):(TableFillBrushDX["Signal-"]==null ? DXBrushes_Black : TableFillBrushDX["Signal-"])
								);
								drawstring(txt, xRight  - getTextWidth(txt, pTableFont) / 2 , TableLocations["Signal"], pTableFont, 
									OverallSignalDirection>0 ? (TableTxtBrushDX["Signal+"]==null? DXBrushes_White : TableTxtBrushDX["Signal+"]):(TableTxtBrushDX["Signal-"]==null ? DXBrushes_White : TableTxtBrushDX["Signal-"]),
									SharpDX.DirectWrite.TextAlignment.Center
								);
							}
						}
                    }
                }
                #endregion

				#region -- Draw Table gridlines --
				if(pShow_Table){
					y = yOfTableTop;
					x = 0;
					for(i = 0; i<TableRows; i++){
						RenderTarget.DrawLine(new SharpDX.Vector2(x,y), new SharpDX.Vector2(ChartPanel.W, y), DXBrushes_White);//horizontal lines
						y += fontheight;
					}
					abar = ChartBars.FromIndex;
					ColNumber = 0;
					x = chartControl.GetXByBarIndex(ChartBars, 0);
					xRight = chartControl.GetXByBarIndex(ChartBars, 1);
					cellWidth = xRight-x;
					while(abar <= ChartBars.ToIndex){
						xRight = chartControl.GetXByBarIndex(ChartBars, abar);
						x = xRight - cellWidth/2;//temporarily set x to be the center of the column
						if(ColNumber>0) RenderTarget.DrawLine(new SharpDX.Vector2(x, ChartPanel.H), new SharpDX.Vector2(x, yOfTableTop), DXBrushes_White);
						if(ColNumber == 0){
							#region -- Paint label column --
							y = yTop;
							string txt = "";
							RenderTarget.FillRectangle(new SharpDX.RectangleF(0, y, x+cellWidth, (1+TableRows) * fontheight - 14), TableFillBrushDX["LabelColumn"]==null ? DXBrushes_Black : TableFillBrushDX["LabelColumn"]);
							for(int i = 0; i<TableRows; i++){
								if(i==0)      txt = "Signal";
								else if(i==1) txt = "Delta";
								else if(i==2) txt = "Cum Delta";
								else if(i==3) txt = "Bid/Ask %";
								else if(i==4) txt = "Delta %";
								else if(i==5) txt = "Volume";
								//Math.Max(2f,xRight - getTextWidth(txt, pTableFont)-5f)
								drawstring(txt, x+cellWidth- 5f- getTextWidth(txt, pTableFont), y, pTableFont, 
									TableTxtBrushDX["LabelColumn"]==null ? DXBrushes_White : TableTxtBrushDX["LabelColumn"],
									SharpDX.DirectWrite.TextAlignment.Leading
								);
								y += fontheight;
							}
							#endregion
						}
						ColNumber++;
						abar++;
					}
				}
				#endregion

// ////////////////////////////////////////////////////////////////// 

				if(!FirstOnMarketDepthRun && iInventoryEnabled){
					var f = new SimpleFont("Arial",18);
					var omd_msg = "This instrument/datafeed is not providing market depth data\nInventory feature will not be available";
					var size = this.getTextWidthHeight(omd_msg, f);
					RenderTarget.FillRectangle(new SharpDX.RectangleF(98, 98, size[0]+4, size[1]+4), this.DXBrushes_Black);
					drawstring(omd_msg, 100, 100, f, DXBrushes_LightGray, SharpDX.DirectWrite.TextAlignment.Leading);
				}


//                if (iCPONTOP && iCompositeEnabled) DrawComp(chartControl, chartScale);//removecomment

                if (iMPONTOP) DrawManualP(chartControl, chartScale, ZoneHDXBrush, ZoneHLineWidth);//Draw Manual Profile

                // JQ 12.09.2017
                // Removed the following code as it's causing the PP to shift away from the SDV bar when the two bars
                // SDV + PP + VMD are added to the same chart and the SDV are set to be seen infront of the PP. 
                // Bug 12782, 12670
                //---start--
                //chartControl.Properties.BarMarginRight = FinalDesiredMargin;
                //---end--
                RenderTarget.AntialiasMode = OSM;
//}
//catch (Exception e) {
//	RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased; 
//	Print(line+", OnRender: "+e.ToString());
}//#BUG003 : restore correct AntialiasMode
            //if (!IsDebugchOnRenderDone)
            //{
            //    benchOR.Stop();
            //    IsDebugchOnRenderDone = true;
            //    int nbbars = Math.Abs(lastBarIndex - firstBarIndex);
            //    Print(String.Format("OnRD Time (@load) : {0}ms on {1} bars => {2:n}ms/bar", benchOR.ElapsedMilliseconds, nbbars, benchOR.ElapsedMilliseconds / (double)nbbars));
            //    benchOR.Reset();
            //}
        #endregion
}catch(Exception kee){Print(line+":  \n"+kee.ToString());}
		}//end of OnRender
//======================================================================================================
		private string AddSoundFolder(string wav){
			if(IsDebug)Print("PrintProfiler attempting to play:  "+wav);
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
//==========================================================================================================
//				pEnableChartMarkers   = false;
//				pBuyChartMarkers      = ARC_PrintProfiler_ChartMarkers.Arrow;
//				pBuyBrushChartMarker  = Brushes.Lime;
//				pSellChartMarkers     = ARC_PrintProfiler_ChartMarkers.Arrow;
//				pSellBrushChartMarker = Brushes.Magenta;
//				pMarkerTicks          = 20;
//==========================================================================================================
		private void DrawChartMarker(int abar, int DirOfSignal, string tag, ref int StackCount){
			tag = string.Format("Signal{0}_{1}",abar,tag);
			double ticks = pMarkerTicks*StackCount*TickSize;
			StackCount++;
			if(DirOfSignal==BUY){
//Draw.Dot(this,"zordersetting",false,-2,0,Brushes.Transparent);	RemoveDrawObject("zordersetting");},0,null);

				switch (pBuyChartMarkers){
					case ARC_PrintProfiler_ChartMarkers.Arrow   :  TriggerCustomEvent(o2 =>{	Draw.ArrowUp   (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, pBuyBrushChartMarker);},0,null);break;
					case ARC_PrintProfiler_ChartMarkers.Triangle:  TriggerCustomEvent(o2 =>{	Draw.TriangleUp(this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, pBuyBrushChartMarker);},0,null);break;
					case ARC_PrintProfiler_ChartMarkers.Dot     :  TriggerCustomEvent(o2 =>{	Draw.Dot       (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, pBuyBrushChartMarker);},0,null);break;
					case ARC_PrintProfiler_ChartMarkers.Square  :  TriggerCustomEvent(o2 =>{	Draw.Square    (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, pBuyBrushChartMarker);},0,null);break;
					case ARC_PrintProfiler_ChartMarkers.Diamond :  TriggerCustomEvent(o2 =>{	Draw.Diamond   (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, pBuyBrushChartMarker);},0,null);break;
				}
			}
			else if(DirOfSignal==SELL){
				switch (pSellChartMarkers){
					case ARC_PrintProfiler_ChartMarkers.Arrow   :  TriggerCustomEvent(o2 =>{	Draw.ArrowDown   (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, pSellBrushChartMarker);},0,null);break;
					case ARC_PrintProfiler_ChartMarkers.Triangle:  TriggerCustomEvent(o2 =>{	Draw.TriangleDown(this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, pSellBrushChartMarker);},0,null);break;
					case ARC_PrintProfiler_ChartMarkers.Dot     :  TriggerCustomEvent(o2 =>{	Draw.Dot         (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, pSellBrushChartMarker);},0,null);break;
					case ARC_PrintProfiler_ChartMarkers.Square  :  TriggerCustomEvent(o2 =>{	Draw.Square      (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, pSellBrushChartMarker);},0,null);break;
					case ARC_PrintProfiler_ChartMarkers.Diamond :  TriggerCustomEvent(o2 =>{	Draw.Diamond     (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, pSellBrushChartMarker);},0,null);break;
				}
			}
		}
//==========================================================================================================
		private void DeleteChartMarker(int abar){
			List<string> del = new List<string>();
			foreach (dynamic obj in DrawObjects){
				if (obj.Tag.StartsWith(string.Format("Signal{0}_",abar)))	del.Add(obj.Tag);
			}
			foreach(string d in del)	RemoveDrawObject(d);
		}
//==========================================================================================================
		private void HandleRedrawOfChartMarkers(){
			for(int abar = 0; abar<BarsArray[0].Count; abar++){
				DeleteChartMarker(abar);
				int StackCount = 1;
				int DDsignal = deltadivergenceDefault.IsValidDataPointAt(abar) ? Convert.ToInt32(deltadivergenceDefault.GetValueAt(abar)) : 0;
				int TTsignal = trappedtraderDefault.IsValidDataPointAt(abar)   ? Convert.ToInt32(trappedtraderDefault.GetValueAt(abar)) : 0;
				int CSsignal = 0;
				if (pShow_CCSignal && DDsignal == TTsignal) CSsignal = DDsignal;
				int VDsignal = pShow_VDSignal  && VDSIGNALS.IsValidDataPointAt(abar)  ? Convert.ToInt32(VDSIGNALS.GetValueAt(abar)) : 0;
				int OFCsignal = pShow_OFCSignal  && OFCSIGNALS.IsValidDataPointAt(abar)  ? Convert.ToInt32(OFCSIGNALS.GetValueAt(abar)) : 0;
				if(CSsignal!=0 && pShow_CCSignal) {
					DrawChartMarker(abar, CSsignal, "CS", ref StackCount);
					var tag = string.Format("Signal{0}_{1}",abar,"TT");
					RemoveDrawObject(tag);
					tag = string.Format("Signal{0}_{1}",abar,"DD");
					RemoveDrawObject(tag);
				}else{
					if(DDsignal!=0 && pShow_DDSignal) DrawChartMarker(abar, DDsignal, "DD", ref StackCount);
					if(TTsignal!=0 && pShow_TTSignal) DrawChartMarker(abar, TTsignal, "TT", ref StackCount);
				}
				if(VDsignal!=0 && pShow_VDSignal) DrawChartMarker(abar, VDsignal, "VD", ref StackCount);
				if(OFCsignal!=0) DrawChartMarker(abar, OFCsignal>0?BUY:SELL, "OFC", ref StackCount);
				if(pShow_VCRSignal){
					int CRsignal = VCRSIGNALS.IsValidDataPointAt(abar) ? Convert.ToInt32(VCRSIGNALS.GetValueAt(abar)) : 0;
//if(Math.Abs(CRsignal)==1) Print("CRSignal: "+CRsignal+"  Show 2b: "+pShow_VCR2b.ToString());
//if(Math.Abs(CRsignal)==2) Print("CRSignal: "+CRsignal+"  \t\tShow 3b: "+pShow_VCR3b.ToString());
					if(pShow_VCR2b && (CRsignal==1 || CRsignal==-1)) DrawChartMarker(abar, CRsignal>=BUY?BUY:SELL, "VC", ref StackCount);
					if(pShow_VCR3b && (CRsignal==2 || CRsignal==-2)) DrawChartMarker(abar, CRsignal>=BUY?BUY:SELL, "VC", ref StackCount);
				}
			}
		}
//==========================================================================================================
		private void InformUserAboutRecalculation(){
			miRecalculate1.Background = Brushes.Yellow;
			miRecalculate1.FontWeight = FontWeights.Bold;
			miRecalculate1.FontStyle  = FontStyles.Italic;
			miRecalculate2.Background = Brushes.Yellow;
			miRecalculate2.FontWeight = FontWeights.Bold;
			miRecalculate2.FontStyle  = FontStyles.Italic;
		}
//==========================================================================================================
		private void ResetRecalculationUI(){
			miRecalculate1.FontWeight = FontWeights.Normal;
			miRecalculate1.FontStyle = FontStyles.Normal;
			miRecalculate1.Background = null;
			miRecalculate2.FontWeight = FontWeights.Normal;
			miRecalculate2.FontStyle = FontStyles.Normal;
			miRecalculate2.Background = null;
		}
//==========================================================================================================
        //------------------ Private Functions --------------------------------
        #region -- Toolbar Management Utilities --
        #region private void addToolBar()
		private MenuItem miProBarCompProfRecalc;
        private void addToolBar()
        {
			if(pButtonText=="terminated") return;

			gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
			gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
			gLabel = new Label();//#RJBug001

			MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
			MenuControl = new MenuItem {Name="NSPP"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Cyan, Header = pButtonText, Foreground = Brushes.Cyan, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControl.GotFocus += delegate(object o, RoutedEventArgs e){
				if(Keyboard.IsKeyDown(Key.LeftShift)){//REMOVE the indicator if left-shift is held down and left-click on the UI pulldown
					this.IsVisible = false;
					IsTerminated = true;
					pButtonText = "terminated";
					indytoolbar.Visibility = Visibility.Collapsed;
					SetState(State.Terminated);
//					if(ChartPanel!=null){
//						ChartPanel.MouseMove -= OnMouseMove;
//						ChartPanel.MouseUp -= OnMouseUp;
//						//ChartControl.PreviewMouseLeftButtonUp -=	OnCtrlPlusClick;
//					}
//	                if (chartWindow != null)
//	                {
//	                    if (indytoolbar != null)
//	                    {
//	                        Dispatcher.BeginInvoke(new Action(() =>
//	                        {
//	                            chartWindow.MainMenu.Remove(indytoolbar);
//	                            indytoolbar = null;

//	                            chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
//	                            chartWindow = null;
//	                        }));
//	                    }
//	                }
				}else{
		            Dispatcher.BeginInvoke(new Action(() =>
		            {
		                if (miBigMoneyAvgAsk != null){
		                    miBigMoneyAvgAsk.Header = string.Format("{0} Avg Ask size", CurrentBigMoneyAskAvg.ToString("0"));
		                    miBigMoneyAvgBid.Header = string.Format("{0} Avg Bid size\n- - -\n{1} Lookback bars\n{2} Multiplier", CurrentBigMoneyBidAvg.ToString("0"), pBigMoneyLookbackBars,pBigMoneyMultiplier);
		                }
						if(miDynamicBlockAvgCalc != null){
							miDynamicBlockAvgCalc.Header = string.Format("{0} :Avg Dynamic Block\n- - -\n{1} :Lookback bars\n{2}  :percentile", (AvgDynamicBlock<=0 ? "N/A":AvgDynamicBlock.ToString("0")), pDynBlockSizeLookbackBars, pDynBlockSizePercentile.ToString("0%"));
						}
		            }));
				}
			};
			MenuControlContainer.Items.Add(MenuControl);

			#region -- Print Menu --
			MenuItem miPrint = new MenuItem { Header = "Print", Name="Print"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			var miP = new MenuItem { Header = iPrintEnabled ? "Print ON" : "Print OFF", Name = "pPrintEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

            miP = new MenuItem { Header = iCurrentBarEnabled ? "Current Bar ON" : "Current Bar OFF", Name = "pCurrentBarEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miP.Click += PrintMenu_Click;
            miPrint.Items.Add(miP);

            miP = new MenuItem { Header = iShowVolAtPrice ? "Volume Numbers ON" : "Volume Numbers OFF", Name = "pShowVolAtPrice"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

			miP = new MenuItem { Header = iShowNetDeltaHeatMap ? "HeatMap ON" : "HeatMap OFF", Name = "pShowNetDeltaHeatMap"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

			miP = new MenuItem { Header = this.pUseSkinnyHeatmapBars ? "Skinny Histo ON" : "Skinny Histo OFF", Name = "pUseSkinnyHeatmapBars"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

			miP = new MenuItem { Header = iShowNetDelta ? "Net Delta ON" : "Net Delta OFF", Name = "pShowNetDelta"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

			miP = new MenuItem { Header = iShowTotalVolumeInHeatMap ? "Tot Vol ON" : "Tot Vol OFF", Name = "pShowTotVolumeInHeatMap"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

			miP = new MenuItem { Header = iShowTotalVolumeAsPct ? "Tot Vol% ON" : "Tot Vol% OFF", Name = "pShowTotVolAsPct"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

			miShowImbalance = new MenuItem { Header = iShowImbalance ? "Bid/Ask Imbalances ON" : "Bid/Ask Imbalances OFF", Name = "pShowImbalanceOnOff"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowImbalance.Click += PrintMenu_Click;
			miPrint.Items.Add(miShowImbalance);

			miShowImbalanceDots = new MenuItem { Header = iShowImbalanceA ? "Bid/Ask Imbalances Dots ON" : "Bid/Ask Imbalances Dots OFF", Name = "pShowImbalanceDots"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowImbalanceDots.Click += PrintMenu_Click;
			miPrint.Items.Add(miShowImbalanceDots);

			miShowImbalanceTxt = new MenuItem { Header = iShowImbalanceText ? "Bid/Ask Imbalances Text ON" : "Bid/Ask Imbalances Text OFF", Name = "pShowImbalanceText"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowImbalanceTxt.Click += PrintMenu_Click;
			miPrint.Items.Add(miShowImbalanceTxt);

			miP = new MenuItem { Header = pShow_Blocks ? "Block Trades ON" : "Block Trades OFF", Name = "pShowBlocks"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

//			miP = new MenuItem { Header = pShow_OFCSignal ? "OFC ON" : "OFC OFF", Name = "pShow_OFCSignal"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miP.ToolTip = "OrderFlow Confluence (based on confluent table column colors)";
//			miP.Click += delegate (object o, RoutedEventArgs e){
//				pShow_OFCSignal = !pShow_OFCSignal;
//				var m = o as MenuItem;
//				m.Header = pShow_OFCSignal ? "OFC ON" : "OFC OFF";
//				if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
//				ForceRefresh();
//			};
			//miPrint.Items.Add(miP);

			miP = new MenuItem { Header = pShow_TTSignal ? "Trapped Trader ON" : "Trapped Trader OFF", Name = "pTTEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

			miP = new MenuItem { Header = pShow_DDSignal ? "Delta Divergence ON" : "Delta Divergence OFF", Name = "pDDEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

			miP = new MenuItem { Header = pShow_CCSignal ? "Combined Signal ON" : "Combined Signal OFF", Name = "pCCEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miP.Click += PrintMenu_Click;
			miPrint.Items.Add(miP);

			miShowBigMoney = new MenuItem { Header = pShow_BigMoneySignal ? "BigMoney Signal ON" : "BigMoney Signal OFF", Name = "pShow_BigMoneySignal"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miShowBigMoney.Click += delegate (object o, RoutedEventArgs e) {
                pShow_BigMoneySignal = !pShow_BigMoneySignal;
                miShowBigMoney.Header = (pShow_BigMoneySignal ? "BigMoney Signal ON" : "BigMoney Signal OFF");
				//if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                ForceRefresh();
            };
			miPrint.Items.Add(miShowBigMoney);

			miShowTable = new MenuItem { Header = pShow_Table ? "Table ON" : "Table OFF", Name = "pShow_Table"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miShowTable.Click += delegate (object o, RoutedEventArgs e) {
                pShow_Table = !pShow_Table;
                miShowTable.Header = (pShow_Table ? "Table ON" : "Table OFF");
                ForceRefresh();
            };
			miPrint.Items.Add(miShowTable);

			miShowUnfinishedBiz = new MenuItem { Header = pShow_UnfinishedBizSignal ? "UnfinishedBiz Signal ON" : "UnfinishedBiz Signal OFF", Name = "pShow_UnfinishedBizSignal"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miShowUnfinishedBiz.Click += delegate (object o, RoutedEventArgs e) {
                pShow_UnfinishedBizSignal = !pShow_UnfinishedBizSignal;
                miShowUnfinishedBiz.Header = (pShow_UnfinishedBizSignal ? "UnfinishedBiz Signal ON" : "UnfinishedBiz Signal OFF");
                ForceRefresh();
            };
			miPrint.Items.Add(miShowUnfinishedBiz);

			miBidAskHistoOpacity = new MenuItem { Header = "BidAsk Histo Opacity "+pBidAskHistoOpacity.ToString(), Name = "pBidAskHistoOpacity"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miBidAskHistoOpacity.Click += delegate (object o, RoutedEventArgs e) {
				if(pBidAskHistoOpacity>0) pBidAskHistoOpacity = 0;
				else pBidAskHistoOpacity = 50;
                miBidAskHistoOpacity.Header = "BidAsk Histo Opacity "+pBidAskHistoOpacity.ToString();
                ForceRefresh();
            };
			miBidAskHistoOpacity.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if(pBidAskHistoOpacity < 100) this.pBidAskHistoOpacity = pBidAskHistoOpacity+5;
				}else{
					if(pBidAskHistoOpacity > 0) this.pBidAskHistoOpacity= pBidAskHistoOpacity-5;
				}
				pBidAskHistoOpacity = Math.Max(0, Math.Min(pBidAskHistoOpacity,100));
                miBidAskHistoOpacity.Header = "BidAsk Histo Opacity "+pBidAskHistoOpacity.ToString();
				ForceRefresh();
			};
			miPrint.Items.Add(miBidAskHistoOpacity);

			//------------------

//Beta			if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1) 
			if(Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
				MenuControl.Items.Add(miPrint);
			#endregion

			#region -- Inventory Menu --
			MenuItem miInventory = new MenuItem { Header = "Inventory", Name="miInventory"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miInventory1 = new MenuItem { Header = iInventoryEnabled ? "Inventory ON" : "Inventory OFF", Name = "pInventoryEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miInventory1.Click += Inventory_Click;
			miInventory.Items.Add(miInventory1);

			//------------------

//Beta		if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
			if(Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
				MenuControl.Items.Add(miInventory);
			#endregion

			#region -- Profile (Bar) Menu --
			MenuItem miProBar = new MenuItem { Header = "Profile (Bar)", Name="miProBar"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miProBar1 = new MenuItem { Header = iBarCompositeEnabled ? "Profile (Bar) ON" : "Profile (Bar) OFF", Name = "pBarCompositeEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProBar1.Click += ProBarMenu_Click;
			miProBar.Items.Add(miProBar1);

			MenuItem miProBar3 = new MenuItem { Header = iDisplayPOC ? "POC ON" : "POC OFF", Name = "pDisplayPOC"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProBar3.Click += ProBarMenu_Click;
			miProBar.Items.Add(miProBar3);

			MenuItem miProBar4 = new MenuItem { Header = iDisplayVA ? "VAH / VAL ON" : "VAH / VAL OFF", Name = "pDisplayVA"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProBar4.Click += ProBarMenu_Click;
			miProBar.Items.Add(miProBar4);

			MenuItem miProBar5 = new MenuItem { Header = iDisplayCL ? "Cluster ON" : "Cluster OFF", Name = "pDisplayCL"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProBar5.Click += ProBarMenu_Click;
			miProBar.Items.Add(miProBar5);

			MenuItem miProBar6 = new MenuItem { Header = iDisplayVWAP ? "VWAP ON" : "VWAP OFF", Name = "pDisplayVWAP"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProBar6.Click += ProBarMenu_Click;
			miProBar.Items.Add(miProBar6);

			MenuItem miProBar7 = new MenuItem { Header = pShow_VDSignal ? "Volume Divergence ON" : "Volume Divergence OFF", Name = "pVDSignal"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProBar7.Click += ProBarMenu_Click;
			miProBar.Items.Add(miProBar7);

            miEnable_VCRSignal = new MenuItem { Header = (pShow_VCRSignal ? "Volume Cluster Reversal ON" : "Volume Cluster Reversal OFF"), Name="pShow_VCRSignal"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miEnable_VCRSignal.Click += delegate (object o, RoutedEventArgs e) {
                pShow_VCRSignal = !pShow_VCRSignal;
                miEnable_VCRSignal.Header = (pShow_VCRSignal ? "Volume Cluster Reversal ON" : "Volume Cluster Reversal OFF");
				if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                ForceRefresh();
            };
            miProBar.Items.Add(miEnable_VCRSignal);
            //----------------------------------------------------------------------------------------------
            miShow_VCR2Bar = new MenuItem { Header = (pShow_VCR2b ? "VCR 2-Bar signals ON" : "VCR 2-Bar signals OFF"), Name="pShow_VCR2b"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miShow_VCR2Bar.Click += delegate (object o, RoutedEventArgs e) {
                pShow_VCR2b = !pShow_VCR2b;
                miShow_VCR2Bar.Header = (pShow_VCR2b ? "VCR 2-Bar signals ON" : "VCR 2-Bar signals OFF");
				if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                ForceRefresh();
            };
            miProBar.Items.Add(miShow_VCR2Bar);
            //----------------------------------------------------------------------------------------------
            miShow_VCR3Bar = new MenuItem { Header = (pShow_VCR3b ? "VCR 3-Bar signals ON" : "VCR 3-Bar signals OFF"), Name="pShow_VCR3b"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miShow_VCR3Bar.Click += delegate (object o, RoutedEventArgs e) {
                pShow_VCR3b = !pShow_VCR3b;
                miShow_VCR3Bar.Header = (pShow_VCR3b ? "VCR 3-Bar signals ON" : "VCR 3-Bar signals OFF");
				if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                ForceRefresh();
            };
            miProBar.Items.Add(miShow_VCR3Bar);
            //----------------------------------------------------------------------------------------------
            miAbsolute_VCR3Bar = new MenuItem { Header = (pShow_Absolute3Bar ? "VCR Absolute 3-Bar ON" : "VCR Absolute 3-Bar OFF"), Name="pShow_Absolute3Bar"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miAbsolute_VCR3Bar.Click += delegate (object o, RoutedEventArgs e) {
                pShow_Absolute3Bar = !pShow_Absolute3Bar;
                miAbsolute_VCR3Bar.Header = (pShow_Absolute3Bar ? "VCR Absolute 3-Bar ON" : "VCR Absolute 3-Bar OFF");
				if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                ForceRefresh();
            };
            miProBar.Items.Add(miAbsolute_VCR3Bar);

            miProBar.Items.Add(new Separator());
			MenuItem miProBar8 = new MenuItem { Header = "RE-CALCULATE PROFILE", Name="miProBar8"+uID, Foreground = Brushes.Black };
            miProBar8.Click += MenuItemF5_Click;
            miProBar.Items.Add(miProBar8);

            //------------------

//Beta		if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1) 
			if(Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
				MenuControl.Items.Add(miProBar);
			#endregion

			#region -- Profile (Composite) Settings Menu --
			MenuItem miProCompSettings = new MenuItem { Header = "Profile (Composite) Settings", Name="ProCompSettings"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			miProCompSettings.Items.Add(createPCSettingsMenu(iCompositeType, iResetTime.Hours.ToString(), iResetTime.Minutes.ToString(), iResetMinutes.ToString()));

			miProCompSettings.Items.Add(new Separator());

			MenuItem miProCompSettings1 = new MenuItem { Header = "RE-CALCULATE PROFILE", Name="Recalc1"+uID, Foreground = Brushes.Black };
			miProCompSettings1.Click += MenuItemF5_Click;
			miProCompSettings.Items.Add(miProCompSettings1);

			//------------------

			MenuControl.Items.Add(miProCompSettings);
			#endregion

			#region -- Profile (Composite) Visual Menu --
			MenuItem miProCompVisual = new MenuItem { Header = "Profile (Composite) Visual", Name="ProCompVisual"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miProCompVisual1 = new MenuItem { Header = iCompositeEnabled ? "Profile (Composite) ON" : "Profile (Composite) OFF", Name = "pCompositeEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompVisual1.Click += ProCompVisualMenu_Click;
			miProCompVisual.Items.Add(miProCompVisual1);
//ProCompVisualMenu_Click
            miProBarCompProfRecalc = new MenuItem { Header = "RE-CALCULATE PROFILE", Name="ProBarCompProfRecalc"+uID, Foreground = Brushes.Black };
			miProBarCompProfRecalc.IsEnabled = false;
            miProBarCompProfRecalc.Click += MenuItemF5_Click;
            miProCompVisual.Items.Add(miProBarCompProfRecalc);


			MenuItem miProCompVisual2 = new MenuItem { Header = "Display Mode " + iCPDisplay, Name = "pCPDisplay"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompVisual2.Click += ProCompVisualMenu_Click;
			miProCompVisual.Items.Add(miProCompVisual2);

			MenuItem miProCompVisual3 = new MenuItem { Header = iCPONTOP ? "Draw On Top ON" : "Draw On Top OFF", Name = "pCPONTOP"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompVisual3.Click += ProCompVisualMenu_Click;
			miProCompVisual.Items.Add(miProCompVisual3);

			MenuItem miProCompVisual4 = new MenuItem { Header = iCCompositeEnabled ? "Current Profile ON" : "Current Profile OFF", Name = "pCCompositeEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompVisual4.Click += ProCompVisualMenu_Click;
			miProCompVisual.Items.Add(miProCompVisual4);

			MenuItem miProCompVisual5 = new MenuItem { Header = "Current Profile " + iCompositeProfileHD.ToUpper(), Name = "pCompositeProfileHD"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompVisual5.Click += ProCompVisualMenu_Click;
			miProCompVisual.Items.Add(miProCompVisual5);

			MenuItem miProCompVisual7 = new MenuItem { Header = iHCompositeEnabled ? "Historical Profiles ON" : "Historical Profiles OFF", Name = "pHCompositeEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompVisual7.Click += ProCompVisualMenu_Click;
			miProCompVisual.Items.Add(miProCompVisual7);

			MenuItem miProCompVisual8 = new MenuItem { Header = iDrawCText ? "Volume Numbers ON" : "Volume Numbers OFF", Name = "pDrawCText"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompVisual8.Click += ProCompVisualMenu_Click;
			miProCompVisual.Items.Add(miProCompVisual8);

			MenuItem miProCompVisual9 = new MenuItem { Header = iCompLineLabels ? "Level Labels ON" : "Level Labels OFF", Name = "pCompLineLabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompVisual9.Click += ProCompVisualMenu_Click;
			miProCompVisual.Items.Add(miProCompVisual9);

			MenuItem miProCompVisual10 = new MenuItem { Header = iCompLineExtend ? "Level Extend ON" : "Level Extend OFF", Name = "pCompLineExtend"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompVisual10.Click += ProCompVisualMenu_Click;
			miProCompVisual.Items.Add(miProCompVisual10);

            //MenuItem miProCompVisual11 = new MenuItem { Header = iShowCwapComposite ? "CWAP ON" : "CWAP OFF", Name = "pCompCwap", Foreground = Brushes.Black, StaysOpenOnClick = true };
            //miProCompVisual11.Click += ProCompVisualMenu_Click;
            //miProCompVisual.Items.Add(miProCompVisual11);

			//------------------

			MenuControl.Items.Add(miProCompVisual);
			#endregion

			#region -- Profile (Composite) Developing Menu --
			MenuItem miProCompDev = new MenuItem { Header = "Profile (Composite) Developing", Name="ProCompDev"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miProCompDev1 = new MenuItem { Header = iCompDevLevel ? "Developing Levels ON" : "Developing Levels OFF", Name = "pCompDevLevel"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompDev1.Click += ProCompDevMenu_Click;
			miProCompDev.Items.Add(miProCompDev1);

			MenuItem miProCompDev2 = new MenuItem { Header = iCompDevCLevel ? "Current Levels ON" : "Current Levels OFF", Name = "pCompDevCLevel"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompDev2.Click += ProCompDevMenu_Click;
			miProCompDev.Items.Add(miProCompDev2);

			MenuItem miProCompDev3 = new MenuItem { Header = iCompDevHLevel ? "Historical Levels ON" : "Historical Levels OFF", Name = "pCompDevHLevel"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompDev3.Click += ProCompDevMenu_Click;
			miProCompDev.Items.Add(miProCompDev3);

			MenuItem miProCompDev4 = new MenuItem { Header = iCompDevLevelArea ? "Fill Area ON" : "Fill Area OFF", Name = "pCompDevLevelArea"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompDev4.Click += ProCompDevMenu_Click;
			miProCompDev.Items.Add(miProCompDev4);

			MenuItem miProCompDev5 = new MenuItem { Header = iCompDevPOC ? "POC ON" : "POC OFF", Name = "pCompDevPOC"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompDev5.Click += ProCompDevMenu_Click;
			miProCompDev.Items.Add(miProCompDev5);

			MenuItem miProCompDev6 = new MenuItem { Header = iCompDevVWAP ? "VWAP ON" : "VWAP OFF", Name = "pCompDevVWAP"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompDev6.Click += ProCompDevMenu_Click;
			miProCompDev.Items.Add(miProCompDev6);

			MenuItem miProCompDev7 = new MenuItem { Header = iCompDevVA ? "Value Area ON" : "Value Area OFF", Name = "pCompDevVA"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompDev7.Click += ProCompDevMenu_Click;
			miProCompDev.Items.Add(miProCompDev7);

			MenuItem miProCompDev8 = new MenuItem { Header = iCompDevEX ? "Extreme Area ON" : "Extreme Area OFF", Name = "pCompDevEX"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProCompDev8.Click += ProCompDevMenu_Click;
			miProCompDev.Items.Add(miProCompDev8);

			//------------------

			MenuControl.Items.Add(miProCompDev);
			#endregion

			#region -- Profile (Manual) Menu --
			MenuItem miProManual = new MenuItem { Header = "Profile (Manual)", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miProManual1 = new MenuItem { Header = "Draw One Profile", Name = "DrawOneProfile"+uID, Foreground = Brushes.Black, StaysOpenOnClick = false };
			miProManual1.Click += ProManual_Click;
			miProManual.Items.Add(miProManual1);

			MenuItem miProManual2 = new MenuItem { Header = "Draw Multiple Profiles", Name = "DrawMultipleProfiles"+uID, Foreground = Brushes.Black, StaysOpenOnClick = false };
			miProManual2.Click += ProManual_Click;
			miProManual.Items.Add(miProManual2);

			MenuItem miProManual3 = new MenuItem { Header = "Display Mode " + iMPDisplay, Name = "pMPDisplay"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProManual3.Click += ProManual_Click;
			miProManual.Items.Add(miProManual3);

			MenuItem miProManual4 = new MenuItem { Header = iMPONTOP ? "Draw On Top ON" : "Draw On Top OFF", Name = "pMPONTOP"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProManual4.Click += ProManual_Click;
			miProManual.Items.Add(miProManual4);

			MenuItem miProManual5 = new MenuItem { Header = iMPLabels ? "Level Labels ON" : "Level Labels OFF", Name = "pMPLabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miProManual5.Click += ProManual_Click;
			miProManual.Items.Add(miProManual5);

            //MenuItem miProManual6 = new MenuItem { Header = iShowCwapManual ? "CWAP ON" : "CWAP OFF", Name = "pShowCwap", Foreground = Brushes.Black, StaysOpenOnClick = true };
            //miProManual6.Click += ProManual_Click;
            //miProManual.Items.Add(miProManual6);

			//------------------

//			if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1) 
				MenuControl.Items.Add(miProManual);
			#endregion
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
			#region -- Volume Averages Set 1 Menu --
			MenuItem miVASet1 = new MenuItem { Header = "Volume Averages Set 1", Name="VASet1"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miVASet11 = new MenuItem { Header = iVA1Enabled ? "Set 1 ON" : "Set 1 OFF", Name = "pVAEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet11.Click += VASet1Menu_Click;
			miVASet1.Items.Add(miVASet11);

			miVASet1.Items.Add(createVA1Menu(iVA1Period.ToString(), iVA1Mode));

			MenuItem miVASet12 = new MenuItem { Header = iVA1Enabled1 ? "POC ON" : "POC OFF", Name = "pVAEnabled1"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet12.Click += VASet1Menu_Click;
			miVASet1.Items.Add(miVASet12);

			MenuItem miVASet13 = new MenuItem { Header = iVA1Enabled2 ? "VWAP ON" : "VWAP OFF", Name = "pVAEnabled2"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet13.Click += VASet1Menu_Click;
			miVASet1.Items.Add(miVASet13);

			MenuItem miVASet14 = new MenuItem { Header = iVA1Enabled3 ? "Cluster ON" : "Cluster OFF", Name = "pVAEnabled3"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet14.Click += VASet1Menu_Click;
			miVASet1.Items.Add(miVASet14);

			miVASet1.Items.Add(new Separator());

			MenuItem miVASet15 = new MenuItem { Header = "RE-CALCULATE VOLUME AVERAGES", Name = "VASet15"+uID, Foreground = Brushes.Black, StaysOpenOnClick = false };
			miVASet15.Click += MenuItemF5_Click;
			miVASet1.Items.Add(miVASet15);

			//------------------

//Beta		if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1) 
			if(Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
				MenuControl.Items.Add(miVASet1);
			#endregion

			#region -- Volume Averages Set 2 Menu --
			MenuItem miVASet2 = new MenuItem { Header = "Volume Averages Set 2", Name="VASet2"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miVASet21 = new MenuItem { Header = iVA2Enabled ? "Set 2 ON" : "Set 2 OFF", Name = "pVA2Enabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet21.Click += VASet2Menu_Click;
			miVASet2.Items.Add(miVASet21);

			miVASet2.Items.Add(createVA2Menu(iVA2Period.ToString(), iVA2Mode));

			MenuItem miVASet22 = new MenuItem { Header = iVA2Enabled1 ? "POC ON" : "POC OFF", Name = "pVA2Enabled1"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet22.Click += VASet2Menu_Click;
			miVASet2.Items.Add(miVASet22);

			MenuItem miVASet23 = new MenuItem { Header = iVA2Enabled2 ? "VWAP ON" : "VWAP OFF", Name = "pVA2Enabled2"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet23.Click += VASet2Menu_Click;
			miVASet2.Items.Add(miVASet23);

			MenuItem miVASet24 = new MenuItem { Header = iVA2Enabled3 ? "Cluster ON" : "Cluster OFF", Name = "pVA2Enabled3"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet24.Click += VASet2Menu_Click;
			miVASet2.Items.Add(miVASet24);

			miVASet2.Items.Add(new Separator());

			MenuItem miVASet25 = new MenuItem { Header = "RE-CALCULATE VOLUME AVERAGES", Name = "VASet25"+uID, Foreground = Brushes.Black, StaysOpenOnClick = false };
			miVASet25.Click += MenuItemF5_Click;
			miVASet2.Items.Add(miVASet25);

			//------------------
//Beta		if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1) 
			if(Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
				MenuControl.Items.Add(miVASet2);
			#endregion
#else
			#region -- Volume Averages Set 1 Menu --
			var miVASet1 = new MenuItem { Header = "Volume Averages Set 1", Name="VASet1"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			var miVASet11 = new MenuItem { Header = iVA1Enabled ? "Set 1 ON" : "Set 1 OFF", Name = "pVA1Enabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet11.Click += delegate(object o, RoutedEventArgs e){
				iVA1Enabled = !iVA1Enabled;
				miVASet11.Header  = iVA1Enabled ? "Set 1 ON" : "Set 1 OFF";
				ForceRefresh();
			};
			miVASet1.Items.Add(miVASet11);
			miVASet1.Items.Add(createVA1Menu(iVA1Period.ToString(), iVA1Mode));

			miRecalculate2 = new MenuItem { Header = "RE-CALCULATE", Name = "Recalc2"+uID, HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate2.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
//				Draw.TextFixed(this, "DataLoadingMsg", "Reclaculating profiles in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			miVASet1.Items.Add(miRecalculate2);

			MenuControl.Items.Add(miVASet1);
			//------------------

			#endregion

			#region -- Volume Averages Set 2 Menu --
			var miVASet2 = new MenuItem { Header = "Volume Averages Set 2", Name="VASet2"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			var miVASet21 = new MenuItem { Header = iVA2Enabled ? "Set 2 ON" : "Set 2 OFF", Name = "pVA2Enabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet21.Click += delegate(object o, RoutedEventArgs e){
				iVA2Enabled = !iVA2Enabled;
				miVASet21.Header  = iVA2Enabled ? "Set 2 ON" : "Set 2 OFF";
				ForceRefresh();
			};
			miVASet2.Items.Add(miVASet21);
			miVASet2.Items.Add(createVA2Menu(iVA2Period.ToString(), iVA2Mode));

			miVASet2.Items.Add(new Separator());

			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", Name="Recalc1"+uID, HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
//				Draw.TextFixed(this, "DataLoadingMsg", "Reclaculating profiles in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			miVASet2.Items.Add(miRecalculate1);

			MenuControl.Items.Add(miVASet2);
			#endregion ---------------------------------
#endif
			#region -- Zones Menu --
			MenuItem miZones = new MenuItem { Header = "Zones", Name="Zones"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miZones1 = new MenuItem { Header = iZonesEnabled ? "Zones ON" : "Zones OFF", Name = "pZonesEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZones1.Click += ZoneMenu_Click;
			miZones.Items.Add(miZones1);

			MenuItem miZones2 = new MenuItem { Header = iShowDemandZones ? "Demand Zones ON" : "Demand Zones OFF", Name = "pShowDemandZones"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZones2.Click += ZoneMenu_Click;
			miZones.Items.Add(miZones2);

			MenuItem miZones3 = new MenuItem { Header = iShowSupplyZones ? "Supply Zones ON" : "Supply Zones OFF", Name = "pShowSupplyZones"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZones3.Click += ZoneMenu_Click;
			miZones.Items.Add(miZones3);

			MenuItem miZones4 = new MenuItem { Header = iShowBrokenZones ? "Broken Zones ON" : "Broken Zones OFF", Name = "pShowBrokenZones"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZones4.Click += ZoneMenu_Click;
			miZones.Items.Add(miZones4);

			MenuItem miZones5 = new MenuItem { Header = iShowFreshZones ? "Fresh Zones ON" : "Fresh Zones OFF", Name = "pShowFreshZones"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZones5.Click += ZoneMenu_Click;
			miZones.Items.Add(miZones5);

			MenuItem miZones6 = new MenuItem { Header = iShowTestedZones ? "Tested Zones ON" : "Tested Zones OFF", Name = "pShowTestedZones"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZones6.Click += ZoneMenu_Click;
			miZones.Items.Add(miZones6);

			MenuItem miZones7 = new MenuItem { Header = iZonesTSEnabled ? "Tested Shading ON" : "Tested Shading OFF", Name = "pZonesTSEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZones7.Click += ZoneMenu_Click;
			miZones.Items.Add(miZones7);

			MenuItem miZones8 = new MenuItem { Header = iZonesTMEnabled ? "Tested Marker ON" : "Tested Marker OFF", Name = "pZonesTMEnabled"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZones8.Click += ZoneMenu_Click;
			miZones.Items.Add(miZones8);

			MenuItem miZones9 = new MenuItem { Header = iExtendZonesRight ? "Extend Right ON" : "Extend Right OFF", Name = "pExtendZonesRight"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZones9.Click += ZoneMenu_Click;
			miZones.Items.Add(miZones9);

			MenuItem miZones10 = new MenuItem { Header = "Restore All Zones", Name = "RestoreAllZones"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZones10.Click += ZoneItem_Click;
			miZones.Items.Add(miZones10);

			//------------------

//Beta		if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
			if(Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
				MenuControl.Items.Add(miZones);
			#endregion

			#region -- Avg BidSize and AskSize Menu, and Dynamic BlockSize--
//Beta			if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
			if(Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
			{
				var miBigMoneyAvgCalcsMenu = new MenuItem { Header = "Avg BigMoney Bids/Asks", Name="BigMoneyAvgCalcsMenu"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
				miBigMoneyAvgCalcsMenu.Items.Add(
					miBigMoneyAvgAsk = new MenuItem { Header = "Avg Ask: N/A", Name = "avgBigMoneyAsk"+uID, Foreground = Brushes.Black, IsEnabled=false, FontStyle=FontStyles.Italic }
				);

				miBigMoneyAvgCalcsMenu.Items.Add(
					miBigMoneyAvgBid = new MenuItem { Header = "Avg Bid: N/A", Name = "avgBigMoneyBid"+uID, Foreground = Brushes.Black, IsEnabled=false, FontStyle=FontStyles.Italic }
				);//miBigMoneyAvgAsk.
				MenuControl.Items.Add(miBigMoneyAvgCalcsMenu);

				var miDynBlockCalcsMenu = new MenuItem { Header = "Avg Dynamic Block", Name="DynBlockCalcsMenu"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
				miDynBlockCalcsMenu.Items.Add(
					miDynamicBlockAvgCalc = new MenuItem { Name="DynBlockAvgCalc"+uID, Header = string.Format("{0} :Avg Dynamic Block\n- - -\n{1} :percentile", (AvgDynamicBlock<=0 ? "N/A":AvgDynamicBlock.ToString("0")), this.pDynBlockSizePercentile.ToString("0.0%").Replace(".0%","%")), Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsEnabled=false, FontStyle=FontStyles.Italic }
				);
				MenuControl.Items.Add(miDynBlockCalcsMenu);
			}
			//------------------

            #endregion

			#region -- Avg Stop Loss Calculators Menu --
			MenuItem miAvgStopCalcs = new MenuItem { Header = "Avg Stop Loss Calculators", Name="AvgStopCalcs"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			miAvgStopCalcs.Items.Add(miAvgStopFirstTouch = new MenuItem { Header = "First Touch: N/A", Name = "avgStopFirstTouch"+uID, Foreground = Brushes.Black, IsEnabled=false, FontStyle=FontStyles.Italic });

			//------------------

//Beta		if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
			if(Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
				MenuControl.Items.Add(miAvgStopCalcs);
            #endregion

            #region -- Signals Settings --
            var miSignalSettingsMenu = new MenuItem { Header = "Signal Settings", Name="SignalSettingsMenu"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
            var miEnableLongs = new MenuItem { Header = (iLongsEnabled ? "Show LONG signals ON" : "Show LONG signals OFF"), Name="EnableLongs"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miEnableLongs.Click += delegate (object o, RoutedEventArgs e) {
                iLongsEnabled = !iLongsEnabled;
                miEnableLongs.Header = (iLongsEnabled ? "Show LONG signals ON" : "Show LONG signals OFF");
                ForceRefresh();
            };
            miSignalSettingsMenu.Items.Add(miEnableLongs);

            var miEnableShorts = new MenuItem { Header = (iShortsEnabled ? "Show SHORT signals ON" : "Show SHORT signals OFF"), Name="EnableShorts"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
            miEnableShorts.Click += delegate (object o, RoutedEventArgs e) {
                iShortsEnabled = !iShortsEnabled;
                miEnableShorts.Header = (iShortsEnabled ? "Show SHORT signals ON" : "Show SHORT signals OFF");
                ForceRefresh();
            };
            miSignalSettingsMenu.Items.Add(miEnableShorts);

//Beta		if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
			if(Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
				MenuControl.Items.Add(miSignalSettingsMenu);
            #endregion
            //----------------------------------------------------------------------------------------------
            #region -- Delta Spread Analysis --
            var miDeltaSpreadAnalysisMenu = new MenuItem { Header = "Delta Spread Analysis", Name="DeltaSpreadAnalysisMenu"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal  };
//----------------------------------------------------------------------------------------------
			miShow_DSASignal = new MenuItem { Header = (pShow_DSASignal ? "Hide signals":"Show signals"), Name="DSAignal"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
			miShow_DSASignal.Click += delegate (object o, RoutedEventArgs e){
				pShow_DSASignal = !pShow_DSASignal;
				miShow_DSASignal.Header = (pShow_DSASignal ? "Hide signals":"Show signals");
				ForceRefresh();
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miShow_DSASignal);
//----------------------------------------------------------------------------------------------
			var hdr = "Signal sensitivity: ";
			miDSA_Sensitivity = new MenuItem { Header = hdr+pDSA_Sensitivity.ToString(), Name="DSA_Sensitivity"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true  };
			miDSA_Sensitivity.Click += delegate (object o, RoutedEventArgs e){
				if(pDSA_Sensitivity < 10) this.pDSA_Sensitivity++; else pDSA_Sensitivity = 1;
				miDSA_Sensitivity.Header = hdr+pDSA_Sensitivity.ToString();
				ForceRefresh();
			};
			miDSA_Sensitivity.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if(pDSA_Sensitivity < 10) this.pDSA_Sensitivity++;
				}else{
					if(pDSA_Sensitivity >1) this.pDSA_Sensitivity--;
				}
				miDSA_Sensitivity.Header = hdr+pDSA_Sensitivity.ToString();
				ForceRefresh();
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miDSA_Sensitivity);
//----------------------------------------------------------------------------------------------
			var hdr1 = "Op. on price bar: ";
			miDSA_OpacityOnBar = new MenuItem { Header = hdr1+pDSA_OpacityOnPriceBar.ToString(), Name="DSA_Opacity"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true  };
			miDSA_OpacityOnBar.Click += delegate (object o, RoutedEventArgs e){
				if(pDSA_OpacityOnPriceBar <= 90) this.pDSA_OpacityOnPriceBar+= 10; else pDSA_OpacityOnPriceBar = 0;
				miDSA_OpacityOnBar.Header = hdr1+pDSA_OpacityOnPriceBar.ToString();
				ForceRefresh();
			};
			miDSA_OpacityOnBar.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if(pDSA_OpacityOnPriceBar < 100) this.pDSA_OpacityOnPriceBar++;
				}else{
					if(pDSA_OpacityOnPriceBar >1) this.pDSA_OpacityOnPriceBar--;
				}
				miDSA_OpacityOnBar.Header = hdr1+pDSA_OpacityOnPriceBar.ToString();
				ForceRefresh();
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miDSA_OpacityOnBar);
//----------------------------------------------------------------------------------------------
			var hdr2 = "Op. on heat map: ";
			miDSA_OpacityOnHeatMapHisto = new MenuItem { Header = hdr2+pDSA_OpacityOnHeatMap.ToString(), Name="OpacityOnHeatMapHisto"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true  };
			miDSA_OpacityOnHeatMapHisto.Click += delegate (object o, RoutedEventArgs e){
				if(pDSA_OpacityOnHeatMap <= 90) this.pDSA_OpacityOnHeatMap+= 10; else pDSA_OpacityOnHeatMap = 0;
				miDSA_OpacityOnHeatMapHisto.Header = hdr2+pDSA_OpacityOnHeatMap.ToString();
				ForceRefresh();
			};
			miDSA_OpacityOnHeatMapHisto.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if(pDSA_OpacityOnHeatMap < 100) this.pDSA_OpacityOnHeatMap++;
				}else{
					if(pDSA_OpacityOnHeatMap >1) this.pDSA_OpacityOnHeatMap--;
				}
				miDSA_OpacityOnHeatMapHisto.Header = hdr2+pDSA_OpacityOnHeatMap.ToString();
				ForceRefresh();
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miDSA_OpacityOnHeatMapHisto);
			
//----------------------------------------------------------------------------------------------
			var hdr3 = "Outline width Heat Map: ";
			miDSA_OutlineWidthOnHeatMapHisto = new MenuItem { Header = hdr3+pDSA_HistoOutlineThickness.ToString(), Name="DSA_OutlineWidthOnHeatMapHisto"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true  };
			miDSA_OutlineWidthOnHeatMapHisto.Click += delegate (object o, RoutedEventArgs e){
				if(pDSA_HistoOutlineThickness <= 10) this.pDSA_HistoOutlineThickness+= 10; else pDSA_HistoOutlineThickness = 0;
				miDSA_OutlineWidthOnHeatMapHisto.Header = hdr3+pDSA_HistoOutlineThickness.ToString();
				ForceRefresh();
			};
			miDSA_OutlineWidthOnHeatMapHisto.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if(pDSA_HistoOutlineThickness < 9) this.pDSA_HistoOutlineThickness++;
				}else{
					if(pDSA_HistoOutlineThickness > 1) this.pDSA_HistoOutlineThickness--;
				}
				miDSA_OutlineWidthOnHeatMapHisto.Header = hdr3+pDSA_HistoOutlineThickness.ToString();
				ForceRefresh();
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miDSA_OutlineWidthOnHeatMapHisto);

//----------------------------------------------------------------------------------------------
			#endregion
//Beta		if (iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
			if(Bars.IsTickReplay || iPCalcM == ARC_PrintProfiler_DataBasis.Tick1)
				MenuControl.Items.Add(miDeltaSpreadAnalysisMenu);

			indytoolbar.Children.Add(MenuControlContainer);
        }

        #endregion

        private void Combo_KeyDown(object sender, KeyEventArgs e) { e.Handled = true; }

        #region private void Combo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        private void Combo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
//#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
            iVA1Mode = ((ComboBoxItem)VA1Combo.SelectedItem).Content.ToString();
            iVA2Mode = ((ComboBoxItem)VA2Combo.SelectedItem).Content.ToString();
//#endif
            iCompositeType = ((ComboBoxItem)CompTypeCombo.SelectedItem).Content.ToString();
            nudPCS1.IsEnabled = iCompositeType != "Day";
            nudPCS2.IsEnabled = iCompositeType != "Day";
            nudPCS3.IsEnabled = iCompositeType != "Day";
        }
        #endregion

        #region private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtSender = sender as TextBox;

            int keyVal = (int)e.Key;
            int value = -1;
            if (keyVal >= (int)Key.D0 && keyVal <= (int)Key.D9) value = keyVal - (int)Key.D0;
            else if (keyVal >= (int)Key.NumPad0 && keyVal <= (int)Key.NumPad9) value = keyVal - (int)Key.NumPad0;

            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);

            if (isNumeric || e.Key == Key.Back)
            {
                string newText = value != -1 ? value.ToString() : "";
                int tbPosition = txtSender.SelectionStart;
                txtSender.Text = txtSender.SelectedText == "" ? txtSender.Text.Insert(tbPosition, newText) : txtSender.Text.Replace(txtSender.SelectedText, newText);
                txtSender.Select(tbPosition + 1, 0);
	            if (txtSender.Name.Contains("VA1period")){
					this.iVA1Period = this.IntParseFast(txtSender.Text);
					InformUserAboutRecalculation();
				}
	            if (txtSender.Name.Contains("VA2period")){
					this.iVA2Period = this.IntParseFast(txtSender.Text);
					InformUserAboutRecalculation();
				}
            }
        }
        #endregion

        #region private void NumericUpDownValueChanged(object TextChangedEventArgs, EventArgs e) 
        private void NumericUpDownValueChanged(object sender, TextChangedEventArgs e)
        {
            //update CP NUD values with Min/Max verif
            int nudPCS1i = Math.Min(23, Math.Max(0, IntParseFast(nudPCS1.Text)));
            nudPCS1.Text = nudPCS1i.ToString();
            int nudPCS2i = Math.Min(59, Math.Max(0, IntParseFast(nudPCS2.Text)));
            nudPCS2.Text = nudPCS2i.ToString();
            int nudPCS3i = Math.Min(1440, Math.Max(1, IntParseFast(nudPCS3.Text)));
            nudPCS3.Text = nudPCS3i.ToString();
            iResetTime = new TimeSpan(nudPCS1i, nudPCS2i, 0);
            iResetMinutes = nudPCS3i;

            //update VA NUD values with Min/Max verif
//#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
            iVA1Period = Math.Min(99999, Math.Max(1, IntParseFast(nudVA1.Text)));
            nudVA1.Text = iVA1Period.ToString();
            iVA2Period = Math.Min(99999, Math.Max(1, IntParseFast(nudVA2.Text)));
            nudVA2.Text = iVA2Period.ToString();
			InformUserAboutRecalculation();
//#endif
        }
        #endregion

        #region private void cmdupdw_Click(object sender, RoutedEventArgs e)
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
            Button cmd = sender as Button;
            if (cmd.Name.Contains("CRV1cmdup")) nudCRV1.Text = (Math.Min(99999, IntParseFast(nudCRV1.Text) + 1)).ToString();
            else if (cmd.Name.Contains("CRV1cmddw")) nudCRV1.Text = (Math.Max(1, IntParseFast(nudCRV1.Text) - 1)).ToString();
            else if (cmd.Name.Contains("CRV2cmdup")) nudCRV2.Text = (Math.Min(99999, IntParseFast(nudCRV2.Text) + 1)).ToString();
            else if (cmd.Name.Contains("CRV2cmddw")) nudCRV2.Text = (Math.Max(1, IntParseFast(nudCRV2.Text) - 1)).ToString();

            else if (cmd.Name.Contains("MST1cmdup")) nudMST1.Text = (Math.Min(99999, IntParseFast(nudMST1.Text) + 1)).ToString();
            else if (cmd.Name.Contains("MST1cmddw")) nudMST1.Text = (Math.Max(0, IntParseFast(nudMST1.Text) - 1)).ToString();
            else if (cmd.Name.Contains("MST2cmdup")) nudMST2.Text = (Math.Min(99999, IntParseFast(nudMST2.Text) + 1)).ToString();
            else if (cmd.Name.Contains("MST2cmddw")) nudMST2.Text = (Math.Max(1, IntParseFast(nudMST2.Text) - 1)).ToString();

            else if (cmd.Name.Contains("CPS1cmdup") && iCompositeType != "Day") nudPCS1.Text = (Math.Min(23, IntParseFast(nudPCS1.Text)) + 1).ToString();
            else if (cmd.Name.Contains("CPS1cmddw") && iCompositeType != "Day") nudPCS1.Text = (Math.Max(0, IntParseFast(nudPCS1.Text) - 1)).ToString();
            else if (cmd.Name.Contains("CPS2cmdup") && iCompositeType != "Day") nudPCS2.Text = (Math.Min(59, IntParseFast(nudPCS2.Text)) + 1).ToString();
            else if (cmd.Name.Contains("CPS2cmddw") && iCompositeType != "Day") nudPCS2.Text = (Math.Max(0, IntParseFast(nudPCS2.Text) - 1)).ToString();
            else if (cmd.Name.Contains("CPS3cmdup") && iCompositeType != "Day") nudPCS3.Text = (Math.Min(1440, IntParseFast(nudPCS3.Text)) + 1).ToString();
            else if (cmd.Name.Contains("CPS3cmddw") && iCompositeType != "Day") nudPCS3.Text = (Math.Max(1, IntParseFast(nudPCS3.Text) - 1)).ToString();

            else if (cmd.Name.Contains("VA1periodcmdup")) {
				this.iVA1Period++;
				nudVA1.Text = Math.Min(99999, iVA1Period).ToString();
				InformUserAboutRecalculation();
			}
            else if (cmd.Name.Contains("VA1periodcmddw")) {
				iVA1Period--;
				nudVA1.Text = Math.Max(1, iVA1Period).ToString();
				InformUserAboutRecalculation();
			}
            else if (cmd.Name.Contains("VA2periodcmdup")) {
				iVA2Period++;
				nudVA2.Text = Math.Min(99999, iVA2Period).ToString();
				InformUserAboutRecalculation();
			}
            else if (cmd.Name.Contains("VA2periodcmddw")) {
				iVA2Period--;
				nudVA2.Text = Math.Max(1, iVA2Period).ToString();
				InformUserAboutRecalculation();
			}
        }
        #endregion

        #region private void MenuItemF5_Click(object sender, EventArgs e)
        private void MenuItemF5_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            System.Windows.Forms.SendKeys.SendWait("{F5}");
        }
        #endregion

        #region private void PrintMenu_Click(object sender, EventArgs e)
        private void PrintMenu_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- pPrintEnabled --
            if (item.Name.Contains("pPrintEnabled"))
            {
                //if (iPCalcM != ARC_PrintProfiler_DataBasis.Tick1) return;

                if (item.Header.ToString().Contains("ON"))
                {
                    iPrintEnabled = false;
                    item.Header = "Print OFF";
                }
                else
                {
                    iPrintEnabled = true;
                    item.Header = "Print ON";
                }
            }
            #endregion

            #region -- pCurrentBarEnabled --
            else if (item.Name.Contains("pCurrentBarEnabled"))
            {
//                if (iPCalcM != ARC_PrintProfiler_DataBasis.Tick1) return;

                if (item.Header.ToString().Contains("ON"))
                {
                    iCurrentBarEnabled = false;
                    item.Header = "Current Bar OFF";
                }
                else
                {
                    iCurrentBarEnabled = true;
                    item.Header = "Current Bar ON";
                }
            }
            #endregion

            #region -- pShowVolAtPrice --
            else if (item.Name.Contains("pShowVolAtPrice"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowVolAtPrice = false;
                    item.Header = "Volume Numbers OFF";
                }
                else
                {
                    iShowVolAtPrice = true;
                    item.Header = "Volume Numbers ON";
                }
            }
            #endregion

            #region -- pShowTotVolumeInHeatMap --
            else if (item.Name.Contains("pShowTotVolumeInHeatMap"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowTotalVolumeInHeatMap = false;
                    item.Header = "Tot Vol OFF";
                }
                else
                {
                    iShowTotalVolumeInHeatMap = true;
                    item.Header = "Tot Vol ON";
                }
            }
            #endregion

            #region -- pShowTotVolAsPct --
            else if (item.Name.Contains("pShowTotVolAsPct"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowTotalVolumeAsPct = false;
                    item.Header = "Tot Vol% OFF";
                }
                else
                {
                    iShowTotalVolumeAsPct = true;
                    item.Header = "Tot Vol% ON";
                }
            }
            #endregion
			
            #region -- pShowNetDeltaHeatMap --
            else if (item.Name.Contains("pShowNetDeltaHeatMap"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowNetDeltaHeatMap = false;
                    item.Header = "HeatMap OFF";
                }
                else
                {
                    iShowNetDeltaHeatMap = true;
                    item.Header = "HeatMap ON";
                }
            }
            #endregion

            #region -- pShowNetDelta --
            else if (item.Name.Contains("pShowNetDelta"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowNetDelta = false;
                    item.Header = "Net Delta OFF";
                }
                else
                {
                    iShowNetDelta = true;
                    item.Header = "Net Delta ON";
                }
            }
            #endregion

            #region -- pUseSkinnyHeatmapBars --
            else if (item.Name.Contains("pUseSkinnyHeatmapBars"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    pUseSkinnyHeatmapBars = false;
                    item.Header = "Skinny Histo OFF";
                }
                else
                {
                    pUseSkinnyHeatmapBars = true;
                    item.Header = "Skinny Histo ON";
                }
            }
            #endregion

            #region -- pShowImbalance --
            else if (item.Name.Contains("pShowImbalanceOnOff"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowImbalance = false;
                    item.Header = "Bid/Ask Imbalances OFF";
                }
                else
                {
                    iShowImbalance = true;
                    item.Header = "Bid/Ask Imbalances ON";
                }
            }
            #endregion

            #region -- pShowImbalanceDots --
            else if (item.Name.Contains("pShowImbalanceDots"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowImbalanceA = false;
                    item.Header = "Bid/Ask Imbalances Dots OFF";
                }
                else
                {
                    iShowImbalanceA = true;
                    item.Header = "Bid/Ask Imbalances Dots ON";
                }
            }
            #endregion

            #region -- pShowImbalanceText --
            else if (item.Name.Contains("pShowImbalanceText"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowImbalanceText = false;
                    item.Header = "Bid/Ask Imbalances Text OFF";
                }
                else
                {
                    iShowImbalanceText = true;
                    item.Header = "Bid/Ask Imbalances Text ON";
                }
            }
            #endregion

            #region -- pShowBlocks --
            else if (item.Name.Contains("pShowBlocks"))
            {
                if (pShow_Blocks)
                {
                    pShow_Blocks = false;
                    item.Header = "Block Trades OFF";
                }
                else
                {
                    pShow_Blocks = true;
                    item.Header = "Block Trades ON";
                }
            }
            #endregion

            #region -- pTTEnabled --
            else if (item.Name.Contains("pTTEnabled"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    pShow_TTSignal = false;
                    item.Header = "Trapped Trader OFF";
					if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                }
                else
                {
                    pShow_TTSignal = true;
                    item.Header = "Trapped Trader ON";
					if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                }
            }
            #endregion

            #region -- pDDEnabled --
            else if (item.Name.Contains("pDDEnabled"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    pShow_DDSignal = false;
                    item.Header = "Delta Divergence OFF";
					if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                }
                else
                {
                    pShow_DDSignal = true;
                    item.Header = "Delta Divergence ON";
					if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                }
            }
            #endregion

            #region -- pCCEnabled --
            else if (item.Name.Contains("pCCEnabled"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    pShow_CCSignal = false;
                    item.Header = "Combined Signal OFF";
					if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                }
                else
                {
                    pShow_CCSignal = true;
                    item.Header = "Combined Signal ON";
					if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                }
            }
            #endregion
			ForceRefresh();
        }
        #endregion

        #region private void ProBarMenu_Click(object sender, EventArgs e)
        private void ProBarMenu_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- pBarCompositeEnabled --
            if (item.Name.Contains("pBarCompositeEnabled"))
            {
                //if (iPCalcM != ARC_PrintProfiler_DataBasis.Tick1) return;

                if (item.Header.ToString().Contains("ON"))
                {
                    iBarCompositeEnabled = false;
                    item.Header = "Profile (Bar) OFF";
                }
                else
                {
                    iBarCompositeEnabled = true;
                    item.Header = "Profile (Bar) ON";
                }
            }
            #endregion

            #region -- pDisplayPOC --
            else if (item.Name.Contains("pDisplayPOC"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iDisplayPOC = false;
                    item.Header = "POC OFF";
                }
                else
                {
                    iDisplayPOC = true;
                    item.Header = "POC ON";
                }
            }
            #endregion

            #region -- pDisplayVA --
            else if (item.Name.Contains("pDisplayVA"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iDisplayVA = false;
                    item.Header = "VAH / VAL OFF";
                }
                else
                {
                    iDisplayVA = true;
                    item.Header = "VAH / VAL ON";
                }
            }
            #endregion

            #region -- pDisplayVWAP --
            else if (item.Name.Contains("pDisplayVWAP"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iDisplayVWAP = false;
                    item.Header = "VWAP OFF";
                }
                else
                {
                    iDisplayVWAP = true;
                    item.Header = "VWAP ON";
                }
            }
            #endregion

            #region -- pDisplayCL --
            else if (item.Name.Contains("pDisplayCL"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iDisplayCL = false;
                    item.Header = "Cluster OFF";
                }
                else
                {
                    iDisplayCL = true;
                    item.Header = "Cluster ON";
                }
            }
            #endregion

            #region -- pShow_VDSignal --
            else if (item.Name.Contains("pVDSignal"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    pShow_VDSignal = false;
                    item.Header = "Volume Divergence OFF";
					if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                }
                else
                {
                    pShow_VDSignal = true;
                    item.Header = "Volume Divergence ON";
					if(pEnableChartMarkers) HandleRedrawOfChartMarkers();
                }
            }
            #endregion

			ForceRefresh();
        }
        #endregion

        #region private void ProCompVisualMenu_Click(object sender, EventArgs e)
        private void ProCompVisualMenu_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- pCompositeEnabled --
            if (item.Name.Contains("pCompositeEnabled"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompositeEnabled = false;
                    item.Header = "Profile (Composite) OFF";
					miProBarCompProfRecalc.IsEnabled = false;
					CompositeProfiles.Clear();
					miProBarCompProfRecalc.IsEnabled = true;
                }
                else
                {
                    iCompositeEnabled = true;
                    item.Header = "Profile (Composite) ON";
					miProBarCompProfRecalc.IsEnabled = false;
                }
            }
            #endregion

            #region -- pCPDisplay --
            else if (item.Name.Contains("pCPDisplay"))
            {
                iCPDisplay = item.Header.ToString().Contains("Histogram") ? "Shape" : "Histogram";
                item.Header = string.Format("Display Mode {0}", iCPDisplay);
            }
            #endregion

            #region -- pCPONTOP --
            else if (item.Name.Contains("pCPONTOP"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCPONTOP = false;
                    item.Header = "Draw On Top OFF";
                }
                else
                {
                    iCPONTOP = true;
                    item.Header = "Draw On Top ON";
                }
            }
            #endregion

            #region -- pCCompositeEnabled --
            else if (item.Name.Contains("pCCompositeEnabled"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCCompositeEnabled = false;
                    item.Header = "Current Profile OFF";
                }
                else
                {
                    iCCompositeEnabled = true;
                    item.Header = "Current Profile ON";
                }
            }
            #endregion

            #region -- pCompositeProfileHD --
            else if (item.Name.Contains("pCompositeProfileHD"))
            {
                iCompositeProfileHD = item.Header.ToString().Contains("LEFT") ? "Right" : "Left";
                item.Header = string.Format("Current Profile {0}", iCompositeProfileHD.ToUpper());
            }
            #endregion

            #region -- pHCompositeEnabled --
            else if (item.Name.Contains("pHCompositeEnabled"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iHCompositeEnabled = false;
                    item.Header = "Historical Profiles OFF";
                }
                else
                {
                    iHCompositeEnabled = true;
                    item.Header = "Historical Profiles ON";
                }
            }
            #endregion

            #region -- pDrawCText --
            else if (item.Name.Contains("pDrawCText"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iDrawCText = false;
                    item.Header = "Volume Numbers OFF";
                }
                else
                {
                    iDrawCText = true;
                    item.Header = "Volume Numbers ON";
                }
            }
            #endregion

            #region -- pCompLineLabels --
            else if (item.Name.Contains("pCompLineLabels"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompLineLabels = false;
                    item.Header = "Level Labels OFF";
                }
                else
                {
                    iCompLineLabels = true;
                    item.Header = "Level Labels ON";
                }
            }
            #endregion

            #region -- pCompLineExtend --
            else if (item.Name.Contains("pCompLineExtend"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompLineExtend = false;
                    item.Header = "Level Extend OFF";
                }
                else
                {
                    iCompLineExtend = true;
                    item.Header = "Level Extend ON";
                }
            }
            #endregion

            /*#region -- pCompCwap --
            else if (item.Name.Contains("pCompCwap")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowCwapComposite = false;
                    item.Header = "CWAP OFF";
                }
                else
                {
                    iShowCwapComposite = true;
                    item.Header = "CWAP ON";
                }
            }
            #endregion*/

			ForceRefresh();
        }
        #endregion

        #region private void ProCompDevMenu_Click(object sender, EventArgs e)
        private void ProCompDevMenu_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- pCompDevLevel --
            if (item.Name.Contains("pCompDevLevel"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompDevLevel = false;
                    item.Header = "Developing Levels OFF";
                }
                else
                {
                    iCompDevLevel = true;
                    item.Header = "Developing Levels ON";
                }
            }
            #endregion

            #region -- pCompDevCLevel --
            else if (item.Name.Contains("pCompDevCLevel"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompDevCLevel = false;
                    item.Header = "Current Levels OFF";
                }
                else
                {
                    iCompDevCLevel = true;
                    item.Header = "Current Levels ON";
                }
            }
            #endregion

            #region -- pCompDevHLevel --
            else if (item.Name.Contains("pCompDevHLevel"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompDevHLevel = false;
                    item.Header = "Historical Levels OFF";
                }
                else
                {
                    iCompDevHLevel = true;
                    item.Header = "Historical Levels ON";
                }
            }
            #endregion

            #region -- pCompDevLevelArea --
            else if (item.Name.Contains("pCompDevLevelArea"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompDevLevelArea = false;
                    item.Header = "Fill Area OFF";
                }
                else
                {
                    iCompDevLevelArea = true;
                    item.Header = "Fill Area ON";
                }
            }
            #endregion

            #region -- pCompDevPOC --
            else if (item.Name.Contains("pCompDevPOC"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompDevPOC = false;
                    item.Header = "POC OFF";
                }
                else
                {
                    iCompDevPOC = true;
                    item.Header = "POC ON";
                }
            }
            #endregion

            #region -- pCompDevVWAP --
            else if (item.Name.Contains("pCompDevVWAP"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompDevVWAP = false;
                    item.Header = "VWAP OFF";
                }
                else
                {
                    iCompDevVWAP = true;
                    item.Header = "VWAP ON";
                }
            }
            #endregion

            #region -- pCompDevVA --
            else if (item.Name.Contains("pCompDevVA"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompDevVA = false;
                    item.Header = "Value Area OFF";
                }
                else
                {
                    iCompDevVA = true;
                    item.Header = "Value Area ON";
                }
            }
            #endregion

            #region -- pCompDevEX --
            else if (item.Name.Contains("pCompDevEX"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iCompDevEX = false;
                    item.Header = "Extreme Area OFF";
                }
                else
                {
                    iCompDevEX = true;
                    item.Header = "Extreme Area ON";
                }
            }
            #endregion

			ForceRefresh();
        }
        #endregion

        #region private void ProManual_Click(object sender, EventArgs e)
        private const int DRAWINGTOOLS_INDEX = 3;
        private const string STAYINDRAWMODE_HEADER = "Stay In Draw Mode";
        private const string RECTANGLE_HEADER = "Rectangle";
        private void ProManual_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- pMPDisplay --
            if (item.Name.Contains("pMPDisplay"))
            {
                iMPDisplay = item.Header.ToString().Contains("Histogram") ? "Shape" : "Histogram";
                item.Header = string.Format("Display Mode {0}", iMPDisplay);
            }
            #endregion

            #region -- pMPONTOP --
            else if (item.Name.Contains("pMPONTOP"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iMPONTOP = false;
                    item.Header = "Draw On Top OFF";
                }
                else
                {
                    iMPONTOP = true;
                    item.Header = "Draw On Top ON";
                }
            }
            #endregion

/*            #region -- pShowCwap --
            else if (item.Name.Contains("pShowCwap")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowCwapManual = false;
                    item.Header = "CWAP OFF";
                }
                else
                {
                    iShowCwapManual = true;
                    item.Header = "CWAP ON";
                }
            }
            #endregion*/

            #region -- pMPLabels --
            else if (item.Name.Contains("pMPLabels"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iMPLabels = false;
                    item.Header = "Level Labels OFF";
                }
                else
                {
                    iMPLabels = true;
                    item.Header = "Level Labels ON";
                }
            }
            #endregion

            else if (item.Name.Contains("DrawOneProfile") || item.Name.Contains("DrawMultipleProfiles"))
            {
                ChartControl.Properties.SnapMode = SnapMode.Bar;//SnapMode.BarAndPrice;
                if (item.Name.Contains("DrawMultipleProfiles") && !ChartControl.IsStayInDrawMode) ChartDrawingToolCommands.ToggleStayInDrawMode.Execute(this);
                else if (item.Name.Contains("DrawOneProfile") && ChartControl.IsStayInDrawMode) ChartDrawingToolCommands.ToggleStayInDrawMode.Execute(this);
                MakeRectanglesList();
                AddNextRectangle = true;
                ChartDrawingToolCommands.Rectangle.Execute(this);
                return;
            }

			ForceRefresh();
        }
        #endregion

        #region private void VASet1Menu_Click(object sender, EventArgs e)
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
        private void VASet1Menu_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- pVAEnabled --
            if (item.Name.Contains("pVAEnabled"))
            {
//                if (iPCalcM != ARC_PrintProfiler_DataBasis.Tick1) return;

                if (item.Header.ToString().Contains("ON"))
                {
                    iVA1Enabled = false;
                    item.Header = "Set 1 OFF";
                }
                else
                {
                    iVA1Enabled = true;
                    item.Header = "Set 1 ON";
                }
            }
            #endregion

            #region -- pVAEnabled1 --
            else if (item.Name.Contains("pVAEnabled1"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iVA1Enabled1 = false;
                    item.Header = "POC OFF";
                }
                else
                {
                    iVA1Enabled1 = true;
                    item.Header = "POC ON";
                }
            }
            #endregion

            #region -- pVAEnabled2 --
            else if (item.Name.Contains("pVAEnabled2"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iVA1Enabled2 = false;
                    item.Header = "VWAP OFF";
                }
                else
                {
                    iVA1Enabled2 = true;
                    item.Header = "VWAP ON";
                }
            }
            #endregion

            #region -- pVAEnabled3 --
            else if (item.Name.Contains("pVAEnabled3"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iVA1Enabled3 = false;
                    item.Header = "Cluster OFF";
                }
                else
                {
                    iVA1Enabled3 = true;
                    item.Header = "Cluster ON"; ;
                }
            }
            #endregion

			ForceRefresh();
        }
#endif
        #endregion

        #region private void VASet2Menu_Click(object sender, EventArgs e)
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
        private void VASet2Menu_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- pVA2Enabled --
            if (item.Name.Contains("pVA2Enabled"))
            {
//                if (iPCalcM != ARC_PrintProfiler_DataBasis.Tick1) return;

                if (item.Header.ToString().Contains("ON"))
                {
                    iVA2Enabled = false;
                    item.Header = "Set 2 OFF";
                }
                else
                {
                    iVA2Enabled = true;
                    item.Header = "Set 2 ON";
                }
            }
            #endregion

            #region -- pVA2Enabled1 --
            else if (item.Name.Contains("pVA2Enabled1"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iVA2Enabled1 = false;
                    item.Header = "POC OFF";
                }
                else
                {
                    iVA2Enabled1 = true;
                    item.Header = "POC ON";
                }
            }
            #endregion

            #region -- pVA2Enabled2 --
            else if (item.Name.Contains("pVA2Enabled2"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iVA2Enabled2 = false;
                    item.Header = "VWAP OFF";
                }
                else
                {
                    iVA2Enabled2 = true;
                    item.Header = "VWAP ON";
                }
            }
            #endregion

            #region -- pVA2Enabled3 --
            else if (item.Name.Contains("pVA2Enabled3"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iVA2Enabled3 = false;
                    item.Header = "Cluster OFF";
                }
                else
                {
                    iVA2Enabled3 = true;
                    item.Header = "Cluster ON";
                }
            }
            #endregion

			ForceRefresh();
        }
#endif
        #endregion

        #region private void ZoneMenu_Click(object sender, EventArgs e)
        private void ZoneMenu_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- pZonesEnabled --
            if (item.Name.Contains("pZonesEnabled"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iZonesEnabled = false;
                    item.Header = "Zones OFF";
                }
                else
                {
                    iZonesEnabled = true;
                    item.Header = "Zones ON";
                }
            }
            #endregion

            #region -- pShowDemandZones --
            else if (item.Name.Contains("pShowDemandZones"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowDemandZones = false;
                    item.Header = "Demand Zones OFF";
                }
                else
                {
                    iShowDemandZones = true;
                    item.Header = "Demand Zones ON";
                }
            }
            #endregion

            #region -- pShowSupplyZones --
            else if (item.Name.Contains("pShowSupplyZones"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowSupplyZones = false;
                    item.Header = "Supply Zones OFF";
                }
                else
                {
                    iShowSupplyZones = true;
                    item.Header = "Supply Zones ON";
                }
            }
            #endregion

            #region -- pShowBrokenZones --
            else if (item.Name.Contains("pShowBrokenZones"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowBrokenZones = false;
                    item.Header = "Broken Zones OFF";
                }
                else
                {
                    iShowBrokenZones = true;
                    item.Header = "Broken Zones ON";
                }
            }
            #endregion

            #region -- pShowFreshZones --
            else if (item.Name.Contains("pShowFreshZones"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowFreshZones = false;
                    item.Header = "Fresh Zones OFF";
                }
                else
                {
                    iShowFreshZones = true;
                    item.Header = "Fresh Zones ON";
                }
            }
            #endregion

            #region -- pShowTestedZones --
            else if (item.Name.Contains("pShowTestedZones"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iShowTestedZones = false;
                    item.Header = "Tested Zones OFF";
                }
                else
                {
                    iShowTestedZones = true;
                    item.Header = "Tested Zones ON";
                }
            }
            #endregion

            #region -- pZonesTSEnabled --
            else if (item.Name.Contains("pZonesTSEnabled"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iZonesTSEnabled = false;
                    item.Header = "Tested Shading OFF";
                }
                else
                {
                    iZonesTSEnabled = true;
                    item.Header = "Tested Shading ON";
                }
            }
            #endregion

            #region -- pZonesTMEnabled --
            else if (item.Name.Contains("pZonesTMEnabled"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iZonesTMEnabled = false;
                    item.Header = "Tested Marker OFF";
                }
                else
                {
                    iZonesTMEnabled = true;
                    item.Header = "Tested Marker ON";
                }
            }
            #endregion

            #region -- pExtendZonesRight --
            else if (item.Name.Contains("pExtendZonesRight"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iExtendZonesRight = false;
                    item.Header = "Extend Right OFF";
                }
                else
                {
                    iExtendZonesRight = true;
                    item.Header = "Extend Right ON";
                }
            }

            #endregion

			ForceRefresh();
        }
        #endregion

        #region private void ZoneItem_Click(object sender, EventArgs e)
        private void ZoneItem_Click(object sender, EventArgs e)
        {
            foreach (KeyValuePair<int, List<Zone>> DZ in SupplyZones)
            {
                foreach (Zone ZS in DZ.Value) ZS.IsHidden = false;
            }
            foreach (KeyValuePair<int, List<Zone>> DZ in DemandZones)
            {
                foreach (Zone ZS in DZ.Value) ZS.IsHidden = false;
            }
			ForceRefresh();
        }
        #endregion

        #region private void Inventory_Click(object sender, EventArgs e)
        private void Inventory_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- pInventoryEnabled --
            if (item.Name.Contains("pInventoryEnabled"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    iInventoryEnabled = false;
                    item.Header = "Inventory OFF";
                }
                else
                {
                    iInventoryEnabled = true;
                    item.Header = "Inventory ON";
                }
            }
            #endregion

			ForceRefresh();
        }
        #endregion

        #region -- Custom Grid to Build NUDControl (not WPF native) --
        private Grid createCRVMenu(string nudValue1, string nudValue2)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - CRV1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Defiance ATR % : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudCRV1 = new TextBox() { Name = string.Format("CRV1txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudCRV1.Text = nudValue1;
            nudCRV1.KeyDown += menuTxtbox_KeyDown;
            nudCRV1.TextChanged += NumericUpDownValueChanged;
            nudCRV1.SetValue(Grid.ColumnProperty, 1);
            nudCRV1.SetValue(Grid.RowProperty, 0);
            nudCRV1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("CRV1cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("CRV1cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);

            //line 2 - CRV2
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Break H/L ATR % : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudCRV2 = new TextBox() { Name = string.Format("CRV2txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudCRV2.Text = nudValue2;
            nudCRV2.KeyDown += menuTxtbox_KeyDown;
            nudCRV2.TextChanged += NumericUpDownValueChanged;
            nudCRV2.SetValue(Grid.ColumnProperty, 1);
            nudCRV2.SetValue(Grid.RowProperty, 2);
            nudCRV2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = string.Format("CRV2cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = string.Format("CRV2cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 2);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudCRV1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudCRV2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            return grid;
        }
        private Grid createMSTMenu(string nudValue1, string nudValue2)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - MST1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "% ATR : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudMST1 = new TextBox() { Name = string.Format("MST1txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST1.Text = nudValue1;
            nudMST1.KeyDown += menuTxtbox_KeyDown;
            nudMST1.TextChanged += NumericUpDownValueChanged;
            nudMST1.SetValue(Grid.ColumnProperty, 1);
            nudMST1.SetValue(Grid.RowProperty, 0);
            nudMST1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("MST1cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("MST1cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);

            //line 2 - MST2
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Strength : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudMST2 = new TextBox() { Name = string.Format("MST2txtbox{0}",uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST2.Text = nudValue2;
            nudMST2.KeyDown += menuTxtbox_KeyDown;
            nudMST2.TextChanged += NumericUpDownValueChanged;
            nudMST2.SetValue(Grid.ColumnProperty, 1);
            nudMST2.SetValue(Grid.RowProperty, 2);
            nudMST2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = string.Format("MST2cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = string.Format("MST2cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 2);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMST1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudMST2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            return grid;
        }
        private Grid createPCSettingsMenu(string PCtype, string nudValue1, string nudValue2, string nudValue3)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            #region -- line 1 - Combo --
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Type : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);

            CompTypeCombo = new ComboBox { Name = string.Format("CPS1combo{0}", uID), MinWidth = 75 + gCmdup.Width, Width = 75 + gCmdup.Width, MaxWidth = 75 + gCmdup.Width, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            CompTypeCombo.Items.Add(new ComboBoxItem { Content = "Day" });
            CompTypeCombo.Items.Add(new ComboBoxItem { Content = "Time" });
            CompTypeCombo.Text = PCtype;
            CompTypeCombo.KeyDown += Combo_KeyDown;
            CompTypeCombo.SelectionChanged += Combo_SelectionChanged;
            CompTypeCombo.SetValue(Grid.ColumnProperty, 1);
            CompTypeCombo.SetValue(Grid.RowProperty, 0);
            CompTypeCombo.SetValue(Grid.ColumnSpanProperty, 2);
            #endregion

            #region -- line 2 - nud1 --
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Start (Hrs) : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 1);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudPCS1 = new TextBox() { Name = string.Format("PCS1txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudPCS1.Text = nudValue1;
            nudPCS1.KeyDown += menuTxtbox_KeyDown;
            nudPCS1.TextChanged += NumericUpDownValueChanged;
            nudPCS1.SetValue(Grid.ColumnProperty, 1);
            nudPCS1.SetValue(Grid.RowProperty, 1);
            nudPCS1.SetValue(Grid.RowSpanProperty, 2);
            nudPCS1.IsEnabled = iCompositeType != "Day";

            Button cmdup1 = new Button() { Name = string.Format("CPS1cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("CPS1cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 1);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 2);
            #endregion

            #region -- line 3 - nud2 --
            Label lbl3 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Start (M) : " };
            lbl3.SetValue(Grid.ColumnProperty, 0);
            lbl3.SetValue(Grid.RowProperty, 3);
            lbl3.SetValue(Grid.RowSpanProperty, 2);

            nudPCS2 = new TextBox() { Name = string.Format("PCS2txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudPCS2.Text = nudValue2;
            nudPCS2.KeyDown += menuTxtbox_KeyDown;
            nudPCS2.TextChanged += NumericUpDownValueChanged;
            nudPCS2.SetValue(Grid.ColumnProperty, 1);
            nudPCS2.SetValue(Grid.RowProperty, 3);
            nudPCS2.SetValue(Grid.RowSpanProperty, 2);
            nudPCS2.IsEnabled = iCompositeType != "Day";

            Button cmdup2 = new Button() { Name = string.Format("CPS2cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = string.Format("CPS2cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 3);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 4);
            #endregion

            #region -- line 4 - nud3 --
            Label lbl4 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Interval (M) : " };
            lbl4.SetValue(Grid.ColumnProperty, 0);
            lbl4.SetValue(Grid.RowProperty, 5);
            lbl4.SetValue(Grid.RowSpanProperty, 2);

            nudPCS3 = new TextBox() { Name = string.Format("PCS3txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudPCS3.Text = nudValue3;
            nudPCS3.KeyDown += menuTxtbox_KeyDown;
            nudPCS3.TextChanged += NumericUpDownValueChanged;
            nudPCS3.SetValue(Grid.ColumnProperty, 1);
            nudPCS3.SetValue(Grid.RowProperty, 5);
            nudPCS3.SetValue(Grid.RowSpanProperty, 2);
            nudPCS3.IsEnabled = iCompositeType != "Day";

            Button cmdup3 = new Button() { Name = string.Format("CPS3cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw3 = new Button() { Name = string.Format("CPS3cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup3.Click += cmdupdw_Click;
            cmdup3.SetValue(Grid.ColumnProperty, 2);
            cmdup3.SetValue(Grid.RowProperty, 5);
            cmddw3.Click += cmdupdw_Click;
            cmddw3.SetValue(Grid.ColumnProperty, 2);
            cmddw3.SetValue(Grid.RowProperty, 6);
            #endregion

            //Add controls to grid
            grid.Children.Add(lbl1);
            grid.Children.Add(CompTypeCombo);

            grid.Children.Add(lbl2);
            grid.Children.Add(nudPCS1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            grid.Children.Add(lbl3);
            grid.Children.Add(nudPCS2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            grid.Children.Add(lbl4);
            grid.Children.Add(nudPCS3);
            grid.Children.Add(cmdup3);
            grid.Children.Add(cmddw3);

            return grid;
        }
        #endregion

		#region -- CreateVA1 and VA2 menu -- 
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
        private Grid createVA1Menu(string nudValue1, string cbVAtype)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            #region -- line 1 - nud1 --
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Period : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudVA1 = new TextBox() { Name = string.Format("VA1period{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudVA1.Text = nudValue1;
            nudVA1.KeyDown += menuTxtbox_KeyDown;
            nudVA1.TextChanged += NumericUpDownValueChanged;
            nudVA1.SetValue(Grid.ColumnProperty, 1);
            nudVA1.SetValue(Grid.RowProperty, 0);
            nudVA1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("VA1periodcmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("VA1periodcmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);
            #endregion

            #region -- line 2 - Combo --
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Type : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);

            VA1Combo = new ComboBox { Name = string.Format("VA1combo{0}", uID), MinWidth = 75 + gCmdup.Width, Width = 75 + gCmdup.Width, MaxWidth = 75 + gCmdup.Width, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            VA1Combo.Items.Add(new ComboBoxItem { Content = "EMA" });
            VA1Combo.Items.Add(new ComboBoxItem { Content = "SMA" });
            VA1Combo.Text = cbVAtype;
            VA1Combo.KeyDown += Combo_KeyDown;
            VA1Combo.SelectionChanged += Combo_SelectionChanged;
            VA1Combo.SetValue(Grid.ColumnProperty, 1);
            VA1Combo.SetValue(Grid.RowProperty, 2);
            VA1Combo.SetValue(Grid.ColumnSpanProperty, 2);
            #endregion

            //Add controls to grid
            grid.Children.Add(lbl1);
            grid.Children.Add(nudVA1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            grid.Children.Add(lbl2);
            grid.Children.Add(VA1Combo);

            return grid;
        }
        private Grid createVA2Menu(string nudValue1, string cbVAtype)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            #region -- line 1 - nud1 --
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Period : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudVA2 = new TextBox() { Name = string.Format("VA2period{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudVA2.Text = nudValue1;
            nudVA2.KeyDown += menuTxtbox_KeyDown;
            nudVA2.TextChanged += NumericUpDownValueChanged;
            nudVA2.SetValue(Grid.ColumnProperty, 1);
            nudVA2.SetValue(Grid.RowProperty, 0);
            nudVA2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("VA2periodcmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("VA2periodcmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);
            #endregion

            #region -- line 2 - Combo --
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Type : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);

            VA2Combo = new ComboBox { Name = string.Format("VA2combo{0}", uID), MinWidth = 75 + gCmdup.Width, Width = 75 + gCmdup.Width, MaxWidth = 75 + gCmdup.Width, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            VA2Combo.Items.Add(new ComboBoxItem { Content = "EMA" });
            VA2Combo.Items.Add(new ComboBoxItem { Content = "SMA" });
            VA2Combo.Text = cbVAtype;
            VA2Combo.KeyDown += Combo_KeyDown;
            VA2Combo.SelectionChanged += Combo_SelectionChanged;
            VA2Combo.SetValue(Grid.ColumnProperty, 1);
            VA2Combo.SetValue(Grid.RowProperty, 2);
            VA2Combo.SetValue(Grid.ColumnSpanProperty, 2);
            #endregion

            //Add controls to grid
            grid.Children.Add(lbl1);
            grid.Children.Add(nudVA2);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            grid.Children.Add(lbl2);
            grid.Children.Add(VA2Combo);

            return grid;
        }
#else
		private Grid createVA1Menu(string nudValue1, string cbVAtype)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            #region -- line 1 - nud1 --
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Period : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudVA1 = new TextBox() { Name = string.Format("VA1period{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudVA1.Text = nudValue1;
            nudVA1.KeyDown += menuTxtbox_KeyDown;
            nudVA1.TextChanged += NumericUpDownValueChanged;
			nudVA1.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
				int num = iVA1Period + (e.Delta>0 ? 1 : -1);
//Print("num: "+num+"   iVA1Period: "+iVA1Period);
				bool isInRange = num>=1 && num<=500;
				if(isInRange){
					iVA1Period   = num;
					nudVA1.Text = num.ToString("0");
					InformUserAboutRecalculation();
					ForceRefresh();
				}
			};

            nudVA1.SetValue(Grid.ColumnProperty, 1);
            nudVA1.SetValue(Grid.RowProperty, 0);
            nudVA1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("VA1periodcmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("VA1periodcmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);
            #endregion

            #region -- line 2 - Combo --
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Type : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);

            VA1Combo = new ComboBox { Name = string.Format("VA1combo{0}", uID), MinWidth = 75 + gCmdup.Width, Width = 75 + gCmdup.Width, MaxWidth = 75 + gCmdup.Width, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            VA1Combo.Items.Add(new ComboBoxItem { Content = "EMA" });
            VA1Combo.Items.Add(new ComboBoxItem { Content = "SMA" });
            VA1Combo.Text = cbVAtype;
            VA1Combo.KeyDown += Combo_KeyDown;
            VA1Combo.SelectionChanged += Combo_SelectionChanged;
			VA1Combo.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
				if(VA1Combo.Text=="EMA") VA1Combo.Text = "SMA"; else VA1Combo.Text="EMA";
				InformUserAboutRecalculation();
				ForceRefresh();
			};
            VA1Combo.SetValue(Grid.ColumnProperty, 1);
            VA1Combo.SetValue(Grid.RowProperty, 2);
            VA1Combo.SetValue(Grid.ColumnSpanProperty, 2);
            #endregion

            //Add controls to grid
            grid.Children.Add(lbl1);
            grid.Children.Add(nudVA1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            grid.Children.Add(lbl2);
            grid.Children.Add(VA1Combo);

            return grid;
        }
        private Grid createVA2Menu(string nudValue1, string cbVAtype)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            #region -- line 1 - nud1 --
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Period : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudVA2 = new TextBox() { Name = string.Format("VA2period{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudVA2.Text = nudValue1;
            nudVA2.KeyDown += menuTxtbox_KeyDown;
            nudVA2.TextChanged += NumericUpDownValueChanged;
			nudVA2.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
				int num = iVA2Period + (e.Delta>0 ? 1 : -1);
				bool isInRange = num>=1 && num<=500;
				if(isInRange){
					iVA2Period   = num;
					nudVA2.Text = num.ToString("0");
					InformUserAboutRecalculation();
					ForceRefresh();
				}
			};
            nudVA2.SetValue(Grid.ColumnProperty, 1);
            nudVA2.SetValue(Grid.RowProperty, 0);
            nudVA2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("VA2periodcmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("VA2periodcmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);
            #endregion

            #region -- line 2 - Combo --
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Type : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);

            VA2Combo = new ComboBox { Name = string.Format("VA2combo{0}", uID), MinWidth = 75 + gCmdup.Width, Width = 75 + gCmdup.Width, MaxWidth = 75 + gCmdup.Width, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            VA2Combo.Items.Add(new ComboBoxItem { Content = "EMA" });
            VA2Combo.Items.Add(new ComboBoxItem { Content = "SMA" });
            VA2Combo.Text = cbVAtype;
            VA2Combo.KeyDown += Combo_KeyDown;
            VA2Combo.SelectionChanged += Combo_SelectionChanged;
			VA2Combo.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
				if(VA2Combo.Text=="EMA") VA2Combo.Text = "SMA"; else VA2Combo.Text="EMA";
				InformUserAboutRecalculation();
				ForceRefresh();
			};
            VA2Combo.SetValue(Grid.ColumnProperty, 1);
            VA2Combo.SetValue(Grid.RowProperty, 2);
            VA2Combo.SetValue(Grid.ColumnSpanProperty, 2);
            #endregion

            //Add controls to grid
            grid.Children.Add(lbl1);
            grid.Children.Add(nudVA2);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            grid.Children.Add(lbl2);
            grid.Children.Add(VA2Combo);

            return grid;
        }
#endif
        #endregion
        #endregion

//==========================================================================================================
        //---------- Events ------------------------------------------------
        #region -- TabSelectionChangedHandler() --
        private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

	    #region -- Mouse Utilities --
	    private int ClickedBar1, ClickedBar2;
	    private double ClickedPrice1, ClickedPrice2;
	    private ChartScale gbChartScale;
	    private bool AddNextRectangle = false;
	    private void ChartPanel_MouseMove(object sender, MouseEventArgs e)
	    {
	        Point coords = e.GetPosition(ChartPanel);
			MM.X = ChartingExtensions.ConvertToHorizontalPixels(coords.X, ChartControl.PresentationSource);
		    MM.Y = ChartingExtensions.ConvertToVerticalPixels(coords.Y, ChartControl.PresentationSource);
            #region -- Handle Mouse entering/leaving Manual Profile button --
            HoveredRectangleTag = string.Empty;
            HoveredRectangleButton = 0;
            foreach (KeyValuePair<string, VolumeProfileS> kvp in ManualProfiles)
            {
                #region -- calculate button coordinates --
                y3 = gbChartScale.GetYByValue(kvp.Value.ProfileHigh);
                y4 = gbChartScale.GetYByValue(kvp.Value.ProfileLow);
                y5 = Math.Min(y3, y4);
                y6 = Math.Abs(y3 - y4);

                x1 = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.ProfileStart);
                x2 = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.ProfileEnd);
                x3 = Math.Min(x1, x2);
                x4 = Math.Abs(x2 - x1);
                #endregion

                Rect BidRectF2F = new Rect(x3, y5, x4, y6);

                int pButtonSizew = 22;
                int moveup = 6;

                B1 = new Rect(BidRectF2F.Left + bsp2 + 0, BidRectF2F.Top - bsp - moveup - iButtonSize, pButtonSizew, iButtonSize);
                B2 = new Rect(BidRectF2F.Left + bsp2 + 0 + pButtonSizew + 1 + 4, BidRectF2F.Top - bsp - moveup - iButtonSize, pButtonSizew, iButtonSize);
                B3 = new Rect(BidRectF2F.Left + bsp2 + 0 + pButtonSizew + 1 + 4 + pButtonSizew + 1 + 4, BidRectF2F.Top - bsp - moveup - iButtonSize, pButtonSizew + 2, iButtonSize);

                bool HighlightR = ThisSelectedRectangle() == kvp.Key;

                #region -- detect if mouse is hover --
                if (!IsInHitTest && (MouseIn(BidRectF2F, 5, 5) || MouseIn(B1, 5, 5) || MouseIn(B2, 5, 5) || MouseIn(B3, 5, 5) || HighlightR))
                {
                    HoveredRectangleTag = kvp.Key;

                    if (MouseIn(B1, 2, 2) && !IsInHitTest)
                    {
                        HoveredRectangleButton = 1;
                    }
                    else if (MouseIn(B2, 2, 2) && !IsInHitTest)
                    {
                        HoveredRectangleButton = 2;
                    }
                    else if (MouseIn(B3, 2, 2) && !IsInHitTest)
                    {
                        HoveredRectangleButton = 3;
                    }
                    else HoveredRectangleButton = 0;
                }
                #endregion

                if (HoveredRectangleTag != string.Empty) break;
            }
            #endregion

			ForceRefresh();
	    }
	    private void ChartPanel_MouseDown(object sender, MouseButtonEventArgs e)
	    {
	        MouseEventArgs mouse = (MouseEventArgs)e;

            #region -- Right Click = Stop drawing Manual Profile --
            if (mouse.RightButton == MouseButtonState.Pressed)
            {
                if (ChartControl.IsStayInDrawMode) ChartDrawingToolCommands.ToggleStayInDrawMode.Execute(this);
                AddNextRectangle = false;
            }
            #endregion

            #region -- Click Over Bar --
            if (InButton1)//bar P button
            {
                if (PrintIndividualBars.Contains(CurrentBars[0] - MouseBarIndex)) PrintIndividualBars.Remove(CurrentBars[0] - MouseBarIndex);
                else PrintIndividualBars.Add(CurrentBars[0] - MouseBarIndex);
            }
            if (InButton2)//bar V button
            {
                MouseBarIndex++;
                if (ProfileIndividualBars.Contains(CurrentBars[0] - MouseBarIndex)) ProfileIndividualBars.Remove(CurrentBars[0] - MouseBarIndex);
                else ProfileIndividualBars.Add(CurrentBars[0] - MouseBarIndex);
            }
            #endregion

            #region -- Manual Profile --
            if (HoveredRectangleButton > 0)
            {
                #region -- click E+ --
                if (HoveredRectangleButton == 2)//E+
                {
                    foreach (KeyValuePair<string, VolumeProfileS> kvp in ManualProfiles)
                    {
                        if (kvp.Key == HoveredRectangleTag)
                        {
                            if (ManualProfilesLE.ContainsKey(HoveredRectangleTag))
                            {
                                ManualProfilesLE[HoveredRectangleTag] = ManualProfilesLE[HoveredRectangleTag] + 1;
                                if (ManualProfilesLE[HoveredRectangleTag] > 2) ManualProfilesLE.Remove(HoveredRectangleTag);
                            }
                            else ManualProfilesLE.Add(HoveredRectangleTag, 1);
                        }
                    }
                }
                #endregion
                #region -- click V+ --
                else if (HoveredRectangleButton == 1)
                {
                    foreach (KeyValuePair<string, VolumeProfileS> kvp in ManualProfiles)
                    {
                        if (kvp.Key == HoveredRectangleTag)
                        {
                            if (ManualProfilesVE.ContainsKey(HoveredRectangleTag))
                            {
                                ManualProfilesVE[HoveredRectangleTag] = ManualProfilesVE[HoveredRectangleTag] + 1;
                                if (ManualProfilesVE[HoveredRectangleTag] > 3) ManualProfilesVE.Remove(HoveredRectangleTag);
                            }
                            else ManualProfilesVE.Add(HoveredRectangleTag, 1);
                        }
                    }
                }
                #endregion
                #region -- click CB --
                else if (HoveredRectangleButton == 3)//CB
                {
                    foreach (KeyValuePair<string, VolumeProfileS> kvp in ManualProfiles)
                    {
                        if (kvp.Key == HoveredRectangleTag)
                        {
                            if (ManualProfilesCB.ContainsKey(HoveredRectangleTag)) ManualProfilesCB.Remove(HoveredRectangleTag);
                            else ManualProfilesCB.Add(HoveredRectangleTag, 1);
                        }
                    }
line=7823;
                    foreach (dynamic draw in DrawObjects)
                    {
                        if (ManualProfilesCB.ContainsKey(HoveredRectangleTag) && draw.Tag.Contains(MANUAL_PROFILE_TAG_SUFFIX))
                        {
                            int Bar1 = (int)draw.StartAnchor.SlotIndex;
                            int Bar2 = (int)draw.EndAnchor.SlotIndex;
                            int StartTickBar = Math.Min(Bar1, Bar2);
                            int EndTickBar = Math.Max(Bar1, Bar2);
                            double TP = Math.Max(draw.StartAnchor.Price, draw.EndAnchor.Price);
                            double BP = Math.Min(draw.StartAnchor.Price, draw.EndAnchor.Price);
                            TP = RTTS(TP);
                            BP = RTTS(BP);

                            int RBar = 0;
                            if (ManualProfilesCB.ContainsKey(draw.Tag))
                            {
                                RBar = EndTickBar;
                                EndTickBar = CurrentBars[0];

                                double StartYV = TP;
                                double EndYV = BP;
                                for (int i = StartTickBar; i <= EndTickBar; i++)
                                {
                                    StartYV = Math.Max(StartYV, Highs[0].GetValueAt(i));
                                    EndYV = Math.Min(EndYV, Lows[0].GetValueAt(i));
                                }

                                if (StartYV != draw.StartAnchor.Price) draw.StartAnchor.Price = StartYV;
                                if (EndYV != draw.EndAnchor.Price) draw.EndAnchor.Price = EndYV;
                            }
                        }
                    }
                }
                #endregion
            }
            #endregion

            #region -- Click Over Zones --
            lock (SupplyZones)
            {
                foreach (KeyValuePair<int, List<Zone>> DZ in SupplyZones)
                {
                    foreach (Zone ZS in DZ.Value)
                    {
                        if (DZ.Key == ClickedZoneBar && ZS.TopPrice == ClickedZoneTop && ZS.BottomPrice == ClickedZoneBottom)
                        {
                            ZS.IsHidden = true;
                            break;
                        }
                    }
                }
            }

            lock (DemandZones)
            {
                foreach (KeyValuePair<int, List<Zone>> DZ in DemandZones)
                {
                    foreach (Zone ZS in DZ.Value)
                    {
                        if (DZ.Key == ClickedZoneBar && ZS.TopPrice == ClickedZoneTop && ZS.BottomPrice == ClickedZoneBottom)
                        {
                            ZS.IsHidden = true;
                            break;
                        }
                    }
                }
            }
            #endregion

			ForceRefresh();
        }
        private List<HorizontalLine> DeleteTags = new List<HorizontalLine>();
        private bool MouseIn(Rect area, int xFrame, int yFrame) { return MM.X >= area.Left - xFrame && MM.X <= area.Right + xFrame && MM.Y >= area.Top - yFrame && MM.Y <= area.Bottom + yFrame; }
        #endregion

		private int AboveZero(int p){return Math.Max(1,p);}
		private double AboveZero(double p){return Math.Max(0.1,p);}

        #region -- Misc Profiles Calculation --
//============================================================================================================================
        private void DrawManualP(ChartControl chartControl, ChartScale chartScale, SharpDX.Direct2D1.Brush ZoneHDXBrush, int ZoneHLineWidth)
        {
			var iManualProfileHDType = iManualProfileHD=="Left" ? 'L':'R';
			var iMPDisplayType = iMPDisplay=="Histogram" ? 'H' : 'S';//Histogram or Shape
			var IsShapeM = iMPDisplay.CompareTo("Shape")==0;
			SharpDX.Direct2D1.Brush txtDXBrush = null;

            //Reset all drawings to draw them again
            ManualProfiles.Clear();
            foreach (dynamic rect in DrawObjects)
            {
                if (rect.Tag.Contains("Rectangle"))//is Rectangle)
                {
                    #region -- add new rectangle to list --
                    if (!AllRectangles.Contains(rect.Tag) && !rect.Tag.Contains(MANUAL_PROFILE_TAG_SUFFIX))
                    {
line=7925;
                        if (AddNextRectangle)
                        {
line=7928;
                            rect.AreaBrush = Brushes.Transparent;
                            rect.OutlineStroke.Brush = Brushes.Transparent;
                            AddNextRectangle = false;
							rect.Tag += MANUAL_PROFILE_TAG_SUFFIX;
line=7933;
                            if (chartControl.IsStayInDrawMode)
                            {
                                MakeRectanglesList();
                                AddNextRectangle = true;
                            }
                        }
line=7940;
                        AllRectangles.Add(rect.Tag);
                    }
                    #endregion

                    #region -- Calculate Profile of rectangle --
                    if (rect.Tag.Contains(MANUAL_PROFILE_TAG_SUFFIX))
                    {
line=7949;
                        if (rect.AreaOpacity != 0) rect.AreaOpacity = 0;

                        rect.EndAnchor.Price = RTTS(rect.EndAnchor.Price);
                        rect.StartAnchor.Price = RTTS(rect.StartAnchor.Price);
                        rect.StartAnchor.BarsAgo = Math.Max(rect.StartAnchor.BarsAgo, 0);
                        rect.EndAnchor.BarsAgo = Math.Max(rect.EndAnchor.BarsAgo, 0);

line=7957;
                        if (rect.StartAnchor.BarsAgo <= rect.EndAnchor.BarsAgo && rect.StartAnchor.BarsAgo == 1) rect.StartAnchor.BarsAgo = 0;

                        int Bar1 = (int)rect.StartAnchor.SlotIndex;
                        int Bar2 = (int)rect.EndAnchor.SlotIndex;

line=7963;
                        int StartTickBar = Math.Min(Bar1, Bar2);
                        int EndTickBar = Math.Max(Bar1, Bar2);

                        // calculate profile
                        double TP = Math.Max(rect.StartAnchor.Price, rect.EndAnchor.Price);
                        double BP = Math.Min(rect.StartAnchor.Price, rect.EndAnchor.Price);
line=7970;
                        TP = RTTS(TP);
                        BP = RTTS(BP);

                        int RBar = 0;
                        if (ManualProfilesCB.ContainsKey(rect.Tag))
                        {
line=7977;
                            RBar = EndTickBar;
                            EndTickBar = CurrentBars[0];

                            double StartYV = TP;
                            double EndYV = BP;
                            for (int i = StartTickBar; i <= EndTickBar; i++)
                            {
                                StartYV = Math.Max(StartYV, Highs[0].GetValueAt(i));
                                EndYV = Math.Min(EndYV, Lows[0].GetValueAt(i));
                            }

                            if (StartYV != rect.StartAnchor.Price) rect.StartAnchor.Price = StartYV;
                            if (EndYV != rect.EndAnchor.Price) rect.EndAnchor.Price = EndYV;
                        }
line=7992;
                        VolumeProfileS VP = CalculateProfile2(StartTickBar, EndTickBar, RBar, TP, BP);
                        if (!ManualProfiles.ContainsKey(rect.Tag)) ManualProfiles.Add(rect.Tag, VP);
                        else
                        {
line=7997;
                            rect.Tag += DateTime.Now.Ticks;
                            if (!ManualProfiles.ContainsKey(rect.Tag)) ManualProfiles.Add(rect.Tag, VP);
                        }
                    }
                    #endregion
                }
            }

            foreach (KeyValuePair<string, VolumeProfileS> kvp in ManualProfiles)
            {
				// draw profiles
				y3 = chartScale.GetYByValue(kvp.Value.ProfileHigh);
				y4 = chartScale.GetYByValue(kvp.Value.ProfileLow);
				y5 = Math.Min(y3, y4);
				y6 = AboveZero(Math.Abs(y3 - y4));

				x1 = chartControl.GetXByBarIndex(ChartBars, kvp.Value.ProfileStart);
				x2 = chartControl.GetXByBarIndex(ChartBars, kvp.Value.ProfileEnd);
				x9 = chartControl.GetXByBarIndex(ChartBars, kvp.Value.Rend);

				x3 = Math.Min(x1, x2);
				x4 = AboveZero(Math.Abs(x2 - x1));
				x8 = Math.Max(x1, x2);

				BidRectF2 = new Rect(x3, y5, x4, y6);
line=8026;//Print("x4:"+x4+"y6:"+y6);
				Rect BidRectF2F = new Rect(x3, y5, x4, y6);

				AboveVA.Clear();
				InVA.Clear();
				BelowVA.Clear();

//	int priorY1 = 0;
				#region -- DRAW Each Level Histogram --
				y1 = -1;
				pVADPercent = 50;
				if (ManualProfilesVE.ContainsKey(kvp.Key))
				{
line=8040;
                    int proTag = ManualProfilesVE[kvp.Key];

                    if (proTag == 1) pVADPercent = 100;
                    if (proTag == 2) pVADPercent = 200;
                    if (proTag == 3) pVADPercent = 300;
                }
				var av = kvp.Value.AllVolume.Where(pr=> pr.Key < chartScale.MaxValue && pr.Key>chartScale.MinValue).ToList();
				foreach (KeyValuePair<double, VolumeAtBA> kvp2 in av)
				{
					if (kvp.Value.ProfileStart > lastBarIndex) continue;

					if(y1==-1) y1 = GetBoxPixel(kvp2.Key, 'T') - 1;
					y2 = GetBoxPixel(kvp2.Key, 'B') - 1;
					if(Math.Abs(y2-y1) <= 1) continue;
//	if(priorY1==0)priorY1=y1;
//	Print("y1 to priorY1: "+(priorY1-y1).ToString()+"   y1 to y2: "+Math.Abs(y1-y2).ToString());
//	priorY1=y1;
					y3 = AboveZero(y2 - y1)+1;
line=8059;
					y4 = chartScale.GetYByValue(kvp2.Key);

line=8062;
                    double totalvolume = kvp2.Value.AskSize + kvp2.Value.BidSize;
                    double ratio = (double)x4 / kvp.Value.POCVolume;
                    x6 = (int)Math.Round(((float)totalvolume * ratio * pVADPercent / 100), 0);
                    if (iManualProfileHDType=='L'/*"Left"*/) ratio = (double)(ChartPanel.X + ChartPanel.W - x3) / kvp.Value.POCVolume;
                    else ratio = (double)(x8) / kvp.Value.POCVolume;
                    x7 = (int)Math.Round(((float)totalvolume * ratio), 0);
                    x5 = AboveZero(pVADPercent == 300 || x7 < x6 ? x7 : x6);

                    BidRectF2 = iManualProfileHDType=='R'/*"Right"*/ ? new Rect(x8 - x5, y1, x5, y3) : new Rect(x3, y1, x5, y3+1);

line=8073;
                    // keep histogram inside the rectangle outline box
                    if (BidRectF2.Top < BidRectF2F.Top)
                    {
                        BidRectF2.Y = BidRectF2F.Top;
                        BidRectF2.Height = AboveZero(BidRectF2.Height / 2 - 1);
                    }
                    if (BidRectF2.Bottom > BidRectF2F.Bottom) BidRectF2.Height = AboveZero(BidRectF2.Height / 2);

                    gx = (int)(BidRectF2.Left + BidRectF2.Width);

line=8084;
                    if (kvp2.Key >= kvp.Value.VAH) AboveVA.Add(new Point(gx, y4));
                    if (kvp2.Key <= kvp.Value.VAL) BelowVA.Add(new Point(gx, y4));
                    if (kvp2.Key >= kvp.Value.VAL && kvp2.Key <= kvp.Value.VAH) InVA.Add(new Point(gx, y4));

                    if (kvp2.Key == kvp.Value.POCPrice)  HistogramDXBrush = iMPHistogramPOCDXBrush;
                    else if (kvp2.Key == kvp.Value.VWAP) HistogramDXBrush = iMPHistogramVWAPDXBrush;
                    else if (kvp2.Key == kvp.Value.VAH)  HistogramDXBrush = iMPHistogramVAHDXBrush;
                    else if (kvp2.Key == kvp.Value.VAL)  HistogramDXBrush = iMPHistogramVALDXBrush;
                    else if (kvp2.Key >= kvp.Value.ClusterBottom && kvp2.Key <= kvp.Value.ClusterTop) 
						HistogramDXBrush = iMPHistogramClusterDXBrush;
                    else if (kvp2.Key > kvp.Value.VAL && kvp2.Key < kvp.Value.VAH) 
						HistogramDXBrush = iMPHistogramVADXBrush;
                    else HistogramDXBrush = iMPHistogramMDXBrush;
                    if(iMPONTOP)
                        HistogramDXBrush.Opacity = 1;
                    else
                        HistogramDXBrush.Opacity = iMPHistogramOpacity / 100f;

                    if (!IsShapeM && !IsInHitTest) drawRegion(BidRectF2, HistogramDXBrush);//, iMPHistogramOpacity);
					y1 = y2;
                }
                if (IsShapeM && !IsInHitTest)
                {
line=8108;
                    if (AboveVA.Count > 0) fillPolygon(MakeShape(AboveVA, (int)BidRectF2.Left), iMPHistogramMDXBrush);//, iMPHistogramOpacity);
                    if (BelowVA.Count > 0) fillPolygon(MakeShape(BelowVA, (int)BidRectF2.Left), iMPHistogramMDXBrush);//, iMPHistogramOpacity);
                    if (InVA.Count > 0)    fillPolygon(MakeShape(InVA,    (int)BidRectF2.Left), iMPHistogramVADXBrush);// iMPHistogramOpacity);
                }
                #endregion

                #region -- labels and lines --
				foreach (KeyValuePair<double, VolumeAtBA> kvp2 in kvp.Value.AllVolume)
                {
line=8118;
					var TxtColor = iMPHistogramPOCColor;
					if (kvp.Value.ProfileStart > lastBarIndex) continue;
					y1 = GetBoxPixel(kvp2.Key, 'T') - 1;
					y2 = GetBoxPixel(kvp2.Key, 'B') - 1;
					y3 = y2 - y1;
					y4 = chartScale.GetYByValue(kvp2.Key);
					string Labell = string.Empty;
					bool MarkThisLevel = true;

					BrushMDXBrush = iMPHistogramPOCDXBrush;
					#region -- Calculate Mark this Level and Color --
					if (kvp2.Key == kvp.Value.POCPrice)
					{
					    PenMDXBrush   = iMPHistogramPOCDXBrush;
					    BrushMDXBrush = iMPHistogramPOCDXBrush;
						TxtColor      = iMPHistogramPOCColor;
						txtDXBrush    = iMPHistoPOCContrastDXBrush;
					    Labell = "POC";
					}
					else if (kvp2.Key == kvp.Value.VWAP)
					{
					    PenMDXBrush   = iMPHistogramVWAPDXBrush;
					    BrushMDXBrush = iMPHistogramVWAPDXBrush;
						TxtColor      = iMPHistogramVWAPColor;
						txtDXBrush    = iMPHistoVWAPContrastDXBrush;
					    Labell = "VWAP";
					}
					else if (kvp2.Key == kvp.Value.VAH)
					{
					    PenMDXBrush   = iMPHistogramVAHDXBrush;
					    BrushMDXBrush = iMPHistogramVAHDXBrush;
						TxtColor      = iMPHistogramVAHColor;
						txtDXBrush    = iMPHistoVAHContrastDXBrush;
					    Labell = "VAH";
					}
					else if (kvp2.Key == kvp.Value.VAL)
					{
					    PenMDXBrush   = iMPHistogramVALDXBrush;
					    BrushMDXBrush = iMPHistogramVALDXBrush;
						TxtColor      = iMPHistogramVALColor;
						txtDXBrush    = iMPHistoVALContrastDXBrush;
					    Labell = "VAL";
					}
					else MarkThisLevel = false;
					y3 = AboveZero(y3);

line=8165;
					//if (y3 > 0)
					{
						pVADPercent = 50;
						if (ManualProfilesVE.ContainsKey(kvp.Key))
						{
						    int tagPriceVE = ManualProfilesVE[kvp.Key];

						    if (tagPriceVE == 1) pVADPercent = 100;
						    if (tagPriceVE == 2) pVADPercent = 200;
						    if (tagPriceVE == 3) pVADPercent = 300;
						}

						double totalvolume = kvp2.Value.AskSize + kvp2.Value.BidSize;
						double ratio = (double)x4 / kvp.Value.POCVolume;
						x6 = (int)Math.Round(((float)totalvolume * ratio * pVADPercent / 100), 0);

						if (iManualProfileHDType == 'L'/*Left"*/) ratio = (double)(ChartPanel.X + ChartPanel.W - x3) / kvp.Value.POCVolume;
						else ratio = (double)(x8) / kvp.Value.POCVolume;

line=8185;
						x7 = (int)Math.Round(((float)totalvolume * ratio), 0);
						x5 = AboveZero(x6);
						if (pVADPercent == 300 || x7 < x6) x5 = x7;
						BidRectF2 = iManualProfileHDType == 'R'/*"Right"*/ ? new Rect(x8 - x5, y1, x5, y3) : new Rect(x3, y1, x5, y3);

						// keep histogram inside the rectangle outline box
						if (BidRectF2.Top < BidRectF2F.Top)
						{
						    BidRectF2.Y = BidRectF2F.Top;
						    BidRectF2.Height = AboveZero(BidRectF2.Height / 2 - 1);
						}
						if (BidRectF2.Bottom > BidRectF2F.Bottom) BidRectF2.Height = AboveZero(BidRectF2.Height / 2);

						#region -- Mark This Level --
						if (!IsInHitTest && MarkThisLevel)
						{
line=8202;
						    Labell = string.Format("{0} {1}",Labell, Instrument.MasterInstrument.FormatPrice(kvp2.Key));
						    x2 = chartControl.GetXByBarIndex(ChartBars, kvp.Value.ProfileEnd);

						    int txtWidth = (int)getTextWidth(Labell, iBarPrintFont) + 4;
						    int rWidth = 8;
						    double leftside = iMPDisplayType == 'H'/*"Histogram"*/ ? BidRectF2.Right : BidRectF2F.Left;

						    if (!ManualProfilesLE.ContainsKey(kvp.Key))
						    {
						        if (iMPDisplayType != 'H'/*"Histogram"*/) drawLine(leftside, BidRectF2.Right, y4, y4, PenMDXBrush, DashStyleHelper.Solid, iMPLineWidth);

						        if (iManualProfileHDType == 'R'/*"Right"*/) BidRectF25 = new Rect(x2 - txtWidth, y4 - rWidth, txtWidth, 1 + rWidth + rWidth);
						        else BidRectF25 = new Rect(x3, y4 - rWidth, txtWidth, 1 + rWidth + rWidth);

						        if (iMPLabels)
						        {
						            drawRegion(BidRectF25, BrushMDXBrush);
						            drawstring(Labell, BidRectF25.X, BidRectF25.Y + (BidRectF25.Height - iBarPrintFont.Size) / 2, iBarPrintFont, txtDXBrush, SharpDX.DirectWrite.TextAlignment.Center, (int)BidRectF25.Width);
						        }
						    }
						    else
						    {
line=8225;
						        if (ManualProfilesLE[kvp.Key] == 1)
						        {
						            if (iManualProfileHDType == 'R'/*"Right"*/)
						            {
						                x2 = x8;
						                drawLine(BidRectF2F.Left, x2 - 1, y4, y4, PenMDXBrush, DashStyleHelper.Solid, iMPLineWidth);
						                BidRectF25 = new Rect(BidRectF2F.Left, y4 - rWidth, txtWidth, 1 + rWidth + rWidth);
						            }
						            else
						            {
						                x2 = x8;
						                drawLine(leftside, x2 - 1, y4, y4, PenMDXBrush, DashStyleHelper.Solid, iMPLineWidth);
						                BidRectF25 = new Rect(x2 - txtWidth, y4 - rWidth, txtWidth, 1 + rWidth + rWidth);
						            }
						            if (iMPLabels)
						            {
						                drawRegion(BidRectF25, BrushMDXBrush);
						                drawstring(Labell, BidRectF25.X, BidRectF25.Y + (BidRectF25.Height - iBarPrintFont.Size) / 2, iBarPrintFont, txtDXBrush, SharpDX.DirectWrite.TextAlignment.Leading, (int)BidRectF25.Width);
						            }
						        }
						        else if (ManualProfilesLE[kvp.Key] == 2)
						        {
						            x2 = (int)(ChartPanel.X + ChartPanel.W);
						            drawLine(leftside, x2 - 1, y4, y4, PenMDXBrush, DashStyleHelper.Solid, iMPLineWidth);
						            BidRectF25 = new Rect(x2 - txtWidth, y4 - rWidth, txtWidth, 1 + rWidth + rWidth);

						            drawRegion(BidRectF25, BrushMDXBrush);
						            drawstring(Labell, BidRectF25.X, BidRectF25.Y + (BidRectF25.Height - iBarPrintFont.Size) / 2, iBarPrintFont, txtDXBrush, SharpDX.DirectWrite.TextAlignment.Center, (int)BidRectF25.Width);
						        }
						    }
						}
						#endregion
                	}
					#endregion
				}
				#endregion

				#region -- DRAW RECTANGLE --
				int pButtonSizew = 22;
				int moveup = 6;

				B1 = new Rect(BidRectF2F.Left + bsp2 + 0, BidRectF2F.Top - bsp - moveup - iButtonSize, pButtonSizew, iButtonSize);
				B2 = new Rect(BidRectF2F.Left + bsp2 + 0 + pButtonSizew + 1 + 4, BidRectF2F.Top - bsp - moveup - iButtonSize, pButtonSizew, iButtonSize);
				B3 = new Rect(BidRectF2F.Left + bsp2 + 0 + pButtonSizew + 1 + 4 + pButtonSizew + 1 + 4, BidRectF2F.Top - bsp - moveup - iButtonSize, pButtonSizew + 2, iButtonSize);

				// draw main rectangle
				if (!IsInHitTest) drawRegion(BidRectF2F, RectangleFillDXBrush);
				if (!IsInHitTest) drawRectangle(BidRectF2F, RectangleDXBrush, RectangleLineWidth);

				if (kvp.Value.Rend != 0 && !IsInHitTest)
				{
					drawLine(x9, x9, BidRectF2F.Bottom, BidRectF2F.Bottom - 20, RectangleDXBrush, DashStyleHelper.Solid, RectangleLineWidth);
					drawLine(x9, x9, BidRectF2F.Top,    BidRectF2F.Top + 20,    RectangleDXBrush, DashStyleHelper.Solid, RectangleLineWidth);
				}

line=8281;
				bool HighlightR = ThisSelectedRectangle() == kvp.Key;

				if (!IsInHitTest && (MouseIn(BidRectF2F, 5, 5) || MouseIn(B1, 5, 5) || MouseIn(B2, 5, 5) || MouseIn(B3, 5, 5) || HighlightR))
				{
                    HoveredRectangleTag = kvp.Key;

                    // button 1
                    drawRectangle(BidRectF2F, ZoneHDXBrush, ZoneHLineWidth);

                    if (kvp.Value.Rend != 0)
                    {
                        drawLine(x9, x9, BidRectF2F.Bottom, BidRectF2F.Bottom - 20, ZoneHDXBrush, DashStyleHelper.Solid, ZoneHLineWidth);
                        drawLine(x9, x9, BidRectF2F.Top,    BidRectF2F.Top + 21,    ZoneHDXBrush, DashStyleHelper.Solid, ZoneHLineWidth);
                    }

                    ButtonDXBrush = DXBrushes_LightGray;

line=8299;
                    drawRegion(B1, ButtonDXBrush);
                    drawRectangle(B1, ButtonPenDXBrush, (int)ButtonPen.Thickness);
                    drawstring("V+", B1.X, B1.Y + (B1.Height - ButtonFont.Size) / 2 - 1, ButtonFont, ButtonTextDXBrush, SharpDX.DirectWrite.TextAlignment.Center, (int)B1.Width);

                    drawRegion(B2, ButtonDXBrush);
                    drawRectangle(B2, ButtonPenDXBrush, (int)ButtonPen.Thickness);
                    drawstring("E+", B2.X, B2.Y + (B2.Height - ButtonFont.Size) / 2 - 1, ButtonFont, ButtonTextDXBrush, SharpDX.DirectWrite.TextAlignment.Center, (int)B2.Width);

                    if (kvp.Value.Rend != 0) ButtonDXBrush = DXBrushes_LightGreen;

                    drawRegion(B3, ButtonDXBrush);
                    drawRectangle(B3, ButtonPenDXBrush, (int)ButtonPen.Thickness);
                    drawstring("CB", B3.X, B3.Y + (B3.Height - ButtonFont.Size) / 2 - 1, ButtonFont, ButtonTextDXBrush, SharpDX.DirectWrite.TextAlignment.Center, (int)B3.Width);

                    if (MouseIn(B1, 2, 2) && !IsInHitTest)
                    {
                        HoveredRectangleButton = 1;
                        drawRectangle(B1, ZoneHDXBrush, ZoneHLineWidth);
                    }
                    else if (MouseIn(B2, 2, 2) && !IsInHitTest)
                    {
                        HoveredRectangleButton = 2;
                        drawRectangle(B2, ZoneHDXBrush, ZoneHLineWidth);
                    }
                    else if (MouseIn(B3, 2, 2) && !IsInHitTest)
                    {
                        HoveredRectangleButton = 3;
                        drawRectangle(B3, ZoneHDXBrush, ZoneHLineWidth);
                    }
                }
                #endregion

				/*#region -- Draw Volume Moving Averages --
				if (iShowCwapManual)
				{
					var iCwapDXBrush = iCwapManColor.ToDxBrush(RenderTarget);
					int profileBars = Math.Abs(kvp.Value.ProfileEnd - kvp.Value.ProfileStart);
					var vwap = kvp.Value.CWAP;
					for (int i = 1; i < profileBars; i++)
					{
						int b = Math.Min(kvp.Value.ProfileEnd, kvp.Value.ProfileStart) + i;
						if (vwap[i] > chartScale.MinValue && vwap[i - 1] > chartScale.MinValue) drawLine(vwap[i], vwap[i - 1], b, b - 1, iCwapDXBrush, iCwapManDashStyle, iCwapManWidth, chartControl, chartScale);
					}
					iCwapDXBrush.Dispose(); iCwapDXBrush = null;
				}
				#endregion*/
			}
		}
//============================================================================================================================
        private void MakeRectanglesList()
        {
            AllRectangles.Clear();
            foreach (dynamic draw in DrawObjects) if (draw.Tag.Contains("Rectangle")) AllRectangles.Add(draw.Tag);
        }
//============================================================================================================================
        private string ThisSelectedRectangle()
        {
            {
                Type chartControlType = typeof(ChartControl);
                FieldInfo fi = chartControlType.GetField("selectedObject", BindingFlags.NonPublic | BindingFlags.Instance);
                if (fi != null)
                {
                    if (base.ChartControl != null && fi.GetValue(base.ChartControl) != null)
                    {
                        object clickedObject = fi.GetValue(base.ChartControl);
                        if (clickedObject.GetType() == typeof(Rectangle))
                        {
                            Rectangle trendLine = (Rectangle)clickedObject;
                            return trendLine.Tag;
                        }
                    }
                }
            }
            return string.Empty;
        }
//============================================================================================================================
        //Draw Composite Profile
        private void DrawComp(ChartControl chartControl, ChartScale chartScale)
        {
            int DesiredMargin = iCompLength + diff;
            if (iCompositeProfileHD[0] != 'L'/*"Left"*/) FinalDesiredMargin = Math.Max(FinalDesiredMargin, DesiredMargin);
            // increase number to make it less sensitive
            bool DrawThisVTest = true;
			var Histo2Color = iCPHistogramPOCColor;
			var ColorM2     = iCPHistogramPOCColor;
			var IsShape     = iCPDisplay[0]  == 'S';//.CompareTo("Shape")==0;
			var IsLeft      = iCompositeProfileHD[0] == 'L';//.CompareTo("Left")==0;
			var IsRight     = iCompositeProfileHD[0] == 'R';//.CompareTo("Right")==0;
			var Histo2VAContrastDXBrush    = ContrastingColor((SolidColorBrush)Histo2Color).ToDxBrush(RenderTarget);
			var Histo2NonVAContrastDXBrush = ContrastingColor((SolidColorBrush)iCPHistogramMColor).ToDxBrush(RenderTarget);
			var Histo2VolTextDXBrush       = Histo2VAContrastDXBrush;
            foreach (var kvp in CompositeProfiles)
            {
try{
                bool IsLatest = kvp.Key == CompositeStartBar;
                if (!iHCompositeEnabled && !IsLatest) continue;
                if (!iCCompositeEnabled && IsLatest) continue;
                #region -- Calculate and Draw Background --
                x1 = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.ProfileStart);
                x2 = x1 + iCompLength ;
                x3 = Math.Min(x1, x2);
                if (IsLeft && iCCompositeEnabled && IsLatest && iCPONTOP)
                {
                    if (x1 < ChartPanel.X)
                    {
                        Rect BackRect = new Rect(0, 0, iCompLength, ChartPanel.H + 10);
                        if (!IsInHitTest && ChartBackgroundBrushDX!=null) drawRegion(BackRect, ChartBackgroundBrushDX);
                    }
                }
                #endregion

				AboveVA.Clear();
				InVA.Clear();
				BelowVA.Clear();

				//DRAW PROFILE
				int textwidth = !iDrawCText ? 0 : kvp.Value.AllVolume.Count <= 0 ? 0 : (int)kvp.Value.AllVolume.Max(p => getTextWidth(p.Value.getLevelVolume().ToString(), iBarPrintFont));

				var vatp = kvp.Value.AllVolume.ToList();//added to get around the error "indexer changed during iterations"
				foreach (var kvp2 in vatp)
				{
                    if (kvp.Value.ProfileStart > lastBarIndex) continue;
//if(IsLatest && kvp2.Key>1.2462 && kvp2.Key<1.2464) Print(kvp2.Key.ToString("0.00000000000000000000000000000000")+"  "+kvp2.Value.AskSize+"/"+kvp2.Value.BidSize);
                    #region -- Calculate Coordinates of BidRectF2 --
                    y1 = GetBoxPixel(kvp2.Key, 'T') - 1;
                    y2 = GetBoxPixel(kvp2.Key, 'B') - 1;
                    y3 = y2 - y1;

                    if (y3 <= 0) y3=1;//continue;

                    y4 = chartScale.GetYByValue(kvp2.Key);

                    x4 = iCompLength - 1;

                    int textsize = IsShape ? 0 : textwidth;
                    int newad = x4 - textsize;
                    double totalvolume = kvp2.Value.getLevelVolume();
                    double ratio = (double)newad / kvp.Value.POCVolume;

                    x5 = textsize + (int)Math.Round(((float)totalvolume * ratio), 0);

                    int ask4 = (int)Math.Round(((float)kvp2.Value.AskSize * ratio), 0);
                    int bid4 = (int)Math.Round(((float)kvp2.Value.BidSize * ratio), 0);

                    BidRectF2 = new Rect(x3, y1, x5, y3);

                    if (IsLatest)
                    {
                        BidRectF2 = new Rect(ChartPanel.X + ChartPanel.W - x5, y1, x5, y3);
                        if (IsLeft)
                        {
                            x8 = x1 > ChartPanel.X ? Math.Max(ChartPanel.X, x1) : ChartPanel.X;
                            BidRectF2 = new Rect(x8, y1, x5, y3);
                        }
                    }
                    #endregion

					gx = IsLatest && IsRight ? (int)BidRectF2.Left : (int)BidRectF2.Left + (int)BidRectF2.Width;

					if (kvp2.Key >= kvp.Value.VAH) AboveVA.Add(new Point(gx, y4));
					if (kvp2.Key <= kvp.Value.VAL) BelowVA.Add(new Point(gx, y4));
					if (kvp2.Key >= kvp.Value.VAL && kvp2.Key <= kvp.Value.VAH) InVA.Add(new Point(gx, y4));
					#region -- Set Colors + Label of Level --
					bool   MarkThisLevel = true;
					string Labell        = string.Empty;
					if (kvp2.Key == kvp.Value.POCPrice)
					{
line=8475;
						HistogramDXBrush2 = iCPHistogramPOCDXBrush;
						Histo2Color  = iCPHistogramPOCColor;
						PenM2DXBrush = iCPHistogramPOCDXBrush;
						DXBrushM2    = iCPHistogramPOCDXBrush;
						ColorM2      = iCPHistogramPOCColor;
						Labell       = "POC";
					}
					else if (kvp2.Key == kvp.Value.VWAP)
					{
line=8485;
						HistogramDXBrush2 = iCPHistogramVWAPDXBrush;
						Histo2Color  = iCPHistogramVWAPColor;
						PenM2DXBrush = iCPHistogramVWAPDXBrush;
						DXBrushM2    = iCPHistogramVWAPDXBrush;
						ColorM2      = iCPHistogramVWAPColor;
						Labell       = "VWAP";
					}
					else if (kvp2.Key == kvp.Value.VAH)
					{
line=8495;
						HistogramDXBrush2 = iCPHistogramVAHDXBrush;
						Histo2Color  = iCPHistogramVAHColor;
						PenM2DXBrush = iCPHistogramVAHDXBrush;
						DXBrushM2    = iCPHistogramVAHDXBrush;
						ColorM2      = iCPHistogramVAHColor;
						Labell       = "VAH";
					}
					else if (kvp2.Key == kvp.Value.VAL)
					{
line=8505;
						HistogramDXBrush2 = iCPHistogramVALDXBrush;
						Histo2Color  = iCPHistogramVALColor;
						PenM2DXBrush = iCPHistogramVALDXBrush;
						DXBrushM2    = iCPHistogramVALDXBrush;
						ColorM2      = iCPHistogramVALColor;
						Labell       = "VAL";
					}
					else if (kvp2.Key >= kvp.Value.ClusterBottom && kvp2.Key <= kvp.Value.ClusterTop)
					{
line=8515;
						HistogramDXBrush2 = iCPHistogramClusterDXBrush;
						Histo2Color       = iCPHistogramClusterColor;
						MarkThisLevel     = false;
						Histo2VolTextDXBrush = Histo2NonVAContrastDXBrush;
					}
					else if (kvp2.Key > kvp.Value.VAL && kvp2.Key < kvp.Value.VAH)
					{
line=8523;
						MarkThisLevel        = false;
						HistogramDXBrush2    = iCPHistogramVADXBrush;
						Histo2Color          = iCPHistogramVAColor;
						Histo2VolTextDXBrush = Histo2VAContrastDXBrush;
					}
					else
					{
line=8531;
						MarkThisLevel     = false;
						HistogramDXBrush2 = iCPHistogramMDXBrush;
						Histo2Color       = iCPHistogramMColor;
					}
					#endregion
					#region -- Draw Histogram --
					if (!IsShape)
					{
line=8540;
						if (!IsInHitTest) drawRegion(BidRectF2, HistogramDXBrush2, 1);
						SharpDX.DirectWrite.TextAlignment FormatFinal = IsLatest && IsRight ? SharpDX.DirectWrite.TextAlignment.Trailing : SharpDX.DirectWrite.TextAlignment.Leading;
						GeneralFont.Size = iBarPrintFont.Size - AdjustFontAmount;
						if (!IsInHitTest && DrawThisVTest && iDrawCText) drawstring(totalvolume.ToString(), BidRectF2.X, y4 - GeneralFont.Size / 2, GeneralFont, Histo2VolTextDXBrush, FormatFinal, (float)BidRectF2.Width);
					}
                    #endregion
                    #region -- Highlight Level if VA/POC/VWAP --
                    if (!IsInHitTest && MarkThisLevel)
                    {
line=8592;
                        Labell = string.Format("{0} {1}",Labell, Instrument.MasterInstrument.FormatPrice(kvp2.Key));

                        x2 = chartControl.GetXByBarIndex(ChartBars, kvp.Value.ProfileEnd);
                        if (BidRectF2.Right > x2) x2 = (int)BidRectF2.Right;
                        if (IsLatest && IsLeft) x2 = ChartPanel.X + ChartPanel.W;

                        if (iCompLineExtend && !(IsLatest && IsRight)) drawLine(BidRectF2.Right, x2 - 1, y4, y4, PenM2DXBrush, DashStyleHelper.Solid, iCPLineWidth);
                        if (iCompLineLabels)
                        {
                            int offset = 8;
                            int width = (int)getTextWidth(Labell, iBarPrintFont) + 4;
                            BidRectF2 = !iCompLineExtend ? new Rect(x1, y4 - offset, width, 1 + 2 * offset) : new Rect(x2 - width, y4 - offset, width, 1 + 2 * offset);
							var ColorM2ContrastDXBrush = ContrastingColor((SolidColorBrush)ColorM2).ToDxBrush(RenderTarget);
							if(IsLatest && IsRight){
								BidRectF2.X = BidRectF2.X - width;
	                            drawRegion(BidRectF2, DXBrushM2);
	                            drawstring(Labell, BidRectF2.X, y4 - iBarPrintFont.Size / 2, iBarPrintFont, ColorM2ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading, (float)BidRectF2.Width);
							}else{
	                            drawRegion(BidRectF2, DXBrushM2);
	                            drawstring(Labell, BidRectF2.X, y4 - iBarPrintFont.Size / 2, iBarPrintFont, ColorM2ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Center, (float)BidRectF2.Width);
							}
							if(ColorM2ContrastDXBrush!=null){ ColorM2ContrastDXBrush.Dispose(); ColorM2ContrastDXBrush=null;}
                        }
                    }
                    #endregion
                }

line=8606;
                if (false && IsShape)//falsefalse
                {
                    if (iCPONTOP)
                    {
                        iCPHistogramMDXBrush.Opacity = 1f;//iCPHistogramOpacity/100f;
                        iCPHistogramVADXBrush.Opacity = 1f;// iCPHistogramOpacity/100f;
                    }
                    else
                    {
                        iCPHistogramMDXBrush.Opacity = iCPHistogramOpacity/100f;
                        iCPHistogramVADXBrush.Opacity = iCPHistogramOpacity/100f;
                    }
                    int xShapeStart = chartControl.GetXByBarIndex(ChartBars, kvp.Value.ProfileStart);
                    if (IsLatest && IsRight) xShapeStart = ChartPanel.X + ChartPanel.W;

                    if (!IsInHitTest && AboveVA.Count > 0) fillPolygon(MakeShape(AboveVA, xShapeStart), iCPHistogramMDXBrush);
                    if (!IsInHitTest && BelowVA.Count > 0) fillPolygon(MakeShape(BelowVA, xShapeStart), iCPHistogramMDXBrush);
                    if (!IsInHitTest && InVA.Count > 0) fillPolygon(MakeShape(InVA, xShapeStart), iCPHistogramVADXBrush);
                }
}catch(Exception eee){Print(line+": "+eee.ToString());}
            }
line=8646;
			if(Histo2VolTextDXBrush!=null)       {Histo2VolTextDXBrush.Dispose();       Histo2VolTextDXBrush=null;}
			if(Histo2NonVAContrastDXBrush!=null) {Histo2NonVAContrastDXBrush.Dispose(); Histo2NonVAContrastDXBrush=null;}
			if(Histo2VAContrastDXBrush!=null)    {Histo2VAContrastDXBrush.Dispose();    Histo2VAContrastDXBrush=null;}

			/*#region -- Draw Volume Moving Averages --
            if (iShowCwapComposite)
            {
                int firstBarIndex = Math.Max(BarsRequiredToPlot, ChartBars.FromIndex);// BarsRequiredToPlot;//FIRST LEFT BAR idx (slot)
                var iCwapDXBrush = iCwapCompColor.ToDxBrush(RenderTarget);
                for (int i = lastBarIndex; i > firstBarIndex; i--)
                {
                    if (CompVWAP.GetValueAt(i) > chartScale.MinValue) drawLine(CompVWAP.GetValueAt(i), CompVWAP.GetValueAt(i - 1), i, i - 1, iCwapDXBrush, iCwapCompDashStyle, iCwapCompWidth, chartControl, chartScale);
                }
                iCwapDXBrush.Dispose(); iCwapDXBrush = null;
            }
            #endregion*/
        }
//============================================================================================================================
        private VolumeProfileS CalculateProfile2(int StartBar, int EndBar, int RBar, double TopPrice, double BottomPrice)
        {
            SortedDictionary<double, VolumeAtBA> allvolumes = new SortedDictionary<double, VolumeAtBA>();
            int EndB2 = Math.Min(EndBar, CurrentBars[0]);
            //List<double> cwap = new List<double>();
            #region -- get the volume from out already finished print data --
//int xx = 0;double px = 0;
            for (int i = StartBar; i <= EndB2; i++)
            {
//if(true) Print("Bar: "+Times[0].GetValueAt(i).ToString()+"   BarDataCollection contains that date? "+BarDataCollection.ContainsKey(i).ToString());
                if (BarDataCollection.ContainsKey(i))
                {
//px = 0;
                    foreach (KeyValuePair<double, PrintLevelDetails> kvp2 in BarDataCollection[i])
                    {
//if(px!=0 && xx<100) Print(xx+":  price: "+kvp2.Key+"  diff: "+(kvp2.Key-px).ToString()+"  AskSize: "+kvp2.Value.AskSize+"  BidSize: "+kvp2.Value.BidSize);
//xx++;
                        double LastPrice = kvp2.Key;
//if(px==0) px= LastPrice;
                        if (LastPrice <= TopPrice && LastPrice >= BottomPrice)
                        {
                            if (allvolumes.ContainsKey(LastPrice))
                            {
                                allvolumes[LastPrice].AskSize += kvp2.Value.AskSize;
                                allvolumes[LastPrice].BidSize += kvp2.Value.BidSize;
                            }
                            else
                            {
                                allvolumes.Add(kvp2.Key, new VolumeAtBA());
                                allvolumes[LastPrice].AskSize = kvp2.Value.AskSize;
                                allvolumes[LastPrice].BidSize = kvp2.Value.BidSize;
                            }
                        }
//px = LastPrice;
                    }
                }
                //cwap.Add(CalculateVWAP(allvolumes));
            }
            #endregion

            VolumeProfileS profile = CalculateProfile3(allvolumes);
            profile.Rend = RBar;//???

            profile.ProfileStart = StartBar;
            profile.ProfileEnd   = EndBar;
            profile.ProfileHigh  = TopPrice;
            profile.ProfileLow   = BottomPrice;
            //profile.CWAP = cwap;

            return profile;
        }
//==========================================================================================================
        private double CalculateVWAP(SortedDictionary<double, VolumeAtBA> allvolumes)
        {
            VolumeProfileS profile = new VolumeProfileS() { AllVolume = allvolumes };
            double AllVolume = 0;
            double VWAPTotal = 0;
            int p;
            for (p = 0; p < profile.AllVolume.Count; p++)
            {
                KeyValuePair<double, VolumeAtBA> level = profile.AllVolume.ElementAt(p);
                double totalvol = level.Value.getLevelVolume();
                VWAPTotal += totalvol * level.Key;
                AllVolume += totalvol;
            }
            double vwap = allvolumes.Count == 0 ? 0 : RTTS(VWAPTotal / AllVolume);
            return vwap;
        }
        private VolumeProfileS CalculateProfile3(SortedDictionary<double, VolumeAtBA> allvolumes)
        {
            VolumeProfileS profile = new VolumeProfileS() { AllVolume = allvolumes };

            #region -- Calculate VWAP / Clusters / POC --
            double POCLevel = 0;
            int POCidx = 0;
            double POCVolume = 0;
            double AllVolume = 0;
            double ThisClusterVolume = 0;
            double FinalClusterVolume = 0;
            double VWAPTotal = 0;

            int p;
            for (p = 0; p < profile.AllVolume.Count; p++)
            {
                KeyValuePair<double, VolumeAtBA> level = profile.AllVolume.ElementAt(p);
                double totalvol = level.Value.getLevelVolume();
                VWAPTotal += totalvol * level.Key;
                if (profile.AllVolume.ContainsKey(RTTS(level.Key + gbTickSize)) && profile.AllVolume.ContainsKey(RTTS(level.Key - gbTickSize)))
                {
                    ThisClusterVolume = profile.AllVolume[RTTS(level.Key - gbTickSize)].getLevelVolume() + profile.AllVolume[RTTS(level.Key + gbTickSize)].getLevelVolume() + totalvol;

                    if (ThisClusterVolume > FinalClusterVolume)
                    {
                        FinalClusterVolume = ThisClusterVolume;
                        profile.ClusterTop = RTTS(level.Key + gbTickSize);
                        profile.ClusterBottom = RTTS(level.Key - gbTickSize);
                    }
                }

                AllVolume += totalvol;
                if (totalvol > POCVolume)
                {
                    POCVolume = totalvol;
                    POCLevel = level.Key;
                    POCidx = p;
                }
            }
            #endregion

            #region -- VAH/VAL Calculation --
            double PercentVolume = AllVolume * iVAPercent / 100;
            double CurrentVolume = POCVolume;
            int idxAbove = POCidx;
            int idxBelow = POCidx;
            bool isUpCluster = false;
            int idxMax = profile.AllVolume.Count - 1;

            double VolumeAbove = idxAbove + 1 <= idxMax ? profile.AllVolume.ElementAt(idxAbove + 1).Value.getLevelVolume() : 0;
            if (idxAbove + 2 <= idxMax) VolumeAbove += profile.AllVolume.ElementAt(idxAbove + 2).Value.getLevelVolume();

            double VolumeBelow = idxBelow - 1 >= 0 ? profile.AllVolume.ElementAt(idxBelow - 1).Value.getLevelVolume() : 0;
            if (idxBelow - 2 >= 0) VolumeBelow += profile.AllVolume.ElementAt(idxBelow - 2).Value.getLevelVolume();

            while (CurrentVolume < PercentVolume)
            {
                if (VolumeBelow > VolumeAbove || idxAbove == idxMax)
                {
                    idxBelow = idxBelow - 2 < 0 ? 0 : idxBelow - 2;
                    CurrentVolume = CurrentVolume + VolumeBelow;
                    VolumeBelow = 0;
                    isUpCluster = false;
                }
                else
                {
                    idxAbove = idxAbove + 2 > idxMax ? idxMax : idxAbove + 2;
                    CurrentVolume = CurrentVolume + VolumeAbove;
                    VolumeAbove = 0;
                    isUpCluster = idxAbove < idxMax;//to unlock
                }

                if (isUpCluster)
                {
                    VolumeAbove = idxAbove + 1 <= idxMax ? profile.AllVolume.ElementAt(idxAbove + 1).Value.getLevelVolume() : 0;
                    if (idxAbove + 2 <= idxMax) VolumeAbove += profile.AllVolume.ElementAt(idxAbove + 2).Value.getLevelVolume();
                }
                else
                {
                    VolumeBelow = idxBelow - 1 >= 0 ? profile.AllVolume.ElementAt(idxBelow - 1).Value.getLevelVolume() : 0;
                    if (idxBelow - 2 >= 0) VolumeBelow += profile.AllVolume.ElementAt(idxBelow - 2).Value.getLevelVolume();
                }
            }
            #endregion

            profile.VWAP      = allvolumes.Count == 0 ? 0 : RTTS(VWAPTotal / AllVolume);
            profile.POCPrice  = POCLevel;
            profile.POCVolume = POCVolume;
            profile.VAH  = allvolumes.Count == 0 ? 0 : profile.AllVolume.ElementAt(idxAbove).Key;//profile.AllVolume.ElementAt(idxAbove).Value.getLevelVolume();
            profile.VAL  = allvolumes.Count == 0 ? 0 : profile.AllVolume.ElementAt(idxBelow).Key;//profile.AllVolume.ElementAt(idxBelow).Value.getLevelVolume(); 
            profile.VAH2 = allvolumes.Count == 0 ? 0 : profile.AllVolume.Max(k => k.Key);//#REMARQUE Quel INTERET??? Toujours at ProfileHigh
            profile.VAL2 = allvolumes.Count == 0 ? 0 : profile.AllVolume.Min(k => k.Key);//#REMARQUE Quel INTERET??? Toujours at ProfileHigh

            profile.ProfileHigh  = allvolumes.Count == 0 ? 0 : profile.AllVolume.Max(k => k.Key);
            profile.ProfileLow   = allvolumes.Count == 0 ? 0 : profile.AllVolume.Min(k => k.Key);
            profile.ProfileStart = CompositeStartBar;
            profile.ProfileEnd   = CurrentBars[0];

            return profile;
        }
        private VolumeProfileS CalculateProfile4(int StartB, SortedDictionary<double, PrintLevelDetails> barPrint)
        {
line=8927;
//#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
			if(CurrentBars[0]> 0 && BARVWAP.IsValidDataPoint(1)){
                BARVWAP[0] = BARVWAP[1];
                BARPOC[0]  = BARPOC[1];
			}else{
	            BARVWAP[0] = Closes[0][0];
    	        BARPOC[0]  = Closes[0][0];
			}
//#endif
            VolumeProfileS profile = new VolumeProfileS();
//try{
            #region -- Fill allvolumes with Print --
            foreach (KeyValuePair<double, PrintLevelDetails> kvp in barPrint)
            {
                if (profile.AllVolume.ContainsKey(kvp.Key))
                {
                    profile.AllVolume[kvp.Key].AskSize = profile.AllVolume[kvp.Key].AskSize + kvp.Value.AskSize;
                    profile.AllVolume[kvp.Key].BidSize = profile.AllVolume[kvp.Key].BidSize + kvp.Value.BidSize;
                }
                else
                {
                    profile.AllVolume.Add(kvp.Key, new VolumeAtBA());
                    profile.AllVolume[kvp.Key].AskSize = kvp.Value.AskSize;
                    profile.AllVolume[kvp.Key].BidSize = kvp.Value.BidSize;
                }
            }
            #endregion

            #region -- Calculate VWAP / Clusters / POC --
            double POCLevel = 0;
            int POCidx = 0;
            double POCVolume = 0;
            double AllVolume = 0;
            double ThisClusterVolume = 0;
            double FinalClusterVolume = 0;
            double VWAPTotal = 0;

            int p;
            for (p = 0; p < profile.AllVolume.Count; p++)
            {
                KeyValuePair<double, VolumeAtBA> level = profile.AllVolume.ElementAt(p);
                double totalvol = level.Value.getLevelVolume();
                VWAPTotal += totalvol * level.Key;
                if (profile.AllVolume.ContainsKey(RTTS(level.Key + gbTickSize)) && profile.AllVolume.ContainsKey(RTTS(level.Key - gbTickSize)))
                {
                    ThisClusterVolume = profile.AllVolume[RTTS(level.Key - gbTickSize)].getLevelVolume() + profile.AllVolume[RTTS(level.Key + gbTickSize)].getLevelVolume() + totalvol;

                    if (ThisClusterVolume > FinalClusterVolume)
                    {
                        FinalClusterVolume = ThisClusterVolume;
                        profile.ClusterTop = RTTS(level.Key + gbTickSize);
                        profile.ClusterBottom = RTTS(level.Key - gbTickSize);
                    }
                }

                AllVolume += totalvol;
                if (totalvol > POCVolume)
                {
                    POCVolume = totalvol;
                    POCLevel = level.Key;
                    POCidx = p;
                }
            }
            #endregion

            #region -- VAH/VAL Calculation --
            double PercentVolume = AllVolume * iVAPercent / 100;
            double CurrentVolume = POCVolume;
            int idxAbove = POCidx;
            int idxBelow = POCidx;
            bool isUpCluster = false;
            int idxMax = profile.AllVolume.Count - 1;

            double VolumeAbove = idxAbove + 1 <= idxMax ? profile.AllVolume.ElementAt(idxAbove + 1).Value.getLevelVolume() : 0;
            if (idxAbove + 2 <= idxMax) VolumeAbove += profile.AllVolume.ElementAt(idxAbove + 2).Value.getLevelVolume();

            double VolumeBelow = idxBelow - 1 >= 0 ? profile.AllVolume.ElementAt(idxBelow - 1).Value.getLevelVolume() : 0;
            if (idxBelow - 2 >= 0) VolumeBelow += profile.AllVolume.ElementAt(idxBelow - 2).Value.getLevelVolume();

            while (CurrentVolume < PercentVolume)
            {
                if (VolumeBelow > VolumeAbove || idxAbove == idxMax)
                {
                    idxBelow = idxBelow - 2 < 0 ? 0 : idxBelow - 2;
                    CurrentVolume = CurrentVolume + VolumeBelow;
                    VolumeBelow = 0;
                    isUpCluster = false;
                }
                else
                {
                    idxAbove = idxAbove + 2 > idxMax ? idxMax : idxAbove + 2;
                    CurrentVolume = CurrentVolume + VolumeAbove;
                    VolumeAbove = 0;
                    isUpCluster = idxAbove < idxMax;//to unlock
                }

                if (isUpCluster)
                {
                    VolumeAbove = idxAbove + 1 <= idxMax ? profile.AllVolume.ElementAt(idxAbove + 1).Value.getLevelVolume() : 0;
                    if (idxAbove + 2 <= idxMax) VolumeAbove += profile.AllVolume.ElementAt(idxAbove + 2).Value.getLevelVolume();
                }
                else
                {
                    VolumeBelow = idxBelow - 1 >= 0 ? profile.AllVolume.ElementAt(idxBelow - 1).Value.getLevelVolume() : 0;
                    if (idxBelow - 2 >= 0) VolumeBelow += profile.AllVolume.ElementAt(idxBelow - 2).Value.getLevelVolume();
                }
            }
            #endregion

            profile.VWAP      = profile.AllVolume.Count==0 || AllVolume == 0 ? 0 : RTTS(VWAPTotal / AllVolume);
            profile.POCPrice  = POCLevel;
            profile.POCVolume = POCVolume;
            profile.VAH  = profile.AllVolume.Count == 0 ? 0 : profile.AllVolume.ElementAt(idxAbove).Key;//profile.AllVolume.ElementAt(idxAbove).Value.getLevelVolume();
            profile.VAL  = profile.AllVolume.Count == 0 ? 0 : profile.AllVolume.ElementAt(idxBelow).Key;//profile.AllVolume.ElementAt(idxBelow).Value.getLevelVolume();
            profile.VAH2 = profile.AllVolume.Count == 0 ? 0 : profile.AllVolume.Max(k => k.Key);//#REMARQUE Quel INTERET??? Toujours at ProfileHigh
            profile.VAL2 = profile.AllVolume.Count == 0 ? 0 : profile.AllVolume.Min(k => k.Key);//#REMARQUE Quel INTERET??? Toujours at ProfileHigh

            profile.ProfileHigh  = profile.AllVolume.Count == 0 ? 0 : profile.AllVolume.Max(k => k.Key);
            profile.ProfileLow   = profile.AllVolume.Count == 0 ? 0 : profile.AllVolume.Min(k => k.Key);
            profile.ProfileStart = CompositeStartBar;
            profile.ProfileEnd   = CurrentBars[0];

line=9053;
            if (CurrentBars[0] > 0 && profile.VWAP > 0.00000001 && profile.POCPrice > 0.00000001)
            {
line=9056;
                BARVWAP[0] = profile.VWAP;
                BARPOC[0]  = profile.POCPrice;
                if (profile.ClusterTop != 0)
                {
line=9061;
                    BARCL[0]  = RTTS(profile.ClusterTop - gbTickSize);
                    BARCLH[0] = profile.ClusterTop;
                    BARCLL[0] = profile.ClusterBottom;
                }
                else
                {
line=9069;
					if(BARCL.IsValidDataPoint(1))  BARCL[0]  = BARCL[1];
					if(BARCLH.IsValidDataPoint(1)) BARCLH[0] = BARCLH[1];
					if(BARCLL.IsValidDataPoint(1))  BARCLL[0] = BARCLL[1];
                }
            }
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
line=9075;
			#region SMA/EMA on bar volume data
			if(iVA1Mode == "SMA"){
				if(CurrentBars[0]<=iVA1Period){
				    MAVWAP[0]  = Close[0];
				    MAPOC[0]   = Close[0];
				    MACL[0]    = Close[0];
				    MACLH[0]   = Close[0];
				    MACLL[0]   = Close[0];
				}else{
				    MAVWAP[0]  = sma_BARVWAP1[0];//SMA(BARVWAP, iVA1Period)[0];
				    MAPOC[0]   = sma_BARPOC1[0];//SMA(BARPOC,  iVA1Period)[0];
				    MACL[0]    = sma_BARCL1[0];//SMA(BARCL,   iVA1Period)[0];
				    MACLH[0]   = sma_BARCLH1[0];//SMA(BARCLH,  iVA1Period)[0];
				    MACLL[0]   = sma_BARCLL1[0];//SMA(BARCLL,  iVA1Period)[0];
				}
				if(CurrentBars[0]<=iVA2Period){
				    MA2VWAP[0] = Close[0];
				    MA2POC[0]  = Close[0];
				    MA2CL[0]   = Close[0];
				    MA2CLH[0]  = Close[0];
				    MA2CLL[0]  = Close[0];
				}else{
				    MA2VWAP[0] = sma_BARVWAP2[0];//SMA(BARVWAP, iVA2Period)[0];
				    MA2POC[0]  = sma_BARPOC2[0];//SMA(BARPOC,  iVA2Period)[0];
				    MA2CL[0]   = sma_BARCL2[0];//SMA(BARCL,   iVA2Period)[0];
				    MA2CLH[0]  = sma_BARCLH2[0];//SMA(BARCLH,  iVA2Period)[0];
				    MA2CLL[0]  = sma_BARCLL2[0];//SMA(BARCLL,  iVA2Period)[0];
				}
			}else{//iVA1Mode == "EMA"
				if(CurrentBars[0]<=iVA1Period){
				    MAVWAP[0]  = Close[0];
				    MAPOC[0]   = Close[0];
				    MACL[0]    = Close[0];
				    MACLH[0]   = Close[0];
				    MACLL[0]   = Close[0];
				}else{
				    MAVWAP[0]  = ema_BARVWAP1[0];//EMA(BARVWAP, iVA1Period)[0];
				    MAPOC[0]   = ema_BARPOC1[0];//EMA(BARPOC,  iVA1Period)[0];
				    MACL[0]    = ema_BARCL1[0];//EMA(BARCL,   iVA1Period)[0];
				    MACLH[0]   = ema_BARCLH1[0];//EMA(BARCLH,  iVA1Period)[0];
				    MACLL[0]   = ema_BARCLL1[0];//EMA(BARCLL,  iVA1Period)[0];
				}
				if(CurrentBars[0]<=iVA2Period){
				    MA2VWAP[0]  = Close[0];
				    MA2POC[0]   = Close[0];
				    MA2CL[0]    = Close[0];
				    MA2CLH[0]   = Close[0];
				    MA2CLL[0]   = Close[0];
				}else{
				    MA2VWAP[0] = ema_BARVWAP2[0];//EMA(BARVWAP, iVA2Period)[0];
				    MA2POC[0]  = ema_BARPOC2[0];//EMA(BARPOC,  iVA2Period)[0];
				    MA2CL[0]   = ema_BARCL2[0];//EMA(BARCL,   iVA2Period)[0];
				    MA2CLH[0]  = ema_BARCLH2[0];//EMA(BARCLH,  iVA2Period)[0];
				    MA2CLL[0]  = ema_BARCLL2[0];//EMA(BARCLL,  iVA2Period)[0];
				}
			}
			#endregion

			#region Try to determine when to start the printing of the vol ma's
			if(CurrentBars[0]>10 && iVA1StartBar == int.MaxValue){//the first bar for the VolAvg 1 is when the POC crosses through a bar
//if(CurrentBars[0]<200)Print("Lows[0][1]: "+Lows[0][1]+"  Highs[0][1]: "+Highs[0][1]+"   MACLL: "+MACLL[0]);
				if(Lows[0][1] < MACLL[0] && Highs[0][0] > MACLL[0]) iVA1StartBar = CurrentBars[0];
				if(Highs[0][1] > MACLL[0] && Lows[0][0] < MACLL[0]) iVA1StartBar = CurrentBars[0];
			}
			if(CurrentBars[0]>10 && iVA2StartBar == int.MaxValue){//the first bar for the VolAvg 1 is when the POC crosses through a bar
				if(Lows[0][1] < MA2CLL[0] && Highs[0][0] > MA2CLL[0]) iVA2StartBar = CurrentBars[0];
				if(Highs[0][1] > MA2CLL[0] && Lows[0][0] < MA2CLL[0]) iVA2StartBar = CurrentBars[0];
			}
			#endregion

			#region assign to plots
            if (iVA1Enabled)
            {
                if (iVA1Enabled1) Values[3][0] = MAPOC[0];
                if (iVA1Enabled2) Values[2][0] = MAVWAP[0];
                if (iVA1Enabled3)
                {
                    Values[1][0] = MACLH[0];
                    Values[0][0] = MACLL[0];
                }
            }

            if (iVA2Enabled)
            {
                if (iVA2Enabled1) Values[7][0] = MA2POC[0];
                if (iVA2Enabled2) Values[6][0] = MA2VWAP[0];
                if (iVA2Enabled3)
                {
                    Values[5][0] = MA2CLH[0];
                    Values[4][0] = MA2CLL[0];
                }
            }
			#endregion
#else
			if(iVA1Mode[0]=='E'){
				MA1High[0] = ema_ma1[0] + iVA1_ClusterSizeTicks/2.0*TickSize;
				MA1Low[0]  = ema_ma1[0] - iVA1_ClusterSizeTicks/2.0*TickSize;
			}
			else if(iVA1Mode[0]=='S'){
				MA1High[0] = sma_ma1[0] + iVA1_ClusterSizeTicks/2.0*TickSize;
				MA1Low[0]  = sma_ma1[0] - iVA1_ClusterSizeTicks/2.0*TickSize;
			}
			if(iVA2Mode[0]=='E'){
				MA2High[0] = ema_ma2[0] + iVA2_ClusterSizeTicks/2.0*TickSize;
				MA2Low[0]  = ema_ma2[0] - iVA2_ClusterSizeTicks/2.0*TickSize;
			}
			else if(iVA2Mode[0]=='S'){
				MA2High[0] = sma_ma2[0] + iVA2_ClusterSizeTicks/2.0*TickSize;
				MA2Low[0]  = sma_ma2[0] - iVA2_ClusterSizeTicks/2.0*TickSize;
			}
#endif
line=9187;

            BARVAH[0] = profile.VAH;
            BARVAL[0] = profile.VAL;
//Draw.Dot(this,"BVAH"+CurrentBars[0].ToString(), false, 0, BARPOC[0], Brushes.Red);
//}catch(Exception eee){Print(line+":  "+eee.ToString());}
            return profile;
        }
        #endregion

        #region -- Low Level Drawing Functions - AzurITec --
//        //Draw Rectangle. Rect as pixel coordinate
//        private void drawRectangle(Rect rectangle, Brush color, int width, DashStyleHelper dashstyle = DashStyleHelper.Solid)
//        {
//            drawRectangle(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, color, dashstyle, width);
//        }
//        //Draw Rectangle. x and y as pixel coordinate, w and h in pixel too.
//        private void drawRectangle(double x, double y, double w, double h, Brush color, DashStyleHelper dashstyle, int width)
//        {
//            drawRectangle(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, color, dashstyle, width);
//        }
        //Draw Rectangle. Rect as pixel coordinate
        private void drawRectangle(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush, int width, DashStyleHelper dashstyle = DashStyleHelper.Solid)
        {
            drawRectangle(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, dxbrush, dashstyle, width);
        }
        //Draw Rectangle. x and y as pixel coordinate, w and h in pixel too.
        private void drawRectangle(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
        {
            drawRectangle(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush, dashstyle, width);
        }
        //Draw Rectangle. points are in pixel coordinate.
//        private void drawRectangle(Point[] points, Brush couleur, DashStyleHelper dashstyle, int width)
//        {
//            drawLine(points[0].X, points[1].X, points[0].Y, points[1].Y, couleur, dashstyle, width);
//            drawLine(points[1].X, points[2].X, points[1].Y, points[2].Y, couleur, dashstyle, width);
//            drawLine(points[2].X, points[3].X, points[2].Y, points[3].Y, couleur, dashstyle, width);
//            drawLine(points[3].X, points[0].X, points[3].Y, points[0].Y, couleur, dashstyle, width);
//        }
        private void drawRectangle(Point[] points, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
        {
            drawLine(points[0].X, points[1].X, points[0].Y, points[1].Y, dxbrush, dashstyle, width);
            drawLine(points[1].X, points[2].X, points[1].Y, points[2].Y, dxbrush, dashstyle, width);
            drawLine(points[2].X, points[3].X, points[2].Y, points[3].Y, dxbrush, dashstyle, width);
            drawLine(points[3].X, points[0].X, points[3].Y, points[0].Y, dxbrush, dashstyle, width);
        }
        //Draw a line between 2 points in pixel coordinates.
//        private void drawLine(double x1, double x2, double y1, double y2, Brush couleur, DashStyleHelper dashstyle, int width)
//        {
//            SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
//            SharpDX.Direct2D1.DashStyle _dashstyle;
//            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

//            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
//            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

//            Point p0 = new Point(x1, y1);
//            Point p1 = new Point(x2, y2);
//            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

//            linebrush.Dispose();
//            strokestyle.Dispose();
//        }
        private void drawLine(double x1, double x2, double y1, double y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
        {
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            Point p0 = new Point(x1, y1);
            Point p1 = new Point(x2, y2);
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), dxbrush, width, strokestyle);

            strokestyle.Dispose();
        }
        //Draw Region between 4 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawRegion(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale)
        {
#if USE_WPF_COORDS
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl), chartScale.GetYByValueWpf(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl), chartScale.GetYByValueWpf(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl), chartScale.GetYByValueWpf(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl), chartScale.GetYByValueWpf(yValues[3]))
                },
                dxbrush
                );
#else
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl), chartScale.GetYByValue(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl), chartScale.GetYByValue(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl), chartScale.GetYByValue(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl), chartScale.GetYByValue(yValues[3]))
                },
                dxbrush
                );
#endif
        }

        //Draw Region between 4 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
//        private void drawRegion(double[] yValues, int[] xIndex, Brush color, int opacity, ChartControl chartControl, ChartScale chartScale)
//        {
//#if USE_WPF_COORDS
//            drawRegion(new Point[]{
//                    new Point(GetX0(xIndex[0], chartControl), chartScale.GetYByValueWpf(yValues[0])),
//                    new Point(GetX0(xIndex[1], chartControl), chartScale.GetYByValueWpf(yValues[1])),
//                    new Point(GetX0(xIndex[2], chartControl), chartScale.GetYByValueWpf(yValues[2])),
//                    new Point(GetX0(xIndex[3], chartControl), chartScale.GetYByValueWpf(yValues[3]))
//                },
//                color,
//                opacity
//                );
//#else
//            drawRegion(new Point[]{
//                    new Point(GetX0(xIndex[0], chartControl), chartScale.GetYByValue(yValues[0])),
//                    new Point(GetX0(xIndex[1], chartControl), chartScale.GetYByValue(yValues[1])),
//                    new Point(GetX0(xIndex[2], chartControl), chartScale.GetYByValue(yValues[2])),
//                    new Point(GetX0(xIndex[3], chartControl), chartScale.GetYByValue(yValues[3]))
//                },
//                color,
//                opacity
//                );
//#endif
//        }
		//Draw Region between 4 points. Coordinates are in pixel.
//        private void drawRegion(Point[] points, Brush color, int opacity = 100)
//        {
//            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
//            linebrush.Opacity = opacity / 100f;

//            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

//            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
//            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
//            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
//            sink1.AddLines(vectors);
//            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
//            sink1.Close();

//            RenderTarget.FillGeometry(geo1, linebrush);
//            geo1.Dispose();
//            sink1.Dispose();
//            linebrush.Dispose();
//        }
        private void drawRegion(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
        {
            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();
        }
//        //Draw Region. Rect in pixel coordinate.
//        private void drawRegion(Rect rectangle, Brush color, int opacity = 100)
//        {
//            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, color, opacity);
//        }
//        //Draw Region. x and y as pixel coordinate, w and h in pixel too.
//        private void drawRegion(double x, double y, double w, double h, Brush color, int opacity = 100)
//        {
//            drawRegion(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, color, opacity);
//        }
        //Draw Region. Rect in pixel coordinate.
        private void drawRegion(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush)
        {
            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, dxbrush);
        }
        private void drawRegion(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush, int MinHeight)
        {
            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, Math.Max(MinHeight,rectangle.Height), dxbrush);
        }
        //Draw Region. x and y as pixel coordinate, w and h in pixel too.
        private void drawRegion(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush)
        {
            drawRegion(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush);
        }

//        private void fillEllipse(Rect rectangle, Brush color, int opacity = 100)
//        {
//            Point center = new Point(rectangle.X + rectangle.Width / 2, rectangle.Y + rectangle.Height / 2);
//            float radiusX = (float)rectangle.Width / 2f;
//            float radiusY = (float)rectangle.Height / 2f;

//            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
//            linebrush.Opacity = opacity / 100f;

//            SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(center.ToVector2(), radiusX, radiusY);
//            RenderTarget.FillEllipse(ellipse, linebrush);

//            linebrush.Dispose();
//        }
        private void fillEllipse(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush)
        {
            Point center = new Point(rectangle.X + rectangle.Width / 2, rectangle.Y + rectangle.Height / 2);
            float radiusX = Convert.ToSingle(rectangle.Width) / 2f;
            float radiusY = Convert.ToSingle(rectangle.Height) / 2f;

            SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(center.ToVector2(), radiusX, radiusY);
            RenderTarget.FillEllipse(ellipse, dxbrush);
        }
        //Fill a Polygon from points given in x;y coordinates
//        private void fillPolygon(Point[] points, Brush color, int opacity = 100)
//        {
//            SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
//            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

//            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
//            linebrush.Opacity = opacity / 100f;

//            //SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };
//            SharpDX.Vector2[] vectors = new SharpDX.Vector2[points.Count() - 1];
//            for (int v = 1; v < points.Count(); v++) vectors[v - 1] = points[v].ToVector2();

//            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
//            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
//            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
//            sink1.AddLines(vectors);
//            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
//            sink1.Close();

//            RenderTarget.FillGeometry(geo1, linebrush);
//            geo1.Dispose();
//            sink1.Dispose();
//            linebrush.Dispose();

//            RenderTarget.AntialiasMode = oldAntialiasMode;
//        }
        private void fillPolygon(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
        {
            SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

            //SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };
            SharpDX.Vector2[] vectors = new SharpDX.Vector2[points.Count() - 1];
            for (int v = 1; v < points.Count(); v++) vectors[v - 1] = points[v].ToVector2();

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();

            RenderTarget.AntialiasMode = oldAntialiasMode;
        }
        //Fill a Polygon from points given in x;y coordinates
        private void drawPolygon(Point[] points, Brush color, int width, int opacity = 100, DashStyleHelper dashstyle = DashStyleHelper.Solid)
        {
            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            linebrush.Opacity = opacity / 100f;
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;
            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            SharpDX.Vector2[] vectors = new SharpDX.Vector2[points.Count() - 1];
            for (int v = 1; v < points.Count(); v++) vectors[v - 1] = points[v].ToVector2();

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.DrawGeometry(geo1, linebrush, width, strokestyle);
            geo1.Dispose();
            sink1.Dispose();
            linebrush.Dispose();
            strokestyle.Dispose();
        }
        private void drawPolygon(Point[] points, SharpDX.Direct2D1.Brush dxbrush, int width, DashStyleHelper dashstyle = DashStyleHelper.Solid)
        {
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;
            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            SharpDX.Vector2[] vectors = new SharpDX.Vector2[points.Count() - 1];
            for (int v = 1; v < points.Count(); v++) vectors[v - 1] = points[v].ToVector2();

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.DrawGeometry(geo1, dxbrush, width, strokestyle);
            geo1.Dispose();
            sink1.Dispose();
            strokestyle.Dispose();
        }
        //Draw a line between 2 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawLine(double value1, double value2, int idxslot1, int idxslot2, Brush color, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale)
        {
            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

#if USE_WPF_COORDS
            Point p0 = new Point(GetX0(idxslot1, chartControl), chartScale.GetYByValueWpf(value1));
            Point p1 = new Point(idxslot2 == 0 ? GetX0(Math.Min(CurrentBar, ChartBars.ToIndex), chartControl) : GetX0(idxslot2, chartControl), chartScale.GetYByValueWpf(value2));
#else
            Point p0 = new Point(GetX0(idxslot1, chartControl), chartScale.GetYByValue(value1));
            Point p1 = new Point(idxslot2 == 0 ? GetX0(Math.Min(CurrentBar, ChartBars.ToIndex), chartControl) : GetX0(idxslot2, chartControl), chartScale.GetYByValue(value2));
#endif
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }
        private void drawLine(double value, int idxslot1, int idxslot2, Brush color, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale) { drawLine(value, value, idxslot1, idxslot2, color, dashstyle, width, chartControl, chartScale); }
        private void drawLine(double value1, double value2, int idxslot1, int idxslot2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale)
        {
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

#if USE_WPF_COORDS
            Point p0 = new Point(GetX0(idxslot1, chartControl), chartScale.GetYByValueWpf(value1));
            Point p1 = new Point(idxslot2 == 0 ? GetX0(Math.Min(CurrentBar, ChartBars.ToIndex), chartControl) : GetX0(idxslot2, chartControl), chartScale.GetYByValueWpf(value2));
#else
            Point p0 = new Point(GetX0(idxslot1, chartControl), chartScale.GetYByValue(value1));
            Point p1 = new Point(idxslot2 == 0 ? GetX0(Math.Min(CurrentBar, ChartBars.ToIndex), chartControl) : GetX0(idxslot2, chartControl), chartScale.GetYByValue(value2));
#endif
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), dxbrush, width, strokestyle);
            strokestyle.Dispose();
        }
        private void drawLine(double value, int idxslot1, int idxslot2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale) { drawLine(value, value, idxslot1, idxslot2, dxbrush, dashstyle, width, chartControl, chartScale); }
        private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
            //SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                Convert.ToSingle(font.Size)
                )
            { TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
        }
        private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.Direct2D1.Brush fillDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
            //SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                Convert.ToSingle(font.Size)
                )
            { TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

			RenderTarget.FillRectangle(new SharpDX.RectangleF(Convert.ToSingle(x-5), Convert.ToSingle(y-5), textLayout.Metrics.Width+10, Convert.ToSingle(font.Size+10)), fillDXBrush);
            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
        }

        private double CalculateOptimalFontSize(double maxWidth, string text, SimpleFont font)
        {
            double fsize = font.Size;
            for (fsize = font.Size; fsize > 0; fsize--)
            {
                font.Size = fsize;
                float txtwidth = getTextWidth(text, font);
                if (txtwidth < maxWidth) break;
            }
            return fsize;
        }
        private float getTextWidth(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                Convert.ToSingle(font.Size)
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }
        private float[] getTextWidthHeight(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                Convert.ToSingle(font.Size)
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			var result = new float[2]{textLayout.Metrics.Width, textLayout.Metrics.Height};

            textLayout.Dispose();
            textFormat.Dispose();

            return result;
        }
        //private int GetX0(int bars, ChartControl chartControl) { return chartControl.GetXByBarIndex(ChartBars, bars); }//NEW indicatorVersion NT8
        private int GetX0(int bars, ChartControl chartControl, bool atMiddle = false) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars) - (atMiddle ? (int)(chartControl.Properties.BarDistance / 2) : 0); }//NEW indicatorVersion NT8        

        #endregion

//================================================================================================================================================
        private SortedDictionary<double, PrintLevelDetails> ProcessFootSignals(SortedDictionary<double, PrintLevelDetails> SL)
        {
			SortedDictionary<double, PrintLevelDetails> ThisI = new SortedDictionary<double, PrintLevelDetails>();
			var items = from pair in SL orderby pair.Key descending select pair;

			ThisI          = SL;
			double bidt    = 0;
			double askt    = 0;
			bool ttt       = true;
			double tttv    = 0;
			double prevvol = 0;

			int TCB = BarsAreMinute ? CurrentBars[0] : ThisCurrentBar;
//if(IsDebug) Print("CB: "+CurrentBars[0]+"   ThisCurrentBar: "+ThisCurrentBar+"   "+(CurrentBars[0]!=ThisCurrentBar ? "))))))))))))))))))))))))))))) different":""));

			BarDataTotals[TCB] = new BarTotal();
			BarDataTotals[TCB].MaxBid = 0;
			BarDataTotals[TCB].MaxAsk = 0;
			BarDataTotals[TCB].TrappedTraderN = 0;
			BarDataTotals[TCB].POC = 0;
			int barsAgoIndex = CurrentBars[0] - TCB;

			// add the profile
			if (BarProfiles.ContainsKey(TCB)) BarProfiles[TCB] = CalculateProfile4(TCB, SL);
			else BarProfiles.Add(TCB, CalculateProfile4(TCB, SL));
//if(z){
//	Print(Times[0][0].ToString());
//	foreach(var kk in AI){
//		Print(string.Format("     {0} :  {1} / {2}",kk.Key, kk.Value.BidSize, kk.Value.AskSize));
//	}
//}
			foreach (KeyValuePair<double, PrintLevelDetails> kvp2 in items)
			{
				if (kvp2.Key > Highs[0][barsAgoIndex] + 0.0000001 || kvp2.Key < Lows[0][barsAgoIndex] - 0.0000001) continue;
				if (ttt){
					if (kvp2.Value.AskSize > prevvol) tttv = tttv - 1;
					else ttt = false;
					prevvol = kvp2.Value.AskSize;
                }
//if(z){
//	Print(Times[0][0].ToString());
//	foreach(var kk in AI){
//		Print(string.Format("     {0} :  {1} / {2}",kk.Key, kk.Value.BidSize, kk.Value.AskSize));
//	}
//}
				bidt = bidt + kvp2.Value.BidSize;
				askt = askt + kvp2.Value.AskSize;
				BarDataTotals[TCB].MaxBid  = Math.Max(BarDataTotals[TCB].MaxBid, kvp2.Value.BidSize);
				BarDataTotals[TCB].MaxAsk  = Math.Max(BarDataTotals[TCB].MaxAsk, kvp2.Value.AskSize);
            }
			#region VD Signals
			VDSIGNALS[0] = FLAT;
            if(Closes[0].GetValueAt(TCB) >= Opens[0].GetValueAt(TCB) && BarProfiles[TCB].ClusterTop > 0 && BarProfiles[TCB].ClusterTop < (IsDebug?Opens00:Opens00))
                VDSIGNALS[0] = BUY;
            else if(Closes[0].GetValueAt(TCB) <= Opens[0].GetValueAt(TCB) && BarProfiles[TCB].ClusterBottom > 0 && BarProfiles[TCB].ClusterBottom > (IsDebug?Opens00:Opens00))
                VDSIGNALS[0] = SELL;
            volumedivergenceDefault[0] = VDSIGNALS[0];//added by BenL - no other place where volumedivergenceDefault was being set
//			if(IsCurrentBar && VDSIGNALS[0]!=0 && AudibleAlertMgr !=null && AudibleAlertMgr.VDabar != CurrentBars[0]) AudibleAlertMgr.Play(this, (int)VDSIGNALS[0], "VD", CurrentBars[0]);
			#endregion
            #region VCR Signals
            VCRSIGNALS[0] = FLAT;

            if (BarProfiles.ContainsKey(TCB - 1) && BarProfiles.ContainsKey(TCB - 2))
            {
                double cMid0 = (BarProfiles[TCB].ClusterTop + BarProfiles[TCB].ClusterBottom) / 2;
                double cMid1 = (BarProfiles[TCB - 1].ClusterTop + BarProfiles[TCB - 1].ClusterBottom) / 2;
                double cMid2 = (BarProfiles[TCB - 2].ClusterTop + BarProfiles[TCB - 2].ClusterBottom) / 2;
                double cTop0 = BarProfiles[TCB].ClusterTop;
                double cBot0 = BarProfiles[TCB].ClusterBottom;
                double cTop1 = BarProfiles[TCB - 1].ClusterTop;
                double cBot1 = BarProfiles[TCB - 1].ClusterBottom;
                double cTop2 = BarProfiles[TCB - 2].ClusterTop;
                double cBot2 = BarProfiles[TCB - 2].ClusterBottom;
                double barMid0 = (Highs[0].GetValueAt(TCB) + Lows[0].GetValueAt(TCB)) / 2;
                double barMid1 = (Highs[0].GetValueAt(TCB-1) + Lows[0].GetValueAt(TCB-1)) / 2;

                if (pShow_VCR2b){
					bool c1 = Closes[0].GetValueAt(TCB) > Opens[0].GetValueAt(TCB);
					bool c2 = Closes[0].GetValueAt(TCB) == Opens[0].GetValueAt(TCB) && Closes[0].GetValueAt(TCB) > barMid0;
					c1 = (c1 || c2);
					c2 = Closes[0].GetValueAt(TCB-1) <= Opens[0].GetValueAt(TCB-1);
					bool c3 = cBot0 >= cTop1;
	                if (c1 && c2 && c3)
    	            {
        	            VCRSIGNALS[0] = 1;
            	    }
				}
				

				if(pShow_VCR3b){
					bool c1 = Closes[0].GetValueAt(TCB) > Opens[0].GetValueAt(TCB);
					bool c2 = Closes[0].GetValueAt(TCB) == Opens[0].GetValueAt(TCB) && Closes[0].GetValueAt(TCB) > barMid0;
					c1 = c1 || c2;
					c2 = Closes[0].GetValueAt(TCB-1) >= Opens[0].GetValueAt(TCB-1);
					bool c3 = Closes[0].GetValueAt(TCB-2) <= Opens[0].GetValueAt(TCB-2);
					bool c4 = (pShow_Absolute3Bar ? cBot0 >= cTop2 : cBot0 >= cTop1);
					if (c1 && c2 && c3 && c4)
					{
					    VCRSIGNALS[0] = 2;
					}
				}

                if (pShow_VCR2b){
					bool c1 = Closes[0].GetValueAt(TCB) < Opens[0].GetValueAt(TCB);
					bool c2 = Closes[0].GetValueAt(TCB) == Opens[0].GetValueAt(TCB) && Closes[0].GetValueAt(TCB) < barMid0;
					c1 = c1 || c2;
					c2 = Closes[0].GetValueAt(TCB-1) >= Opens[0].GetValueAt(TCB-1);
					bool c3 = cTop0 <= cBot1;
	                if (c1 && c2 && c3)
    	            {
                	    //Print(Time[0].ToString() + ", 0: " + cMid0 + ", 1: " + cMid1 + ", 2: " + cMid2);
        	            VCRSIGNALS[0] = -1;
            	    }
				}
				if(pShow_VCR3b){
					bool c1 = Closes[0].GetValueAt(TCB) < Opens[0].GetValueAt(TCB);
					bool c2 = Closes[0].GetValueAt(TCB) == Opens[0].GetValueAt(TCB) && Closes[0].GetValueAt(TCB) < barMid0;
					c1 = c1 || c2;
					c2 = Closes[0].GetValueAt(TCB-1) <= Opens[0].GetValueAt(TCB-1);
					bool c3 = Closes[0].GetValueAt(TCB-2) >= Opens[0].GetValueAt(TCB-2);
					bool c4 = pShow_Absolute3Bar ? cTop0 <= cBot2 : cTop0 <= cBot1;
					if (c1 && c2 && c3 && c4)
    	            {
        	            //Print(Time[0].ToString() + ", 0: " + cMid0 + ", 1: " + cMid1 + ", 2: " + cMid2);
            	        VCRSIGNALS[0] = -2;
                	}
				}
            }
			#endregion
			#region TT Signals
			if (IsCurrentBar)
			{
line=9856;
			    trappedtraderDefault[0]    = FLAT;
			    deltadivergenceDefault[0]  = FLAT;
			    volumedivergenceDefault[0] = FLAT;
			}
			if (iHighLowRangeFilter)
			{
line=9863;
			    if (Highs[0].IsValidDataPoint(TCB - 1) && Highs[0].GetValueAt(TCB) > Highs[0].GetValueAt(TCB-1) && Direction[0]==-1 && tttv <= -1 * iMinimumDecliningLevels)
			    {
			        BarDataTotals[TCB].TrappedTraderN = tttv;
			        if (IsCurrentBar) {
						trappedtraderDefault[0] = SELL;
					}
			    }
			}
            else if (Closes[0].IsValidDataPoint(TCB - 1) && Direction[0]==-1 && tttv <= -1 * iMinimumDecliningLevels)
            {
line=9875;
                BarDataTotals[TCB].TrappedTraderN = tttv;
                if (IsCurrentBar) {
					trappedtraderDefault[0] = SELL;
				}
            }
//if(trappedtraderDefault[0]!=FLAT)Print("trappedtraderDefault on bar "+CurrentBars[0]+"   "+Times[0][0].ToString());
			#endregion

            BarDataTotals[TCB].AskTotal = askt;
            BarDataTotals[TCB].BidTotal = bidt;
            NETDELTA[0] = askt - bidt;
			if(NETDELTA[0]>0){
				NetD_MaxMgr.AddLong(Convert.ToInt64(NETDELTA[0]), CurrentBars[0]);
				NetD_MinMgr.NoChange(CurrentBars[0]);
//				if(!NetD_MaxMgr.Initialized) Print("MaxMgr is NOT initialized!");
//				if(NetD_MaxMgr.Status.Length>0) Print("MaxMgr.Status: "+NetD_MaxMgr.Status);
			}else{ 
				NetD_MinMgr.AddLong(Convert.ToInt64(Math.Abs(NETDELTA[0])), CurrentBars[0]);
				NetD_MaxMgr.NoChange(CurrentBars[0]);
//				if(!NetD_MinMgr.Initialized) Print("MinMgr is NOT initialized!");
//				if(NetD_MinMgr.Status.Length>0) Print("MinMgr.Status: "+NetD_MinMgr.Status);
			}
//			if(CurrentBars[0]>100){
//				Print(CurrentBars[0]+"  "+NETDELTA[0]+"   a: "+askt+"   b: "+bidt+"    MaxA: "+NetD_MaxMgr.GetMax(CurrentBars[0])+"   MaxB: "+NetD_MinMgr.GetMax(CurrentBars[0]));
//				Print("    3-bars ago:    MaxAsk: "+NetD_AsksMgr.GetMax(CurrentBars[0]-3)+"   MaxBid: "+NetD_BidsMgr.GetMax(CurrentBars[0]-3));
			//}

			ttt = true;
            tttv = 0;
            prevvol = 0;

            // loop through lowest to highest price
            AllPrices.Clear();
            AllPrices2.Clear();
            double CurrentVolumeAtPrice = 0;
            double CurrentMaximumVolume = 0;
            double CurrentPOCPrice      = 0;

            bool IsFirst = true;
            int C        = 0;
			double thisbidsize = 0;
			double thisasksize = 0;
			double NextAsk= 0;
			double AskS   = 0;
			double AskI   = 0;
			double BidS   = 0;
			double BidI   = 0;
			double AskMin = 0;
			double BidMin = 0;
			bool IsLast   = false;
            foreach (KeyValuePair<double, PrintLevelDetails> kvp2 in SL)
            {
				#region -- x --
                if (kvp2.Key > Highs[0][barsAgoIndex] || kvp2.Key < Lows[0][barsAgoIndex]) continue;
                thisbidsize = kvp2.Value.BidSize;
                thisasksize = kvp2.Value.AskSize;
                ThisI[kvp2.Key].POC  = false;
                ThisI[kvp2.Key].DIFF = Math.Abs(thisbidsize - thisasksize);
                ThisI[kvp2.Key].UFA  = false;

                C++;
                IsLast = C == SL.Count && kvp2.Key == Highs00;

                if (kvp2.Key != Lows00) IsFirst = false;
                if (IsFirst || IsLast)
                {
                    IsFirst = false;
                    if (thisbidsize != 0 && thisasksize != 0) ThisI[kvp2.Key].UFA = true;
                }

                if (ttt)
                {
                    if (thisbidsize > prevvol) tttv = tttv + 1;
                    else ttt = false;
                    prevvol = thisbidsize;
                }

                NextAsk = RTTS(kvp2.Key + gbTickSize);

                if (SL.ContainsKey(NextAsk))
                {
                    AskS = Math.Max(SL[NextAsk].AskSize, 1);
                    BidS = Math.Max(thisbidsize, 1);
                    AskI = (AskS / BidS);
                    BidI = (BidS / AskS);

                    ThisI[NextAsk].AskImbalance = 0;
                    ThisI[kvp2.Key].BidImbalance = 0;

					AskMin = (double)askt / (double)SL.Count / (double)100 * iVolumeQualifier;
                    BidMin = (double)bidt / (double)SL.Count / (double)100 * iVolumeQualifier;

                    if (AskI > iImbalanceOffset && BidS >= BidMin)
                    {
                        ThisI[NextAsk].AskImbalance = AskI;
                        AllPrices2.Add(NextAsk);
                    }
                    else if (BidI > iImbalanceOffset && AskS >= AskMin)
                    {
                        ThisI[kvp2.Key].BidImbalance = BidI;
                        AllPrices.Add(kvp2.Key);
                    }
                }

                CurrentVolumeAtPrice = thisasksize + thisbidsize;
                if (CurrentVolumeAtPrice > CurrentMaximumVolume)
                {
                    CurrentMaximumVolume = CurrentVolumeAtPrice;
                    CurrentPOCPrice = kvp2.Key;
                }
				#endregion
            }

            if (CurrentPOCPrice != 0) ThisI[CurrentPOCPrice].POC = true;
            double bottomn = 0;
            int csize = 0;
            Zone Z;

            #region -- ADD DEMAND ZONES --
            DemandZones[TCB] = new List<Zone>();
            foreach (double d in AllPrices2)
            {
                if (d <= Highs00)
                {
                    if (bottomn == 0)
                    {
                        bottomn = d;
                        csize++;
                    }
                    else
                    {
                        if (RTTS(bottomn + gbTickSize * csize) == d) csize++;
                        else
                        {
                            if (csize >= iMinZWidth)
                            {
                                Z = new Zone();
                                Z.BottomPrice = bottomn;
                                Z.TopPrice = bottomn + (csize - 1) * gbTickSize;
                                Z.TicksWidth = csize;
                                Z.TestedPrice = 0;
                                Z.IsBroken = false;
                                Z.IsHidden = false;
                                Z.EndBar = 0;

                                if (Closes[0][CurrentBars[0] - TCB] > Z.BottomPrice) DemandZones[TCB].Add(Z);
                            }
                            csize = 1;
                            bottomn = d;
                        }
                    }
                }
            }

            if (csize >= iMinZWidth)
            {
                Z = new Zone();
                Z.BottomPrice = bottomn;
                Z.TopPrice = bottomn + (csize - 1) * gbTickSize;
                Z.TicksWidth = csize;
                Z.TestedPrice = 0;
                Z.IsBroken = false;
                Z.IsHidden = false;
                Z.EndBar = 0;

                if (Closes[0][CurrentBars[0] - TCB] > Z.BottomPrice) DemandZones[TCB].Add(Z);
            }
            #endregion

            csize = 0;
            #region -- ADD SUPPLY ZONES --
            SupplyZones[TCB] = new List<Zone>();
            foreach (double d in AllPrices)
            {
                if (d <= Highs00)
                {
                    if (bottomn == 0)
                    {
                        bottomn = d;
                        csize++;
                    }
                    else
                    {
                        if (RTTS(bottomn + gbTickSize * csize) == d) csize++;
                        else
                        {
                            if (csize >= iMinZWidth)
                            {
                                Z = new Zone();
                                Z.BottomPrice = bottomn;
                                Z.TopPrice = bottomn + (csize - 1) * gbTickSize;
                                Z.TicksWidth = csize;
                                Z.TestedPrice = 0;
                                Z.IsBroken = false;
                                Z.IsHidden = false;
                                Z.EndBar = 0;

                                if (Closes[0][CurrentBars[0] - TCB] < Z.TopPrice) SupplyZones[TCB].Add(Z);
                            }
                            csize = 1;
                            bottomn = d;
                        }
                    }
                }
            }

            if (csize >= iMinZWidth)
            {
                Z = new Zone();
                Z.BottomPrice = bottomn;
                Z.TopPrice = bottomn + (csize - 1) * gbTickSize;
                Z.TicksWidth = csize;
                Z.TestedPrice = 0;
                Z.IsBroken = false;
                Z.IsHidden = false;
                Z.EndBar = 0;

                if (Closes[0][CurrentBars[0] - TCB] < Z.TopPrice) SupplyZones[TCB].Add(Z);
            }
            #endregion

			if (iHighLowRangeFilter)
            {
                if (Lows[0].IsValidDataPoint(CurrentBars[0] - 1) && Lows[0][0] < Lows[0][1] && Direction[0]==1 && tttv >= 1 * iMinimumDecliningLevels)
                {
                    BarDataTotals[TCB].TrappedTraderN = tttv;
                    if (IsCurrentBar) {
						trappedtraderDefault[0] = BUY;
					}
                }
            }
            else
            {
                if (Closes[0].IsValidDataPoint(CurrentBars[0] - 1) && Direction[0]==1 && tttv >= 1 * iMinimumDecliningLevels)
                {
                    BarDataTotals[TCB].TrappedTraderN = tttv;
                    if (IsCurrentBar) {
						trappedtraderDefault[0] = BUY;
					}
                }
            }
//if(trappedtraderDefault[0]!=FLAT)Print("trappedtraderDefault on bar "+CurrentBars[0]+"   "+Times[0][0].ToString());

            if (Highs[0].IsValidDataPoint(CurrentBars[0] - 1) && CurrentBars[0] >= iLookBack && Highs[0][0] >= MAX(Highs[0], iLookBack + 1)[0] && Direction[0]==-1 &&
                BarDataTotals[TCB].AskTotal - BarDataTotals[TCB].BidTotal < 0)
            {
                BarDataTotals[TCB].POC = -1;
                if (IsCurrentBar)
					deltadivergenceDefault[0] = SELL;
			}

			if (Lows[0].IsValidDataPoint(CurrentBars[0] - 1) && CurrentBars[0] >= iLookBack && Lows[0][0] <= MIN(Lows[0], iLookBack + 1)[0] && Direction[0]==1 &&
				BarDataTotals[TCB].AskTotal - BarDataTotals[TCB].BidTotal > 0)
			{
				BarDataTotals[TCB].POC = 1;
				if (IsCurrentBar) {
					deltadivergenceDefault[0] = BUY;
				}
			}
			#region -- Calculate CumDelta on this bar --
			if(cum_deltavolume == long.MinValue){
				if(IsNewSession){
					BarDataTotals[TCB].CumDelta = 0;
					IsNewSession = false;
				}
				else if(BarDataTotals.ContainsKey(TCB-1))
					BarDataTotals[TCB].CumDelta = BarDataTotals[TCB-1].CumDelta + (long)NETDELTA.GetValueAt(TCB);
			}else{
				BarDataTotals[TCB].CumDelta = cum_deltavolume;
			}
			#endregion
            return ThisI;
        }
        #region -- Misc Functions --
        //-- optimized code to parse string to int
        private int IntParseFast(string value)
        {
            int result = 0;
            for (int i = 0; i < value.Length; i++) result = 10 * result + (value[i] - 48);
            return result;
        }
        //-- create the signal (TT/DD/CS/2B&3B) arrow
        private Point[] DrawArrow(int x1, ref int y1, int dir, int ArrowHeight, int ArrowWidth)
        {
            dir = dir>0 ? -1: 1;

            if (pArrowBarWidth > ArrowWidth + 1) pArrowBarWidth = ArrowWidth + 1;
            y1 += (int)(0.5 * (-dir * ArrowWidth * 2));
            int triangleTip = dir > 0 ? y1 + ArrowWidth + pArrowTipAdjust : y1 - ArrowWidth - pArrowTipAdjust;

			var y = y1;
			y1 = dir<0? y + ( dir * -ArrowHeight ) : y1;
            return (new Point[]{
                    new Point( x1, y)
                    , new Point( x1 + (( ArrowWidth * 2 - (pArrowBarWidth-1)*2 ) / 2 ), y )
                    , new Point( x1 + (( ArrowWidth * 2 - (pArrowBarWidth-1)*2 ) / 2 ), y + ( dir * -ArrowHeight ) )
                    , new Point( x1 + (pArrowBarWidth-1)*2 + ( ( ArrowWidth * 2 - (pArrowBarWidth-1)*2 ) / 2 ), y + ( dir * -ArrowHeight ) )
                    , new Point( x1 + (pArrowBarWidth-1)*2 + ( ( ArrowWidth * 2 - (pArrowBarWidth-1)*2 ) / 2 ), y )
                    , new Point( x1 + ArrowWidth * 2, y )
                    , new Point( x1 + (ArrowWidth * 2 / 2 ), triangleTip ) });
        }
        //recreate the profile's shape from the list of points (above or below or inside VA)
        private Point[] MakeShape(List<Point> points, int start)
        {
            Point[] newPoints = new Point[points.Count + 2];
            int i = 0;
            bool firstone = true;
            foreach (Point p in points)
            {
                if (firstone)
                {
                    firstone = false;
                    newPoints[i] = new Point(start, p.Y);
                    i++;
                }
                newPoints[i] = p;
                i++;
                if (i == points.Count + 1) newPoints[i] = new Point(start, p.Y);
            }
            return newPoints;
        }
        //set the color to Black or White depending on background color
        public Brush ContrastingColor(SolidColorBrush background)
        {
            // Counting the perceptive luminance - human eye favors green color... 
            double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
            if (a < 0.5) return Brushes.Black; // bright colors - black font
            else return Brushes.White; // dark colors - white font
        }
        //return coordinates of Box price depending on type
        private int GetBoxPixel(double price, char type)
        {
            price = RTTS(price);
            if (PriceBoxes.ContainsKey(price))
            {
                if (type == 'T') return PriceBoxes[price].Top;
                else if (type == 'B') return PriceBoxes[price].Bottom;
                else if (type == 'H') return PriceBoxes[price].Height;
            }
            return int.MinValue;
		}
		private int GetBoxPixel(double price, char type, bool GiveSpace)
		{
			price = RTTS(price);
			if (!PriceBoxes.ContainsKey(price)) return 0;
			double space = 0;
			if(GiveSpace){
				if(this.iShowNetDelta)         space = space + iNetDeltaFont.Size;
				if(this.iShowTotalVolumeAsPct) space = space + iNetDeltaFont.Size;
				space = space + iNetDeltaFont.Size;
				if (type == 'T') space = space + (iNetDeltaFont.Size/2);
				if (type == 'B') space = space + 3;
			}
			if (type == 'T') return PriceBoxes[price].Top - Convert.ToInt32(space);
			else if (type == 'B') return PriceBoxes[price].Bottom + Convert.ToInt32(space);
			else if (type == 'H') return PriceBoxes[price].Height;
			return int.MinValue;
		}

		private Point[] DrawTri(int x1, int y1, double val, int arrowSize, int dir)
		{
            arrowSize = arrowSize + 1;
            if (dir > 0) return (new Point[] { new Point(x1, y1 - arrowSize), new Point(x1, y1 + arrowSize), new Point(x1 + arrowSize, y1) });
            else return (new Point[] { new Point(x1, y1 - arrowSize), new Point(x1, y1 + arrowSize), new Point(x1 - arrowSize, y1) });
        }

        private void ProcessZones()
        {
line=9558;
            //check for zones being broken or tested
            TotalWidthOfAllZones = 0;
            TotalNumberOfZones = 0;
            lastSupplyZoneLow[0] = 999999999;
            lastDemandZoneHigh[0] = 0;
			nearestSupplyZoneLow[0] = 999999999;
			nearestDemandZoneHigh[0] = 0;

line=9567;
            #region -- Init @ first tick --
            if (IsFirstTickOfBar)
            {
                longSignalDefault[0] = 0;
                shortSignalDefault[0] = 0;
                shortSignalsDefault[0] = 0;
                longSignalsDefault[0] = 0;
                longSignalAllDefault[0] = 0;
                shortSignalAllDefault[0] = 0;
                longSignalsAllDefault[0] = 0;
                shortSignalsAllDefault[0] = 0;
            }
            #endregion

            bool NoSignal = true;
line=9583;
            #region -- Process SupplyZones --
//if(IsDebug && SupplyZones.Count>0 || DemandZones.Count>0) Print("Supp Zones Count: "+SupplyZones.Count+"  Demand Zones count: "+DemandZones.Count);

            foreach (KeyValuePair<int, List<Zone>> DZ in SupplyZones)
            {
//if(IsDebug && DZ.Value.Count>0) Print("  Supply Z.Key: "+DZ.Key+"  Z.List.Count: "+DZ.Value.Count);
                // do not signal in live data when zone is being formed on current bar
                if (IsCurrentBar && DZ.Key != CurrentBars[0]) NoSignal = false;
                if (IsHistorical) NoSignal = false;

                foreach (Zone ZS in DZ.Value)
                {
//if(IsDebug) Print("Supply: "+ZS.IsBroken.ToString()+"  top: "+ZS.TopPrice+"  bot: "+ZS.BottomPrice);
                    TotalNumberOfZones = TotalNumberOfZones + 1;
                    TotalWidthOfAllZones = TotalWidthOfAllZones + Math.Round((ZS.TopPrice - ZS.BottomPrice) / gbTickSize, 0);

                    if (ZS.IsBroken) continue;
                    if (DZ.Key != CurrentBars[0]) lastSupplyZoneLow[0] = Math.Min(ZS.BottomPrice, lastSupplyZoneLow[0]);
//if(IsDebug) Print(DZ.Key+"  "+ZS.BottomPrice);
					if (ZS.BottomPrice < nearestSupplyZoneLow[0]) nearestSupplyZoneLow[0] = ZS.BottomPrice;
                    if ((CurveHighZ[0] >= ZS.BottomPrice) && (CurveHighZ[0] < ZS.TopPrice))
                    {
                        CurveHighZ[0] = Math.Max(CurveHighZ[0], ZS.TopPrice);
                        CurveBar2[0] = DZ.Key;
                    }
                    if (ZS.EndBar == 0 && CurrentBars[0] > DZ.Key)
                    {
                        if (ZS.IsBroken) continue;

                        //TESTED
                        if (Highs00 >= ZS.BottomPrice)
                        {
                            if (ZS.TestedPrice == 0)
                            {
                                if (!NoSignal) shortSignalDefault[0] = 1;
                                ZS.TestedPrice = Highs00;
                            }
                            else ZS.TestedPrice = Math.Max(ZS.TestedPrice, Highs00);
                        }

                        // BROKEN	
                        if (Highs00 > ZS.TopPrice)
                        {
                            ZS.EndBar = CurrentBars[0];
                            ZS.IsBroken = true;
                            if (ZS.TestedPrice != 0) ZS.TestedPrice = 0;
                        }
                    }
                }
            }
            #endregion

            NoSignal = true;
line=9637;
            #region -- Process DemandZones --
            foreach (KeyValuePair<int, List<Zone>> DZ in DemandZones)
            {
//if(IsDebug && DZ.Value.Count>0) Print("   Demand Z.Key: "+DZ.Key+"  Z.List.Count: "+DZ.Value.Count);
                // do not signal in live data when zone is being formed on current bar
                if (IsCurrentBar && DZ.Key != CurrentBars[0]) NoSignal = false;
                if (IsHistorical) NoSignal = false;
                foreach (Zone ZS in DZ.Value)
                {
//if(IsDebug) Print("Demand: "+ZS.IsBroken.ToString()+"  top: "+ZS.TopPrice+"  bot: "+ZS.BottomPrice);
                    TotalNumberOfZones = TotalNumberOfZones + 1;
                    TotalWidthOfAllZones = TotalWidthOfAllZones + Math.Round((ZS.TopPrice - ZS.BottomPrice) / gbTickSize, 0);

                    if (ZS.IsBroken) continue;
                    if (DZ.Key != CurrentBars[0]) lastDemandZoneHigh[0] = Math.Max(ZS.TopPrice, lastDemandZoneHigh[0]);
					if (ZS.TopPrice > nearestDemandZoneHigh[0]) nearestDemandZoneHigh[0] = ZS.TopPrice;
                    if ((CurveLowZ[0] > ZS.BottomPrice) && (CurveLowZ[0] <= ZS.TopPrice))
                    {
                        CurveLowZ[0] = Math.Min(CurveLowZ[0], ZS.BottomPrice);
                        CurveBar2[0] = Math.Min(CurveBar2[0], DZ.Key);
                    }
                    if (ZS.EndBar == 0 && CurrentBars[0] > DZ.Key)
                    {
                        // TESTED
                        if (Lows00 <= ZS.TopPrice) // ZONE
                        {
                            if (ZS.TestedPrice == 0)
                            {
                                if (!NoSignal) longSignalDefault[0] = 1;
                                ZS.TestedPrice = Lows00;
                            }
                            else ZS.TestedPrice = Math.Min(ZS.TestedPrice, Lows00);
                        }
                        // BROKEN	
                        if (Lows00 < ZS.BottomPrice)
                        {
                            ZS.EndBar = CurrentBars[0];
                            ZS.IsBroken = true;
                            if (ZS.TestedPrice != 0) ZS.TestedPrice = 0;
                        }
                    }
                }
            }
            #endregion

            CurveBar2[0] = Math.Min(CurveBar[0], CurveBar2[0]);

line=9685;
            // BLOODHOUND
            // LONG / SHORT SIGNALS
            longSignalsDefault[0] = longSignalDefault[0];
            shortSignalsDefault[0] = shortSignalDefault[0];
            if (Low[0] <= lastDemandZoneHigh[0] && lastDemandZoneHigh[0] == lastDemandZoneHigh[1] && longSignalsDefault[1] != 0) longSignalsDefault[0] = 1;
            if (High[0] >= lastSupplyZoneLow[0] && lastSupplyZoneLow[0] == lastSupplyZoneLow[1] && shortSignalsDefault[1] != 0) shortSignalsDefault[0] = 1;

line=9693;
            // SHORT SIGNAL / SIGNALS ALL
            if (shortSignalDefault[0] == 1) shortSignalAllDefault[0] = 1;
            if (Highs00 >= lastSupplyZoneLow[0] && Highs01 < lastSupplyZoneLow[0] && lastSupplyZoneLow[0] != lastSupplyZoneLow[1]) shortSignalAllDefault[0] = 1;
            if (Highs00 >= lastSupplyZoneLow[0]) shortSignalsAllDefault[0] = 1;
            if (shortSignalsAllDefault[0] == 1 && shortSignalsAllDefault[1] == 0) shortSignalAllDefault[0] = 1;

line=9700;
            // LONG SIGNAL / SIGNALS ALL
            if (longSignalDefault[0] == 1) longSignalAllDefault[0] = 1;
            if (Lows00 <= lastDemandZoneHigh[0] && Lows01 < lastDemandZoneHigh[0] && lastDemandZoneHigh[0] != lastDemandZoneHigh[1]) longSignalAllDefault[0] = 1;
            if (Lows00 <= lastDemandZoneHigh[0]) longSignalsAllDefault[0] = 1;
            if (longSignalsAllDefault[0] == 1 && longSignalsAllDefault[1] == 0) longSignalAllDefault[0] = 1;
            // END BLOODHOUND

line=9708;
            //-- update average stop loss in Menu --
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (miAvgStopFirstTouch != null)
                {
line=9714;
                    double avgwidth = (TotalWidthOfAllZones / TotalNumberOfZones) + iAvgStopLossOffset;
                    miAvgStopFirstTouch.Header = string.Format(" First Touch: {0}", avgwidth.ToString("n1"));
                }
            }));
line=9719;
        }

//===============================================================================================================================
		private double RoundToWholePip(double D){
			int ticks = Convert.ToInt32(Math.Round(D/gbTickSize));
			return ticks * gbTickSize;
		}
//===============================================================================================================================
        //##Modif by Kriss AzurITec##
        //The NT function Instrument.MasterInstrument.Round2TickSize doesn't work for some reason in NT7 and NT8
        //This function has been manually written
        private double RTTS(double D)
        {
			int ticks = Convert.ToInt32(Math.Round(D/gbTickSize));
			return ticks * gbTickSize;
            //return Instrument.MasterInstrument.RoundToTickSize(value); BUG from NT7 and NT8
            #region -- Code equivalent to Instrument.MasterInstrument.Round2TickSize() --
            double price = D;
            double increment = gbTickSize;
            if (increment == 0.0)
            {
                return price;
            }
            if (increment > 1.0)
            {
                if ((price > double.MaxValue) || (increment > double.MaxValue))
                {
                    return double.MaxValue;
                }
                if ((price >= -double.MaxValue) && (increment >= -double.MaxValue))
                {
                    int num = (price < 0.0) ? -1 : 1;
                    decimal num2 = (decimal)increment;
                    decimal num3 = (decimal)Math.Abs(price);
                    return (double)(num * ((num3 - (num3 % num2)) + (((num3 % num2) < (num2 / 2M)) ? 0M : num2)));
                }
                return -double.MaxValue;
            }
            int num4 = (price < 0.0) ? -1 : 1;
            double num5 = Math.Abs(price);
            double num7 = (((Math.Floor((double)((num5 + (increment / 2.0)) / increment)) * increment) - num5) > (increment / 4.0)) ? (increment / 10.0) : 0.0;
            return (num4 * Math.Round((double)(Math.Floor((double)((0.5 + num7) + (num5 / increment))) * increment), 10));
            #endregion
        }

        #endregion

        //-------------------- Nested Classes/Structs -------------------

        #region -------------------- Nested Classes/Structs -------------------

        #region --- internal struct ManualCurve
        internal struct ManualCurve
        {
            public double HighPrice;
            public double LowPrice;
            public int LeftBar;
            public int RightBar;
            public ManualCurve(double highPrice, double lowPrice, int leftBar, int rightBar)
            {
                HighPrice = highPrice;
                LowPrice = lowPrice;
                LeftBar = leftBar;
                RightBar = rightBar;
            }
        }
        #endregion

        #region --- internal class MouseManager --- #REMARQUE : NOT SURE IF IT NEEDS TO BE IMPLEMENTED ----
        internal class MouseManager
        {
            public int HoverIndex { get; set; }
            public bool Dragging { get; set; }
            public int X { get; set; }
            public int Y { get; set; }
            public int XStart { get; set; }
            public int YStart { get; set; }
            public int Index { get; set; }

            public MouseManager()
            {
                HoverIndex = -1;
                Dragging = false;
                X = 0;
                Y = 0;
                XStart = 0;
                YStart = 0;
                Index = 0;
            }

            public void Clear()
            {
                HoverIndex = -1;
                Dragging = false;
                X = 0;
                Y = 0;
                XStart = 0;
                YStart = 0;
                Index = 0;
            }
        }
        #endregion

        #region --- internal class PriceBox --- #REMARQUE : INTERET??? ---- AverageBoxHeight
        internal class PriceBox
        {
            public int Top { get; set; }
            public int Bottom { get; set; }
            public int Height { get; set; }
        }
        #endregion

        #region --- internal class VolumeAtBA
        internal class VolumeAtBA
        {
            public double BidSize { get; set; }
            public double AskSize { get; set; }

            public double getLevelVolume() { return BidSize + AskSize; }
        }
        #endregion

        #region --- internal class PrintLevelDetails
        internal class PrintLevelDetails
        {
            public double DIFF { get; set; }
            public bool POC { get; set; }
            public bool UFA { get; set; }

            public SortedDictionary<double, VolumeAtBA> AllVolume { get; set; }

            public double BidSize { get; set; }
            public double AskSize { get; set; }
            public double BidTotal { get; set; }
            public double AskTotal { get; set; }
            public double BidSizeReduced { get; set; }
            public double AskSizeReduced { get; set; }

            public double BidImbalance { get; set; }
            public double AskImbalance { get; set; }
            public List<double> BidBlocks { get; set; }
            public List<double> AskBlocks { get; set; }

            public PrintLevelDetails()
            {
                BidBlocks = new List<double>();
                AskBlocks = new List<double>();
                AllVolume = new SortedDictionary<double, VolumeAtBA>();
            }
        }
        #endregion

        #region --- internal class ProfileLevelDetails
        internal class ProfileLevelDetails
        {
            public long BidSize { get; set; }
            public long AskSize { get; set; }

            public double VAH { get; set; }
            public double VAL { get; set; }
            public double POC { get; set; }
        }
        #endregion

        #region --- internal class VolumeProfileS
        internal class VolumeProfileS
        {
            public SortedDictionary<double, VolumeAtBA> AllVolume { get; set; }

            //public long BidSize       { get; set; }
            //public long AskSize       { get; set; }
            public double VAH         { get; set; }
            public double VAL         { get; set; }
            public double VAH2        { get; set; }//#REMARQUE Quel INTERET??? Toujours at ProfileHigh
            public double VAL2        { get; set; }//#REMARQUE Quel INTERET??? toujours at ProfileLow
            public double POCPrice    { get; set; }
            public double POCVolume   { get; set; }
            public double VWAP        { get; set; }

            public double ClusterTop    { get; set; }
            public double ClusterBottom { get; set; }

            public double ProfileHigh   { get; set; }
            public double ProfileLow    { get; set; }
            public int ProfileStart     { get; set; }
            public int ProfileEnd       { get; set; }
            public int Rend             { get; set; }

            public bool ExtendRight { get; set; }

            public List<double> CWAP { get; set; }

            public VolumeProfileS() { AllVolume = new SortedDictionary<double, VolumeAtBA>(); CWAP = new List<double>(); }
        }
        #endregion

        #region --- internal class BarTotal
        internal class BarTotal
        {
            public double BidTotal { get; set; }
            public double AskTotal { get; set; }
			public double MaxBid { get; set;}
			public double MaxAsk { get; set;}
            public double TrappedTraderN { get; set; }
            public double POC { get; set; }
            public long   CumDelta { get; set; }
        }
        #endregion

        #region --- internal class Zone
        internal class Zone
        {
            public bool IsBroken { get; set; }
            public bool IsHidden { get; set; }
            public long TicksWidth { get; set; }
            public int EndBar { get; set; }
            public double TestedPrice { get; set; }
            public double BottomPrice { get; set; }
            public double TopPrice { get; set; }
        }
        #endregion

        #region --- internal class LadderRow
        internal class LadderRow
        {
            public string MarketMaker { get; set; }          // relevant for stocks only
            public double Price { get; set; }
            public long Volume { get; set; }

            public LadderRow(double myPrice, long myVolume, string myMarketMaker)
            {
                MarketMaker = myMarketMaker;
                Price = myPrice;
                Volume = myVolume;
            }
        }
        #endregion

        //----------------- Converter -------------------
        #region internal class OutsideInside : StringConverter
        internal class OutsideInside : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Outside", "Inside" });
            }
        }
        #endregion

        #region internal class ProfileHD : StringConverter
        internal class ProfileHD : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Left", "Right" });
            }
        }
        #endregion

        #region internal class CompositeType : StringConverter
        internal class CompositeType : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Day", "Time" });
            }
        }
        #endregion

        #region internal class VolumeAverageMode : StringConverter
        internal class VolumeAverageMode : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "EMA", "SMA" });
            }
        }
        #endregion

        #region internal class ProfileCalcMode : StringConverter
        internal class ProfileCalcMode : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "All", "VolumeProfileOnly" });
            }
        }
        #endregion

        #region internal class TotalMode : StringConverter
        internal class TotalMode : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Contracts", "Percent", "Both" });
            }
        }
        #endregion

        #region internal class SignalHD : StringConverter
        internal class SignalHD : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Inside", "Outside" });
            }
        }
        #endregion

        #region internal class ProfileDisplayMode : StringConverter
        internal class ProfileDisplayMode : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Histogram", "Shape" });
            }
        }
        #endregion

		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";
//					System.IO.DirectoryInfo dirCustom = new System.IO.DirectoryInfo(folder);
//					System.IO.FileInfo[] filCustom = dirCustom.GetFiles( search);

//					string[] list = new string[filCustom.Length+1];
//					list[0] = "none";
//					int i = 1;
//					foreach (System.IO.FileInfo fi in filCustom)
//					{
////					if(fi.Extension.ToLower().CompareTo(".exe")!=0 && fi.Extension.ToLower().CompareTo(".txt")!=0){
//						list[i] = fi.Name;
//						i++;
////					}
//					}
//					filteredlist = new string[i];
//					for(i = 0; i<filteredlist.Length; i++) filteredlist[i] = list[i];
					
//				}catch{filteredlist = new string[1]{"none"};}
//				return new StandardValuesCollection(filteredlist);

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				list.Add("<inst>_Buy_PrintProfiler.wav");
				list.Add("<inst>_Sell_PrintProfiler.wav");
				list.Add("<inst>_TT_Buy_PrintProfiler.wav");
				list.Add("<inst>_TT_Sell_PrintProfiler.wav");
				list.Add("<inst>_DD_Buy_PrintProfiler.wav");
				list.Add("<inst>_DD_Sell_PrintProfiler.wav");
				list.Add("<inst>_VCR_Buy_PrintProfiler.wav");
				list.Add("<inst>_VCR_Sell_PrintProfiler.wav");
				list.Add("<inst>_CS_Buy_PrintProfiler.wav");
				list.Add("<inst>_CS_Sell_PrintProfiler.wav");
				list.Add("<inst>_VD_Buy_PrintProfiler.wav");
				list.Add("<inst>_VD_Sell_PrintProfiler.wav");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }
        #endregion

        //---------------------- Properties ----------------------------
        #region -- Exposed Series --
        #region --- EXPOSED COMPOSITE ---
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCOMPPOC { get { return CompPOC; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCOMPVWAP { get { return CompVWAP; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCOMPVAH { get { return CompVAH1; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCOMPVAL { get { return CompVAL1; } }
        #endregion

        #region --- EXPOSED TT/DD/VD ---
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exTrappedTraderSignals { get { return trappedtraderDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exDeltaDivergenceSignals { get { return deltadivergenceDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exVolumeDivergenceSignalLong { get { return volumedivergenceDefault; } }
        #endregion

        #region --- EXPOSED Long/Short Signals ---
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exLongSignal { get { return longSignalDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exShortSignal { get { return shortSignalDefault; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exLongSignals { get { return longSignalsDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exShortSignals { get { return shortSignalsDefault; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exLongSignalAll { get { return longSignalAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exShortSignalAll { get { return shortSignalAllDefault; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exLongSignalsAll { get { return longSignalsAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exShortSignalsAll { get { return shortSignalsAllDefault; } }
        #endregion

        #region --- EXPOSED CURVE ---
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurve1 { get { return vCurve1; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurve2 { get { return vCurve2; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurve3 { get { return vCurve3; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurve4 { get { return vCurve4; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurve5 { get { return vCurve5; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveStatus { get { return vCurveStatus; } }
        #endregion

        #region --- EXPOSED PROFILE ---
//#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exBarProfileVWAP { get { return BARVWAP; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exBarProfilePOC { get { return BARPOC; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exBarProfileClusterHigh { get { return BARCLH; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exBarProfileClusterLow { get { return BARCLL; } }
//#endif
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exBarProfileVAHigh { get { return BARVAH; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exBarProfileVALow { get { return BARVAL; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exNetDelta { get { return NETDELTA; } }
        #endregion

        [Browsable(false)]
        [XmlIgnore()]
		public Series<double> LastDemandZoneHigh { get { return lastDemandZoneHigh; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LastSupplyZoneLow { get { return lastSupplyZoneLow; } }

        [Browsable(false)]
        [XmlIgnore()]
		public Series<double> NearestDemandZoneHigh { get { return nearestDemandZoneHigh; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> NearestSupplyZoneLow { get { return nearestSupplyZoneLow; } }

        #region -- Plots -- #REMARQUE : DONT KNOW WHY THERE WERE IN COMMENT BUT DECLARED IN INITIALIZE ----
#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> VA1CLL { get { return Values[0]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> VA1CLH { get { return Values[1]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> VA1VWAP { get { return Values[2]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> VA1POC { get { return Values[3]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> VA2CLL { get { return Values[4]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> VA2CLH { get { return Values[5]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> VA2VWAP { get { return Values[6]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> VA2POC { get { return Values[7]; } }
#endif
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> MA1High { get { return Values[0]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> MA1Low { get { return Values[1]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> MA2High { get { return Values[2]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> MA2Low { get { return Values[3]; } }
//        [Browsable(false)]
//        [XmlIgnore()]
//        public Series<double> CWAPMAN { get { return Values[12]; } }
//        [Browsable(false)]
//        [XmlIgnore()]
//        public Series<double> CWAPCOMP { get { return Values[13]; } }
        #endregion
        #endregion

        #region -- Properties --
		[Display(Name = "Enable ChartMarkers", GroupName = "ChartMarker Signals", Description = "", Order = 00)]
		public bool pEnableChartMarkers { get; set; }

		[Display(Name = "Up ChartMarker Type", GroupName = "ChartMarker Signals", Description = "", Order = 10)]
		public ARC_PrintProfiler_ChartMarkers pBuyChartMarkers { get; set; }

		[XmlIgnore]
		[Display(Name = "Up Color", GroupName = "ChartMarker Signals", Description = "", Order = 20)]
		public Brush pBuyBrushChartMarker {get;set;}
			[Browsable(false)]
			public string pBuyBrushChartMarkerSerialize	{get { return Serialize.BrushToString(pBuyBrushChartMarker); }set { pBuyBrushChartMarker = Serialize.StringToBrush(value); }}

		[Display(Name = "Down ChartMarker Type", GroupName = "ChartMarker Signals", Description = "", Order = 30)]
		public ARC_PrintProfiler_ChartMarkers pSellChartMarkers { get; set; }

		[XmlIgnore]
		[Display(Name = "Down Color", GroupName = "ChartMarker Signals", Description = "", Order = 40)]
		public Brush pSellBrushChartMarker {get;set;}
			[Browsable(false)]
			public string pSellBrushChartMarkerSerialize	{get { return Serialize.BrushToString(pSellBrushChartMarker); }set { pSellBrushChartMarker = Serialize.StringToBrush(value); }}

		[Display(Name = "ChartMarker Separation Ticks", GroupName = "ChartMarker Signals", Description = "", Order = 50)]
		public int pMarkerTicks {get;set;}


		#region -- Bid/Ask Imbalances --
		[Display(Name = "Bid/Ask Imbalances Enabled", GroupName = "Bid/Ask Imbalances", Description = "", Order = 00)]
		public bool iShowImbalance { get; set; }

		[Display(Name = "Bid/Ask Imbalances Dots Enabled", GroupName = "Bid/Ask Imbalances", Description = "", Order = 20)]
		public bool iShowImbalanceA { get; set; }

		[Display(Name = "Bid/Ask Imbalances Text Enabled", GroupName = "Bid/Ask Imbalances", Description = "", Order = 30)]
		public bool iShowImbalanceText { get; set; }

		[NinjaScriptProperty]
		[Range(1, 100000)]
		[Display(Name = "Multiplier (x)", GroupName = "Bid/Ask Imbalances", Description = "", Order = 40)]
		public double iImbalanceOffset { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100000)]
		[Display(Name = "Volume Qualifier (%)", GroupName = "Bid/Ask Imbalances", Description = "", Order = 50)]
		public double iVolumeQualifier { get; set; }

//        [XmlIgnore]
//        [Display(Name = "Ask Fill Color", GroupName = "Bid/Ask Imbalances", Description = "", Order = 60)]
//        public Brush iIBAskColor { get; set; }
//        [Browsable(false)]
//        public string iIBAskColorSerialize
//        {
//            get { return Serialize.BrushToString(iIBAskColor); }
//            set { iIBAskColor = Serialize.StringToBrush(value); }
//        }

//        [Range(0, 100)]
//        [Display(Name = "Ask Fill Opacity (%)", GroupName = "Bid/Ask Imbalances", Description = "", Order = 70)]
//        public int iOpacityUp2 { get; set; }

//        [XmlIgnore]
//        [Display(Name = "Bid Fill Color", GroupName = "Bid/Ask Imbalances", Description = "", Order = 80)]
//        public Brush iIBBidColor { get; set; }
//        [Browsable(false)]
//        public string iIBBidColorSerialize
//        {
//            get { return Serialize.BrushToString(iIBBidColor); }
//            set { iIBBidColor = Serialize.StringToBrush(value); }
//        }

//        [Range(0, 100)]
//        [Display(Name = "Bid Fill Opacity (%)", GroupName = "Bid/Ask Imbalances", Description = "", Order = 90)]
//        public int iOpacityDn2 { get; set; }

		[XmlIgnore]
		[Display(Name = "Dot Color Ask", GroupName = "Bid/Ask Imbalances", Description = "", Order = 100)]
		public Brush iBlocksColor { get; set; }
				[Browsable(false)]
				public string iBlocksColorSerialize
				{
				    get { return Serialize.BrushToString(iBlocksColor); }
				    set { iBlocksColor = Serialize.StringToBrush(value); }
				}

		[XmlIgnore]
		[Display(Name = "Dot Color Bid", GroupName = "Bid/Ask Imbalances", Description = "", Order = 110)]
		public Brush iBlocks2Color { get; set; }
				[Browsable(false)]
				public string iBlocks2ColorSerialize
				{
				    get { return Serialize.BrushToString(iBlocks2Color); }
				    set { iBlocks2Color = Serialize.StringToBrush(value); }
				}

		[Range(0, 100)]
		[Display(Name = "Dot Opacity (%)", GroupName = "Bid/Ask Imbalances", Description = "", Order = 120)]
		public int iBlocksO { get; set; }

		[Range(1, 100000)]
		[Display(Name = "Dot Size", GroupName = "Bid/Ask Imbalances", Description = "", Order = 130)]
		public int iRSSize { get; set; }

		[TypeConverter(typeof(OutsideInside))]
		[Display(Name = "Dot Mode", GroupName = "Bid/Ask Imbalances", Description = "", Order = 140)]
		public string pImbalancesDotMode { get; set; }

		[XmlIgnore]
		[Display(Name = "Text Color Ask", GroupName = "Bid/Ask Imbalances", Description = "", Order = 150)]
		public Brush iTxtBrush_AskImbalance { get; set; }
		[Browsable(false)]
		public string iTxtBrush_AskImbalanceSerialize
		{
		    get { return Serialize.BrushToString(iTxtBrush_AskImbalance); }
		    set { iTxtBrush_AskImbalance = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Text Color Bid", GroupName = "Bid/Ask Imbalances", Description = "", Order = 160)]
		public Brush iTxtBrush_BidImbalance { get; set; }
				[Browsable(false)]
				public string iTxtBrush_BidImbalanceSerialize
				{
				    get { return Serialize.BrushToString(iTxtBrush_BidImbalance); }
				    set { iTxtBrush_BidImbalance = Serialize.StringToBrush(value); }
				}

//        [Range(0, 100)]
//        [Display(Name = "Text Size Increase", GroupName = "Bid/Ask Imbalances", Description = "", Order = 170)]
//        public int iIpButtonSizeI { get; set; }

//        [Display(Name = "Text Style Bold ?", GroupName = "Bid/Ask Imbalances", Description = "", Order = 180)]
//        public bool iIBFS { get; set; }


        #endregion

        #region -- Zones Display --
        [Display(Name = "Zones Enabled", GroupName = "Zones Display", Description = "", Order = 0)]
        public bool iZonesEnabled { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Minimum Size (Ticks)", GroupName = "Zones Display", Description = "the minimum number of stacked imbalances required to form a supply or demand zone.", Order = 10)]
        public int iMinZWidth { get; set; }

        [Display(Name = "Show Demand Zones", GroupName = "Zones Display", Description = "", Order = 20)]
        public bool iShowDemandZones { get; set; }

        [Display(Name = "Show Supply Zones", GroupName = "Zones Display", Description = "", Order = 30)]
        public bool iShowSupplyZones { get; set; }

        [Display(Name = "Show Fresh Zones", GroupName = "Zones Display", Description = "", Order = 40)]
        public bool iShowFreshZones { get; set; }

        [Display(Name = "Show Tested Zones", GroupName = "Zones Display", Description = "", Order = 50)]
        public bool iShowTestedZones { get; set; }

        [Display(Name = "Show Broken Zones", GroupName = "Zones Display", Description = "", Order = 60)]
        public bool iShowBrokenZones { get; set; }

        [Display(Name = "Draw - Extend Right", GroupName = "Zones Display", Description = "", Order = 70)]
        public bool iExtendZonesRight { get; set; }

        [Range(1, 100)]
        [Display(Name = "Draw - Tick Level Width (Pixels)", GroupName = "Zones Display", Description = "set the width for levels that consist of only one imbalance block when print is disabled.", Order = 80)]
        public int iTickLevelWidth { get; set; }

        [XmlIgnore]
        [Display(Name = "Demand Fill Color (Broken)", GroupName = "Zones Display", Description = "", Order = 90)]
        public Brush iDemandZColorBroken { get; set; }
        [Browsable(false)]
        public string iDemandZColorBrokenSerialize
        {
            get { return Serialize.BrushToString(iDemandZColorBroken); }
            set { iDemandZColorBroken = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Demand Fill Color (Fresh)", GroupName = "Zones Display", Description = "", Order = 100)]
        public Brush iDemandZColorFresh { get; set; }
        [Browsable(false)]
        public string iDemandZColorFreshSerialize
        {
            get { return Serialize.BrushToString(iDemandZColorFresh); }
            set { iDemandZColorFresh = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Demand Fill Color (Tested)", GroupName = "Zones Display", Description = "", Order = 110)]
        public Brush iDemandZColorTested { get; set; }
        [Browsable(false)]
        public string iDemandZColorTestedSerialize
        {
            get { return Serialize.BrushToString(iDemandZColorTested); }
            set { iDemandZColorTested = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Demand Fill Opacity (Broken)", GroupName = "Zones Display", Description = "", Order = 120)]
        public int iDemandZOpacityBroken { get; set; }

        [Range(0, 100)]
        [Display(Name = "Demand Fill Opacity (Fresh)", GroupName = "Zones Display", Description = "", Order = 130)]
        public int iDemandZOpacityFresh { get; set; }

        [Range(0, 100)]
        [Display(Name = "Demand Fill Opacity (Tested)", GroupName = "Zones Display", Description = "", Order = 140)]
        public int iDemandZOpacityTested { get; set; }

        [XmlIgnore]
        [Display(Name = "Demand Outline Color (Broken)", GroupName = "Zones Display", Description = "", Order = 150)]
        public Brush iDemandZOLColorBroken { get; set; }
        [Browsable(false)]
        public string iDemandZOLColorBrokenSerialize
        {
            get { return Serialize.BrushToString(iDemandZOLColorBroken); }
            set { iDemandZOLColorBroken = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Demand Outline Color (Fresh)", GroupName = "Zones Display", Description = "", Order = 160)]
        public Brush iDemandZOLColorFresh { get; set; }
        [Browsable(false)]
        public string iDemandZOLColorFreshSerialize
        {
            get { return Serialize.BrushToString(iDemandZOLColorFresh); }
            set { iDemandZOLColorFresh = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Demand Outline Color (Tested)", GroupName = "Zones Display", Description = "", Order = 170)]
        public Brush iDemandZOLColorTested { get; set; }
        [Browsable(false)]
        public string iDemandZOLColorTestedSerialize
        {
            get { return Serialize.BrushToString(iDemandZOLColorTested); }
            set { iDemandZOLColorTested = Serialize.StringToBrush(value); }
        }


        [XmlIgnore]
        [Display(Name = "Supply Fill Color (Broken)", GroupName = "Zones Display", Description = "", Order = 180)]
        public Brush iSupplyZColorBroken { get; set; }
        [Browsable(false)]
        public string iSupplyZColorBrokenSerialize
        {
            get { return Serialize.BrushToString(iSupplyZColorBroken); }
            set { iSupplyZColorBroken = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Supply Fill Color (Fresh)", GroupName = "Zones Display", Description = "", Order = 190)]
        public Brush iSupplyZColorFresh { get; set; }
        [Browsable(false)]
        public string iSupplyZColorFreshSerialize
        {
            get { return Serialize.BrushToString(iSupplyZColorFresh); }
            set { iSupplyZColorFresh = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Supply Fill Color (Tested)", GroupName = "Zones Display", Description = "", Order = 200)]
        public Brush iSupplyZColorTested { get; set; }
        [Browsable(false)]
        public string iSupplyZColorTestedSerialize
        {
            get { return Serialize.BrushToString(iSupplyZColorTested); }
            set { iSupplyZColorTested = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Supply Fill Opacity (Broken)", GroupName = "Zones Display", Description = "", Order = 210)]
        public int iSupplyZOpacityBroken { get; set; }

        [Range(0, 100)]
        [Display(Name = "Supply Fill Opacity (Fresh)", GroupName = "Zones Display", Description = "", Order = 220)]
        public int iSupplyZOpacityFresh { get; set; }

        [Range(0, 100)]
        [Display(Name = "Supply Fill Opacity (Tested)", GroupName = "Zones Display", Description = "", Order = 230)]
        public int iSupplyZOpacityTested { get; set; }

        [XmlIgnore]
        [Display(Name = "Supply Outline Color (Broken)", GroupName = "Zones Display", Description = "", Order = 240)]
        public Brush iSupplyZOLColorBroken { get; set; }
        [Browsable(false)]
        public string iSupplyZOLColorBrokenSerialize
        {
            get { return Serialize.BrushToString(iSupplyZOLColorBroken); }
            set { iSupplyZOLColorBroken = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Supply Outline Color (Fresh)", GroupName = "Zones Display", Description = "", Order = 250)]
        public Brush iSupplyZOLColorFresh { get; set; }
        [Browsable(false)]
        public string iSupplyZOLColorFreshSerialize
        {
            get { return Serialize.BrushToString(iSupplyZOLColorFresh); }
            set { iSupplyZOLColorFresh = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Supply Outline Color (Tested)", GroupName = "Zones Display", Description = "", Order = 260)]
        public Brush iSupplyZOLColorTested { get; set; }
        [Browsable(false)]
        public string iSupplyZOLColorTestedSerialize
        {
            get { return Serialize.BrushToString(iSupplyZOLColorTested); }
            set { iSupplyZOLColorTested = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Tested Marker Enabled", GroupName = "Zones Display", Description = "", Order = 270)]
        public bool iZonesTMEnabled { get; set; }

        [XmlIgnore]
        [Display(Name = "Tested Marker Color", GroupName = "Zones Display", Description = "", Order = 280)]
        public Brush iTMColor { get; set; }
        [Browsable(false)]
        public string iTMColorSerialize
        {
            get { return Serialize.BrushToString(iTMColor); }
            set { iTMColor = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Tested Marker Opacity (%)", GroupName = "Zones Display", Description = "", Order = 290)]
        public int iTMOpacity { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Tested Marker Width", GroupName = "Zones Display", Description = "", Order = 300)]
        public int iTMWidth { get; set; }

        [Display(Name = "Tested Shading Enabled", GroupName = "Zones Display", Description = "", Order = 310)]
        public bool iZonesTSEnabled { get; set; }
        #endregion

        #region -- Print Display --
        [Display(Name = "Print Enabled", GroupName = "Print Display", Description = "", Order = 00)]
        public bool iPrintEnabled { get; set; }

        [Display(Name = "Current Bar Enabled", GroupName = "Print Display", Description = "", Order = 10)]
        public bool iCurrentBarEnabled { get; set; }

        [Display(Name = "Volume NumbersEnabled", GroupName = "Print Display", Description = "", Order = 20)]
        public bool iShowVolAtPrice { get; set; }

		[Display(Name = "HeatMap Enabled", GroupName = "Print Display", Description = "", Order = 30)]
		public bool iShowNetDeltaHeatMap { get; set; }

		[XmlIgnore]
		[Display(Name = "HeatMap Positive", GroupName = "Print Display", Description = "Color of heatmap rectangle when current net delta exceeds the average positive net delta", Order = 40)]
		public Brush pHeatMap_PositiveColor { get; set; }
		[Browsable(false)]
		public string HeatMapPositiveColorSerialize
		{
		    get { return Serialize.BrushToString(pHeatMap_PositiveColor); }
		    set { pHeatMap_PositiveColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "HeatMap Negative", GroupName = "Print Display", Description = "Color of heatmap rectangle when current net delta exceeds the average positive net delta", Order = 50)]
		public Brush pHeatMap_NegativeColor { get; set; }
		[Browsable(false)]
		public string HeatMapNegativeColorSerialize
		{
		    get { return Serialize.BrushToString(pHeatMap_NegativeColor); }
		    set { pHeatMap_NegativeColor = Serialize.StringToBrush(value); }
		}

		[Range(0,100)]
		[Display(Name = "HeatMap Height Period", GroupName = "Print Display", Description = "Number of bars for total volume average - used in calculating the height of the HeatMap histogram", Order = 60)]
		public int pHeatMapHeightPeriod { get; set; }

		[Range(0,100)]
		[Display(Name = "HeatMap Color Period", GroupName = "Print Display", Description = "Number of bars for average net delta volume - used in calculating the color of the HeatMap histogram", Order = 70)]
		public int pHeatMapColorPeriod { get; set; }

		[Display(Name = "HeatMap Skinny Bars", GroupName = "Print Display", Description = "", Order = 85)]
		public bool pUseSkinnyHeatmapBars { get; set; }

		[Display(Name = "HeatMap Volume Enabled", GroupName = "Print Display", Description = "Total volume prints at bottom of HeatMap histogram bars", Order = 80)]
		public bool iShowTotalVolumeInHeatMap { get; set; }

		[XmlIgnore]
		[Display(Name = "HeatMap MinimumLine", GroupName = "Print Display", Description = "Color of heatmap minimum line", Order = 83)]
		public Brush pHeatMap_MinimumLineColor { get; set; }
		[Browsable(false)]
		public string pHeatMap_MinimumLineColorSerialize
		{
		    get { return Serialize.BrushToString(pHeatMap_MinimumLineColor); }
		    set { pHeatMap_MinimumLineColor = Serialize.StringToBrush(value); }
		}
        [Range(0, 1000)]
        [Display(Name = "HeatMap MinLine Thickness", GroupName = "Print Display", Description = "Thickness of the HeatMap minimum line (set to '0' to turn-off this line)", Order = 86)]
        public int pHeatMap_MinLineThickness { get; set; }


		[Display(Name = "Show %Vol Enabled", GroupName = "Print Display", Description = "Show net delta as a percent of total bar volume", Order = 90)]
		public bool iShowTotalVolumeAsPct { get; set; }

		[Display(Name = "Net Delta Enabled", GroupName = "Print Display", Description = "", Order = 100)]
		public bool iShowNetDelta { get; set; }

		[XmlIgnore]
		[Display(Name = "Net Delta Color Negative", GroupName = "Print Display", Description = "", Order = 110)]
		public Brush iDNColor { get; set; }
		[Browsable(false)]
		public string iDNColorSerialize
		{
		    get { return Serialize.BrushToString(iDNColor); }
		    set { iDNColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Net Delta Color Positive", GroupName = "Print Display", Description = "", Order = 120)]
		public Brush iDPColor { get; set; }
		[Browsable(false)]
		public string iDPColorSerialize
		{
		    get { return Serialize.BrushToString(iDPColor); }
		    set { iDPColor = Serialize.StringToBrush(value); }
		}

		[Display(Name = "Net Delta Font", GroupName = "Print Display", Description = "", Order = 130)]
		public SimpleFont iNetDeltaFont { get; set; }

		[XmlIgnore]
		[Display(Name = "Text Color", GroupName = "Print Display", Description = "", Order = 140)]
		public Brush iTxtBrush_BidAskVol { get; set; }
				[Browsable(false)]
				public string iTxtBrush_BidAskVolSerialize{get { return Serialize.BrushToString(iTxtBrush_BidAskVol); }set { iTxtBrush_BidAskVol = Serialize.StringToBrush(value); }}

        [Display(Name = "Text Font", GroupName = "Print Display", Description = "", Order = 150)]
        public SimpleFont iBarPrintFont { get; set; }

        #endregion
		#region -- Table Display --
		[Display(Name = "Show Data Table?", GroupName = "Table Display", Description = "", Order = 10)]
		public bool pShow_Table
		{get;set;}

		#region -- Label column colors --
		[XmlIgnore]
		[Display(Name = "Label Column Text Color", GroupName = "Table Display", Description = "", Order = 20)]
		public Brush pTableTxt_LabelColumn_Brush { get; set; }
				[Browsable(false)]
				public string pTableTxt_LabelColumn_Brushser{get { return Serialize.BrushToString(pTableTxt_LabelColumn_Brush); }set { pTableTxt_LabelColumn_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Label Column Fill Color", GroupName = "Table Display", Description = "", Order = 21)]
		public Brush pTableFill_LabelColumn_Brush { get; set; }
				[Browsable(false)]
				public string pTableFill_LabelColumn_Brushser{get { return Serialize.BrushToString(pTableFill_LabelColumn_Brush); }set { pTableFill_LabelColumn_Brush = Serialize.StringToBrush(value); }}
		#endregion
		#region -- Signal row colors --
		[XmlIgnore]
		[Display(Name = "Up Signal Text Color", GroupName = "Table Display", Description = "", Order = 30)]
		public Brush pTableTxt_SignalUp_Brush {get;set;}
				[Browsable(false)]
				public string pTableTxt_SignalUp_Brushser{get { return Serialize.BrushToString(pTableTxt_SignalUp_Brush); }set { pTableTxt_SignalUp_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Up Signal Fill Color", GroupName = "Table Display", Description = "", Order = 31)]
		public Brush pTableFill_SignalUp_Brush {get;set;}
				[Browsable(false)]
				public string pTableFill_SignalUp_Brushser{get { return Serialize.BrushToString(pTableFill_SignalUp_Brush); }set { pTableFill_SignalUp_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Down Signal Text Color", GroupName = "Table Display", Description = "", Order = 32)]
		public Brush pTableTxt_SignalDown_Brush {get;set;}
				[Browsable(false)]
				public string pTableTxt_SignalDown_Brushser{get { return Serialize.BrushToString(pTableTxt_SignalDown_Brush); }set { pTableTxt_SignalDown_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Down Signal Fill Color", GroupName = "Table Display", Description = "", Order = 33)]
		public Brush pTableFill_SignalDown_Brush {get;set;}
				[Browsable(false)]
				public string pTableFill_SignalDown_Brushser{get { return Serialize.BrushToString(pTableFill_SignalDown_Brush); }set { pTableFill_SignalDown_Brush = Serialize.StringToBrush(value); }}
		#endregion
		#region -- Delta row colors --
		[XmlIgnore]
		[Display(Name = "Up Delta Text Color", GroupName = "Table Display", Description = "", Order = 40)]
		public Brush pTableTxt_DeltaPos_Brush {get;set;}
				[Browsable(false)]
				public string pTableTxt_DeltaPos_Brushser{get { return Serialize.BrushToString(pTableTxt_DeltaPos_Brush); }set { pTableTxt_DeltaPos_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Up Delta Fill Color", GroupName = "Table Display", Description = "", Order = 41)]
		public Brush pTableFill_DeltaPos_Brush {get;set;}
				[Browsable(false)]
				public string pTableFill_DeltaPos_Brushser{get { return Serialize.BrushToString(pTableFill_DeltaPos_Brush); }set { pTableFill_DeltaPos_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Down Delta Text Color", GroupName = "Table Display", Description = "", Order = 42)]
		public Brush pTableTxt_DeltaNeg_Brush {get;set;}
				[Browsable(false)]
				public string pTableTxt_DeltaNeg_Brushser{get { return Serialize.BrushToString(pTableTxt_DeltaNeg_Brush); }set { pTableTxt_DeltaNeg_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Down Delta Fill Color", GroupName = "Table Display", Description = "", Order = 43)]
		public Brush pTableFill_DeltaNeg_Brush {get;set;}
				[Browsable(false)]
				public string pTableFill_DeltaNeg_Brushser{get { return Serialize.BrushToString(pTableFill_DeltaNeg_Brush); }set { pTableFill_DeltaNeg_Brush = Serialize.StringToBrush(value); }}
		#endregion
		#region -- CumDelta row colors --
		[XmlIgnore]
		[Display(Name = "Up CumDelta Text Color", GroupName = "Table Display", Description = "", Order = 50)]
		public Brush pTableTxt_CumDeltaPos_Brush {get;set;}
				[Browsable(false)]
				public string pTableTxt_CumDeltaPos_Brushser{get { return Serialize.BrushToString(pTableTxt_CumDeltaPos_Brush); }set { pTableTxt_CumDeltaPos_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Up CumDelta Fill Color", GroupName = "Table Display", Description = "", Order = 51)]
		public Brush pTableFill_CumDeltaPos_Brush {get;set;}
				[Browsable(false)]
				public string pTableFill_CumDeltaPos_Brushser{get { return Serialize.BrushToString(pTableFill_CumDeltaPos_Brush); }set { pTableFill_CumDeltaPos_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Down CumDelta Text Color", GroupName = "Table Display", Description = "", Order = 52)]
		public Brush pTableTxt_CumDeltaNeg_Brush {get;set;}
				[Browsable(false)]
				public string pTableTxt_CumDeltaNeg_Brushser{get { return Serialize.BrushToString(pTableTxt_CumDeltaNeg_Brush); }set { pTableTxt_CumDeltaNeg_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Down CumDelta Fill Color", GroupName = "Table Display", Description = "", Order = 53)]
		public Brush pTableFill_CumDeltaNeg_Brush {get;set;}
				[Browsable(false)]
				public string pTableFill_CumDeltaNeg_Brushser{get { return Serialize.BrushToString(pTableFill_CumDeltaNeg_Brush); }set { pTableFill_CumDeltaNeg_Brush = Serialize.StringToBrush(value); }}
		#endregion
		#region -- DeltaPct row colors --
		[XmlIgnore]
		[Display(Name = "Delta% Text Color", GroupName = "Table Display", Description = "", Order = 60)]
		public Brush pTableTxt_DeltaPct_Brush {get;set;}
				[Browsable(false)]
				public string pTableTxt_DeltaPct_Brushser{get { return Serialize.BrushToString(pTableTxt_DeltaPct_Brush); }set { pTableTxt_DeltaPct_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Delta% Fill Color", GroupName = "Table Display", Description = "", Order = 61)]
		public Brush pTableFill_DeltaPct_Brush {get;set;}
				[Browsable(false)]
				public string pTableFill_DeltaPct_Brushser{get { return Serialize.BrushToString(pTableFill_DeltaPct_Brush); }set { pTableFill_DeltaPct_Brush = Serialize.StringToBrush(value); }}

		#endregion
		#region -- Volume row colors --
		[XmlIgnore]
		[Display(Name = "Volume Text Color", GroupName = "Table Display", Description = "", Order = 70)]
		public Brush pTableTxt_Volume_Brush {get;set;}
				[Browsable(false)]
				public string pTableTxt_Volume_Brushser{get { return Serialize.BrushToString(pTableTxt_Volume_Brush); }set { pTableTxt_Volume_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Volume Fill Color", GroupName = "Table Display", Description = "", Order = 71)]
		public Brush pTableFill_Volume_Brush {get;set;}
				[Browsable(false)]
				public string pTableFill_Volume_Brushser{get { return Serialize.BrushToString(pTableFill_Volume_Brush); }set { pTableFill_Volume_Brush = Serialize.StringToBrush(value); }}

		#endregion
		#region -- BidVol row colors --
		[XmlIgnore]
		[Display(Name = "BidVol Text Color", GroupName = "Table Display", Description = "", Order = 80)]
		public Brush pTableTxt_BidVol_Brush {get;set;}
				[Browsable(false)]
				public string pTableTxt_BidVol_Brushser{get { return Serialize.BrushToString(pTableTxt_BidVol_Brush); }set { pTableTxt_BidVol_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "BidVol Fill Color", GroupName = "Table Display", Description = "", Order = 81)]
		public Brush pTableFill_BidVol_Brush {get;set;}
				[Browsable(false)]
				public string pTableFill_BidVol_Brushser{get { return Serialize.BrushToString(pTableFill_BidVol_Brush); }set { pTableFill_BidVol_Brush = Serialize.StringToBrush(value); }}

		#endregion
		#region -- AskVol row colors --
		[XmlIgnore]
		[Display(Name = "AskVol Text Color", GroupName = "Table Display", Description = "", Order = 90)]
		public Brush pTableTxt_AskVol_Brush {get;set;}
				[Browsable(false)]
				public string pTableTxt_AskVol_Brushser{get { return Serialize.BrushToString(pTableTxt_AskVol_Brush); }set { pTableTxt_AskVol_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "AskVol Fill Color", GroupName = "Table Display", Description = "", Order = 91)]
		public Brush pTableFill_AskVol_Brush {get;set;}
				[Browsable(false)]
				public string pTableFill_AskVol_Brushser{get { return Serialize.BrushToString(pTableFill_AskVol_Brush); }set { pTableFill_AskVol_Brush = Serialize.StringToBrush(value); }}

		#endregion
				
		[Display(Name = "Text Font", GroupName = "Table Display", Description = "", Order = 50)]
        public SimpleFont pTableFont { get; set; }

        #endregion
		#region -- BidAsk Histo --
		[Display(Name = "Histo scaling basis", GroupName = "BidAsk Histos", Description = "Are histo sizes based on the max vol from all bars on chart, or from each bar individually", Order = 5)]
		public ARC_PrintProfiler_BidAskHistoScaling pBiAskHistoScalingBasis
		{get;set;}

		[Range(0f,100f)]
		[Display(Name = "BidAsk Histo Opacity", GroupName = "BidAsk Histos", Description = "", Order = 10)]
		public float pBidAskHistoOpacity
		{get;set;}

		[XmlIgnore]
		[Display(Name = "BidHisto Color", GroupName = "BidAsk Histos", Description = "", Order = 20)]
		public Brush pBidHistoBrush {get;set;}
				[Browsable(false)]
				public string pBidHistoBrushSerialize{get { return Serialize.BrushToString(pBidHistoBrush); }set { pBidHistoBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "AskHistoColor", GroupName = "BidAsk Histos", Description = "", Order = 30)]
		public Brush pAskHistoBrush {get;set;}
				[Browsable(false)]
				public string pAskHistoBrushSerialize{get { return Serialize.BrushToString(pAskHistoBrush); }set { pAskHistoBrush = Serialize.StringToBrush(value); }}

		#endregion
        #region -- Profile (Manual) --
        [TypeConverter(typeof(ProfileDisplayMode))]
        [Display(Name = "Display Mode", GroupName = "Profile (Manual)", Description = "", Order = 00)]
        public string iMPDisplay { get; set; }

        [XmlIgnore]
        [Display(Name = "Rectangle Fill Color", GroupName = "Profile (Manual)", Description = "", Order = 10)]
        public Brush iMPFillColor { get; set; }
        [Browsable(false)]
        public string iMPFillColorSerialize
        {
            get { return Serialize.BrushToString(iMPFillColor); }
            set { iMPFillColor = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Rectangle Fill Opacity (%)", GroupName = "Profile (Manual)", Description = "In percent, the opacity of the rectangle fill color.", Order = 20)]
        public int iMPFillOpacity { get; set; }

        [XmlIgnore]
        [Display(Name = "Rectangle Outline Color", GroupName = "Profile (Manual)", Description = "", Order = 30)]
        public Brush iMPOutlineColor { get; set; }
        [Browsable(false)]
        public string iMPOutlineColorSerialize
        {
            get { return Serialize.BrushToString(iMPOutlineColor); }
            set { iMPOutlineColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color", GroupName = "Profile (Manual)", Description = "", Order = 40)]
        public Brush iMPHistogramMColor { get; set; }
        [Browsable(false)]
        public string iMPHistogramMColorSerialize
        {
            get { return Serialize.BrushToString(iMPHistogramMColor); }
            set { iMPHistogramMColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color Cluster", GroupName = "Profile (Manual)", Description = "", Order = 50)]
        public Brush iMPHistogramClusterColor { get; set; }
        [Browsable(false)]
        public string iMPHistogramClusterColorSerialize
        {
            get { return Serialize.BrushToString(iMPHistogramClusterColor); }
            set { iMPHistogramClusterColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color POC", GroupName = "Profile (Manual)", Description = "", Order = 60)]
        public Brush iMPHistogramPOCColor { get; set; }
        [Browsable(false)]
        public string iMPHistogramPOCColorSerialize
        {
            get { return Serialize.BrushToString(iMPHistogramPOCColor); }
            set { iMPHistogramPOCColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color VA", GroupName = "Profile (Manual)", Description = "", Order = 70)]
        public Brush iMPHistogramVAColor { get; set; }
        [Browsable(false)]
        public string iMPHistogramVAColorSerialize
        {
            get { return Serialize.BrushToString(iMPHistogramVAColor); }
            set { iMPHistogramVAColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color VAH", GroupName = "Profile (Manual)", Description = "", Order = 80)]
        public Brush iMPHistogramVAHColor { get; set; }
        [Browsable(false)]
        public string iMPHistogramVAHColorSerialize
        {
            get { return Serialize.BrushToString(iMPHistogramVAHColor); }
            set { iMPHistogramVAHColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color VAL", GroupName = "Profile (Manual)", Description = "", Order = 90)]
        public Brush iMPHistogramVALColor { get; set; }
        [Browsable(false)]
        public string iMPHistogramVALColorSerialize
        {
            get { return Serialize.BrushToString(iMPHistogramVALColor); }
            set { iMPHistogramVALColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color VWAP", GroupName = "Profile (Manual)", Description = "", Order = 100)]
        public Brush iMPHistogramVWAPColor { get; set; }
        [Browsable(false)]
        public string iMPHistogramVWAPColorSerialize
        {
            get { return Serialize.BrushToString(iMPHistogramVWAPColor); }
            set { iMPHistogramVWAPColor = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Histogram Fill Opacity (%)", GroupName = "Profile (Manual)", Description = "In percent, the opacity of the histogram fill color.", Order = 110)]
        public int iMPHistogramOpacity { get; set; }

        [Range(0, 100)]
        [Display(Name = "Levels Line Width", GroupName = "Profile (Manual)", Description = "Width of lines", Order = 120)]
        public int iMPLineWidth { get; set; }

        [Display(Name = "Draw On Top", GroupName = "Profile (Manual)", Description = "", Order = 130)]
        public bool iMPONTOP { get; set; }

        [TypeConverter(typeof(ProfileHD))]
        [Display(Name = "Horizontal Display", GroupName = "Profile (Manual)", Description = "", Order = 140)]
        public string iManualProfileHD { get; set; }

        [Display(Name = "Level Labels", GroupName = "Profile (Manual)", Description = "", Order = 150)]
        public bool iMPLabels { get; set; }

/*        [Display(Name = "Show CWAP", GroupName = "Profile (Manual)", Description = "", Order = 160)]
        public bool iShowCwapManual { get; set; }

        [XmlIgnore]
        [Display(Name = "CWAP Color", GroupName = "Profile (Manual)", Description = "", Order = 161)]
        public Brush iCwapManColor { get; set; }
        [Browsable(false)]
        public string iCwapManColorSerialize
        {
            get { return Serialize.BrushToString(iCwapManColor); }
            set { iCwapManColor = Serialize.StringToBrush(value); }
        }

        [Display(Name = "CWAP DashStyle", GroupName = "Profile (Manual)", Description = "", Order = 162)]
        public DashStyleHelper iCwapManDashStyle { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "CWAP Width", GroupName = "Profile (Manual)", Description = "", Order = 163)]
        public int iCwapManWidth { get; set; }*/
        #endregion

        #region -- Profile (Composite) --
        [Display(Name = "Profile (Composite) Enabled", GroupName = "Profile (Composite)", Description = "", Order = 00)]
        public bool iCompositeEnabled { get; set; }

        [TypeConverter(typeof(CompositeType))]
        [Display(Name = "Composite Type", GroupName = "Profile (Composite)", Description = "Day - reset at the session break. Time - reset at specified time and interval.", Order = 10)]
        public string iCompositeType { get; set; }

        private TimeSpan iResetTime;
        [NinjaScriptProperty]
        [Display(Name = "Time Start", GroupName = "Profile (Composite)", Description = "Enter the time to reset.", Order = 20)]
        public string ResetTime
        {
            get { return iResetTime.Hours.ToString("0") + ":" + iResetTime.Minutes.ToString("00"); }
            set { if (!TimeSpan.TryParse(value, out iResetTime)) iResetTime = new TimeSpan(0, 0, 0); }
        }

        [NinjaScriptProperty]
        [Range(0, 1440)]
        [Display(Name = "Time Interval (Minutes)", GroupName = "Profile (Composite)", Description = "Minutes To Reset.", Order = 30)]
        public int iResetMinutes { get; set; }

        [TypeConverter(typeof(ProfileDisplayMode))]
        [Display(Name = "Display Mode", GroupName = "Profile (Composite)", Description = "", Order = 40)]
        public string iCPDisplay { get; set; }

//        [Range(0, 100)]
//        [Display(Name = "Rectangle Fill Opacity (%)", GroupName = "Profile (Composite)", Description = "In percent, the opacity of the rectangle fill color.", Order = 50)]
//        public int iCPFillOpacity { get; set; }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color", GroupName = "Profile (Composite)", Description = "", Order = 60)]
        public Brush iCPHistogramMColor { get; set; }
        [Browsable(false)]
        public string iCPHistogramMColorSerialize
        {
            get { return Serialize.BrushToString(iCPHistogramMColor); }
            set { iCPHistogramMColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color Cluster", GroupName = "Profile (Composite)", Description = "", Order = 70)]
        public Brush iCPHistogramClusterColor { get; set; }
        [Browsable(false)]
        public string iCPHistogramClusterColorSerialize
        {
            get { return Serialize.BrushToString(iCPHistogramClusterColor); }
            set { iCPHistogramClusterColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color EXH", GroupName = "Profile (Composite)", Description = "", Order = 80)]
        public Brush iCPHistogramVAH2Color { get; set; }
        [Browsable(false)]
        public string iCPHistogramVAH2ColorSerialize
        {
            get { return Serialize.BrushToString(iCPHistogramVAH2Color); }
            set { iCPHistogramVAH2Color = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color EXL", GroupName = "Profile (Composite)", Description = "", Order = 90)]
        public Brush iCPHistogramVAL2Color { get; set; }
        [Browsable(false)]
        public string iCPHistogramVAL2ColorSerialize
        {
            get { return Serialize.BrushToString(iCPHistogramVAL2Color); }
            set { iCPHistogramVAL2Color = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color POC", GroupName = "Profile (Composite)", Description = "", Order = 100)]
        public Brush iCPHistogramPOCColor { get; set; }
        [Browsable(false)]
        public string iCPHistogramPOCColorSerialize
        {
            get { return Serialize.BrushToString(iCPHistogramPOCColor); }
            set { iCPHistogramPOCColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color VA", GroupName = "Profile (Composite)", Description = "", Order = 110)]
        public Brush iCPHistogramVAColor { get; set; }
        [Browsable(false)]
        public string iCPHistogramVAColorSerialize
        {
            get { return Serialize.BrushToString(iCPHistogramVAColor); }
            set { iCPHistogramVAColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color VAH", GroupName = "Profile (Composite)", Description = "", Order = 120)]
        public Brush iCPHistogramVAHColor { get; set; }
        [Browsable(false)]
        public string iCPHistogramVAHColorSerialize
        {
            get { return Serialize.BrushToString(iCPHistogramVAHColor); }
            set { iCPHistogramVAHColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color VAL", GroupName = "Profile (Composite)", Description = "", Order = 130)]
        public Brush iCPHistogramVALColor { get; set; }
        [Browsable(false)]
        public string iCPHistogramVALColorSerialize
        {
            get { return Serialize.BrushToString(iCPHistogramVALColor); }
            set { iCPHistogramVALColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Histogram Fill Color VWAP", GroupName = "Profile (Composite)", Description = "", Order = 140)]
        public Brush iCPHistogramVWAPColor { get; set; }
        [Browsable(false)]
        public string iCPHistogramVWAPColorSerialize
        {
            get { return Serialize.BrushToString(iCPHistogramVWAPColor); }
            set { iCPHistogramVWAPColor = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Histogram Fill Opacity (%)", GroupName = "Profile (Composite)", Description = "In percent, the opacity of the histogram fill color.", Order = 150)]
        public int iCPHistogramOpacity { get; set; }

        [Range(0, 10000)]
        [Display(Name = "Histogram Length (Pixels)", GroupName = "Profile (Composite)", Description = "the maximum length of the histogram display, in pixels.", Order = 160)]
        public int iCompLength { get; set; }

        [Display(Name = "Current Profile Enabled", GroupName = "Profile (Composite)", Description = "", Order = 180)]
        public bool iCCompositeEnabled { get; set; }

        [Display(Name = "Historical Profiles Enabled", GroupName = "Profile (Composite)", Description = "", Order = 190)]
        public bool iHCompositeEnabled { get; set; }

        [Range(0, 100)]
        [Display(Name = "Levels Line Width", GroupName = "Profile (Composite)", Description = "Width of lines", Order = 200)]
        public int iCPLineWidth { get; set; }

        [Display(Name = "Volume Numbers Enabled", GroupName = "Profile (Composite)", Description = "", Order = 210)]
        public bool iDrawCText { get; set; }

        [Display(Name = "Developing Levels Enabled", GroupName = "Profile (Composite)", Description = "", Order = 220)]
        public bool iCompDevLevel { get; set; }

        [XmlIgnore]
        [Display(Name = "Developing Level Area Fill Color (EX)", GroupName = "Profile (Composite)", Description = "", Order = 230)]
        public Brush iEXFillColor { get; set; }
        [Browsable(false)]
        public string iEXFillColorSerialize
        {
            get { return Serialize.BrushToString(iEXFillColor); }
            set { iEXFillColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Developing Level Area Fill Color (VA)", GroupName = "Profile (Composite)", Description = "", Order = 240)]
        public Brush iVAFillColor { get; set; }
        [Browsable(false)]
        public string iVAFillColorSerialize
        {
            get { return Serialize.BrushToString(iVAFillColor); }
            set { iVAFillColor = Serialize.StringToBrush(value); }
        }

        [Range(1, 100)]
        [Display(Name = "Developing Level Area Fill Opacity (%)", GroupName = "Profile (Composite)", Description = "In percent, the opacity of the rectangle fill color.", Order = 260)]
        public int iFillAreaOpacity { get; set; }

        [Display(Name = "Developing Levels Current Enabled", GroupName = "Profile (Composite)", Description = "", Order = 270)]
        public bool iCompDevCLevel { get; set; }

        [Display(Name = "Developing Levels Historical Enabled", GroupName = "Profile (Composite)", Description = "", Order = 280)]
        public bool iCompDevHLevel { get; set; }

        [Display(Name = "Developing Levels (EX)", GroupName = "Profile (Composite)", Description = "", Order = 290)]
        public bool iCompDevEX { get; set; }

        [Display(Name = "Developing Levels (POC)", GroupName = "Profile (Composite)", Description = "", Order = 300)]
        public bool iCompDevPOC { get; set; }

        [Display(Name = "Developing Levels (VA)", GroupName = "Profile (Composite)", Description = "", Order = 310)]
        public bool iCompDevVA { get; set; }

        [Display(Name = "Developing Levels (VWAP)", GroupName = "Profile (Composite)", Description = "", Order = 320)]
        public bool iCompDevVWAP { get; set; }

        [Display(Name = "Developing Levels Area Fill", GroupName = "Profile (Composite)", Description = "", Order = 330)]
        public bool iCompDevLevelArea { get; set; }

        [Display(Name = "Draw On Top", GroupName = "Profile (Composite)", Description = "", Order = 340)]
        public bool iCPONTOP { get; set; }

        [TypeConverter(typeof(ProfileHD))]
        [Display(Name = "Horizontal Display", GroupName = "Profile (Composite)", Description = "", Order = 350)]
        public string iCompositeProfileHD { get; set; }

        [Display(Name = "Level Extend", GroupName = "Profile (Composite)", Description = "", Order = 360)]
        public bool iCompLineExtend { get; set; }

        [Display(Name = "Level Labels", GroupName = "Profile (Composite)", Description = "", Order = 370)]
        public bool iCompLineLabels { get; set; }
/*
        [Display(Name = "Show CWAP", GroupName = "Profile (Composite)", Description = "", Order = 380)]
        public bool iShowCwapComposite { get; set; }

        [XmlIgnore]
        [Display(Name = "CWAP Color", GroupName = "Profile (Composite)", Description = "", Order = 381)]
        public Brush iCwapCompColor { get; set; }
        [Browsable(false)]
        public string iCwapCompColorSerialize
        {
            get { return Serialize.BrushToString(iCwapCompColor); }
            set { iCwapCompColor = Serialize.StringToBrush(value); }
        }

        [Display(Name = "CWAP DashStyle", GroupName = "Profile (Composite)", Description = "", Order = 382)]
        public DashStyleHelper iCwapCompDashStyle { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "CWAP Width", GroupName = "Profile (Composite)", Description = "", Order = 383)]
        public int iCwapCompWidth { get; set; }
        */
        #endregion

        #region -- Profile (Bars) --
        [Display(Name = "Profile (Bar) Enabled", GroupName = "Profile (Bar)", Description = "", Order = 00)]
        public bool iBarCompositeEnabled { get; set; }

        [Display(Name = "Display Cluster", GroupName = "Profile (Bar)", Description = "", Order = 20)]
        public bool iDisplayCL { get; set; }

        [Display(Name = "Display POC", GroupName = "Profile (Bar)", Description = "", Order = 30)]
        public bool iDisplayPOC { get; set; }

        [Display(Name = "Display VAH / VAL", GroupName = "Profile (Bar)", Description = "", Order = 40)]
        public bool iDisplayVA { get; set; }

        [Display(Name = "Display VWAP", GroupName = "Profile (Bar)", Description = "", Order = 50)]
        public bool iDisplayVWAP { get; set; }

        [Range(0, 10000)]
        [Display(Name = "Histogram Width", GroupName = "Profile (Bar)", Description = "Width of the histogram lines for bar profile, when print is disabled", Order = 60)]
        public int iBarPW { get; set; }

        [XmlIgnore]
        [Display(Name = "Bar Fill Color", GroupName = "Profile (Bar)", Description = "", Order = 70)]
        public Brush iMPBarMColor { get; set; }
        [Browsable(false)]
        public string iMPBarMColorSerialize
        {
            get { return Serialize.BrushToString(iMPBarMColor); }
            set { iMPBarMColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bar Fill Color Cluster", GroupName = "Profile (Bar)", Description = "", Order = 80)]
        public Brush iMPBarClusterColor { get; set; }
        [Browsable(false)]
        public string iMPBarClusterColorSerialize
        {
            get { return Serialize.BrushToString(iMPBarClusterColor); }
            set { iMPBarClusterColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bar Fill Color POC", GroupName = "Profile (Bar)", Description = "", Order = 90)]
        public Brush iMPBarPOCColor { get; set; }
        [Browsable(false)]
        public string iMPBarPOCColorSerialize
        {
            get { return Serialize.BrushToString(iMPBarPOCColor); }
            set { iMPBarPOCColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bar Fill Color VA", GroupName = "Profile (Bar)", Description = "", Order = 100)]
        public Brush iMPBarVAColor { get; set; }
        [Browsable(false)]
        public string iMPBarVAColorSerialize
        {
            get { return Serialize.BrushToString(iMPBarVAColor); }
            set { iMPBarVAColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bar Fill Color VAH", GroupName = "Profile (Bar)", Description = "", Order = 110)]
        public Brush iMPBarVAHColor { get; set; }
        [Browsable(false)]
        public string iMPBarVAHColorSerialize
        {
            get { return Serialize.BrushToString(iMPBarVAHColor); }
            set { iMPBarVAHColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bar Fill Color VAL", GroupName = "Profile (Bar)", Description = "", Order = 120)]
        public Brush iMPBarVALColor { get; set; }
        [Browsable(false)]
        public string iMPBarVALColorSerialize
        {
            get { return Serialize.BrushToString(iMPBarVALColor); }
            set { iMPBarVALColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bar Fill Color VWAP", GroupName = "Profile (Bar)", Description = "", Order = 130)]
        public Brush iMPBarVWAPColor { get; set; }
        [Browsable(false)]
        public string iMPBarVWAPColorSerialize
        {
            get { return Serialize.BrushToString(iMPBarVWAPColor); }
            set { iMPBarVWAPColor = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Bar Fill Opacity (%)", GroupName = "Profile (Bar)", Description = "In percent, the opacity of the Bar fill color.", Order = 140)]
        public int iMPBarOpacity { get; set; }

        [Range(0, 100)]
        [Display(Name = "Cluster Box Fill Opacity (%) (Print Off)", GroupName = "Profile (Bar)", Description = "In percent, the opacity of the Cluster Box color.", Order = 150)]
        public int iMPBarOpacity2 { get; set; }

        [XmlIgnore]
        [Display(Name = "Cluster Box Color (Print Off)", GroupName = "Profile (Bar)", Description = "", Order = 160)]
        public Brush iMPHistogramClusterColor2 { get; set; }
        [Browsable(false)]
        public string iMPHistogramClusterColor2Serialize
        {
            get { return Serialize.BrushToString(iMPHistogramClusterColor2); }
            set { iMPHistogramClusterColor2 = Serialize.StringToBrush(value); }
        }

        #endregion

        #region -- Profile (All) --
        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name = "Value Area (%)", GroupName = "Profile (All)", Description = "In percent, the amount of volume that makes up the value area.", Order = 0)]
        public int iVAPercent { get; set; }
        #endregion

        #region -- Indicator Display --
        [Range(0, 100)]
        [Display(Name = "Chart Button Size (Pixels)", GroupName = "Indicator Display", Description = "", Order = 00)]
        public int iButtonSize { get; set; }

		[Display(Name = "Button Text", GroupName = "Indicator Display", Description = "", Order = 20)]
		public string pButtonText {get;set;}
        #endregion

        #region -- Signals Display --
        [Display(Name = "Show Long Signals", GroupName = "Signals Display", Description = "", Order = 00)]
        public bool iLongsEnabled { get; set; }

        [Display(Name = "Show Short Signals", GroupName = "Signals Display", Description = "", Order = 10)]
        public bool iShortsEnabled { get; set; }
        #endregion

#if VOLUME_AVERAGES_ON_TRANSACTION_VOLUME
        #region -- Volume Averages Set 1 --
        [Display(Name = "Enabled", GroupName = "Volume Averages Set 1", Description = "", Order = 00)]
        public bool iVA1Enabled { get; set; }

        [Range(0, 1000)]
        [Display(Name = "MA Period", GroupName = "Volume Averages Set 1", Description = "", Order = 10)]
        public int iVA1Period { get; set; }

        [TypeConverter(typeof(VolumeAverageMode))]
        [Display(Name = "MA Type", GroupName = "Volume Averages Set 1", Description = "", Order = 20)]
        public string iVA1Mode { get; set; }

        [Display(Name = "Cluster Enabled", GroupName = "Volume Averages Set 1", Description = "", Order = 30)]
        public bool iVA1Enabled3 { get; set; }

        [XmlIgnore]
        [Display(Name = "Cluster Color", GroupName = "Volume Averages Set 1", Description = "", Order = 40)]
        public Brush iVA3Color { get; set; }
        [Browsable(false)]
        public string iVA3ColorSerialize
        {
            get { return Serialize.BrushToString(iVA3Color); }
            set { iVA3Color = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Cluster DashStyle", GroupName = "Volume Averages Set 1", Description = "", Order = 50)]
        public DashStyleHelper iVA1DashStyle { get; set; }

        [XmlIgnore]
        [Display(Name = "Cluster Fill Color", GroupName = "Volume Averages Set 1", Description = "", Order = 60)]
        public Brush iVA33Color { get; set; }
        [Browsable(false)]
        public string iVA33ColorSerialize
        {
            get { return Serialize.BrushToString(iVA33Color); }
            set { iVA33Color = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Cluster Fill Opacity (%)", GroupName = "Volume Averages Set 1", Description = "", Order = 70)]
        public int iVA3Opacity { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Cluster Width", GroupName = "Volume Averages Set 1", Description = "", Order = 80)]
        public int iVA1Width { get; set; }

        [Display(Name = "POC Enabled", GroupName = "Volume Averages Set 1", Description = "", Order = 90)]
        public bool iVA1Enabled1 { get; set; }

        [XmlIgnore]
        [Display(Name = "POC Color", GroupName = "Volume Averages Set 1", Description = "", Order = 100)]
        public Brush iVA1Color { get; set; }
        [Browsable(false)]
        public string iVA1ColorSerialize
        {
            get { return Serialize.BrushToString(iVA1Color); }
            set { iVA1Color = Serialize.StringToBrush(value); }
        }

        [Display(Name = "POC DashStyle", GroupName = "Volume Averages Set 1", Description = "", Order = 110)]
        public DashStyleHelper iVA1DashStyle { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "POC Width", GroupName = "Volume Averages Set 1", Description = "", Order = 120)]
        public int iVA1Width { get; set; }

        [Display(Name = "VWAP Enabled", GroupName = "Volume Averages Set 1", Description = "", Order = 130)]
        public bool iVA1Enabled2 { get; set; }

        [XmlIgnore]
        [Display(Name = "VWAP Color", GroupName = "Volume Averages Set 1", Description = "", Order = 140)]
        public Brush iVA2Color { get; set; }
        [Browsable(false)]
        public string iVA2ColorSerialize
        {
            get { return Serialize.BrushToString(iVA2Color); }
            set { iVA2Color = Serialize.StringToBrush(value); }
        }

        [Display(Name = "VWAP DashStyle", GroupName = "Volume Averages Set 1", Description = "", Order = 150)]
        public DashStyleHelper iVA2DashStyle { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "VWAP Width", GroupName = "Volume Averages Set 1", Description = "", Order = 160)]
        public int iVA2Width { get; set; }
        #endregion

        #region -- Volume Averages Set 2 --
        [Display(Name = "Enabled", GroupName = "Volume Averages Set 2", Description = "", Order = 00)]
        public bool iVA2Enabled { get; set; }

        [Range(0, 1000)]
        [Display(Name = "MA Period", GroupName = "Volume Averages Set 2", Description = "", Order = 10)]
        public int iVA2Period { get; set; }

        [TypeConverter(typeof(VolumeAverageMode))]
        [Display(Name = "MA Type", GroupName = "Volume Averages Set 2", Description = "", Order = 20)]
        public string iVA2Mode { get; set; }

        [Display(Name = "Cluster Enabled", GroupName = "Volume Averages Set 2", Description = "", Order = 30)]
        public bool iVA2Enabled3 { get; set; }

        [XmlIgnore]
        [Display(Name = "Cluster Color", GroupName = "Volume Averages Set 2", Description = "", Order = 40)]
        public Brush iVAS3Color { get; set; }
        [Browsable(false)]
        public string iVAS3ColorSerialize
        {
            get { return Serialize.BrushToString(iVAS3Color); }
            set { iVAS3Color = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Cluster DashStyle", GroupName = "Volume Averages Set 2", Description = "", Order = 50)]
        public DashStyleHelper iVA2DashStyle { get; set; }

        [XmlIgnore]
        [Display(Name = "Cluster Fill Color", GroupName = "Volume Averages Set 2", Description = "", Order = 60)]
        public Brush iVAS33Color { get; set; }
        [Browsable(false)]
        public string iVAS33ColorSerialize
        {
            get { return Serialize.BrushToString(iVAS33Color); }
            set { iVAS33Color = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Cluster Fill Opacity (%)", GroupName = "Volume Averages Set 2", Description = "", Order = 70)]
        public int iVAS3Opacity { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Cluster Width", GroupName = "Volume Averages Set 2", Description = "", Order = 80)]
        public int iVA2Width { get; set; }

        [Display(Name = "POC Enabled", GroupName = "Volume Averages Set 2", Description = "", Order = 90)]
        public bool iVA2Enabled1 { get; set; }

        [XmlIgnore]
        [Display(Name = "POC Color", GroupName = "Volume Averages Set 2", Description = "", Order = 100)]
        public Brush iVAS1Color { get; set; }
        [Browsable(false)]
        public string iVAS1ColorSerialize
        {
            get { return Serialize.BrushToString(iVAS1Color); }
            set { iVAS1Color = Serialize.StringToBrush(value); }
        }

        [Display(Name = "POC DashStyle", GroupName = "Volume Averages Set 2", Description = "", Order = 110)]
        public DashStyleHelper iVAS1DashStyle { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "POC Width", GroupName = "Volume Averages Set 2", Description = "", Order = 120)]
        public int iVAS1Width { get; set; }

        [Display(Name = "VWAP Enabled", GroupName = "Volume Averages Set 2", Description = "", Order = 130)]
        public bool iVA2Enabled2 { get; set; }

        [XmlIgnore]
        [Display(Name = "VWAP Color", GroupName = "Volume Averages Set 2", Description = "", Order = 140)]
        public Brush iVAS2Color { get; set; }
        [Browsable(false)]
        public string iVAS2ColorSerialize
        {
            get { return Serialize.BrushToString(iVAS2Color); }
            set { iVAS2Color = Serialize.StringToBrush(value); }
        }

        [Display(Name = "VWAP DashStyle", GroupName = "Volume Averages Set 2", Description = "", Order = 150)]
        public DashStyleHelper iVAS2DashStyle { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "VWAP Width", GroupName = "Volume Averages Set 2", Description = "", Order = 160)]
        public int iVAS2Width { get; set; }
        #endregion
#else
		#region -- Volume Averages Set 1 --

		[NinjaScriptProperty]
		[Display(Name = "Enabled", GroupName = "Volume Averages Set 1", Description = "", Order = 00)]
		public bool iVA1Enabled { get; set; }

		[NinjaScriptProperty]
		[Range(0, 1000)]
		[Display(Name = "MA Period", GroupName = "Volume Averages Set 1", Description = "", Order = 10)]
		public int iVA1Period { get; set; }

		[NinjaScriptProperty]
		[TypeConverter(typeof(VolumeAverageMode))]
		[Display(Name = "MA Type", GroupName = "Volume Averages Set 1", Description = "", Order = 20)]
		public string iVA1Mode { get; set; }

		[XmlIgnore]
		[Display(Name = "Cluster Color", GroupName = "Volume Averages Set 1", Description = "", Order = 40)]
		public Brush iVA1_Color { get; set; }
					[Browsable(false)]
					public string iVA3ColorSerialize
					{
					    get { return Serialize.BrushToString(iVA1_Color); }
					    set { iVA1_Color = Serialize.StringToBrush(value); }
					}

		[XmlIgnore]
		[Display(Name = "Cluster Fill Color", GroupName = "Volume Averages Set 1", Description = "", Order = 60)]
		public Brush iVA1_FillColor { get; set; }
					[Browsable(false)]
					public string iVA33ColorSerialize
					{
					    get { return Serialize.BrushToString(iVA1_FillColor); }
					    set { iVA1_FillColor = Serialize.StringToBrush(value); }
					}

		[Range(0, 100)]
		[Display(Name = "Cluster Fill Opacity (%)", GroupName = "Volume Averages Set 1", Description = "", Order = 70)]
		public int iVA3Opacity { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Cluster size (ticks)", GroupName = "Volume Averages Set 1", Description = "", Order = 80)]
		public int iVA1_ClusterSizeTicks { get; set; }

		#endregion

		#region -- Volume Averages Set 2 --
		[NinjaScriptProperty]
		[Display(Name = "Enabled", GroupName = "Volume Averages Set 2", Description = "", Order = 00)]
		public bool iVA2Enabled { get; set; }

		[NinjaScriptProperty]
		[Range(0, 1000)]
		[Display(Name = "MA Period", GroupName = "Volume Averages Set 2", Description = "", Order = 10)]
		public int iVA2Period { get; set; }

		[NinjaScriptProperty]
		[TypeConverter(typeof(VolumeAverageMode))]
		[Display(Name = "MA Type", GroupName = "Volume Averages Set 2", Description = "", Order = 20)]
		public string iVA2Mode { get; set; }

		[XmlIgnore]
		[Display(Name = "Cluster Color", GroupName = "Volume Averages Set 2", Description = "", Order = 40)]
		public Brush iVA2_Color { get; set; }
					[Browsable(false)]
					public string iVAS3ColorSerialize
					{
					    get { return Serialize.BrushToString(iVA2_Color); }
					    set { iVA2_Color = Serialize.StringToBrush(value); }
					}

		[XmlIgnore]
		[Display(Name = "Cluster Fill Color", GroupName = "Volume Averages Set 2", Description = "", Order = 60)]
		public Brush iVA2_FillColor { get; set; }
					[Browsable(false)]
					public string iVAS33ColorSerialize
					{
					    get { return Serialize.BrushToString(iVA2_FillColor); }
					    set { iVA2_FillColor = Serialize.StringToBrush(value); }
					}

		[Range(0, 100)]
		[Display(Name = "Cluster Fill Opacity (%)", GroupName = "Volume Averages Set 2", Description = "", Order = 70)]
		public int iVAS3Opacity { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Cluster size (ticks)", GroupName = "Volume Averages Set 2", Description = "", Order = 80)]
		public int iVA2_ClusterSizeTicks { get; set; }

        #endregion
#endif
        #region -- Volume Divergence Signals --

        //		pSignalTiming = NSVolumeLean_SignalTimingTypes.OnClose;
        //		[Description("When do you want the audible alert to play?  'OnTick' may have pre-signals which can be reversed and become non-signals")]
        //        [Display(Name = "Sound Timing", GroupName = "Volume Divergence Signals", Order = 259)]
        //		public NSVolumeLean_SignalTimingTypes pSignalTiming
        //		{ get; set; }

        //		[Description("WAV file to play for Volume Divergence signals, leave blank to turn off the alert")]
        //        [Display(Name = "VolD Buy Sound", GroupName = "Volume Divergence Signals", Order = 300)]
        //		[RefreshProperties(RefreshProperties.All)]
        //		[TypeConverter(typeof(LoadSoundFileList))]
        //		public string VD_BuyAlertWav
        //		{ get; set; }

        //		[Description("WAV file to play for Volume Divergence signals, leave blank to turn off the alert")]
        //        [Display(Name = "VolD Sell Sound", GroupName = "Volume Divergence Signals", Order = 310)]
        //		[RefreshProperties(RefreshProperties.All)]
        //		[TypeConverter(typeof(LoadSoundFileList))]
        //		public string VD_SellAlertWav
        //		{ get; set; }
        #endregion

        #region -- Volume Cluster Reversal signals --
        [Display(Order = 10, Name = "Enable VCR", GroupName = "VCR Alert", Description = "")]
        public bool pShow_VCRSignal { get; set; }

        [Display(Order = 20, Name = "Show 2-Bar Pattern", GroupName = "VCR Alert", Description = "")]
        public bool pShow_VCR2b { get; set; }

        [Display(Order = 21, Name = "Show 3-Bar Pattern", GroupName = "VCR Alert", Description = "")]
        public bool pShow_VCR3b { get; set; }

        [Display(Order = 22, Name = "Absolute High in 3-bar", GroupName = "VCR Alert", Description = "")]
        public bool pShow_Absolute3Bar { get; set; }

        [XmlIgnore]
        [Display(Order = 30, Name = "BUY color", GroupName = "VCR Alert", Description = "Color of triangles that give visual BUY signal")]
        public Brush iArrowUpColorVCR { get; set; }
        [Browsable(false)]
        public string BuyVCRBrush_Serialize { get { return Serialize.BrushToString(iArrowUpColorVCR); } set { iArrowUpColorVCR = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Order = 40, Name = "SELL color", GroupName = "VCR Alert", Description = "Color of triangles that give visual SELL signal")]
        public Brush iArrowDnColorVCR { get; set; }
        [Browsable(false)]
        public string SellVCRBrush_Serialize { get { return Serialize.BrushToString(iArrowDnColorVCR); } set { iArrowDnColorVCR = Serialize.StringToBrush(value); } }

        [Display(Order = 60, Name = "2-Bar Signal Display Name", GroupName = "VCR Alert", Description = "")]
        public string iSignalNameVCR2 { get; set; }

        [Display(Order = 61, Name = "3-Bar Signal Display Name", GroupName = "VCR Alert", Description = "")]
        public string iSignalNameVCR3 { get; set; }

        [Range(0, 1000)]
        [Display(Name = "Arrows - Offset (Pixels)", GroupName = "VCR Alert", Description = "Number of pixels distance arrows level.", Order = 70)]
        public int iSeparationVCR { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Arrows - Size", GroupName = "VCR Alert", Description = "Arrow size, in pixels", Order = 71)]
        public int iArrowWidthVCR { get; set; }

        [Description("WAV file to play for Volume Cluster Reversal signals, leave blank to turn off the alert")]
        [Display(Name = "Vol Cluster Buy Sound", GroupName = "VCR Alert", Order = 300)]
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
        public string VC_BuyAlertWav
        { get; set; }

        [Description("WAV file to play for Volume Cluster Reversal signals, leave blank to turn off the alert")]
        [Display(Name = "Vol Cluster Sell Sound", GroupName = "VCR Alert", Order = 310)]
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
        public string VC_SellAlertWav
        { get; set; }
        #endregion

		#region -- OrderFlowConfluence Signals --
//        [Display(Order = 10, Name = "Enable OFC", GroupName = "OrderFlowConfluence Signals", Description = "OrderFlow Confluence, based on all green, or all red table values")]
//        public bool pShow_OFCSignal { get; set; }
		private bool pShow_OFCSignal = false;

//		[Description("WAV file to play for OrderFlow Confluence signals, leave blank to turn off the alert")]
//        [Display(Name = "OrderFlow Confl. Sound", GroupName = "OrderFlowConfluence Signals", Order = 20)]
//        [RefreshProperties(RefreshProperties.All)]
//        [TypeConverter(typeof(LoadSoundFileList))]
//        public string OFC_AlertWav
//        { get; set; }
		private string OFC_AlertWav = "";

//		[Display(Name = "Label OFC", GroupName = "OrderFlowConfluence Signals", Description = "", Order = 40)]
//        public string iSignalNameOFC { get; set; }
		private string iSignalNameOFC = "";

//		[Range(0, 1000)]
//        [Display(Name = "Diamond - Offset (Pixels)", GroupName = "OrderFlowConfluence Signals", Description = "Number of pixels distance arrows level.", Order = 60)]
//        public int iDiamondSeparationOFC { get; set; }
		private int iDiamondSeparationOFC=1;

//        [Range(1, 1000)]
//        [Display(Name = "Diamond - Size", GroupName = "OrderFlowConfluence Signals", Description = "Diamond size, in pixels", Order = 70)]
//		public int iDotWidthOFC
//		{get;set;}
		private int iDotWidthOFC = 1;

        #endregion

		#region -- Delta Spread Analysis signals --
		[Display(Order = 10, Name = "Enable DSA", GroupName = "DSA Alert", Description = "")]
		public bool pShow_DSASignal { get; set; }

		[Range(1,10)]
		[Display(Order = 20, Name = "DSA Sensitivity", GroupName = "DSA Alert", Description = "1 is most permissive, 10 is most restrictive")]
		public int pDSA_Sensitivity { get; set; }

		[XmlIgnore]
		[Display(Order = 30, Name = "BUY color", GroupName = "DSA Alert", Description = "Color of rectangles that give visual BUY signal")]
		public Brush pBuy_DSABrush { get; set; }
				[Browsable(false)]
				public string BuyDSABrush_Serialize{get { return Serialize.BrushToString(pBuy_DSABrush); }set { pBuy_DSABrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 40, Name = "SELL color", GroupName = "DSA Alert", Description = "Color of rectangles that give visual SELL signal")]
		public Brush pSell_DSABrush { get; set; }
				[Browsable(false)]
				public string SellDSABrush_Serialize{get { return Serialize.BrushToString(pSell_DSABrush); }set { pSell_DSABrush = Serialize.StringToBrush(value); }}

		[Range(1,100)]
		[Display(Order = 50, Name = "Op. HM outline", GroupName = "DSA Alert", Description = "Opacity of colored signal rectangle that prints around the HeatMap rectangle")]
		public float pDSA_OpacityOnHeatMap { get; set; }

		[Range(1,10)]
		[Display(Order = 60, Name = "Width HM outline", GroupName = "DSA Alert", Description = "Width of colored signal rectangle that prints around the HeatMap rectangle")]
		public float pDSA_HistoOutlineThickness {get;set;}

		[Range(1,100)]
		[Display(Order = 70, Name = "Op. PriceBar outline", GroupName = "DSA Alert", Description = "Opacity of colored signal rectangle that prints above and below the price bar")]
		public float pDSA_OpacityOnPriceBar { get; set; }

        //		[Display(Order = 80, Name = "Overprint PriceBar?", GroupName = "DSA Alert", Description = "Overprint a rectangle on the price bar?  If not, then print 2 rectangles, one above the price bar, and one below it")]
        //		public bool pDSA_OverprintPriceBar {get; set;}

        #endregion

        #region -- Bar Display --
        [Range(1, 1000)]
        [Display(Name = "Right Side Margin Minimum (Pixels)", GroupName = "Bar Display", Description = "", Order = 00)]
        public int iRightSideMarginMin { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Right Side Padding Minimum (Pixels)", GroupName = "Bar Display", Description = "", Order = 10)]
        public int iRightSidePaddingMin { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Bar Space Minimum (Pixels)", GroupName = "Bar Display", Description = "", Order = 20)]
        public int iMinBarSpacePixels { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Bar Space Maximum (Pixels)", GroupName = "Bar Display", Description = "", Order = 30)]
        public int iMaxBarSpacePixels { get; set; }
        #endregion

        #region -- Block Trades --
        [Display(Name = "Block Trades Enabled", GroupName = "Block Trades", Description = "", Order = 00)]
        public bool pShow_Blocks { get; set; }

		[Display(Name = "Dyn BlockSize Percentile", GroupName = "Block Trades", Description = "Percentile filter, use to filter out low-volume Blocks", Order = 10)]
		public double pDynBlockSizePercentile {get;set;}

        [Display(Name = "Dyn BlockSize chart bars lookback", GroupName = "Block Trades", Description = "Number of bars of history prior to the current bar being used in the calculation of the Dynamic BlockSize", Order = 20)]
		public int pDynBlockSizeLookbackBars {get;set;}
		
//        [Display(Name = "Enable continuous dyn calc?", GroupName = "Block Trades", Description = "Calculate avg dynamic blocksize continuously?  Could cause performance slowdown", Order = 30)]
//		public bool pEnableContinuousDynBlockSizeCalc {get;set;}

		[Range(-1, int.MaxValue)]
        [Display(Name = "Minimum Block Trade Size", GroupName = "Block Trades", Description = ""/*"If 'continuous dyn calc' is enabled, this parameter is ignored"*/, Order = 40)]
        public int iBlockSize { get; set; }

        [XmlIgnore]
        [Display(Name = "Arrow Ask Color", GroupName = "Block Trades", Description = "", Order = 50)]
        public Brush iIBAskColor3 { get; set; }
        [Browsable(false)]
        public string iIBAskColor3Serialize
        {
            get { return Serialize.BrushToString(iIBAskColor3); }
            set { iIBAskColor3 = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Arrow Ask Opacity (%)", GroupName = "Block Trades", Description = "", Order = 60)]
        public int iOpacityUp3 { get; set; }

        [XmlIgnore]
        [Display(Name = "Arrow Bid Color", GroupName = "Block Trades", Description = "", Order = 70)]
        public Brush iIBBidColor3 { get; set; }
        [Browsable(false)]
        public string iIBBidColor3Serialize
        {
            get { return Serialize.BrushToString(iIBBidColor3); }
            set { iIBBidColor3 = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Arrow Bid Opacity (%)", GroupName = "Block Trades", Description = "", Order = 80)]
        public int iOpacityDn3 { get; set; }

//        [TypeConverter(typeof(SignalHD))]
//        [Display(Name = "Arrow Display Mode", GroupName = "Block Trades", Description = "", Order = 90)]
        private string iTriMode { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Arrow Size", GroupName = "Block Trades", Description = "", Order = 100)]
        public int iTriSize { get; set; }
        #endregion

        #region -- Avg Stop Loss Calculators --
        [Range(-100, 100)]
        [Display(Name = "Tick Buffer", GroupName = "Avg Stop Loss Calculators", Description = "", Order = 00)]
        public int iAvgStopLossOffset { get; set; }
        #endregion

        #region -- Inventory Display --
        [NinjaScriptProperty]
        [Display(Name = "Inventory Enabled", GroupName = "Inventory Display", Description = "", Order = 00)]
        public bool iInventoryEnabled { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Total Display", GroupName = "Inventory Display", Description = "", Order = 10)]
        public bool iDisplayTotal { get; set; }

        [TypeConverter(typeof(TotalMode))]
        [Display(Name = "Total Mode", GroupName = "Inventory Display", Description = "", Order = 20)]
        public string iTriMode2 { get; set; }

        [NinjaScriptProperty]
        [Range(1, 100)]
        [Display(Name = "Max Levels", GroupName = "Inventory Display", Description = "Max Levels to Display", Order = 30)]
        public int imaxRows { get; set; }

        [Range(0, 10000)]
        [Display(Name = "Histogram Length (Pixels)", GroupName = "Inventory Display", Description = "the maximum length of the histogram display, in pixels.", Order = 40)]
        public int iInvLength { get; set; }

        [Range(0, 100)]
        [Display(Name = "Ask Fill Opacity (%)", GroupName = "Inventory Display", Description = "The opacity in percent.", Order = 50)]
        public int iSwingOpacity { get; set; }

        [XmlIgnore]
        [Display(Name = "Ask Largest Fill Color", GroupName = "Inventory Display", Description = "", Order = 60)]
        public Brush iAskHistColor2 { get; set; }
        [Browsable(false)]
        public string iAskHistColor2Serialize
        {
            get { return Serialize.BrushToString(iAskHistColor2); }
            set { iAskHistColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Ask Normal Fill Color", GroupName = "Inventory Display", Description = "", Order = 70)]
        public Brush iAskHistColor1 { get; set; }
        [Browsable(false)]
        public string iAskHistColor1Serialize
        {
            get { return Serialize.BrushToString(iAskHistColor1); }
            set { iAskHistColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Ask Outline Color", GroupName = "Inventory Display", Description = "", Order = 80)]
        public Brush iAskOutColor1 { get; set; }
        [Browsable(false)]
        public string iAskOutColor1Serialize
        {
            get { return Serialize.BrushToString(iAskOutColor1); }
            set { iAskOutColor1 = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Bid Fill Opacity (%)", GroupName = "Inventory Display", Description = "The opacity in percent.", Order = 90)]
        public int iSwingOpacity2 { get; set; }

        [XmlIgnore]
        [Display(Name = "Bid Largest Fill Color", GroupName = "Inventory Display", Description = "", Order = 100)]
        public Brush iBidHistColor2 { get; set; }
        [Browsable(false)]
        public string iBidHistColor2Serialize
        {
            get { return Serialize.BrushToString(iBidHistColor2); }
            set { iBidHistColor2 = Serialize.StringToBrush(value); }

        }

        [XmlIgnore]
        [Display(Name = "Bid Normal Fill Color", GroupName = "Inventory Display", Description = "", Order = 110)]
        public Brush iBidHistColor1 { get; set; }
        [Browsable(false)]
        public string iBidHistColor1Serialize
        {
            get { return Serialize.BrushToString(iBidHistColor1); }
            set { iBidHistColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bid Outline Color", GroupName = "Inventory Display", Description = "", Order = 120)]
        public Brush iBidOutColor1 { get; set; }
        [Browsable(false)]
        public string iBidOutColor1Serialize
        {
            get { return Serialize.BrushToString(iBidOutColor1); }
            set { iBidOutColor1 = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Outline Enabled", GroupName = "Inventory Display", Description = "", Order = 130)]
        public bool ioutlineHistBars { get; set; }
        #endregion

        #region -- Data --
		[NinjaScriptProperty]
		[Display(Name = "Use TickReplay data?", Order = 5, GroupName = "Data", Description = "If you have TickReplay enabled, you can either use TickReplay data, or you can use the old UpTick/DownTick data")]
		public bool pUseTickReplayData {get;set;}

		[NinjaScriptProperty]
       // [TypeConverter(typeof(ProfileCalcMode))]
        [Display(Name = "Mode", Order = 10, GroupName = "Data", Description = "Anything other than Tick1 ??? gives both orderflow print and volume profile options...Second30, and all Minute ??? used on larger lookbacks and larger interval charts, (orderflow is not available, profile features only). ")]
        public ARC_PrintProfiler_DataBasis iPCalcM { get; set; }

		[NinjaScriptProperty]
        [Display(Name = "Limit Type", Order = 20, GroupName = "Data", Description = "The type of limiting measurement, either a number of minutes, a number of bars, or nolimit at all")]
        public ARC_PrintProfiler_DataLimitType DataLimitType { get; set; }

		[NinjaScriptProperty]
        [Display(Name = "Limit Qty", Order = 30, GroupName = "Data", Description = "Number of ticks, or minutes, or chart bars.  Reduce this number to help speed-up Print execution")]
        public double DataLimitQty { get; set; }

		[NinjaScriptProperty]
        [Display(Name = "Ignore last forex digit", Order = 40, GroupName = "Data", Description = "Round-off the rightmost digit in forex instruments")]
		public bool pRoundForexToWholePip { get; set; }

        #endregion

        #region -- Trapped Trader / Delta Divergence Signals --
        [Display(Name = "Trapped Trader Enabled", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 00)]
        public bool pShow_TTSignal { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trapped Trader High Low Range Filter", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 10)]
        public bool iHighLowRangeFilter { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1000)]
        [Display(Name = "Trapped Trader Declining Levels", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "the minimum number of declining levels on the price scale to qualify a signal.", Order = 20)]
        public int iMinimumDecliningLevels { get; set; }

        [Display(Name = "Delta Divergence Enabled", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 30)]
        public bool pShow_DDSignal { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1000)]
        [Display(Name = "Delta Divergence Bars Look Back", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "bars look back for higher high and lower low to qualify a signal.", Order = 40)]
        public int iLookBack { get; set; }

        [Display(Name = "Combined (TT/DD) Signal Enabled", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 50)]
        public bool pShow_CCSignal { get; set; }

        [Display(Name = "Volume Divergence Enabled", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 60)]
        public bool pShow_VDSignal { get; set; }

        [Range(0, 1000)]
        [Display(Name = "Arrows - Offset (Pixels)", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "Number of pixels distance arrows level.", Order = 80)]
        public int iArrowSeparation { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Arrows - Size", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "Arrow size, in pixels", Order = 85)]
        public int iArrowWidth { get; set; }

		[Range(0, 1000)]
        [Display(Name = "Diamond - Offset (Pixels)", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "Number of pixels distance arrows level.", Order = 90)]
        public int iDiamondSeparationVDS { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Diamond - Size", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "Diamond size, in pixels", Order = 100)]
        public int iDotWidthVDS { get; set; }

        [XmlIgnore]
        [Display(Name = "Signals - Long (Fill)", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 110)]
        public Brush iArrowUpColor { get; set; }
        [Browsable(false)]
        public string iArrowUpColorSerialize
        {
            get { return Serialize.BrushToString(iArrowUpColor); }
            set { iArrowUpColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Signals - Long (Outline)", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 120)]
        public Brush iArrowUpOColor { get; set; }
        [Browsable(false)]
        public string iArrowUpOColorSerialize
        {
            get { return Serialize.BrushToString(iArrowUpOColor); }
            set { iArrowUpOColor = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Signals - Opacity (%)", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "In percent, the opacity of the arrow fill.", Order = 130)]
        public int iArrowShade { get; set; }

        [XmlIgnore]
        [Display(Name = "Signals - Short (Fill)", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 140)]
        public Brush iArrowDnColor { get; set; }
        [Browsable(false)]
        public string iArrowDnColorSerialize
        {
            get { return Serialize.BrushToString(iArrowDnColor); }
            set { iArrowDnColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Signals - Short (Outline)", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 150)]
        public Brush iArrowDnOColor { get; set; }
        [Browsable(false)]
        public string iArrowDnOColorSerialize
        {
            get { return Serialize.BrushToString(iArrowDnOColor); }
            set { iArrowDnOColor = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Label Enabled", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 160)]
        public bool iLabelsEnabled { get; set; }

        [Display(Name = "Label Font", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "Choose the font style for the numbers displayed.", Order = 170)]
        public SimpleFont iFontText2 { get; set; }

        [Display(Name = "Label Trapped Trader Long", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 180)]
        public string iSignalNameTTL { get; set; }

        [Display(Name = "Label Trapped Trader Short", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 190)]
        public string iSignalNameTTS { get; set; }

        [Display(Name = "Label Delta Divergence Long", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 200)]
        public string iSignalNameDDL { get; set; }

        [Display(Name = "Label Delta Divergence Short", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 210)]
        public string iSignalNameDDS { get; set; }

        [Display(Name = "Label Combined Signal Long", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 220)]
        public string iSignalNameCSL { get; set; }

        [Display(Name = "Label Combined Signal Short", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 230)]
        public string iSignalNameCSS { get; set; }

        [Display(Name = "Label Volume Divergence Long", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 240)]
        public string iSignalNameVDL { get; set; }

        [Display(Name = "Label Volume Divergence Short", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Description = "", Order = 250)]
        public string iSignalNameVDS { get; set; }

		//		pSignalTiming = ARC_PrintProfiler_SignalTimingTypes.OnClose;
		[Description("When do you want the audible alert to play?  'OnTick' may have pre-signals which can be reversed and become non-signals")]
        [Display(Name = "Sound Timing", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Order = 259)]
		public ARC_PrintProfiler_SignalTimingTypes pSignalTiming
		{ get; set; }
		
		[Description("WAV file to play for TrappedTrader signals, leave blank to turn off the alert")]
        [Display(Name = "TrappedT Buy Sound", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Order = 260)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string TT_BuyAlertWav
		{ get; set; }

		[Description("WAV file to play for TrappedTrader signals, leave blank to turn off the alert")]
        [Display(Name = "TrappedT Sell Sound", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Order = 270)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string TT_SellAlertWav
		{ get; set; }

		[Description("WAV file to play for Delta Divergence signals, leave blank to turn off the alert")]
        [Display(Name = "DeltaD Buy Sound", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Order = 280)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string DD_BuyAlertWav
		{ get; set; }

		[Description("WAV file to play for Delta Divergence signals, leave blank to turn off the alert")]
        [Display(Name = "DeltaD Sell Sound", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Order = 290)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string DD_SellAlertWav
		{ get; set; }

        [Description("WAV file to play for Volume Divergence signals, leave blank to turn off the alert")]
        [Display(Name = "VolD Buy Sound", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Order = 300)]
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
        public string VD_BuyAlertWav
        { get; set; }

        [Description("WAV file to play for Volume Divergence signals, leave blank to turn off the alert")]
        [Display(Name = "VolD Sell Sound", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Order = 310)]
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
        public string VD_SellAlertWav
        { get; set; }

        [Description("WAV file to play for Combined signals, leave blank to turn off the alert")]
        [Display(Name = "CombinedSignal Buy Sound", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Order = 320)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string CS_BuyAlertWav
		{ get; set; }

		[Description("WAV file to play for Combined signals, leave blank to turn off the alert")]
        [Display(Name = "CombinedSignal Sell Sound", GroupName = "Trapped Trader / Delta Divergence / Volume Divergence Signals", Order = 330)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string CS_SellAlertWav
		{ get; set; }

		#endregion

		#region -- Bid/Ask Volume Visuals --
		[Range(0,int.MaxValue)]
        [Display(Name = "Volume Threshold", Order = 10, GroupName = "Bid/Ask Volume Visuals", Description = "Minimum volume.  Volumes below this level will be affected by these visual settings in this category")]
		public int pSmallVolumeThreshold {get;set;}

		[Range(0,100)]
        [Display(Name = "Opacity", Order = 20, GroupName = "Bid/Ask Volume Visuals", Description = "Small bid/ask volumes will be output at this opacity level")]
		public int pSmallVolumeTextOpacity {get;set;}

		[Range(1,double.MaxValue)]
        [Display(Name = "Volume Divisor", Order = 30, GroupName = "Bid/Ask Volume Visuals", Description = "For visual appearance only - will shorten the bid/ask volume text")]
		public double pVisualVolumeDivisor {get;set;}
		#endregion

		#region -- Unfinished Business Signals --
        [Display(Name = "UnfinishedBiz Enabled", Order = 10, GroupName = "UnfinishedBiz Signals", Description = "When both the bid and ask volumes at the top or bottom of the wick are non-zero volumes")]
		public bool pShow_UnfinishedBizSignal {get;set;}

//        [XmlIgnore]
//        [Display(Name = "Dot Color", Order = 20, GroupName = "UnfinishedBiz Signals", Description = "Dot prints at the high or low of a candle, indicating the bid and ask volumes are both non-zero values")]
//        public Brush pUnfinishedBizFillColor { get; set; }
//					[Browsable(false)]
//					public string pUnfinishedBizFillColorSerialize
//					{get { return Serialize.BrushToString(pUnfinishedBizFillColor); }set { pUnfinishedBizFillColor = Serialize.StringToBrush(value); }}

//		[Range(0,20)]
//        [Display(Name = "Line width", Order = 30, GroupName = "UnfinishedBiz Signals", Description = "Thickness of line, set to '0' to hide the line")]
//		public int pUnfinishedBizLineWidth
//		{get;set;}
        [Display(Name = "Line Style", Order = 40, GroupName = "UnfinishedBiz Signals", Description = "")]
		public Stroke pUnfinishedBizStrokeStyle
		{get;set;}

		#endregion

		#region -- BigMoney Signals --
        [Display(Name = "BigMoney Enabled", GroupName = "BigMoney Signals", Description = "Show when current bar bid or ask volume exceeds the average of the recent bids/asks", Order = 10)]
		public bool pShow_BigMoneySignal {get;set;}

		[Display(Name = "BigMoney multiplier", GroupName = "BigMoney Signals", Description = "Multipler of average, use to filter out low-volume BigMoney signals", Order = 20)]
		public double pBigMoneyMultiplier {get;set;}

//		[Range(-1,double.MaxValue)]
//		[Display(Name = "Max size for Signal", GroupName = "BigMoney Signals", Description = "Maximum volume size, all bid/ask volume-at-price amounts that exceed this value will be ignored, set to '-1' to ignore this max value", Order = 25)]
//		public double pMaxSizeForBigMoneySignal {get;set;}
		private double pMaxSizeForBigMoneySignal;

        [Display(Name = "BigMoney bars lookback", GroupName = "BigMoney Signals", Description = "Number of bars of history prior to the current bar being used in the calculation of the BigMoney average", Order = 30)]
		public int pBigMoneyLookbackBars {get;set;}

        [XmlIgnore]
        [Display(Name = "Ask Rectangle Fill Color", GroupName = "BigMoney Signals", Description = "", Order = 40)]
        public Brush pBigMoneyAskRectangleFillColor { get; set; }
					[Browsable(false)]
					public string pBigMoneyAskRectangleFillColorSerialize
					{
						get { return Serialize.BrushToString(pBigMoneyAskRectangleFillColor); }
						set { pBigMoneyAskRectangleFillColor = Serialize.StringToBrush(value); }
					}

        [XmlIgnore]
        [Display(Name = "Bid Rectangle Fill Color", GroupName = "BigMoney Signals", Description = "", Order = 50)]
        public Brush pBigMoneyBidRectangleFillColor { get; set; }
					[Browsable(false)]
					public string pBigMoneyBidRectangleFillColorSerialize
					{
						get { return Serialize.BrushToString(pBigMoneyBidRectangleFillColor); }
						set { pBigMoneyBidRectangleFillColor = Serialize.StringToBrush(value); }
					}

		#endregion

		#endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_PrintProfiler[] cacheARC_PrintProfiler;
		public ARC.ARC_PrintProfiler ARC_PrintProfiler(double iImbalanceOffset, double iVolumeQualifier, string resetTime, int iResetMinutes, int iVAPercent, bool iVA1Enabled, int iVA1Period, string iVA1Mode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, bool iInventoryEnabled, bool iDisplayTotal, int imaxRows, bool pUseTickReplayData, ARC_PrintProfiler_DataBasis iPCalcM, ARC_PrintProfiler_DataLimitType dataLimitType, double dataLimitQty, bool pRoundForexToWholePip, bool iHighLowRangeFilter, int iMinimumDecliningLevels, int iLookBack)
		{
			return ARC_PrintProfiler(Input, iImbalanceOffset, iVolumeQualifier, resetTime, iResetMinutes, iVAPercent, iVA1Enabled, iVA1Period, iVA1Mode, iVA2Enabled, iVA2Period, iVA2Mode, iInventoryEnabled, iDisplayTotal, imaxRows, pUseTickReplayData, iPCalcM, dataLimitType, dataLimitQty, pRoundForexToWholePip, iHighLowRangeFilter, iMinimumDecliningLevels, iLookBack);
		}

		public ARC.ARC_PrintProfiler ARC_PrintProfiler(ISeries<double> input, double iImbalanceOffset, double iVolumeQualifier, string resetTime, int iResetMinutes, int iVAPercent, bool iVA1Enabled, int iVA1Period, string iVA1Mode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, bool iInventoryEnabled, bool iDisplayTotal, int imaxRows, bool pUseTickReplayData, ARC_PrintProfiler_DataBasis iPCalcM, ARC_PrintProfiler_DataLimitType dataLimitType, double dataLimitQty, bool pRoundForexToWholePip, bool iHighLowRangeFilter, int iMinimumDecliningLevels, int iLookBack)
		{
			if (cacheARC_PrintProfiler != null)
				for (int idx = 0; idx < cacheARC_PrintProfiler.Length; idx++)
					if (cacheARC_PrintProfiler[idx] != null && cacheARC_PrintProfiler[idx].iImbalanceOffset == iImbalanceOffset && cacheARC_PrintProfiler[idx].iVolumeQualifier == iVolumeQualifier && cacheARC_PrintProfiler[idx].ResetTime == resetTime && cacheARC_PrintProfiler[idx].iResetMinutes == iResetMinutes && cacheARC_PrintProfiler[idx].iVAPercent == iVAPercent && cacheARC_PrintProfiler[idx].iVA1Enabled == iVA1Enabled && cacheARC_PrintProfiler[idx].iVA1Period == iVA1Period && cacheARC_PrintProfiler[idx].iVA1Mode == iVA1Mode && cacheARC_PrintProfiler[idx].iVA2Enabled == iVA2Enabled && cacheARC_PrintProfiler[idx].iVA2Period == iVA2Period && cacheARC_PrintProfiler[idx].iVA2Mode == iVA2Mode && cacheARC_PrintProfiler[idx].iInventoryEnabled == iInventoryEnabled && cacheARC_PrintProfiler[idx].iDisplayTotal == iDisplayTotal && cacheARC_PrintProfiler[idx].imaxRows == imaxRows && cacheARC_PrintProfiler[idx].pUseTickReplayData == pUseTickReplayData && cacheARC_PrintProfiler[idx].iPCalcM == iPCalcM && cacheARC_PrintProfiler[idx].DataLimitType == dataLimitType && cacheARC_PrintProfiler[idx].DataLimitQty == dataLimitQty && cacheARC_PrintProfiler[idx].pRoundForexToWholePip == pRoundForexToWholePip && cacheARC_PrintProfiler[idx].iHighLowRangeFilter == iHighLowRangeFilter && cacheARC_PrintProfiler[idx].iMinimumDecliningLevels == iMinimumDecliningLevels && cacheARC_PrintProfiler[idx].iLookBack == iLookBack && cacheARC_PrintProfiler[idx].EqualsInput(input))
						return cacheARC_PrintProfiler[idx];
			return CacheIndicator<ARC.ARC_PrintProfiler>(new ARC.ARC_PrintProfiler(){ iImbalanceOffset = iImbalanceOffset, iVolumeQualifier = iVolumeQualifier, ResetTime = resetTime, iResetMinutes = iResetMinutes, iVAPercent = iVAPercent, iVA1Enabled = iVA1Enabled, iVA1Period = iVA1Period, iVA1Mode = iVA1Mode, iVA2Enabled = iVA2Enabled, iVA2Period = iVA2Period, iVA2Mode = iVA2Mode, iInventoryEnabled = iInventoryEnabled, iDisplayTotal = iDisplayTotal, imaxRows = imaxRows, pUseTickReplayData = pUseTickReplayData, iPCalcM = iPCalcM, DataLimitType = dataLimitType, DataLimitQty = dataLimitQty, pRoundForexToWholePip = pRoundForexToWholePip, iHighLowRangeFilter = iHighLowRangeFilter, iMinimumDecliningLevels = iMinimumDecliningLevels, iLookBack = iLookBack }, input, ref cacheARC_PrintProfiler);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_PrintProfiler ARC_PrintProfiler(double iImbalanceOffset, double iVolumeQualifier, string resetTime, int iResetMinutes, int iVAPercent, bool iVA1Enabled, int iVA1Period, string iVA1Mode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, bool iInventoryEnabled, bool iDisplayTotal, int imaxRows, bool pUseTickReplayData, ARC_PrintProfiler_DataBasis iPCalcM, ARC_PrintProfiler_DataLimitType dataLimitType, double dataLimitQty, bool pRoundForexToWholePip, bool iHighLowRangeFilter, int iMinimumDecliningLevels, int iLookBack)
		{
			return indicator.ARC_PrintProfiler(Input, iImbalanceOffset, iVolumeQualifier, resetTime, iResetMinutes, iVAPercent, iVA1Enabled, iVA1Period, iVA1Mode, iVA2Enabled, iVA2Period, iVA2Mode, iInventoryEnabled, iDisplayTotal, imaxRows, pUseTickReplayData, iPCalcM, dataLimitType, dataLimitQty, pRoundForexToWholePip, iHighLowRangeFilter, iMinimumDecliningLevels, iLookBack);
		}

		public Indicators.ARC.ARC_PrintProfiler ARC_PrintProfiler(ISeries<double> input , double iImbalanceOffset, double iVolumeQualifier, string resetTime, int iResetMinutes, int iVAPercent, bool iVA1Enabled, int iVA1Period, string iVA1Mode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, bool iInventoryEnabled, bool iDisplayTotal, int imaxRows, bool pUseTickReplayData, ARC_PrintProfiler_DataBasis iPCalcM, ARC_PrintProfiler_DataLimitType dataLimitType, double dataLimitQty, bool pRoundForexToWholePip, bool iHighLowRangeFilter, int iMinimumDecliningLevels, int iLookBack)
		{
			return indicator.ARC_PrintProfiler(input, iImbalanceOffset, iVolumeQualifier, resetTime, iResetMinutes, iVAPercent, iVA1Enabled, iVA1Period, iVA1Mode, iVA2Enabled, iVA2Period, iVA2Mode, iInventoryEnabled, iDisplayTotal, imaxRows, pUseTickReplayData, iPCalcM, dataLimitType, dataLimitQty, pRoundForexToWholePip, iHighLowRangeFilter, iMinimumDecliningLevels, iLookBack);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_PrintProfiler ARC_PrintProfiler(double iImbalanceOffset, double iVolumeQualifier, string resetTime, int iResetMinutes, int iVAPercent, bool iVA1Enabled, int iVA1Period, string iVA1Mode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, bool iInventoryEnabled, bool iDisplayTotal, int imaxRows, bool pUseTickReplayData, ARC_PrintProfiler_DataBasis iPCalcM, ARC_PrintProfiler_DataLimitType dataLimitType, double dataLimitQty, bool pRoundForexToWholePip, bool iHighLowRangeFilter, int iMinimumDecliningLevels, int iLookBack)
		{
			return indicator.ARC_PrintProfiler(Input, iImbalanceOffset, iVolumeQualifier, resetTime, iResetMinutes, iVAPercent, iVA1Enabled, iVA1Period, iVA1Mode, iVA2Enabled, iVA2Period, iVA2Mode, iInventoryEnabled, iDisplayTotal, imaxRows, pUseTickReplayData, iPCalcM, dataLimitType, dataLimitQty, pRoundForexToWholePip, iHighLowRangeFilter, iMinimumDecliningLevels, iLookBack);
		}

		public Indicators.ARC.ARC_PrintProfiler ARC_PrintProfiler(ISeries<double> input , double iImbalanceOffset, double iVolumeQualifier, string resetTime, int iResetMinutes, int iVAPercent, bool iVA1Enabled, int iVA1Period, string iVA1Mode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, bool iInventoryEnabled, bool iDisplayTotal, int imaxRows, bool pUseTickReplayData, ARC_PrintProfiler_DataBasis iPCalcM, ARC_PrintProfiler_DataLimitType dataLimitType, double dataLimitQty, bool pRoundForexToWholePip, bool iHighLowRangeFilter, int iMinimumDecliningLevels, int iLookBack)
		{
			return indicator.ARC_PrintProfiler(input, iImbalanceOffset, iVolumeQualifier, resetTime, iResetMinutes, iVAPercent, iVA1Enabled, iVA1Period, iVA1Mode, iVA2Enabled, iVA2Period, iVA2Mode, iInventoryEnabled, iDisplayTotal, imaxRows, pUseTickReplayData, iPCalcM, dataLimitType, dataLimitQty, pRoundForexToWholePip, iHighLowRangeFilter, iMinimumDecliningLevels, iLookBack);
		}
	}
}

#endregion
