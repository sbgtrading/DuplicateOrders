using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui;
using SharpDX.Direct2D1;
using System.Collections.Generic;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using System.Windows.Media;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Windows;
using System.ComponentModel;
using System.Xml.Serialization;
using System;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public class ARC_ATTraderAlgo_ARC_ATTrader : ARC_ATTraderAlgo_ARCIndicatorBase
	{
		internal class TrendLine
		{
			public ARC_ATTraderAlgo_ZigZagPoint P0 { get; set; }
			public ARC_ATTraderAlgo_ZigZagPoint P1 { get; set; }
			public int BarCreated { get; set; }
			public ARC_ATTraderAlgo_ZigZagPoint End { get; set; }
			public bool Broken { get; set; }
			public double MaxDistance { get; set; }

			public double Slope => P1 == null ? double.NaN : (P1.Price - P0.Price) / (P1.Bar - P0.Bar);

			public int Dir
			{
				get
				{
					if (P1 == null)
						return 0;

					return Slope.ApproxCompare(0);
				}
			}

			public int Side => P0.Side;
		}

		[XmlIgnore, Browsable(false)]
		internal List<TrendLine> UnbrokenTrends
		{
			get
			{
				Update();
				return unbrokenLines.ToList();
			}
		}
		
		[XmlIgnore, Browsable(false)]
		internal List<TrendLine> JustBrokenTrends
		{
			get
			{
				Update();
				return trendLines.Values
					.SelectMany(v => v)
					.Where(v => v.Broken && v.End.Bar == CurrentBar)
					.OrderBy(v => v.P1.Bar)
					.ToList();
			}
		}

		public override string ProductVersion => "v1.0.0 (9/20/2024)";
		public override bool ColicensedOnly => true;

		// Zone termination size = the distance we have to cross the line by to actually stop the line.
		// Break size = the distance we need to cross the line by to print a line break.
		private readonly Dictionary<int, List<TrendLine>> trendLines = new Dictionary<int, List<TrendLine>>
		{
			{ -1, new List<TrendLine>() },
			{ 1, new List<TrendLine>() }
		};
		internal ARC_ATTraderAlgo_ARC_MWPatternFinderZigZag anchorTracker;
		private ATR bufferSizeAtr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && !this.ARC_ATTraderAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				Name = "AT Trader";
				IsOverlay = true;
				DisplayInDataBox = false;

				BreakLogic = ARC_ATTraderAlgo_BreakLogic.Close;
				Strength = 3;
				BufferZoneSizeType = ARC_ATTraderAlgo_AtrOrTicks.ATR;
				BufferZoneATRPeriod = 14;
				BufferZoneSize = 10;
				trendStrokes.Clear();
				bufferZoneOpacity.Clear();

				AddPlot(new Stroke(Brushes.Orange, 2), PlotStyle.Dot, "Intercepts");
			}
			else if (State == State.DataLoaded)
			{
				bufferSizeAtr = ATR(BufferZoneATRPeriod);
				anchorTracker = ARC_ATTraderAlgo_ARC_MWPatternFinderZigZag(Strength, true);
			}
		}

		internal double GetBreakPrice(TrendLine tl, int bar)
		{
			return GetIntercept(tl, bar) - tl.Dir * GetBufferZoneSize(bar);
		}
		
		internal double GetIntercept(TrendLine tl, int bar)
		{
			return tl.P1.Price + tl.Slope * (bar - tl.P1.Bar);
		}

		public double GetBufferZoneSize(int bar)
		{
			return BufferZoneSize * (BufferZoneSizeType == ARC_ATTraderAlgo_AtrOrTicks.Ticks ? TickSize : bufferSizeAtr.Value.GetValueAt(bar));
		}

		private void RefreshMaxDist(TrendLine tl)
		{
			tl.MaxDistance = double.MinValue;
			for (var bar = tl.P1.Bar; bar <= CurrentBar; bar++)
			{
				tl.MaxDistance = Math.Max(((tl.Side == 1 ? Low : High).GetValueAt(bar) - tl.P1.Price) * -tl.Side, tl.MaxDistance);
			}
		}

		private readonly List<TrendLine> unbrokenLines = new List<TrendLine>();
		private readonly List<TrendLine> brokenLines = new List<TrendLine>();
		private int lastAnchorCounts = 0;
		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_ATTraderAlgo_IsLicensed())
				return;

			bufferSizeAtr.Update();
			anchorTracker.Update();

			// Check for trend line breaks
			foreach (var tl in unbrokenLines.ToList())
			{
				var twoSameSidePointsAfterCreation = anchorTracker.SwingPoints
					.SkipWhile(p => p.Bar > tl.P1.Bar)
					.Where(p => p.Side == tl.Side)
					.Take(2)
					.Count() == 2;

				if (!twoSameSidePointsAfterCreation)
				{
					unbrokenLines.Remove(tl);
					trendLines[tl.Side].Remove(tl);
					continue;
				}

				// Make sure break price was hit
				var breakPrice = GetBreakPrice(tl, CurrentBar);
				double comparisonPrice;
				if (BreakLogic == ARC_ATTraderAlgo_BreakLogic.Close)
				{
					comparisonPrice = Close[0];
				}
				else
				{
					// Full bar means even worst price is past the zone, everything else is best price
					comparisonPrice = new [] { Open, High, Low, Close }
						.Select(s => s[0])
						.OrderBy(s => s * tl.Side * (BreakLogic == ARC_ATTraderAlgo_BreakLogic.FullBar ? 1 : -1))
						.First();
				}

				RefreshMaxDist(tl);
				if (comparisonPrice.ApproxCompare(breakPrice) != tl.Side)		
					continue;

				var wasOnOtherSide = false;
				for (var i = tl.BarCreated; i < CurrentBar - 1; i++)
				{
					if (Close.GetValueAt(i).ApproxCompare(GetIntercept(tl, i) + tl.Side * GetBufferZoneSize(i)) == tl.Side)
						continue;

					wasOnOtherSide = true;
					break;
				}

				if (!wasOnOtherSide)
					continue;

				// Make sure line has intercepted
				var intercept = GetIntercept(tl, CurrentBar);

				tl.End = new ARC_ATTraderAlgo_ZigZagPoint(tl.Side, CurrentBar, intercept);
				tl.Broken = true;
				Value[0] = breakPrice;
				unbrokenLines.Remove(tl);
			}

			var newAnchorPoints = anchorTracker.SwingPoints.Count > lastAnchorCounts;
			lastAnchorCounts = anchorTracker.SwingPoints.Count;

			if (anchorTracker.SwingPoints.Count < 2)
				return;
			
			var mostRecentAnchorPoints = anchorTracker.SwingPoints
				.Where(p => p.Bar == anchorTracker.SwingPoints.Last().Bar)
				.ToArray();

			for (var i = 0; i < mostRecentAnchorPoints.Length; i++)
			{
				var lastSide = mostRecentAnchorPoints[i].Side;
				if (lastSide == 0)
					continue;
			
				// Move anchor forward if last anchor still valid
				if (!newAnchorPoints) 
				{
					var point = trendLines[lastSide].LastOrDefault()?.P1;
					if (point?.Bar != CurrentBar - 1)
						return;

					point.Bar = mostRecentAnchorPoints[i].Bar;
					point.Price = mostRecentAnchorPoints[i].Price;
					return;
				}
	
				// Ensure more then 3 points from lookback point available
				var pointsBack = mostRecentAnchorPoints.Length - (i + 1);
				if (lastAnchorCounts - pointsBack < 3)
					continue;

				// Build trend line
				var swingPoints = anchorTracker.SwingPoints
					.Skip(anchorTracker.SwingPoints.Count - 4 - pointsBack)
					.Select(p => new ARC_ATTraderAlgo_ZigZagPoint(p.Side, p.Bar, p.Price))
					.ToArray();
				var newTl = new TrendLine
				{
					P0 = swingPoints[0],
					P1 = swingPoints[2],
					BarCreated = CurrentBar
				};

				if (newTl.Dir == 0)
					continue;

				// If it points in the right direction, add it
				if (newTl.Dir != -newTl.Side)
					continue;

				if (newTl.Side != -lastSide)
					continue;

				if (!AllowOlderLessSteepLines)
				{
					var existingSameDirLine = unbrokenLines.FirstOrDefault(l => l.Dir == newTl.Dir);
					if (existingSameDirLine != null)
					{
						trendLines[lastSide].Remove(existingSameDirLine);
						unbrokenLines.Remove(existingSameDirLine);
					}
				}

				trendLines[lastSide].Add(newTl);
				unbrokenLines.Add(newTl);
				RefreshMaxDist(newTl);
			}
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			if (!this.ARC_ATTraderAlgo_IsLicensed())
				return;

			if (!IsVisible)
				return;

			var priorAaValue = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
			for (var i = -1; i <= 1; i += 2)
			{
				foreach (var tl in trendLines[i])
				{
					if (tl.P0.Bar > ChartBars.ToIndex)
						continue;

					var pts = new[] { tl.P0, tl.P1, tl.End }
						.Where(pt => pt != null)
						.Select(p => new Point(chartControl.GetXByBarIndex(ChartBars, p.Bar), chartScale.GetYByValue(p.Price)))
						.ToList();

					var endBar = tl.End?.Bar ?? ChartBars.ToIndex;
					if (pts.Count < 3)
						pts.Add(pts[0].ARC_ATTraderAlgo_ExtendLine(pts[1], 1000));

					var stroke = trendStrokes[-i];
					using var dxBrush = stroke.Brush.ToDxBrush(RenderTarget);
					if (ChartBars.FromIndex <= tl.P1.Bar && ChartBars.ToIndex >= tl.P0.Bar)
						RenderTarget.DrawLine(pts[0].ToVector2(), pts[1].ToVector2(), dxBrush, stroke.Width, stroke.StrokeStyle);

					RenderTarget.DrawLine(pts[1].ToVector2(), pts[2].ToVector2(), dxBrush, stroke.Width, stroke.StrokeStyle);

					var bufferZonePoints = new List<Point>();
					if (endBar >= tl.BarCreated)
					{
						for (var bufferSide = -1; bufferSide <= 1; bufferSide += 2)
						{
							var bars = Enumerable.Range(0, endBar - tl.BarCreated + 1).Select(i => i + tl.BarCreated);
							if (bufferSide == 1)
								bars = bars.Reverse();

							foreach (var bar in bars)
							{
								var yVal = chartScale.GetYByValue(GetIntercept(tl, bar) + bufferSide * GetBufferZoneSize(bar));
								var xVal = chartControl.GetXByBarIndex(ChartBars, bar);
								bufferZonePoints.Add(new Point(xVal, yVal));
							}
						}
					}
					
					using var brush = trendStrokes[-i].Brush.ToDxBrush(RenderTarget, bufferZoneOpacity[i]);
					RenderTarget.ARC_ATTraderAlgo_DrawPolygon(brush, brush, bufferZonePoints.ToArray());
				}
			}

			RenderTarget.AntialiasMode = priorAaValue;
		}

		private const string ParameterGroupName = "Parameters";

		[NinjaScriptProperty]
		[Display(Name = "Buffer Zone Break Logic", GroupName = ParameterGroupName, Order = 0)]
		public ARC_ATTraderAlgo_BreakLogic BreakLogic { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Zig Zag Strength", GroupName = ParameterGroupName, Order = 1)]
		public int Strength { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Buffer Zone Size Type", GroupName = ParameterGroupName, Order = 2)]
		public ARC_ATTraderAlgo_AtrOrTicks BufferZoneSizeType { get; set; }
		
		[NinjaScriptProperty]
		[ARC_ATTraderAlgo_HideUnless(nameof(BufferZoneSizeType), ARC_ATTraderAlgo_PropComparisonType.EQ, ARC_ATTraderAlgo_AtrOrTicks.ATR)]
		[Display(Name = "Buffer Zone ATR Period", GroupName = ParameterGroupName, Order = 3)]
		public int BufferZoneATRPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(0.001, int.MaxValue)]
		[Display(Name = "Buffer Zone Size", GroupName = ParameterGroupName, Order = 4)]
		public double BufferZoneSize { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Allow Older Less Steep Lines", GroupName = ParameterGroupName, Order = 5)]
		public bool AllowOlderLessSteepLines { get; set; }

		internal readonly ARC_ATTraderAlgo_DefaultingDictionary<int, Stroke> trendStrokes = new ARC_ATTraderAlgo_DefaultingDictionary<int, Stroke>(dir => new Stroke(dir == 1 ? Brushes.Red : Brushes.Green, 3));
		internal readonly ARC_ATTraderAlgo_DefaultingDictionary<int, float> bufferZoneOpacity = new ARC_ATTraderAlgo_DefaultingDictionary<int, float>(_ => 0.5f);

		[Display(Name = "Bullish Stroke", GroupName = "Visuals", Order = 0)]
		public Stroke BullishTrendStroke { get => trendStrokes[1]; set => trendStrokes[1] = value; }
		
		[Display(Name = "Bearish Stroke", GroupName = "Visuals", Order = 1)]
		public Stroke BearishTrendStroke { get => trendStrokes[-1]; set => trendStrokes[-1] = value; }
		
		[Display(Name = "Bullish Buffer Zone Opacity", GroupName = "Visuals", Order = 2)]
		public float BullishBufferZoneOpacity { get => bufferZoneOpacity[1]; set => bufferZoneOpacity[1] = value; }
		
		[Display(Name = "Bearish Buffer Zone Opacity", GroupName = "Visuals", Order = 3)]
		public float BearishBufferZoneOpacity { get => bufferZoneOpacity[-1]; set => bufferZoneOpacity[-1] = value; }
	}
}

public enum ARC_ATTraderAlgo_BreakLogic
{
	Intrabar,
	Close,
	FullBar
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_ATTraderAlgo_ARC_ATTrader[] cacheARC_ATTraderAlgo_ARC_ATTrader;
		public ARC.ARC_ATTraderAlgo_ARC_ATTrader ARC_ATTraderAlgo_ARC_ATTrader(ARC_ATTraderAlgo_BreakLogic breakLogic, int strength, ARC_ATTraderAlgo_AtrOrTicks bufferZoneSizeType, int bufferZoneATRPeriod, double bufferZoneSize, bool allowOlderLessSteepLines)
		{
			return ARC_ATTraderAlgo_ARC_ATTrader(Input, breakLogic, strength, bufferZoneSizeType, bufferZoneATRPeriod, bufferZoneSize, allowOlderLessSteepLines);
		}

		public ARC.ARC_ATTraderAlgo_ARC_ATTrader ARC_ATTraderAlgo_ARC_ATTrader(ISeries<double> input, ARC_ATTraderAlgo_BreakLogic breakLogic, int strength, ARC_ATTraderAlgo_AtrOrTicks bufferZoneSizeType, int bufferZoneATRPeriod, double bufferZoneSize, bool allowOlderLessSteepLines)
		{
			if (cacheARC_ATTraderAlgo_ARC_ATTrader != null)
				for (int idx = 0; idx < cacheARC_ATTraderAlgo_ARC_ATTrader.Length; idx++)
					if (cacheARC_ATTraderAlgo_ARC_ATTrader[idx] != null && cacheARC_ATTraderAlgo_ARC_ATTrader[idx].BreakLogic == breakLogic && cacheARC_ATTraderAlgo_ARC_ATTrader[idx].Strength == strength && cacheARC_ATTraderAlgo_ARC_ATTrader[idx].BufferZoneSizeType == bufferZoneSizeType && cacheARC_ATTraderAlgo_ARC_ATTrader[idx].BufferZoneATRPeriod == bufferZoneATRPeriod && cacheARC_ATTraderAlgo_ARC_ATTrader[idx].BufferZoneSize == bufferZoneSize && cacheARC_ATTraderAlgo_ARC_ATTrader[idx].AllowOlderLessSteepLines == allowOlderLessSteepLines && cacheARC_ATTraderAlgo_ARC_ATTrader[idx].EqualsInput(input))
						return cacheARC_ATTraderAlgo_ARC_ATTrader[idx];
			return CacheIndicator<ARC.ARC_ATTraderAlgo_ARC_ATTrader>(new ARC.ARC_ATTraderAlgo_ARC_ATTrader(){ BreakLogic = breakLogic, Strength = strength, BufferZoneSizeType = bufferZoneSizeType, BufferZoneATRPeriod = bufferZoneATRPeriod, BufferZoneSize = bufferZoneSize, AllowOlderLessSteepLines = allowOlderLessSteepLines }, input, ref cacheARC_ATTraderAlgo_ARC_ATTrader);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_ATTraderAlgo_ARC_ATTrader ARC_ATTraderAlgo_ARC_ATTrader(ARC_ATTraderAlgo_BreakLogic breakLogic, int strength, ARC_ATTraderAlgo_AtrOrTicks bufferZoneSizeType, int bufferZoneATRPeriod, double bufferZoneSize, bool allowOlderLessSteepLines)
		{
			return indicator.ARC_ATTraderAlgo_ARC_ATTrader(Input, breakLogic, strength, bufferZoneSizeType, bufferZoneATRPeriod, bufferZoneSize, allowOlderLessSteepLines);
		}

		public Indicators.ARC.ARC_ATTraderAlgo_ARC_ATTrader ARC_ATTraderAlgo_ARC_ATTrader(ISeries<double> input , ARC_ATTraderAlgo_BreakLogic breakLogic, int strength, ARC_ATTraderAlgo_AtrOrTicks bufferZoneSizeType, int bufferZoneATRPeriod, double bufferZoneSize, bool allowOlderLessSteepLines)
		{
			return indicator.ARC_ATTraderAlgo_ARC_ATTrader(input, breakLogic, strength, bufferZoneSizeType, bufferZoneATRPeriod, bufferZoneSize, allowOlderLessSteepLines);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_ATTraderAlgo_ARC_ATTrader ARC_ATTraderAlgo_ARC_ATTrader(ARC_ATTraderAlgo_BreakLogic breakLogic, int strength, ARC_ATTraderAlgo_AtrOrTicks bufferZoneSizeType, int bufferZoneATRPeriod, double bufferZoneSize, bool allowOlderLessSteepLines)
		{
			return indicator.ARC_ATTraderAlgo_ARC_ATTrader(Input, breakLogic, strength, bufferZoneSizeType, bufferZoneATRPeriod, bufferZoneSize, allowOlderLessSteepLines);
		}

		public Indicators.ARC.ARC_ATTraderAlgo_ARC_ATTrader ARC_ATTraderAlgo_ARC_ATTrader(ISeries<double> input , ARC_ATTraderAlgo_BreakLogic breakLogic, int strength, ARC_ATTraderAlgo_AtrOrTicks bufferZoneSizeType, int bufferZoneATRPeriod, double bufferZoneSize, bool allowOlderLessSteepLines)
		{
			return indicator.ARC_ATTraderAlgo_ARC_ATTrader(input, breakLogic, strength, bufferZoneSizeType, bufferZoneATRPeriod, bufferZoneSize, allowOlderLessSteepLines);
		}
	}
}

#endregion
