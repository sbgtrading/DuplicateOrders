#define DoLicense
#define MODERATORS
#define NEW_CODE_NOV2018 //code added between Oct 22 and Nov 14 2018

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Diagnostics;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Globalization;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public class ARC_TPO_Distributions : Indicator
	{
		private const string VERSION = "10.18.2023";
		[Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
		public string indicatorVersion { get { return VERSION; } }

		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId       = string.Empty;
		private string MachineId    = string.Empty;
		private bool IsDebug = false;
		string    ModuleName = "TPOCTV";
		
		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "3556", "4690"};
		bool IsBen = false;
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion


		#region Load pulldown parameters
		internal class LoadRayTemplates : StringConverter
		{
			#region LoadRayTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Ray"};
				HLtemplates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(HLtemplates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
		internal class LoadRectTemplates : StringConverter
		{
			#region LoadRectTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Rectangle"};
				HLtemplates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(HLtemplates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";
//					System.IO.DirectoryInfo dirCustom = new System.IO.DirectoryInfo(folder);
//					System.IO.FileInfo[] filCustom = dirCustom.GetFiles( search);

//					string[] list = new string[filCustom.Length+1];
//					list[0] = "none";
//					int i = 1;
//					foreach (System.IO.FileInfo fi in filCustom)
//					{
////					if(fi.Extension.ToLower().CompareTo(".exe")!=0 && fi.Extension.ToLower().CompareTo(".txt")!=0){
//						list[i] = fi.Name;
//						i++;
////					}
//					}
//					filteredlist = new string[i];
//					for(i = 0; i<filteredlist.Length; i++) filteredlist[i] = list[i];
					
//				}catch{filteredlist = new string[1]{"none"};}
//				return new StandardValuesCollection(filteredlist);

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("none");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }
		#endregion

#if NEW_CODE_NOV2018
		#region Global_VARaysData
		private class Global_VARaysData{
			public int StartABar;
			public DateTime DT;
			public double Price;
			public string TemplateName;
			public bool IsDrawn = false;
			public Global_VARaysData(int startABar, DateTime dt, double price, string templatename){
				StartABar = startABar; DT=dt; Price=price; TemplateName=templatename.Replace(" RayTemplate",string.Empty); IsDrawn=false;
			}
		}
		#endregion
		#region Global_RectsData
		private class Global_RectsData{
			public int      StartABar;
			public int      EndABar;
			public DateTime DTStart;
			public double   TopPrice;
			public DateTime DTEnd;
			public double   BottomPrice;
			public string   TemplateName;
			public char     SupportOrResistance;
			public bool     IsDrawn = false;
			public Global_RectsData(int startabar, DateTime dtStart, double topprice, DateTime dtEnd, double bottomprice, string templatename, char support_or_resistance){
				StartABar = startabar; DTStart=dtStart; DTEnd=dtEnd; TopPrice=topprice; BottomPrice=bottomprice; TemplateName=templatename; IsDrawn=false; this.SupportOrResistance=support_or_resistance;
			}
		}
		#endregion
		#region VisibleRectsData
		private class VisibleRectsData{
			public float TopScreenY = 0;
			public float BottomScreenY = 0;
			public int EndABar = 0;
			public double TopPrice = 0;
			public double BottomPrice = 0;
			public VisibleRectsData(float topY, float bottomY, int endABar, double topPrice, double bottomPrice){TopScreenY=topY; BottomScreenY=bottomY; EndABar = endABar; TopPrice=topPrice; BottomPrice=bottomPrice;}
		}
		private SortedDictionary<int, VisibleRectsData> Visible_ResArbs = new SortedDictionary<int, VisibleRectsData>();
		private SortedDictionary<int, VisibleRectsData> Visible_SupArbs = new SortedDictionary<int, VisibleRectsData>();
		#endregion
		private SortedDictionary<string,Global_VARaysData> GlobalVAHL_Rays = new SortedDictionary<string,Global_VARaysData>();
		private SortedDictionary<string,Global_RectsData>  GlobalArb_Rects = new SortedDictionary<string,Global_RectsData>();
#endif

		#region VARIABLES
		InstrumentIncrementSettings IncrementSettings = new InstrumentIncrementSettings ();
        ATR atr;
        string bonds = "ZB,ZN,ZT,ZF,UB";
        bool AreBonds = false;
        bool FirstRealTick = true;
        bool AllSplitMode = false;
        List<SessionInfo> Sessions = new List<SessionInfo>();
        double CurrentSessionOpen = 0;
        int originalZOrder;
        private DateTime sessionBegin;
        //Enums
        Dictionary<DateTime, int> mergeDates = new Dictionary<DateTime, int>();
        public enum ARC_ModeViewEnum{ProfileView,HybridView}
		public enum ARC_ATRModeEnum{Ticks,Points}
		
		
        List<string> tpo_letters_intraday = new List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
                            "p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P"};
        List<string> tpo_letters_day = new List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
                            "p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","1","2","3","4","5"
        ,"6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36",
            "37","38","39","40","41","42","43","44"};

        private	Dictionary<double,double>			volDictionary	=	new Dictionary<double,double>();
		private SessionIterator 					sessionIterator;

		private	List<TPO_Cluster>					TPO_Cluster_List;
		private	SortedDictionary<int,BarFootPrint>					FootPrint_List;

		private SortedDictionary<double,char> UntestedResPrices = new SortedDictionary<double,char>();
		private SortedDictionary<double,char> UntestedSupPrices = new SortedDictionary<double,char>();
		//private DateTime AlertTime = DateTime.MinValue;

		private	bool								first_run				=	true;
		
		private	int									TPO_Period;
		private int									TPO_Ticks_Increment;
		private	int									TPO_Font_Size;
		private	bool 								ProfileView				=	true;
		private	bool 								HybridView				=	false;
		private	bool 								HybridPrintView			=	false;
				int max=0;
		
				int test=0;
		
				int max_letters=0;
		
				bool								IsToolBarButtonAdded	=	false;		
		private	Chart								chartWindow;
		private System.Windows.Controls.Grid   		MenuGrid;
		private	System.Windows.Controls.ComboBox	ViewMode, ZonePopulationComboBox;
		private	System.Windows.Controls.ComboBox	SplitComboBox;
		private	System.Windows.Controls.ComboBox	ZonesComboBox;
		private	System.Windows.Controls.ComboBox	TargetStopModeComboBox;
		private System.Windows.Controls.Button		ShowFreshZones_Button;
		private System.Windows.Controls.Button		ShowBrokenZones_Button;
		private	System.Windows.Controls.CheckBox	TargetStopCheckBox;
		private	System.Windows.Controls.Button		AutoMergeButton;
        private System.Windows.Controls.Button      AutoSplitButton;
		private System.Windows.Controls.Button		SplitEnabledButton;
        private System.Windows.Controls.Button      AllSplitButton;
        private System.Windows.Controls.Button      ClearGlobals_Button;
		private System.Windows.Controls.Button		EnableGlobals_Button;
		private	System.Windows.Controls.TextBox		ZonesVisibleCountTextBox;
        private Thumb                               drag;
        private	bool								IsAutoSplit				=	false;
		private	bool								IsSplitAssist			=	false;
		private	bool								IsManualSplitMerge		=	true;
		private	bool								IsCDAutoSplit			=	false;
		private bool								ShowZonesClickedJustNow =   false;
		
		private	bool?								TargetStopUseVPOC		=	null;
		//private	int									ZonesVisibleCount		=	3;
		
		private	double								trade_volume=0;
		private	double								prev_vol=0;
		private	int									start_day=1000;
//		private	double								Day_Volume=0;
//		private double								Price_Day_Volume=0;
//		private	double								Day_TWAP=0;
		
		private	DateTime							tick_time;
		private	double								tick_volume;
//		private int									daily_bars;
//		private	bool								daily_period=false;
		private	float								vol_hist_opacity;
		
		private const int ID_Ask_Greater_Bid_50_Brush   = 1;
		private const int ID_Ask_Greater_Bid_1549_Brush = 2;
		private const int ID_Ask_Greater_Bid_014_Brush  = 3;
		private const int ID_Bid_Greater_Ask_50_Brush   = 4;
		private const int ID_Bid_Greater_Ask_1549_Brush = 5;
		private const int ID_Bid_Greater_Ask_014_Brush  = 6;
		private SharpDX.Direct2D1.Brush[] BrushesDXTable = new SharpDX.Direct2D1.Brush[7]{null,null,null,null,null,null,null};

		private	double								chartScaleMinMax;
		ChartScale									clickChartScale;
		private	bool								MethodsAdded=false;
		private	bool								DailyMode;
		private	int									day_count;
				int 								currentBar       = 0;
		private	int									prevCurrentBar   = -2;	
		private	double								NetImbalance     = 0;
		private	double								NetImbalanceShow = 0;
		
				bool								isFirstTickOfSession	=	false;
				bool								isFirstTick				=	false;
				bool								isAsk;
				int									barsSinceNewTradingDay	=	0;
		
		private	int									SessionZonesMode		=	0;
		private	TimeSpan							american_time			=	new TimeSpan(7,0,0);
		private	TimeSpan							european_time			=	new TimeSpan(2,0,0);
		private	TimeSpan							asia_time				=	new TimeSpan(18,0,0);
        private int                                 consBars                =   0;
        private int                                 AssistModeIndex         =   -1;
        private int                                 AssistTpoMerge          =   -1;
        private DateTime                            CurrentSessionBegin;
        private DateTime                            PrevSessionBegin;
        private bool                                MarketDataFirst         =   true;

        float max_tpo_y = 0;
        float min_tpo_y = float.MaxValue;
        float max_tpo_width = 0;

//        private string toolbarname = "NSTPOToolBar", uID;
//        private Grid indytoolbar;
//        private Menu MenuControlContainer;
//        private MenuItem MenuControl;

        static int defaultMargin = 5;
        double TogglePositionMarginLeft	= 5;
        double TogglePositionMarginTop = 5;
        double TogglePositionMarginRight = 5;
        double TogglePositionMarginBottom = 5;
        bool DragSwitchedOn = true;
        WrapPanel dragPanel;
        double prevLast;
		double PriorPrice=double.MinValue;
		#endregion


#if NEW_CODE_NOV2018
		private class SavedConfigManager {
			#region SavedConfigManager
			public int CurrentViewMode_SelectedIndex = 0;
			public SortedDictionary<int,string> ViewMode_ConfigFileSuffixes = new SortedDictionary<int,string>();
			public string ConfigDir = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "templates", "TPOconfig");
			public string InstName  = string.Empty;
			public System.IO.DirectoryInfo dirCustom = null;
			public string Status=string.Empty;

			//==========================================================================================================
			public SavedConfigManager(string InstrumentFullName, string InstrumentType){
				try{
					//Status = "Constructor "+InstrumentFullName+"  "+InstrumentType;
					if(!System.IO.Directory.Exists(ConfigDir)) System.IO.Directory.CreateDirectory(ConfigDir);
					dirCustom = new System.IO.DirectoryInfo(ConfigDir);
					InstName = StripOutIllegalCharacters(string.Format("{0}-{1}",InstrumentFullName, InstrumentType),"_");
				}catch(Exception e){Status = "SavedConfigManager constructor: "+e.ToString();}
			}
			//==========================================================================================================
			public void AddViewMode(int idx, string suffix){
				try{
					//Status = Status+"\nAddViewMode "+suffix;
					ViewMode_ConfigFileSuffixes[idx] = suffix;
				}catch(Exception e){Status = "AddViewMode: "+e.ToString();}
			}
			//==========================================================================================================
			public void UpdateStatus(string StatusName, bool NewStatus){
				var fname = System.IO.Path.Combine(ConfigDir,this.StripOutIllegalCharacters(InstName+"-"+StatusName+".config","_"));
				try{
					if(NewStatus){
						System.IO.File.WriteAllText(fname,"x");
					}else{
						if(System.IO.File.Exists(fname)) System.IO.File.Delete(fname);
					}
				}catch(Exception e){Status = "Update "+StatusName+": "+e.ToString();}
			}
			//==========================================================================================================
			public bool DetermineStatus(string StatusName){
				var fname = System.IO.Path.Combine(ConfigDir,this.StripOutIllegalCharacters(InstName+"-"+StatusName+".config","_"));
				try{
					return System.IO.File.Exists(fname);
				}catch(Exception e){Status = "DetermineStatus: "+StatusName+": "+e.ToString();}
				return false;
			}
			//==========================================================================================================
			public bool Determine_ShowRRBoxVisibility(){
				var fnameRRbox = System.IO.Path.Combine(ConfigDir,this.StripOutIllegalCharacters(InstName+"-rrb.config","_"));
				//Status = Status+"\nDetermine_ShowRRBoxVisibility dir: "+fnameRRbox;
				try{
					return System.IO.File.Exists(fnameRRbox);
				}catch(Exception e){Status = "Determine_ShowRRBoxVis: "+e.ToString();}
				return false;
			}
			//==========================================================================================================
			public void Update_ShowRRBoxVisibility(bool IsVisible){
				var fnameRRbox = System.IO.Path.Combine(ConfigDir,this.StripOutIllegalCharacters(InstName+"-rrb.config","_"));
				//Status = Status+"\nUpdate_ShowRRBoxVisibility dir: "+fnameRRbox;
				try{
					if(IsVisible){
						System.IO.File.WriteAllText(fnameRRbox,"x");
					}else{
						if(System.IO.File.Exists(fnameRRbox)) System.IO.File.Delete(fnameRRbox);
					}
				}catch(Exception e){Status = "Update_ShowRRBoxVis: "+e.ToString();}
			}
			//==========================================================================================================
			public bool Determine_SplitEnabledStatus(){
				var fnameSplitEnabled = System.IO.Path.Combine(ConfigDir,this.StripOutIllegalCharacters(InstName+"-splitenabled.config","_"));
				try{
					return System.IO.File.Exists(fnameSplitEnabled);
				}catch(Exception e){Status = "Determine_SplitEnabledStatus: "+e.ToString();}
				return false;
			}
			//==========================================================================================================
			public void Update_SplitEnabledStatus(bool IsLocked){
				var fnameSplitEnabled = System.IO.Path.Combine(ConfigDir,this.StripOutIllegalCharacters(InstName+"-splitenabled.config","_"));
				try{
					if(!IsLocked){
						System.IO.File.WriteAllText(fnameSplitEnabled,"x");
					}else{
						if(System.IO.File.Exists(fnameSplitEnabled)) System.IO.File.Delete(fnameSplitEnabled);
					}
				}catch(Exception e){Status = "Update_SplitEnabledStatus: "+e.ToString();}
			}			//==========================================================================================================
			public int Determine_CurrentViewMode(){
				var filCustom = dirCustom.GetFiles(string.Format("{0}*viewmode.config",InstName));
				//Status = Status+"\nDetermine_CurrentViewMode filCustom.Count: "+filCustom.Length.ToString();
				try{
					if(filCustom==null) 
						return 0;
					else{
						foreach (var fi in filCustom) {
							for(int i = 0; i<ViewMode_ConfigFileSuffixes.Count; i++){
								if(fi.FullName.EndsWith(ViewMode_ConfigFileSuffixes[i])){
									this.CurrentViewMode_SelectedIndex = i;
									return i;
								}
							}
						}
					}
				}catch(Exception e){Status = "Determine_CurrentViewMode: "+e.ToString();}
				return 0;
			}
			//==========================================================================================================
			public void Update_CurrentViewMode(int viewmode_index){
				this.CurrentViewMode_SelectedIndex = viewmode_index;
				var filCustom = dirCustom.GetFiles(string.Format("{0}*viewmode.config",InstName));
				//Status = Status+"\nUpdate_CurrenttViewMode filCustom.Count: "+filCustom.Length.ToString();
				try{
					if(filCustom!=null) foreach (var fi in filCustom) System.IO.File.Delete(fi.FullName);
					var config_filename = StripOutIllegalCharacters(InstName+this.ViewMode_ConfigFileSuffixes[viewmode_index], "_");
					System.IO.File.WriteAllText(System.IO.Path.Combine(ConfigDir, config_filename), "x");
				}catch(Exception e){Status = "Update_CurrentViewMode: "+e.ToString();}
			}
			//==========================================================================================================
			public bool Determine_ShowFreshZones(){
				var config_filename = this.StripOutIllegalCharacters(InstName+"_zones_on.config","_");
				//Status = Status+"\nDetermine_ShowFreshZones dir: "+config_filename;
				try{
					return (System.IO.File.Exists(System.IO.Path.Combine(ConfigDir, config_filename)));
				}catch(Exception e){Status = "Determine_ShowFreshZones: "+e.ToString();}
				return false;
			}
			//==========================================================================================================
			public bool Determine_ShowBrokenZones(){
				var config_filename = this.StripOutIllegalCharacters(InstName+"_brokenzones_on.config","_");
				//Status = Status+"\nDetermine_ShowBrokenZones dir: "+config_filename;
				try{
					return (System.IO.File.Exists(System.IO.Path.Combine(ConfigDir, config_filename)));
				}catch(Exception e){Status = "Determine_ShowBrokenZones: "+e.ToString();}
				return false;
			}
			//==========================================================================================================
			public void Update_ShowFreshZones(bool IsVisible){
				try{
					var config_filename = this.StripOutIllegalCharacters(InstName+"_zones_on.config","_");
					//Status = Status+"\nUpdate_ShowFreshZones dir: "+config_filename;
					if(IsVisible) 
						System.IO.File.WriteAllText(System.IO.Path.Combine(ConfigDir, config_filename),"zones: enabled");
					else 
						System.IO.File.Delete(System.IO.Path.Combine(ConfigDir, config_filename));
				}catch(Exception e){Status = "Update_ShowFreshZones: "+e.ToString();}
			}
			//==========================================================================================================
			public void Update_ShowBrokenZones(bool IsVisible){
				try{
					var config_filename = this.StripOutIllegalCharacters(InstName+"_brokenzones_on.config","_");
					//Status = Status+"\nUpdate_ShowBrokenZones dir: "+config_filename;
					if(IsVisible) 
						System.IO.File.WriteAllText(System.IO.Path.Combine(ConfigDir, config_filename),"broken zones: enabled");
					else 
						System.IO.File.Delete(System.IO.Path.Combine(ConfigDir, config_filename));
				}catch(Exception e){Status = "Update_ShowBrokenZones: "+e.ToString();}
			}
			//==========================================================================================================
			public string StripOutIllegalCharacters(string name, string ReplacementString){
				#region strip
				char[] invalidPathChars = System.IO.Path.GetInvalidFileNameChars();
				string invalids = string.Empty;
				foreach(char ch in invalidPathChars){
					invalids += ch.ToString();
				}
				string result = string.Empty;
				for(int c=0; c<name.Length; c++) {
					if(!invalids.Contains(name[c].ToString())) result += name[c];
					else result += ReplacementString;
				}
				return result;
				#endregion
			}
			#endregion
		}
		//==========================================================================================================
		private SavedConfigManager ConfigMgr = null;
#endif
		private class TempMessageData{
			public DateTime FirstAppearance = DateTime.MinValue;
			public double SecondsToShow = 10;
			public string MsgText = "";
			public char Foreground = 'W';//Brushes.White;
			public char Background = 'B';//Brushes.Black;
			public TempMessageData(DateTime firstAppearance, double secondsToShow, string msgText, char foreground, char background){
				FirstAppearance=firstAppearance; SecondsToShow = secondsToShow; MsgText=msgText; Foreground=foreground; Background=background;
			}
		}
		private List<TempMessageData> Messages = new List<TempMessageData>();

        #region PROPERTIES

#if MODERATORS
		[Display(ResourceType = typeof(Resource), Name = "Value Area (pct)", GroupName = "Parameters", Order = 1)]
		public double pVASize_Pct {get;set;}
#else
		private double pVASize_Pct =0.6;
#endif
        #region PLOTS

        //       [Browsable(false)]
        //[XmlIgnore]
        //public Series<double> VWAP
        //{
        //	get { return Values[0]; }
        //}
        //[Browsable(false)]
        //[XmlIgnore]
        //public Series<double> TWAP
        //{
        //	get { return Values[1]; }
        //}

        #endregion

		#region Alerts buy/sell zone
		[Display(ResourceType = typeof(Resource), Name = "BuyZone Alert WAV", GroupName = "Alerts", Order = 10)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string BuyZoneWAV { get; set; }

		[Display(ResourceType = typeof(Resource), Name = "SellZone Alert WAV", GroupName = "Alerts", Order = 20)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string SellZoneWAV { get; set; }

		[Display(ResourceType = typeof(Resource), Description = "Play alert when price hits the actual zone?", Name = "Play On Zone", GroupName = "Alerts", Order = 25)]
		public bool pPlayOnZoneHit { get; set; }
		[Display(ResourceType = typeof(Resource), Description = "Play alert when price touches the Front-run price?", Name = "Play On FrontRun", GroupName = "Alerts", Order = 30)]
		public bool pPlayOnFrontRunHit { get; set; }

		[Range(0,int.MaxValue)]
		[Display(ResourceType = typeof(Resource), Description = "Number of ticks, in advance of a zone, to provide audible alert", Name = "Front-run ticks", GroupName = "Alerts", Order = 40)]
		public int pFrontrunTicks { get; set; }
		#endregion

		#region TradingHours
		private TimeSpan pTimeBegin = new TimeSpan(0,0,0);
//		[NinjaScriptProperty]
//		[Display(Name="Time Begin", Description="Enter the time at the start of the session", Order=10, GroupName="Trading Hours")]
//		public string TimeBegin
//		{
//			get { return pTimeBegin.Hours.ToString("00")+":"+pTimeBegin.Minutes.ToString("00")+":"+pTimeBegin.Seconds.ToString("00"); }
//			set { if(!TimeSpan.TryParse(value, out pTimeBegin)) pTimeBegin=new TimeSpan(0,0,0); }
//		}

		private TimeSpan pTimeEnd = new TimeSpan(0,0,0);
//		[NinjaScriptProperty] 
//		[Display(Name="Time End", Description="Enter the time at the end of the session", Order=20, GroupName="Trading Hours")]
//		public string TimeEnd
//		{
//			get { return pTimeEnd.Hours.ToString("00")+":"+pTimeEnd.Minutes.ToString("00")+":"+pTimeEnd.Seconds.ToString("00"); }
//			set { if(!TimeSpan.TryParse(value, out pTimeEnd)) pTimeEnd=new TimeSpan(0,0,0); }
//		}
		#endregion

		#region MARKET PROFILE
        //Fixed at 30 minutes
        [Browsable(false),Range(1,30)][NinjaScriptProperty] [Display(Name="TPO Period in minutes.Range 1-30", Order=1, GroupName="Market Profile Settings")]
		public int	TPO_PERIOD
		{
			get { return TPO_Period; }
			set { TPO_Period = value; }
		}
		
		[NinjaScriptProperty] [Display(Name="TPO Tick Increment", Order=2, GroupName="Market Profile Settings")]
		public int	TPO_TICKS_INCREMENT
		{
			get { return TPO_Ticks_Increment; }
			set { TPO_Ticks_Increment = Math.Max(1,value); }
		}
		
		[NinjaScriptProperty] [Display(Name="Auto Increment", Order=3, GroupName="Market Profile Settings")]
		public bool	TPO_Ticks_Increment_Auto
		{
			get;set;
		}
		
		[Display(ResourceType = typeof(Resource), Name = "Hybrid Profile Opacity % -- 10%", GroupName = "Market Profile Settings", Order = 4)]
		public float TPO_Squares_Opacity { get; set; }
		
		//Remove it
		[Browsable(false),NinjaScriptProperty] [Display(Name="Hybrid Mode. TPO Profile Enabled", Order=5, GroupName="Market Profile Settings")]
		public bool TPO_Profile_Enabled
		{get;set;}
		
		[Browsable(false),NinjaScriptProperty] [Display(Name="Hybrid Mode. Volume Profile Enabled", Order=6, GroupName="Market Profile Settings")]
		public bool Volume_Profile_Enabled
		{get;set;}
		////
		/// 
		#endregion
		
		#region GLOBAL VISUAL

		[Display(ResourceType = typeof(Resource), Name = "Enable Global objects", GroupName = "Global Visuals", Order = 1)]
		public bool	GlobalSR_Enabled {get;set;}

		[Display(ResourceType = typeof(Resource), Name = "VAH Ray Template", GroupName = "Global Visuals", Order = 10)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string VAH_Ray_Template { get; set; }

		[Display(ResourceType = typeof(Resource), Name = "VAL Ray Template", GroupName = "Global Visuals", Order = 20)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string VAL_Ray_Template { get; set; }

		[Display(ResourceType = typeof(Resource), Name = "Support zone Template", GroupName = "Global Visuals", Order = 30)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRectTemplates))]
		public string SupportZones_Template { get; set; }
		[Display(ResourceType = typeof(Resource), Name = "Resistance zone Template", GroupName = "Global Visuals", Order = 40)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRectTemplates))]
		public string ResistanceZones_Template { get; set; }
		#endregion

		#region TPO VISUAL
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "TPO Value Area Color", GroupName = "TPO Visual Settings", Order = 10)]
		public Brush VA_TPO_Color { get; set; }
		[Browsable(false)]
		public string VA_TPO_ColorSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(VA_TPO_Color); }
			set { VA_TPO_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "TPO Above Value Color", GroupName = "TPO Visual Settings", Order = 20)]
		public Brush VA_Above_Color { get; set; }
		[Browsable(false)]
		public string VA_Above_ColorSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(VA_Above_Color); }
			set { VA_Above_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "TPO Below Value Color", GroupName = "TPO Visual Settings", Order = 30)]
		public Brush VA_Below_Color { get; set; }
		[Browsable(false)]
		public string VA_Below_ColorSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(VA_Below_Color); }
			set { VA_Below_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Profile TPO Value Area", GroupName = "TPO Visual Settings", Order = 40)]
		public Brush VA_Line_Color { get; set; }
		[Browsable(false)]
		public string VA_Line_ColorSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(VA_Line_Color); }
			set { VA_Line_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Profile Volume Value Area", GroupName = "TPO Visual Settings", Order = 60)]
		public Brush VolumeValueArea_Brush { get; set; }
		[Browsable(false)]
		public string VolumeValueArea_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(VolumeValueArea_Brush); }
			set { VolumeValueArea_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Single Print Color", GroupName = "TPO Visual Settings", Order = 70)]
		public Brush Single_Prints_Color { get; set; }
		[Browsable(false)]
		public string Single_PrintsColorSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Single_Prints_Color); }
			set { Single_Prints_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Volume Profile Color", GroupName = "TPO Visual Settings", Order = 80)]
		public Brush Vol_Hist_Color { get; set; }
		[Browsable(false)]
		public string Vol_Hist_ColorSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Vol_Hist_Color); }
			set { Vol_Hist_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty] [Display(Name="Volume Profile Opacity % -- 10%", GroupName="TPO Visual Settings", Order=90)]
		public float	VOL_HIST_OPACITY
		{
			get { return vol_hist_opacity; }
			set { vol_hist_opacity = Math.Min(1,Math.Max(0,value));}
		}

        [Display(ResourceType = typeof(Resource), Name = "TPO Font", GroupName = "TPO Visual Settings", Order = 100)]
        public SimpleFont TpoFont { get; set; }

		[Range(1f,100f)]
        [Display(ResourceType = typeof(Resource), Name = "TPO Font Size", GroupName = "TPO Visual Settings", Order = 101)]
        public float TpoFontSize { get; set; }

        [Display(ResourceType = typeof(Resource), Name = "Supplemental Marker", GroupName = "TPO Visual Settings", Order = 110)]
		public bool Supplemental_Marker { get; set; }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Supplemental Marker Color", GroupName = "TPO Visual Settings", Order = 120)]
		public Brush SupplementalMarker_Brush { get; set; }
		[Browsable(false)]
		public string SupplementalMarker_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(SupplementalMarker_Brush); }
			set { SupplementalMarker_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "POC TPO COLOR", GroupName = "TPO Visual Settings", Order = 130)]
		public Brush POC_TPO_Color { get; set; }
		[Browsable(false)]
		public string POC_TPO_ColorSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(POC_TPO_Color); }
			set { POC_TPO_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "VPOC TPO COLOR", GroupName = "TPO Visual Settings", Order = 140)]
		public Brush VPOC_TPO_Color { get; set; }
		[Browsable(false)]
		public string VPOC_TPO_ColorSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(VPOC_TPO_Color); }
			set { VPOC_TPO_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "POC Line Color", GroupName = "TPO Visual Settings", Order = 150)]
		public Brush POC_Line_Color { get; set; }
		[Browsable(false)]
		public string POC_Line_ColorSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(POC_Line_Color); }
			set { POC_Line_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
        [Display(ResourceType = typeof(Resource), Name = "Open Close Marker Size", GroupName = "TPO Visual Settings", Order = 160)]
        public float OC_MarkerSize { get; set; }

		[Display(ResourceType = typeof(Resource), Name = "ATR Mode", GroupName = "TPO Visual Settings", Order = 170)]
        public ARC_ATRModeEnum ATRMode { get; set; }
		
        #region Remove
//        [XmlIgnore]
//		[Browsable(false),Display(ResourceType = typeof(Resource), Name = "VWAP TPO COLOR", GroupName = "TPO Visual Settings", Order = 4)]
//		public Brush VWAP_TPO_Color { get; set; }
//		[Browsable(false)]
//		public string VWAP_TPO_ColorSerialize
//		{
//			get { return NinjaTrader.Gui.Serialize.BrushToString(VWAP_TPO_Color); }
//			set { VWAP_TPO_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
//		}
		
//		[XmlIgnore]
//		[Browsable(false),Display(ResourceType = typeof(Resource), Name = "TWAP TPO COLOR", GroupName = "TPO Visual Settings", Order = 5)]
//		public Brush TWAP_TPO_Color { get; set; }
//		[Browsable(false)]
//		public string TWAP_TPO_ColorSerialize
//		{
//			get { return NinjaTrader.Gui.Serialize.BrushToString(TWAP_TPO_Color); }
//			set { TWAP_TPO_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
//		}
//		[Browsable(false),Display(ResourceType = typeof(Resource), Name = "SINGLE PRINTS TRACKER", GroupName = "TPO Visual Settings", Order = 7)]
//		public bool SinglePrintsTracker { get; set; }
		#endregion
		
		
		
		#endregion
		
		#region FOOTPRINT
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Bid Imbalance", GroupName = "Footprint Settings", Order = 1)]
		public Brush BidHighlight_Brush { get; set; }
		[Browsable(false)]
		public string  BidHighlight_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString( BidHighlight_Brush); }
			set {  BidHighlight_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Ask Imbalance", GroupName = "Footprint Settings", Order = 2)]
		public Brush AskHighlight_Brush { get; set; }
		[Browsable(false)]
		public string  AskHighlight_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString( AskHighlight_Brush); }
			set {  AskHighlight_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Bid Body Color", GroupName = "Footprint Settings", Order = 3)]
		public Brush BidBody_Brush { get; set; }
		[Browsable(false)]
		public string  BidBody_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString( BidBody_Brush); }
			set {  BidBody_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Ask Body Color", GroupName = "Footprint Settings", Order = 4)]
		public Brush AskBody_Brush { get; set; }
		[Browsable(false)]
		public string AskBody_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString( AskBody_Brush); }
			set { AskBody_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Ask > Bid 50%", GroupName = "Footprint Settings", Order = 6)]
		public Brush Ask_Greater_Bid_50_Brush { get; set; }
		[Browsable(false)]
		public string Ask_Greater_Bid_50_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Ask_Greater_Bid_50_Brush); }
			set { Ask_Greater_Bid_50_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Ask > Bid 15%-49%", GroupName = "Footprint Settings", Order = 7)]
		public Brush Ask_Greater_Bid_1549_Brush { get; set; }
		[Browsable(false)]
		public string Ask_Greater_Bid_1549_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Ask_Greater_Bid_1549_Brush); }
			set { Ask_Greater_Bid_1549_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Ask > Bid 0%-14%", GroupName = "Footprint Settings", Order = 8)]
		public Brush Ask_Greater_Bid_014_Brush { get; set; }
		[Browsable(false)]
		public string Ask_Greater_Bid_014_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Ask_Greater_Bid_014_Brush); }
			set { Ask_Greater_Bid_014_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Bid > Ask 50%", GroupName = "Footprint Settings", Order = 9)]
		public Brush Bid_Greater_Ask_50_Brush { get; set; }
		[Browsable(false)]
		public string Bid_Greater_Ask_50_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Bid_Greater_Ask_50_Brush); }
			set { Bid_Greater_Ask_50_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Bid > Ask 15%-49%", GroupName = "Footprint Settings", Order = 10)]
		public Brush Bid_Greater_Ask_1549_Brush { get; set; }
		[Browsable(false)]
		public string Bid_Greater_Ask_1549_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Bid_Greater_Ask_1549_Brush); }
			set { Bid_Greater_Ask_1549_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Bid > Ask 0%-14%", GroupName = "Footprint Settings", Order = 11)]
		public Brush Bid_Greater_Ask_014_Brush { get; set; }
		[Browsable(false)]
		public string Bid_Greater_Ask_014_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString(Bid_Greater_Ask_014_Brush); }
			set { Bid_Greater_Ask_014_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Footprint Outline", GroupName = "Footprint Settings", Order = 12)]
		public Brush Footprint_OutLine_Brush { get; set; }
		[Browsable(false)]
		public string Footprint_OutLine_BrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString( Footprint_OutLine_Brush); }
			set { Footprint_OutLine_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Resource), Name = "Unfinished Auctions", GroupName = "Footprint Settings", Order = 13)]
		public bool UnfinishedAuctionsEnabled { get; set; }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Unfinished Auctions Color", GroupName = "Footprint Settings", Order = 14)]
		
		public Brush UnfinishedAuctionsBrush { get; set; }
		[Browsable(false)]
		public string UnfinishedAuctionsBrushSerialize
		{
			get { return NinjaTrader.Gui.Serialize.BrushToString( UnfinishedAuctionsBrush); }
			set { UnfinishedAuctionsBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		
		
		[Range(0,Int32.MaxValue),Display(ResourceType = typeof(Resource), Name = "Box Tick Increment", GroupName = "Footprint Settings", Order = 15)]
		public int BoxTickIncrement { get; set; }
		
		[Display(ResourceType = typeof(Resource), Name = "Auto Increment", GroupName = "Footprint Settings", Order = 16)]
		public bool BoxTickIncrement_Auto { get; set; }
		
		///Remove next. THere will be a button.
		[Display(ResourceType = typeof(Resource), Name = "Footprint Enabled", GroupName = "Footprint Settings", Order = 17)]
		public bool FootprintEnabled { get; set; }

        #endregion

        #region SPLIT

        [Display(ResourceType = typeof(Resource), Name = "Auto Split", GroupName = "Split Settings", Order = 1)]
        public bool Auto_Split
        {
            get { return IsAutoSplit; }
            set { IsAutoSplit = value; }
        }

        [Display(ResourceType = typeof(Resource), Name = "Split Assist", GroupName = "Split Settings", Order = 20)]
        public bool Split_Assist
		{
			get { return IsSplitAssist; }
			set { IsSplitAssist = value; }
		}

		[Display(ResourceType = typeof(Resource), Name = "Manual Split/Merge", GroupName = "Split Settings", Order = 30)]
		public bool Manual_SplitMerge
		{
			get { return IsManualSplitMerge; }
			set { IsManualSplitMerge = value; }
		}

        [Display(ResourceType = typeof(Resource), Name = "Current Day AutoSplit", GroupName = "Split Settings", Order = 40)]
        public bool CDAuto_Split
        {
            get { return IsCDAutoSplit; }
            set { IsCDAutoSplit = value; }
        }
        [Display(ResourceType = typeof(Resource), Name = "Splitting Locked", GroupName = "Split Settings", Order = 50)]
        public bool IsSplittingLocked {get; set;}

        //Auto-Merge Manipulation
        [Range(0,Int32.MaxValue)][NinjaScriptProperty] [Display(Name="Auto-Merge Manipulation", GroupName="Split Settings", Order=60)]
		public int	AutoMergeManipulation {get;set;}

        #endregion

        #region SPLIT ASSIST
        [XmlIgnore]
        [Display(ResourceType = typeof(Resource), Name = "Split Letter Color", GroupName = "Split Assist Settings", Order = 1)]
        public Brush LetterHighLighted_Brush { get; set; }
        [Browsable(false)]
        public string LetterHighLighted_BrushSerialize
        {
            get { return NinjaTrader.Gui.Serialize.BrushToString(LetterHighLighted_Brush); }
            set { LetterHighLighted_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }

        [Display(ResourceType = typeof(Resource), Name = "Split Letter Color Opacity", GroupName = "Split Assist Settings", Order = 2)]
        public float LetterHighLighted_Brush_Opacity { get; set; }

        [Display(ResourceType = typeof(Resource), Name = "Split Letter Outline", GroupName = "Split Assist Settings", Order = 3)]
        public Stroke LetterHighLighted_Stroke { get; set; }

        [XmlIgnore]
        [Display(ResourceType = typeof(Resource), Name = "Merge Profile Color", GroupName = "Split Assist Settings", Order = 4)]
        public Brush ProfileMerge_Brush { get; set; }
        [Browsable(false)]
        public string ProfileMerge_BrushSerialize
        {
            get { return NinjaTrader.Gui.Serialize.BrushToString(ProfileMerge_Brush); }
            set { ProfileMerge_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }

        [Display(ResourceType = typeof(Resource), Name = "Merge Profile Color Opacity", GroupName = "Split Assist Settings", Order = 5)]
        public float ProfileMerge_Brush_Opacity { get; set; }

        [Display(ResourceType = typeof(Resource), Name = "Merge Profile Outline", GroupName = "Split Assist Settings", Order = 6)]
        public Stroke ProfileMerge_Stroke { get; set; }
        #endregion

        #region ZONES
        [XmlIgnore]
        [Display(ResourceType = typeof(Resource), Name = "Support Zone Color", GroupName = "Zones Settings", Order = 1)]
        public Brush SupportZone_Brush { get; set; }
        [Browsable(false)]
        public string SupportZone_BrushSerialize
        {
            get { return NinjaTrader.Gui.Serialize.BrushToString(SupportZone_Brush); }
            set { SupportZone_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }

        [Range(0,100)]
        [Display(ResourceType = typeof(Resource), Name = "Support Zone Opacity",Description = "Support Zone Opacity 0-100%",GroupName = "Zones Settings", Order = 2)]
        public int SupportZoneOpacity
        {
            get; set;
        }

        [Display(ResourceType = typeof(Resource), Name = "Support Zone Border", GroupName = "Zones Settings", Order = 3)]
        public Stroke SupportZoneBorder
        {
            get;set;
        }

        [XmlIgnore]
        [Display(ResourceType = typeof(Resource), Name = "Resistance Zone Color", GroupName = "Zones Settings", Order = 4)]
        public Brush ResistanceZone_Brush { get; set; }
        [Browsable(false)]
        public string ResistanceZone_BrushSerialize
        {
            get { return NinjaTrader.Gui.Serialize.BrushToString(ResistanceZone_Brush); }
            set { ResistanceZone_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(ResourceType = typeof(Resource), Name = "Resistance Zone Opacity", Description = "Resistance Zone Opacity 0-100%", GroupName = "Zones Settings", Order = 5)]
        public int ResistanceZoneOpacity
        {
            get; set;
        }

        [Display(ResourceType = typeof(Resource), Name = "Resistance Zone Border", GroupName = "Zones Settings", Order = 6)]
        public Stroke ResistanceZoneBorder
        {
            get; set;
        }
		
		[XmlIgnore]
        [Display(ResourceType = typeof(Resource), Name = "Support Tested Zone Color", GroupName = "Zones Settings", Order = 7)]
        public Brush SupportTestedZone_Brush { get; set; }
        [Browsable(false)]
        public string SupportTestedZone_BrushSerialize
        {
            get { return NinjaTrader.Gui.Serialize.BrushToString(SupportTestedZone_Brush); }
            set { SupportTestedZone_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(ResourceType = typeof(Resource), Name = "Support Tested Zone Opacity", Description = "Support Opacity 0-100%", GroupName = "Zones Settings", Order = 8)]
        public int SupportTestedZoneOpacity
        {
            get; set;
        }

        [Display(ResourceType = typeof(Resource), Name = "Support Tested Zone Border", GroupName = "Zones Settings", Order = 9)]
        public Stroke SupportTestedZoneBorder
        {
            get; set;
        }
		
        [XmlIgnore]
        [Display(ResourceType = typeof(Resource), Name = "Resistance Tested Zone Color", GroupName = "Zones Settings", Order = 10)]
        public Brush ResistanceTestedZone_Brush { get; set; }
        [Browsable(false)]
        public string TestedZone_BrushSerialize
        {
            get { return NinjaTrader.Gui.Serialize.BrushToString(ResistanceTestedZone_Brush); }
            set { ResistanceTestedZone_Brush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(ResourceType = typeof(Resource), Name = "Resistance Tested Zone Opacity", Description = "Tested Zone Opacity 0-100%", GroupName = "Zones Settings", Order = 11)]
        public int ResistanceTestedZoneOpacity
        {
            get; set;
        }

        [Display(ResourceType = typeof(Resource), Name = "Resistance Tested Zone Border", GroupName = "Zones Settings", Order = 12)]
        public Stroke ResistanceTestedZoneBorder
        {
            get; set;
        }

		[Display(ResourceType = typeof(Resource), Name = "Fresh Zones", GroupName = "Zones Settings", Order = 13)]
        public bool ShowFreshZones
        {
            get; set;
        }
        [Display(ResourceType = typeof(Resource), Name = "Broken Zones", GroupName = "Zones Settings", Order = 14)]
        public bool ShowBrokenZones
        {
            get; set;
        }

        [Display(ResourceType = typeof(Resource), Name = "Show Range Numbers", GroupName = "Zones Settings", Order = 15)]
        public bool ShowRangeNumbers
        {
            get; set;
        }

        [Display(ResourceType = typeof(Resource), Name = "Range Numbers Font", GroupName = "Zones Settings", Order = 16)]
        public SimpleFont RangeNumbersFont
        {
            get; set;
        }

        #endregion

        #region CANDLE BRUSHES

        [Browsable(false)]
        [XmlIgnore]
        [Display(GroupName = "CandleBrushes")]
        public Brush UpBrush { get; set; }

        [Browsable(false)]
        public string UpBrushColorSerialize
        {
            get { return NinjaTrader.Gui.Serialize.BrushToString(UpBrush); }
            set { UpBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }

        [Browsable(false)]
        [XmlIgnore]
        [Display(GroupName = "CandleBrushes")]
        public Brush DownBrush { get; set; }

        [Browsable(false)]
        public string DownBrushColorSerialize
        {
            get { return NinjaTrader.Gui.Serialize.BrushToString(DownBrush); }
            set { DownBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }

        [Browsable(false)]
        [XmlIgnore]
        [Display(GroupName = "CandleBrushes")]
        public Brush CandleOutlineBrush { get; set; }

        [Browsable(false)]
        public string StrokeBrushColorSerialize
        {
            get { return NinjaTrader.Gui.Serialize.BrushToString(CandleOutlineBrush); }
            set { CandleOutlineBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }

		[Browsable(false)]
		[XmlIgnore]
		[Display(GroupName = "CandleBrushes")]
		public Brush CandleWickBrush { get; set; }

		[Browsable(false)]
		public string Stroke2BrushColorSerialize
		{
            get { return NinjaTrader.Gui.Serialize.BrushToString(CandleWickBrush); }
            set { CandleWickBrush = NinjaTrader.Gui.Serialize.StringToBrush(value); }
		}
		#endregion

		#region ATR Delta Box Visual

		[Display(ResourceType = typeof(Resource), Name = "Font",Description = "Font",GroupName = "ATR Delta Box Visual", Order = 10)]
		public SimpleFont ATR_Delta_Box_Font
		{
            get; set;
		}

		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Font Color",Description = "Font Color",GroupName = "ATR Delta Box Visual", Order = 20)]
		public Brush ATR_Delta_Box_Font_Color { get; set; }

		[Browsable(false)]
		public string ATR_Delta_Box_Font_ColorSerialize
		{
            get { return NinjaTrader.Gui.Serialize.BrushToString(ATR_Delta_Box_Font_Color); }
            set { ATR_Delta_Box_Font_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Box Background Color",Description = "Box Background Color",GroupName = "ATR Delta Box Visual", Order = 30)]
		public Brush ATR_Delta_Box_Back_Color { get; set; }

		[Browsable(false)]
		public string ATR_Delta_Box_Back_ColorSerialize
		{
            get { return NinjaTrader.Gui.Serialize.BrushToString(ATR_Delta_Box_Back_Color); }
            set { ATR_Delta_Box_Back_Color = NinjaTrader.Gui.Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Resource), Name = "Box Border",Description = "Box Border",GroupName = "ATR Delta Box Visual", Order = 40)]
		public Stroke ATR_Delta_Box_Border { get; set; }

		[Display(ResourceType = typeof(Resource), Name = "Show RR", Description = "Shows the RR databox in lower-right corner",GroupName = "ATR Delta Box Visual", Order = 50)]
		public bool ShowRR_databox {get; set;}
		#endregion

		#endregion

		private int ErrorPrintCount = 0;
		private int line=0;
		static string HLtemplates_folder=null;
		int ViewModeSelected = 0;
		bool GlobalSelectionsEnabled = true;
		private MouseManager MM;
		private double FrontRunPts = 0;

		#region PrintNoDup
		private string PriorPrintStr = "";
		private void PrintNoDup(string s){
			if(s.CompareTo(PriorPrintStr)==0) return;
			Print(s);
			PriorPrintStr=s;
		}
		private void PrintNoDup(int i){
			var s = i.ToString();
			if(s.CompareTo(PriorPrintStr)==0) return;
			Print(s);
			PriorPrintStr=s;
		}
		#endregion


		#region -- ON STATE CHANGE --
		protected override void OnStateChange()
		{
//PrintNoDup(State.ToString());
			#region Defaults
			if (State == State.SetDefaults)
			{
				PrintTo = PrintTo.OutputTab2;
				//AddPlot(new Stroke(Brushes.DarkCyan,2),PlotStyle.Line,"VWAP");
				//AddPlot(new Stroke(Brushes.DarkKhaki,2),PlotStyle.Line,"TWAP");
				Description								= 	@"";
//				Name									= 	"NS TPO Test";
				Name									= 	"ARC_TPO Distributions";
				Calculate								= 	Calculate.OnEachTick;
				MaximumBarsLookBack							= 	MaximumBarsLookBack.TwoHundredFiftySix;
				IsOverlay									= 	true;
				DisplayInDataBox							= 	true;
				DrawOnPricePanel							= 	true;
				DrawHorizontalGridLines						= 	true;
				DrawVerticalGridLines						= 	true;
				PaintPriceMarkers							= 	true;
				ScaleJustification							= 	NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive					= 	false;

				LetterHighLighted_Brush                     =   Brushes.Yellow;
				LetterHighLighted_Brush_Opacity             =   0.5f;
				LetterHighLighted_Stroke                    =   new Stroke(Brushes.Black, 2);
				ProfileMerge_Brush                          =   Brushes.LimeGreen;
				ProfileMerge_Brush_Opacity                  =   0.5f;
				ProfileMerge_Stroke                         =   new Stroke(Brushes.Black, 2);

				TPO_Period									= 	30;
				TPO_Ticks_Increment							= 	2;
				TPO_Profile_Enabled							= 	true;
				Volume_Profile_Enabled						=	true;
				VA_TPO_Color								=	Brushes.Black;
				VPOC_TPO_Color								=	Brushes.DarkOrange;
				POC_TPO_Color								=	Brushes.Cyan;
//				TWAP_TPO_Color								=	Brushes.DarkKhaki;
//				VWAP_TPO_Color								=	Brushes.Green;
				Single_Prints_Color							=	Brushes.Black;
				VA_Above_Color								=	Brushes.Blue;
				VA_Below_Color								=	Brushes.Red;
				Vol_Hist_Color								=	Brushes.White;
				VolumeValueArea_Brush						=	Brushes.Cyan;
				SupplementalMarker_Brush					=	Brushes.Black;

				TpoFont                                     =   new SimpleFont("Calibri", 8) { Bold = false };
				TpoFontSize = 8f;
				POC_Line_Color								=	Brushes.Yellow;
				VA_Line_Color								=	Brushes.Black;
				vol_hist_opacity							=	0.3f;
				TPO_Squares_Opacity							=	0.5f;
				Supplemental_Marker							=	true;
				FootprintEnabled							=	true;
				AskHighlight_Brush							=	Brushes.DodgerBlue;
				BidHighlight_Brush							=	Brushes.Gold;
				BidBody_Brush								=	Brushes.LightCoral;
				AskBody_Brush								=	Brushes.DarkSeaGreen;
				Footprint_OutLine_Brush						=	Brushes.Black;
				Ask_Greater_Bid_50_Brush					=	Brushes.LimeGreen;
				Ask_Greater_Bid_1549_Brush					=	Brushes.DarkSeaGreen;
				Ask_Greater_Bid_014_Brush					=	Brushes.LightBlue;
				Bid_Greater_Ask_50_Brush					=	Brushes.Red;
				Bid_Greater_Ask_1549_Brush					=	Brushes.Salmon;
				Bid_Greater_Ask_014_Brush					=	Brushes.Yellow;
				
				BoxTickIncrement							=	1;
				UnfinishedAuctionsEnabled					=	true;
				UnfinishedAuctionsBrush						=	Brushes.LightBlue;
				AutoMergeManipulation						=	0;

				ResistanceZoneBorder                        =   new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
				SupportZoneBorder                           =   new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
				SupportZone_Brush                           =   Brushes.LimeGreen;
				ResistanceZone_Brush                        =   Brushes.Crimson;
				ResistanceTestedZone_Brush                  =   Brushes.Yellow;
				SupportTestedZone_Brush                  	=   Brushes.LightBlue;

				SupportTestedZoneBorder                     =   new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
				ResistanceTestedZoneBorder                  =   new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
				
				ShowFreshZones								=   false;
				ShowBrokenZones								=   false;
				OC_MarkerSize								=   4;
//				SinglePrintsTracker							=   true;

				IsSplitAssist                               =   true;
				IsManualSplitMerge                          =   true;
				IsCDAutoSplit                               =   true;
				IsSplittingLocked							=   true;

				ShowRangeNumbers                            =   false;
				RangeNumbersFont                            =   new SimpleFont("Courier New", 9);

				SupportZoneOpacity                          =   20;
				ResistanceZoneOpacity                       =   20;
				ResistanceTestedZoneOpacity                 =   20;
				SupportTestedZoneOpacity                 	=   20;
				ATRMode										= 	ARC_ATRModeEnum.Points;
				
				TPO_Ticks_Increment_Auto					=	true;
				BoxTickIncrement_Auto						=	true;
				ATR_Delta_Box_Font							=	new SimpleFont("Verdana",12);
				ATR_Delta_Box_Font_Color					=	Brushes.Black;
				ATR_Delta_Box_Back_Color					=	Brushes.DarkKhaki;
				ATR_Delta_Box_Border						=	new Stroke(Brushes.Black,1);
				GlobalSR_Enabled							=   false;
				ResistanceZones_Template					= "Default";
				SupportZones_Template						= "Default";
				VAH_Ray_Template							= "Default";
				VAL_Ray_Template							= "Default";
				ShowRR_databox								= true;
				BuyZoneWAV									= "none";
				SellZoneWAV									= "none";
				pFrontrunTicks								= 0;
				pPlayOnFrontRunHit = true;
				pPlayOnZoneHit     = true;
				pVASize_Pct = 0.6;
//				string[] paths = new string[4]{Core.Globals.UserDataDir,"templates","DrawingTool","HorizontalLine"};
//				HLtemplates_folder = System.IO.Path.Combine(paths);
			}
			#endregion

			#region Configure
			else if (State == State.Configure)
			{
//ClearOutputWindow();
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion
			originalZOrder = ZOrder;

			atr = ATR(Closes[0],14);
			if (TPO_Cluster_List!=null)
				{
					TPO_Cluster_List.Clear();
				}
				TPO_Cluster_List	=	new List<TPO_Cluster>();
				FootPrint_List		=	new SortedDictionary<int,BarFootPrint>();
				sessionIterator		=	new SessionIterator(Bars);

				if(Bars.BarsPeriod.BarsPeriodType==BarsPeriodType.Day)
					DailyMode	=	true;
				else
					DailyMode	=	false;
				
				if(DailyMode)
					day_count	=	-1;
				
				this.MM = new MouseManager();

				//Adding tick dataseries if tick replay is off
				if(!Bars.IsTickReplay)
					AddDataSeries(BarsPeriodType.Tick,1);

				if (bonds.Contains(Instrument.MasterInstrument.Name))
					AreBonds = true;

				FrontRunPts = pFrontrunTicks * TickSize;

//				BrushesTable[0] = Brushes.Transparent;
//				BrushesTable[0].Freeze();
//				BrushesTable[ID_Ask_Greater_Bid_50_Brush]   = Ask_Greater_Bid_50_Brush.Clone();
//				BrushesTable[ID_Ask_Greater_Bid_50_Brush].Freeze();
//				BrushesTable[ID_Ask_Greater_Bid_1549_Brush] = Ask_Greater_Bid_1549_Brush.Clone();
//				BrushesTable[ID_Ask_Greater_Bid_1549_Brush].Freeze();
//				BrushesTable[ID_Ask_Greater_Bid_014_Brush]  = Ask_Greater_Bid_014_Brush.Clone();
//				BrushesTable[ID_Ask_Greater_Bid_014_Brush].Freeze();
//				BrushesTable[ID_Bid_Greater_Ask_50_Brush]   = Bid_Greater_Ask_50_Brush.Clone();
//				BrushesTable[ID_Bid_Greater_Ask_50_Brush].Freeze();
//				BrushesTable[ID_Bid_Greater_Ask_1549_Brush] = Bid_Greater_Ask_1549_Brush.Clone();
//				BrushesTable[ID_Bid_Greater_Ask_1549_Brush].Freeze();
//				BrushesTable[ID_Bid_Greater_Ask_014_Brush]  = Bid_Greater_Ask_014_Brush.Clone();
//				BrushesTable[ID_Bid_Greater_Ask_014_Brush].Freeze();
			}
			#endregion

			#region DataLoaded
			else if (State == State.DataLoaded)
			{
                //				if(!System.IO.Directory.Exists(ConfigDir)) System.IO.Directory.CreateDirectory(ConfigDir);
                //				dirCustom = new System.IO.DirectoryInfo(ConfigDir);
                //				InstName = StripOutIllegalCharacters(string.Format("{0}-{1}",Instrument.MasterInstrument.Name, Instrument.MasterInstrument.InstrumentType),"_");

                #region ChangeIncrementSettings

                int[] sett = IncrementSettings.GetSettings(Instruments[0].MasterInstrument.Name,
					Instruments[0].MasterInstrument.InstrumentType==InstrumentType.Forex,
					(Instruments[0].MasterInstrument.InstrumentType==InstrumentType.Stock ? Close[0]:double.NaN));

				if(BoxTickIncrement_Auto)
					BoxTickIncrement    = sett[0];
				
				if(TPO_Ticks_Increment_Auto)
					TPO_Ticks_Increment = sett[1];

//PrintNoDup(BoxTickIncrement+" "+ TPO_Ticks_Increment);
				#endregion
			}
			#endregion

			#region Historical
			else if(State==State.Historical)
			{
				UpBrush      = (EqualColor(ChartBars.Properties.ChartStyle.UpBrush, Brushes.Transparent))   ? UpBrush   : ChartBars.Properties.ChartStyle.UpBrush;
				DownBrush    = (EqualColor(ChartBars.Properties.ChartStyle.DownBrush, Brushes.Transparent)) ? DownBrush : ChartBars.Properties.ChartStyle.DownBrush;
//				var b        = ((SolidColorBrush)ChartBars.Properties.ChartStyle.Stroke.Brush).Color;
				CandleOutlineBrush  = (EqualColor(ChartBars.Properties.ChartStyle.Stroke2.Brush, Brushes.Transparent)) ? CandleOutlineBrush : ChartBars.Properties.ChartStyle.Stroke.Brush;
				CandleWickBrush     = (EqualColor(ChartBars.Properties.ChartStyle.Stroke2.Brush, Brushes.Transparent)) ? CandleWickBrush    : ChartBars.Properties.ChartStyle.Stroke2.Brush;

#if NEW_CODE_NOV2018
				ConfigMgr = new SavedConfigManager(Instrument.MasterInstrument.Name, Instrument.MasterInstrument.InstrumentType.ToString());
#endif
				Dispatcher.InvokeAsync(new Action(() =>
				{
					if (!IsToolBarButtonAdded) 
					{
						AddToolBar();
						if(ChartControl!=null){
							ChartPanel.MouseMove += ChartPanel_MouseMove;
							ChartPanel.MouseUp   += ChartPanel_MouseUp;
						}
					}
					if(!MethodsAdded && ChartControl!=null)
					{
						ChartControl.PreviewMouseLeftButtonUp +=	OnLeftClick;
						MethodsAdded=true;
					}
					if (ProfileView==true)
					{
						ChartBars.Properties.ChartStyle.UpBrush			= Brushes.Transparent;
						ChartBars.Properties.ChartStyle.DownBrush		= Brushes.Transparent;
						ChartBars.Properties.ChartStyle.Stroke.Brush	= Brushes.Transparent;
						ChartBars.Properties.ChartStyle.Stroke2.Brush	= Brushes.Transparent;
					}
				
					if(ProfileView==false)
					{
						ChartBars.Properties.ChartStyle.UpBrush			= UpBrush;
						ChartBars.Properties.ChartStyle.DownBrush		= DownBrush;
						ChartBars.Properties.ChartStyle.Stroke.Brush	= CandleOutlineBrush;
						ChartBars.Properties.ChartStyle.Stroke2.Brush	= CandleWickBrush;
					}
				}));
			}
			#endregion

			else if(State == State.Realtime){
				//DetermineDisqualifiedZones();
				#region disqualify fresh res zones that are below the current price, and fresh support zones that are above the current price
				foreach(var tpo in TPO_Cluster_List){
					if(tpo.ResistanceTopLevel < Closes[0][0] && !tpo.ResistanceTested) tpo.IsResDisqualified=true;
					if(tpo.SupportBottomLevel > Closes[0][0] && !tpo.SupportTested) tpo.IsSupDisqualified=true;
				}
				#endregion
			}

			#region Terminated
			else if(State==State.Terminated)
			{
				if(ChartBars!=null && UpBrush!=null)
				{
					ChartBars.Properties.ChartStyle.UpBrush			=	UpBrush;
					ChartBars.Properties.ChartStyle.DownBrush		=	DownBrush;
					ChartBars.Properties.ChartStyle.Stroke.Brush	=	CandleOutlineBrush;
					ChartBars.Properties.ChartStyle.Stroke2.Brush	=	CandleWickBrush;
				}
				
				if(TPO_Cluster_List!=null) TPO_Cluster_List.Clear();
				TPO_Cluster_List=null;
				clickChartScale=null;

				if(ChartControl!=null){
					Dispatcher.InvokeAsync((Action)(() => 
					{
						ChartPanel.MouseMove -= ChartPanel_MouseMove;
						ChartPanel.MouseUp   -= ChartPanel_MouseUp;
					}));
				}
				if(MethodsAdded)
				{
					if (ChartControl != null)
					{
				    	ChartControl.Dispatcher.InvokeAsync((Action)(() =>
				        {
							ChartControl.PreviewMouseLeftButtonUp	-=	OnLeftClick;
							MethodsAdded=false;
						 }));
				    }
					
				}
				DisposeCleanUp();
			}
			#endregion

			#region Transition
			else if (State == State.Transition)
			{
				sessionBegin = sessionIterator.ActualSessionBegin;
				SplitAssist(sessionBegin, false);
				AutoMergeFunc();
				AutoSplitFunc();
			}
			#endregion
		}
		#endregion

		//==================================================
		private void DetermineDisqualifiedZones(){
			#region -- DetermineDisqualifiedZones --
			int idx =0;
			for(idx = 0; idx<TPO_Cluster_List.Count-1; idx++){
				TPO_Cluster_List[idx].IsResDisqualified = TPO_Cluster_List[idx+1].Open >= TPO_Cluster_List[idx].ResistanceBottomLevel;
				TPO_Cluster_List[idx].IsSupDisqualified = TPO_Cluster_List[idx+1].Open <= TPO_Cluster_List[idx].SupportBottomLevel;
			}
			TPO_Cluster_List[idx].IsResDisqualified=false;
			TPO_Cluster_List[idx].IsSupDisqualified=false;
			#endregion
		}
		//==================================================

		#region -- ON BAR UPDATE --
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(CurrentBars[0]<2) return;
			if(CurrentBars[1]<2) return;
line=1796;
            if (HybridView)
                SetZOrder(1000);
            else
                SetZOrder(-1000);

line=1802;
#if NEW_CODE_NOV2018
			bool InSession = false;
			#region InSession calc
			try{
				if(pTimeBegin==pTimeEnd) InSession=true;
				else if(pTimeBegin < pTimeEnd && CurrentBars[1]>1){
					var tsNow = Times[1][0].TimeOfDay;
					if(tsNow < this.pTimeBegin) InSession = false;
					else if(tsNow >= this.pTimeEnd) InSession = false;
					else InSession = true;
				}else if(CurrentBars[1]>1){
					var tsNow = Times[1][0].TimeOfDay;
					if(tsNow >= this.pTimeEnd && tsNow < this.pTimeBegin) InSession = false;
					else InSession = true;
				}
			}catch(Exception e){PrintNoDup("1739  E: "+e.ToString());}
			#endregion
			if(!InSession) {
				BackBrush = Brushes.Maroon;
			}
#endif
            bool	LastTickOfHistorical	=	Closes[0].Count-1==CurrentBars[0];
			bool	isHistorical			=	State==State.Historical && !BarsArray[0].IsTickReplay;
			bool	isTickReplay			=	BarsArray[0].IsTickReplay;
			int		serIdx					=	isTickReplay?0:1;//Index of data series, if tick replay is off then use 1 - tick data series,otherwise use 0 - primary data series
			int		barsBack				=	(!BarsArray[0].IsTickReplay&&State==State.Historical) || Calculate==Calculate.OnBarClose?0:1;

return;
			if(CurrentBars[0]>=barsBack)
			{
				if(BarsArray[0].IsFirstBarOfSession && BarsInProgress==0)
				{
					//Day_Volume				= 0;
					//Price_Day_Volume		= 0;
//					Day_TWAP				= 0;
					barsSinceNewTradingDay	= 0;
                }
                

                if (IsFirstTickOfBar && BarsInProgress==0 && (!isHistorical||!LastTickOfHistorical))
				{
					if(!BarsArray[0].IsFirstBarOfSession||isHistorical)
					{
						//Day_Volume       += Volumes[0][barsBack];
						//Price_Day_Volume += Volumes[0][barsBack]*Closes[0][barsBack];
//						Day_TWAP         += (Highs[0][barsBack]+Lows[0][barsBack]+Opens[0][barsBack]+Closes[0][barsBack])/4;
					}
				}
				
				if(BarsInProgress==0)
				{
					double	cur_price_day_vol	=	isHistorical&&!LastTickOfHistorical? 0: Volumes[0][0]*Closes[0][0];
					double	cur_vol				=	isHistorical&&!LastTickOfHistorical? 0: Volumes[0][0];
					double	cur_day_twap		=	isHistorical&&!LastTickOfHistorical? 0: (Highs[0][0]+Lows[0][0]+Opens[0][0]+Closes[0][0])/4;

					//MarketReplay on realtime data has a bug with BarSinceNewTradingDay
					if(IsFirstTickOfBar && (!isHistorical||!LastTickOfHistorical))
					{
						barsSinceNewTradingDay++;
					}
                    
				}
			}
			if(isHistorical)//&&Closes[0].Count-1!=CurrentBars[0]
			{
				#region Historical zone updating
				if(BarsInProgress==0)
				{
					isFirstTickOfSession	=	BarsArray[0].IsFirstBarOfSession&&BarsInProgress==0&&IsFirstTickOfBar;
					isFirstTick				=	BarsInProgress==0&&IsFirstTickOfBar;
					prevCurrentBar			=	CurrentBars[0];
                }
				
				if(BarsInProgress==1)
				{
					//FOOTPRINT POPULATING NO TICK REPLAY
					if(CurrentBars[1]>1 && Closes[1][0]!=Closes[1][1])
					{
						isAsk	=	Closes[1][0]>Closes[1][1];
					}

					FootprintPopulate(isFirstTick,isFirstTickOfSession,CurrentBars[0]+1,Closes[1][0],Volumes[1][0],isAsk);

					//TPO POPULATING NO TICK REPLAY
					bool		isNewSession	=	sessionIterator.IsNewSession(Times[1][0],true);
                    if (isNewSession)
                    {
                        CurrentSessionOpen = Closes[1][0];
                    }
					sessionIterator.CalculateTradingDay(Times[1][0],true);
					DateTime	sessionBegin	=	sessionIterator.ActualSessionBegin;
					DateTime	sessionEnd		=	sessionIterator.ActualSessionEnd;
                    CurrentSessionBegin         =   sessionBegin;
					
                    TPO_Populate(IsFirstTickOfBar,isNewSession,sessionBegin,sessionEnd,CurrentBars[0]+1, CurrentBars[0], Closes[1][0],Times[1][0],Volumes[1][0],true,Lows[1][0]);

                    //Session Info
                    if (isNewSession)
                    {
                        Sessions.Add(new SessionInfo(CurrentBars[0] + 1, sessionBegin));
                    }
                    else 
                    {
                        if(Sessions.Count>0)
                        Sessions.Last().LastBarIdx = CurrentBars[0]+1;
                    }

					if(CurrentBars[0]>BarsArray[0].Count-5 && IsFirstTickOfBar){
						UntestedResPrices.Clear();
						UntestedSupPrices.Clear();
					}
					#region CheckZone
					if(CurrentBars[0]>0){
						foreach (TPO_Cluster TPO in TPO_Cluster_List)
						{
						    if (TPO.SessionBeginDate == sessionBegin)
						        continue;

						    if (TPO.ResistanceTested)
						    {
						        if (!TPO.IsResistanceBroken)
						        {
						            if (!isNewSession)
						            {
						                TPO.ResistanceEndIdx = CurrentBars[0];
						            }
						            else
						            {
						                TPO.IsResistanceBroken = true;
						            }
						        }
						    }

							if (TPO.SupportTested)
						    {
						        if (!TPO.IsSupportBroken)
						        {
						            if (!isNewSession)
						            {
						                TPO.SupportEndIdx = CurrentBars[0];
						            }
						            else
						            {
						                TPO.IsSupportBroken = true;
						            }
						        }
						    }

							if (!TPO.ResistanceTested && Closes[1][1] < TPO.ResistanceBottomLevel)
						    {
						        if (TPO.IsResTouched(Closes[1][0]))
						        {
						            TPO.ResistanceTested = true;
						            TPO.ResistanceTestedDate = Times[0][0];
						            TPO.ResistanceEndIdx = CurrentBars[0];
						        }
						    }
						    if (!TPO.SupportTested && Closes[1][1] > TPO.SupportTopLevel)
						    {
						        if (TPO.IsSupTouched(Closes[1][0]))
						        {
						            TPO.SupportTested = true;
						            TPO.SupportTestedDate = Times[0][0];
						            TPO.SupportEndIdx = CurrentBars[0];
						        }
						    }
						}
					}
					#endregion

                    //Split Assist
                    if (isNewSession)
                    {
                        if(PrevSessionBegin!=null)
                            SplitAssist(PrevSessionBegin, false);
						
						PrevSessionBegin = sessionBegin;
                    }
					isFirstTickOfSession		=	false;
					isFirstTick					=	false;
                }
				#endregion
			}
		}
        #endregion

        #region -- ON MARKET DATA --
        protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
        {
            if (BarsInProgress == 1)
                return;

			if (!Bars.IsTickReplay && State == State.Historical)
                return;

            if (marketDataUpdate.MarketDataType != MarketDataType.Last)
                return;



            double last = marketDataUpdate.Price;
            tick_time   = marketDataUpdate.Time;
            tick_volume = marketDataUpdate.Volume;
            bool? IsAsk = null;



            if (last >= marketDataUpdate.Ask)
                IsAsk = true;
            if (last <= marketDataUpdate.Bid)
                IsAsk = false;
            if (Closes[0].IsValidDataPointAt(CurrentBars[0]))
                currentBar = Closes[0].Count - 1;

            bool FirstTick = currentBar != prevCurrentBar;
            bool isNewSession = sessionIterator.IsNewSession(tick_time, true);

            if (isNewSession)
            {
                CurrentSessionOpen = last;
            }

            sessionIterator.CalculateTradingDay(tick_time, true);
            DateTime sessionBegin = sessionIterator.ActualSessionBegin;
            DateTime sessionEnd   = sessionIterator.ActualSessionEnd;
            CurrentSessionBegin   = sessionBegin;

            if (isNewSession)
            {
                Sessions.Add(new SessionInfo(currentBar, sessionBegin));
            }
            if (!isNewSession && Sessions.Count > 0)
            {
                Sessions.Last().LastBarIdx = currentBar;
            }

            #region FOOTPRINT COLLECTING DATA

            //New Code
            FootprintPopulate(FirstTick, isNewSession, currentBar, last, tick_volume, IsAsk);

            #endregion

            #region TPO COLLECTING DATA

            //New Code
            TPO_Populate(FirstTick,isNewSession, sessionBegin, sessionEnd, currentBar, prevCurrentBar, last, tick_time, tick_volume, false, Lows[0][0]);

            #endregion

            #region CHECK ZONE PER TPO
            //Check Zone
            foreach (TPO_Cluster TPO in TPO_Cluster_List)
            {
                if (TPO.SessionBeginDate == sessionBegin)
                    continue;

                if (TPO.ResistanceTested)
                {
                    if (!TPO.IsResistanceBroken)
                    {
                        if (!isNewSession)
                        {
                            TPO.ResistanceEndIdx = currentBar;
                        }
                        else
                        {
                            TPO.IsResistanceBroken = true;
                        }
                    }
                }

                if (TPO.SupportTested)
                {
                    if (!TPO.IsSupportBroken)
                    {
                        if (!isNewSession)
                        {
                            TPO.SupportEndIdx = currentBar;
                        }
                        else
                        {
                            TPO.IsSupportBroken = true;
                        }
                    }
                }

                if (!TPO.ResistanceTested && prevLast < TPO.ResistanceBottomLevel)
                {
                    if (TPO.IsResTouched(last))
                    {
                        TPO.ResistanceTested        = true;
                        TPO.ResistanceTestedDate    = tick_time;
                        TPO.ResistanceEndIdx        = currentBar;
#if NEW_CODE_NOV2018
						string tag = string.Format("RectArb_{0} {1}", TPO.FirstIndex, TPO.ResistanceTopLevel);
						if(GlobalArb_Rects!=null && GlobalArb_Rects.ContainsKey(tag)) {
							GlobalArb_Rects.Remove(tag);
							RemoveDrawObject(tag);
						}
#endif
                    }
                }

                if (!TPO.SupportTested && prevLast > TPO.SupportTopLevel)
                {
                    if (TPO.IsSupTouched(last))
                    {
                        TPO.SupportTested       = true;
                        TPO.SupportTestedDate   = tick_time;
                        TPO.SupportEndIdx       = currentBar;
#if NEW_CODE_NOV2018
						string tag = string.Format("RectArb_{0} {1}", TPO.FirstIndex, TPO.SupportTopLevel);
						if(GlobalArb_Rects!=null && GlobalArb_Rects.ContainsKey(tag)) {
							GlobalArb_Rects.Remove(tag);
							RemoveDrawObject(tag);
						}
#endif
                    }
                }
            }
            #endregion

            #region CURRENT DAY AUTOSPLIT
            if (IsCDAutoSplit)
            { 
                if (FirstTick && TPO_Cluster_List.Count>0)
                {
                    //if (consBars == 1)
                    //{
                        consBars = 0;
                        AutoSplit(TPO_Cluster_List.Last());
                    //}
                    //consBars++;
                }
            }
            #endregion

            #region PREV DAY AUTOSPLIT
            if (isNewSession&&IsAutoSplit)
            {
                if(TPO_Cluster_List.Count>1)
                    AutoSplit(TPO_Cluster_List[TPO_Cluster_List.Count - 2]);
            }
            #endregion

            //Split Assist
            if (isNewSession)
            {
                if (PrevSessionBegin != null)
                    SplitAssist(PrevSessionBegin, false);
            }

            PrevSessionBegin    = sessionBegin;
            prevCurrentBar      = currentBar;
            prevLast = last;
		}
		#endregion

		#region -- DX brush definitions --
		SharpDX.Direct2D1.Brush backBrushDX;
		SharpDX.Direct2D1.Brush box_text_BrushDX;
		SharpDX.Direct2D1.Brush borderBrushDX;
		SharpDX.Direct2D1.Brush volHistBrushDX;
		SharpDX.Direct2D1.Brush highRangeSinglePrintBrushDX;
		SharpDX.Direct2D1.Brush lowRangeSinglePrintBrushDX;
		SharpDX.Direct2D1.Brush unfinishedAucBrushDX;
		SharpDX.Direct2D1.Brush bidHighlightBrushDX;
		SharpDX.Direct2D1.Brush bidBodyBrushDX;
		SharpDX.Direct2D1.Brush askHighlightBrushDX;
		SharpDX.Direct2D1.Brush askBodyBrushDX;
		SharpDX.Direct2D1.Brush textBrushDX;
		SharpDX.Direct2D1.Brush footprintOutlineBrushDX;
		SharpDX.Direct2D1.Brush BlackBrushDX, WhiteBrushDX;
		SharpDX.Direct2D1.Brush pocBrushDX;
		SharpDX.Direct2D1.Brush valBrushDX;
		SharpDX.Direct2D1.Brush volValueAreaBrushDX;
		SharpDX.Direct2D1.Brush letterBrushDX;
		SharpDX.Direct2D1.Brush strokeBrushDX;
		SharpDX.Direct2D1.Brush merge_assist_brushDX;
		SharpDX.Direct2D1.Brush merge_assist_stroke_brushDX;
		SharpDX.Direct2D1.Brush val2BrushDX;
		SharpDX.Direct2D1.Brush posImbBrushDX;
		SharpDX.Direct2D1.Brush negImbBrushDX;
		SharpDX.Direct2D1.Brush POC_TPO_DX;
		SharpDX.Direct2D1.Brush VPOC_TPO_DX;
		SharpDX.Direct2D1.Brush VA_TPO_DX;
		SharpDX.Direct2D1.Brush VA_Above_DX;
		SharpDX.Direct2D1.Brush VA_Below_DX;
		SharpDX.Direct2D1.Brush Single_DX;
		SharpDX.Direct2D1.Brush TPOBrushDX = null;
		SharpDX.Direct2D1.Brush SupBrushDX;
		SharpDX.Direct2D1.Brush ResBrushDX;
		SharpDX.Direct2D1.Brush ResTestedBrushDX;
		SharpDX.Direct2D1.Brush SupTestedBrushDX;
		SharpDX.Direct2D1.Brush SupStrokeBrushDX;
		SharpDX.Direct2D1.Brush ResStrokeBrushDX;
		SharpDX.Direct2D1.Brush SupTestedStrokeBrushDX;
		SharpDX.Direct2D1.Brush ResTestedStrokeBrushDX;
		SharpDX.Direct2D1.Brush labelBrushDX;
		SharpDX.Direct2D1.Brush TransparentBrushDX;
		SharpDX.Direct2D1.Brush YellowBrushDX;
		#endregion
		public override void OnRenderTargetChanged()
        {
			#region -- ORTC --
//			if(dx!=null   && !dx.IsDisposed)   {dx.Dispose();   dx=null;}
//			if(RenderTarget!=null) dx = bbb.ToDxBrush(RenderTarget);
			if(BrushesDXTable[0]!=null   && !BrushesDXTable[0].IsDisposed)   {BrushesDXTable[0].Dispose();   BrushesDXTable[0]=null;}
			if(RenderTarget!=null) BrushesDXTable[0] = Brushes.Transparent.ToDxBrush(RenderTarget);

			if(BrushesDXTable[ID_Ask_Greater_Bid_50_Brush]!=null   && !BrushesDXTable[ID_Ask_Greater_Bid_50_Brush].IsDisposed)   {BrushesDXTable[ID_Ask_Greater_Bid_50_Brush].Dispose();   BrushesDXTable[ID_Ask_Greater_Bid_50_Brush]=null;}
			if(RenderTarget!=null) BrushesDXTable[ID_Ask_Greater_Bid_50_Brush] = Ask_Greater_Bid_50_Brush.ToDxBrush(RenderTarget);

			if(BrushesDXTable[ID_Ask_Greater_Bid_1549_Brush]!=null   && !BrushesDXTable[ID_Ask_Greater_Bid_1549_Brush].IsDisposed)   {BrushesDXTable[ID_Ask_Greater_Bid_1549_Brush].Dispose();   BrushesDXTable[ID_Ask_Greater_Bid_1549_Brush]=null;}
			if(RenderTarget!=null) BrushesDXTable[ID_Ask_Greater_Bid_1549_Brush] = Ask_Greater_Bid_1549_Brush.ToDxBrush(RenderTarget);

			if(BrushesDXTable[ID_Ask_Greater_Bid_014_Brush]!=null   && !BrushesDXTable[ID_Ask_Greater_Bid_014_Brush].IsDisposed)   {BrushesDXTable[ID_Ask_Greater_Bid_014_Brush].Dispose();   BrushesDXTable[ID_Ask_Greater_Bid_014_Brush]=null;}
			if(RenderTarget!=null) BrushesDXTable[ID_Ask_Greater_Bid_014_Brush] = Ask_Greater_Bid_014_Brush.ToDxBrush(RenderTarget);

			if(BrushesDXTable[ID_Bid_Greater_Ask_50_Brush]!=null   && !BrushesDXTable[ID_Bid_Greater_Ask_50_Brush].IsDisposed)   {BrushesDXTable[ID_Bid_Greater_Ask_50_Brush].Dispose();   BrushesDXTable[ID_Bid_Greater_Ask_50_Brush]=null;}
			if(RenderTarget!=null) BrushesDXTable[ID_Bid_Greater_Ask_50_Brush] = Bid_Greater_Ask_50_Brush.ToDxBrush(RenderTarget);

			if(BrushesDXTable[ID_Bid_Greater_Ask_1549_Brush]!=null   && !BrushesDXTable[ID_Bid_Greater_Ask_1549_Brush].IsDisposed)   {BrushesDXTable[ID_Bid_Greater_Ask_1549_Brush].Dispose();   BrushesDXTable[ID_Bid_Greater_Ask_1549_Brush]=null;}
			if(RenderTarget!=null) BrushesDXTable[ID_Bid_Greater_Ask_1549_Brush] = Bid_Greater_Ask_1549_Brush.ToDxBrush(RenderTarget);

			if(BrushesDXTable[ID_Bid_Greater_Ask_014_Brush]!=null   && !BrushesDXTable[ID_Bid_Greater_Ask_014_Brush].IsDisposed)   {BrushesDXTable[ID_Bid_Greater_Ask_014_Brush].Dispose();   BrushesDXTable[ID_Bid_Greater_Ask_014_Brush]=null;}
			if(RenderTarget!=null) BrushesDXTable[ID_Bid_Greater_Ask_014_Brush] = Bid_Greater_Ask_014_Brush.ToDxBrush(RenderTarget);
			
			if(YellowBrushDX!=null   && !YellowBrushDX.IsDisposed)   {YellowBrushDX.Dispose();   YellowBrushDX=null;}
			if(RenderTarget!=null) YellowBrushDX = Brushes.Yellow.ToDxBrush(RenderTarget);

			if(labelBrushDX!=null   && !labelBrushDX.IsDisposed)   {labelBrushDX.Dispose();   labelBrushDX=null;}
			if(RenderTarget!=null && ChartControl!=null) labelBrushDX = ChartControl.Properties.ChartText.ToDxBrush(RenderTarget);

			if(ResTestedStrokeBrushDX!=null   && !ResTestedStrokeBrushDX.IsDisposed)   {ResTestedStrokeBrushDX.Dispose();   ResTestedStrokeBrushDX=null;}
			if(RenderTarget!=null) ResTestedStrokeBrushDX = ResistanceTestedZoneBorder.Brush.ToDxBrush(RenderTarget);

			if(SupTestedStrokeBrushDX!=null   && !SupTestedStrokeBrushDX.IsDisposed)   {SupTestedStrokeBrushDX.Dispose();   SupTestedStrokeBrushDX=null;}
			if(RenderTarget!=null) SupTestedStrokeBrushDX = SupportTestedZoneBorder.Brush.ToDxBrush(RenderTarget);

			if(ResStrokeBrushDX!=null   && !ResStrokeBrushDX.IsDisposed)   {ResStrokeBrushDX.Dispose();   ResStrokeBrushDX=null;}
			if(RenderTarget!=null) ResStrokeBrushDX = ResistanceZoneBorder.Brush.ToDxBrush(RenderTarget);

			if(SupStrokeBrushDX!=null   && !SupStrokeBrushDX.IsDisposed)   {SupStrokeBrushDX.Dispose();   SupStrokeBrushDX=null;}
			if(RenderTarget!=null) SupStrokeBrushDX = SupportZoneBorder.Brush.ToDxBrush(RenderTarget);

			if(SupTestedBrushDX!=null   && !SupTestedBrushDX.IsDisposed)   {SupTestedBrushDX.Dispose();   SupTestedBrushDX=null;}
			if(RenderTarget!=null){
				SupTestedBrushDX = SupportTestedZone_Brush.ToDxBrush(RenderTarget);
				SupTestedBrushDX.Opacity 	= 	(float)SupportTestedZoneOpacity / 100f;
			}

			if(ResTestedBrushDX!=null   && !ResTestedBrushDX.IsDisposed)   {ResTestedBrushDX.Dispose();   ResTestedBrushDX=null;}
			if(RenderTarget!=null){
				ResTestedBrushDX = ResistanceTestedZone_Brush.ToDxBrush(RenderTarget);
				ResTestedBrushDX.Opacity 	= 	(float)ResistanceTestedZoneOpacity / 100f;
			}

			if(ResBrushDX!=null   && !ResBrushDX.IsDisposed)   {ResBrushDX.Dispose();   ResBrushDX=null;}
			if(RenderTarget!=null){
				ResBrushDX = ResistanceZone_Brush.ToDxBrush(RenderTarget);
				ResBrushDX.Opacity    	= 	(float)ResistanceZoneOpacity / 100f;
			}

			if(SupBrushDX!=null   && !SupBrushDX.IsDisposed)   {SupBrushDX.Dispose();   SupBrushDX=null;}
			if(RenderTarget!=null) {
				SupBrushDX = SupportZone_Brush.ToDxBrush(RenderTarget);
				SupBrushDX.Opacity    	= 	(float)SupportZoneOpacity/100f;
			}

			if(TransparentBrushDX!=null   && !TransparentBrushDX.IsDisposed)   {TransparentBrushDX.Dispose();   TransparentBrushDX=null;}
			if(RenderTarget!=null) TransparentBrushDX = Brushes.Transparent.ToDxBrush(RenderTarget);

			if(Single_DX!=null   && !Single_DX.IsDisposed)   {Single_DX.Dispose();   Single_DX=null;}
			if(RenderTarget!=null) Single_DX = Single_Prints_Color.ToDxBrush(RenderTarget);

			if(VA_Below_DX!=null   && !VA_Below_DX.IsDisposed)   {VA_Below_DX.Dispose();   VA_Below_DX=null;}
			if(RenderTarget!=null) VA_Below_DX = VA_Below_Color.ToDxBrush(RenderTarget);

			if(VA_Above_DX!=null   && !VA_Above_DX.IsDisposed)   {VA_Above_DX.Dispose();   VA_Above_DX=null;}
			if(RenderTarget!=null) VA_Above_DX = VA_Above_Color.ToDxBrush(RenderTarget);

			if(VA_TPO_DX!=null   && !VA_TPO_DX.IsDisposed)   {VA_TPO_DX.Dispose();   VA_TPO_DX=null;}
			if(RenderTarget!=null) VA_TPO_DX = VA_TPO_Color.ToDxBrush(RenderTarget);

			if(VPOC_TPO_DX!=null   && !VPOC_TPO_DX.IsDisposed)   {VPOC_TPO_DX.Dispose();   VPOC_TPO_DX=null;}
			if(RenderTarget!=null) VPOC_TPO_DX = VPOC_TPO_Color.ToDxBrush(RenderTarget);

			if(POC_TPO_DX!=null   && !POC_TPO_DX.IsDisposed)   {POC_TPO_DX.Dispose();   POC_TPO_DX=null;}
			if(RenderTarget!=null) POC_TPO_DX = POC_TPO_Color.ToDxBrush(RenderTarget);

			if(negImbBrushDX!=null   && !negImbBrushDX.IsDisposed)   {negImbBrushDX.Dispose();   negImbBrushDX=null;}
			if(RenderTarget!=null) negImbBrushDX = Brushes.Red.ToDxBrush(RenderTarget);

			if(posImbBrushDX!=null   && !posImbBrushDX.IsDisposed)   {posImbBrushDX.Dispose();   posImbBrushDX=null;}
			if(RenderTarget!=null) posImbBrushDX = Brushes.LimeGreen.ToDxBrush(RenderTarget);

			if(val2BrushDX!=null   && !val2BrushDX.IsDisposed)   {val2BrushDX.Dispose();   val2BrushDX=null;}
			if(RenderTarget!=null) {val2BrushDX = VA_Line_Color.ToDxBrush(RenderTarget);val2BrushDX.Opacity = 0.5f;}

			if(merge_assist_stroke_brushDX!=null   && !merge_assist_stroke_brushDX.IsDisposed)   {merge_assist_stroke_brushDX.Dispose();   merge_assist_stroke_brushDX=null;}
			if(RenderTarget!=null) merge_assist_stroke_brushDX = ProfileMerge_Stroke.Brush.ToDxBrush(RenderTarget);

			if(merge_assist_brushDX!=null   && !merge_assist_brushDX.IsDisposed)   {merge_assist_brushDX.Dispose();   merge_assist_brushDX=null;}
			if(RenderTarget!=null) {merge_assist_brushDX = ProfileMerge_Brush.ToDxBrush(RenderTarget);merge_assist_brushDX.Opacity 	= 	ProfileMerge_Brush_Opacity;}

			if(strokeBrushDX!=null   && !strokeBrushDX.IsDisposed)   {strokeBrushDX.Dispose();   strokeBrushDX=null;}
			if(RenderTarget!=null) strokeBrushDX = LetterHighLighted_Stroke.Brush.ToDxBrush(RenderTarget);

			if(letterBrushDX!=null   && !letterBrushDX.IsDisposed)   {letterBrushDX.Dispose();   letterBrushDX=null;}
			if(RenderTarget!=null) {
				letterBrushDX = LetterHighLighted_Brush.ToDxBrush(RenderTarget);
				letterBrushDX.Opacity = LetterHighLighted_Brush_Opacity;
			}

			if(volValueAreaBrushDX!=null   && !volValueAreaBrushDX.IsDisposed)   {volValueAreaBrushDX.Dispose();   volValueAreaBrushDX=null;}
			if(RenderTarget!=null) {volValueAreaBrushDX = VolumeValueArea_Brush.ToDxBrush(RenderTarget); volValueAreaBrushDX.Opacity   =   1f;}

			if(valBrushDX!=null   && !valBrushDX.IsDisposed)   {valBrushDX.Dispose();   valBrushDX=null;}
			if(RenderTarget!=null) {valBrushDX = VA_Line_Color.ToDxBrush(RenderTarget);valBrushDX.Opacity = 1f;}

			if(pocBrushDX!=null   && !pocBrushDX.IsDisposed)   {pocBrushDX.Dispose();   pocBrushDX=null;}
			if(RenderTarget!=null) {pocBrushDX = POC_Line_Color.ToDxBrush(RenderTarget);pocBrushDX.Opacity = 0.5f;}

			if(BlackBrushDX!=null   && !BlackBrushDX.IsDisposed)   {BlackBrushDX.Dispose();   BlackBrushDX=null;}
			if(RenderTarget!=null) BlackBrushDX = Brushes.Black.ToDxBrush(RenderTarget);

			if(WhiteBrushDX!=null   && !WhiteBrushDX.IsDisposed)   {WhiteBrushDX.Dispose();   WhiteBrushDX=null;}
			if(RenderTarget!=null) WhiteBrushDX = Brushes.White.ToDxBrush(RenderTarget);

			if(footprintOutlineBrushDX!=null   && !footprintOutlineBrushDX.IsDisposed)   {footprintOutlineBrushDX.Dispose();   footprintOutlineBrushDX=null;}
			if(RenderTarget!=null) footprintOutlineBrushDX = Footprint_OutLine_Brush.ToDxBrush(RenderTarget);

			if(textBrushDX!=null   && !textBrushDX.IsDisposed)   {textBrushDX.Dispose();   textBrushDX=null;}
			if(RenderTarget!=null) textBrushDX = Brushes.White.ToDxBrush(RenderTarget);

			if(askBodyBrushDX!=null   && !askBodyBrushDX.IsDisposed)   {askBodyBrushDX.Dispose();   askBodyBrushDX=null;}
			if(RenderTarget!=null) askBodyBrushDX = AskBody_Brush.ToDxBrush(RenderTarget);

			if(askHighlightBrushDX!=null   && !askHighlightBrushDX.IsDisposed)   {askHighlightBrushDX.Dispose();   askHighlightBrushDX=null;}
			if(RenderTarget!=null) askHighlightBrushDX = AskHighlight_Brush.ToDxBrush(RenderTarget);

			if(bidBodyBrushDX!=null   && !bidBodyBrushDX.IsDisposed)   {bidBodyBrushDX.Dispose();   bidBodyBrushDX=null;}
			if(RenderTarget!=null) bidBodyBrushDX = BidBody_Brush.ToDxBrush(RenderTarget);

			if(bidHighlightBrushDX!=null   && !bidHighlightBrushDX.IsDisposed)   {bidHighlightBrushDX.Dispose();   bidHighlightBrushDX=null;}
			if(RenderTarget!=null) bidHighlightBrushDX = BidHighlight_Brush.ToDxBrush(RenderTarget);

			if(bidHighlightBrushDX!=null   && !bidHighlightBrushDX.IsDisposed)   {bidHighlightBrushDX.Dispose();   bidHighlightBrushDX=null;}
			if(RenderTarget!=null) bidHighlightBrushDX = BidHighlight_Brush.ToDxBrush(RenderTarget);

			if(unfinishedAucBrushDX!=null   && !unfinishedAucBrushDX.IsDisposed)   {unfinishedAucBrushDX.Dispose();   unfinishedAucBrushDX=null;}
			if(RenderTarget!=null) unfinishedAucBrushDX = UnfinishedAuctionsBrush.ToDxBrush(RenderTarget);

			if(lowRangeSinglePrintBrushDX!=null   && !lowRangeSinglePrintBrushDX.IsDisposed)   {lowRangeSinglePrintBrushDX.Dispose();   lowRangeSinglePrintBrushDX=null;}
			if(RenderTarget!=null) lowRangeSinglePrintBrushDX = Brushes.Green.ToDxBrush(RenderTarget);

			if(highRangeSinglePrintBrushDX!=null   && !highRangeSinglePrintBrushDX.IsDisposed)   {highRangeSinglePrintBrushDX.Dispose();   highRangeSinglePrintBrushDX=null;}
			if(RenderTarget!=null) highRangeSinglePrintBrushDX = Brushes.Red.ToDxBrush(RenderTarget);

			if(volHistBrushDX!=null   && !volHistBrushDX.IsDisposed)   {volHistBrushDX.Dispose();   volHistBrushDX=null;}
			if(RenderTarget!=null) {
				volHistBrushDX = Vol_Hist_Color.ToDxBrush(RenderTarget);
				volHistBrushDX.Opacity = vol_hist_opacity;
			}

			if(backBrushDX!=null   && !backBrushDX.IsDisposed)   {backBrushDX.Dispose();   backBrushDX=null;}
			if(RenderTarget!=null) backBrushDX = ATR_Delta_Box_Back_Color.ToDxBrush(RenderTarget);

			if(box_text_BrushDX!=null   && !box_text_BrushDX.IsDisposed)   {box_text_BrushDX.Dispose();   backBrushDX=null;}
			if(RenderTarget!=null) box_text_BrushDX = ATR_Delta_Box_Font_Color.ToDxBrush(RenderTarget);

			if(borderBrushDX!=null   && !borderBrushDX.IsDisposed)   {borderBrushDX.Dispose();   borderBrushDX=null;}
			if(RenderTarget!=null) borderBrushDX = ATR_Delta_Box_Border.Brush.ToDxBrush(RenderTarget);
			#endregion
		}

		SharpDX.Vector2	bidPoint;
		SharpDX.Vector2	askPoint;
		SharpDX.Vector2	tr_last_v1;
		SharpDX.Vector2	tr_last_v2;
		SharpDX.Vector2	tr_last_v3;
		SharpDX.Vector2 triangle_v1;
		SharpDX.Vector2 triangle_v2;
		SharpDX.Vector2 triangle_v3;
		SharpDX.Vector2 textVector;
		SharpDX.RectangleF blockRect;
		SharpDX.DirectWrite.TextLayout atrLayout, imbLayout;
		SharpDX.DirectWrite.TextFormat imbTextFormat;
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
		#region -- ON RENDER --
line = 2242;
try{
            if (HybridView)
                SetZOrder(1000);
            else
                SetZOrder(-1000);

            TimeSpan pc_time	=	Times[0].GetValueAt(CurrentBars[0]).TimeOfDay;
			
			clickChartScale	=	chartScale;
			if (IsInHitTest) 
			{
				return;
			}
			int RecentTPOidx = TPO_Cluster_List.Count-1;
#if NEW_CODE_NOV2018
			#region Update the global rays if they are on the current most profile, and if their levels have changed
			if(TPO_Cluster_List.Count>0){
				if(GlobalVAHL_Rays.Count>0){
					string tagH = string.Format("RayVAH_{0}",TPO_Cluster_List[RecentTPOidx].FirstIndex);
					string tagL = string.Format("RayVAL_{0}",TPO_Cluster_List[RecentTPOidx].FirstIndex);
					if(GlobalVAHL_Rays.ContainsKey(tagH) && TPO_Cluster_List[RecentTPOidx].VAH !=GlobalVAHL_Rays[tagH].Price){
						GlobalVAHL_Rays[tagH].Price = TPO_Cluster_List[RecentTPOidx].VAH;
						GlobalVAHL_Rays[tagH].IsDrawn = false;//forces a redraw of this ray
					}
					if(GlobalVAHL_Rays.ContainsKey(tagL) && TPO_Cluster_List[RecentTPOidx].VAL !=GlobalVAHL_Rays[tagL].Price){
						GlobalVAHL_Rays[tagL].Price = TPO_Cluster_List[RecentTPOidx].VAL;
						GlobalVAHL_Rays[tagL].IsDrawn = false;//forces a redraw of this ray
					}
				}
				if(GlobalArb_Rects.Count>0){
//double test_pts = (int)(DateTime.Now.Second / 10) * TickSize;
					string tag = string.Format("RectArb_{0} ", TPO_Cluster_List[RecentTPOidx].FirstIndex);//Data[0] is the start ABar, Data[1] is the price of the top-edge rectangle
					var keys = GlobalArb_Rects.Where(x => x.Key.StartsWith(tag)).Select(x => x.Key).ToList();
					if(keys!=null && keys.Count>0){
						foreach (var id in keys) {
							if(GlobalArb_Rects[id].SupportOrResistance=='S'){
								if(GlobalArb_Rects[id].TopPrice != TPO_Cluster_List[RecentTPOidx].SupportTopLevel || GlobalArb_Rects[id].BottomPrice != TPO_Cluster_List[RecentTPOidx].SupportBottomLevel){
									GlobalArb_Rects[id].TopPrice    = TPO_Cluster_List[RecentTPOidx].SupportTopLevel;
									GlobalArb_Rects[id].BottomPrice = TPO_Cluster_List[RecentTPOidx].SupportBottomLevel;
									GlobalArb_Rects[id].IsDrawn     = false;//forces a redraw of this rectangle
								}
							}else{//if(GlobalArb_Rects[id].SupportOrResistance=='R'){
								if(GlobalArb_Rects[id].TopPrice != TPO_Cluster_List[RecentTPOidx].ResistanceTopLevel || GlobalArb_Rects[id].BottomPrice != TPO_Cluster_List[RecentTPOidx].ResistanceBottomLevel){
									GlobalArb_Rects[id].TopPrice    = TPO_Cluster_List[RecentTPOidx].ResistanceTopLevel;
									GlobalArb_Rects[id].BottomPrice = TPO_Cluster_List[RecentTPOidx].ResistanceBottomLevel;
									GlobalArb_Rects[id].IsDrawn     = false;//forces a redraw of this rectangle
								}
							}
						}
					}
				}
			}
			#endregion
			#region Draw Global Rays
			if(GlobalVAHL_Rays.Count>0){
				var keys = GlobalVAHL_Rays.Where(x => x.Value.IsDrawn==false).Select(x => x.Key);
				foreach(var tag in keys){
						TriggerCustomEvent(o1 =>{Draw.Ray(this, tag, GlobalVAHL_Rays[tag].DT, GlobalVAHL_Rays[tag].Price, GlobalVAHL_Rays[tag].DT.AddMinutes(1), GlobalVAHL_Rays[tag].Price, true, GlobalVAHL_Rays[tag].TemplateName);},0,null);
						GlobalVAHL_Rays[tag].IsDrawn=true;
				}
				double TicksCurrentTPO = (Math.Round((TPO_Cluster_List[RecentTPOidx].VAH-TPO_Cluster_List[RecentTPOidx].VAL)/TickSize,0));
			}
			#endregion
			#region Draw Global Arb rects
			if(GlobalArb_Rects.Count>0){
				var keys = GlobalArb_Rects.Where(x => x.Value.IsDrawn==false).Select(x => x.Key);
				foreach(var tag in keys){
						TriggerCustomEvent(o1 =>{ Draw.Rectangle(this, tag, GlobalArb_Rects[tag].DTStart, GlobalArb_Rects[tag].TopPrice, (GlobalArb_Rects[tag].DTEnd==DateTime.MaxValue ? Times[0].GetValueAt(CurrentBars[0]).AddDays(1) : GlobalArb_Rects[tag].DTEnd), GlobalArb_Rects[tag].BottomPrice, true, GlobalArb_Rects[tag].TemplateName);},0,null);
						GlobalArb_Rects[tag].IsDrawn=true;
				}
				if(IsFirstTickOfBar){//if this is an untested arb zone, then the right-edge of the rectangle must continue to expand to the current bar
					keys = GlobalArb_Rects.Where(x => x.Value.IsDrawn && x.Value.DTEnd == DateTime.MaxValue).Select(x => x.Key);
					foreach(var tag in keys){
						TriggerCustomEvent(o1 =>{Draw.Rectangle(this, tag, GlobalArb_Rects[tag].DTStart, GlobalArb_Rects[tag].TopPrice, Times[0].GetValueAt(CurrentBars[0]).AddDays(1), GlobalArb_Rects[tag].BottomPrice, true, GlobalArb_Rects[tag].TemplateName);},0,null);
					}
				}
			}
			#endregion
#endif
            //Net Imbalance in right bottom corner.ATR.
			#region Draw Imbalance and ATR box
			string atrText = string.Format("{0}", (ATRMode == ARC_ATRModeEnum.Points ? Math.Round(atr.GetValueAt(CurrentBars[0]), 3) : Math.Round((atr.GetValueAt(CurrentBars[0]) / TickSize), 0)));

			imbTextFormat = ATR_Delta_Box_Font.ToDirectWriteTextFormat();
			imbLayout 	= new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,string.Format("??? {0}", NetImbalanceShow), imbTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
			atrLayout   = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, string.Format("ATR: {0}", atrText), imbTextFormat, (float)(ChartPanel.X + ChartPanel.W), 12f);

			float maxWidth    = (imbLayout.Metrics.Width > atrLayout.Metrics.Width ? imbLayout.Metrics.Width : atrLayout.Metrics.Width)+5f;
			float maxHeight   = imbLayout.Metrics.Height + 10f;
			SharpDX.RectangleF atrRect     = new SharpDX.RectangleF(ChartPanel.W - maxWidth  - 5f, ChartPanel.H - maxHeight - 20f,maxWidth, maxHeight);
			SharpDX.RectangleF imbRect     = new SharpDX.RectangleF(atrRect.X - maxWidth, ChartPanel.H - maxHeight - 20f, maxWidth,maxHeight);
            
line = 2051;
			if(backBrushDX!=null){
	            RenderTarget.FillRectangle(atrRect, backBrushDX);
	            RenderTarget.FillRectangle(imbRect, backBrushDX);
			}
			if(borderBrushDX!=null){
	            RenderTarget.DrawRectangle(atrRect, borderBrushDX, ATR_Delta_Box_Border.Width, ATR_Delta_Box_Border.StrokeStyle);
	            RenderTarget.DrawRectangle(imbRect, borderBrushDX, ATR_Delta_Box_Border.Width, ATR_Delta_Box_Border.StrokeStyle);
			}

            imbTextFormat.TextAlignment = SharpDX.DirectWrite.TextAlignment.Center;
            imbTextFormat.ParagraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center;
			if(box_text_BrushDX!=null){
	            RenderTarget.DrawText(string.Format("??? {0}", NetImbalanceShow), imbTextFormat, imbRect, box_text_BrushDX);
    	        RenderTarget.DrawText(string.Format("ATR: {0}", atrText), imbTextFormat, atrRect, box_text_BrushDX);
			}
			#endregion

			#region -- Render Temporary messages on chart --
			TimeSpan tsMSG;
			float msgY = ChartPanel.H - (1+Messages.Count) *(atrLayout.Metrics.Height + 3f); //Y-coord of first message.  The x-coord is 30
			foreach(var msg in Messages){
				tsMSG = new TimeSpan(DateTime.Now.Ticks - msg.FirstAppearance.Ticks);
				if(tsMSG.Seconds > msg.SecondsToShow){
					msg.FirstAppearance = DateTime.MinValue;
				}else{
					atrLayout   = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg.MsgText, imbTextFormat, (float)(ChartPanel.X + ChartPanel.W), imbTextFormat.FontSize);
					maxWidth    = atrLayout.Metrics.Width + 5f;
					maxHeight   = atrLayout.Metrics.Height + 2f;
					if(WhiteBrushDX!=null && BlackBrushDX!=null){
						blockRect = new SharpDX.RectangleF(30f, msgY, maxWidth, maxHeight);
			            RenderTarget.FillRectangle(blockRect, msg.Background=='W'? WhiteBrushDX : BlackBrushDX);
						RenderTarget.DrawText(msg.MsgText, imbTextFormat, blockRect, msg.Foreground=='W'? WhiteBrushDX : BlackBrushDX);
					}
					msgY = msgY + maxHeight;
				}
			}
			#endregion
			#region -- Initialize --
			int	first_bar_painted	=	ChartBars.FromIndex;
			int	last_bar_painted	=	ChartBars.ToIndex;
			int	total_painted		=	last_bar_painted-first_bar_painted+1;
			//Tick size in pixels
			float								zero_pos					=	(float)((ChartPanel.Y + ChartPanel.H) - ((0 - ChartPanel.MinValue )/ chartScale.MaxMinusMin) * ChartPanel.H);
			float								tick_pos					=	(float)((ChartPanel.Y + ChartPanel.H) - ((TickSize - ChartPanel.MinValue )/ chartScale.MaxMinusMin) * ChartPanel.H);
			float								tick_float					=	Math.Abs(tick_pos-zero_pos);


line = 2072;
            NinjaTrader.Gui.Tools.SimpleFont    TPO_Font                  =   TpoFont;
			TPO_Font.Size = TpoFontSize;

            SharpDX.DirectWrite.TextFormat 		textFormat 					= 	TPO_Font.ToDirectWriteTextFormat();
			SharpDX.DirectWrite.TextFormat 		bottomTextFormat 			= 	new SharpDX.DirectWrite.TextFormat(NinjaTrader.Core.Globals.DirectWriteFactory, "Verdana",
																				SharpDX.DirectWrite.FontWeight.Bold,SharpDX.DirectWrite.FontStyle.Normal, 12);
			
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			#endregion
			for(int abar=first_bar_painted;abar<=last_bar_painted;abar++)
			{
//Print(abar+":  <  FootPrint_List.Count: "+FootPrint_List.Count);
                //if (FootPrint_List.Count > abar)
				{
					DateTime				bar_time				=	chartControl.GetTimeBySlotIndex(abar);
//PrintNoDup(bar_time.ToString()+"     L2548");

					#region TPO RENDER
					List<TPO_Cluster>		currentTPO_ClusterList	=   TPO_Cluster_List.Where(a=>CheckTimeIn(bar_time, a.StartTimeOfSession, a.EndTimeOfSession)==true).ToList();
					int 					list_count				=	currentTPO_ClusterList.Count;
					if (list_count!=0)
					{
line = 2140;
						#region POC,VAH,VAL... pixel values
						float poc_y     = (float)(chartScale.GetYByValue(currentTPO_ClusterList[0].POC));
						float vah_y     = (float)(chartScale.GetYByValue(currentTPO_ClusterList[0].VAH));
						float val_y     = (float)(chartScale.GetYByValue(currentTPO_ClusterList[0].VAL));
						float poc_vol_y = (float)(chartScale.GetYByValue(currentTPO_ClusterList[0].VOLUME_POC));
						float vah_vol_y = (float)(chartScale.GetYByValue(currentTPO_ClusterList[0].VOLUME_VAH));
						float val_vol_y = (float)(chartScale.GetYByValue(currentTPO_ClusterList[0].VOLUME_VAL));

						float line_x = (float)ChartControl.GetXByBarIndex(ChartBars, currentTPO_ClusterList[0].FirstIndex);
						float open_y = chartScale.GetYByValue(currentTPO_ClusterList[0].Open);
						float last_y = chartScale.GetYByValue(currentTPO_ClusterList[0].Last);
						#endregion

line = 2154;
						int bar_index_since_tpo_start			=	abar-currentTPO_ClusterList[0].FirstIndex;
//PrintNoDup("   bars since: "+bar_index_since_tpo_start);
						float x									=	(float)ChartControl.GetXByBarIndex(ChartBars,abar);

						//Last element
						TPO_Cluster_Level last_level			=	null;

						if(currentTPO_ClusterList[0].Cluster_Level_List.Count>0)
							last_level							=	currentTPO_ClusterList[0].Cluster_Level_List[currentTPO_ClusterList[0].Cluster_Level_List.Count-1];

						#region TPO Vertical Lines

						if (!AllSplitMode)
						{
line = 2168;
							if (abar == currentTPO_ClusterList[0].FirstIndex)
							{
								SharpDX.Vector2 st_point_val = new System.Windows.Point(line_x - (float)ChartControl.BarWidth, val_y).ToVector2();
								SharpDX.Vector2 end_point_val = new System.Windows.Point(line_x - (float)ChartControl.BarWidth, vah_y).ToVector2();

								SharpDX.Vector2 volume_va_point1 = new System.Windows.Point(line_x - (float)ChartControl.BarWidth - 4, val_vol_y).ToVector2();
								SharpDX.Vector2 volume_va_point2 = new System.Windows.Point(line_x - (float)ChartControl.BarWidth - 4, vah_vol_y).ToVector2();

								if(currentTPO_ClusterList[0].MAX_Length > 1 && valBrushDX!=null)
									RenderTarget.DrawLine(st_point_val, end_point_val, valBrushDX, 3);
								if(volValueAreaBrushDX!=null)
									RenderTarget.DrawLine(volume_va_point1, volume_va_point2, volValueAreaBrushDX, 3);
							}
						}

						#endregion

line = 2185;
//PrintNoDup("TPO Cluster FirstBar: "+Times[0].GetValueAt(currentTPO_ClusterList[0].FirstIndex).ToString());
						//Loop for every price level in TPO Cluster
						foreach (TPO_Cluster_Level level in currentTPO_ClusterList[0].Cluster_Level_List)
						{
line = 2193;
//PrintNoDup("      level: "+level.PriceLevel.ToString());
							bool c1 = level.LetterList.Count > bar_index_since_tpo_start;
							bool c2 = bar_index_since_tpo_start>=0;
							bool c3 = false;
							//If there is no more TPOs letters on this price on this bar, pass the iteration, continue to the next level
							if (c1 && c2)
							{
								//Y coordinate in pixels
								float y		=	(float)((ChartPanel.Y + ChartPanel.H) - ((level.PriceLevel - ChartPanel.MinValue )/ chartScale.MaxMinusMin) * ChartPanel.H);
								TPOBrushDX	= 	level.PriceLevel==currentTPO_ClusterList[0].POC										?POC_TPO_DX:
												(level.PriceLevel==currentTPO_ClusterList[0].VOLUME_POC)							?VPOC_TPO_DX:
															//(level.PriceLevel==MasterInstrument.RoundPrice(VWAP.GetValueAt(i),TickSize))		?VWAP_TPO_Color.ToDxBrush(RenderTarget):
															//(level.PriceLevel==MasterInstrument.RoundPrice(TWAP.GetValueAt(i),TickSize))		?TWAP_TPO_Color.ToDxBrush(RenderTarget):
									(level.PriceLevel <= currentTPO_ClusterList[0].VAH && level.PriceLevel>=currentTPO_ClusterList[0].VAL)		?VA_TPO_DX:
									(level.PriceLevel>currentTPO_ClusterList[0].VAH && (level.LetterList.Count>1 ))		?VA_Above_DX:
									(level.PriceLevel<currentTPO_ClusterList[0].VAL && (level.LetterList.Count>1 ))		?VA_Below_DX:
									(level.LetterList.Count==1 )			?Single_DX:
																					TransparentBrushDX;
line = 2211;
								if(currentTPO_ClusterList[0].MAX_Length==1)	TPOBrushDX = VA_TPO_DX;
								string 	letter	=	level.LetterList[bar_index_since_tpo_start];

								#region Draw letters for profile view
								if(ProfileView)
								{
									//RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
									var textLayout 	= new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, letter, textFormat, (float)(ChartPanel.X + ChartPanel.W), textFormat.FontSize);
									//SharpDX Vector containing x,y coordinates in pixels
									textVector = new System.Windows.Point(x-textLayout.Metrics.Width/2f,y-textLayout.Metrics.Height/2f).ToVector2();
									//Render text layout
									if(TPOBrushDX != null)
										RenderTarget.DrawTextLayout(textVector, textLayout, TPOBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

line = 2227;
									//Finding high and low of the first tpo column
									if (bar_index_since_tpo_start == 0 && currentTPO_ClusterList[0].AssistMerge)
									{
										if (textVector.Y+textLayout.Metrics.Height > max_tpo_y)
											max_tpo_y = textVector.Y + textLayout.Metrics.Height;
										if (textVector.Y < min_tpo_y)
											min_tpo_y = textVector.Y; 
										if (textLayout.Metrics.Width > max_tpo_width)
											max_tpo_width = textLayout.Metrics.Width;
									}
									//Split Assist - Highlighted letter
									if (IsSplitAssist&&currentTPO_ClusterList[0].AssistSplitLetterIndex!=-1)
									{
										if(letter == tpo_letters_intraday[currentTPO_ClusterList[0].AssistSplitLetterIndex] &&
											level.PriceLevel==currentTPO_ClusterList[0].AssistLevel &&
											letterBrushDX !=null &&
											strokeBrushDX !=null)
										{
											blockRect = new SharpDX.RectangleF(textVector.X-1f, textVector.Y, textLayout.Metrics.Width+2, textLayout.Metrics.Height);
											RenderTarget.FillRectangle(blockRect, letterBrushDX);
											RenderTarget.DrawRectangle(blockRect, strokeBrushDX, LetterHighLighted_Stroke.Width,
											    LetterHighLighted_Stroke.StrokeStyle);
										}
									}
									textLayout.Dispose();
								}
								#endregion
								#region TPO Squares in Hybrid mode, or HybridPrint mode
								else if(TPO_Profile_Enabled && TPOBrushDX!=null)
								{
									TPOBrushDX.Opacity = TPO_Squares_Opacity;
									blockRect = new SharpDX.RectangleF(
											x-(tick_float * currentTPO_ClusterList[0].tpoTicksIncrement>3f?3f:tick_float*0.3f),
											y-(tick_float * currentTPO_ClusterList[0].tpoTicksIncrement>3f?3f:tick_float*0.3f),
											  (tick_float * currentTPO_ClusterList[0].tpoTicksIncrement>3f?6f:tick_float*0.6f),
											  (tick_float * currentTPO_ClusterList[0].tpoTicksIncrement>3f?6f:tick_float*0.6f));
									RenderTarget.FillRectangle(blockRect, TPOBrushDX);
								}
								#endregion
							}

							//Wait until last bar of session or last bar painted occurs to draw volume histogram,lines,support/res levels
							c1 = abar != currentTPO_ClusterList[0].LastBarIndex;
							c2 = abar != last_bar_painted;
							c3 = currentTPO_ClusterList[0].LastBarIndex < last_bar_painted;
//PrintNoDup(bar_time.ToString()+"      c1: "+c1.ToString()+"   c2: "+c2.ToString()+"    c3: "+c3.ToString()+"  LBI: "+currentTPO_ClusterList[0].LastBarIndex);
							if(   !(c1 && (c2 || c3))   )
							{
//PrintNoDup("2679   TPO endtime: "+Times[0].GetValueAt(currentTPO_ClusterList[0].LastBarIndex).ToShortTimeString());
								if(level==last_level)
								{
									if(ProfileView && !AllSplitMode)
									{
										#region TPO Open, Close markers
										triangle_v1 = new System.Windows.Point(line_x-(float)ChartControl.BarWidth, open_y).ToVector2();	
										triangle_v2 = new System.Windows.Point(line_x-(float)ChartControl.BarWidth-OC_MarkerSize, open_y- OC_MarkerSize).ToVector2();
										triangle_v3 = new System.Windows.Point(line_x-(float)ChartControl.BarWidth- OC_MarkerSize, open_y+ OC_MarkerSize).ToVector2();

										tr_last_v1 = new System.Windows.Point(x+(float)ChartControl.BarWidth, last_y).ToVector2();	
										tr_last_v2 = new System.Windows.Point(x+(float)ChartControl.BarWidth+ OC_MarkerSize, last_y- OC_MarkerSize).ToVector2();
										tr_last_v3 = new System.Windows.Point(x+(float)ChartControl.BarWidth+ OC_MarkerSize, last_y+ OC_MarkerSize).ToVector2();

										var pathGeo = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
										var open_triangle = pathGeo.Open();
										open_triangle.BeginFigure(triangle_v1,SharpDX.Direct2D1.FigureBegin.Filled);
										open_triangle.AddLine(triangle_v2);
										open_triangle.AddLine(triangle_v3);
										open_triangle.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
										open_triangle.Close();
										if(valBrushDX!=null) 
											RenderTarget.FillGeometry(pathGeo, valBrushDX);
//PrintNoDup("2701");
										pathGeo = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
										var last_triangle = pathGeo.Open();
										last_triangle.BeginFigure(tr_last_v1,SharpDX.Direct2D1.FigureBegin.Filled);
										last_triangle.AddLine(tr_last_v2);
										last_triangle.AddLine(tr_last_v3);
										last_triangle.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
										last_triangle.Close();
										if(valBrushDX!=null) 
											RenderTarget.FillGeometry(pathGeo, valBrushDX);
										#endregion

										#region Draw Supplemental Marker
										int tpo_cluster_index	=	TPO_Cluster_List.IndexOf(currentTPO_ClusterList[0]);
										if(tpo_cluster_index==TPO_Cluster_List.Count-1||
											(tpo_cluster_index<TPO_Cluster_List.Count-1&&TPO_Cluster_List[tpo_cluster_index+1].LastBarIndex>last_bar_painted))
										{
											float								last_painted_x			=	ChartControl.GetXByBarIndex(ChartBars,last_bar_painted);
											SharpDX.Vector2						st_point_suppmarker		=	new System.Windows.Point(x+(float)ChartControl.BarWidth+4, last_y).ToVector2();
											SharpDX.Vector2						end_point_suppmarker	=	new System.Windows.Point(last_painted_x, last_y).ToVector2();

											Stroke aStroke = new Stroke(SupplementalMarker_Brush, DashStyleHelper.Dash, 2);
											if(RenderTarget!=null)
												aStroke.RenderTarget = RenderTarget;
											if(aStroke.BrushDX!=null)
												RenderTarget.DrawLine(st_point_suppmarker, end_point_suppmarker, aStroke.BrushDX, aStroke.Width,aStroke.StrokeStyle);
										}
										#endregion

										#region Draw Merge Assist
										if (IsSplitAssist && currentTPO_ClusterList[0].AssistMerge)
										{
										    float merge_assist_rect_x = ChartControl.GetXByBarIndex(ChartBars, currentTPO_ClusterList[0].FirstIndex) - max_tpo_width / 2f;
										    blockRect = new SharpDX.RectangleF(merge_assist_rect_x, min_tpo_y, max_tpo_width, max_tpo_y - min_tpo_y);
										    RenderTarget.FillRectangle(blockRect, merge_assist_brushDX);
										    RenderTarget.DrawRectangle(blockRect, merge_assist_brushDX, ProfileMerge_Stroke.Width, ProfileMerge_Stroke.StrokeStyle);

										    max_tpo_y = 0;
										    min_tpo_y = float.MaxValue;

										    max_tpo_width = 0;
										}
										#endregion
									}
			                        #region TPO Lines
			                        if (TPO_Profile_Enabled)
			                        {
			                            SharpDX.Vector2 st_point_poc  = new System.Windows.Point(line_x, poc_y).ToVector2();
			                            SharpDX.Vector2 end_point_poc = new System.Windows.Point(x, poc_y).ToVector2();
			                            SharpDX.Vector2 st_point_val  = new System.Windows.Point(line_x, val_y).ToVector2();
			                            SharpDX.Vector2 end_point_val = new System.Windows.Point(x, val_y).ToVector2();
			                            SharpDX.Vector2 st_point_vah  = new System.Windows.Point(line_x, vah_y).ToVector2();
			                            SharpDX.Vector2 end_point_vah = new System.Windows.Point(x, vah_y).ToVector2();

										if(pocBrushDX != null)
				                            RenderTarget.DrawLine(st_point_poc, end_point_poc, pocBrushDX, 2);
										if(val2BrushDX != null){
				                            RenderTarget.DrawLine(st_point_vah, end_point_vah, val2BrushDX, 2);
				                            RenderTarget.DrawLine(st_point_val, end_point_val, val2BrushDX, 2);
										}
									}
									#endregion
								}
								#region Volume Histogram
								if (Volume_Profile_Enabled)
								{
//PrintNoDup("...drawing volume histo");
									//Drawing volume histogram
									float	gap_between_percent	=	0.8f;
									float	max_volume_length	=	x-line_x;	
									double	cur_volume_percent	=	level.Volume/currentTPO_ClusterList[0].MAX_Volume;
									float	cur_volume_length	=	max_volume_length*(float)cur_volume_percent;
									float	price_y				=	(float)((ChartPanel.Y + ChartPanel.H) - ((level.PriceLevel - ChartPanel.MinValue )/ chartScale.MaxMinusMin) * ChartPanel.H);

									if(volHistBrushDX != null){
										blockRect	= new SharpDX.RectangleF(line_x-(float)ChartControl.BarWidth/2,
											price_y-(tick_float*currentTPO_ClusterList[0].tpoTicksIncrement/2)*gap_between_percent,cur_volume_length,tick_float*currentTPO_ClusterList[0].tpoTicksIncrement*gap_between_percent);
										RenderTarget.FillRectangle(blockRect, volHistBrushDX);
									}
								}
								#endregion
							}
						}
					}
					#endregion
					#region FOOTPRINT RENDER
					if(FootprintEnabled && !ProfileView && !HybridView)
					{
						foreach(BarFootPrint.PriceFootPrint priceFootPrint in FootPrint_List[abar].FootprintList)
						{
							double	price		=	RoundToTick(priceFootPrint.Price, TickSize);
							float   tick_pixels	=	chartScale.GetPixelsForDistance(TickSize);

							float	offset		=	(float)ChartControl.Properties.BarDistance;
							string	ask_vol		=	string.Format("{0}",priceFootPrint.AskVolume);
							string  bid_vol		=	string.Format("{0}",priceFootPrint.BidVolume);
							float	footprint_x	=	(float)(chartControl.GetXByBarIndex(ChartBars,abar)-offset*0.4f);
							float	bid_x		=	footprint_x;
							float	bid_y		=	chartScale.GetYByValue(priceFootPrint.MaxPrice)-tick_pixels*0.5f;
							float	bid_width	=	offset*0.4f;
							float	bid_height	=	tick_pixels*BoxTickIncrement;
							float	ask_x		=	footprint_x+offset*0.4f;
							float	ask_y		=	chartScale.GetYByValue(priceFootPrint.MaxPrice)-tick_pixels*0.5f;
							float	ask_width	=	offset*0.4f;
							float	ask_height	=	tick_pixels*BoxTickIncrement;

							float	bid_center_y	=	bid_y+bid_height/2f;
							float	ask_center_y	=	ask_y+ask_height/2f;

							bool not_high_low	=	priceFootPrint.Price>RoundToTick(Lows[0].GetValueAt(abar)+TickSize, TickSize) && priceFootPrint.Price<RoundToTick(Highs[0].GetValueAt(abar)-TickSize, TickSize);
							bool unfinished		=	(((priceFootPrint.BidVolume!=0&&priceFootPrint.AskVolume!=0 && priceFootPrint.Price==Highs[0].GetValueAt(abar))||
														(priceFootPrint.BidVolume!=0&&priceFootPrint.AskVolume!=0 && priceFootPrint.Price==Lows[0].GetValueAt(abar))) && Bars.Count-1!=abar);

							var 		FootPrint_Format_Bid = 	new SharpDX.DirectWrite.TextFormat(NinjaTrader.Core.Globals.DirectWriteFactory, "Verdana",
															SharpDX.DirectWrite.FontWeight.Normal,SharpDX.DirectWrite.FontStyle.Normal, bid_height-1>0?bid_height-1:1);
							var 		FootPrint_Format_Ask = 	new SharpDX.DirectWrite.TextFormat(NinjaTrader.Core.Globals.DirectWriteFactory, "Verdana",
															SharpDX.DirectWrite.FontWeight.Normal,SharpDX.DirectWrite.FontStyle.Normal, ask_height-1>0?ask_height-1:1);
							double	close	=	Closes[0].GetValueAt(abar);
							double	open	=	Opens[0].GetValueAt(abar);
							bool DrawRectBid	=	(close>=open&&price<=close&&price>=open)||(close<open&&price>=close&&price<=open)||
													(unfinished)||(priceFootPrint.BidHighlightState==1&&not_high_low);
							bool DrawRectAsk	=	(close>=open&&price<=close&&price>=open)||(close<open&&price>=close&&price<=open)||
													(unfinished)||(priceFootPrint.AskHighlightState==1&&not_high_low);
line = 2433;
							if(DrawRectBid && unfinishedAucBrushDX!=null && bidHighlightBrushDX!=null && bidBodyBrushDX!=null && footprintOutlineBrushDX!=null)
							{
								blockRect = new SharpDX.RectangleF(bid_x,bid_y,bid_width,bid_height);
								RenderTarget.FillRectangle(blockRect,(unfinished && UnfinishedAuctionsEnabled)? unfinishedAucBrushDX:
																	(priceFootPrint.BidHighlightState==1 && not_high_low) ? bidHighlightBrushDX:bidBodyBrushDX);
								RenderTarget.DrawRectangle(blockRect, footprintOutlineBrushDX);
							}
							if(DrawRectAsk && unfinishedAucBrushDX!=null && askHighlightBrushDX!=null && askBodyBrushDX!=null && footprintOutlineBrushDX!=null)
							{
								blockRect	=	new SharpDX.RectangleF(ask_x,ask_y,ask_width,ask_height);
								RenderTarget.FillRectangle(blockRect,(unfinished && UnfinishedAuctionsEnabled) ? unfinishedAucBrushDX:
																	(priceFootPrint.AskHighlightState==1 && not_high_low) ? askHighlightBrushDX:askBodyBrushDX);
								RenderTarget.DrawRectangle(blockRect, footprintOutlineBrushDX);
							}
line = 2449;
							if(ChartControl.BarWidth>=10 && bid_height-1>0 && ask_height-1>0)
							{
								SharpDX.DirectWrite.TextLayout 	bidLayout 	= new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,bid_vol, FootPrint_Format_Bid, (float)(ChartPanel.X + ChartPanel.W),bid_height);
								SharpDX.DirectWrite.TextLayout 	askLayout 	= new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,ask_vol, FootPrint_Format_Ask, (float)(ChartPanel.X + ChartPanel.W),ask_height);

								float font_size	=	FootPrint_Format_Bid.FontSize;
								//Suitable font size. May cause perfomance problems!!!
								while(bidLayout.Metrics.Width>bid_width)
								{
									font_size	-= 1;	
									FootPrint_Format_Bid = 	new SharpDX.DirectWrite.TextFormat(NinjaTrader.Core.Globals.DirectWriteFactory, "Verdana",
																SharpDX.DirectWrite.FontWeight.Bold,SharpDX.DirectWrite.FontStyle.Normal, font_size);
									bidLayout 	= new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,bid_vol, FootPrint_Format_Bid, (float)(ChartPanel.X + ChartPanel.W),bid_height);
								}
								font_size	=	FootPrint_Format_Ask.FontSize;
								while(askLayout.Metrics.Width>ask_width)
								{
									font_size	-= 1;	
									FootPrint_Format_Ask = 	new SharpDX.DirectWrite.TextFormat(NinjaTrader.Core.Globals.DirectWriteFactory, "Verdana",
																SharpDX.DirectWrite.FontWeight.Bold,SharpDX.DirectWrite.FontStyle.Normal, font_size);
									askLayout 	= new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,ask_vol, FootPrint_Format_Ask, (float)(ChartPanel.X + ChartPanel.W),ask_height);
								}


								if(textBrushDX!=null && BlackBrushDX!=null){
									bidPoint 	= new System.Windows.Point(bid_x,bid_center_y-bidLayout.Metrics.Height/2f).ToVector2();
									askPoint 	= new System.Windows.Point(ask_x,ask_center_y-askLayout.Metrics.Height/2f).ToVector2();
									RenderTarget.DrawTextLayout(bidPoint,bidLayout,DrawRectBid ? textBrushDX : BlackBrushDX);
									RenderTarget.DrawTextLayout(askPoint,askLayout,DrawRectAsk ? textBrushDX : BlackBrushDX);
								}
							}
line = 2479;
							//Open,Close markers
							float price_y	=	chartScale.GetYByValue(price);
							if(price==Closes[0].GetValueAt(abar) && BlackBrushDX!=null)
							{
								tr_last_v1		=	new System.Windows.Point(footprint_x+offset*0.8f, price_y).ToVector2();	
								tr_last_v2		=	new System.Windows.Point(footprint_x+offset*0.8f+4, price_y-4).ToVector2();
								tr_last_v3		=	new System.Windows.Point(footprint_x+offset*0.8f+4, price_y+4).ToVector2();

								SharpDX.Direct2D1.PathGeometry pathGeo = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
								var last_triangle = pathGeo.Open();
								last_triangle.BeginFigure(tr_last_v1, SharpDX.Direct2D1.FigureBegin.Filled);
								last_triangle.AddLine(tr_last_v2);
								last_triangle.AddLine(tr_last_v3);
								last_triangle.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
								last_triangle.Close();
//PrintNoDup(2894);
								RenderTarget.FillGeometry(pathGeo, BlackBrushDX);
							}
line = 2497;
							if(price==Opens[0].GetValueAt(abar))
							{
								triangle_v1	=	new System.Windows.Point(footprint_x, price_y).ToVector2();	
								triangle_v2	=	new System.Windows.Point(footprint_x-4, price_y-4).ToVector2();
								triangle_v3	=	new System.Windows.Point(footprint_x-4, price_y+4).ToVector2();

								SharpDX.Direct2D1.PathGeometry pathGeo = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
								var open_triangle = pathGeo.Open();
								open_triangle.BeginFigure(triangle_v1,SharpDX.Direct2D1.FigureBegin.Filled);
								open_triangle.AddLine(triangle_v2);
								open_triangle.AddLine(triangle_v3);
								open_triangle.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
								open_triangle.Close();
								if(BlackBrushDX != null)
									RenderTarget.FillGeometry(pathGeo, BlackBrushDX);
//PrintNoDup(2912);
							}
							FootPrint_Format_Bid.Dispose();
							FootPrint_Format_Ask.Dispose();
						}

line = 2518;
						//Bottom text. Imbalance. ATR.
						double	imbalance	=	FootPrint_List[abar].AskNetVolume-FootPrint_List[abar].BidNetVolume;
						float	bar_w		=	ChartControl.Properties.BarDistance;
						float	block_x		=	(float)(chartControl.GetXByBarIndex(ChartBars,abar)-bar_w*0.5f);
						float	block_y		=	ChartPanel.H-15;
						float	block_w		=	ChartControl.Properties.BarDistance;
						float	block_h		=	15;

						blockRect = new SharpDX.RectangleF(block_x,block_y,block_w,block_h);
						if(BlackBrushDX!=null)
							RenderTarget.DrawRectangle(blockRect, BlackBrushDX);
						if(BrushesDXTable[FootPrint_List[abar].ImbalanceBrushID] != null)
							RenderTarget.FillRectangle(blockRect, BrushesDXTable[FootPrint_List[abar].ImbalanceBrushID]);


						bottomTextFormat.TextAlignment = SharpDX.DirectWrite.TextAlignment.Center;
						if(BlackBrushDX != null){
							RenderTarget.DrawTextLayout(new System.Windows.Point((float)(chartControl.GetXByBarIndex(ChartBars,abar))-bar_w*0.5f,ChartPanel.H-15).ToVector2(), 
								new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,imbalance.ToString(), bottomTextFormat, block_w,100f),
								BlackBrushDX);
						}
					}
					#endregion
				}
			}
#if NEW_CODE_NOV2018
			#region - Draw RR box -
			if(this.ShowRR_databox && TPO_Cluster_List.Count>0){
				SharpDX.RectangleF RRTicks_Rect = new SharpDX.RectangleF(atrRect.X - maxWidth, ChartPanel.H - maxHeight*2 - 20f, maxWidth,maxHeight);
				SharpDX.RectangleF RR_Rect      = new SharpDX.RectangleF(ChartPanel.W - maxWidth  - 5f, ChartPanel.H - maxHeight*2 - 20f, maxWidth,maxHeight);
				if(BlackBrushDX != null){
					RenderTarget.FillRectangle(RRTicks_Rect, BlackBrushDX);
					RenderTarget.FillRectangle(RR_Rect, BlackBrushDX);
				}
				if(borderBrushDX != null){
					RenderTarget.DrawRectangle(RRTicks_Rect, borderBrushDX, ATR_Delta_Box_Border.Width, ATR_Delta_Box_Border.StrokeStyle);
					RenderTarget.DrawRectangle(RR_Rect,      borderBrushDX, ATR_Delta_Box_Border.Width, ATR_Delta_Box_Border.StrokeStyle);
				}
				try{
					if(WhiteBrushDX != null){
						double TicksCurrentTPO = (Math.Round((TPO_Cluster_List[RecentTPOidx].VAH-TPO_Cluster_List[RecentTPOidx].VAL)/TickSize,0));
						RenderTarget.DrawText(string.Format("TPO tk: {0}", TicksCurrentTPO.ToString("0")), imbTextFormat, RRTicks_Rect, WhiteBrushDX);
						double rrval = (ATRMode == ARC_ATRModeEnum.Points ? TicksCurrentTPO*TickSize/Math.Round(atr.GetValueAt(CurrentBars[0]), 3) : TicksCurrentTPO/Math.Round((atr.GetValueAt(CurrentBars[0]) / TickSize), 0));
						RenderTarget.DrawText(string.Format("RR: {0}", rrval.ToString("0.0")), imbTextFormat, RR_Rect, WhiteBrushDX);
					}
				}catch(Exception rr){PrintNoDup("rr error: "+rr.ToString());}
			}
			#endregion
#endif
//			List<TPO_Cluster>   UntestedSupportZones       = TPO_Cluster_List.Where(v => v.SupportTested == false&&v.SupportTopLevel < Closes[0].GetValueAt(CurrentBars[0])).OrderByDescending(v=>v.FirstIndex).ToList();
//			List<TPO_Cluster>   UntestedResistanceZones    = TPO_Cluster_List.Where(v => v.ResistanceTested == false && v.ResistanceBottomLevel > Closes[0].GetValueAt(CurrentBars[0])).OrderByDescending(v => v.FirstIndex).ToList();

			bool                isTemplate                 = (SessionZonesMode == 1 && pc_time > american_time) ||
			                                                 (SessionZonesMode == 2 && pc_time > european_time) ||
			                                                 (SessionZonesMode == 3 && pc_time > asia_time);
line = 2757;
			SharpDX.DirectWrite.TextFormat 	labelFormat		= RangeNumbersFont.ToDirectWriteTextFormat();


line = 2905;
			var SellAlertsEnabled = SellZoneWAV.Length>0 && SellZoneWAV!="none";
			var BuyAlertsEnabled = BuyZoneWAV.Length>0 && BuyZoneWAV!="none";

line = 2910;
			bool RecalcScreenCoord = ShowZonesClickedJustNow==true ? true : false;
#if NEW_CODE_NOV2018
			#region Determine if screen has been resized
			if(chartScale.MinValue      != MM.ChartMinPrice) RecalcScreenCoord=true;
			else if(IsFirstTickOfBar) RecalcScreenCoord=true;
			else if(chartScale.MaxValue != MM.ChartMaxPrice) RecalcScreenCoord=true;
			else if(first_bar_painted   != MM.ChartMinABar)  RecalcScreenCoord=true;
			else if(last_bar_painted    != MM.ChartMaxABar)  RecalcScreenCoord=true;
			else if(TPO_Cluster_List.Count != MM.TPOCount)   RecalcScreenCoord=true;
			if(RecalcScreenCoord){
				Visible_ResArbs.Clear();
				Visible_SupArbs.Clear();
			}
			#endregion
#endif

			#region - Zones -
			if ((ShowFreshZones || ShowBrokenZones))
			{
				foreach (TPO_Cluster TPO in TPO_Cluster_List)
				{
					if(TPO_Cluster_List.Last().SessionBeginDate == TPO.SessionBeginDate) continue;
line = 2586;
					int tpo_index				=   TPO_Cluster_List.IndexOf(TPO);
					int tpo_count				=   TPO_Cluster_List.Count;

					TPO_Cluster TPO_Next_Day	= TPO_Cluster_List.First(x => x.SessionBeginDate > TPO.SessionBeginDate);
					double next_tpo_open  = TPO_Next_Day.Open;

					bool SupportOverlapped		= TPO_Cluster_List.Where(v=>v.SessionBeginDate==TPO.SessionBeginDate
													&& v.FirstIndex>TPO.FirstIndex)
																				.Any(v=>(v.VAL <= TPO.SupportBottomLevel && v.VAH >= TPO.SupportBottomLevel)||
																						(v.VAL <= TPO.SupportTopLevel    && v.VAH >= TPO.SupportTopLevel)||	
																						(v.VOLUME_VAL <= TPO.SupportBottomLevel && v.VOLUME_VAH >= TPO.SupportBottomLevel)||
																						(v.VOLUME_VAL <= TPO.SupportTopLevel    && v.VOLUME_VAH >= TPO.SupportTopLevel));
					bool ResOverlapped 		   = TPO_Cluster_List.Where(v=>v.SessionBeginDate==TPO.SessionBeginDate
													&& v.FirstIndex>TPO.FirstIndex)
																				.Any(v=>(v.VAL <= TPO.ResistanceBottomLevel && v.VAH >= TPO.ResistanceBottomLevel)||
																						(v.VAL <= TPO.ResistanceTopLevel    && v.VAH >= TPO.ResistanceTopLevel)||	
																						(v.VOLUME_VAL <= TPO.ResistanceBottomLevel && v.VOLUME_VAH >= TPO.ResistanceBottomLevel)||
																						(v.VOLUME_VAL <= TPO.ResistanceTopLevel    && v.VOLUME_VAH >= TPO.ResistanceTopLevel));


					bool SupportBroken    = ((TPO.IsSupportBroken    || TPO.SupportTested)     && ShowBrokenZones);
					bool ResistanceBroken = ((TPO.IsResistanceBroken || TPO.ResistanceTested)  && ShowBrokenZones);
                    bool SupportFresh     = (!TPO.IsSupportBroken    && !TPO.SupportTested)    && ShowFreshZones && TPO.SupportBottomLevel < GetCurrentBid();
                    bool ResistanceFresh  = (!TPO.IsResistanceBroken && !TPO.ResistanceTested) && ShowFreshZones && TPO.ResistanceTopLevel > GetCurrentBid();
line = 2615;
					float line_x = ChartControl.GetXByBarIndex(ChartBars, TPO.FirstIndex);

					#region - Support Zones -
					if ((SupportBroken || SupportFresh) &&
					    !TPO.IsSupDisqualified && 
					    (double.IsNaN(next_tpo_open) || next_tpo_open > TPO.SupportTopLevel) && 
						!SupportOverlapped)
					{
line = 2624;
						float val_rect_x      = line_x;  
						float val_rect_x2     = TPO.SupportTested ? chartControl.GetXByBarIndex(ChartBars, TPO.SupportEndIdx) : ChartPanel.W;
						float val_rect_width  = val_rect_x2 - line_x;
						float val_rect_y      = chartScale.GetYByValue(TPO.SupportTopLevel);
						float val_rect_height = chartScale.GetPixelsForDistance(TPO.SupportTopLevel - TPO.SupportBottomLevel);
						blockRect = new SharpDX.RectangleF(line_x, val_rect_y, val_rect_width, val_rect_height);
#if NEW_CODE_NOV2018
						if(RecalcScreenCoord) Visible_SupArbs[TPO.FirstIndex] = new VisibleRectsData(val_rect_y, val_rect_y+val_rect_height,TPO.SupportTested ? TPO.SupportEndIdx : int.MaxValue, TPO.SupportTopLevel, TPO.SupportBottomLevel);
#endif
						if(SupTestedBrushDX != null && SupBrushDX != null)
							RenderTarget.FillRectangle(blockRect, TPO.SupportTested ? SupTestedBrushDX : SupBrushDX);
						if(SupTestedStrokeBrushDX != null && SupStrokeBrushDX != null)
							RenderTarget.DrawRectangle(blockRect, TPO.SupportTested ? SupTestedStrokeBrushDX:SupStrokeBrushDX, TPO.SupportTested ?SupportTestedZoneBorder.Width:SupportZoneBorder.Width, TPO.SupportTested ?SupportTestedZoneBorder.StrokeStyle:SupportZoneBorder.StrokeStyle);
#if NEW_CODE_NOV2018
						double arb_price = TPO.SupportTopLevel+FrontRunPts;
						if(!TPO.SupportTested && BuyAlertsEnabled){
							if(pPlayOnFrontRunHit && !UntestedSupPrices.ContainsKey(arb_price) && arb_price < Lows[0].GetValueAt(CurrentBars[0]))
									UntestedSupPrices[arb_price] = 'F';
							if(pPlayOnZoneHit){
								arb_price = TPO.SupportTopLevel;
								if(!UntestedSupPrices.ContainsKey(arb_price) && arb_price < Lows[0].GetValueAt(CurrentBars[0]))
									UntestedSupPrices[arb_price] = 'Z';
							}
						}
#endif
						string SupportBottomLevelText = AreBonds ? BondsPrice(TPO.SupportBottomLevel) : TPO.SupportBottomLevel.ToString();
						string SupportTopLevelText    = AreBonds ? BondsPrice(TPO.SupportTopLevel) : TPO.SupportTopLevel.ToString();
line = 2647;
//						try{
						if (ShowRangeNumbers)
						{
							#region Show VAL range numbers
							SharpDX.DirectWrite.TextLayout botLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, SupportBottomLevelText,
							        labelFormat, (float)ChartPanel.W, (float)ChartPanel.H);
							SharpDX.DirectWrite.TextLayout topLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, SupportTopLevelText,
							        labelFormat, (float)ChartPanel.W, (float)ChartPanel.H);

							float bottom_x1 = val_rect_x2 - botLayout.Metrics.Width - 5f;
							float bottom_y1 = val_rect_y + val_rect_height + 5f;
							float top_x1 = val_rect_x2 - topLayout.Metrics.Width - 5f;
							float top_y1 = val_rect_y - topLayout.Metrics.Height - 5f;

							if(labelBrushDX!=null){
								RenderTarget.DrawTextLayout(new SharpDX.Vector2(bottom_x1, bottom_y1), botLayout, labelBrushDX);
								RenderTarget.DrawTextLayout(new SharpDX.Vector2(top_x1, top_y1), topLayout, labelBrushDX);
							}
							#endregion
						}
//						}catch(Exception e2481){
//							if(ErrorPrintCount==0) PrintNoDup(line+":  e2481 "+e2481.ToString());}
//							ErrorPrintCount++;
					}
					#endregion
line = 2668;
					#region - Resistance Zones -
					if ((ResistanceBroken || ResistanceFresh) &&
					    !TPO.IsResDisqualified && 
					    (double.IsNaN(next_tpo_open) || next_tpo_open < TPO.ResistanceBottomLevel) && 
						!ResOverlapped)
					{
						float vah_rect_x      = line_x;
						float vah_rect_x2     = TPO.ResistanceTested ? chartControl.GetXByBarIndex(ChartBars, TPO.ResistanceEndIdx) : ChartPanel.W;
						float vah_rect_width  = vah_rect_x2 - line_x;
						float vah_rect_y      = chartScale.GetYByValue(TPO.ResistanceTopLevel);
						float vah_rect_height = chartScale.GetPixelsForDistance(TPO.ResistanceTopLevel - TPO.ResistanceBottomLevel);
						blockRect = new SharpDX.RectangleF(line_x, vah_rect_y, vah_rect_width, vah_rect_height);
#if NEW_CODE_NOV2018
						if(RecalcScreenCoord) Visible_ResArbs[TPO.FirstIndex] = new VisibleRectsData(vah_rect_y, vah_rect_y+vah_rect_height,TPO.ResistanceTested ? TPO.ResistanceEndIdx : int.MaxValue, TPO.ResistanceTopLevel, TPO.ResistanceBottomLevel);
#endif
						if(ResTestedBrushDX != null && ResBrushDX != null)
							RenderTarget.FillRectangle(blockRect, TPO.ResistanceTested ? ResTestedBrushDX : ResBrushDX);
						if(ResTestedStrokeBrushDX != null && ResStrokeBrushDX != null)
							RenderTarget.DrawRectangle(blockRect, TPO.ResistanceTested ? ResTestedStrokeBrushDX :ResStrokeBrushDX, TPO.ResistanceTested ?ResistanceTestedZoneBorder.Width :ResistanceZoneBorder.Width, TPO.ResistanceTested ?ResistanceTestedZoneBorder.StrokeStyle :ResistanceZoneBorder.StrokeStyle);
#if NEW_CODE_NOV2018
						double arb_price = TPO.ResistanceBottomLevel-FrontRunPts;
						if(!TPO.ResistanceTested && SellAlertsEnabled){
							if(pPlayOnFrontRunHit && !UntestedResPrices.ContainsKey(arb_price) && arb_price > Highs[0].GetValueAt(CurrentBars[0]))
								UntestedResPrices[arb_price] = 'F';
							if(pPlayOnZoneHit){
								arb_price = TPO.ResistanceBottomLevel;
								if(!UntestedResPrices.ContainsKey(arb_price) && arb_price > Highs[0].GetValueAt(CurrentBars[0]))
									UntestedResPrices[arb_price] = 'Z';
							}
						}
#endif
						string ResistanceBottomLevelText = AreBonds ? BondsPrice(TPO.ResistanceBottomLevel) : TPO.ResistanceBottomLevel.ToString();
						string ResistanceTopLevelText    = AreBonds ? BondsPrice(TPO.ResistanceTopLevel) : TPO.ResistanceTopLevel.ToString();

						if (ShowRangeNumbers)
						{
							#region Show VAL range numbers
							SharpDX.DirectWrite.TextLayout botLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, ResistanceBottomLevelText,
								labelFormat, (float)ChartPanel.W, (float)ChartPanel.H);
							SharpDX.DirectWrite.TextLayout topLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, ResistanceTopLevelText,
								labelFormat, (float)ChartPanel.W, (float)ChartPanel.H);

							float bottom_x1 = vah_rect_x2 - botLayout.Metrics.Width - 5f;
							float bottom_y1 = vah_rect_y + vah_rect_height + 5f;
							float top_x1 = vah_rect_x2 - topLayout.Metrics.Width - 5f;
							float top_y1 = vah_rect_y - topLayout.Metrics.Height - 5f;

							if(labelBrushDX != null){
								RenderTarget.DrawTextLayout(new SharpDX.Vector2(bottom_x1, bottom_y1), botLayout, labelBrushDX);
								RenderTarget.DrawTextLayout(new SharpDX.Vector2(top_x1, top_y1), topLayout, labelBrushDX);
							}
							#endregion
						}
					}
					#endregion
				}
			}
			ShowZonesClickedJustNow = false;
			#endregion
line = 3037;
#if NEW_CODE_NOV2018
			#region - Audible alerts on zones -
			if(PriorPrice!=double.MinValue){// && alertTS.Seconds>10){
				int alert_count=0;
				foreach(var SupPrice in UntestedSupPrices){
					if(Lows[0].GetValueAt(CurrentBars[0]) <= SupPrice.Key){
						Alert(DateTime.Now.Ticks.ToString(), Priority.High, (SupPrice.Value=='Z' ? "Hit TPO BuyZone @ " : "Nearing TPO BuyZone @ ")+Instrument.MasterInstrument.FormatPrice(SupPrice.Key), AddSoundFolder(BuyZoneWAV), 0, Brushes.Green, Brushes.White);
						alert_count++;
						break;
					}
				}
				foreach(var ResPrice in UntestedResPrices){
					if(Highs[0].GetValueAt(CurrentBars[0]) >= ResPrice.Key){
						Alert(DateTime.Now.Ticks.ToString(), Priority.High, (ResPrice.Value=='Z' ? "Hit TPO SellZone @ " : "Nearing TPO SellZone @ ")+Instrument.MasterInstrument.FormatPrice(ResPrice.Key), AddSoundFolder(SellZoneWAV), 0, Brushes.Maroon, Brushes.White);
						alert_count++;
						break;
					}
				}
				if(alert_count>0){
					UntestedResPrices.Clear();
					UntestedSupPrices.Clear();
				}
			}
			PriorPrice = Closes[0].GetValueAt(CurrentBars[0]);
			#endregion
#endif
			#region - Dispose -
			if(!imbTextFormat.IsDisposed)    imbTextFormat.Dispose();    imbTextFormat=null;
			if(!imbLayout.IsDisposed)        imbLayout.Dispose();        imbLayout=null;
			if(!atrLayout.IsDisposed)        atrLayout.Dispose();        atrLayout=null;
			if(!textFormat.IsDisposed)       textFormat.Dispose();	     textFormat=null;
			if(!bottomTextFormat.IsDisposed) bottomTextFormat.Dispose(); bottomTextFormat=null;
			if(!labelFormat.IsDisposed)      labelFormat.Dispose();      labelFormat=null;
			#endregion
			
#if NEW_CODE_NOV2018
			#region - Draw Global Rays on TPO VAH/L and Global rectangles for Arb Regions -
			if(RecalcScreenCoord && GlobalSR_Enabled){
				MM.ChartMinPrice = chartScale.MinValue;
				MM.ChartMaxPrice = chartScale.MaxValue;
				MM.ChartMinABar  = first_bar_painted;
				MM.ChartMaxABar  = last_bar_painted;
				MM.TPOCount = TPO_Cluster_List.Count;
				for(int idx=0; idx< TPO_Cluster_List.Count; idx++){
					TPO_Cluster_List[idx].VA_ScreenX  = ChartControl.GetXByBarIndex(ChartBars, TPO_Cluster_List[idx].FirstIndex);
					TPO_Cluster_List[idx].VA_ScreenYt = chartScale.GetYByValue(TPO_Cluster_List[idx].VAH);
					TPO_Cluster_List[idx].VA_ScreenYb = chartScale.GetYByValue(TPO_Cluster_List[idx].VAL);
line = 3159;
				}
			}
			if(MM.HoverIndex>=0 && GlobalSR_Enabled && YellowBrushDX!=null){
				if(MM.SelectedArbZoneData!=null){
					float arbX    = ChartControl.GetXByBarIndex(ChartBars, Math.Max(ChartBars.FromIndex+2, (int)MM.SelectedArbZoneData[0]));
					float arbYtop = chartScale.GetYByValue(MM.SelectedArbZoneData[1]);
					float arbYbot = chartScale.GetYByValue(MM.SelectedArbZoneData[3]);
					float radius  = (arbYbot-arbYtop)/2f;
					RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(arbX, arbYtop+radius), 5f, radius), YellowBrushDX);
				}else{//draw ovals on TPO ValueArea for auto-Ray drawing
					RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(
						new SharpDX.Vector2(TPO_Cluster_List[MM.HoverIndex].VA_ScreenX, TPO_Cluster_List[MM.HoverIndex].VA_ScreenYt),
						10f,5f), YellowBrushDX);
					RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(
						new SharpDX.Vector2(TPO_Cluster_List[MM.HoverIndex].VA_ScreenX, TPO_Cluster_List[MM.HoverIndex].VA_ScreenYb),
						10f,5f), YellowBrushDX);
				}
			}
			#endregion
#endif
			RenderTarget.AntialiasMode = oldAntialiasMode;

			if(HybridView || HybridPrintView) base.OnRender(chartControl, chartScale);

line = 2939;
			if (HybridView)
			    SetZOrder(1000);
			else
			    SetZOrder(-1000);
}catch(Exception ore){PrintNoDup(line+":  "+ore.ToString());}
		#endregion
        }//return - end onrender

//---------------------------------- OnRender finished ---------------------------------------------------
		#region MOUSE LEFT CLICK HANDLER
		void OnLeftClick(object sender,MouseEventArgs mouse)
		{
            double x = ChartControl.MouseDownPoint.X.ConvertToHorizontalPixels(ChartControl.PresentationSource);
            double y = ChartingExtensions.ConvertToVerticalPixels(mouse.GetPosition(ChartPanel as IInputElement).Y, ChartControl.PresentationSource);
			
			if(!Keyboard.IsKeyDown(Key.LeftCtrl))
				SplitFromCLick((int)x,(float)y);
			else
				MergeFromCLick((int)x,(float)y);
		}
		#endregion
		
		#region SPLIT MERGE TPO FUNCTIONS
		
		    #region SplitFromClick
		    public void SplitFromCLick(int X, float Y)
		    {
				if(IsSplittingLocked) return;
                if (AllSplitMode)
                    return;
                if (!IsManualSplitMerge)
                    return;
                double Custom_TickSize = TPO_Ticks_Increment * TickSize;
                bool debug = false;
                if (clickChartScale == null) return;
                List<string> tpo_letters_intraday = new List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
                                "p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P"};
                List<string> tpo_letters_day = new List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
                                "p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","1","2","3","4","5"
            ,"6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36",
                "37","38","39","40","41","42","43","44"};

                List<string> tpo_letters = DailyMode ? tpo_letters_day : tpo_letters_intraday;
                //If there are no TPOs exit
                if (TPO_Cluster_List.Count == 0)
                    return;


                #region Click Handle
                //1. Index of clicked bar
                int click_index = (int)ChartBars.GetBarIdxByX(ChartControl, X);
                if (debug)
                    PrintNoDup(String.Format("1. User clicked on bar number {0} {1}", click_index, ChartControl.GetSlotIndexByX(X)));

                //2. if user clicked not on bars area - exit
                if (click_index > CurrentBars[0] || click_index < 0)
                {
                    if (debug)
                        PrintNoDup(String.Format("Warning! User didn't clicked bars region. Function stopped.", 0));
                    return;
                }


                //3. Date of the clicked bar
                DateTime click_time = BarsArray[0].GetTime(click_index);
                if (debug)
                    PrintNoDup(String.Format("2. Date of the bar user clicked {0}", click_time));

                //4 .Click price
                double click_price = RoundToTick(clickChartScale.GetValueByY(Y), TickSize);


                if (debug)
                    PrintNoDup(String.Format("3. Price of the bar user clicked {0}", click_price));


                //5. Finding TPO that the user clicked on in the list of all TPO's  
                List<TPO_Cluster> currentTPO_ClusterList = TPO_Cluster_List.Where(a => CheckTimeIn(click_time, a.StartTimeOfSession, a.EndTimeOfSession) == true).ToList();


                int list_count = currentTPO_ClusterList.Count;

                //If click was not in TPO area - exit
                if (list_count == 0)
                {
                    if (debug)
                        PrintNoDup(String.Format("Warning! User didn't clicked TPO region. Function stopped.", click_price));
                    return;
                }

                //If click was on the first column of the TPO - exit
                if (currentTPO_ClusterList[0].FirstIndex == click_index)
                {
                    if (debug)
                        PrintNoDup(String.Format("Warning! User clicked first TPO column. FirstIndex - {0}. Function stopped.", currentTPO_ClusterList[0].FirstIndex));
                    return;
                }



                double max = double.MinValue;
                double min = double.MaxValue;

                //?
                //			int						max_index				=	60;
                //			int						tpo_index				=	0;
                //6. Find the TPO relative click index (not ChartBars index)
                int split_start_index = click_index - currentTPO_ClusterList[0].FirstIndex;
                int max_index = 1000;
                int tpo_index = 0;

                if (split_start_index < 0)
                {
                    if (debug)
                        PrintNoDup(String.Format("Warning! split_start_index < 0. split_start_index - {0}. Function stopped.", split_start_index));
                    return;
                }

                click_price = RoundToTick(RoundToSomeValue(Custom_TickSize, click_price, currentTPO_ClusterList[0].Cluster_Level_List[0].PriceLevel), TickSize);

                if (debug)
                    PrintNoDup("Rounded click price = " + click_price + " " + RoundToSomeValue(Custom_TickSize, click_price, currentTPO_ClusterList[0].Cluster_Level_List[0].PriceLevel));

                //7. Find max price and min price of the clicked TPO column
                foreach (TPO_Cluster_Level level in currentTPO_ClusterList[0].Cluster_Level_List)
                {
                    if (level.LetterList.Count <= split_start_index)
                        continue;

                    if (level.LetterList[split_start_index] != "0")
                    {
                        if (level.PriceLevel > max)
                            max = level.PriceLevel;
                        if (level.PriceLevel < min)
                            min = level.PriceLevel;
                    }
                }

                //If click was out of the TPO column - exit
                if (click_price > max || click_price < min || (max == double.MinValue && min == double.MaxValue))
                {
                    if (debug)
                        PrintNoDup(String.Format("Warning! User didn't click on the letter. Max - {0}, Min - {1}, click_price - {2} Function stopped.", max, min, click_price));
                    return;
                }

                #endregion

                if (debug)
                    PrintNoDup("inputs " + Custom_TickSize + " " + click_price + " " + currentTPO_ClusterList[0].Cluster_Level_List[0].PriceLevel);



                //9. Finding the min TPO letter in clicked TPO column
                for (int i = 0; i < currentTPO_ClusterList[0].Cluster_Level_List.Count; i++)
                {
                    if (debug)
                        PrintNoDup("price level = " + currentTPO_ClusterList[0].Cluster_Level_List[i].PriceLevel + " " + click_price + " " + (currentTPO_ClusterList[0].Cluster_Level_List[i].PriceLevel == click_price));
                    int index;

                    if (currentTPO_ClusterList[0].Cluster_Level_List[i].PriceLevel == click_price &&
                        currentTPO_ClusterList[0].Cluster_Level_List[i].LetterList.Count > split_start_index)
                    {

                        max_index = tpo_letters.IndexOf(currentTPO_ClusterList[0].Cluster_Level_List[i].LetterList[split_start_index]);
                        if (debug)
                            PrintNoDup(String.Format("5. Letter index that user clicked was found {0}", max_index));
                    }
                }
                if (max_index == 1000)
                {
                    if (debug)
                        PrintNoDup(String.Format("Warning! User didn't click the letter", max_index));
                    return;
                }
                if (debug)
                    PrintNoDup(String.Format("5_1. Letter index checking - {0}", max_index));



                SplitByLetter(currentTPO_ClusterList[0], max_index);
                //AutoSplit(currentTPO_ClusterList[0]);

                DateTime sb = currentTPO_ClusterList[0].SessionBeginDate;

                if (IsSplitAssist &&
                    sb != CurrentSessionBegin)
                    SplitAssist(sb, false);

				//DetermineDisqualifiedZones();
				CleanUpOrphanedRaysAndRectangles();
                ForceRefresh();
            }
		    #endregion

		    #region MergeFromClick
		    public void MergeFromCLick(int X, float Y)
		    {
				if(IsSplittingLocked) return;
                #region Click Handle
                if (!IsManualSplitMerge)
                    return;

                if (clickChartScale==null) return;

			    //1. Click index
			    int			click_index	=	(int)ChartControl.GetSlotIndexByX(X);
			    if(click_index>CurrentBars[0]||click_index<0)
				    return;

			    //2. Click time and price
			    DateTime	click_time	=	BarsArray[0].GetTime(click_index);
			    double		click_price		=	RoundToTick(clickChartScale.GetValueByY(Y), TickSize);

			    //3. Finding clicked TPO 
			    if(TPO_Cluster_List.Count==0) 
			    {
				    return;
			    }
			    List<TPO_Cluster>		currentTPO_ClusterList	=   TPO_Cluster_List.Where(a=>CheckTimeIn(click_time, a.StartTimeOfSession, a.EndTimeOfSession)==true).ToList();
			    int 					list_count				=	currentTPO_ClusterList.Count;
			    if(list_count==0) return;

			    //4. Index of TPO to delete
			    int		cluster_index_delete	=	TPO_Cluster_List.IndexOf(currentTPO_ClusterList[0]);	

			    double max = double.MinValue;
			    double min = double.MaxValue;

			    int split_start_index	=	click_index	-currentTPO_ClusterList[0].FirstIndex;	

			    if(split_start_index<0) return;

			    //5. Max and min of clicked TPO column
			    foreach(TPO_Cluster_Level level in currentTPO_ClusterList[0].Cluster_Level_List)
			    {
				    if(level.LetterList.Count<=split_start_index)
					    continue;
				    if(level.LetterList[split_start_index]!="0")
				    {
					    if(level.PriceLevel>max)
						    max = level.PriceLevel;
					    if(level.PriceLevel<min)
						    min = level.PriceLevel;
				    }	
			    }
			    if(click_price>max||click_price<min||(max==double.MinValue&&min==double.MaxValue))
				    return;
                #endregion

			    MergeBack(currentTPO_ClusterList[0]);

                DateTime sb = currentTPO_ClusterList[0].SessionBeginDate;

                if (IsSplitAssist &&
                    sb != CurrentSessionBegin)
                    SplitAssist(sb,false);

				//DetermineDisqualifiedZones();
				CleanUpOrphanedRaysAndRectangles();
                ForceRefresh();
		    }
		    #endregion

		    #region SplitByLetter
		    private void SplitByLetter(TPO_Cluster SplitTPO,int split_index)
		    {
                bool debug = false;
                List<string> tpo_letters_intraday = new List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
                                "p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P"};
                List<string> tpo_letters_day = new List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
                                "p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","1","2","3","4","5"
            ,"6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36",
                "37","38","39","40","41","42","43","44"};

                List<string> tpo_letters = DailyMode ? tpo_letters_day : tpo_letters_intraday;

                //int	split_index					=	tpo_letters.IndexOf(letter);
                //index of current TPO in the TPO list
                int TPO_Cluster_Index = TPO_Cluster_List.IndexOf(SplitTPO);
                //Find session begin for the next splitted TPO
                DateTime sessionBegin = SplitTPO.StartTimeOfSession;//DailyMode?Bars.GetTime(currentTPO_ClusterList[0].DetermineBarIndex(split_index))
                                                                    //:currentTPO_ClusterList[0].DetermineTime(split_index);
                DateTime sessionEnd = SplitTPO.EndTimeOfSession;
                //Start point for the next splitted TPO
                double StartPoint = SplitTPO.StartPoint;
                int max_tpo_letter_new = 0;
                int max_tpo_letter_old = 0;
                int min_tpo_old_index = Int32.MaxValue;
                int increment = SplitTPO.tpoTicksIncrement;

                //			if(debug)
                //				PrintNoDup(String.Format("6. Properties for the next TPO are calculating. sessionBegin - {0}, sessionEnd - {1}, FirstIndex - {2}, StartPoint - {3}"
                //									,sessionBegin,sessionEnd,0,StartPoint));


                //11. Insert new TPO in TPO list.
                TPO_Cluster_List.Insert(TPO_Cluster_Index + 1, new TPO_Cluster(SplitTPO.SessionBeginDate, SplitTPO.SessionEndDate, sessionBegin, sessionEnd,
                    TPO_Period, 0, StartPoint, 0, TickSize, increment, Opens[0].GetValueAt(0), DailyMode));
                if (debug)
                    PrintNoDup(String.Format("SplitByLetter. New TPO was inserted", split_index));

                if (debug)
                    PrintNoDup(String.Format("SplitByLetter. Adding values to new TPO started", split_index));

                #region Copying values to new TPO
                for (int i = 0; i < SplitTPO.Cluster_Level_List.Count; i++)
                {
                    for (int z = 0; z < SplitTPO.Cluster_Level_List[i].LetterList.Count; z++)
                    {
                        string lett = SplitTPO.Cluster_Level_List[i].LetterList[z];
                        int idx = tpo_letters.IndexOf(lett);
                        double level = SplitTPO.Cluster_Level_List[i].PriceLevel;

                        if (idx >= split_index)
                        {
                            //						if(debug)
                            //							PrintNoDup(String.Format("Adding level{3} letter{4}: lett - {0}, idx - {1}, level - {2}",lett,idx,level,i,z));	
                            TPO_Cluster_List[TPO_Cluster_Index + 1].AddLevel(level, lett, SplitTPO.Cluster_Level_List[i].Volume_Letter, 0, pVASize_Pct);
                            //last value tpo index in new cluster
                            if (idx > max_tpo_letter_new)
                            {
                                max_tpo_letter_new = idx;
                            }
                        }
                        else
                        {
                            //last value tpo index in old cluster
                            if (idx > max_tpo_letter_old)
                            {
                                max_tpo_letter_old = idx;
                            }
                        }

                        //Min letter indx in old TPO
                        if (idx < min_tpo_old_index)
                        {
                            min_tpo_old_index = idx;
                        }
                    }
                }
                #endregion

                if (debug)
                    PrintNoDup(String.Format("SplitByLetter. Adding values to new TPO 1Tick started", split_index));

                #region Copying values to new TPO 1Tick
                for (int i = 0; i < SplitTPO.Cluster_Level_List_1Tick.Count; i++)
                {
                    for (int z = 0; z < SplitTPO.Cluster_Level_List_1Tick[i].LetterList.Count; z++)
                    {
                        string lett = SplitTPO.Cluster_Level_List_1Tick[i].LetterList[z];
                        int idx = tpo_letters.IndexOf(lett);
                        double level = SplitTPO.Cluster_Level_List_1Tick[i].PriceLevel;

                        if (idx >= split_index)
                        {
                            //						if(debug)
                            //							PrintNoDup(String.Format("Adding level{3} letter{4}: lett - {0}, idx - {1}, level - {2}",lett,idx,level,i,z));	
                            TPO_Cluster_List[TPO_Cluster_Index + 1].AddLevel(level, lett, SplitTPO.Cluster_Level_List_1Tick[i].Volume_Letter, 1, pVASize_Pct);

                        }
                    }
                }
                #endregion

                #region Removing values from old TPO
                if (debug)
                    PrintNoDup(String.Format("SplitByLetter. Removing old values from old TPO started.", 0));
                //13. Removing old values that were already copied to new TPO from the old TPO.
                for (int i = SplitTPO.Cluster_Level_List.Count - 1; i >= 0; i--)
                {
                    for (int z = SplitTPO.Cluster_Level_List[i].LetterList.Count - 1; z >= 0; z--)
                    {
                        string lett = SplitTPO.Cluster_Level_List[i].LetterList[z];
                        int idx = tpo_letters.IndexOf(lett);
                        if (idx >= split_index)
                        {
                            //						if(debug)
                            //							PrintNoDup(String.Format("Removing level{2} letter{3}: lett - {0}, idx - {1}",lett,idx,i,z));
                            //Removing letter volume. For this purposes Volume_Letter was created. 
                            SplitTPO.Cluster_Level_List[i].Volume -= SplitTPO.Cluster_Level_List[i].Volume_Letter[lett];
                            SplitTPO.Cluster_Level_List[i].Volume_Letter.Remove(lett);
                            SplitTPO.Cluster_Level_List[i].LetterList.RemoveAt(z);
                        }
                    }
                    if (SplitTPO.Cluster_Level_List[i].LetterList.Count == 0)
                    {
                        //Remove letter list if it is empty
                        SplitTPO.Cluster_Level_List.RemoveAt(i);
                        //					if(debug)
                        //						PrintNoDup(String.Format("Removing empty letter list",0));
                    }
                    else
                    {
                        //Not sure.
                        SplitTPO.Cluster_Level_List[i].Volume = SplitTPO.Cluster_Level_List[i].Volume_Letter.Sum(x => x.Value);
                    }
                }
                #endregion

                #region Removing values from old TPO 1Tick
                for (int i = SplitTPO.Cluster_Level_List_1Tick.Count - 1; i >= 0; i--)
                {
                    for (int z = SplitTPO.Cluster_Level_List_1Tick[i].LetterList.Count - 1; z >= 0; z--)
                    {
                        string lett = SplitTPO.Cluster_Level_List_1Tick[i].LetterList[z];
                        int idx = tpo_letters.IndexOf(lett);
                        if (idx >= split_index)
                        {
                            //						if(debug)
                            //							PrintNoDup(String.Format("Removing level{2} letter{3}: lett - {0}, idx - {1}",lett,idx,i,z));
                            //Removing letter volume. For this purposes Volume_Letter was created. 
                            SplitTPO.Cluster_Level_List_1Tick[i].Volume -= SplitTPO.Cluster_Level_List_1Tick[i].Volume_Letter[lett];
                            SplitTPO.Cluster_Level_List_1Tick[i].Volume_Letter.Remove(lett);
                            SplitTPO.Cluster_Level_List_1Tick[i].LetterList.RemoveAt(z);
                        }
                    }
                    if (SplitTPO.Cluster_Level_List_1Tick[i].LetterList.Count == 0)
                    {
                        //Remove letter list if it is empty
                        SplitTPO.Cluster_Level_List_1Tick.RemoveAt(i);
                        //					if(debug)
                        //						PrintNoDup(String.Format("Removing empty letter list",0));
                    }
                    else
                    {
                        //Not sure.
                        SplitTPO.Cluster_Level_List_1Tick[i].Volume = SplitTPO.Cluster_Level_List_1Tick[i].Volume_Letter.Sum(x => x.Value);
                    }
                }
                #endregion

                //12. Asigning LastBarIndex, EndTimeOfSession, Last to the new TPO
                TPO_Cluster_List[TPO_Cluster_Index + 1].FirstIndex = DailyMode ? SplitTPO.DetermineBarIndex(split_index) :
                                                                                BarsArray[0].GetBar(SplitTPO.DetermineTime(split_index));
                TPO_Cluster_List[TPO_Cluster_Index + 1].LastBarIndex = TPO_Cluster_List[TPO_Cluster_Index + 1].FirstIndex + TPO_Cluster_List[TPO_Cluster_Index + 1].MAX_Length - 1;

                

                TPO_Cluster_List[TPO_Cluster_Index + 1].StartTimeOfSession = Times[0].GetValueAt(TPO_Cluster_List[TPO_Cluster_Index + 1].FirstIndex);
                TPO_Cluster_List[TPO_Cluster_Index + 1].EndTimeOfSession = Times[0].GetValueAt(TPO_Cluster_List[TPO_Cluster_Index + 1].LastBarIndex);//
                TPO_Cluster_List[TPO_Cluster_Index + 1].Open = Opens[0].GetValueAt(TPO_Cluster_List[TPO_Cluster_Index + 1].FirstIndex);
                TPO_Cluster_List[TPO_Cluster_Index + 1].Last = Closes[0].GetValueAt(BarsArray[0].GetBar(TPO_Cluster_List[TPO_Cluster_Index + 1].DetermineTime(max_tpo_letter_new)));

                if (debug)
                    PrintNoDup(String.Format("SplitByLetter. Calculating properties of new TPO. FirstIndex - {3}, LastBarIndex - {0}, StartTimeOfSession - {4} EndTimeOfSession - {1}, Last - {2}, SessionBeginDate - {5}, SessionBeginIndex - {6}",
                    TPO_Cluster_List[TPO_Cluster_Index + 1].LastBarIndex, TPO_Cluster_List[TPO_Cluster_Index + 1].EndTimeOfSession,
                    TPO_Cluster_List[TPO_Cluster_Index + 1].Last, TPO_Cluster_List[TPO_Cluster_Index + 1].FirstIndex,
                    TPO_Cluster_List[TPO_Cluster_Index + 1].StartTimeOfSession, TPO_Cluster_List[TPO_Cluster_Index + 1].SessionBeginDate,
                    TPO_Cluster_List[TPO_Cluster_Index + 1].SessionBeginIndex));


                //Recalculating properties of the old TPO
                SplitTPO.Last = Closes[0].GetValueAt(DailyMode ? (SplitTPO.DetermineBarIndex(max_tpo_letter_old))
                                                                                : BarsArray[0].GetBar(SplitTPO.DetermineTime(max_tpo_letter_old)));
                SplitTPO.MAX_Volume = SplitTPO.Cluster_Level_List.Max(x => x.Volume);
                SplitTPO.MAX_Volume_1Tick = SplitTPO.Cluster_Level_List_1Tick.Max(x => x.Volume);

                int max_length = SplitTPO.MaxLengthCalc();
                int max_length_1Tick = SplitTPO.MaxLengthCalc1Tick();

                SplitTPO.MAX_Length = max_length;
                SplitTPO.MAX_Length_1Tick = max_length_1Tick;

                SplitTPO.LastBarIndex = SplitTPO.FirstIndex + max_length - 1;
                SplitTPO.EndTimeOfSession = BarsArray[0].GetTime(SplitTPO.LastBarIndex);
				
				
                

            	double poc = SplitTPO.Cluster_Level_List.Where(x => x.LetterList.Count == max_length).OrderByDescending(x => x.Volume).FirstOrDefault().PriceLevel;
                double poc_1Tick = SplitTPO.Cluster_Level_List_1Tick.Where(x => x.LetterList.Count == max_length_1Tick).OrderByDescending(x => x.Volume).FirstOrDefault().PriceLevel;
                SplitTPO.POC = poc;
                SplitTPO.POC_1Tick = poc_1Tick;

                if (debug)
                    PrintNoDup(String.Format("SplitByLetter. Recalculating props of the old TPO. MAX_Volume - {0}, MAX_Length - {1}, POC - {2}, LastBarIndex - {3}, EndTimeOfSession - {4}, Last - {5}",
                    SplitTPO.MAX_Volume, SplitTPO.MAX_Length, SplitTPO.POC, SplitTPO.LastBarIndex,
                    SplitTPO.EndTimeOfSession, SplitTPO.Last));

                //SplitTPO.CalculateHighLowRange(TickSize);
                SplitTPO.ValueAreaRange(SplitTPO.POC_1Tick, SplitTPO.Cluster_Level_List_1Tick, this.pVASize_Pct, TickSize, max_length_1Tick);
                double poc_volume_1Tick = SplitTPO.Cluster_Level_List_1Tick.OrderByDescending(x => x.Volume).FirstOrDefault().PriceLevel;
                SplitTPO.ValueAreaRangeVolume(poc_volume_1Tick, SplitTPO.Cluster_Level_List_1Tick, pVASize_Pct, TickSize, SplitTPO.MAX_Volume_1Tick);
            

                SplitTPO.ResistanceTested = false;
                SplitTPO.SupportTested = false;


                //What zones should be shown
                List<TPO_Cluster> todayTPOs = TPO_Cluster_List.Where(v => v.SessionBeginDate == SplitTPO.SessionBeginDate).ToList();
                int count = todayTPOs.Count >= 2 ? 2 : todayTPOs.Count;
                todayTPOs.OrderByDescending(v => v.ResistanceTopLevel).Take(count).ToList().ForEach(v => v.ShowResZones = true);
                todayTPOs.OrderBy(v => v.SupportBottomLevel).Take(count).ToList().ForEach(v => v.ShowSupZones = true);

                //Delete merge date

                if (mergeDates.Keys.Contains(SplitTPO.SessionBeginDate))
                {
                    mergeDates.Remove(SplitTPO.SessionBeginDate);
                    //PrintNoDup("delete date");
                }

                //Recheck zones for tested
                RecalculateZones(TPO_Cluster_List[TPO_Cluster_Index + 1]);
                RecalculateZones(SplitTPO);
            
            }
		    #endregion

		    #region MergeBack
		    private void MergeBack(TPO_Cluster TPO)
		    {
                //6. TPO to merge
                TPO_Cluster tpo_cluster_merge = DailyMode ? TPO_Cluster_List.OrderByDescending(x => x.StartTimeOfSession).FirstOrDefault(x => x.StartTimeOfSession < TPO.StartTimeOfSession) :
                                                                TPO_Cluster_List.OrderByDescending(x => x.StartTimeOfSession).FirstOrDefault(x => x.StartTimeOfSession < TPO.StartTimeOfSession);

                //If there is no tpo - exit
                if (tpo_cluster_merge == null)
                    return;
                //If previous TPO is from another session - exit
                if ((tpo_cluster_merge.SessionBeginDate != TPO.SessionBeginDate && !DailyMode) ||
                    (tpo_cluster_merge.SessionBeginIndex != TPO.SessionBeginIndex && DailyMode))
                    return;

                //7. Adding values from clicked TPO to previous TPO
                for (int i = 0; i < TPO.Cluster_Level_List.Count; i++)
                {
                    double level = TPO.Cluster_Level_List[i].PriceLevel;
                    for (int z = 0; z < TPO.Cluster_Level_List[i].LetterList.Count; z++)
                    {
                        string lett = TPO.Cluster_Level_List[i].LetterList[z];
                        tpo_cluster_merge.AddLevel(level, lett, TPO.Cluster_Level_List[i].Volume_Letter, 0, pVASize_Pct);
                    }
                }

                for (int i = 0; i < TPO.Cluster_Level_List_1Tick.Count; i++)
                {
                    double level = TPO.Cluster_Level_List_1Tick[i].PriceLevel;
                    for (int z = 0; z < TPO.Cluster_Level_List_1Tick[i].LetterList.Count; z++)
                    {
                        string lett = TPO.Cluster_Level_List_1Tick[i].LetterList[z];

                        tpo_cluster_merge.AddLevel(level, lett, TPO.Cluster_Level_List_1Tick[i].Volume_Letter, 1, pVASize_Pct);
                    }
                }
                //8. 

                if (mergeDates.Keys.Contains(TPO.SessionBeginDate))
                {
                    if (mergeDates[TPO.SessionBeginDate] != TPO_Cluster_List.IndexOf(TPO))
                    {
                        //PrintNoDup("Remove " + TPO_Cluster_List.IndexOf(TPO) + " " + mergeDates[TPO.SessionBeginDate]);
                        mergeDates.Remove(TPO.SessionBeginDate);
                    }
				}

				tpo_cluster_merge.Last 				= 	TPO.Last;

				tpo_cluster_merge.MAX_Length 		=	tpo_cluster_merge.MaxLengthCalc();//tpo_cluster_merge.Cluster_Level_List.Where(x => x.LetterList.Where(y=>y!="0").ToList()).Max(v=>v.LetterList.Count);
				tpo_cluster_merge.LastBarIndex 		= 	tpo_cluster_merge.FirstIndex + tpo_cluster_merge.MAX_Length - 1;//(DailyMode?2:1);
//				if(tpo_cluster_merge.LastBarIndex==183)
//					PrintNoDup("merge "+BarsArray[0].GetTime(tpo_cluster_merge.FirstIndex)+" "+tpo_cluster_merge.MAX_Length);
				tpo_cluster_merge.EndTimeOfSession = 	BarsArray[0].GetTime(tpo_cluster_merge.LastBarIndex);
				//tpo_cluster_merge.ResistanceTested = false;
				//tpo_cluster_merge.SupportTested = false;
				TPO_Cluster_List.Remove(TPO);

				//Recheck zones for tested
				RecalculateZones(tpo_cluster_merge);

				AllSplitMode = false;

				TPO = null;
				tpo_cluster_merge = null;
            }
		    #endregion

		    #region AutoSplitTPO
		    private void AutoSplit(TPO_Cluster TPO)
		    {
			    if(TPO==null)
				    return;
			
			    DateTime	beginTime	=	TPO.SessionBeginDate;
			    int	mode_index			=	FindMode(TPO);
            
                int	lastTPOIndex		=	0;
			    //if not enough modes
			    if(mode_index==-1)
				    return;
			
			    //Splitting
			    do
			    {
				    while(mode_index!=-1)
				    {
					    SplitByLetter(TPO,mode_index);
					    mode_index	=	FindMode(TPO);
                    
				    }
				    int cur_idx		=	TPO_Cluster_List.IndexOf(TPO);
				
				    if(cur_idx==TPO_Cluster_List.Count-1)
					    break;
				    else
					    TPO = TPO_Cluster_List[cur_idx+1];
				
				    lastTPOIndex	=	cur_idx;
				    mode_index		=	FindMode(TPO);
			    }
			    while(beginTime==TPO.SessionBeginDate);
			
			
			    //Merging
			    TPO			=	TPO_Cluster_List[lastTPOIndex+1];
			    TPO_Cluster	TPO_PREV	=	lastTPOIndex+1!=0?TPO_Cluster_List[lastTPOIndex+1-1]:null;
            

                while (TPO_PREV!=null&&
				    beginTime==TPO_PREV.SessionBeginDate)
			    {
					
				    double	vah		=	TPO.VAH;
				    double	val		=	TPO.VAL;
				    double	v_vah	=	TPO.VOLUME_VAH;
				    double	v_val	=	TPO.VOLUME_VAL;
				
				    double	p_vah	=	TPO_PREV.VAH;
				    double	p_val	=	TPO_PREV.VAL;
				    double	p_v_vah	=	TPO_PREV.VOLUME_VAH;
				    double	p_v_val	=	TPO_PREV.VOLUME_VAL;
				
				    if(		(
							    (vah<=p_vah+TickSize*AutoMergeManipulation&&vah>=p_val-TickSize*AutoMergeManipulation)||
							    (val<=p_vah+TickSize*AutoMergeManipulation&&val>=p_val-TickSize*AutoMergeManipulation)
						    )||
						    //(
						    //	(v_vah<=p_v_vah+TickSize*AutoMergeManipulation&&v_vah>=p_v_val-TickSize*AutoMergeManipulation)||
						    //	(v_val<=p_v_vah+TickSize*AutoMergeManipulation&&v_val>=p_v_val-TickSize*AutoMergeManipulation)
						    //)||
                            (TPO.Cluster_Level_List.All(l=>l.LetterList.Count==1))
					    )
				    {
                        
					    //Merge Back
					    MergeBack(TPO);
                        //break;
				    }

                    lastTPOIndex	-=	1;

                

                if (lastTPOIndex==0||lastTPOIndex==-1)
					    break;
				    TPO				=	TPO_Cluster_List[lastTPOIndex+1];
				    TPO_PREV		=	TPO_Cluster_List[lastTPOIndex-1+1];
            }
		    }
            #endregion

            #region SplitAssistTPO
            private void SplitAssist(DateTime SessionBeginDate, bool CurrentDay)
            {
                if (TPO_Cluster_List.Count == 0)
                    return;

                List<TPO_Cluster> TPO_list = TPO_Cluster_List.Where(tpo => tpo.SessionBeginDate == SessionBeginDate).ToList();

                if (TPO_list.Count == 0)
                    return;

                int prevModeIdx = TPO_list[0].AssistSplitLetterIndex;
                bool isPrevAssist = TPO_list[0].AssistSplit;


                for (int i = 0; i < TPO_list.Count; i++)
                {
                    TPO_list[i].ResetAssist();
                }

                TPO_Cluster TPO = TPO_list[0];

                DateTime beginTime = TPO.SessionBeginDate;
                int mode_index = FindModeAssist(TPO);
                int lastTPOIndex = 0;

                //PrintNoDup(mergeDates.Count()+" "+ TPO.SessionBeginDate);
                if (CurrentDay)
                    return;
                if (!mergeDates.Keys.Contains(TPO.SessionBeginDate))
                    do
                    {
                        if (mode_index != -1)
                        {
                            TPO.AssistSplit = true;
                            TPO.AssistSplitLetterIndex = mode_index;

                            return;
                        }
                        int cur_idx = TPO_Cluster_List.IndexOf(TPO);
                        if (cur_idx == TPO_Cluster_List.Count - 1)
                        {
                            break;
                        }
                        else
                        {
                            TPO = TPO_Cluster_List[cur_idx + 1];
                        }
                        lastTPOIndex = cur_idx;
                        mode_index = FindModeAssist(TPO);
                    }
                    while (beginTime == TPO.SessionBeginDate);
                //}


                //Merging
                TPO = TPO_list.Last();
                lastTPOIndex = TPO_list.Count - 1;

                //Adding merge list
                if (!mergeDates.Keys.Contains(TPO.SessionBeginDate))
                {
                    mergeDates.Add(TPO.SessionBeginDate, -1);
                    //PrintNoDup("add date "+" "+ TPO.SessionBeginDate); 
                }

                if (TPO_list.Count < 2)
                    return;
                TPO_Cluster TPO_PREV = TPO_list[TPO_list.Count - 2];

                while (TPO_PREV != null &&
                    beginTime == TPO_PREV.SessionBeginDate)
                {
                    double vah = TPO.VAH;
                    double val = TPO.VAL;
                    double v_vah = TPO.VOLUME_VAH;
                    double v_val = TPO.VOLUME_VAL;

                    double p_vah = TPO_PREV.VAH;
                    double p_val = TPO_PREV.VAL;
                    double p_v_vah = TPO_PREV.VOLUME_VAH;
                    double p_v_val = TPO_PREV.VOLUME_VAL;

                    if ((
                                (vah <= p_vah + TickSize * AutoMergeManipulation && vah >= p_val - TickSize * AutoMergeManipulation) ||
                                (val <= p_vah + TickSize * AutoMergeManipulation && val >= p_val - TickSize * AutoMergeManipulation)
                            ) ||
                            //(
                            //    (v_vah <= p_v_vah + TickSize * AutoMergeManipulation && v_vah >= p_v_val - TickSize * AutoMergeManipulation) ||
                            //    (v_val <= p_v_vah + TickSize * AutoMergeManipulation && v_val >= p_v_val - TickSize * AutoMergeManipulation)
                            //) ||
                            (TPO.Cluster_Level_List.All(l => l.LetterList.Count == 1))
                        )
                    {
                        //PrintNoDup("Add index " + TPO_Cluster_List.IndexOf(TPO));
                        mergeDates[TPO.SessionBeginDate] = TPO_Cluster_List.IndexOf(TPO);
                        TPO.AssistMerge = true;
                        return;
                    }

                    lastTPOIndex -= 1;

                    if (lastTPOIndex == 0)
                        break;
                    TPO = TPO_list[lastTPOIndex];
                    TPO_PREV = TPO_list[lastTPOIndex - 1];
                }

                return;
            }
            #endregion

            #region FindMode
            private int	FindMode(TPO_Cluster TPO)
		    {
			    bool debug	=	false;
			
			    List<string>	tpo_letters_intraday	=	new		List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
							    "p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P"};
			    List<string>	tpo_letters_day	=	new		List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
							    "p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","1","2","3","4","5"
		    ,"6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36",
			    "37","38","39","40","41","42","43","44"};
			
			    List<string>  	tpo_letters	=	DailyMode?tpo_letters_day:tpo_letters_intraday; 
			    List<int>		modeIndices	=	new List<int>();
			    if(TPO==null)
				    return(-1);
			
			    int		mode_index	=	-1;
			    int		mode_count	=	0;
			    //UP Bias or DOWN Bias
			    bool	up_bias	=	TPO.Last>TPO.Open;
			    if(debug)
			    PrintNoDup("up_bias "+up_bias+" "+TPO.Last+" "+TPO.Open);
			    //Sorting TPO to begin with needed Mode
			    TPO.Cluster_Level_List	=	up_bias?TPO.Cluster_Level_List.OrderBy(v=>v.PriceLevel).ToList():TPO.Cluster_Level_List.OrderByDescending(v=>v.PriceLevel).ToList();
			
			    bool	mode0	=	true;
			    bool	mode1	=	false;
			    bool	mode2	=	false;
			    bool	mode3	=	false;
			    bool	fr		=	true;
			    int		mode	=	0;
			    List<int>	indices	=	new List<int>();
			
			    for(int i=2;i<TPO.Cluster_Level_List.Count;i++)
			    {
				    int	prev_length2	=	TPO.Cluster_Level_List[i-2].LetterList.Count;
				    int	prev_length1	=	TPO.Cluster_Level_List[i-1].LetterList.Count;
				    int	cur_length		=	TPO.Cluster_Level_List[i].LetterList.Count;
				    if(debug) PrintNoDup("cur_length - "+cur_length+" prev_length1 - "+prev_length1+" prev_length2 - "+prev_length2+" price "+TPO.Cluster_Level_List[i].PriceLevel);
				    if(mode0 &&
					    cur_length>=3 &&
					    ((cur_length>prev_length1 &&
					    cur_length>prev_length2)||fr))
				    {
					    fr	=	false;
					    if(debug) PrintNoDup("Mode0. First half was met "+cur_length);
					    mode0	=	false;
					    mode1	=	true;
					    mode	=	cur_length;
					    indices.Clear();
					    indices.Add(tpo_letters.IndexOf(TPO.Cluster_Level_List[i].LetterList.Last()));
					    continue;
				    }
				
				    if(mode1)
				    {
					    //High/Low Last rule
					    if(i==TPO.Cluster_Level_List.Count-1)
					    {
						    mode_count++;
						    if(mode_count==2)
							    return(mode_index);
					    }
					    if(cur_length<mode)
					    {
						    if(debug) PrintNoDup("Mode1. cur_length<mode");
						    mode2	=	true;
						    mode1	=	false;
						    continue;
					    }
					    else if(cur_length>mode)
					    {
						    if(debug) PrintNoDup("Mode1. cur_length>mode");
						    mode	=	cur_length;
						    indices.Clear();
						    indices.Add(tpo_letters.IndexOf(TPO.Cluster_Level_List[i].LetterList.Last()));
						    continue;
					    }
					    else if(cur_length == mode)
					    {
						    if(debug) PrintNoDup("Mode1. cur_length == mode");
						    indices.Add(tpo_letters.IndexOf(TPO.Cluster_Level_List[i].LetterList.Last()));
						    continue;
					    }
				    }
					
				    if(mode2)
				    {
					
					    if(cur_length<mode && indices.Count>0)
					    {
						    if(debug) PrintNoDup("Mode2. mode was found "+mode_index);
						    mode0		=	true;
						    mode2		=	false;
						    mode_count++;
						    if(mode_count==2)
							    return(mode_index);
						    mode_index	=	indices.Max();
						
					    }
					    else if(cur_length>mode)
					    {
						    if(debug) PrintNoDup("Mode2. New poc was found "+mode_index);
                            mode = cur_length;
                            indices.RemoveAt(indices.Count - 1);
                            indices.Add(tpo_letters.IndexOf(TPO.Cluster_Level_List[i].LetterList.Last()));
						}
				    }
			    }
			    return(-1);
		    }
		    #endregion

		    #region FindModeAssist
            private int	FindModeAssist(TPO_Cluster TPO)
		    {
			    bool debug	=	false;
			
			    List<string>	tpo_letters_intraday	=	new		List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
							    "p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P"};
			    List<string>	tpo_letters_day	=	new		List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
							    "p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","1","2","3","4","5"
		    ,"6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36",
			    "37","38","39","40","41","42","43","44"};
			
			    List<string>  	tpo_letters	=	DailyMode?tpo_letters_day:tpo_letters_intraday; 
			    List<int>		modeIndices	=	new List<int>();
			    if(TPO==null)
				    return(-1);
			
			    int		mode_index	=	-1;
			    int		mode_count	=	0;
			    //UP Bias or DOWN Bias
			    bool	up_bias		=	TPO.Last>TPO.Open;
			    if(debug)
			    PrintNoDup("up_bias "+up_bias+" "+TPO.Last+" "+TPO.Open);
			    //Sorting TPO to begin with needed Mode
			    TPO.Cluster_Level_List	=	up_bias?TPO.Cluster_Level_List.OrderBy(v=>v.PriceLevel).ToList():TPO.Cluster_Level_List.OrderByDescending(v=>v.PriceLevel).ToList();
			
			    bool	mode0	=	true;
			    bool	mode1	=	false;
			    bool	mode2	=	false;
			    bool	mode3	=	false;
			    bool	fr		=	true;
			    int		mode	=	0;
			    double	price	=	-1;
			    List<int>	indices	=	new List<int>();
			
			    for(int i=2;i<TPO.Cluster_Level_List.Count;i++)
			    {
				    int	prev_length2	=	TPO.Cluster_Level_List[i-2].LetterList.Count;
				    int	prev_length1	=	TPO.Cluster_Level_List[i-1].LetterList.Count;
				    int	cur_length		=	TPO.Cluster_Level_List[i].LetterList.Count;
				    if(debug) PrintNoDup("cur_length - "+cur_length+" prev_length1 - "+prev_length1+" prev_length2 - "+prev_length2+" price "+TPO.Cluster_Level_List[i].PriceLevel);
				    if(mode0&&
					    cur_length>=3&&
					    ((cur_length>prev_length1&&
					    cur_length>prev_length2)||fr))
				    {
					    fr	=	false;
					    if(debug) PrintNoDup("Mode0. First half was met "+cur_length);
					    mode0	=	false;
					    mode1	=	true;
					    mode	=	cur_length;
					    indices.Clear();
					    indices.Add(tpo_letters.IndexOf(TPO.Cluster_Level_List[i].LetterList.Last()));
					    if(mode_count==0)
						    price		=	TPO.Cluster_Level_List[i].PriceLevel;
					    continue;
				    }
				
				    if(mode1)
				    {
					
					    //High/Low Last rule
					    if(i==TPO.Cluster_Level_List.Count-1)
					    {
						    mode_count++;
						    if(mode_count==2)
						    {
							    TPO.AssistLevel	=	price;
							    return(mode_index);
						    }
					    }
					    if(cur_length<mode)
					    {
						    if(debug) PrintNoDup("Mode1. cur_length<mode");
						    mode2	=	true;
						    mode1	=	false;
						    continue;
					    }
					    else if(cur_length>mode)
					    {
						    if(debug) PrintNoDup("Mode1. cur_length>mode");
						    mode	=	cur_length;
						    indices.Clear();
						    indices.Add(tpo_letters.IndexOf(TPO.Cluster_Level_List[i].LetterList.Last()));
						
						    if(mode_count==0)
							    price		=	TPO.Cluster_Level_List[i].PriceLevel;
						
						    continue;
					    }
					    else if(cur_length == mode)
					    {
						    if(debug) PrintNoDup("Mode1. cur_length == mode");
						    indices.Add(tpo_letters.IndexOf(TPO.Cluster_Level_List[i].LetterList.Last()));
						
						    if(mode_count==0)
							    price		=	TPO.Cluster_Level_List[i].PriceLevel;
						
						    continue;
					    }
				    }
					
				    if(mode2)
				    {
					
					    if(cur_length<mode && indices.Count>0)
					    {
						    if(debug)
						    PrintNoDup("Mode2. mode was found "+mode_index);
						    mode0		=	true;
						    mode2		=	false;
						    mode_count++;
						    if(mode_count==2)
						    {
							    TPO.AssistLevel	=	price;
							    return(mode_index);
						    }
						    mode_index	=	indices.Max();
						
						
					    }
					    else if(cur_length>mode)
					    {
						    if(debug)
						    PrintNoDup("Mode2. New poc was found "+mode_index);
                            mode = cur_length;
                            indices.RemoveAt(indices.Count - 1);
                            indices.Add(tpo_letters.IndexOf(TPO.Cluster_Level_List[i].LetterList.Last()));
                        //mode0		=	true;
                        //mode2		=	false;
                    }
				    }
			    }

			    return(-1);
		    }
            #endregion

            #region RecalculateZones
            private void RecalculateZones(TPO_Cluster TPO)
            {
				TPO.IsResistanceBroken 	= false;
				TPO.IsSupportBroken 	= false;
				TPO.SupportTested 		= false;
				TPO.ResistanceTested	= false;
				
	            double sup_bot_lev = TPO.SupportBottomLevel;
	            double sup_top_lev = TPO.SupportTopLevel;
	            double res_bot_lev = TPO.ResistanceBottomLevel;
	            double res_top_lev = TPO.ResistanceTopLevel;

	            DateTime sessionBeginDate = TPO.SessionBeginDate;

	            int day_index = Sessions.FindIndex(v => v.BeginDate == sessionBeginDate);


	            if (day_index == Sessions.Count - 1)
	                return;

	            int day_after_index = day_index + 1;

	            SessionInfo day_after_info = Sessions[day_after_index];


	            int day_after_first_bar = day_after_info.FirstBarIdx;
	            //int day_after_last_bar = day_after_info.LastBarIdx;


	            if (CurrentBars[0] == day_after_first_bar)
	                return;

	            double highest_high = 0;//MAX(Highs[0], CurrentBars[0] - day_after_first_bar)[0];
	            double lowest_low = double.MaxValue;//MIN(Lows[0], CurrentBars[0] - day_after_first_bar)[0];

	            double session_open = Opens[0].GetValueAt(day_after_first_bar);

	            bool sup_catch_tested = false;
	            bool res_catch_tested = false;
	            int sup_test_bar = -1;
	            int res_test_bar = -1;
	            for (int k = day_after_first_bar; k <= CurrentBars[0]; k++)
	            {
	                if (Highs[0].GetValueAt(k) > highest_high)
	                {
	                    highest_high = Highs[0].GetValueAt(k);
	                }

	                if (Lows[0].GetValueAt(k) < lowest_low)
	                {
	                    lowest_low = Lows[0].GetValueAt(k);
	                }

	                if (((session_open > sup_top_lev && lowest_low <= sup_top_lev) ||
	                   (session_open < sup_bot_lev && highest_high >= sup_bot_lev) ||
	                   (session_open <= sup_top_lev && session_open >= sup_bot_lev))&&!sup_catch_tested)
	                {
	                    sup_catch_tested = true;
	                    sup_test_bar = k;
	                }

	                if(((session_open > res_top_lev && lowest_low <= res_top_lev) ||
	                   (session_open < res_bot_lev && highest_high >= res_bot_lev) ||
	                   (session_open <= res_top_lev && session_open >= res_bot_lev))&&!res_catch_tested)
	                {
	                    res_catch_tested = true;
	                    res_test_bar = k;
	                }

	            }

	            bool sup_tested = sup_catch_tested;//(session_open > sup_top_lev && lowest_low <= sup_top_lev) ||
	                                               //(session_open < sup_bot_lev && highest_high >= sup_bot_lev) ||
	                                               //(session_open <= sup_top_lev && session_open >= sup_bot_lev);

	            bool res_tested = res_catch_tested;//(session_open > res_top_lev && lowest_low <= res_top_lev) ||
	                                               //(session_open < res_bot_lev && highest_high >= res_bot_lev) ||
	                                               //(session_open <= res_top_lev && session_open >= res_bot_lev);

	            int sup_day_tested_index = sup_tested?Sessions.FindIndex(v => v.FirstBarIdx <= sup_test_bar && v.LastBarIdx >= sup_test_bar):-1;
	            int res_day_tested_index = res_tested?Sessions.FindIndex(v => v.FirstBarIdx <= res_test_bar && v.LastBarIdx >= res_test_bar):-1;

				if (sup_tested)
	            {
	                int sup_last_bar = Sessions[sup_day_tested_index].LastBarIdx;
	                TPO.SupportTested = true;
	                TPO.SupportEndIdx = sup_last_bar;

	                if (sup_day_tested_index != Sessions.Count - 1)
	                    TPO.IsSupportBroken = true;
	            }

	            if (res_tested)
	            {
	                int res_last_bar = Sessions[res_day_tested_index].LastBarIdx;
	                TPO.ResistanceTested = true;
	                TPO.ResistanceEndIdx = res_last_bar;

	               if (res_day_tested_index != Sessions.Count - 1)
	                    TPO.IsResistanceBroken = true;
	            }

	        }
            #endregion

        #endregion

//=============================================================================================================
        #region -- MouseEvents Utilities --
        #region -- private class MouseManager --
        private class MouseManager
        {
            public int HoverIndex = -1;
            public int X = 0;
            public int Y = 0;
            public int Index = 0;
			public double ChartMaxPrice = double.MinValue;
			public double ChartMinPrice = double.MaxValue;
			public int    ChartMinABar = int.MaxValue;
			public int    ChartMaxABar = 0;
			public int    TPOCount = 0;
			public char   SelectedArbZoneType =   ' ';
			public double[] SelectedArbZoneData = null;	//[0] is the abar of left-edge of rectangle
														//[1] is the price of the top edge of the rectangle
														//[2] is the abar of the right edge of the rectangle
														//[3] is the price of the bottom edge of the rectangle

            public void Clear()
            {
                this.HoverIndex = -1;
                this.X = 0;
                this.Y = 0;
                this.Index = 0;
            }
        }
        #endregion

        private void ChartPanel_MouseMove(object sender, MouseEventArgs e)
        {
#if NEW_CODE_NOV2018
			//e.Handled = true;
			if(!GlobalSR_Enabled) return;
			#region MouseMove
			Point coords = e.GetPosition(ChartPanel);
			int X = ChartingExtensions.ConvertToHorizontalPixels(coords.X, ChartControl.PresentationSource)+(int)ChartControl.BarWidth;
			int Y = ChartingExtensions.ConvertToVerticalPixels(coords.Y, ChartControl.PresentationSource);
			this.MM.X = X;
			this.MM.Y = Y;

			bool c0 = false;
			bool c1 = false;
			bool c2 = false;
			bool c3 = false;
			bool c4 = false;
			MM.HoverIndex=-1;
//			PrintNoDup("Time: "+BarsArray[0].GetTime(ChartBars.GetBarIdxByX(ChartControl, X)));
			int MouseABar = ChartBars.GetBarIdxByX(ChartControl, X);

			if(this.ShowFreshZones || this.ShowBrokenZones) {
				#region Select arb zones for globalizing rectangles
				MM.SelectedArbZoneData = null;
				var ResRects = Visible_ResArbs.Where(x => x.Key < MouseABar && x.Value.EndABar > MouseABar).ToList();
				if(ResRects!=null){
					for (int i = 0; i < ResRects.Count; i++)
					{
						c1 = ResRects[i].Value.TopScreenY < Y;
						c2 = ResRects[i].Value.BottomScreenY > Y;
						if(c1 && c2){
							MM.SelectedArbZoneData  =new double[4]{
									ResRects[i].Key,
										ResRects[i].Value.TopPrice,
									ResRects[i].Value.EndABar,
										ResRects[i].Value.BottomPrice};
							MM.HoverIndex = ResRects[i].Key;
							MM.SelectedArbZoneType = 'R';
							break;
						}
					}
				}
				var SupRects = Visible_SupArbs.Where(x => x.Key < MouseABar && x.Value.EndABar > MouseABar).ToList();
				if(SupRects!=null){
					for (int i = 0; i < SupRects.Count; i++)
					{
						c1 = SupRects[i].Value.TopScreenY < Y;
						c2 = SupRects[i].Value.BottomScreenY > Y;
						if(c1 && c2){
							MM.SelectedArbZoneData  =new double[4]{
									SupRects[i].Key,
										SupRects[i].Value.TopPrice,
									SupRects[i].Value.EndABar,
										SupRects[i].Value.BottomPrice};
							MM.HoverIndex = SupRects[i].Key;
							MM.SelectedArbZoneType = 'S';
							break;
						}
					}
				}
				#endregion
			}
            //detect if mouse over a TPO ValueArea bar or a Arb zone
			for (int g = 0; g < TPO_Cluster_List.Count; g++){
//PrintNoDup(string.Format("VA_X: {0}  X: {1}",TPO_Cluster_List[g].VA_ScreenX,X));
				c1 = (Math.Abs(TPO_Cluster_List[g].VA_ScreenX - X) < 10);
				if(!c1)	continue;

				c2 = TPO_Cluster_List[g].VA_ScreenYt <= Y;
				c3 = TPO_Cluster_List[g].VA_ScreenYb >= Y;
//PrintNoDup(string.Format("{0}  Yt {1}   Yb: {2}  MMy: {3} ",g,TPO_Cluster_List[g].VA_ScreenYt, TPO_Cluster_List[g].VA_ScreenYb, Y));
				if(c1 && c2 && c3) {
					MM.HoverIndex = g;
					break;
				}
			}
            ChartControl.InvalidateVisual();
			#endregion
#endif
		}
		private void ChartPanel_MouseUp(object sender, MouseButtonEventArgs e)
		{
#if NEW_CODE_NOV2018
//			e.Handled = true;
			if(!GlobalSR_Enabled) return;
			int obj_count = 0;
		    if (this.MM.HoverIndex >= 0)
		    {
				//bool MouseInValueArea = MM.Y > TPO_Cluster_List[MM.HoverIndex].ResistanceTopScreenY && MM.Y < TPO_Cluster_List[MM.HoverIndex].ResistanceBottomScreenY;
				try{
					if(MM.SelectedArbZoneData==null){
						string tag = string.Format("RayVAH_{0}",TPO_Cluster_List[MM.HoverIndex].FirstIndex);
						if(GlobalVAHL_Rays.ContainsKey(tag) && GlobalVAHL_Rays[tag].IsDrawn) {
							RemoveDrawObject(tag);
							GlobalVAHL_Rays.Remove(tag);
						}else{
							GlobalVAHL_Rays[tag] = new Global_VARaysData(
											TPO_Cluster_List[MM.HoverIndex].FirstIndex,
											BarsArray[0].GetTime(TPO_Cluster_List[MM.HoverIndex].FirstIndex), 
											TPO_Cluster_List[MM.HoverIndex].VAH, 
											VAH_Ray_Template);
							obj_count++;
						}

						tag = string.Format("RayVAL_{0}",TPO_Cluster_List[MM.HoverIndex].FirstIndex);
						if(GlobalVAHL_Rays.ContainsKey(tag) && GlobalVAHL_Rays[tag].IsDrawn){
							RemoveDrawObject(tag);
							GlobalVAHL_Rays.Remove(tag);
						}else{
							GlobalVAHL_Rays[tag] = new Global_VARaysData(
											TPO_Cluster_List[MM.HoverIndex].FirstIndex,
											BarsArray[0].GetTime(TPO_Cluster_List[MM.HoverIndex].FirstIndex), 
											TPO_Cluster_List[MM.HoverIndex].VAL, 
											VAL_Ray_Template);
							obj_count++;
						}
					}
				}catch(Exception e4473){PrintNoDup("e4473  "+e4473.ToString());}
				if(this.ShowFreshZones || this.ShowBrokenZones) {
					try{
						if(MM.SelectedArbZoneData!=null){
							string tag = string.Format("RectArb_{0} {1}", MM.SelectedArbZoneData[0], MM.SelectedArbZoneData[1]);//Data[0] is the start ABar, Data[1] is the price of the top-edge rectangle
							if(GlobalArb_Rects.ContainsKey(tag) && GlobalArb_Rects[tag].IsDrawn) {
								RemoveDrawObject(tag);
								GlobalArb_Rects.Remove(tag);
								MM.SelectedArbZoneType = ' ';
							}else{
								if(MM.SelectedArbZoneType == 'S'){
									GlobalArb_Rects[tag] = new Global_RectsData((int)MM.SelectedArbZoneData[0],
													BarsArray[0].GetTime((int)MM.SelectedArbZoneData[0]), 
													MM.SelectedArbZoneData[1],
													MM.SelectedArbZoneData[2]>Bars.Count ? DateTime.MaxValue : BarsArray[0].GetTime((int)MM.SelectedArbZoneData[2]), 
													MM.SelectedArbZoneData[3], this.SupportZones_Template, 'S');
									obj_count++;
								}
								else if(MM.SelectedArbZoneType == 'R'){
									GlobalArb_Rects[tag] = new Global_RectsData((int)MM.SelectedArbZoneData[0],
													BarsArray[0].GetTime((int)MM.SelectedArbZoneData[0]), 
													MM.SelectedArbZoneData[1], 
													MM.SelectedArbZoneData[2]>Bars.Count ? DateTime.MaxValue : BarsArray[0].GetTime((int)MM.SelectedArbZoneData[2]), 
													MM.SelectedArbZoneData[3], this.ResistanceZones_Template, 'R');
									obj_count++;
								}
							}
						}
					}catch(Exception e4496){PrintNoDup("e4496  "+e4496.ToString());}
				}
				if(obj_count>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
				}else{
					obj_count=0;
					ClearGlobals_Button.Background = Brushes.Silver;
					foreach (var CO in DrawObjects) {
					//	PrintNoDup("obj: "+CO.Tag);
						if(CO.Tag.StartsWith("RayVAH_")) {
							obj_count=1;
							break;
						}
						if(CO.Tag.StartsWith("RayVAL_")) {
							obj_count=1;
							break;
						}
						if(CO.Tag.StartsWith("RectArb_")) {
							obj_count=1;
							break;
						}
					}
					if(obj_count==0) {
						ClearGlobals_Button.Visibility = Visibility.Collapsed;
					}else{
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
					}
				}
			}
			ForceRefresh();
#endif
			//ChartControl.InvalidateVisual();
		}

		#endregion

		#region GUI, BUTTONS, MENUS...

			#region AddToolbar
			private void AddToolBar()
			{
				// Use this.Dispatcher to ensure code is executed on the proper thread
				ChartControl.Dispatcher.InvokeAsync((Action)(() =>
				{
					// Grid already exists
					if (UserControlCollection.Contains(dragPanel))
					    return;

					AddControls();
					UserControlCollection.Add(dragPanel);
				}));
			}


            #endregion

			#region CleanToolBar
			private void DisposeCleanUp()
			{
				if (chartWindow != null && dragPanel!=null && MenuGrid!=null)
				{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						UserControlCollection.Remove(dragPanel);
					}));
				}
            }
            #endregion

            #region AddControlsToToolbar
            private void AddControls()
            {
                // Add a control grid which will host our custom buttons
                MenuGrid = new System.Windows.Controls.Grid
                {
                    Name = "MenuGrid",
                    // Align the control to the top right corner of the chart
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Top,
                };

                #region Columns

                // Define the two columns in the grid, one for each button
                ColumnDefinition column1 = new System.Windows.Controls.ColumnDefinition();
                ColumnDefinition column2 = new System.Windows.Controls.ColumnDefinition();
                ColumnDefinition column3 = new System.Windows.Controls.ColumnDefinition();
                ColumnDefinition column4 = new System.Windows.Controls.ColumnDefinition();
                ColumnDefinition column5 = new System.Windows.Controls.ColumnDefinition();
                ColumnDefinition column6 = new System.Windows.Controls.ColumnDefinition();
                ColumnDefinition column7 = new System.Windows.Controls.ColumnDefinition();
                ColumnDefinition column8 = new System.Windows.Controls.ColumnDefinition();
                ColumnDefinition column9 = new System.Windows.Controls.ColumnDefinition();
                ColumnDefinition column10 = new System.Windows.Controls.ColumnDefinition();
                ColumnDefinition column11 = new System.Windows.Controls.ColumnDefinition();

                // Add the columns to the Grid
                MenuGrid.ColumnDefinitions.Add(column1);
                MenuGrid.ColumnDefinitions.Add(column2);
                MenuGrid.ColumnDefinitions.Add(column3);
                MenuGrid.ColumnDefinitions.Add(column4);
                MenuGrid.ColumnDefinitions.Add(column5);
                MenuGrid.ColumnDefinitions.Add(column6);
                MenuGrid.ColumnDefinitions.Add(column7);
                MenuGrid.ColumnDefinitions.Add(column8);
                MenuGrid.ColumnDefinitions.Add(column9);
                MenuGrid.ColumnDefinitions.Add(column10);
                MenuGrid.ColumnDefinitions.Add(column11);

                #endregion

                #region DragPanel
                dragPanel = new WrapPanel();

                Thickness thickness = new Thickness(TogglePositionMarginLeft, TogglePositionMarginTop, TogglePositionMarginRight, TogglePositionMarginBottom);
                dragPanel.HorizontalAlignment = HorizontalAlignment.Left;
                dragPanel.VerticalAlignment = VerticalAlignment.Top;
                dragPanel.Margin = thickness;

                drag = new Thumb();
                drag.Width = 10;
                drag.Cursor = Cursors.SizeAll;
                drag.ToolTip = "Drag to anywhere.";
                drag.DragDelta += OnDragDelta;
                FrameworkElementFactory fef = new FrameworkElementFactory(typeof(Border));
                fef.SetValue(Border.BackgroundProperty, Brushes.Black);
                drag.Template = new ControlTemplate(typeof(Thumb)) { VisualTree = fef };

                System.Windows.Controls.Grid.SetColumn(drag, 0);
                MenuGrid.Children.Add(drag);
                #endregion

                #region ViewSettings
                ViewMode = new System.Windows.Controls.ComboBox
                {
                    Name = "ViewModeComboBox",
                    Width = 220,
                };
#if NEW_CODE_NOV2018
                ViewMode.Items.Add("PROFILE");
				if(ConfigMgr!=null) ConfigMgr.AddViewMode(0,"-pviewmode.config");// else AddViewMode(0,"-pviewmode.config");
                ViewMode.Items.Add("HYBRID");
				if(ConfigMgr!=null) ConfigMgr.AddViewMode(1,"-hviewmode.config");// else AddViewMode(1,"-hviewmode.config");
                ViewMode.Items.Add("HYBRID PRINT");
				if(ConfigMgr!=null) ConfigMgr.AddViewMode(2,"-hpviewmode.config");// else AddViewMode(2,"-hpviewmode.config");
                ViewMode.Items.Add("SHOW/HIDE RR");
				ViewMode.SelectedIndex = (ConfigMgr!=null ? ConfigMgr.Determine_CurrentViewMode() : 0);//Determine_CurrentViewMode());
#else
                ViewMode.Items.Add("PROFILE");
                ViewMode.Items.Add("HYBRID");
                ViewMode.Items.Add("HYBRID PRINT");
				ViewMode.SelectedIndex = 0;
#endif
				#region Load saved configuration for ViewMode
				if(ViewMode.SelectedIndex==0) {
					ProfileView     =true;
					HybridView      =false;
					HybridPrintView =false;
				}else if(ViewMode.SelectedIndex==1) {
					ProfileView     =false;
					HybridView      =true;
					HybridPrintView =false;
				}else if(ViewMode.SelectedIndex==2) {
					ProfileView     =false;
					HybridView      =false;
					HybridPrintView =true;
				}
				ViewModeSelectionChanged(null,null);
				#endregion
#if NEW_CODE_NOV2018
				this.ShowRR_databox     = (ConfigMgr!=null ? ConfigMgr.Determine_ShowRRBoxVisibility() : false);
#else
				this.ShowRR_databox     = false;
#endif
				ViewMode.SelectionChanged += ViewModeSelectionChanged;
                System.Windows.Controls.Grid.SetColumn(ViewMode, 1);
                MenuGrid.Children.Add(ViewMode);
                #endregion

                #region ZonesSettings

                ZonesComboBox = new System.Windows.Controls.ComboBox
                {
                    Name = "ZonesComboBox",
                    Width = 140,
                };


                ZonesComboBox.Items.Add("ZONES");
				#region ShowFreshZones checkbox
#if NEW_CODE_NOV2018
				ShowFreshZones = (ConfigMgr!=null ? ConfigMgr.Determine_ShowFreshZones() : false);
#else
				ShowFreshZones = false;
#endif

				ShowFreshZones_Button = new System.Windows.Controls.Button { Content = (ShowFreshZones ? "Fresh Zones ON":"Fresh Zones OFF"), Foreground=Brushes.White, Background=Brushes.Silver};
				ShowFreshZones_Button.Click += delegate(object o, RoutedEventArgs e){
					ShowFreshZones = !ShowFreshZones;
					ShowFreshZones_Button.Content = (ShowFreshZones ? "Fresh Zones ON" : "Fresh Zones OFF");
					ShowZonesClickedJustNow = true;
#if NEW_CODE_NOV2018
					if(ConfigMgr!=null) ConfigMgr.Update_ShowFreshZones(ShowFreshZones);
#endif
					ForceRefresh();
				};
                ZonesComboBox.Items.Add(ShowFreshZones_Button);
				#endregion

				#region Load saved config settings for broken zones on/off
#if NEW_CODE_NOV2018
				ShowBrokenZones = (ConfigMgr!=null ? ConfigMgr.Determine_ShowBrokenZones() : false);
#else
				ShowBrokenZones = false;
#endif
				ShowBrokenZones_Button = new System.Windows.Controls.Button { Content = (ShowBrokenZones ? "Broken Zones ON":"Broken Zones OFF"), Foreground=Brushes.White, Background=Brushes.Silver};
				ShowBrokenZones_Button.Click += delegate(object o, RoutedEventArgs e){
					ShowBrokenZones = !ShowBrokenZones;
					ShowBrokenZones_Button.Content = (ShowBrokenZones ? "Broken Zones ON" : "Broken Zones OFF");
					ShowZonesClickedJustNow = true;
#if NEW_CODE_NOV2018
					if(ConfigMgr!=null) ConfigMgr.Update_ShowBrokenZones(ShowBrokenZones);
#endif
					ForceRefresh();
				};
                ZonesComboBox.Items.Add(ShowBrokenZones_Button);
				#endregion

				ZonesComboBox.SelectedIndex = 0;

//				for (int i = 1; i < ZonesComboBox.Items.Count; i++)
//				{
//				    if (i < 3)
//				    {
//				        System.Windows.Controls.CheckBox check = ZonesComboBox.Items[i] as System.Windows.Controls.CheckBox;
//				        check.Click += ZonesSettingsItem_Checked;
//				    }
//				}
				EnableGlobals_Button = new System.Windows.Controls.Button { Content = (GlobalSR_Enabled ? "Globals ON":"Globals OFF"), Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
				EnableGlobals_Button.Click += delegate (object o, RoutedEventArgs e){
					e.Handled=true;
					GlobalSR_Enabled = !GlobalSR_Enabled;
					EnableGlobals_Button.Content = (GlobalSR_Enabled ? "Globals ON" : "Globals OFF");
	                ForceRefresh();
				};
#if NEW_CODE_NOV2018
				ZonesComboBox.Items.Add(EnableGlobals_Button);
#endif
				ClearGlobals_Button = new System.Windows.Controls.Button { Content = "", Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
				ClearGlobals_Button.Visibility = Visibility.Collapsed;
#if NEW_CODE_NOV2018
				ClearGlobals_Button.Click += delegate(object o, RoutedEventArgs e){
					e.Handled=true;
					var keys = new List<string>(GlobalVAHL_Rays.Keys);
					foreach(var tag in keys){
						RemoveDrawObject(tag);
						GlobalVAHL_Rays.Remove(tag);
					}
					keys = new List<string>(GlobalArb_Rects.Keys);
					foreach(var tag in keys){
						RemoveDrawObject(tag);
						GlobalArb_Rects.Remove(tag);
					}
					ClearGlobals_Button.Content = "";
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
					ClearGlobals_Button.Background = Brushes.Silver;
				};
				ZonesComboBox.Items.Add(ClearGlobals_Button);
#endif
				ZonesComboBox.SelectionChanged += ZonesComboBox_SelectionChanged;

                MenuGrid.Children.Add(ZonesComboBox);
                System.Windows.Controls.Grid.SetColumn(ZonesComboBox, 2);
                #endregion
            
                #region AutoMergeButton
                AutoMergeButton = new System.Windows.Controls.Button
                {
                    Name = "AutoMergeButton",
                    Content = "AUTO MERGE",
                    Height = 21,
                    FontSize = 10,
					HorizontalContentAlignment = HorizontalAlignment.Left,
                    VerticalContentAlignment = VerticalAlignment.Center,
                };

                AutoMergeButton.Click += AutoMergeButton_Click;
                System.Windows.Controls.Grid.SetColumn(AutoMergeButton, 3);
                MenuGrid.Children.Add(AutoMergeButton);
                #endregion

                #region AutoSplitButton
                AutoSplitButton = new System.Windows.Controls.Button
                {
                    Name = "AutoSplitButton",
                    Content = "AUTO SPLIT",
                    Height = 21,
                    FontSize = 10,
					HorizontalContentAlignment = HorizontalAlignment.Left,
                    VerticalContentAlignment = VerticalAlignment.Center,
                };
                AutoSplitButton.Click += AutoSplitButton_Click;
                System.Windows.Controls.Grid.SetColumn(AutoSplitButton, 4);
                MenuGrid.Children.Add(AutoSplitButton);
				#endregion

                #region SplitEnabled
#if NEW_CODE_NOV2018
				this.IsSplittingLocked = (ConfigMgr!=null ? !ConfigMgr.Determine_SplitEnabledStatus() : false);
                SplitEnabledButton = new System.Windows.Controls.Button
                {
                    Name = "SplitEnabledButton",
                    Content = (IsSplittingLocked ? "SPLIT OFF" : "SPLIT ON"),
                    Height = 21,
                    FontSize = 10,
					HorizontalContentAlignment = HorizontalAlignment.Left,
                    VerticalContentAlignment = VerticalAlignment.Center,
                };

                SplitEnabledButton.Click += delegate (object o, RoutedEventArgs e){
					e.Handled=true;
					IsSplittingLocked = !IsSplittingLocked;
					if(ConfigMgr!=null)
						ConfigMgr.Update_SplitEnabledStatus(IsSplittingLocked);
					SplitEnabledButton.Content = (IsSplittingLocked ? "SPLIT OFF" : "SPLIT ON");
	                ForceRefresh();
				};
                System.Windows.Controls.Grid.SetColumn(SplitEnabledButton, 5);
                MenuGrid.Children.Add(SplitEnabledButton);
#endif
                #endregion
                dragPanel.Children.Add(MenuGrid);
            }
            #endregion

            #region CONTROL HANDLERS
            #region ViewModeComboBox_SelectionChanged
            void ViewModeSelectionChanged(object sender, EventArgs e)
            {
                string selectedItem = ViewMode.SelectedItem.ToString();

				if (selectedItem == "PROFILE" && (sender==null || ProfileView == false))
                {
					if(!EqualColor(ChartBars.Properties.ChartStyle.UpBrush,Brushes.Transparent))
					    UpBrush   = ChartBars.Properties.ChartStyle.UpBrush;
					if (!EqualColor(ChartBars.Properties.ChartStyle.DownBrush, Brushes.Transparent))
					    DownBrush = ChartBars.Properties.ChartStyle.DownBrush;
					if (!EqualColor(ChartBars.Properties.ChartStyle.Stroke.Brush, Brushes.Transparent))
					    CandleOutlineBrush = ChartBars.Properties.ChartStyle.Stroke.Brush;
					if (!EqualColor(ChartBars.Properties.ChartStyle.Stroke2.Brush, Brushes.Transparent))
					    CandleWickBrush    = ChartBars.Properties.ChartStyle.Stroke2.Brush;

					ChartBars.Properties.ChartStyle.UpBrush       = Brushes.Transparent;
					ChartBars.Properties.ChartStyle.DownBrush     = Brushes.Transparent;
					ChartBars.Properties.ChartStyle.Stroke.Brush  = Brushes.Transparent;
					ChartBars.Properties.ChartStyle.Stroke2.Brush = Brushes.Transparent;

					ProfileView     = true;
					HybridView      = false;
					HybridPrintView = false;
#if NEW_CODE_NOV2018
					if(ConfigMgr!=null) 
						ConfigMgr.Update_CurrentViewMode(ViewMode.SelectedIndex);
#endif

					SetZOrder(-1000);
                    ForceRefresh();
                }
                if (selectedItem == "HYBRID" && (sender==null || HybridView == false))
                {
					if (!EqualColor(ChartBars.Properties.ChartStyle.UpBrush, Brushes.Transparent))
						UpBrush   = ChartBars.Properties.ChartStyle.UpBrush;
					if (!EqualColor(ChartBars.Properties.ChartStyle.DownBrush, Brushes.Transparent))
						DownBrush = ChartBars.Properties.ChartStyle.DownBrush;
					if (!EqualColor(ChartBars.Properties.ChartStyle.Stroke.Brush, Brushes.Transparent))
						CandleOutlineBrush = ChartBars.Properties.ChartStyle.Stroke.Brush;   //Candle Outline
					if (!EqualColor(ChartBars.Properties.ChartStyle.Stroke2.Brush, Brushes.Transparent))
						CandleWickBrush = ChartBars.Properties.ChartStyle.Stroke2.Brush; //Candle Wicks

					ChartBars.Properties.ChartStyle.UpBrush         = UpBrush;
					ChartBars.Properties.ChartStyle.DownBrush       = DownBrush;
					ChartBars.Properties.ChartStyle.Stroke.Brush    = CandleOutlineBrush;
					ChartBars.Properties.ChartStyle.Stroke2.Brush   = CandleWickBrush;

					ProfileView     = false;
					HybridView      = true;
					HybridPrintView = false;
#if NEW_CODE_NOV2018
					if(ConfigMgr!=null) 
						ConfigMgr.Update_CurrentViewMode(ViewMode.SelectedIndex);
#endif

					SetZOrder(1000);
					ForceRefresh();
                }
                if (selectedItem == "HYBRID PRINT" && (sender==null || HybridPrintView == false))
                {
					if (!EqualColor(ChartBars.Properties.ChartStyle.UpBrush, Brushes.Transparent))
					    UpBrush = ChartBars.Properties.ChartStyle.UpBrush;
					if (!EqualColor(ChartBars.Properties.ChartStyle.DownBrush, Brushes.Transparent))
					    DownBrush = ChartBars.Properties.ChartStyle.DownBrush;
					if (!EqualColor(ChartBars.Properties.ChartStyle.Stroke.Brush, Brushes.Transparent))
					    CandleOutlineBrush = ChartBars.Properties.ChartStyle.Stroke.Brush;
					if (!EqualColor(ChartBars.Properties.ChartStyle.Stroke2.Brush, Brushes.Transparent))
					    CandleWickBrush = ChartBars.Properties.ChartStyle.Stroke2.Brush;

					ChartBars.Properties.ChartStyle.UpBrush       = Brushes.Transparent;
					ChartBars.Properties.ChartStyle.DownBrush     = Brushes.Transparent;
					ChartBars.Properties.ChartStyle.Stroke.Brush  = CandleOutlineBrush;
					ChartBars.Properties.ChartStyle.Stroke2.Brush = CandleWickBrush;

					ProfileView     = false;
					HybridView      = false;
					HybridPrintView = true;
#if NEW_CODE_NOV2018
					if(ConfigMgr!=null) 
						ConfigMgr.Update_CurrentViewMode(ViewMode.SelectedIndex);
#endif

					SetZOrder(-1000);
					ForceRefresh();
                }
#if NEW_CODE_NOV2018
                if (selectedItem == "SHOW/HIDE RR")
                {
					ShowRR_databox = !ShowRR_databox;
					if(ConfigMgr!=null) {
						ConfigMgr.Update_ShowRRBoxVisibility(ShowRR_databox);
						ViewMode.SelectedIndex = ConfigMgr.CurrentViewMode_SelectedIndex;
					}
					ForceRefresh();
				}
#endif
            }
            #endregion

            #region SplitSettingsItem_Checked
            void SplitSettingsItem_Checked(object sender, EventArgs e)
            {
                System.Windows.Controls.CheckBox checkBox = sender as System.Windows.Controls.CheckBox;

                if (checkBox.Content == "AUTO SPLIT")
                {
                    IsAutoSplit = checkBox.IsChecked == true ? true : false;
                    if (IsAutoSplit)
                    {
                        IsSplitAssist = false;
                        IsManualSplitMerge = false;
                        ChartControl.Dispatcher.InvokeAsync((() =>
                        {
                            System.Windows.Controls.CheckBox check2 = SplitComboBox.Items[2] as System.Windows.Controls.CheckBox;
                            System.Windows.Controls.CheckBox check3 = SplitComboBox.Items[3] as System.Windows.Controls.CheckBox;
                            check2.IsChecked = false;
                            check3.IsChecked = false;
                        }));
                    }
                }
                if (checkBox.Content == "SPLIT ASSIST")
                {
                    IsSplitAssist = checkBox.IsChecked == true ? true : false;
                    if (IsSplitAssist)
                    {
                        IsAutoSplit = false;
                        IsCDAutoSplit = false;
                        ChartControl.Dispatcher.InvokeAsync((() =>
                        {
                            System.Windows.Controls.CheckBox check1 = SplitComboBox.Items[1] as System.Windows.Controls.CheckBox;
                            System.Windows.Controls.CheckBox check4 = SplitComboBox.Items[4] as System.Windows.Controls.CheckBox;
                            check1.IsChecked = false;
                            check4.IsChecked = false;
                        }));
                    }
                }
                if (checkBox.Content == "MANUAL SPLIT/MERGE")
                {
                    IsManualSplitMerge = checkBox.IsChecked == true ? true : false;
                    if (IsManualSplitMerge)
                    {
                        IsAutoSplit = false;
                        IsCDAutoSplit = false;
                        ChartControl.Dispatcher.InvokeAsync((() =>
                        {
                            System.Windows.Controls.CheckBox check1 = SplitComboBox.Items[1] as System.Windows.Controls.CheckBox;
                            System.Windows.Controls.CheckBox check4 = SplitComboBox.Items[4] as System.Windows.Controls.CheckBox;
                            check1.IsChecked = false;
                            check4.IsChecked = false;
                        }));
                    }
                }
                if (checkBox.Content == "CURRENT DAY AUTO SPLIT")
                {
                    IsCDAutoSplit = checkBox.IsChecked == true ? true : false;

                    if (IsCDAutoSplit)
                    {
                        if (MarketDataFirst)
                        {
                            consBars = 0;
                            AutoSplit(TPO_Cluster_List.Last());
                            MarketDataFirst = false;
                        }
                    }
                }

                ForceRefresh();
            }
            #endregion

            #region ZonesSettingsComboBox_SelectionChanged
            void ZonesComboBox_SelectionChanged(object sender, EventArgs e)
            {
                ZonesComboBox.SelectedIndex = 0;
            }
            #endregion

			private void CleanUpOrphanedRaysAndRectangles(){
//Print("Cleaning up!");
//string tag = string.Format("RayVAH_{0}",TPO_Cluster_List[MM.HoverIndex].FirstIndex);
//string tag = string.Format("RayVAL_{0}",TPO_Cluster_List[MM.HoverIndex].FirstIndex);
//string tag = string.Format("RectArb_{0} {1}", MM.SelectedArbZoneData[0], MM.SelectedArbZoneData[1]);//Data[0] is the start ABar, Data[1] is the price of the top-edge rectangle
				var TagsToRemove = new List<string>();
				#region Update global rects if their profile no longer exists
				foreach(KeyValuePair<string,Global_RectsData> rect in GlobalArb_Rects) {
					var TPO = TPO_Cluster_List.Where(v => v.FirstIndex == rect.Value.StartABar).ToList();
//Print("4715  TPO size: "+(TPO==null?"null":TPO.Count.ToString()));
					//if(TPO==null || TPO.Count==0)
					{
						TagsToRemove.Add(rect.Key);
						RemoveDrawObject(rect.Key);
//Print("4719  tag being deleted: "+rect.Key);
//					}else{
//						if(rect.Value.SupportOrResistance == 'S'){
//							rect.Value.TopPrice    = TPO[0].SupportTopLevel;
//							rect.Value.BottomPrice = TPO[0].SupportBottomLevel;
//							rect.Value.IsDrawn = false;
//						}else if(rect.Value.SupportOrResistance == 'R'){
//							rect.Value.TopPrice    = TPO[0].ResistanceTopLevel;
//							rect.Value.BottomPrice = TPO[0].ResistanceBottomLevel;
//							rect.Value.IsDrawn = false;
//						}
					}
				}
				foreach(var tag in TagsToRemove){
					GlobalArb_Rects.Remove(tag);
				}
				#endregion
				TagsToRemove.Clear();
				#region Update global VA rays if their profile no longer exists
				foreach(KeyValuePair<string, Global_VARaysData> ray in GlobalVAHL_Rays) {
					var TPO = TPO_Cluster_List.Where(v => v.FirstIndex == ray.Value.StartABar).ToList();
					if(TPO==null || TPO.Count==0){
						TagsToRemove.Add(ray.Key);
						RemoveDrawObject(ray.Key);
					}else{
						if(ray.Key.Contains("VAH")) {
							ray.Value.Price    = TPO[0].VAH;
							ray.Value.IsDrawn = false;
						}else if(ray.Key.Contains("VAL")) {
							ray.Value.Price    = TPO[0].VAL;
							ray.Value.IsDrawn = false;
						}
					}
				}
				foreach(var tag in TagsToRemove){
					GlobalVAHL_Rays.Remove(tag);
				}
				#endregion
			}


			#region AutoMergeButton_Click
            void AutoMergeButton_Click(object sender, EventArgs e)
            {
            AutoMergeFunc();
            }

            private void AutoMergeFunc()
            {
                for (int i = TPO_Cluster_List.Count - 1; i >= 0; i--)
                {
                    MergeBack(TPO_Cluster_List[i]);
                }
                for (int i = TPO_Cluster_List.Count - 2; i >= 0; i--)
                {
                    SplitAssist(TPO_Cluster_List[i].SessionBeginDate, false);
                }
				//DetermineDisqualifiedZones();
				CleanUpOrphanedRaysAndRectangles();
                ForceRefresh();
            }
            #endregion

			#region AutoSplitButton_Click
			private void AutoSplitButton_Click(object sender, RoutedEventArgs e)
			{
				AutoSplitFunc();
			}

            private void AutoSplitFunc()
            {
				if(TPO_Cluster_List==null) return;
                int i = 0;
                DateTime sesBegin = new DateTime();
//				PrintNoDup("TPO_Cluster_List.Count: "+TPO_Cluster_List.Count);
                while (i < TPO_Cluster_List.Count)
   	            {
					try{
        	            if (sesBegin != TPO_Cluster_List[i].SessionBeginDate)
            	        {
                	        sesBegin = TPO_Cluster_List[i].SessionBeginDate;
                    	    AutoSplit(TPO_Cluster_List[i]);
	                    }
					}catch(Exception e){PrintNoDup("AutoSplitFunc error: "+e.ToString());}
					i++;
       	        }
				//DetermineDisqualifiedZones();
				CleanUpOrphanedRaysAndRectangles();
				ForceRefresh();
            }
            #endregion

            #region OnDragDelta
            void OnDragDelta(object sender, DragDeltaEventArgs e)
            {
                try
                {
                    double left, top, right, bottom;
                    left = top = right = bottom = defaultMargin;

                    if (dragPanel.HorizontalAlignment == HorizontalAlignment.Left) left = dragPanel.Margin.Left + e.HorizontalChange;
                    else right = dragPanel.Margin.Right - e.HorizontalChange;

                    if (dragPanel.VerticalAlignment == VerticalAlignment.Top) top = dragPanel.Margin.Top + e.VerticalChange;
                    else bottom = dragPanel.Margin.Bottom - e.VerticalChange;
                

                    left = Math.Max(0, left);
                    top = Math.Max(0, top);
                    right = Math.Max(0, right);
                    bottom = Math.Max(0, bottom);

                    dragPanel.Margin = new Thickness(left, top, right, bottom);
                }
                catch { }
            }
            #endregion

        #endregion
          
        #endregion

        #region TPO CLUSTER CLASSES
		public bool CheckTimeIn(DateTime time, DateTime Start, DateTime End)
		{
			if(time >= Start && time <= End)
				return true;
			else
				return false;
		}
        //TPO Day Cluster Class
        public class TPO_Cluster
		{
			#region Properties
			public List<TPO_Cluster_Level> Cluster_Level_List			{get;set;}
            public List<TPO_Cluster_Level> Cluster_Level_List_1Tick		{get;set;}
			public int			SessionBeginIndex	{get;set;}
			public DateTime 	SessionBeginDate	{get;set;}
			public DateTime 	SessionEndDate		{get;set;}
			public DateTime 	StartTimeOfSession	{get;set;}
			public DateTime 	EndTimeOfSession	{get;set;}
            public int			TPO_Period			{get;set;}
			public int			FirstIndex			{get;set;}
			public int			VA_ScreenX			{get;set;}
			public int			VA_ScreenYt			{get;set;}
			public int			VA_ScreenYb			{get;set;}
			public double 		StartPoint			{get;set;}
			public double       POC					{get;set;}
            public double       POC_1Tick			{get;set;}
            public double		VAH					{get;set;}
			public double		VAL					{get;set;}
			public double		VOLUME_VAH			{get;set;}
			public double		VOLUME_VAL			{get;set;}
			public double		VOLUME_POC			{get;set;}
            public double		VOLUME_POC_1Tick	{get;set;}
            public	int			MAX_Length			{get;set;}
			public	double		MAX_Volume			{get;set;}
            public int 			MAX_Length_1Tick	{get;set;}
            public double		MAX_Volume_1Tick	{get;set;}
            public 	double		High_Range_Start	{get;set;}
			public 	double		Low_Range_Start		{get;set;}
			public 	int			LastBarIndex		{get;set;}
			public List<int>	SplitIndices		{get;set;}
			public	double		Close				{get;set;}
			public	double		Open				{get;set;}
			public  double		Last				{get;set;}
			public	int			tpoTicksIncrement	{get;set;}
			public double		SupportTopLevel			{get;set;}
			public double		SupportBottomLevel		{get;set;}
			public double		ResistanceTopLevel		{get;set;}
			public double		ResistanceBottomLevel	{get;set;}
			public bool			SupportTested			{get;set;}
            public DateTime     SupportTestedDate		{ get; set; }
            public bool			ResistanceTested		{get;set;}
            public DateTime     ResistanceTestedDate	{ get; set; }
            public int          ResistanceEndIdx		{ get; set; }
            public int          SupportEndIdx			{ get; set; }
            public bool         IsSupportBroken			{ get; set; }
            public bool         IsResistanceBroken		{ get; set; }
			public bool			IsResDisqualified		{ get; set; }//when the the open of the next profile is above the Resistance arbzone, that resistance zone is disqualified
			public bool			IsSupDisqualified		{ get; set; }//when the the open of the next profile is below the Support arbzone, that support zone is disqualified
            public bool         ShowResZones			{ get; set; }
            public bool         ShowSupZones			{ get; set; }
            public bool         AssistSplit				{get; set;}
            public int          AssistSplitLetterIndex	{ get; set; }
            public bool         AssistMerge				{ get; set; }
			public double		AssistLevel				{ get; set; }

			private	double		tickSize;
            private	int			VAL_COUNT;
			private int			VAH_COUNT;
			private bool		DailyMode;
			private	double		PrevLevel;

			private	List<string>	tpo_letters	=	new		List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
								"p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P"};
			private	List<string>	tpo_letters_day	=	new		List<string>{"W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o",
								"p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","1","2","3","4","5"
			,"6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36",
				"37","38","39","40","41","42","43","44"};
			#endregion

			#region Constructors
			public TPO_Cluster(DateTime sessionBeginDate,DateTime sessionEndDate,DateTime startTimeOfSession,DateTime endTimeOfSession,int tpo_period,int first_index,
				double start_point,int last_bar_index, double ticksize,int TPO_Increment,double open,bool daily_mode)
			{
				StartTimeOfSession	 =	startTimeOfSession;
				EndTimeOfSession	 =	endTimeOfSession;
				TPO_Period			 =	tpo_period;
				FirstIndex			 =	first_index;
				StartPoint			 =	start_point;
				MAX_Volume			 =	0;
                LastBarIndex		 =	last_bar_index;
				tickSize			 =	ticksize;
				tpoTicksIncrement	 =	TPO_Increment;
				VAL_COUNT			 =	0;
				VAH_COUNT			 =	0;
				SplitIndices		 =	new List<int>();
				Open				 =	open;
				SessionBeginDate	 =	sessionBeginDate;
				SessionEndDate		 =	sessionEndDate;
				DailyMode			 =	daily_mode;
				Cluster_Level_List	 =	new List<TPO_Cluster_Level>();
                Cluster_Level_List_1Tick = new List<TPO_Cluster_Level>();
			}
			public TPO_Cluster(int sessionBeginIndex,DateTime startTimeOfSession,DateTime endTimeOfSession,int tpo_period,int first_index,
				double start_point,int last_bar_index, double ticksize,int TPO_Increment,double open,bool daily_mode)
			{
				StartTimeOfSession	=	startTimeOfSession;
				EndTimeOfSession	=	endTimeOfSession;
				TPO_Period			=	tpo_period;
				FirstIndex			=	first_index;
				StartPoint			=	start_point;
				MAX_Volume			=	0;
                LastBarIndex		=	last_bar_index;
				tickSize			=	ticksize;
				tpoTicksIncrement	=	TPO_Increment;
				VAL_COUNT			=	0;
				VAH_COUNT			=	0;
				SplitIndices		=	new List<int>();
				Open				=	open;
				SessionBeginIndex	=	sessionBeginIndex;
				DailyMode			=	daily_mode;
				Cluster_Level_List	=	new List<TPO_Cluster_Level>();
                Cluster_Level_List_1Tick = new List<TPO_Cluster_Level>();
			}
			#endregion

			#region AddLevel
			public void AddLevel(double level,DateTime time,double volume,int barIndex, double ost, double VASize_Pct)
			{
                if (ost == 0)
                {
                    string letter = DailyMode ? DetermineLetter(barIndex) : DetermineLetter(time);
                    List<TPO_Cluster_Level> curList = Cluster_Level_List.Where(x => x.PriceLevel == level).ToList();
                    int count  = curList.Count;
                    int length = 0;
                    Last       = level;

                    if (count == 0)
                    {
                        Cluster_Level_List.Add(new TPO_Cluster_Level(level, volume));
                        Cluster_Level_List.Last().LetterList.Add(letter);
                        Cluster_Level_List.Last().LetterListCount = Cluster_Level_List.Last().LetterList.Count;
                        Cluster_Level_List.Last().Volume_Letter[letter] = volume;

                        length = 1;
                        //Maximum volume finding
                        if (volume > MAX_Volume)
                        {
                            MAX_Volume = volume;
                            if (length == MAX_Length)
                                POC = level;

                            VOLUME_POC = level;
                        }
                        // Max length updating
                        if (length > MAX_Length)
                        {
                            MAX_Length = length;
                            POC = level;
                        }

                        //ValueAreaRangeVolume(VOLUME_POC, Cluster_Level_List, VA_percent, tickSize, MAX_Volume);
                        //ValueAreaRange(POC, Cluster_Level_List, VA_percent, tickSize, MAX_Length);
                        //CalculateHighLowRange(tickSize);
                    }
                    else
                    {
                        if (curList[0].LetterList.Where(a => a == letter).Count() == 0)
                        {
                            curList[0].LetterList.Add(letter);

                            length = curList[0].LetterList.Where(x => x != "0").Count();

                            // Max length updating
                            if (length > MAX_Length)
                            {
                                MAX_Length = length;
                                POC = level;
                            }
                            //ValueAreaRangeVolume(VOLUME_POC, Cluster_Level_List, VASize_Pct, tickSize, MAX_Volume);
                            //ValueAreaRange(POC, Cluster_Level_List, VASize_Pct, tickSize, MAX_Length);
                            //CalculateHighLowRange(tickSize);

                            curList[0].Volume_Letter[letter] = volume;
                        }
                        else
                        {
                            curList[0].Volume_Letter[letter] += volume;
                        }

                        curList[0].Volume += volume;

                        //Maximum volume finding
                        if (curList[0].Volume > MAX_Volume)
                        {
                            VOLUME_POC = level;
                            MAX_Volume = curList[0].Volume;
                            if (length == MAX_Length)
                                POC = level;
                        }
                    }
                }

                string letter_1Tick = DailyMode ? DetermineLetter(barIndex) : DetermineLetter(time);
                List<TPO_Cluster_Level> curList_1Tick = Cluster_Level_List_1Tick.Where(x => x.PriceLevel == level).ToList();
                int count_1Tick = curList_1Tick.Count;
                int length_1Tick = 0;
                //Last = level;

                if (count_1Tick == 0)
                {
                    Cluster_Level_List_1Tick.Add(new TPO_Cluster_Level(level, volume));
                    Cluster_Level_List_1Tick.Last().LetterList.Add(letter_1Tick);
                    Cluster_Level_List_1Tick.Last().LetterListCount = Cluster_Level_List_1Tick.Last().LetterList.Count;
                    Cluster_Level_List_1Tick.Last().Volume_Letter[letter_1Tick] = volume;

                    length_1Tick = 1;
                    //Maximum volume finding
                    if (volume > MAX_Volume_1Tick)
                    {
                        MAX_Volume_1Tick = volume;
                        if (length_1Tick == MAX_Length_1Tick)
                            POC_1Tick = level;

                        VOLUME_POC_1Tick = level;
                    }
                    // Max length updating
                    if (length_1Tick > MAX_Length_1Tick)
                    {
                        MAX_Length_1Tick = length_1Tick;
                        POC_1Tick = level;
                    }

                    ValueAreaRangeVolume(VOLUME_POC_1Tick, Cluster_Level_List_1Tick, VASize_Pct, tickSize, MAX_Volume_1Tick);
                    ValueAreaRange(POC_1Tick, Cluster_Level_List_1Tick, VASize_Pct, tickSize, MAX_Length_1Tick);
                    //CalculateHighLowRange(tickSize);
                }
                else
                {
                    if (curList_1Tick[0].LetterList.Where(a => a == letter_1Tick).Count() == 0)
                    {
                        curList_1Tick[0].LetterList.Add(letter_1Tick);

                        length_1Tick = curList_1Tick[0].LetterList.Where(x => x != "0").Count();

                        // Max length updating
                        if (length_1Tick > MAX_Length_1Tick)
                        {
                            MAX_Length_1Tick = length_1Tick;
                            POC_1Tick = level;
                        }
                        ValueAreaRangeVolume(VOLUME_POC_1Tick, Cluster_Level_List_1Tick, VASize_Pct, tickSize, MAX_Volume_1Tick);
                        ValueAreaRange(POC_1Tick, Cluster_Level_List_1Tick, VASize_Pct, tickSize, MAX_Length_1Tick);
                        //CalculateHighLowRange(tickSize);

                        curList_1Tick[0].Volume_Letter[letter_1Tick] = volume;
                    }
                    else
                    {
                        curList_1Tick[0].Volume_Letter[letter_1Tick] += volume;
                    }

                    curList_1Tick[0].Volume += volume;

                    //Maximum volume finding
                    if (curList_1Tick[0].Volume > MAX_Volume_1Tick)
                    {
                        VOLUME_POC_1Tick = level;
                        MAX_Volume_1Tick = curList_1Tick[0].Volume;
                        if (length_1Tick == MAX_Length_1Tick)
                            POC_1Tick = level;
                    }
                }
            }
			
			public void AddLevel(double level,string letter,Dictionary<string,double> vol_lett, double ost, double VA_percent)
			{
                if (ost == 0)
                {
                    List<TPO_Cluster_Level> curList = Cluster_Level_List.Where(x => x.PriceLevel == level).ToList();
                    int count = curList.Count;
                    int length = 0;
                    double volume = vol_lett[letter];
                    Last = level;

                    if (count == 0)
                    {
                        Cluster_Level_List.Add(new TPO_Cluster_Level(level, volume));
                        Cluster_Level_List.Last().LetterList.Add(letter);
                        Cluster_Level_List.Last().LetterListCount = Cluster_Level_List.Last().LetterList.Count;

                        Cluster_Level_List.Last().Volume_Letter[letter] = volume;

                        length = 1;
                        //Maximum volume finding
                        if (volume > MAX_Volume)
                        {
                            MAX_Volume = volume;
                            if (length == MAX_Length)
                                POC = level;
                            VOLUME_POC = level;
                        }
                        // Max length updating
                        if (length > MAX_Length)
                        {
                            MAX_Length = length;
                            POC = level;
                        }
                        //ValueAreaRangeVolume(VOLUME_POC, Cluster_Level_List, VA_percent, tickSize, MAX_Volume);
                        //ValueAreaRange(POC, Cluster_Level_List, VA_percent, tickSize, MAX_Length);
                        //CalculateHighLowRange(tickSize);
                    }
                    else
                    {

                        if (curList[0].LetterList.Where(a => a == letter).Count() == 0)
                        {
                            curList[0].LetterList.Add(letter);
                            length = curList[0].LetterList.Count;

                            // Max length updating
                            if (length > MAX_Length)
                            {
                                MAX_Length = length;
                                POC = level;
                            }
                            //ValueAreaRangeVolume(VOLUME_POC, Cluster_Level_List, VA_percent, tickSize, MAX_Volume);
                            //ValueAreaRange(POC, Cluster_Level_List, VA_percent, tickSize, MAX_Length);
                            //CalculateHighLowRange(tickSize);

                            curList[0].Volume_Letter[letter] = volume;
                        }
                        else
                        {
                            curList[0].Volume_Letter[letter] += volume;
                        }



                        curList[0].Volume += volume;

                        //Maximum volume finding
                        if (curList[0].Volume > MAX_Volume)
                        {
                            MAX_Volume = curList[0].Volume;
                            if (length == MAX_Length)
                                POC = level;
                            VOLUME_POC = level;//
                        }
                    }
                }

                else
                {
                    List<TPO_Cluster_Level> curList_1Tick = Cluster_Level_List_1Tick.Where(x => x.PriceLevel == level).ToList();
                    int count_1Tick = curList_1Tick.Count;
                    int length_1Tick = 0;
                    double volume_1Tick = vol_lett[letter];
                    //Last = level;

                    if (count_1Tick == 0)
                    {
                        Cluster_Level_List_1Tick.Add(new TPO_Cluster_Level(level, volume_1Tick));
                        Cluster_Level_List_1Tick.Last().LetterList.Add(letter);
                        Cluster_Level_List_1Tick.Last().LetterListCount = Cluster_Level_List_1Tick.Last().LetterList.Count;

                        Cluster_Level_List_1Tick.Last().Volume_Letter[letter] = volume_1Tick;

                        length_1Tick = 1;
                        //Maximum volume finding
                        if (volume_1Tick > MAX_Volume_1Tick)
                        {
                            MAX_Volume_1Tick = volume_1Tick;
                            if (length_1Tick == MAX_Length_1Tick)
                                POC_1Tick = level;
                            VOLUME_POC_1Tick = level;
                        }
                        // Max length updating
                        if (length_1Tick > MAX_Length_1Tick)
                        {
                            MAX_Length_1Tick = length_1Tick;
                            POC_1Tick = level;
                        }
                        ValueAreaRangeVolume(VOLUME_POC_1Tick, Cluster_Level_List_1Tick, VA_percent, tickSize, MAX_Volume_1Tick);
                        ValueAreaRange(POC_1Tick, Cluster_Level_List_1Tick, VA_percent, tickSize, MAX_Length_1Tick);
                        // CalculateHighLowRange(tickSize);
                    }
                    else
                    {

                        if (curList_1Tick[0].LetterList.Where(a => a == letter).Count() == 0)
                        {
                            curList_1Tick[0].LetterList.Add(letter);
                            length_1Tick = curList_1Tick[0].LetterList.Count;

                            // Max length updating
                            if (length_1Tick > MAX_Length_1Tick)
                            {
                                MAX_Length_1Tick = length_1Tick;
                                POC_1Tick = level;
                            }
                            ValueAreaRangeVolume(VOLUME_POC_1Tick, Cluster_Level_List_1Tick, VA_percent, tickSize, MAX_Volume_1Tick);
                            ValueAreaRange(POC_1Tick, Cluster_Level_List_1Tick, VA_percent, tickSize, MAX_Length_1Tick);
                            //CalculateHighLowRange(tickSize);

                            curList_1Tick[0].Volume_Letter[letter] = volume_1Tick;
                        }
                        else
                        {
                            curList_1Tick[0].Volume_Letter[letter] += volume_1Tick;
                        }
                        
                        curList_1Tick[0].Volume += volume_1Tick;

                        //Maximum volume finding
                        if (curList_1Tick[0].Volume > MAX_Volume_1Tick)
                        {
                            MAX_Volume_1Tick = curList_1Tick[0].Volume;
                            if (length_1Tick == MAX_Length_1Tick)
                                POC_1Tick = level;
                            VOLUME_POC_1Tick = level;//
                        }
                    }
                }
            }

			#endregion

			#region Determine time,letter, bar index...
			private string DetermineLetter(DateTime time)
			{
				//int TPO_range_count		=	(int)((StartTimeOfSession-EndTimeOfSession).TotalMinutes/TPO_Period);
				int TPO_range_number;
				string letter;
				
				TPO_range_number	=	(int)(((time-SessionBeginDate).TotalMinutes>0?(time-SessionBeginDate).TotalMinutes:0)/TPO_Period);
				TPO_range_number	=	TPO_range_number>45?45:TPO_range_number;
				letter 				=	tpo_letters[TPO_range_number];
				return(letter);
			}
			private string DetermineLetter(int	BarIndex)
			{
				//int TPO_range_count		=	(int)((StartTimeOfSession-EndTimeOfSession).TotalMinutes/TPO_Period);
				int TPO_range_number;
				string letter="";
							
				
				TPO_range_number	=	BarIndex-SessionBeginIndex;
				letter 				=	tpo_letters_day[TPO_range_number];
				
				return(letter);
			}
			public DateTime DetermineTime(string letter)
			{
				DateTime time;
				int TPO_range_number;
				
				TPO_range_number	=	tpo_letters.IndexOf(letter);
				if(TPO_range_number==-1)
					return(DateTime.MinValue);
				
				time	=	SessionBeginDate.AddMinutes(TPO_Period*TPO_range_number);
				return(time);
			}
			public DateTime DetermineTime(int TPO_letter_index)
			{
				DateTime time;
				int TPO_range_number	=	TPO_letter_index;
				
				
				time	=	SessionBeginDate.AddMinutes(TPO_Period*(TPO_range_number+1));
	
				return(time);
			}
			public int DetermineBarIndex(string letter)
			{
				int barindex;
				int TPO_range_number;
				
				TPO_range_number	=	tpo_letters_day.IndexOf(letter);
				
				barindex	=	SessionBeginIndex+TPO_range_number;
				return(barindex);
			}
			
			public int DetermineBarIndex(int TPO_letter_index)
			{
				int barindex;
				int TPO_range_number	=	TPO_letter_index;
				
				barindex	=	SessionBeginIndex+TPO_range_number;
				return(barindex);
			}
			#endregion

			#region Calculating Value area(TPO)
			public void ValueAreaRange(double poc, List<TPO_Cluster_Level> cluster_level_list,double distribution_percent,double TickSize,int max_length)
			{
				
                int increment = 1;
                int		summ_tpo		=	cluster_level_list.Sum(x=>x.LetterList.Count);
				double	value_area_summ	=	Math.Round(summ_tpo*distribution_percent,1);
				int 	summ			=	0;

				double	poc_top1		=	RoundToTickSize(poc+TickSize*increment,TickSize);
				double	poc_bottom1 	=	RoundToTickSize(poc-TickSize*increment,TickSize);
				double	poc_top2		=	RoundToTickSize(poc+2*TickSize*increment,TickSize);
				double	poc_bottom2 	=	RoundToTickSize(poc-2*TickSize*increment,TickSize);
				double	i 				=	RoundToTickSize(TickSize*increment,TickSize);
				double	val				=	poc;
				double	vah				=	poc;
				bool	top				=	true;
				bool	bottom			=	false;
				bool	reverse			=	false;
				double	all				=	0;
				
				while(summ<value_area_summ)
				{
					int poc_top_count		=	0;
					int	poc_bottom_count	=	0;
					
					all=0;
					for(int j=0;j<cluster_level_list.Count;j++)
					{
						if(RoundToTickSize(cluster_level_list[j].PriceLevel,TickSize)==poc_top1||RoundToTickSize(cluster_level_list[j].PriceLevel,TickSize)==poc_top2)
							poc_top_count		+=	cluster_level_list[j].LetterList.Where(z=>z!="0").Count();
						if(RoundToTickSize(cluster_level_list[j].PriceLevel,TickSize)==poc_bottom1||RoundToTickSize(cluster_level_list[j].PriceLevel,TickSize)==poc_bottom2)
						{
							poc_bottom_count	+=	cluster_level_list[j].LetterList.Where(z=>z!="0").Count();
						}
						all+=cluster_level_list[j].LetterList.Count;
					}
					if(poc_top_count>poc_bottom_count)
					{
						summ	+=	summ==0?poc_top_count+max_length:poc_top_count;
						vah		=	poc_top2;
						poc_top1		=	RoundToTickSize(poc_top1+2*i,TickSize);
						poc_top2		=	RoundToTickSize(poc_top2+2*i,TickSize);
						
					}
					if(poc_top_count<poc_bottom_count)
					{
						summ	+=	summ==0?poc_bottom_count+max_length:poc_bottom_count;
						val		=	poc_bottom2;
						poc_bottom1		=	RoundToTickSize(poc_bottom1-2*i,TickSize);
						poc_bottom2		=	RoundToTickSize(poc_bottom2-2*i,TickSize);
					}
					if(poc_top_count==poc_bottom_count)
					{
						if(top)
						{
							summ			+=	summ==0?poc_top_count+max_length:poc_top_count;
							vah				=	poc_top2;
							poc_top1		=	RoundToTickSize(poc_top1+2*i,TickSize);
							poc_top2		=	RoundToTickSize(poc_top2+2*i,TickSize);
							reverse			=	true;
						}
						else if(bottom)
						{
							summ			+=	summ==0?poc_bottom_count+max_length:poc_bottom_count;
							val				=	poc_bottom2;
							poc_bottom1		=	RoundToTickSize(poc_bottom1-2*i,TickSize);
							poc_bottom2		=	RoundToTickSize(poc_bottom2-2*i,TickSize);
							reverse			=	true;
						}
						
					}
					if(top&&reverse)
					{
						bottom	=	true;
						top		=	false;
						reverse	=	false;
					}
					if(bottom&&reverse)
					{
						bottom	=	false;
						top		=	true;
						reverse	=	false;
					}
					
					
					
				}

				VAH	=	vah;
				VAL	=	val;
				
				if(VAH>VOLUME_VAH)
				{
					ResistanceTopLevel		=	VAH;
					ResistanceBottomLevel	=	VOLUME_VAH;
				}
				else if(VAH<VOLUME_VAH)
				{
					ResistanceTopLevel		=	VOLUME_VAH;
					ResistanceBottomLevel	=	VAH;
				}
				else if(VAH==VOLUME_VAH)
				{
					ResistanceTopLevel		=	VAH+2*TickSize;
					ResistanceBottomLevel	=	VAH;
				}
				
				if(VAL>VOLUME_VAL)
				{
					SupportTopLevel		=	VAL;
					SupportBottomLevel	=	VOLUME_VAL;
				}
				else if(VAL<VOLUME_VAL)
				{
					SupportTopLevel		=	VOLUME_VAL;
					SupportBottomLevel	=	VAL;
				}
				else if(VAL==VOLUME_VAL)
				{
					SupportTopLevel		=	VAL;
					SupportBottomLevel	=	VAL-2*TickSize;
				}
			}
			#endregion
			
			#region Calculating Value area(VOL)
			public void ValueAreaRangeVolume(double poc, List<TPO_Cluster_Level> cluster_level_list,double distribution_percent,double TickSize,double max_volume)
			{
				
                int increment = 1;
                double	summ_tpo		=	cluster_level_list.Sum(x=>x.Volume);
				double	value_area_summ	=	Math.Round(summ_tpo*distribution_percent,1);
				double 	summ			=	0;
				double	poc_top1		=	RoundToTickSize(poc+TickSize*increment,TickSize);
				double	poc_bottom1 	=	RoundToTickSize(poc-TickSize*increment,TickSize);
				double	poc_top2		=	RoundToTickSize(poc+2*TickSize*increment,TickSize);
				double	poc_bottom2 	=	RoundToTickSize(poc-2*TickSize*increment,TickSize);
				double	i 				=	RoundToTickSize(TickSize*increment,TickSize);
				double	val				=	poc;
				double	vah				=	poc;
				bool	top				=	true;
				bool	bottom			=	false;
				bool	reverse			=	false;
				double	all				=	0;
				
				
				while(summ<value_area_summ)
				{
					double 	poc_top_count		=	0;
					double	poc_bottom_count	=	0;
					
					all=0;
					for(int j=0;j<cluster_level_list.Count;j++)
					{
						if(RoundToTickSize(cluster_level_list[j].PriceLevel,TickSize)==poc_top1||RoundToTickSize(cluster_level_list[j].PriceLevel,TickSize)==poc_top2)
							poc_top_count		+=	cluster_level_list[j].Volume;
						if(RoundToTickSize(cluster_level_list[j].PriceLevel,TickSize)==poc_bottom1||RoundToTickSize(cluster_level_list[j].PriceLevel,TickSize)==poc_bottom2)
							poc_bottom_count	+=	cluster_level_list[j].Volume;
						
					}
					if(poc_top_count>poc_bottom_count)
					{
						summ	+=	summ==0?poc_top_count+max_volume:poc_top_count;
						vah		=	poc_top1;
						poc_top1		=	RoundToTickSize(poc_top1+2*i,TickSize);
						poc_top2		=	RoundToTickSize(poc_top2+2*i,TickSize);
						
					}
					if(poc_top_count<poc_bottom_count)
					{
						summ	+=	summ==0?poc_bottom_count+max_volume:poc_bottom_count;
						val		=	poc_bottom1;
						poc_bottom1		=	RoundToTickSize(poc_bottom1-2*i,TickSize);
						poc_bottom2		=	RoundToTickSize(poc_bottom2-2*i,TickSize);
					}
					if(poc_top_count==poc_bottom_count)
					{
						if(top)
						{
							summ			+=	summ==0?poc_top_count+max_volume:poc_top_count;
							vah				=	poc_top1;
							poc_top1		=	RoundToTickSize(poc_top1+2*i,TickSize);
							poc_top2		=	RoundToTickSize(poc_top2+2*i,TickSize);
							reverse			=	true;
						}
						else if(bottom)
						{
							summ			+=	summ==0?poc_bottom_count+max_volume:poc_bottom_count;
							val				=	poc_bottom1;
							poc_bottom1		=	RoundToTickSize(poc_bottom1-2*i,TickSize);
							poc_bottom2		=	RoundToTickSize(poc_bottom2-2*i,TickSize);
							reverse			=	true;
						}
						
					}
					if(top&&reverse)
					{
						bottom	=	true;
						top		=	false;
						reverse	=	false;
					}
					if(bottom&&reverse)
					{
						bottom	=	false;
						top		=	true;
						reverse	=	false;
					}
					
					
				}
				VOLUME_VAH	=	vah;
				VOLUME_VAL	=	val;
				
				if(VAH>VOLUME_VAH)
				{
					ResistanceTopLevel		=	VAH;
					ResistanceBottomLevel	=	VOLUME_VAH;
				}
				else if(VAH<VOLUME_VAH)
				{
					ResistanceTopLevel		=	VOLUME_VAH;
					ResistanceBottomLevel	=	VAH;
				}
				else if(VAH==VOLUME_VAH)
				{
					ResistanceTopLevel		=	VAH+2*TickSize;
					ResistanceBottomLevel	=	VAH;
				}
				
				if(VAL>VOLUME_VAL)
				{
					SupportTopLevel		=	VAL;
					SupportBottomLevel	=	VOLUME_VAL;
				}
				else if(VAL<VOLUME_VAL)
				{
					SupportTopLevel		=	VOLUME_VAL;
					SupportBottomLevel	=	VAL;
				}
				else if(VAL==VOLUME_VAL)
				{
					SupportTopLevel		=	VAL;
					SupportBottomLevel	=	VAL-2*TickSize;
				}
			}
			#endregion
			
			#region RoundToTickSize
			static double RoundToTickSize(double rounding_value,double origin)
			{
				int multiplicator	=	(int)Math.Round(rounding_value/origin);
				return(multiplicator*origin);
			}
			#endregion
			
			#region CalculateHighLowRange
			public void CalculateHighLowRange(double tickSize)
			{
				double								offset						=	RoundToTickSize(tpoTicksIncrement*tickSize,tickSize);
				double 								first_non_single_low		=	Cluster_Level_List.OrderBy(x=>x.PriceLevel).FirstOrDefault(x=>x.LetterList.Count>1)!=null?
																					Cluster_Level_List.OrderBy(x=>x.PriceLevel).FirstOrDefault(x=>x.LetterList.Count>1).PriceLevel:0;
				List<TPO_Cluster_Level>				FirstNonSingleList_Low		=	Cluster_Level_List.Where(x=>RoundToTickSize(x.PriceLevel,tickSize)==RoundToTickSize(first_non_single_low-offset,tickSize)).ToList();
				double								first_single_low			=	FirstNonSingleList_Low.Count>0?FirstNonSingleList_Low[0].PriceLevel:0;	
				
				double 								first_non_single_high		=	Cluster_Level_List.OrderByDescending(x=>x.PriceLevel).FirstOrDefault(x=>x.LetterList.Count>1)!=null?
																					Cluster_Level_List.OrderByDescending(x=>x.PriceLevel).FirstOrDefault(x=>x.LetterList.Count>1).PriceLevel:0;
				List<TPO_Cluster_Level>				FirstNonSingleList_High		=	Cluster_Level_List.Where(x=>RoundToTickSize(x.PriceLevel,tickSize)==RoundToTickSize(first_non_single_high+offset,tickSize)).ToList();
				double								first_single_high			=	FirstNonSingleList_High.Count>0?FirstNonSingleList_High[0].PriceLevel:0;	
				
				
				High_Range_Start	=	first_single_high;
				Low_Range_Start		=	first_single_low;
			}
			#endregion
			
			#region CheckTouchZones
			public bool IsSupTouched(double level)
			{
				return(level<=SupportTopLevel && level>=SupportBottomLevel);
			}
			public bool IsResTouched(double level)
			{
				return(level<=ResistanceTopLevel && level>=ResistanceBottomLevel);
			}
            #endregion

            #region ResetAssist
            public void ResetAssist()
            {
                AssistSplit = false;
                AssistSplitLetterIndex = -1;
                AssistMerge = false;
				AssistLevel	=	-1;
            }
            #endregion
			
			#region MaxLengthCalculate
			
			public int MaxLengthCalc()
			{
				int max_length = 0;
				for(int i=0;i<Cluster_Level_List.Count;i++)
				{
					int let_length = 0;
					for(int j=0;j<Cluster_Level_List[i].LetterList.Count;j++)
					{
						if(Cluster_Level_List[i].LetterList[j]!="0")
							let_length ++;
					}
					
					if(let_length>max_length)
						max_length = let_length;
				}
				
				return(max_length);
			}
			
			public int MaxLengthCalc1Tick()
			{
				int max_length = 0;
				for(int i=0;i<Cluster_Level_List_1Tick.Count;i++)
				{
					int let_length = 0;
					for(int j=0;j<Cluster_Level_List_1Tick[i].LetterList.Count;j++)
					{
						if(Cluster_Level_List_1Tick[i].LetterList[j]!="0")
							let_length ++;
					}
					
					if(let_length>max_length)
						max_length = let_length;
				}
				
				return(max_length);
			}
			
			#endregion
        }
		
		// Price level class
		public class TPO_Cluster_Level
		{
			public 	double	  		Volume
			{get;set;}
			public 	double 			PriceLevel
			{get;set;}
			public 	List<string>	LetterList
			{get;set;}
			public	int				LetterListCount
			{get;set;}
			public Dictionary<string,double> Volume_Letter
			{get;set;}
			
			public TPO_Cluster_Level(double priceLevel,double volume)
			{
				LetterList	=	new List<string>();
				PriceLevel	=	priceLevel;
				Volume		=	volume;
				Volume_Letter	=	new Dictionary<string,double>();
			}
		}
		#endregion
	
		#region BAR FOOTPRINT CLASS
		public class BarFootPrint
		{
			public List<PriceFootPrint> FootprintList
			{get;set;}
			public	double  AskNetVolume
			{get;set;}
			public	double  BidNetVolume
			{get;set;}
			public 	double  Imbalance
			{get;set;}
			public	int    ImbalanceBrushID
			{get;set;}
			public	double	HighlightPercent;
				
//			private	double  TickSize;
			private	int	AskBid1BrushID;
			private	int	AskBid2BrushID;
			private	int	AskBid3BrushID;
			private	int	BidAsk1BrushID;
			private	int	BidAsk2BrushID;
			private	int	BidAsk3BrushID;
			/// <summary>
			/// 1.If the net Difference between Ask Volume vs Bid Volume is greater than 50%, 
			/// then Block color = Bright Green - 
			/// 2.If the net Difference between Ask Volume vs Bid Volume is 15% to 49%, 
			/// then Block color = Green - 
			/// 3.If the net difference between Bid Volume vs Ask Volume is greater than 50%, 
			/// then Block color = Bright Red - 
			/// 4.If the net difference between Bid Volume vs Ask Volume is 15% to 49%, 
			/// then BLock color = Red - 
			/// If the net difference between Bid Volume vs Ask Volume and ViceVersa is 0%-14% 
			/// 5.then Block Color Light Blue if Ask volume > Bid volume 
			/// 6.else Block color yellow if Bid volume > Ask volume 
			/// </summary>
			/// <param name="barIndex"></param>
			/// <param name="price"></param>
			/// <param name="volume"></param>
			/// <param name="ask"></param>
			//=============================================================================
			public BarFootPrint(double price, double volume,bool? ask,double tickSize, double highlightPercent,
				int Ask_Greater_Bid_50_BrushID, 
				int Ask_Greater_Bid_1549_BrushID,
				int Ask_Greater_Bid_014_BrushID,
				int Bid_Greater_Ask_50_BrushID,
				int Bid_Greater_Ask_1549_BrushID,
				int Bid_Greater_Ask_014_BrushID, 
				int BoxTickIncrement)
			{
				AskBid1BrushID		=	Ask_Greater_Bid_50_BrushID;
				AskBid2BrushID		=	Ask_Greater_Bid_1549_BrushID;
				AskBid3BrushID		=	Ask_Greater_Bid_014_BrushID;
				BidAsk1BrushID		=	Bid_Greater_Ask_50_BrushID;
				BidAsk2BrushID		=	Bid_Greater_Ask_1549_BrushID;
				BidAsk3BrushID		=	Bid_Greater_Ask_014_BrushID;

				//TickSize			=	tickSize;
				FootprintList 		= 	new List<PriceFootPrint>();
				HighlightPercent	=	highlightPercent;	
				if(ask==true)
				{
					FootprintList.Add(new PriceFootPrint(price,volume,0));
					AskNetVolume	=	volume;
					Imbalance		+=	volume;
					
				}
				if(ask==false)
				{
					FootprintList.Add(new PriceFootPrint(price,0,volume));
					BidNetVolume	=	volume;
					Imbalance		-=	volume;
				}

				FootprintList.Last().MaxPrice = RoundToTickSize(price+(BoxTickIncrement-1)*tickSize, tickSize);
				FootprintList.Last().MinPrice = RoundToTickSize(price, tickSize);
				CalcImbalanceState();
			}
			//=============================================================================
			public void AddPrint_(double price, double volume, bool? ask, int BoxTickIncrement, double tickSize)
			{
				List<PriceFootPrint> sourceList	= FootprintList.Where(x=>x.MaxPrice>=RoundToTickSize(price,tickSize) && x.MinPrice<=RoundToTickSize(price, tickSize)).ToList();

				double	maxLevel	=	FootprintList.Max(x=>x.MaxPrice);
				double	minLevel	=	FootprintList.Min(x=>x.MinPrice);

				bool IsAlready	=	sourceList.Count>0;

				if(!IsAlready)
				{
					if(ask==true)
					{
						FootprintList.Add(new PriceFootPrint(price,volume,0));
						AskNetVolume	+=volume;
						Imbalance		+=volume;
					}
					if(ask==false)
					{
						FootprintList.Add(new PriceFootPrint(price,0,volume));
						BidNetVolume	+=volume;
						Imbalance		-=volume;
					}

					if(price>maxLevel)
					{
						FootprintList.Last().MaxPrice = RoundToTickSize(maxLevel+BoxTickIncrement*tickSize, tickSize);
						FootprintList.Last().MinPrice = RoundToTickSize(maxLevel+tickSize, tickSize);
					}
					else
					{
						FootprintList.Last().MinPrice = RoundToTickSize(minLevel-BoxTickIncrement*tickSize, tickSize);
						FootprintList.Last().MaxPrice = RoundToTickSize(minLevel-tickSize, tickSize);
					}
					CalcHighlights(FootprintList.Last(), ask, tickSize);
				}
				else
				{
					PriceFootPrint priceFootPrint = sourceList[0];
					if(ask==true)
					{
						priceFootPrint.AskVolume += volume;
						AskNetVolume	+=volume;
						Imbalance		+=volume;
					}
					if(ask==false)
					{
						priceFootPrint.BidVolume += volume;
						BidNetVolume	+=volume;
						Imbalance		-=volume;
					}
					CalcHighlights(priceFootPrint, ask, tickSize);
				}
				CalcImbalanceState();
			}
			//=============================================================================
			private void CalcHighlights(PriceFootPrint footPrint1,bool? ask, double tickSize)
			{
				double price	=	footPrint1.Price;
				double volume	=	ask==true?footPrint1.AskVolume:ask==false?footPrint1.BidVolume:0;
				PriceFootPrint footPrint2	=	FootprintList.Where(x=>x.Price==RoundToTickSize(ask!=true?price+tickSize:price-tickSize,tickSize)).ToList().FirstOrDefault();
				if(footPrint2!=null)
				{
					double	volume2	=	ask==true?footPrint2.BidVolume:ask==false?footPrint2.AskVolume:0;

					double 	rel		=	1-volume2/volume;
					double	rel2	=	1-volume/volume2;

					if(rel>=HighlightPercent)
					{
						if(ask==true)
							footPrint1.AskHighlightState=1;
						if(ask==false)
							footPrint1.BidHighlightState=1;
					}
					else
					{
						if(ask==true)
							footPrint1.AskHighlightState=0;
						if(ask==false)
							footPrint1.BidHighlightState=0;
					}

					if(rel2<HighlightPercent)
					{
						if(ask==true)
							footPrint2.BidHighlightState=0;
						if(ask==false)
							footPrint2.AskHighlightState=0;
					}
				}
			}
			//=============================================================================
			public void CalcImbalanceState()
			{
				int result = 0;
				double rel;
				if(AskNetVolume>=BidNetVolume)
				{
					rel	=	Math.Round(1-BidNetVolume/AskNetVolume,2);
					result	=	rel>=0.5				?AskBid1BrushID:
								rel>=0.15 && rel<=0.49	?AskBid2BrushID:
								rel>=0    && rel<=0.14	?AskBid3BrushID:0;
				}
				else
				{
					rel	=	Math.Round(1-AskNetVolume/BidNetVolume,2);
					result	=	rel>=0.5				?BidAsk1BrushID:
								rel>=0.15 && rel<=0.49	?BidAsk2BrushID:
								rel>=0    && rel<=0.14	?BidAsk3BrushID:0;
				}

				ImbalanceBrushID = result;
			}
			//=============================================================================
			public class PriceFootPrint
			{
				public	double AskVolume
				{get; set;}
				public	double BidVolume
				{get; set;}
				public  double Price
				{get; set;}
				public	byte   BidHighlightState//1.Bid>Ask 68% Red,0.Nothing
				{get; set;}
				public	byte   AskHighlightState//1.Ask>Bid 68% Green,0.Nothing
				{get; set;}
				public double  MaxPrice
				{get; set;}
				public double  MinPrice
				{get; set;}
			//=============================================================================
				public PriceFootPrint(double price,double ask_volume,double bid_volume)
				{
					Price		=	price;
					AskVolume	=	ask_volume;
					BidVolume	=	bid_volume;
				}
			}
			//=============================================================================
			public static double RoundToTickSize(double rounding_value,double origin)
			{
				int multiplicator	=	(int)Math.Round(rounding_value/origin);
				return(multiplicator*origin);
			}
			//=============================================================================
		}
        #endregion

        #region SessionInfoClass
        public class SessionInfo
        {
            public int FirstBarIdx { get; set; }
            public int LastBarIdx { get; set; }

            public DateTime BeginDate { get; set; }

            public SessionInfo(int FirstBarIdx,DateTime BeginDate)
            {
                this.FirstBarIdx = FirstBarIdx;
                this.BeginDate = BeginDate;

            }
        }
        #endregion

        #region MISC
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
		private double RoundToTick(double p, double TickSize){
			int i = (int)Math.Round(p/TickSize,0);
			return i*TickSize;
		}
        #region FootprintPopulate
        private void FootprintPopulate(bool isFirstTickOfBar,bool isFirstBarOfSession,int CurrentBar,double LastPrice,double TickVolume,bool? IsAsk)
		{
//PrintNoDup(CurrentBar + "  FootPrint_List called "+Times[0][0].ToString());
			if(isFirstTickOfBar)
			{
				if(isFirstBarOfSession)
				{
					NetImbalance=0;
				}
				else
					NetImbalance	+= FootPrint_List.Count>0?FootPrint_List.Values.Last().Imbalance:0;

				FootPrint_List[CurrentBar] = (new BarFootPrint(LastPrice,TickVolume,IsAsk,TickSize, 0.68,
					ID_Ask_Greater_Bid_50_Brush,
					ID_Ask_Greater_Bid_1549_Brush,
					ID_Ask_Greater_Bid_014_Brush,
					ID_Bid_Greater_Ask_50_Brush,
					ID_Bid_Greater_Ask_1549_Brush,
					ID_Bid_Greater_Ask_014_Brush,
					BoxTickIncrement));
//Print(CurrentBar+"      FootPrint_List.Count is now "+FootPrint_List.Count);
			}
			else
			{
				if(FootPrint_List.Count>0)
				{
					FootPrint_List.Values.Last().AddPrint_(LastPrice,TickVolume,IsAsk,BoxTickIncrement,TickSize);
					NetImbalanceShow	=	NetImbalance+FootPrint_List.Values.Last().Imbalance;
				}
				else{
					FootPrint_List[CurrentBar] = (new BarFootPrint(LastPrice,TickVolume,IsAsk,TickSize, 0.68,
						ID_Ask_Greater_Bid_50_Brush,
						ID_Ask_Greater_Bid_1549_Brush,
						ID_Ask_Greater_Bid_014_Brush,
						ID_Bid_Greater_Ask_50_Brush,
						ID_Bid_Greater_Ask_1549_Brush,
						ID_Bid_Greater_Ask_014_Brush,
						BoxTickIncrement));
//Print(CurrentBar+"      FootPrint_List.Count is now "+FootPrint_List.Count);
				}
			}
#if NEW_CODE_NOV2018
//			while(FootPrint_List.Count<CurrentBars[0]){
//PrintNoDup(CurrentBars[0]+"      FootPrint_List.Count is short");
//				FootPrint_List[CurrentBar] = (new BarFootPrint (LastPrice, TickVolume, IsAsk, TickSize, 0.68, 
//					ID_Ask_Greater_Bid_50_Brush, 
//					ID_Ask_Greater_Bid_1549_Brush, 
//					ID_Ask_Greater_Bid_014_Brush, 
//					ID_Bid_Greater_Ask_50_Brush,
//					ID_Bid_Greater_Ask_1549_Brush, 
//					ID_Bid_Greater_Ask_014_Brush, 
//					BoxTickIncrement));
//PrintNoDup("        FootPrint_List.Count: "+FootPrint_List.Count);
//			}
#endif
		}
		#endregion
		
		#region TPOPopulate
		private void TPO_Populate(bool FirstTick, bool isNewSession,DateTime sessionBegin,DateTime sessionEnd,int CurrentBar,int PrevBar,double lastPrice,DateTime TickTime,double TickVolume,bool isHistorical,double Low)
		{
			if(first_run||isNewSession)
			{
				first_run	=	false;
				if(!DailyMode)
				{
                    //Finding bar index of first TPO bar
                    int FirstIndex	=	CurrentBar;//+1;
                                                   //Adding new TPO Cluster to the list
					TPO_Cluster_List.Add(new TPO_Cluster(sessionBegin,sessionEnd,sessionBegin,sessionEnd,TPO_Period,FirstIndex,RoundToTick(Low, TickSize),
						FirstIndex,TickSize,TPO_Ticks_Increment,lastPrice,DailyMode));//Lows[1][0]
				}
				else
				{
					if(CurrentBar<14)
						return;
					else
					{
						if(day_count==89)
						{
							day_count =	-1;
//PrintNoDup("6799  Adding TPO_Cluster_List "+Times[0].GetValueAt(CurrentBars[0])+"  CB: "+CurrentBars[0]);
						}
						day_count++;
						if(day_count==0)
						{
							TPO_Ticks_Increment	= (int)(ATR(14)[0]/4/TickSize);	
							//Finding bar index of first TPO bar
							int FirstIndex	=	CurrentBar;//+1;
                                                           //Adding new TPO Cluster to the list
                            
							TPO_Cluster_List.Add(new TPO_Cluster(FirstIndex, sessionBegin, sessionEnd, TPO_Period, FirstIndex, RoundToTick(Low, TickSize),
									FirstIndex, TickSize, TPO_Ticks_Increment, lastPrice, DailyMode));//Lows[1][0]
						}
						TPO_Cluster_List.Last().EndTimeOfSession	=	sessionEnd;
					}
				}
			}
			if(TPO_Cluster_List.Count>0)
			{
				if (!AllSplitMode || !FirstTick)
				{
					double level = RoundToTick(lastPrice, TickSize);
					double st_point = TPO_Cluster_List.Last().StartPoint;
					double dif = RoundToTick(st_point, TickSize) - RoundToTick(level, TickSize);
//					dif = RoundToTick(dif, TickSize);
					double ost = Math.Round(dif / TickSize) % TPO_Cluster_List.Last().tpoTicksIncrement;

					TPO_Cluster_List.Last().AddLevel(level, TickTime, TickVolume, CurrentBar, ost, pVASize_Pct); //Times[1][0] Volumes[1][0]
                                                                                                    //Collect data only from increment levels
					if (ost == 0)
					{
						TPO_Cluster_List.Last().LastBarIndex = TPO_Cluster_List.Last().FirstIndex + TPO_Cluster_List.Last().MAX_Length - 1;
//PrintNoDup("6831  Setting LastBarIndex to "+Times[0].GetValueAt(TPO_Cluster_List.Last().LastBarIndex).ToString()+"   MaxLength: "+TPO_Cluster_List.Last().MAX_Length+"   tpoTicksInc: "+TPO_Cluster_List.Last().tpoTicksIncrement);
						TPO_Cluster_List.Last().EndTimeOfSession = sessionEnd;
					}
				}
				else if(AllSplitMode && FirstTick)
				{
//PrintNoDup("6837  Adding TPO_Cluster_List "+Times[0].GetValueAt(CurrentBars[0])+" "+CurrentBars[0]);
					TPO_Cluster_List.Add(new TPO_Cluster(CurrentBar, Times[0].GetValueAt(CurrentBar), Times[0].GetValueAt(CurrentBar), TPO_Period, CurrentBar, RoundToTick(Low, TickSize),
							CurrentBar, TickSize, TPO_Ticks_Increment, lastPrice, DailyMode));
                }
            }
		}
        #endregion

        #region RoundToSomeValue(double someValue)
        double RoundToSomeValue(double someValue, double roundedValue, double anyRoundedPrice)
        {
            bool debug = false;

            double res = 0;

            if (debug)
                PrintNoDup("someValue " + someValue + " roundedValue " + roundedValue + " anyRoundedPrice " + anyRoundedPrice);

            double dif = anyRoundedPrice - roundedValue;

            if (debug)
                PrintNoDup("dif " + dif);

            int integer = someValue != 0 ? Math.Abs((int)(dif / someValue)) : 0;

            if (debug)
                PrintNoDup("integer " + integer);

            double ost = Math.Abs(dif % someValue);

            if (debug)
                PrintNoDup("ost " + ost);

            double lower = 0;
            double higher = 0;



            if (dif <= 0)
            {
                lower = anyRoundedPrice + integer * someValue;
                higher = lower + someValue;

            }
            else
            {
                higher = anyRoundedPrice - integer * someValue;
                lower = higher - someValue;
            }
            if (debug)
                PrintNoDup("lower " + lower);
            if (debug)
                PrintNoDup("higher " + higher);


            if ((ost / someValue >= 0.5 && dif <= 0) || (ost / someValue < 0.5 && dif > 0))
                res = higher;
            else
                res = lower;

            if (debug)
                PrintNoDup("res " + res);

            return (res);
        }
        #endregion

        #region BondsPrice
        string BondsPrice(double price)
        {
            //return(Math.Floor(price) + "'" + ((price - Math.Floor(price)) * 32).ToString("00"));
            double trunc = Math.Truncate(price);
            int fraction = Convert.ToInt32(320 * Math.Abs(price - trunc) - 0.0001); // rounding down for ZF and ZT
            string priceMarker = "";
            if (TickSize == 0.03125)
            {
                fraction = fraction / 10;
                if (fraction < 10)
                    priceMarker = trunc.ToString() + "'0" + fraction.ToString();
                else
                    priceMarker = trunc.ToString() + "'" + fraction.ToString();
            }
            else if (TickSize == 0.015625 || TickSize == 0.0078125)
            {
                if (fraction < 10)
                    priceMarker = trunc.ToString() + "'00" + fraction.ToString();
                else if (fraction < 100)
                    priceMarker = trunc.ToString() + "'0" + fraction.ToString();
                else
                    priceMarker = trunc.ToString() + "'" + fraction.ToString();
            }
            else
                priceMarker = price.ToString();
            return priceMarker;
        }
        #endregion
        
		#region InstrumentIncrementSettings Class
		
		public class InstrumentIncrementSettings
		{
            List<InstrumentIncrementSetting> IncrumentSettings { get; set; }
            

            public InstrumentIncrementSettings()
            {
                IncrumentSettings = new List<InstrumentIncrementSetting>();

                IncrumentSettings.Add(new InstrumentIncrementSetting("ES", 1, 3));
                IncrumentSettings.Add(new InstrumentIncrementSetting("NQ", 4, 12));
                IncrumentSettings.Add(new InstrumentIncrementSetting("YM", 2, 8));
                IncrumentSettings.Add(new InstrumentIncrementSetting("TF", 2, 4));
                IncrumentSettings.Add(new InstrumentIncrementSetting("RTY", 1, 4));
                IncrumentSettings.Add(new InstrumentIncrementSetting("ZB", 1, 1));
                IncrumentSettings.Add(new InstrumentIncrementSetting("ZF", 1, 3));
                IncrumentSettings.Add(new InstrumentIncrementSetting("ZT", 1, 3));
                IncrumentSettings.Add(new InstrumentIncrementSetting("UB", 1, 3));
                IncrumentSettings.Add(new InstrumentIncrementSetting("CL", 2, 4));
                IncrumentSettings.Add(new InstrumentIncrementSetting("NG", 2, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("GM", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("QG", 1, 1));
                IncrumentSettings.Add(new InstrumentIncrementSetting("GC", 2, 4));
                IncrumentSettings.Add(new InstrumentIncrementSetting("SI", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("HG", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("PL", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("PA", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("6E", 2, 4));
                IncrumentSettings.Add(new InstrumentIncrementSetting("6A", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("6B", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("6C", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("6S", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("6N", 1, 1));
                IncrumentSettings.Add(new InstrumentIncrementSetting("6M", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("FDAX", 2, 10));
                IncrumentSettings.Add(new InstrumentIncrementSetting("FESX", 1, 1));
                IncrumentSettings.Add(new InstrumentIncrementSetting("FGBL", 1, 2));
                IncrumentSettings.Add(new InstrumentIncrementSetting("BTC", 1, 4));
                IncrumentSettings.Add(new InstrumentIncrementSetting("XBT", 1, 4));
            }

            public int[] GetSettings(string InstName, bool IsSubPipSpotFX, double StockPrice)
            {
                InstrumentIncrementSetting sett = IncrumentSettings.Find(v => v.InstrumentName == InstName);

                if(sett!=null)
                {
                    return (new int[] { sett.BoxTick, sett.TPOTick });
                }
                else if(IsSubPipSpotFX)
                    return (new int[] { 10, 20 });
				else if(!double.IsNaN(StockPrice)){
					if(StockPrice <=10) return new int[]{5,5};
					else if(StockPrice <=50) return new int[]{10,10};
					else if(StockPrice <=100) return new int[]{20,20};
					else if(StockPrice <=500) return new int[]{30,30};
					else if(StockPrice <=1000) return new int[]{50,50};
					else return new int[]{100,100};
				}
                    return (new int[] { 1, 4 });
            }

            private class InstrumentIncrementSetting
            {
                public string InstrumentName { get; set; }
                public int BoxTick { get; set; }
                public int TPOTick { get; set; }

                public InstrumentIncrementSetting(string InstrumentName, int BoxTick, int TPOTick)
                {
                    this.InstrumentName = InstrumentName;
                    this.BoxTick = BoxTick;
                    this.TPOTick = TPOTick;
                }
            }
		}
		#endregion
		
		bool    EqualColor(Brush FirstBrush,Brush SecondBrush)
		{
			return (((SolidColorBrush)FirstBrush).Color == ((SolidColorBrush)SecondBrush).Color); 
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_TPO_Distributions[] cacheARC_TPO_Distributions;
		public ARC.ARC_TPO_Distributions ARC_TPO_Distributions(int tPO_PERIOD, int tPO_TICKS_INCREMENT, bool tPO_Ticks_Increment_Auto, bool tPO_Profile_Enabled, bool volume_Profile_Enabled, float vOL_HIST_OPACITY, int autoMergeManipulation)
		{
			return ARC_TPO_Distributions(Input, tPO_PERIOD, tPO_TICKS_INCREMENT, tPO_Ticks_Increment_Auto, tPO_Profile_Enabled, volume_Profile_Enabled, vOL_HIST_OPACITY, autoMergeManipulation);
		}

		public ARC.ARC_TPO_Distributions ARC_TPO_Distributions(ISeries<double> input, int tPO_PERIOD, int tPO_TICKS_INCREMENT, bool tPO_Ticks_Increment_Auto, bool tPO_Profile_Enabled, bool volume_Profile_Enabled, float vOL_HIST_OPACITY, int autoMergeManipulation)
		{
			if (cacheARC_TPO_Distributions != null)
				for (int idx = 0; idx < cacheARC_TPO_Distributions.Length; idx++)
					if (cacheARC_TPO_Distributions[idx] != null && cacheARC_TPO_Distributions[idx].TPO_PERIOD == tPO_PERIOD && cacheARC_TPO_Distributions[idx].TPO_TICKS_INCREMENT == tPO_TICKS_INCREMENT && cacheARC_TPO_Distributions[idx].TPO_Ticks_Increment_Auto == tPO_Ticks_Increment_Auto && cacheARC_TPO_Distributions[idx].TPO_Profile_Enabled == tPO_Profile_Enabled && cacheARC_TPO_Distributions[idx].Volume_Profile_Enabled == volume_Profile_Enabled && cacheARC_TPO_Distributions[idx].VOL_HIST_OPACITY == vOL_HIST_OPACITY && cacheARC_TPO_Distributions[idx].AutoMergeManipulation == autoMergeManipulation && cacheARC_TPO_Distributions[idx].EqualsInput(input))
						return cacheARC_TPO_Distributions[idx];
			return CacheIndicator<ARC.ARC_TPO_Distributions>(new ARC.ARC_TPO_Distributions(){ TPO_PERIOD = tPO_PERIOD, TPO_TICKS_INCREMENT = tPO_TICKS_INCREMENT, TPO_Ticks_Increment_Auto = tPO_Ticks_Increment_Auto, TPO_Profile_Enabled = tPO_Profile_Enabled, Volume_Profile_Enabled = volume_Profile_Enabled, VOL_HIST_OPACITY = vOL_HIST_OPACITY, AutoMergeManipulation = autoMergeManipulation }, input, ref cacheARC_TPO_Distributions);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_TPO_Distributions ARC_TPO_Distributions(int tPO_PERIOD, int tPO_TICKS_INCREMENT, bool tPO_Ticks_Increment_Auto, bool tPO_Profile_Enabled, bool volume_Profile_Enabled, float vOL_HIST_OPACITY, int autoMergeManipulation)
		{
			return indicator.ARC_TPO_Distributions(Input, tPO_PERIOD, tPO_TICKS_INCREMENT, tPO_Ticks_Increment_Auto, tPO_Profile_Enabled, volume_Profile_Enabled, vOL_HIST_OPACITY, autoMergeManipulation);
		}

		public Indicators.ARC.ARC_TPO_Distributions ARC_TPO_Distributions(ISeries<double> input , int tPO_PERIOD, int tPO_TICKS_INCREMENT, bool tPO_Ticks_Increment_Auto, bool tPO_Profile_Enabled, bool volume_Profile_Enabled, float vOL_HIST_OPACITY, int autoMergeManipulation)
		{
			return indicator.ARC_TPO_Distributions(input, tPO_PERIOD, tPO_TICKS_INCREMENT, tPO_Ticks_Increment_Auto, tPO_Profile_Enabled, volume_Profile_Enabled, vOL_HIST_OPACITY, autoMergeManipulation);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_TPO_Distributions ARC_TPO_Distributions(int tPO_PERIOD, int tPO_TICKS_INCREMENT, bool tPO_Ticks_Increment_Auto, bool tPO_Profile_Enabled, bool volume_Profile_Enabled, float vOL_HIST_OPACITY, int autoMergeManipulation)
		{
			return indicator.ARC_TPO_Distributions(Input, tPO_PERIOD, tPO_TICKS_INCREMENT, tPO_Ticks_Increment_Auto, tPO_Profile_Enabled, volume_Profile_Enabled, vOL_HIST_OPACITY, autoMergeManipulation);
		}

		public Indicators.ARC.ARC_TPO_Distributions ARC_TPO_Distributions(ISeries<double> input , int tPO_PERIOD, int tPO_TICKS_INCREMENT, bool tPO_Ticks_Increment_Auto, bool tPO_Profile_Enabled, bool volume_Profile_Enabled, float vOL_HIST_OPACITY, int autoMergeManipulation)
		{
			return indicator.ARC_TPO_Distributions(input, tPO_PERIOD, tPO_TICKS_INCREMENT, tPO_Ticks_Increment_Auto, tPO_Profile_Enabled, volume_Profile_Enabled, vOL_HIST_OPACITY, autoMergeManipulation);
		}
	}
}

#endregion
