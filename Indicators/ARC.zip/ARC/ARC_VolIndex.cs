#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public enum ARC_VolIndex_DisplayModes {Ticks,Points}

	public class ARC_VolIndex : Indicator
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "VolIndex";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "21602", "27405"};//27405 is Annual Membership
		private string indicatorVersion = "v1.0";
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		private DateTime AsiaBegin, AsiaEnd;
		private DateTime EuropeBegin, EuropeEnd;
		private DateTime USABegin, USAEnd;
		private string CurrentSession = string.Empty;
		private bool Initialized = false;
		private double HH = double.MinValue;
		private double LL = double.MaxValue;
		private bool HidePlots = false;
		private Series<double> AsiaVolatility;
		private Series<double> EuroVolatility;
		private Series<double> USAVolatility;
		private string format   = string.Empty;
		private bool InSession1 = false;
		private bool InSession2 = false;
		private bool InSession3 = false;

		private class SessionData{
			public DateTime Ended = DateTime.MinValue;
			public double High = double.MinValue;
			public double Low = double.MaxValue;
			public double Range = 0;
			public SessionData(DateTime ended, double high, double low){
				Ended = ended; High=high; Low=low; Range=0;
			}
			public void UpdateHL(double high, double low){
				High=Math.Max(High,high); Low=Math.Min(Low,low); Range=High-Low;
			}
		}
		private SortedDictionary<string,List<SessionData>> SessionDict = new SortedDictionary<string, List<SessionData>>();
		private SortedDictionary<int,List<double>> BarDict = new SortedDictionary<int,List<double>>();//the key is the time, in int format, and the value is the list of ranges

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "ARC_VolIndex";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= false;
				DrawVerticalGridLines						= false;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;

				AsiaStart   = DateTime.Parse("18:00", System.Globalization.CultureInfo.InvariantCulture);
				AsiaStop    = DateTime.Parse("3:00", System.Globalization.CultureInfo.InvariantCulture);
//				AsiaPlotColor = Brushes.Orange;
				EuropeStart = DateTime.Parse("3:00", System.Globalization.CultureInfo.InvariantCulture);
				EuropeStop  = DateTime.Parse("11:30", System.Globalization.CultureInfo.InvariantCulture);
//				EuroPlotColor = Brushes.Cyan;
				USAStart    = DateTime.Parse("9:30", System.Globalization.CultureInfo.InvariantCulture);
				USAStop     = DateTime.Parse("16:00", System.Globalization.CultureInfo.InvariantCulture);
//				USAPlotColor = Brushes.Green;

				DisplayMode = ARC_VolIndex_DisplayModes.Ticks;
				LocationDialogBox = TextPosition.BottomLeft;

				AddPlot(new Stroke(Brushes.Orange,2), PlotStyle.Hash, "AvgAsiaVol_Plot");
				AddPlot(new Stroke(Brushes.Cyan,2),   PlotStyle.Hash, "AvgEuroVol_Plot");
				AddPlot(new Stroke(Brushes.Green,2),  PlotStyle.Hash, "AvgUSAVol_Plot");
				//AddPlot(new Stroke(Brushes.DarkOrange, 1), PlotStyle.Bar,  "AvgBarVolatility");
				//AddPlot(new Stroke(Brushes.Red, 2),        PlotStyle.Hash, "BarRange");
				//AddPlot(new Stroke(Brushes.Cyan,2),        PlotStyle.Hash, "CurSessionRange");
			}
			else if (State == State.Configure)
			{
				IsDebug = System.IO.File.Exists(@"c:\222222222222.txt") && (NinjaTrader.Cbi.License.MachineId.CompareTo("1E53E271B82EC62C7C03A15C336229AE")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion
			}
			if (State == State.DataLoaded)
			{
				if(Plots[0].Pen.Brush.ToString()==Brushes.Transparent.ToString()) HidePlots = true; else HidePlots=false;
				AsiaVolatility = new Series<double>(this);
				EuroVolatility = new Series<double>(this);
				USAVolatility = new Series<double>(this);
			}
			if (State == State.Historical)
			{
				format = Instrument.MasterInstrument.FormatPrice(1.111111111111111111111111111).Replace("1","0");
				//Print("format: "+format);
			}

		}
//===================================================================================================================
		private string UpdateBeginEnd(ref DateTime Begin, ref DateTime End, string Session){
			string retval = string.Empty;
			if(Time[0]>=End) {
				retval = Session+" ended";
				while(Time[0] >= End){
					Begin = Begin.AddDays(1);
					if(End<Begin)
						End = End.AddDays(1);
				}
			}
			bool c1 = Time[0] >= Begin && Time[1] < Begin;
			bool c2 = Time[0] >= Begin && Time[0] < End;
			if(c1 || c2) {
				retval = Session;
			}
			return retval;
		}
//===================================================================================================================
		private double GetAvg(List<SessionData> S){
			if(S==null) return 0;
			if(S.Count==0) return 0;
			double sum = 0;
			foreach(var v in S) {
				//Print("H: "+v.High+"  L: "+v.Low);
				sum = sum + v.Range;
			}
			return sum/S.Count;
		}
//===================================================================================================================
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(BarsArray.Length<=0) return;
			if(BarsArray[0].Count<=0) return;
			if(CurrentBar<=1) return;
			if(!Initialized){
				try{
					AsiaBegin   = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, AsiaStart.Hour, AsiaStart.Minute, AsiaStart.Second);
					AsiaEnd     = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, AsiaStop.Hour, AsiaStop.Minute, AsiaStop.Second);
					EuropeBegin = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, EuropeStart.Hour, EuropeStart.Minute, EuropeStart.Second);
					EuropeEnd   = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, EuropeStop.Hour, EuropeStop.Minute, EuropeStop.Second);
					USABegin    = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, USAStart.Hour, USAStart.Minute, USAStart.Second);
					USAEnd      = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, USAStop.Hour, USAStop.Minute, USAStop.Second);
					if(AsiaBegin > AsiaEnd)     AsiaEnd   = AsiaEnd.AddDays(1);
					if(EuropeBegin > EuropeEnd) EuropeEnd = EuropeEnd.AddDays(1);
					if(USABegin > USAEnd)       USAEnd    = USAEnd.AddDays(1);
					Initialized = true;
				}catch(Exception e){
					Print(e);
				}
				if(!Initialized) return;
			}
			AsiaVolatility[0] = AsiaVolatility[1];
			EuroVolatility[0] = EuroVolatility[1];
			USAVolatility[0]  = USAVolatility[1];

			var Session1 = UpdateBeginEnd(ref AsiaBegin, ref AsiaEnd, "Asia");
			var Session2 = UpdateBeginEnd(ref EuropeBegin, ref EuropeEnd, "Europe");
			var Session3 = UpdateBeginEnd(ref USABegin, ref USAEnd, "USA");

			string CurrentS = "Asia";
			if(Session1.Contains("ended")){
				Session1=string.Empty;
				CurrentSession = string.Empty;
				InSession1 = false;
			}else if(Session1.Contains(CurrentS) && !InSession1){
				InSession1 = true;
				if(SessionDict.ContainsKey(CurrentS)) {
					AvgAsiaVol_Plot[0] = GetAvg(SessionDict[CurrentS]);
					AvgAsiaVol_Plot[1] = AvgAsiaVol_Plot[0];
				}
				if(!SessionDict.ContainsKey(CurrentS)) SessionDict[CurrentS] = new List<SessionData>();
				SessionDict[CurrentS].Add(new SessionData(Time[0], High[0], Low[0]));
			}
			CurrentS = "Europe";
			if(Session2.Contains("ended")){
//				if(SessionDict.ContainsKey("Europe") && HH>double.MinValue && LL<double.MaxValue) SessionDict["Europe"].Add(new SessionData(Time[0], HH, LL));
				//HH = double.MinValue; LL = double.MaxValue;
				Session2=string.Empty;
				CurrentSession = string.Empty;
				InSession2 = false;
			}else if(Session2.Contains(CurrentS) && !InSession2){
				InSession2 = true;
				if(SessionDict.ContainsKey(CurrentS)) {
					AvgEuroVol_Plot[0] = GetAvg(SessionDict[CurrentS]);
					AvgEuroVol_Plot[1] = AvgEuroVol_Plot[0];
				}
				if(!SessionDict.ContainsKey(CurrentS)) SessionDict[CurrentS] = new List<SessionData>();
				SessionDict[CurrentS].Add(new SessionData(Time[0], High[0], Low[0]));
			}
			CurrentS = "USA";
			if(Session3.Contains("ended")){
//				if(SessionDict.ContainsKey(CurrentS) && HH>double.MinValue && LL<double.MaxValue) SessionDict[CurrentS].Add(new SessionData(Time[0], HH, LL));
				//HH = double.MinValue; LL = double.MaxValue;
				Session3 = string.Empty;
				CurrentSession = string.Empty;
				InSession3 = false;
			}else if(Session3.Contains(CurrentS) && !InSession3){
				InSession3 = true;
				if(SessionDict.ContainsKey(CurrentS)) {
					AvgUSAVol_Plot[0] = GetAvg(SessionDict[CurrentS]);
					AvgUSAVol_Plot[1] = AvgUSAVol_Plot[0];
				}
				if(!SessionDict.ContainsKey(CurrentS)) SessionDict[CurrentS] = new List<SessionData>();
//else
//	Print(Time[0].ToShortDateString()+"  Range of USA: "+SessionDict[CurrentS].Last().High+"-"+SessionDict[CurrentS].Last().Low+" = "+(SessionDict[CurrentS].Last().High-SessionDict[CurrentS].Last().Low).ToString());
				SessionDict[CurrentS].Add(new SessionData(Time[0], High[0], Low[0]));
			}

			if(InSession1){
				CurrentS = "Asia";
				AvgAsiaVol_Plot[0] = AvgAsiaVol_Plot[1];
				AsiaVolatility[0] = AvgAsiaVol_Plot[0];
				if(SessionDict[CurrentS].Count>0) SessionDict[CurrentS].Last().UpdateHL(High[0], Low[0]);
			}else
				AsiaVolatility[0] = AsiaVolatility[1];

			if(InSession2){
				CurrentS = "Europe";
				AvgEuroVol_Plot[0] = AvgEuroVol_Plot[1];
				EuroVolatility[0] = AvgEuroVol_Plot[0];
				if(SessionDict[CurrentS].Count>0) SessionDict[CurrentS].Last().UpdateHL(High[0], Low[0]);
			}else
				EuroVolatility[0] = EuroVolatility[1];

			if(InSession3){
				CurrentS = "USA";
				AvgUSAVol_Plot[0] = AvgUSAVol_Plot[1];
				USAVolatility[0] = AvgUSAVol_Plot[0];
				if(SessionDict[CurrentS].Count>0) SessionDict[CurrentS].Last().UpdateHL(High[0], Low[0]);
//Draw.Dot(this,Time[0].Day.ToString()+"H",false,0,SessionDict[CurrentS].Last().High, Brushes.Red);
//Draw.Dot(this,Time[0].Day.ToString()+"L",false,0,SessionDict[CurrentS].Last().Low, Brushes.Blue);
			}else
				USAVolatility[0] = USAVolatility[1];

//			var sess = string.Format("{0}{1}{2}",Session1,Session2,Session3).Replace(" ",string.Empty).Trim();
//			if(sess.Length>0)
//				CurrentSession = sess;
//			if(CurrentSession.Length>0){
//				if(!SessionDict.ContainsKey(CurrentSession)) SessionDict[CurrentSession] = new List<SessionData>();
//				HH = Math.Max(HH, High[0]);
//				LL = Math.Min(LL, Low[0]);
//				CurSessionRange[0] = HH-LL;
//				AvgSessionVolatility[0] = GetAvg(SessionDict[CurrentSession]);
//				if(CurrentSession == "Asia"){
////					PlotBrushes[2][0] = AsiaPlotColor;
//					AsiaVolatility[0] = AvgSessionVolatility[0];
//				}
//				else if(CurrentSession == "Europe"){
////					PlotBrushes[2][0] = EuroPlotColor;
//					EuroVolatility[0] = AvgSessionVolatility[0];
//				}
//				else if(CurrentSession == "USA"){
////					PlotBrushes[2][0] = USAPlotColor;
//					USAVolatility[0]  = AvgSessionVolatility[0];
//				}
////				if(!HidePlots && CurSessionRange[0]>AvgSessionVolatility[0]) PlotBrushes[3][0] = Brushes.Red;
////Print(CurrentSession+" ("+SessionDict[CurrentSession].Count+")  Avg: "+(AvgSessionVolatility[0]/TickSize).ToString("0"));
//			}
			
//			if(IsFirstTickOfBar){
//				var t = ToTime(Time[1]);
//				if(!BarDict.ContainsKey(t)) BarDict[t] = new List<double>();
//				BarDict[t].Add(High[1]-Low[1]);
//				t = ToTime(Time[0]);
//				if(BarDict.ContainsKey(t) && BarDict[t].Count>0) AvgBarVolatility[0] = BarDict[t].Average();
//				CurBarRange[0] = High[0]-Low[0];
//			}

			string msg = string.Empty;
			#region Draw output text box
			double LargeVol = 0;
			string LargeSession =string.Empty;
			double MedVol = 0;
			string MedSession =string.Empty;
			double SmallVol = 0;
			string SmallSession =string.Empty;
			if(USAVolatility[0] > AsiaVolatility[0] && USAVolatility[0]>EuroVolatility[0]){
				LargeVol = USAVolatility[0];
				LargeSession = "USA";
				if(AsiaVolatility[0] > EuroVolatility[0]){
					MedVol = AsiaVolatility[0];
					MedSession = "Asia";
					SmallVol = EuroVolatility[0];
					SmallSession = "Europe";
				}else{
					MedVol = EuroVolatility[0];
					MedSession = "Europe";
					SmallVol = AsiaVolatility[0];
					SmallSession = "Asia";
				}
			}else if(EuroVolatility[0] > AsiaVolatility[0] && EuroVolatility[0]>USAVolatility[0]){
				LargeVol = EuroVolatility[0];
				LargeSession = "Europe";
				if(USAVolatility[0] > AsiaVolatility[0]){
					MedVol = USAVolatility[0];
					MedSession = "USA";
					SmallVol = AsiaVolatility[0];
					SmallSession = "Asia";
				}else{
					MedVol = AsiaVolatility[0];
					MedSession = "Asia";
					SmallVol = USAVolatility[0];
					SmallSession = "USA";
				}
			}else if(AsiaVolatility[0] > EuroVolatility[0] && AsiaVolatility[0]>EuroVolatility[0]){
				LargeVol = AsiaVolatility[0];
				LargeSession = "Asia";
				if(USAVolatility[0] > EuroVolatility[0]){
					MedVol = USAVolatility[0];
					MedSession = "USA";
					SmallVol = EuroVolatility[0];
					SmallSession = "Europe";
				}else{
					MedVol = EuroVolatility[0];
					MedSession = "Europe";
					SmallVol = USAVolatility[0];
					SmallSession = "USA";
				}
			}
			if(DisplayMode == ARC_VolIndex_DisplayModes.Points)
				msg = string.Format("{1}-pts on {2}{0}{3}-pts on {4}{0}{5}-pts on {6}",Environment.NewLine, 
							LargeVol.ToString(format), LargeSession, 
							MedVol.ToString(format), MedSession, 
							SmallVol.ToString(format), SmallSession);
			else if(DisplayMode == ARC_VolIndex_DisplayModes.Ticks)
				msg = string.Format("{1}-tks on {2}{0}{3}-tks on {4}{0}{5}-tks on {6}",Environment.NewLine, 
							(LargeVol/TickSize).ToString("0"), LargeSession, 
							(MedVol/TickSize).ToString("0"), MedSession, 
							(SmallVol/TickSize).ToString("0"), SmallSession);
			Draw.TextFixed(this,"avgvolinfo", string.Format("{0}{1}{2}-days in calculation",msg,Environment.NewLine,
						SessionDict.ContainsKey("USA") ? SessionDict["USA"].Count : (SessionDict.ContainsKey("Europe") ? SessionDict["Europe"].Count : (SessionDict.ContainsKey("Asia") ? SessionDict["Asia"].Count : 0))
						), this.LocationDialogBox);
			#endregion
		}
//============================================================================================================================
		#region Properties

		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="Asia Start", Description="Start time of the asian session, based on your computer clock", Order=10, GroupName="Parameters")]
		public DateTime AsiaStart		{ get; set; }
		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="Asia Stop", Description="Stop time of the asian session, based on your computer clock", Order=11, GroupName="Parameters")]
		public DateTime AsiaStop		{ get; set; }
//		[XmlIgnore]
//		[Display(Name="Asia Color", Description="Color of Asia AvgSessionVolatility", Order=12, GroupName="Parameters")]
//		public Brush AsiaPlotColor
//		{ get; set; }

		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="Europe Start", Description="Start time of the european session, based on your computer clock", Order=20, GroupName="Parameters")]
		public DateTime EuropeStart		{ get; set; }
		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="Europe Stop", Description="Stop time of the european session, based on your computer clock", Order=21, GroupName="Parameters")]
		public DateTime EuropeStop		{ get; set; }
//		[XmlIgnore]
//		[Display(Name="Europe Color", Description="Color of Europe AvgSessionVolatility", Order=22, GroupName="Parameters")]
//		public Brush EuroPlotColor
//		{ get; set; }

		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="USA Start", Description="Start time of the US session, based on your computer clock", Order=30, GroupName="Parameters")]
		public DateTime USAStart		{ get; set; }
		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="USA Stop", Description="Stop time of the US session, based on your computer clock", Order=31, GroupName="Parameters")]
		public DateTime USAStop		{ get; set; }
//		[XmlIgnore]
//		[Display(Name="USA Color", Description="Color of USA AvgSessionVolatility", Order=32, GroupName="Parameters")]
//		public Brush USAPlotColor
//		{ get; set; }

		[Display(Name="Location of DialogBox", Order=40, GroupName="Parameters")]
		public TextPosition LocationDialogBox
		{ get; set; }
		[Display(Name="Display Mode", Description="ticks or points", Order=50, GroupName="Parameters")]
		public ARC_VolIndex_DisplayModes DisplayMode
		{ get; set; }

		#endregion
		#region Brush serialization
//		[Browsable(false)]
//		public string AsiaPlotColorSerializable		{get { return Serialize.BrushToString(AsiaPlotColor); }set { AsiaPlotColor = Serialize.StringToBrush(value); }}			
//		[Browsable(false)]
//		public string EuroPlotColorSerializable		{get { return Serialize.BrushToString(EuroPlotColor); }set { EuroPlotColor = Serialize.StringToBrush(value); }}			
//		[Browsable(false)]
//		public string USAPlotColorSerializable		{get { return Serialize.BrushToString(USAPlotColor); }set { USAPlotColor = Serialize.StringToBrush(value); }}			
		#endregion

		#region Plots
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> AvgAsiaVol_Plot	{get { return Values[0]; }}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> AvgEuroVol_Plot	{get { return Values[1]; }}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> AvgUSAVol_Plot	{get { return Values[2]; }}

//		[Browsable(false)]
//		[XmlIgnore]
//		public Series<double> AvgBarVolatility {get { return Values[3]; }}

//		[Browsable(false)]
//		[XmlIgnore]
//		public Series<double> CurBarRange	{get { return Values[4]; }}
//		[Browsable(false)]
//		[XmlIgnore]
//		public Series<double> CurSessionRange	{get { return Values[5]; }}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_VolIndex[] cacheARC_VolIndex;
		public ARC.ARC_VolIndex ARC_VolIndex(DateTime asiaStart, DateTime asiaStop, DateTime europeStart, DateTime europeStop, DateTime uSAStart, DateTime uSAStop)
		{
			return ARC_VolIndex(Input, asiaStart, asiaStop, europeStart, europeStop, uSAStart, uSAStop);
		}

		public ARC.ARC_VolIndex ARC_VolIndex(ISeries<double> input, DateTime asiaStart, DateTime asiaStop, DateTime europeStart, DateTime europeStop, DateTime uSAStart, DateTime uSAStop)
		{
			if (cacheARC_VolIndex != null)
				for (int idx = 0; idx < cacheARC_VolIndex.Length; idx++)
					if (cacheARC_VolIndex[idx] != null && cacheARC_VolIndex[idx].AsiaStart == asiaStart && cacheARC_VolIndex[idx].AsiaStop == asiaStop && cacheARC_VolIndex[idx].EuropeStart == europeStart && cacheARC_VolIndex[idx].EuropeStop == europeStop && cacheARC_VolIndex[idx].USAStart == uSAStart && cacheARC_VolIndex[idx].USAStop == uSAStop && cacheARC_VolIndex[idx].EqualsInput(input))
						return cacheARC_VolIndex[idx];
			return CacheIndicator<ARC.ARC_VolIndex>(new ARC.ARC_VolIndex(){ AsiaStart = asiaStart, AsiaStop = asiaStop, EuropeStart = europeStart, EuropeStop = europeStop, USAStart = uSAStart, USAStop = uSAStop }, input, ref cacheARC_VolIndex);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_VolIndex ARC_VolIndex(DateTime asiaStart, DateTime asiaStop, DateTime europeStart, DateTime europeStop, DateTime uSAStart, DateTime uSAStop)
		{
			return indicator.ARC_VolIndex(Input, asiaStart, asiaStop, europeStart, europeStop, uSAStart, uSAStop);
		}

		public Indicators.ARC.ARC_VolIndex ARC_VolIndex(ISeries<double> input , DateTime asiaStart, DateTime asiaStop, DateTime europeStart, DateTime europeStop, DateTime uSAStart, DateTime uSAStop)
		{
			return indicator.ARC_VolIndex(input, asiaStart, asiaStop, europeStart, europeStop, uSAStart, uSAStop);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_VolIndex ARC_VolIndex(DateTime asiaStart, DateTime asiaStop, DateTime europeStart, DateTime europeStop, DateTime uSAStart, DateTime uSAStop)
		{
			return indicator.ARC_VolIndex(Input, asiaStart, asiaStop, europeStart, europeStop, uSAStart, uSAStop);
		}

		public Indicators.ARC.ARC_VolIndex ARC_VolIndex(ISeries<double> input , DateTime asiaStart, DateTime asiaStop, DateTime europeStart, DateTime europeStop, DateTime uSAStart, DateTime uSAStop)
		{
			return indicator.ARC_VolIndex(input, asiaStart, asiaStop, europeStart, europeStop, uSAStart, uSAStop);
		}
	}
}

#endregion
