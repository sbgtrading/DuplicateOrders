#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public enum ARC_StopFinder_DisplayModes {Ticks,Points}

	public class ARC_StopFinder : Indicator
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "Stop Finder";


		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "21294", "27405"};//27405 is Annual Membership
		private string indicatorVersion = "v1.0";
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		private List<double> atr = new List<double>();
		private List<double> TR = new List<double>();
		private SortedDictionary<int,double> Peaks = new SortedDictionary<int,double>();
		private SortedDictionary<int,double> Valleys = new SortedDictionary<int,double>();
		private double max_line = 0;
		private double min_line = 0;
		private bool IsLive = false;
		double DollarsPerPt = 0;
		string TicksOrPipsLabel = "tks";
		private DateTime StartTime, EndTime;
		DateTime LaunchedAt = DateTime.Now;
		bool insession = false;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "ARC_StopFinder";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive	= false;

				EnableDialogBox				= true;
				LocationDialogBox			= TextPosition.BottomLeft;
				ATRperiod					= 14;
				DisplayMode					= ARC_StopFinder_DisplayModes.Ticks;
				DisplayRiskDollars			= true;
				TextColor					= Brushes.Lime;
				TextFont					= new SimpleFont("Arial",12);
				TextBkgColor				= Brushes.Black;
				TextBackgroundOpacity		= 100;
				MinPeakCount				= 3;
				Lookback					= 500;
				Significance				= 3;
				ValuePerTickInDollars		= 0;
				pSessionStartTime = 830;
				pSessionEndTime = 1500;
				pEnableSessionTime = false;
				StocksLabel = "cents";

				PipsOrPipettesLabel = "pipettes";
				AddPlot(Brushes.Yellow, "AvgTR");
				AddPlot(new Stroke(Brushes.Maroon, 2), PlotStyle.Hash, "MaxLine");
				AddPlot(new Stroke(Brushes.Blue, 2), PlotStyle.Hash, "MinLine");
				AddPlot(new Stroke(Brushes.Black, 2), PlotStyle.Hash, "AvgStop");
			}
			else if (State == State.Configure)
			{
				IsDebug = System.IO.File.Exists(@"c:\222222222222.txt") && (NinjaTrader.Cbi.License.MachineId.CompareTo("1E53E271B82EC62C7C03A15C336229AE")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion
			}
			else if (State == State.DataLoaded)
			{
				var t = Time.GetValueAt(0);
				int hr = pSessionStartTime/100;
				int min = pSessionStartTime - hr*100;
				if(hr > 23) {hr = 23; min=59;}
				if(min > 59) min=59;
				pSessionStartTime = hr*100+min;
				StartTime = new DateTime(t.Year, t.Month, t.Day, hr, min, 0);
				hr = pSessionEndTime/100;
				min = pSessionEndTime - hr*100;
				if(hr > 23) {hr = 23; min=59;}
				if(min > 59) min=59;
				pSessionEndTime = hr*100+min;
				EndTime = new DateTime(t.Year, t.Month, t.Day, hr, min, 0);
				if(EndTime < StartTime){
					StartTime = StartTime.AddDays(-1);
				}
				if(ValuePerTickInDollars==0)
					DollarsPerPt = Instrument.MasterInstrument.PointValue;
				else
					DollarsPerPt = ValuePerTickInDollars/TickSize;
//				Print("DollarsPerPt = "+DollarsPerPt);

				if(Instrument.MasterInstrument.InstrumentType == InstrumentType.Forex) TicksOrPipsLabel = PipsOrPipettesLabel;
				if(Instrument.MasterInstrument.InstrumentType == InstrumentType.Stock) TicksOrPipsLabel = StocksLabel;
			}
			else if(State == State.Realtime){
				IsLive = true;
			}
		}

		private bool IsInSession(DateTime t, DateTime t1, ref DateTime starttime, ref DateTime endtime){
			bool result = false;
			if(t1 < starttime && t >= starttime)   result = true;
			else if(t >= starttime && t < endtime) result = true;
			else if(t1 < endtime && t >= endtime)  result = false;
			while(t > endtime){
				starttime = starttime.AddDays(1);
				endtime = endtime.AddDays(1);
			}
			return result;
		}
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(CurrentBar<=1) return;
			insession = !pEnableSessionTime || IsInSession(Time[0], Time[1], ref StartTime, ref EndTime);
			if(insession){
				LaunchedAt = DateTime.Now;
				double tr = Math.Max(Math.Abs(Low[0]-Close[1]), Math.Max(High[0]-Low[0], Math.Abs(High[0] - Close[1])));
				TR.Insert(0, tr);
				while(TR.Count > this.ATRperiod) TR.RemoveAt(TR.Count-1);
				atr.Insert(0, TR.Average());
			}else{
//				if(EnableDialogBox && CurrentBar > Bars.Count-4){
//					var msg = string.Empty;
//					if(DisplayRiskDollars){
//						if(DisplayMode == ARC_StopFinder_DisplayModes.Points)
//							msg = string.Format("StopFinder:{0}{1}-pts  ${2}:  Max Stop{0}{3}-pts  ${4}:  Avg Stop{0}{5}-pts  ${6}:  Min Stop{0}{7}-pts  ${8}:  Current Stop",Environment.NewLine,
//								Instrument.MasterInstrument.FormatPrice(max_line), (Instrument.MasterInstrument.RoundToTickSize(max_line)*DollarsPerPt).ToString("0.00"),
//								Instrument.MasterInstrument.FormatPrice((max_line+min_line)/2.0), (Instrument.MasterInstrument.RoundToTickSize((max_line+min_line)/2.0)*DollarsPerPt).ToString("0.00"),
//								Instrument.MasterInstrument.FormatPrice(min_line), (Instrument.MasterInstrument.RoundToTickSize(min_line)*DollarsPerPt).ToString("0.00"),
//								Instrument.MasterInstrument.FormatPrice(atr[0]),   (Instrument.MasterInstrument.RoundToTickSize(atr[0])  *DollarsPerPt).ToString("0.00"));
//						else
//							msg = string.Format("StopFinder:{0}{2}-{1}  ${3}:  Max Stop{0}{4}-{1}  ${5}:  Avg Stop{0}{6}-{1}  ${7}:  Min Stop{0}{8}-{1}  ${9}:  Current Stop",Environment.NewLine, TicksOrPipsLabel,
//								(max_line/TickSize).ToString("0"), (Instrument.MasterInstrument.RoundToTickSize(max_line)*DollarsPerPt).ToString("0.00"),
//								((max_line+min_line)/2.0/TickSize).ToString("0"), (Instrument.MasterInstrument.RoundToTickSize((max_line+min_line)/2.0)*DollarsPerPt).ToString("0.00"),
//								(min_line/TickSize).ToString("0"), (Instrument.MasterInstrument.RoundToTickSize(min_line)*DollarsPerPt).ToString("0.00"),
//								(atr[0]/TickSize).ToString("0"),   (Instrument.MasterInstrument.RoundToTickSize(atr[0])  *DollarsPerPt).ToString("0.00"));
//					}else{
//						if(DisplayMode == ARC_StopFinder_DisplayModes.Points)
//							msg = string.Format("StopFinder:{0}{1}:  Max Stop{0}{2}:  Avg Stop{0}{3}:  Min Stop{0}{4}:  Current Stop",Environment.NewLine,
//								Instrument.MasterInstrument.FormatPrice(max_line),
//								Instrument.MasterInstrument.FormatPrice((max_line+min_line)/2.0),
//								Instrument.MasterInstrument.FormatPrice(min_line),
//								Instrument.MasterInstrument.FormatPrice(atr[0]));
//						else
//							msg = string.Format("StopFinder:{0}{1}:  Max Stop{0}{2}:  Avg Stop{0}{3}:  Min Stop{0}{4}:  Current Stop",Environment.NewLine,
//								(max_line/TickSize).ToString("0"),
//								((max_line+min_line)/2.0/TickSize).ToString("0"),
//								(min_line/TickSize).ToString("0"),
//								(atr[0]/TickSize).ToString("0"));
//					}
//					Draw.TextFixed(this,"stopinfo",msg.Replace(".00:",":"), LocationDialogBox, TextColor, TextFont, TextColor, TextBkgColor, TextBackgroundOpacity);
//				}
				if(LaunchedAt != DateTime.MaxValue)
					Draw.TextFixed(this,"stopinfo","Out of session - no StopFinder data will print", LocationDialogBox, TextColor, TextFont, TextColor, TextBkgColor, TextBackgroundOpacity);
				return;
			}
			if(atr.Count < Significance * 2.1) return;

			AvgTR[0] = atr[0];

			bool new_peak   = false;
			bool new_valley = false;
			if(atr[Significance]!=atr[Significance+1]){
				bool fail = false;
				for(int i = Significance; i>0 && !fail; i--){
					if(atr[Significance] < atr[Significance+i]) fail = true;
					if(atr[Significance] < atr[i-1]) fail = true;
				}
				if(!fail) {
					Peaks[CurrentBar-Significance] = atr[Significance];
					new_peak = true;
					//Draw.Dot(this,CurrentBar.ToString(),false,Significance,Close.GetValueAt(CurrentBar-Significance), Brushes.Red);
				}
				
				fail = false;
				for(int i = Significance; i>0 && !fail; i--){
					if(atr[Significance] > atr[Significance+i]) fail = true;
					if(atr[Significance] > atr[i-1]) fail = true;
				}
				if(!fail) {
					Valleys[CurrentBar-Significance] = atr[Significance];
					new_valley = true;
					//Draw.Dot(this,CurrentBar.ToString(),false,Significance,Close.GetValueAt(CurrentBar-Significance), Brushes.Green);
				}
			}

			if(new_peak || new_valley){
				if(Lookback > 0){
					var idx = Peaks.Keys.Where(k=> k<CurrentBar-Lookback).ToList();
					foreach(var del in idx) Peaks.Remove(del);
					idx = Valleys.Keys.Where(k=> k<CurrentBar-Lookback).ToList();
					foreach(var del in idx) Valleys.Remove(del);
				}

				if(new_peak){
					var atrs = Peaks.Values.ToList();
					atrs.Sort();
					if(atrs[0] < atrs.Last()) atrs.Reverse();
					if(atrs.Count < MinPeakCount)
						max_line = atrs.Min();
					else
						max_line = atrs[MinPeakCount-1];
				}

				if(new_valley){
					var atrs = Valleys.Values.ToList();
					atrs.Sort();
					if(atrs[0] > atrs.Last()) atrs.Reverse();
					if(atrs.Count < MinPeakCount)
						min_line = atrs.Max();
					else
						min_line = atrs[MinPeakCount-1];
				}
			}

			MaxLine[0] = max_line;
			MinLine[0] = min_line;
			AvgStop[0] = (MaxLine[0]+MinLine[0])/2.0;
			
			if(EnableDialogBox && CurrentBar > Bars.Count-4){
				var msg = string.Empty;
				if(DisplayRiskDollars){
					if(DisplayMode == ARC_StopFinder_DisplayModes.Points)
						msg = string.Format("StopFinder:{0}{1}-pts  ${2}:  Max Stop{0}{3}-pts  ${4}:  Avg Stop{0}{5}-pts  ${6}:  Min Stop{0}{7}-pts  ${8}:  Current Stop",Environment.NewLine,
							Instrument.MasterInstrument.FormatPrice(MaxLine[0]), (Instrument.MasterInstrument.RoundToTickSize(MaxLine[0])*DollarsPerPt).ToString("0.00"),
							Instrument.MasterInstrument.FormatPrice(AvgStop[0]), (Instrument.MasterInstrument.RoundToTickSize(AvgStop[0])*DollarsPerPt).ToString("0.00"),
							Instrument.MasterInstrument.FormatPrice(MinLine[0]), (Instrument.MasterInstrument.RoundToTickSize(MinLine[0])*DollarsPerPt).ToString("0.00"),
							Instrument.MasterInstrument.FormatPrice(AvgTR[0]),   (Instrument.MasterInstrument.RoundToTickSize(AvgTR[0])  *DollarsPerPt).ToString("0.00"));
					else
						msg = string.Format("StopFinder:{0}{2}-{1}  ${3}:  Max Stop{0}{4}-{1}  ${5}:  Avg Stop{0}{6}-{1}  ${7}:  Min Stop{0}{8}-{1}  ${9}:  Current Stop",Environment.NewLine, TicksOrPipsLabel,
							(MaxLine[0]/TickSize).ToString("0"), (Instrument.MasterInstrument.RoundToTickSize(MaxLine[0])*DollarsPerPt).ToString("0.00"),
							(AvgStop[0]/TickSize).ToString("0"), (Instrument.MasterInstrument.RoundToTickSize(AvgStop[0])*DollarsPerPt).ToString("0.00"),
							(MinLine[0]/TickSize).ToString("0"), (Instrument.MasterInstrument.RoundToTickSize(MinLine[0])*DollarsPerPt).ToString("0.00"),
							(AvgTR[0]/TickSize).ToString("0"),   (Instrument.MasterInstrument.RoundToTickSize(AvgTR[0])  *DollarsPerPt).ToString("0.00"));
				}else{
					if(DisplayMode == ARC_StopFinder_DisplayModes.Points)
						msg = string.Format("StopFinder:{0}{1}:  Max Stop{0}{2}:  Avg Stop{0}{3}:  Min Stop{0}{4}:  Current Stop",Environment.NewLine,
							Instrument.MasterInstrument.FormatPrice(MaxLine[0]),
							Instrument.MasterInstrument.FormatPrice(AvgStop[0]),
							Instrument.MasterInstrument.FormatPrice(MinLine[0]),
							Instrument.MasterInstrument.FormatPrice(AvgTR[0]));
					else
						msg = string.Format("StopFinder:{0}{1}:  Max Stop{0}{2}:  Avg Stop{0}{3}:  Min Stop{0}{4}:  Current Stop",Environment.NewLine,
							(MaxLine[0]/TickSize).ToString("0"),
							(AvgStop[0]/TickSize).ToString("0"),
							(MinLine[0]/TickSize).ToString("0"),
							(AvgTR[0]/TickSize).ToString("0"));
				}
				Draw.TextFixed(this,"stopinfo",msg.Replace(".00:",":"), LocationDialogBox, TextColor, TextFont, TextColor, TextBkgColor, TextBackgroundOpacity);
			}
		}
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
			base.OnRender(chartControl, chartScale);
			if(!insession && LaunchedAt != DateTime.MaxValue){
				var ts = new TimeSpan(DateTime.Now.Ticks - LaunchedAt.Ticks);
				if(ts.TotalSeconds> 10) {
					RemoveDrawObject("stopinfo");
					LaunchedAt = DateTime.MaxValue;
				}
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Enable Sessions", GroupName = "Session", Order = 5)]
		public bool pEnableSessionTime {get;set;}
		
		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Session Start", GroupName = "Session", Order = 10)]
		public int pSessionStartTime		{ get; set; }
		
		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Session End", GroupName = "Session", Order = 11)]
		public int pSessionEndTime		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Enable DialogBox", Description="Show/Hide dialog box", Order=10, GroupName="Parameters")]
		public bool EnableDialogBox
		{ get; set; }

		[Display(Name="Location of DialogBox", Order=20, GroupName="Parameters")]
		public TextPosition LocationDialogBox
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="ATR period", Description="Period of ATR", Order=30, GroupName="Parameters")]
		public int ATRperiod
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Min Peak Count", Description="Minimum number of peaks to constitute the Max or Min line", Order=40, GroupName="Parameters")]
		public int MinPeakCount
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Lookback", Description="Lookback, in bars.  Set to 0 to include all bars on chart", Order=150, GroupName="Parameters")]
		public int Lookback
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Significance", Description="Strength of the ATR peaks", Order=60, GroupName="Parameters")]
		public int Significance
		{ get; set; }

		
		[Display(Name="Display Mode", Description="ticks or points", Order=5, GroupName="Visuals")]
		public ARC_StopFinder_DisplayModes DisplayMode
		{ get; set; }

		[Display(Name="Display $ risk", Description="", Order=10, GroupName="Visuals")]
		public bool DisplayRiskDollars
		{ get; set; }

		[Range(0, double.MaxValue)]
		[Display(Name="Value of tick (in $)", Description="How valuable is the smallest increment in price, in dollars.  Set to '0' to use the default value you've set in the instrument settings", Order=12, GroupName="Visuals")]
		public double ValuePerTickInDollars {get;set;}

		[XmlIgnore]
		[Display(Name="Text Color", Description="Text font color", Order=20, GroupName="Visuals")]
		public Brush TextColor
		{ get; set; }

		[Display(Name="Text Font", Description="Font", Order=30, GroupName="Visuals")]
		public SimpleFont TextFont
		{ get; set; }

		[XmlIgnore]
		[Display(Name="Text BkgColor", Description="Background color", Order=40, GroupName="Visuals")]
		public Brush TextBkgColor
		{ get; set; }

		[Range(0, int.MaxValue)]
		[Display(Name="Text BackgroundOpacity", Description="Opacity, 0-transparent, 100-full color", Order=50, GroupName="Visuals")]
		public int TextBackgroundOpacity
		{ get; set; }

		[Display(Name="Unit label for spotFX", Description="When this is a spot FX instrument, is the smallest increment a Pip or Pipette?", Order=60, GroupName="Visuals")]
		public string PipsOrPipettesLabel
		{ get; set; }

		[Display(Name="Unit label for stocks", Description="When this is an equity instrument, what label do you want to use?", Order=70, GroupName="Visuals")]
		public string StocksLabel
		{ get; set; }
		#endregion

		#region Brush serialization
		[Browsable(false)]
		public string TextColorSerializable		{get { return Serialize.BrushToString(TextColor); }set { TextColor = Serialize.StringToBrush(value); }}			
		[Browsable(false)]
		public string TextBkgColorSerializable	{get { return Serialize.BrushToString(TextBkgColor); } set { TextBkgColor = Serialize.StringToBrush(value); }}			
		#endregion

		#region Plots
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> AvgTR
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MaxLine
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MinLine
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> AvgStop
		{
			get { return Values[3]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_StopFinder[] cacheARC_StopFinder;
		public ARC.ARC_StopFinder ARC_StopFinder(bool pEnableSessionTime, int pSessionStartTime, int pSessionEndTime, bool enableDialogBox, int aTRperiod, int minPeakCount, int lookback, int significance)
		{
			return ARC_StopFinder(Input, pEnableSessionTime, pSessionStartTime, pSessionEndTime, enableDialogBox, aTRperiod, minPeakCount, lookback, significance);
		}

		public ARC.ARC_StopFinder ARC_StopFinder(ISeries<double> input, bool pEnableSessionTime, int pSessionStartTime, int pSessionEndTime, bool enableDialogBox, int aTRperiod, int minPeakCount, int lookback, int significance)
		{
			if (cacheARC_StopFinder != null)
				for (int idx = 0; idx < cacheARC_StopFinder.Length; idx++)
					if (cacheARC_StopFinder[idx] != null && cacheARC_StopFinder[idx].pEnableSessionTime == pEnableSessionTime && cacheARC_StopFinder[idx].pSessionStartTime == pSessionStartTime && cacheARC_StopFinder[idx].pSessionEndTime == pSessionEndTime && cacheARC_StopFinder[idx].EnableDialogBox == enableDialogBox && cacheARC_StopFinder[idx].ATRperiod == aTRperiod && cacheARC_StopFinder[idx].MinPeakCount == minPeakCount && cacheARC_StopFinder[idx].Lookback == lookback && cacheARC_StopFinder[idx].Significance == significance && cacheARC_StopFinder[idx].EqualsInput(input))
						return cacheARC_StopFinder[idx];
			return CacheIndicator<ARC.ARC_StopFinder>(new ARC.ARC_StopFinder(){ pEnableSessionTime = pEnableSessionTime, pSessionStartTime = pSessionStartTime, pSessionEndTime = pSessionEndTime, EnableDialogBox = enableDialogBox, ATRperiod = aTRperiod, MinPeakCount = minPeakCount, Lookback = lookback, Significance = significance }, input, ref cacheARC_StopFinder);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_StopFinder ARC_StopFinder(bool pEnableSessionTime, int pSessionStartTime, int pSessionEndTime, bool enableDialogBox, int aTRperiod, int minPeakCount, int lookback, int significance)
		{
			return indicator.ARC_StopFinder(Input, pEnableSessionTime, pSessionStartTime, pSessionEndTime, enableDialogBox, aTRperiod, minPeakCount, lookback, significance);
		}

		public Indicators.ARC.ARC_StopFinder ARC_StopFinder(ISeries<double> input , bool pEnableSessionTime, int pSessionStartTime, int pSessionEndTime, bool enableDialogBox, int aTRperiod, int minPeakCount, int lookback, int significance)
		{
			return indicator.ARC_StopFinder(input, pEnableSessionTime, pSessionStartTime, pSessionEndTime, enableDialogBox, aTRperiod, minPeakCount, lookback, significance);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_StopFinder ARC_StopFinder(bool pEnableSessionTime, int pSessionStartTime, int pSessionEndTime, bool enableDialogBox, int aTRperiod, int minPeakCount, int lookback, int significance)
		{
			return indicator.ARC_StopFinder(Input, pEnableSessionTime, pSessionStartTime, pSessionEndTime, enableDialogBox, aTRperiod, minPeakCount, lookback, significance);
		}

		public Indicators.ARC.ARC_StopFinder ARC_StopFinder(ISeries<double> input , bool pEnableSessionTime, int pSessionStartTime, int pSessionEndTime, bool enableDialogBox, int aTRperiod, int minPeakCount, int lookback, int significance)
		{
			return indicator.ARC_StopFinder(input, pEnableSessionTime, pSessionStartTime, pSessionEndTime, enableDialogBox, aTRperiod, minPeakCount, lookback, significance);
		}
	}
}

#endregion
