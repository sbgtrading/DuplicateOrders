#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using SharpDX;
using SharpDX.Direct2D1;
using Brush = System.Windows.Media.Brush;

#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[Browsable(false)]
	public class ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop : ARC_ATRVolTraderAlgo_ARCIndicatorBase
	{
		public override string ProductVersion { get { return "v1.0.2 (5/1/2023)"; } }
		public override bool ColicensedOnly { get { return true; } }

		[XmlIgnore, Browsable(false)]
		public ISeries<int> Bias { get { return bias; } }
		private Series<int> bias;

		private ATR atr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_ATRVolTraderAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				IsOverlay = true;

				AddPlot(new Stroke(Brushes.DodgerBlue, 3), PlotStyle.Dot, "ATR Stop");

				Period = 14;
				Multiplier = 1;
				UptrendBrush = Brushes.Blue;
				DowntrendBrush = Brushes.Red;
			}
			else if (State == State.DataLoaded)
			{
				atr = ATR(Period);
				bias = new Series<int>(this, MaximumBarsLookBack.Infinite);
			}
		}

		internal static void ARC_ATRVolTraderAlgo_UpdateValue(IndicatorBase indicator, Series<double> value, Series<int> bias, ATR atr, double multiplier, bool roundToNearestTick)
		{
			if (indicator.CurrentBar == 0)
			{
				bias[0] = indicator.Close[0].ApproxCompare(indicator.Open[0]);
				if (bias[0] == 0)
					bias[0] = 1;
			} 
			else 
			{
				if (bias[1] == -1 && indicator.Close[0] > value[1])
					bias[0] = 1;
				else if (bias[1] == 1 && indicator.Close[0] < value[1])
					bias[0] = -1;
				else
					bias[0] = bias[1];
			}

			value[0] = indicator.Close[0] - bias[0] * multiplier * atr[0];
			
			if (roundToNearestTick)
				value[0] = indicator.Instrument.MasterInstrument.RoundToTickSize(value[0]);

			if (indicator.CurrentBar != 0 && bias[0] == bias[1] && value[1].ApproxCompare(value[0]) == bias[0])
				value[0] = value[1];
		}

		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_ATRVolTraderAlgo_IsLicensed())
				return;

			ARC_ATRVolTraderAlgo_UpdateValue(this, Value, bias, atr, Multiplier, RoundToNearestTick);
			if (bias[0] == 0)
				return;
			
			PlotBrushes[0][0] = bias[0] == 1 ? UptrendBrush : DowntrendBrush;
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			if (!this.ARC_ATRVolTraderAlgo_IsLicensed() || IsInHitTest)
				return;

			var oldAaMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
			try
			{
				using (var uptrendDxBrush = UptrendBrush.ToDxBrush(RenderTarget))
				using (var downtrendDxBrush = DowntrendBrush.ToDxBrush(RenderTarget))
					for (var i = Math.Max(1, ChartBars.FromIndex); i <= Math.Min(ChartBars.Count - 1, ChartBars.ToIndex + 1); i++)
					{
						if (!Value.IsValidDataPointAt(i) || bias.GetValueAt(i) != bias.GetValueAt(i - 1))
							continue;

						var midlinePoints = new[] { i, i - 1 }
							.Select(i2 => new Vector2(chartControl.GetXByBarIndex(ChartBars, i2), chartScale.GetYByValue(Value.GetValueAt(i2))))
							.ToArray();
						RenderTarget.DrawLine(midlinePoints[0], midlinePoints[1], bias.GetValueAt(i) == 1 ? uptrendDxBrush : downtrendDxBrush);
					}
			}
			finally
			{
				RenderTarget.AntialiasMode = oldAaMode;
			}
		}

		#region Properties
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "NinjaScriptParameters", Order = 0)]
		public int Period { get; set; }

		[NinjaScriptProperty, Range(double.Epsilon, double.MaxValue)]
		[Display(Name = "Multiplier", Order = 1, GroupName = "Parameters")]
		public double Multiplier { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Round to Tick", Order = 2, GroupName = "Parameters", Description = "Round the band levels to the nearest tick?")]
		public bool RoundToNearestTick { get; set; }

		[XmlIgnore]
		[Display(Name = "Downtrend Color", Order = 3, GroupName = "Parameters")]
		public Brush DowntrendBrush { get; set; }

		[Browsable(false)]
		public string DowntrendBrushSerializable
		{
			get { return Serialize.BrushToString(DowntrendBrush); }
			set { DowntrendBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Uptrend Color", Order = 3, GroupName = "Parameters")]
		public Brush UptrendBrush { get; set; }

		[Browsable(false)]
		public string UptrendBrushSerializable
		{
			get { return Serialize.BrushToString(UptrendBrush); }
			set { UptrendBrush = Serialize.StringToBrush(value); }
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop[] cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStop;
		public ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(int period, double multiplier, bool roundToNearestTick)
		{
			return ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(Input, period, multiplier, roundToNearestTick);
		}

		public ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(ISeries<double> input, int period, double multiplier, bool roundToNearestTick)
		{
			if (cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStop != null)
				for (int idx = 0; idx < cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStop.Length; idx++)
					if (cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStop[idx] != null && cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStop[idx].Period == period && cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStop[idx].Multiplier == multiplier && cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStop[idx].RoundToNearestTick == roundToNearestTick && cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStop[idx].EqualsInput(input))
						return cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStop[idx];
			return CacheIndicator<ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop>(new ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(){ Period = period, Multiplier = multiplier, RoundToNearestTick = roundToNearestTick }, input, ref cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStop);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(int period, double multiplier, bool roundToNearestTick)
		{
			return indicator.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(Input, period, multiplier, roundToNearestTick);
		}

		public Indicators.ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(ISeries<double> input , int period, double multiplier, bool roundToNearestTick)
		{
			return indicator.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(input, period, multiplier, roundToNearestTick);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(int period, double multiplier, bool roundToNearestTick)
		{
			return indicator.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(Input, period, multiplier, roundToNearestTick);
		}

		public Indicators.ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(ISeries<double> input , int period, double multiplier, bool roundToNearestTick)
		{
			return indicator.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(input, period, multiplier, roundToNearestTick);
		}
	}
}

#endregion
