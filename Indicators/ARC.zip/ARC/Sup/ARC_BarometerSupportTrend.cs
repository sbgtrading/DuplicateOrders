#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Reflection;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
#endregion
	
public enum ARC_Barometer_BinTimeScalar
{
	SECONDS,
	MINUTES,
}

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC.Sup
{

    /// <summary>
    /// Calculates the trades per minute
    /// </summary>
    public class ARC_BarometerSupportTrend : Indicator
    {
		#region RegFilterClass
		internal class FiltFiltType
		{
			private Indicator indicator;
			private int windowSize = 9; // Default setting for WindowSize
			private double m_sigma = 6.0; // Default setting for WindowSize
			
			private double[] filtfilt;

			public Series<double> Output;

			/// <summary>
			/// This method is used to configure the indicator and is called once before any bar data is loaded.
			/// </summary>
			#region RegConstructor
			
			public FiltFiltType(int iWindowSize, double iFineAdjust, Indicator iIndicator)
			{
				this.windowSize = Math.Min(iWindowSize, 50);
				this.m_sigma = Math.Min(Math.Max(0.01, iFineAdjust), 50.0);
				this.indicator = iIndicator;
				
				this.filtfilt = new double[this.windowSize];
				
				double m = (this.windowSize / 2);
				
				double s = this.windowSize;
				s /= this.m_sigma;

				for (int i = 0; i < this.windowSize; i++)                
					filtfilt[i] = Math.Exp(-((((double)i) - m) * (((double)i) - m)) / (2 * s * s));

				Output = new Series<double>(this.indicator, MaximumBarsLookBack.Infinite);
			}
			
			#endregion

			/// <summary>
			/// Called on each bar update event (incoming tick)
			/// </summary>
			public bool Calculate()
			{

				if (indicator.CurrentBar <= this.windowSize)
					return false;				

				this.ComputeFilter();
								
				return true;
			}
			
			
			private double ComputeFilter()
			{
				for (int pt = 0; pt < (this.windowSize / 2) + 1; pt++) 
				{
					double agr  = 0;
					double norm = 0;
					double cValue = 0;
										
					for (int i = 0; i < windowSize; i++) 
					{
						if (i < windowSize-pt) 
						{													
							cValue = indicator.Input[this.windowSize-pt-1-i];							
				
							agr += filtfilt[i] * cValue;
							norm += filtfilt[i];
						}
					}
					
					// Normalize the result
					if (norm != 0) 
						agr /= norm;
					
					// Set the approrpiate bar.
					Output[(windowSize/2) - pt] = agr;
				}	
				
				return 0;
			}			
		}	
		#endregion

		#region RegInputs
		
        
        private int iNormPeriod = 14; 
        [NinjaScriptProperty]        [Display(Name = "01. Period", GroupName = "Parameters", Order = 1)]        public int NormPeriod
        {
            get { return iNormPeriod; }
            set { iNormPeriod = Math.Max(1, value);}
		} 			        	
		#endregion
		
		public int key;
		
		private List<double> values;
		private Series<double> sValues;
				
		private FiltFiltType indFilter;
		
		private int bbPeriod = 8; 
		public double iFindAdjustFactor = 1.0; 	

        #region RegInitialize
		
        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    Name = "ARC_BarometerSupportTrend";
					AddPlot(new Stroke(Brushes.DodgerBlue, 3), PlotStyle.Line, "ForecastValue");			
											
		            IsOverlay				= true;
					Calculate = Calculate.OnEachTick;
                    break;

                case State.DataLoaded:
					this.sValues = new Series<double>(this);
					this.values = new List<double>();
					
                    break;
             }
        }

		#endregion

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
            if (this.indFilter == null)
                this.indFilter = new FiltFiltType(this.bbPeriod, this.iFindAdjustFactor, this);
			
            if(!this.indFilter.Calculate())
				return;					

			if(this.key != 102812655){
				Draw.TextFixed(this,"st","."+Environment.NewLine+"."+Environment.NewLine+"ARC_BarometerSupportTrend does not provide output to a chart",TextPosition.Center);
				return;
			}
			
			double val = 0;						
			for(int i = 0 ; i < (int)(this.bbPeriod / 2) ; i++)
				val += this.indFilter.Output[i];			
			
			val /= (double)(this.bbPeriod / 2);		
			
			this.values.Add(val);
			this.sValues[0] = val;
			
			if(CurrentBar < this.iNormPeriod)
				return;
			
			double norm = this.LogikNormalizer(this.sValues, this.iNormPeriod);

			if(!IsFinite(norm))
			{
				ForecastValue[0] = ForecastValue[1];
				return;
			}
			
			norm -= 50;
			ForecastValue[0] = norm;						
        }
		
        private bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value) && value > TickSize && value < double.MaxValue;
        }	
		
        //**********************************************************************
        // - Normalizer
        //**********************************************************************
        private double LogikNormalizer(Series<double> iDataSeries, int iLength)
        {
            double range = Math.Abs(HighestInd(iDataSeries, iLength) - 
                                               LowestInd(iDataSeries, iLength));
            double rval = -1;

            if (range != 0)
                rval = (100 * ((iDataSeries[0] - 
                                    LowestInd(iDataSeries, iLength)) / range));

            return rval;
        }
        //**********************************************************************
        // - Highest Value in DataSeries
        //**********************************************************************
        private double HighestInd(ISeries<double> iDataSeries, int iLength)
        {
            double hMA = iDataSeries[0];
            for (int i = 0; i <= iLength; i++)
            {
                if (iDataSeries[i] > hMA)
                    hMA = iDataSeries[i];
            }

            return hMA;
        }

        //**********************************************************************
        // - Lowest Value in DataSeries
        //**********************************************************************
        private double LowestInd(ISeries<double> iDataSeries, int iLength)
        {
            double hMA = iDataSeries[0];
            for (int i = 0; i <= iLength; i++)
            {
                if (iDataSeries[i] < hMA)
                    hMA = iDataSeries[i];
            }

            return hMA;
        }				

        #region Properties
		
		public override string ToString()
		{
			return Name;
		}
	
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove		
		public Series<double> ForecastValue
        {
            get { return Values[0]; }
        }	
		
        #endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Sup.ARC_BarometerSupportTrend[] cacheARC_BarometerSupportTrend;
		public ARC.Sup.ARC_BarometerSupportTrend ARC_BarometerSupportTrend(int normPeriod)
		{
			return ARC_BarometerSupportTrend(Input, normPeriod);
		}

		public ARC.Sup.ARC_BarometerSupportTrend ARC_BarometerSupportTrend(ISeries<double> input, int normPeriod)
		{
			if (cacheARC_BarometerSupportTrend != null)
				for (int idx = 0; idx < cacheARC_BarometerSupportTrend.Length; idx++)
					if (cacheARC_BarometerSupportTrend[idx] != null && cacheARC_BarometerSupportTrend[idx].NormPeriod == normPeriod && cacheARC_BarometerSupportTrend[idx].EqualsInput(input))
						return cacheARC_BarometerSupportTrend[idx];
			return CacheIndicator<ARC.Sup.ARC_BarometerSupportTrend>(new ARC.Sup.ARC_BarometerSupportTrend(){ NormPeriod = normPeriod }, input, ref cacheARC_BarometerSupportTrend);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Sup.ARC_BarometerSupportTrend ARC_BarometerSupportTrend(int normPeriod)
		{
			return indicator.ARC_BarometerSupportTrend(Input, normPeriod);
		}

		public Indicators.ARC.Sup.ARC_BarometerSupportTrend ARC_BarometerSupportTrend(ISeries<double> input , int normPeriod)
		{
			return indicator.ARC_BarometerSupportTrend(input, normPeriod);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Sup.ARC_BarometerSupportTrend ARC_BarometerSupportTrend(int normPeriod)
		{
			return indicator.ARC_BarometerSupportTrend(Input, normPeriod);
		}

		public Indicators.ARC.Sup.ARC_BarometerSupportTrend ARC_BarometerSupportTrend(ISeries<double> input , int normPeriod)
		{
			return indicator.ARC_BarometerSupportTrend(input, normPeriod);
		}
	}
}

#endregion
