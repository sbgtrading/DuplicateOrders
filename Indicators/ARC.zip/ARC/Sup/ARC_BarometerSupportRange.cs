#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Reflection;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
#endregion



// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC.Sup
{

    /// <summary>
    /// Calculates the trades per minute
    /// </summary>
    public class ARC_BarometerSupportRange : Indicator
    {
		private ARC_Barometer_BinTimeScalar iBinTimeScalar = ARC_Barometer_BinTimeScalar.MINUTES;
        [NinjaScriptProperty]        [Display(Name = "BinTimeScalar", Description = "", GroupName = "Parameters", Order = 1)]        public ARC_Barometer_BinTimeScalar BinTimeScalar
        {
            get { return iBinTimeScalar; }
            set { iBinTimeScalar = value; }
        }
		public int iAveragePeriod = 1;
		
		public int key;
		private int tickBasedAverageBars = 5;
		private int lookbackPeriodDays = 3;
		private int dataPointsPerDay = 0;
		private List<Dictionary<int, float>> db;
		
		private float valueForecast;
		private int lastForecastTime, forecastPeriod;
		
		private const int donchianPeriod = 5;		
		
        #region RegInitialize

        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    Name = "ARC_BarometerSupportRange";
					
					AddPlot(new Stroke(Brushes.DodgerBlue, 2), PlotStyle.Line, "ForecastValue");			
					AddPlot(new Stroke(Brushes.Yellow, 2), PlotStyle.Bar, "CurrentValue");
											
		            IsOverlay				= false;
					Calculate = Calculate.OnEachTick;
					
                    break;

		        case State.Configure:
					switch(iBinTimeScalar)
					{
						case ARC_Barometer_BinTimeScalar.SECONDS:
						{
							dataPointsPerDay = 86400;
							AddDataSeries(Instrument.FullName, BarsPeriodType.Second, 1); //1
							break;
						}
						case ARC_Barometer_BinTimeScalar.MINUTES:
						{
							dataPointsPerDay = 1440;
							AddDataSeries(Instrument.FullName, BarsPeriodType.Minute, 1); //1
							break;			
						}
					}	
                    break;
					
				case State.DataLoaded:
						
					this.db = new List<Dictionary<int, float>>();
							
					if(BarsArray[0].BarsType.BuiltFrom != BarsPeriodType.Tick)			
						this.forecastPeriod = BarsArray[0].BarsType.BarsPeriod.Value;

					break;
             }
        }
		

		#endregion

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if(CurrentBars[0] <= 1 || CurrentBars[1] <= 1 || this.key != 102812655)
				return;			
			
			int timeIndex = 0;
			if(this.iBinTimeScalar == ARC_Barometer_BinTimeScalar.SECONDS)
				timeIndex = Times[1][0].Hour * 3600 + Times[1][0].Minute * 60 + Times[1][0].Second;
			else
				timeIndex = Times[1][0].Hour * 60 + Times[1][0].Minute;
				
			#region RegDb
			
			if(BarsInProgress == 1)
			{
				// Session break - Pin point here.
				if(Times[1][0].Date != Times[1][1].Date)
				{					
					lastForecastTime = timeIndex;
				
					// Create the new point in the list
					this.db.Add(new Dictionary<int, float>());
					// Add keys for the entire day
					for(int i = 0 ; i < this.dataPointsPerDay ; i++)
						this.db[this.db.Count - 1].Add(i, 0);					
										
					// Trim database.  Add 1 to handle the fact that you can't forecast using current day's data.
					if(this.db.Count > this.lookbackPeriodDays + 2)
						this.db.RemoveAt(0);
				}									
				
				// Add this data point, once the first day has been added
				if(this.db.Count > 0)
					this.db[this.db.Count - 1][timeIndex] = (float)((MAX(Highs[1], donchianPeriod)[0] - MIN(Lows[1], donchianPeriod)[0]) / TickSize);// ((this.indDonchForecast.Upper[0] - this.indDonchForecast.Lower[0]) / TickSize);
				
				return;
			}
			#endregion
			
			// Do not process until data exists in the database
			if(this.db.Count == 0)
				return;	
			
			if(CurrentBars[0] <= Math.Max(this.tickBasedAverageBars, this.iAveragePeriod))
				return;
			
			if(BarsArray[0].BarsType.BuiltFrom == BarsPeriodType.Tick || this.iAveragePeriod != 1)
			{
				// Compute average time over last 5 bars
				int sumTime = 0;	
				int sumCount = 0;
				for(int i = 0 ; i < tickBasedAverageBars ; i++)
				{
					sumCount++;
					sumTime += (int)(Times[0][i].Subtract(Times[0][i+1]).TotalSeconds);
				}
				
				this.forecastPeriod = (sumTime / sumCount);								
			}
			
			// Forecast over time period							
			if(timeIndex - this.lastForecastTime >= this.forecastPeriod)
			{				
				// Set this as the new time last forecast time
				this.lastForecastTime = timeIndex;
								
				List<float> values = new List<float>();
				for(int dbIndex = this.db.Count - 2 ; dbIndex >= 0 ; dbIndex--)
				{		
					float sum = 0;
					float count = 0;						
					for(int i = timeIndex ; i < Math.Min(timeIndex + this.forecastPeriod, this.dataPointsPerDay) ; i++)						
					{
						sum += this.db[dbIndex][i];	
						count++;
					}

					values.Add(sum);
				}					
								
				float sumValues = 0;
				float countValues = 0;
				for(int i = 0 ; i < values.Count ; i++)
				{
					if(values[i] != 0)
					{
						countValues++;
						sumValues += values[i];						
					}
				}
				
				this.valueForecast = (sumValues / countValues);					
			}
			
			double val = (MAX(Highs[0], donchianPeriod)[0] - MIN(Lows[0], donchianPeriod)[0]) / TickSize;// (this.indDonchPrimary.Upper[0] - this.indDonchPrimary.Lower[0]) / TickSize;
			
			if(!IsFinite(val) || !IsFinite(this.valueForecast))
			{
				CurrentValue[0] = (CurrentValue[1]);
				ForecastValue[0] = (ForecastValue[1]);
				return;
			}
			
			CurrentValue[0] = val;
			ForecastValue[0] = this.valueForecast;
        }
		
        private bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value) && value > TickSize && value < double.MaxValue;
        }		

        #region Properties
		
		public override string ToString()
		{
			return Name;
		}
	
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove		
		public Series<double> ForecastValue
        {
            get { return Values[0]; }
        }
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove		
		public Series<double> CurrentValue
        {
            get { return Values[1]; }
        }		
		
        #endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Sup.ARC_BarometerSupportRange[] cacheARC_BarometerSupportRange;
		public ARC.Sup.ARC_BarometerSupportRange ARC_BarometerSupportRange(ARC_Barometer_BinTimeScalar binTimeScalar)
		{
			return ARC_BarometerSupportRange(Input, binTimeScalar);
		}

		public ARC.Sup.ARC_BarometerSupportRange ARC_BarometerSupportRange(ISeries<double> input, ARC_Barometer_BinTimeScalar binTimeScalar)
		{
			if (cacheARC_BarometerSupportRange != null)
				for (int idx = 0; idx < cacheARC_BarometerSupportRange.Length; idx++)
					if (cacheARC_BarometerSupportRange[idx] != null && cacheARC_BarometerSupportRange[idx].BinTimeScalar == binTimeScalar && cacheARC_BarometerSupportRange[idx].EqualsInput(input))
						return cacheARC_BarometerSupportRange[idx];
			return CacheIndicator<ARC.Sup.ARC_BarometerSupportRange>(new ARC.Sup.ARC_BarometerSupportRange(){ BinTimeScalar = binTimeScalar }, input, ref cacheARC_BarometerSupportRange);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Sup.ARC_BarometerSupportRange ARC_BarometerSupportRange(ARC_Barometer_BinTimeScalar binTimeScalar)
		{
			return indicator.ARC_BarometerSupportRange(Input, binTimeScalar);
		}

		public Indicators.ARC.Sup.ARC_BarometerSupportRange ARC_BarometerSupportRange(ISeries<double> input , ARC_Barometer_BinTimeScalar binTimeScalar)
		{
			return indicator.ARC_BarometerSupportRange(input, binTimeScalar);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Sup.ARC_BarometerSupportRange ARC_BarometerSupportRange(ARC_Barometer_BinTimeScalar binTimeScalar)
		{
			return indicator.ARC_BarometerSupportRange(Input, binTimeScalar);
		}

		public Indicators.ARC.Sup.ARC_BarometerSupportRange ARC_BarometerSupportRange(ISeries<double> input , ARC_Barometer_BinTimeScalar binTimeScalar)
		{
			return indicator.ARC_BarometerSupportRange(input, binTimeScalar);
		}
	}
}

#endregion
