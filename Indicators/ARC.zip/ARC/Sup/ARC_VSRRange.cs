#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Reflection;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
#endregion



// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC.Sup
{

    /// <summary>
    /// Calculates the trades per minute
    /// </summary>
    public class ARC_VSRRange : Indicator
    {
		private string iBinTimeScalar = "MINUTES";
        [NinjaScriptProperty]        [Display(Name = "BinTimeScalar", Description = "", GroupName = "Parameters", Order = 1)]        public string BinTimeScalar
        {
            get { return iBinTimeScalar; }
            set { iBinTimeScalar = value; }
        }
		private string iCalculationModel = "B";
        [NinjaScriptProperty]        [Display(Name = "Model", Description = "", GroupName = "Parameters", Order = 10)]        public string CalculationModel
        {
            get { return iCalculationModel; }
            set { iCalculationModel = value; }
        }
//		private NS_VSR_BinTimeScalar iBinTimeScalar = NS_VSR_BinTimeScalar.MINUTES;
//        [NinjaScriptProperty]        [Display(Name = "BinTimeScalar", Description = "", GroupName = "Parameters", Order = 1)]        public NS_VSR_BinTimeScalar BinTimeScalar
//        {
//            get { return iBinTimeScalar; }
//            set { iBinTimeScalar = value; }
//        }
		public int iAveragePeriod = 1;
		
		public int key;
		private int tickBasedAverageBars = 5;
		private int lookbackPeriodDays = 3;
		private int dataPointsPerDay = 0;
		private List<Dictionary<int, float>> db;
		
		private EMA ema = null;

		private double val=25,valueForecast=50;
		private int lastForecastTime, forecastPeriod;
		
		private const int donchianPeriod = 5;		
		
        #region RegInitialize

        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    Name = "ARC_VSR_Range";
					
					AddPlot(new Stroke(Brushes.DodgerBlue, 2), PlotStyle.Line, "ForecastValue");			
					AddPlot(new Stroke(Brushes.Yellow, 2), PlotStyle.Bar, "CurrentValue");
											
		            IsOverlay				= false;
					Calculate = Calculate.OnEachTick;
					
                    break;

		        case State.Configure:
					if(iCalculationModel[0] == 'B') iBinTimeScalar ="MINUTES";
					switch(iBinTimeScalar)
					{
						case "SECONDS":
						{
							dataPointsPerDay = 86400;
							AddDataSeries(Instrument.FullName, BarsPeriodType.Second, 1); //1
							break;
						}
						case "MINUTES":
						{
							dataPointsPerDay = 1440;
							AddDataSeries(Instrument.FullName, BarsPeriodType.Minute, 1); //1
							break;			
						}
					}	
                    break;
					
				case State.DataLoaded:

					ema = EMA(BarsArray[0], 10);
					this.db = new List<Dictionary<int, float>>();
							
					if(BarsArray[0].BarsType.BuiltFrom != BarsPeriodType.Tick)			
						this.forecastPeriod = BarsArray[0].BarsType.BarsPeriod.Value;

					break;
             }
        }
		

		#endregion

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if(CurrentBars[0] <= 1 || CurrentBars[1] <= 1 || this.key != 10812655)
				return;

			if(iCalculationModel[0] == 'A'){
				#region -- Model A --
				int timeIndex = 0;
				if(this.iBinTimeScalar.StartsWith("SECONDS"))
					timeIndex = Times[1][0].Hour * 3600 + Times[1][0].Minute * 60 + Times[1][0].Second;
				else
					timeIndex = Times[1][0].Hour * 60 + Times[1][0].Minute;
					
				#region RegDb
				
				if(BarsInProgress == 1)
				{
					// Session break - Pin point here.
					if(Times[1][0].Date != Times[1][1].Date)
					{					
						lastForecastTime = timeIndex;
					
						// Create the new point in the list
						this.db.Add(new Dictionary<int, float>());
						// Add keys for the entire day
						for(int i = 0 ; i < this.dataPointsPerDay ; i++)
							this.db[this.db.Count - 1].Add(i, 0);					
											
						// Trim database.  Add 1 to handle the fact that you can't forecast using current day's data.
						if(this.db.Count > this.lookbackPeriodDays + 2)
							this.db.RemoveAt(0);
					}									
					
					// Add this data point, once the first day has been added
					if(this.db.Count > 0)
						this.db[this.db.Count - 1][timeIndex] = (float)((MAX(Highs[1], donchianPeriod)[0] - MIN(Lows[1], donchianPeriod)[0]) / TickSize);// ((this.indDonchForecast.Upper[0] - this.indDonchForecast.Lower[0]) / TickSize);
					
					return;
				}
				#endregion
				
				// Do not process until data exists in the database
				if(this.db.Count == 0)
					return;	
				
				if(CurrentBars[0] <= Math.Max(this.tickBasedAverageBars, this.iAveragePeriod))
					return;
				
				if(BarsArray[0].BarsType.BuiltFrom == BarsPeriodType.Tick || this.iAveragePeriod != 1)
				{
					// Compute average time over last 5 bars
					int sumTime = 0;	
					int sumCount = 0;
					for(int i = 0 ; i < tickBasedAverageBars ; i++)
					{
						sumCount++;
						sumTime += (int)(Times[0][i].Subtract(Times[0][i+1]).TotalSeconds);
					}
					
					this.forecastPeriod = (sumTime / sumCount);								
				}
				
				// Forecast over time period							
				if(timeIndex - this.lastForecastTime >= this.forecastPeriod)
				{				
					// Set this as the new time last forecast time
					this.lastForecastTime = timeIndex;
									
					List<float> values = new List<float>();
					for(int dbIndex = this.db.Count - 2 ; dbIndex >= 0 ; dbIndex--)
					{		
						float sum = 0;
						float count = 0;						
						for(int i = timeIndex ; i < Math.Min(timeIndex + this.forecastPeriod, this.dataPointsPerDay) ; i++)						
						{
							sum += this.db[dbIndex][i];	
							count++;
						}

						values.Add(sum);
					}					
									
					float sumValues = 0;
					float countValues = 0;
					for(int i = 0 ; i < values.Count ; i++)
					{
						if(values[i] != 0)
						{
							countValues++;
							sumValues += values[i];						
						}
					}
					
					this.valueForecast = (sumValues / countValues);					
				}
				
				val = (MAX(Highs[0], donchianPeriod)[0] - MIN(Lows[0], donchianPeriod)[0]) / TickSize;// (this.indDonchPrimary.Upper[0] - this.indDonchPrimary.Lower[0]) / TickSize;
				
				if(!IsFinite(val) || !IsFinite(this.valueForecast))
				{
					CurrentValue[0] = (CurrentValue[1]);
					ForecastValue[0] = (ForecastValue[1]);
					return;
				}
				#endregion
			}else if (iCalculationModel[0] == 'B' && BarsInProgress==0 && CurrentBars[0]>21){
				//Forecast is the average slope of the EMA(4) over the last 20 bars.  Current is current slope of the EMA(4) 
				double sum1 = 0;
				int i = 0;
				for(i = 1; i<=20; i++){
					sum1 = sum1 + ema[i]-ema[i+1];
				}
				valueForecast = Math.Abs(sum1/i);
				val = Math.Abs(ema[0]-ema[1]);
			}

			CurrentValue[0]  = Math.Abs(valueForecast-val);
			valueForecast    = (Math.Abs(valueForecast) <= double.Epsilon ? double.Epsilon : valueForecast);
			ForecastValue[0] = valueForecast;
        }

        private bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value) && value > TickSize && value < double.MaxValue;
        }

        #region Properties
		
		public override string ToString()
		{
			return Name;
		}
	
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove		
		public Series<double> ForecastValue
        {
            get { return Values[0]; }
        }
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove		
		public Series<double> CurrentValue
        {
            get { return Values[1]; }
        }		
		
        #endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Sup.ARC_VSRRange[] cacheARC_VSRRange;
		public ARC.Sup.ARC_VSRRange ARC_VSRRange(string binTimeScalar, string calculationModel)
		{
			return ARC_VSRRange(Input, binTimeScalar, calculationModel);
		}

		public ARC.Sup.ARC_VSRRange ARC_VSRRange(ISeries<double> input, string binTimeScalar, string calculationModel)
		{
			if (cacheARC_VSRRange != null)
				for (int idx = 0; idx < cacheARC_VSRRange.Length; idx++)
					if (cacheARC_VSRRange[idx] != null && cacheARC_VSRRange[idx].BinTimeScalar == binTimeScalar && cacheARC_VSRRange[idx].CalculationModel == calculationModel && cacheARC_VSRRange[idx].EqualsInput(input))
						return cacheARC_VSRRange[idx];
			return CacheIndicator<ARC.Sup.ARC_VSRRange>(new ARC.Sup.ARC_VSRRange(){ BinTimeScalar = binTimeScalar, CalculationModel = calculationModel }, input, ref cacheARC_VSRRange);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Sup.ARC_VSRRange ARC_VSRRange(string binTimeScalar, string calculationModel)
		{
			return indicator.ARC_VSRRange(Input, binTimeScalar, calculationModel);
		}

		public Indicators.ARC.Sup.ARC_VSRRange ARC_VSRRange(ISeries<double> input , string binTimeScalar, string calculationModel)
		{
			return indicator.ARC_VSRRange(input, binTimeScalar, calculationModel);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Sup.ARC_VSRRange ARC_VSRRange(string binTimeScalar, string calculationModel)
		{
			return indicator.ARC_VSRRange(Input, binTimeScalar, calculationModel);
		}

		public Indicators.ARC.Sup.ARC_VSRRange ARC_VSRRange(ISeries<double> input , string binTimeScalar, string calculationModel)
		{
			return indicator.ARC_VSRRange(input, binTimeScalar, calculationModel);
		}
	}
}

#endregion
