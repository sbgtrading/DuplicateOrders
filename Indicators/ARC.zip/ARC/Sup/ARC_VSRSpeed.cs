#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Reflection;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using System.Linq;
#endregion

	
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC.Sup
{

    /// <summary>
    /// Calculates the trades per minute
    /// </summary>
    public class ARC_VSRSpeed : Indicator
    {
		private string iBinTimeScalar = "MINUTES";
        [NinjaScriptProperty]        [Display(Name = "BinTimeScalar", Description = "", GroupName = "Parameters", Order = 1)]        public string BinTimeScalar
        {
            get { return iBinTimeScalar; }
            set { iBinTimeScalar = value; }
        }
		private string iCalculationModel = "B";
        [NinjaScriptProperty]        [Display(Name = "Model", Description = "", GroupName = "Parameters", Order = 10)]        public string CalculationModel
        {
            get { return iCalculationModel; }
            set { iCalculationModel = value; }
        }
//		private NS_VSR_BinTimeScalar iBinTimeScalar = NS_VSR_BinTimeScalar.MINUTES;
//        [NinjaScriptProperty]        [Display(Name = "BinTimeScalar", Description = "", GroupName = "Parameters", Order = 1)]        public NS_VSR_BinTimeScalar BinTimeScalar
//        {
//            get { return iBinTimeScalar; }
//            set { iBinTimeScalar = value; }
//        }
		public int iAveragePeriod = 1;
		
		public int key;
		private int tickBasedAverageBars = 5;
		private int lookbackPeriodDays = 3;
		private int dataPointsPerDay = 0;
		private List<Dictionary<int, float>> db;	

		private double val=25,valueForecast=50;
		private int lastForecastTime, forecastPeriod;

		private const int volPeriod = 5;
		private const double primaryE = 3;
		private const double forecastE = 2;

		private SMA indSmaPrimary, indSmaForecast;

        #region RegInitialize

        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    Name = "ARC_VSR_Speed";
                    Description = "";
					
					AddPlot(new Stroke(Brushes.DodgerBlue, 2), PlotStyle.Line, "ForecastValue");			
					AddPlot(new Stroke(Brushes.Yellow, 2), PlotStyle.Bar, "CurrentValue");
											
		            IsOverlay				= false;
					Calculate = Calculate.OnEachTick;
					
                    break;

                case State.Configure:

					if(iCalculationModel[0]=='B'){
						AddDataSeries(Instrument.FullName, BarsPeriodType.Tick, 1); //1
					}else{
						switch(iBinTimeScalar)
						{
							case "SECONDS":
							{
								dataPointsPerDay = 86400;
								AddDataSeries(Instrument.FullName, BarsPeriodType.Second, 1); //1
								break;
							}
							case "MINUTES":
							{
								dataPointsPerDay = 1440;
								AddDataSeries(Instrument.FullName, BarsPeriodType.Minute, 1); //1
								break;			
							}
						}
					}
					
                    break;
					
				case State.DataLoaded:					
						
					if(iCalculationModel[0]=='A'){
						this.db = new List<Dictionary<int, float>>();
						this.indSmaPrimary = SMA(BarsArray[0], volPeriod);
						this.indSmaForecast = SMA(BarsArray[1], volPeriod);

						if(BarsArray[0].BarsType.BuiltFrom != BarsPeriodType.Tick)			
							this.forecastPeriod = BarsArray[0].BarsType.BarsPeriod.Value;
					}
					
					break;
             }
        }
		
		
		#endregion

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {

			if(CurrentBars[0] <= 1 || CurrentBars[1] <= 1 || this.key != 10812655)
				return;
			if(iCalculationModel[0]=='A'){
				#region -- CalcModel 'A' --
				int timeIndex = 0;
				if(this.iBinTimeScalar.StartsWith("SECONDS"))
					timeIndex = Times[1][0].Hour * 3600 + Times[1][0].Minute * 60 + Times[1][0].Second;
				else
					timeIndex = Times[1][0].Hour * 60 + Times[1][0].Minute;
				
			#region RegDb
			
			if(BarsInProgress == 1)
			{
				// Session break - Pin point here.
				if(Times[1][0].Date != Times[1][1].Date)
				{					
					lastForecastTime = timeIndex;
				
					// Create the new point in the list
					this.db.Add(new Dictionary<int, float>());
					// Add keys for the entire day
					for(int i = 0 ; i < this.dataPointsPerDay ; i++)
						this.db[this.db.Count - 1].Add(i, 0);					
										
					// Trim database.  Add 1 to handle the fact that you can't forecast using current day's data.
					if(this.db.Count > this.lookbackPeriodDays + 2)
						this.db.RemoveAt(0);
				}									
				
				// Add this data point, once the first day has been added
				if(this.db.Count > 0)
				{
					
					double[] srcArryF = new double[volPeriod];
					for(int i = 0; i < Math.Min(CurrentBars[0], volPeriod) ; i++)
						srcArryF[i] = this.indSmaForecast[i];
					
					double eF = ComputeE(srcArryF) * forecastE;
					this.db[this.db.Count - 1][timeIndex] = (float)(((this.indSmaForecast[0] + eF) - (this.indSmaForecast[0] - eF)) / TickSize);
				}
				
				return;
			}
			#endregion
			
				// Do not process until data exists in the database
				if(this.db.Count == 0)
					return;	
				
				if(CurrentBars[0] <= Math.Max(this.tickBasedAverageBars, this.iAveragePeriod))
					return;			
				
				if(BarsArray[0].BarsType.BuiltFrom == BarsPeriodType.Tick || this.iAveragePeriod != 1)
				{
					// Compute average time over last 5 bars 
					int sumTime = 0;	
					int sumCount = 0;
					for(int i = 0 ; i < tickBasedAverageBars ; i++)
					{
						sumCount++;
						sumTime += (int)(Times[0][i].Subtract(Times[0][i+1]).TotalSeconds);
					}
					
					if(sumCount > 0)
						this.forecastPeriod = (sumTime / sumCount);								
				}
				
				// Forecast over time period							
				if(timeIndex - this.lastForecastTime >= this.forecastPeriod)
				{				
					// Set this as the new time last forecast time
					this.lastForecastTime = timeIndex;
									
					List<float> values = new List<float>();
					for(int dbIndex = this.db.Count - 2 ; dbIndex >= 0 ; dbIndex--)
					{		
						float sum = 0;
						float count = 0;						
						for(int i = timeIndex ; i < Math.Min(timeIndex + this.forecastPeriod, this.dataPointsPerDay) ; i++)						
						{
							sum += this.db[dbIndex][i];	
							count++;
						}

						values.Add(sum);
					}					
									
					float sumValues = 0;
					float countValues = 0;
					for(int i = 0 ; i < values.Count ; i++)
					{
						if(values[i] != 0)
						{
							countValues++;
							sumValues += values[i];						
						}
					}
					
					if(countValues > 0)
						this.valueForecast = (sumValues / countValues);					
				}
				
				double[] srcArry = new double[volPeriod];
				for(int i = 0; i < Math.Min(CurrentBars[0], volPeriod) ; i++)
					srcArry[i] = this.indSmaPrimary[i];
				
				double e = ComputeE(srcArry) * primaryE;
				val = (MAX(High, volPeriod)[0] - MIN(Low, volPeriod)[0]) / TickSize;

				if(!IsFinite(val) || !IsFinite(this.valueForecast))
				{
					CurrentValue[0] = CurrentValue[1];
					ForecastValue[0] = ForecastValue[1];
					return;
				}
				#endregion
			}else if (iCalculationModel[0] == 'B' && BarsInProgress==0){
				//Forecast is the number of ticks between 2-chart bars ago and 1-chart bar ago.
				//Val is the number of ticks in the current chart bar
				var t5 = Times[0][2];
				var t1 = Times[0][1];
				int rbar5 = CurrentBars[1] - BarsArray[1].GetBar(t5);//number of ticks for last 2 chart bars
				int rbar1 = CurrentBars[1] - BarsArray[1].GetBar(t1);//number of ticks in current chart bar
				valueForecast = rbar5 - rbar1;
				valueForecast = Math.Max(1,valueForecast);
				val = rbar1;
			}
			CurrentValue[0] = val;
			ForecastValue[0] = this.valueForecast *1.5;//this gives room for the current tick count to be above the count of the prior bar
        }
		
		private double ComputeE(double[] source)
		{
			Array.Sort(source);

			double med = source.Length % 2 == 0
				? (source[source.Length / 2 - 1] + source[source.Length / 2]) / 2.0
				: source[source.Length / 2];

			double[] d = source.Select(x => Math.Abs(x - med)).OrderBy(x => x).ToArray();

			return (1.483 * (d.Length % 2 == 0 ? (d[d.Length / 2 - 1] + d[d.Length / 2]) / 2.0 : d[d.Length / 2]));
		}
		
        private bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value) && value > TickSize && value < double.MaxValue;
        }		

        #region Properties
		
		public override string ToString()
		{
			return Name;
		}
	
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove		
		public Series<double> ForecastValue
        {
            get { return Values[0]; }
        }
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove		
		public Series<double> CurrentValue
        {
            get { return Values[1]; }
        }		
		
        #endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.Sup.ARC_VSRSpeed[] cacheARC_VSRSpeed;
		public ARC.Sup.ARC_VSRSpeed ARC_VSRSpeed(string binTimeScalar, string calculationModel)
		{
			return ARC_VSRSpeed(Input, binTimeScalar, calculationModel);
		}

		public ARC.Sup.ARC_VSRSpeed ARC_VSRSpeed(ISeries<double> input, string binTimeScalar, string calculationModel)
		{
			if (cacheARC_VSRSpeed != null)
				for (int idx = 0; idx < cacheARC_VSRSpeed.Length; idx++)
					if (cacheARC_VSRSpeed[idx] != null && cacheARC_VSRSpeed[idx].BinTimeScalar == binTimeScalar && cacheARC_VSRSpeed[idx].CalculationModel == calculationModel && cacheARC_VSRSpeed[idx].EqualsInput(input))
						return cacheARC_VSRSpeed[idx];
			return CacheIndicator<ARC.Sup.ARC_VSRSpeed>(new ARC.Sup.ARC_VSRSpeed(){ BinTimeScalar = binTimeScalar, CalculationModel = calculationModel }, input, ref cacheARC_VSRSpeed);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.Sup.ARC_VSRSpeed ARC_VSRSpeed(string binTimeScalar, string calculationModel)
		{
			return indicator.ARC_VSRSpeed(Input, binTimeScalar, calculationModel);
		}

		public Indicators.ARC.Sup.ARC_VSRSpeed ARC_VSRSpeed(ISeries<double> input , string binTimeScalar, string calculationModel)
		{
			return indicator.ARC_VSRSpeed(input, binTimeScalar, calculationModel);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.Sup.ARC_VSRSpeed ARC_VSRSpeed(string binTimeScalar, string calculationModel)
		{
			return indicator.ARC_VSRSpeed(Input, binTimeScalar, calculationModel);
		}

		public Indicators.ARC.Sup.ARC_VSRSpeed ARC_VSRSpeed(ISeries<double> input , string binTimeScalar, string calculationModel)
		{
			return indicator.ARC_VSRSpeed(input, binTimeScalar, calculationModel);
		}
	}
}

#endregion
