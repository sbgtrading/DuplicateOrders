#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;

using System.Windows.Automation;
using System.Windows.Controls;
#endregion

#region Author/Copyright
/*********************************************************************
************************* Golden Zone Trading ************************
**********************************************************************
* Author NT7 : -
* Author NT8 : Kriss { AzurITec }
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
v1.000  - 06.05.2016    + Conversion from NT7 to NT8b10 as is (no change nor optimization).
----------------------------------------------------------------------
v1.001  - 20.05.2016    + Removed functionalities : drag of Zone/curve + Move of Zones.
                        + Removed Holidays in UI but still present in calculations
----------------------------------------------------------------------
v1.002  - 27.05.2016    + Compatibility with beta11 (CBC with OnRender)
                        + Setting wdw + chart Loading speed OK
----------------------------------------------------------------------
v1.003  - 06.06.2016    + Version after Sean first review
                        + Changes in DropDown Menu : Visuals => Zone Visuals / sub menu => All Zones / sub menu MST now in MST main menu
                        + MarketStructure main menu : Now ON/OFF master labels.
                        + Toolbar Font in bold + Border
                        + All fontsize are 12 by default
                        + Tested shading is OFF by default
                        + Bug Fixed regarding Volume Profile info on chart (VV + V% in Tick calc)
----------------------------------------------------------------------
v1.004  - 07.06.2016    + Removed "Controls" in Menu
                        + Expand now change on dropbox change
                        + Removed MST Labels ON/OFF
                        + Add MST Font size in user settings
                        + Bug Fixed with region drawn before bars are display when scroll back on historical data
----------------------------------------------------------------------
v1.005  - 13.06.2016    + Modify Numeric UpDown design to work with skins
----------------------------------------------------------------------
v1.006  - 15.06.2016    + Changed AntiAlias Mode to remove blurryness in Histogram drawing
                        + FIXED MTF issues in OnRender and when MTF equals to primary bars
----------------------------------------------------------------------
v1.007  - 21.06.2016    + BUGSDV00 : [FIXED] One level missing in profile calculation causing blank profiles.
----------------------------------------------------------------------
v1.008  - 06.09.2016    + Added LVNs + Options in settings and toolbar
                        + Compatible Beta13 RC1
----------------------------------------------------------------------
v1.009  - 22.09.2016    + Added [NinjaScriptProperty] Attribute to be called from PPTrades indicator
----------------------------------------------------------------------
v1.010  - 02.11.2016    + Simplified Opacity Settings
                        + Compatible Beta14 RC2
                        + Change ForceRefresh() to ChartControl.InvalidateVisual() for immediate change
----------------------------------------------------------------------
v1.011  - 15.11.2016    + Bug fixed - TickSize made global -> Contacted NT support but response is crazy
                        + Bug fixed - CurrentBar inside Render is now CurrentBars[0]
                        + Compatible NT8.0.1
----------------------------------------------------------------------
v1.012  - 30.11.2016    + #RJBug001 fixed - WPF controls can't be initialized in global area because main thread is not STA => crash when opened in MarketAnalyzer
----------------------------------------------------------------------
v1.013  - 01.03.2017    + New textchanged/keydown event code for NumericUPDW
                        + New color of DD
                        + Added Compilation Licensing code
                        + Tested with 8.0.4.0
----------------------------------------------------------------------
v1.1    - 08.Feb.2018   + Added "Bars_To_Process" to limit the load time during times of high volatility
----------------------------------------------------------------------
v1.2    - 13.Feb.2018   + Cleaned up dozens of string concats, replaced with string.Format()
                        + Worked on getting zones to print in 8.0.12.0, changed MouseMove and MouseDown, added ChartingExtensions method call
                        + Removed mouse coords (unecessary) on MouseUp event
----------------------------------------------------------------------
v1.31   - 24.Oct.2018   + Corrected WAV file path issue...and added the SoundFileHandler method
v1.4    - 22.Oct.2018   + Fixed null brush on DeltaFactor drawing
----------------------------------------------------------------------
######################################################################
~~~~~~~~~~~~~~~~~~~~~~~~~ BUGS/ LIMITATIONS ~~~~~~~~~~~~~~~~~~~~~~~~~~
BUGSDV00 [FIXED] => When High=Low (specific case on small timeframes) and with Minutes/Seconds Profiles, num_bis = 0 causing no profile calculation. 
					If all bars inside the zones are H=L, then no profiles print. Also profiles are wrong because only bars with H!=L are taken into account.
**********************************************************************
*/
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	#region -- Category Order --
	[CategoryOrder("TimeFrame Parameters",          10)]
	[CategoryOrder("Parameters",                    20)]
	[CategoryOrder("Parameters Market Structure",   30)]
	[CategoryOrder("Curve",                         40)]
	[CategoryOrder("Profile",                       50)]
	[CategoryOrder("Visual Toggles",                60)]
	[CategoryOrder("Visual Style",                  70)]
	[CategoryOrder("Visual Style Market Structure", 80)]
	[CategoryOrder("Visual Style Paintbars",        90)]
	[CategoryOrder("Alerts",                        100)]
	[CategoryOrder("Global Visuals",                110)]
	[CategoryOrder("Qualified Zones",               120)]
	[CategoryOrder("Trade Plan",                    130)]
	[CategoryOrder("Trade Plan Entry",              140)]
	[CategoryOrder("Trade Plan StopLoss",           150)]
	[CategoryOrder("Trade Plan Target1",            160)]
	[CategoryOrder("Trade Plan Target2",            170)]
	[CategoryOrder("Indicator Version",             180)]
	#endregion

	public class ARC_SDVSystem : Indicator
	{
		#region -- Constants --
		private const int CONSOLIDATION_BAR_ID = 0;
		private const int SIMPLE_UPBAR_ID = 2;
		private const int SIMPLE_DOWNBAR_ID = -2;
		private const int REV_CONTINUE_UPBAR_ID = 3;
		private const int REV_CONTINUE_DOWNBAR_ID = -3;
		private const int THRUST_UPBAR_ID = 4;
		private const int THRUST_DOWNBAR_ID = -4;
		private const char SUPPLY_ID = 'S';
		private const char DEMAND_ID = 'D';
		private const int UPPER_LEFT = 0;
		private const int LOWER_LEFT = 1;
		private const int LOWER_RIGHT = 2;
		private const int UPPER_RIGHT = 3;
		private const int CONTROLZ = 4;
		private const int CONTROLX = 5;
		private const int CONTROLPL = 8;
		private const int CONTROLPPR = 9;
		private const int CONTROLPPC = 10;
		private const int CONTROLPVL = 11;
		private const int CONTROLPVH = 12;
		private const int CONTROLPVP = 13;
		private const int CONTROLPVC = 14;
		private const int CONTROLPPT = 15;
		private const int CONTROLPDF = 16;
		private const int CONTROLPVV = 17;
		private const int CENTER = 18;

		private const int GZ_DEMAND = 0;
		private const int GZ_SUPPLY = 1;
		private const int GZ_DEMANDSUPPLY = 2;

		private const int GZ_INSUPPLY = 1;
		private const int GZ_PRICEOUT = 0;
		private const int GZ_INDEMAND = -1;

		private const int GZ_CONTROL_ACTIVE = -5;
		private const int GZ_CONTROL = -4;
		private const int GZ_HOVER = -3;
		private const int GZ_LABEL = -2;
		private const int GZ_SWING = -1;

		private const int GZ_FORMED = 0;
		private const int GZ_FRESH = 1;
		private const int GZ_RETEST = 2;
		private const int GZ_TESTED = 3;
		private const int GZ_HIDDEN = 4;
		private const int GZ_BROKEN = 5;

		private const int GZ_RALLY = 1;
		private const int GZ_BASE = 0;
		private const int GZ_DROP = -1;
		#endregion

		private bool ValidLicense   = true;
		private bool LicenseChecked = false;
		private bool IsDebug  = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "SDVSystem";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "11165", "819", "27405"};//27405 is Annual Membership and 819 is old mastery program
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		//1.0 Jan 14 2020 - changed to ARC_SDVSystem
		//1.1 Mar 24 2020 - Added two VolAverages lines (with UI)
		//1.2 - Set all Series<double> to MaxBarsLookBack.Infinite
		//1.3 - used Linq to select zones to update/mouse-over.  OnRender and ChartPanel_MouseMove method, Changed GZS[g] to "foreach(z in zones)"
        private const string VERSION = "v1.3 23-Jun-22";
        #region -- Variables --
        private List<GZone> GZS;
        private MouseManager MM;
        private bool UseChartBars = false;
        private bool showLabels = true;

        //private Brush tempBrush;
        private Pen tempPen;
        private DashStyleHelper tempPenDashStyle;

        private double gMin, gMax;
        private Rect gChartBounds;
        private ChartScale gChartScale;

        private int ClosestSupplyZone = -1;
        private int ClosestDemandZone = -1;

        private BarsPeriodType EChartType1;
        private int GZSLastCount = 0;
        
        private SessionIterator sessionIterator;
        Dictionary<ARC_SDVSystem_MTFBarType, BarsPeriodType> dictionaryPeriodTypes = new Dictionary<ARC_SDVSystem_MTFBarType, BarsPeriodType>()
        { 
            {ARC_SDVSystem_MTFBarType.Tick,   BarsPeriodType.Tick},
            {ARC_SDVSystem_MTFBarType.Range,  BarsPeriodType.Range},
            {ARC_SDVSystem_MTFBarType.Second, BarsPeriodType.Second},
            {ARC_SDVSystem_MTFBarType.Volume, BarsPeriodType.Volume},
            {ARC_SDVSystem_MTFBarType.Minute, BarsPeriodType.Minute},
            {ARC_SDVSystem_MTFBarType.Day,    BarsPeriodType.Day},
            {ARC_SDVSystem_MTFBarType.Week,   BarsPeriodType.Week},
            {ARC_SDVSystem_MTFBarType.Month,  BarsPeriodType.Month},
            {ARC_SDVSystem_MTFBarType.Year,   BarsPeriodType.Year}
        };

        private Brush pLineColor1;

        #region -- zigzag --
        private double multiplierATR = 0.15;
        private double currentHigh = 0.0;
        private double currentLow = 0.0;
        private double priorCurrentHigh = 0.0;
        private double priorCurrentLow = 0.0;
        private double swingMax = 0.0;
        private double swingMin = 0.0;
        
        private int lastHighIdx = 0;
        private int lastLowIdx = 0;
        private int priorLastHighIdx = 0;
        private int priorLastLowIdx = 0;
        private int priorSwingHighIdx = 0;
        private int priorSwingLowIdx = 0;
        private bool showDots = false;
        private bool upTrend = true;
        private bool priorUpTrend = true;
        private bool firstHighIdx = false;
        private bool firstLowIdx = false;
        private bool addHigh = false;
        private bool updateHigh = false;
        private bool addLow = false;
        private bool updateLow = false;
        private bool isPreliminaryHigh = false;
        private bool isPreliminaryLow = false;
        //private SimpleFont mstTextFont = new SimpleFont("Arial", 12);//v1.003 - was 10, Sean asked 12
        private int fontSize = 6;
        private int plot0Width = 2;
        private int dotSize = 4;
        private ATR avgTrueRange;
        #endregion

        #region -- supply & demand zones --
        private int zoneCount = 8;        
        private int sessionBar = 1; //changed V23
        private int consolidationIndex = 0;
        private int priorConsolidationIndex = 0;
        private int priorIndex = 0;
        private int demandIndex = 0;
        private int supplyIndex = 0;
        private int demandArraySize = 0;
        private int supplyArraySize = 0;
        private int startBar = 0;
        private int lastThrustBarUp = -1;
        private int lastThrustBarDown = -1;
        private int longSignal1Bar = 0;
        private int longSignal2Bar = 0;
        private int longPOCSignal1Bar = 0;
        private int longPOCSignal2Bar = 0;
        private int longVCSignal1Bar = 0;
        private int longVCSignal2Bar = 0;
        private int longVASignal1Bar = 0;
        private int longVASignal2Bar = 0;
        private int shortSignal1Bar = 0;
        private int shortSignal2Bar = 0;
        private int shortPOCSignal1Bar = 0;
        private int shortPOCSignal2Bar = 0;
        private int shortVCSignal1Bar = 0;
        private int shortVCSignal2Bar = 0;
        private int shortVASignal1Bar = 0;
        private int shortVASignal2Bar = 0;
        private int longSignalAll1Bar = 0;
        private int longSignalAll2Bar = 0;
        private int longPOCSignalAll1Bar = 0;
        private int longPOCSignalAll2Bar = 0;
        private int longVCSignalAll1Bar = 0;
        private int longVCSignalAll2Bar = 0;
        private int longVASignalAll1Bar = 0;
        private int longVASignalAll2Bar = 0;
        private int shortSignalAll1Bar = 0;
        private int shortSignalAll2Bar = 0;
        private int shortPOCSignalAll1Bar = 0;
        private int shortPOCSignalAll2Bar = 0;
        private int shortVCSignalAll1Bar = 0;
        private int shortVCSignalAll2Bar = 0;
        private int shortVASignalAll1Bar = 0;
        private int shortVASignalAll2Bar = 0;
        private double multiplier = 0.0;
        private double avgSessionBody = 0.0;
        private double avgCurrentBody = 0.0;
        private double avgConsolidationBody = 0.0;
        private double consolidationHigh = double.MinValue;
        private double consolidationLow = double.MaxValue;
        private double consolidationVAHigh = double.MinValue;
        private double consolidationVALow = double.MaxValue;
        private double distalLine = 0.0;
        private double proximalLine = 0.0;
        private double distalLineOL = 0.0;
        private double tempHigh = double.MinValue;
        private double tempLow = double.MaxValue;
        private bool showDemandZones = false;//false;
        private bool showSupplyZones = false;
        private bool showExpiredZones = false;
        private bool showFreshSignals = false;
        private bool showAllSignals = false;
        private bool showConsecutiveSignals = false;
        
        private bool applyThrustFilter = false;
        private bool firstSessionComplete = false;
        private bool init = false;
        private bool priorHistorical = true;
        private bool noPublicHoliday = true;
        private DateTime lastBarTimeStamp = new DateTime(0);
        private DateTime currentDate = new DateTime(0);
        
        private Brush freshDemandColor = Brushes.Lime;
        private Brush freshSupplyColor = Brushes.Coral;
        private Brush demandColor = Brushes.DarkGreen;
        private Brush supplyColor = Brushes.DarkRed;
        private Brush freshDemandFillColor = Brushes.Lime;
        private Brush freshSupplyFillColor = Brushes.Coral;
        private Brush demandFillColor = Brushes.DarkGreen;
        private Brush supplyFillColor = Brushes.DarkRed;
        private Brush longEntryColor = Brushes.Lime;
        private Brush shortEntryColor = Brushes.Red;
        private int opacity = 3;
        private SimpleFont arrowFont = null;
        private string arrowStringUp = "5";
        private string arrowStringDown = "6";

        private List<int>    demandFirstBar = new List<int>();
        private List<int>    demandLastBar  = new List<int>();
        private List<int>    supplyFirstBar = new List<int>();
        private List<int>    supplyLastBar  = new List<int>();
        private List<double> demandUpper = new List<double>();
        private List<double> demandLower = new List<double>();
        private List<double> demandPOC   = new List<double>();
        private List<double> demandPOCHit  = new List<double>();
        private List<double> demandPOCHits = new List<double>();
        private List<double> demandVCHit   = new List<double>();
        private List<double> demandVCHits  = new List<double>();
        private List<double> demandVAHit   = new List<double>();
        private List<double> demandVAHits  = new List<double>();
        private List<double> demandVAH = new List<double>();
        private List<double> demandVAL = new List<double>();
        private List<double> demandVCT = new List<double>();
        private List<double> demandVCB = new List<double>();
        private List<bool>   demandVC      = new List<bool>();
        private List<bool>   demandVA      = new List<bool>();
        private List<double> supplyUpper   = new List<double>();
        private List<double> supplyLower   = new List<double>();
        private List<double> supplyPOC     = new List<double>();
        private List<double> supplyPOCHit  = new List<double>();
        private List<double> supplyPOCHits = new List<double>();
        private List<double> supplyVCHit   = new List<double>();
        private List<double> supplyVCHits  = new List<double>();
        private List<double> supplyVAHit   = new List<double>();
        private List<double> supplyVAHits  = new List<double>();
        private List<double> supplyVAH = new List<double>();
        private List<double> supplyVAL = new List<double>();
        private List<double> supplyVCT = new List<double>();
        private List<double> supplyVCB = new List<double>();
        private List<bool>   supplyVC  = new List<bool>();
        private List<bool>   supplyVA  = new List<bool>();
        private List<bool>   demandFresh   = new List<bool>();
        private List<bool>   supplyFresh   = new List<bool>();        
        private DateTime[]   publicHoliday = new DateTime[48];
        #endregion
		static string  HLtemplates_folder = null;


        #region -- DataSeries --
        private Series<double> bodyHigh;
        private Series<double> bodyLow;
        private Series<double> bodyRange;
		private Series<double> truerange;

        private Series<double> allDemandProximal1;
        private Series<double> allDemandDistal1;
        private Series<double> allDemandPOC1;
        private Series<double> allDemandVAH1;
        private Series<double> allDemandVAL1;
        private Series<double> allDemandVCT1;
        private Series<double> allDemandVCB1;

        private Series<double> allSupplyProximal1;
        private Series<double> allSupplyDistal1;
        private Series<double> allSupplyPOC1;
        private Series<double> allSupplyVAH1;
        private Series<double> allSupplyVAL1;
        private Series<double> allSupplyVCT1;
        private Series<double> allSupplyVCB1;

        private Series<double> freshDemandProximal1;
        private Series<double> freshDemandDistal1;
        private Series<double> freshDemandPOC1;
        private Series<double> freshDemandVAH1;
        private Series<double> freshDemandVAL1;
        private Series<double> freshDemandVCT1;
        private Series<double> freshDemandVCB1;

        private Series<double> freshSupplyProximal1;
        private Series<double> freshSupplyDistal1;
        private Series<double> freshSupplyPOC1;
        private Series<double> freshSupplyVAH1;
        private Series<double> freshSupplyVAL1;
        private Series<double> freshSupplyVCT1;
        private Series<double> freshSupplyVCB1;

        private Series<double> allDemandProximal2;
        private Series<double> allDemandDistal2;
        private Series<double> allDemandPOC2;
        private Series<double> allDemandVAH2;
        private Series<double> allDemandVAL2;
        private Series<double> allDemandVCT2;
        private Series<double> allDemandVCB2;

        private Series<double> allSupplyProximal2;
        private Series<double> allSupplyDistal2;
        private Series<double> allSupplyPOC2;
        private Series<double> allSupplyVAH2;
        private Series<double> allSupplyVAL2;
        private Series<double> allSupplyVCT2;
        private Series<double> allSupplyVCB2;

        private Series<double> freshDemandProximal2;
        private Series<double> freshDemandDistal2;
        private Series<double> freshDemandPOC2;
        private Series<double> freshDemandVAH2;
        private Series<double> freshDemandVAL2;
        private Series<double> freshDemandVCT2;
        private Series<double> freshDemandVCB2;

        private Series<double> freshSupplyProximal2;
        private Series<double> freshSupplyDistal2;
        private Series<double> freshSupplyPOC2;
        private Series<double> freshSupplyVAH2;
        private Series<double> freshSupplyVAL2;
        private Series<double> freshSupplyVCT2;
        private Series<double> freshSupplyVCB2;

        private Series<double> longSignal;
        private Series<double> longPOCSignal;
        private Series<double> longVCSignal;
        private Series<double> longVASignal;

        private Series<double> shortSignal;
        private Series<double> shortPOCSignal;
        private Series<double> shortVCSignal;
        private Series<double> shortVASignal;

        private Series<double> longSignals;
        private Series<double> longPOCSignals;
        private Series<double> longVCSignals;
        private Series<double> longVASignals;

        private Series<double> shortSignals;
        private Series<double> shortPOCSignals;
        private Series<double> shortVCSignals;
        private Series<double> shortVASignals;

        private Series<double> longSignalAll;
        private Series<double> longPOCSignalAll;
        private Series<double> longVCSignalAll;
        private Series<double> longVASignalAll;

        private Series<double> shortSignalAll;
        private Series<double> shortPOCSignalAll;
        private Series<double> shortVCSignalAll;
        private Series<double> shortVASignalAll;

        private Series<double> longSignalsAll;
        private Series<double> longPOCSignalsAll;
        private Series<double> longVCSignalsAll;
        private Series<double> longVASignalsAll;

        private Series<double> shortSignalsAll;
        private Series<double> shortPOCSignalsAll;
        private Series<double> shortVCSignalsAll;
        private Series<double> shortVASignalsAll;

        private Series<double> barType;
        private Series<double> trend;
		private Series<double> ThrustOvershoot;

        private Series<double> bodyHighDefault;
        private Series<double> bodyLowDefault;
        private Series<double> bodyRangeDefault;

        private Series<double> allDemandProximal1Default;
        private Series<double> allDemandDistal1Default;
        private Series<double> allDemandPOC1Default;
        private Series<double> allDemandVAH1Default;
        private Series<double> allDemandVAL1Default;
        private Series<double> allDemandVCT1Default;
        private Series<double> allDemandVCB1Default;

        private Series<double> allSupplyProximal1Default;
        private Series<double> allSupplyDistal1Default;
        private Series<double> allSupplyPOC1Default;
        private Series<double> allSupplyVAH1Default;
        private Series<double> allSupplyVAL1Default;
        private Series<double> allSupplyVCT1Default;
        private Series<double> allSupplyVCB1Default;

        private Series<double> freshDemandProximal1Default;
        private Series<double> freshDemandDistal1Default;
        private Series<double> freshSupplyProximal1Default;
        private Series<double> freshSupplyDistal1Default;

        private Series<double> allDemandProximal2Default;
        private Series<double> allDemandDistal2Default;
        private Series<double> allDemandPOC2Default;
        private Series<double> allDemandVAH2Default;
        private Series<double> allDemandVAL2Default;
        private Series<double> allDemandVCT2Default;
        private Series<double> allDemandVCB2Default;

        private Series<double> allSupplyProximal2Default;
        private Series<double> allSupplyDistal2Default;
        private Series<double> allSupplyPOC2Default;
        private Series<double> allSupplyVAH2Default;
        private Series<double> allSupplyVAL2Default;
        private Series<double> allSupplyVCT2Default;
        private Series<double> allSupplyVCB2Default;

        private Series<double> freshDemandProximal2Default;
        private Series<double> freshDemandDistal2Default;
        private Series<double> freshSupplyProximal2Default;
        private Series<double> freshSupplyDistal2Default;

        private Series<double> longSignalDefault;
        private Series<double> longPOCSignalDefault;
        private Series<double> longVCSignalDefault;
        private Series<double> longVASignalDefault;

        private Series<double> shortSignalDefault;
        private Series<double> shortPOCSignalDefault;
        private Series<double> shortVCSignalDefault;
        private Series<double> shortVASignalDefault;

        private Series<double> longSignalsDefault;
        private Series<double> longPOCSignalsDefault;
        private Series<double> longVCSignalsDefault;
        private Series<double> longVASignalsDefault;

        private Series<double> shortSignalsDefault;
        private Series<double> shortPOCSignalsDefault;
        private Series<double> shortVCSignalsDefault;
        private Series<double> shortVASignalsDefault;

        private Series<double> longSignalAllDefault;
        private Series<double> longPOCSignalAllDefault;
        private Series<double> longVCSignalAllDefault;
        private Series<double> longVASignalAllDefault;

        private Series<double> shortSignalAllDefault;
        private Series<double> shortPOCSignalAllDefault;
        private Series<double> shortVCSignalAllDefault;
        private Series<double> shortVASignalAllDefault;

        private Series<double> longSignalsAllDefault;
        private Series<double> longPOCSignalsAllDefault;
        private Series<double> longVCSignalsAllDefault;
        private Series<double> longVASignalsAllDefault;

        private Series<double> shortSignalsAllDefault;
        private Series<double> shortPOCSignalsAllDefault;
        private Series<double> shortVCSignalsAllDefault;
        private Series<double> shortVASignalsAllDefault;

        private Series<double> barTypeDefault;
        private Series<double> trendDefault;

        private Series<double> vZigZag;
        private Series<double> vZigZagHigh;
        private Series<double> vZigZagLow;

        private Series<double> vCurve1;
        private Series<double> vCurve2;
        private Series<double> vCurve3;
        private Series<double> vCurve4;
        private Series<double> vCurve5;
        private Series<double> vCurveStatus;

        private Series<double> sExtrnDemandTop;
        private Series<double> sExtrnDemandBottom;
        private Series<double> sExtrnSupplyTop;
        private Series<double> sExtrnSupplyBottom;

        private Series<double> CurveLow;
        private Series<double> CurveHigh;
        private Series<double> CurveLowZ;
        private Series<double> CurveHighZ;
        private Series<double> CurveLowF;
        private Series<double> CurveHighF;
        private Series<double> CurveBar;
        private Series<double> AllPivots;
        private Series<double> FinalHigh;
        private Series<double> FinalLow;
        #endregion

        #region -- moving median VWTPO --

        private int period = 20;
        private int lookback = 0;
        private int fieldSize = 0;
        private int lowIndex = 0;
        private int bodyHighIndex = 0;
        private int bodyLowIndex = 0;
        private int highIndex = 0;
        private int plotCount = 0;
        private double high = 0.0;
        private double low = 0.0;
        private double preVolume = 0;
        private double slice = 0.0;
        private double volume = 0;
        private double sum = 0.0;
        private double price = 0.0;
        private double valueAreaHigh = 0.0;
        private double valueAreaLow = 0.0;
        private List<double> fList = new List<double>();

        #endregion

        #region -- RegCurveVariables --
        private int CB = 0;
        private double CH = 0;
        private double CL = 0;

        private bool MovingCurveTop, MovingCurveBottom = false;

        private double Price100P = 0;
        private int CBar = 0;
        private double Price0P = 0;
        private int BB2 = 0;

        Rect B1 = new Rect(0, 0, 0, 0);
        
        SortedDictionary<double, int> AllLevels = new SortedDictionary<double, int>();
        SortedDictionary<int, double> HighP  = new SortedDictionary<int, double>();
        SortedDictionary<int, double> LowP   = new SortedDictionary<int, double>();
        SortedDictionary<int, double> HighLA = new SortedDictionary<int, double>();
        SortedDictionary<int, double> LowLA  = new SortedDictionary<int, double>();
        SortedDictionary<int, double> DeleteLA = new SortedDictionary<int, double>();
        SortedDictionary<int, int>    HighLF = new SortedDictionary<int, int>();
        SortedDictionary<int, int>    LowLF  = new SortedDictionary<int, int>();
        SortedDictionary<int, string> HighLabels = new SortedDictionary<int, string>();
        SortedDictionary<int, string> LowLabels  = new SortedDictionary<int, string>();

        private List<int> PotentialHighs = new List<int>();
        private List<int> PotentialLows = new List<int>();
        private List<int> PotentialDeletes = new List<int>();

        string LastLow, LastHigh = string.Empty;

        private bool DrawingCurve = false;
        private bool DrawingCurve2 = false;
        private bool AdjustingCurve = false;
        private bool MovingCurve = false;

        private int ClickedBar1, ClickedBar2, DifferenceBars = -1;
        private double ClickedPrice1, ClickedPrice2, DifferencePrice = 0;

        private int CurrentHighBar, CurrentLowBar = 0;
        private bool WaitingForHigh = true;
        private bool WaitingForLow = true;
        private double CurrentHighPrice, CurrentLowPrice, TradeHighPrice, TradeLowPrice = 0;
        private bool IsCurrentBar = false;

        private int y = 0;
        private int x = 0;
        private int x1 = 0;
        private int x2 = 0;
        private int x3 = 0;
        private int x4 = 0;
        private int x5 = 0;
        private int x6 = 0;
        private int x7 = 0;
        private int x8 = 0;

        private int y1 = 0;
        private int y2 = 0;
        private int y3 = 0;
        private int y4 = 0;
        private int y5 = 0;
        private int y6 = 0;
        private int y7 = 0;
        private int y8 = 0;
        private int y9 = 0;

        private int pButtonSize = 15;
        private int pTicksMove = 0;
        private int TicksToBreak = 0;
        private int CurveLowIdx = 0;
        private int CurveHighIdx = 0;
        #endregion

        #region -- RegHistVariables --
        private GHistogram MinHist;
        private GHistogram Hist;
        private List<GHistogram> BarHists;

        private double PrevTick = 0.0;
        private double CurrTick = 0.0;
        private ARC_SDVSystem_TickDirection LastTickType = ARC_SDVSystem_TickDirection.DOWN;
        #endregion
    
        #region -- public holiday --
        private DateTime publicHoliday0 = new DateTime(2010, 01, 18);
        private DateTime publicHoliday1 = new DateTime(2010, 02, 15);
        private DateTime publicHoliday2 = new DateTime(2010, 04, 02);
        private DateTime publicHoliday3 = new DateTime(2010, 05, 31);
        private DateTime publicHoliday4 = new DateTime(2010, 07, 05);
        private DateTime publicHoliday5 = new DateTime(2010, 09, 06);
        private DateTime publicHoliday6 = new DateTime(2010, 11, 11);
        private DateTime publicHoliday7 = new DateTime(2010, 11, 25);
        private DateTime publicHoliday8 = new DateTime(2011, 01, 17);
        private DateTime publicHoliday9 = new DateTime(2011, 02, 21);
        private DateTime publicHoliday10 = new DateTime(2011, 04, 22);
        private DateTime publicHoliday11 = new DateTime(2011, 05, 30);
        private DateTime publicHoliday12 = new DateTime(2011, 07, 04);
        private DateTime publicHoliday13 = new DateTime(2011, 09, 05);
        private DateTime publicHoliday14 = new DateTime(2011, 11, 11);
        private DateTime publicHoliday15 = new DateTime(2011, 11, 24);
        private DateTime publicHoliday16 = new DateTime(2012, 01, 16);
        private DateTime publicHoliday17 = new DateTime(2012, 02, 20);
        private DateTime publicHoliday18 = new DateTime(2012, 04, 06);
        private DateTime publicHoliday19 = new DateTime(2012, 05, 28);
        private DateTime publicHoliday20 = new DateTime(2012, 07, 04);
        private DateTime publicHoliday21 = new DateTime(2012, 09, 03);
        private DateTime publicHoliday22 = new DateTime(2012, 11, 12);
        private DateTime publicHoliday23 = new DateTime(2012, 11, 22);
        private DateTime publicHoliday24 = new DateTime(2013, 01, 21);
        private DateTime publicHoliday25 = new DateTime(2013, 02, 18);
        private DateTime publicHoliday26 = new DateTime(2013, 03, 29);
        private DateTime publicHoliday27 = new DateTime(2013, 05, 27);
        private DateTime publicHoliday28 = new DateTime(2013, 07, 04);
        private DateTime publicHoliday29 = new DateTime(2013, 09, 02);
        private DateTime publicHoliday30 = new DateTime(2013, 11, 11);
        private DateTime publicHoliday31 = new DateTime(2013, 11, 28);
        private DateTime publicHoliday32 = new DateTime(2014, 01, 20);
        private DateTime publicHoliday33 = new DateTime(2014, 02, 17);
        private DateTime publicHoliday34 = new DateTime(2014, 04, 18);
        private DateTime publicHoliday35 = new DateTime(2014, 05, 26);
        private DateTime publicHoliday36 = new DateTime(2014, 07, 04);
        private DateTime publicHoliday37 = new DateTime(2014, 09, 01);
        private DateTime publicHoliday38 = new DateTime(2014, 11, 11);
        private DateTime publicHoliday39 = new DateTime(2014, 11, 27);
        private DateTime publicHoliday40 = new DateTime(2015, 01, 19);
        private DateTime publicHoliday41 = new DateTime(2015, 02, 16);
        private DateTime publicHoliday42 = new DateTime(2015, 04, 03);
        private DateTime publicHoliday43 = new DateTime(2015, 05, 25);
        private DateTime publicHoliday44 = new DateTime(2015, 07, 03);
        private DateTime publicHoliday45 = new DateTime(2015, 09, 07);
        private DateTime publicHoliday46 = new DateTime(2015, 11, 11);
        private DateTime publicHoliday47 = new DateTime(2015, 11, 26);
        #endregion

        #region -- other input variables --
        
        private int iChartValue2 = 1;
        private int iChartValue3 = 1;
        private bool iAutoHideRetests = false;
        private int iAutoHideNumberOfRetests = 2;
        private bool iShowHiddenZones = false;
        
        #endregion

		#region -- Toolbar variables --
		private string toolbarname = "NSSDVSystemToolBar", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;
		private SortedDictionary<string, bool> IsGlobalized = new SortedDictionary<string,bool>();

		private Menu MenuControlContainer;
		private MenuItem MenuControl;

		private ComboBox comboMTF, comboZFM, comboProfile;
		private MenuItem miProfileM1, miProfileM2, miProfileM3, miProfileM4, miProfileM5;
		private MenuItem miAvgStopFirstTouch, miAvgStopPOC, miAvgStopVA, miAvgStopVC, miGlobalize_FreshZones, miGlobalize_BrokenZones, miGlobalize_TestedZones, miGlobalize_QualifiedZones;
		private MenuItem miAvgVolPOC, miAvgVolVA, miAvgVolVC, miShowHide_FreshZones, miShowHide_BrokenZones, miShowHide_TestedZones, miShowHide_QualifiedZones;
		private MenuItem miEntryBasis, miSLBasis, miTPBasis, miShowLongTP, miShowShortTP, miShowFarTP, miShowNearTP, miShowTPOnFreshZones, miShowTPOnTestedZones, miShowTPOnQualifiedZones;
		private MenuItem miRecalculate1, miRecalculate2;//, miRecalculate3;
		private ComboBox VA1Combo, VA2Combo;
		private TextBox nudVA1, nudVA2;

		private TextBox nudMTF, nudZFM, nudMST1, nudMST2, nudCRV1, nudCRV2, nudMaxVolPctOfAvg, nudMaxBasingCount;
		private TextBox nudEntryOffset, nudSLOffset, nudATRperiod, nudSLsize_inTicks, nudT1size_inTicks, nudT2size_inTicks, nudSLsize_inATRs, nudT1size_inATRs, nudT2size_inATRs, nudT1size_inRRs, nudT2size_inRRs;

		private Button ClearGlobals_Button, EnableGlobals_Button;
		private Button gCmdup;
		private Button gCmddw;
		private Label gLabel;
		#endregion

        #endregion

		#region dx brushes
		SharpDX.Direct2D1.Brush[] overlapDXBrush = new SharpDX.Direct2D1.Brush[3];
        int[] overlapOpacity = new int[3];
        float[] overlapThickness = new float[3];
		SharpDX.Direct2D1.Brush iCurveAreaDXBrush1 = null;
		SharpDX.Direct2D1.Brush iCurveAreaDXBrush2 = null;
		SharpDX.Direct2D1.Brush iCurveAreaDXBrush3 = null;
		SharpDX.Direct2D1.Brush iCurveAreaDXBrush4 =null;
		SharpDX.Direct2D1.Brush iLineDXBrush1 = null;
		SharpDX.Direct2D1.Brush iUpDXBrush = null;
		SharpDX.Direct2D1.Brush iDownDXBrush = null;
		//SharpDX.Direct2D1.Brush iNeutralDXBrush = null;
		SharpDX.Direct2D1.Brush baseDXBrush = null;
		SharpDX.Direct2D1.Brush iTMDXBrush = null;
		//SharpDX.Direct2D1.Brush iProfileDXBrush = null;
		SharpDX.Direct2D1.Brush iVRUDXBrush = null;
		SharpDX.Direct2D1.Brush iVRDDXBrush = null;
		SharpDX.Direct2D1.Brush iLVNDXBrush = null;
		SharpDX.Direct2D1.Brush iVAHDXBrush = null;
		SharpDX.Direct2D1.Brush iPOCDXBrush = null;
		SharpDX.Direct2D1.Brush iVALDXBrush = null;
		SharpDX.Direct2D1.Brush iDFTextBackDXBrush = null;
		SharpDX.Direct2D1.Brush iVVTextBackDXBrush = null;
		SharpDX.Direct2D1.Brush iQualifiedZoneBackDXBrush = null;
		SharpDX.Direct2D1.Brush iDisqualifiedZoneBackDXBrush = null;
		SharpDX.Direct2D1.Brush DXBrushes_LightGray = null;
		SharpDX.Direct2D1.Brush DXBrushes_LightGreen = null;
        SharpDX.Direct2D1.Brush DXBrushes_Black = null;
		SharpDX.Direct2D1.Brush iTextDXBrush = null;
		SharpDX.Direct2D1.Brush tempBrush = null;
		SharpDX.Direct2D1.Brush tempPen_DXBrush = null;
		SharpDX.Direct2D1.Brush iFreshSupplyZoneDXBrush = null;
		SharpDX.Direct2D1.Brush iTestedSupplyZoneDXBrush = null;
		SharpDX.Direct2D1.Brush iBrokenSupplyZoneDXBrush = null;
		SharpDX.Direct2D1.Brush iFreshDemandZoneDXBrush = null;
		SharpDX.Direct2D1.Brush iTestedDemandZoneDXBrush = null;
		SharpDX.Direct2D1.Brush iBrokenDemandZoneDXBrush = null;
		//Brush tempColor = null;
		SharpDX.Direct2D1.Brush pLineDXBrush1 = null;
		SharpDX.Direct2D1.Brush volumeClusterDXBrush = null;
		//SharpDX.Direct2D1.Brush BkgContrastDXBrush = null;
		//Brush BkgContrastBrush = null;
		SharpDX.Direct2D1.Brush RectHighlightDXBrush = null;
		SharpDX.Direct2D1.Brush iFreshDemandZoneOutlineDXBrush = null;
		SharpDX.Direct2D1.Brush iTestedDemandZoneOutlineDXBrush = null;
		SharpDX.Direct2D1.Brush iBrokenDemandZoneOutlineDXBrush = null;
		SharpDX.Direct2D1.Brush iFreshSupplyZoneOutlineDXBrush = null;
		SharpDX.Direct2D1.Brush iTestedSupplyZoneOutlineDXBrush = null;
		SharpDX.Direct2D1.Brush iBrokenSupplyZoneOutlineDXBrush = null;

		#region TradePlan brushes
		SharpDX.Direct2D1.Brush fillbrush, EntryDXBrush, EntryContrastDXBrush;
		SharpDX.Direct2D1.Brush LongSLDXBrush, LongSLContrastDXBrush, LongT1DXBrush, LongT1ContrastDXBrush, LongT2DXBrush, LongT2ContrastDXBrush;
		SharpDX.Direct2D1.Brush ShortSLDXBrush, ShortSLContrastDXBrush, ShortT1DXBrush, ShortT1ContrastDXBrush, ShortT2DXBrush, ShortT2ContrastDXBrush;
		#endregion
        //set the color to Black or White depending on background color
        public Brush ContrastingColor(SolidColorBrush background)
        {
            // Counting the perceptive luminance - human eye favors green color... 
            double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
            if (a < 0.5) return Brushes.Black; // bright colors - black font
            else return Brushes.White; // dark colors - white font
        }

		#endregion

		#region private class HistData
		private class HistData
		{
		    private double bin;
		    private long total;
		    private long totalUpticks;
		    private long totalDownticks;
		    private int expansion;
		    private float percentage;

		    //CTors.
		    public HistData(double newBin, long newTotal, ARC_SDVSystem_TickDirection direction, long ticksIncrement) : this(newBin, newTotal) { UpdateTicks(direction, ticksIncrement); }
		    public HistData(double newBin, long newTotal)
		    {
		        bin = newBin;
		        total = newTotal;
		        expansion = 0;
		        percentage = 0.0f;
		        totalUpticks = 0;
		        totalDownticks = 0;    
		    }
		    public HistData(double newBin, long newTotal, long newUpticks, long newDownticks)
		    {
		        bin = newBin;
		        total = newTotal;
		        expansion = 0;
		        percentage = 0.0f;
		        totalUpticks = newUpticks;
		        totalDownticks = newDownticks;
		    }

		    public double GetBin() { return bin; }
		    public void UpdateTicks(ARC_SDVSystem_TickDirection direction, long ticksIncrement)
		    {
		        if (direction == ARC_SDVSystem_TickDirection.DOWN) totalDownticks += ticksIncrement;
		        else totalUpticks += ticksIncrement;
		    }
		    public void SetTicks(ARC_SDVSystem_TickDirection direction, long ticksIncrement)
		    {
		        if (direction == ARC_SDVSystem_TickDirection.DOWN) totalDownticks = ticksIncrement;
		        else totalUpticks = ticksIncrement;
		    }

		    public long GetTotal() { return total; }
		    public void SetTotal(long increment, ARC_SDVSystem_TickDirection direction, long ticksIncrement)
		    {
		        total = increment;
		        SetTicks(direction, ticksIncrement);
		    }
		    public void UpdateTotal(long increment, ARC_SDVSystem_TickDirection direction, long ticksIncrement)
		    {
		        total += increment;
		        UpdateTicks(direction, ticksIncrement);
		    }
		    public void UpdateTotal(long increment) { total += increment; }

		    public void UpdateTotalUpticks(long increment) { totalUpticks += increment; }
		    public long GetTotalUpticks() { return totalUpticks; }

		    public void UpdateTotalDownticks(long increment) { totalDownticks += increment; }
		    public long GetTotalDownticks(){return totalDownticks;}

		    public void SetExpansionState()
		    {
		        expansion++;
		        if (expansion > 2) expansion = 0;
		    }
		    public void SetExpansionState(int exp) { expansion = exp; }
		    public int GetExpansionState() { return expansion; }

		    public void SetPercentage(long cumulativeTotal)
		    {
		        if (total != 0.0 && cumulativeTotal != 0.0)
		            percentage = (float)((float)total / (float)cumulativeTotal);
		        else
		            percentage = 0.0f;
		    }
		    public float GetPercentage() { return percentage; }
		    public void ClearPercentage() { percentage = 0.0f; }
		}
		#endregion

		#region private class GHistogram
		private class GHistogram
		{
		    private long total;
		    private long largestBinTotal;
		    private long totalUpticks;
		    private long totalDownticks;
		    private double upPct;
		    private double downPct;
		    private long netTicks;
		    private List<HistData> histogram;        
		    private double BinSize;
		    private double PctOfVolumeInVA;
		    private int VACalcType;
		    private double volumeClusterTop;
		    private double volumeClusterBottom;

		    //Properties
		    public int RatioInfoState { get; set; }
		    public int HistInfoState { get; set; }
		    public double VAH { get; set; }
		    public double VAL { get; set; }
		    public double POC { get; set; }
		    
		    public long Total { get { return total; } }
		    public long TotalUpticks { get { return totalUpticks; } }
		    public long TotalDownticks { get { return totalDownticks; } }
		    public long NetTicks { get { return netTicks; } }
		    public double UpPercent { get { return upPct; } }
		    public double DownPercent { get { return downPct; } }
		    public double VolumeClusterTop { get { return volumeClusterTop; } }
		    public double VolumeClusterBottom { get { return volumeClusterBottom; } }
		    public long LargestBinTotal { get { return largestBinTotal; } }

		    public List<double> LVNs { get; set; }
		    private int zonetype;
		    private int nbLvns;

		    //CTor.
		    public GHistogram(double BinSize, int VACalcType, double PctOfVolumeInVA) : this(BinSize, VACalcType, PctOfVolumeInVA, -1, -1) { }
		    public GHistogram(double BinSize, int VACalcType, double PctOfVolumeInVA, int ZoneType, int NbLVNs)
		    {
		        histogram = new List<HistData>();
		        LVNs = new List<double>();
		        zonetype = ZoneType;
		        nbLvns = NbLVNs;
		        total = 0;
		        largestBinTotal = 0;
		        totalUpticks = 0;
		        totalDownticks = 0;
		        upPct = 0;
		        downPct = 0;
		        netTicks = 0;
		        RatioInfoState = 0;
		        HistInfoState = 0;
		        VAH = 0;
		        VAL = 0;
		        POC = 0;
		        this.PctOfVolumeInVA = PctOfVolumeInVA;
		        this.VACalcType = VACalcType;
		        this.BinSize = BinSize;
		        this.volumeClusterTop = double.MinValue;
		        this.volumeClusterBottom = double.MinValue;
		    }

		    public double GetBin(int index) { return histogram[index].GetBin(); }
		    public int GetTotalBins() { return histogram.Count; }
		    public void ClearAllData()
		    {
		        histogram.Clear();
		        total = 0;
		    }

		    public List<HistData> GetHistogram() { return histogram; }

		    public void SetData(double bin, long increment, ARC_SDVSystem_TickDirection direction, long ticksIncrement)
		    {
		        int binIndex = GetIndexForBin(bin);
		        if (binIndex == -1)
		            AddBin(bin, increment, direction, ticksIncrement);
		        else
		            histogram[binIndex].SetTotal(increment, direction, ticksIncrement);

		        total += increment;

		        Sort();

		        CalculatePercentages();
		    }
		    public void MergeData(GHistogram GH)
		    {
		        for (int pb = 0; pb < GH.histogram.Count; pb++)
		        {
		            bool newBin = true;
		            for (int b = 0; b < this.histogram.Count; b++)
		            {
		                if (this.histogram[b].GetBin() == GH.histogram[pb].GetBin())
		                {
		                    this.histogram[b].UpdateTotal(GH.histogram[pb].GetTotal());
		                    newBin = false;
		                    break;
		                }
		            }
		            if (newBin)
		                this.AddBin(GH.histogram[pb].GetBin(), GH.histogram[pb].GetTotal(), ARC_SDVSystem_TickDirection.UP, GH.histogram[pb].GetTotal());
		        }

		        Sort();

		        CalculatePercentages();
		    }
		    public void PruneData(GHistogram GH)
		    {
		        for (int b = 0; b < this.histogram.Count; b++)
		        {
		            for (int pb = 0; pb < GH.histogram.Count; pb++)
		            {
		                if (this.histogram[b].GetBin() == GH.histogram[pb].GetBin())
		                {
		                    this.histogram[b].UpdateTotal(-GH.histogram[pb].GetTotal());
		                    break;
		                }
		            }
		        }
		    }
		    public void UpdateData(double bin, long increment, ARC_SDVSystem_TickDirection direction, long ticksIncrement)
		    {
		        int binIndex = GetIndexForBin(bin);
		        if (binIndex == -1)
		            AddBin(bin, increment, direction, ticksIncrement);
		        else
		            histogram[binIndex].UpdateTotal(increment, direction, ticksIncrement);

		        total += increment;

		        Sort();

		        CalculatePercentages();
		    }

		    public void AddDataFromHistogram(List<HistData> iHistogram, double iUpperLimit, double iLowerLimit)
		    {
		        for (int b = 0; b < iHistogram.Count; b++)
		        {
		            double bin = iHistogram[b].GetBin();
		            if (iLowerLimit <= bin &&
		                bin <= iUpperLimit)
		            {
		                int binIndex = this.GetIndexForBin(bin);
		                if (binIndex == -1)
		                {
		                    this.histogram.Add(
		                        new HistData(
		                            iHistogram[b].GetBin(),
		                            iHistogram[b].GetTotal(),
		                            iHistogram[b].GetTotalUpticks(),
		                            iHistogram[b].GetTotalDownticks()));
		                }
		                else
		                {
		                    histogram[binIndex].UpdateTotal(iHistogram[b].GetTotal());
		                    histogram[binIndex].UpdateTotalUpticks(iHistogram[b].GetTotalUpticks());
		                    histogram[binIndex].UpdateTotalDownticks(iHistogram[b].GetTotalDownticks());
		                }
		            }
		        }

		        Sort();
		        CalculateTotals();
		        CalculateLVNs();
		        CalculatePercentages();
		        CalculateProfile();
		    }

		    private class ClusterStats
		    {
		        public double Top;
		        public double Bottom;
		        public long Total;

		        public ClusterStats(double Top, double Bottom, long Total)
		        {
		            this.Top = Top;
		            this.Bottom = Bottom;
		            this.Total = Total;
		        }
		    }

		    private void CalculateLVNs()
		    {
		        LVNs.Clear();
		        if (histogram.Count < 3) return;

		        for (int b = 0; b < histogram.Count; b++)
		        {
		            if (true || histogram[b].GetBin() < volumeClusterBottom || histogram[b].GetBin() > volumeClusterTop)//v1.005 : if true let LVNs to be inside cluster
		            {
		                if (b == 0) { if (histogram[0].GetTotal() <= histogram[1].GetTotal()) LVNs.Add(histogram[0].GetBin()); }
		                else if (b == histogram.Count - 1) { if (histogram[b].GetTotal() <= histogram[b - 1].GetTotal()) LVNs.Add(histogram[b].GetBin()); }
		                else
		                {
		                    if (histogram[b - 1].GetTotal() > histogram[b].GetTotal() && histogram[b].GetTotal() < histogram[b + 1].GetTotal()) LVNs.Add(histogram[b].GetBin());//cas parfait
		                    else if (histogram[b - 1].GetTotal() > histogram[b].GetTotal() && histogram[b].GetTotal() == histogram[b + 1].GetTotal()) LVNs.Add(histogram[b].GetBin());//double top
		                    else if (histogram[b - 1].GetTotal() == histogram[b].GetTotal() && histogram[b].GetTotal() < histogram[b + 1].GetTotal()) LVNs.Add(histogram[b].GetBin());//double bottom
		                    //else if (histogram[b - 1].GetTotal() == histogram[b].GetTotal() && histogram[b].GetTotal() == histogram[b + 1].GetTotal()) LVNs.Add(histogram[b].GetBin());//triple dip
		                }
		            }
		        }
		        if (this.nbLvns < LVNs.Count)
		        {
		            if (this.zonetype == 1) LVNs.RemoveRange(nbLvns, LVNs.Count - nbLvns);
		            else if (this.zonetype == 0) LVNs.RemoveRange(0, LVNs.Count - nbLvns);
		            else LVNs.Clear();
		        }
				LVNs.Sort();
				if(LVNs.Count>1){
					if(LVNs[0]>=LVNs.Max()) LVNs.Reverse();//smallest LVN price will be the first in the list, and ascend from there to the back of the list
				}
		    }

		    public void CalculateTotals()
		    {
		        total = 0;
		        totalUpticks = 0;
		        totalDownticks = 0;
		        largestBinTotal = 0;

		        List<ClusterStats> tempClusters = new List<ClusterStats>();

		        for (int b = 0; b < histogram.Count; b++)
		        {
		            total += histogram[b].GetTotal();
		            totalUpticks += histogram[b].GetTotalUpticks();
		            totalDownticks += histogram[b].GetTotalDownticks();
		            largestBinTotal = Math.Max(largestBinTotal, histogram[b].GetTotal());

		            if (b >= 2) // clusters of 3
		            {
		                long vcTotal = 0;
		                for (int a = b - 2; a <= b; a++)
		                {
		                    vcTotal += histogram[a].GetTotal();
		                }

		                tempClusters.Add(new ClusterStats(histogram[b].GetBin(), histogram[b - 2].GetBin(), vcTotal));
		            }
		        }

		        if (tempClusters.Count > 0)
		        {
		            int maxClusterIdx = 0;
		            for (int c = 1; c < tempClusters.Count; c++)
		            {
		                if (tempClusters[maxClusterIdx].Total < tempClusters[c].Total)
		                    maxClusterIdx = c;
		            }

		            volumeClusterTop = tempClusters[maxClusterIdx].Top;
		            volumeClusterBottom = tempClusters[maxClusterIdx].Bottom;
		        }

		        upPct = (double)((double)totalUpticks / (double)total);
		        downPct = 1.0 - upPct;
		        netTicks = totalUpticks - totalDownticks;
		    }
		    public void CalculateProfile()
		    {
		        int numBins = histogram.Count;
		        long total = 0;
		        long maxBinTotal = 0;
		        double histLowPrice = double.MaxValue;
		        double histHighPrice = double.MinValue;
		        double THxP = 0.0; // Total of Hits multiplied by Price at that volume
		        double POCPrice = 0.0;
		        int POCIndex = 0;
		        int minBinIndex = -1;
		        int maxBinIndex = -1;
		        double sessVAtop = 0.0;
		        double sessVAbot = 0.0;

		        long[] binTotals = new long[numBins + 2];
		        double[] binPrices = new double[numBins + 2];

		        for (int bin = 0; bin < this.histogram.Count; bin++)
		        {
		            double p = this.histogram[bin].GetBin();
		            binTotals[bin] = 0;
		            binPrices[bin] = p;

		            if (histogram[bin].GetTotal() != 0.0)
		            {
		                histLowPrice = Math.Min(histLowPrice, p);
		                histHighPrice = Math.Max(histHighPrice, p);

		                if (minBinIndex == -1)
		                    minBinIndex = bin;
		                else
		                    maxBinIndex = bin;
		            }
		            binTotals[bin] = histogram[bin].GetTotal();

		            if (maxBinTotal < binTotals[bin])
		            {
		                maxBinTotal = binTotals[bin];
		                POCPrice = p;
		                POCIndex = bin;
		            }
		            total += binTotals[bin];
		            THxP += ((double)binTotals[bin] * p);
		        }

		        double midPointPrice = (histHighPrice + histLowPrice) / 2.0;
		        double midUpCnt = 0.0; //counts above midpoint
		        double midDnCnt = 0.0; // counts below midpoint
		        int POCcount = 0;
		        double mid1 = midPointPrice;
		        double mid2 = midPointPrice;	//Distance from midPoint, set larger than possible
		        int mid1Dx = 0, mid2Dx = 0;	//array index count of finds.

		        float multiplier = ((float)total / (float)maxBinTotal);
		        for (int bin = 0; bin < this.histogram.Count; bin++)
		        {
		            double p = this.histogram[bin].GetBin();
		            if (bin >= minBinIndex && bin <= maxBinIndex)
		            {
		                // sum up hits for possable later use (don't count equals)
		                if (p > midPointPrice)
		                    midUpCnt += binTotals[bin];
		                if (p < midPointPrice)
		                    midDnCnt += binTotals[bin];

		                if (binTotals[bin] == maxBinTotal)
		                {
		                    POCcount++;
		                    //find 2 closest to midpoint
		                    if (Math.Abs(midPointPrice - p) <= mid1)
		                    {
		                        mid2 = mid1;//rotate next closest
		                        mid2Dx = mid1Dx;
		                        mid1 = Math.Abs(midPointPrice - p);	//how far away from midpoint
		                        mid1Dx = bin;
		                    }
		                }
		            }
		        }

		        //DETERMINE POC -> Rules to use are:
		        // 1. If there is more than 1 price with the same 'most' TPO's then the price closest to the mid-point of the range (high - low) is used. 
		        // 2. If the 2 'most' TPO prices are equi-distance from the mid-point then the price on the side of the mid-point with the most TPO's is used. 
		        // 3. If there are equal number of TPO's on each side then the lower price is used. 
		        //
		        if (POCcount > 1)
		        {
		            if (mid1 != mid2)
		            {
		                //found it, rule #1
		                POCPrice = binPrices[mid1Dx];
		                POCIndex = mid1Dx;
		            }
		            else
		            {
		                //they are equal, Rule #2 may apply
		                if (midUpCnt == midDnCnt)
		                {	//must use Rule #3
		                    POCPrice = binPrices[mid2Dx];	//use the lower.
		                    POCIndex = mid2Dx;
		                }
		                else
		                {	//Rule #2
		                    if (midUpCnt > midDnCnt)
		                    {
		                        POCPrice = binPrices[mid1Dx];	//mid1 = upper of 2
		                        POCIndex = mid1Dx;
		                    }
		                    else
		                    {
		                        POCPrice = binPrices[mid2Dx];	//must be the lower.
		                        POCIndex = mid2Dx;
		                    }
		                }//end Rule #2
		            }
		        }


		        if (VACalcType == 1)
		        {
		            //start mid-range and expand
		            //AvgPrice = THxP/HitsTotal;
		            sessVAtop = THxP / total;
		            sessVAbot = sessVAtop;

		            //This loop calculates the percentage of hits contained within the Value Area
		            double ViA = 0.0;
		            double TV = 0.00001;
		            double Adj = 0.0;
		            while (ViA / TV < this.PctOfVolumeInVA / 100.0)
		            {
		                sessVAbot = sessVAbot - Adj;
		                sessVAtop = sessVAtop + Adj;
		                ViA = 0.0;
		                TV = 0.00001;
		                for (int i = minBinIndex; i <= maxBinIndex; i++)
		                {
		                    if (binPrices[i] > sessVAbot - Adj && binPrices[i] < sessVAtop + Adj)
		                        ViA += binTotals[i];
		                    TV += binTotals[i];
		                }
		                Adj = BinSize;
		            }
		        }
		        else
		        {
		            //start at POC Slot and expand by slots.
		            //start at POC and add largest of each side till done.
		            double ViA = binTotals[POCIndex];
		            int upSlot = POCIndex + 1, dnSlot = POCIndex - 1;
		            double upCnt, dnCnt;

		            while ((ViA / (double)total) < (this.PctOfVolumeInVA / 100.0))
		            {
		                if (upSlot <= maxBinIndex)
		                    upCnt = binTotals[upSlot];
		                else
		                    upCnt = 0;

		                if (dnSlot >= 0)
		                    dnCnt = binTotals[dnSlot];
		                else
		                    dnCnt = 0;

		                if (upCnt == dnCnt)
		                {
		                    //if both equal, add this one.
		                    if (POCIndex - dnSlot < upSlot - POCIndex)
		                        upCnt = 0;	//use closest
		                    else
		                        dnCnt = 0;	//use upper if the same.
		                }
		                if (upCnt >= dnCnt)
		                {	//if still equal (i.e. zero), do it.
		                    ViA += upCnt;
		                    if (upSlot <= maxBinIndex)
		                        upSlot++;
		                }
		                if (upCnt <= dnCnt)
		                {	//need equals to increment counts.
		                    ViA += dnCnt;
		                    if (dnSlot >= 0)
		                        dnSlot--;
		                }
		                if (upSlot > maxBinIndex && dnSlot < 0)
		                {
		                    //error.
		                    upSlot = maxBinIndex;
		                    dnSlot = 0;
		                    break;
		                }
		            }
		            //index's have gone one too far...
		            if (upSlot != 0)
		                sessVAtop = binPrices[--upSlot];
		            if (dnSlot != maxBinIndex)
		                sessVAbot = binPrices[++dnSlot];
		        }


		        VAH = sessVAtop;
		        VAL = sessVAbot;
		        POC = POCPrice;

		    }
		    private void AddBin(double bin, long increment, ARC_SDVSystem_TickDirection direction, long ticksIncrement) { histogram.Add(new HistData(bin, increment, direction, ticksIncrement)); }
		    public int GetIndexForBin(double bin)
		    {
		        for (int i = 0; i < histogram.Count; i++)
		            if (histogram[i].GetBin() == bin)
		                return i;
		        return -1;
		    }
		    public void CalculatePercentages() { for (int i = 0; i < histogram.Count; i++)histogram[i].SetPercentage(total); }
		    public void ClearAllExpansions() { for (int i = 0; i < histogram.Count; i++)histogram[i].SetExpansionState(0); }
		    public void SetExpansion(double bin) 
		    {
		        int binIndex = GetIndexForBin(bin);
		        if (binIndex != -1) histogram[binIndex].SetExpansionState();
		    }
		    public void SetExpansion(double bin, int exp)
		    {
		        int binIndex = GetIndexForBin(bin);
		        if (binIndex != -1) histogram[binIndex].SetExpansionState(exp);
		    }
		    public int GetExpansion(double bin) 
		    {
		        int binIndex = GetIndexForBin(bin);
		        return binIndex == -1 ? 0 : histogram[binIndex].GetExpansionState();
		    }
		    private void Sort() { histogram.Sort(delegate(HistData b1, HistData b2) { return b1.GetBin().CompareTo(b2.GetBin()); }); }

		    public float GetPercentage(double bin) 
		    {
		        int binIndex = GetIndexForBin(bin);
		        return binIndex == -1 ? 0.0f : histogram[binIndex].GetPercentage();
		    }
		    public long GetTotal(double bin)
		    {
		        int binIndex = GetIndexForBin(bin);
		        return binIndex == -1 ? 0 : histogram[binIndex].GetTotal();
		    }
		    public long GetTotalUpticks(double bin)
		    {
		        int binIndex = GetIndexForBin(bin);
		        return binIndex == -1 ? 0 : histogram[binIndex].GetTotalUpticks();
		    }
		    public long GetTotalDownticks(double bin)
		    {
		        int binIndex = GetIndexForBin(bin);
		        return binIndex == -1 ? 0 : histogram[binIndex].GetTotalDownticks();
		    }
		    
		    public float CalculateUptickPercent()
		    {
		        long cumulativeTotalUpticks = 0;
		        long cumulativeTotalDownticks = 0;

		        for (int i = 0; i < histogram.Count; i++)
		        {
		            cumulativeTotalUpticks += histogram[i].GetTotalUpticks();
		            cumulativeTotalDownticks += histogram[i].GetTotalDownticks();
		        }

		        return (float)((float)cumulativeTotalUpticks / (float)(cumulativeTotalUpticks + cumulativeTotalDownticks));
		    }
		    public float CalculateUptickPercent(double binMin, double binMax)
		    {
		        double minBinValue = histogram[0].GetBin();
		        double maxBinValue = histogram[histogram.Count - 1].GetBin();

		        int binIndexMin = Math.Max(0, GetIndexForBin(binMin));
		        int binIndexMax = GetIndexForBin(binMax);
		        if (binIndexMax == -1) binIndexMax = histogram.Count - 1;

		        long cumulativeTotalUpticks = 0;
		        long cumulativeTotalDownticks = 0;

		        for (int i = binIndexMin; i <= binIndexMax; i++)
		        {
		            cumulativeTotalUpticks += histogram[i].GetTotalUpticks();
		            cumulativeTotalDownticks += histogram[i].GetTotalDownticks();
		        }

		        return (float)((float)cumulativeTotalUpticks / (float)(cumulativeTotalUpticks + cumulativeTotalDownticks));
		    }
		    public void CalculatePercentages(double binMin, double binMax)
		    {
		        double minBinValue = histogram[0].GetBin();
		        double maxBinValue = histogram[histogram.Count - 1].GetBin();

		        int binIndexMin = Math.Max(0, GetIndexForBin(binMin));
		        int binIndexMax = GetIndexForBin(binMax);
		        if (binIndexMax == -1)
		        {
		            binIndexMax = histogram.Count - 1;
		        }

		        long cumulativeTotal = 0;

		        for (int i = binIndexMin; i <= binIndexMax; i++) cumulativeTotal += histogram[i].GetTotal();
		        for (int i = 0; i < histogram.Count; i++) histogram[i].ClearPercentage();
		        for (int i = binIndexMin; i <= binIndexMax; i++)
		        {
		            // Sanity check for percentage
		            if (histogram[i].GetBin() <= binMax && histogram[i].GetBin() >= binMin) histogram[i].SetPercentage(cumulativeTotal);
		        }
		    }
		}
		#endregion

		#region private class GZone
		private class GZone
		{
			public int		IDnum		{get;set;}
			public string	ID			{ get; set; }
			public DateTime StartTime	{ get; set; }
			public DateTime EndTime		{ get; set; }
			public int		StartBar	{ get; set; }
			public int		EndBar		{ get; set; }
			public int		ThrustBar	{ get; set; }
			public double	Top			{ get; set; }
			public double	Bottom		{ get; set; }
			public int		Type		{ get; set; }
			public int		State		{ get; set; }
			public Rect		Rect		{ get; set; }
			public Rect[]	MouseRects		{ get; set; }
			public string[]	MouseBtnText	{ get; set; }
			public bool[]	MouseBtnStates	{ get; set; }
			public int[]	MouseBtnIStates	{ get; set; }
			public int		NumRetests		{ get; set; }
			public bool		Alerting		{ get; set; }
			public bool		Locked			{ get; set; }
			public bool		PLocked			{ get; set; }
			public int		IDiterator		{ get; set; }
			public bool		Visible			{ get; set; }
			public bool		HoldOff			{ get; set; }
			public int		FormedBar		{ get; set; }
			public double	CurrentAvgVAVol	{ get; set; }
			public double	NumOfBasingCandles	{get;set;}
			public GHistogram	Hist		{ get; set; }
			public double		TestMarker	{ get; set; }
			public long	TotVolVA           = long.MinValue;
			public bool	IsLowVolumeVA      = false;
			public bool	IsSufficientThrust = false;
			public bool	IsSufficientBase   = false;

		//		public GZone(string ID, int Type, DateTime StartTime, DateTime EndTime, int StartBar, int EndBar, double Top, double Bottom,
		//		             int State, Rect Rect, Rect[] MouseRects, int NumRetests, bool Alerting, bool Locked, bool PLocked, double currentAvgVAVol, int lowVolPctQualifier, GHistogram Hist)
		//		{
		//			this.ID = ID;
		//			this.StartTime = StartTime;
		//			this.EndTime = EndTime;
		//			this.StartBar = StartBar;
		//			this.EndBar = EndBar;
		//			this.Top = Top;
		//			this.Bottom = Bottom;
		//			this.Type = Type;
		//			this.TestMarker = this.Type == 1 ? this.Bottom : this.TestMarker = this.Top;
		//			this.State = State;
		//			this.NumRetests = NumRetests;
		//			this.Alerting = Alerting;
		//			this.Rect = Rect;
		//			this.MouseRects = new Rect[19];
		//			MouseRects.CopyTo(this.MouseRects, 0);
		//			this.MouseBtnText = new string[19];
		//			this.SetMouseBtnText();
		//			this.MouseBtnStates = new bool[19];
		//			this.MouseBtnIStates = new int[19];
		//			for (int m = 0; m < 19; m++)
		//			{
		//				this.MouseBtnStates[m] = false;
		//				this.MouseBtnIStates[m] = 0;
		//			}
		//			this.Locked = Locked;
		//			this.PLocked = PLocked;
		//			this.IDiterator = 0;
		//			this.Visible = false;
		//			this.HoldOff = false;
		//			this.FormedBar = 0;
		//			this.CurrentAvgVAVol = currentAvgVAVol;
		//			this.Hist = Hist;
		//			this.TotVolVA = 0;
		//			for (double p = Hist.VAL; p <= Hist.VAH; p = Instruments[0].MasterInstrument.RoundToTickSize(p + gbTickSize)) TotVolVA += Hist.GetTotal(p);
		//			IsLowVolumeVA = TotVolVA < currentAvgVAVol * lowVolPctQualifier/100.0;
		//        }
		    
		    public GZone(int id_num, int Type, DateTime StartTime, DateTime EndTime, int StartBar, int ThrustABar, double Top, double Bottom, int FormedBar, bool ManualZone, double currentAvgVAVol, int lowVolPctQualifier, int numOfBasingCandles, int pMaxBasingCount, bool IsQualifyingThrust, GHistogram Hist)
		    {
				this.IDnum = id_num;
		        this.ID = "GZ_" + Type.ToString() + "_" + StartTime.ToString();
		        this.StartTime = StartTime;
		        this.EndTime = EndTime;
		        this.StartBar = StartBar;
		        this.EndBar = 0;
				this.ThrustBar = ThrustABar;
		        this.Top = Top;
		        this.Bottom = Bottom;
		        this.Type = Type;
		        this.TestMarker = this.Type == 1 ? this.Bottom : this.Top;
		        this.State = 0;
		        this.NumRetests = 0;
		        this.Alerting = false;
		        this.Rect = Rect.Empty;
		        this.MouseRects = new Rect[19];
		        this.MouseBtnText = new string[19];
		        this.SetMouseBtnText();
		        this.MouseBtnStates = new bool[19];
		        this.MouseBtnIStates = new int[19];
		        for (int m = 0; m < 19; m++)
		        {
		            this.MouseBtnStates[m] = false;
		            this.MouseRects[m] = Rect.Empty;
		            this.MouseBtnIStates[m] = 0;
		        }
		        this.Locked  = true;
		        this.PLocked = true;
		        this.IDiterator = 0;
		        this.Visible    = false;
		        this.HoldOff    = true;
		        this.FormedBar  = FormedBar;
				this.CurrentAvgVAVol    = currentAvgVAVol;
				this.NumOfBasingCandles = numOfBasingCandles;
				this.IsSufficientBase   = numOfBasingCandles <= pMaxBasingCount;
				this.IsSufficientThrust = IsQualifyingThrust;
		        this.Hist = Hist;
				this.TotVolVA = 0;
				foreach(var hp in Hist.GetHistogram()) if(hp.GetBin() <= Hist.VAH && hp.GetBin() >= Hist.VAL) TotVolVA += hp.GetTotal();
	//			for (double p = Hist.VAL; p <= Hist.VAH; p = p + gbTickSize) TotVolVA += Hist.GetTotal(p);
				IsLowVolumeVA = TotVolVA < currentAvgVAVol * lowVolPctQualifier/100.0;
		    }

		    public void SetProfileToggles(bool PR, bool PC, bool VL, bool VH, int VPi, bool VC, bool PT, bool DF, bool VV)
		    {
				this.MouseBtnStates[CONTROLPPR]  = PR;
		        this.MouseBtnStates[CONTROLPPC]  = PC;
		        this.MouseBtnStates[CONTROLPVL]  = VL;
		        this.MouseBtnStates[CONTROLPVH]  = VH;
		        this.MouseBtnIStates[CONTROLPVP] = VPi;
		        this.MouseBtnStates[CONTROLPVP]  = VPi != 0;
		        this.MouseBtnStates[CONTROLPVC]  = VC;
		        this.MouseBtnStates[CONTROLPPT]  = PT;
		        this.MouseBtnStates[CONTROLPDF]  = DF;
		        this.MouseBtnStates[CONTROLPVV]  = VV;
		    }
		    public override string ToString()
		    {
		        return
		            this.ID + ";" +
		            this.StartTime.ToString() + ";" +
		            this.EndTime.ToString() + ";" +
		            this.StartBar.ToString() + ";" +
		            this.EndBar.ToString() + ";" +
		            this.Top.ToString() + ";" +
		            this.Bottom.ToString() + ";" +
		            this.Type.ToString() + ";" +
		            this.NumRetests.ToString() + ";" +
		            this.State.ToString() + ";";
		    }

		//        public GZone GetCopy()
		//        {
		//            this.IDiterator++;
		//            return new GZone(
		//                this.ID + "_c" + this.IDiterator.ToString(),
		//                this.Type,
		//                this.StartTime,
		//                this.EndTime,
		//                this.StartBar,
		//                this.EndBar,
		//                this.Top,
		//                this.Bottom,
		//                0, //this.State,
		//                this.Rect,
		//                this.MouseRects,
		//                0,//this.NumRetests,
		//                this.Alerting,
		//                this.Locked,
		//                this.PLocked,
		//				this.CurrentAvgVAVol,
		//				this.TotVolVA,
		//				this.IsLowVolumeVA,
		//				this.IsSufficientThrust,
		//				this.IsSufficientBase,
		//                this.Hist);
		//        }

		    private void SetMouseBtnText()
		    {
		        this.MouseBtnText[0] = "";
		        this.MouseBtnText[1] = "";
		        this.MouseBtnText[2] = "";
		        this.MouseBtnText[3] = "";
		        this.MouseBtnText[CONTROLZ] = "Z";
		        this.MouseBtnText[CONTROLX] = "X";
		        this.MouseBtnText[6] = "mm";
		        this.MouseBtnText[7] = "";
		        this.MouseBtnText[CONTROLPL] = "V";
		        this.MouseBtnText[CONTROLPPR] = "PR";
		        this.MouseBtnText[CONTROLPPC] = "PC";
		        this.MouseBtnText[CONTROLPVL] = "VL";
		        this.MouseBtnText[CONTROLPVH] = "VH";
		        this.MouseBtnText[CONTROLPVP] = "V+";
		        this.MouseBtnText[CONTROLPVC] = "VC";
		        this.MouseBtnText[CONTROLPPT] = "V%";
		        this.MouseBtnText[CONTROLPDF] = "DF";
		        this.MouseBtnText[CONTROLPVV] = "VV";
		        this.MouseBtnText[CENTER] = "C";
		    }
		}
		#endregion

		#region private class ARC_SDVSystemItem
		private class ARC_SDVSystemItem
		{
		    public List<GZone> ZoneList { get; set; }
		    public string ID { get; set; }
		    public DateTime LastUpdateTime { get; set; }

		    public ARC_SDVSystemItem(string ID)
		    {
		        this.ZoneList = new List<GZone>();
		        this.ID = ID;
		    }

		    public void UpdateTime(DateTime Time) { if (this.LastUpdateTime.CompareTo(Time) < 0) this.LastUpdateTime = Time; }

		    public void ClearZones()
		    {
		        this.LastUpdateTime = DateTime.MinValue;
		        this.ZoneList.Clear();
		    }
		}
		#endregion

		#region private class ARC_SDVSystemManager
		private class ARC_SDVSystemManager
		{
		    private List<ARC_SDVSystemItem> ManagerList;

		    public ARC_SDVSystemManager() { this.ManagerList = new List<ARC_SDVSystemItem>(); }

		    public ARC_SDVSystemItem GetZoneItem(string ID)
		    {
		        ARC_SDVSystemItem nsitem = this.ManagerList.Find(x => x.ID == ID);

		        if (nsitem != null) return nsitem;
		        else
		        {
		            nsitem = new ARC_SDVSystemItem(ID);
		            this.ManagerList.Add(nsitem);
		            return nsitem;
		        }
		    }
		}
		#endregion
		
		#region -- Volume Averages --
		private EMA ema_ma1, ema_ma2;
		private SMA sma_ma1, sma_ma2;
//		private SharpDX.Direct2D1.Brush iVA1DXBrush=null;
//		private SharpDX.Direct2D1.Brush iVA2DXBrush=null;
		private SharpDX.Direct2D1.Brush iVA1_lineDXBrush=null;
		private SharpDX.Direct2D1.Brush iVA2_lineDXBrush=null;
//		private SharpDX.Direct2D1.Brush iVAS1DXBrush, iVAS2DXBrush, 
		private SharpDX.Direct2D1.Brush iVA1_fillDXBrush=null;
		private SharpDX.Direct2D1.Brush iVA2_fillDXBrush=null;
		private int iVA3Width = 2;
		private int iVAS3Width = 2;
		private DashStyleHelper iVA3DashStyle=DashStyleHelper.Solid;
		private DashStyleHelper iVAS3DashStyle=DashStyleHelper.Solid;
		#endregion

		#region -- Global_RectsData ---------------------------------------------------
		private class Global_RectsData{
			public int      StartABar;
			//public int      EndABar;
			public DateTime DTStart;
			public double   TopPrice;
			public DateTime DTEnd;
			public double   BottomPrice;
			public string   TemplateName;
			public char     SupportOrResistance;
			public bool     IsDrawn = false;
			public Global_RectsData(int startabar, DateTime dtStart, double topprice, DateTime dtEnd, double bottomprice, string templatename, char support_or_resistance){
				StartABar = startabar; DTStart=dtStart; DTEnd=dtEnd; TopPrice=topprice; BottomPrice=bottomprice; TemplateName=templatename.Replace(" Rectangle Template",string.Empty); IsDrawn=false; this.SupportOrResistance=support_or_resistance;
			}
			public string ToString(){
				return string.Format("{0} {1}  {2}  {3}  {4} {5}", StartABar, DTStart, TopPrice, BottomPrice, SupportOrResistance, DTEnd.ToString());
			}
		}
		#endregion
		private SortedDictionary<string,Global_RectsData>  Global_Zone_Rects = new SortedDictionary<string,Global_RectsData>();
		private bool RecalcGlobalsCount = false;
		private bool IsRealTime = false;
		private string ObjectPrefix = string.Empty;
		
        //---------------------------- Virtuals -----------------------------------------------
        public override string DisplayName { get { return "ARC_SDVSystem"; } }

        private double gbTickSize = 0;
//==========================================================================================================================================
        protected override void OnStateChange()
        {
	        #region -- OnStateChange()  --
            #region State == State.SetDefaults 
            if (State == State.SetDefaults)
            {
                #region -- chart config --
                Description							= @"Enter the description for your new custom Indicator here.";
				Name								= "ARC_SDVSystem";
				Calculate							= Calculate.OnEachTick;
                IsOverlay                           = true;
                DisplayInDataBox                    = false;
				DrawOnPricePanel					= true;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
                PaintPriceMarkers                   = false;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive			= false;                
                MaximumBarsLookBack                 = MaximumBarsLookBack.Infinite;
                ArePlotsConfigurable                = false;
                IsAutoScale                         = true;
                BarsRequiredToPlot                  = 0;
                #endregion

				#region Plots
					#region Volume Averages
					AddPlot(Brushes.Black, "MA1 High");
					AddPlot(Brushes.Black, "MA1 Low");
					AddPlot(Brushes.Black, "MA2 High");
					AddPlot(Brushes.Black, "MA2 Low");
					#endregion
				#endregion

				pButtonText = "SDVSystem";
                #region -- TimeFrame Parameters --
                iChartMode1 = ARC_SDVSystem_ZoneMode2.DEFAULT_CHART;
                iChartType1 = ARC_SDVSystem_MTFBarType.Minute;
                iChartValue1 = 5;
                iProfileCalcTimeFrame = ARC_SDVSystem_ProfileDataType.SECOND;
                #endregion

				#region -- TradingPlan defaults --
//				EntryZoneSize_inATRs = 0.5;
				EntryBasis = ARC_SDVSystem_TradeEntryBasis.AtZoneEdge;
				SL_CalcBasis = ARC_SDVSystem_SL_CalcBasis.ZoneEdge;
				TP_CalcBasis = ARC_SDVSystem_TP_CalcBasis.ATR;
				EntryOffsetTicks = 1;
				SLOffsetTicks  = 0;
				ATRperiod      = 13;
				SLsize_inATRs  = 1.25;
				SLsize_inTicks = 10;
				T1size_inATRs  = 1.0;
				T2size_inATRs  = 1.5;
				T1size_inRRs   = 1.75;
				T2size_inRRs   = 3.5;
				T1size_inTicks = 12;
				T2size_inTicks = 18;
				EntryBrush     = Brushes.White;
				ShortSLBrush   = Brushes.Green;
				ShortT1Brush   = Brushes.LightGreen;
				ShortT2Brush   = Brushes.DarkGreen;
				LongSLBrush    = Brushes.Red;
				LongT1Brush    = Brushes.Orange;
				LongT2Brush    = Brushes.DarkOrange;
				EntryDashStyle = DashStyleHelper.Dash;
				SLDashStyle  = DashStyleHelper.Solid;
				T1DashStyle  = DashStyleHelper.Solid;
				T2DashStyle  = DashStyleHelper.Solid;
				EntryLineWidth = 2;
				SLLineWidth  = 2;
				T1LineWidth  = 2;
				T2LineWidth  = 2;
				ShowLongTradePlans  = true;
				ShowShortTradePlans = true;
				ShowNearTradePlan   = true;
				ShowFarTradePlan    = true;
				TradePlanOnFreshZones = true;
				TradePlanOnTestedZones = false;
				TradePlanOnQualifiedZones = false;
//				ShowEntryZones      = true;
				ShowT2 = true;
				ShowT1 = true;
				ShowSL = true;
				TradePlan_LineLength = 5;
//				FarTradePlan_LineLength  = 5;
				BuyFarTradePlan_Location   = ARC_SDVSystem_TradePlanLocation.Left;
				BuyNearTradePlan_Location  = ARC_SDVSystem_TradePlanLocation.Right;
				SellNearTradePlan_Location = ARC_SDVSystem_TradePlanLocation.Right;
				SellFarTradePlan_Location  = ARC_SDVSystem_TradePlanLocation.Left;
//				BuyEntryZoneColor          = Brushes.Green;
//				BuyEntryZoneColorOpacity   = 50;
//				SellEntryZoneColor         = Brushes.Red;
//				SellEntryZoneColorOpacity  = 50;
				FontEL = new SimpleFont("Arial", 12);
				FontSL = new SimpleFont("Arial", 12);
				FontT1 = new SimpleFont("Arial", 12);
				FontT2 = new SimpleFont("Arial", 12);
				ShortEntryLabel = "E";
				LongEntryLabel  = "E";
				ShortSLLabel    = "SL";
				LongSLLabel     = "SL";
				ShortT1Label   = "T1";
				LongT1Label    = "T1";
				ShortT2Label   = "T2";
				LongT2Label    = "T2";
//				IncludeTerminatedLevels  = false;
//				TerminatedLevelColor     = Brushes.Yellow;
//				TerminatedLevelLineWidth = 1;
//				TerminatedLevelDashStyle = DashStyleHelper.Solid;
				VisualShiftDistance = 2;
//				DominantTradePlan = ARC_SDVSystem_DominantTradePlan.None;
				#endregion

                #region -- 01. Parameters --
                applyRangeFilter = false;
                barFilter = 750;
                iTickBuffer = 3;
				Bars_To_Process = -1;
                #endregion

                #region -- 05. Visual Toggles --
                iShowSDVZones = true;
                iShowSupplyZones = true;
                iShowDemandZones = true;
                iShowFreshZones = true;
                iShowTestedZones = true;
                iShowTestedShading = false;//v1.003 - Sean asked to change to false
                iShowTestedMarker = true;
                iShowBrokenZones = false;
				iFilterQualifiedZones = false;
                iShowPriceLabels = false;
                showZigZag = false;
				pGlobalObjects_Enabled = false;
                #endregion

                #region -- 06. Visual Style SDVSystem --
                iFreshDemandZoneColor = Brushes.Green;
                iFreshDemandZoneOpacity = 50;
                iFreshDemandZoneOutlineColor = Brushes.Black;
                iFreshDemandZoneOutlineStyle = DashStyleHelper.Solid;

                iTestedDemandZoneColor = Brushes.LightGreen;
                iTestedDemandZoneOpacity = 50;
                iTestedDemandZoneOutlineColor = Brushes.Black;
                iTestedDemandZoneOutlineStyle = DashStyleHelper.Solid;

                iBrokenDemandZoneColor = Brushes.Cyan;
                iBrokenDemandZoneOpacity = 15;
                iBrokenDemandZoneOutlineColor = Brushes.Black;
                iBrokenDemandZoneOutlineStyle = DashStyleHelper.Solid;

                iFreshSupplyZoneColor = Brushes.Red;
                iFreshSupplyZoneOpacity = 50;
                iFreshSupplyZoneOutlineColor = Brushes.Black;
                iFreshSupplyZoneOutlineStyle = DashStyleHelper.Solid;

                iTestedSupplyZoneColor = Brushes.LightCoral;
                iTestedSupplyZoneOpacity = 50;
                iTestedSupplyZoneOutlineColor = Brushes.Black;
                iTestedSupplyZoneOutlineStyle = DashStyleHelper.Solid;

                iBrokenSupplyZoneColor = Brushes.Fuchsia;
                iBrokenSupplyZoneOpacity = 15;
                iBrokenSupplyZoneOutlineColor = Brushes.Black;
                iBrokenSupplyZoneOutlineStyle = DashStyleHelper.Solid;

                iTextFont = new SimpleFont("Arial", 12);//v1.003 - was 10, Sean asked 12
                iTextColor = Brushes.Black;
                #endregion

                #region -- 09. Alerts  --
                iAlertOn = false;
                iAlertSoundFile = "Alert2.wav";
                #endregion

                #region -- 08. Visual Style Paintbars  --
                iPaintBarsEnabled = true;
                upthrustFillColor = Brushes.Lime;
                upthrustColor = Brushes.Black;
                downthrustFillColor = Brushes.Red;
                downthrustColor = Brushes.Black;
                uptrendFillColor = Brushes.DarkGreen;
                downtrendFillColor = Brushes.DarkRed;
                uptrendColor = Brushes.Black;
                downtrendColor = Brushes.Black;
                consolidationColor = Brushes.Black;
                consolidupFillColor = Brushes.Black;
                consoliddownFillColor = Brushes.Black;
                #endregion

                #region -- 02. Parameters Market Structure --
                iUpColor = Brushes.Lime;
                iDownColor = Brushes.DarkRed;
                iNeutralColor = Brushes.Black;
                dash0Style = DashStyleHelper.Solid;
                
                swingStrength = 2;
                percentATR = 0;
                mstTextFont = new SimpleFont("Arial", 12);
                #endregion

                #region -- curve default --
                pDisplayEnabled = false;
                pDashStyle1 = DashStyleHelper.Solid;
                pWidth1 = 2;
                pXOffset = 10;
                iOpacity1 = 100;
                pLineColor1 = Brushes.Black;
                pPercent1 = 0;
                pPercent2 = 25;
                pPercent3 = 50;
                pPercent4 = 75;
                pPercent5 = 100;
                iCurveAreaBrush1 = Brushes.Green;
                iCurveOpacity1 = 40;
                iCurveAreaBrush2 = Brushes.LightGreen;
                iCurveOpacity2 = 20;
                iCurveAreaBrush3 = Brushes.LightCoral;
                iCurveOpacity3 = 20;
                iCurveAreaBrush4 = Brushes.Red;
                iCurveOpacity4 = 40;
                pDefiance = 170;
                pBreakATR = 10;
                pDisplayPrice = false;
                pDisplayPercent = true;
                pIncludeZone = true;
                pDisplayText = true;
                pTextFont3 = new SimpleFont("Arial", 12);//v1.003 - was 10, Sean asked 12
                #endregion

                #region -- 04. Profile --
                iProfileColor = Brushes.Black;
                iProfileOpacity = 40;
                iPOCColor = Brushes.Yellow;
                iPOCOpacity = 100;
                iVALColor = Brushes.Lime;
                iVALOpacity = 100;
                iVAHColor = Brushes.Fuchsia;
                iVAHOpacity = 100;
                iVCColor = Brushes.Black;
                iVCOpacity = 75;
                iVRUColor = Brushes.LimeGreen;
                iVRUOpacity = 65;
                iVRDColor = Brushes.Red;
                iVRDOpacity = 65;
                iVRTextColor = Brushes.Black;
                iDFUTextColor = Brushes.LimeGreen;
                iDFDTextColor = Brushes.Red;
                iDFTextBackColor = Brushes.White;
                iDFTextBackOpacity = 65;
                iVVTextColor = Brushes.Black;
                iVVTextBackColor = Brushes.White;
                iVVTextBackOpacity = 65;
				iQualifiedBackColor = Brushes.Orange;
				iDisqualifiedBackColor = Brushes.DimGray;
				iTMColor = Brushes.White;
                iTMOpacity = 65;

                iPctOfVolumeInVA = 70;
                iShowProfile = true;
                iShowPOC = true;
                iShowVAL = true;
                iShowVAH = true;
                iProfileExpansion = ARC_SDVSystem_ProfileExpansion.DEFAULT;
                iShowVolumeCluster = true;
                iShowVolumeRatio = false;
                iShowDeltaFactor = false;
                iShowVolumeValues = false;
                iShowAllProfile = true;
                iShowAllSupplyProfile = true;
                iShowAllDemandProfile = true;
                iShowAllTestedProfile = true;
                iShowAllBrokenProfile = true;
                iProfileThickness = 5;
                iPOCThickness = 5;
                iVALThickness = 5;
                iVAHThickness = 5;
                iVCThickness = 3;
                iVRTextFont = new SimpleFont("Arial", 12);//v1.003 - was 10, Sean asked 12
                iDFTextFont = new SimpleFont("Arial", 12);//v1.003 - was 10, Sean asked 12
                iVVTextFont = new SimpleFont("Arial", 12);//v1.003 - was 10, Sean asked 12
                iTMThickness = 3;

                iShowLVNProfile = true;
                iExpandLVNProfile = false;
                iNumberOfLVN = 2;
                iLVNColor = Brushes.Navy;
                iLVNOpacity = 100;
                iLVNThickness = 5;
                #endregion

				#region -- Volume Averages Set 1 --
				iVAEnabled    = false;
				iVAPeriod     = 20;
				iVAMode       = "EMA";
//				iVAEnabled3   = true;
				iVA1_Color     = Brushes.Black;
				iVA1_FillColor = Brushes.Black;
				iVA3Opacity    = 20;
				iVA1_ClusterSizeTicks = 3;
				//iVA3DashStyle = DashStyleHelper.Solid;
				//iVA3Width     = 2;
				#endregion

				#region -- Volume Averages Set 2 --
				iVA2Enabled    = false;
				iVA2Period     = 50;
				iVA2Mode       = "SMA";
//				iVA2Enabled3   = true;
				iVA2_Color     = Brushes.Black;
				iVA2_FillColor = Brushes.Black;
				iVAS3Opacity   = 20;
				iVA2_ClusterSizeTicks = 3;
				//iVAS3DashStyle = DashStyleHelper.Solid;
				// iVAS3Width     = 2;
				#endregion

				pSupplyFreshZone_Template  = "Default";
				pSupplyTestedZone_Template = "Default";
				pSupplyBrokenZone_Template = "Default";
				pDemandFreshZone_Template  = "Default";
				pDemandTestedZone_Template = "Default";
				pDemandBrokenZone_Template = "Default";
				
				pMaxVolPctQualifier = 90;
				pMaxBasingCount = 2;
				pQualifyOnVolume = false;
				pQualifyOnThrust = false;
				pQualifyOnBasingCount = false;
            }
            #endregion

            #region State == State.Configure 
            else if (State == State.Configure)
            {
				IsDebug=System.IO.File.Exists("c:\\222222222222.txt");
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
#endif

				gbTickSize = TickSize;//bug fix

                if (iProfileCalcTimeFrame == ARC_SDVSystem_ProfileDataType.TICK) AddDataSeries(BarsPeriodType.Tick, 1);
                else if (iProfileCalcTimeFrame == ARC_SDVSystem_ProfileDataType.SECOND) AddDataSeries(BarsPeriodType.Second, 1);
                else AddDataSeries(BarsPeriodType.Minute, 1);

                #region -- RegMTFManagement --
                string MTFserie = this.iChartType1.ToString() + this.iChartValue1;
                if (iChartMode1 == ARC_SDVSystem_ZoneMode2.MTF && Instrument != null && MTFserie != BarsArray[0].BarsPeriod.BarsPeriodTypeName + BarsArray[0].BarsPeriod.Value.ToString())
                {
                    this.EChartType1 = dictionaryPeriodTypes[this.iChartType1];
                    AddDataSeries(Instrument.FullName, this.EChartType1, this.iChartValue1, MarketDataType.Last);
                }
                else
                {
                    AddDataSeries(BarsPeriodType.Minute, 1);
                    this.iChartMode1 = ARC_SDVSystem_ZoneMode2.DEFAULT_CHART;
                }
                #endregion

                this.sExtrnSupplyTop = new Series<double>(SMA(BarsArray[0], 1), MaximumBarsLookBack.Infinite);
                this.sExtrnSupplyBottom = new Series<double>(SMA(BarsArray[0], 1), MaximumBarsLookBack.Infinite);
                this.sExtrnDemandBottom = new Series<double>(SMA(BarsArray[0], 1), MaximumBarsLookBack.Infinite);
                this.sExtrnDemandTop = new Series<double>(SMA(BarsArray[0], 1), MaximumBarsLookBack.Infinite);

                this.MM = new MouseManager();

                this.UseChartBars = iChartMode1 != ARC_SDVSystem_ZoneMode2.MTF;
                this.tempBrush = null;//Brushes.Black;
                this.tempPen = new Pen() { Brush = Brushes.Black };
                this.tempPenDashStyle = DashStyleHelper.Solid;

                #region -- zigzag --
                multiplierATR = percentATR / 100.0;
                upTrend = true; // arbitrary, just to start somwhere
                priorUpTrend = false;
                firstHighIdx = false;
                firstLowIdx = false;
                addHigh = false;
                updateHigh = false;
                addLow = false;
                updateLow = false;
                lastHighIdx = 0;
                lastLowIdx = 0;
                arrowFont = new SimpleFont("WebDings", 3 * fontSize);
                #endregion

                #region -- publicHoliday --
                publicHoliday[0] = publicHoliday0;
                publicHoliday[1] = publicHoliday1;
                publicHoliday[2] = publicHoliday2;
                publicHoliday[3] = publicHoliday3;
                publicHoliday[4] = publicHoliday4;
                publicHoliday[5] = publicHoliday5;
                publicHoliday[6] = publicHoliday6;
                publicHoliday[7] = publicHoliday7;
                publicHoliday[8] = publicHoliday8;
                publicHoliday[9] = publicHoliday9;
                publicHoliday[10] = publicHoliday10;
                publicHoliday[11] = publicHoliday11;
                publicHoliday[12] = publicHoliday12;
                publicHoliday[13] = publicHoliday13;
                publicHoliday[14] = publicHoliday14;
                publicHoliday[15] = publicHoliday15;
                publicHoliday[16] = publicHoliday16;
                publicHoliday[17] = publicHoliday17;
                publicHoliday[18] = publicHoliday18;
                publicHoliday[19] = publicHoliday19;
                publicHoliday[20] = publicHoliday20;
                publicHoliday[21] = publicHoliday21;
                publicHoliday[22] = publicHoliday22;
                publicHoliday[23] = publicHoliday23;
                publicHoliday[24] = publicHoliday24;
                publicHoliday[25] = publicHoliday25;
                publicHoliday[26] = publicHoliday26;
                publicHoliday[27] = publicHoliday27;
                publicHoliday[28] = publicHoliday28;
                publicHoliday[29] = publicHoliday29;
                publicHoliday[30] = publicHoliday30;
                publicHoliday[31] = publicHoliday31;
                publicHoliday[32] = publicHoliday32;
                publicHoliday[33] = publicHoliday33;
                publicHoliday[34] = publicHoliday34;
                publicHoliday[35] = publicHoliday35;
                publicHoliday[36] = publicHoliday36;
                publicHoliday[37] = publicHoliday37;
                publicHoliday[38] = publicHoliday38;
                publicHoliday[39] = publicHoliday39;
                publicHoliday[40] = publicHoliday40;
                publicHoliday[41] = publicHoliday41;
                publicHoliday[42] = publicHoliday42;
                publicHoliday[43] = publicHoliday43;
                publicHoliday[44] = publicHoliday44;
                publicHoliday[45] = publicHoliday45;
                publicHoliday[46] = publicHoliday46;
                publicHoliday[47] = publicHoliday47;
                #endregion

                init = false;
                priorHistorical = true;
                multiplier = barFilter / 100.0;

                this.GZSLastCount = 0;

            }
            #endregion
			else if (State == State.DataLoaded){
if(IsDebug) ClearOutputWindow();
                #region -- Init Series --
                if (iChartMode1 == ARC_SDVSystem_ZoneMode2.DEFAULT_CHART)
                {
                    bodyHigh = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    bodyLow = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    bodyRange = new Series<double>(this, MaximumBarsLookBack.Infinite);
					truerange = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    allDemandProximal1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandDistal1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandPOC1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandVAH1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandVAL1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandVCT1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandVCB1 = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    allSupplyProximal1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyDistal1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyPOC1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyVAH1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyVAL1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyVCT1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyVCB1 = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    freshDemandProximal1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandDistal1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandPOC1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandVAH1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandVAL1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandVCT1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandVCB1 = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    freshSupplyProximal1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyDistal1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyPOC1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyVAH1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyVAL1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyVCT1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyVCB1 = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    allDemandProximal2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandDistal2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandPOC2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandVAH2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandVAL2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandVCT2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allDemandVCB2 = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    allSupplyProximal2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyDistal2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyPOC2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyVAH2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyVAL2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyVCT2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    allSupplyVCB2 = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    freshDemandProximal2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandDistal2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandPOC2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandVAH2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandVAL2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandVCT2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshDemandVCB2 = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    freshSupplyProximal2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyDistal2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyPOC2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyVAH2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyVAL2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyVCT2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    freshSupplyVCB2 = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    longSignal = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longPOCSignal = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longVCSignal = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longVASignal = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    shortSignal = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortPOCSignal = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortVCSignal = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortVASignal = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    longSignals = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longPOCSignals = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longVCSignals = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longVASignals = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    shortSignals = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortPOCSignals = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortVCSignals = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortVASignals = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    longSignalAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longPOCSignalAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longVCSignalAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longVASignalAll = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    shortSignalAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortPOCSignalAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortVCSignalAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortVASignalAll = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    longSignalsAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longPOCSignalsAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longVCSignalsAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    longVASignalsAll = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    shortSignalsAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortPOCSignalsAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortVCSignalsAll = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    shortVASignalsAll = new Series<double>(this, MaximumBarsLookBack.Infinite);

                    barType = new Series<double>(this, MaximumBarsLookBack.Infinite);
                    trend = new Series<double>(this, MaximumBarsLookBack.Infinite);
					ThrustOvershoot = new Series<double>(this, MaximumBarsLookBack.Infinite);
                }

                bodyHighDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                bodyLowDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                bodyRangeDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);

                allDemandProximal1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandDistal1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandPOC1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandVAH1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandVAL1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandVCT1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandVCB1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);

                allSupplyProximal1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyDistal1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyPOC1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyVAH1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyVAL1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyVCT1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyVCB1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);

                freshDemandProximal1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                freshDemandDistal1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                freshSupplyProximal1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                freshSupplyDistal1Default = new Series<double>(this, MaximumBarsLookBack.Infinite);

                allDemandProximal2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandDistal2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandPOC2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandVAH2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandVAL2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandVCT2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allDemandVCB2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);

                allSupplyProximal2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyDistal2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyPOC2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyVAH2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyVAL2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyVCT2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                allSupplyVCB2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);

                freshDemandProximal2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                freshDemandDistal2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                freshSupplyProximal2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);
                freshSupplyDistal2Default = new Series<double>(this, MaximumBarsLookBack.Infinite);

                longSignalDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longPOCSignalDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longVCSignalDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longVASignalDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);

                shortSignalDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortPOCSignalDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortVCSignalDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortVASignalDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);

                longSignalsDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longPOCSignalsDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longVCSignalsDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longVASignalsDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);

                shortSignalsDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortPOCSignalsDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortVCSignalsDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortVASignalsDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);

                longSignalAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longPOCSignalAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longVCSignalAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longVASignalAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);

                shortSignalAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortPOCSignalAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortVCSignalAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortVASignalAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);

                longSignalsAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longPOCSignalsAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longVCSignalsAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                longVASignalsAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);

                shortSignalsAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortPOCSignalsAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortVCSignalsAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                shortVASignalsAllDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);

                barTypeDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);
                trendDefault = new Series<double>(this, MaximumBarsLookBack.Infinite);

                AllPivots = new Series<double>(this, MaximumBarsLookBack.Infinite);
                FinalHigh = new Series<double>(this, MaximumBarsLookBack.Infinite);
                FinalLow = new Series<double>(this, MaximumBarsLookBack.Infinite);

                vZigZag = new Series<double>(this, MaximumBarsLookBack.Infinite);
                vZigZagHigh = new Series<double>(this, MaximumBarsLookBack.Infinite);
                vZigZagLow = new Series<double>(this, MaximumBarsLookBack.Infinite);

                vCurve1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                vCurve2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                vCurve3 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                vCurve4 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                vCurve5 = new Series<double>(this, MaximumBarsLookBack.Infinite);
                vCurveStatus = new Series<double>(this, MaximumBarsLookBack.Infinite);

                CurveLow = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveHigh = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveLowZ = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveHighZ = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveLowF = new Series<double>(this, MaximumBarsLookBack.Infinite);
                CurveHighF = new Series<double>(this, MaximumBarsLookBack.Infinite);

                CurveBar = new Series<double>(this, MaximumBarsLookBack.Infinite);
				
				ema_ma1 = EMA(Typical, iVAPeriod);
				ema_ma2 = EMA(Typical, iVA2Period);
				sma_ma1 = SMA(Typical, iVAPeriod);
				sma_ma2 = SMA(Typical, iVA2Period);
				ema_ma1.Calculate = this.Calculate;
				ema_ma2.Calculate = this.Calculate;
				sma_ma1.Calculate = this.Calculate;
				sma_ma2.Calculate = this.Calculate;
                #endregion
			}

            #region State == State.Historical
            else if (State == State.Historical)
            {
                sessionIterator = new SessionIterator(Bars);
				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
//Print("uID: "+uID);
				#region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;
                        
                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

                            addSDVToolBar();
                            
                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                            ChartPanel.KeyUp += ChartPanel_KeyUp;
                            ChartPanel.MouseUp += ChartPanel_MouseUp;
                            ChartPanel.MouseMove += ChartPanel_MouseMove;
                            ChartPanel.MouseDown += ChartPanel_MouseDown;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion
				ObjectPrefix = string.Format("{0}{1}{2}", DateTime.Now.Second,DateTime.Now.Millisecond, Instrument.MasterInstrument.Name);
            }
            #endregion
			else if(State == State.Realtime){
				IsRealTime = true;
			}

            #region State == State.Terminated
            else if(State == State.Terminated)
            {
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
						indytoolbar = null;
						try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
							indytoolbar = null;
							try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
							chartWindow = null;
						}));
					}
				}


                if (this.ChartControl != null)
                {
                    ChartPanel.KeyUp -= ChartPanel_KeyUp;
                    ChartPanel.MouseUp -= ChartPanel_MouseUp;
                    ChartPanel.MouseMove -= ChartPanel_MouseMove;
                    ChartPanel.MouseDown -= ChartPanel_MouseDown;
                }
            }
            #endregion
	        #endregion
        }
//==========================================================================================================================================
		#region Plots
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> MA1High { get { return Values[0]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> MA1Low { get { return Values[1]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> MA2High { get { return Values[2]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> MA2Low { get { return Values[3]; } }
		#endregion
//==========================================================================================================================================
		#region -- UI support --
		private void InformUserAboutRecalculation(){
			if(ChartControl != null){
				if (ChartControl.Dispatcher.CheckAccess()) {
					miRecalculate1.Background = Brushes.Yellow;
					miRecalculate1.FontWeight = FontWeights.Bold;
					miRecalculate1.FontStyle  = FontStyles.Italic;
					miRecalculate2.Background = Brushes.Yellow;
					miRecalculate2.FontWeight = FontWeights.Bold;
					miRecalculate2.FontStyle  = FontStyles.Italic;
				}else{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						miRecalculate1.Background = Brushes.Yellow;
						miRecalculate1.FontWeight = FontWeights.Bold;
						miRecalculate1.FontStyle  = FontStyles.Italic;
						miRecalculate2.Background = Brushes.Yellow;
						miRecalculate2.FontWeight = FontWeights.Bold;
						miRecalculate2.FontStyle  = FontStyles.Italic;
					}));
				}
			}
		}
		private void ResetRecalculationUI(){
			if(ChartControl != null){
				if (ChartControl.Dispatcher.CheckAccess()) {
					miRecalculate1.FontWeight = FontWeights.Normal;
					miRecalculate1.FontStyle  = FontStyles.Normal;
					miRecalculate1.Background = null;
					miRecalculate2.FontWeight = FontWeights.Normal;
					miRecalculate2.FontStyle  = FontStyles.Normal;
					miRecalculate2.Background = null;
				}else{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						miRecalculate1.FontWeight = FontWeights.Normal;
						miRecalculate1.FontStyle  = FontStyles.Normal;
						miRecalculate1.Background = null;
						miRecalculate2.FontWeight = FontWeights.Normal;
						miRecalculate2.FontStyle  = FontStyles.Normal;
						miRecalculate2.Background = null;
					}));
				}
			}
		}

		private void Combo_KeyDown(object sender, KeyEventArgs e) { e.Handled = true; InformUserAboutRecalculation();}
        private void Combo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
			var s1 = iVAMode;
			var s2 = iVA2Mode;
            iVAMode = ((ComboBoxItem)VA1Combo.SelectedItem).Content.ToString();
            iVA2Mode = ((ComboBoxItem)VA2Combo.SelectedItem).Content.ToString();
			if(s1 != iVAMode || s2 !=iVA2Mode) InformUserAboutRecalculation();
        }
        #region NumericUpDownValueChanged() 
        private void NumericUpDownValueChanged(object sender, TextChangedEventArgs e)
        {
			var s1 = iVAPeriod;
			var s2 = iVA2Period;
            iVAPeriod = Math.Min(99999, Math.Max(1, IntParseFast(nudVA1.Text)));
            nudVA1.Text = iVAPeriod.ToString();
            iVA2Period = Math.Min(99999, Math.Max(1, IntParseFast(nudVA2.Text)));
            nudVA2.Text = iVA2Period.ToString();
			if(s1 != iVAPeriod || s2 !=iVA2Period) InformUserAboutRecalculation();
        }
        #endregion
        private int IntParseFast(string value)
        {
            int result = 0;
            for (int i = 0; i < value.Length; i++) result = 10 * result + (value[i] - 48);
            return result;
        }
//====================================================================================
		private Grid createVA1Menu(string nudValue1, string cbVAtype)
        {
			#region createVA1Menu
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            #region -- line 1 - nud1 --
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Period : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudVA1 = new TextBox() { Name = string.Format("VA1txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudVA1.Text = nudValue1;
            nudVA1.KeyDown += menuTxtbox_KeyDown;
            nudVA1.TextChanged += NumericUpDownValueChanged;
			nudVA1.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
				int num = iVAPeriod + (e.Delta>0 ? 1 : -1);
//Print("num: "+num+"   iVAperiod: "+iVAPeriod);
				bool isInRange = num>=1 && num<=500;
				if(isInRange){
					iVAPeriod   = num;
					nudVA1.Text = num.ToString("0");
					InformUserAboutRecalculation();
					ForceRefresh();
				}
			};
            nudVA1.SetValue(Grid.ColumnProperty, 1);
            nudVA1.SetValue(Grid.RowProperty, 0);
            nudVA1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("VA1cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("VA1cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);
            #endregion

            #region -- line 2 - Combo --
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Type : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);

            VA1Combo = new ComboBox { Name = string.Format("VA1combo{0}", uID), MinWidth = 75 + gCmdup.Width, Width = 75 + gCmdup.Width, MaxWidth = 75 + gCmdup.Width, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            VA1Combo.Items.Add(new ComboBoxItem { Content = "EMA" });
            VA1Combo.Items.Add(new ComboBoxItem { Content = "SMA" });
            VA1Combo.Text = cbVAtype;
            VA1Combo.KeyDown += Combo_KeyDown;
            VA1Combo.SelectionChanged += Combo_SelectionChanged;
			VA1Combo.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
				if(VA1Combo.Text=="EMA") VA1Combo.Text = "SMA"; else VA1Combo.Text="EMA";
				InformUserAboutRecalculation();
				ForceRefresh();
			};

            VA1Combo.SetValue(Grid.ColumnProperty, 1);
            VA1Combo.SetValue(Grid.RowProperty, 2);
            VA1Combo.SetValue(Grid.ColumnSpanProperty, 2);
            #endregion

            //Add controls to grid
            grid.Children.Add(lbl1);
            grid.Children.Add(nudVA1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            grid.Children.Add(lbl2);
            grid.Children.Add(VA1Combo);

            return grid;
			#endregion
        }
        private Grid createVA2Menu(string nudValue1, string cbVAtype)
        {
			#region createVA2Menu
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            #region -- line 1 - nud1 --
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Period : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudVA2 = new TextBox() { Name = string.Format("VA2txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudVA2.Text = nudValue1;
            nudVA2.KeyDown += menuTxtbox_KeyDown;
            nudVA2.TextChanged += NumericUpDownValueChanged;
			nudVA2.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
				int num = iVA2Period + (e.Delta>0 ? 1 : -1);
//Print("num: "+num+"   iVA2period: "+iVA2Period);
				bool isInRange = num>=1 && num<=500;
				if(isInRange){
					iVA2Period   = num;
					nudVA2.Text = num.ToString("0");
					InformUserAboutRecalculation();
					ForceRefresh();
				}
			};
            nudVA2.SetValue(Grid.ColumnProperty, 1);
            nudVA2.SetValue(Grid.RowProperty, 0);
            nudVA2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("VA2cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("VA2cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);
            #endregion

            #region -- line 2 - Combo --
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Type : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);

            VA2Combo = new ComboBox { Name = string.Format("VA2combo{0}", uID), MinWidth = 75 + gCmdup.Width, Width = 75 + gCmdup.Width, MaxWidth = 75 + gCmdup.Width, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            VA2Combo.Items.Add(new ComboBoxItem { Content = "EMA" });
            VA2Combo.Items.Add(new ComboBoxItem { Content = "SMA" });
            VA2Combo.Text = cbVAtype;
            VA2Combo.KeyDown += Combo_KeyDown;
            VA2Combo.SelectionChanged += Combo_SelectionChanged;
			VA2Combo.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
				if(VA2Combo.Text=="EMA") VA2Combo.Text = "SMA"; else VA2Combo.Text="EMA";
				InformUserAboutRecalculation();
				ForceRefresh();
			};

            VA2Combo.SetValue(Grid.ColumnProperty, 1);
            VA2Combo.SetValue(Grid.RowProperty, 2);
            VA2Combo.SetValue(Grid.ColumnSpanProperty, 2);
            #endregion

            //Add controls to grid
            grid.Children.Add(lbl1);
            grid.Children.Add(nudVA2);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            grid.Children.Add(lbl2);
            grid.Children.Add(VA2Combo);

            return grid;
			#endregion
        }
		#endregion
//====================================================================================

		#region -- Parameters --
		[NinjaScriptProperty]
        [Display(Order = 0, Name = "Qualify on Low Volume", GroupName = "Qualified Zones", Description = "Require zones to be low volume")]
        public bool pQualifyOnVolume { get; set; }
        [NinjaScriptProperty]
        [Display(Order = 10, Name = "Qualify on Thrust", GroupName = "Qualified Zones", Description = "Require thrust bars to exceed the range of the zone")]
        public bool pQualifyOnThrust { get; set; }
        [NinjaScriptProperty]
        [Display(Order = 20, Name = "Qualify on Basing Count", GroupName = "Qualified Zones", Description = "Require zones to have a max number of basing candles")]
        public bool pQualifyOnBasingCount { get; set; }

		[NinjaScriptProperty]
        [Range(1,100)]
        [Display(Order = 30, Name = "Low Vol Pct of Avg Vol", GroupName = "Qualified Zones", Description = "Low volume zone as a percent of Avg Zone Volume.  E.g. '25' means that qualified zones will have, at max, 25% of the avg zone volume")]
        public int pMaxVolPctQualifier { get; set; }
		[NinjaScriptProperty]
        [Range(1,5)]
        [Display(Order = 40, Name = "Max Basing Count", GroupName = "Qualified Zones", Description = "Max number of basing (black) candles for a qualified zone")]
		public int pMaxBasingCount {get;set;}
        [XmlIgnore]
        [Display(Order = 50, Name = "Qualified Zone Text Back Color", GroupName = "Qualified Zones", Description = "")]
        public Brush iQualifiedBackColor { get; set; }
        [Browsable(false)]
        public string iQualifiedBackColorSerialize{ get { return Serialize.BrushToString(iQualifiedBackColor); } set { iQualifiedBackColor = Serialize.StringToBrush(value); }}
        [XmlIgnore]
        [Display(Order = 60, Name = "Disqualified Zone Text Back Color", GroupName = "Qualified Zones", Description = "")]
        public Brush iDisqualifiedBackColor { get; set; }
        [Browsable(false)]
        public string iDisqualifiedBackColorSerialize{ get { return Serialize.BrushToString(iDisqualifiedBackColor); } set { iDisqualifiedBackColor = Serialize.StringToBrush(value); }}

		#region TradingPlan
		[Range(-100, 100)]
		[Display(Name = "Entry Offset ticks", GroupName = "Trade Plan", Description = "+ value means EntryPrice will be advanced towards the market, - value means EntryPrice will be moved away from the market", Order = 1)]
		public int EntryOffsetTicks {get;set;}
		[Range(-100, 100)]
		[Display(Name = "SL Offset ticks", GroupName = "Trade Plan", Description = "+ value means SL will be enlarged, - value means SL will be reduced", Order = 2)]
		public int SLOffsetTicks {get;set;}
		[Range(1, 100)]
		[Display(Name = "ATR period", GroupName = "Trade Plan", Description = "", Order = 3)]
		public int ATRperiod  {get; set;}
		[Display(Name = "Sell Far Trade Plan loc", GroupName = "Trade Plan", Description = "", Order = 8)]
		public ARC_SDVSystem_TradePlanLocation SellFarTradePlan_Location  {get; set;}
		[Display(Name = "Sell Near Trade Plan loc", GroupName = "Trade Plan", Description = "", Order = 10)]
		public ARC_SDVSystem_TradePlanLocation SellNearTradePlan_Location  {get; set;}
		[Display(Name = "Buy Near Trade Plan loc", GroupName = "Trade Plan", Description = "", Order = 15)]
		public ARC_SDVSystem_TradePlanLocation BuyNearTradePlan_Location  {get; set;}
		[Display(Name = "Buy Far Trade Plan loc", GroupName = "Trade Plan", Description = "", Order = 20)]
		public ARC_SDVSystem_TradePlanLocation BuyFarTradePlan_Location  {get; set;}
		[Display(Name = "Show Longs", GroupName = "Trade Plan", Description = "Show trade plan for long trades", Order = 25)]
		public bool ShowLongTradePlans {get; set;}
		[Display(Name = "Show Shorts", GroupName = "Trade Plan", Description = "Show trade plan for short trades", Order = 30)]
		public bool ShowShortTradePlans {get; set;}
		[Display(Name = "Show Near Trade Plans", GroupName = "Trade Plan", Description = "Show the trade plan for the nearest fib line", Order = 35)]
		public bool ShowNearTradePlan {get; set;}
		[Display(Name = "Show Far Trade Plans", GroupName = "Trade Plan", Description = "Show the trade plan for the far fib line", Order = 40)]
		public bool ShowFarTradePlan {get; set;}

		[Display(Name = "Enable on Fresh zones?", GroupName = "Trade Plan", Description = "", Order = 42)]
		public bool TradePlanOnFreshZones {get;set;}
		[Display(Name = "Enable on Tested zones?", GroupName = "Trade Plan", Description = "", Order = 44)]
		public bool TradePlanOnTestedZones {get;set;}
		[Display(Name = "Enable on Qualified zones?", GroupName = "Trade Plan", Description = "", Order = 46)]
		public bool TradePlanOnQualifiedZones {get;set;}

//		[Display(Name = "Print at CurrentBar?", GroupName = "Trade Plan", Description = "", Order = 42)]
//		public bool PrintPlansInRightMargin = false;
		[Range(0, 10000)]
		[Display(Name = "Line length", GroupName = "Trade Plan", Description = "Line length (in bars) for near trade plan SL, T1 and T2 lines", Order = 50)]
		public int TradePlan_LineLength {get;set;}
//		[Display(Name = "Include terminated levels", GroupName = "Trade Plan", Description = "Include all historical levels, not just the current ones", Order = 55)]
//		public bool IncludeTerminatedLevels{get; set;}
//		[XmlIgnore]
//		[Display(Name = "Terminated color", GroupName = "Trade Plan", Description = "Color of terminated lines carried forward", Order = 60)]
//		public Brush TerminatedLevelColor {get; set;}
//		[Browsable(false)]
//		public string TerminatedLevelColorSerialize {get { return Serialize.BrushToString(TerminatedLevelColor); }set { TerminatedLevelColor = Serialize.StringToBrush(value); }}
//		[Display(Name = "Terminated line width", GroupName = "Trade Plan", Description = "Thickness of terminated line carried forward", Order = 65)]
//		public int TerminatedLevelLineWidth {get; set;}
//		[Display(Name = "Terminated line style", GroupName = "Trade Plan", Description = "Style of terminated lines", Order = 70)]
//		public DashStyleHelper TerminatedLevelDashStyle {get;set;}
		[Display(Name = "Visual Shift distance", GroupName = "Trade Plan", Description = "Distance (in bars) of shifting the trade plans away from the current bar (neg value moves print to the left, pos values to the right)", Order = 75)]
		public int VisualShiftDistance {get; set;}

		[Display(Name = "SL Calc Basis", GroupName = "Trade Plan", Description = "When calculating the SL location, should it use the Zone edge opposite of the entry zone edge, or an ATR multiple, or raw Tick distances?", Order = 77)]
		public ARC_SDVSystem_SL_CalcBasis SL_CalcBasis {get;set;}

		[Display(Name = "TP Calc Basis", GroupName = "Trade Plan", Description = "When calculating the Target distances, should it use the ATR multiple of the SL, or raw Tick distances?", Order = 80)]
		public ARC_SDVSystem_TP_CalcBasis TP_CalcBasis {get; set;}

		[Display(Name = "Show T2 line", GroupName = "Trade Plan", Description = "Show the T2 line", Order = 86)]
		public bool ShowT2 {get; set;}
		[Display(Name = "Show T1 line", GroupName = "Trade Plan", Description = "Show the T1 line", Order = 90)]
		public bool ShowT1 {get; set;}
		[Display(Name = "Show SL line", GroupName = "Trade Plan", Description = "Show the SL line", Order = 95)]
		public bool ShowSL {get; set;}

//============================================================================================================
//		[Range(0.01, 10)]
//		[Display(Name = "EntryZone Height", GroupName = "Trade Plan Entry", Description = "Size of Entry Area rectangle, in multiples of the ATR", Order = 0)]
//		public double EntryZoneSize_inATRs { get; set; }

		[Display(Name = "Entry Basis", GroupName = "Trade Plan Entry", Description = "", Order = 5)]
		public ARC_SDVSystem_TradeEntryBasis EntryBasis {get;set;}

//		[Display(Name = "Show Entry Areas", GroupName = "Trade Plan Entry", Description = "", Order = 10)]
//		public bool ShowEntryZones {get;set;}

		[Display(Name = "Label for Longs", GroupName = "Trade Plan Entry", Description = "Enter a '*' for price insertion", Order = 15)]
		public string LongEntryLabel {get;set;}
		[Display(Name = "Label for Shorts", GroupName = "Trade Plan Entry", Description = "Enter a '*' for price insertion", Order = 20)]
		public string ShortEntryLabel {get;set;}
//		[XmlIgnore]
//		[Display(Name = "Buy EntryZone Fill", GroupName = "Trade Plan Entry", Description = "", Order = 25)]
//		public Brush BuyEntryZoneColor{get;set;}
//		[Browsable(false)]
//		public string BuyEntryZoneColorSerialize {get { return Serialize.BrushToString(BuyEntryZoneColor); }set { BuyEntryZoneColor = Serialize.StringToBrush(value); }}
//		[Range(0, 100)]
//		[Display(Name = "Buy EntryZone Fill Opacity", GroupName = "Trade Plan Entry", Description = "0=transparent, 100=fully opaque", Order = 30)]
//		public int BuyEntryZoneColorOpacity {get;set;}

//		[XmlIgnore]
//		[Display(Name = "Sell EntryZone Fill", GroupName = "Trade Plan Entry", Description = "", Order = 35)]
//		public Brush SellEntryZoneColor{get;set;}
//		[Browsable(false)]
//		public string SellEntryZoneColorSerialize {get { return Serialize.BrushToString(SellEntryZoneColor); }set { SellEntryZoneColor = Serialize.StringToBrush(value); }}
//		[Range(0, 100)]
//		[Display(Name = "Sell EntryZone Fill Opacity", GroupName = "Trade Plan Entry", Description = "0=transparent, 100=fully opaque", Order = 40)]
//		public int SellEntryZoneColorOpacity {get;set;}

		[Display(Name = "Font", GroupName = "Trade Plan Entry", Description = "", Order = 45)]
        public SimpleFont FontEL { get; set; }
		[XmlIgnore]
		[Display(Name = "Entry color", GroupName = "Trade Plan Entry", Description = "Color of Entry lines", Order = 50)]
		public Brush EntryBrush  {get;set;}
				[Browsable(false)]
				public string EntryBrushSerialize {get { return Serialize.BrushToString(EntryBrush); }set { EntryBrush = Serialize.StringToBrush(value); }}
		[Display(Name = "Entry line style", GroupName = "Trade Plan Entry", Description = "Style of Entry lines", Order = 55)]
		public DashStyleHelper EntryDashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "Entry line width", GroupName = "Trade Plan Entry", Description = "", Order = 60)]
		public int EntryLineWidth {get;set;}
//============================================================================================================
		[Display(Name = "Font", GroupName = "Trade Plan StopLoss", Description = "", Order = 1)]
        public SimpleFont FontSL { get; set; }
		[Range(0.0, 1000)]
		[Display(Name = "SL size ATRs", GroupName = "Trade Plan StopLoss", Description = "Size of the stoploss as a multiple of the ATR", Order = 10)]
		public double SLsize_inATRs {get;set;}
		[Range(0, 10000)]
		[Display(Name = "SL size Ticks", GroupName = "Trade Plan StopLoss", Description = "Size of the stoploss in Ticks", Order = 11)]
		public int SLsize_inTicks {get;set;}
		[Display(Name = "SL label for Longs", GroupName = "Trade Plan StopLoss", Description = "Enter a '*' for price insertion", Order = 20)]
		public string LongSLLabel {get;set;}
		[Display(Name = "SL label for Shorts", GroupName = "Trade Plan StopLoss", Description = "Enter a '*' for price insertion", Order = 30)]
		public string ShortSLLabel {get;set;}
		[XmlIgnore]
		[Display(Name = "SL color for Longs", GroupName = "Trade Plan StopLoss", Description = "Color of SL lines", Order = 50)]
		public Brush LongSLBrush  {get;set;}
				[Browsable(false)]
				public string LSLBrushSerialize {get { return Serialize.BrushToString(LongSLBrush); }set { LongSLBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Name = "SL color for Shorts", GroupName = "Trade Plan StopLoss", Description = "Color of SL lines", Order = 51)]
		public Brush ShortSLBrush  {get;set;}
				[Browsable(false)]
				public string SSLBrushSerialize {get { return Serialize.BrushToString(ShortSLBrush); }set { ShortSLBrush = Serialize.StringToBrush(value); }}
		[Display(Name = "SL line style", GroupName = "Trade Plan StopLoss", Description = "Style of SL lines", Order = 65)]
		public DashStyleHelper SLDashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "SL line width", GroupName = "Trade Plan StopLoss", Description = "", Order = 80)]
		public int SLLineWidth {get;set;}
//============================================================================================================
        [Display(Name = "Font", GroupName = "Trade Plan Target1", Description = "", Order = 1)]
        public SimpleFont FontT1 { get; set; }
		[Range(0.0, 1000)]
		[Display(Name = "Target1 ATRs", GroupName = "Trade Plan Target1", Description = "Size of the first profit target as a multiple of ATR", Order = 10)]
		public double T1size_inATRs  {get;set;}
		[Range(0.0, 1000)]
		[Display(Name = "Target1 RRs", GroupName = "Trade Plan Target1", Description = "Size of the first profit target as a multiple of the Risk (entry to stoploss)", Order = 11)]
		public double T1size_inRRs  {get;set;}
		[Range(0.0, 10000)]
		[Display(Name = "Target1 Ticks", GroupName = "Trade Plan Target1", Description = "Size of the first profit target in ticks", Order = 12)]
		public double T1size_inTicks  {get;set;}
		[Display(Name = "Target1 label for Longs", GroupName = "Trade Plan Target1", Description = "Enter a '*' for price insertion", Order = 20)]
		public string LongT1Label {get;set;}
		[Display(Name = "Target1 label for Shorts", GroupName = "Trade Plan Target1", Description = "Enter a '*' for price insertion", Order = 30)]
		public string ShortT1Label {get;set;}
		[XmlIgnore]
		[Display(Name = "Target1 color for Longs", GroupName = "Trade Plan Target1", Description = "Color of T1 lines", Order = 40)]
		public Brush LongT1Brush {get;set;}
				[Browsable(false)]
				public string LT1BrushSerialize {get { return Serialize.BrushToString(LongT1Brush); }set { LongT1Brush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Name = "Target1 color for Shorts", GroupName = "Trade Plan Target1", Description = "Color of T1 lines", Order = 50)]
		public Brush ShortT1Brush {get;set;}
				[Browsable(false)]
				public string ST1BrushSerialize {get { return Serialize.BrushToString(ShortT1Brush); }set { ShortT1Brush = Serialize.StringToBrush(value); }}
		[Display(Name = "Target1 line style", GroupName = "Trade Plan Target1", Description = "Style of T1 lines", Order = 60)]
		public DashStyleHelper T1DashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "Target1 line width", GroupName = "Trade Plan Target1", Description = "", Order = 70)]
		public int T1LineWidth {get;set;}
//============================================================================================================
		[Display(Name = "Font", GroupName = "Trade Plan Target2", Description = "", Order = 1)]
        public SimpleFont FontT2 { get; set; }
		[Range(0.0, 1000)]
		[Display(Name = "Target2 ATRs", GroupName = "Trade Plan Target2", Description = "Size of the second profit target as a multiple of ATR", Order = 10)]
		public double T2size_inATRs  { get;set; }
		[Range(0.0, 1000)]
		[Display(Name = "Target2 RRs", GroupName = "Trade Plan Target2", Description = "Size of the second profit target as a multiple of ATR", Order = 11)]
		public double T2size_inRRs  { get;set; }
		[Range(0.0, 10000)]
		[Display(Name = "Target2 Ticks", GroupName = "Trade Plan Target2", Description = "Size of the second profit target in ticks", Order = 12)]
		public double T2size_inTicks  { get;set; }
		[Display(Name = "Target2 label for Longs", GroupName = "Trade Plan Target2", Description = "Enter a '*' for price insertion", Order = 20)]
		public string LongT2Label { get;set; }
		[Display(Name = "Target2 label for Shorts", GroupName = "Trade Plan Target2", Description = "Enter a '*' for price insertion", Order = 30)]
		public string ShortT2Label { get;set; }
		[XmlIgnore]
		[Display(Name = "Target2 color for Longs", GroupName = "Trade Plan Target2", Description = "Color of T2 lines", Order = 40)]
		public Brush LongT2Brush {get;set;}
				[Browsable(false)]
				public string LT2BrushSerialize {get { return Serialize.BrushToString(LongT2Brush); }set { LongT2Brush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Name = "Target2 color for Shorts", GroupName = "Trade Plan Target2", Description = "Color of T2 lines", Order = 50)]
		public Brush ShortT2Brush {get;set;}
				[Browsable(false)]
				public string ST2BrushSerialize {get { return Serialize.BrushToString(ShortT2Brush); }set { ShortT2Brush = Serialize.StringToBrush(value); }}
		[Display(Name = "Target2 line style", GroupName = "Trade Plan Target2", Description = "Style of T2 lines", Order = 60)]
		public DashStyleHelper T2DashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "Target2 line width", GroupName = "Trade Plan Target2", Description = "", Order = 70)]
		public int T2LineWidth {get;set;}
//============================================================================================================
		#endregion
		#region -- Volume Averages Set 1 --

		[NinjaScriptProperty]
		[Display(Name = "Enabled", GroupName = "Volume Averages Set 1", Description = "", Order = 00)]
		public bool iVAEnabled { get; set; }

		[NinjaScriptProperty]
		[Range(0, 1000)]
		[Display(Name = "MA Period", GroupName = "Volume Averages Set 1", Description = "", Order = 10)]
		public int iVAPeriod { get; set; }

		[NinjaScriptProperty]
		[TypeConverter(typeof(VolumeAverageMode))]
		[Display(Name = "MA Type", GroupName = "Volume Averages Set 1", Description = "", Order = 20)]
		public string iVAMode { get; set; }

//        [NinjaScriptProperty]
//        [Display(Name = "Cluster Enabled", GroupName = "Volume Averages Set 1", Description = "", Order = 30)]
//        public bool iVAEnabled3 { get; set; }

		[XmlIgnore]
		[Display(Name = "Cluster Color", GroupName = "Volume Averages Set 1", Description = "", Order = 40)]
		public Brush iVA1_Color { get; set; }
					[Browsable(false)]
					public string iVA3ColorSerialize
					{
					    get { return Serialize.BrushToString(iVA1_Color); }
					    set { iVA1_Color = Serialize.StringToBrush(value); }
					}

//        [Display(Name = "Cluster DashStyle", GroupName = "Volume Averages Set 1", Description = "", Order = 50)]
//        public DashStyleHelper iVA3DashStyle { get; set; }

		[XmlIgnore]
		[Display(Name = "Cluster Fill Color", GroupName = "Volume Averages Set 1", Description = "", Order = 60)]
		public Brush iVA1_FillColor { get; set; }
					[Browsable(false)]
					public string iVA33ColorSerialize
					{
					    get { return Serialize.BrushToString(iVA1_FillColor); }
					    set { iVA1_FillColor = Serialize.StringToBrush(value); }
					}

		[Range(0, 100)]
		[Display(Name = "Cluster Fill Opacity (%)", GroupName = "Volume Averages Set 1", Description = "", Order = 70)]
		public int iVA3Opacity { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Cluster size (ticks)", GroupName = "Volume Averages Set 1", Description = "", Order = 80)]
		public int iVA1_ClusterSizeTicks { get; set; }

//        [Range(1, int.MaxValue)]
//        [Display(Name = "Line Width", GroupName = "Volume Averages Set 1", Description = "", Order = 90)]
//        public int iVA3Width { get; set; }

		#endregion
		#region -- Volume Averages Set 2 --
		[NinjaScriptProperty]
		[Display(Name = "Enabled", GroupName = "Volume Averages Set 2", Description = "", Order = 00)]
		public bool iVA2Enabled { get; set; }

		[NinjaScriptProperty]
		[Range(0, 1000)]
		[Display(Name = "MA Period", GroupName = "Volume Averages Set 2", Description = "", Order = 10)]
		public int iVA2Period { get; set; }

		[NinjaScriptProperty]
		[TypeConverter(typeof(VolumeAverageMode))]
		[Display(Name = "MA Type", GroupName = "Volume Averages Set 2", Description = "", Order = 20)]
		public string iVA2Mode { get; set; }

//        [NinjaScriptProperty]
//        [Display(Name = "Cluster Enabled", GroupName = "Volume Averages Set 2", Description = "", Order = 30)]
//        public bool iVA2Enabled3 { get; set; }

		[XmlIgnore]
		[Display(Name = "Cluster Color", GroupName = "Volume Averages Set 2", Description = "", Order = 40)]
		public Brush iVA2_Color { get; set; }
					[Browsable(false)]
					public string iVAS3ColorSerialize
					{
					    get { return Serialize.BrushToString(iVA2_Color); }
					    set { iVA2_Color = Serialize.StringToBrush(value); }
					}

//        [Display(Name = "Cluster DashStyle", GroupName = "Volume Averages Set 2", Description = "", Order = 50)]
//        public DashStyleHelper iVAS3DashStyle { get; set; }

		[XmlIgnore]
		[Display(Name = "Cluster Fill Color", GroupName = "Volume Averages Set 2", Description = "", Order = 60)]
		public Brush iVA2_FillColor { get; set; }
					[Browsable(false)]
					public string iVAS33ColorSerialize
					{
					    get { return Serialize.BrushToString(iVA2_FillColor); }
					    set { iVA2_FillColor = Serialize.StringToBrush(value); }
					}

		[Range(0, 100)]
		[Display(Name = "Cluster Fill Opacity (%)", GroupName = "Volume Averages Set 2", Description = "", Order = 70)]
		public int iVAS3Opacity { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Cluster size (ticks)", GroupName = "Volume Averages Set 2", Description = "", Order = 80)]
		public int iVA2_ClusterSizeTicks { get; set; }

//        [Range(1, int.MaxValue)]
//        [Display(Name = "Cluster Width", GroupName = "Volume Averages Set 2", Description = "", Order = 90)]
//        public int iVAS3Width { get; set; }

        #endregion
		#endregion
        #region internal class VolumeAverageMode : StringConverter
        internal class VolumeAverageMode : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "EMA", "SMA" });
            }
        }
        #endregion


		#region -- OnBarUpdate()  --
        protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
//Print("OBU:  "+IsDebug.ToString());
            if (Instruments[0] == null || Instruments[1] == null) return;
            if (Instruments[0].FullName != Instruments[1].FullName) return;
            if (this.iChartMode1 == ARC_SDVSystem_ZoneMode2.DEFAULT_CHART && BarsInProgress == 2) return;
			if(Bars_To_Process>0 && iProfileCalcTimeFrame == ARC_SDVSystem_ProfileDataType.TICK){
				if(CurrentBars[1] < BarsArray[1].Count-Bars_To_Process) return;
			}

            if (BarsInProgress == 0) {
				avgTrueRange = ATR(14);
//Print("iVA1Mode: "+iVAMode+"   2: "+iVA2Mode);
				#region -- VolumeAverages --
				if(iVAMode[0]=='E'){
					MA1High[0] = ema_ma1[0] + iVA1_ClusterSizeTicks/2.0*TickSize;
					MA1Low[0]  = ema_ma1[0] - iVA1_ClusterSizeTicks/2.0*TickSize;
				}
				else if(iVAMode[0]=='S'){
					MA1High[0] = sma_ma1[0] + iVA1_ClusterSizeTicks/2.0*TickSize;
					MA1Low[0]  = sma_ma1[0] - iVA1_ClusterSizeTicks/2.0*TickSize;
				}
				if(iVA2Mode[0]=='E'){
					MA2High[0] = ema_ma2[0] + iVA2_ClusterSizeTicks/2.0*TickSize;
					MA2Low[0]  = ema_ma2[0] - iVA2_ClusterSizeTicks/2.0*TickSize;
				}
				else if(iVA2Mode[0]=='S'){
					MA2High[0] = sma_ma2[0] + iVA2_ClusterSizeTicks/2.0*TickSize;
					MA2Low[0]  = sma_ma2[0] - iVA2_ClusterSizeTicks/2.0*TickSize;
				}
			}
			#endregion

            #region -- RegInit --
            if (this.GZS == null)
            {
                string instid = this.iChartType1.ToString() + "_" + this.iChartValue1.ToString() + "_" + this.iChartValue2.ToString() + "_" + this.iChartValue3.ToString();
                if (this.UseChartBars) instid = BarsArray[0].BarsPeriod.BaseBarsPeriodValue.ToString() + "_" + BarsArray[0].BarsPeriod.Value.ToString() + "_" + BarsArray[0].BarsPeriod.Value2.ToString() + "_" + BarsArray[0].BarsPeriod.BaseBarsPeriodValue.ToString();
                string gzsid = Instrument.FullName + "_" + instid + "_" + this.barFilter.ToString() + "_" + this.applyRangeFilter.ToString() + "_" + this.applyThrustFilter.ToString() + "_" + this.Calculate.ToString();
                this.GZS = new List<GZone>(); // BH OVERRIDE GLOBAL MEMORY
//if(IsDebug){
//	Print("L 2686  GZS init");
//	Print("BarsArray[0].Count: "+BarsArray[0].Count);
//	Print("BarsArray[1].Count: "+BarsArray[1].Count);
//	Print("BarsArray[2].Count: "+BarsArray[2].Count);
//}
            }
            #endregion

            #region -- RegHistCalculate --
            if (Hist == null)
            {
                Hist = new GHistogram(gbTickSize, 2, this.iPctOfVolumeInVA);
                BarHists = new List<GHistogram>();
            }

            if (MinHist == null) MinHist = new GHistogram(gbTickSize, 2, this.iPctOfVolumeInVA);
            int histogramBIP = iChartMode1 == ARC_SDVSystem_ZoneMode2.DEFAULT_CHART ? 0 : 2;
            if (BarsInProgress == histogramBIP && IsFirstTickOfBar) BarHists.Add(new GHistogram(gbTickSize, 2, this.iPctOfVolumeInVA));// Add the new object
            if (BarsInProgress == 1)
            {
                if (iProfileCalcTimeFrame == ARC_SDVSystem_ProfileDataType.TICK)
                {
                    // UPTICK/DOWNTICK CALCULATION
                    PrevTick = CurrTick;
                    CurrTick = Closes[BarsInProgress][0];

                    if ((CurrTick > PrevTick) || ((CurrTick == PrevTick) && (LastTickType == ARC_SDVSystem_TickDirection.UP))) LastTickType = ARC_SDVSystem_TickDirection.UP;
                    else if ((CurrTick < PrevTick) || ((CurrTick == PrevTick) && (LastTickType == ARC_SDVSystem_TickDirection.DOWN))) LastTickType = ARC_SDVSystem_TickDirection.DOWN;

                    if (CurrentBars[histogramBIP] >= 2)
                    {
                        int histIndex = (State == State.Historical && Times[histogramBIP][0] == Times[1][0]) ? CurrentBars[histogramBIP] - 1 : CurrentBars[histogramBIP];
                        if (State != State.Historical) histIndex -= 1;
                        if (histIndex >= 0) BarHists[histIndex].UpdateData(Closes[BarsInProgress][0], (long)Volumes[BarsInProgress][0], LastTickType, (long)Volumes[BarsInProgress][0]);// FILL HISTOGRAM
                    }
                }
                else
                {
//if(IsDebug) Print(string.Format("L  2720   CurrentBars[{0}]: {1}",histogramBIP,CurrentBars[histogramBIP]));
                    if (CurrentBars[histogramBIP] >= 2)
                    {
                        int histIndex = (State == State.Historical && Times[histogramBIP][0] == Times[1][0]) ? CurrentBars[histogramBIP] - 1 : CurrentBars[histogramBIP];
                        if (State != State.Historical) histIndex -= 1;
                        if (IsFirstTickOfBar) MinHist.ClearAllData();
                        else
                        {
                            BarHists[histIndex].PruneData(MinHist);
                            MinHist.ClearAllData();
                        }

                        //VWTPO
                        double num_bins = Math.Abs(Math.Round((High[0] - Low[0]) / gbTickSize, 0)) + 1;//BUGSDV00 - [BUG FIX:21.06.2016] : missing "+1" in calculation.
                        if (num_bins != 0.0)
                        {
                            for (double p = Low[0]; p <= High[0]; p = Instrument.MasterInstrument.RoundToTickSize(p + gbTickSize))
                            {
                                MinHist.SetData(p, (long)(Volume[0] / (long)num_bins), LastTickType, 1);
                            }
                        }

                        BarHists[histIndex].MergeData(MinHist);
//if(IsDebug) Print("L 2746     BarHists.Count: "+BarHists.Count);
                    }
                }
                return;
            }
            #endregion

            if (BarsInProgress == 0 && CurrentBars[0] >= 2)
            {
//if(IsDebug) Print("L   2754   BIP 0");
                #region -- RegMarketStructure --
                if (IsFirstTickOfBar)
                {
                    if (addHigh || updateHigh) firstHighIdx = true;
                    if (addLow || updateLow) firstLowIdx = true;
                    priorUpTrend = upTrend;
                    priorCurrentLow = currentLow;
                    priorCurrentHigh = currentHigh;
                    priorLastHighIdx = lastHighIdx;
                    priorLastLowIdx = lastLowIdx;
                    swingMax = MAX(High, swingStrength)[1];
                    swingMin = MIN(Low, swingStrength)[1];
                    isPreliminaryHigh = false;
                    isPreliminaryLow = false;
                    AllPivots[0] = 0;
                }
                updateHigh = priorUpTrend && High[0] > priorCurrentHigh;
                updateLow = !priorUpTrend && Low[0] < priorCurrentLow;
                addHigh = !priorUpTrend && !(Low[0] < priorCurrentLow) && High[0] > swingMax;
                addLow = priorUpTrend && !(High[0] > priorCurrentHigh) && Low[0] < swingMin;

                #region -- add high -- 
                if (addHigh)
                {
                    if (!PotentialLows.Contains(lastLowIdx)) PotentialLows.Add(lastLowIdx);
                    upTrend = true;
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - priorLastLowIdx; i++)
                    {
                        if (High[i] > newHigh)
                        {
                            newHigh = High[i];
                            j = i;
                        }
                    }
                    if (isPreliminaryHigh && CurrentBar - j > lastHighIdx)
                    {
                        vZigZagHigh.Reset(CurrentBar - lastHighIdx);
                        AllPivots[CurrentBar - lastHighIdx] = 0;
                    }
                    vZigZagHigh[j] = newHigh;
                    AllPivots[j] = 1;
                    if (j > 0)
                    {
                        vZigZagHigh.Reset();
                        AllPivots[0] = 0;
                    }
                    currentHigh = newHigh;
                    lastHighIdx = CurrentBar - j;
                    isPreliminaryHigh = true;
                }
                #endregion
                
                #region -- update high --
                else if (updateHigh)
                {
                    vZigZagHigh[0] = High[0];
                    AllPivots[0] = 1;
                    if (firstHighIdx)
                    {
                        vZigZagHigh.Reset(CurrentBar - priorLastHighIdx);
                        AllPivots[CurrentBar - priorLastHighIdx] = 0;
                        if (showDots) AllPivots[CurrentBar - priorLastHighIdx] = 0;
                    }
                    currentHigh = High[0];
                    currentLow = priorCurrentLow;
                    lastHighIdx = CurrentBar;
                    if (isPreliminaryLow)
                    {
                        upTrend = true;
                        vZigZagLow.Reset(CurrentBar - lastLowIdx);

                        AllPivots[CurrentBar - lastLowIdx] = 0;
                        if (showLabels)
                        {
                            RemoveDrawObject("swingLow" + priorSwingHighIdx);
                            LowLabels.Remove(priorSwingHighIdx);
                        }
                        currentLow = priorCurrentLow;
                        lastLowIdx = priorLastLowIdx;
                        isPreliminaryLow = false;
                    }
                }
                #endregion
                
                else vZigZagHigh.Reset();

                #region -- add low --
                if (addLow)
                {
                    if (!PotentialHighs.Contains(lastHighIdx)) PotentialHighs.Add(lastHighIdx);
                    upTrend = false;
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - priorLastHighIdx; i++)
                    {
                        if (Low[i] < newLow)
                        {
                            newLow = Low[i];
                            j = i;
                        }
                    }
                    if (isPreliminaryLow && CurrentBar - j > lastLowIdx) vZigZagLow.Reset(CurrentBar - lastLowIdx);
                    vZigZagLow[j] = newLow;
                    AllPivots[j] = -1;
                    if (j > 0)
                    {
                        vZigZagLow.Reset();
                        AllPivots[0] = 0;
                    }
                    currentLow = newLow;
                    lastLowIdx = CurrentBar - j;
                    isPreliminaryLow = true;
                }
                #endregion

                #region -- update low --
                else if (updateLow)
                {
                    vZigZagLow[0] = Low[0];
                    AllPivots[0] = -1;
                    if (firstLowIdx)
                    {
                        vZigZagLow.Reset(CurrentBar - priorLastLowIdx);
                        AllPivots[CurrentBar - priorLastLowIdx] = 0;
                    }
                    currentLow = Low[0];
                    lastLowIdx = CurrentBar;
                    if (isPreliminaryHigh)
                    {
                        upTrend = false;
                        vZigZagHigh.Reset(CurrentBar - lastHighIdx);
                        AllPivots[CurrentBar - lastHighIdx] = 0;
                        if (showLabels)
                        {
                            RemoveDrawObject("swingHigh" + priorSwingLowIdx);
                            HighLabels.Remove(priorSwingLowIdx);
                        }
                        currentHigh = priorCurrentHigh;
                        lastHighIdx = priorLastHighIdx;
                        isPreliminaryHigh = false;
                    }
                }
                #endregion

                else vZigZagLow.Reset();

                if (firstLowIdx && (addHigh || updateHigh) && (CurrentBar - priorLastLowIdx) >= 0 && (CurrentBar - lastHighIdx) >= 0)
                {
                    int priorHighCount = CurrentBar - priorSwingHighIdx;
                    int highCount = CurrentBar - lastHighIdx;
                    int lowCount = CurrentBar - priorLastLowIdx;
                    int count = lowCount - highCount;
                    double lastLow = Low[lowCount];
                    double thisHigh = High[highCount];

                    for (int i = 0; i < count; i++)
                    {
                        vZigZag[highCount + i] = thisHigh * (count - i) / count + lastLow * i / count;

                        if (currentHigh > High[priorHighCount] + multiplierATR * avgTrueRange[highCount]) LastHigh = "HH";                            
                        else if (currentHigh < High[priorHighCount] - multiplierATR * avgTrueRange[highCount]) LastHigh = "LH";
                        else LastHigh = "DT";

                        if (!HighLabels.ContainsKey(CurrentBar - highCount)) HighLabels.Add(CurrentBar - highCount, LastHigh);
                        else HighLabels[CurrentBar - highCount] = LastHigh;
                    }
                    priorSwingLowIdx = priorLastLowIdx;
                }
                else if (firstHighIdx && (addLow || updateLow) && (CurrentBar - priorLastHighIdx) >= 0 &&(CurrentBar - lastLowIdx) >= 0)
                {
                    int priorLowCount = CurrentBar - priorSwingLowIdx;
                    int lowCount = CurrentBar - lastLowIdx;
                    int highCount = CurrentBar - priorLastHighIdx;
                    int count = highCount - lowCount;
                    double lastHigh = High[highCount];
                    double thisLow = Low[lowCount];

                    for (int i = 0; i < count; i++)
                    {
                        vZigZag[lowCount + i] = thisLow * (count - i) / count + lastHigh * i / count;

                        if (currentLow < Low[priorLowCount] - multiplierATR * avgTrueRange[lowCount]) LastLow = "LL";
                        else if (currentLow > Low[priorLowCount] + multiplierATR * avgTrueRange[lowCount]) LastLow = "HL";
                        else LastLow = "DB";

                        if (!LowLabels.ContainsKey(CurrentBar - lowCount)) LowLabels.Add(CurrentBar - lowCount, LastLow);
                        else LowLabels[CurrentBar - lowCount] = LastLow;
                    }
                    if (lowCount > 0) vZigZag.Reset();
                    priorSwingHighIdx = priorLastHighIdx;
                }
                else vZigZag.Reset();


                #endregion

                #region -- RegCurveFormation --
                try
                {
                    int PeriodValue = 0;

                    if (BarsArray[0].BarsType.BuiltFrom == Data.BarsPeriodType.Tick && BarsArray[0].BarsPeriod.ToString().IndexOf("Range") >= 0)
                    {
                        PeriodValue = Bars.BarsPeriod.Value;
                    }
                    else
                    {
                        // Other Chart
                        PeriodValue = (int)Math.Round(ATR(17)[0] / gbTickSize, 0);
                    }

                    pTicksMove = (int)Math.Round((double)PeriodValue * (pDefiance) / 100, 0);

                    TicksToBreak = (int)Math.Round((double)(PeriodValue * pBreakATR / 100), 0);
                    TicksToBreak = Math.Max(TicksToBreak, 1);

                    CurveLow[0] = 0;
                    CurveLowIdx = 0;
                    CurveHigh[0] = 99999999;
                    CurveHighIdx = 0;

                    foreach (int L in PotentialHighs)
                    {
                        if (CurrentBar - L >= 0)
                        {
                            if (High[0] > High[CurrentBar - L]) PotentialDeletes.Add(L);
                            else if (Low[0] < High[CurrentBar - L] - pTicksMove * gbTickSize)
                            {
                                if (!HighLA.ContainsKey(L)) HighLA.Add(L, High[CurrentBar - L]);
                                else HighLA[L] = High[CurrentBar - L];

                                PotentialDeletes.Add(L);
                            }
                        }
                    }
                    foreach (int L in PotentialDeletes) PotentialHighs.Remove(L);

                    PotentialDeletes.Clear();

                    foreach (KeyValuePair<int, double> L in HighLA)
                    {
                        if (High[0] >= RTTS(L.Value + TicksToBreak * gbTickSize)) DeleteLA.Add(L.Key, L.Value);
                        else
                        {
                            CurveHigh[0] = Math.Min(CurveHigh[0], L.Value);
                            CurveHighIdx = L.Key;
                        }
                    }

                    foreach (KeyValuePair<int, double> L in DeleteLA)
                    {
                        HighLA.Remove(L.Key);
                        HighLF.Add(L.Key, CurrentBars[0]);
                    }

                    DeleteLA.Clear();

                    foreach (int L in PotentialLows)
                    {
                        if (CurrentBar - L >= 0)
                        {
                            if (Low[0] < Low[CurrentBar - L]) PotentialDeletes.Add(L);
                            if (High[0] > Low[CurrentBar - L] + pTicksMove * gbTickSize)
                            {
                                if (!LowLA.ContainsKey(L)) LowLA.Add(L, Low[CurrentBar - L]);
                                else LowLA[L] = Low[CurrentBar - L];
                                PotentialDeletes.Add(L);
                            }
                        }
                    }
                    foreach (int L in PotentialDeletes) PotentialLows.Remove(L);

                    PotentialDeletes.Clear();

                    foreach (KeyValuePair<int, double> L in LowLA)
                    {
                        if (Low[0] <= RTTS(L.Value - TicksToBreak * gbTickSize)) DeleteLA.Add(L.Key, L.Value);
                        else
                        {
                            CurveLow[0] = Math.Max(CurveLow[0], L.Value);
                            CurveLowIdx = L.Key;
                        }
                    }

                    foreach (KeyValuePair<int, double> L in DeleteLA)
                    {
                        LowLA.Remove(L.Key);
                        LowLF.Add(L.Key, CurrentBars[0]);
                    }

                    DeleteLA.Clear();

                    if (Calculate == Calculate.OnBarClose) IsCurrentBar = CurrentBars[0] + 2 == BarsArray[0].Count;
                    else IsCurrentBar = CurrentBars[0] + 1 == BarsArray[0].Count;

                    FinalHigh[0] = High[0];
                    FinalLow[0] = Low[0];

                    CurveBar[0] = Math.Max(lastLowIdx, lastHighIdx);
                    CurveHighZ[0] = CurveHigh[0];
                    CurveLowZ[0] = CurveLow[0];

                    CurveLowIdx = lastLowIdx;
                    CurveHighIdx = lastHighIdx;
                }
                catch { }
                #endregion
            }

            #region -- RegPreProcessing --
            bool allowManipulation = true;

            if (allowManipulation && (BarsInProgress == 2 || this.UseChartBars) && this.GZS != null && this.GZS.Count > 0)
            {
//if(IsDebug) Print("L   3067  ");
                for (int g = 0; g < this.GZS.Count; g++)
                {
                    double processPrice = (GZS[g].Type == GZ_SUPPLY) ? Highs[BarsInProgress][0] : Lows[BarsInProgress][0];
                    this.ProcessZone(GZS[g], processPrice, Opens[BarsInProgress][0], Times[BarsInProgress][0], CurrentBars[BarsInProgress]);
                }
            }
            #endregion
            if ((BarsInProgress == 2 || this.UseChartBars))
            {
                #region -- RegSDVSystemFormation --
                if (iChartMode1 == ARC_SDVSystem_ZoneMode2.MTF)
                {
                    #region -- RegMTFInitDataSeries --
                    if (bodyHigh == null)  bodyHigh = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (bodyLow == null)   bodyLow = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (bodyRange == null) bodyRange = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
					if (truerange == null) truerange = new Series<double>(SMA(BarsArray[0],1), MaximumBarsLookBack.Infinite);

                    if (allDemandProximal1 == null) allDemandProximal1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandDistal1 == null) allDemandDistal1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandPOC1 == null) allDemandPOC1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandVAH1 == null) allDemandVAH1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandVAL1 == null) allDemandVAL1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandVCT1 == null) allDemandVCT1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandVCB1 == null) allDemandVCB1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (freshDemandProximal1 == null) freshDemandProximal1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandDistal1 == null) freshDemandDistal1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandPOC1 == null) freshDemandPOC1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandVAH1 == null) freshDemandVAH1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandVAL1 == null) freshDemandVAL1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandVCT1 == null) freshDemandVCT1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandVCB1 == null) freshDemandVCB1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (freshSupplyProximal1 == null) freshSupplyProximal1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyDistal1 == null) freshSupplyDistal1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyPOC1 == null) freshSupplyPOC1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyVAH1 == null) freshSupplyVAH1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyVAL1 == null) freshSupplyVAL1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyVCT1 == null) freshSupplyVCT1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyVCB1 == null) freshSupplyVCB1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (allSupplyProximal1 == null) allSupplyProximal1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyDistal1 == null) allSupplyDistal1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyPOC1 == null) allSupplyPOC1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyVAH1 == null) allSupplyVAH1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyVAL1 == null) allSupplyVAL1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyVCT1 == null) allSupplyVCT1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyVCB1 == null) allSupplyVCB1 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (allDemandProximal2 == null) allDemandProximal2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandDistal2 == null) allDemandDistal2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandPOC2 == null) allDemandPOC2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandVAH2 == null) allDemandVAH2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandVAL2 == null) allDemandVAL2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandVCT2 == null) allDemandVCT2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allDemandVCB2 == null) allDemandVCB2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (freshDemandProximal2 == null) freshDemandProximal2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandDistal2 == null) freshDemandDistal2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandPOC2 == null) freshDemandPOC2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandVAH2 == null) freshDemandVAH2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandVAL2 == null) freshDemandVAL2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandVCT2 == null) freshDemandVCT2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshDemandVCB2 == null) freshDemandVCB2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (freshSupplyProximal2 == null) freshSupplyProximal2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyDistal2 == null) freshSupplyDistal2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyPOC2 == null) freshSupplyPOC2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyVAH2 == null) freshSupplyVAH2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyVAL2 == null) freshSupplyVAL2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyVCT2 == null) freshSupplyVCT2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (freshSupplyVCB2 == null) freshSupplyVCB2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (allSupplyProximal2 == null) allSupplyProximal2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyDistal2 == null) allSupplyDistal2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyPOC2 == null) allSupplyPOC2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyVAH2 == null) allSupplyVAH2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyVAL2 == null) allSupplyVAL2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyVCT2 == null) allSupplyVCT2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (allSupplyVCB2 == null) allSupplyVCB2 = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);


                    if (longSignal == null) longSignal = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longPOCSignal == null) longPOCSignal = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longVCSignal == null) longVCSignal = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longVASignal == null) longVASignal = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (shortSignal == null) shortSignal = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortPOCSignal == null) shortPOCSignal = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortVCSignal == null) shortVCSignal = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortVASignal == null) shortVASignal = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (longSignals == null) longSignals = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longPOCSignals == null) longPOCSignals = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longVCSignals == null) longVCSignals = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longVASignals == null) longVASignals = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (shortSignals == null) shortSignals = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortPOCSignals == null) shortPOCSignals = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortVCSignals == null) shortVCSignals = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortVASignals == null) shortVASignals = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (longSignalAll == null) longSignalAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longPOCSignalAll == null) longPOCSignalAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longVCSignalAll == null) longVCSignalAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longVASignalAll == null) longVASignalAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (shortSignalAll == null) shortSignalAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortPOCSignalAll == null) shortPOCSignalAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortVCSignalAll == null) shortVCSignalAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortVASignalAll == null) shortVASignalAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (longSignalsAll == null) longSignalsAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longPOCSignalsAll == null) longPOCSignalsAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longVCSignalsAll == null) longVCSignalsAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (longVASignalsAll == null) longVASignalsAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (shortSignalsAll == null) shortSignalsAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortPOCSignalsAll == null) shortPOCSignalsAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortVCSignalsAll == null) shortVCSignalsAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (shortVASignalsAll == null) shortVASignalsAll = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);

                    if (barType == null) barType = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    if (trend == null) trend = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
					if (ThrustOvershoot == null) ThrustOvershoot = new Series<double>(SMA(BarsArray[BarsInProgress], 1), MaximumBarsLookBack.Infinite);
                    #endregion
                }

//if(IsDebug) Print("L   3100  ");
                #region -- RegInitAlgo --
                if (CurrentBar < 2)
                {
                    bodyHigh[0] = Math.Max(Open[0], Close[0]);
                    bodyLow[0] = Math.Min(Open[0], Close[0]);
                    bodyRange[0] = bodyHigh[0] - bodyLow[0];
                    barType[0] = CONSOLIDATION_BAR_ID;
                    trend[0] = 0.0;

                    allDemandProximal1.Reset();
                    allDemandDistal1.Reset();
                    allDemandPOC1.Reset();
                    allDemandVAH1.Reset();
                    allDemandVAL1.Reset();
                    allDemandVCT1.Reset();
                    allDemandVCB1.Reset();

                    allSupplyProximal1.Reset();
                    allSupplyDistal1.Reset();
                    allSupplyPOC1.Reset();
                    allSupplyVAH1.Reset();
                    allSupplyVAL1.Reset();
                    allSupplyVCT1.Reset();
                    allSupplyVCB1.Reset();

                    freshDemandProximal1.Reset();
                    freshDemandDistal1.Reset();
                    freshDemandPOC1.Reset();
                    freshDemandVAH1.Reset();
                    freshDemandVAL1.Reset();
                    freshDemandVCT1.Reset();
                    freshDemandVCB1.Reset();

                    freshSupplyProximal1.Reset();
                    freshSupplyDistal1.Reset();
                    freshSupplyDistal1.Reset();
                    freshSupplyPOC1.Reset();
                    freshSupplyVAH1.Reset();
                    freshSupplyVAL1.Reset();
                    freshSupplyVCT1.Reset();
                    freshSupplyVCB1.Reset();

                    allDemandProximal2.Reset();
                    allDemandDistal2.Reset();
                    allDemandPOC2.Reset();
                    allDemandVAH2.Reset();
                    allDemandVAL2.Reset();
                    allDemandVCT2.Reset();
                    allDemandVCB2.Reset();

                    allSupplyProximal2.Reset();
                    allSupplyDistal2.Reset();
                    allSupplyPOC2.Reset();
                    allSupplyVAH2.Reset();
                    allSupplyVAL2.Reset();
                    allSupplyVCT2.Reset();
                    allSupplyVCB2.Reset();

                    freshDemandProximal2.Reset();
                    freshDemandDistal2.Reset();
                    freshDemandPOC2.Reset();
                    freshDemandVAH2.Reset();
                    freshDemandVAL2.Reset();
                    freshDemandVCT2.Reset();
                    freshDemandVCB2.Reset();

                    freshSupplyProximal2.Reset();
                    freshSupplyDistal2.Reset();
                    freshSupplyDistal2.Reset();
                    freshSupplyPOC2.Reset();
                    freshSupplyVAH2.Reset();
                    freshSupplyVAL2.Reset();
                    freshSupplyVCT2.Reset();
                    freshSupplyVCB2.Reset();

                    longSignal[0] = 0;
                    longPOCSignal[0] = 0;
                    longVCSignal[0] = 0;
                    longVASignal[0] = 0;

                    shortSignal[0] = 0;
                    shortPOCSignal[0] = 0;
                    shortVCSignal[0] = 0;
                    shortVASignal[0] = 0;

                    if (this.iPaintBarsEnabled && iChartMode1 != ARC_SDVSystem_ZoneMode2.MTF)
                    {
                        if (Close[0] > Open[0])
                        {
                            BarBrushes[0] = uptrendFillColor;
                            CandleOutlineBrushes[0] = uptrendColor;
                        }
                        else
                        {
                            BarBrushes[0] = downtrendFillColor;
                            CandleOutlineBrushes[0] = downtrendColor;
                        }
                    }
                    lastBarTimeStamp = sessionIterator.GetTradingDayBeginLocal(Time[0]);//Bars.GetDayBar(0).Time;//Bars.GetTradingDayFromLocal(Time[0]);
                    currentDate = lastBarTimeStamp;
                    return;
                }
                #endregion

                //supply & demand zones
//if(IsDebug) Print("L   3200  ");
                bodyHigh[0] = Math.Max(Open[0], Close[0]);
                bodyLow[0] = Math.Min(Open[0], Close[0]);
                bodyRange[0] = bodyHigh[0] - bodyLow[0];
				if(CurrentBars[0]>0) truerange[0] = Math.Max(Math.Abs(Lows[0][0] - Closes[0][1]), Math.Max(Highs[0][0] - Lows[0][0], Math.Abs(Highs[0][0] - Closes[0][1])));

//if(IsDebug) Print("L   3300  ");
                #region -- RegFirstTickOfBar --

                #region -- Need 100 bars only {in comment} --
                //if (IsFirstTickOfBar)
                //{
                //    lastBarTimeStamp = sessionIterator.GetTradingDayBeginLocal(Time[0]);//Bars.GetDayBar(0).Time;//Bars.GetTradingDayFromLocal(Time[0]);
                //    if (sessionBar >= 100)//AJOUT
                //    {
                //        noPublicHoliday = true;
                //        for (int i = 0; i < 48; i++)
                //            if (publicHoliday[i] == currentDate)
                //                noPublicHoliday = false;
                //        if (noPublicHoliday)
                //        {
                //            avgSessionBody = avgCurrentBody * (sessionBar - 1) / sessionBar + bodyRange[1] / sessionBar;
                //            firstSessionComplete = true;//AJOUT
                //            if (!init)
                //            {
                //                if (firstSessionComplete) init = true;
                //                firstSessionComplete = true;
                //            }
                //        }
                //        avgCurrentBody = 0.0;
                //        sessionBar = 1;
                //        currentDate = lastBarTimeStamp;
                //    }
                //    else
                //    {
                //        avgCurrentBody = avgCurrentBody * (sessionBar - 1) / sessionBar + bodyRange[1] / sessionBar;
                //        sessionBar = sessionBar + 1;
                //    }
                //}
                #endregion

                if (IsFirstTickOfBar)
                {
                    lastBarTimeStamp = sessionIterator.GetTradingDayBeginLocal(Time[0]);
                    if (lastBarTimeStamp != currentDate)
                    {
                        avgSessionBody = avgCurrentBody * (sessionBar - 1) / sessionBar + bodyRange[1] / sessionBar;
                        if (!init)
                        {
                            if (firstSessionComplete) init = true;
                            firstSessionComplete = true;
                        }
                        avgCurrentBody = 0.0;
                        sessionBar = 1;
                        currentDate = lastBarTimeStamp;
                    }
                    else
                    {
                        avgCurrentBody = avgCurrentBody * (sessionBar - 1) / sessionBar + bodyRange[1] / sessionBar;
                        sessionBar = sessionBar + 1;
                    }
					if(!firstSessionComplete) Draw.TextFixed(this,"not enough data","SDVSystem needs at least 1-day of data, please add more data",TextPosition.Center);
					else RemoveDrawObject("not enough data");
                }
                #endregion

                if (!init)
                {
//if(IsDebug) Print("L   3400  ");
                    #region -- RegInitDataSeries --
                    barType[0] = CONSOLIDATION_BAR_ID;
                    trend[0] = 0.0;

                    allDemandProximal1.Reset();
                    allDemandDistal1.Reset();
                    allDemandPOC1.Reset();
                    allDemandVAH1.Reset();
                    allDemandVAL1.Reset();
                    allDemandVCT1.Reset();
                    allDemandVCB1.Reset();

                    allSupplyProximal1.Reset();
                    allSupplyDistal1.Reset();
                    allSupplyPOC1.Reset();
                    allSupplyVAH1.Reset();
                    allSupplyVAL1.Reset();
                    allSupplyVCT1.Reset();
                    allSupplyVCB1.Reset();

                    freshDemandProximal1.Reset();
                    freshDemandDistal1.Reset();
                    freshDemandPOC1.Reset();
                    freshDemandVAH1.Reset();
                    freshDemandVAL1.Reset();
                    freshDemandVCT1.Reset();
                    freshDemandVCB1.Reset();

                    freshSupplyProximal1.Reset();
                    freshSupplyDistal1.Reset();
                    freshSupplyDistal1.Reset();
                    freshSupplyPOC1.Reset();
                    freshSupplyVAH1.Reset();
                    freshSupplyVAL1.Reset();
                    freshSupplyVCT1.Reset();
                    freshSupplyVCB1.Reset();

                    allDemandProximal2.Reset();
                    allDemandDistal2.Reset();
                    allDemandPOC2.Reset();
                    allDemandVAH2.Reset();
                    allDemandVAL2.Reset();
                    allDemandVCT2.Reset();
                    allDemandVCB2.Reset();

                    allSupplyProximal2.Reset();
                    allSupplyDistal2.Reset();
                    allSupplyPOC2.Reset();
                    allSupplyVAH2.Reset();
                    allSupplyVAL2.Reset();
                    allSupplyVCT2.Reset();
                    allSupplyVCB2.Reset();

                    freshDemandProximal2.Reset();
                    freshDemandDistal2.Reset();
                    freshDemandPOC2.Reset();
                    freshDemandVAH2.Reset();
                    freshDemandVAL2.Reset();
                    freshDemandVCT2.Reset();
                    freshDemandVCB2.Reset();

                    freshSupplyProximal2.Reset();
                    freshSupplyDistal2.Reset();
                    freshSupplyDistal2.Reset();
                    freshSupplyPOC2.Reset();
                    freshSupplyVAH2.Reset();
                    freshSupplyVAL2.Reset();
                    freshSupplyVCT2.Reset();
                    freshSupplyVCB2.Reset();

                    longSignal[0] = 0.0;
                    longPOCSignal[0] = 0.0;
                    longVCSignal[0] = 0.0;
                    longVASignal[0] = 0.0;

                    longSignals[0] = 0.0;
                    longPOCSignals[0] = 0.0;
                    longVCSignals[0] = 0.0;
                    longVASignals[0] = 0.0;

                    shortSignal[0] = 0.0;
                    shortPOCSignal[0] = 0.0;
                    shortVCSignal[0] = 0.0;
                    shortVASignal[0] = 0.0;

                    shortSignals[0] = 0.0;
                    shortPOCSignals[0] = 0.0;
                    shortVCSignals[0] = 0.0;
                    shortVASignals[0] = 0.0;

                    longSignalAll[0] = 0.0;
                    longPOCSignalAll[0] = 0.0;
                    longVCSignalAll[0] = 0.0;
                    longVASignalAll[0] = 0.0;

                    longSignalsAll[0] = 0.0;
                    longPOCSignalsAll[0] = 0.0;
                    longVCSignalsAll[0] = 0.0;
                    longVASignalsAll[0] = 0.0;

                    shortSignalAll[0] = 0.0;
                    shortPOCSignalAll[0] = 0.0;
                    shortVCSignalAll[0] = 0.0;
                    shortVASignalAll[0] = 0.0;

                    shortSignalsAll[0] = 0.0;
                    shortPOCSignalsAll[0] = 0.0;
                    shortVCSignalsAll[0] = 0.0;
                    shortVASignalsAll[0] = 0.0;
                    #endregion

                    return;
                }
//if(IsFirstTickOfBar && CurrentBars[0] > BarsArray[0].Count-5){
//	foreach(var ggz in GZS) Print("GZS: "+ggz.ID+"   "+ggz.ToString());
//}
                if (Calculate == Calculate.OnBarClose || IsFirstTickOfBar)
                {
//if(IsDebug) Print("L   4796");
                    #region -- RegRepaintRemove --
                    #region Repainting and removing demand zones
                    for (int i = 0; i < demandIndex; i++)
                    {
                        if (Low[1] < demandLower[i])
                        {
                            if (showDemandZones && showExpiredZones)
                                Draw.Rectangle(this, "demand" + demandFirstBar[i], false, 0, demandUpper[i], CurrentBar - demandFirstBar[i], demandLower[i], demandColor, demandFillColor, opacity);
                            else if (showDemandZones)
                                RemoveDrawObject("demand" + demandFirstBar[i]);
                            for (int j = i; j < demandIndex - 1; j++)
                            {
                                demandFirstBar[j] = demandFirstBar[j + 1];
                                demandLastBar[j] = demandLastBar[j + 1];
                                demandUpper[j] = demandUpper[j + 1];
                                demandLower[j] = demandLower[j + 1];
                                demandPOC[j] = demandPOC[j + 1];
                                demandPOCHit[j] = demandPOCHit[j + 1];
                                demandPOCHits[j] = demandPOCHits[j + 1];
                                demandVAH[j] = demandVAH[j + 1];
                                demandVAL[j] = demandVAL[j + 1];
                                demandVAHit[j] = demandVAHit[j + 1];
                                demandVAHits[j] = demandVAHits[j + 1];
                                demandVCT[j] = demandVCT[j + 1];
                                demandVCB[j] = demandVCB[j + 1];
                                demandVCHit[j] = demandVCHit[j + 1];
                                demandVCHits[j] = demandVCHits[j + 1];
                                demandFresh[j] = demandFresh[j + 1];
                                demandVA[j] = demandVA[j + 1];
                                demandVC[j] = demandVC[j + 1];
                            }
                            demandIndex = demandIndex - 1;
                            i = i - 1;
                        }
                        else
                        {
                            if (Low[1] < demandUpper[i] + 0.5 * gbTickSize) demandFresh[i] = false;
                            if (IsFirstTickOfBar)
                            {
                                demandLastBar[i] = demandLastBar[i] + 1;
                                if (showDemandZones && (showExpiredZones || i < zoneCount || demandUpper[i] >= demandUpper[Math.Min(zoneCount - 1, demandIndex - 1)]))
                                {
                                    if (demandFresh[i]) Draw.Rectangle(this, "demand" + demandFirstBar[i], false, CurrentBar - demandLastBar[i], demandUpper[i], CurrentBar - demandFirstBar[i], demandLower[i], freshDemandColor, freshDemandFillColor, opacity);
                                    else Draw.Rectangle(this, "demand" + demandFirstBar[i], false, CurrentBar - demandLastBar[i], demandUpper[i], CurrentBar - demandFirstBar[i], demandLower[i], demandColor, demandFillColor, opacity);
                                }
                                else if (showDemandZones) RemoveDrawObject("demand" + demandFirstBar[i]);
                            }
                        }
                    }
                    #endregion
//if(IsDebug) Print("L   4847");

                    #region Repainting and removing supply zones
                    for (int i = 0; i < supplyIndex; i++)
                    {
                        if (High[1] > supplyUpper[i])
                        {
                            if (showSupplyZones && showExpiredZones)
                                Draw.Rectangle(this, string.Format("supply{0}", supplyFirstBar[i]), false, 0, supplyUpper[i], CurrentBar - supplyFirstBar[i], supplyLower[i], supplyColor, supplyFillColor, opacity);
                            else if (showSupplyZones)
                                RemoveDrawObject(string.Format("supply{0}", supplyFirstBar[i]));
                            for (int j = i; j < supplyIndex - 1; j++)
                            {
                                supplyFirstBar[j] = supplyFirstBar[j + 1];
                                supplyLastBar[j] = supplyLastBar[j + 1];
                                supplyUpper[j] = supplyUpper[j + 1];
                                supplyLower[j] = supplyLower[j + 1];
                                supplyPOC[j] = supplyPOC[j + 1];
                                supplyPOCHit[j] = supplyPOCHit[j + 1];
                                supplyPOCHits[j] = supplyPOCHits[j + 1];
                                supplyVAH[j] = supplyVAH[j + 1];
                                supplyVAL[j] = supplyVAL[j + 1];
                                supplyVAHit[j] = supplyVAHit[j + 1];
                                supplyVAHits[j] = supplyVAHits[j + 1];
                                supplyVCT[j] = supplyVCT[j + 1];
                                supplyVCB[j] = supplyVCB[j + 1];
                                supplyVCHit[j] = supplyVCHit[j + 1];
                                supplyVCHits[j] = supplyVCHits[j + 1];
                                supplyFresh[j] = supplyFresh[j + 1];
                                supplyVA[j] = supplyVA[j + 1];
                                supplyVC[j] = supplyVC[j + 1];
                            }
                            supplyIndex = supplyIndex - 1;
                            i = i - 1;
                        }
                        else
                        {
                            if (High[1] > supplyLower[i] - 0.5 * gbTickSize)
                                supplyFresh[i] = false;
                            if (IsFirstTickOfBar)
                            {
                                supplyLastBar[i] = supplyLastBar[i] + 1;
                                if (showSupplyZones && (showExpiredZones || i < zoneCount || supplyLower[i] <= supplyLower[Math.Min(zoneCount - 1, supplyIndex - 1)]))
                                {
                                    if (supplyFresh[i]) Draw.Rectangle(this, string.Format("supply{0}", supplyFirstBar[i]), false, CurrentBar - supplyLastBar[i], supplyUpper[i], CurrentBar - supplyFirstBar[i], supplyLower[i], freshSupplyColor, freshSupplyFillColor, opacity);
                                    else Draw.Rectangle(this, string.Format("supply{0}", supplyFirstBar[i]), false, CurrentBar - supplyLastBar[i], supplyUpper[i], CurrentBar - supplyFirstBar[i], supplyLower[i], supplyColor, supplyFillColor, opacity);
                                }
                                else if (showSupplyZones) RemoveDrawObject(string.Format("supply{0}", supplyFirstBar[i]));
                            }
                        }
                    }
                    #endregion
                    #endregion

					#region -- RegAddZones --
//if(IsDebug) {
//	Print("barType[1] = 4: "+barType[1]);
//	Print("priorConsolidationIndex >0  : "+priorConsolidationIndex);
//	Print("trend[2] !=0  : "+trend[2]);
//}
                    #region Adding new demand zone
                    if (barType[1] == THRUST_UPBAR_ID && priorConsolidationIndex > 0 && trend[2] != 0)
                    {
//if(IsDebug) Print("L 3590  Adding demand zone");
                        if (trend[2] == 1) 
							distalLine = MIN(Low, priorConsolidationIndex + 1)[1];
                        else if (trend[2] == -1) 
							distalLine = MIN(Low, priorConsolidationIndex + 2)[1];
                        CalculateValueArea(priorConsolidationIndex, 2, out valueAreaHigh, out valueAreaLow);
                        proximalLine = valueAreaHigh + gbTickSize;
                        distalLineOL = valueAreaLow;

                        if ((demandIndex == 0 || distalLineOL > demandUpper[0]) && (proximalLine - distalLine) < multiplier * avgSessionBody)
                        {
                            demandIndex = demandIndex + 1;
                            if (demandIndex > demandArraySize)
                            {
                                demandFirstBar.Add(0);
                                demandLastBar.Add(0);
                                demandUpper.Add(0.0);
                                demandLower.Add(0.0);
                                demandPOC.Add(0.0);
                                demandPOCHit.Add(0.0);
                                demandPOCHits.Add(0.0);
                                demandVAH.Add(0.0);
                                demandVAL.Add(0.0);
                                demandVAHit.Add(0.0);
                                demandVAHits.Add(0.0);
                                demandVCT.Add(0.0);
                                demandVCB.Add(0.0);
                                demandVCHit.Add(0.0);
                                demandVCHits.Add(0.0);
                                demandVC.Add(false);
                                demandVA.Add(false);
                                demandFresh.Add(true);
                                demandArraySize = demandArraySize + 1;
                            }
                            for (int i = demandIndex - 1; i > 0; i--)
                            {
                                demandFirstBar[i] = demandFirstBar[i - 1];
                                demandLastBar[i]  = demandLastBar[i - 1];
                                demandUpper[i]    = demandUpper[i - 1];
                                demandLower[i]    = demandLower[i - 1];
                                demandPOC[i]      = demandPOC[i - 1];
                                demandPOCHit[i]   = demandPOCHit[i - 1];
                                demandPOCHits[i]  = demandPOCHits[i - 1];
                                demandVAH[i]    = demandVAH[i - 1];
                                demandVAL[i]    = demandVAL[i - 1];
                                demandVAHit[i]  = demandVAHit[i - 1];
                                demandVAHits[i] = demandVAHits[i - 1];
                                demandVCT[i]    = demandVCT[i - 1];
                                demandVCB[i]    = demandVCB[i - 1];
                                demandVCHit[i]  = demandVCHit[i - 1];
                                demandVCHits[i] = demandVCHits[i - 1];
                                demandFresh[i]  = demandFresh[i - 1];
                                demandVC[i]     = demandVC[i - 1];
                                demandVA[i] = demandVA[i - 1];
                            }
                            if (trend[2] == 1) 
								demandFirstBar[0] = CurrentBar - 1 - priorConsolidationIndex;
                            else if (trend[2] == -1)
								demandFirstBar[0] = CurrentBar - 2 - priorConsolidationIndex;
                            demandLastBar[0] = CurrentBar + 256;
                            demandUpper[0] = proximalLine;
                            demandLower[0] = distalLine;
                            demandFresh[0] = true;
                            if (showDemandZones) Draw.Rectangle(this, string.Format("demand{0}", demandFirstBar[0]), false, CurrentBar - demandLastBar[0], demandUpper[0], CurrentBar - demandFirstBar[0], demandLower[0], freshDemandColor, freshDemandFillColor, opacity);
                            if (allowManipulation)
                            {
//if(IsDebug) Print(4975);
                                bool created =
                                    this.CreateZone(
                                        GZ_DEMAND,
                                        CurrentBar - demandFirstBar[0],
										CurrentBar - 1,
										ThrustOvershoot[1],
                                        Instruments[0].MasterInstrument.RoundToTickSize(demandUpper[0]),
                                        Instruments[0].MasterInstrument.RoundToTickSize(demandLower[0]));

                                demandVA[0] = false;
                                demandVC[0] = false;
                                if (created || (!created && Calculate == Calculate.OnBarClose))
                                {
                                    if (this.GZS[this.GZS.Count - 1].Hist.GetTotalBins() >= 1)
                                    {
                                        demandVA[0] = true;
                                        demandPOC[0] = this.GZS[this.GZS.Count - 1].Hist.POC;
                                        demandPOCHit[0] = 0.0;
                                        demandPOCHits[0] = 0.0;
                                        demandVAH[0] = this.GZS[this.GZS.Count - 1].Hist.VAH;
                                        demandVAL[0] = this.GZS[this.GZS.Count - 1].Hist.VAL;
                                        demandVAHit[0] = 0.0;
                                        demandVAHits[0] = 0.0;
                                    }

                                    if (this.GZS[this.GZS.Count - 1].Hist.GetTotalBins() >= 3)
                                    {
                                        demandVC[0] = true;
                                        demandVCT[0] = this.GZS[this.GZS.Count - 1].Hist.VolumeClusterTop;
                                        demandVCB[0] = this.GZS[this.GZS.Count - 1].Hist.VolumeClusterBottom;
                                        demandVCHit[0] = 0.0;
                                        demandVCHits[0] = 0.0;
                                    }
                                }
                            }
                        }
                    }
                    #endregion

//if(IsDebug) Print("L   3690");
                    #region Adding new supply zone
                    if (barType[1] == THRUST_DOWNBAR_ID && priorConsolidationIndex > 0 && trend[2] != 0)
                    {
//if(IsDebug) Print("L 3693  Adding supply zone");
                        if (trend[2] == -1) 
							distalLine = MAX(High, priorConsolidationIndex + 1)[1];
                        else if (trend[2] == 1) 
							distalLine = MAX(High, priorConsolidationIndex + 2)[1];
                        CalculateValueArea(priorConsolidationIndex, 2, out valueAreaHigh, out valueAreaLow);
                        proximalLine = valueAreaLow - gbTickSize;
                        distalLineOL = valueAreaHigh;

                        if ((supplyIndex == 0 || distalLineOL < supplyLower[0]) && (distalLine - proximalLine) < multiplier * avgSessionBody)
                        {
                            supplyIndex = supplyIndex + 1;
                            if (supplyIndex > supplyArraySize)
                            {
                                supplyFirstBar.Add(0);
                                supplyLastBar.Add(0);
                                supplyUpper.Add(0.0);
                                supplyLower.Add(0.0);
                                supplyPOC.Add(0.0);
                                supplyPOCHit.Add(0.0);
                                supplyPOCHits.Add(0.0);
                                supplyVAH.Add(0.0);
                                supplyVAL.Add(0.0);
                                supplyVAHit.Add(0.0);
                                supplyVAHits.Add(0.0);
                                supplyVCT.Add(0.0);
                                supplyVCB.Add(0.0);
                                supplyVCHit.Add(0.0);
                                supplyVCHits.Add(0.0);
                                supplyFresh.Add(true);
                                supplyVA.Add(false);
                                supplyVC.Add(false);
                                supplyArraySize = supplyArraySize + 1;
                            }
                            for (int i = supplyIndex - 1; i > 0; i--)
                            {
                                supplyFirstBar[i] = supplyFirstBar[i - 1];
                                supplyLastBar[i] = supplyLastBar[i - 1];
                                supplyUpper[i] = supplyUpper[i - 1];
                                supplyLower[i] = supplyLower[i - 1];
                                supplyPOC[i] = supplyPOC[i - 1];
                                supplyPOCHit[i] = supplyPOCHit[i - 1];
                                supplyPOCHits[i] = supplyPOCHits[i - 1];
                                supplyVAH[i] = supplyVAH[i - 1];
                                supplyVAL[i] = supplyVAL[i - 1];
                                supplyVAHit[i] = supplyVAHit[i - 1];
                                supplyVAHits[i] = supplyVAHits[i - 1];
                                supplyVCT[i] = supplyVCT[i - 1];
                                supplyVCB[i] = supplyVCB[i - 1];
                                supplyVCHit[i] = supplyVCHit[i - 1];
                                supplyVCHits[i] = supplyVCHits[i - 1];
                                supplyFresh[i] = supplyFresh[i - 1];
                                supplyVA[i] = supplyVA[i - 1];
                                supplyVC[i] = supplyVC[i - 1];
                            }
                            if (trend[2] == -1)
                                supplyFirstBar[0] = CurrentBar - 1 - priorConsolidationIndex;
                            else if (trend[2] == 1)
                                supplyFirstBar[0] = CurrentBar - 2 - priorConsolidationIndex;
                            supplyLastBar[0] = CurrentBar + 256;
                            supplyUpper[0] = distalLine;
                            supplyLower[0] = proximalLine;
                            supplyFresh[0] = true;
                            if (showSupplyZones) Draw.Rectangle(this, string.Format("supply{0}", supplyFirstBar[0]), false, CurrentBar - supplyLastBar[0], supplyUpper[0], CurrentBar - supplyFirstBar[0], supplyLower[0], freshSupplyColor, freshSupplyFillColor, opacity);
                            if (allowManipulation)
                            {
//if(IsDebug) Print(5085);
                                bool created =
                                    this.CreateZone(
                                        GZ_SUPPLY,
                                        CurrentBar - supplyFirstBar[0],
										CurrentBar - 1,
										ThrustOvershoot[1],
                                        Instruments[0].MasterInstrument.RoundToTickSize(supplyUpper[0]),
                                        Instruments[0].MasterInstrument.RoundToTickSize(supplyLower[0]));

                                supplyVA[0] = false;
                                supplyVC[0] = false;
                                if (created || (!created && Calculate == Calculate.OnBarClose))
                                {
                                    if (this.GZS[this.GZS.Count - 1].Hist.GetTotalBins() >= 1)
                                    {
                                        supplyVA[0] = true;
                                        supplyPOC[0] = this.GZS[this.GZS.Count - 1].Hist.POC;
                                        supplyPOCHit[0] = 0.0;
                                        supplyPOCHits[0] = 0.0;
                                        supplyVAH[0] = this.GZS[this.GZS.Count - 1].Hist.VAH;
                                        supplyVAL[0] = this.GZS[this.GZS.Count - 1].Hist.VAL;
                                        supplyVAHit[0] = 0.0;
                                        supplyVAHits[0] = 0.0;
                                    }

                                    if (this.GZS[this.GZS.Count - 1].Hist.GetTotalBins() >= 3)
                                    {
                                        supplyVC[0] = true;
                                        supplyVCT[0] = this.GZS[this.GZS.Count - 1].Hist.VolumeClusterTop;
                                        supplyVCB[0] = this.GZS[this.GZS.Count - 1].Hist.VolumeClusterBottom;
                                        supplyVCHit[0] = 0.0;
                                        supplyVCHits[0] = 0.0;
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    #endregion
//if(IsDebug) Print("L   3796");

                    #region -- RegLayeringSignals --

					#region Storing proximal and distal lines of two layers of supply & demand zones closest to price
                    if (demandIndex > 0)
                    {
                        allDemandProximal1[0] = demandUpper[0];
                        allDemandDistal1[0] = demandLower[0];
                        allDemandPOC1[0] = demandPOC[0];
                        allDemandVAH1[0] = demandVAH[0];
                        allDemandVAL1[0] = demandVAL[0];
                        allDemandVCT1[0] = demandVCT[0];
                        allDemandVCB1[0] = demandVCB[0];
                    }
                    else
                    {
                        allDemandProximal1.Reset();
                        allDemandDistal1.Reset();
                        allDemandPOC1.Reset();
                        allDemandVAH1.Reset();
                        allDemandVAL1.Reset();
                        allDemandVCT1.Reset();
                        allDemandVCB1.Reset();
                    }

                    if (demandIndex > 1)
                    {
                        allDemandProximal2[0] = demandUpper[1];
                        allDemandDistal2[0] = demandLower[1];
                        allDemandPOC2[0] = demandPOC[1];
                        allDemandVAH2[0] = demandVAH[1];
                        allDemandVAL2[0] = demandVAL[1];
                        allDemandVCT2[0] = demandVCT[1];
                        allDemandVCB2[0] = demandVCB[1];
                    }
                    else
                    {
                        allDemandProximal2.Reset();
                        allDemandDistal2.Reset();
                        allDemandPOC2.Reset();
                        allDemandVAH2.Reset();
                        allDemandVAL2.Reset();
                        allDemandVCT2.Reset();
                        allDemandVCB2.Reset();
                    }

                    if (supplyIndex > 0)
                    {
                        allSupplyProximal1[0] = supplyLower[0];
                        allSupplyDistal1[0] = supplyUpper[0];
                        allSupplyPOC1[0] = supplyPOC[0];
                        allSupplyVAH1[0] = supplyVAH[0];
                        allSupplyVAL1[0] = supplyVAL[0];
                        allSupplyVCT1[0] = supplyVCT[0];
                        allSupplyVCB1[0] = supplyVCB[0];
                    }
                    else
                    {
                        allSupplyProximal1.Reset();
                        allSupplyDistal1.Reset();
                        allSupplyPOC1.Reset();
                        allSupplyVAH1.Reset();
                        allSupplyVAL1.Reset();
                        allSupplyVCT1.Reset();
                        allSupplyVCB1.Reset();
                    }

                    if (supplyIndex > 1)
                    {
                        allSupplyProximal2[0] = supplyLower[1];
                        allSupplyDistal2[0] = supplyUpper[1];
                        allSupplyPOC2[0] = supplyPOC[1];
                        allSupplyVAH2[0] = supplyVAH[1];
                        allSupplyVAL2[0] = supplyVAL[1];
                        allSupplyVCT2[0] = supplyVCT[1];
                        allSupplyVCB2[0] = supplyVCB[1];
                    }
                    else
                    {
                        allSupplyProximal2.Reset();
                        allSupplyDistal2.Reset();
                        allSupplyPOC2.Reset();
                        allSupplyVAH2.Reset();
                        allSupplyVAL2.Reset();
                        allSupplyVCT2.Reset();
                        allSupplyVCB2.Reset();
                    }

                    for (int i = 0; i < demandIndex; i++)
                    {
                        if (demandFresh[i])
                        {
                            freshDemandProximal1[0] = demandUpper[i];
                            freshDemandDistal1[0] = demandLower[i];
                            freshDemandPOC1[0] = demandPOC[i];
                            freshDemandVAH1[0] = demandVAH[i];
                            freshDemandVAL1[0] = demandVAL[i];
                            freshDemandVCT1[0] = demandVCT[i];
                            freshDemandVCB1[0] = demandVCB[i];
                            for (int j = i + 1; j < demandIndex; j++)
                            {
                                if (demandFresh[j])
                                {
                                    freshDemandProximal2[0] = demandUpper[j];
                                    freshDemandDistal2[0] = demandLower[j];
                                    freshDemandPOC2[0] = demandPOC[j];
                                    freshDemandVAH2[0] = demandVAH[j];
                                    freshDemandVAL2[0] = demandVAL[j];
                                    freshDemandVCT2[0] = demandVCT[j];
                                    freshDemandVCB2[0] = demandVCB[j];
                                    break;
                                }
                                if (j == demandIndex - 1)
                                {
                                    freshDemandProximal2.Reset();
                                    freshDemandDistal2.Reset();
                                    freshDemandPOC2.Reset();
                                    freshDemandVAH2.Reset();
                                    freshDemandVAL2.Reset();
                                    freshDemandVCT2.Reset();
                                    freshDemandVCB2.Reset();
                                }
                            }
                            break;
                        }
                        if (i == demandIndex - 1)
                        {
                            freshDemandProximal1.Reset();
                            freshDemandDistal1.Reset();
                            freshDemandPOC1.Reset();
                            freshDemandVAH1.Reset();
                            freshDemandVAL1.Reset();
                            freshDemandVCT1.Reset();
                            freshDemandVCB1.Reset();

                            freshDemandProximal2.Reset();
                            freshDemandDistal2.Reset();
                            freshDemandPOC2.Reset();
                            freshDemandVAH2.Reset();
                            freshDemandVAL2.Reset();
                            freshDemandVCT2.Reset();
                            freshDemandVCB2.Reset();
                        }
                    }
//Print("   allDemandProximal1: "+allDemandProximal1[0]+"  allDemandProximal2: "+allDemandProximal2[0]);

                    for (int i = 0; i < supplyIndex; i++)
                    {
                        if (supplyFresh[i])
                        {
                            freshSupplyProximal1[0] = supplyLower[i];
                            freshSupplyDistal1[0] = supplyUpper[i];
                            freshSupplyPOC1[0] = supplyPOC[i];
                            freshSupplyVAH1[0] = supplyVAH[i];
                            freshSupplyVAL1[0] = supplyVAL[i];
                            freshSupplyVCT1[0] = supplyVCT[i];
                            freshSupplyVCB1[0] = supplyVCB[i];
                            for (int j = i + 1; j < supplyIndex; j++)
                            {
                                if (supplyFresh[j])
                                {
                                    freshSupplyProximal2[0] = supplyUpper[j];
                                    freshSupplyDistal2[0] = supplyLower[j];
                                    freshSupplyPOC2[0] = supplyPOC[j];
                                    freshSupplyVAH2[0] = supplyVAH[j];
                                    freshSupplyVAL2[0] = supplyVAL[j];
                                    freshSupplyVCT2[0] = supplyVCT[j];
                                    freshSupplyVCB2[0] = supplyVCB[j];
                                    break;
                                }
                                if (j == supplyIndex - 1)
                                {
                                    freshSupplyProximal2.Reset();
                                    freshSupplyDistal2.Reset();
                                    freshSupplyPOC2.Reset();
                                    freshSupplyVAH2.Reset();
                                    freshSupplyVAL2.Reset();
                                    freshSupplyVCT2.Reset();
                                    freshSupplyVCB2.Reset();
                                }
                            }
                            break;
                        }
                        if (i == supplyIndex - 1)
                        {
                            freshSupplyProximal1.Reset();
                            freshSupplyDistal1.Reset();
                            freshSupplyPOC1.Reset();
                            freshSupplyVAH1.Reset();
                            freshSupplyVAL1.Reset();
                            freshSupplyVCT1.Reset();
                            freshSupplyVCB1.Reset();

                            freshSupplyProximal2.Reset();
                            freshSupplyDistal2.Reset();
                            freshSupplyPOC2.Reset();
                            freshSupplyVAH2.Reset();
                            freshSupplyVAL2.Reset();
                            freshSupplyVCT2.Reset();
                            freshSupplyVCB2.Reset();
                        }
                    }
                    #endregion

                    #region Section required for calculating bar types
                    priorConsolidationIndex = consolidationIndex;
                    priorIndex = Math.Max(1, consolidationIndex);
                    avgConsolidationBody = SMA(bodyRange, Math.Max(1, priorConsolidationIndex))[1];
                    consolidationHigh = MAX(High, priorIndex)[1];
                    consolidationLow = MIN(Low, priorIndex)[1];
                    CalculateValueArea(priorIndex, 1, out consolidationVAHigh, out consolidationVALow);
                    #endregion

                    #endregion
                }
//if(IsDebug) Print("L   4012");
                #region -- RegDrawZones --
                // Color change and removal of zones for visuals only
                if (showDemandZones)
                {
                    for (int i = 0; i < demandIndex; i++)
                    {
                        if (!showExpiredZones && Low[0] < demandLower[i]) RemoveDrawObject(string.Format("demand{0}", demandFirstBar[0]));
                        else if (Low[0] < demandUpper[i] + 0.5 * gbTickSize) Draw.Rectangle(this, string.Format("demand{0}", demandFirstBar[0]), false, CurrentBar - demandLastBar[i], demandUpper[i], CurrentBar - demandFirstBar[i], demandLower[i], demandColor, demandFillColor, opacity);
                    }
                }
                if (showSupplyZones)
                {
                    for (int i = 0; i < supplyIndex; i++)
                    {
                        if (!showExpiredZones && High[0] > supplyUpper[i]) RemoveDrawObject(string.Format("supply{0}", supplyFirstBar[i]));
                        else if (High[0] > supplyLower[i] - 0.5 * gbTickSize) Draw.Rectangle(this, string.Format("supply{0}", supplyFirstBar[i]), false, CurrentBar - supplyLastBar[i], supplyUpper[i], CurrentBar - supplyFirstBar[i], supplyLower[i], supplyColor, supplyFillColor, opacity);
                    }
                }
                #endregion

                #region -- RegBarTypes --
                // Identifying bar types
				ThrustOvershoot[0] = double.MinValue;
                #region -- leg up --
                if (Close[0] > Open[0] && bodyRange[0] >= 0.5 * Range()[0])
                {
                    #region breakout after consolidation
                    if (barType[1] == CONSOLIDATION_BAR_ID && ((!applyThrustFilter && Close[0] > consolidationVAHigh) || (applyThrustFilter && Close[0] > consolidationHigh))
                        && (!applyRangeFilter || (bodyRange[0] > avgConsolidationBody && bodyRange[0] > avgSessionBody)))
                    {
                        barType[0] = THRUST_UPBAR_ID;
						ThrustOvershoot[0] = Close[0] - consolidationHigh;
//Print(Time[0].ToString()+"  thrust up:  "+ThrustOvershoot[0]);
                        trend[0] = 1.0;
                        if (this.iPaintBarsEnabled && iChartMode1 != ARC_SDVSystem_ZoneMode2.MTF)
                        {
                            BarBrushes[0] = upthrustFillColor;
                            CandleOutlineBrushes[0] = upthrustColor;
                        }
                        consolidationIndex = 0;
                    }
                    #endregion

                    #region reversal or continuation
                    else if ((!applyThrustFilter && Close[0] > bodyHigh[1]) || (applyThrustFilter && Close[0] > High[1]))
                    {
                        barType[0] = REV_CONTINUE_UPBAR_ID;
                        trend[0] = 1.0;
                        if (this.iPaintBarsEnabled && iChartMode1 != ARC_SDVSystem_ZoneMode2.MTF)
                        {
                            BarBrushes[0] = uptrendFillColor;
                            CandleOutlineBrushes[0] = uptrendColor;
                        }
                        consolidationIndex = 0;
                    }
                    #endregion

                    #region simple leg up
                    else
                    {
                        barType[0] = SIMPLE_UPBAR_ID;
                        trend[0] = 1.0; // changed from trend.Set(trend[1]);
                        if (this.iPaintBarsEnabled && iChartMode1 != ARC_SDVSystem_ZoneMode2.MTF)
                        {
                            BarBrushes[0] = uptrendFillColor;
                            CandleOutlineBrushes[0] = uptrendColor;
                        }
                        consolidationIndex = 0;
                    }
                    #endregion
                }
                #endregion

                #region -- leg down --
                else if (Close[0] < Open[0] && bodyRange[0] >= 0.5 * Range()[0])
                {
                    #region breakout after consolidation
                    if (barType[1] == CONSOLIDATION_BAR_ID && ((!applyThrustFilter && Close[0] < consolidationVALow) || (applyThrustFilter && Close[0] < consolidationLow))
                        && (!applyRangeFilter || (bodyRange[0] > avgConsolidationBody && bodyRange[0] > avgSessionBody)))
                    {
                        barType[0] = THRUST_DOWNBAR_ID;
						ThrustOvershoot[0] = consolidationLow - Close[0];
//Print(Time[0].ToString()+"  thrust down:  "+ThrustOvershoot[0]);
                        trend[0] = -1.0;
                        if (this.iPaintBarsEnabled && iChartMode1 != ARC_SDVSystem_ZoneMode2.MTF)
                        {
                            BarBrushes[0] = downthrustFillColor;
                            CandleOutlineBrushes[0] = downthrustColor;
                        }
                        consolidationIndex = 0;
                    }
                    #endregion

                    #region reversal or continuation
                    else if ((!applyThrustFilter && Close[0] < bodyLow[1]) || (applyThrustFilter && Close[0] < Low[1]))
                    {
                        barType[0] = REV_CONTINUE_DOWNBAR_ID;
                        trend[0] = -1.0;
                        if (this.iPaintBarsEnabled && iChartMode1 != ARC_SDVSystem_ZoneMode2.MTF)
                        {
                            BarBrushes[0] = downtrendFillColor;
                            CandleOutlineBrushes[0] = downtrendColor;
                        }
                        consolidationIndex = 0;
                    }
                    #endregion

                    #region simple leg down
                    else
                    {
                        barType[0] = SIMPLE_DOWNBAR_ID;
                        trend[0] = -1.0; // changed from trend.Set(trend[1]);
                        if (this.iPaintBarsEnabled && iChartMode1 != ARC_SDVSystem_ZoneMode2.MTF)
                        {
                            BarBrushes[0] = downtrendFillColor;
                            CandleOutlineBrushes[0] = downtrendColor;
                        }
                        consolidationIndex = 0;
                    }
                    #endregion
                }
                #endregion

                else
                {
                    barType[0] = CONSOLIDATION_BAR_ID;
                    trend[0] = trend[1];
                    if (this.iPaintBarsEnabled && iChartMode1 != ARC_SDVSystem_ZoneMode2.MTF)
                    {
                        BarBrushes[0] = Close[0] < Open[0] ? consoliddownFillColor : consolidupFillColor;
                        CandleOutlineBrushes[0] = consolidationColor;
                    }
                    consolidationIndex = priorConsolidationIndex + 1;
                }
                #endregion

                #region -- RegNewZonesCOBCTrue --
                // Early adding of visuals for newly created supply & demand zones in case CalculateOnBarClose == true
                if (Calculate == Calculate.OnBarClose)
                {
                    if (barType[0] == THRUST_UPBAR_ID && priorConsolidationIndex > 0 && trend[1] != 0)
                    {
                        if (trend[1] == 1)       distalLine = MIN(Low, priorConsolidationIndex + 1)[0];
                        else if (trend[1] == -1) distalLine = MIN(Low, priorConsolidationIndex + 2)[0];
                        CalculateValueArea(priorConsolidationIndex, 1, out valueAreaHigh, out valueAreaLow);
                        proximalLine = valueAreaHigh + gbTickSize;
                        distalLineOL = valueAreaLow;

                        if ((demandIndex == 0 || distalLineOL > demandUpper[0]) && (proximalLine - distalLine) < multiplier * avgSessionBody)
                        {
                            if (trend[1] == 1)
                                startBar = CurrentBar - priorConsolidationIndex;
                            else if (trend[1] == -1)
                                startBar = CurrentBar - 1 - priorConsolidationIndex;
                            if (showDemandZones) Draw.Rectangle(this, string.Format("demand{0}", startBar), false, -256, proximalLine, CurrentBar - startBar, distalLine, freshDemandColor, freshDemandFillColor, opacity);
                            if (allowManipulation)
                            {
//if(IsDebug) Print(5500);
                                bool created =
                                    this.CreateZone(
                                        GZ_DEMAND,
                                        CurrentBar - startBar,
										CurrentBar,
										ThrustOvershoot[0],
                                        Instruments[0].MasterInstrument.RoundToTickSize(proximalLine),
                                        Instruments[0].MasterInstrument.RoundToTickSize(distalLine));
                            }
                        }
                    }
                    if (barType[0] == THRUST_DOWNBAR_ID && priorConsolidationIndex > 0 && trend[1] != 0)
                    {
                        if (trend[1] == -1)     distalLine = MAX(High, priorConsolidationIndex + 1)[0];
                        else if (trend[1] == 1) distalLine = MAX(High, priorConsolidationIndex + 2)[0];
                        CalculateValueArea(priorConsolidationIndex, 1, out valueAreaHigh, out valueAreaLow);
                        proximalLine = valueAreaLow - gbTickSize;
                        distalLineOL = valueAreaHigh;

                        if ((supplyIndex == 0 || distalLineOL < supplyLower[0]) && (distalLine - proximalLine) < multiplier * avgSessionBody)
                        {
                            if (trend[1] == -1)     startBar = CurrentBar - priorConsolidationIndex;
                            else if (trend[1] == 1) startBar = CurrentBar - 1 - priorConsolidationIndex;
                            if (showSupplyZones) Draw.Rectangle(this, string.Format("supply{0}", startBar), false, -256, distalLine, CurrentBar - startBar, proximalLine, freshSupplyColor, freshSupplyFillColor, opacity);
                            if (allowManipulation)
                            {
                                bool created =
                                    this.CreateZone(
                                        GZ_SUPPLY,
                                        CurrentBar - startBar,
										CurrentBar,
										ThrustOvershoot[0],
                                        Instruments[0].MasterInstrument.RoundToTickSize(distalLine),
                                        Instruments[0].MasterInstrument.RoundToTickSize(proximalLine));
                            }
                        }
                    }
                }
                #endregion

                #region -- RegNormalEntries --

                #region Generating long signals for trade entries, when fresh demand zones are first tested
                if (freshDemandProximal2.IsValidDataPoint(0) && Low[0] < freshDemandProximal2[0] + 0.5 * gbTickSize && Low[0] > freshDemandDistal2[0] - 0.5 * gbTickSize)
                {
                    longSignal[0] = 2.0;
                    longSignals[0] = 2.0;
                    longSignal2Bar = CurrentBar;
                    if (showFreshSignals && !showAllSignals)
                    {
                        Draw.Text(this, string.Format("long1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("long2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (freshDemandProximal1.IsValidDataPoint(0) && Low[0] < freshDemandProximal1[0] + 0.5 * gbTickSize && Low[0] > freshDemandDistal1[0] - 0.5 * gbTickSize)
                {
                    longSignal[0] = 1.0;
                    longSignals[0] = 1.0;
                    longSignal1Bar = CurrentBar;
                    if (showFreshSignals && !showAllSignals)
                    {
                        Draw.Text(this, string.Format("long1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    longSignal[0] = 0.0;
                    RemoveDrawObject(string.Format("long1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("long2{0}", CurrentBar));
                    if (longSignals[1] == 2.0 && Low[0] < freshDemandProximal2[CurrentBar - longSignal2Bar] + 0.5 * gbTickSize && Low[0] > freshDemandDistal2[CurrentBar - longSignal2Bar] - 0.5 * gbTickSize)
                    {
                        longSignals[0] = 2.0;
                        if (showConsecutiveSignals && showFreshSignals && !showAllSignals)
                        {
                            Draw.Text(this, string.Format("long1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("long2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longSignals[1] == 1.0 && Low[0] < freshDemandProximal1[CurrentBar - longSignal1Bar] + 0.5 * gbTickSize && Low[0] > freshDemandDistal1[CurrentBar - longSignal1Bar] - 0.5 * gbTickSize)
                    {
                        longSignals[0] = 1.0;
                        if (showConsecutiveSignals && showFreshSignals && !showAllSignals)
                        {
                            Draw.Text(this, string.Format("long1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else longSignals[0] = 0.0;
                }
                #endregion
                
                #region Generating short signals for trade entries, when fresh supply zones are first tested
                if (freshSupplyProximal2.IsValidDataPoint(0) && High[0] > freshSupplyProximal2[0] - 0.5 * gbTickSize && High[0] < freshSupplyDistal2[0] + 0.5 * gbTickSize)
                {
                    shortSignal[0] = 1.0;
                    shortSignals[0] = 1.0;
                    shortSignal2Bar = CurrentBar;
                    if (showFreshSignals & !showAllSignals)
                    {
                        Draw.Text(this, string.Format("short1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("short2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (freshSupplyProximal1.IsValidDataPoint(0) && High[0] > freshSupplyProximal1[0] - 0.5 * gbTickSize && High[0] < freshSupplyDistal1[0] + 0.5 * gbTickSize)
                {
                    shortSignal[0] = 1.0;
                    shortSignals[0] = 1.0;
                    shortSignal1Bar = CurrentBar;
                    if (showFreshSignals & !showAllSignals)
                    {
                        Draw.Text(this, string.Format("short1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    shortSignal[0] = 0.0;
                    RemoveDrawObject(string.Format("short1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("short2{0}", CurrentBar));
                    if (shortSignals[1] == 2.0 && High[0] > freshSupplyProximal2[CurrentBar - shortSignal2Bar] - 0.5 * gbTickSize && High[0] < freshSupplyDistal2[CurrentBar - shortSignal2Bar] + 0.5 * gbTickSize)
                    {
                        shortSignals[0] = 2.0;
                        if (showConsecutiveSignals && showFreshSignals && !showAllSignals)
                        {
                            Draw.Text(this, string.Format("short1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("short2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortSignals[1] == 1.0 && High[0] > freshSupplyProximal1[CurrentBar - shortSignal1Bar] - 0.5 * gbTickSize && High[0] < freshSupplyDistal1[CurrentBar - shortSignal1Bar] + 0.5 * gbTickSize)
                    {
                        shortSignals[0] = 1.0;
                        if (showConsecutiveSignals && showFreshSignals && !showAllSignals)
                        {
                            Draw.Text(this, string.Format("short1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else shortSignals[0] = 0.0;
                }
                #endregion

                #region Generating long signals for trade entries, when any demand zone is touched
                bool showLongSignalsAll = false;
                bool showLongSignalsAllConsecutive = false;
                if (allDemandProximal2.IsValidDataPoint(0) && (longSignalsAll[1] < 2.0 || (longSignalsAll[1] == 2.0 && allDemandProximal2[0] < allDemandProximal2[1]))
                    && Low[0] < allDemandProximal2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                {
                    longSignalAll[0] = 2.0;
                    longSignalsAll[0] = 2.0;
                    longSignalAll2Bar = CurrentBar;
                    if (showLongSignalsAll)
                    {
                        Draw.Text(this, string.Format("long1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("long2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (longSignalsAll[1] < 1.0 && allDemandProximal1.IsValidDataPoint(0) && Low[0] < allDemandProximal1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                {
                    longSignalAll[0] = 1.0;
                    longSignalsAll[0] = 1.0;
                    longSignalAll1Bar = CurrentBar;
                    if (showLongSignalsAll)
                    {
                        Draw.Text(this, string.Format("long1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    longSignalAll[0] = 0.0;
                    RemoveDrawObject(string.Format("long1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("long2{0}", CurrentBar));
                    if (longSignalsAll[1] == 2.0 && Low[0] < allDemandProximal2[CurrentBar - longSignalAll2Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[CurrentBar - longSignalAll2Bar] - 0.5 * gbTickSize)
                    {
                        longSignalsAll[0] = 2.0;
                        if (showLongSignalsAllConsecutive && showLongSignalsAll)
                        {
                            Draw.Text(this, string.Format("long1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("long2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longSignalsAll[1] == 1.0 && Low[0] < allDemandProximal1[CurrentBar - longSignalAll1Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[CurrentBar - longSignalAll1Bar] - 0.5 * gbTickSize)
                    {
                        longSignalsAll[0] = 1.0;
                        if (showLongSignalsAllConsecutive && showLongSignalsAll)
                        {
                            Draw.Text(this, string.Format("long1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longSignalsAll[1] != 0.0 && Low[0] < allDemandProximal1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                    {
                        longSignalsAll[0] = 1.0;
                        longSignalAll1Bar = CurrentBar;
                        if (showLongSignalsAllConsecutive && showLongSignalsAll)
                        {
                            Draw.Text(this, string.Format("long1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longSignalsAll[1] == 2.0 && Low[0] < allDemandProximal2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                    {
                        longSignalsAll[0] = 2.0;
                        longSignalAll2Bar = CurrentBar;
                        if (showLongSignalsAllConsecutive && showLongSignalsAll)
                        {
                            Draw.Text(this, string.Format("long1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("long2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        longSignalsAll[0] = 0.0;
                }
                #endregion

                #region Generating short signals for trade entries, when any supply zone is touched
                bool showShortSignalsAll = false;
                bool showShortSignalsAllConsecutive = false;
                if (allSupplyProximal2.IsValidDataPoint(0) && (shortSignalsAll[1] < 2.0 || (shortSignalsAll[1] == 2.0 && allSupplyProximal2[0] > allSupplyProximal2[1]))
                    && High[0] > allSupplyProximal2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                {
                    shortSignalAll[0] = 2.0;
                    shortSignalsAll[0] = 2.0;
                    shortSignalAll2Bar = CurrentBar;
                    if (showShortSignalsAll)
                    {
                        Draw.Text(this, string.Format("short1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("short2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (shortSignalsAll[1] < 1.0 && allSupplyProximal1.IsValidDataPoint(0) && High[0] > allSupplyProximal1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                {
                    shortSignalAll[0] = 1.0;
                    shortSignalsAll[0] = 1.0;
                    shortSignalAll1Bar = CurrentBar;
                    if (showShortSignalsAll)
                    {
                        Draw.Text(this, string.Format("short1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    shortSignalAll[0] = 0.0;
                    RemoveDrawObject(string.Format("short1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("short2{0}", CurrentBar));
                    if (shortSignalsAll[1] == 2.0 && High[0] > allSupplyProximal2[CurrentBar - shortSignalAll2Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[CurrentBar - shortSignalAll2Bar] + 0.5 * gbTickSize)
                    {
                        shortSignalsAll[0] = 2.0;
                        if (showShortSignalsAllConsecutive && showShortSignalsAll)
                        {
                            Draw.Text(this, string.Format("short1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("short2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortSignalsAll[1] == 1.0 && High[0] > allSupplyProximal1[CurrentBar - shortSignalAll1Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[CurrentBar - shortSignalAll1Bar] + 0.5 * gbTickSize)
                    {
                        shortSignalsAll[0] = 1.0;
                        if (showShortSignalsAllConsecutive && showShortSignalsAll)
                        {
                            Draw.Text(this, string.Format("short1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortSignalsAll[1] != 0.0 && High[0] > allSupplyProximal1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                    {
                        shortSignalsAll[0] = 1.0;
                        shortSignalAll1Bar = CurrentBar;
                        if (showShortSignalsAllConsecutive && showShortSignalsAll)
                        {
                            Draw.Text(this, string.Format("short1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortSignalsAll[1] == 2.0 && High[0] > allSupplyProximal2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                    {
                        shortSignalsAll[0] = 2.0;
                        shortSignalAll2Bar = CurrentBar;
                        if (showShortSignalsAllConsecutive && showShortSignalsAll)
                        {
                            Draw.Text(this, string.Format("short1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("short2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else shortSignalsAll[0] = 0.0;
                }
                #endregion

                #endregion

                #region -- RegPOCEntries --
                
                #region Generating long signals for trade entries, when POC are first tested
                bool showLongPOCSignal = false;
                bool showLongPOCSignalConsecutive = false;
                if (allDemandPOC2.IsValidDataPoint(0) && demandVA[1] && demandPOCHit[1] == 0.0 && Low[0] < allDemandPOC2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                {
                    longPOCSignal[0] = 2.0;
                    longPOCSignals[0] = 2.0;
                    demandPOCHit[1] = 1.0;
                    longPOCSignal2Bar = CurrentBar;
                    if (showLongPOCSignal)
                    {
                        Draw.Text(this, string.Format("longPOC1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("longPOC2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (allDemandPOC1.IsValidDataPoint(0) && demandVA[0] && demandPOCHit[0] == 0.0 && Low[0] < allDemandPOC1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                {
                    longPOCSignal[0] = 1.0;
                    longPOCSignals[0] = 1.0;
                    demandPOCHit[0] = 1.0;
                    longPOCSignal1Bar = CurrentBar;
                    if (showLongPOCSignal)
                    {
                        Draw.Text(this, string.Format("longPOC1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    longPOCSignal[0] = 0.0;
                    RemoveDrawObject(string.Format("longPOC1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("longPOC2{0}", CurrentBar));
                    if (longPOCSignals[1] == 2.0 && Low[0] < allDemandPOC2[CurrentBar - longPOCSignal2Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[CurrentBar - longPOCSignal2Bar] - 0.5 * gbTickSize)
                    {
                        longPOCSignals[0] = 2.0;
                        if (showLongPOCSignalConsecutive && showLongPOCSignal)
                        {
                            Draw.Text(this, string.Format("longPOC1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("longPOC2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longPOCSignals[1] == 1.0 && Low[0] < allDemandPOC1[CurrentBar - longPOCSignal1Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[CurrentBar - longPOCSignal1Bar] - 0.5 * gbTickSize)
                    {
                        longPOCSignals[0] = 1.0;
                        if (showLongPOCSignalConsecutive && showLongPOCSignal)
                        {
                            Draw.Text(this, string.Format("longPOC1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        longPOCSignals[0] = 0.0;
                }
                #endregion

                #region Generating short signals for trade entries, when POC are first tested
                bool showShortPOCSignal = false;
                bool showShortPOCSignalConsecutive = false;
                if (allSupplyPOC2.IsValidDataPoint(0) && supplyVA[1] && supplyPOCHit[1] == 0.0 && High[0] > allSupplyPOC2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                {
                    shortPOCSignal[0] = 2.0;
                    shortPOCSignals[0] = 2.0;
                    supplyPOCHit[1] = 1.0;
                    shortPOCSignal2Bar = CurrentBar;
                    if (showShortPOCSignal)
                    {
                        Draw.Text(this, string.Format("shortPOC1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("shortPOC2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (allSupplyPOC1.IsValidDataPoint(0) && supplyVA[0] && supplyPOCHit[0] == 0.0 && High[0] > allSupplyPOC1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                {
                    shortPOCSignal[0] = 1.0;
                    shortPOCSignals[0] = 1.0;
                    supplyPOCHit[0] = 1.0;
                    shortPOCSignal1Bar = CurrentBar;
                    if (showShortPOCSignal)
                    {
                        Draw.Text(this, string.Format("shortPOC1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    shortPOCSignal[0] = 0.0;
                    RemoveDrawObject(string.Format("shortPOC1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("shortPOC2{0}", CurrentBar));
                    if (shortPOCSignals[1] == 2.0 && High[0] > allSupplyPOC2[CurrentBar - shortPOCSignal2Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[CurrentBar - shortPOCSignal2Bar] + 0.5 * gbTickSize)
                    {
                        shortPOCSignals[0] = 2.0;
                        if (showShortPOCSignalConsecutive && showShortPOCSignal)
                        {
                            Draw.Text(this, string.Format("shortPOC1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("shortPOC2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortPOCSignals[1] == 1.0 && High[0] > allSupplyPOC1[CurrentBar - shortPOCSignal1Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[CurrentBar - shortPOCSignal1Bar] + 0.5 * gbTickSize)
                    {
                        shortPOCSignals[0] = 1.0;
                        if (showShortPOCSignalConsecutive && showShortPOCSignal)
                        {
                            Draw.Text(this, string.Format("shortPOC1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else shortPOCSignals[0] = 2.0;
                }
                #endregion

                #region Generating long signals for trade entries, when any demand POC is touched
                bool showLongPOCSignalsAll = false;
                bool showLongPOCSignalsAllConsecutive = false;
                if (allDemandPOC2.IsValidDataPoint(0) && demandVA[1] && /*demandPOCHits[1] == 0.0 &&*/ (longPOCSignalsAll[1] < 2.0 || (longPOCSignalsAll[1] == 2.0 && allDemandPOC2[0] < allDemandPOC2[1]))
                    && Low[0] < allDemandPOC2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                {
                    longPOCSignalAll[0] = 2.0;
                    longPOCSignalsAll[0] = 2.0;
                    demandPOCHits[1] = 1.0;
                    longPOCSignalAll2Bar = CurrentBar;
                    if (showLongPOCSignalsAll)
                    {
                        Draw.Text(this, string.Format("longPOCAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("longPOCAll2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (longPOCSignalsAll[1] < 1.0 && allDemandPOC1.IsValidDataPoint(0) && demandVA[0] && /*demandPOCHits[0] == 0.0 &&*/ Low[0] < allDemandPOC1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                {
                    longPOCSignalAll[0] = 1.0;
                    longPOCSignalsAll[0] = 1.0;
                    demandPOCHits[0] = 1.0;
                    longPOCSignalAll1Bar = CurrentBar;
                    if (showLongPOCSignalsAll)
                    {
                        Draw.Text(this, string.Format("longPOCAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    longPOCSignalAll[0] = 0.0;
                    RemoveDrawObject(string.Format("longPOCAll1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("longPOCAll2{0}", CurrentBar));
                    if (longPOCSignalsAll[1] == 2.0 && Low[0] < allDemandPOC2[CurrentBar - longPOCSignalAll2Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[CurrentBar - longPOCSignalAll2Bar] - 0.5 * gbTickSize)
                    {
                        longPOCSignalsAll[0] = 2.0;
                        if (showLongPOCSignalsAllConsecutive && showLongPOCSignalsAll)
                        {
                            Draw.Text(this, string.Format("longPOCAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("longPOCAll2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longPOCSignalsAll[1] == 1.0 && Low[0] < allDemandPOC1[CurrentBar - longPOCSignalAll1Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[CurrentBar - longPOCSignalAll1Bar] - 0.5 * gbTickSize)
                    {
                        longPOCSignalsAll[0] = 1.0;
                        if (showLongPOCSignalsAllConsecutive && showLongPOCSignalsAll)
                        {
                           Draw.Text(this, string.Format("longPOCAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longPOCSignalsAll[1] != 0.0 && Low[0] < allDemandPOC1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                    {
                        longPOCSignalsAll[0] = 1.0;
                        longPOCSignalAll1Bar = CurrentBar;
                        if (showLongPOCSignalsAllConsecutive && showLongPOCSignalsAll)
                        {
                            Draw.Text(this, string.Format("longPOCAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longPOCSignalsAll[1] == 2.0 && Low[0] < allDemandPOC2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                    {
                        longPOCSignalsAll[0] = 2.0;
                        longPOCSignalAll2Bar = CurrentBar;
                        if (showLongPOCSignalsAllConsecutive && showLongPOCSignalsAll)
                        {
                            Draw.Text(this, string.Format("longPOCAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("longPOCAll2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        longPOCSignalsAll[0] = 0.0;

                    if (allDemandProximal1.IsValidDataPoint(0) && demandPOCHits[0] == 1.0 && Low[0] > allDemandProximal1[0] + 0.5 * gbTickSize)
                    {
                        if (allDemandPOC1.IsValidDataPoint(0)) demandPOCHits[0] = 0.0;
                    }

                    if (allDemandProximal2.IsValidDataPoint(0) && demandPOCHits[1] == 1.0 && Low[0] > allDemandProximal2[0] + 0.5 * gbTickSize)
                    {
                        if (allDemandPOC2.IsValidDataPoint(0)) demandPOCHits[1] = 0.0;
                    }
                }
                #endregion

                #region Generating short signals for trade entries, when any supply zone is touched
                bool showShortPOCSignalsAll = false;
                bool showShortPOCSignalsAllConsecutive = false;
                if (allSupplyPOC2.IsValidDataPoint(0) && supplyVA[1] && /*supplyPOCHits[1] == 0.0 &&*/ (shortPOCSignalsAll[1] < 2.0 || (shortPOCSignalsAll[1] == 2.0 && allSupplyPOC2[0] > allSupplyPOC2[1]))
                    && High[0] > allSupplyPOC2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                {
                    shortPOCSignalAll[0] = 2.0;
                    shortPOCSignalsAll[0] = 2.0;
                    supplyPOCHits[1] = 1.0;
                    shortPOCSignalAll2Bar = CurrentBar;
                    if (showShortPOCSignalsAll)
                    {
                        Draw.Text(this, string.Format("shortPOCAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("shortPOCAll2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (shortPOCSignalsAll[1] < 1.0 && allSupplyPOC1.IsValidDataPoint(0) && supplyVA[0] && /*supplyPOCHits[0] == 0.0 &&*/ High[0] > allSupplyPOC1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                {
                    shortPOCSignalAll[0] = 1.0;
                    shortPOCSignalsAll[0] = 1.0;
                    supplyPOCHits[0] = 1.0;
                    shortPOCSignalAll1Bar = CurrentBar;
                    if (showShortPOCSignalsAll)
                    {
                        Draw.Text(this, string.Format("shortPOCAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    shortPOCSignalAll[0] = 0.0;
                    RemoveDrawObject(string.Format("shortPOCAll1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("shortPOCAll2{0}", CurrentBar));
                    if (shortPOCSignalsAll[1] == 2.0 && High[0] > allSupplyPOC2[CurrentBar - shortPOCSignalAll2Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[CurrentBar - shortPOCSignalAll2Bar] + 0.5 * gbTickSize)
                    {
                        shortPOCSignalsAll[0] = 2.0;
                        if (showShortPOCSignalsAllConsecutive && showShortPOCSignalsAll)
                        {
                            Draw.Text(this, string.Format("shortPOCAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("shortPOCAll2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortPOCSignalsAll[1] == 1.0 && High[0] > allSupplyPOC1[CurrentBar - shortPOCSignalAll1Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[CurrentBar - shortPOCSignalAll1Bar] + 0.5 * gbTickSize)
                    {
                        shortPOCSignalsAll[0] = 1.0;
                        if (showShortPOCSignalsAllConsecutive && showShortPOCSignalsAll)
                        {
                            Draw.Text(this, string.Format("shortPOCAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortPOCSignalsAll[1] != 0.0 && High[0] > allSupplyPOC1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                    {
                        shortPOCSignalsAll[0] = 1.0;
                        shortPOCSignalAll1Bar = CurrentBar;
                        if (showShortPOCSignalsAllConsecutive && showShortPOCSignalsAll)
                        {
                            Draw.Text(this, string.Format("shortPOCAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortPOCSignalsAll[1] == 2.0 && High[0] > allSupplyPOC2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                    {
                        shortPOCSignalsAll[0] = 2.0;
                        shortPOCSignalAll2Bar = CurrentBar;
                        if (showShortPOCSignalsAllConsecutive && showShortPOCSignalsAll)
                        {
                            Draw.Text(this, string.Format("shortPOCAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("shortPOCAll2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else shortPOCSignalsAll[0] = 0.0;

                    if (allSupplyProximal1.IsValidDataPoint(0) && supplyPOCHits[0] == 1.0 && High[0] < allSupplyProximal1[0] - 0.5 * gbTickSize)
                    {
                        if (allSupplyPOC1.IsValidDataPoint(0)) supplyPOCHits[0] = 0.0;
                    }

                    if (allSupplyProximal2.IsValidDataPoint(0) && supplyPOCHits[1] == 1.0 && High[0] < allSupplyProximal2[0] - 0.5 * gbTickSize)
                    {
                        if (allSupplyPOC2.IsValidDataPoint(0)) supplyPOCHits[1] = 0.0;
                    }
                }
                #endregion

                #endregion

                #region -- RegVCEntries --
                
                #region Generating long signals for trade entries, when VCT are first tested
                bool showLongVCSignal = false;
                bool showLongVCSignalConsecutive = false;
                if (allDemandVCT2.IsValidDataPoint(0) && demandVC[1] && demandVCHit[1] == 0.0 && Low[0] < allDemandVCT2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                {
                    longVCSignal[0] = 2.0;
                    longVCSignals[0] = 2.0;
                    demandVCHit[1] = 1.0;
                    longVCSignal2Bar = CurrentBar;
                    if (showLongVCSignal)
                    {
                        Draw.Text(this, string.Format("longVCT1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("longVCT2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (allDemandVCT1.IsValidDataPoint(0) && demandVC[0] && demandVCHit[0] == 0.0 && Low[0] < allDemandVCT1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                {
                    longVCSignal[0] = 1.0;
                    longVCSignals[0] = 1.0;
                    demandVCHit[0] = 1.0;
                    longVCSignal1Bar = CurrentBar;
                    if (showLongVCSignal)
                    {
                        Draw.Text(this, string.Format("longVCT1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    longVCSignal[0] = 0.0;
                    RemoveDrawObject(string.Format("longVCT1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("longVCT2{0}", CurrentBar));
                    if (longVCSignals[1] == 2.0 && Low[0] < allDemandVCT2[CurrentBar - longVCSignal2Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[CurrentBar - longVCSignal2Bar] - 0.5 * gbTickSize)
                    {
                        longVCSignals[0] = 2.0;
                        if (showLongVCSignalConsecutive && showLongVCSignal)
                        {
                            Draw.Text(this, string.Format("longVCT1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("longVCT2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longVCSignals[1] == 1.0 && Low[0] < allDemandVCT1[CurrentBar - longVCSignal1Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[CurrentBar - longVCSignal1Bar] - 0.5 * gbTickSize)
                    {
                        longVCSignals[0] = 1.0;
                        if (showLongVCSignalConsecutive && showLongVCSignal)
                        {
                            Draw.Text(this, string.Format("longVCT1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        longVCSignals[0] = 0.0;
                }
                #endregion

                #region Generating short signals for trade entries, when VCB are first tested
                bool showShortVCSignal = false;
                bool showShortVCSignalConsecutive = false;
                if (allSupplyVCB2.IsValidDataPoint(0) && supplyVC[1] && supplyVCHit[1] == 0.0 && High[0] > allSupplyVCB2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                {
                    shortVCSignal[0] = 2.0;
                    shortVCSignals[0] = 2.0;
                    supplyVCHit[1] = 1.0;
                    shortVCSignal2Bar = CurrentBar;
                    if (showShortVCSignal)
                    {
                        Draw.Text(this, string.Format("shortVCB1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("shortVCB2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (allSupplyVCB1.IsValidDataPoint(0) && supplyVC[0] && supplyVCHit[0] == 0.0 && High[0] > allSupplyVCB1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                {
                    shortVCSignal[0] = 1.0;
                    shortVCSignals[0] = 1.0;
                    supplyVCHit[0] = 1.0;
                    shortVCSignal1Bar = CurrentBar;
                    if (showShortVCSignal)
                    {
                        Draw.Text(this, string.Format("shortVCB1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    shortVCSignal[0] = 0.0;
                    RemoveDrawObject(string.Format("shortVCB1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("shortVCB2{0}", CurrentBar));
                    if (shortVCSignals[1] == 2.0 && High[0] > allSupplyVCB2[CurrentBar - shortVCSignal2Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[CurrentBar - shortVCSignal2Bar] + 0.5 * gbTickSize)
                    {
                        shortVCSignals[0] = 2.0;
                        if (showShortVCSignalConsecutive && showShortVCSignal)
                        {
                            Draw.Text(this, string.Format("shortVCB1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("shortVCB2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortVCSignals[1] == 1.0 && High[0] > allSupplyVCB1[CurrentBar - shortVCSignal1Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[CurrentBar - shortVCSignal1Bar] + 0.5 * gbTickSize)
                    {
                        shortVCSignals[0] = 1.0;
                        if (showShortVCSignalConsecutive && showShortVCSignal)
                        {
                            Draw.Text(this, string.Format("shortVCB1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        shortVCSignals[0] = 0.0;
                }
                #endregion

                #region Generating long signals for trade entries, when any demand VCT is touched
                bool showLongVCSignalsAll = false;
                bool showLongVCSignalsAllConsecutive = false;
                if (allDemandVCT2.IsValidDataPoint(0) && demandVC[1] && /*demandVCHits[1] == 0.0 &&*/ (longVCSignalsAll[1] < 2.0 || (longVCSignalsAll[1] == 2.0 && allDemandVCT2[0] < allDemandVCT2[1]))
                    && Low[0] < allDemandVCT2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                {
                    longVCSignalAll[0] = 2.0;
                    longVCSignalsAll[0] = 2.0;
                    demandVCHits[1] = 1.0;
                    longVCSignalAll2Bar = CurrentBar;
                    if (showLongVCSignalsAll)
                    {
                        Draw.Text(this, string.Format("longVCTAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("longVCTAll2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (longVCSignalsAll[1] < 1.0 && allDemandVCT1.IsValidDataPoint(0) && demandVC[0] && /*demandVCHits[0] == 0.0 &&*/ Low[0] < allDemandVCT1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                {
                    longVCSignalAll[0] = 1.0;
                    longVCSignalsAll[0] = 1.0;
                    demandVCHits[0] = 1.0;
                    longVCSignalAll1Bar = CurrentBar;
                    if (showLongVCSignalsAll)
                    {
                        Draw.Text(this, string.Format("longVCTAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    longVCSignalAll[0] = 0.0;
                    RemoveDrawObject(string.Format("longVCTAll1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("longVCTAll2{0}", CurrentBar));
                    if (longVCSignalsAll[1] == 2.0 && Low[0] < allDemandVCT2[CurrentBar - longVCSignalAll2Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[CurrentBar - longVCSignalAll2Bar] - 0.5 * gbTickSize)
                    {
                        longVCSignalsAll[0] = 2.0;
                        if (showLongVCSignalsAllConsecutive && showLongVCSignalsAll)
                        {
                            Draw.Text(this, string.Format("longVCTAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("longVCTAll2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longVCSignalsAll[1] == 1.0 && Low[0] < allDemandVCT1[CurrentBar - longVCSignalAll1Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[CurrentBar - longVCSignalAll1Bar] - 0.5 * gbTickSize)
                    {
                        longVCSignalsAll[0] = 1.0;
                        if (showLongVCSignalsAllConsecutive && showLongVCSignalsAll)
                        {
                            Draw.Text(this, string.Format("longVCTAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longVCSignalsAll[1] != 0.0 && Low[0] < allDemandVCT1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                    {
                        longVCSignalsAll[0] = 1.0;
                        longVCSignalAll1Bar = CurrentBar;
                        if (showLongVCSignalsAllConsecutive && showLongVCSignalsAll)
                        {
                            Draw.Text(this, string.Format("longVCTAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longVCSignalsAll[1] == 2.0 && Low[0] < allDemandVCT2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                    {
                        longVCSignalsAll[0] = 2.0;
                        longVCSignalAll2Bar = CurrentBar;
                        if (showLongVCSignalsAllConsecutive && showLongVCSignalsAll)
                        {
                            Draw.Text(this, string.Format("longVCTAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        longVCSignalsAll[0] = 0.0;

                    if (allDemandProximal1.IsValidDataPoint(0) && demandVCHits[0] == 1.0 && Low[0] > allDemandProximal1[0] + 0.5 * gbTickSize)
                    {
                        if (allDemandVCT1.IsValidDataPoint(0)) demandVCHits[0] = 0.0;
                    }

                    if (allDemandProximal2.IsValidDataPoint(0) && demandVCHits[1] == 1.0 && Low[0] > allDemandProximal2[0] + 0.5 * gbTickSize)
                    {
                        if (allDemandVCT2.IsValidDataPoint(0)) demandVCHits[1] = 0.0;
                    }
                }
                #endregion

                #region Generating short signals for trade entries, when any supply zone is touched
                bool showShortVCSignalsAll = false;
                bool showShortVCSignalsAllConsecutive = false;
                if (allSupplyVCB2.IsValidDataPoint(0) && supplyVC[1] && /*supplyVCHits[1] == 0.0 &&*/ (shortVCSignalsAll[1] < 2.0 || (shortVCSignalsAll[1] == 2.0 && allSupplyVCB2[0] > allSupplyVCB2[1]))
                    && High[0] > allSupplyVCB2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                {
                    shortVCSignalAll[0] = 2.0;
                    shortVCSignalsAll[0] = 2.0;
                    supplyVCHits[1] = 1.0;
                    shortVCSignalAll2Bar = CurrentBar;
                    if (showShortVCSignalsAll)
                    {
                        Draw.Text(this, string.Format("shortVCBAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("shortVCBAll2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (shortVCSignalsAll[1] < 1.0 && allSupplyVCB1.IsValidDataPoint(0) && supplyVC[0] && /*supplyVCHits[0] == 0.0 &&*/ High[0] > allSupplyVCB1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                {
                    shortVCSignalAll[0] = 1.0;
                    shortVCSignalsAll[0] = 1.0;
                    supplyVCHits[0] = 1.0;
                    shortVCSignalAll1Bar = CurrentBar;
                    if (showShortVCSignalsAll)
                    {
                        Draw.Text(this, string.Format("shortVCBAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    shortVCSignalAll[0] = 0.0;
                    RemoveDrawObject(string.Format("shortVCBAll1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("shortVCBAll2{0}", CurrentBar));
                    if (shortVCSignalsAll[1] == 2.0 && High[0] > allSupplyVCB2[CurrentBar - shortVCSignalAll2Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[CurrentBar - shortVCSignalAll2Bar] + 0.5 * gbTickSize)
                    {
                        shortVCSignalsAll[0] = 2.0;
                        if (showShortVCSignalsAllConsecutive && showShortVCSignalsAll)
                        {
                            Draw.Text(this, string.Format("shortVCBAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("shortVCBAll2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortVCSignalsAll[1] == 1.0 && High[0] > allSupplyVCB1[CurrentBar - shortVCSignalAll1Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[CurrentBar - shortVCSignalAll1Bar] + 0.5 * gbTickSize)
                    {
                        shortVCSignalsAll[0] = 1.0;
                        if (showShortVCSignalsAllConsecutive && showShortVCSignalsAll)
                        {
                            Draw.Text(this, string.Format("shortVCBAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortVCSignalsAll[1] != 0.0 && High[0] > allSupplyVCB1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                    {
                        shortVCSignalsAll[0] = 1.0;
                        shortVCSignalAll1Bar = CurrentBar;
                        if (showShortVCSignalsAllConsecutive && showShortVCSignalsAll)
                        {
                            Draw.Text(this, string.Format("shortVCBAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortVCSignalsAll[1] == 2.0 && High[0] > allSupplyVCB2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                    {
                        shortVCSignalsAll[0] = 2.0;
                        shortVCSignalAll2Bar = CurrentBar;
                        if (showShortVCSignalsAllConsecutive && showShortVCSignalsAll)
                        {
                            Draw.Text(this, string.Format("shortVCBAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("shortVCBAll2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        shortVCSignalsAll[0] = 0.0;

                    if (allSupplyProximal1.IsValidDataPoint(0) && supplyVCHits[0] == 1.0 && High[0] < allSupplyProximal1[0] - 0.5 * gbTickSize)
                    {
                        if (allSupplyVCB1.IsValidDataPoint(0)) supplyVCHits[0] = 0.0;
                    }

                    if (allSupplyProximal2.IsValidDataPoint(0) && supplyVCHits[1] == 1.0 && High[0] < allSupplyProximal2[0] - 0.5 * gbTickSize)
                    {
                        if (allSupplyVCB2.IsValidDataPoint(0)) supplyVCHits[1] = 0.0;
                    }
                }
                #endregion

                #endregion

                #region -- RegVAEntries --

                #region Generating long signals for trade entries, when VAH are first tested
                bool showLongVASignal = false;
                bool showLongVASignalConsecutive = false;
                if (allDemandVAH2.IsValidDataPoint(0) && demandVA[1] && demandVAHit[1] == 0.0 && Low[0] < allDemandVAH2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                {
                    longVASignal[0] = 2.0;
                    longVASignals[0] = 2.0;
                    demandVAHit[1] = 1.0;
                    longVASignal2Bar = CurrentBar;
                    if (showLongVASignal)
                    {
                        Draw.Text(this, string.Format("longVAH1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("longVAH2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (allDemandVAH1.IsValidDataPoint(0) && demandVA[0] && demandVAHit[0] == 0.0 && Low[0] < allDemandVAH1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                {
                    longVASignal[0] = 1.0;
                    longVASignals[0] = 1.0;
                    demandVAHit[0] = 1.0;
                    longVASignal1Bar = CurrentBar;
                    if (showLongVASignal)
                    {
                        Draw.Text(this, string.Format("longVAH1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    longVASignal[0] = 0.0;
                    RemoveDrawObject(string.Format("longVAH1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("longVAH2{0}", CurrentBar));
                    if (longVASignals[1] == 2.0 && Low[0] < allDemandVAH2[CurrentBar - longVASignal2Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[CurrentBar - longVASignal2Bar] - 0.5 * gbTickSize)
                    {
                        longVASignals[0] = 2.0;
                        if (showLongVASignalConsecutive && showLongVASignal)
                        {
                            Draw.Text(this, string.Format("longVAH1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("longVAH2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longVASignals[1] == 1.0 && Low[0] < allDemandVAH1[CurrentBar - longVASignal1Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[CurrentBar - longVASignal1Bar] - 0.5 * gbTickSize)
                    {
                        longVASignals[0] = 1.0;
                        if (showLongVASignalConsecutive && showLongVASignal)
                        {
                            Draw.Text(this, string.Format("longVAH1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        longVASignals[0] = 0.0;
                }
                #endregion

                #region Generating short signals for trade entries, when VAL are first tested
                bool showShortVASignal = false;
                bool showShortVASignalConsecutive = false;
                if (allSupplyVAL2.IsValidDataPoint(0) && supplyVA[1] && supplyVAHit[1] == 0.0 && High[0] > allSupplyVAL2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                {
                    shortVASignal[0] = 2.0;
                    shortVASignals[0] = 2.0;
                    supplyVAHit[1] = 1.0;
                    shortVASignal2Bar = CurrentBar;
                    if (showShortVASignal)
                    {
                        Draw.Text(this, string.Format("shortVAL1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("shortVAL2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (allSupplyVAL1.IsValidDataPoint(0) && supplyVA[0] && supplyVAHit[0] == 0.0 && High[0] > allSupplyVAL1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                {
                    shortVASignal[0] = 1.0;
                    shortVASignals[0] = 1.0;
                    supplyVAHit[0] = 1.0;
                    shortVASignal1Bar = CurrentBar;
                    if (showShortVASignal)
                    {
                        Draw.Text(this, string.Format("shortVAL1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    shortVASignal[0] = 0.0;
                    RemoveDrawObject(string.Format("shortVAL1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("shortVAL2{0}", CurrentBar));
                    if (shortVASignals[1] == 2.0 && High[0] > allSupplyVAL2[CurrentBar - shortVASignal2Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[CurrentBar - shortVASignal2Bar] + 0.5 * gbTickSize)
                    {
                        shortVASignals[0] = 2.0;
                        if (showShortVASignalConsecutive && showShortVASignal)
                        {
                            Draw.Text(this, string.Format("shortVAL1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("shortVAL2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortVASignals[1] == 1.0 && High[0] > allSupplyVAL1[CurrentBar - shortVASignal1Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[CurrentBar - shortVASignal1Bar] + 0.5 * gbTickSize)
                    {
                        shortVASignals[0] = 1.0;
                        if (showShortVASignalConsecutive && showShortVASignal)
                        {
                            Draw.Text(this, string.Format("shortVAL1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        shortVASignals[0] = 0.0;
                }
                #endregion

                #region Generating long signals for trade entries, when any demand VAH is touched
                bool showLongVASignalsAll = false;
                bool showLongVASignalsAllConsecutive = false;
                if (allDemandVAH2.IsValidDataPoint(0) && demandVA[1] && /*demandVAHits[1] == 0.0 &&*/ (longVASignalsAll[1] < 2.0 || (longVASignalsAll[1] == 2.0 && allDemandVAH2[0] < allDemandVAH2[1]))
                    && Low[0] < allDemandVAH2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                {
                    longVASignalAll[0] = 2.0;
                    longVASignalsAll[0] = 2.0;
                    demandVAHits[1] = 1.0;
                    longVASignalAll2Bar = CurrentBar;
                    if (showLongVASignalsAll)
                    {
                        Draw.Text(this, string.Format("longVAHAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("longVAHAll2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (longVASignalsAll[1] < 1.0 && allDemandVAH1.IsValidDataPoint(0) && demandVA[0] && /*demandVAHits[0] == 0.0 &&*/ Low[0] < allDemandVAH1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                {
                    longVASignalAll[0] = 1.0;
                    longVASignalsAll[0] = 1.0;
                    demandVAHits[0] = 1.0;
                    longVASignalAll1Bar = CurrentBar;
                    if (showLongVASignalsAll)
                    {
                        Draw.Text(this, string.Format("longVAHAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    longVASignalAll[0] = 0.0;
                    RemoveDrawObject(string.Format("longVAHAll1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("longVAHAll2{0}", CurrentBar));
                    if (longVASignalsAll[1] == 2.0 && Low[0] < allDemandVAH2[CurrentBar - longVASignalAll2Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[CurrentBar - longVASignalAll2Bar] - 0.5 * gbTickSize)
                    {
                        longVASignalsAll[0] = 2.0;
                        if (showLongVASignalsAllConsecutive && showLongVASignalsAll)
                        {
                            Draw.Text(this, string.Format("longVAHAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("longVAHAll2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longVASignalsAll[1] == 1.0 && Low[0] < allDemandVAH1[CurrentBar - longVASignalAll1Bar] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[CurrentBar - longVASignalAll1Bar] - 0.5 * gbTickSize)
                    {
                        longVASignalsAll[0] = 1.0;
                        if (showLongVASignalsAllConsecutive && showLongVASignalsAll)
                        {
                            Draw.Text(this, string.Format("longVAHAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longVASignalsAll[1] != 0.0 && Low[0] < allDemandVAH1[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal1[0] - 0.5 * gbTickSize)
                    {
                        longVASignalsAll[0] = 1.0;
                        longVASignalAll1Bar = CurrentBar;
                        if (showLongVASignalsAllConsecutive && showLongVASignalsAll)
                        {
                            Draw.Text(this, string.Format("longVAHAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (longVASignalsAll[1] == 2.0 && Low[0] < allDemandVAH2[0] + 0.5 * gbTickSize && Low[0] > allDemandDistal2[0] - 0.5 * gbTickSize)
                    {
                        longVASignalsAll[0] = 2.0;
                        longVASignalAll2Bar = CurrentBar;
                        if (showLongVASignalsAllConsecutive && showLongVASignalsAll)
                        {
                            Draw.Text(this, string.Format("longVAHAll1{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -25 - Convert.ToInt32(1.5 * fontSize), longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("longVAHAll2{0}", CurrentBar), true, arrowStringUp, 0, Low[0], -26 - 5 * fontSize, longEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        longVASignalsAll[0] = 0.0;

                    if (allDemandProximal1.IsValidDataPoint(0) && demandVAHits[0] == 1.0 && Low[0] > allDemandProximal1[0] + 0.5 * gbTickSize)
                    {
                        if (allDemandVAH1.IsValidDataPoint(0)) demandVAHits[0] = 0.0;
                    }

                    if (allDemandProximal2.IsValidDataPoint(0) && demandVAHits[1] == 1.0 && Low[0] > allDemandProximal2[0] + 0.5 * gbTickSize)
                    {
                        if (allDemandVAH2.IsValidDataPoint(0)) demandVAHits[1] = 0.0;
                    }
                }
                #endregion

                #region Generating short signals for trade entries, when any supply zone is touched
                bool showShortVASignalsAll = false;
                bool showShortVASignalsAllConsecutive = false;
                if (allSupplyVAL2.IsValidDataPoint(0) && supplyVA[1] && /*supplyVAHits[1] == 0.0 &&*/ (shortVASignalsAll[1] < 2.0 || (shortVASignalsAll[1] == 2.0 && allSupplyVAL2[0] > allSupplyVAL2[1]))
                    && High[0] > allSupplyVAL2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                {
                    shortVASignalAll[0] = 2.0;
                    shortVASignalsAll[0] = 2.0;
                    supplyVAHits[1] = 1.0;
                    shortVASignalAll2Bar = CurrentBar;
                    if (showShortVASignalsAll)
                    {
                        Draw.Text(this, string.Format("shortVALAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        Draw.Text(this, string.Format("shortVALAll2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else if (shortVASignalsAll[1] < 1.0 && allSupplyVAL1.IsValidDataPoint(0) && supplyVA[0] && /*supplyVAHits[0] == 0.0 &&*/ High[0] > allSupplyVAL1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                {
                    shortVASignalAll[0] = 1.0;
                    shortVASignalsAll[0] = 1.0;
                    supplyVAHits[0] = 1.0;
                    shortVASignalAll1Bar = CurrentBar;
                    if (showShortVASignalsAll)
                    {
                        Draw.Text(this, string.Format("shortVALAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                    }
                }
                else
                {
                    shortVASignalAll[0] = 0.0;
                    RemoveDrawObject(string.Format("shortVALAll1{0}", CurrentBar));
                    RemoveDrawObject(string.Format("shortVALAll2{0}", CurrentBar));
                    if (shortVASignalsAll[1] == 2.0 && High[0] > allSupplyVAL2[CurrentBar - shortVASignalAll2Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[CurrentBar - shortVASignalAll2Bar] + 0.5 * gbTickSize)
                    {
                        shortVASignalsAll[0] = 2.0;
                        if (showShortVASignalsAllConsecutive && showShortVASignalsAll)
                        {
                            Draw.Text(this, string.Format("shortVALAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("shortVALAll2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortVASignalsAll[1] == 1.0 && High[0] > allSupplyVAL1[CurrentBar - shortVASignalAll1Bar] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[CurrentBar - shortVASignalAll1Bar] + 0.5 * gbTickSize)
                    {
                        shortVASignalsAll[0] = 1.0;
                        if (showShortVASignalsAllConsecutive && showShortVASignalsAll)
                        {
                            Draw.Text(this, string.Format("shortVALAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortVASignalsAll[1] != 0.0 && High[0] > allSupplyVAL1[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal1[0] + 0.5 * gbTickSize)
                    {
                        shortVASignalsAll[0] = 1.0;
                        shortVASignalAll1Bar = CurrentBar;
                        if (showShortVASignalsAllConsecutive && showShortVASignalsAll)
                        {
                            Draw.Text(this, string.Format("shortVALAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else if (shortVASignalsAll[1] == 2.0 && High[0] > allSupplyVAL2[0] - 0.5 * gbTickSize && High[0] < allSupplyDistal2[0] + 0.5 * gbTickSize)
                    {
                        shortVASignalsAll[0] = 2.0;
                        shortVASignalAll2Bar = CurrentBar;
                        if (showShortVASignalsAllConsecutive && showShortVASignalsAll)
                        {
                            Draw.Text(this, string.Format("shortVALAll1{0}", CurrentBar), true, arrowStringDown, 0, High[0], 35 + Convert.ToInt32(1.5 * fontSize), shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                            Draw.Text(this, string.Format("shortVALAll2{0}", CurrentBar), true, arrowStringDown, 0, High[0], 36 + 5 * fontSize, shortEntryColor, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
                        }
                    }
                    else
                        shortVASignalsAll[0] = 0.0;

                    if (allSupplyProximal1.IsValidDataPoint(0) && supplyVAHits[0] == 1.0 && High[0] < allSupplyProximal1[0] - 0.5 * gbTickSize)
                    {
                        if (allSupplyVAL1.IsValidDataPoint(0))
                            supplyVAHits[0] = 0.0;
                    }

                    if (allSupplyProximal2.IsValidDataPoint(0) && supplyVAHits[1] == 1.0 && High[0] < allSupplyProximal2[0] - 0.5 * gbTickSize)
                    {
                        if (allSupplyVAL2.IsValidDataPoint(0)) supplyVAHits[1] = 0.0;
                    }
                }
                #endregion

                #endregion

                #endregion
            }

            if (BarsInProgress == 0)
            {
                this.sExtrnDemandTop[0] = GetZoneProperty(0, 0, 0, 1);
                this.sExtrnDemandBottom[0] = GetZoneProperty(0, 0, 1, 1);

                this.sExtrnSupplyTop[0] = GetZoneProperty(1, 0, 0, 1);
                this.sExtrnSupplyBottom[0] = GetZoneProperty(1, 0, 1, 1);
            }
            #region -- RegZoneProcessing --
            if (allowManipulation && (BarsInProgress == 2 || this.UseChartBars) && this.GZS != null && this.GZS.Count > 0)
            {
                for (int g = 0; g < this.GZS.Count; g++)
                {
                    if (State == State.Historical && GZS[g].State == GZ_FORMED)
                    {
                        double processPrice = (GZS[g].Type == GZ_SUPPLY) ? Highs[BarsInProgress][0] : Lows[BarsInProgress][0];

                        // I don't understand this business....if we don't run this, zones appear to match COBC = false operation.....
                        this.ProcessZone(GZS[g], processPrice, Opens[BarsInProgress][0], Times[BarsInProgress][0], CurrentBars[BarsInProgress]);
                    }

                    if (this.iAlertOn)
                    {
                        // Do not monitor hidden zones
                        if (!this.iShowHiddenZones)
                        {
                            if (this.iAutoHideRetests && GZS[g].State == GZ_HIDDEN) continue;
                        }
						bool c1 = (Closes[BarsInProgress][0] >= GZS[g].Bottom);
						bool c2 = (Closes[BarsInProgress][0] <= GZS[g].Top);
                        if (c1 && c2 && (!GZS[g].Alerting))
                        {
							this.SoundAlertHandler(this.iAlertSoundFile, 
								string.Format("{0}: SDV zone entered at {1}",Name,Instrument.MasterInstrument.FormatPrice((c1 ? GZS[g].Bottom : GZS[g].Top))));

                            GZS[g].Alerting = true;
                        }
                        else if ((Closes[BarsInProgress][0] <= GZS[g].Bottom) && (Closes[BarsInProgress][0] >= GZS[g].Top) && (GZS[g].Alerting))
                        {
                            GZS[g].Alerting = false;
                        }
                    }
                }
            }
            #endregion
            #region -- RegCurveProcessing --
            if (BarsInProgress == 0 && CurrentBars[0] > 0)
            {
                CheckForCurveInZone();
                if (pIncludeZone)
                {
                    CurveHighF[0] = CurveHighZ[0];
                    CurveLowF[0] = CurveLowZ[0];
                }
                else
                {
                    CurveHighF[0] = CurveHigh[0];
                    CurveLowF[0] = CurveLow[0];
                }
                Curve1[0] = CurveLowF[0] + (CurveHighF[0] - CurveLowF[0]) * pPercent5 / 100;
                Curve2[0] = CurveLowF[0] + (CurveHighF[0] - CurveLowF[0]) * pPercent4 / 100;
                Curve3[0] = CurveLowF[0] + (CurveHighF[0] - CurveLowF[0]) * pPercent3 / 100;
                Curve4[0] = CurveLowF[0] + (CurveHighF[0] - CurveLowF[0]) * pPercent2 / 100;
                Curve5[0] = CurveLowF[0] + (CurveHighF[0] - CurveLowF[0]) * pPercent1 / 100;

                if (CurveStatus[1] == 0) // last bar was not in the curve
                {
                    if (Close[0] <= Curve1[0] && Close[0] >= Curve2[0]) CurveStatus[0] = 1;
                    else if (Close[0] <= Curve2[0] && Close[0] >= Curve3[0]) CurveStatus[0] = 2;
                    else if (Close[0] <= Curve3[0] && Close[0] >= Curve4[0]) CurveStatus[0] = 3;
                    else if (Close[0] <= Curve4[0] && Close[0] >= Curve5[0]) CurveStatus[0] = 4;
                    else CurveStatus[0] = 0;
                }
                else if (CurveStatus[1] <= 2) // last bar was in retail
                {
                    if (Close[0] <= Curve1[0] && Close[0] > Curve2[0]) CurveStatus[0] = 1;
                    else if (Close[0] <= Curve2[0] && Close[0] > Curve3[0]) CurveStatus[0] = 2;
                    else if (Close[0] <= Curve3[0] && Close[0] >= Curve4[0]) CurveStatus[0] = 3;
                    else if (Close[0] <= Curve4[0] && Close[0] >= Curve5[0]) CurveStatus[0] = 4;
                    else CurveStatus[0] = 0;
                }
                else if (CurveStatus[1] <= 4) // last bar was in value
                {
                    if (Close[0] <= Curve1[0] && Close[0] >= Curve2[0]) CurveStatus[0] = 1;
                    else if (Close[0] <= Curve2[0] && Close[0] >= Curve3[0]) CurveStatus[0] = 2;
                    else if (Close[0] <= Curve3[0] && Close[0] >= Curve4[0]) CurveStatus[0] = 3;
                    else if (Close[0] <= Curve4[0] && Close[0] >= Curve5[0]) CurveStatus[0] = 4;
                    else CurveStatus[0] = 0;
                }
                else
                {
                    if (Close[0] <= Curve1[0] && Close[0] >= Curve2[0]) CurveStatus[0] = 1;
                    else if (Close[0] <= Curve2[0] && Close[0] >= Curve3[0]) CurveStatus[0] = 2;
                    else if (Close[0] <= Curve3[0] && Close[0] >= Curve4[0]) CurveStatus[0] = 3;
                    else if (Close[0] <= Curve4[0] && Close[0] >= Curve5[0]) CurveStatus[0] = 4;
                    else CurveStatus[0] = 0;
                }
            }
            #endregion
            #region -- RegExtDataManagement --
            if (BarsInProgress == 0 && bodyHigh != null && ((iChartMode1 == ARC_SDVSystem_ZoneMode2.DEFAULT_CHART && CurrentBars[0] > 0) || (iChartMode1 == ARC_SDVSystem_ZoneMode2.MTF && CurrentBars[2] > 0)))
            {
                bodyHighDefault[0]  = bodyHigh[0];
                bodyLowDefault[0]   = bodyLow[0];
                bodyRangeDefault[0] = bodyRange[0];

                allDemandProximal1Default[0] = allDemandProximal1[0];
                allDemandDistal1Default[0]   = allDemandDistal1[0];
                allDemandPOC1Default[0] = allDemandPOC1[0];
                allDemandVAH1Default[0] = allDemandVAH1[0];
                allDemandVAL1Default[0] = allDemandVAL1[0];
                allDemandVCT1Default[0] = allDemandVCT1[0];
                allDemandVCB1Default[0] = allDemandVCB1[0];

                allSupplyProximal1Default[0] = allSupplyProximal1[0];
                allSupplyDistal1Default[0]   = allSupplyDistal1[0];
                allSupplyPOC1Default[0] = allSupplyPOC1[0];
                allSupplyVAH1Default[0] = allSupplyVAH1[0];
                allSupplyVAL1Default[0] = allSupplyVAL1[0];
                allSupplyVCT1Default[0] = allSupplyVCT1[0];
                allSupplyVCB1Default[0] = allSupplyVCB1[0];

                freshDemandProximal1Default[0] = freshDemandProximal1[0];
                freshDemandDistal1Default[0]   = freshDemandDistal1[0];
                freshSupplyProximal1Default[0] = freshSupplyProximal1[0];
                freshSupplyDistal1Default[0]   = freshSupplyDistal1[0];

                allDemandProximal2Default[0] = allDemandProximal2[0];
                allDemandDistal2Default[0]   = allDemandDistal2[0];
                allDemandPOC2Default[0] = allDemandPOC2[0];
                allDemandVAH2Default[0] = allDemandVAH2[0];
                allDemandVAL2Default[0] = allDemandVAL2[0];
                allDemandVCT2Default[0] = allDemandVCT2[0];
                allDemandVCB2Default[0] = allDemandVCB2[0];

                allSupplyProximal2Default[0] = allSupplyProximal2[0];
                allSupplyDistal2Default[0]   = allSupplyDistal2[0];
                allSupplyPOC2Default[0] = allSupplyPOC2[0];
                allSupplyVAH2Default[0] = allSupplyVAH2[0];
                allSupplyVAL2Default[0] = allSupplyVAL2[0];
                allSupplyVCT2Default[0] = allSupplyVCT2[0];
                allSupplyVCB2Default[0] = allSupplyVCB2[0];

                freshDemandProximal2Default[0] = freshDemandProximal2[0];
                freshDemandDistal2Default[0]   = freshDemandDistal2[0];
                freshSupplyProximal2Default[0] = freshSupplyProximal2[0];
                freshSupplyDistal2Default[0]   = freshSupplyDistal2[0];

                longSignalDefault[0]    = longSignal[0];
                longPOCSignalDefault[0] = longPOCSignal[0];
                longVCSignalDefault[0]  = longVCSignal[0];
                longVASignalDefault[0]  = longVASignal[0];

                shortSignalDefault[0]    = shortSignal[0];
                shortPOCSignalDefault[0] = shortPOCSignal[0];
                shortVCSignalDefault[0]  = shortVCSignal[0];
                shortVASignalDefault[0]  = shortVASignal[0];

                longSignalsDefault[0]    = longSignals[0];
                longPOCSignalsDefault[0] = longPOCSignals[0];
                longVCSignalsDefault[0]  = longVCSignals[0];
                longVASignalsDefault[0]  = longVASignals[0];

                shortSignalsDefault[0]    = shortSignals[0];
                shortPOCSignalsDefault[0] = shortPOCSignals[0];
                shortVCSignalsDefault[0]  = shortVCSignals[0];
                shortVASignalsDefault[0]  = shortVASignals[0];

                longSignalAllDefault[0]    = longSignalAll[0];
                longPOCSignalAllDefault[0] = longPOCSignalAll[0];
                longVCSignalAllDefault[0]  = longVCSignalAll[0];
                longVASignalAllDefault[0]  = longVASignalAll[0];

                shortSignalAllDefault[0]    = shortSignalAll[0];
                shortPOCSignalAllDefault[0] = shortPOCSignalAll[0];
                shortVCSignalAllDefault[0]  = shortVCSignalAll[0];
                shortVASignalAllDefault[0]  = shortVASignalAll[0];

                longSignalsAllDefault[0]    = longSignalsAll[0];
                longPOCSignalsAllDefault[0] = longPOCSignalsAll[0];
                longVCSignalsAllDefault[0]  = longVCSignalsAll[0];
                longVASignalsAllDefault[0]  = longVASignalsAll[0];

                shortSignalsAllDefault[0]    = shortSignalsAll[0];
                shortPOCSignalsAllDefault[0] = shortPOCSignalsAll[0];
                shortVCSignalsAllDefault[0]  = shortVCSignalsAll[0];
                shortVASignalsAllDefault[0]  = shortVASignalsAll[0];

                barTypeDefault[0] = barType[0];
                trendDefault[0]   = trend[0];
            }
            #endregion
            if (BarsInProgress == 0 && this.GZSLastCount != this.GZS.Count)
            {
                double[] avgStops = CalculateAvgStops();                    
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    try
                    {
                        #region -- RegAvgStopCalculation --
                        if (this.miAvgStopFirstTouch != null)
                        {
                            this.miAvgStopFirstTouch.Header = " First Touch: " + Instruments[0].MasterInstrument.RoundToTickSize(avgStops[0]);
                            this.miAvgStopPOC.Header = " POC: " + Instruments[0].MasterInstrument.RoundToTickSize(avgStops[1]);
                            this.miAvgStopVA.Header = " VA: " + Instruments[0].MasterInstrument.RoundToTickSize(avgStops[2]);
                            this.miAvgStopVC.Header = " Volume Cluster: " + Instruments[0].MasterInstrument.RoundToTickSize(avgStops[3]);
                        }
                        #endregion

                        #region -- RegAvgVolCalculation --
                        double[] avgVols = CalculateAvgVols();
                        if (this.miAvgVolPOC != null)
                        {
                            this.miAvgVolPOC.Header = " POC: " + Instruments[0].MasterInstrument.RoundToTickSize(avgVols[0]);
                            this.miAvgVolVA.Header = " VA: " + Instruments[0].MasterInstrument.RoundToTickSize(avgVols[1]);
                            this.miAvgVolVC.Header = " Volume Cluster: " + Instruments[0].MasterInstrument.RoundToTickSize(avgVols[2]);
                        }
                        #endregion
                    }
                    catch (Exception){};// e5507) {Print("5507  Err: "+e5507.ToString());}
                }));
                this.GZSLastCount = this.GZS.Count;
            }
		}
        #endregion
//==========================================================================================================================================
		private double GetTheATR(int BarNumber){
			int count = 0;
			double sum = 0;
			double tr=0;
			for(int abar = BarNumber; abar > Math.Max(0,BarNumber-ATRperiod); abar--){
				tr = truerange.GetValueAt(abar);
				sum = sum+tr;
				count++;
			}
			return sum/count;
		}
//==========================================================================================================================================
		public override void OnRenderTargetChanged()
		{
			#region dispose of brushes
			if(volumeClusterDXBrush!=null && !volumeClusterDXBrush.IsDisposed) volumeClusterDXBrush.Dispose(); volumeClusterDXBrush=null;
			if(iUpDXBrush!=null   && !iUpDXBrush.IsDisposed)      iUpDXBrush.Dispose();     iUpDXBrush=null;
			if(iDownDXBrush!=null && !iDownDXBrush.IsDisposed)    iDownDXBrush.Dispose();   iDownDXBrush=null;
			if(iTMDXBrush!=null   && !iTMDXBrush.IsDisposed)      iTMDXBrush.Dispose();      iTMDXBrush=null;
			if(iVRUDXBrush!=null  && !iVRUDXBrush.IsDisposed) iVRUDXBrush.Dispose();  iVRUDXBrush=null;
			if(iVRDDXBrush!=null  && !iVRDDXBrush.IsDisposed) iVRDDXBrush.Dispose();  iVRDDXBrush=null;
			if(iLVNDXBrush!=null  && !iLVNDXBrush.IsDisposed) iLVNDXBrush.Dispose();  iLVNDXBrush=null;
			if(iVAHDXBrush!=null  && !iVAHDXBrush.IsDisposed)  iVAHDXBrush.Dispose();  iVAHDXBrush=null;
			if(iPOCDXBrush!=null  && !iPOCDXBrush.IsDisposed) iPOCDXBrush.Dispose();  iPOCDXBrush=null;
			if(iVALDXBrush!=null  && !iVALDXBrush.IsDisposed) iVALDXBrush.Dispose();  iVALDXBrush=null;
			if(iDFTextBackDXBrush!=null && !iDFTextBackDXBrush.IsDisposed)   iDFTextBackDXBrush.Dispose();    iDFTextBackDXBrush=null;
			if(iVVTextBackDXBrush!=null && !iVVTextBackDXBrush.IsDisposed)   iVVTextBackDXBrush.Dispose();    iVVTextBackDXBrush=null;
			if(iQualifiedZoneBackDXBrush != null    && !iQualifiedZoneBackDXBrush.IsDisposed)    iQualifiedZoneBackDXBrush.Dispose();  iQualifiedZoneBackDXBrush =null;
			if(iDisqualifiedZoneBackDXBrush != null && !iDisqualifiedZoneBackDXBrush.IsDisposed) iDisqualifiedZoneBackDXBrush.Dispose();   iDisqualifiedZoneBackDXBrush =null;
			if(DXBrushes_LightGray!=null  && !DXBrushes_LightGray.IsDisposed)  DXBrushes_LightGray.Dispose();   DXBrushes_LightGray=null;
			if(DXBrushes_LightGreen!=null && !DXBrushes_LightGreen.IsDisposed) DXBrushes_LightGreen.Dispose();  DXBrushes_LightGreen=null;
			if(iTextDXBrush!=null     && !iTextDXBrush.IsDisposed)     iTextDXBrush.Dispose();  iTextDXBrush=null;
			if(iVA1_lineDXBrush!=null && !iVA1_lineDXBrush.IsDisposed) iVA1_lineDXBrush.Dispose(); iVA1_lineDXBrush=null;
			if(iVA1_fillDXBrush!=null && !iVA1_fillDXBrush.IsDisposed) iVA1_fillDXBrush.Dispose(); iVA1_fillDXBrush=null;
			if(iVA2_lineDXBrush!=null && !iVA2_lineDXBrush.IsDisposed) iVA2_lineDXBrush.Dispose(); iVA2_lineDXBrush=null;
			if(iVA2_fillDXBrush!=null && !iVA2_fillDXBrush.IsDisposed)  iVA2_fillDXBrush.Dispose(); iVA2_fillDXBrush=null;

			if(iFreshSupplyZoneOutlineDXBrush !=null && !iFreshSupplyZoneOutlineDXBrush.IsDisposed)  iFreshSupplyZoneOutlineDXBrush.Dispose();   iFreshSupplyZoneOutlineDXBrush=null;
			if(iTestedSupplyZoneOutlineDXBrush!=null && !iTestedDemandZoneOutlineDXBrush.IsDisposed) iTestedSupplyZoneOutlineDXBrush.Dispose();  iTestedSupplyZoneOutlineDXBrush=null;
			if(iBrokenSupplyZoneOutlineDXBrush!=null && !iBrokenSupplyZoneOutlineDXBrush.IsDisposed) iBrokenSupplyZoneOutlineDXBrush.Dispose();  iBrokenSupplyZoneOutlineDXBrush=null;
			if(iFreshDemandZoneOutlineDXBrush!=null  && !iFreshDemandZoneOutlineDXBrush.IsDisposed)  iFreshDemandZoneOutlineDXBrush.Dispose();   iFreshDemandZoneOutlineDXBrush=null;
			if(iTestedDemandZoneOutlineDXBrush!=null && !iTestedDemandZoneOutlineDXBrush.IsDisposed) iTestedDemandZoneOutlineDXBrush.Dispose();  iTestedDemandZoneOutlineDXBrush=null;
			if(iBrokenDemandZoneOutlineDXBrush!=null && !iBrokenDemandZoneOutlineDXBrush.IsDisposed) iBrokenDemandZoneOutlineDXBrush.Dispose();  iBrokenDemandZoneOutlineDXBrush=null;

			if(iFreshSupplyZoneDXBrush!=null  && !iFreshDemandZoneDXBrush.IsDisposed)   iFreshSupplyZoneDXBrush.Dispose();   iFreshSupplyZoneDXBrush=null;
			if(iTestedSupplyZoneDXBrush!=null && !iTestedDemandZoneDXBrush.IsDisposed) iTestedSupplyZoneDXBrush.Dispose();  iTestedSupplyZoneDXBrush=null;
			if(iBrokenSupplyZoneDXBrush!=null && !iBrokenSupplyZoneDXBrush.IsDisposed) iBrokenSupplyZoneDXBrush.Dispose();  iBrokenSupplyZoneDXBrush=null;
			if(iFreshDemandZoneDXBrush!=null  && !iFreshDemandZoneDXBrush.IsDisposed)  iFreshDemandZoneDXBrush.Dispose();   iFreshDemandZoneDXBrush=null;
			if(iTestedDemandZoneDXBrush!=null && !iTestedDemandZoneDXBrush.IsDisposed) iTestedDemandZoneDXBrush.Dispose();  iTestedDemandZoneDXBrush=null;
			if(iBrokenDemandZoneDXBrush!=null && !iBrokenDemandZoneDXBrush.IsDisposed) iBrokenDemandZoneDXBrush.Dispose();  iBrokenDemandZoneDXBrush=null;

			if(baseDXBrush!=null && !baseDXBrush.IsDisposed) baseDXBrush.Dispose(); baseDXBrush = null;
//				if( != null && !.IsDisposed) .Dispose();  = null;
			if(RectHighlightDXBrush != null && !RectHighlightDXBrush.IsDisposed) RectHighlightDXBrush.Dispose(); RectHighlightDXBrush = null;
			if(DXBrushes_Black != null      && !DXBrushes_Black.IsDisposed) DXBrushes_Black.Dispose(); DXBrushes_Black = null;
			if(tempBrush != null            && !tempBrush.IsDisposed) tempBrush.Dispose(); tempBrush = null;
			if(tempPen_DXBrush != null      && !tempPen_DXBrush.IsDisposed) tempPen_DXBrush.Dispose(); tempPen_DXBrush = null;
			if(pLineDXBrush1 != null        && !pLineDXBrush1.IsDisposed)   pLineDXBrush1.Dispose();   pLineDXBrush1 = null;
			if(iCurveAreaDXBrush1 != null   && !iCurveAreaDXBrush1.IsDisposed) iCurveAreaDXBrush1.Dispose(); iCurveAreaDXBrush1 = null;
			if(iCurveAreaDXBrush2 != null   && !iCurveAreaDXBrush2.IsDisposed) iCurveAreaDXBrush2.Dispose(); iCurveAreaDXBrush2 = null;
			if(iCurveAreaDXBrush3 != null   && !iCurveAreaDXBrush3.IsDisposed) iCurveAreaDXBrush3.Dispose(); iCurveAreaDXBrush3 = null;
			if(iCurveAreaDXBrush4 != null   && !iCurveAreaDXBrush4.IsDisposed) iCurveAreaDXBrush4.Dispose(); iCurveAreaDXBrush4 = null;

			#region -- TradePlan brushes --
			if(fillbrush!=null && !fillbrush.IsDisposed) fillbrush.Dispose(); 
			fillbrush = null;

			if(EntryDXBrush!=null && !EntryDXBrush.IsDisposed) EntryDXBrush.Dispose(); 
			EntryDXBrush = null;

			if(ShortSLDXBrush!=null && !ShortSLDXBrush.IsDisposed) ShortSLDXBrush.Dispose(); 
			ShortSLDXBrush = null;
			if(ShortT1DXBrush!=null && !ShortT1DXBrush.IsDisposed) ShortT1DXBrush.Dispose(); 
			ShortT1DXBrush = null;
			if(ShortT2DXBrush!=null && !ShortT2DXBrush.IsDisposed) ShortT2DXBrush.Dispose(); 
			ShortT2DXBrush = null;

			if(LongSLDXBrush!=null && !LongSLDXBrush.IsDisposed) LongSLDXBrush.Dispose(); 
			LongSLDXBrush = null;
			if(LongT1DXBrush!=null && !LongT1DXBrush.IsDisposed) LongT1DXBrush.Dispose(); 
			LongT1DXBrush = null;
			if(LongT2DXBrush!=null && !LongT2DXBrush.IsDisposed) LongT2DXBrush.Dispose(); 
			LongT2DXBrush = null;

			if(EntryContrastDXBrush!=null && !EntryContrastDXBrush.IsDisposed) EntryContrastDXBrush.Dispose(); 
			EntryContrastDXBrush = null;

			if(ShortSLContrastDXBrush!=null && !ShortSLContrastDXBrush.IsDisposed) ShortSLContrastDXBrush.Dispose(); 
			ShortSLContrastDXBrush = null;
			if(ShortT1ContrastDXBrush!=null && !ShortT1ContrastDXBrush.IsDisposed) ShortT1ContrastDXBrush.Dispose(); 
			ShortT1ContrastDXBrush = null;
			if(ShortT2ContrastDXBrush!=null && !ShortT2ContrastDXBrush.IsDisposed) ShortT2ContrastDXBrush.Dispose(); 
			ShortT2ContrastDXBrush = null;
			
			if(LongSLContrastDXBrush!=null && !LongSLContrastDXBrush.IsDisposed) LongSLContrastDXBrush.Dispose(); 
			LongSLContrastDXBrush = null;
			if(LongT1ContrastDXBrush!=null && !LongT1ContrastDXBrush.IsDisposed) LongT1ContrastDXBrush.Dispose(); 
			LongT1ContrastDXBrush = null;
			if(LongT2ContrastDXBrush!=null && !LongT2ContrastDXBrush.IsDisposed) LongT2ContrastDXBrush.Dispose(); 
			LongT2ContrastDXBrush = null;
			#endregion
			#endregion
			if(RenderTarget!=null){
				#region create brushes
				#region TradePlan DX Brushes
				fillbrush = null;
				EntryDXBrush  = EntryBrush.ToDxBrush(RenderTarget);
				EntryContrastDXBrush = ContrastingColor((SolidColorBrush)EntryBrush).ToDxBrush(RenderTarget);
				EntryContrastDXBrush.Opacity  = 0.5f;

				#region Long trade plan brushes
				LongSLDXBrush  = LongSLBrush.ToDxBrush(RenderTarget);
				LongSLContrastDXBrush = ContrastingColor((SolidColorBrush)LongSLBrush).ToDxBrush(RenderTarget);
				LongSLContrastDXBrush.Opacity  = 0.5f;

				LongT1DXBrush = LongT1Brush.ToDxBrush(RenderTarget);
				LongT1ContrastDXBrush     = ContrastingColor((SolidColorBrush)LongT1Brush).ToDxBrush(RenderTarget);
				LongT1ContrastDXBrush.Opacity = 0.5f;

				LongT2DXBrush = LongT2Brush.ToDxBrush(RenderTarget);
				LongT2ContrastDXBrush     = ContrastingColor((SolidColorBrush)LongT2Brush).ToDxBrush(RenderTarget);
				LongT2ContrastDXBrush.Opacity = 0.5f;
				#endregion

				#region Short trade plan brushes
				ShortSLDXBrush  = ShortSLBrush.ToDxBrush(RenderTarget);
				ShortSLContrastDXBrush = ContrastingColor((SolidColorBrush)ShortSLBrush).ToDxBrush(RenderTarget);
				ShortSLContrastDXBrush.Opacity  = 0.5f;

				ShortT1DXBrush = ShortT1Brush.ToDxBrush(RenderTarget);
				ShortT1ContrastDXBrush     = ContrastingColor((SolidColorBrush)ShortT1Brush).ToDxBrush(RenderTarget);
				ShortT1ContrastDXBrush.Opacity = 0.5f;

				ShortT2DXBrush = ShortT2Brush.ToDxBrush(RenderTarget);
				ShortT2ContrastDXBrush     = ContrastingColor((SolidColorBrush)ShortT2Brush).ToDxBrush(RenderTarget);
				ShortT2ContrastDXBrush.Opacity = 0.5f;
				#endregion
				#endregion

				volumeClusterDXBrush = iVCColor.ToDxBrush(RenderTarget); volumeClusterDXBrush.Opacity = (float)iVCOpacity / 100f;
				baseDXBrush = iProfileColor.ToDxBrush(RenderTarget);
				iVRDDXBrush = iVRDColor.ToDxBrush(RenderTarget);
				iVRUDXBrush = iVRUColor.ToDxBrush(RenderTarget);
				iDFTextBackDXBrush = iDFTextBackColor.ToDxBrush(RenderTarget);
				DXBrushes_LightGray = Brushes.LightGray.ToDxBrush(RenderTarget);
				DXBrushes_LightGreen = Brushes.LightGreen.ToDxBrush(RenderTarget);
				iFreshSupplyZoneDXBrush = iFreshSupplyZoneColor.ToDxBrush(RenderTarget);
				iTestedSupplyZoneDXBrush = iTestedSupplyZoneColor.ToDxBrush(RenderTarget);
				iBrokenSupplyZoneDXBrush = iBrokenSupplyZoneColor.ToDxBrush(RenderTarget);
				iFreshDemandZoneDXBrush = iFreshDemandZoneColor.ToDxBrush(RenderTarget);
				iTestedDemandZoneDXBrush = iTestedDemandZoneColor.ToDxBrush(RenderTarget);
				iBrokenDemandZoneDXBrush = iBrokenDemandZoneColor.ToDxBrush(RenderTarget);
				iFreshSupplyZoneOutlineDXBrush = iFreshSupplyZoneOutlineColor.ToDxBrush(RenderTarget);
				iTestedSupplyZoneOutlineDXBrush = iTestedSupplyZoneOutlineColor.ToDxBrush(RenderTarget);
				iBrokenSupplyZoneOutlineDXBrush = iBrokenSupplyZoneOutlineColor.ToDxBrush(RenderTarget);
				iFreshDemandZoneOutlineDXBrush = iFreshDemandZoneOutlineColor.ToDxBrush(RenderTarget);
				iTestedDemandZoneOutlineDXBrush = iTestedDemandZoneOutlineColor.ToDxBrush(RenderTarget);
				iBrokenDemandZoneOutlineDXBrush = iBrokenDemandZoneOutlineColor.ToDxBrush(RenderTarget);
				DXBrushes_Black = Brushes.Black.ToDxBrush(RenderTarget);
				tempBrush = Brushes.Black.ToDxBrush(RenderTarget);
				tempPen_DXBrush = Brushes.Black.ToDxBrush(RenderTarget);
				iVA1_lineDXBrush = iVA1_Color.ToDxBrush(RenderTarget);
				iVA1_fillDXBrush = iVA1_FillColor.ToDxBrush(RenderTarget); iVA1_fillDXBrush.Opacity = Convert.ToSingle(iVA3Opacity)/100.0f;
				iVA2_lineDXBrush = iVA2_Color.ToDxBrush(RenderTarget);
				iVA2_fillDXBrush = iVA2_FillColor.ToDxBrush(RenderTarget); iVA2_fillDXBrush.Opacity = Convert.ToSingle(iVAS3Opacity)/100.0f;
				//tempColor = Brushes.Black;
				iTMDXBrush = iTMColor.ToDxBrush(RenderTarget);	iTMDXBrush.Opacity = iTMOpacity/100f;
				iLVNDXBrush = iLVNColor.ToDxBrush(RenderTarget);
				iVAHDXBrush = iVAHColor.ToDxBrush(RenderTarget);
				iPOCDXBrush = iPOCColor.ToDxBrush(RenderTarget);
				iVALDXBrush = iVALColor.ToDxBrush(RenderTarget);
				iUpDXBrush = iUpColor.ToDxBrush(RenderTarget);
				iDownDXBrush = iDownColor.ToDxBrush(RenderTarget);
				iVVTextBackDXBrush = iVVTextBackColor.ToDxBrush(RenderTarget);
				iQualifiedZoneBackDXBrush = iQualifiedBackColor.ToDxBrush(RenderTarget);
				iDisqualifiedZoneBackDXBrush = iDisqualifiedBackColor.ToDxBrush(RenderTarget);
				iCurveAreaDXBrush1 = iCurveAreaBrush1.ToDxBrush(RenderTarget);
				iCurveAreaDXBrush2 = iCurveAreaBrush2.ToDxBrush(RenderTarget);
				iCurveAreaDXBrush3 = iCurveAreaBrush3.ToDxBrush(RenderTarget);
				iCurveAreaDXBrush4 = iCurveAreaBrush4.ToDxBrush(RenderTarget);
				pLineDXBrush1 = pLineColor1.ToDxBrush(RenderTarget);  pLineDXBrush1.Opacity = iOpacity1/100f;
				#endregion
			}
//Print("IsDisposed? "+tempBrush.IsDisposed.ToString()+"  IsValid? "+tempBrush.IsValid(RenderTarget).ToString());
		}
        private void drawstring(string text, float x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush,  SharpDX.Direct2D1.Brush bkgBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxX = -9999f)
        {
			#region drawstring
			if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
			//SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();

			var textFormat = new SharpDX.DirectWrite.TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
			)
				{ TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, ChartPanel.W/3, ChartPanel.H);
			if(x<0) x = Math.Abs(x) - textLayout.Metrics.Width - 5;

			if(MaxX>0)
				x = Math.Min(x, MaxX - 3f - textLayout.Metrics.Width);

			y = y - textLayout.Metrics.Height/2.0;
			if (bkgBrush!=null && bkgBrush.Opacity>0) {
				double xl = x - 3;
				double xr = x + textLayout.Metrics.Width + 3;
				double yt = y - 1;
				double yb = y+textLayout.Metrics.Height + 2;
				if(textAlignment==SharpDX.DirectWrite.TextAlignment.Trailing){
					xr = x + textLayout.Metrics.LayoutWidth +3;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				else if(textAlignment==SharpDX.DirectWrite.TextAlignment.Center){
					xr = x + textLayout.Metrics.LayoutWidth/2 + 3 + textLayout.Metrics.Width/2;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				var bkgBox = new System.Windows.Point[]
				{	new System.Windows.Point(xl, yt),
					new System.Windows.Point(xl, yb),
					new System.Windows.Point(xr, yb),
					new System.Windows.Point(xr, yt),
				};
				drawRegion(bkgBox, bkgBrush);
			}
			RenderTarget.DrawTextLayout(new SharpDX.Vector2(x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			textLayout.Dispose();
			textFormat.Dispose();
			#endregion
		}
//==========================================================================================================================================
		double priorChartMaxPrice = 0;
		double priorChartMinPrice = 0;
		int prior_lmab = 0;
		int prior_rmab = 0;
		bool newview = false;
        //26.05.16 - updated for Beta11 CBC : use Series<T>.getValueAt(CB) instead of Series<T>[0] due to multithread issue
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			if(GZS.Count==0) Draw.TextFixed(this,"info","No zones found...try adding more days of history to your chart",TextPosition.Center);
			#region -- OnRender() --
            #region -- conditions to return --
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (Instruments[0] == null || Instruments[1] == null) return;
            if (Instruments[0].FullName != Instruments[1].FullName) return;
            if (Bars == null || ChartControl == null) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
            if (this.GZS == null) return;
			if(IsInHitTest) return;
            #endregion
			int lastBarIndex = Math.Min(CurrentBars[0], ChartBars.ToIndex);//RIGHT BAR idx (slot)
			int firstBarIndex = Math.Max(1, ChartBars.FromIndex);// BarsRequiredToPlot;//FIRST LEFT BAR idx (slot)
			MM.price = chartScale.GetValueByY(MM.Y);
			MM.abar = Convert.ToInt32(chartControl.GetSlotIndexByX(MM.X));
//			if(chartScale.MaxValue != priorChartMaxPrice) {newview = true; priorChartMaxPrice = priorChartMaxPrice;}
//			if(chartScale.MinValue != priorChartMinPrice) {newview = true; priorChartMinPrice = priorChartMinPrice;}
//			if(firstBarIndex != prior_lmab) {newview = true; prior_lmab = firstBarIndex;}
//			if(lastBarIndex != prior_rmab)  {newview = true; prior_rmab = lastBarIndex;}

			//base.OnRender(chartControl, chartScale);
			SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
			if ((iVAEnabled || iVA2Enabled))
			{
				var abars_array = new int[] { 0,0,0,0 };
				var price_array = new double[] {0,0,0,0};
//				double h1=0;
//				double l1=0;
//				if (iVAEnabled)
//					Draw.Region(this,"ma1", CurrentBars[0]-firstBarIndex, CurrentBars[0]-lastBarIndex, MA1High, MA1Low, iVA1_Color, iVA1_FillColor,iVA3Opacity);
//				if (iVA2Enabled)
//					Draw.Region(this,"ma2", CurrentBars[0]-firstBarIndex, CurrentBars[0]-lastBarIndex, MA2High, MA2Low, iVA2_Color, iVA2_FillColor,iVA3Opacity);
				for (int i = lastBarIndex; i >firstBarIndex; i--)
				{
					abars_array[0] = i;
					abars_array[1] = i - 1;
					abars_array[2] = abars_array[1];
					abars_array[3] = abars_array[0];
                    #region -- draw MA1 --
                    if (iVAEnabled)
                    {
						price_array[0] = MA1Low.GetValueAt(i);
						price_array[1] = MA1Low.GetValueAt(i-1);
						price_array[2] = MA1High.GetValueAt(i-1);
						price_array[3] = MA1High.GetValueAt(i);
						//if (price_array[3] > chartScale.MinValue && price_array[3] < chartScale.MaxValue) 
						drawLine(price_array[3], price_array[2], abars_array[0], abars_array[1], iVA1_lineDXBrush, iVA3DashStyle, iVA3Width, chartControl, chartScale, true);
						//if (price_array[0]  > chartScale.MinValue && price_array[0] < chartScale.MaxValue) 
						drawLine(price_array[0], price_array[1], abars_array[0], abars_array[1], iVA1_lineDXBrush, iVA3DashStyle, iVA3Width, chartControl, chartScale, true);
						if (iVA3Opacity>0){// && MA1High.GetValueAt(i) > chartScale.MinValue && MA1Low.GetValueAt(i) > chartScale.MinValue) {
							draw_Region(
								price_array, 
								abars_array, 
								iVA1_fillDXBrush, chartControl, chartScale);
						}
                    }
					#endregion

					#region -- draw MA2 --
					if (iVA2Enabled)
					{
						price_array[0] = MA2Low.GetValueAt(i);
						price_array[1] = MA2Low.GetValueAt(i-1);
						price_array[2] = MA2High.GetValueAt(i-1);
						price_array[3] = MA2High.GetValueAt(i);
						//if (price_array[3] > chartScale.MinValue && price_array[3] < chartScale.MaxValue) 
						drawLine(price_array[3], price_array[2], abars_array[0], abars_array[1], iVA2_lineDXBrush, iVAS3DashStyle, iVAS3Width, chartControl, chartScale, true);
						//if (price_array[0] > chartScale.MinValue && price_array[0] < chartScale.MaxValue) 
						drawLine(price_array[0], price_array[1], abars_array[0], abars_array[1], iVA2_lineDXBrush, iVAS3DashStyle, iVAS3Width, chartControl, chartScale, true);
						if (iVAS3Opacity>0){// && MA2High.GetValueAt(i) > chartScale.MinValue && MA2Low.GetValueAt(i) > chartScale.MinValue) {
							draw_Region(
								price_array, 
								abars_array, 
								iVA2_fillDXBrush, chartControl, chartScale);
						}
                    }
                    #endregion
                }
            }
            gMin = chartScale.MinValue;
            gMax = chartScale.MaxValue;
            gChartScale = chartScale;
            gChartBounds = new Rect(chartControl.CanvasLeft, 0, chartControl.CanvasRight - chartControl.CanvasLeft, (int)chartScale.Height - (int)chartControl.AxisXHeight);

//Print(5594);
			
//			var bkg = (System.Windows.Media.SolidColorBrush)ChartControl.Background;
//            double a = 1 - (0.299 * bkg.Color.R + 0.587 * bkg.Color.G + 0.114 * bkg.Color.B) / 255;
//            if (a < 0.5) BkgContrastBrush = Brushes.Black; 
//            else BkgContrastBrush = Brushes.White;
			//BkgContrastDXBrush = BkgContrastBrush.ToDxBrush(RenderTarget);
			#region -- draw structure --            
            if (showZigZag)
            {
                RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

                if (ChartBars.FromIndex >= 2)
                {
                    int RMB = ChartBars.ToIndex;

                    int pTextOffset = 15;
                    double PreviousDir = 0;
                    double PreviousPrice = 0;
                    int PreviousBB = 0;
                    double ThisSize = 0;
                    string FS = string.Empty;
                    float SZ = getTextWidth("", mstTextFont);

                    Brush StructureLabelBrush = Brushes.Black;

                    int j = ChartBars.FromIndex;
                    while ((AllPivots.GetValueAt(j) != 1 && AllPivots.GetValueAt(j) != 1 && j > 0) || j == ChartBars.FromIndex) { j = j - 1; }

                    int k = Math.Min(CurrentBars[0], ChartBars.ToIndex);

                    try
                    {
                        for (int i = j; i <= k; i++)
                        {
                            int BB = Math.Max(0, Math.Min(CurrentBars[0], CurrentBars[0] - i));
                            if (AllPivots.GetValueAt(i) == 1 || AllPivots.GetValueAt(i) == -1)
                            {
                                x1 = ChartControl.GetXByBarIndex(chartControl.BarsArray[0], i);
                                x2 = ChartControl.GetXByBarIndex(chartControl.BarsArray[0], PreviousBB);

                                if (PreviousPrice != 0)
                                {
                                    #region -- Up Trend --
                                    if (AllPivots.GetValueAt(i) == 1)
                                    {
                                        y1 = chartScale.GetYByValue(FinalHigh.GetValueAt(i));
                                        y2 = chartScale.GetYByValue(PreviousPrice);

                                        if (!IsInHitTest) {
											drawLine(x1, x2, y1, y2, iUpDXBrush, dash0Style, plot0Width);
										}

                                        if (showLabels)
                                        {
                                            FS = HighLabels[i];
                                            if (FS == "HH" || FS == "HL") StructureLabelBrush = iUpColor;
                                            else if (FS == "LH" || FS == "LL") StructureLabelBrush = iDownColor;
                                            else StructureLabelBrush = iNeutralColor;

                                            SZ = getTextWidth(FS, mstTextFont);
                                            if (!IsInHitTest) drawString(FS, x1 - SZ / 2, y1 - pTextOffset - mstTextFont.Size, mstTextFont, StructureLabelBrush, SharpDX.DirectWrite.TextAlignment.Center);                                            
                                        }
                                    }
                                    #endregion

                                    #region -- Down Trend --
                                    if (AllPivots.GetValueAt(i) == -1)
                                    {
                                        y1 = chartScale.GetYByValue(FinalLow.GetValueAt(i));
                                        y2 = chartScale.GetYByValue(PreviousPrice);

                                        if (!IsInHitTest) {
											drawLine(x1, x2, y1, y2, iDownDXBrush, dash0Style, plot0Width);
										}

                                        if (showLabels)
                                        {
                                            ThisSize = PreviousPrice - FinalLow.GetValueAt(i);
                                            FS = LowLabels[i];
                                            if (FS == "HH" || FS == "HL") StructureLabelBrush = iUpColor;
                                            else if (FS == "LH" || FS == "LL") StructureLabelBrush = iDownColor;
                                            else StructureLabelBrush = iNeutralColor;

                                            SZ = getTextWidth(FS, mstTextFont);

                                            if (!IsInHitTest) drawString(FS, x1 - SZ / 2, y1 + pTextOffset - mstTextFont.Size, mstTextFont, StructureLabelBrush, SharpDX.DirectWrite.TextAlignment.Center);                                            
                                        }
                                    }
                                    #endregion
                                }
                                PreviousBB = i;
                                PreviousDir = AllPivots.GetValueAt(i);
                                if (PreviousDir == 1) PreviousPrice = FinalHigh.GetValueAt(i);
                                if (PreviousDir == -1) PreviousPrice = FinalLow.GetValueAt(i);
                            }
                        }
                    }
                    catch{ }
                }

                RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
            }
            #endregion

            #region -- ShowSDVZones --
            if (this.iShowSDVZones)
            {
				int textfontHeight = Convert.ToInt32(iTextFont.Size);
				var zkvp = GZS.Where(x=>x.Top> gMin && x.Bottom < gMax && x.StartBar < lastBarIndex && (x.EndBar==0 || x.EndBar > firstBarIndex)).ToList();
//if(IsDebug && GZS.Count>0) 	Print("GZS.Count: "+GZS.Count);
//				for (int g = 0; g < this.GZS.Count; g++)
				foreach(GZone z in zkvp)
				{
					z.Visible = false;

                    if (z.StartTime.CompareTo(BarsArray[0].GetTime(1)) < 0 || z.EndTime.CompareTo(BarsArray[0].GetTime(1)) < 0) continue;

                    int xEndBarPx = ChartControl.GetXByTime(z.EndTime);
                    if (z.State != GZ_BROKEN) xEndBarPx = chartControl.CanvasRight;
                    double idxFormedBarPx = ChartControl.GetSlotIndexByTime(BarsArray[UseChartBars ? 0 : 2].GetTime(z.FormedBar));//get slot index on primary bar based on FormedBar index on MTF bar (if MTF)
//if(IsDebug) Print("GZS.State: "+z.State.ToString());
                    if (idxFormedBarPx > ChartBars.ToIndex + 1) continue;//v1.006 - Draw zones only when formed bar is visible + FIXED MTF issue
                    if (!this.iShowHiddenZones && this.iAutoHideRetests && z.State == GZ_HIDDEN) continue;
                    if (!this.iShowBrokenZones && z.State  == GZ_BROKEN) continue;
                    if (!this.iShowTestedZones && (z.State == GZ_RETEST || z.State == GZ_TESTED)) continue;
                    if (!this.iShowFreshZones  && (z.State == GZ_FORMED || z.State == GZ_FRESH)) continue;
                    if (!this.iShowSupplyZones && z.Type   == GZ_SUPPLY) continue;
                    if (!this.iShowDemandZones && z.Type   == GZ_DEMAND) continue;
					if(iFilterQualifiedZones){
						bool c1 = !pQualifyOnVolume || z.IsLowVolumeVA;
						bool c2 = !pQualifyOnThrust || z.IsSufficientThrust;
						bool c3 = !pQualifyOnBasingCount || z.IsSufficientBase;
						if(!c1 || !c2 || !c3) continue;//if its a disqualified zone, none of these conditions will be true
					}
//if(IsDebug) Print("GZS is visible");

                    z.Visible = true;

                    #region -- Init Buttons as rectangles
                    int xStartBarPx       = ChartControl.GetXByTime(z.StartTime);
					int yTopPx            = chartScale.GetYByValue(z.Top);// + textfontHeight;//this helps include the upper button graphic on this zone
                    int yBottomPx         = chartScale.GetYByValue(z.Bottom);// - 2*textfontHeight;//this helps include the lower button graphics on this zone
                    if ((xEndBarPx - xStartBarPx) <= 0 || (yBottomPx - yTopPx) <= 0) continue;
                    z.Rect = new Rect(xStartBarPx, yTopPx, (xEndBarPx - xStartBarPx), (yBottomPx - yTopPx));
                    z.MouseRects[CENTER]	 = new Rect(z.Rect.Left, z.Rect.Top, z.Rect.Width, z.Rect.Height);
                    z.MouseRects[UPPER_LEFT] = new Rect(z.Rect.Left - 5, z.Rect.Top - 5, 11, 11);
//drawRectangle(z.MouseRects[UPPER_LEFT], iPOCDXBrush, tempPenDashStyle, 3);

                    int startb = 7;
                    for (int b = CONTROLZ; b <= CONTROLX; b++)
                    {
                        int width = (b == CONTROLZ ? 25 : 15);
                        z.MouseRects[b] = new Rect(z.Rect.Left + startb, z.Rect.Top + 2, width, 15);
                        startb += width;
                    }
                    startb = 7;
                    int startby = (int)z.Rect.Bottom-10*2;
                    for (int b = CONTROLPL; b <= CONTROLPVV; b++)
                    {
                        int width = (b == CONTROLPL ? 25 : 30);

                        if (b == CONTROLPVC)
                        {
                            startb = 7 + 25;
                            startby += 15;
                        }

                        if (iProfileCalcTimeFrame == ARC_SDVSystem_ProfileDataType.TICK || (iProfileCalcTimeFrame != ARC_SDVSystem_ProfileDataType.TICK && b != CONTROLPDF && b != CONTROLPPT))
                        {
                            z.MouseRects[b] = new Rect(z.Rect.Left + startb, startby, width, 15);
                            startb += width;
                        }
                    }
//		CONTROLZ = 4;
//		CONTROLX = 5;
//		CONTROLPL = 8;
//		CONTROLPPR = 9;
//		CONTROLPPC = 10;
//		CONTROLPVL = 11;
//		CONTROLPVH = 12;
//		CONTROLPVP = 13;
//		CONTROLPVC = 14;
//		CONTROLPPT = 15;
//		CONTROLPDF = 16;
//		CONTROLPVV = 17;
//		CENTER     = 18;

					z.MouseRects[LOWER_LEFT]  = new Rect(z.Rect.Left - 5,  z.Rect.Bottom - 5, 11, 11);
                    z.MouseRects[LOWER_RIGHT] = new Rect(z.Rect.Right - 5, z.Rect.Bottom - 5, 11, 11);
                    z.MouseRects[UPPER_RIGHT] = new Rect(z.Rect.Right - 5, z.Rect.Top    - 5, 11, 11);
                    #endregion
                    
                    #region -- Zones Drawing --
                    #region -- Broken Zone --
                    if (z.State == GZ_BROKEN)
                    {
						this.SetPaintStyle(z.Type, z.State);
						drawRegion(z.Rect, tempBrush, (int)(tempBrush.Opacity * 100));
                    }
                    #endregion
                    else
                    {
	                    int yTestMarkerPx     = chartScale.GetYByValue(z.TestMarker);
                        #region -- TestMarker Shader (GZ_FRESH / GZ_TESTED ) --
                        if (this.iShowTestedShading)
                        {
                            if (z.Type == GZ_SUPPLY)
                            {
                                this.SetPaintStyle(z.Type, GZ_FRESH);
                                drawRegion(z.Rect.X, z.Rect.Y, z.Rect.Width, Math.Abs(yTestMarkerPx - z.Rect.Y), tempBrush, (int)(tempBrush.Opacity * 100));

                                this.SetPaintStyle(z.Type, GZ_TESTED);
                                drawRegion(z.Rect.X, z.Rect.Top + Math.Abs(yTestMarkerPx - z.Rect.Y), z.Rect.Width, Math.Abs(z.Rect.Bottom - yTestMarkerPx), tempBrush, (int)(tempBrush.Opacity * 100)); 
                            }
                            else
                            {
                                this.SetPaintStyle(z.Type, GZ_TESTED);
                                drawRegion(z.Rect.X, z.Rect.Y, z.Rect.Width, Math.Abs(yTestMarkerPx - z.Rect.Y), tempBrush, (int)(tempBrush.Opacity * 100));

                                this.SetPaintStyle(z.Type, GZ_FRESH);
                                drawRegion(z.Rect.X, z.Rect.Top + Math.Abs(yTestMarkerPx - z.Rect.Y), z.Rect.Width, Math.Abs(z.Rect.Bottom - yTestMarkerPx), tempBrush, (int)(tempBrush.Opacity * 100));
                            }
                        }
                        else
                        {
                            this.SetPaintStyle(z.Type, z.State);
                            drawRegion(z.Rect, tempBrush, (int)(tempBrush.Opacity * 100));
                        }
                        #endregion

                        #region -- TestMarker (GZ_TESTED / GZ_RETEST ) --
                        if (this.iShowTestedMarker && (z.State == GZ_RETEST || z.State == GZ_TESTED))
                        {
                            drawLine(z.Rect.Left, z.Rect.Right, yTestMarkerPx, yTestMarkerPx, iTMDXBrush, DashStyleHelper.Solid, this.iTMThickness, iTMOpacity);
                        }
                        #endregion
                    }
                    #endregion

                    #region -- PlotHist --
                   // Brush baseColor = iProfileColor;
                    
                    int totalB = z.Hist.GetTotalBins();
                    float totalLB = (float)z.Hist.LargestBinTotal;
                    if (totalB > 0 && totalLB > 0)
                    {
                        float scalar = ((float)z.Hist.Total / totalLB);
                        int widthPx = (int)(z.Rect.Width / 4);

                        if (z.MouseBtnIStates[CONTROLPVP] == 1) widthPx *= 2;
                        else if (z.MouseBtnIStates[CONTROLPVP] == 2) widthPx *= 3;
                        else if (z.MouseBtnIStates[CONTROLPVP] == 3) widthPx = (int)z.Rect.Width;
                        
                        //v1.008 - added calculate LVNs

                        for (double p = z.Hist.GetBin(0); p <= z.Hist.GetBin(totalB - 1); p = Instruments[0].MasterInstrument.RoundToTickSize(p + gbTickSize))
                        {
                            int binHistHeight = Math.Abs(chartScale.GetYByValue(p + (gbTickSize / 2.0)) - chartScale.GetYByValue(p - (gbTickSize / 2.0)));
                            int binHistWidth = Math.Min(widthPx, (int)(scalar * (float)(widthPx) * ((float)z.Hist.GetTotal(p) / (float)z.Hist.Total)));

                            if (binHistWidth == 0 && z.Hist.GetTotal(p) != 0) binHistWidth = 1;

                            overlapDXBrush[0] = baseDXBrush;
                            overlapDXBrush[1] = baseDXBrush;
                            overlapDXBrush[2] = baseDXBrush;

                            overlapOpacity[0] = iProfileOpacity;
                            overlapOpacity[1] = iProfileOpacity;
                            overlapOpacity[2] = iProfileOpacity;

                            overlapThickness[0] = this.iProfileThickness;
                            overlapThickness[1] = this.iProfileThickness;
                            overlapThickness[2] = this.iProfileThickness;

                            int overlapCount = 0;
                            int sumOverlapHeight = 0;

                            bool isLVN = false;
                            if (this.iShowLVNProfile && z.Hist.LVNs.Contains(p))
                            {
                                overlapDXBrush[0] = iLVNDXBrush;
                                overlapOpacity[0] = iLVNOpacity;
                                overlapThickness[0] = (float)this.iLVNThickness;
                                overlapCount++;
                                sumOverlapHeight += this.iLVNThickness;
                                isLVN = true;
                            }

                            if (z.MouseBtnStates[CONTROLPVH] && p == z.Hist.VAH)
                            {
                                overlapDXBrush[overlapCount] = this.iVAHDXBrush;
                                overlapOpacity[overlapCount] = iVAHOpacity;
                                overlapThickness[overlapCount] = (float)this.iVAHThickness;
                                overlapCount++;
                                sumOverlapHeight += this.iVAHThickness;
                            }
                            if (z.MouseBtnStates[CONTROLPPC] && p == z.Hist.POC)
                            {
                                overlapDXBrush[overlapCount] = this.iPOCDXBrush;
                                overlapOpacity[overlapCount] = iPOCOpacity;
                                overlapThickness[overlapCount] = (float)this.iPOCThickness;
                                overlapCount++;
                                sumOverlapHeight += this.iPOCThickness;
                            }
                            if (z.MouseBtnStates[CONTROLPVL] && p == z.Hist.VAL)
                            {
                                overlapDXBrush[overlapCount] = this.iVALDXBrush;
                                overlapOpacity[overlapCount] = iVALOpacity;
                                overlapThickness[overlapCount] = (float)this.iVALThickness;
                                overlapCount++;
                                sumOverlapHeight += this.iVALThickness;
                            }
                            if (overlapCount == 0) overlapCount = 1;

                            if (z.MouseBtnStates[CONTROLPPR] || overlapDXBrush[0] != baseDXBrush)
                            {
                                if (overlapCount > 1) binHistHeight = Math.Min(sumOverlapHeight, binHistHeight);

                                int oHeight = (int)((double)binHistHeight / (double)overlapCount);
                                int hHeight = (int)((double)binHistHeight / 2.0);

                                int tHeight = 0;
                                int bHeight = oHeight;
                                int bY = chartScale.GetYByValue(p + (gbTickSize / 2.0));
                                int pY = chartScale.GetYByValue(p);

                                int binHistWidthLevel = binHistWidth;

                                for (int o = 0; o < overlapCount; o++)
                                {
                                    if (isLVN && o == 0)
                                    {
                                        if (this.iExpandLVNProfile) binHistWidthLevel = (int)z.Rect.Width;
                                        else binHistWidthLevel = binHistWidth;
                                    }
                                    else if (z.MouseBtnIStates[CONTROLPVP] == 4 && overlapDXBrush[o] != baseDXBrush) binHistWidthLevel = (int)z.Rect.Width;
                                    else binHistWidthLevel = binHistWidth;
                                    //-------------------------------------
                                    if (overlapCount > 1) {
										drawRegion(z.Rect.X, pY - hHeight, binHistWidthLevel, bHeight, overlapDXBrush[o], overlapOpacity[o]);
									}
                                    else {
										drawLine(z.Rect.X, z.Rect.X + binHistWidthLevel, pY, pY, overlapDXBrush[o], DashStyleHelper.Solid, Math.Abs(Math.Min(binHistHeight, (int)overlapThickness[o])), overlapOpacity[o]);//Math.Abs added Ben Oct 14 2020
									}

                                    bHeight = Math.Min(binHistHeight - tHeight, oHeight);
                                    pY += bHeight;
                                    bY += bHeight;
                                    tHeight += oHeight;
                                }
                            }
                        }

                        string upText   = (z.Hist.UpPercent * 100.0).ToString("00.0") + "%";
                        string downText = (z.Hist.DownPercent * 100.0).ToString("00.0") + "%";
                        string netText  = z.Hist.NetTicks.ToString();

                        int upDownWidth = 5 + (int)Math.Max(getTextWidth(upText, this.iVRTextFont), Math.Max(getTextWidth(netText, this.iVRTextFont), getTextWidth(downText, this.iVRTextFont)));

                        int totalHeight = (int)z.Rect.Height;
                        int upHeight    = (int)((double)totalHeight * z.Hist.UpPercent);
                        int downHeight  = totalHeight - upHeight;

                        Rect upRect          = new Rect(z.Rect.X - upDownWidth - 10, z.Rect.Y, upDownWidth, upHeight);
                        Rect upTextRect      = new Rect(upRect.X, upRect.Bottom - (int)this.iVRTextFont.Size, upDownWidth, (int)this.iVRTextFont.Size);
                        Rect upNetTextRect   = new Rect(upRect.X, upRect.Top - (int)this.iDFTextFont.Size, upDownWidth, (int)this.iDFTextFont.Size);
                        Rect downRect        = new Rect(z.Rect.X - upDownWidth - 10, z.Rect.Y + upHeight, upDownWidth, downHeight);
                        Rect downTextRect    = new Rect(downRect.X, downRect.Top, upDownWidth, (int)this.iVRTextFont.Size);
                        Rect downNetTextRect = new Rect(downRect.X, downRect.Bottom, upDownWidth, (int)this.iDFTextFont.Size);

                        if (z.MouseBtnStates[CONTROLPPT])
                        {
                            drawRegion(upRect, iVRUDXBrush, iVRUOpacity);
                            drawString(upText, upTextRect, this.iVRTextFont, iVRTextColor);

                            drawRegion(downRect, iVRDDXBrush, iVRDOpacity);
                            drawString(downText, downTextRect, this.iVRTextFont, iVRTextColor);
                        }

                        if (z.MouseBtnStates[CONTROLPDF])
                        {
                            if (z.Hist.NetTicks > 0)
                            {
                                drawRegion(upNetTextRect, iDFTextBackDXBrush, iDFTextBackOpacity);
                                drawString(netText, upNetTextRect, this.iDFTextFont, iDFUTextColor);
                            }
                            else
                            {
                                drawRegion(downNetTextRect, iDFTextBackDXBrush, iDFTextBackOpacity);
                                drawString(netText, downNetTextRect, this.iDFTextFont, iDFDTextColor);
                            }
                        }

						if (z.MouseBtnStates[CONTROLPVV])
                        {
                            string vvString = string.Empty;

                            if (z.Hist.GetTotalBins() > 0 && z.Hist.GetTotal(z.Hist.POC) > 0)
                            {
                                vvString = string.Format("{0}POC: {1}", vvString, z.Hist.GetTotal(z.Hist.POC));
                                vvString = string.Format("{0}\nVA: {1}", vvString, z.TotVolVA);
                            }

                            if (z.Hist.GetTotalBins() > 2 && z.Hist.VolumeClusterTop != double.MinValue && z.Hist.VolumeClusterTop != double.MinValue)
                            {
                                long sum = 0;
                                for (double p = z.Hist.VolumeClusterBottom; p <= z.Hist.VolumeClusterTop; p = Instruments[0].MasterInstrument.RoundToTickSize(p + gbTickSize))
                                    sum += z.Hist.GetTotal(p);
                                vvString = string.Format("{0}\nVC: {1}",vvString, sum.ToString());
                            }

                            int vvWidth = (int)getTextWidth(vvString, this.iVVTextFont) + 2;
                            int vvHeight = (int)getTextHeight(vvString, this.iVVTextFont) + 5;//(int)this.iVVTextFont.Size + 5;

                            Rect vvRect1 = new Rect(z.Rect.X - (upDownWidth + 10) - (vvWidth + 10), z.Rect.Y + (z.Rect.Height - (double)vvHeight) / 2, vvWidth, vvHeight);//v1.003 - Bug Fixed
                            Rect vvRect2 = new Rect(z.Rect.X - vvWidth - 10, z.Rect.Y + (z.Rect.Height - (double)vvHeight) / 2, vvWidth, vvHeight);//v1.003 - Bug Fixed

							if(pQualifyOnBasingCount || pQualifyOnVolume || pQualifyOnThrust){
								bool c1 = !pQualifyOnVolume || z.IsLowVolumeVA;
								bool c2 = !pQualifyOnThrust || z.IsSufficientThrust;
								bool c3 = !pQualifyOnBasingCount || z.IsSufficientBase;
								if(c1 && c2 && c3){
									if (!z.MouseBtnStates[CONTROLPPT]) drawRegion(vvRect2, iQualifiedZoneBackDXBrush, iVVTextBackOpacity);
									else drawRegion(vvRect1, iQualifiedZoneBackDXBrush, iVVTextBackOpacity);
								}else{
									if (!z.MouseBtnStates[CONTROLPPT]) drawRegion(vvRect2, iDisqualifiedZoneBackDXBrush, iVVTextBackOpacity);
									else drawRegion(vvRect1, iDisqualifiedZoneBackDXBrush, iVVTextBackOpacity);
								}
							}else{
								if (!z.MouseBtnStates[CONTROLPPT]) drawRegion(vvRect2, iVVTextBackDXBrush, iVVTextBackOpacity);
								else drawRegion(vvRect1, iVVTextBackDXBrush, iVVTextBackOpacity);
							}

                            if (!z.MouseBtnStates[CONTROLPPT]) drawString(vvString, vvRect2.X, vvRect2.Y + 2.5, this.iVVTextFont, iVVTextColor, SharpDX.DirectWrite.TextAlignment.Center);//v1.003 - Bug Fixed
                            else drawString(vvString, vvRect1.X, vvRect1.Y + 2.5, this.iVVTextFont, iVVTextColor, SharpDX.DirectWrite.TextAlignment.Center);//v1.003 - Bug Fixed
                        }
                        if (z.MouseBtnStates[CONTROLPVC])
                        {
                            if (z.Hist.VolumeClusterTop != double.MinValue && z.Hist.VolumeClusterTop != double.MinValue)
                            {
                                SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
                                SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();

                                int bin = 0;
                                for (double p = z.Hist.VolumeClusterBottom; p <= z.Hist.VolumeClusterTop; p = Instruments[0].MasterInstrument.RoundToTickSize(p + gbTickSize))
                                {
                                    int binHistHeight = Math.Abs(chartScale.GetYByValue(p + (gbTickSize / 2.0)) - chartScale.GetYByValue(p - (gbTickSize / 2.0)));
                                    int binHistWidth = Math.Min(widthPx, (int)(scalar * (float)(widthPx) * ((float)z.Hist.GetTotal(p) / (float)z.Hist.Total)));
                                    if (binHistWidth == 0 && z.Hist.GetTotal(p) != 0) binHistWidth = 1;

                                    if (bin == 0)
                                    {
                                        sink1.BeginFigure(new SharpDX.Vector2((float)z.Rect.X, chartScale.GetYByValue(p - (gbTickSize / 2.0))), SharpDX.Direct2D1.FigureBegin.Filled);
                                        sink1.AddLine(new SharpDX.Vector2((float)z.Rect.X + binHistWidth, chartScale.GetYByValue(p - (gbTickSize / 2.0))));
                                        sink1.AddLine(new SharpDX.Vector2((float)z.Rect.X + binHistWidth, chartScale.GetYByValue(p + (gbTickSize / 2.0))));
                                    }
                                    else if (bin == 1)
                                    {
                                        sink1.AddLine(new SharpDX.Vector2((float)z.Rect.X + binHistWidth, chartScale.GetYByValue(p - (gbTickSize / 2.0))));
                                        sink1.AddLine(new SharpDX.Vector2((float)z.Rect.X + binHistWidth, chartScale.GetYByValue(p + (gbTickSize / 2.0))));
                                    }
                                    else if (bin == 2)
                                    {
                                        sink1.AddLine(new SharpDX.Vector2((float)z.Rect.X + binHistWidth, chartScale.GetYByValue(p - (gbTickSize / 2.0))));
                                        sink1.AddLine(new SharpDX.Vector2((float)z.Rect.X + binHistWidth, chartScale.GetYByValue(p + (gbTickSize / 2.0))));
                                        sink1.AddLine(new SharpDX.Vector2((float)z.Rect.X, chartScale.GetYByValue(p + (gbTickSize / 2.0))));
                                    }
                                    bin++;
                                }
                                sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
                                sink1.Close();
                                RenderTarget.DrawGeometry(geo1, volumeClusterDXBrush, (float)this.iVCThickness);

                                geo1.Dispose();
                                sink1.Dispose();
                            }
                        }
                    }
                    #endregion
                    
                    //Hilight Zone if hover
                    if (this.MM.HoverIndex != z.IDnum) 
						this.SetPaintStyle(z.Type, z.State);
                    else 
						this.SetPaintStyle(z.Type, GZ_HOVER);
                    drawRectangle(z.Rect, tempPen_DXBrush, tempPenDashStyle, (int)tempPen.Thickness);

                    #region -- if Mouse over zone
                    if (this.MM.HoverIndex == z.IDnum)
                    {
						bool c1 = (this.MM.Index >= CONTROLZ && this.MM.Index <= CONTROLX);
						bool c2 = (this.MM.Index >= CONTROLPL && this.MM.Index <= CONTROLPVV);
//if(c1)Print("c1 7679  "+MM.Index+"  z.PLocked: "+z.PLocked.ToString());
//if(c2)Print("c2 7680  "+MM.Index+"  z.PLocked: "+z.PLocked.ToString());
                        if (c1 || c2 || this.MM.Index == CENTER)
                        {
                            #region -- Zone --
                            this.SetPaintStyle(z.Type, GZ_CONTROL);
                            drawRegion(z.MouseRects[CONTROLZ], this.tempBrush, (int)(tempBrush.Opacity * 100));
                            drawRectangle(z.MouseRects[CONTROLZ], this.tempPen_DXBrush, this.tempPenDashStyle, (int)this.tempPen.Thickness);

                            if (z.Locked)
                                drawString(string.Format("{0}>",z.MouseBtnText[CONTROLZ]), z.MouseRects[CONTROLZ], ChartControl.Properties.LabelFont, tempPen.Brush);
                            else
                            {
                                drawString(z.MouseBtnText[CONTROLZ], z.MouseRects[CONTROLZ], ChartControl.Properties.LabelFont, tempPen.Brush);
                                this.SetPaintStyle(z.Type, GZ_CONTROL);

                                drawRegion(z.MouseRects[CONTROLX], this.tempBrush, (int)(tempBrush.Opacity * 100));
                                drawRectangle(z.MouseRects[CONTROLX], this.tempPen_DXBrush, this.tempPenDashStyle, (int)this.tempPen.Thickness);
                                drawString(z.MouseBtnText[CONTROLX], z.MouseRects[CONTROLX], ChartControl.Properties.LabelFont, tempPen.Brush);
//Print(" "+r+"  txt: "+z.MouseBtnText[r]);
                            }
                            #endregion

                            #region -- Profile controls --
                            this.SetPaintStyle(z.Type, GZ_CONTROL);

                            drawRegion(z.MouseRects[CONTROLPL], this.tempBrush, (int)(tempBrush.Opacity * 100));
                            drawRectangle(z.MouseRects[CONTROLPL], this.tempPen_DXBrush, this.tempPenDashStyle, (int)this.tempPen.Thickness);
                            if (z.PLocked)
								drawString(string.Format("{0}>",z.MouseBtnText[CONTROLPL]), z.MouseRects[CONTROLPL], ChartControl.Properties.LabelFont, tempPen.Brush);
                            else
                            {
                                drawString(z.MouseBtnText[CONTROLPL], z.MouseRects[CONTROLPL], ChartControl.Properties.LabelFont, tempPen.Brush);

                                for (int r = CONTROLPPR; r <= CONTROLPVV; r++)
                                {
                                    if (z.MouseRects[r] == Rect.Empty) continue;

                                    this.SetPaintStyle(z.Type, GZ_CONTROL);
                                    if (z.MouseBtnStates[r]) this.SetPaintStyle(z.Type, GZ_CONTROL_ACTIVE);

                                    drawRegion(z.MouseRects[r], this.tempBrush, (int)(tempBrush.Opacity * 100));
                                    drawRectangle(z.MouseRects[r], this.tempPen_DXBrush, this.tempPenDashStyle, (int)this.tempPen.Thickness);
                                    drawString(z.MouseBtnText[r], z.MouseRects[r], ChartControl.Properties.LabelFont, tempPen.Brush);
                                }                                
                            }
                            #endregion
                        }
                        if ((!z.PLocked && this.MM.Index >= CONTROLPL && this.MM.Index <= CONTROLPVV) || (this.MM.Index == CONTROLPL))
                        {
                            this.SetPaintStyle(z.Type, GZ_HOVER);
                            drawRectangle(z.MouseRects[this.MM.Index], this.tempPen_DXBrush, this.tempPenDashStyle, (int)this.tempPen.Thickness);
//drawRectangle(z.MouseRects[MM.Index], iPOCDXBrush, tempPenDashStyle, 3);
                        }
                    }
                    #endregion

                    #region -- hide text if zone is scrolled off the right side
                    if (xStartBarPx < chartControl.CanvasRight)
                    {
                        if (this.iShowPriceLabels && z.State != GZ_BROKEN)
                        {
                            this.SetPaintStyle(0, GZ_LABEL);

                            string tempLabel = Instrument.MasterInstrument.FormatPrice(z.Top);
                            drawString(tempLabel, chartControl.CanvasRight - getTextWidth(tempLabel, iTextFont), yTopPx - (int)iTextFont.Size, iTextFont, tempPen.Brush, SharpDX.DirectWrite.TextAlignment.Center);

                            tempLabel = Instrument.MasterInstrument.FormatPrice(z.Bottom);
                            drawString(tempLabel, chartControl.CanvasRight - getTextWidth(tempLabel, iTextFont), yBottomPx, iTextFont, tempPen.Brush, SharpDX.DirectWrite.TextAlignment.Center);

                        }
                    }
                    #endregion
                }
            }
            #endregion

			#region -- CURVE ON STRUCTURE --
            x8 = chartControl.CanvasRight - chartControl.CanvasLeft;
            BB2 = ChartBars.ToIndex;//Math.Max(0, CurrentBars[0] - ChartBars.ToIndex);
            CB = 0;
            CH = 0;
            CL = 0;

            if (pIncludeZone)
            {
                CH = CurveHighZ.GetValueAt(BB2);
                CL = CurveLowZ.GetValueAt(BB2);
                CB = (int)CurveBar.GetValueAt(BB2);
            }
            else
            {

                CH = CurveHigh.GetValueAt(BB2);
                CL = CurveLow.GetValueAt(BB2);
                CB = (int)CurveBar.GetValueAt(BB2);
            }

            if (pDisplayEnabled && CH != 99999999 && CL != 0) DrawCurve(chartControl, chartScale, CH, CL, ChartBars.ToIndex, 0, true);
            #endregion

			#region -- Show Trade Plans --
			if(GZS.Count>0 && (ShowLongTradePlans || ShowShortTradePlans)) {
				int RMaB = Math.Min(ChartBars.ToIndex, CurrentBars[0]);
				float x_rmab = chartControl.GetXByBarIndex(ChartBars, RMaB);
				var gl = GZS.Where(k=> k.ThrustBar < RMaB && k.State != GZ_BROKEN).Select(k=>k.StartBar).ToList();
				if(gl!=null && gl.Count>0){
					gl.Sort();
					if(gl.Count>1 && gl[0]<gl.Max()) gl.Reverse();//make sure the largest bar ids are at the head of the list
					bool LNearTradePlanFound  = !ShowNearTradePlan;
					bool LFarTradePlanFound   = !ShowFarTradePlan;
					bool SNearTradePlanFound  = !ShowNearTradePlan;
					bool SFarTradePlanFound   = !ShowFarTradePlan;
					int ABarFirstDemandZone   = -1;
					int ABarFirstSupplyZone   = -1;
					GZone zone                = null;
					double entryPrice, slPrice, t1Price, t2Price;
					double atr = GetTheATR(RMaB);//ATR is based on the current bar (rightmost visible bar on the chart)
					float line_length = TradePlan_LineLength * ChartControl.Properties.BarDistance;
					var close_price = Closes[0].GetValueAt(RMaB-1);//use the close of the prior bar, the current bar is fluctuating and the trade plan needs to be stable during this fluctuation
					for(int i=0; i<gl.Count; i++){
						bool LeftSideFlip = false;
						zone = GZS.Where(k=> k.StartBar == gl[i]).ToList()[0];
						bool SelectedZone = true;
						if(!TradePlanOnTestedZones && (zone.State == GZ_RETEST || zone.State == GZ_TESTED)) SelectedZone = false;
						if(!TradePlanOnFreshZones  && zone.State == GZ_FRESH) SelectedZone = false;
						if(SelectedZone && TradePlanOnQualifiedZones){
							bool c1 = !pQualifyOnVolume      || zone.IsLowVolumeVA;
							bool c2 = !pQualifyOnThrust      || zone.IsSufficientThrust;
							bool c3 = !pQualifyOnBasingCount || zone.IsSufficientBase;
//Print(zone.StartBar+"   IsLowVol? "+zone.IsLowVolumeVA.ToString()+"  IsSuffThrust? "+zone.IsSufficientThrust.ToString()+"  IsBasing? "+zone.IsSufficientBase.ToString()+"   c123: "+c1.ToString()+" "+c2.ToString()+" "+c3.ToString());
//							if() SelectedZone = false;
							SelectedZone = c1 && c2 && c3;
						}
						if(!SelectedZone) continue;
						entryPrice = double.MinValue;
						slPrice    = double.MinValue;
						t1Price    = double.MinValue;
						t2Price    = double.MinValue;
						if(iShowDemandZones && zone.Type == GZ_DEMAND && ShowLongTradePlans){
							if(ABarFirstDemandZone==-1) ABarFirstDemandZone = i;
							if(ShowNearTradePlan && !LNearTradePlanFound){
//Entry Offset ticks  Description = "+ value means EntryPrice will be advanced towards the market, - value means EntryPrice will be moved away from the market"
//SL Offset ticks     Description = "+ value means SL will be enlarged, - value means SL will be reduced"
								#region -- Calculate entryPrice --
								if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtZoneEdge)
									entryPrice = zone.Top + EntryOffsetTicks * TickSize;
								else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtNearLVN){
									if(zone.Hist.LVNs==null || zone.Hist.LVNs.Count==0){
										entryPrice=double.MinValue;
										drawString("No LVN's available in the zones...EntryPrice cannot be determined", 100,100, ChartControl.Properties.LabelFont, Brushes.White, SharpDX.DirectWrite.TextAlignment.Center);
									}else
										entryPrice = zone.Hist.LVNs.Max() + EntryOffsetTicks*TickSize;
								}
								else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtFarLVN){
									if(zone.Hist.LVNs==null || zone.Hist.LVNs.Count==0){
										entryPrice=double.MinValue;
										drawString("No LVN's available in the zones...EntryPrices cannot be determined", 100,100, ChartControl.Properties.LabelFont, Brushes.White, SharpDX.DirectWrite.TextAlignment.Center);
									}else
										entryPrice = zone.Hist.LVNs.Min() + EntryOffsetTicks*TickSize;
								}
								#endregion
								if(entryPrice >= close_price){//long entry must be from an entry price that is below current market
									entryPrice = double.MinValue;
									continue;
								}
								LNearTradePlanFound = true;
								if(BuyNearTradePlan_Location == ARC_SDVSystem_TradePlanLocation.Left) LeftSideFlip = true;
							}
							if(ShowFarTradePlan && !LFarTradePlanFound && i!=ABarFirstDemandZone){//skipping the first demand zone, the "near" zone
								#region -- Calculate entryPrice --
								if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtZoneEdge)
									entryPrice = zone.Top + EntryOffsetTicks * TickSize;
								else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtNearLVN){
									if(zone.Hist.LVNs==null || zone.Hist.LVNs.Count==0){
										entryPrice=double.MinValue;
										drawString("No LVN's available in the zones...EntryPrice cannot be determined", 100,100,this.FontEL, Brushes.White, SharpDX.DirectWrite.TextAlignment.Center);
									}else
										entryPrice = zone.Hist.LVNs.Max() + EntryOffsetTicks*TickSize;
								}else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtFarLVN){
									if(zone.Hist.LVNs==null || zone.Hist.LVNs.Count==0){
										entryPrice=double.MinValue;
										drawString("No LVN's available in the zones...EntryPrice cannot be determined", 100,100,this.FontEL, Brushes.White, SharpDX.DirectWrite.TextAlignment.Center);
									}else
										entryPrice = zone.Hist.LVNs.Min() + EntryOffsetTicks*TickSize;
								}
								#endregion
								if(entryPrice >= close_price){//long entry must be from an entry price that is below current market
									entryPrice = double.MinValue;
									continue;
								}
								LFarTradePlanFound = true;
								if(BuyFarTradePlan_Location == ARC_SDVSystem_TradePlanLocation.Left) LeftSideFlip = true;
							}
							if(entryPrice != double.MinValue){
								#region -- FOR LONGS:  Calculate slPrice, t1Price and t2Price --
								if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.ZoneEdge)
									slPrice = zone.Bottom - SLOffsetTicks * TickSize;
								else if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.ATR){
									if(atr<0) atr = GetTheATR(zone.ThrustBar);
									slPrice = RTTS(entryPrice - atr * SLsize_inATRs);
								}else if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.Ticks)
									slPrice = RTTS(entryPrice - (SLsize_inTicks - SLOffsetTicks) * TickSize);

								if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.ATR){
									if(atr<0) atr = GetTheATR(zone.ThrustBar);
									t1Price = RTTS(entryPrice + atr*T1size_inATRs);
									t2Price = RTTS(entryPrice + atr*T2size_inATRs);
								}else if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.Ticks){
									t1Price = entryPrice + T1size_inTicks * TickSize;
									t2Price = entryPrice + T2size_inTicks * TickSize;
								}else if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.RR){
									double RiskPts = entryPrice - slPrice;
									t1Price = entryPrice + T1size_inRRs*RiskPts;
									t2Price = entryPrice + T2size_inRRs*RiskPts;
								}
								#endregion
							}
						}
						if(iShowSupplyZones && zone.Type == GZ_SUPPLY && ShowShortTradePlans){
							if(ABarFirstSupplyZone==-1) ABarFirstSupplyZone = i;
							if(ShowNearTradePlan && !SNearTradePlanFound){
								#region -- Calculate entryPrice --
								if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtZoneEdge)
									entryPrice = zone.Bottom - EntryOffsetTicks * TickSize;
								else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtNearLVN){
									if(zone.Hist.LVNs==null || zone.Hist.LVNs.Count==0){
										entryPrice=double.MinValue;
										drawString("No LVN's available in the zones...EntryPrices cannot be determined", 100,100, ChartControl.Properties.LabelFont, Brushes.White, SharpDX.DirectWrite.TextAlignment.Center);
									}else
										entryPrice = zone.Hist.LVNs.Min() - EntryOffsetTicks*TickSize;
								}else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtFarLVN){
									if(zone.Hist.LVNs==null || zone.Hist.LVNs.Count==0){
										entryPrice=double.MinValue;
										drawString("No LVN's available in the zones...EntryPrices cannot be determined", 100,100, ChartControl.Properties.LabelFont, Brushes.White, SharpDX.DirectWrite.TextAlignment.Center);
									}else
										entryPrice = zone.Hist.LVNs.Max() - EntryOffsetTicks*TickSize;
								}
								#endregion
								if(entryPrice <= close_price){//short entry must be from an entry price that is above current market
									entryPrice = double.MinValue;
									continue;
								}
								SNearTradePlanFound = true;
								if(SellNearTradePlan_Location == ARC_SDVSystem_TradePlanLocation.Left) LeftSideFlip = true;
							}
							if(ShowFarTradePlan && !SFarTradePlanFound && i!=ABarFirstSupplyZone){//skipping the first supply zone, the "near" zone
								#region -- Calculate entryPrice --
								if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtZoneEdge)
									entryPrice = zone.Bottom - EntryOffsetTicks * TickSize;
								else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtNearLVN){
									if(zone.Hist.LVNs==null || zone.Hist.LVNs.Count==0){
										entryPrice=double.MinValue;
										drawString("No LVN's available in the zones...EntryPrice cannot be determined", 100,100,this.FontEL, Brushes.White, SharpDX.DirectWrite.TextAlignment.Center);
									}else
										entryPrice = zone.Hist.LVNs.Min() - EntryOffsetTicks*TickSize;
								}else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtFarLVN){
									if(zone.Hist.LVNs==null || zone.Hist.LVNs.Count==0){
										entryPrice=double.MinValue;
										drawString("No LVN's available in the zones...EntryPrice cannot be determined", 100,100,this.FontEL, Brushes.White, SharpDX.DirectWrite.TextAlignment.Center);
									}else
										entryPrice = zone.Hist.LVNs.Max() - EntryOffsetTicks*TickSize;
								}
								#endregion
								if(entryPrice <= close_price){//short entry must be from an entry price that is above current market
									entryPrice = double.MinValue;
									continue;
								}
								SFarTradePlanFound = true;
								if(SellFarTradePlan_Location == ARC_SDVSystem_TradePlanLocation.Left) LeftSideFlip = true;
							}
							if(entryPrice != double.MinValue){
								#region -- FOR SHORTS:  Calculate slPrice, t1Price and t2Price --
								if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.ZoneEdge)
									slPrice = zone.Top + SLOffsetTicks * TickSize;
								else if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.ATR){
									atr = GetTheATR(zone.ThrustBar);
									slPrice = RTTS(entryPrice + atr * SLsize_inATRs);
								}else if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.Ticks)
									slPrice = RTTS(entryPrice + (SLsize_inTicks + SLOffsetTicks) * TickSize);

								if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.ATR){
									if(atr<0) atr = GetTheATR(zone.ThrustBar);
									t1Price = RTTS(entryPrice - atr*T1size_inATRs);
									t2Price = RTTS(entryPrice - atr*T2size_inATRs);
								}else if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.Ticks){
									t1Price = entryPrice - T1size_inTicks * TickSize;
									t2Price = entryPrice - T2size_inTicks * TickSize;
								}else if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.RR){
									double RiskPts = slPrice - entryPrice;
									t1Price = entryPrice - T1size_inRRs*RiskPts;
									t2Price = entryPrice - T2size_inRRs*RiskPts;
								}
								#endregion
							}
						}
						if(entryPrice != double.MinValue){			//Draw the trade plan (EP, SL, T1 and T2)
							float x = x_rmab + VisualShiftDistance * ChartControl.Properties.BarDistance + (Calculate==Calculate.OnBarClose ? 1.5f : 0.5f) * ChartControl.Properties.BarDistance;
							//this x is now shifted, by the user (VisualShiftDistance).  Gets the trade plan away from (to the right of) the current bar
							if(LeftSideFlip){
								x = x + 3f;//add some space for the line labels
							} else {
								x = x + line_length + 6f;//for trade plans on the right-side, shift them over (to the right) an additional line_length
							}

							Brush SLBrush = ShortSLBrush;
							Brush T1Brush = ShortT1Brush;
							Brush T2Brush = ShortT2Brush;
							SharpDX.Direct2D1.Brush SLDXBrush  = ShortSLDXBrush;
							SharpDX.Direct2D1.Brush T1DXBrush = ShortT1DXBrush;
							SharpDX.Direct2D1.Brush T2DXBrush = ShortT2DXBrush;
							SharpDX.Direct2D1.Brush SLContrastDXBrush = ShortSLContrastDXBrush;
							SharpDX.Direct2D1.Brush T1ContrastDXBrush = ShortT1ContrastDXBrush;
							SharpDX.Direct2D1.Brush T2ContrastDXBrush = ShortT2ContrastDXBrush;
							string EntryLabel = ShortEntryLabel;
							string SLLabel    = ShortSLLabel;
							string T1Label    = ShortT1Label;
							string T2Label    = ShortT2Label;
							if(entryPrice > slPrice) {
								EntryLabel = LongEntryLabel;
								SLLabel    = LongSLLabel;
								T1Label    = LongT1Label;
								T2Label    = LongT2Label;
								SLBrush    = LongSLBrush;
								T1Brush    = LongT1Brush;
								T2Brush    = LongT2Brush;
								SLDXBrush  = LongSLDXBrush;
								T1DXBrush  = LongT1DXBrush;
								T2DXBrush  = LongT2DXBrush;
								SLContrastDXBrush  = LongSLContrastDXBrush;
								T1ContrastDXBrush  = LongT1ContrastDXBrush;
								T2ContrastDXBrush  = LongT2ContrastDXBrush;
							}
							if(EntryLineWidth>0 && EntryBrush != Brushes.Transparent){
								drawLine(entryPrice, entryPrice, x, x + line_length, EntryDXBrush, EntryDashStyle, EntryLineWidth, chartControl, chartScale);
								if(LeftSideFlip)
									drawstring(EntryLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(entryPrice)), -x, chartScale.GetYByValue(entryPrice), FontEL, EntryDXBrush, EntryContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
								else
									drawstring(EntryLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(entryPrice)), x+line_length+5, chartScale.GetYByValue(entryPrice), FontEL, EntryDXBrush, EntryContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
							}
//RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2((float)chartControl.PanelWidth,100),50,50),fillbrush);
							if(SLLineWidth>0 && SLBrush!=Brushes.Transparent && ShowSL){
								drawLine(slPrice, slPrice, x, x + line_length, SLDXBrush, SLDashStyle, SLLineWidth, chartControl, chartScale);
								if(LeftSideFlip)
									drawstring(SLLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(slPrice)), -x, chartScale.GetYByValue(slPrice), FontSL, SLDXBrush, SLContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
								else
									drawstring(SLLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(slPrice)), x+line_length+5, chartScale.GetYByValue(slPrice), FontSL, SLDXBrush, SLContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
							}
//Print("T1 linewidth: "+T1LineWidth+"  t1Price: "+t1Price);
							if(T1LineWidth>0 && T1Brush!=Brushes.Transparent && ShowT1){
								drawLine(t1Price, t1Price, x, x + line_length, T1DXBrush, T1DashStyle, T1LineWidth, chartControl, chartScale);
								if(LeftSideFlip)
									drawstring(T1Label.Replace("*",Instrument.MasterInstrument.FormatPrice(t1Price)), -x, chartScale.GetYByValue(t1Price), FontT1, T1DXBrush, T1ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
								else
									drawstring(T1Label.Replace("*",Instrument.MasterInstrument.FormatPrice(t1Price)), x+line_length+5, chartScale.GetYByValue(t1Price), FontT1, T1DXBrush, T1ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
							}
							if(T2LineWidth>0 && T2Brush!=Brushes.Transparent && ShowT2){
								drawLine(t2Price, t2Price, x, x + line_length, T2DXBrush, T2DashStyle, T2LineWidth, chartControl, chartScale);
								if(LeftSideFlip)
									drawstring(T2Label.Replace("*",Instrument.MasterInstrument.FormatPrice(t2Price)), -x, chartScale.GetYByValue(t2Price), FontT2, T2DXBrush, T2ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
								else
									drawstring(T2Label.Replace("*",Instrument.MasterInstrument.FormatPrice(t2Price)), x+line_length+5, chartScale.GetYByValue(t2Price), FontT2, T2DXBrush, T2ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
							}
						}
					}
//if(!iShowHiddenZones && this.iAutoHideRetests && GZS[g].State == GZ_HIDDEN) continue;
//if(!iShowBrokenZones && GZS[g].State  == GZ_BROKEN) continue;
//if(!iShowTestedZones && (GZS[g].State == GZ_RETEST || GZS[g].State == GZ_TESTED)) continue;
//if(!iShowFreshZones  && (GZS[g].State == GZ_FORMED || GZS[g].State == GZ_FRESH)) continue;
//if(!iShowSupplyZones && GZS[g].Type   == GZ_SUPPLY) continue;
//if(!iShowDemandZones && GZS[g].Type   == GZ_DEMAND) continue;
//		Print(gl.Last().StartTime.ToString()+"   "+gl.Last().Type+"    "+gl.Last().State);
				}
			}
			#endregion

            RenderTarget.AntialiasMode = OSM;
	        #endregion
        }
//==========================================================================================================================================
        //Draw Region between 4 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void draw_Region(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale)
        {
#if USE_WPF_COORDS
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl), chartScale.GetYByValueWpf(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl), chartScale.GetYByValueWpf(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl), chartScale.GetYByValueWpf(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl), chartScale.GetYByValueWpf(yValues[3]))
                },
                dxbrush
                );
#else
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl), chartScale.GetYByValue(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl), chartScale.GetYByValue(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl), chartScale.GetYByValue(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl), chartScale.GetYByValue(yValues[3]))
                },
                dxbrush
                );
#endif
        }
//==========================================================================================================================================
        #region public override string FormatPriceMarker(double price)
        public override string FormatPriceMarker(double price)
        {
            double trunc = Math.Truncate(price);
            int fraction = Convert.ToInt32(320 * Math.Abs(price - trunc) - 0.0001); // rounding down for ZF and ZT
            string priceMarker = "";
            if (gbTickSize == 0.03125)
            {
                fraction = fraction / 10;
                if (fraction < 10) priceMarker = trunc.ToString() + "'0" + fraction.ToString();
                else priceMarker = trunc.ToString() + "'" + fraction.ToString();
            }
            else if (gbTickSize == 0.015625 || gbTickSize == 0.0078125)
            {
                if (fraction < 10) priceMarker = trunc.ToString() + "'00" + fraction.ToString();
                else if (fraction < 100) priceMarker = trunc.ToString() + "'0" + fraction.ToString();
                else priceMarker = trunc.ToString() + "'" + fraction.ToString();
            }
            else priceMarker = price.ToString(NinjaTrader.Core.Globals.GetTickFormatString(gbTickSize));
            return priceMarker;
        }
        #endregion
//==========================================================================================================================================
		private void SoundAlertHandler(string wav, string msg){
			if(wav=="SOUND OFF") return;
			string filename = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
			if(System.IO.File.Exists(filename))
				Alert(
					DateTime.Now.Millisecond.ToString(),
					Priority.High,
					msg,
					filename,
					0,
					Brushes.Gold,
					Brushes.Black);
			else
				Log("SDVSystem alert triggered, but failed.  Could not find "+filename,NinjaTrader.Cbi.LogLevel.Information);
		}
//==========================================================================================================================================

        //------------------------- Private Functions / Methods -------------------------------

        #region -- addSDVToolBar --
        private void addSDVToolBar()
        {
            gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "^", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"^" - #RJBug001
            gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"?" - #RJBug001
            gLabel = new Label();//#RJBug001

            MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
            MenuControl = new MenuItem { Name="SDVS"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Red, Header = pButtonText, Foreground = Brushes.Red, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControl.GotFocus += delegate(object o, RoutedEventArgs e){
				GetGlobalObjCount("@GZ_", true);
			};
            MenuControlContainer.Items.Add(MenuControl);

            #region -- RegTimeFrameMenu --
            MenuItem miTimeFrame = new MenuItem { Header = "Time Frame", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
            
            MenuItem miTimeFrame1 = new MenuItem { Header = "USE DEFAULT CHART", Name = "chartTimeFrameClick" };
            miTimeFrame1.Click += MenuItemF5_Click;
            miTimeFrame.Items.Add(miTimeFrame1);
            MenuItem miTimeFrame2 = new MenuItem { Header = "MTF", StaysOpenOnClick = true };

            miTimeFrame.Items.Add(miTimeFrame2);
            miTimeFrame2.Items.Add(createSubMTFMenu(this.iChartType1.ToString(), this.iChartValue1.ToString()));

            miTimeFrame2.Items.Add(new Separator());

            //Button Recalculate
            MenuItem buttonMTF = new MenuItem { Header = "USE MTF", Name = "mtfTimeFrameClick", HorizontalAlignment = HorizontalAlignment.Center };
            buttonMTF.Click += MenuItemF5_Click;
            miTimeFrame2.Items.Add(buttonMTF);
            //------------------

            MenuControl.Items.Add(miTimeFrame);
            #endregion

            #region -- RegZoneFormationMenu --
            MenuItem miZoneFormation = new MenuItem { Header = "Zone Formation", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
            miZoneFormation.Items.Add(createZFMMenu(this.applyRangeFilter.ToString(), this.barFilter.ToString()));
            miZoneFormation.Items.Add(new Separator());
            MenuItem buttonZFM = new MenuItem { Header = "RE-CALCULATE ZONES", Name = "zoneFormationClick", HorizontalAlignment = HorizontalAlignment.Center };
            buttonZFM.Click += MenuItemF5_Click;
            miZoneFormation.Items.Add(buttonZFM);
            //------------------

            MenuControl.Items.Add(miZoneFormation);
            #endregion

            #region -- RegMarketStructure --
            MenuItem miMarketStructure = new MenuItem { Header = "Market Structure", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            MenuItem miMarketStructure1 = new MenuItem { Header = showZigZag ? "Market Structure ON" : "Market Structure OFF", Name = "showMarketStructureClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miMarketStructure1.Click += mstMenuItem_Click;
            miMarketStructure.Items.Add(miMarketStructure1);

            miMarketStructure.Items.Add(createMSTMenu(this.percentATR.ToString(), this.swingStrength.ToString()));
            miMarketStructure.Items.Add(new Separator());
            MenuItem buttonMST = new MenuItem { Header = "RE-CALCULATE MARKET STRUCTURE", Name = "marketStructureClick", HorizontalAlignment = HorizontalAlignment.Center };
            buttonMST.Click += MenuItemF5_Click;
            miMarketStructure.Items.Add(buttonMST);
            //------------------

            MenuControl.Items.Add(miMarketStructure);
            #endregion

            #region -- RegAvgStopCalculators --
            MenuItem miAvgStopCalcs = new MenuItem { Header = this.iChartMode1 == ARC_SDVSystem_ZoneMode2.MTF ? "Avg Stop Loss MTF Calculators" : "Avg Stop Loss Calculators", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
            miAvgStopCalcs.Items.Add(miAvgStopFirstTouch = new MenuItem { Header = "First Touch: N/A", Name = "avgStopFirstTouch", Foreground = Brushes.Black });
            miAvgStopCalcs.Items.Add(miAvgStopPOC = new MenuItem { Header = "POC: N/A", Name = "avgStopPOC", Foreground = Brushes.Black });
            miAvgStopCalcs.Items.Add(miAvgStopVA = new MenuItem { Header = "VA: N/A", Name = "avgStopVA", Foreground = Brushes.Black });
            miAvgStopCalcs.Items.Add(miAvgStopVC = new MenuItem { Header = "Volume Cluster: N/A", Name = "avgStopVC", Foreground = Brushes.Black });

            MenuControl.Items.Add(miAvgStopCalcs);
            #endregion

            #region -- RegAvgVolumeCalculators --
            MenuItem miAvgVolCalcs = new MenuItem { Header = this.iChartMode1 == ARC_SDVSystem_ZoneMode2.MTF ? "Avg Volume MTF Calculators" : "Avg Volume Calculators", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
            miAvgVolCalcs.Items.Add(miAvgVolPOC = new MenuItem { Header = "POC: N/A", Name = "avgVolPOC", Foreground = Brushes.Black });
            miAvgVolCalcs.Items.Add(miAvgVolVA = new MenuItem { Header = "VA: N/A", Name = "avgVolVAL", Foreground = Brushes.Black });
            miAvgVolCalcs.Items.Add(miAvgVolVC = new MenuItem { Header = "Volume Cluster: N/A", Name = "avgVolVC", Foreground = Brushes.Black });

            MenuControl.Items.Add(miAvgVolCalcs);
            #endregion

            #region -- RegCurve --
            MenuItem miCurve = new MenuItem { Header = "Curve", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            MenuItem miCurve1 = new MenuItem { Header = pDisplayEnabled ? "Curve ON" : "Curve OFF", Name = "pDisplayEnabled", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miCurve1.Click += curveMenuItem_Click;
            miCurve.Items.Add(miCurve1);

            miCurve.Items.Add(createCRVMenu(this.pDefiance.ToString(), this.pBreakATR.ToString()));

            MenuItem miCurve2 = new MenuItem { Header = pDisplayPrice ? "Price Labels ON" : "Price Labels OFF", Name = "pDisplayPrice", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miCurve2.Click += curveMenuItem_Click;
            miCurve.Items.Add(miCurve2);

            MenuItem miCurve3 = new MenuItem { Header = pDisplayText ? "Name Labels ON" : "Name Labels OFF", Name = "pDisplayText", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miCurve3.Click += curveMenuItem_Click;
            miCurve.Items.Add(miCurve3);

            miCurve.Items.Add(new Separator());

            MenuItem miCurve4 = new MenuItem { Header = "RE-CALCULATE CURVE", Name = "recalc", Foreground = Brushes.Black, HorizontalAlignment = HorizontalAlignment.Center };
            miCurve4.Click += MenuItemF5_Click;
            miCurve.Items.Add(miCurve4);

            MenuControl.Items.Add(miCurve);
            #endregion

            #region -- RegProfileMaster --
            MenuItem miProfileM = new MenuItem { Header = "Profile Master", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miProfileM1 = new MenuItem { Header = iShowAllProfile ? "All Profiles ON" : "All Profiles OFF", Name = "showAllProfile", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfileM1.Click += profileMasterMenuItem_Click;
            miProfileM.Items.Add(miProfileM1);

            miProfileM2 = new MenuItem { Header = iShowAllSupplyProfile ? "Supply Profiles ON" : "Supply Profiles OFF", Name = "showAllSupplyProfile", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfileM2.Click += profileMasterMenuItem_Click;
            miProfileM.Items.Add(miProfileM2);

            miProfileM3 = new MenuItem { Header = iShowAllDemandProfile ? "Demand Profiles ON" : "Demand Profiles OFF", Name = "showAllDemandProfile", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfileM3.Click += profileMasterMenuItem_Click;
            miProfileM.Items.Add(miProfileM3);

            miProfileM4 = new MenuItem { Header = iShowAllTestedProfile ? "Tested Profiles ON" : "Tested Profiles OFF", Name = "showAllTestedProfile", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfileM4.Click += profileMasterMenuItem_Click;
            miProfileM.Items.Add(miProfileM4);

            miProfileM5 = new MenuItem { Header = iShowAllBrokenProfile ? "Broken Profiles ON" : "Broken Profiles OFF", Name = "showAllBrokenProfile", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfileM5.Click += profileMasterMenuItem_Click;
            miProfileM.Items.Add(miProfileM5);

            MenuControl.Items.Add(miProfileM);
            #endregion

            #region -- RegProfileFeatures --
            MenuItem miProfile = new MenuItem { Header = "Profile Features", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            MenuItem miProfile1 = new MenuItem { Header = iShowProfile ? "Profile ON" : "Profile OFF", Name = "showProfile", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfile1.Click += profileMenuItem_Click;
            miProfile.Items.Add(miProfile1);

            MenuItem miProfile2 = new MenuItem { Header = iShowPOC ? "POC ON" : "POC OFF", Name = "showPOC", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfile2.Click += profileMenuItem_Click;
            miProfile.Items.Add(miProfile2);

            MenuItem miProfile3 = new MenuItem { Header = iShowVAL ? "VAL ON" : "VAL OFF", Name = "showVAL", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfile3.Click += profileMenuItem_Click;
            miProfile.Items.Add(miProfile3);

            MenuItem miProfile4 = new MenuItem { Header = iShowVAH ? "VAH ON" : "VAH OFF", Name = "showVAH", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfile4.Click += profileMenuItem_Click;
            miProfile.Items.Add(miProfile4);

            List<string> cbItems = new List<string>();
            foreach (var pt in Enum.GetValues(typeof(ARC_SDVSystem_ProfileExpansion))) cbItems.Add(pt.ToString());
            ContentPresenter ctpr = new ContentPresenter() { HorizontalAlignment = HorizontalAlignment.Left, Width = 45, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 5, 0), Content = "Expand : " };
            comboProfile = new ComboBox() { Name = "cbProfile" + uID, MinWidth = 120, Width = 120, MaxWidth = 120, Margin = new Thickness(5, 0, 5, 0), Padding = new Thickness(5, 2, 5, 2) };
            foreach (string item in cbItems) comboProfile.Items.Add(item);
            comboProfile.SelectedItem = this.iProfileExpansion.ToString();
            comboProfile.SelectionChanged += ComboProfile_SelectionChanged;
            StackPanel stack = new StackPanel { Orientation = Orientation.Horizontal, Width = 175, Margin = new Thickness(0) };
            stack.Children.Add(ctpr);
            stack.Children.Add(comboProfile);
            miProfile.Items.Add(stack);
            
            MenuItem miProfile6 = new MenuItem { Header = iShowVolumeCluster ? "Volume Cluster ON" : "Volume Cluster OFF", Name = "showVolumeCluster", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfile6.Click += profileMenuItem_Click;
            miProfile.Items.Add(miProfile6);

            if (iProfileCalcTimeFrame == ARC_SDVSystem_ProfileDataType.TICK)
            {
                MenuItem miProfile7 = new MenuItem { Header = iShowVolumeRatio ? "Volume Ratio ON" : "Volume Ratio OFF", Name = "showVolumeRatio", Foreground = Brushes.Black, StaysOpenOnClick = true };
                miProfile7.Click += profileMenuItem_Click;
                miProfile.Items.Add(miProfile7);

                MenuItem miProfile8 = new MenuItem { Header = iShowDeltaFactor ? "Delta Factor ON" : "Delta Factor OFF", Name = "showDeltaFactor", Foreground = Brushes.Black, StaysOpenOnClick = true };
                miProfile8.Click += profileMenuItem_Click;
                miProfile.Items.Add(miProfile8);
            }

            MenuItem miProfile9 = new MenuItem { Header = iShowVolumeValues ? "Volume Values ON" : "Volume Values OFF", Name = "showVolumeValues", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfile9.Click += profileMenuItem_Click;
            miProfile.Items.Add(miProfile9);

            MenuItem miProfile10 = new MenuItem { Header = iShowLVNProfile ? "LVNs ON" : "LVNs OFF", Name = "showLVNs", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfile10.Click += profileMenuItem_Click;
            miProfile.Items.Add(miProfile10);

            MenuItem miProfile11 = new MenuItem { Header = iExpandLVNProfile ? "LVNs Expanded" : "LVNs Normalized", Name = "expandLVNs", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miProfile11.Click += profileMenuItem_Click;
            miProfile.Items.Add(miProfile11);

            MenuControl.Items.Add(miProfile);
            #endregion

			#region -- Volume Averages Set 1 Menu --
			var miVASet1 = new MenuItem { Header = "Volume Averages Set 1", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			var miVASet11 = new MenuItem { Header = iVAEnabled ? "Set 1 ON" : "Set 1 OFF", Name = "pVAEnabled", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet11.Click += delegate(object o, RoutedEventArgs e){
				iVAEnabled = !iVAEnabled;
				miVASet11.Header  = iVAEnabled ? "Set 1 ON" : "Set 1 OFF";
				ForceRefresh();
			};
			miVASet1.Items.Add(miVASet11);
			miVASet1.Items.Add(createVA1Menu(iVAPeriod.ToString(), iVAMode));

			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
//				Draw.TextFixed(this, "DataLoadingMsg", "Reclaculating profiles in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			miVASet1.Items.Add(miRecalculate1);

			//------------------

			#endregion

			#region -- Volume Averages Set 2 Menu --
			var miVASet2 = new MenuItem { Header = "Volume Averages Set 2", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			var miVASet21 = new MenuItem { Header = iVA2Enabled ? "Set 2 ON" : "Set 2 OFF", Name = "pVA2Enabled", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miVASet21.Click += delegate(object o, RoutedEventArgs e){
				iVA2Enabled = !iVA2Enabled;
				miVASet21.Header  = iVA2Enabled ? "Set 2 ON" : "Set 2 OFF";
				ForceRefresh();
			};
			miVASet2.Items.Add(miVASet21);
			miVASet2.Items.Add(createVA2Menu(iVA2Period.ToString(), iVA2Mode));

			miVASet2.Items.Add(new Separator());

			miRecalculate2 = new MenuItem { Header = "RE-CALCULATE", HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate2.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
//				Draw.TextFixed(this, "DataLoadingMsg", "Reclaculating profiles in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			miVASet2.Items.Add(miRecalculate2);
			#endregion ---------------------------------

			MenuControl.Items.Add(miVASet1);
			MenuControl.Items.Add(miVASet2);

            #region -- RegVisualMenu --
            MenuItem miVisual = new MenuItem { Header = "Zone Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            MenuItem miVisual1 = new MenuItem { Header = iShowSDVZones ? "All Zones ON" : "All Zones OFF", Name = "showSDVZonesClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miVisual1.Click += visualMenuItem_Click;
            miVisual.Items.Add(miVisual1);

            MenuItem miVisual2 = new MenuItem { Header = iShowSupplyZones ? "Supply Zones ON" : "Supply Zones OFF", Name = "showSupplyZonesClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miVisual2.Click += visualMenuItem_Click;
            miVisual.Items.Add(miVisual2);

            MenuItem miVisual3 = new MenuItem { Header = iShowDemandZones ? "Demand Zones ON" : "Demand Zones OFF", Name = "showDemandZonesClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miVisual3.Click += visualMenuItem_Click;
            miVisual.Items.Add(miVisual3);

            miShowHide_FreshZones = new MenuItem { Header = iShowFreshZones ? "Fresh Zones ON" : "Fresh Zones OFF", Name = "showFreshZonesClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miShowHide_FreshZones.Click += visualMenuItem_Click;
            miVisual.Items.Add(miShowHide_FreshZones);

            miShowHide_TestedZones = new MenuItem { Header = iShowTestedZones ? "Tested Zones ON" : "Tested Zones OFF", Name = "showTestedZonesClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miShowHide_TestedZones.Click += visualMenuItem_Click;
            miVisual.Items.Add(miShowHide_TestedZones);

            MenuItem miVisual6 = new MenuItem { Header = iShowTestedShading ? "Tested Shading ON" : "Tested Shading OFF", Name = "showTestedShadingClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miVisual6.Click += visualMenuItem_Click;
            miVisual.Items.Add(miVisual6);

            MenuItem miVisual7 = new MenuItem { Header = iShowTestedMarker ? "Tested Marker ON" : "Tested Marker OFF", Name = "showTestedMarkerClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miVisual7.Click += visualMenuItem_Click;
            miVisual.Items.Add(miVisual7);

            miShowHide_BrokenZones = new MenuItem { Header = iShowBrokenZones ? "Broken Zones ON" : "Broken Zones OFF", Name = "showBrokenZonesClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miShowHide_BrokenZones.Click += visualMenuItem_Click;
            miVisual.Items.Add(miShowHide_BrokenZones);

            miShowHide_QualifiedZones = new MenuItem { Header = iFilterQualifiedZones ? "Qualified Zones ONLY" : "No Qualification Filter", Name = "showQualifiedZonesClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miShowHide_QualifiedZones.Click += visualMenuItem_Click;
            miVisual.Items.Add(miShowHide_QualifiedZones);

            MenuItem miVisual9 = new MenuItem { Header = iShowPriceLabels ? "Price Labels ON" : "Price Labels OFF", Name = "showPriceLabelsClick", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miVisual9.Click += visualMenuItem_Click;
            miVisual.Items.Add(miVisual9);
            
            MenuControl.Items.Add(miVisual);
            #endregion

			miVisual = new MenuItem { Header = "Zone Qualification", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
            miVisual.Items.Add(this.createQualifiersMenu());

            var miQ0 = new MenuItem { Header = this.pQualifyOnVolume ? "Low Volume?  ON" : "Low Volume?  OFF", Name = "pQualifyOnVolume", Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region -- Q0 --
			miQ0.Click += delegate(object o, RoutedEventArgs e){
				pQualifyOnVolume = !pQualifyOnVolume;
				miQ0.Header = this.pQualifyOnVolume ? "Low Volume?  ON" : "Low Volume?  OFF";
				this.UpdateAllGZS_IsLowVolumeVA(this.pMaxVolPctQualifier);
				ForceRefresh();
			};
			miQ0.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pQualifyOnVolume = !pQualifyOnVolume;
				miQ0.Header = this.pQualifyOnVolume ? "Low Volume?  ON" : "Low Volume?  OFF";
				this.UpdateAllGZS_IsLowVolumeVA(this.pMaxVolPctQualifier);
				ForceRefresh();
			};
			miVisual.Items.Add(miQ0);
			#endregion

			var miQ1 = new MenuItem { Header = this.pQualifyOnThrust ? "Breakout Thrust?  ON" : "Breakout Thrust?  OFF", Name = "pQualifyOnThrust", Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region -- Q1 --
			miQ1.Click += delegate(object o, RoutedEventArgs e){
				pQualifyOnThrust = !pQualifyOnThrust;
				miQ1.Header = this.pQualifyOnThrust ? "Breakout Thrust?  ON" : "Breakout Thrust?  OFF";
				UpdateAllGZS_IsSufficientThrust();
				ForceRefresh();
			};
			miQ1.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pQualifyOnThrust = !pQualifyOnThrust;
				miQ1.Header = this.pQualifyOnThrust ? "Breakout Thrust?  ON" : "Breakout Thrust?  OFF";
				UpdateAllGZS_IsSufficientThrust();
				ForceRefresh();
			};
			miVisual.Items.Add(miQ1);
			#endregion

			var miQ2 = new MenuItem { Header = this.pQualifyOnBasingCount ? "Basing Bars?  ON" : "Basing Bars?  OFF", Name = "pQualifyOnBasingCount", Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region -- Q2 --
			miQ2.Click += delegate(object o, RoutedEventArgs e){
				pQualifyOnBasingCount = !pQualifyOnBasingCount;
				miQ2.Header = this.pQualifyOnBasingCount ? "Basing Bars?  ON" : "Basing Bars?  OFF";
				UpdateAllGZS_IsSufficientBase();
				ForceRefresh();
			};
			miQ2.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pQualifyOnBasingCount = !pQualifyOnBasingCount;
				miQ2.Header = this.pQualifyOnBasingCount ? "Basing Bars?  ON" : "Basing Bars?  OFF";
				UpdateAllGZS_IsSufficientBase();
				ForceRefresh();
			};
			miVisual.Items.Add(miQ2);
			#endregion

			miVisual.Items.Add(new Separator());
			MenuControl.Items.Add(miVisual);

			#region -- Trade Plan --
			miVisual = new MenuItem { Header = "Trade Plan", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
		//========================================================================
			miEntryBasis = new MenuItem { Header = "Entry Basis: "+ this.EntryBasis.ToString(), Name = "entryBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miEntryBasis.Click += delegate (object o, RoutedEventArgs e){
				if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtZoneEdge)     EntryBasis = ARC_SDVSystem_TradeEntryBasis.AtNearLVN;
				else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtNearLVN) EntryBasis = ARC_SDVSystem_TradeEntryBasis.AtFarLVN;
				else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtFarLVN)  EntryBasis = ARC_SDVSystem_TradeEntryBasis.AtZoneEdge;
				miEntryBasis.Header = "Entry Basis: "+ this.EntryBasis.ToString();
				ForceRefresh();
			};
			miEntryBasis.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtZoneEdge)     EntryBasis = ARC_SDVSystem_TradeEntryBasis.AtNearLVN;
				else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtNearLVN) EntryBasis = ARC_SDVSystem_TradeEntryBasis.AtFarLVN;
				else if(EntryBasis == ARC_SDVSystem_TradeEntryBasis.AtFarLVN)  EntryBasis = ARC_SDVSystem_TradeEntryBasis.AtZoneEdge;
				miEntryBasis.Header = "Entry Basis: "+ this.EntryBasis.ToString();
				ForceRefresh();
			};
			miVisual.Items.Add(miEntryBasis);
		//========================================================================
//SL_CalcBasis = ARC_SDVSystem_SL_CalcBasis.ZoneEdge;
//TP_CalcBasis = ARC_SDVSystem_TP_CalcBasis.ATR;

			miSLBasis = new MenuItem { Header = "SL Basis: "+ this.SL_CalcBasis.ToString(), Name = "slBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miSLBasis.Click += delegate (object o, RoutedEventArgs e){
				if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.ZoneEdge)   SL_CalcBasis = ARC_SDVSystem_SL_CalcBasis.ATR;
				else if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.ATR)   SL_CalcBasis = ARC_SDVSystem_SL_CalcBasis.Ticks;
				else if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.Ticks) SL_CalcBasis = ARC_SDVSystem_SL_CalcBasis.ZoneEdge;
				miSLBasis.Header = "SL Basis: "+ SL_CalcBasis.ToString();
				ColorizeNumberFieldsBasedOnCalcBasis(SL_CalcBasis, TP_CalcBasis);
				ForceRefresh();
			};
			miSLBasis.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.ZoneEdge)   SL_CalcBasis = ARC_SDVSystem_SL_CalcBasis.ATR;
				else if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.ATR)   SL_CalcBasis = ARC_SDVSystem_SL_CalcBasis.Ticks;
				else if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.Ticks) SL_CalcBasis = ARC_SDVSystem_SL_CalcBasis.ZoneEdge;
				miSLBasis.Header = "SL Basis: "+ SL_CalcBasis.ToString();
				ColorizeNumberFieldsBasedOnCalcBasis(SL_CalcBasis, TP_CalcBasis);
				ForceRefresh();
			};
			miVisual.Items.Add(miSLBasis);
		//========================================================================

			miTPBasis = new MenuItem { Header = "TP Basis: "+ this.TP_CalcBasis.ToString(), Name = "tpBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miTPBasis.Click += delegate (object o, RoutedEventArgs e){
				if(     TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.ATR)   TP_CalcBasis = ARC_SDVSystem_TP_CalcBasis.RR;
				else if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.RR) TP_CalcBasis    = ARC_SDVSystem_TP_CalcBasis.Ticks;
				else if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.Ticks) TP_CalcBasis = ARC_SDVSystem_TP_CalcBasis.ATR;
				miTPBasis.Header = "TP Basis: "+ TP_CalcBasis.ToString();
				ColorizeNumberFieldsBasedOnCalcBasis(SL_CalcBasis, TP_CalcBasis);
				ForceRefresh();
			};
			miTPBasis.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				if(     TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.ATR)   TP_CalcBasis = ARC_SDVSystem_TP_CalcBasis.RR;
				else if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.RR) TP_CalcBasis    = ARC_SDVSystem_TP_CalcBasis.Ticks;
				else if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.Ticks) TP_CalcBasis = ARC_SDVSystem_TP_CalcBasis.ATR;
				miTPBasis.Header = "TP Basis: "+ TP_CalcBasis.ToString();
				ColorizeNumberFieldsBasedOnCalcBasis(SL_CalcBasis, TP_CalcBasis);
				ForceRefresh();
			};
			miVisual.Items.Add(miTPBasis);
		//========================================================================
//			miPlanLevelsBasis = new MenuItem { Header = "Plan Level Basis: "+ this.PlanLevelsBasis.ToString(), Name = "PlanLevelsBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miPlanLevelsBasis.Click += tradeplanMasterMenuItem_Click;
//			miTPMaster.Items.Add(miPlanLevelsBasis);
		//========================================================================
			miVisual.Items.Add(new Separator());
		//========================================================================
			miShowLongTP = new MenuItem { Header = this.ShowLongTradePlans ? "Long TradePlans:  ON" : "Long TradePlans:  OFF", Name = "showLongTradePlans"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(ShowLongTradePlans) miShowLongTP.FontWeight = FontWeights.Bold; else miShowLongTP.FontWeight = FontWeights.Normal;
			miShowLongTP.Click += delegate (object o, RoutedEventArgs e){
				ShowLongTradePlans = !ShowLongTradePlans;
				miShowLongTP.Header = this.ShowLongTradePlans ? "Long TradePlans:  ON" : "Long TradePlans:  OFF";
				if(ShowLongTradePlans) miShowLongTP.FontWeight = FontWeights.Bold; else miShowLongTP.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miShowLongTP.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				ShowLongTradePlans = !ShowLongTradePlans;
				miShowLongTP.Header = this.ShowLongTradePlans ? "Long TradePlans:  ON" : "Long TradePlans:  OFF";
				if(ShowLongTradePlans) miShowLongTP.FontWeight = FontWeights.Bold; else miShowLongTP.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miVisual.Items.Add(miShowLongTP);
		//========================================================================
			miShowShortTP = new MenuItem { Header = ShowShortTradePlans ? "Short TradePlans:  ON" : "Short TradePlans:  OFF", Name = "showShortTradePlans"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(ShowShortTradePlans) miShowShortTP.FontWeight = FontWeights.Bold; else miShowShortTP.FontWeight = FontWeights.Normal;
			miShowShortTP.Click += delegate (object o, RoutedEventArgs e){
				ShowShortTradePlans = !ShowShortTradePlans;
				miShowShortTP.Header = this.ShowShortTradePlans ? "Short TradePlans:  ON" : "Short TradePlans:  OFF";
				if(ShowShortTradePlans) miShowShortTP.FontWeight = FontWeights.Bold; else miShowShortTP.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miShowShortTP.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				ShowShortTradePlans = !ShowShortTradePlans;
				miShowShortTP.Header = this.ShowShortTradePlans ? "Short TradePlans:  ON" : "Short TradePlans:  OFF";
				if(ShowShortTradePlans) miShowShortTP.FontWeight = FontWeights.Bold; else miShowShortTP.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miVisual.Items.Add(miShowShortTP);
		//========================================================================
			miShowNearTP = new MenuItem { Header = ShowNearTradePlan ? "Near TradePlans:  ON" : "Near TradePlans:  OFF", Name = "showNearTradePlans"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(ShowNearTradePlan) miShowNearTP.FontWeight = FontWeights.Bold; else miShowNearTP.FontWeight = FontWeights.Normal;
			miShowNearTP.Click += delegate (object o, RoutedEventArgs e){
				ShowNearTradePlan = !ShowNearTradePlan;
				miShowNearTP.Header = this.ShowNearTradePlan ? "Near TradePlans:  ON" : "Near TradePlans:  OFF";
				if(ShowNearTradePlan) miShowNearTP.FontWeight = FontWeights.Bold; else miShowNearTP.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miShowNearTP.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				ShowNearTradePlan = !ShowNearTradePlan;
				miShowNearTP.Header = this.ShowNearTradePlan ? "Near TradePlans:  ON" : "Near TradePlans:  OFF";
				if(ShowNearTradePlan) miShowNearTP.FontWeight = FontWeights.Bold; else miShowNearTP.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miVisual.Items.Add(miShowNearTP);
		//========================================================================
			miShowFarTP = new MenuItem { Header = ShowFarTradePlan ? "Far TradePlans:  ON" : "Far TradePlans:  OFF", Name = "showFarTradePlans"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(ShowFarTradePlan) miShowFarTP.FontWeight = FontWeights.Bold; else miShowFarTP.FontWeight = FontWeights.Normal;
			miShowFarTP.Click += delegate (object o, RoutedEventArgs e){
				ShowFarTradePlan = !ShowFarTradePlan;
				miShowFarTP.Header = this.ShowFarTradePlan ? "Far TradePlans:  ON" : "Far TradePlans:  OFF";
				if(ShowFarTradePlan) miShowFarTP.FontWeight = FontWeights.Bold; else miShowFarTP.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miShowFarTP.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				ShowFarTradePlan = !ShowFarTradePlan;
				miShowFarTP.Header = this.ShowFarTradePlan ? "Far TradePlans:  ON" : "Far TradePlans:  OFF";
				if(ShowFarTradePlan) miShowFarTP.FontWeight = FontWeights.Bold; else miShowFarTP.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miVisual.Items.Add(miShowFarTP);
		//========================================================================
            miVisual.Items.Add(new Separator());
		//========================================================================
			miShowTPOnFreshZones = new MenuItem { Header = TradePlanOnFreshZones ? "Fresh Zones:  ON" : "Fresh Zones:  OFF", Name = "TradePlanOnFreshZones"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(TradePlanOnFreshZones) miShowTPOnFreshZones.FontWeight = FontWeights.Bold; else miShowTPOnFreshZones.FontWeight = FontWeights.Normal;
			miShowTPOnFreshZones.Click += delegate (object o, RoutedEventArgs e){
				TradePlanOnFreshZones = !TradePlanOnFreshZones;
				miShowTPOnFreshZones.Header = this.TradePlanOnFreshZones ? "Fresh Zones:  ON" : "Fresh Zones:  OFF";
				if(TradePlanOnFreshZones) miShowTPOnFreshZones.FontWeight = FontWeights.Bold; else miShowTPOnFreshZones.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miShowTPOnFreshZones.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				TradePlanOnFreshZones = !TradePlanOnFreshZones;
				miShowTPOnFreshZones.Header = this.TradePlanOnFreshZones ? "Fresh Zones:  ON" : "Fresh Zones:  OFF";
				if(TradePlanOnFreshZones) miShowTPOnFreshZones.FontWeight = FontWeights.Bold; else miShowTPOnFreshZones.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miVisual.Items.Add(miShowTPOnFreshZones);
		//========================================================================
			miShowTPOnTestedZones = new MenuItem { Header = TradePlanOnTestedZones ? "Tested Zones:  ON" : "Tested Zones:  OFF", Name = "TradePlanOnTestedZones"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(TradePlanOnTestedZones) miShowTPOnTestedZones.FontWeight = FontWeights.Bold; else miShowTPOnTestedZones.FontWeight = FontWeights.Normal;
			miShowTPOnTestedZones.Click += delegate (object o, RoutedEventArgs e){
				TradePlanOnTestedZones = !TradePlanOnTestedZones;
				miShowTPOnTestedZones.Header = this.TradePlanOnTestedZones ? "Tested Zones:  ON" : "Tested Zones:  OFF";
				if(TradePlanOnTestedZones) miShowTPOnTestedZones.FontWeight = FontWeights.Bold; else miShowTPOnTestedZones.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miShowTPOnTestedZones.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				TradePlanOnTestedZones = !TradePlanOnTestedZones;
				miShowTPOnTestedZones.Header = this.TradePlanOnTestedZones ? "Tested Zones:  ON" : "Tested Zones:  OFF";
				if(TradePlanOnTestedZones) miShowTPOnTestedZones.FontWeight = FontWeights.Bold; else miShowTPOnTestedZones.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miVisual.Items.Add(miShowTPOnTestedZones);
		//========================================================================
			miShowTPOnQualifiedZones = new MenuItem { Header = TradePlanOnQualifiedZones ? "Qualified Zones:  ON" : "Qualified Zones:  OFF", Name = "TradePlanOnQualifiedZones"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(TradePlanOnQualifiedZones) miShowTPOnQualifiedZones.FontWeight = FontWeights.Bold; else miShowTPOnQualifiedZones.FontWeight = FontWeights.Normal;
			miShowTPOnQualifiedZones.Click += delegate (object o, RoutedEventArgs e){
				TradePlanOnQualifiedZones = !TradePlanOnQualifiedZones;
				miShowTPOnQualifiedZones.Header = this.TradePlanOnQualifiedZones ? "Qualified Zones:  ON" : "Qualified Zones:  OFF";
				if(TradePlanOnQualifiedZones) miShowTPOnQualifiedZones.FontWeight = FontWeights.Bold; else miShowTPOnQualifiedZones.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miShowTPOnQualifiedZones.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				TradePlanOnQualifiedZones = !TradePlanOnQualifiedZones;
				miShowTPOnQualifiedZones.Header = this.TradePlanOnQualifiedZones ? "Qualified Zones:  ON" : "Qualified Zones:  OFF";
				if(TradePlanOnQualifiedZones) miShowTPOnQualifiedZones.FontWeight = FontWeights.Bold; else miShowTPOnQualifiedZones.FontWeight = FontWeights.Normal;
				ForceRefresh();
			};
			miVisual.Items.Add(miShowTPOnQualifiedZones);
		//========================================================================
            miVisual.Items.Add(new Separator());
		//========================================================================
			miVisual.Items.Add(createTradePlanMenu());
			ColorizeNumberFieldsBasedOnCalcBasis(SL_CalcBasis, TP_CalcBasis);
            MenuControl.Items.Add(miVisual);
			#endregion

			var miZoneGlobal_SubMenu = new MenuItem { Header = "Zone Global Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			#region -- Globalize_FreshZones --
			miGlobalize_FreshZones = new MenuItem {Header = "Globalize FreshZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["F"] = false;
			miGlobalize_FreshZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["F"] = !IsGlobalized["F"];
				if(!IsGlobalized["F"]){
					DeleteAllZones("State", GZ_FRESH);
					this.miShowHide_FreshZones.Header = "Fresh Zones:  OFF";
				} else {
					if(!iShowFreshZones) {
						iShowFreshZones = true;
						this.miShowHide_FreshZones.Header = "Fresh Zones:  ON";
					}
					if(iShowFreshZones){
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content = "Globals ON";
						#endregion --
						#region -- See if the user is selecting a fresh zone ---------------------------------------------------------
						var plist = GZS.Where(k => k.State==GZ_FRESH).ToList();
						var tag = string.Empty;
						if(plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(this.iShowDemandZones && p.Type == GZ_DEMAND){
									tag = CalculateRectKey(p.ID);
									Global_Zone_Rects[tag] = new Global_RectsData(
													p.StartBar,
													p.StartTime, 
													p.Top,
													p.State==GZ_BROKEN ? p.EndTime : BarsArray[0].GetTime(CurrentBars[0]).AddDays(5), 
													p.Bottom, pDemandFreshZone_Template, DEMAND_ID);
									ImmediatelyDraw_Zone(tag, Global_Zone_Rects);
								}
								if(this.iShowSupplyZones && p.Type == GZ_SUPPLY){
									tag = CalculateRectKey(p.ID);
									Global_Zone_Rects[tag] = new Global_RectsData(
													p.StartBar,
													p.StartTime, 
													p.Top,
													p.State==GZ_BROKEN ? p.EndTime : BarsArray[0].GetTime(CurrentBars[0]).AddDays(5), 
													p.Bottom, pSupplyFreshZone_Template, SUPPLY_ID);
									ImmediatelyDraw_Zone(tag, Global_Zone_Rects);
								}
							}
						}
						#endregion
					}
				}
				GetGlobalObjCount("@GZ_");
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_FreshZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Globalize_TestedZones --
			miGlobalize_TestedZones = new MenuItem {Header = "Globalize TestedZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["T"] = false;
			miGlobalize_TestedZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["T"] = !IsGlobalized["T"];
				if(!IsGlobalized["T"]){
					DeleteAllZones("State", GZ_TESTED);
					this.miShowHide_TestedZones.Header = "Tested Zones:  OFF";
				} else {
					if(!iShowTestedZones) {
						iShowTestedZones = true;
						this.miShowHide_TestedZones.Header = "Tested Zones:  ON";
					}
					if(iShowTestedZones){
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content = "Globals ON";
						#endregion --
						#region -- See if the user is selecting a Tested zone ---------------------------------------------------------
						var plist = GZS.Where(k => k.State==GZ_TESTED).ToList();
						var tag = string.Empty;
						if(plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(this.iShowDemandZones && p.Type == GZ_DEMAND){
									tag = CalculateRectKey(p.ID);
									Global_Zone_Rects[CalculateRectKey(p.ID)] = new Global_RectsData(
													p.StartBar,
													p.StartTime, 
													p.Top,
													p.State==GZ_BROKEN ? p.EndTime : BarsArray[0].GetTime(CurrentBars[0]).AddDays(5), 
													p.Bottom, pDemandTestedZone_Template, DEMAND_ID);
									ImmediatelyDraw_Zone(tag, Global_Zone_Rects);
								}
								if(this.iShowSupplyZones && p.Type == GZ_SUPPLY){
									tag = CalculateRectKey(p.ID);
									Global_Zone_Rects[tag] = new Global_RectsData(
													p.StartBar,
													p.StartTime, 
													p.Top,
													p.State==GZ_BROKEN ? p.EndTime : BarsArray[0].GetTime(CurrentBars[0]).AddDays(5), 
													p.Bottom, pSupplyTestedZone_Template, SUPPLY_ID);
									ImmediatelyDraw_Zone(tag, Global_Zone_Rects);
								}
							}
						}
						#endregion
					}
				}
				GetGlobalObjCount("@GZ_");
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_TestedZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Globalize_BrokenZones --
			miGlobalize_BrokenZones = new MenuItem {Header = "Globalize BrokenZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["B"] = false;
			miGlobalize_BrokenZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["B"] = !IsGlobalized["B"];
				if(!IsGlobalized["B"]){
					DeleteAllZones("State", GZ_BROKEN);
					this.miShowHide_BrokenZones.Header = "Broken Zones:  OFF";
				} else {
					if(!iShowBrokenZones) {
						iShowBrokenZones = true;
						this.miShowHide_BrokenZones.Header = "Broken Zones:  ON";
					}
					if(iShowBrokenZones){
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content = "Globals ON";
						#endregion --
						#region -- See if the user is selecting a Broken zone ---------------------------------------------------------
						var plist = GZS.Where(k => k.State==GZ_BROKEN).ToList();
						var tag = string.Empty;
						if(plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(this.iShowDemandZones && p.Type == GZ_DEMAND){
									tag = CalculateRectKey(p.ID);
									Global_Zone_Rects[tag] = new Global_RectsData(
													p.StartBar,
													p.StartTime, 
													p.Top,
													p.State==GZ_BROKEN ? p.EndTime : BarsArray[0].GetTime(CurrentBars[0]).AddDays(5), 
													p.Bottom, pDemandBrokenZone_Template, DEMAND_ID);
									ImmediatelyDraw_Zone(tag, Global_Zone_Rects);
								}
								if(this.iShowSupplyZones && p.Type == GZ_SUPPLY){
									tag = CalculateRectKey(p.ID);
									Global_Zone_Rects[tag] = new Global_RectsData(
													p.StartBar,
													p.StartTime, 
													p.Top,
													p.State==GZ_BROKEN ? p.EndTime : BarsArray[0].GetTime(CurrentBars[0]).AddDays(5), 
													p.Bottom, pSupplyBrokenZone_Template, SUPPLY_ID);
									ImmediatelyDraw_Zone(tag, Global_Zone_Rects);
								}
							}
						}
						#endregion
					}
				}
				GetGlobalObjCount("@GZ_");
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_BrokenZones);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Globalize_QualifiedZones --
			miGlobalize_QualifiedZones = new MenuItem {Header = "Globalize QualifiedZones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["Q"] = false;
			miGlobalize_QualifiedZones.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				IsGlobalized["Q"] = !IsGlobalized["Q"];
				if(!IsGlobalized["Q"]){
					DeleteAllZones("Qualified", int.MinValue);
//					this.miShowHide_QualifiedZones.Header = "Qualified Zones:  OFF";
				} else {
//					if(!pShowQualifiedZones) {
//						pShowQualifiedZones = true;
//						this.miShowHide_QualifiedZones.Header = "Qualified Zones:  ON";
//					}
//					if(iShowTestedZones)
					{
						if(!pQualifyOnBasingCount && !pQualifyOnVolume && !pQualifyOnThrust) /*User has not selected any qualification criteria*/return;
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content = "Globals ON";
						#endregion --
						#region -- See if the user is selecting a Qualified zone ---------------------------------------------------------
						var plist = GZS.Where(k => 
							((iShowFreshZones       && k.State == GZ_FRESH)  ||
							(iShowTestedZones       && k.State == GZ_TESTED) ||
							(iShowBrokenZones       && k.State == GZ_BROKEN))
								&&
							(!pQualifyOnVolume      || k.IsLowVolumeVA)      &&
							(!pQualifyOnThrust      || k.IsSufficientThrust) &&
							(!pQualifyOnBasingCount || k.IsSufficientBase)).ToList();
						var tag = string.Empty;
						if(plist!=null && plist.Count>0){
							foreach(var p in plist){
								if(this.iShowDemandZones && p.Type == GZ_DEMAND){
									tag = CalculateRectKey(p.ID);
									Global_Zone_Rects[CalculateRectKey(p.ID)] = new Global_RectsData(
													p.StartBar,
													p.StartTime, 
													p.Top,
													p.State==GZ_BROKEN ? p.EndTime : BarsArray[0].GetTime(CurrentBars[0]).AddDays(5), 
													p.Bottom, pDemandTestedZone_Template, DEMAND_ID);
									ImmediatelyDraw_Zone(tag, Global_Zone_Rects);
								}
								if(this.iShowSupplyZones && p.Type == GZ_SUPPLY){
									tag = CalculateRectKey(p.ID);
									Global_Zone_Rects[tag] = new Global_RectsData(
													p.StartBar,
													p.StartTime, 
													p.Top,
													p.State==GZ_BROKEN ? p.EndTime : BarsArray[0].GetTime(CurrentBars[0]).AddDays(5), 
													p.Bottom, pSupplyTestedZone_Template, SUPPLY_ID);
									ImmediatelyDraw_Zone(tag, Global_Zone_Rects);
								}
							}
						}
						#endregion
					}
				}
				GetGlobalObjCount("@GZ_");
				ForceRefresh();
			};
			miZoneGlobal_SubMenu.Items.Add(miGlobalize_QualifiedZones);
			#endregion
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(miZoneGlobal_SubMenu);
	//- - - - - - - - - - - - - 
			#region -- Enable Globals --
			EnableGlobals_Button = new System.Windows.Controls.Button { Content = (pGlobalObjects_Enabled ? "Globals ON":"Globals OFF"), Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
			EnableGlobals_Button.Click += delegate (object o, RoutedEventArgs e){
				pGlobalObjects_Enabled = !pGlobalObjects_Enabled;
				EnableGlobals_Button.Content = (pGlobalObjects_Enabled ? "Globals ON" : "Globals OFF");
                ForceRefresh();
			};
			MenuControl.Items.Add(EnableGlobals_Button);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Clear Globals --
			ClearGlobals_Button = new System.Windows.Controls.Button { Content = "", Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
			ClearGlobals_Button.Visibility = Visibility.Collapsed;
			ClearGlobals_Button.Click += delegate(object o, RoutedEventArgs e){
				DeleteAllZones("@GZ_");
			};
			MenuControl.Items.Add(ClearGlobals_Button);
			#endregion

            indytoolbar.Children.Add(MenuControlContainer);
        }
        
        #endregion
		//------------------------------------------------------------------
		private void UpdateAllGZS_IsLowVolumeVA(int LowVolPctQualifier){
			if(!this.pQualifyOnVolume) return;
			var pct = LowVolPctQualifier/100.0;
			foreach(var z in GZS){
				z.IsLowVolumeVA = z.TotVolVA < z.CurrentAvgVAVol * pct;
			}
		}
		private void UpdateAllGZS_IsSufficientThrust(){
			if(!this.pQualifyOnThrust) return;
			foreach(var z in GZS){
//Print(z.StartTime.ToString()+"  startbar: "+z.StartBar+"   endbar: "+z.EndBar);
				z.IsSufficientThrust = ThrustOvershoot.GetValueAt(z.ThrustBar) > 0;
			}
		}
		private void UpdateAllGZS_IsSufficientBase(){
			if(!this.pQualifyOnBasingCount) return;
			foreach(var z in GZS){
				z.IsSufficientBase = z.NumOfBasingCandles <= pMaxBasingCount;
			}
		}
//------------------------------------------------------------------

        #region -- Toolbar Management Utilities --
//		private void InformUserAboutRecalculation(){
//			miRecalculate1.Background = Brushes.Yellow;
//			miRecalculate1.FontWeight = FontWeights.Bold;
//			miRecalculate1.FontStyle = FontStyles.Italic;
//			miRecalculate2.Background = Brushes.Yellow;
//			miRecalculate2.FontWeight = FontWeights.Bold;
//			miRecalculate2.FontStyle = FontStyles.Italic;
////			miRecalculate3.Background = Brushes.Yellow;
////			miRecalculate3.FontWeight = FontWeights.Bold;
////			miRecalculate3.FontStyle = FontStyles.Italic;
//		}
//		private void ResetRecalculationUI(){
//			miRecalculate1.FontWeight = FontWeights.Normal;
//			miRecalculate1.FontStyle = FontStyles.Normal;
//			miRecalculate1.Background = null;
//			miRecalculate2.FontWeight = FontWeights.Normal;
//			miRecalculate2.FontStyle = FontStyles.Normal;
//			miRecalculate2.Background = null;
////			miRecalculate3.FontWeight = FontWeights.Normal;
////			miRecalculate3.FontStyle = FontStyles.Normal;
////			miRecalculate3.Background = null;
//		}
		private void ColorizeNumberFieldsBasedOnCalcBasis(ARC_SDVSystem_SL_CalcBasis SL_CalcBasis, ARC_SDVSystem_TP_CalcBasis TP_CalcBasis){
			#region -- ColorizeNumberFieldsBasedOnCalcBasis --
			//private TextBox nudEntryOffset, nudSLOffset, 
			//nudATRperiod, nudSLsize_inTicks, nudT1size_inTicks, nudT2size_inTicks, nudSLsize_inATRs, nudT1size_inATRs, nudT2size_inATRs, nudT1size_inRRs, nudT2size_inRRs;
			nudATRperiod.Background      = Brushes.DimGray;
			nudSLsize_inTicks.Background = Brushes.DimGray;
			nudT1size_inTicks.Background = Brushes.DimGray;
			nudT2size_inTicks.Background = Brushes.DimGray;
			nudSLsize_inATRs.Background  = Brushes.DimGray;
			nudT1size_inATRs.Background  = Brushes.DimGray;
			nudT2size_inATRs.Background  = Brushes.DimGray;
			nudT1size_inRRs.Background   = Brushes.DimGray;
			nudT2size_inRRs.Background   = Brushes.DimGray;
			nudATRperiod.Foreground      = Brushes.White;
			nudSLsize_inTicks.Foreground = Brushes.White;
			nudSLsize_inATRs.Foreground  = Brushes.White;
			nudT1size_inTicks.Foreground = Brushes.White;
			nudT2size_inTicks.Foreground = Brushes.White;
			nudT1size_inATRs.Foreground  = Brushes.White;
			nudT2size_inATRs.Foreground  = Brushes.White;
			nudT1size_inRRs.Foreground   = Brushes.White;
			nudT2size_inRRs.Foreground   = Brushes.White;
			nudATRperiod.FontWeight      = FontWeights.Normal;
			nudSLsize_inTicks.FontWeight = FontWeights.Normal;
			nudSLsize_inATRs.FontWeight  = FontWeights.Normal;
			nudT1size_inTicks.FontWeight = FontWeights.Normal;
			nudT2size_inTicks.FontWeight = FontWeights.Normal;
			nudT1size_inATRs.FontWeight  = FontWeights.Normal;
			nudT2size_inATRs.FontWeight  = FontWeights.Normal;
			nudT1size_inRRs.FontWeight   = FontWeights.Normal;
			nudT2size_inRRs.FontWeight   = FontWeights.Normal;
			if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.ATR){
				nudATRperiod.FontWeight     = FontWeights.Bold;
				nudSLsize_inATRs.FontWeight = FontWeights.Bold;

				nudATRperiod.Foreground     = Brushes.Magenta;
				nudSLsize_inATRs.Foreground = Brushes.Magenta;

				nudATRperiod.Background     = Brushes.Black;
				nudSLsize_inATRs.Background = Brushes.Black;
			}
			else if(SL_CalcBasis == ARC_SDVSystem_SL_CalcBasis.Ticks){
				nudSLsize_inTicks.FontWeight = FontWeights.Bold;
				nudSLsize_inTicks.Foreground = Brushes.Magenta;
				nudSLsize_inTicks.Background = Brushes.Black;
			}
			if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.ATR){
				nudATRperiod.FontWeight     = FontWeights.Bold;
				nudT1size_inATRs.FontWeight = FontWeights.Bold;
				nudT2size_inATRs.FontWeight = FontWeights.Bold;

				nudATRperiod.Foreground     = Brushes.Magenta;
				nudT1size_inATRs.Foreground = Brushes.Magenta;
				nudT2size_inATRs.Foreground = Brushes.Magenta;

				nudATRperiod.Background     = Brushes.Black;
				nudT1size_inATRs.Background = Brushes.Black;
				nudT2size_inATRs.Background = Brushes.Black;
			}
			else if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.Ticks){
				nudT1size_inTicks.FontWeight = FontWeights.Bold;
				nudT2size_inTicks.FontWeight = FontWeights.Bold;

				nudT1size_inTicks.Foreground = Brushes.Magenta;
				nudT2size_inTicks.Foreground = Brushes.Magenta;

				nudT1size_inTicks.Background = Brushes.Black;
				nudT2size_inTicks.Background = Brushes.Black;
			}
			else if(TP_CalcBasis == ARC_SDVSystem_TP_CalcBasis.RR){
				nudT1size_inRRs.FontWeight = FontWeights.Bold;
				nudT2size_inRRs.FontWeight = FontWeights.Bold;

				nudT1size_inRRs.Foreground = Brushes.Magenta;
				nudT2size_inRRs.Foreground = Brushes.Magenta;

				nudT1size_inRRs.Background = Brushes.Black;
				nudT2size_inRRs.Background = Brushes.Black;
			}
			#endregion
		}
//=====================================================================================================
		private int GetGlobalObjCount(string Tag, bool RefreshUI = true){
			var objects = DrawObjects.Where(o=> o.Tag.StartsWith(Tag));
//Print("Count: "+objects.Count()+"  IsGlobalized[B]: "+IsGlobalized["B"].ToString());
			if(RefreshUI){
				if(objects.Count()==0){
					ClearGlobals_Button.Content = "";
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
					ClearGlobals_Button.Background = Brushes.DimGray;
				}else{
					ClearGlobals_Button.Content = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
					ClearGlobals_Button.Background = Brushes.DarkGreen;
				}
				try{
					MenuControl.InvalidateVisual();
					ChartControl.InvalidateVisual();
				}catch{}
			}
			return objects.Count();
		}
//=====================================================================================================
		private void DeleteAllZones(string prefix){
			var objects = DrawObjects.ToList();
			foreach (dynamic dob in objects)
			{
//Print("Object: "+dob.Tag);
				if (dob.ToString().EndsWith(".Rectangle") && dob.Tag.StartsWith(prefix)) {
					RemoveDrawObject(dob.Tag);
					if(Global_Zone_Rects.ContainsKey(dob.Tag)) Global_Zone_Rects.Remove(dob.Tag);
				}
			}
			GetGlobalObjCount("@GZ_", false);
		}
//=====================================================================================================
		private string CalculateRectKey(string ZoneID){
			return string.Format("@{0}.{1}", ZoneID, ObjectPrefix);
		}
//=====================================================================================================
		private void DeleteAllZones(string ZoneType, int val){
			List<GZone> list = null;
			if(ZoneType == "State") 	list = GZS.Where(z=> z.State==val).ToList();
			else if(ZoneType == "Type") list = GZS.Where(z=> z.Type==val).ToList();
			else if(ZoneType == "Qualified") list = GZS.Where(k => 
														(!pQualifyOnVolume      || k.IsLowVolumeVA)      &&
														(!pQualifyOnThrust      || k.IsSufficientThrust) &&
														(!pQualifyOnBasingCount || k.IsSufficientBase)).ToList();

			foreach(var z in list){
				string global_obj_tag = CalculateRectKey(z.ID);
//Print("Deleting tag: "+global_obj_tag);
				RemoveDrawObject(global_obj_tag);
				if(Global_Zone_Rects.ContainsKey(z.ID)) Global_Zone_Rects.Remove(global_obj_tag);
			}
			GetGlobalObjCount("@GZ_", false);
		}
//=====================================================================================================
//------------ Misc ------------------------------------------------
		#region -- submenu creators --
        private Grid createSubMTFMenu(string cbItemSelected, string MTFValue)
        {
            List<string> cbItems = new List<string>();
            foreach (KeyValuePair<ARC_SDVSystem_MTFBarType, BarsPeriodType> pair in dictionaryPeriodTypes) cbItems.Add(pair.Value.ToString());

            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - combo
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "BarType : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);

            comboMTF = new ComboBox() { Name = "MTFcb" + uID, MinWidth = 86, Width = 86, MaxWidth = 86, Margin = new Thickness(5, 0, 0, 0) };
            foreach (string item in cbItems) comboMTF.Items.Add(item);
            comboMTF.SelectedItem = cbItemSelected;
            comboMTF.SetValue(Grid.ColumnProperty, 1);
            comboMTF.SetValue(Grid.ColumnSpanProperty, 2);
            comboMTF.SetValue(Grid.RowProperty, 0);
			comboMTF.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				var keys = dictionaryPeriodTypes.Keys.ToList();
				if(e.Delta<0){
					if(iChartType1 == keys[0]) iChartType1 = keys.Last();
					else{
						keys.Reverse();
						var i = keys.IndexOf(iChartType1);
						iChartType1 = keys[i+1];
					}
				}else if(e.Delta>0){
					if(iChartType1 == keys.Last()) iChartType1 = keys[0];
					else{
						var i = keys.IndexOf(iChartType1);
						iChartType1 = keys[i+1];
					}
				}
				comboMTF.Text = iChartType1.ToString();
			};
            //line 2 - NUD
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Value : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 1);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudMTF = new TextBox() { Name = "MTFtxtbox" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMTF.Text = MTFValue;
            nudMTF.KeyDown += menuTxtbox_KeyDown;
            nudMTF.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudMTF.Text);
				if(x>1000000) {
					nudMTF.Text = "1000000";
					x=1000000;
				}
				if(x<1) {
					nudMTF.Text = "1";
					x=1;
				}
				this.iChartValue1 = x;
			};
			nudMTF.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					iChartValue1 = (iChartValue1<=1 ? 1000000 : --iChartValue1);
				}else if(e.Delta>0){
					iChartValue1 = (iChartValue1>=1000000 ? 1 : ++iChartValue1);
				}
				nudMTF.Text = iChartValue1.ToString();
			};
            nudMTF.SetValue(Grid.ColumnProperty, 1);
            nudMTF.SetValue(Grid.RowProperty, 1);
            nudMTF.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup = new Button() { Name = "MTFcmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup.Click += cmdupdw_Click;
            cmdup.SetValue(Grid.ColumnProperty, 2);
            cmdup.SetValue(Grid.RowProperty, 1);
            Button cmddw = new Button() { Name = "MTFcmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmddw.Click += cmdupdw_Click;
            cmddw.SetValue(Grid.ColumnProperty, 2);
            cmddw.SetValue(Grid.RowProperty, 2);

            grid.Children.Add(lbl1);
            grid.Children.Add(comboMTF);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudMTF);
            grid.Children.Add(cmdup);
            grid.Children.Add(cmddw);

            return grid;
        }
        private Grid createZFMMenu(string cbItemSelected, string nudValue)
        {
            List<string> cbItems = new List<string>();
            foreach (var pt in Enum.GetValues(typeof(ARC_SDVSystem_ZoneBool2))) cbItems.Add(pt.ToString());

            const int rHeight = 26;
            
            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - combo
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Range Filter : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);

            comboZFM = new ComboBox() { Name = "ZFMcb" + uID, MinWidth = 86, Width = 86, MaxWidth = 86, Margin = new Thickness(5, 0, 0, 0) };
            foreach (string item in cbItems) comboZFM.Items.Add(item);
            comboZFM.SelectedItem = cbItemSelected;
            comboZFM.SetValue(Grid.ColumnProperty, 1);
            comboZFM.SetValue(Grid.ColumnSpanProperty, 2);
            comboZFM.SetValue(Grid.RowProperty, 0);
			comboZFM.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(comboZFM.SelectedIndex==0) comboZFM.SelectedIndex=1; else comboZFM.SelectedIndex=0;
				if(comboZFM.SelectedItem.ToString().ToLower()=="true") this.applyRangeFilter = true; else applyRangeFilter = false;
			};
            //line 2 - NUD
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "MaxATR(%) : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 1);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudZFM = new TextBox() { Name = "ZFMtxtbox" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudZFM.Text = nudValue;
            nudZFM.KeyDown += menuTxtbox_KeyDown;
            nudZFM.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudZFM.Text);
				if(x>1000000) {
					nudZFM.Text = "1000000";
					x=1000000;
				}
				if(x<100) {
					nudZFM.Text = "100";
					x=100;
				}
				this.barFilter = x;
			};
			nudZFM.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				int x = barFilter;
				if(e.Delta<0)      x = x-5;
				else if(e.Delta>0) x = x+5;

				if(x<100) barFilter = 1000000;
				else if(x>1000000) barFilter = 100;
				else barFilter = x;
				nudZFM.Text = barFilter.ToString();
			};
            nudZFM.SetValue(Grid.ColumnProperty, 1);
            nudZFM.SetValue(Grid.RowProperty, 1);
            nudZFM.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup = new Button() { Name = "ZFMcmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup.Click += cmdupdw_Click;
            cmdup.SetValue(Grid.ColumnProperty, 2);
            cmdup.SetValue(Grid.RowProperty, 1);
            Button cmddw = new Button() { Name = "ZFMcmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmddw.Click += cmdupdw_Click;
            cmddw.SetValue(Grid.ColumnProperty, 2);
            cmddw.SetValue(Grid.RowProperty, 2);

            grid.Children.Add(lbl1);
            grid.Children.Add(comboZFM);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudZFM);
            grid.Children.Add(cmdup);
            grid.Children.Add(cmddw);

            return grid;
        }
        private Grid createMSTMenu(string nudValue1, string nudValue2)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - MST1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "% ATR : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudMST1 = new TextBox() { Name = "MST1txtbox" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST1.Text = nudValue1;
            nudMST1.KeyDown += menuTxtbox_KeyDown;
            nudMST1.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudMST1.Text);
				if(x>1000) {
					nudMST1.Text = "1000";
					x=1000;
				}
				if(x<1) {
					nudMST1.Text = "0";
					x=0;
				}
				this.percentATR = x;
			};
			nudMST1.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					percentATR = (percentATR==0 ? 1000 : --percentATR);
				}else if(e.Delta>0){
					percentATR = (percentATR==1000 ? 0 : ++percentATR);
				}
				nudMST1.Text = percentATR.ToString();
			};
            nudMST1.SetValue(Grid.ColumnProperty, 1);
            nudMST1.SetValue(Grid.RowProperty, 0);
            nudMST1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = "MST1cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = "MST1cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);

            //line 2 - MST2
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Strength : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudMST2 = new TextBox() { Name = "MST2txtbox" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST2.Text = nudValue2;
            nudMST2.KeyDown += menuTxtbox_KeyDown;
            nudMST2.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudMST2.Text);
				if(x>1000) {
					nudMST2.Text = "1000";
					x=1000;
				}
				if(x<1) {
					nudMST2.Text = "1";
					x=1;
				}
				this.swingStrength = x;
			};
			nudMST2.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					swingStrength = (swingStrength==1 ? 1000 : --swingStrength);
				}else if(e.Delta>0){
					swingStrength = (swingStrength==1000 ? 1 : ++swingStrength);
				}
				nudMST2.Text = swingStrength.ToString();
			};
			nudMST2.SetValue(Grid.ColumnProperty, 1);
            nudMST2.SetValue(Grid.RowProperty, 2);
            nudMST2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = "MST2cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = "MST2cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 2);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMST1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudMST2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            return grid;
        }
        private Grid createCRVMenu(string nudValue1, string nudValue2)
        {
            const int rHeight = 26;
            
            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - CRV1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Defiance ATR % : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudCRV1 = new TextBox() { Name = "CRV1txtbox" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudCRV1.Text = nudValue1;
            nudCRV1.KeyDown += menuTxtbox_KeyDown;
            nudCRV1.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudCRV1.Text);
				if(x>1000) {
					nudCRV1.Text = "1000";
					x=1000;
				}
				if(x<1) {
					nudCRV1.Text = "1";
					x=1;
				}
				pDefiance = x;
			};
            nudCRV1.SetValue(Grid.ColumnProperty, 1);
            nudCRV1.SetValue(Grid.RowProperty, 0);
            nudCRV1.SetValue(Grid.RowSpanProperty, 2);
			nudCRV1.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					pDefiance = (pDefiance==0 ? pDefiance = 1000 : --pDefiance);
				}else if(e.Delta>0){
					pDefiance = (pDefiance==1000 ? pDefiance = 0 : ++pDefiance);
				}
				nudCRV1.Text = pDefiance.ToString();
			};

//            Button cmdup1 = new Button() { Name = "CRV1cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
//            Button cmddw1 = new Button() { Name = "CRV1cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
//            cmdup1.Click += cmdupdw_Click;
//            cmdup1.SetValue(Grid.ColumnProperty, 2);
//            cmdup1.SetValue(Grid.RowProperty, 0);
//            cmddw1.Click += cmdupdw_Click;
//            cmddw1.SetValue(Grid.ColumnProperty, 2);
//            cmddw1.SetValue(Grid.RowProperty, 1);

            //line 2 - CRV2
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Break H/L ATR % : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudCRV2 = new TextBox() { Name = "CRV2txtbox" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudCRV2.Text = nudValue2;
            nudCRV2.KeyDown += menuTxtbox_KeyDown;
            nudCRV2.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudCRV2.Text);
				if(x>1000) {
					nudCRV2.Text = "1000";
					x=1000;
				}
				if(x<1) {
					nudCRV2.Text = "1";
					x=1;
				}
				pBreakATR = x;
			};
            nudCRV2.SetValue(Grid.ColumnProperty, 1);
            nudCRV2.SetValue(Grid.RowProperty, 2);
            nudCRV2.SetValue(Grid.RowSpanProperty, 2);
			nudCRV2.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					pBreakATR = (pBreakATR==0 ? 1000 : --pBreakATR);
				}else if(e.Delta>0){
					pBreakATR = (pBreakATR==1000 ? 0 : ++pBreakATR);
				}
				nudCRV2.Text = pBreakATR.ToString();
			};

//            Button cmdup2 = new Button() { Name = "CRV2cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
//            Button cmddw2 = new Button() { Name = "CRV2cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
//            cmdup2.Click += cmdupdw_Click;
//            cmdup2.SetValue(Grid.ColumnProperty, 2);
//            cmdup2.SetValue(Grid.RowProperty, 2);
//            cmddw2.Click += cmdupdw_Click;
//            cmddw2.SetValue(Grid.ColumnProperty, 2);
//            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudCRV1);
//            grid.Children.Add(cmdup1);
//            grid.Children.Add(cmddw1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudCRV2);
//            grid.Children.Add(cmdup2);
//            grid.Children.Add(cmddw2);

            return grid;
        }
        private Grid createQualifiersMenu()
        {
            const int rHeight = 26;
            
            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - nudMaxVolPctOfAvg
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Max Vol % of Avg : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);
//nudMaxVolPctOfAvg, nudMaxBasingCount   tb_QMaxBaseCount    tb_QMaxVolPctOfAvg
            nudMaxVolPctOfAvg = new TextBox() { Name = "tb_QMaxVolPctOfAvg" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMaxVolPctOfAvg.Text = pMaxVolPctQualifier.ToString();
            nudMaxVolPctOfAvg.KeyDown += menuTxtbox_KeyDown;
            nudMaxVolPctOfAvg.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudMaxVolPctOfAvg.Text);
				if(x>100) {
					nudMaxVolPctOfAvg.Text = "100";
					x=100;
				}
				if(x<1) {
					nudMaxVolPctOfAvg.Text = "1";
					x=1;
				}
				pMaxVolPctQualifier = x;
				UpdateAllGZS_IsLowVolumeVA(pMaxVolPctQualifier);
			};
			nudMaxVolPctOfAvg.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					pMaxVolPctQualifier = (pMaxVolPctQualifier>=1 ? 100 : --pMaxVolPctQualifier);
				}else if(e.Delta>0){
					pMaxVolPctQualifier = (pMaxVolPctQualifier<=100 ? 1 : ++pMaxVolPctQualifier);
				}
				nudMaxVolPctOfAvg.Text = pMaxVolPctQualifier.ToString();
				UpdateAllGZS_IsLowVolumeVA(pMaxVolPctQualifier);
			};

            nudMaxVolPctOfAvg.SetValue(Grid.ColumnProperty, 1);
            nudMaxVolPctOfAvg.SetValue(Grid.RowProperty, 0);
            nudMaxVolPctOfAvg.SetValue(Grid.RowSpanProperty, 2);

//            Button cmdup1 = new Button() { Name = "CRV1cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
//            Button cmddw1 = new Button() { Name = "CRV1cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
//            cmdup1.Click += cmdupdw_Click;
//            cmdup1.SetValue(Grid.ColumnProperty, 2);
//            cmdup1.SetValue(Grid.RowProperty, 0);
//            cmddw1.Click += cmdupdw_Click;
//            cmddw1.SetValue(Grid.ColumnProperty, 2);
//            cmddw1.SetValue(Grid.RowProperty, 1);

            //line 2 - Max base counts (black candles forming a qualified zone
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Max Basing Candles : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudMaxBasingCount = new TextBox() { Name = "tb_QMaxBaseCount" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMaxBasingCount.Text = pMaxBasingCount.ToString();
            nudMaxBasingCount.KeyDown += menuTxtbox_KeyDown;
            nudMaxBasingCount.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudMaxBasingCount.Text);
				if(x>5) {
					nudMaxBasingCount.Text = "5";
					x=5;
				}
				if(x<1) {
					nudMaxBasingCount.Text = "1";
					x=1;
				}
				pMaxBasingCount = x;
				this.UpdateAllGZS_IsSufficientBase();
			};
			nudMaxBasingCount.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					pMaxBasingCount = (pMaxBasingCount<=1 ? pMaxBasingCount = 5 : --pMaxBasingCount);
				}else if(e.Delta>0){
					pMaxBasingCount = (pMaxBasingCount>=5 ? pMaxBasingCount = 1 : ++pMaxBasingCount);
				}
				nudMaxBasingCount.Text = pMaxBasingCount.ToString();
				this.UpdateAllGZS_IsSufficientBase();
			};

            nudMaxBasingCount.SetValue(Grid.ColumnProperty, 1);
            nudMaxBasingCount.SetValue(Grid.RowProperty, 2);
            nudMaxBasingCount.SetValue(Grid.RowSpanProperty, 2);

//            Button cmdup2 = new Button() { Name = "CRV2cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
//            Button cmddw2 = new Button() { Name = "CRV2cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
//            cmdup2.Click += cmdupdw_Click;
//            cmdup2.SetValue(Grid.ColumnProperty, 2);
//            cmdup2.SetValue(Grid.RowProperty, 2);
//            cmddw2.Click += cmdupdw_Click;
//            cmddw2.SetValue(Grid.ColumnProperty, 2);
//            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMaxVolPctOfAvg);
//            grid.Children.Add(cmdup1);
//            grid.Children.Add(cmddw1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudMaxBasingCount);
//            grid.Children.Add(cmdup2);
//            grid.Children.Add(cmddw2);

            return grid;
        }
        private Grid createTradePlanMenu()
        {
			const int rHeight = 26;
			int row=0;

			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

			//line a - Entry offset ticks (+ value means EntryPrice will be advanced towards the market, - value means EntryPrice will be moved away from the market)
			#region -- Entry Offset --
			Label lbla = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Entry Offset: " };
			lbla.SetValue(Grid.ColumnProperty, 0);
			lbla.SetValue(Grid.RowProperty, row);
			lbla.SetValue(Grid.RowSpanProperty, 2);
			nudEntryOffset          = new TextBox() { Name = "tb_EntryOffset" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, FontWeight=FontWeights.Bold, BorderBrush = gLabel.Foreground, Background=Brushes.Black, Foreground=Brushes.Magenta};
			nudEntryOffset.Text     = EntryOffsetTicks.ToString();
			nudEntryOffset.KeyDown     += menuTxtbox_KeyDown;
			nudEntryOffset.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudEntryOffset.Text);
				if(x>100) {
					nudEntryOffset.Text = "-100";
					x=-100;
				}
				if(x<-100) {
					nudEntryOffset.Text = "100";
					x=100;
				}
				EntryOffsetTicks = x;
				ForceRefresh();
			};
			nudEntryOffset.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					EntryOffsetTicks = (EntryOffsetTicks<=-100 ? 100 : --EntryOffsetTicks);
				}else if(e.Delta>0){
					EntryOffsetTicks = (EntryOffsetTicks>=100 ? -100 : ++EntryOffsetTicks);
				}
				nudEntryOffset.Text = EntryOffsetTicks.ToString();
				ForceRefresh();
			};

            nudEntryOffset.SetValue(Grid.ColumnProperty, 1);
            nudEntryOffset.SetValue(Grid.RowProperty, row);
            nudEntryOffset.SetValue(Grid.RowSpanProperty, 2);
			#endregion

			//line 0 - SL offset ticks (+ means add to the SL distance, - means tighten the SL distance
			#region -- SL Offset --
			row = row+2;
			Label lbl0 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "SL Offset: " };
			lbl0.SetValue(Grid.ColumnProperty, 0);
			lbl0.SetValue(Grid.RowProperty, row);
			lbl0.SetValue(Grid.RowSpanProperty, 2);
			nudSLOffset          = new TextBox() { Name = "tb_SLOffset" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, FontWeight=FontWeights.Bold, BorderBrush = gLabel.Foreground, Background=Brushes.Black, Foreground=Brushes.Magenta };
			nudSLOffset.Text     = SLOffsetTicks.ToString();
			nudSLOffset.KeyDown     += menuTxtbox_KeyDown;
			nudSLOffset.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudSLOffset.Text);
				if(x>100) {
					nudSLOffset.Text = "-100";
					x=-100;
				}
				if(x<-100) {
					nudSLOffset.Text = "100";
					x=100;
				}
				SLOffsetTicks = x;
				ForceRefresh();
			};
			nudSLOffset.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					SLOffsetTicks = (SLOffsetTicks<=-100 ? 100 : --SLOffsetTicks);
				}else if(e.Delta>0){
					SLOffsetTicks = (SLOffsetTicks>=100 ? -100 : ++SLOffsetTicks);
				}
				nudSLOffset.Text = SLOffsetTicks.ToString();
				ForceRefresh();
			};

            nudSLOffset.SetValue(Grid.ColumnProperty, 1);
            nudSLOffset.SetValue(Grid.RowProperty, row);
            nudSLOffset.SetValue(Grid.RowSpanProperty, 2);
			#endregion

            //line 1 - ATR Period
			#region -- ATR Period --
			row = row+2;
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "ATR period: " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, row);
            lbl1.SetValue(Grid.RowSpanProperty, 2);
            nudATRperiod = new TextBox() { Name = "tb_ATRperiod" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, BorderBrush = gLabel.Foreground };
            nudATRperiod.Text = ATRperiod.ToString();
            nudATRperiod.KeyDown += menuTxtbox_KeyDown;
            nudATRperiod.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudATRperiod.Text);
				if(x>100) {
					nudATRperiod.Text = "100";
					x=100;
				}
				if(x<1) {
					nudATRperiod.Text = "1";
					x=1;
				}
				ATRperiod = x;
				ForceRefresh();
				
			};
			nudATRperiod.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					ATRperiod = (ATRperiod<=1 ? 100 : --ATRperiod);
				}else if(e.Delta>0){
					ATRperiod = (ATRperiod>=100 ? 1 : ++ATRperiod);
				}
				nudATRperiod.Text = ATRperiod.ToString();
				ForceRefresh();
			};

            nudATRperiod.SetValue(Grid.ColumnProperty, 1);
            nudATRperiod.SetValue(Grid.RowProperty, row);
            nudATRperiod.SetValue(Grid.RowSpanProperty, 2);

//            Button cmdup1 = new Button() { Name = "CRV1cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
//            Button cmddw1 = new Button() { Name = "CRV1cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
//            cmdup1.Click += cmdupdw_Click;
//            cmdup1.SetValue(Grid.ColumnProperty, 2);
//            cmdup1.SetValue(Grid.RowProperty, 0);
//            cmddw1.Click += cmdupdw_Click;
//            cmddw1.SetValue(Grid.ColumnProperty, 2);
//            cmddw1.SetValue(Grid.RowProperty, 1);
			#endregion

			row++;//blank row for separation

			//line 2 - Ticks for SL
			#region -- SL Ticks --
			row = row+2;
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "SL (ticks) : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, row);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudSLsize_inTicks = new TextBox() { Name = "tb_TicksForSL" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, BorderBrush = gLabel.Foreground };
            nudSLsize_inTicks.Text = this.SLsize_inTicks.ToString();
            nudSLsize_inTicks.KeyDown += menuTxtbox_KeyDown;
            nudSLsize_inTicks.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudSLsize_inTicks.Text);
				if(x>5000) {
					nudSLsize_inTicks.Text = "5000";
					x=5000;
				}
				if(x<1) {
					nudSLsize_inTicks.Text = "1";
					x=1;
				}
				SLsize_inTicks = x;
				ForceRefresh();
			};
			nudSLsize_inTicks.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					SLsize_inTicks = (SLsize_inTicks<=1 ? 5000 : --SLsize_inTicks);
				}else if(e.Delta>0){
					SLsize_inTicks = (SLsize_inTicks>=5000 ? 1 : ++SLsize_inTicks);
				}
				nudSLsize_inTicks.Text = SLsize_inTicks.ToString();
				ForceRefresh();
			};

            nudSLsize_inTicks.SetValue(Grid.ColumnProperty, 1);
            nudSLsize_inTicks.SetValue(Grid.RowProperty, row);
            nudSLsize_inTicks.SetValue(Grid.RowSpanProperty, 2);
			#endregion

            //line 5 - ATR Multipler for SL
			#region -- SL multiplier --
			row = row+2;
            Label lbl5 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "SL (ATRs) : " };
            lbl5.SetValue(Grid.ColumnProperty, 0);
            lbl5.SetValue(Grid.RowProperty, row);
            lbl5.SetValue(Grid.RowSpanProperty, 2);

            nudSLsize_inATRs = new TextBox() { Name = "tb_MultForSL" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, BorderBrush = gLabel.Foreground };
            nudSLsize_inATRs.Text = this.SLsize_inATRs.ToString();
            nudSLsize_inATRs.KeyDown += menuTxtbox_KeyDown;
            nudSLsize_inATRs.TextChanged += delegate(object o, TextChangedEventArgs e){
				double x = Convert.ToDouble(this.nudSLsize_inATRs.Text);
				if(x>10) {
					nudSLsize_inATRs.Text = "10";
					x=10;
				}
				if(x<0) {
					nudSLsize_inATRs.Text = "0";
					x=0;
				}
				SLsize_inATRs = x;
				ForceRefresh();
			};
			nudSLsize_inATRs.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					SLsize_inATRs = (SLsize_inATRs<=0 ? 10 : SLsize_inATRs-0.5);
				}else if(e.Delta>0){
					SLsize_inATRs = (SLsize_inATRs>=10 ? 0 : SLsize_inATRs+0.5);
				}
				nudSLsize_inATRs.Text = SLsize_inATRs.ToString();
				ForceRefresh();
			};

            nudSLsize_inATRs.SetValue(Grid.ColumnProperty, 1);
            nudSLsize_inATRs.SetValue(Grid.RowProperty, row);
            nudSLsize_inATRs.SetValue(Grid.RowSpanProperty, 2);
			#endregion

			row++;//blank row for separation

			//line 3 - Ticks for T1
			#region -- T1 ticks --
			row = row+2;
            Label lbl3 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "T1 (ticks) : " };
            lbl3.SetValue(Grid.ColumnProperty, 0);
            lbl3.SetValue(Grid.RowProperty, row);
            lbl3.SetValue(Grid.RowSpanProperty, 2);

            nudT1size_inTicks = new TextBox() { Name = "tb_TicksForT1" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, BorderBrush = gLabel.Foreground };
            nudT1size_inTicks.Text = this.T1size_inTicks.ToString();
            nudT1size_inTicks.KeyDown += menuTxtbox_KeyDown;
            nudT1size_inTicks.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudT1size_inTicks.Text);
				if(x>5000) {
					nudT1size_inTicks.Text = "5000";
					x=5000;
				}
				if(x<1) {
					nudT1size_inTicks.Text = "1";
					x=1;
				}
				T1size_inTicks = x;
				ForceRefresh();
			};
			nudT1size_inTicks.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					T1size_inTicks = (T1size_inTicks<=1 ? 5000 : --T1size_inTicks);
				}else if(e.Delta>0){
					T1size_inTicks = (T1size_inTicks>=5000 ? 1 : ++T1size_inTicks);
				}
				nudT1size_inTicks.Text = T1size_inTicks.ToString();
				ForceRefresh();
			};

            nudT1size_inTicks.SetValue(Grid.ColumnProperty, 1);
            nudT1size_inTicks.SetValue(Grid.RowProperty, row);
            nudT1size_inTicks.SetValue(Grid.RowSpanProperty, 2);
			#endregion

            //line 4 - Ticks for T2
			#region -- T2 ticks --
			row = row+2;
            Label lbl4 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "T2 (ticks) : " };
            lbl4.SetValue(Grid.ColumnProperty, 0);
            lbl4.SetValue(Grid.RowProperty, row);
            lbl4.SetValue(Grid.RowSpanProperty, 2);

            nudT2size_inTicks = new TextBox() { Name = "tb_TicksForT2" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, BorderBrush = gLabel.Foreground };
            nudT2size_inTicks.Text = this.T2size_inTicks.ToString();
            nudT2size_inTicks.KeyDown += menuTxtbox_KeyDown;
            nudT2size_inTicks.TextChanged += delegate(object o, TextChangedEventArgs e){
				int x = Convert.ToInt32(this.nudT2size_inTicks.Text);
				if(x>5000) {
					nudT2size_inTicks.Text = "5000";
					x=5000;
				}
				if(x<1) {
					nudT2size_inTicks.Text = "1";
					x=1;
				}
				T2size_inTicks = x;
				ForceRefresh();
			};
			nudT2size_inTicks.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					T2size_inTicks = (T2size_inTicks<=1 ? 5000 : --T2size_inTicks);
				}else if(e.Delta>0){
					T2size_inTicks = (T2size_inTicks>=5000 ? 1 : ++T2size_inTicks);
				}
				nudT2size_inTicks.Text = T2size_inTicks.ToString();
				ForceRefresh();
			};

            nudT2size_inTicks.SetValue(Grid.ColumnProperty, 1);
            nudT2size_inTicks.SetValue(Grid.RowProperty, row);
            nudT2size_inTicks.SetValue(Grid.RowSpanProperty, 2);

//            Button cmdup2 = new Button() { Name = "CRV2cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
//            Button cmddw2 = new Button() { Name = "CRV2cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
//            cmdup2.Click += cmdupdw_Click;
//            cmdup2.SetValue(Grid.ColumnProperty, 2);
//            cmdup2.SetValue(Grid.RowProperty, 2);
//            cmddw2.Click += cmdupdw_Click;
//            cmddw2.SetValue(Grid.ColumnProperty, 2);
//            cmddw2.SetValue(Grid.RowProperty, 3);
			#endregion

			row++;//blank row for separation

            //line 6 - ATR Mult for T1
			#region -- T1 multiplier --
			row = row+2;
            Label lbl6 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "T1 (ATRs) : " };
            lbl6.SetValue(Grid.ColumnProperty, 0);
            lbl6.SetValue(Grid.RowProperty, row);
            lbl6.SetValue(Grid.RowSpanProperty, 2);

            nudT1size_inATRs = new TextBox() { Name = "tb_MultForT1" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, BorderBrush = gLabel.Foreground };
            nudT1size_inATRs.Text = this.T1size_inATRs.ToString();
            nudT1size_inATRs.KeyDown += menuTxtbox_KeyDown;
            nudT1size_inATRs.TextChanged += delegate(object o, TextChangedEventArgs e){
				var x = Convert.ToDouble(this.nudT1size_inATRs.Text);
				if(x>10) {
					nudT1size_inATRs.Text = "10";
					x=10;
				}
				if(x<0) {
					nudT1size_inATRs.Text = "0";
					x=0;
				}
				T1size_inATRs = x;
				ForceRefresh();
			};
			nudT1size_inATRs.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					T1size_inATRs = (T1size_inATRs<=0 ? 10 : T1size_inATRs-0.5);
				}else if(e.Delta>0){
					T1size_inATRs = (T1size_inATRs>=10 ? 0 : T1size_inATRs+0.5);
				}
				nudT1size_inATRs.Text = T1size_inATRs.ToString();
				ForceRefresh();
			};

            nudT1size_inATRs.SetValue(Grid.ColumnProperty, 1);
            nudT1size_inATRs.SetValue(Grid.RowProperty, row);
            nudT1size_inATRs.SetValue(Grid.RowSpanProperty, 2);
			#endregion

            //line 7 - ATR Mult for T2
			#region -- T2 multiplier --
			row = row+2;
            Label lbl7 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "T2 (ATRs) : " };
            lbl7.SetValue(Grid.ColumnProperty, 0);
            lbl7.SetValue(Grid.RowProperty, row);
            lbl7.SetValue(Grid.RowSpanProperty, 2);

            nudT2size_inATRs = new TextBox() { Name = "tb_MultForT2" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, BorderBrush = gLabel.Foreground };
            nudT2size_inATRs.Text = this.T2size_inATRs.ToString();
            nudT2size_inATRs.KeyDown += menuTxtbox_KeyDown;
            nudT2size_inATRs.TextChanged += delegate(object o, TextChangedEventArgs e){
				double x = Convert.ToDouble(this.nudT2size_inATRs.Text);
				if(x>10) {
					nudT2size_inATRs.Text = "10";
					x=10;
				}
				if(x<0) {
					nudT2size_inATRs.Text = "0";
					x=0;
				}
				T2size_inATRs = x;
				ForceRefresh();
			};
			nudT2size_inATRs.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					T2size_inATRs = (T2size_inATRs<=0 ? 10 : T2size_inATRs-0.5);
				}else if(e.Delta>0){
					T2size_inATRs = (T2size_inATRs>=10 ? 0 : T2size_inATRs+0.5);
				}
				nudT2size_inATRs.Text = T2size_inATRs.ToString();
				ForceRefresh();
			};

            nudT2size_inATRs.SetValue(Grid.ColumnProperty, 1);
            nudT2size_inATRs.SetValue(Grid.RowProperty, row);
            nudT2size_inATRs.SetValue(Grid.RowSpanProperty, 2);

//            Button cmdup2 = new Button() { Name = "CRV2cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
//            Button cmddw2 = new Button() { Name = "CRV2cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
//            cmdup2.Click += cmdupdw_Click;
//            cmdup2.SetValue(Grid.ColumnProperty, 2);
//            cmdup2.SetValue(Grid.RowProperty, 2);
//            cmddw2.Click += cmdupdw_Click;
//            cmddw2.SetValue(Grid.ColumnProperty, 2);
//            cmddw2.SetValue(Grid.RowProperty, 3);
			#endregion

			row++;//blank row for separation

            //line 8 - RR Mult for T1
			#region -- T1 multiplier --
			row = row+2;
            Label lbl8 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "T1 (RRs) : " };
            lbl8.SetValue(Grid.ColumnProperty, 0);
            lbl8.SetValue(Grid.RowProperty, row);
            lbl8.SetValue(Grid.RowSpanProperty, 2);

            nudT1size_inRRs = new TextBox() { Name = "tb_MultForT1_RR" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, BorderBrush = gLabel.Foreground };
            nudT1size_inRRs.Text = this.T1size_inRRs.ToString();
            nudT1size_inRRs.KeyDown += menuTxtbox_KeyDown;
            nudT1size_inRRs.TextChanged += delegate(object o, TextChangedEventArgs e){
				var x = Convert.ToDouble(this.nudT1size_inRRs.Text);
				if(x>10) {
					nudT1size_inRRs.Text = "10";
					x=10;
				}
				if(x<0) {
					nudT1size_inRRs.Text = "0";
					x=0;
				}
				T1size_inRRs = x;
				ForceRefresh();
			};
			nudT1size_inRRs.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					T1size_inRRs = (T1size_inRRs<=0 ? 10 : T1size_inRRs-0.5);
				}else if(e.Delta>0){
					T1size_inRRs = (T1size_inRRs>=10 ? 0 : T1size_inRRs+0.5);
				}
				nudT1size_inRRs.Text = T1size_inRRs.ToString();
				ForceRefresh();
			};

            nudT1size_inRRs.SetValue(Grid.ColumnProperty, 1);
            nudT1size_inRRs.SetValue(Grid.RowProperty, row);
            nudT1size_inRRs.SetValue(Grid.RowSpanProperty, 2);
			#endregion

            //line 9 - RR Mult for T2
			#region -- T2 multiplier --
			row = row+2;
            Label lbl9 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "T2 (RRs) : " };
            lbl9.SetValue(Grid.ColumnProperty, 0);
            lbl9.SetValue(Grid.RowProperty, row);
            lbl9.SetValue(Grid.RowSpanProperty, 2);

            nudT2size_inRRs = new TextBox() { Name = "tb_MultForT2_RR" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), TextAlignment=TextAlignment.Center, BorderBrush = gLabel.Foreground };
            nudT2size_inRRs.Text = this.T2size_inRRs.ToString();
            nudT2size_inRRs.KeyDown += menuTxtbox_KeyDown;
            nudT2size_inRRs.TextChanged += delegate(object o, TextChangedEventArgs e){
				double x = Convert.ToDouble(this.nudT2size_inRRs.Text);
				if(x>10) {
					nudT2size_inRRs.Text = "10";
					x=10;
				}
				if(x<0) {
					nudT2size_inRRs.Text = "0";
					x=0;
				}
				T2size_inRRs = x;
				ForceRefresh();
			};
			nudT2size_inRRs.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(e.Delta<0){
					T2size_inRRs = (T2size_inRRs<=0 ? 10 : T2size_inRRs-0.5);
				}else if(e.Delta>0){
					T2size_inRRs = (T2size_inRRs>=10 ? 0 : T2size_inRRs+0.5);
				}
				nudT2size_inRRs.Text = T2size_inRRs.ToString();
				ForceRefresh();
			};

            nudT2size_inRRs.SetValue(Grid.ColumnProperty, 1);
            nudT2size_inRRs.SetValue(Grid.RowProperty, row);
            nudT2size_inRRs.SetValue(Grid.RowSpanProperty, 2);

//            Button cmdup2 = new Button() { Name = "CRV2cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
//            Button cmddw2 = new Button() { Name = "CRV2cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
//            cmdup2.Click += cmdupdw_Click;
//            cmdup2.SetValue(Grid.ColumnProperty, 2);
//            cmdup2.SetValue(Grid.RowProperty, 2);
//            cmddw2.Click += cmdupdw_Click;
//            cmddw2.SetValue(Grid.ColumnProperty, 2);
//            cmddw2.SetValue(Grid.RowProperty, 3);
			#endregion

grid.Children.Add(lbla);
grid.Children.Add(nudEntryOffset);
//            grid.Children.Add(cmdup1);
//            grid.Children.Add(cmddw1);
grid.Children.Add(lbl0);
grid.Children.Add(nudSLOffset);
//            grid.Children.Add(cmdup1);
//            grid.Children.Add(cmddw1);
grid.Children.Add(lbl1);
grid.Children.Add(nudATRperiod);
//            grid.Children.Add(cmdup1);
//            grid.Children.Add(cmddw1);
grid.Children.Add(lbl2);
grid.Children.Add(nudSLsize_inTicks);
//            grid.Children.Add(cmdup2);
//            grid.Children.Add(cmddw2);
grid.Children.Add(lbl5);
grid.Children.Add(nudSLsize_inATRs);
//            grid.Children.Add(cmdup2);
//            grid.Children.Add(cmddw2);
grid.Children.Add(lbl3);
grid.Children.Add(nudT1size_inTicks);
//            grid.Children.Add(cmdup2);
//            grid.Children.Add(cmddw2);
grid.Children.Add(lbl4);
grid.Children.Add(nudT2size_inTicks);
//            grid.Children.Add(cmdup2);
//            grid.Children.Add(cmddw2);
//grid.Children.Add(new Separator());
grid.Children.Add(lbl6);
grid.Children.Add(nudT1size_inATRs);
//            grid.Children.Add(cmdup2);
//            grid.Children.Add(cmddw2);
grid.Children.Add(lbl7);
grid.Children.Add(nudT2size_inATRs);
//            grid.Children.Add(cmdup2);
//            grid.Children.Add(cmddw2);
grid.Children.Add(lbl8);
grid.Children.Add(nudT1size_inRRs);
//            grid.Children.Add(cmdup2);
//            grid.Children.Add(cmddw2);
grid.Children.Add(lbl9);
grid.Children.Add(nudT2size_inRRs);
//            grid.Children.Add(cmdup2);
//            grid.Children.Add(cmddw2);

            return grid;
        }
		#endregion

        //---------- Events ------------------------------------------------
        #region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #region private void cmdupdw_Click(object sender, RoutedEventArgs e)
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
            Button cmd = sender as Button;
            if (cmd.Name.Contains("MTFcmdup")) nudMTF.Text = (Math.Min(999999, Convert.ToInt32(nudMTF.Text) + 1)).ToString();
            else if (cmd.Name.Contains("MTFcmddw")) nudMTF.Text = (Math.Max(1, Convert.ToInt32(nudMTF.Text) - 1)).ToString();

            else if (cmd.Name.Contains("ZFMcmdup")) nudZFM.Text = (Math.Min(1000, Convert.ToInt32(nudZFM.Text) + 25)).ToString();
            else if (cmd.Name.Contains("ZFMcmddw")) nudZFM.Text = (Math.Max(0, Convert.ToInt32(nudZFM.Text) - 25)).ToString();

            else if (cmd.Name.Contains("MST1cmdup")) nudMST1.Text = (Math.Min(999999999, Convert.ToInt32(nudMST1.Text) + 1)).ToString();
            else if (cmd.Name.Contains("MST1cmddw")) nudMST1.Text = (Math.Max(0, Convert.ToInt32(nudMST1.Text) - 1)).ToString();
            else if (cmd.Name.Contains("MST2cmdup")) nudMST2.Text = (Math.Min(999999999, Convert.ToInt32(nudMST2.Text) + 1)).ToString();
            else if (cmd.Name.Contains("MST2cmddw")) nudMST2.Text = (Math.Max(1, Convert.ToInt32(nudMST2.Text) - 1)).ToString();

            else if (cmd.Name.Contains("VA1cmdup")) {
				this.iVAPeriod = Math.Min(999999999, Convert.ToInt32(nudVA1.Text) + 1);
				nudVA1.Text = (iVAPeriod).ToString();
			}
            else if (cmd.Name.Contains("VA1cmddw")) {
				this.iVAPeriod = Math.Max(1, Convert.ToInt32(nudVA1.Text) - 1);
				nudVA1.Text = (iVAPeriod).ToString();
			}
            else if (cmd.Name.Contains("VA2cmdup")) {
				this.iVA2Period = Math.Min(999999999, Convert.ToInt32(nudVA2.Text) + 1);
				nudVA2.Text = (iVA2Period).ToString();
			}
            else if (cmd.Name.Contains("VA2cmddw")) {
				this.iVA2Period = Math.Max(1, Convert.ToInt32(nudVA2.Text) - 1);
				nudVA2.Text = (iVA2Period).ToString();
			}
        }
        #endregion
        
        #region private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtSender = sender as TextBox;

            int keyVal = (int)e.Key;
            int value = -1;
            if (keyVal >= (int)Key.D0 && keyVal <= (int)Key.D9) value = keyVal - (int)Key.D0;
            else if (keyVal >= (int)Key.NumPad0 && keyVal <= (int)Key.NumPad9) value = keyVal - (int)Key.NumPad0;

            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);

            if (isNumeric || e.Key == Key.Back)
            {
                string newText = value != -1 ? value.ToString() : "";
                int tbPosition = txtSender.SelectionStart;
                txtSender.Text = txtSender.SelectedText == "" ? txtSender.Text.Insert(tbPosition, newText) : txtSender.Text.Replace(txtSender.SelectedText, newText);
                txtSender.Select(tbPosition + 1, 0);
            }
        }
        #endregion

        #region private void MenuItemF5_Click(object sender, EventArgs e)
        private void MenuItemF5_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- chartTimeFrameClick --
            if (item != null && item.Name == "chartTimeFrameClick")
            {
                this.iChartMode1 = ARC_SDVSystem_ZoneMode2.DEFAULT_CHART;                
            }
            #endregion
            
            #region -- mtfTimeFrameClick --
            else if (item == null || item.Name == "mtfTimeFrameClick")
            {
                this.iChartType1 = (ARC_SDVSystem_MTFBarType)Enum.Parse(typeof(ARC_SDVSystem_MTFBarType), comboMTF.SelectedItem.ToString(), true);
                this.iChartValue1 = Convert.ToInt32(nudMTF.Text);
                this.iChartMode1 = ARC_SDVSystem_ZoneMode2.MTF;
            }
            #endregion
            
            #region -- zoneFormationClick --
            else if (item.Name == "zoneFormationClick")
            {
                ARC_SDVSystem_ZoneBool2 tempBool = (ARC_SDVSystem_ZoneBool2)Enum.Parse(typeof(ARC_SDVSystem_ZoneBool2), comboZFM.SelectedItem.ToString(), true);
                this.applyRangeFilter = (tempBool == ARC_SDVSystem_ZoneBool2.True) ? true : false;
                this.barFilter = Convert.ToInt32(nudZFM.Text);
            }
            #endregion

            #region -- marketStructureClick --
            else if (item.Name == "marketStructureClick")
            {
                this.percentATR = Convert.ToInt32(nudMST1.Text);
                this.swingStrength = Convert.ToInt32(nudMST2.Text);
            }
            #endregion

            System.Windows.Forms.SendKeys.SendWait("{F5}");
        }
        #endregion

        #region private void NumericUpDownValueChanged(object TextChangedEventArgs, EventArgs e) 
//        private string currentTextEdit;
//        private void NumericUpDownValueChanged(object sender, TextChangedEventArgs e)
//        {
//            TextBox txtSender = sender as TextBox;
//            if (txtSender.Text.Length > 0)
//            {
//                float result;
//                bool isNumeric = float.TryParse(txtSender.Text, out result);

//                if (isNumeric) currentTextEdit = txtSender.Text;
//                else
//                {
//                    txtSender.Text = currentTextEdit;
//                    txtSender.Select(txtSender.Text.Length, 0);
//                }
//                if (txtSender.Name == "MTFtxtbox")       iChartValue1  = Convert.ToInt32(nudMTF.Text);
//                else if (txtSender.Name == "ZFMtxtbox")  barFilter     = Convert.ToInt32(nudZFM.Text);
//                else if (txtSender.Name == "MST1txtbox") percentATR    = Convert.ToInt32(nudMST1.Text);
//                else if (txtSender.Name == "MST2txtbox") swingStrength = Convert.ToInt32(nudMST2.Text);
//                else if (txtSender.Name == "CRV1txtbox") pDefiance = Math.Max(0,Math.Min(1000,Convert.ToInt32(nudCRV1.Text)));
//                else if (txtSender.Name == "CRV2txtbox") pBreakATR = Math.Max(0,Math.Min(1000,Convert.ToInt32(nudCRV2.Text)));
//            }            
//        }
        #endregion

        #region private void curveMenuItem_Click(object sender, EventArgs e)
        private void curveMenuItem_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- pDisplayEnabled --
            if (item.Name == "pDisplayEnabled")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    pDisplayEnabled = false;
                    item.Header = "Curve OFF";
                }
                else
                {
                    pDisplayEnabled = true;
                    item.Header = "Curve ON";
                }
            }
            #endregion

            #region -- pDisplayPrice --
            else if (item.Name == "pDisplayPrice")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    pDisplayPrice = false;
                    item.Header = "Price Labels OFF";
                }
                else
                {
                    pDisplayPrice = true;
                    item.Header = "Price Labels ON";
                }
            }
            #endregion

            #region -- pDisplayPercent --
            else if (item.Name == "pDisplayPercent")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    pDisplayPercent = false;
                    item.Header = "Percent Labels OFF";
                }
                else
                {
                    pDisplayPercent = true;
                    item.Header = "Percent Labels ON";
                }
            }
            #endregion

            #region -- pDisplayText --
            else if (item.Name == "pDisplayText")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    pDisplayText = false;
                    item.Header = "Text Labels OFF";
                }
                else
                {
                    pDisplayText = true;
                    item.Header = "Text Labels ON";
                }
            }
            #endregion

            ChartControl.InvalidateVisual();
        }
        #endregion

        #region -- profileMasterMenuItem_Click --
        private void profileMasterMenuItem_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            bool setProfileToggles = false;
            bool toggleState = false;
            int type = -1;
            int state = -1;

            #region -- showAllProfile --
            if (item.Name == "showAllProfile")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowAllProfile = false;
                    item.Header = "Profiles OFF";

                    this.iShowAllSupplyProfile = this.iShowAllProfile;
                    miProfileM2.Header = "Supply Profiles OFF";
                    this.iShowAllDemandProfile = this.iShowAllProfile;
                    miProfileM3.Header = "Demand Profiles OFF";
                    this.iShowAllTestedProfile = this.iShowAllProfile;
                    miProfileM4.Header = "Tested Profiles OFF";
                    this.iShowAllBrokenProfile = this.iShowAllProfile;
                    miProfileM5.Header = "Broken Profiles OFF";
                }
                else
                {
                    this.iShowAllProfile = true;
                    item.Header = "Profiles ON";

                    this.iShowAllSupplyProfile = this.iShowAllProfile;
                    miProfileM2.Header = "Supply Profiles ON";
                    this.iShowAllDemandProfile = this.iShowAllProfile;
                    miProfileM3.Header = "Demand Profiles ON";
                    this.iShowAllTestedProfile = this.iShowAllProfile;
                    miProfileM4.Header = "Tested Profiles ON";
                    this.iShowAllBrokenProfile = this.iShowAllProfile;
                    miProfileM5.Header = "Broken Profiles ON";
                }

                toggleState = this.iShowAllProfile;
                type = GZ_DEMANDSUPPLY;
                setProfileToggles = true;
            }
            #endregion

            #region -- showAllSupplyProfile --
            else if (item.Name == "showAllSupplyProfile")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowAllSupplyProfile = false;
                    item.Header = "Supply Profiles OFF";
                }
                else
                {
                    this.iShowAllSupplyProfile = true;
                    item.Header = "Supply Profiles ON";
                }

                type = GZ_SUPPLY;
                toggleState = this.iShowAllSupplyProfile;
                setProfileToggles = true;
            }
            #endregion

            #region -- showAllDemandProfile --
            else if (item.Name == "showAllDemandProfile")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowAllDemandProfile = false;
                    item.Header = "Demand Profiles OFF";
                }
                else
                {
                    this.iShowAllDemandProfile = true;
                    item.Header = "Demand Profiles ON";
                }

                type = GZ_DEMAND;
                toggleState = this.iShowAllDemandProfile;
                setProfileToggles = true;
            }
            #endregion

            #region -- showAllTestedProfile --
            else if (item.Name == "showAllTestedProfile")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowAllTestedProfile = false;
                    item.Header = "Tested Profiles OFF";
                }
                else
                {
                    this.iShowAllTestedProfile = true;
                    item.Header = "Tested Profiles ON";
                }

                state = GZ_TESTED;
                toggleState = this.iShowAllTestedProfile;
                setProfileToggles = true;
            }
            #endregion

            #region -- showAllBrokenProfile --
            else if (item.Name == "showAllBrokenProfile")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowAllBrokenProfile = false;
                    item.Header = "Broken Profiles OFF";
                }
                else
                {
                    this.iShowAllBrokenProfile = true;
                    item.Header = "Broken Profiles ON";
                }

                state = GZ_BROKEN;
                toggleState = this.iShowAllBrokenProfile;
                setProfileToggles = true;
            }
            #endregion

            #region -- setProfileToggles --
            if (setProfileToggles)
            {
                if (toggleState == false)
                {
                    this.SetProfileToggles(
                        type,
                        state,
                        toggleState,
                        toggleState,
                        toggleState,
                        toggleState,
                        (int)this.iProfileExpansion,
                        toggleState,
                        toggleState,
                        toggleState,
                        toggleState);
                }
                else
                {
                    this.SetProfileToggles(
                        type,
                        state,
                        this.iShowProfile,
                        this.iShowPOC,
                        this.iShowVAL,
                        this.iShowVAH,
                        (int)this.iProfileExpansion,
                        this.iShowVolumeCluster,
                        this.iShowVolumeRatio,
                        this.iShowDeltaFactor,
                        this.iShowVolumeValues);
                }

                ChartControl.InvalidateVisual();
            }
            #endregion
        }
        #endregion

        #region private void ComboProfile_SelectionChanged(object sender, SelectionChangedEventArgs e)
        private void ComboProfile_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MenuItem mi = new MenuItem { Name = "updateProfileExpansion" };
            profileMenuItem_Click(mi, null);
        }
        #endregion

        #region private void profileMenuItem_Click(object sender, EventArgs e)
        private void profileMenuItem_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            bool setProfileToggles = false;

            #region -- showProfile --
            if (item.Name == "showProfile")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowProfile = false;
                    item.Header = "Profile OFF";
                }
                else
                {
                    this.iShowProfile = true;
                    item.Header = "Profile ON";
                }

                setProfileToggles = true;
            }
            #endregion

            #region -- showPOC --
            else if (item.Name == "showPOC")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowPOC = false;
                    item.Header = "POC OFF";
                }
                else
                {
                    this.iShowPOC = true;
                    item.Header = "POC ON";
                }

                setProfileToggles = true;
            }
            #endregion

            #region -- showVAL --
            else if (item.Name == "showVAL")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowVAL = false;
                    item.Header = "VAL OFF";
                }
                else
                {
                    this.iShowVAL = true;
                    item.Header = "VAL ON";
                }

                setProfileToggles = true;
            }
            #endregion

            #region -- showVAH --
            else if (item.Name == "showVAH")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowVAH = false;
                    item.Header = "VAH OFF";
                }
                else
                {
                    this.iShowVAH = true;
                    item.Header = "VAH ON";
                }

                setProfileToggles = true;
            }
            #endregion

            #region -- updateProfileExpansion --
            else if (item.Name == "updateProfileExpansion")
            {
                this.iProfileExpansion = (ARC_SDVSystem_ProfileExpansion)Enum.Parse(typeof(ARC_SDVSystem_ProfileExpansion), comboProfile.SelectedItem.ToString(), true);
                setProfileToggles = true;
            }
            #endregion

            #region -- showVolumeCluster --
            else if (item.Name == "showVolumeCluster")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowVolumeCluster = false;
                    item.Header = "Volume Cluster OFF";
                }
                else
                {
                    this.iShowVolumeCluster = true;
                    item.Header = "Volume Cluster ON";
                }

                setProfileToggles = true;
            }
            #endregion

            #region -- showVolumeRatio --
            else if (item.Name == "showVolumeRatio")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowVolumeRatio = false;
                    item.Header = "Volume Ratio OFF";
                }
                else
                {
                    this.iShowVolumeRatio = true;
                    item.Header = "Volume Ratio ON";
                }

                setProfileToggles = true;
            }
            #endregion

            #region -- showDeltaFactor --
            else if (item.Name == "showDeltaFactor")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowDeltaFactor = false;
                    item.Header = "Delta Factor OFF";
                }
                else
                {
                    this.iShowDeltaFactor = true;
                    item.Header = "Delta Factor ON";
                }

                setProfileToggles = true;
            }
            #endregion

            #region -- showVolumeValues --
            else if (item.Name == "showVolumeValues")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowVolumeValues = false;
                    item.Header = "Volume Values OFF";
                }
                else
                {
                    this.iShowVolumeValues = true;
                    item.Header = "Volume Values ON";
                }

                setProfileToggles = true;
            }
            #endregion

            #region -- showLVNs --
            else if (item.Name == "showLVNs")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowLVNProfile = false;
                    item.Header = "LVNs OFF";
                }
                else
                {
                    this.iShowLVNProfile = true;
                    item.Header = "LVNs ON";
                }

                setProfileToggles = false;
                ChartControl.InvalidateVisual();
            }
            #endregion

            #region -- expandLVNs --
            else if (item.Name == "expandLVNs")
            {
                if (item.Header.ToString().Contains("Expanded"))
                {
                    this.iExpandLVNProfile = false;
                    item.Header = "LVNs Normalized";
                }
                else
                {
                    this.iExpandLVNProfile = true;
                    item.Header = "LVNs Expanded";
                }

                setProfileToggles = false;
                ChartControl.InvalidateVisual();
            }
            #endregion

            #region -- setProfileToggles --
            if (setProfileToggles)
            {
                if (this.iShowAllProfile)
                {
                    this.SetProfileToggles(
                        GZ_DEMANDSUPPLY,
                        -1,
                        this.iShowProfile,
                        this.iShowPOC,
                        this.iShowVAL,
                        this.iShowVAH,
                        (int)this.iProfileExpansion,
                        this.iShowVolumeCluster,
                        this.iShowVolumeRatio,
                        this.iShowDeltaFactor,
                        this.iShowVolumeValues);
                }

                if (this.iShowAllSupplyProfile)
                {
                    this.SetProfileToggles(
                        GZ_SUPPLY,
                        -1,
                        this.iShowProfile,
                        this.iShowPOC,
                        this.iShowVAL,
                        this.iShowVAH,
                        (int)this.iProfileExpansion,
                        this.iShowVolumeCluster,
                        this.iShowVolumeRatio,
                        this.iShowDeltaFactor,
                        this.iShowVolumeValues);
                }

                if (this.iShowAllDemandProfile)
                {
                    this.SetProfileToggles(
                        GZ_DEMAND,
                        -1,
                        this.iShowProfile,
                        this.iShowPOC,
                        this.iShowVAL,
                        this.iShowVAH,
                        (int)this.iProfileExpansion,
                        this.iShowVolumeCluster,
                        this.iShowVolumeRatio,
                        this.iShowDeltaFactor,
                        this.iShowVolumeValues);
                }

                if (this.iShowAllTestedProfile)
                {
                    this.SetProfileToggles(
                        -1,
                        GZ_TESTED,
                        this.iShowProfile,
                        this.iShowPOC,
                        this.iShowVAL,
                        this.iShowVAH,
                        (int)this.iProfileExpansion,
                        this.iShowVolumeCluster,
                        this.iShowVolumeRatio,
                        this.iShowDeltaFactor,
                        this.iShowVolumeValues);
                }

                if (this.iShowAllBrokenProfile)
                {
                    this.SetProfileToggles(
                        -1,
                        GZ_BROKEN,
                        this.iShowProfile,
                        this.iShowPOC,
                        this.iShowVAL,
                        this.iShowVAH,
                        (int)this.iProfileExpansion,
                        this.iShowVolumeCluster,
                        this.iShowVolumeRatio,
                        this.iShowDeltaFactor,
                        this.iShowVolumeValues);
                }

                ChartControl.InvalidateVisual();
            }
            #endregion
        }
        #endregion

        #region private void controlMenuItem_Click(object sender, EventArgs e)
        private void controlMenuItem_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            if (item.Name == "zonesLockClick")
            {
                // Loop and lock All zones
                for (int g = 0; g < this.GZS.Count; g++) GZS[g].Locked = true;
                this.MM.Clear();
                ChartControl.InvalidateVisual();
            }
        }
        #endregion

        #region private void mstMenuItem_Click(object sender, EventArgs e)
        private void mstMenuItem_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- showMarketStructureClick --
            if (item.Name == "showMarketStructureClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.showZigZag = false;
                    item.Header = "Market Structure OFF";
                }
                else
                {
                    this.showZigZag = true;
                    item.Header = "Market Structure ON";
                }
            }
            #endregion

            ChartControl.InvalidateVisual();
        }
        #endregion

        #region private void visualMenuItem_Click(object sender, EventArgs e)
        private void visualMenuItem_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;
            
            #region -- showSDVZonesClick --
            if (item.Name == "showSDVZonesClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowSDVZones = false;
                    item.Header = "SDV Zones OFF";
					DeleteAllZones("@GZ_");
                }
                else
                {
                    this.iShowSDVZones = true;
                    item.Header = "SDV Zones ON";
                }
            }
            #endregion

            #region -- showSupplyZonesClick --
            else if (item.Name == "showSupplyZonesClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowSupplyZones = false;
                    item.Header = "Supply Zones OFF";
					DeleteAllZones("Type", GZ_SUPPLY);
                }
                else
                {
                    this.iShowSupplyZones = true;
                    item.Header = "Supply Zones ON";
                }
            }
            #endregion

            #region -- showDemandZonesClick --
            else if (item.Name == "showDemandZonesClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowDemandZones = false;
                    item.Header = "Demand Zones OFF";
					DeleteAllZones("Type", GZ_DEMAND);
                }
                else
                {
                    this.iShowDemandZones = true;
                    item.Header = "Demand Zones ON";
                }
            }
            #endregion

            #region -- showFreshZonesClick --
            else if (item.Name == "showFreshZonesClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowFreshZones = false;
                    item.Header = "Fresh Zones OFF";
					DeleteAllZones("State", GZ_FRESH);
                }
                else
                {
                    this.iShowFreshZones = true;
                    item.Header = "Fresh Zones ON";
                }
            }
            #endregion

            #region -- showTestedZonesClick --
            else if (item.Name == "showTestedZonesClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowTestedZones = false;
                    item.Header = "Tested Zones OFF";
					DeleteAllZones("State", GZ_TESTED);
                }
                else
                {
                    this.iShowTestedZones = true;
                    item.Header = "Tested Zones ON";
                }
            }
            #endregion

            #region -- showHiddenZonesClick --
            else if (item.Name == "showHiddenZonesClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowHiddenZones = false;
                    item.Header = "Hidden Zones OFF";
                }
                else
                {
                    this.iShowHiddenZones = true;
                    item.Header = "Hidden Zones ON";
                }
            }
            #endregion

            #region -- showBrokenZonesClick --
            else if (item.Name == "showBrokenZonesClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowBrokenZones = false;
                    item.Header = "Broken Zones OFF";
					DeleteAllZones("State", GZ_BROKEN);
                }
                else
                {
                    this.iShowBrokenZones = true;
                    item.Header = "Broken Zones ON";
                }
            }
            #endregion
			else if(item.Name == "showQualifiedZonesClick")
			{
                if (item.Header.ToString().Contains("ONLY"))
                {
                    this.iFilterQualifiedZones = false;
                    item.Header = "No Qualification Filter";
                }
                else
                {
                    this.iFilterQualifiedZones = true;
                    item.Header = "Qualified Zones ONLY";
                }
			}

            #region -- showTestedShadingClick --
            else if (item.Name == "showTestedShadingClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowTestedShading = false;
                    item.Header = "Tested Shading OFF";
                }
                else
                {
                    this.iShowTestedShading = true;
                    item.Header = "Tested Shading ON";
                }
            }
            #endregion

            #region -- showTestedMarkerClick --
            else if (item.Name == "showTestedMarkerClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowTestedMarker = false;
                    item.Header = "Tested Marker OFF";
                }
                else
                {
                    this.iShowTestedMarker = true;
                    item.Header = "Tested Marker ON";
                }
            }
            #endregion

            #region -- showPriceLabelsClick --
            else if (item.Name == "showPriceLabelsClick")
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.iShowPriceLabels = false;
                    item.Header = "Price Labels OFF";
                }
                else
                {
                    this.iShowPriceLabels = true;
                    item.Header = "Price Labels ON";
                }
            }
            #endregion

            ChartControl.InvalidateVisual();
        }
        #endregion

        #endregion

        #region -- MouseEvents Utilities --
        private void ChartPanel_MouseMove(object sender, MouseEventArgs e)
        {
            Point coords = e.GetPosition(ChartPanel);
			int X = ChartingExtensions.ConvertToHorizontalPixels(coords.X, ChartControl.PresentationSource);
		    int Y = ChartingExtensions.ConvertToVerticalPixels(coords.Y, ChartControl.PresentationSource);

            if (this.GZS == null) return;
            this.MM.X = X;
            this.MM.Y = Y;
            bool foundHover = false;
//Print("MM.abar: "+MM.abar+"   "+Times[0].GetValueAt(MM.abar).ToString());
			var zones = GZS.Where(z=>z.Top >= MM.price && z.Bottom <= MM.price && z.StartBar < MM.abar && (z.EndBar==0 || z.EndBar > MM.abar)).ToList();
            //detect if mouse over zone
//			for (int g = 0; g < this.GZS.Count; g++)
//Print("zones.count: "+zones.Count());
			foreach(GZone z in zones)
			{
				//int g = z.IDnum;
                //if (z.Visible) continue;
                for (int i = 0; i < z.MouseRects.Length; i++)
                {
//Print("i: "+i);
                    if (z.MouseRects[i].Contains(X, Y))
                    {
//Print(i+"  xy: "+GZS[g].MouseRects[i].X+" x "+GZS[g].MouseRects[i].Y+"  wl: "+GZS[g].MouseRects[i].Width+"  "+GZS[g].MouseRects[i].Height);
//Print("z.Locked: "+z.Locked.ToString()+"   z.PLocked: "+z.PLocked.ToString());
						if (z.Locked && i == CONTROLX) continue;
						if (z.PLocked && (i >= CONTROLPPR && i <= CONTROLPVV)) continue;
						//if(Keyboard.IsKeyDown(Key.LeftCtrl)) 
							this.MM.HoverIndex = z.IDnum;
						this.MM.Index = i;
//Print("MM.Index set to: "+MM.Index);
//Print("HoverIndex: "+MM.HoverIndex+"   width:  "+z.MouseRects[i].Width+"   endbar: "+z.EndBar+"   EndTime: "+z.EndTime.ToString());
						foundHover = true;
						break;
					}
                }
            }

            if (!foundHover) {
				this.MM.SelectedProfileId = -1;
				this.MM.HoverIndex = -1;
			} else if(pGlobalObjects_Enabled) {
				MM.SelectedProfileId      = MM.HoverIndex;
			}

            ChartControl.InvalidateVisual();
        }
//=============================================================================================================
		private void ImmediatelyDraw_Zone(string tag, SortedDictionary<string, Global_RectsData> dict){
			#region -- Draw Global Supply/Demand zone rect --------------------------------
//Print("tag: "+global_obj_tag);
			if(tag!=null && tag.Length>0 && dict[tag].IsDrawn==false){
				TriggerCustomEvent(o =>{	Draw.Rectangle(this, tag, dict[tag].DTStart, dict[tag].TopPrice, (dict[tag].DTEnd==DateTime.MaxValue ? Times[0].GetValueAt(CurrentBars[0]).AddDays(5) : dict[tag].DTEnd), dict[tag].BottomPrice, true, dict[tag].TemplateName);},0,null);
				dict[tag].IsDrawn=true;
			}
			if(IsFirstTickOfBar){//if this is an untested zone, then the right-edge of the rectangle must continue to expand to the current bar
				if(tag!=null && tag.Length>0 && dict[tag].IsDrawn && dict[tag].DTEnd==DateTime.MaxValue){
					TriggerCustomEvent(o =>{	Draw.Rectangle(this, tag, dict[tag].DTStart, dict[tag].TopPrice, Times[0].GetValueAt(CurrentBars[0]).AddDays(5), dict[tag].BottomPrice, true, dict[tag].TemplateName);},0,null);
				}
			}
			GetGlobalObjCount("@GZ_", false);
			#endregion -----------------------------------------------------------
		}
//=============================================================================================================
        private void ChartPanel_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (this.MM.HoverIndex >= 0)
            {
                if (this.MM.Index == CONTROLZ)
                {
                    if (this.GZS[this.MM.HoverIndex].Locked) this.GZS[this.MM.HoverIndex].Locked = false;
                    else this.GZS[this.MM.HoverIndex].Locked = true;
                }
                else if (this.MM.Index == CONTROLPL)
                {
//Print("11145 "+DateTime.Now.ToString());
                    if (this.GZS[this.MM.HoverIndex].PLocked) this.GZS[this.MM.HoverIndex].PLocked = false;
                    else this.GZS[this.MM.HoverIndex].PLocked = true;
                }
                else if (this.MM.Index >= CONTROLPPR && this.MM.Index <= CONTROLPVV)
                {
                    if (this.MM.Index != CONTROLPVP)
                    {
                        if (this.GZS[this.MM.HoverIndex].MouseBtnStates[this.MM.Index]) this.GZS[this.MM.HoverIndex].MouseBtnStates[this.MM.Index] = false;
                        else this.GZS[this.MM.HoverIndex].MouseBtnStates[this.MM.Index] = true;
                    }
                    else
                    {
                        if (this.GZS[this.MM.HoverIndex].MouseBtnIStates[this.MM.Index] < 4)
                        {
                            this.GZS[this.MM.HoverIndex].MouseBtnStates[this.MM.Index] = true;
                            this.GZS[this.MM.HoverIndex].MouseBtnIStates[this.MM.Index]++;
                        }
                        else
                        {
                            this.GZS[this.MM.HoverIndex].MouseBtnStates[this.MM.Index] = false;
                            this.GZS[this.MM.HoverIndex].MouseBtnIStates[this.MM.Index] = 0;
                        }
                    }
                }
                else if (this.MM.Index == CONTROLX) 
					this.GZS.RemoveAt(this.MM.HoverIndex);
				else{
					if(this.pGlobalObjects_Enabled && MM.SelectedProfileId>=0){
						string tag = CalculateRectKey(GZS[MM.SelectedProfileId].ID);
						if(Global_Zone_Rects.ContainsKey(tag)){
//Print("Deleting tag: "+global_obj_tag);
							RemoveDrawObject(tag);
							Global_Zone_Rects.Remove(tag);
							GetGlobalObjCount("@GZ_",false);
						}else{
							if(GZS[MM.SelectedProfileId].Type == GZ_DEMAND){
								string template = DetermineTemplateName (GZS[MM.SelectedProfileId].State, GZ_DEMAND);
								if(GZS[MM.SelectedProfileId].State==GZ_BROKEN) template = pDemandBrokenZone_Template;
								else if(GZS[MM.SelectedProfileId].State==GZ_TESTED) template = pDemandTestedZone_Template;
								Global_Zone_Rects[tag] = new Global_RectsData(
												GZS[MM.SelectedProfileId].StartBar,
												GZS[MM.SelectedProfileId].StartTime, 
												GZS[MM.SelectedProfileId].Top,
												GZS[MM.SelectedProfileId].State==GZ_BROKEN ? GZS[MM.SelectedProfileId].EndTime : BarsArray[0].GetTime(CurrentBars[0]).AddDays(5), 
												GZS[MM.SelectedProfileId].Bottom, template, DEMAND_ID);
								ImmediatelyDraw_Zone(tag, Global_Zone_Rects);
							}
							if(GZS[MM.SelectedProfileId].Type == GZ_SUPPLY){
								string template = DetermineTemplateName (GZS[MM.SelectedProfileId].State, GZ_SUPPLY);
								Global_Zone_Rects[tag] = new Global_RectsData(
												GZS[MM.SelectedProfileId].StartBar,
												GZS[MM.SelectedProfileId].StartTime, 
												GZS[MM.SelectedProfileId].Top,
												GZS[MM.SelectedProfileId].State==GZ_BROKEN ? GZS[MM.SelectedProfileId].EndTime : BarsArray[0].GetTime(CurrentBars[0]).AddDays(5), 
												GZS[MM.SelectedProfileId].Bottom, template, SUPPLY_ID);
								ImmediatelyDraw_Zone(tag, Global_Zone_Rects);
							}
//Print(string.Format("Zone: ID {0}  State {1}  Lb: {2} @ {3}",GZS[MM.SelectedProfileId].ID, GZS[MM.SelectedProfileId].State, GZS[MM.SelectedProfileId].StartBar, GZS[MM.SelectedProfileId].StartTime.ToString()));
						}
					}
				}
            }
            ChartControl.InvalidateVisual();
        }
//======================================================================================================
		private string DetermineTemplateName (int State, int Type){
			if(Type==GZ_SUPPLY){
				var template = pSupplyFreshZone_Template;
				if(State==GZ_BROKEN)      template = pSupplyBrokenZone_Template;
				else if(State==GZ_TESTED) template = pSupplyTestedZone_Template;
				return template;
			}else{
				var template = pDemandFreshZone_Template;
				if(State==GZ_BROKEN)      template = pDemandBrokenZone_Template;
				else if(State==GZ_TESTED) template = pDemandTestedZone_Template;
				return template;
			}
		}
//======================================================================================================
		private void PrintType(int type){
			if(type == GZ_DEMAND)Print("---------------------------------  Type:   DEMAND");
			if(type == GZ_SUPPLY)Print("---------------------------------  Type:   SUPPLY");
			if(type == GZ_DEMANDSUPPLY)Print("---------------------------------  Type:   DEMANDSUPPLY");
		}
//======================================================================================================
        private void ChartPanel_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Point coords = e.GetPosition(ChartPanel);
			MM.X = ChartingExtensions.ConvertToHorizontalPixels(coords.X, ChartControl.PresentationSource);
		    MM.Y = ChartingExtensions.ConvertToVerticalPixels(coords.Y, ChartControl.PresentationSource);

            #region -- Click Curve.Z Button --
            if (MM.X >= B1.Left && MM.X <= B1.Right && MM.Y >= B1.Top && MM.Y <= B1.Bottom) pIncludeZone = !pIncludeZone;
			//Print("IncludeZone: "+pIncludeZone.ToString());
            #endregion
        }
//======================================================================================================
        private void ChartPanel_KeyUp(object sender, KeyEventArgs k)
        {
//if (k.Key == Key.Space)Print("Space hit");
//if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) Print("Has Control key");
//if(Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) Print("Has Shift key");
			if (k.Key == Key.Space && Keyboard.Modifiers.HasFlag(ModifierKeys.Control) && Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
			{
			    this.iShowSDVZones = !this.iShowSDVZones;
//				Print("iShowSDVZones: "+this.iShowSDVZones.ToString());
			    ChartControl.InvalidateVisual();
			}
		}
		#endregion
//==========================================================================================================================================

		#region -- Zone Management Utilities -- 

		#region -- ProcessZone --
		private void ProcessZone(GZone Zone, double Price, double OPrice, DateTime Time, int CB)
		{
	        // Do not monitor zones that are already broken
	        if (Zone.State == GZ_BROKEN) return;
			int PriorState = Zone.State;
	        // Manage end time
	        if (Zone.State != GZ_BROKEN)
	        {
	            Zone.EndTime = Time;
	            Zone.EndBar = CurrentBar;
	        }

	        #region Supply Management
	        if (Zone.Type == GZ_SUPPLY)
	        {
	            // Check for Break
	            if (Price > Zone.Top)
	            {
	                Zone.State = GZ_BROKEN;
	                Zone.TestMarker = Zone.Top;
	                ProcessProfile(Zone);
					if(IsRealTime && PriorState != Zone.State){
						string global_obj_tag = CalculateRectKey(Zone.ID);
						RemoveDrawObject(global_obj_tag);
						if(Global_Zone_Rects.ContainsKey(global_obj_tag)) Global_Zone_Rects.Remove(global_obj_tag);
						GetGlobalObjCount("@GZ_", false);
					}
	                return;
	            }

	            // Wait for retest checks until after considered fresh
	            if (Zone.State == GZ_FORMED)
	            {
	                if (OPrice < Zone.Bottom) Zone.State = GZ_FRESH;
	                else if (Zone.FormedBar == (CB) && Price >= Zone.Bottom) Zone.State = GZ_FRESH;
	                else return;
	            }

	            // Check for Retest
	            if (Zone.State == GZ_RETEST)
	            {
	                Zone.TestMarker = Math.Max(Zone.TestMarker, Price);
	                if (Price < Zone.Bottom) Zone.State = GZ_TESTED;
	            }
	            else
	            {
	                if ((Price >= Zone.Bottom) && (Price <= Zone.Top))
	                {
	                    Zone.State = GZ_RETEST;
	                    Zone.NumRetests++;
	                    Zone.TestMarker = Math.Max(Zone.TestMarker, Price);
	                    ProcessProfile(Zone);
	                    if (this.iAutoHideRetests && Zone.NumRetests >= this.iAutoHideNumberOfRetests) Zone.State = GZ_HIDDEN;
	                }
	            }
	        }
	        #endregion

	        #region Demand Management
	        if (Zone.Type == GZ_DEMAND)
	        {
	            // Check for Break
	            if (Price < Zone.Bottom)
	            {
	                Zone.State = GZ_BROKEN;
	                Zone.TestMarker = Zone.Bottom;
	                ProcessProfile(Zone);
					if(IsRealTime && PriorState != Zone.State){
						string global_obj_tag = CalculateRectKey(Zone.ID);
						RemoveDrawObject(global_obj_tag);
						if(Global_Zone_Rects.ContainsKey(global_obj_tag)) Global_Zone_Rects.Remove(global_obj_tag);
						GetGlobalObjCount("@GZ_", false);
					}
	                return;
	            }

	            // Wait for retest checks until after considered fresh
	            if (Zone.State == GZ_FORMED)
	            {
	                if (OPrice > Zone.Top) Zone.State = GZ_FRESH;
	                else if (Zone.FormedBar == (CB) && Price <= Zone.Top) Zone.State = GZ_FRESH;
	                else return;
	            }

	            // Check for Retest
	            if (Zone.State == GZ_RETEST)
	            {
	                Zone.TestMarker = Math.Min(Zone.TestMarker, Price);
	                if (Price > Zone.Top) Zone.State = GZ_TESTED;
	            }
	            else
	            {
	                if ((Price >= Zone.Bottom) && (Price <= Zone.Top))
	                {
	                    Zone.State = GZ_RETEST;
	                    Zone.NumRetests++;
	                    Zone.TestMarker = Math.Min(Zone.TestMarker, Price);
	                    ProcessProfile(Zone);
	                    if (this.iAutoHideRetests && Zone.NumRetests >= this.iAutoHideNumberOfRetests) Zone.State = GZ_HIDDEN;
	                }
	            }
	        }
	        #endregion

		}
	    #endregion

		#region private void ProcessProfile(GZone Zone)
		private void ProcessProfile(GZone Zone)
		{
		    bool toggleState = false;
		    if (this.iShowAllTestedProfile && (Zone.State == GZ_RETEST || Zone.State == GZ_TESTED)) toggleState = true;
		    else if (this.iShowAllBrokenProfile && Zone.State == GZ_BROKEN) toggleState = true;

		    if (Zone.State == GZ_RETEST || Zone.State == GZ_TESTED || Zone.State == GZ_BROKEN)
		    {
		        if (toggleState == false)
		            Zone.SetProfileToggles(
		                toggleState,
		                toggleState,
		                toggleState,
		                toggleState,
		                (int)this.iProfileExpansion,
		                toggleState,
		                toggleState,
		                toggleState,
		                toggleState);
		        else
		            Zone.SetProfileToggles(
		                this.iShowProfile,
		                this.iShowPOC,
		                this.iShowVAL,
		                this.iShowVAH,
		                (int)this.iProfileExpansion,
		                this.iShowVolumeCluster,
		                this.iShowVolumeRatio,
		                this.iShowDeltaFactor,
		                this.iShowVolumeValues);
		    }
		}
		#endregion

	    #region private void ReprocessZone(GZone Zone)
	    private void ReprocessZone(GZone Zone)
	    {
	        int barsinprogress = this.UseChartBars ? 0 : 2;
	        int startBarsAgo = CurrentBars[barsinprogress] - BarsArray[barsinprogress].GetBar(Zone.StartTime);
	        int endBarsAgo = 0;

	        Zone.State = GZ_FORMED;
	        Zone.NumRetests = 0;
	        if (Zone.Type == 1) Zone.TestMarker = Zone.Bottom;
	        else Zone.TestMarker = Zone.Top;
	        for (int ba = startBarsAgo; ba >= endBarsAgo; ba--)
	        {
	            double processPrice = (Zone.Type == GZ_SUPPLY) ? Highs[barsinprogress][ba] : Lows[barsinprogress][ba];
	            this.ProcessZone(Zone, processPrice, Highs[barsinprogress][ba], Times[barsinprogress][ba], CurrentBars[barsinprogress] - ba);
	            if (Zone.State == GZ_BROKEN)
	            {
	                if (ba == startBarsAgo)
	                {
	                    Zone.State = GZ_FORMED;
	                    Zone.NumRetests = 0;
	                    if (Zone.Type == 1) Zone.TestMarker = Zone.Bottom;
	                    else Zone.TestMarker = Zone.Top;
	                }
	                break;
	            }
	        }
	    }
	    #endregion

	    #region -- CreateZone() --
	    private bool CreateZone(int ZoneType, int BarsAgo, int ThrustABar, double ThrustOvershootAmount, double ZoneTop, double ZoneBottom)
	    {
	        // Build Histogram
	        GHistogram gH = new GHistogram(gbTickSize, 2, this.iPctOfVolumeInVA, ZoneType, iNumberOfLVN);

	        double baseHigh = double.MinValue;
	        double baseLow = double.MaxValue;
			int NumOfBasingCandles = 0;
		    for (int ba = BarsAgo; ba >= 0; ba--)
		    {
		        int bdx = (this.BarHists.Count - 1) - (ba + 1);
		        if (barType[ba] == CONSOLIDATION_BAR_ID)
		        {
					NumOfBasingCandles++;
		            gH.AddDataFromHistogram(this.BarHists[bdx].GetHistogram(), ZoneTop, ZoneBottom);
		            baseHigh = Math.Max(baseHigh, High[ba]);
		            baseLow = Math.Min(baseLow, Low[ba]);
		        }
		        else if (ZoneType == GZ_DEMAND && barType[ba] == THRUST_UPBAR_ID)
		        {
		            if (High[ba] <= baseHigh) gH.AddDataFromHistogram(this.BarHists[bdx].GetHistogram(), ZoneTop, ZoneBottom);
		            break;
		        }
		        else if (ZoneType == GZ_SUPPLY && barType[ba] == THRUST_DOWNBAR_ID)
		        {
		            if (Low[ba] >= baseLow) gH.AddDataFromHistogram(this.BarHists[bdx].GetHistogram(), ZoneTop, ZoneBottom);
		            break;
		        }
		    }
//if(IsDebug) Print("CreateZone  "+CurrentBars[0]);
		    GZone gZ = new GZone(0, ZoneType, Time[BarsAgo], Time[0], CurrentBar - BarsAgo, ThrustABar, ZoneTop, ZoneBottom, CurrentBar, false, CalculateAvgVAVol(), this.pMaxVolPctQualifier, NumOfBasingCandles, pMaxBasingCount, ThrustOvershootAmount>0, gH);

		    bool toggleState = false;
		    if (this.iShowAllDemandProfile && ZoneType == GZ_DEMAND) toggleState = true;
		    else if (this.iShowAllSupplyProfile && ZoneType == GZ_SUPPLY) toggleState = true;
		    else if (this.iShowAllProfile) toggleState = true;

		    if (toggleState == false)
		        gZ.SetProfileToggles(
		            toggleState,
		            toggleState,
		            toggleState,
		            toggleState,
		            (int)this.iProfileExpansion,
		            toggleState,
		            toggleState,
		            toggleState,
		            toggleState);
		    else
		        gZ.SetProfileToggles(
		            this.iShowProfile,
		            this.iShowPOC,
		            this.iShowVAL,
		            this.iShowVAH,
		            (int)this.iProfileExpansion,
		            this.iShowVolumeCluster,
		            this.iShowVolumeRatio,
		            this.iShowDeltaFactor,
		            this.iShowVolumeValues);

		    if (!IsDuplicateZone(gZ))
		    {
//if(IsDebug) Print("Adding zone to GZS");
		        this.GZS.Add(gZ);
				GZS.Last().IDnum = GZS.Count-1;
		        return true;
		    }else{
//if(IsDebug) Print("NOT adding zone to GZS");
			}
		    return false;
		}
		#endregion

	    #region private void SetProfileToggles(bool PR, bool PC, bool VL, bool VH, int VPi, bool VC, bool PT, bool DF, bool VV)
	    private void SetProfileToggles(bool PR, bool PC, bool VL, bool VH, int VPi, bool VC, bool PT, bool DF, bool VV)
	    {
	        for (int g = 0; g < this.GZS.Count; g++)
	        {
	            GZS[g].SetProfileToggles(PR, PC, VL, VH, VPi, VC, PT, DF, VV);
	        }
	    }
	    #endregion

	    #region private void SetProfileToggles(int Type, int State, bool PR, bool PC, bool VL, bool VH, int VPi, bool VC, bool PT, bool DF, bool VV)
	    private void SetProfileToggles(int Type, int State, bool PR, bool PC, bool VL, bool VH, int VPi, bool VC, bool PT, bool DF, bool VV)
	    {
	        for (int g = 0; g < this.GZS.Count; g++)
	        {
	            if (Type == GZ_DEMANDSUPPLY || Type == GZS[g].Type || State == GZS[g].State || (State == GZ_TESTED && GZS[g].State == GZ_RETEST))
	            {
	                GZS[g].SetProfileToggles(PR, PC, VL, VH, VPi, VC, PT, DF, VV);
	            }
	        }
	    }
	    #endregion

	    #region private void CheckForCurveInZone()
	    private void CheckForCurveInZone()
	    {
	        for (int g = 0; g < this.GZS.Count; g++)
	        {
	            // Do not monitor zones that are already broken
	            if (GZS[g].State == GZ_BROKEN) continue;

	            // Supply
	            if (GZS[g].Type == GZ_SUPPLY)
	            {
	                double price = Close[0];
	                double tempDistance = GZS[g].Bottom - price;
	                if ((CurveHighZ[0] >= GZS[g].Bottom) && (CurveHighZ[0] <= GZS[g].Top)) CurveHighZ[0] = Math.Max(CurveHighZ[0], GZS[g].Top);
	            }

	            // Demand
	            if (GZS[g].Type == GZ_DEMAND)
	            {
	                double price = Close[0];
	                double tempDistance = price - GZS[g].Top;
	                if ((CurveLowZ[0] >= GZS[g].Bottom) && (CurveLowZ[0] <= GZS[g].Top)) CurveLowZ[0] = Math.Min(CurveLowZ[0], GZS[g].Bottom);
	            }
	        }
	    }
	    #endregion

	    #region private bool IsZoneWithinAnActiveZone(GZone Zone)
	    private bool IsZoneWithinAnActiveZone(GZone Zone)
	    {
	        for (int g = 0; g < this.GZS.Count; g++)
	        {
	            if (GZS[g].State == GZ_BROKEN) continue;
	            if ((Zone.Type != GZS[g].Type) && (Zone.StartTime.CompareTo(GZS[g].StartTime) > 0) && ((Zone.Top <= GZS[g].Top && Zone.Bottom >= GZS[g].Bottom))) return true;
	            else if ((Zone.Type == GZS[g].Type) && (Zone.StartTime.CompareTo(GZS[g].StartTime) > 0) && ((Zone.Top <= GZS[g].Top && Zone.Bottom >= GZS[g].Bottom))) return true;
	        }
	        return false;
	    }
	    #endregion

	    #region private bool IsDuplicateZone(GZone Zone)
	    private bool IsDuplicateZone(GZone Zone)
	    {
	        for (int g = 0; g < this.GZS.Count; g++) if (Zone.ID == GZS[g].ID) return true;
	        return false;
	    }
	    #endregion

	    #endregion

		#region -- Drawing Functions Utilities --

        #region private string GetText(double TFPercent, double TFPrice)
        private string GetText(double TFPercent, double TFPrice)
        {
            string fibst = string.Empty;
            if (pDisplayPercent) fibst = TFPercent.ToString() + "%";
            if (fibst != string.Empty && pDisplayPrice) fibst = fibst + "  ";
            if (pDisplayPrice) fibst = fibst + FormatPriceMarker(TFPrice);
            return fibst;
        }
        #endregion

        #region -- Curve Management --

        #region private void DrawFibZone(ChartScale chartScale, bool Active, double Percent1, double Percent2, Brush iColor, int pWidth1, DashStyleHelper pDash, int pOpacity1, string NameZ)
        private void DrawFibZone(ChartScale chartScale, bool Active, double Percent1, double Percent2, SharpDX.Direct2D1.Brush iDXBrush, int pWidth1, DashStyleHelper pDash, int opacity, string NameZ)
        {
            if (Active)
            {
                double TFPrice = Price0P + (Price100P - Price0P) * Percent1 / 100;
                double TFPrice2 = Price0P + (Price100P - Price0P) * Percent2 / 100;
                double TFPercent = Percent1;

                y5 = chartScale.GetYByValue(TFPrice);
                y6 = chartScale.GetYByValue(TFPrice2);
                y7 = Math.Min(y5, y6);
                y8 = Math.Max(y5, y6);

                if (!IsInHitTest) drawRegion(new Point[] { new Point(x1, y7), new Point(x2, y7), new Point(x2, y8), new Point(x1, y8) }, iDXBrush, opacity);
                if (pDisplayText && !IsInHitTest) drawString(NameZ, new Rect(x1, y7, Math.Max(0, x2 - x1), y8 - y7), pTextFont3, pLineColor1);
            }
        }
        #endregion

        #region private void DrawFib(bool Active, double Percent, Brush iColor, int pWidth1, DashStyleHelper pDash, int pOpacity1, string ss)
        private void DrawFib(ChartScale chartScale, bool Active, double Percent, Brush iColor, SharpDX.Direct2D1.Brush iDXBrush, int pWidth1, DashStyleHelper pDash, int opacity)
        {
            if (Active)
            {
                double TFPrice = Price0P + (Price100P - Price0P) * Percent / 100;
                double TFPercent = Percent;

                if (!AllLevels.ContainsKey(TFPrice))
                {
                    AllLevels.Add(TFPrice, 1);
                    y5 = chartScale.GetYByValue(TFPrice);                    
                    if (!IsInHitTest) drawLine(x1, x2, y5, y5, iDXBrush, pDash, pWidth1, opacity);
                    
                    string fibst = GetText(TFPercent, TFPrice);
                    if (pDisplayPercent || pDisplayPrice)
                    {
                        float fibsz = getTextWidth(fibst, pTextFont3);
                        x5 = x2 - (int)fibsz - 4;
                        if (!IsInHitTest) drawString(fibst, x5, y5 - 2 - pTextFont3.Size, pTextFont3, iColor, SharpDX.DirectWrite.TextAlignment.Center );
                    }
                }                
            }
        }
        #endregion

        #region private void DrawCurve(ChartControl chartControl, ChartScale chartScale, double HighPrice, double LowPrice, int LeftBar, int RightBar, bool ShowButtons)
        private void DrawCurve(ChartControl chartControl, ChartScale chartScale, double HighPrice, double LowPrice, int LeftBar, int RightBar, bool ShowButtons)
        {
            #region -- calculate coordinates --
            x1 = ChartControl.GetXByBarIndex(chartControl.BarsArray[0], LeftBar) + (int)ChartControl.BarWidth + pXOffset;
            x2 = RightBar == 0 ? x8 : ChartControl.GetXByBarIndex(chartControl.BarsArray[0], RightBar);

            //Limit the Curve width to 2 times max string width
            int fibsz = (int)getTextWidth("Deep Retail", pTextFont3);
            if (x2 - x1 > 2 * fibsz) x1 = x2 - 2 * fibsz;

            Price100P = HighPrice;
            Price0P = LowPrice;
            y1 = chartScale.GetYByValue(Price100P);
            y2 = chartScale.GetYByValue(Price0P);
            #endregion

            AllLevels.Clear();

            #region -- draw curve zone + frame + values --

            //zones must be first, then lines then frame
            DrawFibZone(chartScale, true, pPercent1, pPercent2, iCurveAreaDXBrush1, pWidth1, pDashStyle1, iCurveOpacity1, "Deep Value");
            DrawFibZone(chartScale, true, pPercent2, pPercent3, iCurveAreaDXBrush2, pWidth1, pDashStyle1, iCurveOpacity2, "Value");
            DrawFibZone(chartScale, true, pPercent3, pPercent4, iCurveAreaDXBrush3, pWidth1, pDashStyle1, iCurveOpacity3, "Retail");
            DrawFibZone(chartScale, true, pPercent4, pPercent5, iCurveAreaDXBrush4, pWidth1, pDashStyle1, iCurveOpacity4, "Deep Retail");

            DrawFib(chartScale, true, pPercent1, pLineColor1, pLineDXBrush1, pWidth1, pDashStyle1, iOpacity1);
            DrawFib(chartScale, true, pPercent2, pLineColor1, pLineDXBrush1, pWidth1, pDashStyle1, iOpacity1);
            DrawFib(chartScale, true, pPercent3, pLineColor1, pLineDXBrush1, pWidth1, pDashStyle1, iOpacity1);
            DrawFib(chartScale, true, pPercent4, pLineColor1, pLineDXBrush1, pWidth1, pDashStyle1, iOpacity1);
            DrawFib(chartScale, true, pPercent5, pLineColor1, pLineDXBrush1, pWidth1, pDashStyle1, iOpacity1);
                        
            Point[] DrawCurve = new Point[] { new Point(x1, y1), new Point(x2, y1), new Point(x2, y2), new Point(x1, y2) };//(x1, y1, x2 - x1 + 4, y2 - y1);
            if (!IsInHitTest) drawRectangle(DrawCurve, pLineDXBrush1, pDashStyle1, pWidth1);//PenCurveOutline);
            
            #endregion

            #region -- Curve Buttons --
            Rect HoverCurve = new Rect(x1 - 6, y1 - 6, x2 - x1 + 4 + 12, y2 - y1 + 12);
            if (MM.X >= HoverCurve.Left && MM.X <= HoverCurve.Right && MM.Y >= HoverCurve.Top && MM.Y <= HoverCurve.Bottom)
            {
                y5 = chartScale.GetYByValue(Price0P) - pButtonSize;
                B1 = new Rect((int)x1 + 9, (int)y5 - 9, pButtonSize, pButtonSize);

                #region -- Z button --
                if (!IsInHitTest)
                {
                    drawRegion(B1, pIncludeZone ? DXBrushes_LightGreen : DXBrushes_LightGray);
                    drawRectangle(B1, DXBrushes_Black, DashStyleHelper.Solid, 1);
                    float txtZwidth = getTextWidth("Z", ChartControl.Properties.LabelFont);
                    drawString("Z", B1, ChartControl.Properties.LabelFont, Brushes.Black);
                }
                #endregion

                #region -- HighLight --
                if (!IsInHitTest)
                {
					if(RectHighlightDXBrush==null){
						RectHighlightDXBrush = Brushes.Black.ToDxBrush(RenderTarget);
            			RectHighlightDXBrush.Opacity = 0.70f;
					}
                    if (MM.X >= B1.Left && MM.X <= B1.Right && MM.Y >= B1.Top && MM.Y <= B1.Bottom)
                        drawRectangle(x1 + 9, y5 - 9, pButtonSize, pButtonSize, RectHighlightDXBrush, DashStyleHelper.Solid, 2);

                    drawRectangle(DrawCurve, RectHighlightDXBrush, DashStyleHelper.Solid, pWidth1 + 2);
                }
                #endregion
            
            }
            #endregion
        }
        #endregion

        #endregion

        #region -- Low level drawing functions { AzurITec } --
		
		#region DrawRectangle
        //Draw Rectangle. Rect as pixel coordinate
        private void drawRectangle(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
        {
            drawRectangle(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, dxbrush, dashstyle, width);
        }
        //Draw Rectangle. x and y as pixel coordinate, w and h in pixel too.
        private void drawRectangle(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
        {
            drawRectangle(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush, dashstyle, width);
        }
        //Draw Rectangle. points are in pixel coordinate.
        private void drawRectangle(Point[] points, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
        {
            drawLine(points[0].X, points[1].X, points[0].Y, points[1].Y, dxbrush, dashstyle, width);
            drawLine(points[1].X, points[2].X, points[1].Y, points[2].Y, dxbrush, dashstyle, width);
            drawLine(points[2].X, points[3].X, points[2].Y, points[3].Y, dxbrush, dashstyle, width);
            drawLine(points[3].X, points[0].X, points[3].Y, points[0].Y, dxbrush, dashstyle, width);
        }
		#endregion
        //Draw Region. Rect in pixel coordinate.
        private void drawRegion(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush, int opacity = -100)
        {
            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, dxbrush, opacity);
        }
        //Draw Region. x and y as pixel coordinate, w and h in pixel too.
        private void drawRegion(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush, int opacity = -100)
        {
            drawRegion(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush, opacity);
        }
        //Draw Region between 4 points. Coordinates are in pixel.
        private void drawRegion(Point[] points, SharpDX.Direct2D1.Brush dxbrush, int opacity = -100)
        {
            //SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            if(opacity>=0) dxbrush.Opacity = opacity / 100f;

            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();
            //linebrush.Dispose();
        }        
        //Draw Region between 4 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawRegion(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false, int opacity = 100)
        {
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl), (drawOnPricePanel?0:ChartPanel.Y) + chartScale.GetYByValueWpf(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl), (drawOnPricePanel?0:ChartPanel.Y) + chartScale.GetYByValueWpf(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl), (drawOnPricePanel?0:ChartPanel.Y) + chartScale.GetYByValueWpf(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl), (drawOnPricePanel?0:ChartPanel.Y) + chartScale.GetYByValueWpf(yValues[3]))
                },
                dxbrush,
                opacity
                );
        }
//drawLine(price_array[3], price_array[2], abars_array[0], abars_array[1], iVA2_lineDXBrush, iVAS3DashStyle, iVAS3Width, chartControl, chartScale);

        //Draw a line between 2 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawLine(double val1, double val2, int idxslot1, int idxslot2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false)
        {
			#region
            //SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            Point p0 = new Point(GetX0(idxslot1, chartControl), (drawOnPricePanel ? 0 : ChartPanel.Y) + chartScale.GetYByValue(val1));
            Point p1 = new Point(GetX0(idxslot2, chartControl), (drawOnPricePanel ? 0 : ChartPanel.Y) + chartScale.GetYByValue(val2));
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), dxbrush, width, strokestyle);

            //linebrush.Dispose();
            strokestyle.Dispose();
			#endregion
        }
        //Draw a line between 2 points in pixel coordinates.        
        private void drawLine(double x1, double x2, double y1, double y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, int opacity = 100)
        {
			#region
            //SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
            dxbrush.Opacity = opacity / 100f;
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            Point p0 = new Point(x1, y1);
            Point p1 = new Point(x2, y2);
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), dxbrush, width, strokestyle);

            //linebrush.Dispose();
            strokestyle.Dispose();
			#endregion
        }
        //Draw a line between 2 points. 'x1' and 'x2' are pixel locations, the y value is the numerical value (ie price / oscillator value)
		private void drawLine(double val1, double val2, float x1, float x2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = true)
		{
			#region
			if(double.IsNaN(val1) || double.IsNaN(val2)) {Print("Val is NaN"); return;}
			//SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.DashStyle _dashstyle;
			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

			SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
			SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

			SharpDX.Vector2 v1 = new SharpDX.Vector2(x1, drawOnPricePanel ? chartScale.GetYByValue(val1) : ChartPanel.Y + (float)chartScale.GetYByValue(val1));
			SharpDX.Vector2 v2 = new SharpDX.Vector2(x2, drawOnPricePanel ? chartScale.GetYByValue(val2) : ChartPanel.Y + (float)chartScale.GetYByValue(val2));
//Print("\nv1: "+v1.X+", "+v1.Y+"   "+val1);
//Print("v2: "+v2.X+", "+v2.Y+"   "+val2);
			RenderTarget.DrawLine(v1, v2, dxbrush, width, strokestyle);

			strokestyle.Dispose();
			#endregion
		}
        //Draw a text at {x;y} coordinates in pixel.
        private void drawString(string text, double x, double y, SimpleFont font, Brush textBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
			#region
            SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                ) { TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textBrush.ToDxBrush(RenderTarget), SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
			#endregion
        }
        //Draw a text at center of Rect (coordinates in pixel).
        private void drawString(string text, Rect rect, SimpleFont font, Brush textBrush, float width = 0f)
        {
			#region
            double x = rect.X;
            double y = rect.Y + (rect.Height - font.Size) / 2;

            SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                ) { TextAlignment = SharpDX.DirectWrite.TextAlignment.Center, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, (float)rect.Width, float.MaxValue);

            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textBrush.ToDxBrush(RenderTarget), SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
			#endregion
        }

        //retrieve the x coordinate in pixel of a a relative bar index.
        private int GetX0(int bars, ChartControl chartControl) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars); }//NEW VERSION NT8

        private float getTextWidth(string text, SimpleFont font)
        {
			#region
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
			#endregion
        }
        private float getTextHeight(string text, SimpleFont font)
        {
			#region
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textheight = textLayout.Metrics.Height;

            textLayout.Dispose();
            textFormat.Dispose();

            return textheight;
			#endregion
        }
        #endregion

        #endregion

        #region -- Misc Utilities --

        #region public double GetZoneProperty(int Type, int State, int Property, int Instance)
        // PROPERTIES : TOP = 0 / BOTTOM = 1 / VAH = 2 / POC = 3 / VAL = 4 / VCT = 5 / VCB = 6
        // STATE : FRESH = 0 / TESTED = 1
        // TYPE :  DEMAND = 0 / SUPPLY = 1
        public double GetZoneProperty(int Type, int State, int Property, int Instance)
        {
            int instance = 0;
            for (int g = this.GZS.Count - 1; g >= 0; g--)
            {
                if ((Type == 0 && GZS[g].Type == GZ_DEMAND && State == 0 && (GZS[g].State == GZ_FORMED || GZS[g].State == GZ_FRESH)) ||
                    (Type == 1 && GZS[g].Type == GZ_SUPPLY && State == 0 && (GZS[g].State == GZ_FORMED || GZS[g].State == GZ_FRESH)) ||
                    (Type == 0 && GZS[g].Type == GZ_DEMAND && State == 1 && (GZS[g].State == GZ_RETEST || GZS[g].State == GZ_TESTED)) ||
                    (Type == 1 && GZS[g].Type == GZ_SUPPLY && State == 1 && (GZS[g].State == GZ_RETEST || GZS[g].State == GZ_TESTED)))
                {
                    instance++;
                    if (instance == Instance)
                    {
                        if (Property == 0) return GZS[g].Top;
                        else if (Property == 1) return GZS[g].Bottom;
                        else if (Property == 2 && GZS[g].Hist.GetTotalBins() > 0 && GZS[g].Hist.GetTotal(GZS[g].Hist.POC) > 0) return GZS[g].Hist.VAH;
                        else if (Property == 3 && GZS[g].Hist.GetTotalBins() > 0 && GZS[g].Hist.GetTotal(GZS[g].Hist.POC) > 0) return GZS[g].Hist.POC;
                        else if (Property == 4 && GZS[g].Hist.GetTotalBins() > 0 && GZS[g].Hist.GetTotal(GZS[g].Hist.POC) > 0) return GZS[g].Hist.VAL;
                        else if (Property == 5 && GZS[g].Hist.GetTotalBins() > 2 && GZS[g].Hist.VolumeClusterTop != double.MinValue) return GZS[g].Hist.VolumeClusterTop;
                        else if (Property == 6 && GZS[g].Hist.GetTotalBins() > 2 && GZS[g].Hist.VolumeClusterBottom != double.MinValue) return GZS[g].Hist.VolumeClusterBottom;
                        else return -1.0;
                    }
                }
            }

            return -1.0;
        }
        #endregion

		private double CalculateAvgVAVol(){
	        #region CalculateAvgVAVol()
			double sums = 0;
			foreach(var g in GZS)
            {
				if(g.TotVolVA == 0){
    	            if (g.Hist.GetTotalBins() > 0 && g.Hist.GetTotal(g.Hist.POC) > 0)
        	        {
            	        long sum = 0;
                	    for (double p = g.Hist.VAL; p <= g.Hist.VAH; p = Instruments[0].MasterInstrument.RoundToTickSize(p + gbTickSize))
                        	sum += g.Hist.GetTotal(p);
    	                sums += sum;
						g.TotVolVA = sum;
					}
				}else{
					sums += g.TotVolVA;
                }
			}
			#endregion
			return sums/Math.Max(1,GZS.Count);
		}
        private double[] CalculateAvgVols()
        {
	        #region CalculateAvgVols()
            double[] sums = new double[3];
            double[] avgs = new double[3];
            double[] tots = new double[3];

            if (this.GZS.Count == 0) return avgs;

            for (int s = 0; s < 3; s++)
            {
                sums[s] = 0.0;
                avgs[s] = 0.0;
                tots[s] = 0.0;
            }

//          for (int g = 0; g < this.GZS.Count; g++)
			foreach(var g in GZS)
            {
                if (g.Hist.GetTotalBins() > 0 && g.Hist.GetTotal(g.Hist.POC) > 0)
                {
                    sums[0] += g.Hist.GetTotal(g.Hist.POC);
                    tots[0]++;
                }

				if(g.TotVolVA == 0){
	                if (g.Hist.GetTotalBins() > 0 && g.Hist.GetTotal(g.Hist.POC) > 0)
	                {
	                    long sum = 0;
	                    for (double p = g.Hist.VAL; p <= g.Hist.VAH; p = Instruments[0].MasterInstrument.RoundToTickSize(p + gbTickSize))
	                        sum += g.Hist.GetTotal(p);

	                    sums[1] += sum;
						g.TotVolVA = sum;
	                    tots[1]++;
	                }
				}else{
					sums[1] += g.TotVolVA;
                    tots[1]++;
				}

                if (g.Hist.GetTotalBins() > 2 && g.Hist.VolumeClusterTop != double.MinValue && g.Hist.VolumeClusterTop != double.MinValue)
                {
                    long sum = 0;
                    for (double p = g.Hist.VolumeClusterBottom; p <= g.Hist.VolumeClusterTop; p = Instruments[0].MasterInstrument.RoundToTickSize(p + gbTickSize))
                    {
                        sum += g.Hist.GetTotal(p);
                    }

                    sums[2] += sum;
                    tots[2]++;
                }
            }

            for (int s = 0; s < 3; s++) avgs[s] = sums[s] / tots[s];
            return avgs;
	        #endregion
        }

        #region private double[] CalculateAvgStops()
        private double[] CalculateAvgStops()
        {
            double[] sums = new double[4];
            double[] avgs = new double[4];
            double[] tots = new double[4];

            if (this.GZS.Count == 0) return avgs;

            for (int s = 0; s < 4; s++)
            {
                sums[s] = 0.0;
                avgs[s] = 0.0;
                tots[s] = 0.0;
            }

//          for (int g = 0; g < this.GZS.Count; g++)
			foreach(var g in GZS)
            {
                sums[0] += Instruments[0].MasterInstrument.RoundToTickSize((g.Top - g.Bottom) / gbTickSize) + (double)this.iTickBuffer;
                tots[0]++;

                if (g.Type == GZ_DEMAND)
                {
                    if (g.Hist.GetTotalBins() > 0 && g.Hist.GetTotal(g.Hist.POC) > 0)
                    {
                        sums[1] += Instruments[0].MasterInstrument.RoundToTickSize(Math.Abs(g.Hist.POC - g.Bottom) / gbTickSize) + (double)this.iTickBuffer;
                        tots[1]++;
                        if (g.Hist.VAH != 0.0)
                        {
                            sums[2] += Instruments[0].MasterInstrument.RoundToTickSize(Math.Abs(g.Hist.VAH - g.Bottom) / gbTickSize) + (double)this.iTickBuffer;
                            tots[2]++;
                        }
                    }

                    if (g.Hist.GetTotalBins() > 2 && g.Hist.VolumeClusterTop != double.MinValue && g.Hist.VolumeClusterTop != double.MinValue)
                    {
                        tots[3]++;
                        sums[3] += Instruments[0].MasterInstrument.RoundToTickSize(Math.Abs(g.Hist.VolumeClusterTop - g.Bottom) / gbTickSize) + (double)this.iTickBuffer;
                    }
                }
                else
                {
                    if (g.Hist.GetTotalBins() > 0 && g.Hist.GetTotal(g.Hist.POC) > 0)
                    {
                        sums[1] += Instruments[0].MasterInstrument.RoundToTickSize(Math.Abs(g.Top - g.Hist.POC) / gbTickSize) + (double)this.iTickBuffer;
                        tots[1]++;
                        if (g.Hist.VAL != 0.0)
                        {
                            sums[2] += Instruments[0].MasterInstrument.RoundToTickSize(Math.Abs(g.Top - g.Hist.VAL) / gbTickSize) + (double)this.iTickBuffer;
                            tots[2]++;
                        }
                    }

                    if (g.Hist.GetTotalBins() > 2 && g.Hist.VolumeClusterTop != double.MinValue && g.Hist.VolumeClusterTop != double.MinValue)
                    {
                        tots[3]++;
                        sums[3] += Instruments[0].MasterInstrument.RoundToTickSize(Math.Abs(g.Top - g.Hist.VolumeClusterBottom) / gbTickSize) + (double)this.iTickBuffer;
                    }
                }
            }

            for (int s = 0; s < 4; s++) avgs[s] = sums[s] / tots[s];
            return avgs;
        }
        #endregion

        private double RTTS(double r) { int t = (int)Math.Round(r/TickSize,0); return t*TickSize; }
        private double PriceFromY(int y) { return gChartScale.GetValueByY(y); }
        private int BarsAgoFromX(int x) { return (int)ChartControl.GetSlotIndexByX(x); }

        #region private void CalculateValueArea(int lookback, int barsAgo, out double upperBand, out double lowerBand)
        private void CalculateValueArea(int lookback, int barsAgo, out double upperBand, out double lowerBand)  // changed v13
        {
            lookback += lookback == 1 ? 1 : 0;//##ADDED##
            
            //section moving median VWTPO
            if (IsFirstTickOfBar)
            {
                high = MAX(High, lookback - 1)[1 + barsAgo];
                low = MIN(Low, lookback - 1)[1 + barsAgo];
                preVolume = 0;
                fieldSize = 1 + Convert.ToInt32((high - low) / gbTickSize);
                fList = new List<double>();
                for (int i = 0; i < fieldSize; i++)
                    fList.Add(0.0);
                for (int j = 1 + barsAgo; j < lookback + barsAgo; j++)
                {
                    lowIndex = Convert.ToInt32((Low[j] - low) / gbTickSize);
                    highIndex = Convert.ToInt32((High[j] - low) / gbTickSize);
                    bodyLowIndex = Convert.ToInt32((bodyLow[j] - low) / gbTickSize);
                    bodyHighIndex = Convert.ToInt32((bodyHigh[j] - low) / gbTickSize);
                    preVolume += Volume[j];
                    slice = Volume[j] / (2 + highIndex - lowIndex + bodyHighIndex - bodyLowIndex);
                    if (lowIndex >= 0 && highIndex >= 0)
                    {
                        for (int k = lowIndex; k <= highIndex; k++)
                            fList[k] = fList[k] + slice;
                        for (int k = bodyLowIndex; k <= bodyHighIndex; k++)
                            fList[k] = fList[k] + slice;
                    }
                }
            }

            if (Low[barsAgo] < low)
            {
                int newLowFields = Convert.ToInt32((low - Low[barsAgo]) / gbTickSize);
                for (int i = 0; i < newLowFields; i++)
                    fList.Insert(0, 0.0);
                low = Low[barsAgo];
                fieldSize += newLowFields;
            }
            if (High[barsAgo] > high)
            {
                int newHighFields = Convert.ToInt32((High[barsAgo] - high) / gbTickSize);
                for (int i = 0; i < newHighFields; i++)
                    fList.Add(0.0);
                high = High[barsAgo];
                fieldSize += newHighFields;
            }

            volume = preVolume + Volume[barsAgo];
            lowIndex = Convert.ToInt32(((Low[barsAgo] - low) / gbTickSize));
            highIndex = Convert.ToInt32((High[barsAgo] - low) / gbTickSize);
            bodyLowIndex = Convert.ToInt32((bodyLow[barsAgo] - low) / gbTickSize);
            bodyHighIndex = Convert.ToInt32((bodyHigh[barsAgo] - low) / gbTickSize);
            slice = Volume[barsAgo] / (2 + highIndex - lowIndex + bodyHighIndex - bodyLowIndex);
            sum = 0.0;
            plotCount = 1;
            upperBand = Close[barsAgo];
            lowerBand = Close[barsAgo];
            for (int i = 0; i < fieldSize; i++)
            {
                price = low + i * gbTickSize;
                if (i < lowIndex || i > highIndex)
                    sum += fList[i];
                else if (i < bodyLowIndex || i > bodyHighIndex)
                    sum += fList[i] + slice;
                else
                    sum += fList[i] + 2 * slice;
                if (plotCount == 1 && 10 * sum > 3 * volume)
                {
                    lowerBand = price;
                    plotCount = 2;
                }
                else if (plotCount == 2 && 10 * sum >= 7 * volume)
                {
                    upperBand = price;
                    plotCount = 0;
                    break;
                }
            }
            if (plotCount > 0)
            {
                if (price > lowerBand)
                    upperBand = lowerBand + gbTickSize;
                else
                    upperBand = lowerBand;
            }
            return;
        }
        #endregion

        #region private void InitializeManualCurve()
        private void InitializeManualCurve()
        {
            ClickedBar1 = (int)CurveBar[BB2];
            ClickedPrice1 = CurveHighF[BB2];

            ClickedBar2 = (int)CurveBar[BB2];
            ClickedPrice2 = CurveLowF[BB2];

        }
        #endregion

        #region -- SetPaintStyle --
        private void SetPaintStyle(int ZoneType, int ObjectType)
        {
            if (ObjectType == GZ_HOVER)
            {
                this.tempPen_DXBrush   = DXBrushes_Black;
				this.tempPen.Brush     = Brushes.Black;
                this.tempPen.Thickness = 3.0;
                this.tempBrush         = DXBrushes_LightGray;
            }
            else if (ObjectType == GZ_CONTROL_ACTIVE)
            {
                this.tempPen_DXBrush   = DXBrushes_Black;
				this.tempPen.Brush     = Brushes.Black;
                this.tempPen.Thickness = 1.0;
                this.tempBrush         = DXBrushes_LightGreen;
            }
            else if (ObjectType == GZ_CONTROL)
            {
                this.tempPen_DXBrush   = DXBrushes_Black;
				this.tempPen.Brush     = Brushes.Black;
                this.tempPen.Thickness = 1.0;
                this.tempBrush         = DXBrushes_LightGray;
            }
            else if (ObjectType == GZ_LABEL) {
				if(iTextDXBrush==null) iTextDXBrush = iTextColor.ToDxBrush(RenderTarget);
				this.tempBrush = this.iTextDXBrush;
			}
            else if (ObjectType == GZ_FORMED || ObjectType == GZ_FRESH)
            {
                this.tempPen_DXBrush   = (ZoneType == GZ_SUPPLY ? this.iFreshSupplyZoneOutlineDXBrush : this.iFreshDemandZoneOutlineDXBrush);
                this.tempPen.Brush     = (ZoneType == GZ_SUPPLY ? this.iFreshSupplyZoneOutlineColor : this.iFreshDemandZoneOutlineColor);
                this.tempPenDashStyle  = (ZoneType == GZ_SUPPLY ? this.iFreshSupplyZoneOutlineStyle : this.iFreshDemandZoneOutlineStyle);
                this.tempPen.Thickness = 1.0f;
                tempBrush         = ZoneType == GZ_SUPPLY ? this.iFreshSupplyZoneDXBrush : this.iFreshDemandZoneDXBrush;
				tempBrush.Opacity = (ZoneType == GZ_SUPPLY ? this.iFreshSupplyZoneOpacity : this.iFreshDemandZoneOpacity) / 100f;
            }
            else if (ObjectType == GZ_RETEST || ObjectType == GZ_TESTED || ObjectType == GZ_HIDDEN)
            {
                this.tempPen_DXBrush   = (ZoneType == GZ_SUPPLY ? this.iTestedSupplyZoneOutlineDXBrush : this.iTestedDemandZoneOutlineDXBrush);
                this.tempPen.Brush     = (ZoneType == GZ_SUPPLY ? this.iTestedSupplyZoneOutlineColor : this.iTestedDemandZoneOutlineColor);
                this.tempPenDashStyle  = (ZoneType == GZ_SUPPLY ? this.iTestedSupplyZoneOutlineStyle : this.iTestedDemandZoneOutlineStyle);
                this.tempPen.Thickness = 1.0;

                tempBrush         = ZoneType == GZ_SUPPLY ? this.iTestedSupplyZoneDXBrush : this.iTestedDemandZoneDXBrush;
				tempBrush.Opacity = (ZoneType == GZ_SUPPLY ? this.iTestedSupplyZoneOpacity : this.iTestedDemandZoneOpacity) / 100f;
            }
            else if (ObjectType == GZ_BROKEN)
            {
                this.tempPen_DXBrush   = (ZoneType == GZ_SUPPLY ? this.iBrokenSupplyZoneOutlineDXBrush : this.iBrokenDemandZoneOutlineDXBrush);
                this.tempPen.Brush     = (ZoneType == GZ_SUPPLY ? this.iBrokenSupplyZoneOutlineColor : this.iBrokenDemandZoneOutlineColor);
                this.tempPenDashStyle  = (ZoneType == GZ_SUPPLY ? this.iBrokenSupplyZoneOutlineStyle : this.iBrokenDemandZoneOutlineStyle);
                this.tempPen.Thickness = 1.0;
                tempBrush         = ZoneType == GZ_SUPPLY ? this.iBrokenSupplyZoneDXBrush : this.iBrokenDemandZoneDXBrush;
				tempBrush.Opacity = (ZoneType == GZ_SUPPLY ? this.iBrokenSupplyZoneOpacity : this.iBrokenDemandZoneOpacity) / 100f;
            }
        }        
        #endregion

        #endregion

        //------------------------------- Properties ------------------------------------------
        #region -- DataSeries --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ExtrnSupplyBottom { get { Update(); return sExtrnSupplyBottom; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ExtrnSupplyTop { get { Update(); return sExtrnSupplyTop; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ExtrnDemandBottom { get { Update(); return sExtrnDemandBottom; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ExtrnDemandTop { get { Update(); return sExtrnDemandTop; } }
        
        
        #region -- Curve --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Curve1 { get { return vCurve1; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Curve2 { get { return vCurve2; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Curve3 { get { return vCurve3; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Curve4 { get { return vCurve4; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Curve5 { get { return vCurve5; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> CurveStatus { get { return vCurveStatus; } }
        #endregion

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BarType { get { return barTypeDefault; } }

        #region -- Signal --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongSignal { get { return longSignalDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongPOCSignal { get { return longPOCSignalDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongVCSignal { get { return longVCSignalDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongVASignal { get { return longVASignalDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortSignal { get { return shortSignalDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortPOCSignal { get { return shortPOCSignalDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortVCSignal { get { return shortVCSignalDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortVASignal { get { return shortVASignalDefault; } }
        #endregion 

        #region -- Signals --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongSignals { get { return longSignalsDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongPOCSignals { get { return longPOCSignalsDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongVCSignals { get { return longVCSignalsDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongVASignals { get { return longVASignalsDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortSignals { get { return shortSignalsDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortPOCSignals { get { return shortPOCSignalsDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortVCSignals { get { return shortVCSignalsDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortVASignals { get { return shortVASignalsDefault; } }
        #endregion 

        #region -- SignalAll --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongSignalAll { get { return longSignalAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongPOCSignalAll { get { return longPOCSignalAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongVCSignalAll { get { return longVCSignalAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongVASignalAll { get { return longVASignalAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortSignalAll { get { return shortSignalAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortPOCSignalAll { get { return shortPOCSignalAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortVCSignalAll { get { return shortVCSignalAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortVASignalAll { get { return shortVASignalAllDefault; } }
        #endregion 

        #region -- SignalsAll --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongSignalsAll { get { return longSignalsAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongPOCSignalsAll { get { return longPOCSignalsAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongVCSignalsAll { get { return longVCSignalsAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> LongVASignalsAll { get { return longVASignalsAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortSignalsAll { get { return shortSignalsAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortPOCSignalsAll { get { return shortPOCSignalsAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortVCSignalsAll { get { return shortVCSignalsAllDefault; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ShortVASignalsAll { get { return shortVASignalsAllDefault; } }
        #endregion 

        #region -- ZigZag --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ZigZag { get { return vZigZag; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ZigZagHigh { get { return vZigZagHigh; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ZigZagLow { get { return vZigZagLow; } }
        #endregion

        #endregion

        #region -- Parameters -- 

        #region -- 00. TimeFrame Parameters --
        [NinjaScriptProperty]
        [Display(Name = "Mode", GroupName = "TimeFrame Parameters", Description = "", Order = 0)]
        public ARC_SDVSystem_ZoneMode2 iChartMode1 { get; set; }

        [NinjaScriptProperty]
        [Range(-1, int.MaxValue)]
        [Display(Name = "Bkg Bars To Process", GroupName = "TimeFrame Parameters", Description = "Smaller number means faster load time, larger number means more historical data processed, set to -1 to turn-off this limiter", Order = 1)]
        public int Bars_To_Process { get; set; }

		[NinjaScriptProperty]
        [Display(Name = "MTF BarType", GroupName = "TimeFrame Parameters", Description = "", Order = 2)]
        public ARC_SDVSystem_MTFBarType iChartType1 { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "MTF Value", GroupName = "TimeFrame Parameters", Description = "", Order = 3)]
        public int iChartValue1 { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Profile Calculation", GroupName = "TimeFrame Parameters", Description = "If TICK is selected, please be aware of how much data you are loading on the chart. If it is a large amount of data, then your CPU may be heavily taxed upon loading the indicator.\nIf MINUTE or SECOND are selected, Delta Factor and Volume Ratio are not available.", Order = 4)]
        public ARC_SDVSystem_ProfileDataType iProfileCalcTimeFrame { get; set; }
        #endregion

        #region -- 01. Parameters --
        [NinjaScriptProperty]
        [Display(Name = "Apply Range Filter", GroupName = "Parameters", Description = "Apply range filter to thrust bars", Order = 0)]
        public bool applyRangeFilter { get; set; }

        [NinjaScriptProperty]
        [Range(100, int.MaxValue)]
        [Display(Name = "Size Limitation S/D Zones % of ATR", GroupName = "Parameters", Description = "The range size of the support and demand zones can be limited as a multiple of the average size of the candle bodies", Order = 1)]
        public int barFilter { get; set; }

        [NinjaScriptProperty]
        [Range(0, int.MaxValue)]
        [Display(Name = "Avg Stop Loss Tick Buffer", GroupName = "Parameters", Description = "", Order = 2)]
        public int iTickBuffer { get; set; }
		
		[Description("Button text - enter how you want the UI button to be labeled")]
		[Display(Order = 10, Name = "Button Txt",  GroupName = "Parameters", ResourceType = typeof(Custom.Resource))]
		public string pButtonText {get;set;}
        #endregion

        #region -- 02. Parameters Market Structure --
        [Display(Name = "Show Market Structure", GroupName = "Parameters Market Structure", Description = "Show swings to identify the current market structure", Order = 0)]
        public bool showZigZag { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Swing Strength", GroupName = "Parameters Market Structure", Description = "Number of bars used to identify a swing high or low", Order = 1)]
        public int swingStrength { get; set; }

        [NinjaScriptProperty]
        [Range(0, int.MaxValue)]
        [Display(Name = "Sensitivity Double Tops/Bottoms", GroupName = "Parameters Market Structure", Description = "Percentage of ATR ignored when detecting double tops or bottoms", Order = 2)]
        public int percentATR { get; set; }

        [Display(Name = "Text Font", GroupName = "Parameters Market Structure", Description = "Choose your font style market structure text.", Order = 3)]
        public SimpleFont mstTextFont { get; set; }
        #endregion

        #region -- 05. Visual Toggles --
        [Display(Name = "Show SDV Zones", GroupName = "Visual Toggles", Description = "", Order = 0)]
        public bool iShowSDVZones { get; set; }

        [Display(Name = "Show Supply Zones", GroupName = "Visual Toggles", Description = "", Order = 10)]
        public bool iShowSupplyZones { get; set; }

        [Display(Name = "Show Demand Zones", GroupName = "Visual Toggles", Description = "", Order = 20)]
        public bool iShowDemandZones { get; set; }

        [Display(Name = "Show Fresh Zones", GroupName = "Visual Toggles", Description = "", Order = 30)]
        public bool iShowFreshZones { get; set; }

        [Display(Name = "Show Tested Zones", GroupName = "Visual Toggles", Description = "", Order = 40)]
        public bool iShowTestedZones { get; set; }

        [Display(Name = "Show Tested Shading", GroupName = "Visual Toggles", Description = "", Order = 50)]
        public bool iShowTestedShading { get; set; }

        [Display(Name = "Show Tested Marker", GroupName = "Visual Toggles", Description = "", Order = 60)]
        public bool iShowTestedMarker { get; set; }

        [Display(Name = "Show Broken Zones", GroupName = "Visual Toggles", Description = "", Order = 70)]
        public bool iShowBrokenZones { get; set; }
		
        [Display(Name = "Filter Qualified Zones", GroupName = "Visual Toggles", Description = "", Order = 80)]
		public bool iFilterQualifiedZones { get; set; }

        [Display(Name = "Show Price Labels", GroupName = "Visual Toggles", Description = "", Order = 90)]
        public bool iShowPriceLabels { get; set; }
		
        [Display(Name = "Enable Globals", GroupName = "Visual Toggles", Description = "", Order = 100)]
		public bool pGlobalObjects_Enabled {get;set;}

        #endregion

        #region -- 06. Visual Style SDVSystem --
        [XmlIgnore]
        [Display(Name = "Fresh Demand Zone Color", GroupName = "Visual Style", Description = "", Order = 0)] //##OK##
        public Brush iFreshDemandZoneColor { get; set; }
        [Browsable(false)]
        public string iFreshDemandZoneColorSerialize
        {
            get { return Serialize.BrushToString(iFreshDemandZoneColor); }
            set { iFreshDemandZoneColor = Serialize.StringToBrush(value); }
        }
        [Range(0, 100)]
        [Display(Name = "Fresh Demand Zone Opacity", GroupName = "Visual Style", Description = "", Order = 12)] //##OK##
        public int iFreshDemandZoneOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Fresh Demand Zone Outline Color", GroupName = "Visual Style", Description = "", Order = 6)] //##OK##
        public Brush iFreshDemandZoneOutlineColor { get; set; }
        [Browsable(false)]
        public string iFreshDemandZoneOutlineColorSerialize
        {
            get { return Serialize.BrushToString(iFreshDemandZoneOutlineColor); }
            set { iFreshDemandZoneOutlineColor = Serialize.StringToBrush(value); }
        }
        [Display(Name = "Fresh Demand Zone OutlineStyle", GroupName = "Visual Style", Description = "", Order = 18)] //##OK##
        public DashStyleHelper iFreshDemandZoneOutlineStyle { get; set; }
        
        [XmlIgnore]
        [Display(Name = "Tested Demand Zone Color", GroupName = "Visual Style", Description = "", Order = 2)] //##OK##
        public Brush iTestedDemandZoneColor { get; set; }
        [Browsable(false)]
        public string iTestedDemandZoneColorSerialize
        {
            get { return Serialize.BrushToString(iTestedDemandZoneColor); }
            set { iTestedDemandZoneColor = Serialize.StringToBrush(value); }
        }
        [Range(0, 100)]
        [Display(Name = "Tested Demand Zone Opacity", GroupName = "Visual Style", Description = "", Order = 14)] //##OK##
        public int iTestedDemandZoneOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Tested Demand Zone Outline Color", GroupName = "Visual Style", Description = "", Order = 8)] //##OK##
        public Brush iTestedDemandZoneOutlineColor { get; set; }
        [Browsable(false)]
        public string iTestedDemandZoneOutlineColorSerialize
        {
            get { return Serialize.BrushToString(iTestedDemandZoneOutlineColor); }
            set { iTestedDemandZoneOutlineColor = Serialize.StringToBrush(value); }
        }
        [Display(Name = "Tested Demand Zone OutlineStyle", GroupName = "Visual Style", Description = "", Order = 20)] //##OK##
        public DashStyleHelper iTestedDemandZoneOutlineStyle { get; set; }

        [XmlIgnore]
        [Display(Name = "Broken Demand Zone Color", GroupName = "Visual Style", Description = "", Order = 4)] //##OK##
        public Brush iBrokenDemandZoneColor { get; set; }
        [Browsable(false)]
        public string iBrokenDemandZoneColorSerialize
        {
            get { return Serialize.BrushToString(iBrokenDemandZoneColor); }
            set { iBrokenDemandZoneColor = Serialize.StringToBrush(value); }
        }
        [Range(0, 100)]
        [Display(Name = "Broken Demand Zone Opacity", GroupName = "Visual Style", Description = "", Order = 16)] //##OK##
        public int iBrokenDemandZoneOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Broken Demand Zone Outline Color", GroupName = "Visual Style", Description = "", Order = 10)] //##OK##
        public Brush iBrokenDemandZoneOutlineColor { get; set; }
        [Browsable(false)]
        public string iBrokenDemandZoneOutlineColorSerialize
        {
            get { return Serialize.BrushToString(iBrokenDemandZoneOutlineColor); }
            set { iBrokenDemandZoneOutlineColor = Serialize.StringToBrush(value); }
        }
        [Display(Name = "Broken Demand Zone OutlineStyle", GroupName = "Visual Style", Description = "", Order = 22)] //##OK##
        public DashStyleHelper iBrokenDemandZoneOutlineStyle { get; set; }


        [XmlIgnore]
        [Display(Name = "Fresh Supply Zone Color", GroupName = "Visual Style", Description = "", Order = 1)] //##OK##
        public Brush iFreshSupplyZoneColor { get; set; }
        [Browsable(false)]
        public string iFreshSupplyZoneColorSerialize
        {
            get { return Serialize.BrushToString(iFreshSupplyZoneColor); }
            set { iFreshSupplyZoneColor = Serialize.StringToBrush(value); }
        }
        [Range(0, 100)]
        [Display(Name = "Fresh Supply Zone Opacity", GroupName = "Visual Style", Description = "", Order = 13)] //##OK##
        public int iFreshSupplyZoneOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Fresh Supply Zone Outline Color", GroupName = "Visual Style", Description = "", Order = 7)] //##OK##
        public Brush iFreshSupplyZoneOutlineColor { get; set; }
        [Browsable(false)]
        public string iFreshSupplyZoneOutlineColorSerialize
        {
            get { return Serialize.BrushToString(iFreshSupplyZoneOutlineColor); }
            set { iFreshSupplyZoneOutlineColor = Serialize.StringToBrush(value); }
        }
        [Display(Name = "Fresh Supply Zone OutlineStyle", GroupName = "Visual Style", Description = "", Order = 19)] //##OK##
        public DashStyleHelper iFreshSupplyZoneOutlineStyle { get; set; }

        [XmlIgnore]
        [Display(Name = "Tested Supply Zone Color", GroupName = "Visual Style", Description = "", Order = 3)] //##OK##
        public Brush iTestedSupplyZoneColor { get; set; }
        [Browsable(false)]
        public string iTestedSupplyZoneColorSerialize
        {
            get { return Serialize.BrushToString(iTestedSupplyZoneColor); }
            set { iTestedSupplyZoneColor = Serialize.StringToBrush(value); }
        }
        [Range(0, 100)]
        [Display(Name = "Tested Supply Zone Opacity", GroupName = "Visual Style", Description = "", Order = 15)] //##OK##
        public int iTestedSupplyZoneOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Tested Supply Zone Outline Color", GroupName = "Visual Style", Description = "", Order = 9)] //##OK##
        public Brush iTestedSupplyZoneOutlineColor { get; set; }
        [Browsable(false)]
        public string iTestedSupplyZoneOutlineColorSerialize
        {
            get { return Serialize.BrushToString(iTestedSupplyZoneOutlineColor); }
            set { iTestedSupplyZoneOutlineColor = Serialize.StringToBrush(value); }
        }
        [Display(Name = "Tested Supply Zone OutlineStyle", GroupName = "Visual Style", Description = "", Order = 21)] //##OK##
        public DashStyleHelper iTestedSupplyZoneOutlineStyle { get; set; }

        [XmlIgnore]
        [Display(Name = "Broken Supply Zone Color", GroupName = "Visual Style", Description = "", Order = 5)] //##OK##
        public Brush iBrokenSupplyZoneColor { get; set; }
        [Browsable(false)]
        public string iBrokenSupplyZoneColorSerialize
        {
            get { return Serialize.BrushToString(iBrokenSupplyZoneColor); }
            set { iBrokenSupplyZoneColor = Serialize.StringToBrush(value); }
        }
        [Range(0, 100)]
        [Display(Name = "Broken Supply Zone Opacity", GroupName = "Visual Style", Description = "", Order = 17)] //##OK##
        public int iBrokenSupplyZoneOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Broken Supply Zone Outline Color", GroupName = "Visual Style", Description = "", Order = 11)] //##OK##
        public Brush iBrokenSupplyZoneOutlineColor { get; set; }
        [Browsable(false)]
        public string iBrokenSupplyZoneOutlineColorSerialize
        {
            get { return Serialize.BrushToString(iBrokenSupplyZoneOutlineColor); }
            set { iBrokenSupplyZoneOutlineColor = Serialize.StringToBrush(value); }
        }
        [Display(Name = "Broken Supply Zone OutlineStyle", GroupName = "Visual Style", Description = "", Order = 23)] //##OK##
        public DashStyleHelper iBrokenSupplyZoneOutlineStyle { get; set; }
        
        [Display(Name = "Text Font", GroupName = "Visual Style", Description = "", Order = 24)]
        public SimpleFont iTextFont { get; set; }
        [XmlIgnore]
        [Display(Name = "Text Color", GroupName = "Visual Style", Description = "", Order = 25)]
        public Brush iTextColor { get; set; }
        [Browsable(false)]
        public string iTextColorSerialize
        {
            get { return Serialize.BrushToString(iTextColor); }
            set { iTextColor = Serialize.StringToBrush(value); }
        }
        #endregion

        #region -- 07. Visual Style Market Structure  --
        [Display(Name = "Zigzag Dash Style", GroupName = "Visual Style Market Structure", Description = "Dash style for zigzag line", Order = 0)]
        public DashStyleHelper dash0Style { get; set; }
        
        [XmlIgnore]
        [Display(Name = "Upswing Color", GroupName = "Visual Style Market Structure", Description = "Select color for uptrend", Order = 1)]
        public Brush iUpColor { get; set; }
        [Browsable(false)]
        public string UpColorColorSerialize
        {
            get { return Serialize.BrushToString(iUpColor); }
            set { iUpColor = Serialize.StringToBrush(value); }
        }
        
        [XmlIgnore]
        [Display(Name = "Downswing Color", GroupName = "Visual Style Market Structure", Description = "Select color for downtrend", Order = 2)]
        public Brush iDownColor { get; set; }
        [Browsable(false)]
        public string downColorSerialize
        {
            get { return Serialize.BrushToString(iDownColor); }
            set { iDownColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Double Top/Bottom Color", GroupName = "Visual Style Market Structure", Description = "Select color for double tops and double bottoms", Order = 3)]
        public Brush iNeutralColor { get; set; }
        [Browsable(false)]
        public string NeutralColorSerialize
        {
            get { return Serialize.BrushToString(iNeutralColor); }
            set { iNeutralColor = Serialize.StringToBrush(value); }
        }
        #endregion

        #region -- 09. Alerts  --

        [Display(Name = "On entering zone", GroupName = "Alerts", Description = "Turn-on alert when price crosses into a zone", Order = 0)]
        public bool iAlertOn { get; set; }

        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
        [Display(Name = "Audio File", GroupName = "Alerts", Description = "", Order = 10)]
        public string iAlertSoundFile { get; set; }

        #endregion

        #region -- 08. Visual Style Paintbars  --
        [Display(Name = "Enabled", GroupName = "Visual Style Paintbars", Description = "Paint Bars", Order = 0)] //##OK##
        public bool iPaintBarsEnabled { get; set; }

        [XmlIgnore]
        [Display(Name = "Upthrust Body", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 1)] //##OK##
        public Brush upthrustFillColor { get; set; }
        [Browsable(false)]
        public string upthrustFillColorSerialize
        {
            get { return Serialize.BrushToString(upthrustFillColor); }
            set { upthrustFillColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Upthrust Outline", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 7)] //##OK##
        public Brush upthrustColor { get; set; }
        [Browsable(false)]
        public string upthrustColorSerialize
        {
            get { return Serialize.BrushToString(upthrustColor); }
            set { upthrustColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Downthrust Body", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 2)] //##OK##
        public Brush downthrustFillColor { get; set; }
        [Browsable(false)]
        public string downthrustFillColorSerialize
        {
            get { return Serialize.BrushToString(downthrustFillColor); }
            set { downthrustFillColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Downthrust Outline", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 8)] //##OK##
        public Brush downthrustColor { get; set; }
        [Browsable(false)]
        public string downthrustColorSerialize
        {
            get { return Serialize.BrushToString(downthrustColor); }
            set { downthrustColor = Serialize.StringToBrush(value); }
        }
        
        [XmlIgnore]
        [Display(Name = "Uptrend Continuation Body", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 3)] //##OK##
        public Brush uptrendFillColor { get; set; }
        [Browsable(false)]
        public string uptrendFillColorSerialize
        {
            get { return Serialize.BrushToString(uptrendFillColor); }
            set { uptrendFillColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Uptrend Continuation Outline", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 9)] //##OK##
        public Brush uptrendColor { get; set; }
        [Browsable(false)]
        public string uptrendColorSerialize
        {
            get { return Serialize.BrushToString(uptrendColor); }
            set { uptrendColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Downtrend Continuation Body", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 4)] //##OK##
        public Brush downtrendFillColor { get; set; }
        [Browsable(false)]
        public string downtrendFillColorSerialize
        {
            get { return Serialize.BrushToString(downtrendFillColor); }
            set { downtrendFillColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Downtrend Continuation Outline", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 10)] //##OK##
        public Brush downtrendColor { get; set; }
        [Browsable(false)]
        public string downtrendColorSerialize
        {
            get { return Serialize.BrushToString(downtrendColor); }
            set { downtrendColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Consolidation Upclose Body", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 5)] //##OK##
        public Brush consolidupFillColor { get; set; }
        [Browsable(false)]
        public string consolidupFillColorSerialize
        {
            get { return Serialize.BrushToString(consolidupFillColor); }
            set { consolidupFillColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Consolidation Downclose Body", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 6)] //##OK##
        public Brush consoliddownFillColor { get; set; }
        [Browsable(false)]
        public string consoliddownFillColorSerialize
        {
            get { return Serialize.BrushToString(consoliddownFillColor); }
            set { consoliddownFillColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Consolidation Outline", GroupName = "Visual Style Paintbars", Description = "Select Bar Color", Order = 11)]
        public Brush consolidationColor { get; set; }
        [Browsable(false)]
        public string consolidationColorSerialize
        {
            get { return Serialize.BrushToString(consolidationColor); }
            set { consolidationColor = Serialize.StringToBrush(value); }
        }

        #endregion

        #region -- 03. Curve --

        [Display(Name = "Outline DashStyle", GroupName = "Curve", Description = "", Order = 14)]        
        public DashStyleHelper pDashStyle1 { get; set; }
        
        [Range(1, int.MaxValue)]
        [Display(Name = "Outline Width", GroupName = "Curve", Description = "", Order = 16)]
        public int pWidth1 { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "X Offset (Pixels)", GroupName = "Curve", Description = "adjust the curve, in pixels, to the right of the last bar painted.", Order = 25)]
        public int pXOffset { get; set; }

        [Range(0, 100)]
        [Display(Name = "Outline Opacity (%)", GroupName = "Curve", Description = "", Order = 15)]
        public int iOpacity1 { get; set; }
//        [XmlIgnore]
//        [Display(Name = "Outline Color", GroupName = "Curve", Description = "", Order = 13)]
//        public Brush iLC1 { get; set; }
//        [Browsable(false)]
//        public string LC1Serialize
//        {
//            get { return Serialize.BrushToString(iLC1); }
//            set { iLC1 = Serialize.StringToBrush(value); }
//        }

        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name = "Percent 5", GroupName = "Curve", Description = "", Order = 12)]
        public int pPercent1 { get; set; }

        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name = "Percent 4", GroupName = "Curve", Description = "", Order = 11)]
        public int pPercent2 { get; set; }

        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name = "Percent 3", GroupName = "Curve", Description = "", Order = 10)]
        public int pPercent3 { get; set; }

        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name = "Percent 2", GroupName = "Curve", Description = "", Order = 9)]
        public int pPercent4 { get; set; }

        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name = "Percent 1", GroupName = "Curve", Description = "", Order = 8)]
        public int pPercent5 { get; set; }

        [Range(0, 100)]
        [Display(Name = "Deep Value Opacity (%)", GroupName = "Curve", Description = "The opacity in percent.", Order = 24)]
        public int iCurveOpacity1 { get; set; }
        [XmlIgnore]
        [Display(Name = "Deep Value Color", GroupName = "Curve", Description = "", Order = 23)]
        public Brush iCurveAreaBrush1 { get; set; }
        [Browsable(false)]
        public string CurveAreaDXBrush1Serialize
        {
            get { return Serialize.BrushToString(iCurveAreaBrush1); }
            set { iCurveAreaBrush1 = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Value Opacity (%)", GroupName = "Curve", Description = "The opacity in percent.", Order = 22)]
        public int iCurveOpacity2 { get; set; }
        [XmlIgnore]
        [Display(Name = "Value Color", GroupName = "Curve", Description = "", Order = 21)]
        public Brush iCurveAreaBrush2 { get; set; }
        [Browsable(false)]
        public string CurveAreaDXBrush2Serialize
        {
            get { return Serialize.BrushToString(iCurveAreaBrush2); }
            set { iCurveAreaBrush2 = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Retail Opacity (%)", GroupName = "Curve", Description = "The opacity in percent.", Order = 20)]
        public int iCurveOpacity3 { get; set; }
        [XmlIgnore]
        [Display(Name = "Retail Color", GroupName = "Curve", Description = "", Order = 19)]
        public Brush iCurveAreaBrush3 { get; set; }
        [Browsable(false)]
        public string CurveAreaDXBrush3Serialize
        {
            get { return Serialize.BrushToString(iCurveAreaBrush3); }
            set { iCurveAreaBrush3 = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Deep Retail Opacity (%)", GroupName = "Curve", Description = "The opacity in percent.", Order = 18)]
        public int iCurveOpacity4 { get; set; }
        [XmlIgnore]
        [Display(Name = "Deep Retail Color", GroupName = "Curve", Description = "", Order = 17)]
        public Brush iCurveAreaBrush4 { get; set; }
        [Browsable(false)]
        public string CurveAreaDXBrush4Serialize
        {
            get { return Serialize.BrushToString(iCurveAreaBrush4); }
            set { iCurveAreaBrush4 = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Enabled", GroupName = "Curve", Description = "", Order = 0)]
        public bool pDisplayEnabled { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1000)]
        [Display(Name = "Defiance ATR (%)", GroupName = "Curve", Description = "", Order = 1)]
        public int pDefiance { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1000)]
        [Display(Name = "Break H/L ATR (%)", GroupName = "Curve", Description = "", Order = 2)]
        public int pBreakATR { get; set; }

        [Display(Name = "Show Price Labels", GroupName = "Curve", Description = "", Order = 3)]
        public bool pDisplayPrice { get; set; }

        [Display(Name = "Show Percent Labels", GroupName = "Curve", Description = "", Order = 4)]
        public bool pDisplayPercent { get; set; }

        [Display(Name = "Zone Snap Enabled", GroupName = "Curve", Description = "", Order = 7)]
        public bool pIncludeZone { get; set; }

        [Display(Name = "Show Name Labels", GroupName = "Curve", Description = "", Order = 5)]
        public bool pDisplayText { get; set; }

        [Display(Name = "Text Font", GroupName = "Curve", Description = "Choose your font style curve text.", Order = 26)]
        public SimpleFont pTextFont3 { get; set; }

        #endregion

        #region -- 04. Profile --

        [NinjaScriptProperty]
        [Range(1,100)]
        [Display(Name = "Percent of Volume In Value Area", GroupName = "Profile", Description = "Percent of volume within Value Area (1-100)", Order = 0)]
        public int iPctOfVolumeInVA { get; set; }

        [Display(Name = "Show Profile", GroupName = "Profile", Description = "", Order = 1)]
        public bool iShowProfile { get; set; }

        [Display(Name = "Show POC", GroupName = "Profile", Description = "", Order = 2)]
        public bool iShowPOC { get; set; }

        [Display(Name = "Show VAL", GroupName = "Profile", Description = "", Order = 3)]
        public bool iShowVAL { get; set; }

        [Display(Name = "Show VAH", GroupName = "Profile", Description = "", Order = 4)]
        public bool iShowVAH { get; set; }

        [Display(Name = "Profile Expansion", GroupName = "Profile", Description = "", Order = 5)]
        public ARC_SDVSystem_ProfileExpansion iProfileExpansion { get; set; }

        [Display(Name = "Show Volume Cluster", GroupName = "Profile", Description = "", Order = 6)]
        public bool iShowVolumeCluster { get; set; }

        [Display(Name = "Show Volume Ratio", GroupName = "Profile", Description = "", Order = 7)]
        public bool iShowVolumeRatio { get; set; }

        [Display(Name = "Show Delta Factor", GroupName = "Profile", Description = "", Order = 8)]
        public bool iShowDeltaFactor { get; set; }

        [Display(Name = "Show Volume Values", GroupName = "Profile", Description = "", Order = 9)]
        public bool iShowVolumeValues { get; set; }

        [Display(Name = "Show All Profiles", GroupName = "Profile", Description = "", Order = 10)]
        public bool iShowAllProfile { get; set; }

        [Display(Name = "Show All Supply Profiles", GroupName = "Profile", Description = "", Order = 11)]
        public bool iShowAllSupplyProfile { get; set; }

        [Display(Name = "Show All Demand Profiles", GroupName = "Profile", Description = "", Order = 12)]
        public bool iShowAllDemandProfile { get; set; }

        [Display(Name = "Show All Tested Profiles", GroupName = "Profile", Description = "", Order = 13)]
        public bool iShowAllTestedProfile { get; set; }

        [Display(Name = "Show All Broken Profiles", GroupName = "Profile", Description = "", Order = 14)]
        public bool iShowAllBrokenProfile { get; set; }

        [Range(0, 100)]
        [Display(Name = "Profile Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 16)]
        public int iProfileOpacity { get; set; }

        [XmlIgnore]
        [Display(Name = "Profile Color", GroupName = "Profile", Description = "", Order = 15)]
        public Brush iProfileColor { get; set; }
        [Browsable(false)]
        public string ProfileColorSerialize
        {
            get { return Serialize.BrushToString(iProfileColor); }
            set { iProfileColor = Serialize.StringToBrush(value); }
        }
        [Range(1,int.MaxValue)]
        [Display(Name = "Profile Thickness", GroupName = "Profile", Description = "", Order = 17)]
        public int iProfileThickness { get; set; }

        [Range(0, 100)]
        [Display(Name = "POC Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 19)]
        public int iPOCOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "POC Color", GroupName = "Profile", Description = "", Order = 18)]
        public Brush iPOCColor { get; set; }
        [Browsable(false)]
        public string POCColorSerialize
        {
            get { return Serialize.BrushToString(iPOCColor); }
            set { iPOCColor = Serialize.StringToBrush(value); }
        }
        [Range(1, int.MaxValue)]
        [Display(Name = "POC Thickness", GroupName = "Profile", Description = "", Order = 20)]
        public int iPOCThickness { get; set; }

        [Range(0, 100)]
        [Display(Name = "VAL Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 22)]
        public int iVALOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "VAL Color", GroupName = "Profile", Description = "", Order = 21)]
        public Brush iVALColor { get; set; }
        [Browsable(false)]
        public string VALColorColorSerialize
        {
            get { return Serialize.BrushToString(iVALColor); }
            set { iVALColor = Serialize.StringToBrush(value); }
        }
        [Range(1, int.MaxValue)]
        [Display(Name = "VAL Thickness", GroupName = "Profile", Description = "", Order = 23)]
        public int iVALThickness { get; set; }

        [Range(0, 100)]
        [Display(Name = "VAH Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 25)]
        public int iVAHOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "VAH Color", GroupName = "Profile", Description = "", Order = 24)]
        public Brush iVAHColor { get; set; }
        [Browsable(false)]
        public string VAHColorColorSerialize
        {
            get { return Serialize.BrushToString(iVAHColor); }
            set { iVAHColor = Serialize.StringToBrush(value); }
        }
        [Range(1, int.MaxValue)]
        [Display(Name = "VAH Thickness", GroupName = "Profile", Description = "", Order = 26)]
        public int iVAHThickness { get; set; }

        [Range(0, 100)]
        [Display(Name = "Volume Cluster Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 28)]
        public int iVCOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Volume Cluster Color", GroupName = "Profile", Description = "", Order = 27)]
        public Brush iVCColor { get; set; }
        [Browsable(false)]
        public string VCColorColorSerialize
        {
            get { return Serialize.BrushToString(iVCColor); }
            set { iVCColor = Serialize.StringToBrush(value); }
        }
        [Range(1, int.MaxValue)]
        [Display(Name = "Volume Cluster Thickness", GroupName = "Profile", Description = "", Order = 29)]
        public int iVCThickness { get; set; }

        [Range(0, 100)]
        [Display(Name = "Volume Ratio Up Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 31)]
        public int iVRUOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Volume Ratio Up Color", GroupName = "Profile", Description = "", Order = 30)]
        public Brush iVRUColor { get; set; }
        [Browsable(false)]
        public string VRUColorColorSerialize
        {
            get { return Serialize.BrushToString(iVRUColor); }
            set { iVRUColor = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Volume Ratio Down Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 33)]
        public int iVRDOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Volume Ratio Down Color", GroupName = "Profile", Description = "", Order = 32)]
        public Brush iVRDColor { get; set; }
        [Browsable(false)]
        public string VRDColorColorSerialize
        {
            get { return Serialize.BrushToString(iVRDColor); }
            set { iVRDColor = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Volume Ratio Text Font", GroupName = "Profile", Description = "", Order = 34)]
        public SimpleFont iVRTextFont { get; set; }
        [XmlIgnore]
        [Display(Name = "Volume Ratio Text Color", GroupName = "Profile", Description = "", Order = 35)]
        public Brush iVRTextColor { get; set; }
        [Browsable(false)]
        public string VRTextColorColorSerialize
        {
            get { return Serialize.BrushToString(iVRTextColor); }
            set { iVRTextColor = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Delta Factor Text Font", GroupName = "Profile", Description = "", Order = 37)]
        public SimpleFont iDFTextFont { get; set; }        
        [XmlIgnore]
        [Display(Name = "Delta Factor Up Text Color", GroupName = "Profile", Description = "", Order = 38)]
        public Brush iDFUTextColor { get; set; }
        [Browsable(false)]
        public string DFUTextColorSerialize
        {
            get { return Serialize.BrushToString(iDFUTextColor); }
            set { iDFUTextColor = Serialize.StringToBrush(value); }
        }
        [XmlIgnore]
        [Display(Name = "Delta Factor Down Text Color", GroupName = "Profile", Description = "", Order = 39)]
        public Brush iDFDTextColor { get; set; }
        [Browsable(false)]
        public string DFDTextColorSerialize
        {
            get { return Serialize.BrushToString(iDFDTextColor); }
            set { iDFDTextColor = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Delta Factor Text Back Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 42)]
        public int iDFTextBackOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Delta Factor Text Back Color", GroupName = "Profile", Description = "", Order = 41)]
        public Brush iDFTextBackColor { get; set; }
        [Browsable(false)]
        public string DFTextBackColorSerialize
        {
            get { return Serialize.BrushToString(iDFTextBackColor); }
            set { iDFTextBackColor = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Volume Values Text Font", GroupName = "Profile", Description = "", Order = 43)]
        public SimpleFont iVVTextFont { get; set; }
        [XmlIgnore]
        [Display(Name = "Volume Values Text Color", GroupName = "Profile", Description = "", Order = 44)]
        public Brush iVVTextColor { get; set; }
        [Browsable(false)]
        public string VVTextColorSerialize
        {
            get { return Serialize.BrushToString(iVVTextColor); }
            set { iVVTextColor = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Volume Values Text Back Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 47)]
        public int iVVTextBackOpacity { get; set; }

        [XmlIgnore]
        [Display(Name = "Volume Values Text Back Color", GroupName = "Profile", Description = "", Order = 46)]
        public Brush iVVTextBackColor { get; set; }
        [Browsable(false)]
        public string VVTextBackColorSerialize
        {
            get { return Serialize.BrushToString(iVVTextBackColor); }
            set { iVVTextBackColor = Serialize.StringToBrush(value); }
        }
		
        [Range(0, 100)]
        [Display(Name = "Tested Marker Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 49)]
        public int iTMOpacity { get; set; }
        [XmlIgnore]
        [Display(Name = "Tested Marker Color", GroupName = "Profile", Description = "", Order = 48)]
        public Brush iTMColor { get; set; }
        [Browsable(false)]
        public string TMColorSerialize
        {
            get { return Serialize.BrushToString(iTMColor); }
            set { iTMColor = Serialize.StringToBrush(value); }
        }
        
        [Range(1, int.MaxValue)]
        [Display(Name = "Tested Marker Thickness", GroupName = "Profile", Description = "", Order = 50)]
        public int iTMThickness { get; set; }

        [Display(Name = "Show LVNs", GroupName = "Profile", Description = "", Order = 60)]
        public bool iShowLVNProfile { get; set; }
        
        [Display(Name = "Expand LVNs", GroupName = "Profile", Description = "", Order = 61)]
        public bool iExpandLVNProfile { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Number of LVNs to display", GroupName = "Profile", Description = "", Order = 62)]
        public int iNumberOfLVN { get; set; }

        [XmlIgnore]
        [Display(Name = "LVNs Color", GroupName = "Profile", Description = "", Order = 63)]
        public Brush iLVNColor { get; set; }
        [Browsable(false)]
        public string LVNColorSerialize
        {
            get { return Serialize.BrushToString(iLVNColor); }
            set { iLVNColor = Serialize.StringToBrush(value); }
        }
        [Range(0, 100)]
        [Display(Name = "LVNs Opacity (%)", GroupName = "Profile", Description = "The opacity in percent", Order = 64)]
        public int iLVNOpacity { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "LVNs Thickness", GroupName = "Profile", Description = "", Order = 65)]
        public int iLVNThickness { get; set; }

        #endregion

		[Display(Order = 10, Name = "Fresh Supply Zone Template", GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pSupplyFreshZone_Template { get; set; }

		[Display(Order = 20, Name = "Tested Supply Zone Template", GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pSupplyTestedZone_Template { get; set; }

		[Display(Order = 30, Name = "Broken Supply Zone Template", GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pSupplyBrokenZone_Template { get; set; }

		[Display(Order = 40, Name = "Fresh Demand Zone Template", GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pDemandFreshZone_Template { get; set; }

		[Display(Order = 50, Name = "Tested Demand Zone Template", GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pDemandTestedZone_Template { get; set; }

		[Display(Order = 60, Name = "Broken Demand Zone Template", GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadZoneTemplates))]
		public string pDemandBrokenZone_Template { get; set; }

		[Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

        #endregion

        //----------------------------- Nested Classes ----------------------------------------
		#region -- Load pulldown parameters --
		internal class LoadZoneTemplates : StringConverter
		{
			#region LoadZoneTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Rectangle"};
				HLtemplates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(HLtemplates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
		internal class LoadRayTemplates : StringConverter
		{
			#region LoadRayTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Ray"};
				HLtemplates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(HLtemplates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }
		#endregion

		#region -- private class MouseManager --
		private class MouseManager
		{
			public int HoverIndex;
			public int SelectedProfileId;
			public int X;
			public int Y;
			public int Index;
			public double price = 0;
			public int abar = 0;
			public bool ChoosingToAddRay = false;
			public double ChartMaxPrice = double.MinValue;
			public double ChartMinPrice = double.MaxValue;
			public int    ChartMinABar  = int.MaxValue;
			public int    ChartMaxABar  = 0;
			public double  ChartHeight  = 0;

			public MouseManager()
			{
				this.Clear();
			}
			public void Clear()
			{
				this.SelectedProfileId = -1;
				this.X = 0;
				this.Y = 0;
				this.Index = 0;
				this.HoverIndex = -1;
			}
		}
		#endregion
	}
}


    #region -- enums --
    public enum ARC_SDVSystem_TickDirection { UP, DOWN }
    public enum ARC_SDVSystem_ProfileDataType { TICK, SECOND, MINUTE }
    public enum ARC_SDVSystem_ProfileExpansion { DEFAULT = 0, EXPAND_1 = 1, EXPAND_2 = 2, EXPAND_3 = 3, EXPAND_LINES = 4 }
    public enum ARC_SDVSystem_ViewToggle2 { ALL, AUTO_ONLY, MANUAL_ONLY, NONE }
    public enum ARC_SDVSystem_ZoneMode2 { DEFAULT_CHART, MTF }
    public enum ARC_SDVSystem_ZoneBool2 { True, False }
    public enum ARC_SDVSystem_MTFBarType { Tick = 2, Volume = 1, Range = 8, Second = 7, Minute = 0, Day = 3, Week = 4, Month = 5, Year = 6 }

	public enum ARC_SDVSystem_TradeEntryBasis{ AtZoneEdge, AtNearLVN, AtFarLVN}
	public enum ARC_SDVSystem_TradePlanLocation {Left, Right}
	public enum ARC_SDVSystem_SL_CalcBasis {ZoneEdge, ATR, Ticks}
	public enum ARC_SDVSystem_TP_CalcBasis {ATR, Ticks, RR}
//	public enum ARC_SDVSystem_Plan_LevelsBasis {AtFib, AtEntryPrice}
    #endregion

    #region partial class Indicator
//    partial class Indicator
  //  {

       // private const ARC_SDVSystemManager gGZS = new ARC_SDVSystemManager();


    //}
    #endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_SDVSystem[] cacheARC_SDVSystem;
		public ARC.ARC_SDVSystem ARC_SDVSystem(bool pQualifyOnVolume, bool pQualifyOnThrust, bool pQualifyOnBasingCount, int pMaxVolPctQualifier, int pMaxBasingCount, bool iVAEnabled, int iVAPeriod, string iVAMode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, ARC_SDVSystem_ZoneMode2 iChartMode1, int bars_To_Process, ARC_SDVSystem_MTFBarType iChartType1, int iChartValue1, ARC_SDVSystem_ProfileDataType iProfileCalcTimeFrame, bool applyRangeFilter, int barFilter, int iTickBuffer, int swingStrength, int percentATR, int pPercent1, int pPercent2, int pPercent3, int pPercent4, int pPercent5, int pDefiance, int pBreakATR, int iPctOfVolumeInVA)
		{
			return ARC_SDVSystem(Input, pQualifyOnVolume, pQualifyOnThrust, pQualifyOnBasingCount, pMaxVolPctQualifier, pMaxBasingCount, iVAEnabled, iVAPeriod, iVAMode, iVA2Enabled, iVA2Period, iVA2Mode, iChartMode1, bars_To_Process, iChartType1, iChartValue1, iProfileCalcTimeFrame, applyRangeFilter, barFilter, iTickBuffer, swingStrength, percentATR, pPercent1, pPercent2, pPercent3, pPercent4, pPercent5, pDefiance, pBreakATR, iPctOfVolumeInVA);
		}

		public ARC.ARC_SDVSystem ARC_SDVSystem(ISeries<double> input, bool pQualifyOnVolume, bool pQualifyOnThrust, bool pQualifyOnBasingCount, int pMaxVolPctQualifier, int pMaxBasingCount, bool iVAEnabled, int iVAPeriod, string iVAMode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, ARC_SDVSystem_ZoneMode2 iChartMode1, int bars_To_Process, ARC_SDVSystem_MTFBarType iChartType1, int iChartValue1, ARC_SDVSystem_ProfileDataType iProfileCalcTimeFrame, bool applyRangeFilter, int barFilter, int iTickBuffer, int swingStrength, int percentATR, int pPercent1, int pPercent2, int pPercent3, int pPercent4, int pPercent5, int pDefiance, int pBreakATR, int iPctOfVolumeInVA)
		{
			if (cacheARC_SDVSystem != null)
				for (int idx = 0; idx < cacheARC_SDVSystem.Length; idx++)
					if (cacheARC_SDVSystem[idx] != null && cacheARC_SDVSystem[idx].pQualifyOnVolume == pQualifyOnVolume && cacheARC_SDVSystem[idx].pQualifyOnThrust == pQualifyOnThrust && cacheARC_SDVSystem[idx].pQualifyOnBasingCount == pQualifyOnBasingCount && cacheARC_SDVSystem[idx].pMaxVolPctQualifier == pMaxVolPctQualifier && cacheARC_SDVSystem[idx].pMaxBasingCount == pMaxBasingCount && cacheARC_SDVSystem[idx].iVAEnabled == iVAEnabled && cacheARC_SDVSystem[idx].iVAPeriod == iVAPeriod && cacheARC_SDVSystem[idx].iVAMode == iVAMode && cacheARC_SDVSystem[idx].iVA2Enabled == iVA2Enabled && cacheARC_SDVSystem[idx].iVA2Period == iVA2Period && cacheARC_SDVSystem[idx].iVA2Mode == iVA2Mode && cacheARC_SDVSystem[idx].iChartMode1 == iChartMode1 && cacheARC_SDVSystem[idx].Bars_To_Process == bars_To_Process && cacheARC_SDVSystem[idx].iChartType1 == iChartType1 && cacheARC_SDVSystem[idx].iChartValue1 == iChartValue1 && cacheARC_SDVSystem[idx].iProfileCalcTimeFrame == iProfileCalcTimeFrame && cacheARC_SDVSystem[idx].applyRangeFilter == applyRangeFilter && cacheARC_SDVSystem[idx].barFilter == barFilter && cacheARC_SDVSystem[idx].iTickBuffer == iTickBuffer && cacheARC_SDVSystem[idx].swingStrength == swingStrength && cacheARC_SDVSystem[idx].percentATR == percentATR && cacheARC_SDVSystem[idx].pPercent1 == pPercent1 && cacheARC_SDVSystem[idx].pPercent2 == pPercent2 && cacheARC_SDVSystem[idx].pPercent3 == pPercent3 && cacheARC_SDVSystem[idx].pPercent4 == pPercent4 && cacheARC_SDVSystem[idx].pPercent5 == pPercent5 && cacheARC_SDVSystem[idx].pDefiance == pDefiance && cacheARC_SDVSystem[idx].pBreakATR == pBreakATR && cacheARC_SDVSystem[idx].iPctOfVolumeInVA == iPctOfVolumeInVA && cacheARC_SDVSystem[idx].EqualsInput(input))
						return cacheARC_SDVSystem[idx];
			return CacheIndicator<ARC.ARC_SDVSystem>(new ARC.ARC_SDVSystem(){ pQualifyOnVolume = pQualifyOnVolume, pQualifyOnThrust = pQualifyOnThrust, pQualifyOnBasingCount = pQualifyOnBasingCount, pMaxVolPctQualifier = pMaxVolPctQualifier, pMaxBasingCount = pMaxBasingCount, iVAEnabled = iVAEnabled, iVAPeriod = iVAPeriod, iVAMode = iVAMode, iVA2Enabled = iVA2Enabled, iVA2Period = iVA2Period, iVA2Mode = iVA2Mode, iChartMode1 = iChartMode1, Bars_To_Process = bars_To_Process, iChartType1 = iChartType1, iChartValue1 = iChartValue1, iProfileCalcTimeFrame = iProfileCalcTimeFrame, applyRangeFilter = applyRangeFilter, barFilter = barFilter, iTickBuffer = iTickBuffer, swingStrength = swingStrength, percentATR = percentATR, pPercent1 = pPercent1, pPercent2 = pPercent2, pPercent3 = pPercent3, pPercent4 = pPercent4, pPercent5 = pPercent5, pDefiance = pDefiance, pBreakATR = pBreakATR, iPctOfVolumeInVA = iPctOfVolumeInVA }, input, ref cacheARC_SDVSystem);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_SDVSystem ARC_SDVSystem(bool pQualifyOnVolume, bool pQualifyOnThrust, bool pQualifyOnBasingCount, int pMaxVolPctQualifier, int pMaxBasingCount, bool iVAEnabled, int iVAPeriod, string iVAMode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, ARC_SDVSystem_ZoneMode2 iChartMode1, int bars_To_Process, ARC_SDVSystem_MTFBarType iChartType1, int iChartValue1, ARC_SDVSystem_ProfileDataType iProfileCalcTimeFrame, bool applyRangeFilter, int barFilter, int iTickBuffer, int swingStrength, int percentATR, int pPercent1, int pPercent2, int pPercent3, int pPercent4, int pPercent5, int pDefiance, int pBreakATR, int iPctOfVolumeInVA)
		{
			return indicator.ARC_SDVSystem(Input, pQualifyOnVolume, pQualifyOnThrust, pQualifyOnBasingCount, pMaxVolPctQualifier, pMaxBasingCount, iVAEnabled, iVAPeriod, iVAMode, iVA2Enabled, iVA2Period, iVA2Mode, iChartMode1, bars_To_Process, iChartType1, iChartValue1, iProfileCalcTimeFrame, applyRangeFilter, barFilter, iTickBuffer, swingStrength, percentATR, pPercent1, pPercent2, pPercent3, pPercent4, pPercent5, pDefiance, pBreakATR, iPctOfVolumeInVA);
		}

		public Indicators.ARC.ARC_SDVSystem ARC_SDVSystem(ISeries<double> input , bool pQualifyOnVolume, bool pQualifyOnThrust, bool pQualifyOnBasingCount, int pMaxVolPctQualifier, int pMaxBasingCount, bool iVAEnabled, int iVAPeriod, string iVAMode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, ARC_SDVSystem_ZoneMode2 iChartMode1, int bars_To_Process, ARC_SDVSystem_MTFBarType iChartType1, int iChartValue1, ARC_SDVSystem_ProfileDataType iProfileCalcTimeFrame, bool applyRangeFilter, int barFilter, int iTickBuffer, int swingStrength, int percentATR, int pPercent1, int pPercent2, int pPercent3, int pPercent4, int pPercent5, int pDefiance, int pBreakATR, int iPctOfVolumeInVA)
		{
			return indicator.ARC_SDVSystem(input, pQualifyOnVolume, pQualifyOnThrust, pQualifyOnBasingCount, pMaxVolPctQualifier, pMaxBasingCount, iVAEnabled, iVAPeriod, iVAMode, iVA2Enabled, iVA2Period, iVA2Mode, iChartMode1, bars_To_Process, iChartType1, iChartValue1, iProfileCalcTimeFrame, applyRangeFilter, barFilter, iTickBuffer, swingStrength, percentATR, pPercent1, pPercent2, pPercent3, pPercent4, pPercent5, pDefiance, pBreakATR, iPctOfVolumeInVA);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_SDVSystem ARC_SDVSystem(bool pQualifyOnVolume, bool pQualifyOnThrust, bool pQualifyOnBasingCount, int pMaxVolPctQualifier, int pMaxBasingCount, bool iVAEnabled, int iVAPeriod, string iVAMode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, ARC_SDVSystem_ZoneMode2 iChartMode1, int bars_To_Process, ARC_SDVSystem_MTFBarType iChartType1, int iChartValue1, ARC_SDVSystem_ProfileDataType iProfileCalcTimeFrame, bool applyRangeFilter, int barFilter, int iTickBuffer, int swingStrength, int percentATR, int pPercent1, int pPercent2, int pPercent3, int pPercent4, int pPercent5, int pDefiance, int pBreakATR, int iPctOfVolumeInVA)
		{
			return indicator.ARC_SDVSystem(Input, pQualifyOnVolume, pQualifyOnThrust, pQualifyOnBasingCount, pMaxVolPctQualifier, pMaxBasingCount, iVAEnabled, iVAPeriod, iVAMode, iVA2Enabled, iVA2Period, iVA2Mode, iChartMode1, bars_To_Process, iChartType1, iChartValue1, iProfileCalcTimeFrame, applyRangeFilter, barFilter, iTickBuffer, swingStrength, percentATR, pPercent1, pPercent2, pPercent3, pPercent4, pPercent5, pDefiance, pBreakATR, iPctOfVolumeInVA);
		}

		public Indicators.ARC.ARC_SDVSystem ARC_SDVSystem(ISeries<double> input , bool pQualifyOnVolume, bool pQualifyOnThrust, bool pQualifyOnBasingCount, int pMaxVolPctQualifier, int pMaxBasingCount, bool iVAEnabled, int iVAPeriod, string iVAMode, bool iVA2Enabled, int iVA2Period, string iVA2Mode, ARC_SDVSystem_ZoneMode2 iChartMode1, int bars_To_Process, ARC_SDVSystem_MTFBarType iChartType1, int iChartValue1, ARC_SDVSystem_ProfileDataType iProfileCalcTimeFrame, bool applyRangeFilter, int barFilter, int iTickBuffer, int swingStrength, int percentATR, int pPercent1, int pPercent2, int pPercent3, int pPercent4, int pPercent5, int pDefiance, int pBreakATR, int iPctOfVolumeInVA)
		{
			return indicator.ARC_SDVSystem(input, pQualifyOnVolume, pQualifyOnThrust, pQualifyOnBasingCount, pMaxVolPctQualifier, pMaxBasingCount, iVAEnabled, iVAPeriod, iVAMode, iVA2Enabled, iVA2Period, iVA2Mode, iChartMode1, bars_To_Process, iChartType1, iChartValue1, iProfileCalcTimeFrame, applyRangeFilter, barFilter, iTickBuffer, swingStrength, percentATR, pPercent1, pPercent2, pPercent3, pPercent4, pPercent5, pDefiance, pBreakATR, iPctOfVolumeInVA);
		}
	}
}

#endregion
