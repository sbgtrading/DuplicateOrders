#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.Diagnostics;
//using System.Drawing;
//using System.Drawing.Drawing2D;
using System.ComponentModel;
using System.Xml.Serialization;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;

using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using SharpDX.DirectWrite;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Windows.Media;
using System.Linq;
#endregion
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    [CategoryOrder("Parameters",	10)]
    [CategoryOrder("Level Visuals",	20)]
//    [CategoryOrder("SpecificLevels",	50)]

    /// <summary>
    /// Plots lines at user  defined values.
    /// </summary>
	[Description("Plots lines at user defined values. Lines with values of zero will not plot.")]
	public class ARC_BigRoundNumbers : Indicator
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "BigRoundNumbers";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "21266", "27405"};//27405 is Annual Membership
		private string indicatorVersion = "v1.0";
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId,LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		private bool RunInit = true;
		private Brush RegionBrush=null;
		private Brush SpecificLevel1RegionBrush = null;
		private Brush SpecificLevel2RegionBrush = null;
		private Brush SpecificLevel3RegionBrush = null;
		private Brush SpecificLevel4RegionBrush = null;
		private Brush SpecificLevel5RegionBrush = null;
		private double Interval_points = 0;
		private double LastMinPrice = double.MaxValue;
		private double BasePrice_calibrated = double.MinValue;

	protected override void OnStateChange()
	{
		#region OnStateChange
		if (State == State.SetDefaults)
		{
			bool IsDebug = NinjaTrader.Cbi.License.MachineId.CompareTo("1E53E271B82EC62C7C03A15C336229AE")==0 && System.IO.File.Exists("c:\\222222222222.txt");
			AddPlot(new Stroke(Brushes.Navy,2), PlotStyle.Line, "Lvl");

			IsChartOnly=true;
			IsAutoScale=false;
			Calculate=Calculate.OnBarClose;
			DisplayInDataBox	= false;
			IsOverlay=true;
			Name = "ARC_Big Round Numbers";
		}
		if(State == State.Configure){
			IsDebug = System.IO.File.Exists(@"c:\222222222222.txt") && (NinjaTrader.Cbi.License.MachineId.CompareTo("1E53E271B82EC62C7C03A15C336229AE")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
			#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
			#endregion
		}
		if (State == State.DataLoaded){
			if(pIntervalType == ARC_BigRoundNumbers_IntervalType.Points){
				if(pIntervalInPts<TickSize*2) Interval_points = TickSize*2;
				else Interval_points = pIntervalInPts;
			}else if(pIntervalType == ARC_BigRoundNumbers_IntervalType.Ticks){
				Interval_points = Math.Max(2,pIntervalInTicks) * TickSize;
			}else if(pIntervalType == ARC_BigRoundNumbers_IntervalType.Pips){
				Interval_points = Math.Max(1,pIntervalInPips)*10*TickSize;
			}
			RegionBrush = pRegionBrush.Clone();
			RegionBrush.Opacity = pRegionOpacity/100.0;
			RegionBrush.Freeze();

//			SpecificLevel1RegionBrush = pRegionLevel1Brush.Clone();
//			SpecificLevel1RegionBrush.Opacity = pRegion1Opacity/10.0;
//			SpecificLevel1RegionBrush.Freeze();

//			SpecificLevel2RegionBrush = pRegionLevel2Brush.Clone();
//			SpecificLevel2RegionBrush.Opacity = pRegion2Opacity/10.0;
//			SpecificLevel2RegionBrush.Freeze();

//			SpecificLevel3RegionBrush = pRegionLevel3Brush.Clone();
//			SpecificLevel3RegionBrush.Opacity = pRegion3Opacity/10.0;
//			SpecificLevel3RegionBrush.Freeze();

//			SpecificLevel4RegionBrush = pRegionLevel4Brush.Clone();
//			SpecificLevel4RegionBrush.Opacity = pRegion4Opacity/10.0;
//			SpecificLevel4RegionBrush.Freeze();

//			SpecificLevel5RegionBrush = pRegionLevel5Brush.Clone();
//			SpecificLevel5RegionBrush.Opacity = pRegion5Opacity/10.0;
//			SpecificLevel5RegionBrush.Freeze();
		}
		#endregion
	}

	protected override void OnBarUpdate()
	{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif

		if(RunInit && CurrentBar>Bars.Count-5) {
			RunInit = false;

			if(pDrawAsHorizontalLines){
				double price = pBasePrice;
				double minPrice = double.MaxValue;
				for(int abar = 0; abar<Bars.Count-2; abar++){
					if(Bars.GetLow(abar) < minPrice) minPrice = Bars.GetLow(abar);
				}
				while(price>minPrice*0.9) price = price - Interval_points;
				while(price < Close[0]*2) {
					price = price + Interval_points;
					Draw.HorizontalLine(this, price.ToString(),false,price,Plots[0].Brush,DashStyleHelper.Dash,2);
				}
//				if(pLevel1>0)
//					Draw.HorizontalLine(this, pLevel1.ToString(),false,pLevel1,SpecificLevel1RegionBrush,DashStyleHelper.Dash,2);
//				if(pLevel2>0)
//					Draw.HorizontalLine(this, pLevel2.ToString(),false,pLevel2,SpecificLevel2RegionBrush,DashStyleHelper.Dash,2);
//				if(pLevel3>0)
//					Draw.HorizontalLine(this, pLevel3.ToString(),false,pLevel3,SpecificLevel3RegionBrush,DashStyleHelper.Dash,2);
//				if(pLevel4>0)
//					Draw.HorizontalLine(this, pLevel4.ToString(),false,pLevel4,SpecificLevel4RegionBrush,DashStyleHelper.Dash,2);
//				if(pLevel5>0)
//					Draw.HorizontalLine(this, pLevel5.ToString(),false,pLevel5,SpecificLevel5RegionBrush,DashStyleHelper.Dash,2);
			}
		}
	}
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
	protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
		if (!IsVisible) return;
		double minPrice = chartScale.MinValue; double maxPrice = chartScale.MaxValue;
		base.OnRender(chartControl, chartScale);
		Point PanelUpperLeftPoint	= new Point(ChartPanel.X, ChartPanel.Y);
		Point PanelLowerRightPoint	= new Point(ChartPanel.X + ChartPanel.W, ChartPanel.Y + ChartPanel.H);
		int firstBarPainted = ChartBars.FromIndex;
		int lastBarPainted = ChartBars.ToIndex;

		try{
			float RegionHeight = pRegionSizeInTicks * (chartScale.GetYByValue(0) - chartScale.GetYByValue(TickSize));
			float HalfOfRegionHeight = Convert.ToSingle((pRegionSizeType == ARC_BigRoundNumbers_RegionType.Ticks ? RegionHeight : pRegionSizeInPixels))/2.0f;
			double price = BasePrice_calibrated;
			if(BasePrice_calibrated == double.MinValue){//the calibrated price is the first key price level below the current min price of the chart
				//performing this calibration will optimize the hunt for key levels...instead of using the "pBasePrice", we're finding a key price closer to the market
				price = pBasePrice;
				if(LastMinPrice > chartScale.MinValue-Interval_points || LastMinPrice > chartScale.MinValue-Interval_points){
					price = pBasePrice;
					if(price>minPrice){
						while(price>minPrice) price = price - Interval_points;
					}else{
						while(price<minPrice) price = price + Interval_points;
						price = price - Interval_points;
					}
					LastMinPrice = price - Interval_points;
				}else
					price = LastMinPrice;
				BasePrice_calibrated = price;
			}
			if(price>minPrice){
				while(price>minPrice) price = price - Interval_points;//find the first price level below the min price of the chart
			}

			int x2 = ChartPanel.W;
			int y1 = 0;
			var rect = new SharpDX.RectangleF(0, 0, ChartPanel.W, (pRegionSizeType == ARC_BigRoundNumbers_RegionType.Ticks ? RegionHeight : pRegionSizeInPixels));
			var v1 = new SharpDX.Vector2(0,y1);
			var v2 = new SharpDX.Vector2(x2,y1);
			var regionBrush = RegionBrush.ToDxBrush(RenderTarget);
			while(price<=maxPrice) {
				price = price + Interval_points;

				y1 = chartScale.GetYByValue( price);
				if(pRegionOpacity>0){
					rect.Y = y1-HalfOfRegionHeight;
					RenderTarget.FillRectangle(rect,regionBrush);
				}
				if(!pDrawAsHorizontalLines){
					v1.Y = y1;
					v2.X = x2;
					v2.Y = y1;
					RenderTarget.DrawLine(v1, v2, Plots[0].BrushDX, Plots[0].Width);
				}
			}
//			if(pLevel1>0 && pLevel1 >= minPrice && pLevel1 <= maxPrice) {
//				y1 = chartScale.GetYByValue( maxPrice);
//				if(!pDrawAsHorizontalLines){
//					v1.Y = y1;
//					v2.X = x2;
//					v2.Y = y1;
//					RenderTarget.DrawLine(v1,v2, Plots[0].BrushDX, Plots[0].Width);
//				}
//				rect.Y = y1-HalfOfRegionHeight;
//				RenderTarget.FillRectangle(rect,SpecificLevel1RegionBrush.ToDxBrush(RenderTarget));
//			}
//			if(pLevel2>0 && pLevel2 >= minPrice && pLevel2 <= maxPrice) {
//				y1 = chartScale.GetYByValue( maxPrice);
//				if(!pDrawAsHorizontalLines){
//					v1.Y = y1;
//					v2.X = x2;
//					v2.Y = y1;
//					RenderTarget.DrawLine(v1,v2, Plots[0].BrushDX, Plots[0].Width);
//				}
//				rect.Y = y1-HalfOfRegionHeight;
//				RenderTarget.FillRectangle(rect,SpecificLevel2RegionBrush.ToDxBrush(RenderTarget));
//			}
//			if(pLevel3>0 && pLevel3 >= minPrice && pLevel3 <= maxPrice) {
//				y1 = chartScale.GetYByValue( maxPrice);
//				if(!pDrawAsHorizontalLines){
//					v1.Y = y1;
//					v2.X = x2;
//					v2.Y = y1;
//					RenderTarget.DrawLine(v1,v2, Plots[0].BrushDX, Plots[0].Width);
//				}
//				rect.Y = y1-HalfOfRegionHeight;
//				RenderTarget.FillRectangle(rect,SpecificLevel3RegionBrush.ToDxBrush(RenderTarget));
//			}
//			if(pLevel4>0 && pLevel4 >= minPrice && pLevel4 <= maxPrice) {
//				y1 = chartScale.GetYByValue( maxPrice);
//				if(!pDrawAsHorizontalLines){
//					v1.Y = y1;
//					v2.X = x2;
//					v2.Y = y1;
//					RenderTarget.DrawLine(v1,v2, Plots[0].BrushDX, Plots[0].Width);
//				}
//				rect.Y = y1-HalfOfRegionHeight;
//				RenderTarget.FillRectangle(rect,SpecificLevel4RegionBrush.ToDxBrush(RenderTarget));
//			}
//			if(pLevel5>0 && pLevel5 >= minPrice && pLevel5 <= maxPrice) {
//				y1 = chartScale.GetYByValue( maxPrice);
//				if(!pDrawAsHorizontalLines){
//					v1.Y = y1;
//					v2.X = x2;
//					v2.Y = y1;
//					RenderTarget.DrawLine(v1,v2, Plots[0].BrushDX, Plots[0].Width);
//				}
//				rect.Y = y1-HalfOfRegionHeight;
//				RenderTarget.FillRectangle(rect,SpecificLevel5RegionBrush.ToDxBrush(RenderTarget));
//			}

} catch (Exception err){Print(err.ToString());}
		}
		//========================================================================================================


		
        #region Plot
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public Series<double> Lvl
        {
            get { return Values[0]; }
        }
		#endregion


		#region -- Specific Levels ==
		private double pLevel1 = 0;
		private double pLevel2 = 0;
		private double pLevel3 = 0;
		private double pLevel4 = 0;
		private double pLevel5 = 0;
//        [Description("Specific, user-defined levels to insert into chart")]
//        [Category("SpecificLevels")]
//        public double     Level1
//        {
//			get { return pLevel1; }
//			set {        pLevel1 = value; }
//        }
//        [Description("Specific, user-defined levels to insert into chart")]
//        [Category("SpecificLevels")]
//        public double     Level2
//        {
//			get { return pLevel2; }
//			set {        pLevel2 = value; }
//        }
//        [Description("Specific, user-defined levels to insert into chart")]
//        [Category("SpecificLevels")]
//        public double     Level3
//        {
//			get { return pLevel3; }
//			set {        pLevel3 = value; }
//        }
//		[Description("Specific, user-defined levels to insert into chart")]
//		[Category("SpecificLevels")]
//		public double     Level4
//		{
//			get { return pLevel4; }
//			set {        pLevel4 = value; }
//		}
//		[Description("Specific, user-defined levels to insert into chart")]
//		[Category("SpecificLevels")]
// 		public double     Level5
// 		{
//			get { return pLevel5; }
//			set {        pLevel5 = value; }
//		}
		
		private Brush pRegionLevel1Brush = Brushes.Purple;
		private Brush pRegionLevel2Brush = Brushes.Purple;
		private Brush pRegionLevel3Brush = Brushes.Purple;
		private Brush pRegionLevel4Brush = Brushes.Purple;
		private Brush pRegionLevel5Brush = Brushes.Purple;
//		[XmlIgnore()]
//		[Description("")]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Region Level1",  GroupName = "SpecificLevels")]
//		public Brush Region1_Brush{	get { return pRegionLevel1Brush; }	set { pRegionLevel1Brush = value; }		}
//					[Browsable(false)]
//					public string Region1ClSerialize
//					{	get { return Serialize.BrushToString(pRegionLevel1Brush); } set { pRegionLevel1Brush = Serialize.StringToBrush(value); }
//					}
//		[XmlIgnore()]
//		[Description("")]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Region Level2",  GroupName = "SpecificLevels")]
//		public Brush Region2_Brush{	get { return pRegionLevel2Brush; }	set { pRegionLevel2Brush = value; }		}
//					[Browsable(false)]
//					public string Region2ClSerialize
//					{	get { return Serialize.BrushToString(pRegionLevel2Brush); } set { pRegionLevel2Brush = Serialize.StringToBrush(value); }
//					}
//		[XmlIgnore()]
//		[Description("")]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Region Level3",  GroupName = "SpecificLevels")]
//		public Brush Region3_Brush{	get { return pRegionLevel3Brush; }	set { pRegionLevel3Brush = value; }		}
//					[Browsable(false)]
//					public string Region3ClSerialize
//					{	get { return Serialize.BrushToString(pRegionLevel3Brush); } set { pRegionLevel3Brush = Serialize.StringToBrush(value); }
//					}
//		[XmlIgnore()]
//		[Description("")]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Region Level4",  GroupName = "SpecificLevels")]
//		public Brush Region4_Brush{	get { return pRegionLevel4Brush; }	set { pRegionLevel4Brush = value; }		}
//					[Browsable(false)]
//					public string Region4ClSerialize
//					{	get { return Serialize.BrushToString(pRegionLevel4Brush); } set { pRegionLevel4Brush = Serialize.StringToBrush(value); }
//					}
//		[XmlIgnore()]
//		[Description("")]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Region Level5",  GroupName = "SpecificLevels")]
//		public Brush Region5_Brush{	get { return pRegionLevel5Brush; }	set { pRegionLevel5Brush = value; }		}
//					[Browsable(false)]
//					public string Region5ClSerialize
//					{	get { return Serialize.BrushToString(pRegionLevel5Brush); } set { pRegionLevel5Brush = Serialize.StringToBrush(value); }
//					}

		private int pRegion1Opacity = 4;
		private int pRegion2Opacity = 4;
		private int pRegion3Opacity = 4;
		private int pRegion4Opacity = 4;
		private int pRegion5Opacity = 4;
//		[Description("Opacity of Line1 colored region.  0 is transparent, 10 is solid")]
//		[Category("SpecificLevels")]
//		public int Region1Opacity
//		{
//			get { return pRegion1Opacity; }
//			set { pRegion1Opacity = Math.Max(0,Math.Min(10,value)); }
//		}
//		[Description("Opacity of Line2 colored region.  0 is transparent, 10 is solid")]
//		[Category("SpecificLevels")]
//		public int Region2Opacity
//		{
//			get { return pRegion2Opacity; }
//			set { pRegion2Opacity = Math.Max(0,Math.Min(10,value)); }
//		}
//		[Description("Opacity of Line3 colored region.  0 is transparent, 10 is solid")]
//		[Category("SpecificLevels")]
//		public int Region3Opacity
//		{
//			get { return pRegion3Opacity; }
//			set { pRegion3Opacity = Math.Max(0,Math.Min(10,value)); }
//		}
//		[Description("Opacity of Line4 colored region.  0 is transparent, 10 is solid")]
//		[Category("SpecificLevels")]
//		public int Region4Opacity
//		{
//			get { return pRegion4Opacity; }
//			set { pRegion4Opacity = Math.Max(0,Math.Min(10,value)); }
//		}
//		[Description("Opacity of Line5 colored region.  0 is transparent, 10 is solid")]
//		[Category("SpecificLevels")]
//		public int Region5Opacity
//		{
//			get { return pRegion5Opacity; }
//			set { pRegion5Opacity = Math.Max(0,Math.Min(10,value)); }
//		}

		#endregion

		private double pBasePrice = 0.00;
        [Description("Base price...the price from which all lines eminate at Interval values")]
        [Display(Order = 10, Name = "Base Price", GroupName = "Parameters")]
        public double BasePrice
        {
            get { return pBasePrice; }
            set { pBasePrice = value; }
        }

		private ARC_BigRoundNumbers_IntervalType pIntervalType = ARC_BigRoundNumbers_IntervalType.Points;
        [Description("Interval type")]
        [Display(Order = 30, Name = "Interval type", GroupName = "Parameters")]
        public ARC_BigRoundNumbers_IntervalType IntervalType
        {
            get { return pIntervalType; }
            set { pIntervalType = value; }
        }

		private double pIntervalInPts = 10;
        [Description("Interval (in points) between lines")]
        [Display(Order = 31, Name = "Interval in pts", GroupName = "Parameters")]
        public double IntervalInPts
        {
            get { return pIntervalInPts; }
            set { pIntervalInPts = Math.Max(0,value); }
        }
		private double pIntervalInTicks = 10;
        [Description("Interval (in ticks) between lines")]
        [Display(Order = 32, Name = "Interval in ticks", GroupName = "Parameters")]
        public double IntervalInTicks
        {
            get { return pIntervalInTicks; }
            set { pIntervalInTicks = Math.Max(2,value); }
        }
		private double pIntervalInPips = 1;
        [Description("Interval (in Pips) between lines (a pip is 10x a tick)")]
        [Display(Order = 33, Name = "Interval in Pips", GroupName = "Parameters")]
        public double IntervalInPips
        {
            get { return pIntervalInPips; }
            set { pIntervalInPips = Math.Max(1,value); }
        }

		#region -- Level Visuals --
		private Brush pRegionBrush = Brushes.Gold;
		[XmlIgnore()]
		[Description("Color of all auto-generated regions")]
		[Display(Order = 10, ResourceType = typeof(Custom.Resource), Name = "Highlight Color",  GroupName = "Level Visuals")]
		public Brush Region_Brush{	get { return pRegionBrush; }	set { pRegionBrush = value; }		}
					[Browsable(false)]
					public string RegionClSerialize
					{	get { return Serialize.BrushToString(pRegionBrush); } set { pRegionBrush = Serialize.StringToBrush(value); }
					}

		private ARC_BigRoundNumbers_RegionType pRegionSizeType = ARC_BigRoundNumbers_RegionType.Ticks;
        [Description("Size of colored highlight region around the round number lines, in ticks")]
        [Display(Order = 21, Name = "Highlight Thickness Type", GroupName = "Level Visuals")]
        public ARC_BigRoundNumbers_RegionType RegionSizeType
        {
            get { return pRegionSizeType; }
            set { pRegionSizeType = value; }
        }
		private int pRegionSizeInTicks = 1;
        [Description("Size of colored highlight region around the round number lines, in ticks")]
        [Display(Order = 22, Name = "Highlight Thickness Ticks", GroupName = "Level Visuals")]
        public int RegionSizeInTicks
        {
            get { return pRegionSizeInTicks; }
            set { pRegionSizeInTicks = Math.Max(0,value); }
        }
		private int pRegionSizeInPixels = 5;
        [Description("Size of colored highlight region around the round number lines, in screen pixels")]
        [Display(Order = 23, Name = "Highlight Thickness Pixels", GroupName = "Level Visuals")]
        public int RegionSizeInPixels
        {
            get { return pRegionSizeInPixels; }
            set { pRegionSizeInPixels = Math.Max(0,value); }
        }
		private int pRegionOpacity = 0;
		[Description("Opacity of colored region around the round number lines.  0 is transparent, 100 is solid")]
        [Display(Order = 30, Name = "Highlight Opacity", GroupName = "Level Visuals")]
		public int Region_Opacity
		{
			get { return pRegionOpacity; }
			set { pRegionOpacity = Math.Max(0,Math.Min(100,value)); }
		}
		private bool pDrawAsHorizontalLines = false;
        [Description("If you have graphics issues, then choose to draw levels as Horizontal Line drawing objects")]
        [Display(Order = 40, Name = "Draw as HLine Objects", GroupName = "Level Visuals")]
        public bool DrawAsHorizontalLines
        {
			get { return pDrawAsHorizontalLines; }
			set {        pDrawAsHorizontalLines = value; }
        }

        #endregion
	}
public enum ARC_BigRoundNumbers_IntervalType {Points, Ticks, Pips}
public enum ARC_BigRoundNumbers_RegionType {Ticks, Pixels}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_BigRoundNumbers[] cacheARC_BigRoundNumbers;
		public ARC.ARC_BigRoundNumbers ARC_BigRoundNumbers()
		{
			return ARC_BigRoundNumbers(Input);
		}

		public ARC.ARC_BigRoundNumbers ARC_BigRoundNumbers(ISeries<double> input)
		{
			if (cacheARC_BigRoundNumbers != null)
				for (int idx = 0; idx < cacheARC_BigRoundNumbers.Length; idx++)
					if (cacheARC_BigRoundNumbers[idx] != null &&  cacheARC_BigRoundNumbers[idx].EqualsInput(input))
						return cacheARC_BigRoundNumbers[idx];
			return CacheIndicator<ARC.ARC_BigRoundNumbers>(new ARC.ARC_BigRoundNumbers(), input, ref cacheARC_BigRoundNumbers);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_BigRoundNumbers ARC_BigRoundNumbers()
		{
			return indicator.ARC_BigRoundNumbers(Input);
		}

		public Indicators.ARC.ARC_BigRoundNumbers ARC_BigRoundNumbers(ISeries<double> input )
		{
			return indicator.ARC_BigRoundNumbers(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_BigRoundNumbers ARC_BigRoundNumbers()
		{
			return indicator.ARC_BigRoundNumbers(Input);
		}

		public Indicators.ARC.ARC_BigRoundNumbers ARC_BigRoundNumbers(ISeries<double> input )
		{
			return indicator.ARC_BigRoundNumbers(input);
		}
	}
}

#endregion
