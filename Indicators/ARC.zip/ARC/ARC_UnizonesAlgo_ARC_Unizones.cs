using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using Brushes = System.Windows.Media.Brushes;
using RectangleF = SharpDX.RectangleF;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public class ARC_UnizonesAlgo_ARC_Unizones : ARC_UnizonesAlgo_ARCIndicatorBase
	{
		public class Unizone
		{
			public Guid Id { get; private set; } = Guid.NewGuid();
			public int Bias { get; set; }
			public int StartBar { get; set; }
			public double Y1 { get; set; }
			public double Y2 { get; set; }
			public int? BarFirstTested { get; set; }
			public int? BarBroken { get; set; }
			public double EntryPrice => Bias == 1 ? Math.Max(Y1, Y2) : Math.Min(Y1, Y2);

			public double Stop => Bias == 1 ? Math.Min(Y1, Y2) : Math.Max(Y1, Y2);
		}


		[Browsable(false), XmlIgnore]
		public List<Unizone> BrokenBlocks
		{
			get
			{
				Update();
				return brokenBlocks;
			}
		}
		private readonly List<Unizone> brokenBlocks = new List<Unizone>();

		[Browsable(false), XmlIgnore]
		public List<Unizone> FreshBlocks
		{
			get
			{
				Update();
				return freshBlocks;
			}
		}
		private readonly List<Unizone> freshBlocks = new List<Unizone>();
		
		[Browsable(false), XmlIgnore]
		public List<Unizone> TestedBlocks
		{
			get
			{
				Update();
				return testedBlocks;
			}
		}
		private readonly List<Unizone> testedBlocks = new List<Unizone>();

		public override string ProductVersion => "v1.0.7 (11/20/2023)";
		public override bool ColicensedOnly => true;

		private ATR atr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && !this.ARC_UnizonesAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				Name = "ARC_UnizonesAlgo_ARC_Unizones";
				IsOverlay = true;
				IsSuspendedWhileInactive = true;

				MaxBody = 100;
				IncludeWicksInBasingBars = true;
				MaxBasingBars = 1000;
				MaxThrustBarDelay = 0;
				MaxAgeDays = 5;
				TrapZoneSizeType = ARC_UnizonesAlgo_UnizoneSizeType.ATR;
				TrapZoneMinSize = 1;
				TrapZoneMaxSize = 1000;

				BasingBarUpBrush = Brushes.White;
				BasingBarDownBrush = Brushes.Black;
				ThrustBarUpBrush = Brushes.Lime;
				ThrustBarDownBrush = Brushes.Red;
			}
			else if (State == State.Configure)
			{
				freshBlocks.Clear();
				testedBlocks.Clear();
				brokenBlocks.Clear();
			}
			else if (State == State.DataLoaded)
			{
				atr = ATR(14);
			}
		}

		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_UnizonesAlgo_IsLicensed())
				return;

			if (CurrentBar == 0)
				return;

			// Check for first tests
			var newTestedBlocks = freshBlocks
				.Where(ob => (ob.Bias == 1 ? Low : High)[0].ApproxCompare(ob.EntryPrice) == -ob.Bias)
				.ToList();
			foreach (var ob in newTestedBlocks)
			{
				ob.BarFirstTested = CurrentBar;
				freshBlocks.Remove(ob);
				testedBlocks.Add(ob);
			}

			// Check for breaks
			var newBrokenBlocks = testedBlocks
				.Where(ob => (ob.Bias == 1 ? Low : High)[0].ApproxCompare(ob.Stop) == -ob.Bias)
				.ToList();
			foreach (var ob in newBrokenBlocks)
			{
				ob.BarBroken = CurrentBar;
				testedBlocks.Remove(ob);
				brokenBlocks.Add(ob);
			}

			// Check for timeouts
			foreach (var blocks in new[] { testedBlocks, freshBlocks })
			{
				var timedOutBlocks = blocks
					.Where(b => (Time[0] - Time.GetValueAt(b.StartBar)).TotalDays > MaxAgeDays)
					.ToList();
				foreach (var ob in timedOutBlocks)
				{
					ob.BarFirstTested ??= CurrentBar;
					ob.BarBroken = CurrentBar;
					blocks.Remove(ob);
					brokenBlocks.Add(ob);
				}
			}

			// Check for new blocks and handle any other block type specific logic
			switch (Type)
			{
			case ARC_UnizonesAlgo_UnizoneType.OrderBlock:
			{
				var dir = Close[0].ApproxCompare(Open[0]);
				if (dir == 0)
					return;

				for (var i = 1; i <= Math.Min(MaxThrustBarDelay + 1, CurrentBar); i++)
				{
					if (!IsUnderMaxBodySize(i))
						continue;

					if (Close[i].ApproxCompare(Open[i]) != -dir)
						continue;

					var unizone = new Unizone
					{
						Bias = dir, 
						StartBar = CurrentBar - i, 
						Y1 = dir == 1 ? Math.Min(Low[0], Low[i]) : Math.Max(High[0], High[i]), 
						Y2 = dir == 1 ? High[i] : Low[i]
					};
					if (freshBlocks.Concat(testedBlocks).Any(b => b.Y1.ApproxCompare(unizone.Y1) == 0 && b.Y2.ApproxCompare(unizone.Y2) == 0))
						continue;

					var delayBarsClosedInsideZone = true;
					for (var i2 = 1; i2 < i; i2++)
						if (!Close[i2].ARC_UnizonesAlgo_InRange(unizone.Y1, unizone.Y2))
						{
							delayBarsClosedInsideZone = false;
							break;
						}

					if (!delayBarsClosedInsideZone)
						continue;

					if (Close[0].ApproxCompare(dir == 1 ? High[i] : Low[i]) != dir)
						continue;

					freshBlocks.Add(unizone);
					return;
				}
				
				return;
			}
			case ARC_UnizonesAlgo_UnizoneType.SupplyAndDemand:
			{
				if (IsUnderMaxBodySize(0))
				{
					BarBrushes[0] = Close[0].ApproxCompare(Open[0]) == 1 ? BasingBarUpBrush : BasingBarDownBrush;
					return;
				}

				if (!IsUnderMaxBodySize(1))
					return;

				var dir = Close[0].ApproxCompare(Open[0]);
				if (dir == 0)
					return;

				Func<int, double> getBasingBarHigh = bar => dir == -1 || IncludeWicksInBasingBars ? High[bar] : Math.Max(Open[bar], Close[bar]);
				Func<int, double> getBasingBarLow = bar => dir == 1 || IncludeWicksInBasingBars ? Low[bar] : Math.Min(Open[bar], Close[bar]);

				var basingBarStart = 1;
				var basingBarHigh = getBasingBarHigh(1);
				var basingBarLow = getBasingBarLow(1);
				for (var i = 2; i <= CurrentBar && IsUnderMaxBodySize(i); i++)
				{
					if (i > MaxBasingBars)
						return;

					basingBarStart = i;
					var high = getBasingBarHigh(i);
					if (basingBarHigh < high)
						basingBarHigh = high;

					var low = getBasingBarLow(i);
					if (basingBarLow > low)
						basingBarLow = low;
				}

				if (Close[0].ApproxCompare(dir == 1 ? basingBarHigh : basingBarLow) != dir)
					return;

				BarBrushes[0] = dir == 1 ? ThrustBarUpBrush : ThrustBarDownBrush;

				// Opposing thrust bar wick is always included in range
				if (dir == 1)
					basingBarLow = Math.Min(basingBarLow, Low[0]);
				else
					basingBarHigh = Math.Max(basingBarHigh, High[0]);

				if (basingBarLow.ApproxCompare(basingBarHigh) == 0)
					return;

				freshBlocks.Add(new Unizone
				{
					Bias = dir, 
					StartBar = CurrentBar - basingBarStart, 
					Y1 = dir == 1 ? basingBarLow : basingBarHigh, 
					Y2 = dir == 1 ? basingBarHigh : basingBarLow
				});

				return;
			}
			case ARC_UnizonesAlgo_UnizoneType.Trap:
			{
				if (CurrentBar < 2)
					return;

				var dir = Close[1].ApproxCompare(Open[1]);
				if (dir == 0)
					return;

				if (dir == 1 ? High[2] >= Low[0] : Low[2] <= High[0])
					return;

				var zone = new Unizone
				{
					Bias = dir, 
					StartBar = CurrentBar - 1, 
					Y1 = (dir == 1 ? Low : High)[0], 
					Y2 = (dir == 1 ? High : Low)[2]
				};

				var sizeUnitSize = TrapZoneSizeType == ARC_UnizonesAlgo_UnizoneSizeType.ATR ? atr[0] : Instrument.MasterInstrument.TickSize;
				if (!Math.Abs(zone.Y1 - zone.Y2).ARC_UnizonesAlgo_InRange(TrapZoneMinSize * sizeUnitSize, TrapZoneMaxSize * sizeUnitSize))
					return;

				freshBlocks.Add(zone);
				return;
			}
			default:
				throw new ArgumentOutOfRangeException();
			}
		}

		private bool IsUnderMaxBodySize(int bar)
		{
			return Math.Abs(Close[bar] - Open[bar]) < (High[bar] - Low[bar]) * MaxBody / 100;
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			if (!this.ARC_UnizonesAlgo_IsLicensed())
				return;

			if (IsInHitTest)
				return;

			outlineBrushes.Values.ToList().ForEach(v => v.RenderTarget = RenderTarget);
			foreach (var ob in freshBlocks.Concat(testedBlocks).Concat(brokenBlocks).ToList())
			{
				// Is it vertically in frame?
				if (Math.Min(ob.Y1, ob.Y2) > chartScale.MaxValue)
					continue;
				if (Math.Max(ob.Y1, ob.Y2) < chartScale.MinValue)
					continue;

				// Is it horizontally in frame?
				if (ChartBars.ToIndex < ob.StartBar)
					continue;
				if (ob.BarBroken != null && ChartBars.FromIndex > ob.BarBroken)
					continue;

				var zoneFreshness = ARC_UnizonesAlgo_UnizoneFreshness.Fresh;
				if (ob.BarBroken != null)
					zoneFreshness = ARC_UnizonesAlgo_UnizoneFreshness.Broken;
				else if (ob.BarFirstTested != null)
					zoneFreshness = ARC_UnizonesAlgo_UnizoneFreshness.Tested;
				
				var y = chartScale.GetYByValue(Math.Min(ob.Y1, ob.Y2));
				var height = chartScale.GetYByValue(Math.Max(ob.Y1, ob.Y2)) - y;
				var x = ChartControl.GetXByBarIndex(ChartBars, ob.StartBar);
				var width = ChartControl.GetXByBarIndex(ChartBars, ob.BarBroken ?? (ChartBars.ToIndex + 1)) - x;
				var rect = new RectangleF(x, y, width, height);
				
				RenderTarget.FillRectangle(rect, ((System.Windows.Media.Brush) zoneBrushes[ob.Bias][zoneFreshness]).ToDxBrush(RenderTarget));
				RenderTarget.DrawRectangle(rect, outlineBrushes[zoneFreshness].BrushDX, outlineBrushes[zoneFreshness].Width, outlineBrushes[zoneFreshness].StrokeStyle);
			}
		}

		#region General Params
		private const string ParametersGroupName = "Parameters";
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Type", GroupName = ParametersGroupName, Order = 0)]
		public ARC_UnizonesAlgo_UnizoneType Type { get; set; }
		
		[NinjaScriptProperty, Range(double.Epsilon, 100)]
		[ARC_UnizonesAlgo_HideUnless(nameof(Type), ARC_UnizonesAlgo_PropComparisonType.NEQ, ARC_UnizonesAlgo_UnizoneType.Trap)]
		[ARC_UnizonesAlgo_Rename("Max Body %", nameof(Type), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneType.OrderBlock)]
		[ARC_UnizonesAlgo_Rename("Basing Bar Max Body %", nameof(Type), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneType.SupplyAndDemand)]
		[Display(Name = "Max Body %", GroupName = ParametersGroupName, Order = 1)]
		public double MaxBody { get; set; }
		
		[NinjaScriptProperty]
		[ARC_UnizonesAlgo_HideUnless(nameof(Type), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneType.SupplyAndDemand)]
		[Display(Name = "Include Wicks in Basing Bars", GroupName = ParametersGroupName, Order = 2)]
		public bool IncludeWicksInBasingBars { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_UnizonesAlgo_HideUnless(nameof(Type), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneType.SupplyAndDemand)]
		[Display(Name = "Max Basing Bars", GroupName = ParametersGroupName, Order = 3)]
		public int MaxBasingBars { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_UnizonesAlgo_HideUnless(nameof(Type), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneType.OrderBlock)]
		[Display(Name = "Max Thrust Bar Delay", GroupName = ParametersGroupName, Order = 4)]
		public int MaxThrustBarDelay { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Max Age Days", GroupName = ParametersGroupName, Order = 5)]
		public int MaxAgeDays { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Trap Zone Size Type", GroupName = ParametersGroupName, Order = 6)]
		public ARC_UnizonesAlgo_UnizoneSizeType TrapZoneSizeType { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_UnizonesAlgo_Rename("Trap Zone Min Size (ATR)", nameof(TrapZoneSizeType), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneSizeType.ATR)]
		[ARC_UnizonesAlgo_Rename("Trap Zone Min Size (Ticks)", nameof(TrapZoneSizeType), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneSizeType.Ticks)]
		[Display(Name = "TrapZoneMinSize", GroupName = ParametersGroupName, Order = 7)]
		public double TrapZoneMinSize { get; set; }
		
		[NinjaScriptProperty, Range(1e-5, int.MaxValue)]
		[ARC_UnizonesAlgo_Rename("Trap Zone Max Size (ATR)", nameof(TrapZoneSizeType), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneSizeType.ATR)]
		[ARC_UnizonesAlgo_Rename("Trap Zone Max Size (Ticks)", nameof(TrapZoneSizeType), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneSizeType.Ticks)]
		[Display(Name = "TrapZoneMaxSize", GroupName = ParametersGroupName, Order = 8)]
		public double TrapZoneMaxSize { get; set; }
		#endregion

		#region Visual Params
		private const string VisualParametersGroupName = "Visuals";

		internal ARC_UnizonesAlgo_DefaultingDictionary<int, ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneFreshness, ARC_UnizonesAlgo_EnhancedBrush>> zoneBrushes = new ARC_UnizonesAlgo_DefaultingDictionary<int, ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneFreshness, ARC_UnizonesAlgo_EnhancedBrush>>(dir => new ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneFreshness, ARC_UnizonesAlgo_EnhancedBrush>(f => f switch
		{
			ARC_UnizonesAlgo_UnizoneFreshness.Fresh => new ARC_UnizonesAlgo_EnhancedBrush { OpaqueBrush = dir == 1 ? Brushes.Lime : Brushes.Red, Opacity = 0.5f },
			ARC_UnizonesAlgo_UnizoneFreshness.Tested => new ARC_UnizonesAlgo_EnhancedBrush { OpaqueBrush = dir == 1 ? Brushes.Green : Brushes.Maroon, Opacity = 0.5f },
			ARC_UnizonesAlgo_UnizoneFreshness.Broken => new ARC_UnizonesAlgo_EnhancedBrush { OpaqueBrush = dir == 1 ? Brushes.Cyan : Brushes.LightCoral, Opacity = 0.25f },
			_ => throw new ArgumentOutOfRangeException(nameof(f))
		}));

		internal ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneFreshness, Stroke> outlineBrushes = new ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneFreshness, Stroke>(f => f switch
		{
			ARC_UnizonesAlgo_UnizoneFreshness.Fresh => new Stroke { Brush = Brushes.Black, Opacity = 50, DashStyleHelper = DashStyleHelper.Solid, Width = 3 },
			ARC_UnizonesAlgo_UnizoneFreshness.Tested => new Stroke { Brush = Brushes.Black, Opacity = 50, DashStyleHelper = DashStyleHelper.Solid, Width = 3 },
			ARC_UnizonesAlgo_UnizoneFreshness.Broken => new Stroke { Brush = Brushes.Black, Opacity = 50, DashStyleHelper = DashStyleHelper.Solid, Width = 3 },
			_ => throw new ArgumentOutOfRangeException(nameof(f))
		});

		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Fresh Support Color", GroupName = VisualParametersGroupName, Order = 0)]
		public ARC_UnizonesAlgo_EnhancedBrush FreshSupportBrush
		{
			get => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Fresh];
			set => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Fresh] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Tested Support Color", GroupName = VisualParametersGroupName, Order = 1)]
		public ARC_UnizonesAlgo_EnhancedBrush TestedSupportBrush
		{
			get => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Tested];
			set => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Tested] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Broken Support Color", GroupName = VisualParametersGroupName, Order = 2)]
		public ARC_UnizonesAlgo_EnhancedBrush BrokenSupportBrush
		{
			get => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Broken];
			set => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Broken] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Fresh Resistance Color", GroupName = VisualParametersGroupName, Order = 3)]
		public ARC_UnizonesAlgo_EnhancedBrush FreshResistanceBrush
		{
			get => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Fresh];
			set => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Fresh] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Tested Resistance Color", GroupName = VisualParametersGroupName, Order = 4)]
		public ARC_UnizonesAlgo_EnhancedBrush TestedResistanceBrush
		{
			get => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Tested];
			set => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Tested] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Broken Resistance Color", GroupName = VisualParametersGroupName, Order = 5)]
		public ARC_UnizonesAlgo_EnhancedBrush BrokenResistanceBrush
		{
			get => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Broken];
			set => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Broken] = value;
		}

		[Browsable(false)]
		public string SupportResistanceBrushesSerializable
		{
			get =>
				zoneBrushes.ToString('/', 
					dir => dir.ToString(), 
					zoneDict => zoneDict.ToString('\\', fresh => fresh.ToString(), brush => brush.ToString()));
			set =>
				zoneBrushes = ARC_UnizonesAlgo_DefaultingDictionary.ARC_UnizonesAlgo_FromString(value, '/', 
					int.Parse, 
					freshDict => ARC_UnizonesAlgo_DefaultingDictionary.ARC_UnizonesAlgo_FromString(freshDict, '\\', 
						fresh => (ARC_UnizonesAlgo_UnizoneFreshness) Enum.Parse(typeof(ARC_UnizonesAlgo_UnizoneFreshness), fresh), 
						brush => (ARC_UnizonesAlgo_EnhancedBrush) brush));
		}

		[Display(Name = "Fresh Outline Color", GroupName = VisualParametersGroupName, Order = 6)]
		public Stroke FreshOutlineBrush
		{
			get => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Fresh];
			set => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Fresh] = value;
		}
		
		[Display(Name = "Tested Outline Color", GroupName = VisualParametersGroupName, Order = 7)]
		public Stroke TestedOutlineBrush
		{
			get => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Tested];
			set => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Tested] = value;
		}
		
		[Display(Name = "Broken Outline Color", GroupName = VisualParametersGroupName, Order = 8)]
		public Stroke BrokenOutlineBrush
		{
			get => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Broken];
			set => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Broken] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Basing Bar Up Color", GroupName = VisualParametersGroupName, Order = 201)]
		public ARC_UnizonesAlgo_EnhancedBrush BasingBarUpBrush { get; set; }
		
		[Browsable(false)]
		public string BasingBarUpBrushSerializable
		{
			get => BasingBarUpBrush;
			set => BasingBarUpBrush = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Basing Bar Down Color", GroupName = VisualParametersGroupName, Order = 202)]
		public ARC_UnizonesAlgo_EnhancedBrush BasingBarDownBrush { get; set; }
		
		[Browsable(false)]
		public string BasingBarDownBrushSerializable
		{
			get => BasingBarDownBrush;
			set => BasingBarDownBrush = value;
		}

		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Thrust Bar Up Color", GroupName = VisualParametersGroupName, Order = 203)]
		public ARC_UnizonesAlgo_EnhancedBrush ThrustBarUpBrush { get; set; }
		
		[Browsable(false)]
		public string ThrustBarUpBrushSerializable
		{
			get => ThrustBarUpBrush;
			set => ThrustBarUpBrush = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Thrust Bar Down Color", GroupName = VisualParametersGroupName, Order = 204)]
		public ARC_UnizonesAlgo_EnhancedBrush ThrustBarDownBrush { get; set; }
		
		[Browsable(false)]
		public string ThrustBarDownBrushSerializable
		{
			get => ThrustBarDownBrush;
			set => ThrustBarDownBrush = value;
		}
		#endregion
	}
}

internal enum ARC_UnizonesAlgo_UnizoneFreshness
{
	Fresh,
	Tested,
	Broken
}

public enum ARC_UnizonesAlgo_UnizoneType
{
	OrderBlock,
	SupplyAndDemand,
	Trap
}

public enum ARC_UnizonesAlgo_UnizoneSizeType
{
	ATR,
	Ticks
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_UnizonesAlgo_ARC_Unizones[] cacheARC_Unizones;
		public ARC.ARC_UnizonesAlgo_ARC_Unizones ARC_UnizonesAlgo_ARC_Unizones(ARC_UnizonesAlgo_UnizoneType type, double maxBody, bool includeWicksInBasingBars, int maxBasingBars, int maxThrustBarDelay, int maxAgeDays, ARC_UnizonesAlgo_UnizoneSizeType trapZoneSizeType, double trapZoneMinSize, double trapZoneMaxSize)
		{
			return ARC_UnizonesAlgo_ARC_Unizones(Input, type, maxBody, includeWicksInBasingBars, maxBasingBars, maxThrustBarDelay, maxAgeDays, trapZoneSizeType, trapZoneMinSize, trapZoneMaxSize);
		}

		public ARC.ARC_UnizonesAlgo_ARC_Unizones ARC_UnizonesAlgo_ARC_Unizones(ISeries<double> input, ARC_UnizonesAlgo_UnizoneType type, double maxBody, bool includeWicksInBasingBars, int maxBasingBars, int maxThrustBarDelay, int maxAgeDays, ARC_UnizonesAlgo_UnizoneSizeType trapZoneSizeType, double trapZoneMinSize, double trapZoneMaxSize)
		{
			if (cacheARC_Unizones != null)
				for (int idx = 0; idx < cacheARC_Unizones.Length; idx++)
					if (cacheARC_Unizones[idx] != null && cacheARC_Unizones[idx].Type == type && cacheARC_Unizones[idx].MaxBody == maxBody && cacheARC_Unizones[idx].IncludeWicksInBasingBars == includeWicksInBasingBars && cacheARC_Unizones[idx].MaxBasingBars == maxBasingBars && cacheARC_Unizones[idx].MaxThrustBarDelay == maxThrustBarDelay && cacheARC_Unizones[idx].MaxAgeDays == maxAgeDays && cacheARC_Unizones[idx].TrapZoneSizeType == trapZoneSizeType && cacheARC_Unizones[idx].TrapZoneMinSize == trapZoneMinSize && cacheARC_Unizones[idx].TrapZoneMaxSize == trapZoneMaxSize && cacheARC_Unizones[idx].EqualsInput(input))
						return cacheARC_Unizones[idx];
			return CacheIndicator<ARC.ARC_UnizonesAlgo_ARC_Unizones>(new ARC.ARC_UnizonesAlgo_ARC_Unizones(){ Type = type, MaxBody = maxBody, IncludeWicksInBasingBars = includeWicksInBasingBars, MaxBasingBars = maxBasingBars, MaxThrustBarDelay = maxThrustBarDelay, MaxAgeDays = maxAgeDays, TrapZoneSizeType = trapZoneSizeType, TrapZoneMinSize = trapZoneMinSize, TrapZoneMaxSize = trapZoneMaxSize }, input, ref cacheARC_Unizones);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_UnizonesAlgo_ARC_Unizones ARC_UnizonesAlgo_ARC_Unizones(ARC_UnizonesAlgo_UnizoneType type, double maxBody, bool includeWicksInBasingBars, int maxBasingBars, int maxThrustBarDelay, int maxAgeDays, ARC_UnizonesAlgo_UnizoneSizeType trapZoneSizeType, double trapZoneMinSize, double trapZoneMaxSize)
		{
			return indicator.ARC_UnizonesAlgo_ARC_Unizones(Input, type, maxBody, includeWicksInBasingBars, maxBasingBars, maxThrustBarDelay, maxAgeDays, trapZoneSizeType, trapZoneMinSize, trapZoneMaxSize);
		}

		public Indicators.ARC.ARC_UnizonesAlgo_ARC_Unizones ARC_UnizonesAlgo_ARC_Unizones(ISeries<double> input , ARC_UnizonesAlgo_UnizoneType type, double maxBody, bool includeWicksInBasingBars, int maxBasingBars, int maxThrustBarDelay, int maxAgeDays, ARC_UnizonesAlgo_UnizoneSizeType trapZoneSizeType, double trapZoneMinSize, double trapZoneMaxSize)
		{
			return indicator.ARC_UnizonesAlgo_ARC_Unizones(input, type, maxBody, includeWicksInBasingBars, maxBasingBars, maxThrustBarDelay, maxAgeDays, trapZoneSizeType, trapZoneMinSize, trapZoneMaxSize);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_UnizonesAlgo_ARC_Unizones ARC_UnizonesAlgo_ARC_Unizones(ARC_UnizonesAlgo_UnizoneType type, double maxBody, bool includeWicksInBasingBars, int maxBasingBars, int maxThrustBarDelay, int maxAgeDays, ARC_UnizonesAlgo_UnizoneSizeType trapZoneSizeType, double trapZoneMinSize, double trapZoneMaxSize)
		{
			return indicator.ARC_UnizonesAlgo_ARC_Unizones(Input, type, maxBody, includeWicksInBasingBars, maxBasingBars, maxThrustBarDelay, maxAgeDays, trapZoneSizeType, trapZoneMinSize, trapZoneMaxSize);
		}

		public Indicators.ARC.ARC_UnizonesAlgo_ARC_Unizones ARC_UnizonesAlgo_ARC_Unizones(ISeries<double> input , ARC_UnizonesAlgo_UnizoneType type, double maxBody, bool includeWicksInBasingBars, int maxBasingBars, int maxThrustBarDelay, int maxAgeDays, ARC_UnizonesAlgo_UnizoneSizeType trapZoneSizeType, double trapZoneMinSize, double trapZoneMaxSize)
		{
			return indicator.ARC_UnizonesAlgo_ARC_Unizones(input, type, maxBody, includeWicksInBasingBars, maxBasingBars, maxThrustBarDelay, maxAgeDays, trapZoneSizeType, trapZoneMinSize, trapZoneMaxSize);
		}
	}
}

#endregion
