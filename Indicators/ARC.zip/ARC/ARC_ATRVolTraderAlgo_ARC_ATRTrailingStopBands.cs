using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using SharpDX;
using SharpDX.Direct2D1;
using Brush = System.Windows.Media.Brush;

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[ARC_ATRVolTraderAlgo_CoLicenses(typeof(ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop))]
	public class ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands : ARC_ATRVolTraderAlgo_ARCIndicatorBase
	{
		public override string ProductVersion { get { return "v1.0.1 (5/4/2023)"; } }
		public override bool ColicensedOnly { get { return true; } }

		private ATR bandOffsetAtr;
		private Series<int> bias;
		private ATR atr;
		private Series<double> centerLine;
		private Series<double> bandOffsetAtrStore;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && !this.ARC_ATRVolTraderAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				IsOverlay = true;

				Period = 14;
				Multiplier = 1;
				BandPeriod = 14;
				BandMultiplier = 1;
				BandBrush = Brushes.Blue;
				BandOpacity = 25;
			}
			else if (State == State.Configure)
			{
				SetZOrder(-100);
			}
			else if (State == State.DataLoaded)
			{
				atr = ATR(Period);
				bias = new Series<int>(this, MaximumBarsLookBack.Infinite);
				centerLine = new Series<double>(this, MaximumBarsLookBack.Infinite);
				bandOffsetAtrStore = new Series<double>(this, MaximumBarsLookBack.Infinite);
				bandOffsetAtr = ATR(BandPeriod);
			}
		}

		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_ATRVolTraderAlgo_IsLicensed())
				return;

			ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop.ARC_ATRVolTraderAlgo_UpdateValue(this, centerLine, bias, atr, Multiplier, RoundToNearestTick);
			bandOffsetAtrStore[0] = bandOffsetAtr[0];
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			if (!this.ARC_ATRVolTraderAlgo_IsLicensed() || IsInHitTest)
				return;

			var oldAaMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
			try
			{
				var lowBoundingPoints = new List<Vector2>();
				var highBoundingPoints = new List<Vector2>();
				var visibleRangeEnd = Math.Min(ChartBars.Count - (State == State.Realtime ? 2 : 1), ChartBars.ToIndex + 1);
				using (var bandFillBrush = BandBrush.ToDxBrush(RenderTarget, BandOpacity / 100f))
				using (var bandOutlineBrush = BandBrush.ToDxBrush(RenderTarget, BandOpacity / 100f))
					for (var i = Math.Max(0, ChartBars.FromIndex - 1); i <= visibleRangeEnd; i++)
					{
						if (!bias.IsValidDataPointAt(i))
							continue;

						var offsetVector = new Vector2(0, chartScale.GetPixelsForDistance(bandOffsetAtrStore.GetValueAt(i) * BandMultiplier));
						var midlinePoint = new Vector2(chartControl.GetXByBarIndex(ChartBars, i), chartScale.GetYByValue(centerLine.GetValueAt(i)));
						highBoundingPoints.Add(midlinePoint + offsetVector);
						lowBoundingPoints.Insert(0, midlinePoint - offsetVector);

						if (highBoundingPoints.Count == 1 || (i != visibleRangeEnd && bias.GetValueAt(i) == bias.GetValueAt(i + 1)))
							continue;

						RenderTarget.ARC_ATRVolTraderAlgo_DrawRegion(false, bandOutlineBrush, bandFillBrush, lowBoundingPoints.Concat(highBoundingPoints).ToArray());
						highBoundingPoints.Clear();
						lowBoundingPoints.Clear();
					}
			}
			finally
			{
				if (RenderTarget != null)
					RenderTarget.AntialiasMode = oldAaMode;
			}
		}

		#region Properties
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", Order = 0, GroupName = "NinjaScriptParameters")]
		public int Period { get; set; }

		[Range(double.Epsilon, double.MaxValue), NinjaScriptProperty]
		[Display(Name = "Multiplier", Order = 1, GroupName = "Parameters")]
		public double Multiplier { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Round to Tick", Order = 2, GroupName = "Parameters", Description = "Round the band levels to the nearest tick?")]
		public bool RoundToNearestTick { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Band ATR Period", Order = 3, GroupName = "Parameters", Description = "Lookback period for the ATR for band calculation")]
		public int BandPeriod { get; set; }

		[Range(double.Epsilon, double.MaxValue), NinjaScriptProperty]
		[Display(Name = "Band Multiplier", Order = 4, GroupName = "Parameters")]
		public double BandMultiplier { get; set; }

		[XmlIgnore]
		[Display(Name = "Band Color", Order = 5, GroupName = "Parameters")]
		public Brush BandBrush { get; set; }

		[Browsable(false)]
		public string BandBrushSerializable
		{
			get { return Serialize.BrushToString(BandBrush); }
			set { BandBrush = Serialize.StringToBrush(value); }
		}

		[Range(0, 100)]
		[Display(Name = "Band Opacity", Order = 6, GroupName = "Parameters", Description = "Round the band levels to the nearest tick?")]
		public int BandOpacity { get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands[] cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands;
		public ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(int period, double multiplier, bool roundToNearestTick, int bandPeriod, double bandMultiplier)
		{
			return ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(Input, period, multiplier, roundToNearestTick, bandPeriod, bandMultiplier);
		}

		public ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(ISeries<double> input, int period, double multiplier, bool roundToNearestTick, int bandPeriod, double bandMultiplier)
		{
			if (cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands != null)
				for (int idx = 0; idx < cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands.Length; idx++)
					if (cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands[idx] != null && cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands[idx].Period == period && cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands[idx].Multiplier == multiplier && cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands[idx].RoundToNearestTick == roundToNearestTick && cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands[idx].BandPeriod == bandPeriod && cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands[idx].BandMultiplier == bandMultiplier && cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands[idx].EqualsInput(input))
						return cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands[idx];
			return CacheIndicator<ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands>(new ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(){ Period = period, Multiplier = multiplier, RoundToNearestTick = roundToNearestTick, BandPeriod = bandPeriod, BandMultiplier = bandMultiplier }, input, ref cacheARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(int period, double multiplier, bool roundToNearestTick, int bandPeriod, double bandMultiplier)
		{
			return indicator.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(Input, period, multiplier, roundToNearestTick, bandPeriod, bandMultiplier);
		}

		public Indicators.ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(ISeries<double> input , int period, double multiplier, bool roundToNearestTick, int bandPeriod, double bandMultiplier)
		{
			return indicator.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(input, period, multiplier, roundToNearestTick, bandPeriod, bandMultiplier);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(int period, double multiplier, bool roundToNearestTick, int bandPeriod, double bandMultiplier)
		{
			return indicator.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(Input, period, multiplier, roundToNearestTick, bandPeriod, bandMultiplier);
		}

		public Indicators.ARC.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(ISeries<double> input , int period, double multiplier, bool roundToNearestTick, int bandPeriod, double bandMultiplier)
		{
			return indicator.ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(input, period, multiplier, roundToNearestTick, bandPeriod, bandMultiplier);
		}
	}
}

#endregion
