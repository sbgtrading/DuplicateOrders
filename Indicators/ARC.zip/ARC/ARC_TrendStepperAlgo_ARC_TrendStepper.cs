#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;

#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[Browsable(true)]
	public class ARC_TrendStepperAlgo_ARC_TrendStepper : ARC_TrendStepperAlgo_ARCIndicatorBase
	{
		public override string ProductVersion { get { return "v1.0.0 (3/21/2023)"; } }
		public override bool ColicensedOnly { get { return true; } }

		public int LastMovementDir
		{
			get
			{
				Update();
				return trendDir;
			}
		}

		private Brush upBrush = Brushes.Green;
		private Brush downBrush = Brushes.Maroon;

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State == State.SetDefaults)
			{
				IsOverlay = true;
				IsSuspendedWhileInactive = true;

				StepSize = 4;
				UpBrush = Brushes.Green;
				DownBrush = Brushes.Red;
				AddPlot(new Stroke(Brushes.Gold, 2), PlotStyle.Square, "Value");
			}
			else if (State == State.Configure)
			{
				trendDir = 0;
				keyValue = double.MinValue;
			}
			else if (State == State.DataLoaded)
			{
				Plots[0].Opacity = 100;
				if (BackgroundOpacity <= 0)
					return;

				upBrush = UpBrush.Clone();
				upBrush.Opacity = BackgroundOpacity / 100.0;
				upBrush.Freeze();

				downBrush = DownBrush.Clone();
				downBrush.Opacity = BackgroundOpacity / 100.0;
				downBrush.Freeze();
			}
		}

		private double keyValue = double.MinValue;
		private int trendDir;
		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_TrendStepperAlgo_IsLicensed())
				return;

			if (keyValue.ApproxCompare(double.MinValue) == 0)
			{
				keyValue = Close[0];
				Value[0] = keyValue;
				return;
			}

			var uThresh = Value[1] + TickSize * StepSize;
			var lThresh = Value[1] - TickSize * StepSize;
			var higherCloseOrOpen = Math.Max(Close[0], Open[0]);
			var lowerCloseOrOpen = Math.Min(Close[0], Open[0]);
			var isDoji = higherCloseOrOpen.ApproxCompare(lowerCloseOrOpen) == 0;
			var barDir = Close[0] > Open[0] ? 1 : -1;
			var h = trendDir == -1 ? higherCloseOrOpen : High[0];
			var l = trendDir == 1 ? lowerCloseOrOpen : Low[0];

			Value[0] = Value[1];
			if (h > uThresh && l < lThresh)
			{
				if (isDoji)
				{
					Value[0] = Value[1];
				}
				else
				{
					var upDistance = higherCloseOrOpen - Value[1];
					var downDistance = Value[1] - lowerCloseOrOpen;
					if (trendDir != -1 && barDir == 1)
						Value[0] += upDistance - downDistance;
					else if (trendDir != -1 && barDir == -1)
						Value[0] += upDistance - downDistance;
					else if (trendDir != 1 && barDir == 1)
						Value[0] += upDistance - downDistance;
					else if (trendDir != 1 && barDir == -1)
						Value[0] += upDistance - downDistance;
					Value[0] = Math.Max(lowerCloseOrOpen, Math.Min(higherCloseOrOpen, Value[0]));
				}
			}
			else if (h > uThresh)
			{
				var p1 = h - TickSize * StepSize;
				var p2 = High[1] + TickSize * StepSize;
				Value[0] = Math.Min(p1, p2);
			}
			else if (l < lThresh)
			{
				var p1 = l + TickSize * StepSize;
				var p2 = Low[1] - TickSize * StepSize;
				Value[0] = Math.Max(p1, p2);
			}
			else
			{
				Value[0] = Value[1];
			}

			if (trendDir == -1 && barDir == -1)
				Value[0] = Math.Min(Value[1], Value[0]);
			else if (trendDir == 1 && barDir == 1)
				Value[0] = Math.Max(Value[1], Value[0]);

			if (Value[0] > Value[1])
				trendDir = 1;
			else if (Value[0] < Value[1])
				trendDir = -1;

			if (BackgroundOpacity <= 0 || CurrentBar <= 3 || trendDir == 0)
				return;

			BackBrushes[0] = trendDir == 1 ? upBrush : downBrush;
		}

		#region Parameters
		#region General
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Step Size", Order = 1, GroupName = "Parameters")]
		public int StepSize { get; set; }
		#endregion

		#region Visuals
		private const string VisualGroupName = "Visuals";

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "Background Opacity", Order = 1, GroupName = VisualGroupName, Description = "0=transparent, 100=opaque")]
		public int BackgroundOpacity { get; set; }

		[XmlIgnore]
		[Display(Name = "Up Background color", Order = 2, GroupName = VisualGroupName, Description = "Color of background of up-trend")]
		public Brush UpBrush { get; set; }

		[Browsable(false)]
		public string UpBrushSerialize
		{
			get { return Serialize.BrushToString(UpBrush); }
			set { UpBrush = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Down Background color", Order = 3, GroupName = VisualGroupName, Description = "Color of background of down-trend")]
		public Brush DownBrush { get; set; }

		[Browsable(false)]
		public string DownBrushSerialize
		{
			get { return Serialize.BrushToString(DownBrush); }
			set { DownBrush = Serialize.StringToBrush(value); }
		}
		#endregion
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_TrendStepperAlgo_ARC_TrendStepper[] cacheARC_TrendStepperAlgo_ARC_TrendStepper;
		public ARC.ARC_TrendStepperAlgo_ARC_TrendStepper ARC_TrendStepperAlgo_ARC_TrendStepper(int stepSize, int backgroundOpacity)
		{
			return ARC_TrendStepperAlgo_ARC_TrendStepper(Input, stepSize, backgroundOpacity);
		}

		public ARC.ARC_TrendStepperAlgo_ARC_TrendStepper ARC_TrendStepperAlgo_ARC_TrendStepper(ISeries<double> input, int stepSize, int backgroundOpacity)
		{
			if (cacheARC_TrendStepperAlgo_ARC_TrendStepper != null)
				for (int idx = 0; idx < cacheARC_TrendStepperAlgo_ARC_TrendStepper.Length; idx++)
					if (cacheARC_TrendStepperAlgo_ARC_TrendStepper[idx] != null && cacheARC_TrendStepperAlgo_ARC_TrendStepper[idx].StepSize == stepSize && cacheARC_TrendStepperAlgo_ARC_TrendStepper[idx].BackgroundOpacity == backgroundOpacity && cacheARC_TrendStepperAlgo_ARC_TrendStepper[idx].EqualsInput(input))
						return cacheARC_TrendStepperAlgo_ARC_TrendStepper[idx];
			return CacheIndicator<ARC.ARC_TrendStepperAlgo_ARC_TrendStepper>(new ARC.ARC_TrendStepperAlgo_ARC_TrendStepper(){ StepSize = stepSize, BackgroundOpacity = backgroundOpacity }, input, ref cacheARC_TrendStepperAlgo_ARC_TrendStepper);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_TrendStepperAlgo_ARC_TrendStepper ARC_TrendStepperAlgo_ARC_TrendStepper(int stepSize, int backgroundOpacity)
		{
			return indicator.ARC_TrendStepperAlgo_ARC_TrendStepper(Input, stepSize, backgroundOpacity);
		}

		public Indicators.ARC.ARC_TrendStepperAlgo_ARC_TrendStepper ARC_TrendStepperAlgo_ARC_TrendStepper(ISeries<double> input , int stepSize, int backgroundOpacity)
		{
			return indicator.ARC_TrendStepperAlgo_ARC_TrendStepper(input, stepSize, backgroundOpacity);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_TrendStepperAlgo_ARC_TrendStepper ARC_TrendStepperAlgo_ARC_TrendStepper(int stepSize, int backgroundOpacity)
		{
			return indicator.ARC_TrendStepperAlgo_ARC_TrendStepper(Input, stepSize, backgroundOpacity);
		}

		public Indicators.ARC.ARC_TrendStepperAlgo_ARC_TrendStepper ARC_TrendStepperAlgo_ARC_TrendStepper(ISeries<double> input , int stepSize, int backgroundOpacity)
		{
			return indicator.ARC_TrendStepperAlgo_ARC_TrendStepper(input, stepSize, backgroundOpacity);
		}
	}
}

#endregion
