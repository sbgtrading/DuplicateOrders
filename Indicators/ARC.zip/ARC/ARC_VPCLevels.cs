#define DoLicense
#define MODERATORS
//#define USE_WPF_COORDS

#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using System.Threading;
using System.Globalization;
using System.Collections.Generic;
#endregion

using System.Linq;
using System.Windows;

#region Author/Copyright
/*********************************************************************
************************* Golden Zone Trading ************************
**********************************************************************
* Author NT8 : Kriss { AzurITec }
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
v0.000  - 20.06.2016    + version test. ZigZag code only no preload
----------------------------------------------------------------------
v0.001  - 22.06.2016    + version to compare Profile Algos.
----------------------------------------------------------------------
v0.002  - 23.06.2016    + Version with Profile Opti (Algo7) and Swing Profiles Merging. 
Performances : 
Loading Time for 300days of 1 minute bars and 9 TF => 13"
Total Span Algo TF[9] : 13397ms on 171465 bars => 78,13ns/bar
-		canSwing	{int[10]}	int[]
		[0]	5038	int
		[1]	2282	int
		[2]	1077	int
		[3]	456	int
		[4]	222	int
		[5]	108	int
		[6]	50	int
		[7]	23	int
		[8]	9	int
		[9]	5	int
----------------------------------------------------------------------
v0.003  - 06.07.2016    + Version Weight Calculation + R/S Selection and Plot
Total Span Algo TF[9] : 20987ms on 171091 bars => 122,67ns/bar sur 300jours 1minute bars - no preloading
----------------------------------------------------------------------
v0.004  - 07.07.2016    + Version with preloading Mintue profile only
Total Span Algo TF[9] : 926ms on 3315 bars => 279,34ns/bar sur 300jours 1minute bars - with preloading / 5days on Main
----------------------------------------------------------------------
v0.005  - 12.07.2016    + Version with Differentiate option to see each kind of level confluence
----------------------------------------------------------------------
v0.006  - 19.07.2016    + Version with Setting Watchdog
                        + Seconds Profile added (was a bug in Minute profile)   => Total Span Algo TF[9] : 2928ms on 777 bars => 3768,34ns/bar
                        + Tick Profile added (was a bug in Minute profile)      => Total Span Algo TF[9] : 6825ms on 777 bars => 8783,78ns/bar
----------------------------------------------------------------------
v0.007  - 20.07.2016    + Version with Important variables in Custom Settings
----------------------------------------------------------------------
v0.008  - 25.07.2016    + Minor Bugs correction 
----------------------------------------------------------------------
v0.009  - 27.07.2016    + Bug Fixed : When loading 3days loopback and 7days on DataSeries (= no preloading)
                        + Fix Plot/Dash style issue
----------------------------------------------------------------------
v0.010  - 28.07.2016    + Prune Parameters to most important
----------------------------------------------------------------------
v0.011  - 28.07.2016    + [BUG001] FIXED : was due to int round on FX (1.399999 became 1.39 instead of 1.40)
----------------------------------------------------------------------
v0.012  - 01.08.2016    + Added Level Extension until breakout by x time ATR
----------------------------------------------------------------------
v1.00   - 09.08.2016    + Update from Final NT7 version
                        + Level extension issue FIXED.
                        + Bench with initial version
                            -> Total Span VPCLevels_1.000 TF[9] : 579ms on 731 bars => 792,07ns/bar
                            -> Total Span VPCLevels_1.000 TF[9] : 539ms on 731 bars => 737,35ns/bar
                            -> Total Span VPCLevels_1.000 TF[9] : 530ms on 731 bars => 725,03ns/bar
----------------------------------------------------------------------
v1.01   - 10.08.2016    + Sean's Request : Extend old levels too.    
                        + First Draft :
                            -> Loading Time increased to 13s for 300days : Need to remove all unecessary code
                            -> Confluence from extended levels need to be 1 line only cause too much lines.
                            -> Need to do it for Differentiate
                        + !!! IMPORTANT !!! : Cette version est longue car elle comporte le calcul des clusters et possibilit� de MixUpDw ou pas. Les versions suivantes n'ont
                        plus ce code car ralenti trop. Cependant, il faudra repartir de cette version pour ajouter !MixUPDW et/ou clusters plus tard.
                            -> Total Span VPCLevels_1.001 TF[9] : 11670ms on 731 bars => 15�964,43ns/bar
                            -> Total Span VPCLevels_1.001 TF[9] : 15356ms on 756 bars => 20�312,17ns/bar
                            -> Total Span VPCLevels_1.001 TF[9] : 13505ms on 731 bars => 18�474,69ns/bar
----------------------------------------------------------------------
v1.02   - 10.08.2016    + Removed useless code
                            -> Total Span VPCLevels TF[9] : 3019ms on 756 bars => 3�993,39ns/bar
                            -> Total Span VPCLevels TF[9] : 3039ms on 756 bars => 4�019,84ns/bar
                            -> Total Span VPCLevels TF[9] : 3091ms on 756 bars => 4�088,62ns/bar
----------------------------------------------------------------------
v1.03   - 16.08.2016    + Finalized NT8 version after NT7 Finale version
                        + added Historical extensions confluence detection
                        + added Opacity+Width to historical extensions lines
                        + bug fixed after useless code removal
----------------------------------------------------------------------
v1.04   - 06.09.2016    + [BUG002] FIXED : when loading lots of historical, min/max window where updated only in preloading phase (few bars) but not in OnBarUpdate.
                        + Compatible Beta13 RC1
----------------------------------------------------------------------
v1.05   - 16.11.2016    + Minor Bug : Use CurrentBar instead of CurrentBars[0] in OnRender section
                        + Compatible NT8.0.1.0
----------------------------------------------------------------------
v1.06   - 01.03.2017    + Added Compilation Licensing code
                        + Tested with 8.0.4.0
----------------------------------------------------------------------
######################################################################
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ COMMENTS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
BUG001 [FIXED] : There is a bug on 6B 3ticks FullRange. 7 days load, 300days 5minute profile ZZF=4
BUG002 [FIXED] : AAPL not loading all levels (bug on NT7, same error in NT8).
TODO01 : Code still long to load (seems longer than NT7). Will see with NT8 First candidate
**********************************************************************
----------------------------------------------------------------------
v1.07   - 11.18.2017    + JQ 11.18.2017
						  BUG #12495
							Set the confLevel.pPrice to be extendedlevels[lv].pPrice instead of the
							(confLevel.pPrice * count + extendedlevels[lv].pPrice) / (count + 1)
							The old code confLevel.pPrice = (confLevel.pPrice * count + extendedlevels[lv].pPrice) / (count + 1)  
							shifted the price do the calculation it was using and it used this calculation to be the price. 
							As the extended levele are already available, the extended lines should be the extended level price 
							and not the calculated price that were used in the original code.
						+ Added indicator version number on the property window.
----------------------------------------------------------------------
*/
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region Global Enums
    public enum ARC_VPCLevels_Resolution { Smallest, Small, Default, Increased, Large, Largest }
    #endregion

    public class ARC_VPCLevels : Indicator
    {
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "VPCLevels";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "1911", "819", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsDebug = false;


        #region -- Constants --
        private const int MINDAYS = 2;
        private const double stepUpRatio = 1.5;
        private const double pVAPercent = 70;
        private double devalue = 0.8;
        private const bool usePOC = true;
        private const bool useVWAP = true;
        private const bool useVAH = true;
        private const bool useVAL = true;
		// JQ 11.18.2017
		// Added VERSION CONSTANT
		private const string VERSION = "v1.09 Apr.8.2020";

        private double ZZFACTOR = 2;
        #endregion

        #region -- variables --
        //Misc
        private SimpleFont textFont = new SimpleFont("Arial", 12);
        private string errorProfileData = "Loading of profile data is incomplete. Please refresh chart via F5 or check historical data.";
        private string errorSwingData = "Loading of minute data is incomplete. Please refresh chart via F5 or check minute data.";
        private SimpleFont textFont2 = new SimpleFont("Arial", 12);
        private List<gztExtendedLevel> extendedlevels;

        //Global
        private int cbIndex = 0;//CurrentBar index. Can be 0 if COBC or 1 if !
        private bool generalError = false;
        private double avgTrueRange = 0;
        private double displayFactor = 80.0;
        private double upperLimitSupport = double.MaxValue;
        private double lowerLimitSupport = 0;
        private double lowerLimitResistance = 0;
        private double upperLimitResistance = double.MaxValue;
        private double upperLimitWeakResistance = double.MaxValue;
        private double lowerLimitWeakSupport = 0;
        private int highestTimeFrame = 9;

        //Confluences
        private double confluenceRangeWidth = 0;

        private bool isTrainingComplete = false;
        private int currentBars1 = 0;
        private int priorCurrentBars1 = 0;

        private double tmpOpen = 0;
        private double tmpHigh = 0;
        private double tmpLow = 0;
        private double tmpClose = 0;
        private int tmpOldState = 0;
        private double tmpBOBHigh = 0.0;
        private double tmpBOBLow = 0.0;
        private double tmpBOBClose = 0.0;
        private double lowestResistance = double.MaxValue;        
        private double highestSupport = double.MinValue;
        private double tmpProValue = 0.0;

        //MTF
        private DateTime firstSessionBegin = new DateTime(0);
        private string preloadedData = "";
        private Brush textBrush = Brushes.Red;
        private bool drawPreloadInfo = false;
        private int swingBarIndex = 0;
        private int lowestTimeFrame = 0;
        
        private int profileBIP = 2;//BarsInProgress used to calculated Profile. Can be 2 or 1/0
        private bool preloadData = false;
        private Bars swingBars = null;
        private Bars profileBars = null;
        private DateTime lastSwingBarTime = new DateTime(0);

        //zigzag
        private double zigZagFactor = 0;
        private double confluenceRange = 0;

        private double currentBarHigh = 0;
        private double currentBarLow = 0;
        private double currentBarClose = 0;
        private double priorBarHigh = 0;
        private double priorBarLow = 0;
        private double priorBarClose = 0;
        private DateTime priorBarTime = new DateTime(0);

        private double currentBarTrueRange = 0;

        private double[] minimumDeviation = new double[10];
        private double[] timeFrameFactor = new double[10];
        private bool highUpdate;
        private bool lowUpdate;
        private bool addHigh;
        private bool addLow;
        private double normalizedRangeUp;
        private double normalizedRangeDown;
        private bool[] upTrend = new bool[10];

        private int[] countDown = new int[10];
        private double[] validSwingHigh = new double[10];//valid pivot high. Can't be changed after validation
        private double[] validSwingLow = new double[10];//valid pivot low. Can't be changed after validation
        private DateTime[] pivotHighBarTime = new DateTime[10];//valid high pivot time. Can't be changed after validation
        private DateTime[] pivotLowBarTime = new DateTime[10];//valid Low pivot time. Can't be changed after validation


        //Profile LEVELS
        //Levels
        private double[] POCUp = new double[10];
        private double[] VWAPUp = new double[10];
        private double[] VAHUp = new double[10];
        private double[] VALUp = new double[10];

        private double[] priorPOCUp = new double[10];
        private double[] priorVWAPUp = new double[10];
        private double[] priorVAHUp = new double[10];
        private double[] priorVALUp = new double[10];

        private double[] weightPOCUp = new double[10];
        private double[] weightVWAPUp = new double[10];
        private double[] weightVAHUp = new double[10];
        private double[] weightVALUp = new double[10];

        private double[] cumulatedWeightPOCUp = new double[10];
        private double[] cumulatedWeightVWAPUp = new double[10];
        private double[] cumulatedWeightVAHUp = new double[10];
        private double[] cumulatedWeightVALUp = new double[10];
        #endregion
		private SharpDX.Direct2D1.Brush		iPOCDXBrush = null;
		private SharpDX.Direct2D1.Brush		iVWAPDXBrush = null;
		private SharpDX.Direct2D1.Brush		iVAHDXBrush = null;
		private SharpDX.Direct2D1.Brush		iVALDXBrush = null;
		private SharpDX.Direct2D1.Brush		iSupportDXBrush = null;
		private SharpDX.Direct2D1.Brush		iResistanceDXBrush = null;

        #region -- Arrays --
        private int[] canSwing = new int[10];
        private double[] currentHigh = new double[10];
        private double[] currentLow = new double[10];
        private DateTime[] currentHighTime = new DateTime[10];
        private DateTime[] currentLowTime = new DateTime[10];

        private double[] proLine = new double[120];
        private double[] proWeight = new double[120];
        private double[] proResistance = new double[120];
        private double[] proSupport = new double[120];

        private double[] proPOCRes = new double[20];
        private double[] proPOCSup = new double[20];
        private double[] proVWAPRes = new double[20];
        private double[] proVWAPSup = new double[20];
        private double[] proVAHRes = new double[20];
        private double[] proVAHSup = new double[20];
        private double[] proVALRes = new double[20];
        private double[] proVALSup = new double[20];

        private double[] profilesLines = new double[40];
        private double[] oldProfileLines = new double[40];
        private double[] priorProfileLines = new double[40];

        private double[] POCprofilesLines = new double[20];
        private double[] oldPOCProfileLines = new double[20];
        private double[] priorPOCProfileLines = new double[20];
        private double[] VWAPprofilesLines = new double[20];
        private double[] oldVWAPProfileLines = new double[20];
        private double[] priorVWAPProfileLines = new double[20];
        private double[] VAHprofilesLines = new double[20];
        private double[] oldVAHProfileLines = new double[20];
        private double[] priorVAHProfileLines = new double[20];
        private double[] VALprofilesLines = new double[20];
        private double[] oldVALProfileLines = new double[20];
        private double[] priorVALProfileLines = new double[20];

        private int[] newState = new int[40];
        private int[] oldState = new int[40];
        private double[] newBOBHigh = new double[40];
        private double[] oldBOBHigh = new double[40];
        private double[] newBOBLow = new double[40];
        private double[] oldBOBLow = new double[40];
        private double[] newBOBClose = new double[40];
        private double[] oldBOBClose = new double[40];
        #endregion

        //------------------------ Virtuals -----------------------------------------
        public override string DisplayName { get { return "ARC_VPCLevels"; } }

        private List<double> historicalLevels = new List<double>();
        private List<double> historicalLevelsPOC = new List<double>();
        private List<double> historicalLevelsVWAP = new List<double>();
        private List<double> historicalLevelsVAH = new List<double>();
        private List<double> historicalLevelsVAL = new List<double>();
        private double highestHigh = 0;
        private double lowestLow = double.MaxValue;

        //private Stopwatch bench = new Stopwatch();
        protected override void OnStateChange()
        {
            #region State == State.SetDefaults
            if (State == State.SetDefaults)
            {
                #region -- NT UI Settings --
                Description = @"ARC_VPCLevels";
                Name = "ARC_VPCLevels";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                PaintPriceMarkers = false;
                DisplayInDataBox = false;
                IsAutoScale = false;
                ArePlotsConfigurable = false;
                ZOrder = 0;
                DrawOnPricePanel = true;
                ScaleJustification = ScaleJustification.Right;
                IsSuspendedWhileInactive = true;
                #endregion

                for (int i = 0; i < 40; i++) AddPlot(Brushes.Black, String.Format("Confluence{0}", i));
                for (int i = 40; i < 60; i++) AddPlot(Brushes.Black, String.Format("ConfPOC{0}", i));
                for (int i = 60; i < 80; i++) AddPlot(Brushes.Black, String.Format("ConfVWAP{0}", i));
                for (int i = 80; i < 100; i++) AddPlot(Brushes.Black, String.Format("ConfVAH{0}", i));
                for (int i = 100; i < 120; i++) AddPlot(Brushes.Black, String.Format("ConfVAL{0}", i));

                #region -- default parameters --
                iBarPeriod = 3;
                iLineDensity = ARC_VPCLevels_Resolution.Small;
                iThreshold = 100;
                iLookBackMinute = 300;

                iResistanceColor = Brushes.Maroon;
                iSupportColor = Brushes.Blue;

                iDifferentiate = false;

                iShowPOC = true;
                iShowVWAP = true;
                iShowVAH = true;
                iShowVAL = true;

                iPOCColor = Brushes.Yellow;
                iVWAPColor = Brushes.Cyan;
                iVAHColor = Brushes.Fuchsia;
                iVALColor = Brushes.Lime;
                iPlotStyle = PlotStyle.Line;
                iDashStyle = DashStyleHelper.Solid;
                iLineWidth = 2;

                iExtendLevels = true;
                iSRBreak = 1;
                iExtendedLineWidth = 2;
                iExtendedLineOpacity = 50;

                specificWeightPOC = 100;
                specificWeightVWAP = 90;
                specificWeightVAH = 70;
                specificWeightVAL = 70;
                #endregion
            }
            #endregion

            #region State == Configure
            else if (State == State.Configure)
            {
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
                for (int i = 0; i < 120; i++)
                {
                    if (i >= 40)
                    {
                        if (i < 60) Plots[i].Brush = iPOCColor;
                        else if (i < 80) Plots[i].Brush = iVWAPColor;
                        else if (i < 100) Plots[i].Brush = iVAHColor;
                        else Plots[i].Brush = iVALColor;
                    }

                    Plots[i].Width = iLineWidth;
                    Plots[i].PlotStyle = iPlotStyle;
                    Plots[i].DashStyleHelper = iDashStyle;
                }

                cbIndex = Calculate == Calculate.OnBarClose ? 0 : 1;

                AddDataSeries(BarsPeriodType.Minute, iBarPeriod);//Swing DataSeries
                AddDataSeries(BarsPeriodType.Minute, 1);//profile series
                profileBIP = 2;

                #region -- Init Arrays --
                for (int i = 0; i < 10; i++)
                {
                    timeFrameFactor[i] = i == 0 ? 1 : Math.Sqrt(stepUpRatio) * timeFrameFactor[i - 1];

                    upTrend[i] = true;
                    countDown[i] = -1;
                    minimumDeviation[i] = double.MaxValue;

                    validSwingHigh[i] = double.MaxValue;
                    validSwingLow[i] = double.MinValue;
                    canSwing[i] = 0;
                    currentHigh[i] = 0;
                    currentLow[i] = 0;
                    currentHighTime[i] = new DateTime(0);
                    currentLowTime[i] = new DateTime(0);
                    pivotHighBarTime[i] = new DateTime(0);
                    pivotLowBarTime[i] = new DateTime(0);

                    POCUp[i] = 0;
                    VWAPUp[i] = 0;
                    VAHUp[i] = 0;
                    VALUp[i] = 0;

                    priorPOCUp[i] = 0;
                    priorVWAPUp[i] = 0;
                    priorVAHUp[i] = 0;
                    priorVALUp[i] = 0;

                    weightPOCUp[i] = 0;
                    weightVWAPUp[i] = 0;
                    weightVAHUp[i] = 0;
                    weightVALUp[i] = 0;

                    cumulatedWeightPOCUp[i] = 0;
                    cumulatedWeightVWAPUp[i] = 0;
                    cumulatedWeightVAHUp[i] = 0;
                    cumulatedWeightVALUp[i] = 0;
                }
                for (int i = 0; i < 120; i++)
                {
                    if (i < 40)
                    {
                        oldProfileLines[i] = 0;
                        priorProfileLines[i] = 0;
                        newState[i] = 1;
                        oldState[i] = 1;

                        newBOBHigh[i] = 0.0;
                        oldBOBHigh[i] = 0.0;
                        newBOBLow[i] = 0.0;
                        oldBOBLow[i] = 0.0;
                        newBOBClose[i] = 0.0;
                        oldBOBClose[i] = 0.0;

                        if (i < 20)
                        {
                            oldPOCProfileLines[i] = 0;
                            priorPOCProfileLines[i] = 0;
                            oldVWAPProfileLines[i] = 0;
                            priorVWAPProfileLines[i] = 0;
                            oldVAHProfileLines[i] = 0;
                            priorVAHProfileLines[i] = 0;
                            oldVALProfileLines[i] = 0;
                            priorVALProfileLines[i] = 0;
                        }
                    }
                    proLine[i] = 0;
                    proWeight[i] = 0;
                }
                #endregion
            }
            #endregion

            #region State == State.DataLoaded
            else if (State == State.DataLoaded)
            {
                //bench.Start();

                #region -- calculate zigZagFactor and confluenceRange --
                zigZagFactor = Math.Max(ZZFACTOR * 2, ZZFACTOR * 4.0 / Math.Pow(iBarPeriod, 0.25));

                if (iLineDensity == ARC_VPCLevels_Resolution.Small)
                    zigZagFactor = zigZagFactor / 1.4;
                else if (iLineDensity == ARC_VPCLevels_Resolution.Smallest)
                    zigZagFactor = zigZagFactor / (1.96);
                else if (iLineDensity == ARC_VPCLevels_Resolution.Increased)
                    zigZagFactor = 1.4 * zigZagFactor;
                else if (iLineDensity == ARC_VPCLevels_Resolution.Large)
                    zigZagFactor = 1.96 * zigZagFactor;
                else if (iLineDensity == ARC_VPCLevels_Resolution.Largest)
                    zigZagFactor = 2.74 * zigZagFactor;

                confluenceRange = 0.2 * zigZagFactor;
                #endregion

                DateTime firstLdBarTime = BarsArray[1].GetTime(0);
                DateTime firstPreLdBarTime = BarsArray[1].LastBarTime.AddDays(-iLookBackMinute).Date;

                preloadData = firstPreLdBarTime.CompareTo(firstLdBarTime.Date) < 0;

                if (preloadData)
                {
                    #region -- Preload Profile Bars --
                    profileBars = loadHistoricalBars(Bars.ToDate.AddDays(-iLookBackMinute).Date, Bars.ToDate, BarsArray[profileBIP].BarsPeriod.BarsPeriodType, BarsArray[profileBIP].BarsPeriod.Value);//preload profile bars - sync code
                    if (profileBars == null || profileBars.Count <= 1)//if no historical data
                    {
                        textBrush = ChartControl.Properties.AxisPen.Brush;
                        Draw.TextFixed(this, "errortag", errorProfileData, TextPosition.Center, textBrush, textFont, Brushes.Transparent, Brushes.Transparent, 0);
                        generalError = true;
                    }
                    #endregion

                    #region -- Preload Swing Bars + Calculate Profiles --
                    if (!generalError) swingBars = loadHistoricalBars(Bars.ToDate.AddDays(-iLookBackMinute).Date, Bars.ToDate, BarsArray[1].BarsPeriod.BarsPeriodType, BarsArray[1].BarsPeriod.Value);//preload swing bars - sync code

                    if (swingBars == null || swingBars.Count <= 1)//if no historical data
                    {
                        textBrush = ChartControl.Properties.AxisPen.Brush;
                        Draw.TextFixed(this, "errortag", errorSwingData, TextPosition.Center, textBrush, textFont, Brushes.Transparent, Brushes.Transparent, 0);
                        generalError = true;
                    }
                    else
                    {
                        string minuteBarsStart = "";
                        CultureInfo minuteBarsCulture = new CultureInfo("en-us");

                        #region -- Calculate ATR and Profiles after MINSWINGBARINDEX bars --
                        while (swingBars.GetTime(swingBarIndex).CompareTo(firstLdBarTime) < 0)
                        {
                            priorBarHigh = swingBars.GetHigh(swingBarIndex);
                            priorBarLow = swingBars.GetLow(swingBarIndex);
                            priorBarClose = swingBars.GetClose(swingBarIndex);
                            priorBarTime = swingBars.GetTime(swingBarIndex);
                            
                            currentBarHigh = swingBars.GetHigh(swingBarIndex + 1);
                            currentBarLow = swingBars.GetLow(swingBarIndex + 1);
                            currentBarClose = swingBars.GetClose(swingBarIndex + 1);

                            highestHigh = Math.Max(highestHigh, currentBarHigh);//prune outside wdw
                            lowestLow = Math.Min(lowestLow, currentBarLow);//prune outside wdw

                            #region -- 1st Bar -- 
                            if (swingBarIndex == 0)
                            {
                                minuteBarsStart = swingBars.GetTime(swingBarIndex).Date.ToString("d MMM yyyy", minuteBarsCulture);
                                firstSessionBegin = swingBars.GetTime(swingBarIndex).Date;
                            }
                            #endregion

                            #region -- 2nd Bar -- 
                            else if (swingBarIndex == 1)
                            {
                                for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
                                {
                                    currentHigh[i] = priorBarHigh;
                                    currentLow[i] = priorBarLow;
                                    currentHighTime[i] = priorBarTime;
                                    currentLowTime[i] = priorBarTime;
                                }
                                currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                                avgTrueRange = currentBarTrueRange;
                            }
                            #endregion

                            #region -- All Following Bars --
                            else
                            {
                                currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                                avgTrueRange = avgTrueRange * (swingBarIndex - 1) / swingBarIndex + currentBarTrueRange / swingBarIndex;
                                if (swingBars.GetTime(swingBarIndex + 1).CompareTo(firstSessionBegin.AddDays(MINDAYS)) > 0)
                                {
                                    for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
                                        CalculateSwingProfilesMixUpDw(i, true);
                                    isTrainingComplete = true;
                                }

                                //==============================================================================================================================
                                // Sets all lines and weights within the display range
                                // Note : this is the hot path. It takes on average 1ms to run for each bar. On a 5 days 1Min barchart = 37000 bars, it takes 3.7s to run.
                                //==============================================================================================================================
                                if (!iDifferentiate) SetLinesAndWeights();
                                else SetLinesAndWeightsWithDifferentiate();

                                //==============================================================================================================================
                                // Selects strong and weak lines above defined theshold for weight and checks whether wekaer lines are in the smaller display range
                                //==============================================================================================================================
                                if (!iDifferentiate) SelectLines();
                                else SelectLinesWidthDifferentiate();

                                if (!iDifferentiate)
                                {
                                    //prune levels
                                    historicalLevels.RemoveAll(p => p < lowestLow || p > highestHigh || (currentBarLow < p && p < currentBarHigh));

                                    //add new levels
                                    for (int i = 0; i < 20; i++)
                                    {
                                        if (proSupport[i] != 0 && !historicalLevels.Contains(proSupport[i])) historicalLevels.Add(proSupport[i]);
                                        if (proResistance[i] != 0 && !historicalLevels.Contains(proResistance[i])) historicalLevels.Add(proResistance[i]);
                                    }                              
                                }
                                else
                                {
                                    //prune levels
                                    if (iShowPOC) historicalLevelsPOC.RemoveAll(p => p < lowestLow || p > highestHigh || (currentBarLow < p && p < currentBarHigh));
                                    if (iShowVWAP) historicalLevelsVWAP.RemoveAll(p => p < lowestLow || p > highestHigh || (currentBarLow < p && p < currentBarHigh));
                                    if (iShowVAH) historicalLevelsVAH.RemoveAll(p => p < lowestLow || p > highestHigh || (currentBarLow < p && p < currentBarHigh));
                                    if (iShowVAL) historicalLevelsVAL.RemoveAll(p => p < lowestLow || p > highestHigh || (currentBarLow < p && p < currentBarHigh));

                                    //add new levels
                                    for (int i = 0; i < 10; i++)
                                    {
                                        if (iShowPOC)
                                        {
                                            if (proPOCSup[i] != 0 && !historicalLevelsPOC.Contains(proPOCSup[i])) historicalLevelsPOC.Add(proPOCSup[i]);
                                            if (proPOCRes[i] != 0 && !historicalLevelsPOC.Contains(proPOCRes[i])) historicalLevelsPOC.Add(proPOCRes[i]);
                                        }
                                        if (iShowVWAP)
                                        {
                                            if (proVWAPSup[i] != 0 && !historicalLevelsVWAP.Contains(proVWAPSup[i])) historicalLevelsVWAP.Add(proVWAPSup[i]);
                                            if (proVWAPRes[i] != 0 && !historicalLevelsVWAP.Contains(proVWAPRes[i])) historicalLevelsVWAP.Add(proVWAPRes[i]);
                                        }
                                        if (iShowVAH)
                                        {
                                            if (proVAHSup[i] != 0 && !historicalLevelsVAH.Contains(proVAHSup[i])) historicalLevelsVAH.Add(proVAHSup[i]);
                                            if (proVAHRes[i] != 0 && !historicalLevelsVAH.Contains(proVAHRes[i])) historicalLevelsVAH.Add(proVAHRes[i]);
                                        }
                                        if (iShowVAL)
                                        {
                                            if (proVALSup[i] != 0 && !historicalLevelsVAL.Contains(proVALSup[i])) historicalLevelsVAL.Add(proVALSup[i]);
                                            if (proVALRes[i] != 0 && !historicalLevelsVAL.Contains(proVALRes[i])) historicalLevelsVAL.Add(proVALRes[i]);
                                        }
                                    }
                                }
                            }
                            #endregion
                            swingBarIndex++;
                        }
                        #endregion
                        
                        lastSwingBarTime = swingBars.GetTime(swingBarIndex - 1);
                    }
                    #endregion
                }
            }
            #endregion

            #region State == State.Transition
            else if (State == State.Transition)
            {
                //bench.Stop();
                //Print(String.Format("Total Span VPCLevels TF[{3}] : {0}ms on {1} bars => {2:n}ns/bar", bench.ElapsedMilliseconds, CurrentBars[1], 1000 * bench.ElapsedMilliseconds / (double)CurrentBars[1], highestTimeFrame));
            }
            #endregion

            #region State == State.Terminated
            else if (State == State.Terminated)
            {
                if (swingBars != null) swingBars.Dispose();
                if (profileBars != null) profileBars.Dispose();
            }
            #endregion
        }

        protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif

            if (!BarsType.CreateInstance(Bars.BarsPeriod.BarsPeriodType).IsIntraday) return;
            if (generalError) return;
            if (BarsInProgress == 2) return;

            #region -- if (BarsInProgress == 1) --
            if (BarsInProgress == 1)
            {
                if (Times[1][0].CompareTo(firstSessionBegin) > 0)
                {
                    if (Calculate != Calculate.OnBarClose && CurrentBars[1] == 0)
                    {
                        currentBarHigh = Highs[1][0];
                        currentBarLow = Lows[1][0];
                        currentBarClose = Closes[1][0];
                        return;
                    }
                    else if (Calculate != Calculate.OnBarClose && !IsFirstTickOfBar) return;

                    priorBarHigh = currentBarHigh;
                    priorBarLow = currentBarLow;
                    priorBarClose = currentBarClose;
                    priorBarTime = CurrentBars[1] == 0 ? priorBarTime : Times[1][cbIndex + 1];

                    currentBarHigh = Highs[1][cbIndex];
                    currentBarLow = Lows[1][cbIndex];
                    currentBarClose = Closes[1][cbIndex];

                    highestHigh = Math.Max(highestHigh, currentBarHigh);//prune outside wdw
                    lowestLow = Math.Min(lowestLow, currentBarLow);//prune outside wdw

                    #region -- 2nd Bar -- 
                    if (swingBarIndex == 1)
                    {
                        for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
                        {
                            currentHigh[i] = priorBarHigh;
                            currentLow[i] = priorBarLow;
                            currentHighTime[i] = priorBarTime;
                            currentLowTime[i] = priorBarTime;
                        }
                        currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                        avgTrueRange = currentBarTrueRange;
                    }
                    #endregion

                    #region -- All Following Bars --
                    else if (swingBarIndex > 1)
                    {
                        currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                        avgTrueRange = avgTrueRange * (swingBarIndex - 1) / swingBarIndex + currentBarTrueRange / swingBarIndex;
                        //==============================================================================================================================
                        // Calculates Swing Highs and Lows, Retracements, Extensions, Alternates and Projections from currentBarHigh and currentBarLow
                        //==============================================================================================================================
                        if (Times[1][cbIndex].CompareTo(firstSessionBegin.AddDays(MINDAYS)) > 0)
                        {
                            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
                                CalculateSwingProfilesMixUpDw(i);
                            isTrainingComplete = true;
                        }
                        confluenceRangeWidth = confluenceRange * avgTrueRange;
                        upperLimitResistance = MAX(Highs[1], 20)[cbIndex] + displayFactor * avgTrueRange;
                        lowerLimitResistance = Closes[1][cbIndex];
                        upperLimitSupport = Closes[1][cbIndex];
                        lowerLimitSupport = MIN(Lows[1], 20)[cbIndex] - displayFactor * avgTrueRange;
                        upperLimitWeakResistance = MAX(Highs[1], 20)[cbIndex] + displayFactor * avgTrueRange;
                        lowerLimitWeakSupport = MIN(Lows[1], 20)[cbIndex] - displayFactor * avgTrueRange;
                    }
                    #endregion

                    swingBarIndex = swingBarIndex + 1;
                }
            }
            #endregion

            else if (BarsInProgress == 0)
            {
                if (CurrentBars[0] < 2) return;

                if (isTrainingComplete && (IsFirstTickOfBar || currentBars1 > priorCurrentBars1))
                {
                    priorCurrentBars1 = currentBars1;

                    //==============================================================================================================================
                    // Sets all lines and weights within the display range
                    // Note : this is the hot path. It takes on average 1ms to run for each bar. On a 5 days 1Min barchart = 37000 bars, it takes 3.7s to run.
                    //==============================================================================================================================
                    if (!iDifferentiate) SetLinesAndWeights();
                    else SetLinesAndWeightsWithDifferentiate();

                    //==============================================================================================================================
                    // Selects strong and weak lines above defined theshold for weight and checks whether wekaer lines are in the smaller display range
                    //==============================================================================================================================
                    if (!iDifferentiate) SelectLines();
                    else SelectLinesWidthDifferentiate();

                    //==============================================================================================================================
                    // Sorting Arrays fibLine, fibWeight, fibLine and  fibWeight with BubbleSort to prepare for Analyzer
                    // Note : the sorting method has been written to be faster than the Array.Sort c# method.
                    //==============================================================================================================================
                    if (!iDifferentiate) SortLines();
                    else SortLinesWithDifferentiate();

                    if (!iDifferentiate)
                    {
                        #region Display up to 20 Resistance and 20 Support Ranges
                        for (int i = 0; i < 20; i++)
                        {
                            profilesLines[i] = proSupport[19 - i];
                            profilesLines[20 + i] = proResistance[i];
                        }

                        if (IsFirstTickOfBar)
                        {
                            for (int i = 0; i < 40; i++)
                            {
                                oldProfileLines[i] = priorProfileLines[i];
                                oldState[i] = newState[i];
                                oldBOBHigh[i] = newBOBHigh[i];
                                oldBOBLow[i] = newBOBLow[i];
                                oldBOBClose[i] = newBOBClose[i];
                            }
                        }

                        for (int i = 0; i < 40; i++)
                        {
                            for (int j = 0; j < 40; j++)
                            {
                                if (profilesLines[j] == oldProfileLines[i])
                                {
                                    profilesLines[j] = profilesLines[i];
                                    profilesLines[i] = oldProfileLines[i];
                                }
                            }
                        }

                        #region -- SET Confluences to strongFibs --
                        if (profilesLines[0] > 0) Confluence0[0] = profilesLines[0];
                        if (profilesLines[1] > 0) Confluence1[0] = profilesLines[1];
                        if (profilesLines[2] > 0) Confluence2[0] = profilesLines[2];
                        if (profilesLines[3] > 0) Confluence3[0] = profilesLines[3];
                        if (profilesLines[4] > 0) Confluence4[0] = profilesLines[4];
                        if (profilesLines[5] > 0) Confluence5[0] = profilesLines[5];
                        if (profilesLines[6] > 0) Confluence6[0] = profilesLines[6];
                        if (profilesLines[7] > 0) Confluence7[0] = profilesLines[7];
                        if (profilesLines[8] > 0) Confluence8[0] = profilesLines[8];
                        if (profilesLines[9] > 0) Confluence9[0] = profilesLines[9];
                        if (profilesLines[10] > 0) Confluence10[0] = profilesLines[10];
                        if (profilesLines[11] > 0) Confluence11[0] = profilesLines[11];
                        if (profilesLines[12] > 0) Confluence12[0] = profilesLines[12];
                        if (profilesLines[13] > 0) Confluence13[0] = profilesLines[13];
                        if (profilesLines[14] > 0) Confluence14[0] = profilesLines[14];
                        if (profilesLines[15] > 0) Confluence15[0] = profilesLines[15];
                        if (profilesLines[16] > 0) Confluence16[0] = profilesLines[16];
                        if (profilesLines[17] > 0) Confluence17[0] = profilesLines[17];
                        if (profilesLines[18] > 0) Confluence18[0] = profilesLines[18];
                        if (profilesLines[19] > 0) Confluence19[0] = profilesLines[19];

                        if (profilesLines[20] > 0) Confluence20[0] = profilesLines[20];
                        if (profilesLines[21] > 0) Confluence21[0] = profilesLines[21];
                        if (profilesLines[22] > 0) Confluence22[0] = profilesLines[22];
                        if (profilesLines[23] > 0) Confluence23[0] = profilesLines[23];
                        if (profilesLines[24] > 0) Confluence24[0] = profilesLines[24];
                        if (profilesLines[25] > 0) Confluence25[0] = profilesLines[25];
                        if (profilesLines[26] > 0) Confluence26[0] = profilesLines[26];
                        if (profilesLines[27] > 0) Confluence27[0] = profilesLines[27];
                        if (profilesLines[28] > 0) Confluence28[0] = profilesLines[28];
                        if (profilesLines[29] > 0) Confluence29[0] = profilesLines[29];
                        if (profilesLines[30] > 0) Confluence30[0] = profilesLines[30];
                        if (profilesLines[31] > 0) Confluence31[0] = profilesLines[31];
                        if (profilesLines[32] > 0) Confluence32[0] = profilesLines[32];
                        if (profilesLines[33] > 0) Confluence33[0] = profilesLines[33];
                        if (profilesLines[34] > 0) Confluence34[0] = profilesLines[34];
                        if (profilesLines[35] > 0) Confluence35[0] = profilesLines[35];
                        if (profilesLines[36] > 0) Confluence36[0] = profilesLines[36];
                        if (profilesLines[37] > 0) Confluence37[0] = profilesLines[37];
                        if (profilesLines[38] > 0) Confluence38[0] = profilesLines[38];
                        if (profilesLines[39] > 0) Confluence39[0] = profilesLines[39];
                        #endregion

                        //newState und newBobClose determined via fib values
                        tmpOpen  = Opens[0][0];
                        tmpHigh  = Highs[0][0];
                        tmpLow   = Lows[0][0];
                        tmpClose = Closes[0][0];
                        lowestResistance = double.MaxValue;
                        highestSupport   = double.MinValue;

                        for (int i = 0; i < 40; i++)
                        {
                            tmpProValue = profilesLines[i];
                            priorProfileLines[i] = tmpProValue;
                            tmpOldState = oldState[i];
                            tmpBOBHigh  = oldBOBHigh[i];
                            tmpBOBLow   = oldBOBLow[i];
                            tmpBOBClose = oldBOBClose[i];
                            if (oldProfileLines[i] != tmpProValue)
                                newState[i] = 0;
                            else if (tmpOldState == 0 && tmpClose < tmpProValue)
                                newState[i] = 1;
                            else if (tmpOldState == 0 && tmpClose >= tmpProValue)
                                newState[i] = 3;
                            else if (tmpOldState == 1 && tmpLow > tmpProValue)
                                newState[i] = 3;
                            else if (tmpOldState == 1)
                                newState[i] = 1;
                            else if (tmpOldState == 3 && tmpHigh < tmpProValue)
                                newState[i] = 1;
                            else if (tmpOldState == 3)
                                newState[i] = 3;
                            if (newState[i] == 0)
                                PlotBrushes[i][0] = Brushes.Transparent;
                            else if (newState[i] == 1 || newState[i] == 2)
                            {
                                PlotBrushes[i][0] = iResistanceColor;
                                lowestResistance = Math.Min(tmpProValue, lowestResistance);
                            }
                            else if (newState[i] == 3 || newState[i] == 4)
                            {
                                PlotBrushes[i][0] = iSupportColor;
                                highestSupport = Math.Max(tmpProValue, highestSupport);
                            }
                        }
                        #endregion
                    }
                    else
                    {
                        #region Display up to 10 Resistance and 10 Support for each kind of level
                        for (int i = 0; i < 10; i++)
                        {
                            POCprofilesLines[i] = proPOCSup[9 - i];
                            POCprofilesLines[10 + i] = proPOCRes[i];
                            VWAPprofilesLines[i] = proVWAPSup[9 - i];
                            VWAPprofilesLines[10 + i] = proVWAPRes[i];
                            VAHprofilesLines[i] = proVAHSup[9 - i];
                            VAHprofilesLines[10 + i] = proVAHRes[i];
                            VALprofilesLines[i] = proVALSup[9 - i];
                            VALprofilesLines[10 + i] = proVALRes[i];
                        }

                        if (IsFirstTickOfBar)
                        {
                            for (int i = 0; i < 20; i++)
                            {
                                oldPOCProfileLines[i] = priorPOCProfileLines[i];
                                oldVWAPProfileLines[i] = priorVWAPProfileLines[i];
                                oldVAHProfileLines[i] = priorVAHProfileLines[i];
                                oldVALProfileLines[i] = priorVALProfileLines[i];
                            }
                        }

                        #region -- Re-Order Plot if same value exist at bar-1 to have straight line, no cut --
                        for (int i = 0; i < 20; i++)
                        {
                            for (int j = 0; j < 20; j++)
                            {
                                if (POCprofilesLines[j] == oldPOCProfileLines[i])
                                {
                                    POCprofilesLines[j] = POCprofilesLines[i];
                                    POCprofilesLines[i] = oldPOCProfileLines[i];
                                }
                                if (VWAPprofilesLines[j] == oldVWAPProfileLines[i])
                                {
                                    VWAPprofilesLines[j] = VWAPprofilesLines[i];
                                    VWAPprofilesLines[i] = oldVWAPProfileLines[i];
                                }
                                if (VAHprofilesLines[j] == oldVAHProfileLines[i])
                                {
                                    VAHprofilesLines[j] = VAHprofilesLines[i];
                                    VAHprofilesLines[i] = oldVAHProfileLines[i];
                                }
                                if (VALprofilesLines[j] == oldVALProfileLines[i])
                                {
                                    VALprofilesLines[j] = VALprofilesLines[i];
                                    VALprofilesLines[i] = oldVALProfileLines[i];
                                }
                            }
                        }
                        #endregion

                        #region -- SET Confluences to strongFibs --
                        if (iShowPOC)
                        {
                            ConfPOC0[0] = POCprofilesLines[0];
                            ConfPOC1[0] = POCprofilesLines[1];
                            ConfPOC2[0] = POCprofilesLines[2];
                            ConfPOC3[0] = POCprofilesLines[3];
                            ConfPOC4[0] = POCprofilesLines[4];
                            ConfPOC5[0] = POCprofilesLines[5];
                            ConfPOC6[0] = POCprofilesLines[6];
                            ConfPOC7[0] = POCprofilesLines[7];
                            ConfPOC8[0] = POCprofilesLines[8];
                            ConfPOC9[0] = POCprofilesLines[9];
                            ConfPOC10[0] = POCprofilesLines[10];
                            ConfPOC11[0] = POCprofilesLines[11];
                            ConfPOC12[0] = POCprofilesLines[12];
                            ConfPOC13[0] = POCprofilesLines[13];
                            ConfPOC14[0] = POCprofilesLines[14];
                            ConfPOC15[0] = POCprofilesLines[15];
                            ConfPOC16[0] = POCprofilesLines[16];
                            ConfPOC17[0] = POCprofilesLines[17];
                            ConfPOC18[0] = POCprofilesLines[18];
                            ConfPOC19[0] = POCprofilesLines[19];
                        }
                        if (iShowVWAP)
                        {
                            ConfVWAP0[0] = VWAPprofilesLines[0];
                            ConfVWAP1[0] = VWAPprofilesLines[1];
                            ConfVWAP2[0] = VWAPprofilesLines[2];
                            ConfVWAP3[0] = VWAPprofilesLines[3];
                            ConfVWAP4[0] = VWAPprofilesLines[4];
                            ConfVWAP5[0] = VWAPprofilesLines[5];
                            ConfVWAP6[0] = VWAPprofilesLines[6];
                            ConfVWAP7[0] = VWAPprofilesLines[7];
                            ConfVWAP8[0] = VWAPprofilesLines[8];
                            ConfVWAP9[0] = VWAPprofilesLines[9];
                            ConfVWAP10[0] = VWAPprofilesLines[10];
                            ConfVWAP11[0] = VWAPprofilesLines[11];
                            ConfVWAP12[0] = VWAPprofilesLines[12];
                            ConfVWAP13[0] = VWAPprofilesLines[13];
                            ConfVWAP14[0] = VWAPprofilesLines[14];
                            ConfVWAP15[0] = VWAPprofilesLines[15];
                            ConfVWAP16[0] = VWAPprofilesLines[16];
                            ConfVWAP17[0] = VWAPprofilesLines[17];
                            ConfVWAP18[0] = VWAPprofilesLines[18];
                            ConfVWAP19[0] = VWAPprofilesLines[19];
                        }
                        if (iShowVAH)
                        {
                            ConfVAH0[0] = VAHprofilesLines[0];
                            ConfVAH1[0] = VAHprofilesLines[1];
                            ConfVAH2[0] = VAHprofilesLines[2];
                            ConfVAH3[0] = VAHprofilesLines[3];
                            ConfVAH4[0] = VAHprofilesLines[4];
                            ConfVAH5[0] = VAHprofilesLines[5];
                            ConfVAH6[0] = VAHprofilesLines[6];
                            ConfVAH7[0] = VAHprofilesLines[7];
                            ConfVAH8[0] = VAHprofilesLines[8];
                            ConfVAH9[0] = VAHprofilesLines[9];
                            ConfVAH10[0] = VAHprofilesLines[10];
                            ConfVAH11[0] = VAHprofilesLines[11];
                            ConfVAH12[0] = VAHprofilesLines[12];
                            ConfVAH13[0] = VAHprofilesLines[13];
                            ConfVAH14[0] = VAHprofilesLines[14];
                            ConfVAH15[0] = VAHprofilesLines[15];
                            ConfVAH16[0] = VAHprofilesLines[16];
                            ConfVAH17[0] = VAHprofilesLines[17];
                            ConfVAH18[0] = VAHprofilesLines[18];
                            ConfVAH19[0] = VAHprofilesLines[19];
                        }
                        if (iShowVAL)
                        {
                            ConfVAL0[0] = VALprofilesLines[0];
                            ConfVAL1[0] = VALprofilesLines[1];
                            ConfVAL2[0] = VALprofilesLines[2];
                            ConfVAL3[0] = VALprofilesLines[3];
                            ConfVAL4[0] = VALprofilesLines[4];
                            ConfVAL5[0] = VALprofilesLines[5];
                            ConfVAL6[0] = VALprofilesLines[6];
                            ConfVAL7[0] = VALprofilesLines[7];
                            ConfVAL8[0] = VALprofilesLines[8];
                            ConfVAL9[0] = VALprofilesLines[9];
                            ConfVAL10[0] = VALprofilesLines[10];
                            ConfVAL11[0] = VALprofilesLines[11];
                            ConfVAL12[0] = VALprofilesLines[12];
                            ConfVAL13[0] = VALprofilesLines[13];
                            ConfVAL14[0] = VALprofilesLines[14];
                            ConfVAL15[0] = VALprofilesLines[15];
                            ConfVAL16[0] = VALprofilesLines[16];
                            ConfVAL17[0] = VALprofilesLines[17];
                            ConfVAL18[0] = VALprofilesLines[18];
                            ConfVAL19[0] = VALprofilesLines[19];
                        }
                        #endregion

                        #region -- Color Lines if visible --
                        for (int i = 40; i < 120; i++)
                        {
                            if (i < 60)
                            {
                                priorPOCProfileLines[i - 40] = POCprofilesLines[i - 40];
                                if (oldPOCProfileLines[i - 40] != POCprofilesLines[i - 40]) PlotBrushes[i][0] = Brushes.Transparent;
                                else PlotBrushes[i][0] = iPOCColor;
                            }
                            else if (i < 80)
                            {
                                priorVWAPProfileLines[i - 60] = VWAPprofilesLines[i - 60];
                                if (oldVWAPProfileLines[i - 60] != VWAPprofilesLines[i - 60]) PlotBrushes[i][0] = Brushes.Transparent;
                                else PlotBrushes[i][0] = iVWAPColor;
                            }
                            else if (i < 100)
                            {
                                priorVAHProfileLines[i - 80] = VAHprofilesLines[i - 80];
                                if (oldVAHProfileLines[i - 80] != VAHprofilesLines[i - 80]) PlotBrushes[i][0] = Brushes.Transparent;
                                else PlotBrushes[i][0] = iVAHColor;
                            }
                            else if (i < 120)
                            {
                                priorVALProfileLines[i - 100] = VALprofilesLines[i - 100];
                                if (oldVALProfileLines[i - 100] != VALprofilesLines[i - 100]) PlotBrushes[i][0] = Brushes.Transparent;
                                else PlotBrushes[i][0] = iVALColor;
                            }                            
                        }
                        #endregion

                        #endregion
                    }
                }
            }
        }
		public override void OnRenderTargetChanged()
		{
			if(iPOCDXBrush!=null){
				if(!iPOCDXBrush.IsDisposed)iPOCDXBrush.Dispose(); iPOCDXBrush = null;
			}
			if(iVWAPDXBrush!=null){
				if(!iVWAPDXBrush.IsDisposed)iVWAPDXBrush.Dispose(); iVWAPDXBrush = null;
			}
			if(iVAHDXBrush!=null){
				if(!iVAHDXBrush.IsDisposed)iVAHDXBrush.Dispose(); iVAHDXBrush = null;
			}
			if(iVALDXBrush!=null){
				if(!iVALDXBrush.IsDisposed)iVALDXBrush.Dispose(); iVALDXBrush = null;
			}
			if(iSupportDXBrush!=null){
				if(!iSupportDXBrush.IsDisposed)iSupportDXBrush.Dispose(); iSupportDXBrush = null;
			}
			if(iResistanceDXBrush!=null){
				if(!iResistanceDXBrush.IsDisposed)iResistanceDXBrush.Dispose(); iResistanceDXBrush = null;
			}
//			if(dxbrush!=null){
//				if(!dxbrush.IsDisposed)dxbrush.Dispose(); dxbrush = null;
//			}
			if(RenderTarget!=null){
				iPOCDXBrush = iPOCColor.ToDxBrush(RenderTarget);
				iPOCDXBrush.Opacity = iExtendedLineOpacity / 100f;
				iVWAPDXBrush = iVWAPColor.ToDxBrush(RenderTarget);
				iVWAPDXBrush.Opacity = iExtendedLineOpacity / 100f;
				iVAHDXBrush = iVAHColor.ToDxBrush(RenderTarget);
				iVAHDXBrush.Opacity = iExtendedLineOpacity / 100f;
				iVALDXBrush = iVALColor.ToDxBrush(RenderTarget);
				iVALDXBrush.Opacity = iExtendedLineOpacity / 100f;
				iSupportDXBrush = iSupportColor.ToDxBrush(RenderTarget);
				iSupportDXBrush.Opacity = iExtendedLineOpacity / 100f;
				iResistanceDXBrush = iResistanceColor.ToDxBrush(RenderTarget);
				iResistanceDXBrush.Opacity = iExtendedLineOpacity / 100f;
			}
		}

        #region protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            #region -- conditions to return --
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (Bars == null || ChartControl == null) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
            #endregion

			base.OnRender(chartControl, chartScale);
			SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;

			double gMin = chartScale.MinValue;
			double gMax = chartScale.MaxValue;

			int lastBarIndex = Math.Min(CurrentBars[0], ChartBars.ToIndex);//RIGHT BAR idx (slot)
			int firstBarIndex = BarsRequiredToPlot;//FIRST LEFT BAR idx (slot)

			extendedlevels = new List<gztExtendedLevel>();
			SharpDX.Direct2D1.Brush dxbrush = null;
			if (iExtendLevels)
			{
                #region -- get the levels to extend --
                for (int index = firstBarIndex; index < lastBarIndex; index++)
                {
                    if (index < lastBarIndex - 1)//do it for all except far-right bar
                    {
                        List<double> levels = new List<double>();
                        //get the levels to extend which are inside the window
                        for (int vplot = (iDifferentiate ? 40 : 0); vplot < (iDifferentiate ? 120 : 40); vplot++)
                        {
                            gztLevelExtendProfileType ptype = vplot < 40 ? gztLevelExtendProfileType.ALL : 
							vplot < 60 ? gztLevelExtendProfileType.POC : 
							vplot < 80 ? gztLevelExtendProfileType.VWAP : 
							vplot < 100 ? gztLevelExtendProfileType.VAH : 
							gztLevelExtendProfileType.VAL;

                            if (Values[vplot].GetValueAt(index) >= Math.Max(lowestLow, gMin) && 
                                Values[vplot].GetValueAt(index) <= gMax && 
                                Values[vplot].GetValueAt(index) != Values[vplot].GetValueAt(index + 1))
                            {
                                if (Closes[0].GetValueAt(index) > Values[vplot].GetValueAt(index) 
                                    && !gztExtendedLevel.isBrokenSupport(iSRBreak * avgTrueRange, Values[vplot].GetValueAt(index), Lows[0].GetValueAt(index)))
                                    extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.NEW,
                                                                              pPrice = Values[vplot].GetValueAt(index),
                                                                              pSlotStart = index,
                                                                              pType = gztLevelExtendType.SUPPORT,
                                                                              pProfileType = ptype });
                                else if (Closes[0].GetValueAt(index) < Values[vplot].GetValueAt(index) 
                                    && !gztExtendedLevel.isBrokenResistance(iSRBreak * avgTrueRange, Values[vplot].GetValueAt(index), Highs[0].GetValueAt(index)))
                                    extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.NEW,
                                                                              pPrice = Values[vplot].GetValueAt(index),
                                                                              pSlotStart = index,
                                                                              pType = gztLevelExtendType.RESISTANCE,
                                                                              pProfileType = ptype });
                            }
                            levels.Add(Values[vplot].GetValueAt(index));
                        }
                        //for existing levels, check if broken
                        var exlevels = extendedlevels.Where(p => p.pSate == gztLevelExtendState.VALID);
                        foreach (gztExtendedLevel level in exlevels)
                        {
                            if ((level.pType == gztLevelExtendType.RESISTANCE 
                                    && gztExtendedLevel.isBrokenResistance(iSRBreak * avgTrueRange, level.pPrice, Highs[0].GetValueAt(index))) 
                                    || (level.pType == gztLevelExtendType.SUPPORT && 
                                        gztExtendedLevel.isBrokenSupport(iSRBreak * avgTrueRange, level.pPrice, Lows[0].GetValueAt(index)
                                        )))
                            {
                                level.pSate = gztLevelExtendState.BROKEN;
                                level.pSlotEnd = index;
                            }
                        }
                        //mark new as valid (existing for next loop)
                        var newlevels = extendedlevels.Where(p => p.pSate == gztLevelExtendState.NEW);
                        foreach (gztExtendedLevel level in newlevels)
                            level.pSate = gztLevelExtendState.VALID;
                    }
                    else //special treatment for far-right bar : always extend it
                    {
                        //get the levels to extend which are inside the window
                        for (int vplot = (iDifferentiate ? 40 : 0); vplot < (iDifferentiate ? 120 : 40); vplot++)
                        {
                            gztLevelExtendProfileType ptype = vplot < 40 ? gztLevelExtendProfileType.ALL : 
                                                                vplot < 60 ? gztLevelExtendProfileType.POC : 
                                                                vplot < 80 ? gztLevelExtendProfileType.VWAP : 
                                                                vplot < 100 ? gztLevelExtendProfileType.VAH : 
                                                                gztLevelExtendProfileType.VAL;
                            double vp = Values[vplot].GetValueAt(index);
                            if (Values[vplot].GetValueAt(index) >= Math.Max(lowestLow, gMin) 
                                && Values[vplot].GetValueAt(index) <= gMax)
                                extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID,
                                                                          pPrice = Values[vplot].GetValueAt(index),
                                                                          pSlotStart = index,
                                                                          pType = Closes[0].GetValueAt(index) > Values[vplot].GetValueAt(index) 
                                                                                  ? gztLevelExtendType.SUPPORT : gztLevelExtendType.RESISTANCE,
                                                                          pProfileType = ptype });
                        }
                    }
                }
                #endregion

			    #region -- draw level extension --
			    foreach (gztExtendedLevel level in extendedlevels)
			    {
			        dxbrush = iDifferentiate ? (level.pProfileType == gztLevelExtendProfileType.POC ? iPOCDXBrush : level.pProfileType == gztLevelExtendProfileType.VWAP ? iVWAPDXBrush : level.pProfileType == gztLevelExtendProfileType.VAH ? iVAHDXBrush : iVALDXBrush) : level.pType == gztLevelExtendType.SUPPORT ? iSupportDXBrush : iResistanceDXBrush;
			        if (dxbrush != null)
			        {
			            if (level.pPrice >= lowestLow) 
							drawLine(level.pPrice, level.pSlotStart, level.pSlotEnd, dxbrush, iDashStyle, iExtendedLineWidth, chartControl, chartScale);
			        }
			    }
			    #endregion
			}

			//historical
			if (iExtendLevels)
			{
			    extendedlevels.Clear();

                #region -- Get extended levels inside the window --
                if (!iDifferentiate)
                {
                    List<double> levels = historicalLevels.FindAll(p => gMin < p && p < gMax);
                    foreach (double level in levels)
                    {
                        if (Closes[0].GetValueAt(firstBarIndex) > level)
                            extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID,
                                                                      pPrice = level,
                                                                      pSlotStart = firstBarIndex,
                                                                      pType = gztLevelExtendType.SUPPORT,
                                                                      pProfileType = gztLevelExtendProfileType.ALL });
                        else
                            extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID,
                                                                      pPrice = level,
                                                                      pSlotStart = firstBarIndex,
                                                                      pType = gztLevelExtendType.RESISTANCE,
                                                                      pProfileType = gztLevelExtendProfileType.ALL });
                    }
                }
				
				#region iDifferentiate levels
                else
                {
                    List<double> levels = historicalLevelsPOC.FindAll(p => gMin < p && p < gMax);
                    foreach (double level in levels)
                    {
                        if (Closes[0].GetValueAt(firstBarIndex) > level)
                            extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID,
                                                                      pPrice = level,
                                                                      pSlotStart = firstBarIndex,
                                                                      pType = gztLevelExtendType.SUPPORT,
                                                                      pProfileType = gztLevelExtendProfileType.POC });
                        else
                            extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID,
                                                                      pPrice = level,
                                                                      pSlotStart = firstBarIndex,
                                                                      pType = gztLevelExtendType.RESISTANCE,
                                                                      pProfileType = gztLevelExtendProfileType.POC });
                    }

                    levels.Clear();
                    levels = historicalLevelsVWAP.FindAll(p => gMin < p && p < gMax);
                    foreach (double level in levels)
                    {
                        if (Closes[0].GetValueAt(firstBarIndex) > level)
                            extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID,
                                                                      pPrice = level,
                                                                      pSlotStart = firstBarIndex,
                                                                      pType = gztLevelExtendType.SUPPORT,
                                                                      pProfileType = gztLevelExtendProfileType.VWAP });
                        else
                            extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID,
                                                                      pPrice = level,
                                                                      pSlotStart = firstBarIndex,
                                                                      pType = gztLevelExtendType.RESISTANCE,
                                                                      pProfileType = gztLevelExtendProfileType.VWAP });
                    }

                    levels.Clear();
                    levels = historicalLevelsVAH.FindAll(p => gMin < p && p < gMax);
                    foreach (double level in levels)
                    {
                        if (Closes[0].GetValueAt(firstBarIndex) > level)
                            extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID, pPrice = level, pSlotStart = firstBarIndex, pType = gztLevelExtendType.SUPPORT, pProfileType = gztLevelExtendProfileType.VAH });
                        else
                            extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID, pPrice = level, pSlotStart = firstBarIndex, pType = gztLevelExtendType.RESISTANCE, pProfileType = gztLevelExtendProfileType.VAH });
                    }

                    levels.Clear();
                    levels = historicalLevelsVAL.FindAll(p => gMin < p && p < gMax);
                    foreach (double level in levels)
                    {
                        if (Closes[0].GetValueAt(firstBarIndex) > level)
                            extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID, pPrice = level, pSlotStart = firstBarIndex, pType = gztLevelExtendType.SUPPORT, pProfileType = gztLevelExtendProfileType.VAL });
                        else
                            extendedlevels.Add(new gztExtendedLevel { pSate = gztLevelExtendState.VALID, pPrice = level, pSlotStart = firstBarIndex, pType = gztLevelExtendType.RESISTANCE, pProfileType = gztLevelExtendProfileType.VAL });
                    }
                }
				#endregion iDifferentiate
				
                #endregion

				if (extendedlevels.Count > 0)
				{
				    #region -- Recalcul conf --
				    extendedlevels = extendedlevels.OrderBy(pr => pr.pPrice).ToList();
				    List<gztExtendedLevel> confExtendedlevels = new List<gztExtendedLevel>();
				    gztExtendedLevel confLevel = new gztExtendedLevel();
				    int count = 1;
				    double reflv = 0;

				    for (int lv = 0; lv < extendedlevels.Count; lv++)
				    {
				        if (lv == 0)
				        {
				            count = 1;
				            reflv = extendedlevels[0].pPrice;

				            confLevel = new gztExtendedLevel();
				            confLevel.pPrice = extendedlevels[0].pPrice;
				            confLevel.pProfileType = extendedlevels[0].pProfileType;
				            confLevel.pSlotStart = extendedlevels[0].pSlotStart;
				            confLevel.pSate = extendedlevels[0].pSate;
				            confLevel.pType = extendedlevels[0].pType;
				        }
				        else
				        {

				            if (extendedlevels[lv].pPrice - reflv <= confluenceRangeWidth)//conf
				            {
                                /* ----------------------------------------------------------------------
								JQ 11.18.2017
								BUG #12495
								Set the confLevel.pPrice to be extendedlevels[lv].pPrice instead of the
           						(confLevel.pPrice * count + extendedlevels[lv].pPrice) / (count + 1)
								The old code confLevel.pPrice = (confLevel.pPrice * count + extendedlevels[lv].pPrice) / (count + 1)  
								shifted the price do the calculation it was using and it used this calculation to be the price. 
								As the extended levele are already available, the extended lines should be the extended level price 
								and not the calculated price that were used in the original code.
								----------------------------------------------------------------------*/
								  //--start--
								  // Old Code 
								  // confLevel.pPrice = (confLevel.pPrice * count + extendedlevels[lv].pPrice) / (count + 1);
								  // New Code
								confLevel.pPrice = extendedlevels[lv].pPrice;
								  //--End--
								
							    count++;
							}
							else
							{
							    confExtendedlevels.Add(confLevel);

							    reflv = extendedlevels[lv].pPrice;
							    count = 1;

							    confLevel = new gztExtendedLevel();
							    confLevel.pPrice = extendedlevels[lv].pPrice;
							    confLevel.pProfileType = extendedlevels[lv].pProfileType;
							    confLevel.pSlotStart = extendedlevels[lv].pSlotStart;
							    confLevel.pSate = extendedlevels[lv].pSate;
							    confLevel.pType = extendedlevels[lv].pType;
							}
					    }
					}

					if (reflv != 0) confExtendedlevels.Add(confLevel);//last one or only one
					#endregion -- Recalcul conf --

					#region -- calculate when levels are broken --
					for (int index = firstBarIndex + 1; index < lastBarIndex; index++)
					{
					    //for existing levels, check if broken
					    var exlevels = confExtendedlevels.Where(p => p.pSate == gztLevelExtendState.VALID);
					    foreach (gztExtendedLevel level in exlevels)
					    {
					        if ((level.pType == gztLevelExtendType.RESISTANCE 
					            && gztExtendedLevel.isBrokenResistance(iSRBreak * avgTrueRange, level.pPrice, Highs[0].GetValueAt(index))) 
					            ||
					            (level.pType == gztLevelExtendType.SUPPORT 
					            && gztExtendedLevel.isBrokenSupport(iSRBreak * avgTrueRange, level.pPrice, Lows[0].GetValueAt(index))))
					        {
					            level.pSate = gztLevelExtendState.BROKEN;
					            level.pSlotEnd = index;
					        }
					    }
					}
					#endregion

					#region -- draw level extension --
					foreach (gztExtendedLevel level in confExtendedlevels)
					{
						dxbrush = iDifferentiate ? (level.pProfileType == gztLevelExtendProfileType.POC 
						                                ? iPOCDXBrush : level.pProfileType == gztLevelExtendProfileType.VWAP 
						                                ? iVWAPDXBrush : level.pProfileType == gztLevelExtendProfileType.VAH 
						                                ? iVAHDXBrush : iVALDXBrush) : level.pType == gztLevelExtendType.SUPPORT 
						                                ? iSupportDXBrush : iResistanceDXBrush;
						if (level.pPrice >= lowestLow) 
							drawLine(level.pPrice, level.pSlotStart, level.pSlotEnd, dxbrush, iDashStyle, iExtendedLineWidth, chartControl, chartScale);
                    }
                    #endregion
                }
            }

            RenderTarget.AntialiasMode = OSM;
        }
        #endregion

        //---------- Gloabl variables for OPTI --------------
        private List<gztSwingProfile> profiles = new List<gztSwingProfile>();

        //------------------------- Functions --------------------------------------        
        //This function does a bar request to preload historical minute bars. It is an asynchrone function but has been made synchrone.
        #region -- loadHistoricalBars --
        private Bars loadHistoricalBars(DateTime dtfrom, DateTime dtto, BarsPeriodType barsperiodtype, int barsperiod)
        {
            //---- Prepa Bars Request ----
            BarsRequest barsRequest = new BarsRequest(Bars.Instrument, dtfrom, dtto) { TradingHours = Bars.TradingHours, IsSplitAdjusted = false/*Bars.IsSplitAdjusted*/, IsDividendAdjusted = Bars.IsDividendAdjusted };
            barsRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = barsperiodtype, MarketDataType = Bars.BarsPeriod.MarketDataType, Value = barsperiod };

            //---- Request the bars ----
            bool doWait = true;
            Bars retour = null;
            barsRequest.Request(new Action<BarsRequest, NinjaTrader.Cbi.ErrorCode, string>((bars, errorCode, errorMessage) =>
            {
                if (errorCode != NinjaTrader.Cbi.ErrorCode.NoError) { retour = null; doWait = false; return; }
                else if (bars.Bars == null || bars.Bars.Count == 0) { doWait = false; return; }
                retour = bars.Bars;
                doWait = false;
                return;
            }));
            while (doWait) { Thread.Sleep(10); }//made synchrone cause need request to finish before continuing
            return retour;
        }
        #endregion

        #region -- CalculateSwingProfiles --        
        public void CalculateSwingProfilesMixUpDw(int i, bool isPreloading = false)
        {
            minimumDeviation[i] = zigZagFactor * Math.Pow(stepUpRatio, i) * avgTrueRange;//dev min for trend change
            highUpdate = upTrend[i] && priorBarHigh >= currentBarHigh && priorBarHigh > currentHigh[i];
            lowUpdate = !upTrend[i] && priorBarLow <= currentBarLow && priorBarLow < currentLow[i];
            addHigh = !upTrend[i] && priorBarHigh >= currentBarHigh && priorBarHigh > currentLow[i] + minimumDeviation[i];
            addLow = upTrend[i] && priorBarLow <= currentBarLow && priorBarLow < currentHigh[i] - minimumDeviation[i];
            normalizedRangeUp = 0;
            normalizedRangeDown = 0;

            // Condition required to speed up the indicator
            //==========================================================================================================================
            // printing of lines is delayed by one bar to avoid vertical lines on the chart

            countDown[i] = highUpdate || lowUpdate || addHigh || addLow ? 1 : countDown[i] - 1;

            #region -- countDown[i] == 0 => REM Levels --
            if (countDown[i] == 0)
            {
                priorPOCUp[i] = POCUp[i];
                priorVWAPUp[i] = VWAPUp[i];
                priorVAHUp[i] = VAHUp[i];
                priorVALUp[i] = VALUp[i];
            }
            #endregion

            if (countDown[i] == 1)
            {

                #region -- Section to identify ZigZagHighs and ZigZagLows filling them into arrays +  --
                if (addHigh) // when new high is added, currentLow is validated
                {
                    upTrend[i] = true;
                    currentHigh[i] = priorBarHigh;
                    currentHighTime[i] = priorBarTime;
                    validSwingLow[i] = currentLow[i];
                    pivotLowBarTime[i] = currentLowTime[i];
                    canSwing[i]++;
                }
                else if (highUpdate)
                {
                    currentHigh[i] = priorBarHigh;
                    currentHighTime[i] = priorBarTime;
                }
                else if (addLow)  // when new low is added, currentHigh is validated and set to MicroHighArray, microLow[0] is left empty 
                {
                    upTrend[i] = false;
                    validSwingHigh[i] = currentHigh[i];
                    pivotHighBarTime[i] = currentHighTime[i];
                    currentLow[i] = priorBarLow;
                    currentLowTime[i] = priorBarTime;
                    canSwing[i]++;
                }
                else if (lowUpdate)
                {
                    currentLow[i] = priorBarLow;
                    currentLowTime[i] = priorBarTime;
                }
                #endregion

                if (canSwing[i] < 3) return;

                DateTime dtmin = pivotLowBarTime[i].CompareTo(pivotHighBarTime[i]) < 0 ? pivotLowBarTime[i] : pivotHighBarTime[i];//take min date
                if (isPreloading && profileBars.GetTime(0).CompareTo(dtmin) > 0) return;//no profile calculation if not enough bar
                else if (!isPreloading && BarsArray[profileBIP].GetTime(0).CompareTo(dtmin) > 0) return;//no profile calculation if not enough bar

                #region -- Section to calculate Profile from last Swing High and last Swing Low --

                priorPOCUp[i] = POCUp[i];
                priorVWAPUp[i] = VWAPUp[i];
                priorVAHUp[i] = VAHUp[i];
                priorVALUp[i] = VALUp[i];
                
                if (addLow || lowUpdate)
                {
                    if (addLow)
                    {
                        gztSwingProfile tmpProfile;
                        if (i == 0) tmpProfile = CalculateProfileFromBar(pivotLowBarTime[i], pivotHighBarTime[i], isPreloading);
                        else tmpProfile = CalculateProfileFromSwings(pivotLowBarTime[i], pivotHighBarTime[i], validSwingHigh[i], validSwingLow[i], i);

                        if (tmpProfile == null) return;

                        profiles.Add(tmpProfile);
                        POCUp[i] = specificWeightPOC == 0 ? 0 : tmpProfile.POC;
                        VWAPUp[i] = specificWeightVWAP == 0 ? 0 : tmpProfile.VWAP;
                        VAHUp[i] = specificWeightVAH == 0 ? 0 : tmpProfile.VAH;
                        VALUp[i] = specificWeightVAL == 0 ? 0 : tmpProfile.VAL;

                        normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((validSwingHigh[i] - validSwingLow[i]) / (zigZagFactor * avgTrueRange));
                        weightPOCUp[i] = (iDifferentiate ? 100 : specificWeightPOC) * normalizedRangeUp;
                        weightVWAPUp[i] = (iDifferentiate ? 100 : specificWeightVWAP) * normalizedRangeUp;
                        weightVAHUp[i] = (iDifferentiate ? 100 : specificWeightVAH) * normalizedRangeUp;
                        weightVALUp[i] = (iDifferentiate ? 100 : specificWeightVAL) * normalizedRangeUp;
                    }
                }

                if (addHigh || highUpdate)
                {
                    if (addHigh)
                    {
                        gztSwingProfile tmpProfile;
                        if (i == 0) tmpProfile = CalculateProfileFromBar(pivotHighBarTime[i], pivotLowBarTime[i], isPreloading);
                        else tmpProfile = CalculateProfileFromSwings(pivotHighBarTime[i], pivotLowBarTime[i], validSwingHigh[i], validSwingLow[i], i);

                        if (tmpProfile == null) return;

                        profiles.Add(tmpProfile);
                        POCUp[i] = specificWeightPOC == 0 ? 0 : tmpProfile.POC;
                        VWAPUp[i] = specificWeightVWAP == 0 ? 0 : tmpProfile.VWAP;
                        VAHUp[i] = specificWeightVAH == 0 ? 0 : tmpProfile.VAH;
                        VALUp[i] = specificWeightVAL == 0 ? 0 : tmpProfile.VAL;

                        normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((validSwingHigh[i] - validSwingLow[i]) / (zigZagFactor * avgTrueRange));
                        weightPOCUp[i] = (iDifferentiate ? 100 : specificWeightPOC) * normalizedRangeDown;
                        weightVWAPUp[i] = (iDifferentiate ? 100 : specificWeightVWAP) * normalizedRangeDown;
                        weightVAHUp[i] = (iDifferentiate ? 100 : specificWeightVAH) * normalizedRangeDown;
                        weightVALUp[i] = (iDifferentiate ? 100 : specificWeightVAL) * normalizedRangeDown;
                    }
                }
                #endregion  
            }
        }
        private gztSwingProfile CalculateProfileFromBar(DateTime pofileStart, DateTime profileEnd, bool isPreloading = false)
        {
            Bars barsUsed = isPreloading ? profileBars : (pofileStart.CompareTo(BarsArray[profileBIP].FromDate) < 0 ? profileBars : BarsArray[profileBIP]);
            
            int slotEnd = Math.Max(barsUsed.GetBar(profileEnd), barsUsed.GetBar(pofileStart));
            int slotStart = Math.Min(barsUsed.GetBar(profileEnd), barsUsed.GetBar(pofileStart));

            double proHigh = 0, proLow = double.MaxValue;

            for (int i = slotStart; i <= slotEnd; i++)
            {
                proHigh = Math.Max(proHigh, barsUsed.GetHigh(i));
                proLow = Math.Min(proLow, barsUsed.GetLow(i));
            }

            gztSwingProfile profile = new gztSwingProfile((int)(Math.Round((proHigh - proLow) / this.TickSize)) + 1, 0) { priceMAX = proHigh, priceMIN = proLow, dateStart = barsUsed.GetTime(slotStart), dateEnd = profileEnd };

            double barHigh = 0, barLow = double.MaxValue, barVolume;
            int numLevels, levelIndex, p;
            #region -- Create Histogram of Swing -- 
            for (int i = slotStart; i <= slotEnd; i++)
            {
                barHigh = barsUsed.GetHigh(i);
                barLow = barsUsed.GetLow(i);
                barVolume = barsUsed.GetVolume(i);

                numLevels = (int)((barHigh - barLow) / this.TickSize) + 1;
                levelIndex = (int)((barLow - proLow) / this.TickSize);

                for (p = levelIndex; p < levelIndex + numLevels; p++) profile.levelWeights[p] += barVolume / numLevels;
                profile.volumeTotal += barVolume;
            }
            #endregion

            #region -- calculate VWAP and POC --
            int POCidx = 0;
            double POCVolume = 0;
            double POC = 0;
            double VWAPTotal = 0;

            double level = profile.priceMIN;
            for (p = 0; p < profile.levelWeights.Length; p++)
            {
                VWAPTotal += profile.levelWeights[p] * level;
                if (profile.levelWeights[p] > POCVolume)
                {
                    POCVolume = profile.levelWeights[p];
                    POC = level;
                    POCidx = p;
                }
                level += TickSize;
            }
            #endregion

            #region -- VAH/VAL Calculation --
            double PercentVolume = profile.volumeTotal * pVAPercent / 100;
            double CurrentVolume = POCVolume;
            int idxAbove = POCidx;
            int idxBelow = POCidx;
            bool isUpCluster = false;
            int idxMax = profile.levelWeights.Length - 1;

            double VolumeAbove = idxAbove + 1 <= idxMax ? profile.levelWeights[idxAbove + 1] : 0;
            if (idxAbove + 2 <= idxMax) VolumeAbove += profile.levelWeights[idxAbove + 2];

            double VolumeBelow = idxBelow - 1 >= 0 ? profile.levelWeights[idxBelow - 1] : 0;
            if (idxBelow - 2 >= 0) VolumeBelow += profile.levelWeights[idxBelow - 2];

            while (CurrentVolume < PercentVolume)
            {
                if (VolumeBelow > VolumeAbove || idxAbove == idxMax)
                {
                    idxBelow = idxBelow - 2 < 0 ? 0 : idxBelow - 2;
                    CurrentVolume = CurrentVolume + VolumeBelow;
                    VolumeBelow = 0;
                    isUpCluster = false;
                }
                else
                {
                    idxAbove = idxAbove + 2 > idxMax ? idxMax : idxAbove + 2;
                    CurrentVolume = CurrentVolume + VolumeAbove;
                    VolumeAbove = 0;
                    isUpCluster = idxAbove < idxMax;//to unlock
                }

                if (isUpCluster)
                {
                    VolumeAbove = idxAbove + 1 <= idxMax ? profile.levelWeights[idxAbove + 1] : 0;
                    if (idxAbove + 2 <= idxMax) VolumeAbove += profile.levelWeights[idxAbove + 2];
                }
                else
                {
                    VolumeBelow = idxBelow - 1 >= 0 ? profile.levelWeights[idxBelow - 1] : 0;
                    if (idxBelow - 2 >= 0) VolumeBelow += profile.levelWeights[idxBelow - 2];
                }
            }
            #endregion

            profile.POC = usePOC ? POC : 0;
            profile.VWAP = useVWAP ? RTTS(VWAPTotal / profile.volumeTotal) : 0;
            profile.VAH = useVAH ? proLow + idxAbove * TickSize : 0;
            profile.VAL = useVAL ? proLow + idxBelow * TickSize : 0;

            return profile;
        }
        private gztSwingProfile CalculateProfileFromSwings(DateTime pofileStart, DateTime profileEnd, double topProfile, double bottomProfile, int timeframe)
        {
            List<gztSwingProfile> profilesToMerge = profiles.FindAll(s => s.profileTimeFrames.Contains(timeframe - 1) && s.dateStart.CompareTo(pofileStart) >= 0 && s.dateEnd.CompareTo(profileEnd) <= 0);
            if (profilesToMerge.Count == 0) return null;//GROS PROBLEME
            if (profilesToMerge.Count == 1)
            {
                profilesToMerge[0].profileTimeFrames.Add(timeframe);
                return profilesToMerge[0];
            }
            //Otherwise Merge all swings
            gztSwingProfile profile = new gztSwingProfile((int)(Math.Round((topProfile - bottomProfile) / this.TickSize)) + 1, timeframe) { priceMAX = topProfile, priceMIN = bottomProfile, dateStart = pofileStart, dateEnd = profileEnd };

            double tmpSwingHigh, tmpSwingLow, tmpSwingVolume;
            int numLevels, offsetLevelIndex, p;

            #region -- Create Histogram of Swing -- 
            for (int i = 0; i < profilesToMerge.Count; i++)
            {
                tmpSwingHigh = Math.Min(topProfile, profilesToMerge[i].priceMAX);
                tmpSwingLow = Math.Max(bottomProfile, profilesToMerge[i].priceMIN);

                numLevels = (int)((tmpSwingHigh - tmpSwingLow) / this.TickSize) + 1;//number of price levels inside the swing
                offsetLevelIndex = (int)((tmpSwingLow - bottomProfile) / this.TickSize);//OFFSET level of tmp swing relatively to the total swing

                for (p = 0; p < numLevels; p++)
                {
                    tmpSwingVolume = profilesToMerge[i].levelWeights[p];
                    profile.levelWeights[p + offsetLevelIndex] += tmpSwingVolume;
                }
                profile.volumeTotal += profilesToMerge[i].volumeTotal;
            }
            #endregion

            #region -- calculate VWAP and POC --
            int POCidx = 0;
            double POCVolume = 0;
            double POC = 0;
            double VWAPTotal = 0;

            double level = profile.priceMIN;
            for (p = 0; p < profile.levelWeights.Length; p++)
            {
                VWAPTotal += profile.levelWeights[p] * level;

                if (profile.levelWeights[p] > POCVolume)
                {
                    POCVolume = profile.levelWeights[p];
                    POC = level;
                    POCidx = p;
                }
                level += TickSize;
            }
            #endregion

            #region -- VAH/VAL Calculation --
            double PercentVolume = profile.volumeTotal * pVAPercent / 100;
            double CurrentVolume = POCVolume;
            int idxAbove = POCidx;
            int idxBelow = POCidx;
            bool isUpCluster = false;
            int idxMax = profile.levelWeights.Length - 1;

            double VolumeAbove = idxAbove + 1 <= idxMax ? profile.levelWeights[idxAbove + 1] : 0;
            if (idxAbove + 2 <= idxMax) VolumeAbove += profile.levelWeights[idxAbove + 2];

            double VolumeBelow = idxBelow - 1 >= 0 ? profile.levelWeights[idxBelow - 1] : 0;
            if (idxBelow - 2 >= 0) VolumeBelow += profile.levelWeights[idxBelow - 2];

            while (CurrentVolume < PercentVolume && (VolumeBelow > 0 || VolumeAbove > 0))
            {
                if (VolumeBelow > VolumeAbove)
                {
                    idxBelow = idxBelow - 2 < 0 ? 0 : idxBelow - 2;
                    CurrentVolume = CurrentVolume + VolumeBelow;
                    VolumeBelow = 0;
                    isUpCluster = false;
                }
                else
                {
                    idxAbove = idxAbove + 2 > idxMax ? idxMax : idxAbove + 2;
                    CurrentVolume = CurrentVolume + VolumeAbove;
                    VolumeAbove = 0;
                    isUpCluster = true;
                }

                if (isUpCluster)
                {
                    VolumeAbove = idxAbove + 1 <= idxMax ? profile.levelWeights[idxAbove + 1] : 0;
                    if (idxAbove + 2 <= idxMax) VolumeAbove += profile.levelWeights[idxAbove + 2];
                }
                else
                {
                    VolumeBelow = idxBelow - 1 >= 0 ? profile.levelWeights[idxBelow - 1] : 0;
                    if (idxBelow - 2 >= 0) VolumeBelow += profile.levelWeights[idxBelow - 2];
                }
            }
            #endregion

            profile.POC = usePOC ? POC : 0;
            profile.VWAP = useVWAP ? RTTS(VWAPTotal / profile.volumeTotal) : 0;
            profile.VAH = useVAH ? bottomProfile + idxAbove * TickSize : 0;
            profile.VAL = useVAL ? bottomProfile + idxBelow * TickSize : 0;

            return profile;
        }
        #endregion

        //=========================================================================================================================
        // Writing all Fib Lines and Fib Weights to two separate Arrays that can be sorted
        //=========================================================================================================================            
        private int countLine;
        private double initialWeight;
        private double compoundedWeight;
        private double highestWeight;
        private double dummy;
        
        #region -- SetLinesAndWeights --
        public void SetLinesAndWeights()
        {
            countLine = 0;
            
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                //=========================================================================================================================
                #region -- Section to set Profile from last Swing High and last Swing Low (max. 8 Values calculated and displayed) --

                proLine[countLine] = POCUp[i];
                proWeight[countLine] = weightPOCUp[i];
                countLine = countLine + 1;

                proLine[countLine] = VWAPUp[i];
                proWeight[countLine] = weightVWAPUp[i];
                countLine = countLine + 1;

                proLine[countLine] = VAHUp[i];
                proWeight[countLine] = weightVAHUp[i];
                countLine = countLine + 1;

                proLine[countLine] = VALUp[i];
                proWeight[countLine] = weightVALUp[i];
                countLine = countLine + 1;

                #endregion
            }

            //==============================================================================================================================
            // Select all Resistance and Support Lines within the Display Range and Determine Compounded Weight of Each Line
            //==============================================================================================================================			
            initialWeight = 0;
            compoundedWeight = 0;
            highestWeight = 0;

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                #region -- Profile --
                dummy = cumulatedWeightPOCUp[i];
                cumulatedWeightPOCUp[i] = 0;
                if (POCUp[i] >= lowerLimitSupport && POCUp[i] <= upperLimitResistance)
                {
                    initialWeight = weightPOCUp[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(POCUp[i] - proLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + proWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, proWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorPOCUp[i] == POCUp[i])
                            cumulatedWeightPOCUp[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightPOCUp[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightVWAPUp[i];
                cumulatedWeightVWAPUp[i] = 0;
                if (VWAPUp[i] >= lowerLimitSupport && VWAPUp[i] <= upperLimitResistance)
                {
                    initialWeight = weightVWAPUp[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(VWAPUp[i] - proLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + proWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, proWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorVWAPUp[i] == VWAPUp[i])
                            cumulatedWeightVWAPUp[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightVWAPUp[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightVAHUp[i];
                cumulatedWeightVAHUp[i] = 0;
                if (VAHUp[i] >= lowerLimitSupport && VAHUp[i] <= upperLimitResistance)
                {
                    initialWeight = weightVAHUp[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(VAHUp[i] - proLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + proWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, proWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorVAHUp[i] == VAHUp[i])
                            cumulatedWeightVAHUp[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightVAHUp[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightVALUp[i];
                cumulatedWeightVALUp[i] = 0;
                if (VALUp[i] >= lowerLimitSupport && VALUp[i] <= upperLimitResistance)
                {
                    initialWeight = weightVALUp[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(VALUp[i] - proLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + proWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, proWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorVALUp[i] == VALUp[i])
                            cumulatedWeightVALUp[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightVALUp[i] = 0.5 * compoundedWeight;
                    }
                }
                #endregion
            }
        }
        #endregion

        #region -- SetLinesAndWeightsWithDifferentiate --
        public void SetLinesAndWeightsWithDifferentiate()
        {
            countLine = 0;

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                //=========================================================================================================================
                #region -- Section to set Profile from last Swing High and last Swing Low (max. 8 Values calculated and displayed) --

                proLine[countLine] = POCUp[i];
                proWeight[countLine] = weightPOCUp[i];
                countLine = countLine + 1;

                proLine[countLine] = VWAPUp[i];
                proWeight[countLine] = weightVWAPUp[i];
                countLine = countLine + 1;

                proLine[countLine] = VAHUp[i];
                proWeight[countLine] = weightVAHUp[i];
                countLine = countLine + 1;

                proLine[countLine] = VALUp[i];
                proWeight[countLine] = weightVALUp[i];
                countLine = countLine + 1;

                #endregion
            }

            //==============================================================================================================================
            // Select all Resistance and Support Lines within the Display Range and Determine Compounded Weight of Each Line
            //==============================================================================================================================			
            initialWeight = 0;
            compoundedWeight = 0;
            highestWeight = 0;
            int JOFFSET = 4;

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                #region -- Profile --
                dummy = cumulatedWeightPOCUp[i];
                cumulatedWeightPOCUp[i] = 0;
                if (POCUp[i] >= lowerLimitSupport && POCUp[i] <= upperLimitResistance)
                {
                    initialWeight = weightPOCUp[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j+= JOFFSET)
                    {
                        if (Math.Abs(POCUp[i] - proLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + proWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, proWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorPOCUp[i] == POCUp[i])
                            cumulatedWeightPOCUp[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightPOCUp[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightVWAPUp[i];
                cumulatedWeightVWAPUp[i] = 0;
                if (VWAPUp[i] >= lowerLimitSupport && VWAPUp[i] <= upperLimitResistance)
                {
                    initialWeight = weightVWAPUp[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 1; j < countLine; j += JOFFSET)
                    {
                        if (Math.Abs(VWAPUp[i] - proLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + proWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, proWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorVWAPUp[i] == VWAPUp[i])
                            cumulatedWeightVWAPUp[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightVWAPUp[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightVAHUp[i];
                cumulatedWeightVAHUp[i] = 0;
                if (VAHUp[i] >= lowerLimitSupport && VAHUp[i] <= upperLimitResistance)
                {
                    initialWeight = weightVAHUp[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 2; j < countLine; j += JOFFSET)
                    {
                        if (Math.Abs(VAHUp[i] - proLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + proWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, proWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorVAHUp[i] == VAHUp[i])
                            cumulatedWeightVAHUp[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightVAHUp[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightVALUp[i];
                cumulatedWeightVALUp[i] = 0;
                if (VALUp[i] >= lowerLimitSupport && VALUp[i] <= upperLimitResistance)
                {
                    initialWeight = weightVALUp[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 3; j < countLine; j += JOFFSET)
                    {
                        if (Math.Abs(VALUp[i] - proLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + proWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, proWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorVALUp[i] == VALUp[i])
                            cumulatedWeightVALUp[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightVALUp[i] = 0.5 * compoundedWeight;
                    }
                }
                #endregion
            }
        }
        #endregion

        //==============================================================================================================================
        // Prepare Lines for Display Range if Compounded Weight is Above Multiple of Threshold
        //==============================================================================================================================	
        #region -- SelectLines --
        private int countResistance = 0;
        private int countSupport = 0;
        public void SelectLines()
        {
            countResistance = 0;
            for (int i = 0; i < 40; i++) proResistance[i] = 0;
            countSupport = 0;
            for (int i = 0; i < 40; i++) proSupport[i] = 0;

            #region -- Profile --
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightPOCUp[i] > iThreshold)
                    if (POCUp[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightPOCUp[i] > 1.5 * iThreshold)
                        {
                            proResistance[countResistance] = POCUp[i];
                            countResistance = countResistance + 1;
                        }
                        else if (POCUp[i] < upperLimitWeakResistance)
                        {
                            proResistance[countResistance] = POCUp[i];
                            countResistance = countResistance + 1;
                        }
                    }
                    else if (POCUp[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightPOCUp[i] > 1.5 * iThreshold)
                        {
                            proSupport[countSupport] = POCUp[i];
                            countSupport = countSupport + 1;
                        }
                        else if (POCUp[i] > lowerLimitWeakSupport)
                        {
                            proSupport[countSupport] = POCUp[i];
                            countSupport = countSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightVWAPUp[i] > iThreshold)
                    if (VWAPUp[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightVWAPUp[i] > 1.5 * iThreshold)
                        {
                            proResistance[countResistance] = VWAPUp[i];
                            countResistance = countResistance + 1;
                        }
                        else if (VWAPUp[i] < upperLimitWeakResistance)
                        {
                            proResistance[countResistance] = VWAPUp[i];
                            countResistance = countResistance + 1;
                        }
                    }
                    else if (VWAPUp[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightVWAPUp[i] > 1.5 * iThreshold)
                        {
                            proSupport[countSupport] = VWAPUp[i];
                            countSupport = countSupport + 1;
                        }
                        else if (VWAPUp[i] > lowerLimitWeakSupport)
                        {
                            proSupport[countSupport] = VWAPUp[i];
                            countSupport = countSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightVAHUp[i] > iThreshold)
                    if (VAHUp[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightVAHUp[i] > 1.5 * iThreshold)
                        {
                            proResistance[countResistance] = VAHUp[i];
                            countResistance = countResistance + 1;
                        }
                        else if (VAHUp[i] < upperLimitWeakResistance)
                        {
                            proResistance[countResistance] = VAHUp[i];
                            countResistance = countResistance + 1;
                        }
                    }
                    else if (VAHUp[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightVAHUp[i] > 1.5 * iThreshold)
                        {
                            proSupport[countSupport] = VAHUp[i];
                            countSupport = countSupport + 1;
                        }
                        else if (VAHUp[i] > lowerLimitWeakSupport)
                        {
                            proSupport[countSupport] = VAHUp[i];
                            countSupport = countSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightVALUp[i] > iThreshold)
                    if (VALUp[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightVALUp[i] > 1.5 * iThreshold)
                        {
                            proResistance[countResistance] = VALUp[i];
                            countResistance = countResistance + 1;
                        }
                        else if (VALUp[i] < upperLimitWeakResistance)
                        {
                            proResistance[countResistance] = VALUp[i];
                            countResistance = countResistance + 1;
                        }
                    }
                    else if (VALUp[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightVALUp[i] > 1.5 * iThreshold)
                        {
                            proSupport[countSupport] = VALUp[i];
                            countSupport = countSupport + 1;
                        }
                        else if (VALUp[i] > lowerLimitWeakSupport)
                        {
                            proSupport[countSupport] = VALUp[i];
                            countSupport = countSupport + 1;
                        }
                    }
            }
            #endregion

        }
        #endregion

        #region -- SelectLinesWidthDifferentiate --
        private int countPOCres = 0;
        private int countPOCSup = 0;
        private int countVWAPres = 0;
        private int countVWAPSup = 0;
        private int countVAHres = 0;
        private int countVAHSup = 0;
        private int countVALres = 0;
        private int countVALSup = 0;
        private int countCLHres = 0;
        private int countCLHSup = 0;
        private int countCLLres = 0;
        private int countCLLSup = 0;
        public void SelectLinesWidthDifferentiate()
        {
            countPOCres = 0;
            countPOCSup = 0;
            countVWAPres = 0;
            countVWAPSup = 0;
            countVAHres = 0;
            countVAHSup = 0;
            countVALres = 0;
            countVALSup = 0;
            countCLHres = 0;
            countCLHSup = 0;
            countCLLres = 0;
            countCLLSup = 0;
            for (int i = 0; i < 20; i++)
            {
                proPOCRes[i] = 0;
                proPOCSup[i] = 0;
                proVWAPRes[i] = 0;
                proVWAPSup[i] = 0;
                proVAHRes[i] = 0;
                proVAHSup[i] = 0;
                proVALRes[i] = 0;
                proVALSup[i] = 0;
            }
                        
            #region - POC up -
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightPOCUp[i] > iThreshold)
                    if (POCUp[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightPOCUp[i] > 1.5 * iThreshold)
                        {
                            proPOCRes[countPOCres] = POCUp[i];
                            countPOCres = countPOCres + 1;
                        }
                        else if (POCUp[i] < upperLimitWeakResistance)
                        {
                            proPOCRes[countPOCres] = POCUp[i];
                            countPOCres = countPOCres + 1;
                        }
                    }
                    else if (POCUp[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightPOCUp[i] > 1.5 * iThreshold)
                        {
                            proPOCSup[countPOCSup] = POCUp[i];
                            countPOCSup = countPOCSup + 1;
                        }
                        else if (POCUp[i] > lowerLimitWeakSupport)
                        {
                            proPOCSup[countPOCSup] = POCUp[i];
                            countPOCSup = countPOCSup + 1;
                        }
                    }
            }
            #endregion

            #region - VWAP up -
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightVWAPUp[i] > iThreshold)
                    if (VWAPUp[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightVWAPUp[i] > 1.5 * iThreshold)
                        {
                            proVWAPRes[countVWAPres] = VWAPUp[i];
                            countVWAPres = countVWAPres + 1;
                        }
                        else if (VWAPUp[i] < upperLimitWeakResistance)
                        {
                            proVWAPRes[countVWAPres] = VWAPUp[i];
                            countVWAPres = countVWAPres + 1;
                        }
                    }
                    else if (VWAPUp[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightVWAPUp[i] > 1.5 * iThreshold)
                        {
                            proVWAPSup[countVWAPSup] = VWAPUp[i];
                            countVWAPSup = countVWAPSup + 1;
                        }
                        else if (VWAPUp[i] > lowerLimitWeakSupport)
                        {
                            proVWAPSup[countVWAPSup] = VWAPUp[i];
                            countVWAPSup = countVWAPSup + 1;
                        }
                    }
            }
            #endregion

            #region - VAH up -
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightVAHUp[i] > iThreshold)
                    if (VAHUp[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightVAHUp[i] > 1.5 * iThreshold)
                        {
                            proVAHRes[countVAHres] = VAHUp[i];
                            countVAHres = countVAHres + 1;
                        }
                        else if (VAHUp[i] < upperLimitWeakResistance)
                        {
                            proVAHRes[countVAHres] = VAHUp[i];
                            countVAHres = countVAHres + 1;
                        }
                    }
                    else if (VAHUp[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightVAHUp[i] > 1.5 * iThreshold)
                        {
                            proVAHSup[countVAHSup] = VAHUp[i];
                            countVAHSup = countVAHSup + 1;
                        }
                        else if (VAHUp[i] > lowerLimitWeakSupport)
                        {
                            proVAHSup[countVAHSup] = VAHUp[i];
                            countVAHSup = countVAHSup + 1;
                        }
                    }
            }
            #endregion

            #region - VAL up -
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightVALUp[i] > iThreshold)
                    if (VALUp[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightVALUp[i] > 1.5 * iThreshold)
                        {
                            proVALRes[countVALres] = VALUp[i];
                            countVALres = countVALres + 1;
                        }
                        else if (VALUp[i] < upperLimitWeakResistance)
                        {
                            proVALRes[countVALres] = VALUp[i];
                            countVALres = countVALres + 1;
                        }
                    }
                    else if (VALUp[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightVALUp[i] > 1.5 * iThreshold)
                        {
                            proVALSup[countVALSup] = VALUp[i];
                            countVALSup = countVALSup + 1;
                        }
                        else if (VALUp[i] > lowerLimitWeakSupport)
                        {
                            proVALSup[countVALSup] = VALUp[i];
                            countVALSup = countVALSup + 1;
                        }
                    }
            }
            #endregion
            
        }
        #endregion

        //==============================================================================================================================
        // Sorting Arrays fibResistance, fib, fibLine and  fibWeight with BubbleSort to prepare for Analyzer
        //==============================================================================================================================
        private bool goAhead = false;
        private int m = 0;
        private int n = 0;
        #region -- SortLines --
        public void SortLines()
        {
            #region -- Resistance Array is sorted in ascending order
            goAhead = true;
            m = countResistance;
            while (goAhead && m >= 1)
            {
                goAhead = false;
                for (int i = 1; i < m; i++)
                {
                    if (proResistance[i - 1] > proResistance[i])
                    {
                        dummy = proResistance[i - 1];
                        proResistance[i - 1] = proResistance[i];
                        proResistance[i] = dummy;
                        goAhead = true;
                    }
                }
                m = m - 1;
            }
            #endregion

            #region -- Support Array is sorted in descending order
            goAhead = true;
            n = countSupport;
            while (goAhead && n >= 1)
            {
                goAhead = false;
                for (int i = 1; i < n; i++)
                {
                    if (proSupport[i - 1] < proSupport[i])
                    {
                        dummy = proSupport[i - 1];
                        proSupport[i - 1] = proSupport[i];
                        proSupport[i] = dummy;
                        goAhead = true;
                    }
                }
                n = n - 1;
            }
            #endregion
        }
        #endregion

        #region -- SortLinesWithDifferentiate --
        public void SortLinesWithDifferentiate()
        {
            #region -- proPOCRes Array is sorted in ascending order
            goAhead = true;
            m = countPOCres;
            while (goAhead && m >= 1)
            {
                goAhead = false;
                for (int i = 1; i < m; i++)
                {
                    if (proPOCRes[i - 1] > proPOCRes[i])
                    {
                        dummy = proPOCRes[i - 1];
                        proPOCRes[i - 1] = proPOCRes[i];
                        proPOCRes[i] = dummy;
                        goAhead = true;
                    }
                }
                m = m - 1;
            }
            #endregion

            #region -- proPOCSup Array is sorted in descending order
            goAhead = true;
            n = countPOCSup;
            while (goAhead && n >= 1)
            {
                goAhead = false;
                for (int i = 1; i < n; i++)
                {
                    if (proPOCSup[i - 1] < proPOCSup[i])
                    {
                        dummy = proPOCSup[i - 1];
                        proPOCSup[i - 1] = proPOCSup[i];
                        proPOCSup[i] = dummy;
                        goAhead = true;
                    }
                }
                n = n - 1;
            }
            #endregion

            #region -- proVWAPRes Array is sorted in ascending order
            goAhead = true;
            m = countVWAPres;
            while (goAhead && m >= 1)
            {
                goAhead = false;
                for (int i = 1; i < m; i++)
                {
                    if (proVWAPRes[i - 1] > proVWAPRes[i])
                    {
                        dummy = proVWAPRes[i - 1];
                        proVWAPRes[i - 1] = proVWAPRes[i];
                        proVWAPRes[i] = dummy;
                        goAhead = true;
                    }
                }
                m = m - 1;
            }
            #endregion

            #region -- proVWAPSup Array is sorted in descending order
            goAhead = true;
            n = countVWAPSup;
            while (goAhead && n >= 1)
            {
                goAhead = false;
                for (int i = 1; i < n; i++)
                {
                    if (proVWAPSup[i - 1] < proVWAPSup[i])
                    {
                        dummy = proVWAPSup[i - 1];
                        proVWAPSup[i - 1] = proVWAPSup[i];
                        proVWAPSup[i] = dummy;
                        goAhead = true;
                    }
                }
                n = n - 1;
            }
            #endregion

            #region -- proVAHRes Array is sorted in ascending order
            goAhead = true;
            m = countVAHres;
            while (goAhead && m >= 1)
            {
                goAhead = false;
                for (int i = 1; i < m; i++)
                {
                    if (proVAHRes[i - 1] > proVAHRes[i])
                    {
                        dummy = proVAHRes[i - 1];
                        proVAHRes[i - 1] = proVAHRes[i];
                        proVAHRes[i] = dummy;
                        goAhead = true;
                    }
                }
                m = m - 1;
            }
            #endregion

            #region -- proVAHSup Array is sorted in descending order
            goAhead = true;
            n = countVAHSup;
            while (goAhead && n >= 1)
            {
                goAhead = false;
                for (int i = 1; i < n; i++)
                {
                    if (proVAHSup[i - 1] < proVAHSup[i])
                    {
                        dummy = proVAHSup[i - 1];
                        proVAHSup[i - 1] = proVAHSup[i];
                        proVAHSup[i] = dummy;
                        goAhead = true;
                    }
                }
                n = n - 1;
            }
            #endregion

            #region -- proVALRes Array is sorted in ascending order
            goAhead = true;
            m = countVALres;
            while (goAhead && m >= 1)
            {
                goAhead = false;
                for (int i = 1; i < m; i++)
                {
                    if (proVALRes[i - 1] > proVALRes[i])
                    {
                        dummy = proVALRes[i - 1];
                        proVALRes[i - 1] = proVALRes[i];
                        proVALRes[i] = dummy;
                        goAhead = true;
                    }
                }
                m = m - 1;
            }
            #endregion

            #region -- proVALSup Array is sorted in descending order
            goAhead = true;
            n = countVALSup;
            while (goAhead && n >= 1)
            {
                goAhead = false;
                for (int i = 1; i < n; i++)
                {
                    if (proVALSup[i - 1] < proVALSup[i])
                    {
                        dummy = proVALSup[i - 1];
                        proVALSup[i - 1] = proVALSup[i];
                        proVALSup[i] = dummy;
                        goAhead = true;
                    }
                }
                n = n - 1;
            }
            #endregion
            
        }
        #endregion

        private double RTTS(double value) { return Instrument.MasterInstrument.RoundToTickSize(value); }

        #region -- Drawing Functions - AzurITec --
        //Draw a line between 2 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawLine(double value, int idxslot1, int idxslot2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale)
        {
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

#if USE_WPF_COORDS
            Point p0 = new Point(GetX0(idxslot1, chartControl), chartScale.GetYByValueWpf(value));
            Point p1 = new Point(idxslot2 == 0 ? GetX0(Math.Min(CurrentBars[0], ChartBars.ToIndex), chartControl) : GetX0(idxslot2, chartControl), chartScale.GetYByValueWpf(value));
#else
            Point p0 = new Point(GetX0(idxslot1, chartControl), chartScale.GetYByValue(value));
            Point p1 = new Point(idxslot2 == 0 ? GetX0(Math.Min(CurrentBars[0], ChartBars.ToIndex), chartControl) : GetX0(idxslot2, chartControl), chartScale.GetYByValue(value));
#endif
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), dxbrush, width, strokestyle);

            strokestyle.Dispose();
        }
        private int GetX0(int bars, ChartControl chartControl) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars); }//NEW VERSION NT8
        #endregion

        //------------------------ Properties --------------------------------------
        #region -- Parameters --

        #region -- Volume Weight --

        [Range(0, double.MaxValue)]
        [Display(Name = "POC specific Weight", GroupName = "Volume Weight", Description = "POC specific Weight.", Order = 70)]
        public double specificWeightPOC { get; set; }
        [Range(0, double.MaxValue)]
        [Display(Name = "VWAP specific Weight", GroupName = "Volume Weight", Description = "VWAP specific Weight.", Order = 72)]
        public double specificWeightVWAP { get; set; }
        [Range(0, double.MaxValue)]
        [Display(Name = "VAH specific Weight", GroupName = "Volume Weight", Description = "VAH specific Weight.", Order = 74)]
        public double specificWeightVAH { get; set; }
        [Range(0, double.MaxValue)]
        [Display(Name = "VAL specific Weight", GroupName = "Volume Weight", Description = "VAL specific Weight.", Order = 76)]
        public double specificWeightVAL { get; set; }
        
        #endregion

        #region -- MTF Parameters --
        [Range(1, int.MaxValue)]
        [Display(Name = "Bar period for Swing bars (minutes)", GroupName = "MTF Parameters", Description = "Bar period for minute bars which are used to calculate the Volume Profile confluence lines", Order = 1)]
        public int iBarPeriod { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Total lookback (days)", GroupName = "MTF Parameters", Description = "", Order = 0)]
        public int iLookBackMinute { get; set; }

        [Display(Name = "Swing Timeframe", GroupName = "MTF Parameters", Description = "Timeframes used to identify Swings", Order = 2)]
        public ARC_VPCLevels_Resolution iLineDensity { get; set; }

        [Range(0.0, double.MaxValue)]
        [Display(Name = "Threshold for confluence lines", GroupName = "MTF Parameters", Description = "The treshold set the minumum statistical weight required for a confluence line. Confluence lines with a weight below the threshold value will not be shown.", Order = 3)]
        public double iThreshold { get; set; }
        #endregion

        #region -- Plots Settings --
        [Display(Name = "Differentiate levels", GroupName = "Plots Settings", Description = "", Order = 0)]
        public bool iDifferentiate { get; set; }

        [Display(Name = "Show POC levels", GroupName = "Plots Settings", Description = "", Order = 1)]
        public bool iShowPOC { get; set; }

        [Display(Name = "Show VWAP levels", GroupName = "Plots Settings", Description = "", Order = 2)]
        public bool iShowVWAP { get; set; }

        [Display(Name = "Show VAH levels", GroupName = "Plots Settings", Description = "", Order = 3)]
        public bool iShowVAH { get; set; }

        [Display(Name = "Show VAL levels", GroupName = "Plots Settings", Description = "", Order = 4)]
        public bool iShowVAL { get; set; }
        
        [Range(1, int.MaxValue)]
        [Display(Name = "Line width", GroupName = "Plots Settings", Description = "Line width", Order = 20)]
        public int iLineWidth { get; set; }

        [Display(Name = "Plot style", GroupName = "Plots Settings", Description = "Plot style", Order = 21)]
        public PlotStyle iPlotStyle { get; set; }

        [Display(Name = "Dash style", GroupName = "Plots Settings", Description = "Dash style", Order = 22)]
        public DashStyleHelper iDashStyle { get; set; }
        #endregion

        #region -- Plots Colors --
        [XmlIgnore]
        [Display(Name = "Resistance lines", GroupName = "Plots Colors", Description = "Only when 'Differentiate Levels' is unchecked", Order = 10)]
        public Brush iResistanceColor { get; set; }
        [Browsable(false)]
        public string ResistanceColorSerialize
        {
            get { return Serialize.BrushToString(iResistanceColor); }
            set { iResistanceColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Support lines", GroupName = "Plots Colors", Description = "Only when 'Differentiate Levels' is unchecked", Order = 11)]
        public Brush iSupportColor { get; set; }
        [Browsable(false)]
        public string SupportColorSerialize
        {
            get { return Serialize.BrushToString(iSupportColor); }
            set { iSupportColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "POC lines", GroupName = "Plots Colors", Description = "Select color for all POC lines (Only when 'Differentiate Levels' is checked)", Order = 13)]
        public Brush iPOCColor { get; set; }
        [Browsable(false)]
        public string iPOCColorSerialize
        {
            get { return Serialize.BrushToString(iPOCColor); }
            set { iPOCColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "VWAP lines", GroupName = "Plots Colors", Description = "Select color for all VWAP lines (Only when 'Differentiate Levels' is checked)", Order = 14)]
        public Brush iVWAPColor { get; set; }
        [Browsable(false)]
        public string iVWAPColorSerialize
        {
            get { return Serialize.BrushToString(iVWAPColor); }
            set { iVWAPColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "VAH lines", GroupName = "Plots Colors", Description = "Select color for all VAH lines (Only when 'Differentiate Levels' is checked)", Order = 15)]
        public Brush iVAHColor { get; set; }
        [Browsable(false)]
        public string iVAHColorSerialize
        {
            get { return Serialize.BrushToString(iVAHColor); }
            set { iVAHColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "VAL lines", GroupName = "Plots Colors", Description = "Select color for all VAL lines (Only when 'Differentiate Levels' is checked)", Order = 16)]
        public Brush iVALColor { get; set; }
        [Browsable(false)]
        public string iVALColorSerialize
        {
            get { return Serialize.BrushToString(iVALColor); }
            set { iVALColor = Serialize.StringToBrush(value); }
        }

        #endregion

        #region -- Levels Parameters --
        [Display(Name = "Extend Levels", GroupName = "Levels Parameters", Description = "Exetnd or not Levels", Order = 0)]
        public bool iExtendLevels { get; set; }

        [Range(0, Double.MaxValue)]
        [Display(Name = "SR ATR Break Filter", GroupName = "Levels Parameters", Description = "Support and Resistance ATR Break Filter", Order = 10)]
        public double iSRBreak { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Extended Line width", GroupName = "Levels Parameters", Description = "Extended Line width", Order = 15)]
        public int iExtendedLineWidth { get; set; }

        [Range(0, 100)]
        [Display(Name = "Extended Line Opacity (%)", GroupName = "Levels Parameters", Description = "The opacity in percent.", Order = 20)]
        public int iExtendedLineOpacity { get; set; }
		
		/*
	    * JQ 11.18.2017
	    * Added indicator version number on the property window.
        * */
		//---start--
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 30)]
        public string indicatorVersion { get { return VERSION; } }
		//--end--
		
        #endregion

        #endregion

        //------------------------------ Plots -------------------------------------
                #region -- Confluences ALL Together --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence0 { get { return Values[0]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence1 { get { return Values[1]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence2 { get { return Values[2]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence3 { get { return Values[3]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence4 { get { return Values[4]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence5 { get { return Values[5]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence6 { get { return Values[6]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence7 { get { return Values[7]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence8 { get { return Values[8]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence9 { get { return Values[9]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence10 { get { return Values[10]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence11 { get { return Values[11]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence12 { get { return Values[12]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence13 { get { return Values[13]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence14 { get { return Values[14]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence15 { get { return Values[15]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence16 { get { return Values[16]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence17 { get { return Values[17]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence18 { get { return Values[18]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence19 { get { return Values[19]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence20 { get { return Values[20]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence21 { get { return Values[21]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence22 { get { return Values[22]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence23 { get { return Values[23]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence24 { get { return Values[24]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence25 { get { return Values[25]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence26 { get { return Values[26]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence27 { get { return Values[27]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence28 { get { return Values[28]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence29 { get { return Values[29]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence30 { get { return Values[30]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence31 { get { return Values[31]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence32 { get { return Values[32]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence33 { get { return Values[33]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence34 { get { return Values[34]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence35 { get { return Values[35]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence36 { get { return Values[36]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence37 { get { return Values[37]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence38 { get { return Values[38]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence39 { get { return Values[39]; } }
        #endregion

        #region -- Confluences Differentiate --

        #region -- POC --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC0 { get { return Values[40]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC1 { get { return Values[41]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC2 { get { return Values[42]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC3 { get { return Values[43]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC4 { get { return Values[44]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC5 { get { return Values[45]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC6 { get { return Values[46]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC7 { get { return Values[47]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC8 { get { return Values[48]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC9 { get { return Values[49]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC10 { get { return Values[50]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC11 { get { return Values[51]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC12 { get { return Values[52]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC13 { get { return Values[53]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC14 { get { return Values[54]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC15 { get { return Values[55]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC16 { get { return Values[56]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC17 { get { return Values[57]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC18 { get { return Values[58]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfPOC19 { get { return Values[59]; } }
        #endregion

        #region -- VWAP --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP0 { get { return Values[60]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP1 { get { return Values[61]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP2 { get { return Values[62]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP3 { get { return Values[63]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP4 { get { return Values[64]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP5 { get { return Values[65]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP6 { get { return Values[66]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP7 { get { return Values[67]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP8 { get { return Values[68]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP9 { get { return Values[69]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP10 { get { return Values[70]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP11 { get { return Values[71]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP12 { get { return Values[72]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP13 { get { return Values[73]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP14 { get { return Values[74]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP15 { get { return Values[75]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP16 { get { return Values[76]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP17 { get { return Values[77]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP18 { get { return Values[78]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVWAP19 { get { return Values[79]; } }
        #endregion

        #region -- VAH --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH0 { get { return Values[80]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH1 { get { return Values[81]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH2 { get { return Values[82]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH3 { get { return Values[83]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH4 { get { return Values[84]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH5 { get { return Values[85]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH6 { get { return Values[86]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH7 { get { return Values[87]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH8 { get { return Values[88]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH9 { get { return Values[89]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH10 { get { return Values[90]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH11 { get { return Values[91]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH12 { get { return Values[92]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH13 { get { return Values[93]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH14 { get { return Values[94]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH15 { get { return Values[95]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH16 { get { return Values[96]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH17 { get { return Values[97]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH18 { get { return Values[98]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAH19 { get { return Values[99]; } }
        #endregion

        #region -- VAL --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL0 { get { return Values[100]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL1 { get { return Values[101]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL2 { get { return Values[102]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL3 { get { return Values[103]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL4 { get { return Values[104]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL5 { get { return Values[105]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL6 { get { return Values[106]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL7 { get { return Values[107]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL8 { get { return Values[108]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL9 { get { return Values[109]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL10 { get { return Values[110]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL11 { get { return Values[111]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL12 { get { return Values[112]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL13 { get { return Values[113]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL14 { get { return Values[114]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL15 { get { return Values[115]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL16 { get { return Values[116]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL17 { get { return Values[117]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL18 { get { return Values[118]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ConfVAL19 { get { return Values[119]; } }
        #endregion
        
        #endregion

        //------------------------ Nested Enum / Class --------------------------------------
        internal enum gztLevelExtendState { NEW, VALID, BROKEN }
        internal enum gztLevelExtendType { SUPPORT, RESISTANCE }
        internal enum gztLevelExtendProfileType { ALL, POC, VWAP, VAH, VAL }

        #region internal class gztSwingProfile
        internal class gztSwingProfile
        {
            public double priceMAX { get; set; }
            public double[] levelWeights { get; set; }
            public double priceMIN { get; set; }
            public double volumeTotal { get; set; }
            public DateTime dateStart { get; set; }
            public DateTime dateEnd { get; set; }
            public List<int> profileTimeFrames { get; set; }

            public double POC { get; set; }
            public double VWAP { get; set; }
            public double VAH { get; set; }
            public double VAL { get; set; }

            public gztSwingProfile(int nbLevels, int timeframeIndex)
            {
                levelWeights = new double[nbLevels];
                profileTimeFrames = new List<int>(10);
                profileTimeFrames.Add(timeframeIndex);
            }
        }
        #endregion

        #region internal class gztExtendedLevel
        internal class gztExtendedLevel
        {
            public double pPrice { get; set; }
            public gztLevelExtendState pSate { get; set; }
            public gztLevelExtendType pType { get; set; }
            public gztLevelExtendProfileType pProfileType { get; set; }
            public int pSlotStart { get; set; }
            public int pSlotEnd { get; set; }

            public static bool isBrokenResistance(double range, double level, double high) { return high - level > range; }
            public static bool isBrokenSupport(double range, double level, double low) { return level - low > range; }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_VPCLevels[] cacheARC_VPCLevels;
		public ARC.ARC_VPCLevels ARC_VPCLevels()
		{
			return ARC_VPCLevels(Input);
		}

		public ARC.ARC_VPCLevels ARC_VPCLevels(ISeries<double> input)
		{
			if (cacheARC_VPCLevels != null)
				for (int idx = 0; idx < cacheARC_VPCLevels.Length; idx++)
					if (cacheARC_VPCLevels[idx] != null &&  cacheARC_VPCLevels[idx].EqualsInput(input))
						return cacheARC_VPCLevels[idx];
			return CacheIndicator<ARC.ARC_VPCLevels>(new ARC.ARC_VPCLevels(), input, ref cacheARC_VPCLevels);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_VPCLevels ARC_VPCLevels()
		{
			return indicator.ARC_VPCLevels(Input);
		}

		public Indicators.ARC.ARC_VPCLevels ARC_VPCLevels(ISeries<double> input )
		{
			return indicator.ARC_VPCLevels(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_VPCLevels ARC_VPCLevels()
		{
			return indicator.ARC_VPCLevels(Input);
		}

		public Indicators.ARC.ARC_VPCLevels ARC_VPCLevels(ISeries<double> input )
		{
			return indicator.ARC_VPCLevels(input);
		}
	}
}

#endregion
