#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using RectangleF = SharpDX.RectangleF;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public class ARC_CWAPAlgo_ARC_VolumeCluster : ARC_CWAPAlgo_ARCIndicatorBase
	{
		public override string ProductVersion => "v1.0.0 (11/5/2023)";
		public override bool ColicensedOnly => true;

		[Browsable(false)]
		public Series<double> ClusterCenter
		{
			get
			{
				Update();
				return clusterCenter;
			}
		}
		private Series<double> clusterCenter;

		private Series<double> clusterTop;
		private Series<double> clusterBottom;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && !this.ARC_CWAPAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				Name = "Volume Cluster";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				IsSuspendedWhileInactive = true;

				TicksPerCluster = 2;

				ShowVolumeCluster = true;
				VolumeClusterOutlineColor = Brushes.Black;
				VolumeClusterFillColor = Brushes.LightGray;
				ClusterFillOpacity = 75;
				ClusterOutlineThickness = 1;

				AddPlot(new Stroke(Brushes.Black, 3), PlotStyle.Dot, "Centers");
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Tick, 1);
			}
			else if (State == State.DataLoaded)
			{
				clusterTop = new Series<double>(this, MaximumBarsLookBack.Infinite);
				clusterCenter = new Series<double>(this, MaximumBarsLookBack.Infinite);
				clusterBottom = new Series<double>(this, MaximumBarsLookBack.Infinite);
			}
		}

		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_CWAPAlgo_IsLicensed())
				return;

			if (BarsInProgress == 0)
				CalculateCluster();
		}

		private bool hasPrintedBarSizeExceedsMaWarning;
		private void CalculateCluster()
		{
			var clusterHeight = (TicksPerCluster - 1) * TickSize;
			if (Highs[0][0] - Lows[0][0] < clusterHeight)
			{
				clusterTop[0] = Highs[0][0];
				clusterBottom[0] = Lows[0][0];
				clusterCenter[0] = (clusterTop[0] + clusterBottom[0]) / 2;
				return;
			}

			if (CurrentBars[0] < 1)
				return;

			var curTime = Times[0][0];
			var lastDiffTimedBar = MRO(() => Times[0][0] != curTime, 1, Math.Min(255, CurrentBars[0]));
			if (lastDiffTimedBar == -1)
			{
				clusterTop[0] = clusterTop[1];
				clusterBottom[0] = clusterBottom[1];
				clusterCenter[0] = clusterCenter[1];
				return;
			}

			if ((Highs[0][0] - Lows[0][0]) / TickSize > 1e5)
			{
				if (hasPrintedBarSizeExceedsMaWarning)
					return;

				hasPrintedBarSizeExceedsMaWarning = true;
				Log($"Bar at time {Times[0][0]} exceeded max ticks per bar of 10,000. All bars that exceed this threshold will be skipped.", LogLevel.Warning);
				return;
			}

			var volumes = new double[(int)Math.Round((Highs[0][0] - Lows[0][0]) / TickSize) + 1];
			for (var i = 0; i < CurrentBars[1]; i++)
			{
				if (Times[1][i] <= Times[0][lastDiffTimedBar])
					break;

				if (Times[1][i] > Times[0][0])
					continue;

				if (Closes[1][i].ApproxCompare(Highs[0][0]) == 1 || Closes[1][i].ApproxCompare(Lows[0][0]) == -1)
					continue;

				var idx = (int)Math.Round((Closes[1][i] - Lows[0][0]) / TickSize);
				volumes[idx] += Volumes[1][i];
			}

			// No clusters on gap bars
			if (!volumes.Any() || volumes.Max().ApproxCompare(0) == 0)
				return;

			var maxClusterVolume = 0d;
			var clusterVolume = 0d;
			for (var i = 0; i < volumes.Length; i++)
			{
				clusterVolume += volumes[i];
				if (i < TicksPerCluster - 1)
					continue;

				if (i >= TicksPerCluster)
					clusterVolume -= volumes[i - TicksPerCluster];

				if (clusterVolume <= maxClusterVolume)
					continue;

				// TODO Go with the cluster closest to the body if two have the same max volume
				clusterTop[0] = Lows[0][0] + TickSize * i;
				clusterBottom[0] = clusterTop[0] - clusterHeight;
				clusterCenter[0] = (clusterTop[0] + clusterBottom[0]) / 2;
				maxClusterVolume = clusterVolume;
			}
		}

		private void DrawRect(ChartScale chartScale, float midX, float width, double topPrice, double bottomPrice, SharpDX.Direct2D1.Brush outlineBrush, SharpDX.Direct2D1.Brush fillBrush, int outlineThickness)
		{
			var ys = new[] { topPrice, bottomPrice }
				.Select(chartScale.GetYByValue)
				.ToArray();
			var rect = new RectangleF(midX - width / 2, ys[1], width, ys[0] - ys[1]);
			RenderTarget.FillRectangle(rect, fillBrush);
			if (outlineBrush == null)
				return;

			var outlineRect = new RectangleF(midX - width / 2 + outlineThickness / 2, ys[1], width - outlineThickness, ys[0] - ys[1]);
			RenderTarget.DrawRectangle(outlineRect, outlineBrush, outlineThickness);
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			if (!this.ARC_CWAPAlgo_IsLicensed())
				return;

			var shapeWidth = chartControl.GetBarPaintWidth(ChartBars);
			using var clusterDxBrush = VolumeClusterOutlineColor.ToDxBrush(RenderTarget);
			using var clusterDxFillBrush = VolumeClusterFillColor.ToDxBrush(RenderTarget, ClusterFillOpacity / 100f);
			for (var i = ChartBars.FromIndex; i <= ChartBars.ToIndex; i++)
				if (clusterTop.IsValidDataPointAt(i) && ShowVolumeCluster)
					DrawRect(chartScale, chartControl.GetXByBarIndex(ChartBars, i), shapeWidth, clusterBottom.GetValueAt(i), clusterTop.GetValueAt(i), clusterDxBrush, clusterDxFillBrush, ClusterOutlineThickness);
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Ticks Per Cluster", GroupName = "Parameters", Order = 0, Description = "The number of ticks that make up a cluster.")]
		public int TicksPerCluster { get; set; }

		#region Visuals
		private const string VisualsParameterGroupName = "Visuals";

		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Show Volume Clusters", GroupName = VisualsParameterGroupName, Order = 0)]
		public bool ShowVolumeCluster { get; set; }

		[XmlIgnore]
		[ARC_CWAPAlgo_HideUnless(nameof(ShowVolumeCluster), ARC_CWAPAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Volume Cluster (Fill)", GroupName = VisualsParameterGroupName, Order = 1)]
		public Brush VolumeClusterFillColor { get; set; }

		[Range(0, 100)]
		[ARC_CWAPAlgo_HideUnless(nameof(ShowVolumeCluster), ARC_CWAPAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Cluster - Opacity (%)", GroupName = VisualsParameterGroupName, Order = 2, Description = "In percent, the opacity of the cluster fill.")]
		public int ClusterFillOpacity { get; set; }

		[Browsable(false)]
		public string VolumeClusterFillColorSerialize
		{
			get => Serialize.BrushToString(VolumeClusterFillColor);
			set => VolumeClusterFillColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[ARC_CWAPAlgo_HideUnless(nameof(ShowVolumeCluster), ARC_CWAPAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Volume Cluster (Outline)", GroupName = VisualsParameterGroupName, Order = 3)]
		public Brush VolumeClusterOutlineColor { get; set; }

		[Browsable(false)]
		public string VolumeClusterOutlineColorSerialize
		{
			get => Serialize.BrushToString(VolumeClusterOutlineColor);
			set => VolumeClusterOutlineColor = Serialize.StringToBrush(value);
		}

		[Range(0, int.MaxValue)]
		[ARC_CWAPAlgo_HideUnless(nameof(ShowVolumeCluster), ARC_CWAPAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Cluster - Outline Thickness (Pixels)", GroupName = VisualsParameterGroupName, Order = 4, Description = "In pixels, the thickness of the cluster outline.")]
		public int ClusterOutlineThickness { get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_CWAPAlgo_ARC_VolumeCluster[] cacheARC_CWAPAlgo_ARC_VolumeCluster;
		public ARC.ARC_CWAPAlgo_ARC_VolumeCluster ARC_CWAPAlgo_ARC_VolumeCluster(int ticksPerCluster)
		{
			return ARC_CWAPAlgo_ARC_VolumeCluster(Input, ticksPerCluster);
		}

		public ARC.ARC_CWAPAlgo_ARC_VolumeCluster ARC_CWAPAlgo_ARC_VolumeCluster(ISeries<double> input, int ticksPerCluster)
		{
			if (cacheARC_CWAPAlgo_ARC_VolumeCluster != null)
				for (int idx = 0; idx < cacheARC_CWAPAlgo_ARC_VolumeCluster.Length; idx++)
					if (cacheARC_CWAPAlgo_ARC_VolumeCluster[idx] != null && cacheARC_CWAPAlgo_ARC_VolumeCluster[idx].TicksPerCluster == ticksPerCluster && cacheARC_CWAPAlgo_ARC_VolumeCluster[idx].EqualsInput(input))
						return cacheARC_CWAPAlgo_ARC_VolumeCluster[idx];
			return CacheIndicator<ARC.ARC_CWAPAlgo_ARC_VolumeCluster>(new ARC.ARC_CWAPAlgo_ARC_VolumeCluster(){ TicksPerCluster = ticksPerCluster }, input, ref cacheARC_CWAPAlgo_ARC_VolumeCluster);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_CWAPAlgo_ARC_VolumeCluster ARC_CWAPAlgo_ARC_VolumeCluster(int ticksPerCluster)
		{
			return indicator.ARC_CWAPAlgo_ARC_VolumeCluster(Input, ticksPerCluster);
		}

		public Indicators.ARC.ARC_CWAPAlgo_ARC_VolumeCluster ARC_CWAPAlgo_ARC_VolumeCluster(ISeries<double> input , int ticksPerCluster)
		{
			return indicator.ARC_CWAPAlgo_ARC_VolumeCluster(input, ticksPerCluster);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_CWAPAlgo_ARC_VolumeCluster ARC_CWAPAlgo_ARC_VolumeCluster(int ticksPerCluster)
		{
			return indicator.ARC_CWAPAlgo_ARC_VolumeCluster(Input, ticksPerCluster);
		}

		public Indicators.ARC.ARC_CWAPAlgo_ARC_VolumeCluster ARC_CWAPAlgo_ARC_VolumeCluster(ISeries<double> input , int ticksPerCluster)
		{
			return indicator.ARC_CWAPAlgo_ARC_VolumeCluster(input, ticksPerCluster);
		}
	}
}

#endregion
