#define DoLicense
#define MODERATORS

//+----------------------------------------------------------------------------------------------+
//| Copyright © <2019>  NSTradingAcademy.com
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators.ARC.Sup;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	/// <summary>
	/// The ATR trailing stop is a modified version presented by Sylvain Vervoort in 'Average True Range Trailing Stops' (Stocks & Commodities V. 27:6). The long stop is calculated 
	/// by subtracting a multiple of the average true range from the close and comparing it to the prior value for the long stop. Accordingly the short stop is calculated by adding a multiple
	///  of the average true range to the close and comparing it to the prior value for the short stop."; 
	/// </summary>
	[Gui.CategoryOrder("Input Parameters", 10)]
	[Gui.CategoryOrder("ATR Band Parameters", 15)]
	[Gui.CategoryOrder("Display Options", 20)]
	[Gui.CategoryOrder("Data Series", 30)]
	[Gui.CategoryOrder("Set up", 40)]
	[Gui.CategoryOrder("Visual", 50)]
	[Gui.CategoryOrder("Plots", 60)]
//	[Gui.CategoryOrder("Paint Bars", 70)]
	[Gui.CategoryOrder("Sound Alerts", 80)]
	[Gui.CategoryOrder("Version", 90)]
	public class ARC_ATRTrailingStop : Indicator
	{
		private bool IsDebug          = false;
		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName        = "ATR_TrailingStop";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "21210","25900", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId,LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion
		
		private string VERSION = "1.0";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		#region Variables
        private int 						rangePeriod					= 10; 
		private int							displacement				= 0;
		private int							totalBarsRequiredToPlot		= 0;
		private int							shift						= 0;
//		private bool						useModifiedATR				= false;
//		private bool						reverseIntraBar				= false;
		private bool 						showTriangles 				= false;
		private bool 						showPaintBars 				= false;
		private bool						showStopDots				= true;
		private bool 						showStopLine				= true;
		private bool						soundAlerts					= false;
		private bool 						gap0						= false;
		private bool 						gap1						= false;
		private bool						stoppedOut					= false;
		private bool						drawTriangleUp				= false;
		private bool						drawTriangleDown			= false;
		private bool						calculateFromPriceData		= true;
		private bool						indicatorIsOnPricePanel		= true;
		private double 						offset						= 0.0;
		private double						trailingAmount				= 0.0;
		private double						low							= 0.0;
		private double						high						= 0.0;
		private double						labelOffset					= 0.0;
		private SessionIterator				sessionIterator				= null;
		private int 						plot0Width 					= 2;
		private PlotStyle 					plot0Style					= PlotStyle.Dot;
		private int 						plot1Width 					= 1;
		private PlotStyle 					plot1Style					= PlotStyle.Line;
		private Brush						upBrush						= Brushes.Blue;
		private Brush						downBrush					= Brushes.Red;
		private Brush						upBrushUp					= Brushes.Blue;
		private Brush						upBrushDown					= Brushes.LightSkyBlue;
		private Brush						downBrushUp					= Brushes.LightCoral;
		private Brush						downBrushDown				= Brushes.Red;
		private Brush						upBrushOutline				= Brushes.Black;
		private Brush						downBrushOutline			= Brushes.Black;
		private Brush						alertBackBrush				= Brushes.Black;
		private Brush						errorBrush					= Brushes.Black;
		private SimpleFont					dotFont						= null;
		private SimpleFont					triangleFont				= null;
		private SimpleFont					errorFont					= null;
		private int							triangleFontSize			= 10;
		private string						dotString					= "n";
		private string						triangleStringUp			= "5";
		private string						triangleStringDown			= "6";
		private string						errorText					= "The ARC_ATRTrailingStop cannot be used with a negative displacement.";
		private int							rearmTime					= 30;
		private string						pathNewUptrend				= "";
		private string						pathNewDowntrend			= "";
		private string						pathPotentialUptrend		= "";
		private string						pathPotentialDowntrend		= "";
		private const string				versionString				= "v 1.0";
		private Series<double>				preliminaryTrend;
		private Series<double>				trend;
		private Series<double>				currentStopLong;
		private Series<double>				currentStopShort;
		private ISeries<double>				offsetSeries;
		private ATR							barVolatility;
		private double BandATR = 0;
		private const double LONG = 1;
		private const double SHORT = -1;
		#endregion

		protected override void OnStateChange()
		{
			#region OnStateChange
			if (State == State.SetDefaults)
			{
				Description					= "\r\nThe ATR trailing stop is a modified version presented by Sylvain Vervoort in 'Average True Range Trailing Stops' (Stocks & Commodities V. 27:6). The long stop is calculated"
											  + " by subtracting a multiple of the average true range from the close and comparing it to the prior value for the long stop. Accordingly the short stop is calculated by"
											  + " adding a multiple of the average true range to the close and comparing it to the prior value for the short stop."; 
				Name						= "ARC_ATRTrailingStop";
				Calculate					= Calculate.OnPriceChange;
				IsSuspendedWhileInactive	= false;
				IsOverlay					= true;
				ArePlotsConfigurable		= false;
				pBand1Mult = 1.0;
				pBand2Mult = 2;
				pBand3Mult = 3.0;
				pRoundBandToNearestTick = false;
				pBandATRPeriod = 14;
				pBand1Enabled = true;
				pBand1Brush   = Brushes.Blue;
				pBand1Opacity = 20;
				pBand2Enabled = false;
				pBand2Brush   = Brushes.Orange;
				pBand2Opacity = 20;
				pBand3Enabled = false;
				pBand3Brush   = Brushes.Red;
				pBand3Opacity = 20;

				AddPlot(new Stroke(Brushes.Gray, 2),   PlotStyle.Dot, "StopDot");	
				AddPlot(new Stroke(Brushes.Gray, 2),   PlotStyle.Line, "StopLine");
				AddPlot(new Stroke(Brushes.Yellow, 2), PlotStyle.Dot, "ReverseDot");
				AddPlot(new Stroke(Brushes.Blue, 1),   PlotStyle.Line, "BandEdge U3");
				AddPlot(new Stroke(Brushes.Blue, 1),   PlotStyle.Line, "BandEdge U2");
				AddPlot(new Stroke(Brushes.Blue, 1),   PlotStyle.Line, "BandEdge U1");
				AddPlot(new Stroke(Brushes.Maroon, 1), PlotStyle.Line, "BandEdge L1");
				AddPlot(new Stroke(Brushes.Maroon, 1), PlotStyle.Line, "BandEdge L2");
				AddPlot(new Stroke(Brushes.Maroon, 1), PlotStyle.Line, "BandEdge L3");

				newUptrend					= "SOUND OFF";
				newDowntrend				= "SOUND OFF";
				potentialUptrend			= "SOUND OFF";
				potentialDowntrend			= "SOUND OFF";
			}
			else if (State == State.Configure)
			{
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif

				displacement       = Displacement;
				BarsRequiredToPlot = 2*rangePeriod;
				totalBarsRequiredToPlot = BarsRequiredToPlot + displacement;
				Plots[0].PlotStyle = plot0Style;
				Plots[0].Width     = plot0Width;
				Plots[1].PlotStyle = plot1Style;
				Plots[1].Width     = plot1Width;
			}
			else if (State == State.DataLoaded)
			{
				preliminaryTrend = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				trend = new Series<double>(this, MaximumBarsLookBack.Infinite);
				currentStopLong = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				currentStopShort = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				offsetSeries = ARC_ATR(Inputs[0], ARC_ATRCalcMode.Wilder, rangePeriod);
				barVolatility = ATR(Closes[0], 256);
				if(Input is PriceSeries)
					calculateFromPriceData = true;
				else
					calculateFromPriceData = false;
		    	sessionIterator = new SessionIterator(Bars);
			}	
			else if (State == State.Historical)
			{
				if(displacement < 0)
				{
					if(ChartBars != null)
					{	
						errorBrush = ChartControl.Properties.AxisPen.Brush;
						errorBrush.Freeze();
						errorFont = new SimpleFont("Arial", 24);
						indicatorIsOnPricePanel = (ChartPanel.PanelIndex == ChartBars.Panel);
						DrawOnPricePanel = false;
						Draw.TextFixed(this, "error text", errorText, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
					}	
					return;
				}
				if(ChartBars != null)
					indicatorIsOnPricePanel = (ChartPanel.PanelIndex == ChartBars.Panel);
				else
					indicatorIsOnPricePanel = false;		
				if(Calculate == Calculate.OnBarClose)// && !reverseIntraBar)
					shift = displacement + 1;
				else
					shift = displacement;
				gap0 = (plot0Style == PlotStyle.Line)||(plot0Style == PlotStyle.Square);
				gap1 = (plot1Style == PlotStyle.Line)||(plot1Style == PlotStyle.Square);
				dotFont = new SimpleFont("Webdings", plot1Width + 2);
				triangleFont = new SimpleFont("Webdings", 3*triangleFontSize);
				pathNewUptrend = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds", newUptrend);
				pathNewDowntrend = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds", newDowntrend);
				pathPotentialUptrend = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds", potentialUptrend);
				pathPotentialDowntrend = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds", potentialDowntrend);
			}
			#endregion
		}

		private int RegionID = 0;
		protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(IsFirstTickOfBar && CurrentBar>pBandATRPeriod){
				double sum = 0;
				for(int i = 1; i<=pBandATRPeriod; i++) sum = sum + Range()[i];
				BandATR = sum/pBandATRPeriod;
				if(pRoundBandToNearestTick) BandATR = Instrument.MasterInstrument.RoundToTickSize(BandATR);
			}
			if(displacement < 0)
				return;

			if (CurrentBar < 2)
			{ 
				preliminaryTrend[0] = 1.0;
				trend[0] = 1.0;
				StopDot[0] = Input[0];
				StopLine[0] = Input[0];
				if(showReverseDots)
					ReverseDot[0] = Input[0]; 
				PlotBrushes[0][0] = Brushes.Transparent;
				PlotBrushes[1][0] = Brushes.Transparent;
				PlotBrushes[2][0] = Brushes.Transparent;
				return; 
			}
			if (IsFirstTickOfBar)
			{
				offset = Math.Max(TickSize, offsetSeries[1]);
				trailingAmount = multiplier * offset;
				labelOffset = 0.3 * barVolatility[1];
				if(preliminaryTrend[1] == LONG)
				{
					if (calculateFromPriceData)
					{
						currentStopLong[0] = Math.Max(currentStopLong[1], Math.Min(Input[1] - trailingAmount, Input[1] - TickSize));
						currentStopShort[0] = Input[1] + trailingAmount;
					}
					else
					{
						currentStopLong[0] = Math.Max(currentStopLong[1], Input[1] - trailingAmount);
						currentStopShort[0] = Input[1] + trailingAmount;
					}	
					StopDot[0] = currentStopLong[0];
					StopLine[0] = currentStopLong[0];
					if(showReverseDots)
						ReverseDot[0] = currentStopShort[0];
					if(showStopDots)
					{	
						if(gap0 && preliminaryTrend[2] == SHORT)
							PlotBrushes[0][0]= Brushes.Transparent;
						else
							PlotBrushes[0][0] = upBrush;
					}
					else
						PlotBrushes[0][0]= Brushes.Transparent;
					if(showStopLine)
					{	
						if(gap1 && preliminaryTrend[2] == SHORT)
							PlotBrushes[1][0]= Brushes.Transparent;
						else
							PlotBrushes[1][0] = upBrush;
					}
					else
						PlotBrushes[1][0]= Brushes.Transparent;
				}
				else	
				{	
					if (calculateFromPriceData)
					{
						currentStopShort[0] = Math.Min(currentStopShort[1], Math.Max(Input[1] + trailingAmount, Input[1] + TickSize));
						currentStopLong[0] = Input[1] - trailingAmount;
					}
					else
					{
						currentStopShort[0] = Math.Min(currentStopShort[1], Input[1] + trailingAmount);
						currentStopLong[0] = Input[1] - trailingAmount;
					}
					StopDot[0] = currentStopShort[0];
					StopLine[0] = currentStopShort[0];
					if(showReverseDots)
						ReverseDot[0] = currentStopLong[0];
					if(showStopDots)
					{	
						if(gap0 && preliminaryTrend[2] == LONG)
							PlotBrushes[0][0]= Brushes.Transparent;
						else
							PlotBrushes[0][0] = downBrush;
					}
					else
						PlotBrushes[0][0]= Brushes.Transparent;
					if(showStopLine)
					{	
						if(gap1 && preliminaryTrend[2] == LONG)
							PlotBrushes[1][0]= Brushes.Transparent;
						else
							PlotBrushes[1][0] = downBrush;
					}
					else
						PlotBrushes[1][0]= Brushes.Transparent;
				}
				
				if(showStopLine && CurrentBar >= BarsRequiredToPlot)
				{	
					DrawOnPricePanel = false;
					if(plot1Style == PlotStyle.Square && !showStopDots) 
					{
						if(trend[1] == LONG && trend[2] == SHORT)
							Draw.Text(this, "dot" + CurrentBar, false, dotString, -displacement, StopLine[0], 0 , upBrush, dotFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0); 
						else if(trend[1] == SHORT && trend[2] == LONG)
							Draw.Text(this, "dot" + CurrentBar, false, dotString, -displacement, StopLine[0], 0 , downBrush, dotFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0); 
					}
				}
				
				if(showPaintBars && CurrentBar >= BarsRequiredToPlot)
				{
					if (preliminaryTrend[1] == LONG)
					{	
						if(Open[0] < Close[0])
							BarBrushes[-displacement] = upBrushUp;
						else
							BarBrushes[-displacement] = upBrushDown;
						CandleOutlineBrushes[-displacement] = upBrushOutline;
					}	
					else
					{	
						if(Open[0] < Close[0])
							BarBrushes[-displacement] = downBrushUp;
						else
							BarBrushes[-displacement] = downBrushDown;
						CandleOutlineBrushes[-displacement] = downBrushOutline;
					}
				}
				stoppedOut = false;
			}
			
			if (preliminaryTrend[1] == LONG && Input[0] < currentStopLong[0])
				preliminaryTrend[0] = SHORT;
			else if (preliminaryTrend[1] == SHORT && Input[0] > currentStopShort[0])
				preliminaryTrend[0] = LONG;
			else
				preliminaryTrend[0] = preliminaryTrend[1];
			// this information can be accessed by a strategy - trend holds the confirmed trend, whereas preliminaryTrend may hold a preliminary trend only
			if(Calculate == Calculate.OnBarClose)
				trend[0] = preliminaryTrend[0];
			else if(IsFirstTickOfBar)
				trend[0] = preliminaryTrend[1];
			if(trend[2] != trend[1]){
				RegionID = CurrentBars[0];
			}

			if(CurrentBar > totalBarsRequiredToPlot+3 && RegionID>0)
			{
				var newtrend = trend[0]!=trend[1];
				var starttime = BarsArray[0].GetTime(RegionID-1);
				var stoptime = BarsArray[0].GetTime(CurrentBars[0] - (newtrend ? 1:0));
				if(pBand1Enabled && pBand1Mult>0){
					var bandpts = BandATR * pBand1Mult;
					if(pShowOppositeBands){
						BandEdgeU1[0] = StopLine[0] + bandpts;
						BandEdgeL1[0] = StopLine[0] - bandpts;
						if(pBand1Opacity>0 && pBand1Brush !=Brushes.Transparent && RegionID != CurrentBars[0]){
							Draw.Region(this, string.Format("R1{0}",RegionID),starttime, stoptime, BandEdgeU1, BandEdgeL1, Brushes.Transparent, pBand1Brush, pBand1Opacity);
						}
					}else{
						if(trend[0]>0){
							BandEdgeU1[0] = StopLine[0] + bandpts;
							if(pBand1Opacity>0 && pBand1Brush !=Brushes.Transparent && RegionID != CurrentBars[0]){
								Draw.Region(this, string.Format("R1u{0}",RegionID),starttime, stoptime, BandEdgeU1, StopLine, Brushes.Transparent, pBand1Brush, pBand1Opacity);
							}
						}else{
							BandEdgeL1[0] = StopLine[0] - bandpts;
							if(pBand1Opacity>0 && pBand1Brush !=Brushes.Transparent && RegionID != CurrentBars[0]){
								Draw.Region(this, string.Format("R1L{0}",RegionID),starttime, stoptime, BandEdgeL1, StopLine, Brushes.Transparent, pBand1Brush, pBand1Opacity);
							}
						}
					}
					if(newtrend) {BandEdgeU1.Reset(1);BandEdgeL1.Reset(1);}
				}
				if(pBand2Enabled && pBand2Mult>0){
					var bandpts = BandATR * pBand2Mult;
					if(pShowOppositeBands){
						BandEdgeU2[0] = StopLine[0] + bandpts;
						BandEdgeL2[0] = StopLine[0] - bandpts;
						if(pBand2Opacity>0 && pBand2Brush !=Brushes.Transparent && RegionID != CurrentBars[0]){
							if(pBand1Enabled){
								Draw.Region(this, string.Format("R2u{0}",RegionID),starttime, stoptime, BandEdgeU2, BandEdgeU1, Brushes.Transparent, pBand2Brush, pBand2Opacity);
								Draw.Region(this, string.Format("R2L{0}",RegionID),starttime, stoptime, BandEdgeL2, BandEdgeL1, Brushes.Transparent, pBand2Brush, pBand2Opacity);
							}else{
								Draw.Region(this, string.Format("R2{0}",RegionID),starttime, stoptime, BandEdgeU2, BandEdgeL2, Brushes.Transparent, pBand2Brush, pBand2Opacity);
							}
						}
					}else{
						if(trend[0]>0){
							BandEdgeU2[0] = StopLine[0] + bandpts;
							if(pBand2Opacity>0 && pBand2Brush !=Brushes.Transparent && RegionID != CurrentBars[0]){
								if(pBand1Enabled){
									Draw.Region(this, string.Format("R2u{0}",RegionID),starttime, stoptime, BandEdgeU2, BandEdgeU1, Brushes.Transparent, pBand2Brush, pBand2Opacity);
								}else{
									Draw.Region(this, string.Format("R2{0}",RegionID),starttime, stoptime, BandEdgeU2, StopLine, Brushes.Transparent, pBand2Brush, pBand2Opacity);
								}
							}
						}else{
							BandEdgeL2[0] = StopLine[0] - bandpts;
							if(pBand2Opacity>0 && pBand2Brush !=Brushes.Transparent && RegionID != CurrentBars[0]){
								if(pBand1Enabled){
									Draw.Region(this, string.Format("R2L{0}",RegionID),starttime, stoptime, BandEdgeL2, BandEdgeL1, Brushes.Transparent, pBand2Brush, pBand2Opacity);
								}else{
									Draw.Region(this, string.Format("R2{0}",RegionID),starttime, stoptime, BandEdgeL2, StopLine, Brushes.Transparent, pBand2Brush, pBand2Opacity);
								}
							}
						}
					}
					if(newtrend) {BandEdgeU2.Reset(1);BandEdgeL2.Reset(1);}
				}
				if(pBand3Enabled && pBand3Mult>0){
					var bandpts = BandATR * pBand3Mult;
					if(pShowOppositeBands){
						BandEdgeU3[0] = StopLine[0] + bandpts;
						BandEdgeL3[0] = StopLine[0] - bandpts;
						if(pBand3Opacity>0 && pBand3Brush !=Brushes.Transparent && RegionID != CurrentBars[0]){
							if(pBand1Enabled && pBand2Enabled){
								Draw.Region(this, string.Format("R3u{0}",RegionID),starttime, stoptime, BandEdgeU3, BandEdgeU2, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								Draw.Region(this, string.Format("R3L{0}",RegionID),starttime, stoptime, BandEdgeL3, BandEdgeL2, Brushes.Transparent, pBand3Brush, pBand3Opacity);
							}else if(pBand1Enabled && !pBand2Enabled){
								Draw.Region(this, string.Format("R3u{0}",RegionID),starttime, stoptime, BandEdgeU3, BandEdgeU1, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								Draw.Region(this, string.Format("R3L{0}",RegionID),starttime, stoptime, BandEdgeL3, BandEdgeL1, Brushes.Transparent, pBand3Brush, pBand3Opacity);
							}else if(!pBand1Enabled && pBand2Enabled){
								Draw.Region(this, string.Format("R3u{0}",RegionID),starttime, stoptime, BandEdgeU3, BandEdgeU2, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								Draw.Region(this, string.Format("R3L{0}",RegionID),starttime, stoptime, BandEdgeL3, BandEdgeL2, Brushes.Transparent, pBand3Brush, pBand3Opacity);
							}else{
								Draw.Region(this, string.Format("R3{0}",RegionID),starttime, stoptime, BandEdgeU3, BandEdgeL3, Brushes.Transparent, pBand3Brush, pBand3Opacity);
							}
						}
					}else{
						if(trend[0]>0){
							BandEdgeU3[0] = StopLine[0] + bandpts;
							if(pBand3Opacity>0 && pBand3Brush !=Brushes.Transparent && RegionID != CurrentBars[0]){
								if(pBand1Enabled && pBand2Enabled){
									Draw.Region(this, string.Format("R3u{0}",RegionID),starttime, stoptime, BandEdgeU3, BandEdgeU2, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								}else if(pBand1Enabled && !pBand2Enabled){
									Draw.Region(this, string.Format("R3u{0}",RegionID),starttime, stoptime, BandEdgeU3, BandEdgeU1, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								}else if(!pBand1Enabled && pBand2Enabled){
									Draw.Region(this, string.Format("R3u{0}",RegionID),starttime, stoptime, BandEdgeU3, BandEdgeU2, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								}else{
									Draw.Region(this, string.Format("R3{0}",RegionID),starttime, stoptime, BandEdgeU3, StopLine, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								}
							}
						}else{
							BandEdgeL3[0] = StopLine[0] - bandpts;
							if(pBand3Opacity>0 && pBand3Brush !=Brushes.Transparent && RegionID != CurrentBars[0]){
								if(pBand1Enabled && pBand2Enabled){
									Draw.Region(this, string.Format("R3L{0}",RegionID),starttime, stoptime, BandEdgeL3, BandEdgeL2, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								}else if(pBand1Enabled && !pBand2Enabled){
									Draw.Region(this, string.Format("R3L{0}",RegionID),starttime, stoptime, BandEdgeL3, BandEdgeL1, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								}else if(!pBand1Enabled && pBand2Enabled){
									Draw.Region(this, string.Format("R3L{0}",RegionID),starttime, stoptime, BandEdgeL3, BandEdgeL2, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								}else{
									Draw.Region(this, string.Format("R3{0}",RegionID),starttime, stoptime, StopLine, BandEdgeL3, Brushes.Transparent, pBand3Brush, pBand3Opacity);
								}
							}
						}
					}
					if(newtrend) {BandEdgeU3.Reset(1);BandEdgeL3.Reset(1);}
				}

				if(showPaintBars)
				{
					if(trend[shift] > 0)
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = upBrushUp;
						else
							BarBrushes[0] = upBrushDown;
						CandleOutlineBrushes[0] = upBrushOutline;
					}
					else
					{	
						if(Open[0] < Close[0])
							BarBrushes[0] = downBrushUp;
						else
							BarBrushes[0] = downBrushDown;
						CandleOutlineBrushes[0] = downBrushOutline;
					}
				}
				if(showTriangles)
				{
					DrawOnPricePanel = true;
					if(Calculate == Calculate.OnBarClose)
					{	
						if(trend[displacement] == LONG && trend[displacement+1] == SHORT)
							Draw.Text(this, "triangle" + CurrentBar, false, triangleStringUp, 0, Low[0] - labelOffset, -triangleFontSize, upBrush, triangleFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0); 
						else if(trend[displacement] == SHORT && trend[displacement+1] == LONG)
							Draw.Text(this, "triangle" + CurrentBar, false, triangleStringDown, 0, High[0] + labelOffset, triangleFontSize, downBrush, triangleFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
					}
					else if (IsFirstTickOfBar)	
					{
						if(trend[displacement] == LONG && trend[displacement+1] == SHORT)
							Draw.Text(this, "triangle" + CurrentBar, false, triangleStringUp, 1, Low[1] - labelOffset, -triangleFontSize, upBrush, triangleFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0); 
						else if(trend[displacement] == SHORT && trend[displacement+1] == LONG)
							Draw.Text(this, "triangle" + CurrentBar, false, triangleStringDown, 1, High[1] + labelOffset, triangleFontSize, downBrush, triangleFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
					}	
				}	
			}

			if (soundAlerts && State == State.Realtime && IsConnected() && (Calculate == Calculate.OnBarClose))// || reverseIntraBar))
			{
				if(preliminaryTrend[0] == LONG && preliminaryTrend[1] == SHORT && !pathNewUptrend.Contains("SOUND OFF"))		
				{
					Alert("New_Uptrend", Priority.Medium,"New Uptrend", pathNewUptrend, rearmTime, alertBackBrush, upBrush);
				}
				else if(preliminaryTrend[0] == SHORT && preliminaryTrend[1] == LONG && !pathNewDowntrend.Contains("SOUND OFF"))
				{
					Alert("New_Downtrend", Priority.Medium,"New Downtrend", pathNewDowntrend, rearmTime, alertBackBrush, downBrush);
				}
			}				
			if (soundAlerts && State == State.Realtime && IsConnected() && Calculate != Calculate.OnBarClose)// && !reverseIntraBar)
			{
				if(preliminaryTrend[0] == LONG && preliminaryTrend[1] == SHORT && !pathPotentialUptrend.Contains("SOUND OFF"))
				{
					Alert("Potential_Uptrend", Priority.Medium,"Potential Uptrend", pathPotentialUptrend, rearmTime, alertBackBrush, upBrush);
				}
				else if(preliminaryTrend[0] == SHORT && preliminaryTrend[1] == LONG && !pathPotentialDowntrend.Contains("SOUND OFF"))
				{
					Alert("Potential_Downtrend", Priority.Medium,"Potential Downtrend", pathPotentialDowntrend, rearmTime, alertBackBrush, downBrush);
				}
			}	
		}

		#region Plots

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> StopDot
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> StopLine
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ReverseDot
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BandEdgeU3
		{
			get { return Values[3]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BandEdgeU2
		{
			get { return Values[4]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BandEdgeU1
		{
			get { return Values[5]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BandEdgeL1
		{
			get { return Values[6]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BandEdgeL2
		{
			get { return Values[7]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BandEdgeL3
		{
			get { return Values[8]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Trend
		{
			get { return trend; }
		}
		#endregion
		#region Properties
		
//		[NinjaScriptProperty]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Use modified ATR", Description = "When set to 'true', the trailing stop is calculated with the modified ATR, otherwise it is calculated with Wilder's ATR.", GroupName = "Algorithmic Options", Order = 0)]
//        public bool UseModifiedATR
//        {
//            get { return useModifiedATR; }
//            set { useModifiedATR = value; }
//        }
		
//		[NinjaScriptProperty]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Reverse intra-bar", Description = "When set to 'true', reversal signals are triggered intra-bar", GroupName = "Algorithmic Options", Order = 1)]
//        public bool ReverseIntraBar
//        {
//            get { return reverseIntraBar; }
//            set { reverseIntraBar = value; }
//        }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "ATR period", Description = "Sets the lookback period for the average true range", GroupName = "Input Parameters", Order = 0, ResourceType = typeof(Custom.Resource))]
		public int RangePeriod
		{	
            get { return rangePeriod; }
            set { rangePeriod = value; }
		}

		private double multiplier = 2.5;
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(Name = "ATR multiplier", Description = "Sets the multiplier for the average true range", GroupName = "Input Parameters", Order = 1, ResourceType = typeof(Custom.Resource))]
		public double Multiplier
		{	
            get { return multiplier; }
            set { multiplier = value; }
		}

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Order = 5, Name = "Band ATR Period", Description = "Lookback period for the ATR for band calculation", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public int pBandATRPeriod
		{get;set;}

		[Display(Order = 6, Name = "Round to tick?", Description = "Round the band levels to the nearest tick?", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public bool pRoundBandToNearestTick
		{get;set;}

		[Display(Order = 7, Name = "Band 1 Enabled", Description = "", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public bool pBand1Enabled
		{get;set;}

		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(Order = 10, Name = "Band 1 multiplier", Description = "Sets the multiplier for the average true range", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public double pBand1Mult
		{get;set;}	

		[XmlIgnore]
		[Display(Order = 11, Name = "Band 1 color", Description = "", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public Brush pBand1Brush {get;set;}
				[Browsable(false)]
				public string pBand1BrushSerializable{get { return Serialize.BrushToString(pBand1Brush); }set { pBand1Brush = Serialize.StringToBrush(value); }}					
		[Range(0, 100)]
		[Display(Order = 12, Name = "Band 1 opacity", Description = "", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public int pBand1Opacity
		{get;set;}

		[Display(Order = 15, Name = "Band 2 Enabled", Description = "", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public bool pBand2Enabled
		{get;set;}
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(Order = 20, Name = "Band 2 multiplier", Description = "Sets the multiplier for the average true range", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public double pBand2Mult
		{get;set;}

		[XmlIgnore]
		[Display(Order = 21, Name = "Band 2 color", Description = "", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public Brush pBand2Brush {get;set;}
				[Browsable(false)]
				public string pBand2BrushSerializable{get { return Serialize.BrushToString(pBand2Brush); }set { pBand2Brush = Serialize.StringToBrush(value); }}					
		[Range(0, 100)]
		[Display(Order = 22, Name = "Band 2 opacity", Description = "", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public int pBand2Opacity
		{get;set;}

		[Display(Order = 25, Name = "Band 3 Enabled", Description = "", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public bool pBand3Enabled
		{get;set;}
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(Order = 30, Name = "Band 3 multiplier", Description = "Sets the multiplier for the average true range", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public double pBand3Mult
		{get;set;}

		[XmlIgnore]
		[Display(Order = 31, Name = "Band 3 color", Description = "", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public Brush pBand3Brush {get;set;}
				[Browsable(false)]
				public string pBand3BrushSerializable{get { return Serialize.BrushToString(pBand3Brush); }set { pBand3Brush = Serialize.StringToBrush(value); }}					
		[Range(0, 100)]
		[Display(Order = 32, Name = "Band 3 opacity", Description = "", GroupName = "ATR Band Parameters", ResourceType = typeof(Custom.Resource))]
		public int pBand3Opacity
		{get;set;}

		private bool pShowOppositeBands = true;
		[Display(Name = "Show opposite band", GroupName = "Display Options", Order = 10, ResourceType = typeof(Custom.Resource))]
        public bool ShowOppositeBands
        {
            get { return pShowOppositeBands; }
            set { pShowOppositeBands = value; }
        }
		[Display(Name = "Show stop dots", GroupName = "Display Options", Order = 20, ResourceType = typeof(Custom.Resource))]
        public bool ShowStopDots
        {
            get { return showStopDots; }
            set { showStopDots = value; }
        }
		
		[Display(Name = "Show stop line", GroupName = "Display Options", Order = 30, ResourceType = typeof(Custom.Resource))]
        public bool ShowStopLine
        {
            get { return showStopLine; }
            set { showStopLine = value; }
        }
		
		private bool showReverseDots = false;
		[Display(Name = "Show reverse dots", GroupName = "Display Options", Order = 35, ResourceType = typeof(Custom.Resource))]
		public bool ShowReverseDots{
			get {return showReverseDots;}
			set {showReverseDots = value;}
		}
		
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Show paint bars", GroupName = "Display Options", Order = 2)]
//        public bool ShowPaintBars
//        {
//            get { return showPaintBars; }
//            set { showPaintBars = value; }
//        }
		
		[Display(Name = "Show triangles", GroupName = "Display Options", Order = 40, ResourceType = typeof(Custom.Resource))]
        public bool ShowTriangles
        {
            get { return showTriangles; }
            set { showTriangles = value; }
        }

		
		[XmlIgnore]
		[Display(Name = "Bullish color", Description = "Sets the color for the trailing stop", GroupName = "Plots", Order = 0, ResourceType = typeof(Custom.Resource))]
		public Brush UpBrush
		{ 
			get {return upBrush;}
			set {upBrush = value;}
		}
				[Browsable(false)]
				public string UpBrushSerializable{get { return Serialize.BrushToString(upBrush); }set { upBrush = Serialize.StringToBrush(value); }}					
		
		[XmlIgnore]
		[Display(Name = "Bearish color", Description = "Sets the color for the trailing stop", GroupName = "Plots", Order = 1, ResourceType = typeof(Custom.Resource))]
		public Brush DownBrush
		{ 
			get {return downBrush;}
			set {downBrush = value;}
		}
				[Browsable(false)]
				public string DownBrushSerializable{get { return Serialize.BrushToString(downBrush); }	set { downBrush = Serialize.StringToBrush(value); }}
		
		[Display(Name = "Plotstyle stop dots", Description = "Sets the plot style for the stop dots", GroupName = "Plots", Order = 2, ResourceType = typeof(Custom.Resource))]
		public PlotStyle Plot0Style
		{	
            get { return plot0Style; }
            set { plot0Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(Name = "Dot size", Description = "Sets the size for the stop dots", GroupName = "Plots", Order = 3, ResourceType = typeof(Custom.Resource))]
		public int Plot0Width
		{	
            get { return plot0Width; }
            set { plot0Width = value; }
		}
			
		[Display(Name = "Plotstyle stop line", Description = "Sets the plot style for the stop line", GroupName = "Plots", Order = 4, ResourceType = typeof(Custom.Resource))]
		public PlotStyle Plot1Style
		{	
            get { return plot1Style; }
            set { plot1Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(Name = "Width stop line", Description = "Sets the width for the stop line", GroupName = "Plots", Order = 5, ResourceType = typeof(Custom.Resource))]
		public int Plot1Width
		{	
            get { return plot1Width; }
            set { plot1Width = value; }
		}
		
		[Range(1, 256)]
		[Display(Name = "Triangle size", Description = "Allows for adjusting the triangle size", GroupName = "Plots", Order = 6, ResourceType = typeof(Custom.Resource))]
		public int TriangleFontSize
		{	
            get { return triangleFontSize; }
            set { triangleFontSize = value; }
		}

//		[XmlIgnore]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish Upclose", Description = "Sets the color for a bullish trend", GroupName = "Paint Bars", Order = 0)]
//		public Brush UpBrushUp
//		{ 
//			get {return upBrushUp;}
//			set {upBrushUp = value;}
//		}

//		[Browsable(false)]
//		public string UpBrushUpSerializable
//		{
//			get { return Serialize.BrushToString(upBrushUp); }
//			set { upBrushUp = Serialize.StringToBrush(value); }
//		}
		
//		[XmlIgnore]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish Downclose", Description = "Sets the color for a bullish trend", GroupName = "Paint Bars", Order = 1)]
//		public Brush UpBrushDown
//		{ 
//			get {return upBrushDown;}
//			set {upBrushDown = value;}
//		}

//		[Browsable(false)]
//		public string UpBrushDownSerializable
//		{
//			get { return Serialize.BrushToString(upBrushDown); }
//			set { upBrushDown = Serialize.StringToBrush(value); }
//		}
		
//		[XmlIgnore]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish candle outline", Description = "Sets the color for bullish candle outlines", GroupName = "Paint Bars", Order = 2)]
//		public Brush UpBrushOutline
//		{ 
//			get {return upBrushOutline;}
//			set {upBrushOutline = value;}
//		}

//		[Browsable(false)]
//		public string UpBrushOutlineSerializable
//		{
//			get { return Serialize.BrushToString(upBrushOutline); }
//			set { upBrushOutline = Serialize.StringToBrush(value); }
//		}					
		
//		[XmlIgnore]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish Upclose", Description = "Sets the color for a bearish trend", GroupName = "Paint Bars", Order = 3)]
//		public Brush DownBrushUp
//		{ 
//			get {return downBrushUp;}
//			set {downBrushUp = value;}
//		}

//		[Browsable(false)]
//		public string DownBrushUpSerializable
//		{
//			get { return Serialize.BrushToString(downBrushUp); }
//			set { downBrushUp = Serialize.StringToBrush(value); }
//		}
		
//		[XmlIgnore]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish Downclose", Description = "Sets the color for a bearish trend", GroupName = "Paint Bars", Order = 4)]
//		public Brush DownBrushDown
//		{ 
//			get {return downBrushDown;}
//			set {downBrushDown = value;}
//		}

//		[Browsable(false)]
//		public string DownBrushDownSerializable
//		{
//			get { return Serialize.BrushToString(downBrushDown); }
//			set { downBrushDown = Serialize.StringToBrush(value); }
//		}
		
//		[XmlIgnore]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish candle outline", Description = "Sets the color for bearish candle outlines", GroupName = "Paint Bars", Order = 5)]
//		public Brush DownBrushOutline
//		{ 
//			get {return downBrushOutline;}
//			set {downBrushOutline = value;}
//		}

//		[Browsable(false)]
//		public string DownBrushOutlineSerializable
//		{
//			get { return Serialize.BrushToString(downBrushOutline); }
//			set { downBrushOutline = Serialize.StringToBrush(value); }
//		}

		[Display(Name = "Enable Sound alerts?", GroupName = "Sound Alerts", Order = 0, ResourceType = typeof(Custom.Resource))]
        public bool SoundAlerts
        {
            get { return soundAlerts; }
            set { soundAlerts = value; }
        }
		
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
		[Display(Name = "New uptrend", Description = "Sound file for confirmed new uptrend", GroupName = "Sound Alerts", Order = 1, ResourceType = typeof(Custom.Resource))]
        public string newUptrend { get; set; }
		
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
		[Display(Name = "New downtrend", Description = "Sound file for confirmed new downtrend", GroupName = "Sound Alerts", Order = 2, ResourceType = typeof(Custom.Resource))]
        public string newDowntrend { get; set; }
		
        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
		[Display(Name = "Potential uptrend", Description = "Sound file for potential new uptrend", GroupName = "Sound Alerts", Order = 3, ResourceType = typeof(Custom.Resource))]
        public string potentialUptrend { get; set; }

        [RefreshProperties(RefreshProperties.All)]
        [TypeConverter(typeof(LoadSoundFileList))]
		[Display(Name = "Potential downtrend", Description = "Sound file for potential new downtrend", GroupName = "Sound Alerts", Order = 4, ResourceType = typeof(Custom.Resource))]
        public string potentialDowntrend { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Rearm time", Description = "Rearm time for alerts in seconds", GroupName = "Sound Alerts", Order = 5, ResourceType = typeof(Custom.Resource))]
		public int RearmTime
		{	
            get { return rearmTime; }
            set { rearmTime = value; }
		}
		
		[XmlIgnore]
		[Display(Name = "Release#", Description = "", GroupName = "Version", Order = 0, ResourceType = typeof(Custom.Resource))]
		public string VersionString
		{	
            get { return versionString; }
			set { ;}
		}
		#endregion

		#region Miscellaneous
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }

		public override string FormatPriceMarker(double price)
		{
			if(indicatorIsOnPricePanel)
				return Instrument.MasterInstrument.FormatPrice(Instrument.MasterInstrument.RoundToTickSize(price));
			else
				return base.FormatPriceMarker(price);
		}
		
		private bool IsConnected()
        {
			if ( Bars != null && Bars.Instrument.GetMarketDataConnection().PriceStatus == NinjaTrader.Cbi.ConnectionStatus.Connected
					&& sessionIterator.IsInSession(Now, true, true))
				return true;
			else
            	return false;
        }
		
		private DateTime Now
		{
          get 
			{ 
				DateTime now = (Bars.Instrument.GetMarketDataConnection().Options.Provider == NinjaTrader.Cbi.Provider.Playback ? Bars.Instrument.GetMarketDataConnection().Now : DateTime.Now); 

				if (now.Millisecond > 0)
					now = NinjaTrader.Core.Globals.MinDate.AddSeconds((long) System.Math.Floor(now.Subtract(NinjaTrader.Core.Globals.MinDate).TotalSeconds));

				return now;
			}
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_ATRTrailingStop[] cacheARC_ATRTrailingStop;
		public ARC.ARC_ATRTrailingStop ARC_ATRTrailingStop(int rangePeriod, double multiplier, int pBandATRPeriod, double pBand1Mult, double pBand2Mult, double pBand3Mult)
		{
			return ARC_ATRTrailingStop(Input, rangePeriod, multiplier, pBandATRPeriod, pBand1Mult, pBand2Mult, pBand3Mult);
		}

		public ARC.ARC_ATRTrailingStop ARC_ATRTrailingStop(ISeries<double> input, int rangePeriod, double multiplier, int pBandATRPeriod, double pBand1Mult, double pBand2Mult, double pBand3Mult)
		{
			if (cacheARC_ATRTrailingStop != null)
				for (int idx = 0; idx < cacheARC_ATRTrailingStop.Length; idx++)
					if (cacheARC_ATRTrailingStop[idx] != null && cacheARC_ATRTrailingStop[idx].RangePeriod == rangePeriod && cacheARC_ATRTrailingStop[idx].Multiplier == multiplier && cacheARC_ATRTrailingStop[idx].pBandATRPeriod == pBandATRPeriod && cacheARC_ATRTrailingStop[idx].pBand1Mult == pBand1Mult && cacheARC_ATRTrailingStop[idx].pBand2Mult == pBand2Mult && cacheARC_ATRTrailingStop[idx].pBand3Mult == pBand3Mult && cacheARC_ATRTrailingStop[idx].EqualsInput(input))
						return cacheARC_ATRTrailingStop[idx];
			return CacheIndicator<ARC.ARC_ATRTrailingStop>(new ARC.ARC_ATRTrailingStop(){ RangePeriod = rangePeriod, Multiplier = multiplier, pBandATRPeriod = pBandATRPeriod, pBand1Mult = pBand1Mult, pBand2Mult = pBand2Mult, pBand3Mult = pBand3Mult }, input, ref cacheARC_ATRTrailingStop);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_ATRTrailingStop ARC_ATRTrailingStop(int rangePeriod, double multiplier, int pBandATRPeriod, double pBand1Mult, double pBand2Mult, double pBand3Mult)
		{
			return indicator.ARC_ATRTrailingStop(Input, rangePeriod, multiplier, pBandATRPeriod, pBand1Mult, pBand2Mult, pBand3Mult);
		}

		public Indicators.ARC.ARC_ATRTrailingStop ARC_ATRTrailingStop(ISeries<double> input , int rangePeriod, double multiplier, int pBandATRPeriod, double pBand1Mult, double pBand2Mult, double pBand3Mult)
		{
			return indicator.ARC_ATRTrailingStop(input, rangePeriod, multiplier, pBandATRPeriod, pBand1Mult, pBand2Mult, pBand3Mult);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_ATRTrailingStop ARC_ATRTrailingStop(int rangePeriod, double multiplier, int pBandATRPeriod, double pBand1Mult, double pBand2Mult, double pBand3Mult)
		{
			return indicator.ARC_ATRTrailingStop(Input, rangePeriod, multiplier, pBandATRPeriod, pBand1Mult, pBand2Mult, pBand3Mult);
		}

		public Indicators.ARC.ARC_ATRTrailingStop ARC_ATRTrailingStop(ISeries<double> input , int rangePeriod, double multiplier, int pBandATRPeriod, double pBand1Mult, double pBand2Mult, double pBand3Mult)
		{
			return indicator.ARC_ATRTrailingStop(input, rangePeriod, multiplier, pBandATRPeriod, pBand1Mult, pBand2Mult, pBand3Mult);
		}
	}
}

#endregion
