#define ONE_TERMITE_SIGNAL_PER_TREND
//#define USE_WPF_COORDS
//#define SHOW_STRIPES_ONLY_ON_MARKERS
#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
//using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX.DirectWrite;
//using NeuroStreet.VMDivergences;
using System.Windows.Controls;
using System.Windows.Automation;
#endregion

#region -- Author / Infos version --
/*********************************************************************
************************* Golden Zone Trading ************************
**********************************************************************
* Authors NT7 : Harry / RJ { RJ5GROUP }
* Author NT8 : Kriss { AzurITec }
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
v1.001  - 24.03.2016    + Conversion from NT7 to NT8b10. Modified the draw of div in indicator panel by using the SharpDX method in the OnRender section (RT behaviour on historical data)
						+ VERIFIED : Velocity MomoDiv Calculation
						+ VERIFIED : ExcursionValues and plot + colors
						+ VERIFIED : Zigzag calculation + draw @ CalculateOnBarClose and EachTick
						+ VERIFIED : Div calculation + draw @ CalculateOnBarClose and EachTick
                        - Need to check default settings for display (different to NT7) and order in setting window
----------------------------------------------------------------------
v1.002  - 27.03.2016    + [FIXED] Bug BG001 found by Sean and Fixed
						+ [FIXED] Bug BG002 found by Sean and Fixed		
						- Bug BG003 found by Sean - Need to investigate. Suspect NT8 bug
----------------------------------------------------------------------
v1.003  - 07.04.2016    + [NT8 BUG] : Bug BG003 signaled to NinjaTrader and will be fixed in next Beta.
						+ Default settings modified with Sean
						+ AntiAlias Mode from "Aliased" to "PerPrimitive" to get smooth lines (no hash) when drawn with SharpDX Functions.
----------------------------------------------------------------------
v1.004 - 08.04.2016     + VERIFIED : Exposed DataSeries
                        + minor changes in the default settings and DisplayName
----------------------------------------------------------------------
v1.005 - 18.05.2016     + Change Floodig option from bool to enum
                        + [FINAL] version so far.
----------------------------------------------------------------------
v1.006 - 25.05.2016     + Beta11 code breaking change with OnRender Method
                        + [FIXED] Bug BG003 - Beta 11 fixed this bug.
----------------------------------------------------------------------
v1.007  - 05.09.2016    + Compatible Beta13 RC1
----------------------------------------------------------------------
v1.008  - 22.09.2016    + Added [NinjaScriptProperty] Attribute to be called from PPTrades indicator
                        + Created Custom Namespace for enum to be called from PPTrades.
----------------------------------------------------------------------
v1.009  - 22.09.2016    + Compatible Beta14 RC2
                        + Changed Opacity Settings to simplify code
----------------------------------------------------------------------
v1.010  - 06.02.2017    + added hidden divergences. See #HIDDENDIV
----------------------------------------------------------------------
v1.10   - 21.03.2017    + All NT7 changes coded
----------------------------------------------------------------------
######################################################################
~~~~~~~~~~~~~~~~~~~~~~~~~ BUGS/ LIMITATIONS ~~~~~~~~~~~~~~~~~~~~~~~~~~
LIM001 : At that time (NT8beta10) there is no official way to draw on price panel from indicator panel using SharpDX methods. See thread : http://ninjatrader.com/support/forum/showthread.php?p=453383#post453383
LIM002 [FIXED] : The native Draw.Line function always draw above custom draw using SharpDX. As a result, the div on osc panel are drawn above the sentiment box. [FIX : use of custom plot]

----------------------------------------------------------------------
Bug BG001 [FIXED] : PriceExcursionLL3 plots above PriceExcursionUL3. Was a CC problem regarding plots index constantes.
Bug BG002 [FIXED] : BBLine not showing. Forgot to write the draw function of BBLine after code optimization
Bug BG003 [FIXED in B11] : On CL05-16 24.03.2016 @ 11:59, a div (MACD+Histo) is drawn on indicator panel. 
						   On PP, the line isn't drawn and the arrows are drawn at the beginning of the div. 
						   It happens on a succession of phantom bars. Could be a bug from NT8 because the timestamp of each bar is the same to the ms.
----------------------------------------------------------------------
v1.11   - 11.26.2017   + JQ 11.26.2017
	Bug 12782. The set right margin is causing the shifting of the SDV bar when the PP bar and the Divergence indicator
	are all on the same chart. This could be a NT8 issue as it appears the BarMarginRight is only applied to the
	primary bar (PP) rather than the secondary bar (SDV). For now, I will disable the setrightmargin properties
	until I have a chance to talk to NT about this issue.
	+ Added version Number on the property dialog box
----------------------------------------------------------------------
v1.12   - Feb.17.2018   + BenLetto
	In response to NT8.0.12.0, removed all calls to "wpf" coordinate calculations
	Also, removed repetitive DXBrush creation/disposal to help improve performance.  DXBrushes are now created once in the beginning of the OnRender method
----------------------------------------------------------------------
v1.2   - Oct.11.2018   + BenLetto
	Removed numerous sloppy string concatinations, replaced with string.Format()
	Added "SentimentBoxLocation" so user can select location of Sentiment box
	Added - OverprintSentimentBox true/false, SentimentBox will now overprint the plotted info by moving base.OnRender up in the code
	Added "OptimizeSpeed" parameter to limit the number of chart marker and font objects printed to the price chart
----------------------------------------------------------------------
*/
#endregion

//TAGS : ##MODIF HERE## / ##DEFAULT VALUE TO CHECK## / ##HARD CODED## / ##??##
//v1.0.5 - added pButtonText input

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region -- Category Order --
    [CategoryOrder("Parameters", 1)]
	[CategoryOrder("System Signals", 5)]
	[CategoryOrder("Divergence Options", 10)]
    [CategoryOrder("Divergence Parameters", 20)]
    [CategoryOrder("MACDBB Parameters", 30)]
    [CategoryOrder("SwingTrend Parameters", 40)]
    [CategoryOrder("Display Options Divergences", 50)]
    [CategoryOrder("Display Options Oscillator Panel", 60)]
    [CategoryOrder("Display Options Price Excursions", 65)]
    [CategoryOrder("Display Options Swing Trend", 70)]
    [CategoryOrder("Histogram Divergences - Plot Colors", 80)]
    [CategoryOrder("Histogram Divergences - Plot Parameters", 90)]
    [CategoryOrder("Histogram Hidden Divergences - Plot Colors", 100)]
    [CategoryOrder("Histogram Hidden Divergences - Plot Parameters", 110)]
    [CategoryOrder("MACD Divergences - Plot Colors", 120)]
    [CategoryOrder("MACD Divergences - Plot Parameters", 130)]
    [CategoryOrder("MACD Hidden Divergences - Plot Colors", 140)]
    [CategoryOrder("MACD Hidden Divergences - Plot Parameters", 150)]
    [CategoryOrder("Plot Colors", 160)]
    [CategoryOrder("Plot Parameters", 170)]
    [CategoryOrder("Price Excursion - Plot Colors", 180)]
    [CategoryOrder("Price Excursion - Plot Parameters", 190)]
    [CategoryOrder("Sentiment Box - Colors", 200)]
    [CategoryOrder("Sentiment Box - Parameters", 210)]
    [CategoryOrder("Sentiment Box - Text Elements", 220)]
    #endregion
    public class ARC_VMDSystem : Indicator
    {
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		private bool IsSeanKozak = false;
		string ModuleName = "VMDSystem";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "25900", "9961", "875", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsDebug = false;


		bool iz = false;
		private int line = 0;
        private const string VERSION = "v1.2 Sept 24 2020";
		//v1.1 - Added scrollwheel support for Structure SwingStrength and Sensitivity
		//v1.2 - Fixed bbDotTrend...it was outputting zeroes only
        #region ---- Variables ---- 
		
        #region -- Bloodhound --
        private Series<double> bearishMACDDivProjection;
        private Series<double> bullishMACDDivProjection;
        private Series<double> bearishHistogramDivProjection;
        private Series<double> bullishHistogramDivProjection;
        private Series<double> bearishMACDHiddenDivProjection;
        private Series<double> bullishMACDHiddenDivProjection;
        private Series<double> bearishHistogramHiddenDivProjection;
        private Series<double> bullishHistogramHiddenDivProjection;
        private Series<double> structureBiasState;
        private Series<double> swingHighsState;
        private Series<double> swingLowsState;

        private double cptBearMACDdiv, maxcptBearMACDdiv, memfirstPeakBar1;//#BLOOHOUND - added 17.02.03 - AzurITec
        private double cptBullMACDdiv, maxcptBullMACDdiv, memfirstTroughBar1;//#BLOOHOUND - added 17.02.03 - AzurITec        
        private double cptBearHistogramdiv, maxcptBearHistogramdiv, memfirstPeakBar2;//#BLOOHOUND - added 17.02.03 - AzurITec
        private double cptBullHistogramdiv, maxcptBullHistogramdiv, memfirstTroughBar2;//#BLOOHOUND - added 17.02.03 - AzurITec

        private double cptBearMACDhdiv, maxcptBearMACDhdiv, memfirstPeakBar1H;//#BLOOHOUND - added 17.02.03 - AzurITec
        private double cptBullMACDhdiv, maxcptBullMACDhdiv, memfirstTroughBar1H;//#BLOOHOUND - added 17.02.03 - AzurITec        
        private double cptBearHistogramhdiv, maxcptBearHistogramhdiv, memfirstPeakBar2H;//#BLOOHOUND - added 17.02.03 - AzurITec
        private double cptBullHistogramhdiv, maxcptBullHistogramhdiv, memfirstTroughBar2H;//#BLOOHOUND - added 17.02.03 - AzurITec
        #endregion

        #region -- Structure BIAS + Swings --
        private List<int> sequence = new List<int>(3);//#STRBIAS
        private int SRType, preSRType;//#STRBIAS  
        #endregion

        #region -- velocity momo  --
        private MACD BMACD;
        private MACD MACD1;
        private MACD MACD2;
        private MACD MACD3;
        private MACD MACD4;
        private StdDev SDBB;
        #endregion

        #region -- zigzag indicator -- 
        private int lastHighIdx = 0;
        private int lastLowIdx = 0;
        private int priorSwingHighIdx = 0;
        private int priorSwingLowIdx = 0;
        private int highCount = 0;
        private int lowCount = 0;
        private int preLastHighIdx = 0;
        private int preLastLowIdx = 0;
        private double zigzagDeviation = 0.0;
        private double currentHigh = 0.0;
        private double currentLow = 0.0;
        private double swingMax = 0.0;
        private double swingMin = 0.0;
        private double preCurrentHigh = 0.0;
        private double preCurrentLow = 0.0;
        private bool addHigh = false;
        private bool updateHigh = false;
        private bool addLow = false;
        private bool updateLow = false;
        private bool drawHigherHighDot = false;
        private bool drawLowerHighDot = false;
        private bool drawDoubleTopDot = false;
        private bool drawLowerLowDot = false;
        private bool drawHigherLowDot = false;
        private bool drawDoubleBottomDot = false;
        private bool drawHigherHighLabel = false;
        private bool drawLowerHighLabel = false;
        private bool drawDoubleTopLabel = false;
        private bool drawLowerLowLabel = false;
        private bool drawHigherLowLabel = false;
        private bool drawDoubleBottomLabel = false;
        private bool drawSwingLegUp = false;
        private bool drawSwingLegDown = false;
        private bool intraBarAddHigh = false;
        private bool intraBarUpdateHigh = false;
        private bool intraBarAddLow = false;
        private bool intraBarUpdateLow = false;

        private SimpleFont labelFont = null;
        private SimpleFont swingDotFont = null;
        private int pixelOffset1 = 10;               //##HARD CODED##
        private int pixelOffset2 = 10;               //##HARD CODED##
        private Brush upColor = Brushes.LimeGreen;//##HARD CODED##
        private Brush downColor = Brushes.Red;      //##HARD CODED##
        private Brush doubleTopBottomColor = Brushes.Yellow;   //##HARD CODED##
        private string dotString = "n";              //##HARD CODED##

        private ATR avgTrueRange;
        private Series<double> swingInput;
        private Series<int> pre_swingHighType;
        private Series<int> pre_swingLowType;
        private Series<int> swingHighType;
        private Series<int> swingLowType;
        private Series<int> acceleration1;
        private Series<int> acceleration2;
        private Series<bool> upTrend;
        #endregion

        #region -- divergence indicator --
        private bool divergenceActive = true;

        private int[] refPeakBar1H = new int[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private int[] refOscPeakBar1H = new int[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private int firstPeakBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int firstOscPeakBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorFirstPeakBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorFirstOscPeakBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int replacementPeakBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int replacementOscPeakBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int secondPeakBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int secondOscPeakBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorSecondPeakBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorSecondOscPeakBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int peakCount1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec

        private int[] refTroughBar1H = new int[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private int[] refOscTroughBar1H = new int[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private int firstTroughBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int firstOscTroughBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorFirstTroughBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorFirstOscTroughBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int replacementTroughBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int replacementOscTroughBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int secondTroughBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int secondOscTroughBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorSecondTroughBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorSecondOscTroughBar1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int troughCount1H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec

        private int[] refPeakBar2H = new int[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private int[] refOscPeakBar2H = new int[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private int firstPeakBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int firstOscPeakBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorFirstPeakBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorFirstOscPeakBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int replacementPeakBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int replacementOscPeakBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int secondPeakBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int secondOscPeakBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorSecondPeakBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorSecondOscPeakBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int peakCount2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec

        private int[] refTroughBar2H = new int[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private int[] refOscTroughBar2H = new int[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private int firstTroughBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int firstOscTroughBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorFirstTroughBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorFirstOscTroughBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int replacementTroughBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int replacementOscTroughBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int secondTroughBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int secondOscTroughBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorSecondTroughBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int priorSecondOscTroughBar2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private int troughCount2H = 0;//#HIDDENDIV - added 17.02.01 - AzurITec

        private double[] refPeakHigh1H = new double[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private double[] refPeakValue1H = new double[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private double firstPeakHigh1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double firstPeakValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorFirstPeakHigh1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorFirstPeakValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double replacementPeakHigh1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double replacementPeakValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorReplacementPeakValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double secondPeakHigh1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double secondPeakValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorSecondPeakHigh1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorSecondPeakValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorReplacementPeakHigh1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double[] refTroughLow1H = new double[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private double[] refTroughValue1H = new double[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private double firstTroughLow1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double firstTroughValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorFirstTroughLow1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorFirstTroughValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double replacementTroughLow1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double replacementTroughValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorReplacementTroughValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorReplacementTroughLow1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double secondTroughLow1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double secondTroughValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorSecondTroughLow1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorSecondTroughValue1H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorReplacementPeakHigh2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorReplacementTroughLow2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double[] refPeakHigh2H = new double[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private double[] refPeakValue2H = new double[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private double firstPeakHigh2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double firstPeakValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorFirstPeakHigh2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorFirstPeakValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double replacementPeakHigh2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double replacementPeakValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorReplacementPeakValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double secondPeakHigh2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double secondPeakValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorSecondPeakHigh2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorSecondPeakValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double[] refTroughLow2H = new double[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private double[] refTroughValue2H = new double[10];//#HIDDENDIV - added 17.02.01 - AzurITec
        private double firstTroughLow2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double firstTroughValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorFirstTroughLow2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorFirstTroughValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double replacementTroughLow2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double replacementTroughValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorReplacementTroughValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double secondTroughLow2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double secondTroughValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorSecondTroughLow2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec
        private double priorSecondTroughValue2H = 0.0;//#HIDDENDIV - added 17.02.01 - AzurITec

        private bool firstPeakFound1H                 = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool firstTroughFound1H               = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBearishDivCandidatePrice1H   = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBearishDivCandidateOsc1H     = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool updateBearishDivCandidatePrice1H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool updateBearishDivCandidateOsc1H   = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBearishDivOnPrice1H          = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBearishDivOnOsc1H            = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBullishDivCandidatePrice1H   = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBullishDivCandidateOsc1H     = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool updateBullishDivCandidatePrice1H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool updateBullishDivCandidateOsc1H   = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBullishDivOnPrice1H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBullishDivOnOsc1H   = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBearSetup1H         = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBullSetup1H         = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawArrowDown1H         = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawArrowUp1H           = false;//#HIDDENDIV - added 17.02.01 - AzurITec

        private bool firstPeakFound2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool firstTroughFound2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBearishDivCandidatePrice2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBearishDivCandidateOsc2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool updateBearishDivCandidatePrice2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool updateBearishDivCandidateOsc2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBearishDivOnPrice2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBearishDivOnOsc2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBullishDivCandidatePrice2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBullishDivCandidateOsc2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool updateBullishDivCandidatePrice2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool updateBullishDivCandidateOsc2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBullishDivOnPrice2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBullishDivOnOsc2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBearSetup2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawBullSetup2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawArrowDown2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec
        private bool drawArrowUp2H = false;//#HIDDENDIV - added 17.02.01 - AzurITec

        private int[] refPeakBar1 = new int[10];
        private int[] refOscPeakBar1 = new int[10];
        private int firstPeakBar1 = 0;
        private int firstOscPeakBar1 = 0;
        private int priorFirstPeakBar1 = 0;
        private int priorFirstOscPeakBar1 = 0;
        private int replacementPeakBar1 = 0;
        private int replacementOscPeakBar1 = 0;
        private int secondPeakBar1 = 0;
        private int secondOscPeakBar1 = 0;
        private int priorSecondPeakBar1 = 0;
        private int priorSecondOscPeakBar1 = 0;
        private int peakCount1 = 0;

        private int[] refTroughBar1 = new int[10];
        private int[] refOscTroughBar1 = new int[10];
        private int firstTroughBar1 = 0;
        private int firstOscTroughBar1 = 0;
        private int priorFirstTroughBar1 = 0;
        private int priorFirstOscTroughBar1 = 0;
        private int replacementTroughBar1 = 0;
        private int replacementOscTroughBar1 = 0;
        private int secondTroughBar1 = 0;
        private int secondOscTroughBar1 = 0;
        private int priorSecondTroughBar1 = 0;
        private int priorSecondOscTroughBar1 = 0;
        private int troughCount1 = 0;

        private int[] refPeakBar2 = new int[10];
        private int[] refOscPeakBar2 = new int[10];
        private int firstPeakBar2 = 0;
        private int firstOscPeakBar2 = 0;
        private int priorFirstPeakBar2 = 0;
        private int priorFirstOscPeakBar2 = 0;
        private int replacementPeakBar2 = 0;
        private int replacementOscPeakBar2 = 0;
        private int secondPeakBar2 = 0;
        private int secondOscPeakBar2 = 0;
        private int priorSecondPeakBar2 = 0;
        private int priorSecondOscPeakBar2 = 0;
        private int peakCount2 = 0;

        private int[] refTroughBar2 = new int[10];
        private int[] refOscTroughBar2 = new int[10];
        private int firstTroughBar2 = 0;
        private int firstOscTroughBar2 = 0;
        private int priorFirstTroughBar2 = 0;
        private int priorFirstOscTroughBar2 = 0;
        private int replacementTroughBar2 = 0;
        private int replacementOscTroughBar2 = 0;
        private int secondTroughBar2 = 0;
        private int secondOscTroughBar2 = 0;
        private int priorSecondTroughBar2 = 0;
        private int priorSecondOscTroughBar2 = 0;
        private int troughCount2 = 0;

        private double offsetDraw1 = 0.0;
        private double offsetDraw2 = 0.0;
        private double offsetDiv1 = 0.0;
        private double offsetDiv2 = 0.0;
        private double[] refPeakHigh1 = new double[10];
        private double[] refPeakValue1 = new double[10];
        private double firstPeakHigh1 = 0.0;
        private double firstPeakValue1 = 0.0;
        private double priorFirstPeakHigh1 = 0.0;
        private double priorFirstPeakValue1 = 0.0;
        private double replacementPeakHigh1 = 0.0;
        private double replacementPeakValue1 = 0.0;
        private double priorReplacementPeakValue1 = 0.0;
        private double secondPeakHigh1 = 0.0;
        private double secondPeakValue1 = 0.0;
        private double priorSecondPeakHigh1 = 0.0;
        private double priorSecondPeakValue1 = 0.0;
        private double[] refTroughLow1 = new double[10];
        private double[] refTroughValue1 = new double[10];
        private double firstTroughLow1 = 0.0;
        private double firstTroughValue1 = 0.0;
        private double priorFirstTroughLow1 = 0.0;
        private double priorFirstTroughValue1 = 0.0;
        private double replacementTroughLow1 = 0.0;
        private double replacementTroughValue1 = 0.0;
        private double priorReplacementTroughValue1 = 0.0;
        private double secondTroughLow1 = 0.0;
        private double secondTroughValue1 = 0.0;
        private double priorSecondTroughLow1 = 0.0;
        private double priorSecondTroughValue1 = 0.0;

        private double[] refPeakHigh2 = new double[10];
        private double[] refPeakValue2 = new double[10];
        private double firstPeakHigh2 = 0.0;
        private double firstPeakValue2 = 0.0;
        private double priorFirstPeakHigh2 = 0.0;
        private double priorFirstPeakValue2 = 0.0;
        private double replacementPeakHigh2 = 0.0;
        private double replacementPeakValue2 = 0.0;
        private double priorReplacementPeakValue2 = 0.0;
        private double secondPeakHigh2 = 0.0;
        private double secondPeakValue2 = 0.0;
        private double priorSecondPeakHigh2 = 0.0;
        private double priorSecondPeakValue2 = 0.0;
        private double[] refTroughLow2 = new double[10];
        private double[] refTroughValue2 = new double[10];
        private double firstTroughLow2 = 0.0;
        private double firstTroughValue2 = 0.0;
        private double priorFirstTroughLow2 = 0.0;
        private double priorFirstTroughValue2 = 0.0;
        private double replacementTroughLow2 = 0.0;
        private double replacementTroughValue2 = 0.0;
        private double priorReplacementTroughValue2 = 0.0;
        private double secondTroughLow2 = 0.0;
        private double secondTroughValue2 = 0.0;
        private double priorSecondTroughLow2 = 0.0;
        private double priorSecondTroughValue2 = 0.0;

        private bool drawObjectsEnabled = true;//##HARD CODED## - Set only here
        private bool hidePlots = false;//##HARD CODED## - Set only here
        private bool showArrows = true;//##HARD CODED## - Set only here

        private SimpleFont triangleFont1 = null;
        private SimpleFont setupFont1 = null;
        private SimpleFont triangleFont2 = null;
        private SimpleFont setupFont2 = null;
        private string arrowStringUp = "5";//##HARD CODED## - Set only here
        private string arrowStringDown = "6";//##HARD CODED## - Set only here
        private string setupDotString = "n";//##HARD CODED## - Set only here

        private Series<double> bbDotTrend;
        private Series<double> momoSignum;

        private Series<double> bearishCDivMACD;
        private Series<double> bullishCDivMACD;
        private Series<double> bearishCDivHistogram;
        private Series<double> bullishCDivHistogram;

        private Series<double> bearishPDivMACD;
        private Series<double> bullishPDivMACD;
        private Series<double> bearishPDivHistogram;
        private Series<double> bullishPDivHistogram;

        private Series<int> bearishTriggerCountMACDBB;
        private Series<int> bullishTriggerCountMACDBB;
        private Series<int> bearishTriggerCountHistogram;
        private Series<int> bullishTriggerCountHistogram;

        private Series<double> macdBBState;
        private Series<double> histogramState;

        private Series<double> hiddenbearishPDivMACD;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<double> hiddenbullishPDivMACD;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<double> hiddenbearishCDivMACD;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<double> hiddenbullishCDivMACD;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<double> hiddenbearishPDivHistogram;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<double> hiddenbullishPDivHistogram;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<double> hiddenbearishCDivHistogram;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<double> hiddenbullishCDivHistogram;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<int> hiddenbearishTriggerCountMACDBB;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<int> hiddenbullishTriggerCountMACDBB;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<int> hiddenbearishTriggerCountHistogram;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<int> hiddenbullishTriggerCountHistogram;//#HIDDENDIV - added 17.02.01 - AzurITec

        private Series<int> bearishDivPlotSeriesMACDBB;
        private Series<int> hiddenbearishDivPlotSeriesMACDBB;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<int> bullishDivPlotSeriesMACDBB;
        private Series<int> hiddenbullishDivPlotSeriesMACDBB;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<int> bearishDivPlotSeriesHistogram;
        private Series<int> hiddenbearishDivPlotSeriesHistogram;//#HIDDENDIV - added 17.02.01 - AzurITec
        private Series<int> bullishDivPlotSeriesHistogram;
        private Series<int> hiddenbullishDivPlotSeriesHistogram;//#HIDDENDIV - added 17.02.01 - AzurITec

        #endregion

        #region -- Box --
        private SimpleFont dataFont1 = null;
        private SimpleFont dataFont2 = null;
        private bool showBox = true;

        private System.Windows.TextAlignment textAlignmentCenter = System.Windows.TextAlignment.Center;

        private double filterValue1 = 0.0;
        private double filterValue2 = 0.0;
        private double filterValue3 = 0.0;

        private double dataStringHeight = 0.0;//##MODIF HERE## was float
        private string maxString1 = "";
        private string maxString2 = "";
        #endregion

        #region -- rj RJ5GROUP code Algorithm  --
        private SMA ExcursionSeries;
        #endregion

		private SharpDX.Direct2D1.Brush  ChannelBkgDXBrush, BullishBkgDXBrush, BearishBkgDXBrush, DeepBullishBkgDXBrush, DeepBearishBkgDXBrush, OppositeBkgDXBrush, DataTableDXBrush, BullishDivergenceDXBrush, BearishDivergenceDXBrush, BullishAccelerationDXBrush, BearishAccelerationDXBrush;

        #endregion
		private bool Initialized = false;
		private string[] BuySoundFiles = new string[3]{"SOUND OFF", "SOUND OFF", "SOUND OFF"};
		private string[] SellSoundFiles = new string[3]{"SOUND OFF", "SOUND OFF", "SOUND OFF"};
		private double BUY_SYSTEMSIGNAL = 1;
		private double SELL_SYSTEMSIGNAL = -1;

		#region -- System Signal variables --
		private const int TERMITE = 0;
		private const int H_DIV = 1;
		private const int R_DIV = 2;
		Brush BuyStripeBrush, SellStripeBrush;
		private int last_trade_signal_bar = -1;
		private int last_visible_bar = -1;
		private ARC_VMDSystem_SystemTypes LastSignalType = ARC_VMDSystem_SystemTypes.None;
		private List<ARC_VMDSystem_SystemTypes[]> BkgChangesQue = new List<ARC_VMDSystem_SystemTypes[]>();
		string MsgOnChart = string.Empty;
		DateTime TimeOfMessagePrint = DateTime.MinValue;
		#endregion

        #region -- Index Constants to change Plot order and superposition. Lower index goes below --        
        private const int BBMACDIDX = 12;
        private const int BBMACDFrameIDX = 11;
        private const int BBMACDLineIDX = 10;
        private const int AverageIDX = 9;
        private const int UpperIDX = 8;
        private const int LowerIDX = 7;
        private const int HistogramIDX = 6;
        private const int PriceExcursionUL3IDX = 5;
        private const int PriceExcursionUL2IDX = 4;
        private const int PriceExcursionUL1IDX = 3;
        private const int PriceExcursionLL1IDX = 2;
        private const int PriceExcursionLL2IDX = 1;
        private const int PriceExcursionLL3IDX = 0;
        private const int PriceExcursionMAXIDX = 14;
        private const int PriceExcursionMINIDX = 13;
        private const int SystemSignalIDX = 15;
        #endregion

        public override string DisplayName { get { return "ARC_VMDSystem"; } }

        #region -- Toolbar variables --
        private string toolbarname = "NSVMDSystemTB", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private Grid indytoolbar;

        private Menu MenuControlContainer;
        private MenuItem MenuControl;

        //private ComboBox comboMTF, comboZFM, comboProfile;
        private MenuItem miDivOptions1, miDivOptions2, miDivOptions3, miDivOptions4, miRecalculate1;
        private MenuItem miDisplayOptions1, miDisplayOptions2, miDisplayOptions3, miDisplayOptions4, miDisplayOptions5, miDisplayOptions6, miDisplayOptions7;
        private MenuItem miExcursionLevels1, miExcursionLevels2, miExcursionLevels3, miMarketStructure1, miMarketStructure2;
        private ComboBox comboExcursionStyle, comboFlooding;
        private TextBox tbSLTicks, nudMST1, nudMST2;

        private Button gCmdup;
        private Button gCmddw;
        private Label gLabel;
        #endregion
        #region -- addToolBar() --
        private void addToolBar()
        {
            gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            gLabel = new Label();//#RJBug001

            MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
            MenuControl = new MenuItem {Name="NSVMDS"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Lime, Header = pButtonText, Foreground = Brushes.Lime, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
            MenuControlContainer.Items.Add(MenuControl);

            MenuItem item;
            Separator separator;
			const int rHeight = 26;

            #region -- Divergence Options --
            MenuItem miDivOptions = new MenuItem { Header = "Divergence Options", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miDivOptions1 = new MenuItem { Header = UseOscHighLow ? "Adjust Divergence ON" : "Adjust Divergence OFF", Name = "btDivOptions_AdjustDiv", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDivOptions1.Click += ModifyDivOptionsSetting_Click;
            miDivOptions.Items.Add(miDivOptions1);

            miDivOptions2 = new MenuItem { Header = IncludeDoubleTopsAndBottoms ? "Include DT/DB ON" : "Include DT/DB OFF", Name = "btDivOptions_IncludeDTDB", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDivOptions2.Click += ModifyDivOptionsSetting_Click;
            miDivOptions.Items.Add(miDivOptions2);

            miDivOptions3 = new MenuItem { Header = UseLastSwingOnly ? "Recent divergences only ON" : "Recent divergences only OFF", Name = "btDivOptions_RecentDivs", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDivOptions3.Click += ModifyDivOptionsSetting_Click;
            miDivOptions.Items.Add(miDivOptions3);

            miDivOptions4 = new MenuItem { Header = ResetFilter ? "Reset Filter ON" : "Reset Filter OFF", Name = "btDivOptions_ResetFilter", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDivOptions4.Click += ModifyDivOptionsSetting_Click;
            miDivOptions.Items.Add(miDivOptions4);

            separator = new Separator();
            miDivOptions.Items.Add(separator);

            item = new MenuItem { Header = "        RELOAD THE CHART", Name = "btDivOptions_Reload", Foreground = Brushes.Black, StaysOpenOnClick = false };
            item.Click += ReloadChart_Click;
            miDivOptions.Items.Add(item);

            MenuControl.Items.Add(miDivOptions);
            #endregion

            #region -- MarketStructure --
            MenuItem miMarketStructure = new MenuItem { Header = "Swing Trend Parameters", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miMarketStructure1 = new MenuItem { Header = "Structure Swings " + (ShowZigzagLegs ? "ON" : "OFF"), Name = "btMarketStructure_trends", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miMarketStructure1.Click += MarketStructure_Click;
            miMarketStructure.Items.Add(miMarketStructure1);

            miMarketStructure2 = new MenuItem { Header = "Structure Labels " + (ShowZigzagLabels ? "ON" : "OFF"), Name = "btMarketStructure_labels", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miMarketStructure2.Click += MarketStructure_Click;
            miMarketStructure.Items.Add(miMarketStructure2);

            miMarketStructure.Items.Add(createMSTMenu(MultiplierDTB.ToString(), SwingStrength.ToString()));

            separator = new Separator();
            miMarketStructure.Items.Add(separator);

            miRecalculate1 = new MenuItem { Header = "RE-CALCULATE MARKET STRUCTURE", Name = "marketStructureClick", 
				HorizontalAlignment = HorizontalAlignment.Center, 
				FontWeight = FontWeights.Normal,
				FontStyle = FontStyles.Normal,
				Background = null
			};
            miRecalculate1.Click += ReloadChart_Click;
            miMarketStructure.Items.Add(miRecalculate1);
            //------------------

            MenuControl.Items.Add(miMarketStructure);
            #endregion

            #region -- Display Options Divergences --
            MenuItem miDisplayOptions = new MenuItem { Header = "Display Options", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            bool isMasterOn = ShowSetupDots || ShowDivOnPricePanel || ShowDivOnOscillatorPanel || ShowHistogramDivergences || ShowHistogramHiddenDivergences || ShowOscillatorDivergences || ShowOscillatorHiddenDivergences;
            item = new MenuItem { Header = "--- MASTER " + (isMasterOn ? "ON" : "OFF") + " ---", Name = "btDisplayOptions_Master", Foreground = Brushes.Black, StaysOpenOnClick = true };
            item.Click += ModifyDisplayOptionsSetting_Click;
            miDisplayOptions.Items.Add(item);

            miDisplayOptions1 = new MenuItem { Header = "Show Div Dots " + (ShowSetupDots?"ON":"OFF"), Name = "btDisplayOptions_ShowDivDots", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDisplayOptions1.Click += ModifyDisplayOptionsSetting_Click;
            miDisplayOptions.Items.Add(miDisplayOptions1);

            miDisplayOptions2 = new MenuItem { Header = "Show Div On Price Panel " + (ShowDivOnPricePanel ? "ON" : "OFF"), Name = "btDisplayOptions_ShowDivOnPricePanel", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDisplayOptions2.Click += ModifyDisplayOptionsSetting_Click;
            miDisplayOptions.Items.Add(miDisplayOptions2);

            miDisplayOptions3 = new MenuItem { Header = "Show Div On Sub-Panel " + (ShowDivOnOscillatorPanel ? "ON" : "OFF"), Name = "btDisplayOptions_ShowDivOnSubPanel", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDisplayOptions3.Click += ModifyDisplayOptionsSetting_Click;
            miDisplayOptions.Items.Add(miDisplayOptions3);

            miDisplayOptions4 = new MenuItem { Header = "Show Histogram Div " + (ShowHistogramDivergences ? "ON" : "OFF"), Name = "btDisplayOptions_ShowHistoDiv", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDisplayOptions4.Click += ModifyDisplayOptionsSetting_Click;
            miDisplayOptions.Items.Add(miDisplayOptions4);

            miDisplayOptions5 = new MenuItem { Header = "Show Histogram Hidden Div " + (ShowHistogramHiddenDivergences ? "ON" : "OFF"), Name = "btDisplayOptions_ShowHistoHDiv", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDisplayOptions5.Click += ModifyDisplayOptionsSetting_Click;
            miDisplayOptions.Items.Add(miDisplayOptions5);

            miDisplayOptions6 = new MenuItem { Header = "Show MACD Div " + (ShowOscillatorDivergences ? "ON" : "OFF"), Name = "btDisplayOptions_ShowMACDDiv", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDisplayOptions6.Click += ModifyDisplayOptionsSetting_Click;
            miDisplayOptions.Items.Add(miDisplayOptions6);

            miDisplayOptions7 = new MenuItem { Header = "Show MACD Hidden Div " + (ShowOscillatorHiddenDivergences ? "ON" : "OFF"), Name = "btDisplayOptions_ShowMACDHDiv", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miDisplayOptions7.Click += ModifyDisplayOptionsSetting_Click;
            miDisplayOptions.Items.Add(miDisplayOptions7);

            separator = new Separator();
            miDisplayOptions.Items.Add(separator);

            item = new MenuItem { Header = "            RELOAD THE CHART", Name = "btDisplayOptions_Reload", Foreground = Brushes.Black, StaysOpenOnClick = false };
            item.Click += ReloadChart_Click;
            miDisplayOptions.Items.Add(item);

            MenuControl.Items.Add(miDisplayOptions);
            #endregion

            #region -- Excursion Levels --
            MenuItem miExcursionLevels = new MenuItem { Header = "Excursion Levels", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            isMasterOn = DisplayLevel1 || DisplayLevel2 || DisplayLevel3;
            item = new MenuItem { Header = "--- MASTER " + (isMasterOn ? "ON" : "OFF") + " ---", Name = "btExcursionLevels_Master", Foreground = Brushes.Black, StaysOpenOnClick = true };
            item.Click += RefreshChart_Click;
            miExcursionLevels.Items.Add(item);

            miExcursionLevels1 = new MenuItem { Header = "Show Level 1 " + (DisplayLevel1 ? "ON" : "OFF"), Name = "btExcursionLevels_Level1", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miExcursionLevels1.Click += RefreshChart_Click;
            miExcursionLevels.Items.Add(miExcursionLevels1);

            miExcursionLevels2 = new MenuItem { Header = "Show Level 2 " + (DisplayLevel2 ? "ON" : "OFF"), Name = "btExcursionLevels_Level2", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miExcursionLevels2.Click += RefreshChart_Click;
            miExcursionLevels.Items.Add(miExcursionLevels2);

            miExcursionLevels3 = new MenuItem { Header = "Show Level 3 " + (DisplayLevel3 ? "ON" : "OFF"), Name = "btExcursionLevels_Level3", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miExcursionLevels3.Click += RefreshChart_Click;
            miExcursionLevels.Items.Add(miExcursionLevels3);

            List<string> cbItems = new List<string>();
            foreach (var pt in Enum.GetValues(typeof(ARC_VMDSystem_ExcursionStyle))) cbItems.Add(pt.ToString());            
            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Lines' Mode :" };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            comboExcursionStyle = new ComboBox() { Name = "comboExcursionStyle" + uID, MinWidth = 86, Width = 86, MaxWidth = 86, Margin = new Thickness(5, 0, 0, 0) };
            foreach (string cbitem in cbItems) comboExcursionStyle.Items.Add(cbitem);
            comboExcursionStyle.SelectedItem = PlotStyleLevels == PlotStyle.HLine ? ARC_VMDSystem_ExcursionStyle.Static.ToString() : ARC_VMDSystem_ExcursionStyle.Dynamic.ToString();
            comboExcursionStyle.SelectionChanged += ExcursionStyleValueChanged;
            comboExcursionStyle.SetValue(Grid.ColumnProperty, 1);
            comboExcursionStyle.SetValue(Grid.RowProperty, 0);
            grid.Children.Add(lbl1);
            grid.Children.Add(comboExcursionStyle);
            miExcursionLevels.Items.Add(grid);

            MenuControl.Items.Add(miExcursionLevels);
            #endregion

            #region -- Sentiment --
            MenuItem miSentiment = new MenuItem { Header = "Sentiment Settings", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            item = new MenuItem { Header = "Show Histogram Sentiment " + (ShowSentimentInBox ? "ON" : "OFF"), Name = "btSentiment_Sentiment", Foreground = Brushes.Black, StaysOpenOnClick = true };
            item.Click += RefreshChart_Click;
            miSentiment.Items.Add(item);

            item = new MenuItem { Header = "Show Structure Bias " + (ShowBiasInBox ? "ON" : "OFF"), Name = "btSentiment_Bias", Foreground = Brushes.Black, StaysOpenOnClick = true };
            item.Click += RefreshChart_Click;
            miSentiment.Items.Add(item);

            cbItems = new List<string>();
            foreach (var pt in Enum.GetValues(typeof(ARC_VMDSystem_Flooding))) cbItems.Add(pt.ToString());
            grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });
            lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Flooding :" };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            comboFlooding = new ComboBox() { Name = "comboFlooding" + uID, MinWidth = 86, Width = 86, MaxWidth = 86, Margin = new Thickness(5, 0, 0, 0) };
            foreach (string cbitem in cbItems) comboFlooding.Items.Add(cbitem);
            comboFlooding.SelectedItem = BackgroundFlooding.ToString();
            comboFlooding.SelectionChanged += FloodingValueChanged;
            comboFlooding.SetValue(Grid.ColumnProperty, 1);
            comboFlooding.SetValue(Grid.RowProperty, 0);
            grid.Children.Add(lbl1);
            grid.Children.Add(comboFlooding);
            miSentiment.Items.Add(grid);

            MenuControl.Items.Add(miSentiment);
            #endregion
//=============================================================================
			MenuControl.Items.Add(new Separator());
//=============================================================================
			#region -- Signal Type --
			this.miSignalType = new MenuItem {Header = "Signal type:   "+pSignalType.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miSignalType.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				e.Handled = true;
				if     (pSignalType == ARC_VMDSystem_SystemTypes.None)       	 pSignalType = ARC_VMDSystem_SystemTypes.Termite;
				else if(pSignalType == ARC_VMDSystem_SystemTypes.Termite)    	 pSignalType = ARC_VMDSystem_SystemTypes.BothDivergences;
				else if(pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences) pSignalType = ARC_VMDSystem_SystemTypes.RegularDiv;
				else if(pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv)      pSignalType = ARC_VMDSystem_SystemTypes.HiddenDiv;
				else if(pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv)       pSignalType = ARC_VMDSystem_SystemTypes.None;
				miSignalType.Header = "Signal type:   "+pSignalType.ToString();

//				BkgChangesQue.Add(new ARC_VMDSystem_SystemTypes[2]{pSignalType, LastSignalType});
				UpdateBackgroundStripes(LastSignalType, pSignalType);

				SignalType_Updater(pSignalType, true);

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
				LastSignalType = pSignalType;
			};
			miSignalType.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					e.Handled=true;
					if(e.Delta>0) {
						if     (pSignalType == ARC_VMDSystem_SystemTypes.None)            pSignalType = ARC_VMDSystem_SystemTypes.Termite;
						else if(pSignalType == ARC_VMDSystem_SystemTypes.Termite)         pSignalType = ARC_VMDSystem_SystemTypes.BothDivergences;
						else if(pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences) pSignalType = ARC_VMDSystem_SystemTypes.RegularDiv;
						else if(pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv)      pSignalType = ARC_VMDSystem_SystemTypes.HiddenDiv;
						else if(pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv)       pSignalType = ARC_VMDSystem_SystemTypes.None;
					}else{
						if     (pSignalType == ARC_VMDSystem_SystemTypes.None)            pSignalType = ARC_VMDSystem_SystemTypes.HiddenDiv;
						else if(pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv)       pSignalType = ARC_VMDSystem_SystemTypes.RegularDiv;
						else if(pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv)      pSignalType = ARC_VMDSystem_SystemTypes.BothDivergences;
						else if(pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences) pSignalType = ARC_VMDSystem_SystemTypes.Termite;
						else if(pSignalType == ARC_VMDSystem_SystemTypes.Termite)         pSignalType = ARC_VMDSystem_SystemTypes.None;
					}
				}
				miSignalType.Header = "Signal type:   "+pSignalType.ToString();
//				BkgChangesQue.Add(new ARC_VMDSystem_SystemTypes[2]{pSignalType, LastSignalType});
				UpdateBackgroundStripes(LastSignalType, pSignalType);
				SignalType_Updater(pSignalType, true);

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
				LastSignalType = pSignalType;
			};
			MenuControl.Items.Add(miSignalType);
			#endregion
//=============================================================================
			#region -- Show TradePlan --
			this.miShowHide_TradePlan = new MenuItem {Header = "Trade Plan is:   "+(pTradePlanVisible?"Showing":"Hidden"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_TradePlan.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				if(e != null) e.Handled = true;
				pTradePlanVisible = !pTradePlanVisible;
				miShowHide_TradePlan.Header = "Trade Plan is:   "+(pTradePlanVisible?"Showing":"Hidden");

				RemoveDrawObject("E-ray");
				RemoveDrawObject("SL-ray");
				RemoveDrawObject("T1-ray");
				RemoveDrawObject("T2-ray");
				RemoveDrawObject("cSL");
				RemoveDrawObject("cT1");
				RemoveDrawObject("cT2");
				RemoveDrawObject("cEP");
				if(pTradePlanVisible){
					#region -- Draw all trade plan rays on rightmost signal --
					double EP = double.MinValue;
					int SignalABar = -1;
					DrawTradePlanLines(ref EP, ref SignalABar);
					#endregion
				}
				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			miShowHide_TradePlan.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e != null) e.Handled = true;
				pTradePlanVisible = !pTradePlanVisible;
				miShowHide_TradePlan.Header = "Trade Plan is:   "+(pTradePlanVisible?"Showing":"Hidden");

				RemoveDrawObject("E-ray");
				RemoveDrawObject("SL-ray");
				RemoveDrawObject("T1-ray");
				RemoveDrawObject("T2-ray");
				RemoveDrawObject("cSL");
				RemoveDrawObject("cT1");
				RemoveDrawObject("cT2");
				RemoveDrawObject("cEP");
				if(pTradePlanVisible){
					#region -- Draw all trade plan rays on rightmost signal --
					double EP = double.MinValue;
					int SignalABar = -1;
					DrawTradePlanLines(ref EP, ref SignalABar);
					#endregion
				}
				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			MenuControl.Items.Add(miShowHide_TradePlan);
			#endregion
//=============================================================================
			#region -- Show Current Markers --
			this.miShowHide_CurTPMarkers = new MenuItem {Header = "Current Markers are:   "+pCurrent_TP_Markers.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_CurTPMarkers.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				if(e!=null) e.Handled = true;
				if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON)       pCurrent_TP_Markers = ARC_VMDSystem_SignalVisualTypes.OFF;
				else if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF) pCurrent_TP_Markers = ARC_VMDSystem_SignalVisualTypes.ON;
				miShowHide_CurTPMarkers.Header = "Current Markers are:   "+pCurrent_TP_Markers.ToString();

				last_trade_signal_bar = CalculateMostRecentSignalABar(pSignalType);
				if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF){
					RemoveSpecificSignalMarkersOnABar(pSignalType, last_trade_signal_bar);
				} else if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON && last_trade_signal_bar>0){
					if(pSignalType == ARC_VMDSystem_SystemTypes.Termite){
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.HiddenDiv, last_trade_signal_bar);
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.RegularDiv, last_trade_signal_bar);
						DrawHistoricalSignal(Sigs[TERMITE], last_trade_signal_bar-1);
//						UpdateEntry(Sigs[TERMITE], last_trade_signal_bar, true);
						#region -- Draw all trade plan rays on rightmost signal --
						double EP = double.MinValue;
						int SignalABar = -1;
						if(this.pTradePlanVisible)
							DrawTradePlanLines(ref EP, ref SignalABar);
						#endregion
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.Termite, last_trade_signal_bar);
						DrawHistoricalSignal(Sigs[R_DIV], last_trade_signal_bar-1);
						DrawHistoricalSignal(Sigs[H_DIV], last_trade_signal_bar-1);
//						UpdateEntry(Sigs[R_DIV], last_trade_signal_bar, true);
//						UpdateEntry(Sigs[H_DIV], last_trade_signal_bar, true);
						#region -- Draw all trade plan rays on rightmost signal --
						double EP = double.MinValue;
						int SignalABar = -1;
						if(this.pTradePlanVisible)
							DrawTradePlanLines(ref EP, ref SignalABar);
						#endregion
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv){
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.HiddenDiv, last_trade_signal_bar);
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.Termite, last_trade_signal_bar);
						DrawHistoricalSignal(Sigs[R_DIV], last_trade_signal_bar-1);
//						UpdateEntry(Sigs[R_DIV], last_trade_signal_bar, true);
						#region -- Draw all trade plan rays on rightmost signal --
						double EP = double.MinValue;
						int SignalABar = -1;
						if(this.pTradePlanVisible)
							DrawTradePlanLines(ref EP, ref SignalABar);
						#endregion
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv){
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.RegularDiv, last_trade_signal_bar);
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.Termite, last_trade_signal_bar);
						DrawHistoricalSignal(Sigs[H_DIV], last_trade_signal_bar-1);
//						UpdateEntry(Sigs[H_DIV], last_trade_signal_bar, true);
						#region -- Draw all trade plan rays on rightmost signal --
						double EP = double.MinValue;
						int SignalABar = -1;
						if(this.pTradePlanVisible)
							DrawTradePlanLines(ref EP, ref SignalABar);
						#endregion
					}
				}
//				BkgChangesQue.Add(new ARC_VMDSystem_SystemTypes[2]{pSignalType, LastSignalType});
				UpdateBackgroundStripes(LastSignalType, pSignalType, last_trade_signal_bar);

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			miShowHide_CurTPMarkers.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					e.Handled=true;
					if(e.Delta>0){
						if(pCurrent_TP_Markers      == ARC_VMDSystem_SignalVisualTypes.ON) pCurrent_TP_Markers  = ARC_VMDSystem_SignalVisualTypes.OFF;
						else if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF) pCurrent_TP_Markers = ARC_VMDSystem_SignalVisualTypes.ON;
					}else{
						if(pCurrent_TP_Markers      == ARC_VMDSystem_SignalVisualTypes.ON) pCurrent_TP_Markers  = ARC_VMDSystem_SignalVisualTypes.OFF;
						else if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF) pCurrent_TP_Markers = ARC_VMDSystem_SignalVisualTypes.ON;
					}
				}
				miShowHide_CurTPMarkers.Header = "Current Markers are:   "+pCurrent_TP_Markers.ToString();
				last_trade_signal_bar = CalculateMostRecentSignalABar(pSignalType);
				if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF)
					RemoveSpecificSignalMarkersOnABar(pSignalType, last_trade_signal_bar);
				else if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON && last_trade_signal_bar>0){
					if(pSignalType == ARC_VMDSystem_SystemTypes.Termite){
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.HiddenDiv, last_trade_signal_bar);
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.RegularDiv, last_trade_signal_bar);
						DrawHistoricalSignal(Sigs[TERMITE], last_trade_signal_bar-1);
						//UpdateEntry(Sigs[TERMITE], last_trade_signal_bar, true);
						#region -- Draw all trade plan rays on rightmost signal --
						double EP = double.MinValue;
						int SignalABar = -1;
						if(this.pTradePlanVisible)
							DrawTradePlanLines(ref EP, ref SignalABar);
						#endregion
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.Termite, last_trade_signal_bar);
						DrawHistoricalSignal(Sigs[R_DIV], last_trade_signal_bar-1);
						DrawHistoricalSignal(Sigs[H_DIV], last_trade_signal_bar-1);
//						UpdateEntry(Sigs[R_DIV], last_trade_signal_bar, true);
//						UpdateEntry(Sigs[H_DIV], last_trade_signal_bar, true);
						#region -- Draw all trade plan rays on rightmost signal --
						double EP = double.MinValue;
						int SignalABar = -1;
						if(this.pTradePlanVisible)
							DrawTradePlanLines(ref EP, ref SignalABar);
						#endregion
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv){
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.HiddenDiv, last_trade_signal_bar);
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.Termite, last_trade_signal_bar);
						DrawHistoricalSignal(Sigs[R_DIV], last_trade_signal_bar-1);
//						UpdateEntry(Sigs[R_DIV], last_trade_signal_bar, true);
						#region -- Draw all trade plan rays on rightmost signal --
						double EP = double.MinValue;
						int SignalABar = -1;
						if(this.pTradePlanVisible)
							DrawTradePlanLines(ref EP, ref SignalABar);
						#endregion
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv){
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.RegularDiv, last_trade_signal_bar);
//						RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes.Termite, last_trade_signal_bar);
						DrawHistoricalSignal(Sigs[H_DIV], last_trade_signal_bar-1);
//						UpdateEntry(Sigs[H_DIV], last_trade_signal_bar, true);
						#region -- Draw all trade plan rays on rightmost signal --
						double EP = double.MinValue;
						int SignalABar = -1;
						if(this.pTradePlanVisible)
							DrawTradePlanLines(ref EP, ref SignalABar);
						#endregion
					}
				}
//				BkgChangesQue.Add(new ARC_VMDSystem_SystemTypes[2]{pSignalType, LastSignalType});
				UpdateBackgroundStripes(LastSignalType, pSignalType, last_trade_signal_bar);

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			MenuControl.Items.Add(miShowHide_CurTPMarkers);
			#endregion
//=============================================================================
			#region -- Show Historical Markers --
			this.miShowHide_HistTPMarkers = new MenuItem {Header = "Historical Markers are:   "+pHistorical_TP_Markers.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_HistTPMarkers.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				if(e!=null) e.Handled = true;
				if(pHistorical_TP_Markers      == ARC_VMDSystem_SignalVisualTypes.ON)  pHistorical_TP_Markers = ARC_VMDSystem_SignalVisualTypes.OFF;
				else if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF) pHistorical_TP_Markers = ARC_VMDSystem_SignalVisualTypes.ON;
				miShowHide_HistTPMarkers.Header = "Historical Markers are:   "+pHistorical_TP_Markers.ToString();

				last_trade_signal_bar = CalculateMostRecentSignalABar(pSignalType);
				if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
					if(pSignalType == ARC_VMDSystem_SystemTypes.Termite){
//						RemoveAllSignalMarkers(Sigs[TERMITE], 'H');
						DrawHistoricalSignal(Sigs[TERMITE], 0);
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
//						RemoveAllSignalMarkers(Sigs[H_DIV], 'H');
//						RemoveAllSignalMarkers(Sigs[R_DIV], 'H');
						DrawHistoricalSignal(Sigs[R_DIV], 0);
						DrawHistoricalSignal(Sigs[H_DIV],  0);
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv){
//						RemoveAllSignalMarkers(Sigs[R_DIV], 'H');
						DrawHistoricalSignal(Sigs[R_DIV], 0);
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv){
//						RemoveAllSignalMarkers(Sigs[H_DIV], 'H');
						DrawHistoricalSignal(Sigs[H_DIV],  0);
					}
				}else{
					if(pSignalType == ARC_VMDSystem_SystemTypes.Termite){			RemoveAllSignalMarkers(Sigs[TERMITE],'H');
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv){	RemoveAllSignalMarkers(Sigs[H_DIV],'H');
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv){	RemoveAllSignalMarkers(Sigs[R_DIV],'H');
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
						RemoveAllSignalMarkers(Sigs[H_DIV],'H');
						RemoveAllSignalMarkers(Sigs[R_DIV],'H');
					}
				}
				//BkgChangesQue.Add(new ARC_VMDSystem_SystemTypes[2]{pSignalType, LastSignalType});
				UpdateBackgroundStripes(LastSignalType, pSignalType);

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			miShowHide_HistTPMarkers.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				if(e!=null){
					e.Handled=true;
					if(e.Delta>0){
						if(pHistorical_TP_Markers      == ARC_VMDSystem_SignalVisualTypes.ON) pHistorical_TP_Markers = ARC_VMDSystem_SignalVisualTypes.OFF;
						else if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF) pHistorical_TP_Markers = ARC_VMDSystem_SignalVisualTypes.ON;
					}else{
						if(pHistorical_TP_Markers      == ARC_VMDSystem_SignalVisualTypes.ON) pHistorical_TP_Markers = ARC_VMDSystem_SignalVisualTypes.OFF;
						else if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF) pHistorical_TP_Markers = ARC_VMDSystem_SignalVisualTypes.ON;
					}
				}
				miShowHide_HistTPMarkers.Header = "Historical Markers are:   "+pHistorical_TP_Markers.ToString();

				last_trade_signal_bar = CalculateMostRecentSignalABar(pSignalType);
				if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
					if(pSignalType == ARC_VMDSystem_SystemTypes.Termite){
//						RemoveAllSignalMarkers(Sigs[TERMITE], 'H');
						DrawHistoricalSignal(Sigs[TERMITE], 0);
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
//						RemoveAllSignalMarkers(Sigs[H_DIV],  'H');
//						RemoveAllSignalMarkers(Sigs[R_DIV], 'H');
						DrawHistoricalSignal(Sigs[R_DIV], 0);
						DrawHistoricalSignal(Sigs[H_DIV],  0);
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv){
//						RemoveAllSignalMarkers(Sigs[R_DIV], 'H');
						DrawHistoricalSignal(Sigs[R_DIV], 0);
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv){
//						RemoveAllSignalMarkers(Sigs[H_DIV], 'H');
						DrawHistoricalSignal(Sigs[H_DIV],  0);
					}
				}else{
					if(pSignalType == ARC_VMDSystem_SystemTypes.Termite){			RemoveAllSignalMarkers(Sigs[TERMITE],'H');
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv){	RemoveAllSignalMarkers(Sigs[H_DIV],'H');
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv){	RemoveAllSignalMarkers(Sigs[R_DIV],'H');
					}else if(pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
						RemoveAllSignalMarkers(Sigs[H_DIV],'H');
						RemoveAllSignalMarkers(Sigs[R_DIV],'H');
					}
				}
//				BkgChangesQue.Add(new ARC_VMDSystem_SystemTypes[2]{pSignalType, LastSignalType});
				UpdateBackgroundStripes(LastSignalType, pSignalType);

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			MenuControl.Items.Add(miShowHide_HistTPMarkers);
			#endregion
//=============================================================================
			#region -- Show/Hide SL --
			this.miShowHide_SL = new MenuItem {Header = "SL is:   "+(pSLVisible?"Showing":"Hidden"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_SL.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				e.Handled = true;
				pSLVisible = !pSLVisible;
				miShowHide_SL.Header = "SL is:   "+(pSLVisible?"Showing":"Hidden");

				if (pSignalType == ARC_VMDSystem_SystemTypes.None) return;
				RemoveDrawObject("SL-ray");
				if(pSLVisible){
					AddOrUpdateSL(Sigs[TERMITE],    pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF &&  pSignalType == ARC_VMDSystem_SystemTypes.Termite);
					AddOrUpdateSL(Sigs[H_DIV],  pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					AddOrUpdateSL(Sigs[R_DIV], pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					#region -- Redraw TradePlan --
					double EP = double.MinValue;
					int SignalABar = -1;
					if(this.pTradePlanVisible)
						DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
					#endregion
				}else{
					DeleteAllDrawObjectsStartingWith("SL");
					RemoveDrawObject("cSL");
				}
				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			miShowHide_SL.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				e.Handled=true;
				pSLVisible = !pSLVisible;
				miShowHide_SL.Header = "SL is:   "+(pSLVisible?"Showing":"Hidden");

				if (pSignalType == ARC_VMDSystem_SystemTypes.None) return;
				RemoveDrawObject("SL-ray");
				if(pSLVisible){
					AddOrUpdateSL(Sigs[TERMITE],    pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType == ARC_VMDSystem_SystemTypes.Termite);
					AddOrUpdateSL(Sigs[H_DIV],  pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					AddOrUpdateSL(Sigs[R_DIV], pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					#region -- Redraw TradePlan --
					double EP = double.MinValue;
					int SignalABar = -1;
					if(this.pTradePlanVisible)
						DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
					#endregion
				}else{
					DeleteAllDrawObjectsStartingWith("SL");
					RemoveDrawObject("cSL");
				}
				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			MenuControl.Items.Add(miShowHide_SL);
			#endregion
//=============================================================================
			#region -- Show/Hide T1 --
			this.miShowHide_T1 = new MenuItem {Header = "T1 is:   "+(pT1Visible?"Showing":"Hidden"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_T1.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				e.Handled = true;
				pT1Visible = !pT1Visible;
				miShowHide_T1.Header = "T1 is:   "+(pT1Visible?"Showing":"Hidden");

				if (pSignalType == ARC_VMDSystem_SystemTypes.None) return;
				RemoveDrawObject("T1-ray");
				if(pT1Visible){
					AddOrUpdateTarget(Sigs[TERMITE],    1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType  == ARC_VMDSystem_SystemTypes.Termite);
					AddOrUpdateTarget(Sigs[H_DIV],  1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					AddOrUpdateTarget(Sigs[R_DIV], 1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					#region -- Redraw TradePlan --
					double EP = double.MinValue;
					int SignalABar = -1;
					if(this.pTradePlanVisible)
						DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
					#endregion
				}else{
					DeleteAllDrawObjectsStartingWith("T1");
					RemoveDrawObject("cT1");
				}
				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			miShowHide_T1.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				e.Handled=true;
				pT1Visible = !pT1Visible;
				miShowHide_T1.Header = "T1 is:   "+(pT1Visible?"Showing":"Hidden");

				if (pSignalType == ARC_VMDSystem_SystemTypes.None) return;
				RemoveDrawObject("T1-ray");
				if(pT1Visible){
					AddOrUpdateTarget(Sigs[TERMITE],    1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType  == ARC_VMDSystem_SystemTypes.Termite);
					AddOrUpdateTarget(Sigs[H_DIV],  1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					AddOrUpdateTarget(Sigs[R_DIV], 1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					#region -- Redraw TradePlan --
					double EP = double.MinValue;
					int SignalABar = -1;
					if(this.pTradePlanVisible)
						DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
					#endregion
				}else{
					DeleteAllDrawObjectsStartingWith("T1");
					RemoveDrawObject("cT1");
				}
				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			MenuControl.Items.Add(miShowHide_T1);
			#endregion
//=============================================================================
			#region -- Show/Hide T2 --
			this.miShowHide_T2 = new MenuItem {Header = "T2 is:   "+(pT2Visible?"Showing":"Hidden"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowHide_T2.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				e.Handled = true;
				pT2Visible = !pT2Visible;
				miShowHide_T2.Header = "T2 is:   "+(pT2Visible?"Showing":"Hidden");

				if (pSignalType == ARC_VMDSystem_SystemTypes.None) return;
				RemoveDrawObject("T2-ray");
				if(pT2Visible){
					AddOrUpdateTarget(Sigs[TERMITE],    2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType  == ARC_VMDSystem_SystemTypes.Termite);
					AddOrUpdateTarget(Sigs[H_DIV],  2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					AddOrUpdateTarget(Sigs[R_DIV], 2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					#region -- Redraw TradePlan --
					double EP = double.MinValue;
					int SignalABar = -1;
					if(this.pTradePlanVisible)
						DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
					#endregion
				}else{
					DeleteAllDrawObjectsStartingWith("T2");
					RemoveDrawObject("cT2");
				}
				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			miShowHide_T2.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				e.Handled=true;
				pT2Visible = !pT2Visible;
				miShowHide_T2.Header = "T2 is:   "+(pT2Visible?"Showing":"Hidden");

				if (pSignalType == ARC_VMDSystem_SystemTypes.None) return;
				RemoveDrawObject("T2-ray");
				if(pT2Visible){
					AddOrUpdateTarget(Sigs[TERMITE],    2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType  == ARC_VMDSystem_SystemTypes.Termite);
					AddOrUpdateTarget(Sigs[H_DIV],  2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					AddOrUpdateTarget(Sigs[R_DIV], 2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
					#region -- Redraw TradePlan --
					double EP = double.MinValue;
					int SignalABar = -1;
					if(this.pTradePlanVisible)
						DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
					#endregion
				}else{
					DeleteAllDrawObjectsStartingWith("T2");
					RemoveDrawObject("cT2");
				}
				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			MenuControl.Items.Add(miShowHide_T2);
			#endregion
//=============================================================================
			#region -- SL ticks --
			this.miSLTicks = new MenuItem {Header = "SL Ticks:   "+pSLTicks.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };

			miSLTicks.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				e.Handled = true;
				pSLTicks++;
				miSLTicks.Header = "SL Ticks:   "+pSLTicks.ToString();
				AddOrUpdateSL(Sigs[TERMITE],    pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType == ARC_VMDSystem_SystemTypes.Termite);
				AddOrUpdateSL(Sigs[H_DIV],  pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				AddOrUpdateSL(Sigs[R_DIV], pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				#region -- Redraw TradePlan --
				double EP = double.MinValue;
				int SignalABar = -1;
				if(this.pTradePlanVisible)
					DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
				#endregion

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			miSLTicks.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				e.Handled=true;
				if(e.Delta>0) {
					pSLTicks++;
				}else{
					pSLTicks--;
				}
				miSLTicks.Header = "SL Ticks:   "+pSLTicks.ToString();
				AddOrUpdateSL(Sigs[TERMITE],    pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType == ARC_VMDSystem_SystemTypes.Termite);
				AddOrUpdateSL(Sigs[H_DIV],  pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				AddOrUpdateSL(Sigs[R_DIV], pSLTicks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				#region -- Redraw TradePlan --
				double EP = double.MinValue;
				int SignalABar = -1;
				if(this.pTradePlanVisible)
					DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
				#endregion

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			MenuControl.Items.Add(miSLTicks);
			#endregion
//=============================================================================
			#region -- T1 ticks --
			this.miT1Ticks = new MenuItem {Header = "T1 Ticks:   "+pT1Ticks.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };

			miT1Ticks.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				e.Handled = true;
				pT1Ticks++;
				miT1Ticks.Header = "T1 Ticks:   "+pT1Ticks.ToString();
				AddOrUpdateTarget(Sigs[TERMITE],    1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType  == ARC_VMDSystem_SystemTypes.Termite);
				AddOrUpdateTarget(Sigs[H_DIV],  1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				AddOrUpdateTarget(Sigs[R_DIV], 1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				#region -- Redraw TradePlan --
				double EP = double.MinValue;
				int SignalABar = -1;
				if(this.pTradePlanVisible)
					DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
				#endregion

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			miT1Ticks.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				e.Handled=true;
				if(e.Delta>0) {
					pT1Ticks++;
				}else{
					pT1Ticks--;
				}
				miT1Ticks.Header = "T1 Ticks:   "+pT1Ticks.ToString();
				AddOrUpdateTarget(Sigs[TERMITE],    1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType  == ARC_VMDSystem_SystemTypes.Termite);
				AddOrUpdateTarget(Sigs[H_DIV],  1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				AddOrUpdateTarget(Sigs[R_DIV], 1, pT1Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				#region -- Redraw TradePlan --
				double EP = double.MinValue;
				int SignalABar = -1;
				if(this.pTradePlanVisible)
					DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
				#endregion

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			MenuControl.Items.Add(miT1Ticks);
			#endregion
//=============================================================================
			#region -- T2 ticks --
			this.miT2Ticks = new MenuItem {Header = "T2 Ticks:   "+pT2Ticks.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };

			miT2Ticks.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				e.Handled = true;
				pT2Ticks++;
				miT2Ticks.Header = "T2 Ticks:   "+pT2Ticks.ToString();
				AddOrUpdateTarget(Sigs[TERMITE],    2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType  == ARC_VMDSystem_SystemTypes.Termite);
				AddOrUpdateTarget(Sigs[H_DIV],  2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				AddOrUpdateTarget(Sigs[R_DIV], 2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				#region -- Redraw TradePlan --
				double EP = double.MinValue;
				int SignalABar = -1;
				if(this.pTradePlanVisible)
					DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
				#endregion

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			miT2Ticks.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				e.Handled=true;
				if(e.Delta>0) {
					pT2Ticks++;
				}else{
					pT2Ticks--;
				}
				miT2Ticks.Header = "T2 Ticks:   "+pT2Ticks.ToString();
				AddOrUpdateTarget(Sigs[TERMITE],    2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && pSignalType  == ARC_VMDSystem_SystemTypes.Termite);
				AddOrUpdateTarget(Sigs[H_DIV],  2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				AddOrUpdateTarget(Sigs[R_DIV], 2, pT2Ticks * TickSize, pHistorical_TP_Markers!=ARC_VMDSystem_SignalVisualTypes.OFF && (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences));
				#region -- Redraw TradePlan --
				double EP = double.MinValue;
				int SignalABar = -1;
				if(this.pTradePlanVisible)
					DrawTradePlanLines(ref EP, ref SignalABar, pSignalType);
				#endregion

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			MenuControl.Items.Add(miT2Ticks);
			#endregion
//=============================================================================
			#region -- Racing Stripes ticks --
			this.miShowHide_RacingStripes = new MenuItem {Header = "Racing Stripes:  "+(pShowRacingStripes ? "ON":"OFF"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };

			miShowHide_RacingStripes.Click += delegate (object o, RoutedEventArgs e){
				#region -- Click --
				e.Handled = true;
				pShowRacingStripes = !pShowRacingStripes;
				miShowHide_RacingStripes.Header = "Racing Stripes:  "+(pShowRacingStripes ? "ON":"OFF");
				//BkgChangesQue.Add(new ARC_VMDSystem_SystemTypes[2]{pSignalType, LastSignalType});
				UpdateBackgroundStripes(LastSignalType, pSignalType);

				if(pShowRacingStripes && this.pSellStripeOpacity==0 && pBuyStripeOpacity==0){
					MsgOnChart = "ARC_VMDSystem Racing stripe opacities are currently '0'\nNo stripes will show until you increase those opacities";
				}
				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			miShowHide_RacingStripes.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region -- Mousewheel --
				e.Handled=true;
				if(e.Delta>0) {
					pShowRacingStripes = !pShowRacingStripes;
				}else{
					pShowRacingStripes = !pShowRacingStripes;
				}
				miShowHide_RacingStripes.Header = "Racing Stripes:  "+(pShowRacingStripes ? "ON":"OFF");
//				BkgChangesQue.Add(new ARC_VMDSystem_SystemTypes[2]{pSignalType, LastSignalType});
				UpdateBackgroundStripes(LastSignalType, pSignalType);

				if(pShowRacingStripes && this.pSellStripeOpacity==0 && pBuyStripeOpacity==0){
					MsgOnChart = "Racing stripe opacities are '0', no stripes will show until you increase those opacities";
				}

				ForceRefresh();
				MenuControl.InvalidateVisual();
				#endregion
			};
			MenuControl.Items.Add(miShowHide_RacingStripes);
			#endregion
//=============================================================================
			if(pSignalType == ARC_VMDSystem_SystemTypes.None)
				HideShow_SignalMenuItems('H');
			else
				HideShow_SignalMenuItems('S');

            indytoolbar.Children.Add(MenuControlContainer);
        }
        #endregion
        #region -- Toolbar Management Utilities --
//=====================================================================================================
		private void InformUserAboutRecalculation(){
			miRecalculate1.Background = Brushes.Yellow;
			miRecalculate1.FontWeight = FontWeights.Bold;
			miRecalculate1.FontStyle = FontStyles.Italic;
		}
		private void ResetRecalculationUI(){
			miRecalculate1.FontWeight = FontWeights.Normal;
			miRecalculate1.FontStyle = FontStyles.Normal;
			miRecalculate1.Background = null;
		}
//=====================================================================================================

        private Grid createMSTMenu(string nudValue1, string nudValue2)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(55) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - MST1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Sensitivity :" };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudMST1 = new TextBox() { Name = "MST1txtbox" + uID, MinWidth = 60, Width = 60, MaxWidth = 60, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST1.Text = nudValue1;
            nudMST1.KeyDown += menuTxtbox_KeyDown;
            nudMST1.TextChanged += NumericUpDownValueChanged;
			nudMST1.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0) MultiplierDTB = MultiplierDTB+0.1;
				else MultiplierDTB = MultiplierDTB-0.1;
				MultiplierDTB = Math.Max(0,MultiplierDTB);
				nudMST1.Text = MultiplierDTB.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
				};
			nudMST1.SetValue(Grid.ColumnProperty, 1);
            nudMST1.SetValue(Grid.ColumnSpanProperty, 2);
            nudMST1.SetValue(Grid.RowProperty, 0);
            nudMST1.SetValue(Grid.RowSpanProperty, 2);
            
            //line 2 - MST2
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Strength : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudMST2 = new TextBox() { Name = "MST2txtbox" + uID, MinWidth = 50, Width = 50, MaxWidth = 50, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST2.Text = nudValue2;
            nudMST2.KeyDown += menuTxtbox_KeyDown;
            nudMST2.TextChanged += NumericUpDownValueChanged;
			nudMST2.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0) SwingStrength++;
				else SwingStrength--;
				SwingStrength = Math.Max(1,SwingStrength);
				nudMST2.Text = SwingStrength.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
				};
            nudMST2.SetValue(Grid.ColumnProperty, 1);
            nudMST2.SetValue(Grid.RowProperty, 2);
            nudMST2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = "MST2cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = "MST2cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 2);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMST1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudMST2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            return grid;
        }

        //---------- Events ------------------------------------------------
        #region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #region -- DoubleEditKeyPress -- 
        private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtSender = sender as TextBox;

            int keyVal = (int)e.Key;
            int value = -1;
            if (keyVal >= (int)Key.D0 && keyVal <= (int)Key.D9) value = keyVal - (int)Key.D0;
            else if (keyVal >= (int)Key.NumPad0 && keyVal <= (int)Key.NumPad9) value = keyVal - (int)Key.NumPad0;

            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);

            if (isNumeric || e.Key == Key.Back || (e.Key == Key.Decimal && txtSender.Name== "MST1txtbox"))
            {
                string newText = value != -1 ? value.ToString() : e.Key == Key.Decimal ? System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator : "";
                int tbPosition = txtSender.SelectionStart;
                txtSender.Text = txtSender.SelectedText == "" ? txtSender.Text.Insert(tbPosition, newText) : txtSender.Text.Replace(txtSender.SelectedText, newText);
                txtSender.Select(tbPosition + 1, 0);
            }
        }
        #endregion

        #region -- DoubleEditTextChanged --
        private string currentTextEdit;
        private void NumericUpDownValueChanged(object sender, EventArgs e)
        {
            TextBox txtSender = sender as TextBox;
            if (txtSender.Text.Length > 0)
            {
                float result;
                bool isNumeric = float.TryParse(txtSender.Text, out result);

                if (isNumeric) currentTextEdit = txtSender.Text;
                else
                {
                    txtSender.Text = currentTextEdit;
                    txtSender.Select(txtSender.Text.Length, 0);
                }
                if (txtSender.Name == "MST1txtbox") MultiplierDTB = Convert.ToDouble(nudMST1.Text);
                else if (txtSender.Name == "MST2txtbox") SwingStrength = Convert.ToInt32(nudMST2.Text);
            }
        }
        #endregion

        #region -- cmdupdw_Click --
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
            Button cmd = sender as Button;
            if (cmd.Name.Contains("MST2cmdup")) nudMST2.Text = (Math.Min(999999999, Convert.ToInt32(nudMST2.Text) + 1)).ToString();
            else if (cmd.Name.Contains("MST2cmddw")) nudMST2.Text = (Math.Max(1, Convert.ToInt32(nudMST2.Text) - 1)).ToString();
        }
        #endregion

        #region -- MarketStructure_Click --
        private void MarketStructure_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //----------- Divergences Options -------------------
            if (item != null && item.Name == "btMarketStructure_trends") ShowZigzagLegs = !ShowZigzagLegs;
            else if (item != null && item.Name == "btMarketStructure_labels") ShowZigzagLabels = !ShowZigzagLabels;

            miMarketStructure1.Header = "Structure Swings " + (ShowZigzagLegs ? "ON" : "OFF");
            miMarketStructure2.Header = "Structure Labels " + (ShowZigzagLabels ? "ON" : "OFF");
        }

        #endregion

        #region -- FloodingValueChanged --
        private void FloodingValueChanged(object sender, EventArgs e)
        {
            ARC_VMDSystem_Flooding backgroundFlooding;
            Enum.TryParse((string)comboFlooding.SelectedItem, out backgroundFlooding);
            BackgroundFlooding = backgroundFlooding;
            RefreshChart_Click(null, null);
        }
        #endregion

        #region -- ExcursionStyleValueChanged --
        private void ExcursionStyleValueChanged(object sender, EventArgs e)
        {
            PlotStyleLevels = (string)comboExcursionStyle.SelectedItem == ARC_VMDSystem_ExcursionStyle.Static.ToString() ? PlotStyle.HLine : PlotStyle.Line;
            RefreshChart_Click(null, null);
        }
        #endregion

        #region -- RefreshChart_Click --
        private void RefreshChart_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                MenuItem item = sender as MenuItem;

                //----------- Excursion Levels -------------------
                if (item.Name.Contains("btExcursionLevels"))
                {
                    if (item.Name == "btExcursionLevels_Level1") DisplayLevel1 = !DisplayLevel1;
                    else if (item.Name == "btExcursionLevels_Level2") DisplayLevel2 = !DisplayLevel2;
                    else if (item.Name == "btExcursionLevels_Level3") DisplayLevel3 = !DisplayLevel3;
                    else if (item.Name == "btExcursionLevels_Master")
                    {
                        bool master = ((string)(item.Header)).Contains("ON");
                        master = !master;
                        item.Header = "--- MASTER " + (master ? "ON" : "OFF") + " ---";

                        DisplayLevel1 = master;
                        DisplayLevel2 = master;
                        DisplayLevel3 = master;
                    }

                    miExcursionLevels1.Header = "Show Level 1 " + (DisplayLevel1 ? "ON" : "OFF");
                    miExcursionLevels2.Header = "Show Level 2 " + (DisplayLevel2 ? "ON" : "OFF");
                    miExcursionLevels3.Header = "Show Level 3 " + (DisplayLevel3 ? "ON" : "OFF");
                }
                else if (item.Name.Contains("btSentiment"))
                {
                    if (item.Name == "btSentiment_Sentiment")
                    {
                        ShowSentimentInBox = !ShowSentimentInBox;
                        item.Header = "Show Histogram Sentiment " + (ShowSentimentInBox ? "ON" : "OFF");
                    }
                    else if (item.Name == "btSentiment_Bias")
                    {
                        ShowBiasInBox = !ShowBiasInBox;
                        item.Header = "Show Structure Bias " + (ShowBiasInBox ? "ON" : "OFF");
                    }

                    showBox = ShowSentimentInBox || ShowBiasInBox;
                }
            }

            ChartControl.InvalidateVisual();
        }
        #endregion

        #region -- ModifyDivOptionsSetting_Click --
        private void ModifyDivOptionsSetting_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //----------- Divergences Options -------------------
            if (item != null && item.Name == "btDivOptions_AdjustDiv") UseOscHighLow = !UseOscHighLow;
            else if (item != null && item.Name == "btDivOptions_IncludeDTDB") IncludeDoubleTopsAndBottoms = !IncludeDoubleTopsAndBottoms;
            else if (item != null && item.Name == "btDivOptions_RecentDivs") UseLastSwingOnly = !UseLastSwingOnly;
            else if (item != null && item.Name == "btDivOptions_ResetFilter") ResetFilter = !ResetFilter;

            miDivOptions1.Header = "Adjust Divergence " + (UseOscHighLow ? "ON" : "OFF");
            miDivOptions2.Header = "Include DT/DB " + (IncludeDoubleTopsAndBottoms ? "ON" : "OFF");
            miDivOptions3.Header = "Recent divergences only " + (UseLastSwingOnly ? "ON" : "OFF");
            miDivOptions4.Header = "Reset Filter " + (ResetFilter ? "ON" : "OFF");
        }
        #endregion

        #region -- ReloadChart_Click --
        private void ReloadChart_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //----------- Market Structure -------------------
            if (item.Name == "marketStructureClick")
            {
                try
                {
                    MultiplierDTB = Math.Max(0, Convert.ToDouble(nudMST1.Text));
                    SwingStrength = Math.Max(1, Convert.ToInt32(nudMST2.Text));
					ResetRecalculationUI();
                }
                catch (Exception){ }
            }

            System.Windows.Forms.SendKeys.SendWait("{F5}");
        }
        #endregion

        #region -- ModifyDisplayOptionsSetting_Click --
        private void ModifyDisplayOptionsSetting_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //----------- Display Options -------------------
            if (item.Name == "btDisplayOptions_ShowDivDots") ShowSetupDots = !ShowSetupDots;
            else if (item.Name == "btDisplayOptions_ShowDivOnPricePanel") ShowDivOnPricePanel = !ShowDivOnPricePanel;
            else if (item.Name == "btDisplayOptions_ShowDivOnSubPanel") ShowDivOnOscillatorPanel = !ShowDivOnOscillatorPanel;
            else if (item.Name == "btDisplayOptions_ShowHistoDiv") ShowHistogramDivergences = !ShowHistogramDivergences;
            else if (item.Name == "btDisplayOptions_ShowHistoHDiv") ShowHistogramHiddenDivergences = !ShowHistogramHiddenDivergences;
            else if (item.Name == "btDisplayOptions_ShowMACDDiv") ShowOscillatorDivergences = !ShowOscillatorDivergences;
            else if (item.Name == "btDisplayOptions_ShowMACDHDiv") ShowOscillatorHiddenDivergences = !ShowOscillatorHiddenDivergences;
            else if (item.Name == "btDisplayOptions_Master")
            {
                bool master = ((string)(item.Header)).Contains("ON");
                master = !master;
                item.Header = "--- MASTER " + (master ? "ON" : "OFF") + " ---";

                ShowSetupDots = master;
                ShowDivOnPricePanel = master;
                ShowDivOnOscillatorPanel = master;
                ShowHistogramDivergences = master;
                ShowHistogramHiddenDivergences = master;
                ShowOscillatorDivergences = master;
                ShowOscillatorHiddenDivergences = master;
            }

            //-----------Market Structure------------------ -
            else if (item.Name == "marketStructureClick")
            {
                MultiplierDTB = Convert.ToDouble(nudMST1.Text);
                SwingStrength = Convert.ToInt32(nudMST2.Text);
				ResetRecalculationUI();
            }

            miDisplayOptions1.Header = "Show Div Dots " + (ShowSetupDots ? "ON" : "OFF");
            miDisplayOptions2.Header = "Show Div On Price Panel " + (ShowDivOnPricePanel ? "ON" : "OFF");
            miDisplayOptions3.Header = "Show Div On Sub-Panel " + (ShowDivOnOscillatorPanel ? "ON" : "OFF");
            miDisplayOptions4.Header = "Show Histogram Div " + (ShowHistogramDivergences ? "ON" : "OFF");
            miDisplayOptions5.Header = "Show Histogram Hidden Div " + (ShowHistogramHiddenDivergences ? "ON" : "OFF");
            miDisplayOptions6.Header = "Show MACD Div " + (ShowOscillatorDivergences ? "ON" : "OFF");
            miDisplayOptions7.Header = "Show MACD Hidden Div " + (ShowOscillatorHiddenDivergences ? "ON" : "OFF");
        }
        #endregion

        #endregion
//===================================================================================================================
		#region -- System Signal classes and methods --
		private MenuItem miSignalType, miSLTicks, miT1Ticks, miT2Ticks;
		private MenuItem miShowHide_TradePlan, miShowHide_HistTPMarkers, miShowHide_CurTPMarkers, miShowHide_SL, miShowHide_T1, miShowHide_T2, miShowHide_RacingStripes;
		static string  RayTemplates_folder = null;
//================================================================================================================================================
		private class SignalData{
			public double EntryPrice = int.MinValue;
			public double SLPrice    = int.MinValue;
			public double T1Price    = int.MinValue;
			public double T2Price    = int.MinValue;
			public bool IsVisible = true;
			public SignalData(int Dir, double entryPrice, double slPrice, double t1Price, double t2Price, bool isVisible){EntryPrice=entryPrice; SLPrice=entryPrice + -Dir*slPrice; T1Price=entryPrice + Dir*t1Price; T2Price=entryPrice + Dir*t2Price; IsVisible=isVisible;}
			public string ToStr(){
				return string.Format("{0}  E{1}  S{2}  T1{3}  T2{4}",IsVisible.ToString(), EntryPrice, SLPrice, T1Price, T2Price);
			}
		}
		private class SignalsManager{
			public string Name    = string.Empty;
			public const int BUY  = 1;
			public const int FLAT = 0;
			public const int SELL = -1;
			public SortedDictionary<int,SignalData> BuySignals  = new SortedDictionary<int,SignalData>();
			public SortedDictionary<int,SignalData> SellSignals = new SortedDictionary<int,SignalData>();
			public bool DrawEntryArrow = true;
			public List<bool> c        = new List<bool>();
			public List<int> SwingHighABars = new List<int>();
			public List<int> SwingLowABars  = new List<int>();
			public List<double> SuppLevels    = new List<double>();
			public List<double> ResLevels    = new List<double>();
			public bool PermitLongs  = true;
			public bool PermitShorts = true;
			public int RightmostVisibleSignal = -1;
			public SignalsManager(string name){
				Name = name;
//				if(name.StartsWith("T")) DrawEntryArrow = true;
//				else DrawEntryArrow = false;
			}
			public bool IsEntrySignal(){
				if(c.Count==0) return false;
				foreach(bool x in c) {
					if(!x) return false;
				}
				return true;
			}
			public void AddStructure(char Type, double Price, int ABar){
				if(Type=='H'){
					SwingHighABars.Insert(0, ABar);
					if(!ResLevels.Contains(Price)) ResLevels.Add(Price);
				} else if(Type=='L'){
					SwingLowABars.Insert(0, ABar);
					if(!SuppLevels.Contains(Price)) SuppLevels.Add(Price);
				}
			}
		}
//================================================================================================
		private void HideShow_SignalMenuItems(char HideShow){
			if(HideShow == 'H'){
				#region -- Set menu to Hidden --
				miShowHide_TradePlan.Visibility = Visibility.Collapsed;
				miShowHide_HistTPMarkers.Visibility = Visibility.Collapsed;
				miShowHide_CurTPMarkers.Visibility = Visibility.Collapsed;
				miShowHide_SL.Visibility = Visibility.Collapsed;
				miShowHide_T1.Visibility = Visibility.Collapsed;
				miShowHide_T2.Visibility = Visibility.Collapsed;
				miSLTicks.Visibility = Visibility.Collapsed;
				miT1Ticks.Visibility = Visibility.Collapsed;
				miT2Ticks.Visibility = Visibility.Collapsed;
				miShowHide_RacingStripes.Visibility = Visibility.Collapsed;
				#endregion
			}
			if(HideShow == 'S'){
				#region -- Set menu to Visible --
				miShowHide_TradePlan.Visibility = Visibility.Visible;
				miShowHide_HistTPMarkers.Visibility = Visibility.Visible;
				miShowHide_CurTPMarkers.Visibility = Visibility.Visible;
				miShowHide_SL.Visibility = Visibility.Visible;
				miShowHide_T1.Visibility = Visibility.Visible;
				miShowHide_T2.Visibility = Visibility.Visible;
				miSLTicks.Visibility = Visibility.Visible;
				miT1Ticks.Visibility = Visibility.Visible;
				miT2Ticks.Visibility = Visibility.Visible;
				miShowHide_RacingStripes.Visibility = Visibility.Visible;
				#endregion
			}
		}
//================================================================================================
		private void UpdateBackgroundStripes(ARC_VMDSystem_SystemTypes LastSignalType, ARC_VMDSystem_SystemTypes SignalType){
			#region -- UpdateBackgroundStripes --
			int offset = 1;
			if(LastSignalType == ARC_VMDSystem_SystemTypes.Termite){
				foreach(var abar in Sigs[TERMITE].BuySignals.Keys) if(IsValidRBar(CurrentBar-abar+offset))  BackBrushesAll.Set(abar-offset, null);
				foreach(var abar in Sigs[TERMITE].SellSignals.Keys) if(IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, null);
			}
			if(LastSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || LastSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
				foreach(var abar in Sigs[H_DIV].BuySignals.Keys)  if(IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, null);
				foreach(var abar in Sigs[H_DIV].SellSignals.Keys) if(IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, null);
			}
			if(LastSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || LastSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
				foreach(var abar in Sigs[R_DIV].BuySignals.Keys)  if(IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, null);
				foreach(var abar in Sigs[R_DIV].SellSignals.Keys) if(IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, null);
			}
//Print("SHow Racing Stripes? "+pShowRacingStripes.ToString());
			if(pShowRacingStripes){
				List<int> BarsToStripe = null;
				int firstStripeABar = 0;
				int lastStripeABar  = int.MaxValue;
#if SHOW_STRIPES_ONLY_ON_MARKERS
				if(pHistorical_TP_Markers      == ARC_VMDSystem_SignalVisualTypes.OFF) 	firstStripeABar = last_trade_signal_bar;
				else if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON)	firstStripeABar = 0;
				if(pCurrent_TP_Markers         == ARC_VMDSystem_SignalVisualTypes.OFF)	lastStripeABar  = last_trade_signal_bar-1;
				else if(pCurrent_TP_Markers    == ARC_VMDSystem_SignalVisualTypes.ON)	lastStripeABar  = int.MaxValue;
#endif
//					BarsToStripe = Sigs[TERMITE].BuySignals.Keys.Where(k=> k>= last_trade_signal_bar).ToList();
//Print("SIgnal type: "+SignalType.ToString());
//Print("H_Div:  buy "+Sigs[H_DIV].BuySignals.Count+"  sell: "+Sigs[H_DIV].SellSignals.Count);
//Print("R_Div:  buy "+Sigs[R_DIV].BuySignals.Count+"  sell: "+Sigs[R_DIV].SellSignals.Count);
				if(SignalType == ARC_VMDSystem_SystemTypes.Termite){
					if(this.pBuyStripeOpacity>0  && pBuyStripeBrush  != Brushes.Transparent) {
						foreach(var abar in Sigs[TERMITE].BuySignals.Keys)	{
							if(abar >= firstStripeABar && abar <= lastStripeABar && IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, BuyStripeBrush);
						}
					}
					if(this.pSellStripeOpacity>0 && pSellStripeBrush != Brushes.Transparent) 
						foreach(var abar in Sigs[TERMITE].SellSignals.Keys) {
							if(abar >= firstStripeABar && abar <= lastStripeABar && IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, SellStripeBrush);
						}
				}
				if(SignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || SignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
					if(this.pBuyStripeOpacity>0  && pBuyStripeBrush  != Brushes.Transparent) 
						foreach(var abar in Sigs[H_DIV].BuySignals.Keys) {
							if(abar >= firstStripeABar && abar <= lastStripeABar && IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, BuyStripeBrush);
						}
					if(this.pSellStripeOpacity>0 && pSellStripeBrush != Brushes.Transparent) 
						foreach(var abar in Sigs[H_DIV].SellSignals.Keys) {
							if(abar >= firstStripeABar && abar <= lastStripeABar && IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, SellStripeBrush);
						}
				}
				if(SignalType == ARC_VMDSystem_SystemTypes.RegularDiv || SignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
					if(this.pBuyStripeOpacity>0  && pBuyStripeBrush  != Brushes.Transparent) 
						foreach(var abar in Sigs[R_DIV].BuySignals.Keys){
							if(abar >= firstStripeABar && abar <= lastStripeABar && IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, BuyStripeBrush);
						}
					if(this.pSellStripeOpacity>0 && pSellStripeBrush != Brushes.Transparent) 
						foreach(var abar in Sigs[R_DIV].SellSignals.Keys){
							if(abar >= firstStripeABar && abar <= lastStripeABar && IsValidRBar(CurrentBar-abar+offset)) BackBrushesAll.Set(abar-offset, SellStripeBrush);
						}
				}
			}
			#endregion
		}
//================================================================================================
		private void UpdateBackgroundStripes(ARC_VMDSystem_SystemTypes LastSignalType, ARC_VMDSystem_SystemTypes SignalType, int CurrentTradeABar){
			#region -- UpdateBackgroundStripes --
			int offset = 1;
			if(LastSignalType == ARC_VMDSystem_SystemTypes.Termite){
				if(Sigs[TERMITE].BuySignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, null);
				if(Sigs[TERMITE].SellSignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, null);
			}
			if(LastSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || LastSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
				if(Sigs[H_DIV].BuySignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, null);
				if(Sigs[H_DIV].SellSignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, null);
			}
			if(LastSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || LastSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
				if(Sigs[R_DIV].BuySignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, null);
				if(Sigs[R_DIV].SellSignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, null);
			}
			if(pShowRacingStripes){
				if(SignalType == ARC_VMDSystem_SystemTypes.Termite){
					if(this.pBuyStripeOpacity>0  && pBuyStripeBrush  != Brushes.Transparent)
						if(Sigs[TERMITE].BuySignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, BuyStripeBrush);
					if(this.pSellStripeOpacity>0 && pSellStripeBrush != Brushes.Transparent) 
						if(Sigs[TERMITE].SellSignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, SellStripeBrush);
				}
				if(SignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || SignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
					if(this.pBuyStripeOpacity>0  && pBuyStripeBrush  != Brushes.Transparent)
						if(Sigs[H_DIV].BuySignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, BuyStripeBrush);
					if(this.pSellStripeOpacity>0 && pSellStripeBrush != Brushes.Transparent) 
						if(Sigs[H_DIV].SellSignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, SellStripeBrush);
				}
				if(SignalType == ARC_VMDSystem_SystemTypes.RegularDiv || SignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
					if(this.pBuyStripeOpacity>0  && pBuyStripeBrush  != Brushes.Transparent)
						if(Sigs[R_DIV].BuySignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, BuyStripeBrush);
					if(this.pSellStripeOpacity>0 && pSellStripeBrush != Brushes.Transparent) 
						if(Sigs[R_DIV].SellSignals.ContainsKey(CurrentTradeABar)) BackBrushesAll.Set(CurrentTradeABar-offset, SellStripeBrush);
				}
			}
			#endregion
		}
//================================================================================================
		private void SignalType_Updater(ARC_VMDSystem_SystemTypes Signal, bool UpdateUI){
			#region -------
			if(Signal == ARC_VMDSystem_SystemTypes.None){
				RemoveDrawObject("E-ray");
				RemoveDrawObject("SL-ray");
				RemoveDrawObject("T1-ray");
				RemoveDrawObject("T2-ray");
				RemoveDrawObject("cEP");
				RemoveDrawObject("cSL");
				RemoveDrawObject("cT1");
				RemoveDrawObject("cT2");
				if(LastSignalType == ARC_VMDSystem_SystemTypes.Termite)              RemoveAllSignalMarkers(Sigs[TERMITE]);
				else if(LastSignalType == ARC_VMDSystem_SystemTypes.RegularDiv)      RemoveAllSignalMarkers(Sigs[R_DIV]);
				else if(LastSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv)       RemoveAllSignalMarkers(Sigs[H_DIV]);
				else if(LastSignalType == ARC_VMDSystem_SystemTypes.BothDivergences) RemoveAllSignalMarkers(Sigs[H_DIV]);
//				RemoveAllSignalMarkers(Sigs[TERMITE]);
//				RemoveAllSignalMarkers(Sigs[H_DIV]);
//				RemoveAllSignalMarkers(Sigs[R_DIV]);
			}
			else if(Signal == ARC_VMDSystem_SystemTypes.Termite){
				#region -- Draw historical markers if necessary --
				if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
					//RemoveAllSignalMarkers(Sigs[TERMITE], 'H');
					if(LastSignalType == ARC_VMDSystem_SystemTypes.RegularDiv)     RemoveAllSignalMarkers(Sigs[R_DIV],'H');
					else if(LastSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv) RemoveAllSignalMarkers(Sigs[H_DIV],'H');
					else if(LastSignalType == ARC_VMDSystem_SystemTypes.BothDivergences) {
						RemoveAllSignalMarkers(Sigs[H_DIV],'H');
						RemoveAllSignalMarkers(Sigs[R_DIV],'H');
					}
					DrawHistoricalSignal(Sigs[TERMITE], 0);
				}else{
					if(pSignalType == ARC_VMDSystem_SystemTypes.Termite)	RemoveAllSignalMarkers(Sigs[TERMITE],'H');
				}
				#endregion
				#region -- Draw current trade markers if necessary --
				last_trade_signal_bar = CalculateMostRecentSignalABar(pSignalType);
				if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF){
					RemoveSpecificSignalMarkersOnABar(pSignalType, last_trade_signal_bar);
				} else if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON && last_trade_signal_bar>0){
					if(pSignalType == ARC_VMDSystem_SystemTypes.Termite){
						DrawHistoricalSignal(Sigs[TERMITE], last_trade_signal_bar-1);
//						UpdateEntry(Sigs[TERMITE], last_trade_signal_bar, true);
						#region -- Draw all trade plan rays on rightmost signal --
						double EP = double.MinValue;
						int SignalABar = -1;
						if(this.pTradePlanVisible)
							DrawTradePlanLines(ref EP, ref SignalABar);
						#endregion
					}
				}
				#endregion
			}else if(Signal == ARC_VMDSystem_SystemTypes.BothDivergences){
				#region -- Draw historical markers if necessary --
				if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
					if(LastSignalType == ARC_VMDSystem_SystemTypes.Termite) RemoveAllSignalMarkers(Sigs[TERMITE],'H');
					DrawHistoricalSignal(Sigs[R_DIV], 0);
					DrawHistoricalSignal(Sigs[H_DIV], 0);
				}else{
					RemoveAllSignalMarkers(Sigs[R_DIV],'H');
					RemoveAllSignalMarkers(Sigs[H_DIV],'H');
				}
				#endregion
				#region -- Draw current trade markers if necessary --
				last_trade_signal_bar = CalculateMostRecentSignalABar(pSignalType);
				if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF){
					RemoveSpecificSignalMarkersOnABar(pSignalType, last_trade_signal_bar);
				} else if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON && last_trade_signal_bar>0){
					DrawHistoricalSignal(Sigs[R_DIV], last_trade_signal_bar-1);
					DrawHistoricalSignal(Sigs[H_DIV], last_trade_signal_bar-1);
					#region -- Draw all trade plan rays on rightmost signal --
					double EP = double.MinValue;
					int SignalABar = -1;
					if(this.pTradePlanVisible)
						DrawTradePlanLines(ref EP, ref SignalABar);
					#endregion
				}
				#endregion
			}else if(Signal == ARC_VMDSystem_SystemTypes.RegularDiv){
				#region -- Draw historical markers if necessary --
				if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
					if(LastSignalType == ARC_VMDSystem_SystemTypes.Termite)              RemoveAllSignalMarkers(Sigs[TERMITE],'H');
					else if(LastSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv)       RemoveAllSignalMarkers(Sigs[H_DIV],'H');
					else if(LastSignalType == ARC_VMDSystem_SystemTypes.BothDivergences) RemoveAllSignalMarkers(Sigs[H_DIV],'H');
//					RemoveAllSignalMarkers(Sigs[R_DIV], 'H');
					DrawHistoricalSignal(Sigs[R_DIV], 0);
				}else{
					RemoveAllSignalMarkers(Sigs[R_DIV],'H');
				}
				#endregion
				#region -- Draw current trade markers if necessary --
				last_trade_signal_bar = CalculateMostRecentSignalABar(pSignalType);
				if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF){
					RemoveSpecificSignalMarkersOnABar(pSignalType, last_trade_signal_bar);
				} else if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON && last_trade_signal_bar>0){
					DrawHistoricalSignal(Sigs[R_DIV], last_trade_signal_bar-1);
					#region -- Draw all trade plan rays on rightmost signal --
					double EP = double.MinValue;
					int SignalABar = -1;
					if(this.pTradePlanVisible)
						DrawTradePlanLines(ref EP, ref SignalABar);
					#endregion
				}
				#endregion
			}else if(Signal == ARC_VMDSystem_SystemTypes.HiddenDiv){
				#region -- Draw historical markers if necessary --
				if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
					if(this.LastSignalType == ARC_VMDSystem_SystemTypes.Termite)              RemoveAllSignalMarkers(Sigs[TERMITE],'H');
					else if(this.LastSignalType == ARC_VMDSystem_SystemTypes.RegularDiv)      RemoveAllSignalMarkers(Sigs[R_DIV],'H');
					else if(this.LastSignalType == ARC_VMDSystem_SystemTypes.BothDivergences) RemoveAllSignalMarkers(Sigs[R_DIV],'H');
					RemoveAllSignalMarkers(Sigs[H_DIV],'H');
					DrawHistoricalSignal(Sigs[H_DIV], 0);
				}else{
					RemoveAllSignalMarkers(Sigs[H_DIV],'H');
				}
				#endregion
				#region -- Draw current trade markers if necessary --
				last_trade_signal_bar = CalculateMostRecentSignalABar(pSignalType);
				if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.OFF){
					RemoveSpecificSignalMarkersOnABar(pSignalType, last_trade_signal_bar);
				} else if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON && last_trade_signal_bar>0){
					DrawHistoricalSignal(Sigs[H_DIV], last_trade_signal_bar-1);
					#region -- Draw all trade plan rays on rightmost signal --
					double EP = double.MinValue;
					int SignalABar = -1;
					if(this.pTradePlanVisible)
						DrawTradePlanLines(ref EP, ref SignalABar);
					#endregion
				}
				#endregion
			}
			if(UpdateUI){
				if(Signal == ARC_VMDSystem_SystemTypes.None)
					HideShow_SignalMenuItems('H');
				else
					HideShow_SignalMenuItems('S');
			}
			#endregion
		}
//================================================================================================
		private bool IsValidRBar(int rbar){
			if(rbar>=0 && rbar<CurrentBars[0]) return true;
			return false;
		}
//================================================================================================
		private void DeleteAllDrawObjectsStartingWith(string txt){
			foreach (dynamic obj in DrawObjects.ToList())
			{
				//Print(obj.ToString());
				if (obj.Tag.StartsWith(txt))
					RemoveDrawObject(obj.Tag);
			}
		}
//================================================================================================
		private void DeleteAllDrawObjectsEndingWith(string txt){
			foreach (dynamic obj in DrawObjects.ToList())
			{
				if (obj.Tag.EndsWith(txt))
					RemoveDrawObject(obj.Tag);
			}
		}
//================================================================================================
		#region ----- RemoveAllSignalMarkers -----
		private void RemoveSpecificSignalMarkersOnABar(ARC_VMDSystem_SystemTypes SignalType, int abar){
			if(SignalType == ARC_VMDSystem_SystemTypes.Termite){
				RemoveDrawObject(string.Format("EP {0}-{1}", abar, Sigs[TERMITE].Name));
				RemoveDrawObject(string.Format("SL {0}-{1}", abar, Sigs[TERMITE].Name));
				RemoveDrawObject(string.Format("T1 {0}-{1}", abar, Sigs[TERMITE].Name));
				RemoveDrawObject(string.Format("T2 {0}-{1}", abar, Sigs[TERMITE].Name));
			}
			if(SignalType == ARC_VMDSystem_SystemTypes.BothDivergences || SignalType == ARC_VMDSystem_SystemTypes.HiddenDiv){
				RemoveDrawObject(string.Format("EP {0}-{1}", abar, Sigs[H_DIV].Name));
				RemoveDrawObject(string.Format("SL {0}-{1}", abar, Sigs[H_DIV].Name));
				RemoveDrawObject(string.Format("T1 {0}-{1}", abar, Sigs[H_DIV].Name));
				RemoveDrawObject(string.Format("T2 {0}-{1}", abar, Sigs[H_DIV].Name));
			}
			if(SignalType == ARC_VMDSystem_SystemTypes.BothDivergences || SignalType == ARC_VMDSystem_SystemTypes.RegularDiv){
				RemoveDrawObject(string.Format("EP {0}-{1}", abar, Sigs[R_DIV].Name));
				RemoveDrawObject(string.Format("SL {0}-{1}", abar, Sigs[R_DIV].Name));
				RemoveDrawObject(string.Format("T1 {0}-{1}", abar, Sigs[R_DIV].Name));
				RemoveDrawObject(string.Format("T2 {0}-{1}", abar, Sigs[R_DIV].Name));
			}
		}
		//================================================================================================
		private void RemoveAllSignalMarkers(SignalsManager SM, char TypeToRemove){
			//TypeToRemove == 'A' that means ALL (both current marker and historical markers)
			//TypeToRemove == 'H' that means HISTORICAL markers
			//TypeToRemove == 'C' that means CURRENT markers
			if(TypeToRemove=='C') {
				DeleteAllDrawObjectsEndingWith(string.Format("{0}-{1}",last_trade_signal_bar, SM.Name));
				return;
			}
			else if(TypeToRemove=='A') {
				DeleteAllDrawObjectsEndingWith(string.Format("-{0}", SM.Name));
				return;
			}
			else if(TypeToRemove=='H') {
				var tagToDel = string.Format("-{0}",SM.Name);
				var currSigABar = last_trade_signal_bar.ToString();
				foreach (dynamic obj in DrawObjects.ToList())
				{
					if (obj.Tag.EndsWith(tagToDel) && !obj.Tag.Contains(currSigABar)){
						RemoveDrawObject(obj.Tag);
					}
				}
			}
		}
		//================================================================================================
		private void RemoveAllSignalMarkers(SignalsManager SM){
			DeleteAllDrawObjectsEndingWith(string.Format("-{0}",SM.Name));
			return;
//			foreach(var tag in SM.BuySignals.Keys)  {
//				RemoveDrawObject(string.Format("EP {0}-{1}", tag, SM.Name));
//				RemoveDrawObject(string.Format("SL {0}-{1}", tag, SM.Name));
//				RemoveDrawObject(string.Format("T1 {0}-{1}", tag, SM.Name));
//				RemoveDrawObject(string.Format("T2 {0}-{1}", tag, SM.Name));
////				RemoveDrawObject(string.Format("EP {0}-{1}",  tag, SM.Name, 'C'));
////				RemoveDrawObject(string.Format("SL {0}-{1}", tag, SM.Name, 'C'));
////				RemoveDrawObject(string.Format("T1 {0}-{1}", tag, SM.Name, 'C'));
////				RemoveDrawObject(string.Format("T2 {0}-{1}", tag, SM.Name, 'C'));
//			}
//			foreach(var tag in SM.SellSignals.Keys) {
//				RemoveDrawObject(string.Format("EP {0}-{1}", tag, SM.Name));
//				RemoveDrawObject(string.Format("SL {0}-{1}", tag, SM.Name));
//				RemoveDrawObject(string.Format("T1 {0}-{1}", tag, SM.Name));
//				RemoveDrawObject(string.Format("T2 {0}-{1}", tag, SM.Name));
////				RemoveDrawObject(string.Format("EP {0}-{1}",  tag, SM.Name, 'C'));
////				RemoveDrawObject(string.Format("SL {0}-{1}", tag, SM.Name, 'C'));
////				RemoveDrawObject(string.Format("T1 {0}-{1}", tag, SM.Name, 'C'));
////				RemoveDrawObject(string.Format("T2 {0}-{1}", tag, SM.Name, 'C'));
//			}
		}
		//================================================================================================
		private void RemoveAllSignalMarkers(ARC_VMDSystem_SystemTypes SigType, int LastSignalABar){
			if(SigType == ARC_VMDSystem_SystemTypes.Termite){
				if(Sigs[TERMITE].BuySignals.ContainsKey(LastSignalABar) || Sigs[TERMITE].SellSignals.ContainsKey(LastSignalABar)){
					RemoveDrawObject(string.Format("EP {0}-{1}", LastSignalABar, Sigs[TERMITE].Name));
					RemoveDrawObject(string.Format("SL {0}-{1}", LastSignalABar, Sigs[TERMITE].Name));
					RemoveDrawObject(string.Format("T1 {0}-{1}", LastSignalABar, Sigs[TERMITE].Name));
					RemoveDrawObject(string.Format("T2 {0}-{1}", LastSignalABar, Sigs[TERMITE].Name));
//					RemoveDrawObject(string.Format("EP {0}-{1}", LastSignalABar, Sigs[TERMITE].Name, 'C'));
//					RemoveDrawObject(string.Format("SL {0}-{1}", LastSignalABar, Sigs[TERMITE].Name, 'C'));
//					RemoveDrawObject(string.Format("T1 {0}-{1}", LastSignalABar, Sigs[TERMITE].Name, 'C'));
//					RemoveDrawObject(string.Format("T2 {0}-{1}", LastSignalABar, Sigs[TERMITE].Name, 'C'));
				}
			}
			if(SigType == ARC_VMDSystem_SystemTypes.RegularDiv || SigType == ARC_VMDSystem_SystemTypes.BothDivergences){
				if(Sigs[R_DIV].BuySignals.ContainsKey(LastSignalABar) || Sigs[R_DIV].SellSignals.ContainsKey(LastSignalABar)){
					RemoveDrawObject(string.Format("EP {0}-{1}", LastSignalABar, Sigs[R_DIV].Name));
					RemoveDrawObject(string.Format("SL {0}-{1}", LastSignalABar, Sigs[R_DIV].Name));
					RemoveDrawObject(string.Format("T1 {0}-{1}", LastSignalABar, Sigs[R_DIV].Name));
					RemoveDrawObject(string.Format("T2 {0}-{1}", LastSignalABar, Sigs[R_DIV].Name));
//					RemoveDrawObject(string.Format("EP {0}-{1}", LastSignalABar, Sigs[R_DIV].Name, 'C'));
//					RemoveDrawObject(string.Format("SL {0}-{1}", LastSignalABar, Sigs[R_DIV].Name, 'C'));
//					RemoveDrawObject(string.Format("T1 {0}-{1}", LastSignalABar, Sigs[R_DIV].Name, 'C'));
//					RemoveDrawObject(string.Format("T2 {0}-{1}", LastSignalABar, Sigs[R_DIV].Name, 'C'));
				}
			}
			if(SigType == ARC_VMDSystem_SystemTypes.HiddenDiv || SigType == ARC_VMDSystem_SystemTypes.BothDivergences){
				if(Sigs[H_DIV].BuySignals.ContainsKey(LastSignalABar) || Sigs[H_DIV].SellSignals.ContainsKey(LastSignalABar)){
					RemoveDrawObject(string.Format("EP {0}-{1}", LastSignalABar, Sigs[H_DIV].Name));
					RemoveDrawObject(string.Format("SL {0}-{1}", LastSignalABar, Sigs[H_DIV].Name));
					RemoveDrawObject(string.Format("T1 {0}-{1}", LastSignalABar, Sigs[H_DIV].Name));
					RemoveDrawObject(string.Format("T2 {0}-{1}", LastSignalABar, Sigs[H_DIV].Name));
//					RemoveDrawObject(string.Format("EP {0}-{1}", LastSignalABar, Sigs[H_DIV].Name, 'C'));
//					RemoveDrawObject(string.Format("SL {0}-{1}", LastSignalABar, Sigs[H_DIV].Name, 'C'));
//					RemoveDrawObject(string.Format("T1 {0}-{1}", LastSignalABar, Sigs[H_DIV].Name, 'C'));
//					RemoveDrawObject(string.Format("T2 {0}-{1}", LastSignalABar, Sigs[H_DIV].Name, 'C'));
				}
			}
		}
		#endregion
//================================================================================================================================================
		private int CalculateMostRecentSignalABar(ARC_VMDSystem_SystemTypes sigtype){
			#region -- CalculateMostRecentSignalABar --
			if(sigtype==ARC_VMDSystem_SystemTypes.BothDivergences){
				return Math.Max(Sigs[H_DIV].RightmostVisibleSignal, Sigs[R_DIV].RightmostVisibleSignal);
			}else if(sigtype == ARC_VMDSystem_SystemTypes.Termite)
				return Sigs[TERMITE].RightmostVisibleSignal;
			else if(sigtype == ARC_VMDSystem_SystemTypes.HiddenDiv)
				return Sigs[H_DIV].RightmostVisibleSignal;
			else if(sigtype == ARC_VMDSystem_SystemTypes.RegularDiv)
				return Sigs[R_DIV].RightmostVisibleSignal;
			return -1;
			#endregion
		}
//================================================================================================================================================
		private void DrawHistoricalSignal(SignalsManager SM, int FirstABar){
			#region -- DrawHistoricalSignal --
			int rbar = 0;
			int yPixelOffset = 0;
			foreach(var kvp in SM.BuySignals) {
				rbar = CurrentBar-kvp.Key + pMarkerOffset;
				if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON && kvp.Key == last_trade_signal_bar){
					if(SM.DrawEntryArrow) TriggerCustomEvent(o1 =>{	Draw.ArrowUp      (this, string.Format("EP {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.EntryPrice, pBuyBrush); },0,null);
					if(this.pSLVisible) TriggerCustomEvent(o1 =>{	Draw.Square       (this, string.Format("SL {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.SLPrice, pSLBrush); },0,null);
					if(this.pT1Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleDown (this, string.Format("T1 {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.T1Price, pT1Brush); },0,null);
					if(this.pT2Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleDown (this, string.Format("T2 {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.T2Price, pT2Brush); },0,null);
					continue;
				}
				if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
					if(SM.DrawEntryArrow) TriggerCustomEvent(o1 =>{	Draw.ArrowUp      (this, string.Format("EP {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.EntryPrice, pBuyBrush); },0,null);
					if(this.pSLVisible) TriggerCustomEvent(o1 =>{	Draw.Square       (this, string.Format("SL {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.SLPrice, pSLBrush); },0,null);
					if(this.pT1Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleDown (this, string.Format("T1 {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.T1Price, pT1Brush); },0,null);
					if(this.pT2Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleDown (this, string.Format("T2 {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.T2Price, pT2Brush); },0,null);
				}
			}
			foreach(var kvp in SM.SellSignals) {
				rbar = CurrentBar-kvp.Key + pMarkerOffset;
				if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON && kvp.Key == last_trade_signal_bar){
					if(SM.DrawEntryArrow) TriggerCustomEvent(o1 =>{	Draw.ArrowDown  (this, string.Format("EP {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.EntryPrice, pSellBrush); },0,null);
					if(this.pSLVisible) TriggerCustomEvent(o1 =>{	Draw.Square     (this, string.Format("SL {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.SLPrice, pSLBrush); },0,null);
					if(this.pT1Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleUp (this, string.Format("T1 {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.T1Price, pT1Brush); },0,null);
					if(this.pT2Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleUp (this, string.Format("T2 {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.T2Price, pT2Brush); },0,null);
					continue;
				}
				if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
					if(SM.DrawEntryArrow) TriggerCustomEvent(o1 =>{	Draw.ArrowDown  (this, string.Format("EP {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.EntryPrice, pSellBrush); },0,null);
					if(this.pSLVisible) TriggerCustomEvent(o1 =>{	Draw.Square     (this, string.Format("SL {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.SLPrice, pSLBrush); },0,null);
					if(this.pT1Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleUp (this, string.Format("T1 {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.T1Price, pT1Brush); },0,null);
					if(this.pT2Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleUp (this, string.Format("T2 {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.T2Price, pT2Brush); },0,null);
				}
//				if(pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON && kvp.Key == last_trade_signal_bar) continue;
//				kvp.Value.IsVisible = kvp.Key > FirstABar;
//				if(kvp.Value.IsVisible){
//					rbar = CurrentBar-kvp.Key + pMarkerOffset;
//					if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
//						if(SM.DrawEntryArrow) TriggerCustomEvent(o1 =>{	Draw.ArrowDown  (this, string.Format("EP {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.EntryPrice, pSellBrush);},0,null);
//						if(this.pSLVisible) TriggerCustomEvent(o1 =>{	Draw.Square     (this, string.Format("SL {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.SLPrice, pSLBrush);	},0,null);
//						if(this.pT1Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleUp (this, string.Format("T1 {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.T1Price, pT1Brush); },0,null);
//						if(this.pT2Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleUp (this, string.Format("T2 {0}-{1}", kvp.Key, SM.Name), false, rbar, kvp.Value.T2Price, pT2Brush); },0,null);
//					}
//				}
			}
			#endregion
		}
//================================================================================================================================================
		private void AddOrUpdateEntry(SignalsManager SM, string Type, int SignalABar, bool DrawNow){
			#region -- AddOrUpdateEntry --
			double SLPts = pSLTicks *TickSize;
			double T1Pts = pT1Ticks *TickSize;
			double T2Pts = pT2Ticks *TickSize;
			int yPixelOffset = 0;
			int rbarLoc = CurrentBar - SignalABar + pMarkerOffset;
			var mark_type = 'H';
line=2796;
			if(Type.StartsWith("B")){
//if(iz) Print(string.Format("Add/Update:  CB:{0}  rbar:{1}  SignalABar:{2}", Time.GetValueAt(CurrentBar).ToShortTimeString(), Time[rbarLoc].ToShortTimeString(), Time.GetValueAt(SignalABar).ToShortTimeString()));
				if(!SM.BuySignals.ContainsKey(SignalABar))
					SM.BuySignals[SignalABar] = new SignalData(SignalsManager.BUY, Open.GetValueAt(SignalABar), SLPts, T1Pts, T2Pts, false);
				var c1 = SignalABar==Bars.Count-1 && pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON;
				var c2 = SignalABar<Bars.Count-1 && pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON;
				if(DrawNow && (c1 || c2)){
line=2804;
					SystemSignal[0] = BUY_SYSTEMSIGNAL;
					SM.BuySignals[SignalABar].IsVisible = true;
					if(SM.DrawEntryArrow) TriggerCustomEvent(o1 =>{	Draw.ArrowUp      (this, string.Format("EP {0}-{1}",SignalABar, SM.Name, mark_type), false, rbarLoc, SM.BuySignals[SignalABar].EntryPrice, pBuyBrush); },0,null);
					if(this.pSLVisible) TriggerCustomEvent(o1 =>{	Draw.Square       (this, string.Format("SL {0}-{1}",SignalABar, SM.Name, mark_type), false, rbarLoc, SM.BuySignals[SignalABar].SLPrice, pSLBrush); },0,null);
					if(this.pT1Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleDown (this, string.Format("T1 {0}-{1}",SignalABar, SM.Name, mark_type), false, rbarLoc, SM.BuySignals[SignalABar].T1Price, pT1Brush); },0,null);
					if(this.pT2Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleDown (this, string.Format("T2 {0}-{1}",SignalABar, SM.Name, mark_type), false, rbarLoc, SM.BuySignals[SignalABar].T2Price, pT2Brush); },0,null);
				}
				else SM.BuySignals[SignalABar].IsVisible = false;
			}
			else if(Type.StartsWith("S")){
line=2815;
				if(!SM.SellSignals.ContainsKey(SignalABar))
					SM.SellSignals[SignalABar] = new SignalData(SignalsManager.SELL, Open.GetValueAt(SignalABar), SLPts, T1Pts, T2Pts, false);
				var c1 = SignalABar==Bars.Count-1 && pCurrent_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON;
				var c2 = SignalABar<Bars.Count-1 && pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON;
				if(DrawNow && (c1 || c2)){
line=2821;
					SystemSignal[0] = SELL_SYSTEMSIGNAL;
					SM.SellSignals[SignalABar].IsVisible = true;
					if(SM.DrawEntryArrow) TriggerCustomEvent(o1 =>{	Draw.ArrowDown  (this, string.Format("EP {0}-{1}",SignalABar, SM.Name, mark_type), false, rbarLoc, SM.SellSignals[SignalABar].EntryPrice, pSellBrush); },0,null);
					if(this.pSLVisible) TriggerCustomEvent(o1 =>{	Draw.Square     (this, string.Format("SL {0}-{1}",SignalABar, SM.Name, mark_type), false, rbarLoc, SM.SellSignals[SignalABar].SLPrice, pSLBrush);     },0,null);
					if(this.pT1Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleUp (this, string.Format("T1 {0}-{1}",SignalABar, SM.Name, mark_type), false, rbarLoc, SM.SellSignals[SignalABar].T1Price, pT1Brush); },0,null);
					if(this.pT2Visible) TriggerCustomEvent(o1 =>{	Draw.TriangleUp (this, string.Format("T2 {0}-{1}",SignalABar, SM.Name, mark_type), false, rbarLoc, SM.SellSignals[SignalABar].T2Price, pT2Brush); },0,null);
				}
				else SM.SellSignals[SignalABar].IsVisible = false;
			}
line=2831;
			#endregion
		}
//================================================================================================================================================
		private void AddOrUpdateSL(SignalsManager SM, double SLPts, bool DrawNow){
			#region -- AddOrUpdateSL --
			string tag = string.Empty;
			foreach(var key in SM.BuySignals.Keys){
				SM.BuySignals[key].SLPrice = SM.BuySignals[key].EntryPrice - SLPts;
				if(DrawNow /*&& SM.BuySignals[key].IsVisible*/){
					if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
						tag = string.Format("SL {0}-{1}", key, SM.Name);
						RemoveDrawObject(tag);
						TriggerCustomEvent(o1 =>{	Draw.Square(this, tag, false, CurrentBar-key+pMarkerOffset, SM.BuySignals[key].SLPrice, pSLBrush); },0,null);
					}
				}
			}
			foreach(var key in SM.SellSignals.Keys){
				SM.SellSignals[key].SLPrice = SM.SellSignals[key].EntryPrice + SLPts;
				if(DrawNow /*&& SM.SellSignals[key].IsVisible*/){
					if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON){
						tag = string.Format("SL {0}-{1}", key, SM.Name);
						RemoveDrawObject(tag);
						TriggerCustomEvent(o1 =>{	Draw.Square(this, tag, false, CurrentBar-key+pMarkerOffset, SM.SellSignals[key].SLPrice, pSLBrush); },0,null);
					}
				}
			}
			#endregion
		}
//================================================================================================================================================
		private void AddOrUpdateTarget(SignalsManager SM, int TargetNumber, double TPts, bool DrawNow){
			#region -- AddOrUpdateTarget --
			foreach(var key in SM.BuySignals.Keys){
				if(TargetNumber==1)	SM.BuySignals[key].T1Price = SM.BuySignals[key].EntryPrice + TPts;
				else				SM.BuySignals[key].T2Price = SM.BuySignals[key].EntryPrice + TPts;

				if(DrawNow /*&& SM.BuySignals[key].IsVisible*/){
					if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON)
						TriggerCustomEvent(o1 =>{	Draw.TriangleDown(this, string.Format("T{0} {1}-{2}", TargetNumber, key, SM.Name), false, CurrentBar-key+pMarkerOffset, (TargetNumber==1 ? SM.BuySignals[key].T1Price:SM.BuySignals[key].T2Price), (TargetNumber==1 ? pT1Brush:pT2Brush)); },0,null);
				}
			}
			foreach(var key in SM.SellSignals.Keys){
				if(TargetNumber==1)	SM.SellSignals[key].T1Price = SM.SellSignals[key].EntryPrice - TPts;
				else				SM.SellSignals[key].T2Price = SM.SellSignals[key].EntryPrice - TPts;

				if(DrawNow /*&& SM.BuySignals[key].IsVisible*/){
					if(pHistorical_TP_Markers == ARC_VMDSystem_SignalVisualTypes.ON)
						TriggerCustomEvent(o1 =>{	Draw.TriangleUp(this, string.Format("T{0} {1}-{2}", TargetNumber, key, SM.Name), false, CurrentBar-key+pMarkerOffset, (TargetNumber==1 ? SM.SellSignals[key].T1Price:SM.SellSignals[key].T2Price), (TargetNumber==1 ? pT1Brush:pT2Brush)); },0,null);
				}
			}
			#endregion
		}
//================================================================================================================================================
		private int GetTradePlan(SignalsManager SM, int LastVisibleABar, ref double EP, ref double SL, ref double T1, ref double T2){
			//gets the trade plan details for the most recent trade, for this SM, that is prior to the rightmost bar visible on the chart
line=2886;
			#region -- GetTradePlan at rightmost visible bar --
			int lastBuyABar = 0;
			int lastSellABar = 0;
line=2890;
			int max = int.MinValue;
			if(SM.BuySignals.Count>0){
				foreach(int k in SM.BuySignals.Keys) if(k <= last_visible_bar){max = Math.Max(max,k);}
				if(max>int.MinValue){
					lastBuyABar = max;
				}
			}
line=2898;
			max = int.MinValue;
			if(SM.SellSignals.Count>0){
				foreach(int k in SM.SellSignals.Keys) if(k <= last_visible_bar){max = Math.Max(max,k);}
				if(max>int.MinValue){
					lastSellABar = max;
				}
			}
			if(lastBuyABar > lastSellABar){
				EP = SM.BuySignals[lastBuyABar].EntryPrice;
				if(this.pSLVisible) SL = SM.BuySignals[lastBuyABar].SLPrice;
				if(this.pT1Visible) T1 = SM.BuySignals[lastBuyABar].T1Price;
				if(this.pT2Visible) T2 = SM.BuySignals[lastBuyABar].T2Price;
line=2911;
				return lastBuyABar;
			}else if(lastBuyABar < lastSellABar){
				EP = SM.SellSignals[lastSellABar].EntryPrice;
				if(this.pSLVisible) SL = SM.SellSignals[lastSellABar].SLPrice;
				if(this.pT1Visible) T1 = SM.SellSignals[lastSellABar].T1Price;
				if(this.pT2Visible) T2 = SM.SellSignals[lastSellABar].T2Price;
line=2918;
				return lastSellABar;
			}
line=2921;
			#endregion
			return -1;
		}
//================================================================================================================================================
		private void DrawTradePlanLines(ref double EP, ref int SignalABar, ARC_VMDSystem_SystemTypes SignalType){
			#region -- DrawTradePlanLines --
			if(SignalType == ARC_VMDSystem_SystemTypes.Termite){
				DrawTradePlanLines(ref EP, ref SignalABar);
			}else if(SignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
				DrawTradePlanLines(ref EP, ref SignalABar);
				DrawTradePlanLines(ref EP, ref SignalABar);
			}else if(SignalType == ARC_VMDSystem_SystemTypes.RegularDiv){
				DrawTradePlanLines(ref EP, ref SignalABar);
			}else if(SignalType == ARC_VMDSystem_SystemTypes.HiddenDiv){
				DrawTradePlanLines(ref EP, ref SignalABar);
			}
			#endregion
		}
		private void DrawTradePlanLines(ref double EP, ref int SignalABar){//, int last_visible_bar){
			#region -- DrawTradePlanLines --
			DrawOnPricePanel = true;
			double SL = double.MinValue;
			double T1 = double.MinValue;
			double T2 = double.MinValue;
			if(pSignalType == ARC_VMDSystem_SystemTypes.Termite){
				SignalABar = GetTradePlan(Sigs[TERMITE], last_visible_bar, ref EP, ref SL, ref T1, ref T2);
			}else if(pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences){
				double Hep=0;
				double Hsl=0;
				double Ht1=0;
				double Ht2=0;
				SignalABar = GetTradePlan(Sigs[R_DIV], last_visible_bar, ref EP,  ref SL,  ref T1,  ref T2);
				int ABar1  = GetTradePlan(Sigs[H_DIV], last_visible_bar, ref Hep, ref Hsl, ref Ht1, ref Ht2);
				if(ABar1 > SignalABar){	SignalABar = ABar1; EP=Hep; SL=Hsl; T1=Ht1; T2=Ht2;	}
			}else if(pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv){
				SignalABar = GetTradePlan(Sigs[R_DIV], last_visible_bar, ref EP, ref SL, ref T1, ref T2);
			}else if(pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv){
				SignalABar = GetTradePlan(Sigs[H_DIV], last_visible_bar, ref EP, ref SL, ref T1, ref T2);
			}
//			RemoveDrawObject("cEP");
//			RemoveDrawObject("cSL");
//			RemoveDrawObject("cT1");
//			RemoveDrawObject("cT2");
//			RemoveDrawObject("E-ray");
//			RemoveDrawObject("SL-ray");
//			RemoveDrawObject("T1-ray");
//			RemoveDrawObject("T2-ray");
			bool TPDrawn = false;
			if(SignalABar >= 0){
				double ep = EP;
				int rbar = CurrentBar - (last_visible_bar + 1);

				int yPixelOffset = 0;
				if(pTradePlanVisible){
					TPDrawn = true;
					TriggerCustomEvent(o1 =>{	Draw.Line(this, "E-ray",  false, rbar, ep, rbar-pTradePlan_LineLength, ep, false, pLineTemplateName_EP); },0,null);
					TriggerCustomEvent(o1 =>{	Draw.Line(this, "SL-ray", false, rbar, SL, rbar-pTradePlan_LineLength, SL, false, pLineTemplateName_SL); },0,null);
					TriggerCustomEvent(o1 =>{	Draw.Line(this, "T1-ray", false, rbar, T1, rbar-pTradePlan_LineLength, T1, false, pLineTemplateName_T1); },0,null);
					TriggerCustomEvent(o1 =>{	Draw.Line(this, "T2-ray", false, rbar, T2, rbar-pTradePlan_LineLength, T2, false, pLineTemplateName_T2); },0,null);
					if(SL<T1){//buy signal
						TriggerCustomEvent(o1 =>{	                    Draw.Text (this, "cEP",  false, "EP", rbar-pTradePlan_LineLength, ep, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100); },0,null);
						if(this.pSLVisible) TriggerCustomEvent(o1 =>{	Draw.Text (this, "cSL", false, "SL", rbar-pTradePlan_LineLength, SL, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100); },0,null);
						if(this.pT1Visible) TriggerCustomEvent(o1 =>{	Draw.Text (this, "cT1", false, "T1", rbar-pTradePlan_LineLength, T1, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100); },0,null);
						if(this.pT2Visible) TriggerCustomEvent(o1 =>{	Draw.Text (this, "cT2", false, "T2", rbar-pTradePlan_LineLength, T2, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100); },0,null);
					}else{//sell signal
						TriggerCustomEvent(o1 =>{	                    Draw.Text (this, "cEP",  false, "EP", rbar-pTradePlan_LineLength, ep, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100); },0,null);
						if(this.pSLVisible) TriggerCustomEvent(o1 =>{	Draw.Text (this, "cSL", false, "SL", rbar-pTradePlan_LineLength, SL, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100); },0,null);
						if(this.pT1Visible) TriggerCustomEvent(o1 =>{	Draw.Text (this, "cT1", false, "T1", rbar-pTradePlan_LineLength, T1, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100); },0,null);
						if(this.pT2Visible) TriggerCustomEvent(o1 =>{	Draw.Text (this, "cT2", false, "T2", rbar-pTradePlan_LineLength, T2, yPixelOffset, pFlagTextBrush, pTextFont, System.Windows.TextAlignment.Left, null, pFlagBkgBrush, 100); },0,null);
					}
				}
			}
			if(!TPDrawn){
				RemoveDrawObject("cEP");
				RemoveDrawObject("cSL");
				RemoveDrawObject("cT1");
				RemoveDrawObject("cT2");
				RemoveDrawObject("E-ray");
				RemoveDrawObject("SL-ray");
				RemoveDrawObject("T1-ray");
				RemoveDrawObject("T2-ray");
			}
			#endregion
		}
//===================================================================================================================
//		private bool LevelCrossed(int SystemID, char Direction, double HL, double O0, double C0, bool IsUpTrend){
//			#region -- LevelCrossed --
//			bool result = false;
//			bool UpClose = C0 > O0;
//			if(Direction=='B' && UpClose){
//				foreach(var Lvl in Sigs[SystemID].SRLevels) if(Lvl>=HL && Lvl < C0) return true;
//			}else if(Direction=='S' && !UpClose){
//				foreach(var Lvl in Sigs[SystemID].SRLevels) if(Lvl<=HL && Lvl > C0) return true;
//			}
//			return result;
//			#endregion
//		}
		private bool LevelCrossed(int SystemID, char Direction, double HL, double O0, double H0, double L0, double C0, bool IsUpTrend){
			#region -- LevelCrossed --
			bool result = false;
			bool UpClose = C0 > O0;
			if(Direction=='B' && UpClose){
				foreach(var Lvl in Sigs[SystemID].ResLevels) if(Lvl >= HL && L0<=Lvl && C0 > Lvl){
//if(iz)Print("**********************     "+Lvl+"Level crossed upward, Close: "+C0.ToString()+"  L: "+HL.ToString());
					return true;
				}
			}else if(Direction=='S' && !UpClose){
				foreach(var Lvl in Sigs[SystemID].SuppLevels) if(Lvl <= HL && H0>=Lvl && C0 < Lvl) return true;
			}
			return result;
			#endregion
		}
		private void FindAndDisqualifySRLevels(int SystemID, double H1, double L1, double H0, double L0, double C0){
			#region FindAndDisqualifySRLevels
			var levels2 = new List<double>();
			foreach(var lvl in Sigs[SystemID].SuppLevels)	{
				if(pStructureDisq == ARC_VMDSystem_StructureDisqualifierType.ClosePrice){
					if(lvl <= H1 && C0 < lvl) levels2.Add(lvl);
				}else{
					if(lvl <= H1 && L0 < lvl) levels2.Add(lvl);
				}
			}
			if(levels2 != null && levels2.Count>0){
				foreach(var lvl in levels2){
//if(iz)Print("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^   deleting "+lvl);
					Sigs[SystemID].SuppLevels.Remove(lvl);
//TriggerCustomEvent(o1 =>{Draw.Dot(this,CurrentBar.ToString(),false,0,lvl,Brushes.Blue);},0,null);
				}
			}
			levels2.Clear();
			foreach(var lvl in Sigs[SystemID].ResLevels)	{
				if(pStructureDisq == ARC_VMDSystem_StructureDisqualifierType.ClosePrice){
					if(lvl >= L1 && C0 > lvl) levels2.Add(lvl);
				}else{
					if(lvl >= L1 && H0 > lvl) levels2.Add(lvl);
				}
			}
			if(levels2 != null && levels2.Count>0){
				foreach(var lvl in levels2){
//if(iz)Print("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^   deleting "+lvl);
					Sigs[SystemID].ResLevels.Remove(lvl);
//TriggerCustomEvent(o1 =>{Draw.Dot(this,CurrentBar.ToString(),false,0,lvl,Brushes.Red);},0,null);
				}
			}
			#endregion
		}
//================================================================================================================================================
		private SignalsManager[] Sigs = new SignalsManager[3];
		private int RMaB = -1; //right most abs bar...if the chart moves, then we know it's different than RMaB, and we know to refresh some params in the SignalsManagers, see the OnRender for details
		#endregion
		private int AlertBar = 0;
//===================================================================================================================
        protected override void OnStateChange()
        {
            #region State == State.SetDefaults  
            if (State == State.SetDefaults)
            {
                Description = @"Measures 2 components of momentum:  1) the velocity histogram measures minor cycles of Multiple timeframe momentum cycles and act as a leading guage of momentum before a trend has started  2)(Moving Average Convergence/Divergence) is a trend following momentum indicator that shows the relationship between two moving averages of prices.";
                Name = "ARC_VMDSystem";
                ArePlotsConfigurable = false;
                DrawOnPricePanel = false;
                AreLinesConfigurable = false;
                DrawOnPricePanel = false;
                PaintPriceMarkers = false;
                ZOrder = -1;
                MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
                ScaleJustification = ScaleJustification.Right;
                IsSuspendedWhileInactive = false;
                Calculate = Calculate.OnPriceChange;
                IsOverlay = false;
                DisplayInDataBox = true;

                #region INIT Plots / Lines 

                //rj RJ5GROUP code Algorithm
                AddPlot(new Stroke(Brushes.Red), PlotStyle.HLine, "PriceExcursionLL3");
                AddPlot(new Stroke(Brushes.Blue), PlotStyle.HLine, "PriceExcursionLL2");
                AddPlot(new Stroke(Brushes.Black), PlotStyle.HLine, "PriceExcursionLL1");
                AddPlot(new Stroke(Brushes.Black), PlotStyle.HLine, "PriceExcursionUL1");
                AddPlot(new Stroke(Brushes.Blue), PlotStyle.HLine, "PriceExcursionUL2");
                AddPlot(new Stroke(Brushes.Red), PlotStyle.HLine, "PriceExcursionUL3");
                //rj RJ5GROUP code Algorithm

                //AddLine(Brushes.Gray, 0, "Zeroline");
                AddPlot(new Stroke(Brushes.Gray), PlotStyle.Bar, "Histogram");
                AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "Lower");
                AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "Upper");
                AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "Average");
                AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "BBMACDLine");
                AddPlot(new Stroke(Brushes.Gray), PlotStyle.Dot, "BBMACDFrame");
                AddPlot(new Stroke(Brushes.Gray), PlotStyle.Dot, "BBMACD");

                AddPlot(new Stroke(Brushes.Black,0.1f), PlotStyle.Line, "PriceExcursionMAX");
                AddPlot(new Stroke(Brushes.Black, 0.1f), PlotStyle.Line, "PriceExcursionMIN");
                AddPlot(new Stroke(Brushes.Transparent, 0.1f), PlotStyle.Line, "SystemSignal");
                #endregion

                #region INIT Properties to Default Values 

                #region MACDBB Parameters
                BandPeriod = 10;
                Fast = 12;
                Slow = 26;
                StdDevNumber = 1.0;
                #endregion

                #region SwingTrend Parameters 
                SwingStrength = 3;
                MultiplierMD = 0.0;
                MultiplierDTB = 0.0;
                #endregion

                #region Divergence Options 
                ThisInputType = ARC_VMDSystem_InputType.High_Low;
                UseOscHighLow = false;
                IncludeDoubleTopsAndBottoms = true;
                UseLastSwingOnly = true;
                ResetFilter = true;
                #endregion

                #region Divergence Parameters 
                DivMaxBars = 55;
                DivMinBars = 3;
                TriggerBars = 20;
                #endregion

                #region Display Options Oscillator Panel 
                //BackgroundFloodingPanel = gztFloodPanel.None;//##MODIF## AzurITec - 18.05.2016
                ShowBiasInBox = true;
                ShowSentimentInBox = true;
                BackgroundFlooding = ARC_VMDSystem_Flooding.None;
                #endregion

                #region Display Options Swing Trend 
                SwingDotSize = 7;
                LabelFontSize = 10;
                SwingLegWidth = 2;
                ShowZigzagDots = false;
                ShowZigzagLabels = false;
                ShowZigzagLegs = false;
                SwingLegStyle = DashStyleHelper.Solid;
                #endregion

                #region Display Options Divergences 
                ShowDivOnPricePanel = true;
                ShowDivOnOscillatorPanel = true;
                ShowOscillatorDivergences = true;
                ShowHistogramDivergences = true;
                ShowOscillatorHiddenDivergences = true;
                ShowHistogramHiddenDivergences = true;
                ShowSetupDots = true;
                #endregion

                //rj RJ5GROUP code Algorithm
                #region Display Options Price Excursions 
                DisplayLevel1 = false;
                DisplayLevel2 = true;
                DisplayLevel3 = true;
                #endregion

				OptimizeSpeed = ARC_VMDSystem_OptimizeSpeedSettings.Max;
				OverprintSentimentBox = false;

                #region Plot Parameters 
                DotSize = 2;
                Plot2Width = 2;
                Plot3Width = 2;
                Plot4Width = 2;
                Dash3Style = DashStyleHelper.Dot;
                Dash4Style = DashStyleHelper.Solid;
                ZerolineWidth = 1;
                ZerolineStyle = DashStyleHelper.Solid;
                MomoWidth = 6;

                DeepBullishBackgroundColor = Brushes.DarkGreen;
                BullishBackgroundColor = Brushes.Green;
                OppositeBackgroundColor = Brushes.Gray;
                BearishBackgroundColor = Brushes.Red;
                DeepBearishBackgroundColor = Brushes.DarkRed;
                BackgroundOpacity = 30;//##DEFAULT VALUE TO CHECK##
                ChannelColor = Brushes.DodgerBlue;
                ChannelOpacity = 20;
                #endregion

                #region Plot Colors 
                DotsUpRisingColor = Brushes.Green;
                DotsDownRisingColor = Brushes.Green;
                DotsDownFallingColor = Brushes.Red;
                DotsUpFallingColor = Brushes.Red;
                DotsRimColor = Brushes.Black;
                BBAverageColor = Brushes.Transparent;
                BBUpperColor = Brushes.Black;
                BBLowerColor = Brushes.Black;
                HistUpColor = Brushes.LimeGreen;
                HistDownColor = Brushes.Maroon;
                ZerolineColor = Brushes.Black;
                ConnectorColor = Brushes.White;
                #endregion

                //rj RJ5GROUP code Algorithm
                #region Price Excursion: Plot Colors / Parameters 
                Level1Color = Brushes.WhiteSmoke;
                Level2Color = Brushes.Blue;
                Level3Color = Brushes.Red;
                PlotStyleLevels = PlotStyle.HLine;
                DashStyleHelperLevels = DashStyleHelper.Solid;
                PlotWidthLevels = 3;
                #endregion

                #region MACD Divergences: Plot Parameters 
                DivWidth1 = 3;
                OffsetMultiplier3 = 10;
                OffsetMultiplier1 = 40;
                TriangleFontSize1 = 25;
                SetupFontSize1 = 6;
                DivWidth2 = 3;
                OffsetMultiplier4 = 30;
                OffsetMultiplier2 = 65;
                TriangleFontSize2 = 25;
                SetupFontSize2 = 6;

                HiddenDivWidth1 = 3;//#HIDDENDIV - added 17.02.01 - AzurITec
                HiddenTriangleFontSize1 = 25;//#HIDDENDIV - added 17.02.01 - AzurITec
                HiddenSetupFontSize1 = 6;//#HIDDENDIV - added 17.02.01 - AzurITec
                HiddenDivWidth2 = 3;//#HIDDENDIV - added 17.02.01 - AzurITec
                HiddenTriangleFontSize2 = 25;//#HIDDENDIV - added 17.02.01 - AzurITec
                HiddenSetupFontSize2 = 6;//#HIDDENDIV - added 17.02.01 - AzurITec
                HiddenOffsetMultiplier1 = 40;//#HIDDENDIV - added 17.02.01 - AzurITec
                HiddenOffsetMultiplier2 = 90;//#HIDDENDIV - added 17.02.01 - AzurITec
                HiddenOffsetMultiplier3 = 10;//#HIDDENDIV - added 17.02.01 - AzurITec
                HiddenOffsetMultiplier4 = 30;//#HIDDENDIV - added 17.02.01 - AzurITec
                #endregion

                #region MACD Divergences: Plot Colors 
                BearColor1 = Brushes.DarkRed;
                BullColor1 = Brushes.DarkGreen;
                ArrowDownColor1 = Brushes.DarkRed;
                ArrowUpColor1 = Brushes.DarkGreen;
                BearishSetupColor1 = Brushes.DarkRed;
                BullishSetupColor1 = Brushes.DarkGreen;

                HiddenBearColor1 = Brushes.DarkTurquoise;
                HiddenBullColor1 = Brushes.DarkBlue;
                HiddenArrowDownColor1 = Brushes.DarkTurquoise;
                HiddenArrowUpColor1 = Brushes.DarkBlue;
                HiddenBearishSetupColor1 = Brushes.DarkTurquoise;
                HiddenBullishSetupColor1 = Brushes.DarkBlue;
                #endregion

                #region Histogram Divergences: Plot Colors 
                BearColor2 = Brushes.Red;
                BullColor2 = Brushes.Lime;
                ArrowDownColor2 = Brushes.Red;
                ArrowUpColor2 = Brushes.Lime;
                BearishSetupColor2 = Brushes.Red;
                BullishSetupColor2 = Brushes.Lime;

                HiddenBearColor2 = Brushes.Cyan;
                HiddenBullColor2 = Brushes.Blue;
                HiddenArrowDownColor2 = Brushes.Cyan;
                HiddenArrowUpColor2 = Brushes.Blue;
                HiddenBearishSetupColor2 = Brushes.Cyan;
                HiddenBullishSetupColor2 = Brushes.Blue;
                #endregion

                #region Sentiment Box: Colors 
                BearishAccelerationColor = Brushes.Red;
                BearishDivergenceColor = Brushes.Red;
                BearishForegroundColor = Brushes.Black;
                BullishAccelerationColor = Brushes.Lime;
                BullishDivergenceColor = Brushes.Lime;
                BullishForegroundColor = Brushes.Black;
                TextBoxOutlineColor = Brushes.MidnightBlue;
                TextColor = Brushes.White;
                DataTableColor = Brushes.MidnightBlue;
                #endregion

                #region Sentiment Box: Parameters 
				//JQ 11.26.2017
				// Bug 12782. The set right margin is causing the shifting of the SDV bar when the PP bar and the Divergence indicator
                // are all on the same chart. This could be a NT8 issue as it appears the BarMarginRight is only applied to the
				// primary bar (PP) rather than the secondary bar SDV). For now, I will disable the setrightmargin properties
				// until I have a chance to talk to NT about this issue.
				// --start--
//                SetRightSideMargin = true;
				// --end--
                DataFontSize = 12;
				SentimentBoxLocation = ARC_VMDSystem_SentimentBoxLocations.Right;
				#endregion

                #region Sentiment Box: Text Elements 
                BullAccString = "Bullish Acc";
                BullDivCString = "Bullish Div (C)";
                BullDivPString = "Bullish Div (P)";
                BullHDivCString = "Bullish HDiv (C)";
                BullHDivPString = "Bullish HDiv (P)";
                BearAccString = "Bearish Acc";
                BearDivCString = "Bearish Div (C)";
                BearDivPString = "Bearish Div (P)";
                BearHDivCString = "Bearish HDiv (C)";
                BearHDivPString = "Bearish HDiv (P)";
                NeutralString = "Neutral";
                UpBiasString = "Up Trend";//#STRBIAS
                DwBiasString = "Down Trend";//#STRBIAS
                NeutralBiasString = "Oscillation";//#STRBIAS     
                #endregion

                #endregion

				#region -- System Signals & TradePlan variables --
				pSignalType = ARC_VMDSystem_SystemTypes.None;
				LastSignalType = pSignalType;
				pSLTicks = 10;
				pT1Ticks = 10;
				pT2Ticks = 15;
//				pRayTemplateName_EP = "Default";
//				pRayTemplateName_SL = "Default";
//				pRayTemplateName_T1 = "Default";
//				pRayTemplateName_T2 = "Default";
				pLineTemplateName_EP = "Default";
				pLineTemplateName_SL = "Default";
				pLineTemplateName_T1 = "Default";
				pLineTemplateName_T2 = "Default";
				pTradePlanVisible = true;
				pStructureDisq = ARC_VMDSystem_StructureDisqualifierType.ClosePrice;
				pHistorical_TP_Markers = ARC_VMDSystem_SignalVisualTypes.ON;
				pSLVisible = true;
				pT1Visible = true;
				pT2Visible = true;
				pBuyBrush  = Brushes.Lime;
				pSellBrush = Brushes.Magenta;
				pSLBrush = Brushes.Yellow;
				pT1Brush = Brushes.Blue;
				pT2Brush = Brushes.Cyan;
				pFlagTextBrush = Brushes.Cyan;
				pFlagBkgBrush = Brushes.Navy;
				pBuyStripeBrush = Brushes.Green;
				pBuyStripeOpacity = 60;
				pSellStripeBrush = Brushes.Maroon;
				pSellStripeOpacity = 60;
				pCurrent_TP_Markers = ARC_VMDSystem_SignalVisualTypes.ON;
				pTextFont     = new SimpleFont("Arial",12);
				pTradePlan_LineLength = 5;
				pMarkerOffset = 1;
				pShowRacingStripes = false;
				pTermiteBuySoundWAV = "SOUND OFF";
				pTermiteSellSoundWAV = "SOUND OFF";
				pHDIV_BuySoundWAV = "SOUND OFF";
				pHDIV_SellSoundWAV = "SOUND OFF";
				pRDIV_BuySoundWAV = "SOUND OFF";
				pRDIV_SellSoundWAV = "SOUND OFF";
				#endregion
				pButtonText = "VMDSys";

            }
            #endregion

            #region State == State.Configure  
            else if (State == State.Configure)
            {
                Calculate = Calculate.OnPriceChange;
#if DoLicense
				//Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				//RemoveDrawObject("lictext");
				IsDebug=false;
#endif
                #region INIT Fonts  
                labelFont     = new SimpleFont("Arial", LabelFontSize);
                swingDotFont  = new SimpleFont("Webdings", SwingDotSize) { Bold = true };
                triangleFont1 = new SimpleFont("Webdings", TriangleFontSize1);
                triangleFont2 = new SimpleFont("Webdings", TriangleFontSize2);
                setupFont1 = new SimpleFont("Webdings", SetupFontSize1);
                setupFont2 = new SimpleFont("Webdings", SetupFontSize2);
                dataFont1 = new SimpleFont("Arial", Math.Max(1, DataFontSize - 2)) { Bold = true };
                dataFont2 = new SimpleFont("Arial", DataFontSize) { Bold = true };

                //Get string size (H / W) for Sentiment BOX
                dataStringHeight = dataFont2.Size;

                maxString1 = "STRUCTURE BIAS" + 1;

                List<string> boxStrings = new List<string>() { NeutralString, BullAccString, BullDivCString, BullDivPString, BullHDivCString, BullHDivPString, BearAccString, BearDivCString, BearDivPString, BearHDivCString, BearHDivPString, UpBiasString, DwBiasString, NeutralBiasString };
				int maxlen = 0;
				foreach(var s in boxStrings) if(s.Length>maxlen) {maxString2 = s; maxlen = s.Length;}
                maxString2 = maxString2 + 1;
                #endregion

                showBox = ShowSentimentInBox || ShowBiasInBox;

                #region -- Set default to plots --
                Plots[BBMACDIDX].Width = DotSize;
                Plots[BBMACDIDX].DashStyleHelper = DashStyleHelper.Dot;
                Plots[BBMACDFrameIDX].Width = DotSize + 1;
                Plots[BBMACDFrameIDX].DashStyleHelper = DashStyleHelper.Dot;
                Plots[BBMACDLineIDX].Width = Plot2Width;
                Plots[AverageIDX].Width = Plot3Width;
                Plots[AverageIDX].DashStyleHelper = Dash3Style;
                Plots[UpperIDX].Width = Plot4Width;
                Plots[UpperIDX].DashStyleHelper = Dash4Style;
                Plots[LowerIDX].Width = Plot4Width;
                Plots[LowerIDX].DashStyleHelper = Dash4Style;
                Plots[HistogramIDX].Width = MomoWidth;
                Plots[HistogramIDX].DashStyleHelper = DashStyleHelper.Solid;

                //rj RJ5GROUP code Algorithm
                if (false)
                {
                    Plots[PriceExcursionUL3IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionUL3IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionUL3IDX].PlotStyle = PlotStyleLevels;
                    Plots[PriceExcursionUL2IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionUL2IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionUL2IDX].PlotStyle = PlotStyleLevels;
                    Plots[PriceExcursionUL1IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionUL1IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionUL1IDX].PlotStyle = PlotStyleLevels;
                    Plots[PriceExcursionLL1IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionLL1IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionLL1IDX].PlotStyle = PlotStyleLevels;
                    Plots[PriceExcursionLL2IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionLL2IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionLL2IDX].PlotStyle = PlotStyleLevels;
                    Plots[PriceExcursionLL3IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionLL3IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionLL3IDX].PlotStyle = PlotStyleLevels;
                }
                //rj RJ5GROUP code Algorithm

                //Lines[0].Width = ZerolineWidth;
                //Lines[0].DashStyleHelper = ZerolineStyle;
                //Lines[0].Brush = ZerolineColor;

                Plots[BBMACDFrameIDX].Brush = DotsRimColor;
                Plots[BBMACDLineIDX].Brush = ConnectorColor;
                Plots[AverageIDX].Brush = BBAverageColor;
                Plots[UpperIDX].Brush = BBUpperColor;
                Plots[LowerIDX].Brush = BBLowerColor;

                //rj RJ5GROUP code Algorithm
                Plots[PriceExcursionUL3IDX].Brush = Brushes.Transparent;
                Plots[PriceExcursionUL2IDX].Brush = Brushes.Transparent;
                Plots[PriceExcursionUL1IDX].Brush = Brushes.Transparent;
                Plots[PriceExcursionLL1IDX].Brush = Brushes.Transparent;
                Plots[PriceExcursionLL2IDX].Brush = Brushes.Transparent;
                Plots[PriceExcursionLL3IDX].Brush = Brushes.Transparent;
                
                Plots[PriceExcursionMAXIDX].Brush = Level3Color;
                Plots[PriceExcursionMINIDX].Brush = Level3Color;
                //rj RJ5GROUP code Algorithm
                #endregion
            }
            #endregion

            #region State == State.DataLoaded  
			else if (State==State.DataLoaded){
                #region INIT Series
                acceleration1 = new Series<int>(this);
                acceleration2 = new Series<int>(this);

				swingInput        = new Series<double>(this);
                pre_swingHighType = new Series<int>(this);
                pre_swingLowType  = new Series<int>(this);
                swingHighType = new Series<int>(this);
                swingLowType  = new Series<int>(this);
                upTrend = new Series<bool>(this);

                bbDotTrend = new Series<double>(this);
                momoSignum = new Series<double>(this);

                bearishPDivMACD = new Series<double>(this);
                bullishPDivMACD = new Series<double>(this);
                bearishPDivHistogram = new Series<double>(this);
                bullishPDivHistogram = new Series<double>(this);

                bearishCDivMACD = new Series<double>(this);
                bullishCDivMACD = new Series<double>(this);
                bearishCDivHistogram = new Series<double>(this);
                bullishCDivHistogram = new Series<double>(this);

                bearishTriggerCountMACDBB = new Series<int>(this);
                bullishTriggerCountMACDBB = new Series<int>(this);
                bearishTriggerCountHistogram = new Series<int>(this);
                bullishTriggerCountHistogram = new Series<int>(this);

                macdBBState = new Series<double>(this);
                histogramState = new Series<double>(this);

                hiddenbearishPDivMACD = new Series<double>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                hiddenbullishPDivMACD = new Series<double>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                hiddenbearishCDivMACD = new Series<double>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                hiddenbullishCDivMACD = new Series<double>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                hiddenbearishTriggerCountMACDBB = new Series<int>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                hiddenbullishTriggerCountMACDBB = new Series<int>(this);//#HIDDENDIV - added 17.02.01 - AzurITec

                hiddenbearishPDivHistogram = new Series<double>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                hiddenbullishPDivHistogram = new Series<double>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                hiddenbearishCDivHistogram = new Series<double>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                hiddenbullishCDivHistogram = new Series<double>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                hiddenbearishTriggerCountHistogram = new Series<int>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                hiddenbullishTriggerCountHistogram = new Series<int>(this);//#HIDDENDIV - added 17.02.01 - AzurITec

                bearishMACDDivProjection = new Series<double>(this);//#BLOOHOUND - added 17.02.03 - AzurITec
                bullishMACDDivProjection = new Series<double>(this);//#BLOOHOUND - added 17.02.03 - AzurITec
                bearishHistogramDivProjection = new Series<double>(this);//#BLOOHOUND - added 17.02.03 - AzurITec
                bullishHistogramDivProjection = new Series<double>(this);//#BLOOHOUND - added 17.02.03 - AzurITec
                bearishMACDHiddenDivProjection = new Series<double>(this);//#BLOOHOUND - added 17.02.03 - AzurITec
                bullishMACDHiddenDivProjection = new Series<double>(this);//#BLOOHOUND - added 17.02.03 - AzurITec
                bearishHistogramHiddenDivProjection = new Series<double>(this);//#BLOOHOUND - added 17.02.03 - AzurITec
                bullishHistogramHiddenDivProjection = new Series<double>(this);//#BLOOHOUND - added 17.02.03 - AzurITec

                bearishDivPlotSeriesMACDBB = new Series<int>(this);
                hiddenbearishDivPlotSeriesMACDBB = new Series<int>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                bullishDivPlotSeriesMACDBB = new Series<int>(this);
                hiddenbullishDivPlotSeriesMACDBB = new Series<int>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                bearishDivPlotSeriesHistogram = new Series<int>(this);
                hiddenbearishDivPlotSeriesHistogram = new Series<int>(this);//#HIDDENDIV - added 17.02.01 - AzurITec
                bullishDivPlotSeriesHistogram = new Series<int>(this);
                hiddenbullishDivPlotSeriesHistogram = new Series<int>(this);//#HIDDENDIV - added 17.02.01 - AzurITec

                structureBiasState = new Series<double>(this, MaximumBarsLookBack.Infinite);//#STRBIAS
                swingHighsState = new Series<double>(this, MaximumBarsLookBack.Infinite);//#STRBIAS
                swingLowsState = new Series<double>(this, MaximumBarsLookBack.Infinite);//#STRBIAS
                #endregion

                #region INIT external Series  
                BMACD = MACD(Input, Fast, Slow, BandPeriod);
                SDBB = StdDev(BMACD, BandPeriod);
                MACD1 = MACD(8, 20, 20);
                MACD2 = MACD(10, 20, 20);
                MACD3 = MACD(20, 60, 20);
                MACD4 = MACD(60, 240, 20);
                avgTrueRange = ATR(256);
                ExcursionSeries = SMA(ATR(256), 65);//rj RJ5GROUP code Algorithm
                #endregion
			}
            #endregion

            #region State == State.Historical  
            else if (State == State.Historical)
            {
				Sigs[TERMITE] = new SignalsManager("T");
  				Sigs[R_DIV]   = new SignalsManager("RD");
  				Sigs[H_DIV]   = new SignalsManager("HD");
				BuySoundFiles[TERMITE]  = AddSoundFolder(pTermiteBuySoundWAV);
				SellSoundFiles[TERMITE] = AddSoundFolder(pTermiteSellSoundWAV);
				BuySoundFiles[R_DIV]  = AddSoundFolder(pRDIV_BuySoundWAV);
				SellSoundFiles[R_DIV] = AddSoundFolder(pRDIV_SellSoundWAV);
				BuySoundFiles[H_DIV]  = AddSoundFolder(pHDIV_BuySoundWAV);
				SellSoundFiles[H_DIV] = AddSoundFolder(pHDIV_SellSoundWAV);

				BuyStripeBrush = pBuyStripeBrush.Clone();
				BuyStripeBrush.Opacity = this.pBuyStripeOpacity/100.0f;
				BuyStripeBrush.Freeze();
				SellStripeBrush = pSellStripeBrush.Clone();
				SellStripeBrush.Opacity = this.pSellStripeOpacity/100.0f;
				SellStripeBrush.Freeze();
				LastSignalType = pSignalType;
                uID = DateTime.Now.Ticks.ToString()+Instrument.MasterInstrument.ToString().Replace(" ",string.Empty);//prevent multiple toolbar with same name

				#region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;

                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new Grid { Visibility = Visibility.Collapsed };

                            addToolBar();

                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;
                            
                            foreach (TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion
            }
            #endregion

            #region State == State.Terminated
            else if (State == State.Terminated)
            {
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
						indytoolbar = null;
						try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
							indytoolbar = null;
							try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
							chartWindow = null;
						}));
					}
				}
            }
            #endregion
        }
//===================================================================================================================
        protected override void OnBarUpdate()
        {
line=3632;
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(State==State.Realtime && !Initialized){
				SignalType_Updater(pSignalType, false);
				Initialized=true;
			}
			if(IsFirstTickOfBar) SystemSignal[0]= 0;
try{
line=3656;
            #region --- Calculate VelocityMomo ---  
            double macdValue = BMACD[0];
            double average = BMACD.Avg[0];
            double stdDevValue = SDBB[0];

            BBMACD[0] = macdValue;
            BBMACDLine[0] = macdValue;
            BBMACDFrame[0] = macdValue;//used for drawing only
            Average[0] = average;
            Upper[0] = average + StdDevNumber * stdDevValue;
            Lower[0] = average - StdDevNumber * stdDevValue;
            Histogram[0] = MACD1.Diff[0] + MACD2.Diff[0] + MACD3.Diff[0] + MACD4.Diff[0];
            #endregion
            #region -- Color BB + Histo plots --    
            if (CurrentBar > 0)
            {
                #region -- MACD --
				bbDotTrend[0] = 0.0;
                if (IsRising(BBMACD))
                {
                    if (BBMACD[0] > Upper[0])
                    {
                        bbDotTrend[0] = 2.0;
                        PlotBrushes[BBMACDIDX][0] = DotsUpRisingColor;
                    }
                    else
                    {
                        bbDotTrend[0] = 1.0;
                        PlotBrushes[BBMACDIDX][0] = DotsDownRisingColor;
                    }
                }
                else if (IsFalling(BBMACD))
                {
                    if (BBMACD[0] < Lower[0])
                    {
                        bbDotTrend[0] = -2.0;
                        PlotBrushes[BBMACDIDX][0] = DotsDownFallingColor;
                    }
                    else
                    {
                        bbDotTrend[0] = -1.0;
                        PlotBrushes[BBMACDIDX][0] = DotsUpFallingColor;
                    }
                }
                else
                {
                    bbDotTrend[0] = bbDotTrend[1];
                    PlotBrushes[BBMACDIDX][0] = PlotBrushes[BBMACDIDX][1];
                }
                #endregion

                #region -- Histogram --
                if (Histogram[0] > 0)
                {
                    PlotBrushes[HistogramIDX][0] = HistUpColor;
                    momoSignum[0] = 1.0;
                }
                else if (Histogram[0] < 0)
                {
                    PlotBrushes[HistogramIDX][0] = HistDownColor;
                    momoSignum[0] = -1.0;
                }
                else
                {
                    PlotBrushes[HistogramIDX][0] = PlotBrushes[HistogramIDX][1];
                    momoSignum[0] = momoSignum[1];
                }
                #endregion
            }
            #endregion

line=3727;
            bearishMACDDivProjection[0] = (0.0);//#BLOOHOUND - added 17.02.03 - AzurITec
            bullishMACDDivProjection[0] = (0.0);//#BLOOHOUND - added 17.02.03 - AzurITec
            bearishHistogramDivProjection[0] = (0.0);//#BLOOHOUND - added 17.02.03 - AzurITec
            bullishHistogramDivProjection[0] = (0.0);//#BLOOHOUND - added 17.02.03 - AzurITec
            bearishMACDHiddenDivProjection[0] = (0.0);//#BLOOHOUND - added 17.02.03 - AzurITec
            bullishMACDHiddenDivProjection[0] = (0.0);//#BLOOHOUND - added 17.02.03 - AzurITec
            bearishHistogramHiddenDivProjection[0] = (0.0);//#BLOOHOUND - added 17.02.03 - AzurITec
            bullishHistogramHiddenDivProjection[0] = (0.0);//#BLOOHOUND - added 17.02.03 - AzurITec

line=3737;
            //rj RJ5GROUP code Algorithm
            #region --- Calculate ExcurionValue ---  
            //Excursion Algorithm
            double ExcursionValue = ExcursionSeries[0];

            momoSignum[0] = 0.0;

            //Plots
            PriceExcursionUL1[0] = ExcursionValue * 1;
            PriceExcursionLL1[0] = ExcursionValue * -1;
            PriceExcursionUL2[0] = ExcursionValue * 2;
            PriceExcursionLL2[0] = ExcursionValue * -2;
            PriceExcursionUL3[0] = ExcursionValue * 3;
            PriceExcursionLL3[0] = ExcursionValue * -3;
            if (CurrentBar > 0) PriceExcursionMAX.Reset(1);
            PriceExcursionMAX[0] = ExcursionValue * 3;
            if (CurrentBar > 0) PriceExcursionMIN.Reset(1);
            PriceExcursionMIN[0] = ExcursionValue * -3;

            #region -- Show/Hide Excursion levels --  
            if (IsFirstTickOfBar)
            {
                if (!DisplayLevel1)
                {
                    PlotBrushes[PriceExcursionUL1IDX][0] = Brushes.Transparent;
                    PlotBrushes[PriceExcursionLL1IDX][0] = Brushes.Transparent;
                }
                if (!DisplayLevel2)
                {
                    PlotBrushes[PriceExcursionUL2IDX][0] = Brushes.Transparent;
                    PlotBrushes[PriceExcursionLL2IDX][0] = Brushes.Transparent;
                }
                if (!DisplayLevel3)
                {
                    PlotBrushes[PriceExcursionUL3IDX][0] = Brushes.Transparent;
                    PlotBrushes[PriceExcursionLL3IDX][0] = Brushes.Transparent;
                }
            }
            #endregion
            
            #endregion

line=3781;
            if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                swingInput[0] = Input[0];
            else if (ThisInputType == ARC_VMDSystem_InputType.Close)
                swingInput[0] = Close[0];
            else if (ThisInputType == ARC_VMDSystem_InputType.Median)
                swingInput[0] = Median[0];
            else if (ThisInputType == ARC_VMDSystem_InputType.Typical)
                swingInput[0] = Typical[0];

line=3791;
            #region --- Calculate and Draw ZigZag + Intrabar Structure BIAS ---

            #region -- Init zigzag states --    
            if (CurrentBar < 2)
            {
line=3797;
                upTrend[0] = true;
                pre_swingHighType[0] = 0;
                pre_swingLowType[0] = 0;
                swingHighType[0] = 0;
                swingLowType[0] = 0;
            }
            #endregion

            #region else if (Calculate == Calculate.OnBarClose)
            else if (Calculate == Calculate.OnBarClose)
            {
line=3809;
                bool useHL = ThisInputType == ARC_VMDSystem_InputType.High_Low;

                zigzagDeviation = MultiplierMD * avgTrueRange[0];
                swingMax = MAX(useHL ? High : Input, SwingStrength)[1];
                swingMin = MIN(useHL ? Low : Input, SwingStrength)[1];

                pre_swingHighType[0] = 0;
                pre_swingLowType[0] = 0;
                swingHighType[0] = 0;
                swingLowType[0] = 0;

                updateHigh = upTrend[1] && (useHL ? High[0] : swingInput[0]) > currentHigh;
                updateLow = !upTrend[1] && (useHL ? Low[0] : swingInput[0]) < currentLow;
                addHigh = !upTrend[1] && !((useHL ? Low[0] : swingInput[0]) < currentLow) && (useHL ? High[0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                addLow = upTrend[1] && !((useHL ? High[0] : swingInput[0]) > currentHigh) && (useHL ? Low[0] : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

                upTrend[0] = upTrend[1];

line=3828;
                #region -- New High --
                if (addHigh)
                {
                    upTrend[0] = true;
                    int lookback = CurrentBar - lastLowIdx;
                    swingLowType[lookback] = pre_swingLowType[lookback];
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - lastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : swingInput[i]) > newHigh)
                        {
                            newHigh = (useHL ? High[i] : swingInput[i]);
                            j = i;
                        }
                    }
line=3845;
                    currentHigh = newHigh;
                    priorSwingHighIdx = lastHighIdx;
                    lastHighIdx = CurrentBar - j;
                }
                #endregion

                #region -- uptrend --
                else if (updateHigh)
                {
line=3855;
                    upTrend[0] = true;
                    if (ShowZigzagDots) RemoveDrawObject(string.Format("swingHighDot{0}", lastHighIdx));
                    if (ShowZigzagLabels) RemoveDrawObject(string.Format("swingHighLabel{0}", lastHighIdx));
                    if (ShowZigzagLegs) RemoveDrawObject(string.Format("swingLegUp{0}", lastHighIdx));
                    pre_swingHighType[CurrentBar - lastHighIdx] = 0;
                    currentHigh = (useHL ? High[0] : swingInput[0]);
                    lastHighIdx = CurrentBar;
                }
                #endregion

                #region -- New Low --
                else if (addLow)
                {
line=3869;
                    upTrend[0] = false;
                    int lookback = CurrentBar - lastHighIdx;
                    swingHighType[lookback] = pre_swingHighType[lookback];
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - lastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : swingInput[i]) < newLow)
                        {
                            newLow = (useHL ? Low[i] : swingInput[i]);
                            j = i;
                        }
                    }
line=3883;
                    currentLow = newLow;
                    priorSwingLowIdx = lastLowIdx;
                    lastLowIdx = CurrentBar - j;
                }
                #endregion

                #region -- dwtrend --
                else if (updateLow)
                {
line=3893;
                    upTrend[0] = false;
                    if (ShowZigzagDots) RemoveDrawObject(string.Format("swingLowDot{0}", lastLowIdx));
                    if (ShowZigzagLabels) RemoveDrawObject(string.Format("swingLowLabel{0}", lastLowIdx));
                    if (ShowZigzagLegs) RemoveDrawObject(string.Format("swingLegDown{0}", lastLowIdx));
                    pre_swingLowType[CurrentBar - lastLowIdx] = 0;
                    currentLow = (useHL ? Low[0] : swingInput[0]);
                    lastLowIdx = CurrentBar;
                }
                #endregion

                #region re-init drawing states at each new bar before calculous
                if (ShowZigzagDots)
                {
                    drawHigherHighDot = false;
                    drawLowerHighDot = false;
                    drawDoubleTopDot = false;
                    drawLowerLowDot = false;
                    drawHigherLowDot = false;
                    drawDoubleBottomDot = false;
                }

                drawHigherHighLabel = false;
                drawLowerHighLabel = false;
                drawDoubleTopLabel = false;
                drawLowerLowLabel = false;
                drawHigherLowLabel = false;
                drawDoubleBottomLabel = false;
                
                if (ShowZigzagLegs)
                {
                    drawSwingLegUp = false;
                    drawSwingLegDown = false;
                }
                #endregion

                #region -- BUY || HH --
                if (addHigh || updateHigh)
                {
line=3932;
                    int priorHighCount = CurrentBar - priorSwingHighIdx;
                    int priorLowCount = CurrentBar - priorSwingLowIdx;
                    highCount = CurrentBar - lastHighIdx;
                    lowCount = CurrentBar - lastLowIdx;

                    double marginUp = (useHL ? High[priorHighCount] : swingInput[priorHighCount]) + MultiplierDTB * avgTrueRange[highCount];
                    double marginDown = (useHL ? High[priorHighCount] : swingInput[priorHighCount]) - MultiplierDTB * avgTrueRange[highCount];

line=3941;
                    // new code goes here
                    #region -- Calculate acceleration on BBMACD and Histo --
                    if (currentHigh > High[priorHighCount] && (BBMACD[highCount] > 0 && BBMACD[0] > 0) && BBMACD[highCount] > BBMACD[priorHighCount])
                        acceleration1[0] = 2;
                    else if (currentHigh <= High[priorHighCount] && (BBMACD[highCount] > 0 && BBMACD[0] > 0) && acceleration1[lowCount] == 1)
                        acceleration1[0] = 1;
                    else if (currentHigh <= High[priorHighCount] && (BBMACD[highCount] < 0 && BBMACD[0] < 0) && acceleration1[lowCount] == -2)
                        acceleration1[0] = -1;
                    else
                        acceleration1[0] = 0;
                    if (currentHigh > High[priorHighCount] && Histogram[highCount] > 0 && Histogram[0] > 0 && Histogram[highCount] > Histogram[priorHighCount])
                        acceleration2[0] = 2;
                    else if (currentHigh <= High[priorHighCount] && Histogram[highCount] > 0 && Histogram[0] > 0 && acceleration2[lowCount] == 1)
                        acceleration2[0] = 1;
                    else if (currentHigh <= High[priorHighCount] && Histogram[highCount] < 0 && Histogram[0] < 0 && acceleration2[lowCount] == -2)
                        acceleration2[0] = -1;
                    else
                        acceleration2[0] = 0;
                    #endregion
                    // end new code

line=3963;
                    #region -- Set NEW drawing states --
                    if (ShowZigzagDots)
                    {
                        if (currentHigh > marginUp)
                            drawHigherHighDot = true;
                        else if (currentHigh < marginDown)
                            drawLowerHighDot = true;
                        else
                            drawDoubleTopDot = true;
                    }

                    if (currentHigh > marginUp) drawHigherHighLabel = true;
                    else if (currentHigh < marginDown) drawLowerHighLabel = true;
                    else drawDoubleTopLabel = true;

line=3979;
                    if (ShowZigzagLegs)
                        drawSwingLegUp = true;
                    if (currentHigh > marginUp)
                        pre_swingHighType[highCount] = 3;
                    else if (currentHigh < marginDown)
                        pre_swingHighType[highCount] = 1;
                    else
                        pre_swingHighType[highCount] = 2;
                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (addLow || updateLow)
                {
line=3995;
                    int priorLowCount = CurrentBar - priorSwingLowIdx;
                    int priorHighCount = CurrentBar - priorSwingHighIdx;
                    lowCount = CurrentBar - lastLowIdx;
                    highCount = CurrentBar - lastHighIdx;

                    double marginDown = (useHL ? Low[priorLowCount] : swingInput[priorLowCount]) - MultiplierDTB * avgTrueRange[lowCount];
                    double marginUp = (useHL ? Low[priorLowCount] : swingInput[priorLowCount]) + MultiplierDTB * avgTrueRange[lowCount];

line=4004;
                    // new code goes here
                    #region -- Calculate acceleration on BBMACD and Histo --
                    if (currentLow < Low[priorLowCount] && (BBMACD[lowCount] < 0 && BBMACD[0] < 0) && BBMACD[lowCount] < BBMACD[priorLowCount])
                        acceleration1[0] = -2;
                    else if (currentLow >= Low[priorLowCount] && (BBMACD[lowCount] < 0 && BBMACD[0] < 0) && acceleration1[highCount] == -1)
                        acceleration1[0] = -1;
                    else if (currentLow >= Low[priorLowCount] && (BBMACD[lowCount] > 0 && BBMACD[0] > 0) && acceleration1[highCount] == 2)
                        acceleration1[0] = 1;
                    else
                        acceleration1[0] = 0;
                    if (currentLow < Low[priorLowCount] && Histogram[lowCount] < 0 && Histogram[0] < 0 && Histogram[lowCount] < Histogram[priorLowCount])
                        acceleration2[0] = -2;
                    else if (currentLow >= Low[priorLowCount] && Histogram[lowCount] < 0 && Histogram[0] < 0 && acceleration2[highCount] == -1)
                        acceleration2[0] = -1;
                    else if (currentLow >= Low[priorLowCount] && Histogram[lowCount] > 0 && Histogram[0] > 0 && acceleration2[highCount] == 2)
                        acceleration2[0] = 1;
                    else
                        acceleration2[0] = 0;
                    #endregion
                    // end new code

line=4026;
                    #region -- Set NEW drawing states --
                    if (ShowZigzagDots)
                    {
                        if (currentLow < marginDown)
                            drawLowerLowDot = true;
                        else if (currentLow > marginUp)
                            drawHigherLowDot = true;
                        else
                            drawDoubleBottomDot = true;
                    }

line=4038;
                    if (currentLow < marginDown) drawLowerLowLabel = true;
                    else if (currentLow > marginUp) drawHigherLowLabel = true;
                    else drawDoubleBottomLabel = true;
                    
                    if (ShowZigzagLegs)
                        drawSwingLegDown = true;
                    if (currentLow < marginDown)
                        pre_swingLowType[lowCount] = -3;
                    else if (currentLow > marginUp)
                        pre_swingLowType[lowCount] = -1;
                    else
                        pre_swingLowType[lowCount] = -2;
                    #endregion
                }
                #endregion

                //Is it possible ??
                else
                {
line=4058;
                    if ((acceleration1[1] > 0 && BBMACD[0] > 0) || (acceleration1[1] < 0 && BBMACD[0] < 0))
                        acceleration1[0] = acceleration1[1];
                    else
                        acceleration1[0] = 0;
                    if ((acceleration2[1] > 0 && Histogram[0] > 0) || (acceleration2[1] < 0 && Histogram[0] < 0))
                        acceleration2[0] = acceleration2[1];
                    else
                        acceleration2[0] = 0;
                }
            }
            #endregion

            #region else if (IsFirstTickOfBar)
            else if (IsFirstTickOfBar)
            {
line=4074;
                bool useHL = ThisInputType == ARC_VMDSystem_InputType.High_Low;
                zigzagDeviation = MultiplierMD * avgTrueRange[1];
                swingMax = MAX(useHL ? High : Input, SwingStrength)[2];
                swingMin = MIN(useHL ? Low : Input, SwingStrength)[2];

                pre_swingHighType[0] = 0;
                pre_swingLowType[0] = 0;
                swingHighType[0] = 0;
                swingLowType[0] = 0;

                updateHigh = upTrend[1] && (useHL ? High[1] : swingInput[1]) > currentHigh;
                updateLow = !upTrend[1] && (useHL ? Low[1] : swingInput[1]) < currentLow;
                addHigh = !upTrend[1] && !((useHL ? Low[1] : swingInput[1]) < currentLow) && (useHL ? High[1] : swingInput[1]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                addLow = upTrend[1] && !((useHL ? High[1] : swingInput[1]) > currentHigh) && (useHL ? Low[1] : swingInput[1]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

                upTrend[0] = upTrend[1];

line=4092;
                #region -- New High --
                if (addHigh)
                {
                    upTrend[0] = true;
                    int lookback = CurrentBar - lastLowIdx;
                    swingLowType[lookback] = pre_swingLowType[lookback];
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 1; i < CurrentBar - lastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : swingInput[i]) > newHigh)
                        {
                            newHigh = (useHL ? High[i] : swingInput[i]);
                            j = i;
                        }
                    }
                    currentHigh = newHigh;
                    priorSwingHighIdx = lastHighIdx;
                    lastHighIdx = CurrentBar - j;
                }
                #endregion

                #region -- UPtrend --
                else if (updateHigh)
                {
line=4118;
                    upTrend[0] = true;
                    if (ShowZigzagDots)
                        RemoveDrawObject(string.Format("swingHighDot{0}", lastHighIdx));
                    if (ShowZigzagLabels)
                        RemoveDrawObject(string.Format("swingHighLabel{0}", lastHighIdx));
                    if (ShowZigzagLegs)
                        RemoveDrawObject(string.Format("swingLegUp{0}", lastHighIdx));
                    pre_swingHighType[CurrentBar - lastHighIdx] = 0;
                    currentHigh = (useHL ? High[1] : swingInput[1]);
                    lastHighIdx = CurrentBar - 1;
                }
                #endregion

                #region -- New Low --
                else if (addLow)
                {
line=4135;
                    upTrend[0] = false;
                    int lookback = CurrentBar - lastHighIdx;
                    swingHighType[lookback] = pre_swingHighType[lookback];
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 1; i < CurrentBar - lastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : swingInput[i]) < newLow)
                        {
                            newLow = (useHL ? Low[i] : swingInput[i]);
                            j = i;
                        }
                    }
                    currentLow = newLow;
                    priorSwingLowIdx = lastLowIdx;
                    lastLowIdx = CurrentBar - j;
                }
                #endregion

                #region -- DWtrend --
                else if (updateLow)
                {
line=4158;
                    upTrend[0] = false;
                    if (ShowZigzagDots)
                        RemoveDrawObject(string.Format("swingLowDot{0}", lastLowIdx));
                    if (ShowZigzagLabels)
                        RemoveDrawObject(string.Format("swingLowLabel{0}", lastLowIdx));
                    if (ShowZigzagLegs)
                        RemoveDrawObject(string.Format("swingLegDown{0}", lastLowIdx));
                    pre_swingLowType[CurrentBar - lastLowIdx] = 0;
                    currentLow = useHL ? Low[1] : swingInput[1];
                    lastLowIdx = CurrentBar - 1;
                }
                #endregion

                #region re-init drawing states at each new bar before calculous
                if (ShowZigzagDots)
                {
                    drawHigherHighDot = false;
                    drawLowerHighDot = false;
                    drawDoubleTopDot = false;
                    drawLowerLowDot = false;
                    drawHigherLowDot = false;
                    drawDoubleBottomDot = false;
                }

                drawHigherHighLabel = false;
                drawLowerHighLabel = false;
                drawDoubleTopLabel = false;
                drawLowerLowLabel = false;
                drawHigherLowLabel = false;
                drawDoubleBottomLabel = false;

                if (ShowZigzagLegs)
                {
                    drawSwingLegUp = false;
                    drawSwingLegDown = false;
                }
                #endregion

                #region -- BUY || HH --
                if (addHigh || updateHigh)
                {
line=4200;
                    int priorHighCount = CurrentBar - priorSwingHighIdx;
                    highCount = CurrentBar - lastHighIdx;
                    lowCount = CurrentBar - lastLowIdx;

                    double marginUp = (useHL ? High[priorHighCount] : swingInput[priorHighCount]) + MultiplierDTB * avgTrueRange[highCount];
                    double marginDown = (useHL ? High[priorHighCount] : swingInput[priorHighCount]) - MultiplierDTB * avgTrueRange[highCount];

                    #region -- Set NEW drawing states --
                    if (ShowZigzagDots)
                    {
                        if (currentHigh > marginUp)
                            drawHigherHighDot = true;
                        else if (currentHigh < marginDown)
                            drawLowerHighDot = true;
                        else
                            drawDoubleTopDot = true;
                    }

line=4219;
                    if (currentHigh > marginUp) drawHigherHighLabel = true;
                    else if (currentHigh < marginDown) drawLowerHighLabel = true;
                    else drawDoubleTopLabel = true;
                    
                    if (ShowZigzagLegs)
                        drawSwingLegUp = true;
                    if (currentHigh > marginUp)
                        pre_swingHighType[highCount] = 3;
                    else if (currentHigh < marginDown)
                        pre_swingHighType[highCount] = 1;
                    else
                        pre_swingHighType[highCount] = 2;
                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (addLow || updateLow)
                {
line=4239;
                    int priorLowCount = CurrentBar - priorSwingLowIdx;
                    lowCount = CurrentBar - lastLowIdx;
                    highCount = CurrentBar - lastHighIdx;

                    double marginDown = (useHL ? Low[priorLowCount] : swingInput[priorLowCount]) - MultiplierDTB * avgTrueRange[lowCount];
                    double marginUp = (useHL ? Low[priorLowCount] : swingInput[priorLowCount]) + MultiplierDTB * avgTrueRange[lowCount];

                    #region -- Set NEW drawing states --
                    if (ShowZigzagDots)
                    {
                        if (currentLow < marginDown)
                            drawLowerLowDot = true;
                        else if (currentLow > marginUp)
                            drawHigherLowDot = true;
                        else
                            drawDoubleBottomDot = true;
                    }

line=4258;
                    if (currentLow < marginDown) drawLowerLowLabel = true;
                    else if (currentLow > marginUp) drawHigherLowLabel = true;
                    else drawDoubleBottomLabel = true;
                    
                    if (ShowZigzagLegs)
                        drawSwingLegDown = true;
                    if (currentLow < marginDown)
                        pre_swingLowType[lowCount] = -3;
                    else if (currentLow > marginUp)
                        pre_swingLowType[lowCount] = -1;
                    else
                        pre_swingLowType[lowCount] = -2;
                    #endregion
                }
                #endregion
            }
            #endregion

line=4277;
            #region if (Calculate != Calculate.OnBarClose)
            if (Calculate != Calculate.OnBarClose)
            {
                bool useHL = ThisInputType == ARC_VMDSystem_InputType.High_Low;

                intraBarUpdateHigh = upTrend[0] && (useHL ? High[0] : swingInput[0]) > currentHigh;
                intraBarUpdateLow = !upTrend[0] && (useHL ? Low[0] : swingInput[0]) < currentLow;
                intraBarAddHigh = !upTrend[0] && !((useHL ? Low[0] : swingInput[0]) < currentLow) && (useHL ? High[0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                intraBarAddLow = upTrend[0] && !((useHL ? High[0] : swingInput[0]) > currentHigh) && (useHL ? Low[0] : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

line=4288;
                #region -- new HH --
                if (intraBarAddHigh)
                {
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - lastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : swingInput[i]) > newHigh)
                        {
                            newHigh = (useHL ? High[i] : swingInput[i]);
                            j = i;
                        }
                    }
                    preCurrentHigh = newHigh;
                    preLastHighIdx = CurrentBar - j;
                }
                #endregion

                #region -- uptrend --
                else if (intraBarUpdateHigh)
                {
line=4310;
                    preCurrentHigh = (useHL ? High[0] : swingInput[0]);
                    preLastHighIdx = CurrentBar;
                }
                #endregion

line=4316;
                #region -- new LL --
                if (intraBarAddLow)
                {
line=4320;
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - lastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : swingInput[i]) < newLow)
                        {
                            newLow = useHL ? Low[i] : swingInput[i];
                            j = i;
                        }
                    }
                    preCurrentLow = newLow;
                    preLastLowIdx = CurrentBar - j;
                }
                #endregion

                #region -- dwtrend --
                else if (intraBarUpdateLow)
                {
line=4339;
                    preCurrentLow = (useHL ? Low[0] : swingInput[0]);
                    preLastLowIdx = CurrentBar;
                }
                #endregion

                #region -- BUY || HH --
                if (intraBarAddHigh || intraBarUpdateHigh)
                {
line=4348;
                    int prePriorHighCount = intraBarAddHigh ? CurrentBar - lastHighIdx : CurrentBar - priorSwingHighIdx;
                    int preHighCount = CurrentBar - preLastHighIdx;
                    int prePriorLowCount = CurrentBar - priorSwingLowIdx;
                    int preLowCount = CurrentBar - lastLowIdx;

                    #region -- Calculate acceleration on BBMACD and Histo --
                    if (preCurrentHigh > High[prePriorHighCount] && (BBMACD[preHighCount] > 0 && BBMACD[0] > 0) && BBMACD[preHighCount] > BBMACD[prePriorHighCount])
                        acceleration1[0] = 2;
                    else if (preCurrentHigh <= High[prePriorHighCount] && (BBMACD[preHighCount] > 0 && BBMACD[0] > 0) && acceleration1[preLowCount] == 1)
                        acceleration1[0] = 1;
                    else if (preCurrentHigh <= High[prePriorHighCount] && (BBMACD[preHighCount] < 0 && BBMACD[0] < 0) && acceleration1[preLowCount] == -2)
                        acceleration1[0] = -1;
                    else
                        acceleration1[0] = 0;
                    if (preCurrentHigh > High[prePriorHighCount] && Histogram[preHighCount] > 0 && Histogram[0] > 0 && Histogram[preHighCount] > Histogram[prePriorHighCount])
                        acceleration2[0] = 2;
                    else if (preCurrentHigh <= High[prePriorHighCount] && Histogram[preHighCount] > 0 && Histogram[0] > 0 && acceleration2[preLowCount] == 1)
                        acceleration2[0] = 1;
                    else if (preCurrentHigh <= High[prePriorHighCount] && Histogram[preHighCount] < 0 && Histogram[0] < 0 && acceleration2[preLowCount] == -2)
                        acceleration2[0] = -1;
                    else
                        acceleration2[0] = 0;
                    #endregion

line=4373;
                    #region ---- StructureBias RealTime ---
                    double marginUp, marginDown;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                    {
                        marginUp = High[prePriorHighCount] + MultiplierDTB * avgTrueRange[preHighCount];
                        marginDown = High[prePriorHighCount] - MultiplierDTB * avgTrueRange[preHighCount];
                    }
                    else
                    {
                        marginUp = swingInput[prePriorHighCount] + MultiplierDTB * avgTrueRange[preHighCount];
                        marginDown = swingInput[prePriorHighCount] - MultiplierDTB * avgTrueRange[preHighCount];
                    }

                    if (preCurrentHigh > marginUp) preSRType = 3;//#STRBIAS
                    else if (preCurrentHigh < marginDown) preSRType = Math.Max(preSRType, 2);//#STRBIAS
                    else preSRType = Math.Max(preSRType, 1);//#STRBIAS
                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (intraBarAddLow || intraBarUpdateLow)
                {
line=4397;
                    int prePriorLowCount = intraBarAddLow ? CurrentBar - lastLowIdx : CurrentBar - priorSwingLowIdx;
                    int preLowCount = CurrentBar - preLastLowIdx;
                    int prePriorHighCount = CurrentBar - priorSwingHighIdx;
                    int preHighCount = CurrentBar - lastHighIdx;

                    #region -- Calculate acceleration on BBMACD and Histo --
                    if (preCurrentLow < Low[prePriorLowCount] && (BBMACD[preLowCount] < 0 && BBMACD[0] < 0) && BBMACD[preLowCount] < BBMACD[prePriorLowCount])
                        acceleration1[0] = -2;
                    else if (preCurrentLow >= Low[prePriorLowCount] && (BBMACD[preLowCount] < 0 && BBMACD[0] < 0) && acceleration1[preHighCount] == -1)
                        acceleration1[0] = -1;
                    else if (preCurrentLow >= Low[prePriorLowCount] && (BBMACD[preLowCount] > 0 && BBMACD[0] > 0) && acceleration1[preHighCount] == 2)
                        acceleration1[0] = 1;
                    else
                        acceleration1[0] = 0;
                    if (preCurrentLow < Low[prePriorLowCount] && Histogram[preLowCount] < 0 && Histogram[0] < 0 && Histogram[preLowCount] < Histogram[prePriorLowCount])
                        acceleration2[0] = -2;
                    else if (preCurrentLow >= Low[prePriorLowCount] && Histogram[preLowCount] < 0 && Histogram[0] < 0 && acceleration2[preHighCount] == -1)
                        acceleration2[0] = -1;
                    else if (preCurrentLow >= Low[prePriorLowCount] && Histogram[preLowCount] > 0 && Histogram[0] > 0 && acceleration2[preHighCount] == 2)
                        acceleration2[0] = 1;
                    else
                        acceleration2[0] = 0;
                    #endregion

line=4422;
                    #region ---- StructureBias RealTime ---
                    double marginUp, marginDown;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                    {
                        marginDown = Low[prePriorLowCount] - MultiplierDTB * avgTrueRange[preLowCount];
                        marginUp = Low[prePriorLowCount] + MultiplierDTB * avgTrueRange[preLowCount];
                    }
                    else
                    {
                        marginDown = swingInput[prePriorLowCount] - MultiplierDTB * avgTrueRange[preLowCount];
                        marginUp = swingInput[prePriorLowCount] + MultiplierDTB * avgTrueRange[preLowCount];
                    }
                    if (preCurrentLow < marginDown) preSRType = -3;//#STRBIAS
                    else if (preCurrentLow > marginUp) preSRType = Math.Min(preSRType, -2);//#STRBIAS
                    else preSRType = Math.Min(preSRType, -1);//#STRBIAS
                    #endregion
                }
                #endregion

                //Is it possible ??
                else
                {
line=4445;
                    if ((acceleration1[1] > 0 && BBMACD[0] > 0) || (acceleration1[1] < 0 && BBMACD[0] < 0))
                        acceleration1[0] = acceleration1[1];
                    else
                        acceleration1[0] = 0;
                    if ((acceleration2[1] > 0 && Histogram[0] > 0) || (acceleration2[1] < 0 && Histogram[0] < 0))
                        acceleration2[0] = acceleration2[1];
                    else
                        acceleration2[0] = 0;

                    preSRType = 0;//#STRBIAS
                }

                #region ---- StructureBias RealTime ---
                if (CurrentBar < 2) 
					structureBiasState[0] = 0;
                else
                {
line=4463;
                    if (preSRType == 0) structureBiasState[0] = structureBiasState[1];

                    #region -- Oscillation State --
                    else if (structureBiasState[1] == 0)
                    {
                        //Oscillation State
                        //Need HH/!LL/HH to go to Up Trend
                        //{NEW} !LL/High/!LL/HH to go to Up Trend
                        //Need LL/!HH/LL to go to Dw Trend
                        //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
                        if (sequence.Count < 2) structureBiasState[0] = 0;
                        else if (sequence.Count < 3)
                        {
line=4477;
                            if (sequence[0] == 3 && sequence[1] != -3 && preSRType == 3) structureBiasState[0] = 1;
                            else if (sequence[0] == -3 && sequence[1] != 3 && preSRType == -3) structureBiasState[0] = -1;
                            else structureBiasState[0] = 0;
                        }
                        else
                        {
line=4484;
                            if (sequence[1] == 3 && sequence[2] != -3 && preSRType == 3) structureBiasState[0] = 1;
                            else if (sequence[1] == -3 && sequence[2] != 3 && preSRType == -3) structureBiasState[0] = -1;
                            //{NEW} HL/LH/HL/HH to go to Up Trend
                            else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && preSRType == 3) structureBiasState[0] = 1;
                            //{NEW} LH/HL/LH/LL to go to Up Trend
                            else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && preSRType == -3) structureBiasState[0] = -1;
                            else structureBiasState[0] = 0;
                        }
                    }
                    #endregion

                    #region -- UpTrend State --
                    else if (structureBiasState[1] > 0)
                    {
line=4499;
                        //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
                        if (preSRType == -3) structureBiasState[0] = 0;
                        else structureBiasState[0] = 1;
                    }
                    #endregion

                    #region -- DwTrend State --
                    else if (structureBiasState[1] < 0)
                    {
line=4509;
                        //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
                        if (preSRType == 3) structureBiasState[0] = 0;
                        else structureBiasState[0] = -1;
                    }
                    #endregion

                    else structureBiasState[0] = structureBiasState[1];
                }
                #endregion
            }
            #endregion

			int cutoffIdx = int.MinValue;
			int cb = CurrentBar;
			if(State==State.Historical) cb = Bars.Count;
			if(OptimizeSpeed == ARC_VMDSystem_OptimizeSpeedSettings.Min) cutoffIdx = cb-500;
			else if(OptimizeSpeed == ARC_VMDSystem_OptimizeSpeedSettings.Max) cutoffIdx = cb-100;
			bool PrintMarkers = CurrentBar>cutoffIdx;

line=4529;
            if (Calculate == Calculate.OnBarClose || IsFirstTickOfBar)
            {
                DrawOnPricePanel = true;
                #region -- Draw zigzag --    
                if (PrintMarkers && ShowZigzagDots && ThisInputType == ARC_VMDSystem_InputType.High_Low)
                {
line=4536;
					if(IsFirstTickOfBar && cutoffIdx>0){
						RemoveDrawObject(string.Format("swingHighDot{0}",cutoffIdx));
						RemoveDrawObject(string.Format("swingLowDot{0}",cutoffIdx));
					}
                    if (drawHigherHighDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, High[highCount], SwingDotSize / 2, upColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawLowerHighDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, High[highCount], SwingDotSize / 2, downColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawDoubleTopDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, High[highCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    if (drawLowerLowDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, Low[lowCount], SwingDotSize / 2, downColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawHigherLowDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, Low[lowCount], SwingDotSize / 2, upColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawDoubleBottomDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, Low[lowCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                }
                else if (PrintMarkers && ShowZigzagDots)
                {
line=4556;
					if(IsFirstTickOfBar && cutoffIdx>0){
						RemoveDrawObject(string.Format("swingHighDot{0}",cutoffIdx));
						RemoveDrawObject(string.Format("swingLowDot{0}",cutoffIdx));
					}
                    if (drawHigherHighDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, swingInput[highCount], SwingDotSize / 2, upColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawLowerHighDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, swingInput[highCount], SwingDotSize / 2, downColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawDoubleTopDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, swingInput[highCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    if (drawLowerLowDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, swingInput[lowCount], SwingDotSize / 2, downColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawHigherLowDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, swingInput[lowCount], SwingDotSize / 2, upColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawDoubleBottomDot)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, swingInput[lowCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                }
                if (PrintMarkers && ShowZigzagLabels)
                {
line=4576;
					if(IsFirstTickOfBar && cutoffIdx>0){
						RemoveDrawObject(string.Format("swingHighLabel{0}",cutoffIdx));
						RemoveDrawObject(string.Format("swingLowLabel{0}",cutoffIdx));
					}
                    if (drawHigherHighLabel)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingHighLabel{0}", lastHighIdx), true, "HH", highCount, High[highCount], (int)(labelFont.Size) + pixelOffset1, upColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawLowerHighLabel)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingHighLabel{0}", lastHighIdx), true, "LH", highCount, High[highCount], (int)(labelFont.Size) + pixelOffset1, downColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawDoubleTopLabel)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingHighLabel{0}", lastHighIdx), true, "DT", highCount, High[highCount], (int)(labelFont.Size) + pixelOffset1, doubleTopBottomColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    if (drawLowerLowLabel)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingLowLabel{0}", lastLowIdx), true, "LL", lowCount, Low[lowCount], -(int)(labelFont.Size) - pixelOffset2, downColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawHigherLowLabel)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingLowLabel{0}", lastLowIdx), true, "HL", lowCount, Low[lowCount], -(int)(labelFont.Size) - pixelOffset2, upColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                    else if (drawDoubleBottomLabel)
                        TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("swingLowLabel{0}", lastLowIdx), true, "DB", lowCount, Low[lowCount], -(int)(labelFont.Size) - pixelOffset2, doubleTopBottomColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
                }
                if (PrintMarkers && ShowZigzagLegs && ThisInputType == ARC_VMDSystem_InputType.High_Low)
                {
line=4596;
					if(IsFirstTickOfBar && cutoffIdx>0){
						RemoveDrawObject(string.Format("swingLegUp{0}",cutoffIdx));
						RemoveDrawObject(string.Format("swingLegDown{0}",cutoffIdx));
					}
//					TriggerCustomEvent(o1 =>{	
	                    if (drawSwingLegUp)
    	                    TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("swingLegUp{0}", lastHighIdx), false, lowCount, Low[lowCount], highCount, High[highCount], upColor, SwingLegStyle, SwingLegWidth);},0,null);
        	            if (drawSwingLegDown)
            	            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("swingLegDown{0}", lastLowIdx), false, highCount, High[highCount], lowCount, Low[lowCount], downColor, SwingLegStyle, SwingLegWidth);},0,null);
//					},0,null);
                }
                else if (PrintMarkers && ShowZigzagLegs)
                {
line=4610;
					if(IsFirstTickOfBar && cutoffIdx>0){
						RemoveDrawObject(string.Format("swingLegUp{0}",cutoffIdx));
						RemoveDrawObject(string.Format("swingLegDown{0}",cutoffIdx));
					}
//					TriggerCustomEvent(o1 =>{	
	                    if (drawSwingLegUp)
    	                    TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("swingLegUp{0}", lastHighIdx), false, lowCount, swingInput[lowCount], highCount, swingInput[highCount], upColor, SwingLegStyle, SwingLegWidth);},0,null);
        	            if (drawSwingLegDown)
            	            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("swingLegDown{0}", lastLowIdx), false, highCount, swingInput[highCount], lowCount, swingInput[lowCount], downColor, SwingLegStyle, SwingLegWidth);},0,null);
//					},0,null);
                }
                #endregion
            }

            #endregion

            #region -- Calculate / Draw Divergences -- 

            #region --- init before having enought bars --- 
            if (CurrentBar < BarsRequiredToPlot + DivMaxBars)
            {
line=4632;
                structureBiasState[0] = 0;//#STRBIAS
                SRType = 0;//#STRBIAS
                swingHighsState[0] = 0;//#STRBIAS
                swingLowsState[0] = 0;//#STRBIAS

                bearishTriggerCountMACDBB[0] = 0;
                bullishTriggerCountMACDBB[0] = 0;
                bearishTriggerCountHistogram[0] = 0;
                bullishTriggerCountHistogram[0] = 0;

                hiddenbearishTriggerCountMACDBB[0] = (0);//#HIDDENDIV
                hiddenbullishTriggerCountMACDBB[0] = (0);//#HIDDENDIV
                hiddenbearishTriggerCountHistogram[0] = (0);//#HIDDENDIV
                hiddenbullishTriggerCountHistogram[0] = (0);//#HIDDENDIV

                bearishDivPlotSeriesMACDBB[0] = 0;
                bullishDivPlotSeriesMACDBB[0] = 0;
                bearishDivPlotSeriesHistogram[0] = 0;
                bullishDivPlotSeriesHistogram[0] = 0;
                hiddenbearishDivPlotSeriesMACDBB[0] = 0;//#HIDDENDIV
                hiddenbullishDivPlotSeriesMACDBB[0] = 0;//#HIDDENDIV
                hiddenbearishDivPlotSeriesHistogram[0] = 0;//#HIDDENDIV
                hiddenbullishDivPlotSeriesHistogram[0] = 0;//#HIDDENDIV

                cptBearMACDdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                cptBullMACDdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                cptBearHistogramdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                cptBullHistogramdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                cptBearMACDhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                cptBullMACDhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                cptBearHistogramhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                cptBullHistogramhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                return;
            }
            #endregion

            #region -- Calculate OFFSET -- 
            if (IsFirstTickOfBar)
            {
line=4672;
                offsetDraw1 = OffsetMultiplier1 * avgTrueRange[1] / 100;
                offsetDraw2 = OffsetMultiplier2 * avgTrueRange[1] / 100;
                offsetDiv1 = OffsetMultiplier3 * avgTrueRange[1] / 100;
                offsetDiv2 = OffsetMultiplier4 * avgTrueRange[1] / 100;
            }
            #endregion

            #region -- Calculate Divergences --
            if (Calculate == Calculate.OnBarClose)
            {
line=4683;
                #region Bearish divergences between price and BBMACD
                if (bearishTriggerCountMACDBB[1] > 0)
                {
                    priorFirstPeakBar1         = firstPeakBar1;
                    priorFirstOscPeakBar1      = firstOscPeakBar1;
                    priorFirstPeakHigh1        = firstPeakHigh1;
                    priorFirstPeakValue1       = firstPeakValue1;
                    priorReplacementPeakValue1 = replacementPeakValue1;
                    priorSecondPeakValue1      = secondPeakValue1;
                    if (BBMACD[0] > firstPeakValue1)
                    {
                        bearishTriggerCountMACDBB[0] = 0;
                        RemoveDrawObject("divBearCandidateOsc1");
                        RemoveDrawObject("divBearCandidatePrice1");
                    }
                }
                bool drawBearishDivCandidateOsc1     = false;
                bool drawBearishDivCandidatePrice1   = false;
                bool updateBearishDivCandidateOsc1   = false;
                bool updateBearishDivCandidatePrice1 = false;
                bool drawBearSetup1         = false;
                bool drawBearishDivOnOsc1   = false;
                bool drawBearishDivOnPrice1 = false;
                bool drawArrowDown1  = false;
                bool firstPeakFound1 = false;
                peakCount1 = 0;
line=4710;
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
                    int j = 0;
                    if (swingHighType[i] > 0)
                    {
                        refPeakBar1[peakCount1] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refPeakHigh1[peakCount1] = High[i];
                        else
                            refPeakHigh1[peakCount1] = swingInput[i];
                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 4) && BBMACD[j - 1] > BBMACD[j])
                                j = j - 1;
                            refOscPeakBar1[peakCount1] = CurrentBar - j;
                            refPeakValue1[peakCount1] = BBMACD[j];
                            peakCount1 = peakCount1 + 1;
                        }
                        else
                        {
                            refOscPeakBar1[peakCount1] = CurrentBar - i;
                            refPeakValue1[peakCount1] = BBMACD[i];
                            peakCount1 = peakCount1 + 1;
                        }

                    }
                    if ((UseLastSwingOnly && peakCount1 == 1) || peakCount1 == 9)
                        break;
                }
                bearishPDivMACD[0] = 0.0;
                int maxBarOsc = UseOscHighLow && BBMACD[1] > BBMACD[0] ? CurrentBar - 1 : CurrentBar;
                double maxValueOsc = UseOscHighLow && BBMACD[1] > BBMACD[0] ? BBMACD[1] : BBMACD[0];

line=4745;
                for (int count = 0; count < peakCount1; count++) //find smallest divergence setup
                {
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && High[0] >= refPeakHigh1[count]) || (!IncludeDoubleTopsAndBottoms && High[0] > refPeakHigh1[count]))
                        && High[0] > High[1] && High[0] >= MAX(High, CurrentBar - refPeakBar1[count] - 2)[1] && refPeakValue1[count] > 0 && refPeakValue1[count] > maxValueOsc
                        && refPeakValue1[count] > MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1[count] - 6))[1] && (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1[count])[0] > 0))
                    {
                        bearishPDivMACD[0] = 1.0;
                        bearishTriggerCountMACDBB[0] = TriggerBars + 1;
                        firstPeakBar1 = refPeakBar1[count];
                        firstPeakHigh1 = refPeakHigh1[count];
                        firstOscPeakBar1 = refOscPeakBar1[count];
                        firstPeakValue1 = refPeakValue1[count];
                        secondPeakBar1 = CurrentBar;
                        secondPeakHigh1 = High[0];
                        secondOscPeakBar1 = maxBarOsc;
                        secondPeakValue1 = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBearCandidateOsc1");
                            drawBearishDivCandidateOsc1 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBearCandidatePrice1");
                            drawBearishDivCandidatePrice1 = true;
                        }
                        if (ShowSetupDots)
                            drawBearSetup1 = true;
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] >= refPeakHigh1[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] > refPeakHigh1[count]))
                        && swingInput[0] > swingInput[1] && swingInput[0] >= MAX(swingInput, CurrentBar - refPeakBar1[count] - 2)[1] && refPeakValue1[count] > 0 && refPeakValue1[count] > maxValueOsc
                        && refPeakValue1[count] > MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1[count] - 6))[1] && (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1[count])[0] > 0))
                    {
line=4780;
                        bearishPDivMACD[0] = 1.0;
                        bearishTriggerCountMACDBB[0] = TriggerBars + 1;
                        firstPeakBar1 = refPeakBar1[count];
                        firstPeakHigh1 = refPeakHigh1[count];
                        firstOscPeakBar1 = refOscPeakBar1[count];
                        firstPeakValue1 = refPeakValue1[count];
                        secondPeakBar1 = CurrentBar;
                        secondPeakHigh1 = swingInput[0];
                        secondOscPeakBar1 = maxBarOsc;
                        secondPeakValue1 = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBearCandidateOsc1");
                            drawBearishDivCandidateOsc1 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBearCandidatePrice1");
                            drawBearishDivCandidatePrice1 = true;
                        }
                        if (ShowSetupDots)
                            drawBearSetup1 = true;
                        break;
                    }
                }
                for (int count = peakCount1 - 1; count >= 0; count--) //find largest divergence setup
                {
line=4808;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && High[0] >= refPeakHigh1[count]) || (!IncludeDoubleTopsAndBottoms && High[0] > refPeakHigh1[count]))
                        && High[0] > High[1] && High[0] >= MAX(High, CurrentBar - refPeakBar1[count] - 2)[1] && refPeakValue1[count] > 0 && refPeakValue1[count] > maxValueOsc
                        && refPeakValue1[count] > MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1[count] - 6))[1] && (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1[count])[0] > 0))
                    {
                        replacementPeakBar1 = refPeakBar1[count];
                        replacementPeakHigh1 = refPeakHigh1[count];
                        replacementOscPeakBar1 = refOscPeakBar1[count];
                        replacementPeakValue1 = refPeakValue1[count];
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] >= refPeakHigh1[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] > refPeakHigh1[count]))
                        && swingInput[0] > swingInput[1] && swingInput[0] >= MAX(swingInput, CurrentBar - refPeakBar1[count] - 2)[1] && refPeakValue1[count] > 0 && refPeakValue1[count] > maxValueOsc
                        && refPeakValue1[count] > MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1[count] - 6))[1] && (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1[count])[0] > 0))
                    {
                        replacementPeakBar1 = refPeakBar1[count];
                        replacementPeakHigh1 = refPeakHigh1[count];
                        replacementOscPeakBar1 = refOscPeakBar1[count];
                        replacementPeakValue1 = refPeakValue1[count];
                        break;
                    }
                }
line=4830;
                if (bearishPDivMACD[0] < 0.5)
                {
                    if (bearishTriggerCountMACDBB[1] > 0)
                    {
                        bearishTriggerCountMACDBB[0] = bearishTriggerCountMACDBB[1] - 1;
                        if (BBMACD[0] > priorSecondPeakValue1)
                        {
line=4838;
                            if (BBMACD[0] < priorFirstPeakValue1)
                            {
                                secondOscPeakBar1 = CurrentBar;
                                secondPeakValue1 = BBMACD[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBearCandidateOsc1");
                                    updateBearishDivCandidateOsc1 = true;
                                }
                            }
                            else if (BBMACD[0] < priorReplacementPeakValue1)
                            {
                                firstPeakBar1 = replacementPeakBar1;
                                firstPeakHigh1 = replacementPeakHigh1;
                                firstOscPeakBar1 = replacementOscPeakBar1;
                                firstPeakValue1 = replacementPeakValue1;
                                secondOscPeakBar1 = CurrentBar;
                                secondPeakValue1 = BBMACD[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBearCandidateOsc1");
                                    drawBearishDivCandidateOsc1 = true;
                                    RemoveDrawObject("divBearCandidatePrice1");
                                    drawBearishDivCandidatePrice1 = true;
                                }
                            }
                            else
                                bearishTriggerCountMACDBB[0] = 0;
                        }
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low && bearishTriggerCountMACDBB[0] > 0 && High[0] > MAX(High, CurrentBar - firstPeakBar1)[1])
                        {
line=4870;
                            secondPeakBar1 = CurrentBar;
                            secondPeakHigh1 = High[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBearCandidatePrice1");
                                updateBearishDivCandidatePrice1 = true;
                            }
                        }
                        else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bearishTriggerCountMACDBB[0] > 0 && swingInput[0] > MAX(swingInput, CurrentBar - firstPeakBar1)[1])
                        {
line=4881;
                            secondPeakBar1 = CurrentBar;
                            secondPeakHigh1 = swingInput[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBearCandidatePrice1");
                                updateBearishDivCandidatePrice1 = true;
                            }
                        }
                    }
                }

line=4893;
                if (bearishTriggerCountMACDBB[0] > 0)
                {
line=4896;
                    if ((Close[0] < High[CurrentBar - secondPeakBar1]) && (BBMACD[0] < BBMACD[1]) && Close[0] < Open[0])
                    {
                        bearishCDivMACD[0] = 1.0;
                        bearishTriggerCountMACDBB[0] = 0;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                            drawBearishDivOnOsc1 = true;
                        if (ShowDivOnPricePanel)
                            drawBearishDivOnPrice1 = true;
                        if (showArrows)
                            drawArrowDown1 = true;
                        RemoveDrawObject("divBearCandidateOsc1");
                        RemoveDrawObject("divBearCandidatePrice1");

                        if (firstPeakBar1 != memfirstPeakBar1) cptBearMACDdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                        memfirstPeakBar1 = firstPeakBar1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBearMACDdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bearishMACDDivProjection[0] = cptBearMACDdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else
                        bearishCDivMACD[0] = 0.0;
                }
                else
                {
line=4920;
                    bearishCDivMACD[0] = 0.0;
                    {
                        RemoveDrawObject("divBearCandidateOsc1");
                        RemoveDrawObject("divBearCandidatePrice1");
                    }
                }
                #endregion

                #region Bearish Hidden divergences between price and BBMACD #HIDDENDIV
                if (hiddenbearishTriggerCountMACDBB[1] > 0)
                {
line=4932;
                    priorFirstPeakBar1H = firstPeakBar1H;
                    priorFirstOscPeakBar1H = firstOscPeakBar1H;
                    priorFirstPeakHigh1H = firstPeakHigh1H;
                    priorFirstPeakValue1H = firstPeakValue1H;
                    priorReplacementPeakHigh1H = replacementPeakHigh1H;
                    priorReplacementPeakValue1H = replacementPeakValue1H;
                    priorSecondPeakValue1H = secondPeakValue1H;
                    priorSecondPeakHigh1H = secondPeakHigh1H;

                    double refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[0] : swingInput[0];
                    if (refinput > firstPeakHigh1H)
                    {
                        hiddenbearishTriggerCountMACDBB[0] = 0;
                        RemoveDrawObject("hiddendivBearCandidateOsc1");
                        RemoveDrawObject("hiddendivBearCandidatePrice1");
                    }
                }

                #region -- reset variables --
                drawBearishDivCandidateOsc1H = false;
                drawBearishDivCandidatePrice1H = false;
                updateBearishDivCandidateOsc1H = false;
                updateBearishDivCandidatePrice1H = false;
                drawBearSetup1H = false;
                drawBearishDivOnOsc1H = false;
                drawBearishDivOnPrice1H = false;
                drawArrowDown1H = false;
                firstPeakFound1H = false;
                peakCount1H = 0;
                #endregion

                #region -- get price top and osc top --
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
line=4967;
                    int j = 0;
                    if (swingHighType[i] > 0)
                    {
                        refPeakBar1H[peakCount1H] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refPeakHigh1H[peakCount1H] = High[i];
                        else
                            refPeakHigh1H[peakCount1H] = swingInput[i];

                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 4) && BBMACD[j - 1] > BBMACD[j])
                                j = j - 1;
                            refOscPeakBar1H[peakCount1H] = CurrentBar - j;
                            refPeakValue1H[peakCount1H] = BBMACD[j];
                            peakCount1H = peakCount1H + 1;
                        }
                        else
                        {
                            refOscPeakBar1H[peakCount1H] = CurrentBar - i;
                            refPeakValue1H[peakCount1H] = BBMACD[i];
                            peakCount1H = peakCount1H + 1;
                        }

                    }
                    if ((UseLastSwingOnly && peakCount1H == 1) || peakCount1H == 9) break;
                }
                #endregion

                hiddenbearishPDivMACD[0] = 0.0;
                maxBarOsc = UseOscHighLow && BBMACD[1] > BBMACD[0] ? CurrentBar - 1 : CurrentBar;
                maxValueOsc = UseOscHighLow && BBMACD[1] > BBMACD[0] ? BBMACD[1] : BBMACD[0];

                for (int count = 0; count < peakCount1H; count++) //find smallest divergence setup
                {
line=5004;
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] <= refPeakHigh1H[count]) ||
                        (!IncludeDoubleTopsAndBottoms && refinput[0] < refPeakHigh1H[count])) &&
                        refinput[0] > refinput[1] &&
                        refinput[0] >= MAX(refinput, CurrentBar - refPeakBar1H[count] - 2)[1] &&
                        refPeakValue1H[count] > 0 &&
                        refPeakValue1H[count] < maxValueOsc &&
                        refPeakValue1H[count] < MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1H[count] - 6))[1] &&
                        (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1H[count])[0] > 0))
                    {
line=5015;
                        hiddenbearishPDivMACD[0] = 1.0;
                        hiddenbearishTriggerCountMACDBB[0] = TriggerBars + 1;
                        firstPeakBar1H = refPeakBar1H[count];
                        firstPeakHigh1H = refPeakHigh1H[count];
                        firstOscPeakBar1H = refOscPeakBar1H[count];
                        firstPeakValue1H = refPeakValue1H[count];
                        secondPeakBar1H = CurrentBar;
                        secondPeakHigh1H = refinput[0];
                        secondOscPeakBar1H = maxBarOsc;
                        secondPeakValue1H = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("hiddendivBearCandidateOsc1");
                            drawBearishDivCandidateOsc1H = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("hiddendivBearCandidatePrice1");
                            drawBearishDivCandidatePrice1H = true;
                        }
                        if (ShowSetupDots) drawBearSetup1H = true;
                        break;
                    }
                }

line=5041;
                for (int count = peakCount1H - 1; count >= 0; count--) //find largest divergence setup
                {
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] <= refPeakHigh1H[count]) || (!IncludeDoubleTopsAndBottoms && refinput[0] < refPeakHigh1H[count])) &&
                        refinput[0] > refinput[1] &&
                        refinput[0] >= MAX(refinput, CurrentBar - refPeakBar1H[count] - 2)[1] &&
                        refPeakValue1H[count] > 0 &&
                        refPeakValue1H[count] < maxValueOsc &&
                        refPeakValue1H[count] < MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1H[count] - 6))[1] &&
                        (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1H[count])[0] > 0))
                    {
                        replacementPeakBar1H = refPeakBar1H[count];
                        replacementPeakHigh1H = refPeakHigh1H[count];
                        replacementOscPeakBar1H = refOscPeakBar1H[count];
                        replacementPeakValue1H = refPeakValue1H[count];
                        break;
                    }
                }

line=5061;
                double inputref = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[0] : swingInput[0];
                if (hiddenbearishPDivMACD[0] < 0.5)
                {
                    if (hiddenbearishTriggerCountMACDBB[1] > 0)
                    {
                        hiddenbearishTriggerCountMACDBB[0] = hiddenbearishTriggerCountMACDBB[1] - 1;
                        if (inputref > priorSecondPeakHigh1H)
                        {
                            if (inputref < priorFirstPeakHigh1H)//price stays below
                            {
                                secondPeakBar1H = CurrentBar;
                                secondPeakHigh1H = inputref;
                                if (!hidePlots && ShowDivOnPricePanel)
                                {
                                    RemoveDrawObject("hiddendivBearCandidatePrice1");
                                    updateBearishDivCandidatePrice1H = true;
                                }
                            }
                            else if (inputref < priorReplacementPeakHigh1H)
                            {
                                firstPeakBar1H = replacementPeakBar1H;
                                firstPeakHigh1H = replacementPeakHigh1H;
                                firstOscPeakBar1H = replacementOscPeakBar1H;
                                firstPeakValue1H = replacementPeakValue1H;
                                secondPeakBar1H = CurrentBar;
                                secondPeakHigh1H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBearCandidateOsc1");
                                    drawBearishDivCandidateOsc1H = true;
                                    RemoveDrawObject("hiddendivBearCandidatePrice1");
                                    drawBearishDivCandidatePrice1H = true;
                                }
                            }
                            else
                                hiddenbearishTriggerCountMACDBB[0] = 0;
                        }
                        if (hiddenbearishTriggerCountMACDBB[0] > 0 && BBMACD[0] > MAX(BBMACD, CurrentBar - firstOscPeakBar1H)[1])
                        {
                            secondOscPeakBar1H = CurrentBar;
                            secondPeakValue1H = BBMACD[0];
                            if (ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBearCandidateOsc1");
                                updateBearishDivCandidateOsc1H = true;
                            }
                        }
                    }
                }

line=5112;
                if (hiddenbearishTriggerCountMACDBB[0] > 0)
                {
                    if ((Close[0] < High[CurrentBar - secondPeakBar1H]) && (BBMACD[0] < BBMACD[1]) && Close[0] < Open[0])
                    {
                        hiddenbearishCDivMACD[0] = 1.0;
                        hiddenbearishTriggerCountMACDBB[0] = 0;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                            drawBearishDivOnOsc1H = true;
                        if (ShowDivOnPricePanel)
                            drawBearishDivOnPrice1H = true;
                        if (showArrows)
                            drawArrowDown1H = true;
                        RemoveDrawObject("hiddendivBearCandidateOsc1");
                        RemoveDrawObject("hiddendivBearCandidatePrice1");

                        if (firstPeakBar1H != memfirstPeakBar1H) cptBearMACDhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                        memfirstPeakBar1H = firstPeakBar1H;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBearMACDhdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bearishMACDHiddenDivProjection[0] = cptBearMACDhdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else hiddenbearishCDivMACD[0] = 0.0;
                }
                else
                {
                    hiddenbearishCDivMACD[0] = 0.0;
                    RemoveDrawObject("hiddendivBearCandidateOsc1");
                    RemoveDrawObject("hiddendivBearCandidatePrice1");
                }
                #endregion

                #region Bullish divergences between price and BBMACD
                if (bullishTriggerCountMACDBB[1] > 0)
                {
line=5146;
                    priorFirstTroughBar1 = firstTroughBar1;
                    priorFirstOscTroughBar1 = firstOscTroughBar1;
                    priorFirstTroughLow1 = firstTroughLow1;
                    priorFirstTroughValue1 = firstTroughValue1;
                    priorReplacementTroughValue1 = replacementTroughValue1;
                    priorSecondTroughValue1 = secondTroughValue1;
                    if (BBMACD[0] < firstTroughValue1)
                    {
                        bullishTriggerCountMACDBB[0] = 0;
                        RemoveDrawObject("divBullCandidateOsc1");
                        RemoveDrawObject("divBullCandidatePrice1");
                    }
                }
                bool drawBullishDivCandidateOsc1 = false;
                bool drawBullishDivCandidatePrice1 = false;
                bool updateBullishDivCandidateOsc1 = false;
                bool updateBullishDivCandidatePrice1 = false;
                bool drawBullSetup1 = false;
                bool drawBullishDivOnOsc1 = false;
                bool drawBullishDivOnPrice1 = false;
                bool drawArrowUp1 = false;
                bool firstTroughFound1 = false;
                troughCount1 = 0;
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
line=5172;
                    int j = 0;
                    if (swingLowType[i] < 0)
                    {
                        refTroughBar1[troughCount1] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refTroughLow1[troughCount1] = Low[i];
                        else
                            refTroughLow1[troughCount1] = swingInput[i];
                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 3) && BBMACD[j - 1] < BBMACD[j])
                                j = j - 1;
                            refOscTroughBar1[troughCount1] = CurrentBar - j;
                            refTroughValue1[troughCount1] = BBMACD[j];
                            troughCount1 = troughCount1 + 1;
                        }
                        else
                        {
                            refOscTroughBar1[troughCount1] = CurrentBar - i;
                            refTroughValue1[troughCount1] = BBMACD[i];
                            troughCount1 = troughCount1 + 1;
                        }
                    }
                    if ((UseLastSwingOnly && troughCount1 == 1) || troughCount1 == 9)
                        break;
                }
                bullishPDivMACD[0] = 0.0;
                int minBarOsc = UseOscHighLow && BBMACD[1] < BBMACD[0] ? CurrentBar - 1 : CurrentBar;
                double minValueOsc = UseOscHighLow && BBMACD[1] < BBMACD[0] ? BBMACD[1] : BBMACD[0];

                for (int count = 0; count < troughCount1; count++) //find smallest divergence setup
                {
line=5206;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && Low[0] <= refTroughLow1[count]) || (!IncludeDoubleTopsAndBottoms && Low[0] < refTroughLow1[count]))
                        && Low[0] < Low[1] && Low[0] <= MIN(Low, CurrentBar - refTroughBar1[count] - 2)[1] && refTroughValue1[count] < 0 && refTroughValue1[count] < minValueOsc
                        && refTroughValue1[count] < MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1[count] - 6))[1] && (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1[count])[0] < 0))
                    {
                        bullishPDivMACD[0] = 1.0;
                        bullishTriggerCountMACDBB[0] = TriggerBars + 1;
                        firstTroughBar1 = refTroughBar1[count];
                        firstTroughLow1 = refTroughLow1[count];
                        firstOscTroughBar1 = refOscTroughBar1[count];
                        firstTroughValue1 = refTroughValue1[count];
                        secondTroughBar1 = CurrentBar;
                        secondTroughLow1 = Low[0];
                        secondOscTroughBar1 = minBarOsc;
                        secondTroughValue1 = minValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBullCandidateOsc1");
                            drawBullishDivCandidateOsc1 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBullCandidatePrice1");
                            drawBullishDivCandidatePrice1 = true;
                        }
                        if (ShowSetupDots)
                            drawBullSetup1 = true;
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] <= refTroughLow1[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] < refTroughLow1[count]))
                        && swingInput[0] < swingInput[1] && swingInput[0] <= MIN(swingInput, CurrentBar - refTroughBar1[count] - 2)[1] && refTroughValue1[count] < 0 && refTroughValue1[count] < minValueOsc
                        && refTroughValue1[count] < MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1[count] - 6))[1] && (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1[count])[0] < 0))
                    {
line=5239;
                        bullishPDivMACD[0] = 1.0;
                        bullishTriggerCountMACDBB[0] = TriggerBars + 1;
                        firstTroughBar1 = refTroughBar1[count];
                        firstTroughLow1 = refTroughLow1[count];
                        firstOscTroughBar1 = refOscTroughBar1[count];
                        firstTroughValue1 = refTroughValue1[count];
                        secondTroughBar1 = CurrentBar;
                        secondTroughLow1 = swingInput[0];
                        secondOscTroughBar1 = minBarOsc;
                        secondTroughValue1 = minValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBullCandidateOsc1");
                            drawBullishDivCandidateOsc1 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBullCandidatePrice1");
                            drawBullishDivCandidatePrice1 = true;
                        }
                        if (ShowSetupDots)
                            drawBullSetup1 = true;
                        break;
                    }
                }
                for (int count = troughCount1 - 1; count >= 0; count--) //find largest divergence setup
                {
line=5267;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && Low[0] <= refTroughLow1[count]) || (!IncludeDoubleTopsAndBottoms && Low[0] < refTroughLow1[count]))
                        && Low[0] < Low[1] && Low[0] <= MIN(Low, CurrentBar - refTroughBar1[count] - 2)[1] && refTroughValue1[count] < 0 && refTroughValue1[count] < minValueOsc
                        && refTroughValue1[count] < MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1[count] - 6))[1] && (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1[count])[0] < 0))
                    {
                        replacementTroughBar1 = refTroughBar1[count];
                        replacementTroughLow1 = refTroughLow1[count];
                        replacementOscTroughBar1 = refOscTroughBar1[count];
                        replacementTroughValue1 = refTroughValue1[count];
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] <= refTroughLow1[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] < refTroughLow1[count]))
                        && swingInput[0] < swingInput[1] && swingInput[0] <= MIN(swingInput, CurrentBar - refTroughBar1[count] - 2)[1] && refTroughValue1[count] < 0 && refTroughValue1[count] < minValueOsc
                        && refTroughValue1[count] < MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1[count] - 6))[1] && (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1[count])[0] < 0))
                    {
                        replacementTroughBar1 = refTroughBar1[count];
                        replacementTroughLow1 = refTroughLow1[count];
                        replacementOscTroughBar1 = refOscTroughBar1[count];
                        replacementTroughValue1 = refTroughValue1[count];
                        break;
                    }
                }

                if (bullishPDivMACD[0] < 0.5)
                {
line=5292;
                    if (bullishTriggerCountMACDBB[1] > 0)
                    {
                        bullishTriggerCountMACDBB[0] = bullishTriggerCountMACDBB[1] - 1;
                        if (BBMACD[0] < priorSecondTroughValue1)
                        {
                            if (BBMACD[0] > priorFirstTroughValue1)
                            {
line=5300;
                                secondOscTroughBar1 = CurrentBar;
                                secondTroughValue1 = BBMACD[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBullCandidateOsc1");
                                    updateBullishDivCandidateOsc1 = true;
                                }
                            }
                            else if (BBMACD[0] > priorReplacementTroughValue1)
                            {
line=5311;
                                firstTroughBar1 = replacementTroughBar1;
                                firstTroughLow1 = replacementTroughLow1;
                                firstOscTroughBar1 = replacementOscTroughBar1;
                                firstTroughValue1 = replacementTroughValue1;
                                secondOscTroughBar1 = CurrentBar;
                                secondTroughValue1 = BBMACD[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBullCandidateOsc1");
                                    drawBullishDivCandidateOsc1 = true;
                                    RemoveDrawObject("divBullCandidatePrice1");
                                    drawBullishDivCandidatePrice1 = true;
                                }
                            }
                            else
                                bullishTriggerCountMACDBB[0] = 0;
                        }
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low && bullishTriggerCountMACDBB[0] > 0 && Low[0] < MIN(Low, CurrentBar - firstTroughBar1)[1])
                        {
line=5331;
                            secondTroughBar1 = CurrentBar;
                            secondTroughLow1 = Low[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBullCandidatePrice1");
                                updateBullishDivCandidatePrice1 = true;
                            }
                        }
                        else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bullishTriggerCountMACDBB[0] > 0 && swingInput[0] < MIN(swingInput, CurrentBar - firstTroughBar1)[1])
                        {
line=5342;
                            secondTroughBar1 = CurrentBar;
                            secondTroughLow1 = swingInput[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBullCandidatePrice1");
                                updateBullishDivCandidatePrice1 = true;
                            }
                        }
                    }
                }

                if (bullishTriggerCountMACDBB[0] > 0)
                {
                    if ((Close[0] > Low[CurrentBar - secondTroughBar1]) && (BBMACD[0] > BBMACD[1]) && Close[0] > Open[0])
                    {
line=5358;
                        bullishCDivMACD[0] = 1.0;
                        bullishTriggerCountMACDBB[0] = 0;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                            drawBullishDivOnOsc1 = true;
                        if (ShowDivOnPricePanel)
                            drawBullishDivOnPrice1 = true;
                        if (showArrows)
                            drawArrowUp1 = true;
                        RemoveDrawObject("divBullCandidateOsc1");
                        RemoveDrawObject("divBullCandidatePrice1");

                        if (firstTroughBar1 != memfirstTroughBar1) cptBullMACDdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                        memfirstTroughBar1 = firstTroughBar1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBullMACDdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bullishMACDDivProjection[0] = cptBullMACDdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else
                        bullishCDivMACD[0] = 0.0;
                }
                else
                {
                    bullishCDivMACD[0] = 0.0;
                    {
                        RemoveDrawObject("divBullCandidateOsc1");
                        RemoveDrawObject("divBullCandidatePrice1");
                    }
                }
                #endregion

                #region Bullish Hidden divergences between price and BBMACD #HIDDENDIV
                if (hiddenbullishTriggerCountMACDBB[1] > 0)
                {
line=5391;
                    priorFirstTroughBar1H = firstTroughBar1H;
                    priorFirstOscTroughBar1H = firstOscTroughBar1H;
                    priorFirstTroughLow1H = firstTroughLow1H;
                    priorFirstTroughValue1H = firstTroughValue1H;
                    priorReplacementTroughLow1H = replacementTroughLow1H;
                    priorReplacementTroughValue1H = replacementTroughValue1H;
                    priorSecondTroughValue1H = secondTroughValue1H;
                    priorSecondTroughLow1H = secondTroughLow1H;

                    double refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[0] : swingInput[0];
                    if (refinput < firstTroughLow1H)
                    {
                        hiddenbullishTriggerCountMACDBB[0] = 0;
                        RemoveDrawObject("hiddendivBullCandidateOsc1");
                        RemoveDrawObject("hiddendivBullCandidatePrice1");
                    }
                }

                #region -- reset variables --
                drawBullishDivCandidateOsc1H = false;
                drawBullishDivCandidatePrice1H = false;
                updateBullishDivCandidateOsc1H = false;
                updateBullishDivCandidatePrice1H = false;
                drawBullSetup1H = false;
                drawBullishDivOnOsc1H = false;
                drawBullishDivOnPrice1H = false;
                drawArrowUp1H = false;
                firstTroughFound1H = false;
                troughCount1H = 0;
                #endregion

                #region -- get price low and osc low --
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
line=5426;
                    int j = 0;
                    if (swingLowType[i] < 0)
                    {
                        refTroughBar1H[troughCount1H] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refTroughLow1H[troughCount1H] = Low[i];
                        else
                            refTroughLow1H[troughCount1H] = swingInput[i];

                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 3) && BBMACD[j - 1] < BBMACD[j])
                                j = j - 1;
                            refOscTroughBar1H[troughCount1H] = CurrentBar - j;
                            refTroughValue1H[troughCount1H] = BBMACD[j];
                            troughCount1H++;
                        }
                        else
                        {
                            refOscTroughBar1H[troughCount1H] = CurrentBar - i;
                            refTroughValue1H[troughCount1H] = BBMACD[i];
                            troughCount1H++;
                        }

                    }
                    if ((UseLastSwingOnly && troughCount1H == 1) || troughCount1H == 9) break;
                }
                #endregion

                hiddenbullishPDivMACD[0] = 0.0;
                minBarOsc = UseOscHighLow && BBMACD[1] < BBMACD[0] ? CurrentBar - 1 : CurrentBar;
                minValueOsc = UseOscHighLow && BBMACD[1] < BBMACD[0] ? BBMACD[1] : BBMACD[0];

                for (int count = 0; count < troughCount1H; count++) //find smallest divergence setup
                {
line=5463;
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] >= refTroughLow1H[count]) ||
                        (!IncludeDoubleTopsAndBottoms && refinput[0] > refTroughLow1H[count])) &&
                        refinput[0] < refinput[1] &&
                        refinput[0] <= MIN(refinput, CurrentBar - refTroughBar1H[count] - 2)[1] &&
                        refTroughValue1H[count] < 0 &&
                        refTroughValue1H[count] > minValueOsc &&
                        refTroughValue1H[count] > MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1H[count] - 6))[1] &&
                        (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1H[count])[0] < 0))
                    {
line=5474;
                        hiddenbullishPDivMACD[0] = 1.0;
                        hiddenbullishTriggerCountMACDBB[0] = TriggerBars + 1;
                        firstTroughBar1H = refTroughBar1H[count];
                        firstTroughLow1H = refTroughLow1H[count];
                        firstOscTroughBar1H = refOscTroughBar1H[count];
                        firstTroughValue1H = refTroughValue1H[count];
                        secondTroughBar1H = CurrentBar;
                        secondTroughLow1H = refinput[0];
                        secondOscTroughBar1H = maxBarOsc;
                        secondTroughValue1H = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("hiddendivBullCandidateOsc1");
                            drawBullishDivCandidateOsc1H = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("hiddendivBullCandidatePrice1");
                            drawBullishDivCandidatePrice1H = true;
                        }
                        if (ShowSetupDots) drawBullSetup1H = true;
                        break;
                    }
                }

                for (int count = troughCount1H - 1; count >= 0; count--) //find largest divergence setup
                {
line=5502;
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] >= refTroughLow1H[count]) || (!IncludeDoubleTopsAndBottoms && refinput[0] > refTroughLow1H[count])) &&
                        refinput[0] < refinput[1] &&
                        refinput[0] <= MIN(refinput, CurrentBar - refTroughBar1H[count] - 2)[1] &&
                        refTroughValue1H[count] < 0 &&
                        refTroughValue1H[count] > minValueOsc &&
                        refTroughValue1H[count] > MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1H[count] - 6))[1] &&
                        (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1H[count])[0] < 0))
                    {
                        replacementTroughBar1H = refOscTroughBar1H[count];
                        replacementTroughLow1H = refTroughLow1H[count];
                        replacementOscTroughBar1H = refOscTroughBar1H[count];
                        replacementTroughValue1H = refTroughValue1H[count];
                        break;
                    }
                }

                inputref = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[0] : swingInput[0];
                if (hiddenbullishPDivMACD[0] < 0.5)
                {
line=5523;
                    if (hiddenbullishTriggerCountMACDBB[1] > 0)
                    {
                        hiddenbullishTriggerCountMACDBB[0] = hiddenbullishTriggerCountMACDBB[1] - 1;
                        if (inputref < priorSecondTroughLow1H)
                        {
                            if (inputref > priorFirstTroughLow1H)//price stays above
                            {
line=5531;
                                secondTroughBar1H = CurrentBar;
                                secondTroughLow1H = inputref;
                                if (!hidePlots && ShowDivOnPricePanel)
                                {
                                    RemoveDrawObject("hiddendivBullCandidatePrice1");
                                    updateBullishDivCandidatePrice1H = true;
                                }
                            }
                            else if (inputref > priorReplacementTroughLow1H)
                            {
line=5542;
                                firstTroughBar1H = replacementTroughBar1H;
                                firstTroughLow1H = replacementTroughLow1H;
                                firstOscTroughBar1H = replacementOscTroughBar1H;
                                firstTroughValue1H = replacementTroughValue1H;
                                secondTroughBar1H = CurrentBar;
                                secondTroughLow1H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBullCandidateOsc1");
                                    drawBullishDivCandidateOsc1H = true;
                                    RemoveDrawObject("hiddendivBullCandidatePrice1");
                                    drawBullishDivCandidatePrice1H = true;
                                }
                            }
                            else hiddenbullishTriggerCountMACDBB[0] = 0;
                        }
                        if (hiddenbullishTriggerCountMACDBB[0] > 0 && BBMACD[0] < MIN(BBMACD, CurrentBar - firstOscTroughBar1H)[1])
                        {
line=5561;
                            secondOscTroughBar1H = CurrentBar;
                            secondTroughValue1H = BBMACD[0];
                            if (ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBullCandidateOsc1");
                                updateBullishDivCandidateOsc1H = true;
                            }
                        }
                    }
                }

                if (hiddenbullishTriggerCountMACDBB[0] > 0)
                {
line=5575;
                    if ((Close[0] > Low[CurrentBar - secondTroughBar1H]) && (BBMACD[0] > BBMACD[1]) && Close[0] > Open[0])
                    {
                        hiddenbullishCDivMACD[0] = 1.0;
                        hiddenbullishTriggerCountMACDBB[0] = 0;
                        if (!hidePlots && ShowDivOnOscillatorPanel) drawBullishDivOnOsc1H = true;
                        if (ShowDivOnPricePanel) drawBullishDivOnPrice1H = true;
                        if (showArrows) drawArrowUp1H = true;
                        RemoveDrawObject("hiddendivBullCandidateOsc1");
                        RemoveDrawObject("hiddendivBullCandidatePrice1");

                        if (firstTroughBar1H != memfirstTroughBar1H) cptBullMACDhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                        memfirstTroughBar1H = firstTroughBar1H;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBullMACDhdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bullishMACDHiddenDivProjection[0] = cptBullMACDhdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else hiddenbullishCDivMACD[0] = 0.0;
                }
                else
                {
                    hiddenbullishCDivMACD[0] = 0.0;
                    RemoveDrawObject("hiddendivBullCandidateOsc1");
                    RemoveDrawObject("hiddendivBullCandidatePrice1");
                }
                #endregion

                #region Bearish divergences between price and histogram
                if (bearishTriggerCountHistogram[1] > 0)
                {
line=5604;
                    priorFirstPeakBar2 = firstPeakBar2;
                    priorFirstOscPeakBar2 = firstOscPeakBar2;
                    priorFirstPeakHigh2 = firstPeakHigh2;
                    priorFirstPeakValue2 = firstPeakValue2;
                    priorReplacementPeakValue2 = replacementPeakValue2;
                    priorSecondPeakValue2 = secondPeakValue2;
                    if (Histogram[0] > firstPeakValue2)
                    {
                        bearishTriggerCountHistogram[0] = 0;
                        RemoveDrawObject("divBearCandidateOsc2");
                        RemoveDrawObject("divBearCandidatePrice2");
                    }
                }
                bool drawBearishDivCandidateOsc2 = false;
                bool drawBearishDivCandidatePrice2 = false;
                bool updateBearishDivCandidateOsc2 = false;
                bool updateBearishDivCandidatePrice2 = false;
                bool drawBearSetup2 = false;
                bool drawBearishDivOnOsc2 = false;
                bool drawBearishDivOnPrice2 = false;
                bool drawArrowDown2 = false;
                bool firstPeakFound2 = false;
                peakCount2 = 0;
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
line=5630;
                    int j = 0;
                    if (swingHighType[i] > 0)
                    {
                        refPeakBar2[peakCount2] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refPeakHigh2[peakCount2] = High[i];
                        else
                            refPeakHigh2[peakCount2] = swingInput[i];
                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 4) && Histogram[j - 1] > Histogram[j])
                                j = j - 1;
                            refOscPeakBar2[peakCount2] = CurrentBar - j;
                            refPeakValue2[peakCount2] = Histogram[j];
                            peakCount2 = peakCount2 + 1;
                        }
                        else
                        {
                            refOscPeakBar2[peakCount2] = CurrentBar - i;
                            refPeakValue2[peakCount2] = Histogram[i];
                            peakCount2 = peakCount2 + 1;
                        }

                    }
                    if ((UseLastSwingOnly && peakCount2 == 1) || peakCount2 == 9)
                        break;
                }
                bearishPDivHistogram[0] = 0.0;
line=5660;
                if (UseOscHighLow && Histogram[1] > Histogram[0])
                {
                    maxBarOsc = CurrentBar - 1;
                    maxValueOsc = Histogram[1];
                }
                else
                {
                    maxBarOsc = CurrentBar;
                    maxValueOsc = Histogram[0];
                }
                for (int count = 0; count < peakCount2; count++) //find smallest divergence setup
                {
line=5673;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && High[0] >= refPeakHigh2[count]) || (!IncludeDoubleTopsAndBottoms && High[0] > refPeakHigh2[count]))
                        && High[0] > High[1] && High[0] >= MAX(High, CurrentBar - refPeakBar2[count] - 2)[1] && refPeakValue2[count] > 0 && refPeakValue2[count] > maxValueOsc
                        && refPeakValue2[count] > MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2[count] - 6))[1] && (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2[count])[0] > 0))
                    {
                        bearishPDivHistogram[0] = 1.0;
                        bearishTriggerCountHistogram[0] = TriggerBars + 1;
                        firstPeakBar2 = refPeakBar2[count];
                        firstPeakHigh2 = refPeakHigh2[count];
                        firstOscPeakBar2 = refOscPeakBar2[count];
                        firstPeakValue2 = refPeakValue2[count];
                        secondPeakBar2 = CurrentBar;
                        secondPeakHigh2 = High[0];
                        secondOscPeakBar2 = maxBarOsc;
                        secondPeakValue2 = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBearCandidateOsc2");
                            drawBearishDivCandidateOsc2 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBearCandidatePrice2");
                            drawBearishDivCandidatePrice2 = true;
                        }
                        if (ShowSetupDots)
                            drawBearSetup2 = true;
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] >= refPeakHigh2[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] > refPeakHigh2[count]))
                        && swingInput[0] > swingInput[1] && swingInput[0] >= MAX(swingInput, CurrentBar - refPeakBar2[count] - 2)[1] && refPeakValue2[count] > 0 && refPeakValue2[count] > maxValueOsc
                        && refPeakValue2[count] > MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2[count] - 6))[1] && (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2[count])[0] > 0))
                    {
line=5706;
                        bearishPDivHistogram[0] = 1.0;
                        bearishTriggerCountHistogram[0] = TriggerBars + 1;
                        firstPeakBar2 = refPeakBar2[count];
                        firstPeakHigh2 = refPeakHigh2[count];
                        firstOscPeakBar2 = refOscPeakBar2[count];
                        firstPeakValue2 = refPeakValue2[count];
                        secondPeakBar2 = CurrentBar;
                        secondPeakHigh2 = swingInput[0];
                        secondOscPeakBar2 = maxBarOsc;
                        secondPeakValue2 = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBearCandidateOsc2");
                            drawBearishDivCandidateOsc2 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBearCandidatePrice2");
                            drawBearishDivCandidatePrice2 = true;
                        }
                        if (ShowSetupDots)
                            drawBearSetup2 = true;
                        break;
                    }
                }
                for (int count = peakCount2 - 1; count >= 0; count--) //find largest divergence setup
                {
line=5734;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && High[0] >= refPeakHigh2[count]) || (!IncludeDoubleTopsAndBottoms && High[0] > refPeakHigh2[count]))
                        && High[0] > High[1] && High[0] >= MAX(High, CurrentBar - refPeakBar2[count] - 2)[1] && refPeakValue2[count] > 0 && refPeakValue2[count] > maxValueOsc
                        && refPeakValue2[count] > MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2[count] - 6))[1] && (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2[count])[0] > 0))
                    {
                        replacementPeakBar2 = refPeakBar2[count];
                        replacementPeakHigh2 = refPeakHigh2[count];
                        replacementOscPeakBar2 = refOscPeakBar2[count];
                        replacementPeakValue2 = refPeakValue2[count];
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] >= refPeakHigh2[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] > refPeakHigh2[count]))
                        && swingInput[0] > swingInput[1] && swingInput[0] >= MAX(swingInput, CurrentBar - refPeakBar2[count] - 2)[1] && refPeakValue2[count] > 0 && refPeakValue2[count] > maxValueOsc
                        && refPeakValue2[count] > MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2[count] - 6))[1] && (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2[count])[0] > 0))
                    {
                        replacementPeakBar2 = refPeakBar2[count];
                        replacementPeakHigh2 = refPeakHigh2[count];
                        replacementOscPeakBar2 = refOscPeakBar2[count];
                        replacementPeakValue2 = refPeakValue2[count];
                        break;
                    }
                }
                if (bearishPDivHistogram[0] < 0.5)
                {
line=5758;
                    if (bearishTriggerCountHistogram[1] > 0)
                    {
                        bearishTriggerCountHistogram[0] = bearishTriggerCountHistogram[1] - 1;
                        if (Histogram[0] > priorSecondPeakValue2)
                        {
                            if (Histogram[0] < priorFirstPeakValue2)
                            {
line=5766;
                                secondOscPeakBar2 = CurrentBar;
                                secondPeakValue2 = Histogram[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBearCandidateOsc2");
                                    updateBearishDivCandidateOsc2 = true;
                                }
                            }
                            else if (Histogram[0] < priorReplacementPeakValue2)
                            {
line=5777;
                                firstPeakBar2 = replacementPeakBar2;
                                firstPeakHigh2 = replacementPeakHigh2;
                                firstOscPeakBar2 = replacementOscPeakBar2;
                                firstPeakValue2 = replacementPeakValue2;
                                secondOscPeakBar2 = CurrentBar;
                                secondPeakValue2 = Histogram[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBearCandidateOsc2");
                                    drawBearishDivCandidateOsc2 = true;
                                    RemoveDrawObject("divBearCandidatePrice2");
                                    drawBearishDivCandidatePrice2 = true;
                                }
                            }
                            else
                                bearishTriggerCountHistogram[0] = 0;
                        }
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low && bearishTriggerCountHistogram[0] > 0 && High[0] > MAX(High, CurrentBar - firstPeakBar2)[1])
                        {
line=5797;
                            secondPeakBar2 = CurrentBar;
                            secondPeakHigh2 = High[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBearCandidatePrice2");
                                updateBearishDivCandidatePrice2 = true;
                            }
                        }
                        else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bearishTriggerCountHistogram[0] > 0 && swingInput[0] > MAX(swingInput, CurrentBar - firstPeakBar2)[1])
                        {
line=5808;
                            secondPeakBar2 = CurrentBar;
                            secondPeakHigh2 = swingInput[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBearCandidatePrice2");
                                updateBearishDivCandidatePrice2 = true;
                            }
                        }
                    }
                }

                if (bearishTriggerCountHistogram[0] > 0)
                {
                    if ((Close[0] < High[CurrentBar - secondPeakBar2]) && (Histogram[0] < Histogram[1]) && Close[0] < Open[0])
                    {
line=5824;
                        bearishCDivHistogram[0] = 1.0;
                        bearishTriggerCountHistogram[0] = 0;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                            drawBearishDivOnOsc2 = true;
                        if (ShowDivOnPricePanel)
                            drawBearishDivOnPrice2 = true;
                        if (showArrows)
                            drawArrowDown2 = true;
                        RemoveDrawObject("divBearCandidateOsc2");
                        RemoveDrawObject("divBearCandidatePrice2");

                        if (firstPeakBar2 != memfirstPeakBar2) cptBearHistogramdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                        memfirstPeakBar2 = firstPeakBar2;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBearHistogramdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bearishHistogramDivProjection[0] = cptBearHistogramdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else
                        bearishCDivHistogram[0] = 0.0;
                }
                else
                {
                    bearishCDivHistogram[0] = 0.0;
                    {
                        RemoveDrawObject("divBearCandidateOsc2");
                        RemoveDrawObject("divBearCandidatePrice2");
                    }
                }
                #endregion

                #region Bearish Hidden divergences between price and Histogram #HIDDENDIV
                if (hiddenbearishTriggerCountHistogram[1] > 0)
                {
line=5857;
                    priorFirstPeakBar2H = firstPeakBar2H;
                    priorFirstOscPeakBar2H = firstOscPeakBar2H;
                    priorFirstPeakHigh2H = firstPeakHigh2H;
                    priorFirstPeakValue2H = firstPeakValue2H;
                    priorReplacementPeakHigh2H = replacementPeakHigh2H;
                    priorReplacementPeakValue2H = replacementPeakValue2H;
                    priorSecondPeakValue2H = secondPeakValue2H;
                    priorSecondPeakHigh2H = secondPeakHigh2H;

                    double refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[0] : swingInput[0];
                    if (refinput > firstPeakHigh2H)
                    {
                        hiddenbearishTriggerCountHistogram[0] = 0;
                        RemoveDrawObject("hiddendivBearCandidateOsc2");
                        RemoveDrawObject("hiddendivBearCandidatePrice2");
                    }
                }

                #region -- reset variables --
                drawBearishDivCandidateOsc2H = false;
                drawBearishDivCandidatePrice2H = false;
                updateBearishDivCandidateOsc2H = false;
                updateBearishDivCandidatePrice2H = false;
                drawBearSetup2H = false;
                drawBearishDivOnOsc2H = false;
                drawBearishDivOnPrice2H = false;
                drawArrowDown2H = false;
                firstPeakFound2H = false;
                peakCount2H = 0;
                #endregion

                #region -- get price top and osc top --
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
line=5892;
                    int j = 0;
                    if (swingHighType[i] > 0)
                    {
                        refPeakBar2H[peakCount2H] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refPeakHigh2H[peakCount2H] = High[i];
                        else
                            refPeakHigh2H[peakCount2H] = swingInput[i];

                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 4) && Histogram[j - 1] > Histogram[j])
                                j = j - 1;
                            refOscPeakBar2H[peakCount2H] = CurrentBar - j;
                            refPeakValue2H[peakCount2H] = Histogram[j];
                            peakCount2H = peakCount2H + 1;
                        }
                        else
                        {
                            refOscPeakBar2H[peakCount2H] = CurrentBar - i;
                            refPeakValue2H[peakCount2H] = Histogram[i];
                            peakCount2H = peakCount2H + 1;
                        }

                    }
                    if ((UseLastSwingOnly && peakCount2H == 1) || peakCount2H == 9) break;
                }
                #endregion

                hiddenbearishPDivHistogram[0] = 0.0;
                maxBarOsc = UseOscHighLow && Histogram[1] > Histogram[0] ? CurrentBar - 1 : CurrentBar;
                maxValueOsc = UseOscHighLow && Histogram[1] > Histogram[0] ? Histogram[1] : Histogram[0];

                for (int count = 0; count < peakCount2H; count++) //find smallest divergence setup
                {
line=5929;
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] <= refPeakHigh2H[count]) ||
                        (!IncludeDoubleTopsAndBottoms && refinput[0] < refPeakHigh2H[count])) &&
                        refinput[0] > refinput[1] &&
                        refinput[0] >= MAX(refinput, CurrentBar - refPeakBar2H[count] - 2)[1] &&
                        refPeakValue2H[count] > 0 &&
                        refPeakValue2H[count] < maxValueOsc &&
                        refPeakValue2H[count] < MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2H[count] - 6))[1] &&
                        (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2H[count])[0] > 0))
                    {
                        hiddenbearishPDivHistogram[0] = 1.0;
                        hiddenbearishTriggerCountHistogram[0] = TriggerBars + 1;
                        firstPeakBar2H = refPeakBar2H[count];
                        firstPeakHigh2H = refPeakHigh2H[count];
                        firstOscPeakBar2H = refOscPeakBar2H[count];
                        firstPeakValue2H = refPeakValue2H[count];
                        secondPeakBar2H = CurrentBar;
                        secondPeakHigh2H = refinput[0];
                        secondOscPeakBar2H = maxBarOsc;
                        secondPeakValue2H = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("hiddendivBearCandidateOsc2");
                            drawBearishDivCandidateOsc2H = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("hiddendivBearCandidatePrice2");
                            drawBearishDivCandidatePrice2H = true;
                        }
                        if (ShowSetupDots) drawBearSetup2H = true;
                        break;
                    }
                }

                for (int count = peakCount2H - 1; count >= 0; count--) //find largest divergence setup
                {
line=5967;
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] <= refPeakHigh2H[count]) || (!IncludeDoubleTopsAndBottoms && refinput[0] < refPeakHigh2H[count])) &&
                        refinput[0] > refinput[1] &&
                        refinput[0] >= MAX(refinput, CurrentBar - refPeakBar2H[count] - 2)[1] &&
                        refPeakValue2H[count] > 0 &&
                        refPeakValue2H[count] < maxValueOsc &&
                        refPeakValue2H[count] < MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2H[count] - 6))[1] &&
                        (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2H[count])[0] > 0))
                    {
                        replacementPeakBar2H = refPeakBar2H[count];
                        replacementPeakHigh2H = refPeakHigh2H[count];
                        replacementOscPeakBar2H = refOscPeakBar2H[count];
                        replacementPeakValue2H = refPeakValue2H[count];
                        break;
                    }
                }

                inputref = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[0] : swingInput[0];
                if (hiddenbearishPDivHistogram[0] < 0.5)
                {
line=5988;
                    if (hiddenbearishTriggerCountHistogram[1] > 0)
                    {
                        hiddenbearishTriggerCountHistogram[0] = hiddenbearishTriggerCountHistogram[1] - 1;
                        if (inputref > priorSecondPeakHigh2H)
                        {
                            if (inputref < priorFirstPeakHigh2H)//price stays below
                            {
                                secondPeakBar2H = CurrentBar;
                                secondPeakHigh2H = inputref;
                                if (!hidePlots && ShowDivOnPricePanel)
                                {
                                    RemoveDrawObject("hiddendivBearCandidatePrice2");
                                    updateBearishDivCandidatePrice2H = true;
                                }
                            }
                            else if (inputref < priorReplacementPeakHigh2H)
                            {
                                firstPeakBar2H = replacementPeakBar2H;
                                firstPeakHigh2H = replacementPeakHigh2H;
                                firstOscPeakBar2H = replacementOscPeakBar2H;
                                firstPeakValue2H = replacementPeakValue2H;
                                secondPeakBar2H = CurrentBar;
                                secondPeakHigh2H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBearCandidateOsc2");
                                    drawBearishDivCandidateOsc2H = true;
                                    RemoveDrawObject("hiddendivBearCandidatePrice2");
                                    drawBearishDivCandidatePrice2H = true;
                                }
                            }
                            else
                                hiddenbearishTriggerCountHistogram[0] = 0;
                        }
                        if (hiddenbearishTriggerCountHistogram[0] > 0 && Histogram[0] > MAX(Histogram, CurrentBar - firstOscPeakBar2H)[1])
                        {
                            secondOscPeakBar2H = CurrentBar;
                            secondPeakValue2H = Histogram[0];
                            if (ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBearCandidateOsc2");
                                updateBearishDivCandidateOsc2H = true;
                            }
                        }
                    }
                }

line=6036;
                if (hiddenbearishTriggerCountHistogram[0] > 0)
                {
                    if ((Close[0] < High[CurrentBar - secondPeakBar2H]) && (Histogram[0] < Histogram[1]) && Close[0] < Open[0])
                    {
                        hiddenbearishCDivHistogram[0] = 1.0;
                        hiddenbearishTriggerCountHistogram[0] = 0;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                            drawBearishDivOnOsc2H = true;
                        if (ShowDivOnPricePanel)
                            drawBearishDivOnPrice2H = true;
                        if (showArrows)
                            drawArrowDown2H = true;
                        RemoveDrawObject("hiddendivBearCandidateOsc2");
                        RemoveDrawObject("hiddendivBearCandidatePrice2");

                        if (firstPeakBar2H != memfirstPeakBar2H) cptBearHistogramhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                        memfirstPeakBar2H = firstPeakBar2H;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBearHistogramhdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bearishHistogramHiddenDivProjection[0] = cptBearHistogramhdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else hiddenbearishCDivHistogram[0] = 0.0;
                }
                else
                {
                    hiddenbearishCDivHistogram[0] = 0.0;
                    RemoveDrawObject("hiddendivBearCandidateOsc2");
                    RemoveDrawObject("hiddendivBearCandidatePrice2");
                }
                #endregion

line=6067;
                #region Bullish divergences between price and histogram
                if (bullishTriggerCountHistogram[1] > 0)
                {
                    priorFirstTroughBar2 = firstTroughBar2;
                    priorFirstOscTroughBar2 = firstOscTroughBar2;
                    priorFirstTroughLow2 = firstTroughLow2;
                    priorFirstTroughValue2 = firstTroughValue2;
                    priorReplacementTroughValue2 = replacementTroughValue2;
                    priorSecondTroughValue2 = secondTroughValue2;
                    if (Histogram[0] < firstTroughValue2)
                    {
                        bullishTriggerCountHistogram[0] = 0;
                        RemoveDrawObject("divBullCandidateOsc2");
                        RemoveDrawObject("divBullCandidatePrice2");
                    }
                }
                bool drawBullishDivCandidateOsc2 = false;
                bool drawBullishDivCandidatePrice2 = false;
                bool updateBullishDivCandidateOsc2 = false;
                bool updateBullishDivCandidatePrice2 = false;
                bool drawBullSetup2 = false;
                bool drawBullishDivOnOsc2 = false;
                bool drawBullishDivOnPrice2 = false;
                bool drawArrowUp2 = false;
                bool firstTroughFound2 = false;
                troughCount2 = 0;
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
line=6096;
                    int j = 0;
                    if (swingLowType[i] < 0)
                    {
                        refTroughBar2[troughCount2] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refTroughLow2[troughCount2] = Low[i];
                        else
                            refTroughLow2[troughCount2] = swingInput[i];
                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 3) && Histogram[j - 1] < Histogram[j])
                                j = j - 1;
                            refOscTroughBar2[troughCount2] = CurrentBar - j;
                            refTroughValue2[troughCount2] = Histogram[j];
                            troughCount2 = troughCount2 + 1;
                        }
                        else
                        {
                            refOscTroughBar2[troughCount2] = CurrentBar - i;
                            refTroughValue2[troughCount2] = Histogram[i];
                            troughCount2 = troughCount2 + 1;
                        }
                    }
                    if ((UseLastSwingOnly && troughCount2 == 1) || troughCount2 == 9)
                        break;
                }
line=6124;
                bullishPDivHistogram[0] = 0.0;
                if (UseOscHighLow && Histogram[1] < Histogram[0])
                {
                    minBarOsc = CurrentBar - 1;
                    minValueOsc = Histogram[1];
                }
                else
                {
                    minBarOsc = CurrentBar;
                    minValueOsc = Histogram[0];
                }
                for (int count = 0; count < troughCount2; count++) //find smallest divergence setup
                {
line=6138;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && Low[0] <= refTroughLow2[count]) || (!IncludeDoubleTopsAndBottoms && Low[0] < refTroughLow2[count]))
                        && Low[0] < Low[1] && Low[0] <= MIN(Low, CurrentBar - refTroughBar2[count] - 2)[1] && refTroughValue2[count] < 0 && refTroughValue2[count] < minValueOsc
                        && refTroughValue2[count] < MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2[count] - 6))[1] && (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2[count])[0] < 0))
                    {
                        bullishPDivHistogram[0] = 1.0;
                        bullishTriggerCountHistogram[0] = TriggerBars + 1;
                        firstTroughBar2 = refTroughBar2[count];
                        firstTroughLow2 = refTroughLow2[count];
                        firstOscTroughBar2 = refOscTroughBar2[count];
                        firstTroughValue2 = refTroughValue2[count];
                        secondTroughBar2 = CurrentBar;
                        secondTroughLow2 = Low[0];
                        secondOscTroughBar2 = minBarOsc;
                        secondTroughValue2 = minValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBullCandidateOsc2");
                            drawBullishDivCandidateOsc2 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBullCandidatePrice2");
                            drawBullishDivCandidatePrice2 = true;
                        }
                        if (ShowSetupDots)
                            drawBullSetup2 = true;
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] <= refTroughLow2[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] < refTroughLow2[count]))
                        && swingInput[0] < swingInput[1] && swingInput[0] <= MIN(swingInput, CurrentBar - refTroughBar2[count] - 2)[1] && refTroughValue2[count] < 0 && refTroughValue2[count] < minValueOsc
                        && refTroughValue2[count] < MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2[count] - 6))[1] && (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2[count])[0] < 0))
                    {
                        bullishPDivHistogram[0] = 1.0;
                        bullishTriggerCountHistogram[0] = TriggerBars + 1;
                        firstTroughBar2 = refTroughBar2[count];
                        firstTroughLow2 = refTroughLow2[count];
                        firstOscTroughBar2 = refOscTroughBar2[count];
                        firstTroughValue2 = refTroughValue2[count];
                        secondTroughBar2 = CurrentBar;
                        secondTroughLow2 = swingInput[0];
                        secondOscTroughBar2 = minBarOsc;
                        secondTroughValue2 = minValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBullCandidateOsc2");
                            drawBullishDivCandidateOsc2 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBullCandidatePrice2");
                            drawBullishDivCandidatePrice2 = true;
                        }
                        if (ShowSetupDots)
                            drawBullSetup2 = true;
                        break;
                    }
                }
                for (int count = troughCount2 - 1; count >= 0; count--) //find largest divergence setup
                {
line=6198;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && Low[0] <= refTroughLow2[count]) || (!IncludeDoubleTopsAndBottoms && Low[0] < refTroughLow2[count]))
                        && Low[0] < Low[1] && Low[0] <= MIN(Low, CurrentBar - refTroughBar2[count] - 2)[1] && refTroughValue2[count] < 0 && refTroughValue2[count] < minValueOsc
                        && refTroughValue2[count] < MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2[count] - 6))[1] && (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2[count])[0] < 0))
                    {
                        replacementTroughBar2 = refTroughBar2[count];
                        replacementTroughLow2 = refTroughLow2[count];
                        replacementOscTroughBar2 = refOscTroughBar2[count];
                        replacementTroughValue2 = refTroughValue2[count];
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] <= refTroughLow2[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] < refTroughLow2[count]))
                        && swingInput[0] < swingInput[1] && swingInput[0] <= MIN(swingInput, CurrentBar - refTroughBar2[count] - 2)[1] && refTroughValue2[count] < 0 && refTroughValue2[count] < minValueOsc
                        && refTroughValue2[count] < MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2[count] - 6))[1] && (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2[count])[0] < 0))
                    {
                        replacementTroughBar2 = refTroughBar2[count];
                        replacementTroughLow2 = refTroughLow2[count];
                        replacementOscTroughBar2 = refOscTroughBar2[count];
                        replacementTroughValue2 = refTroughValue2[count];
                        break;
                    }
                }

                if (bullishPDivHistogram[0] < 0.5)
                {
line=6223;
                    if (bullishTriggerCountHistogram[1] > 0)
                    {
                        bullishTriggerCountHistogram[0] = bullishTriggerCountHistogram[1] - 1;
                        if (Histogram[0] < priorSecondTroughValue2)
                        {
                            if (Histogram[0] > priorFirstTroughValue2)
                            {
                                secondOscTroughBar2 = CurrentBar;
                                secondTroughValue2 = Histogram[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBullCandidateOsc2");
                                    updateBullishDivCandidateOsc2 = true;
                                }
                            }
                            else if (Histogram[0] > priorReplacementTroughValue2)
                            {
                                firstTroughBar2 = replacementTroughBar2;
                                firstTroughLow2 = replacementTroughLow2;
                                firstOscTroughBar2 = replacementOscTroughBar2;
                                firstTroughValue2 = replacementTroughValue2;
                                secondOscTroughBar2 = CurrentBar;
                                secondTroughValue2 = Histogram[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBullCandidateOsc2");
                                    drawBullishDivCandidateOsc2 = true;
                                    RemoveDrawObject("divBullCandidatePrice2");
                                    drawBullishDivCandidatePrice2 = true;
                                }
                            }
                            else
                                bullishTriggerCountHistogram[0] = 0;
                        }
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low && bullishTriggerCountHistogram[0] > 0 && Low[0] < MIN(Low, CurrentBar - firstTroughBar2)[1])
                        {
                            secondTroughBar2 = CurrentBar;
                            secondTroughLow2 = Low[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBullCandidatePrice2");
                                updateBullishDivCandidatePrice2 = true;
                            }
                        }
                        else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bullishTriggerCountHistogram[0] > 0 && swingInput[0] < MIN(swingInput, CurrentBar - firstTroughBar2)[1])
                        {
                            secondTroughBar2 = CurrentBar;
                            secondTroughLow2 = swingInput[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBullCandidatePrice2");
                                updateBullishDivCandidatePrice2 = true;
                            }
                        }
                    }
                }

                if (bullishTriggerCountHistogram[0] > 0)
                {
line=6283;
                    if ((Close[0] > Low[CurrentBar - secondTroughBar2]) && (Histogram[0] > Histogram[1]) && Close[0] > Open[0])
                    {
                        bullishCDivHistogram[0] = 1.0;
                        bullishTriggerCountHistogram[0] = 0;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                            drawBullishDivOnOsc2 = true;
                        if (ShowDivOnPricePanel)
                            drawBullishDivOnPrice2 = true;
                        if (showArrows)
                            drawArrowUp2 = true;
                        RemoveDrawObject("divBullCandidateOsc2");
                        RemoveDrawObject("divBullCandidatePrice2");

                        if (firstTroughBar2 != memfirstTroughBar2) cptBullHistogramdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                        memfirstTroughBar2 = firstTroughBar2;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBullHistogramdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bullishHistogramDivProjection[0] = cptBullHistogramdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else
                        bullishCDivHistogram[0] = 0.0;
                }
                else
                {
                    bullishCDivHistogram[0] = 0.0;
                    {
                        RemoveDrawObject("divBullCandidateOsc2");
                        RemoveDrawObject("divBullCandidatePrice2");
                    }
                }
                #endregion

                #region Bullish Hidden divergences between price and Histogram #HIDDENDIV
                if (hiddenbullishTriggerCountHistogram[1] > 0)
                {
                    priorFirstTroughBar2H = firstTroughBar2H;
                    priorFirstOscTroughBar2H = firstOscTroughBar2H;
                    priorFirstTroughLow2H = firstTroughLow2H;
                    priorFirstTroughValue2H = firstTroughValue2H;
                    priorReplacementTroughLow2H = replacementTroughLow2H;
                    priorReplacementTroughValue2H = replacementTroughValue2H;
                    priorSecondTroughValue2H = secondTroughValue2H;
                    priorSecondTroughLow2H = secondTroughLow2H;

                    double refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[0] : swingInput[0];
                    if (refinput < firstTroughLow2H)
                    {
                        hiddenbullishTriggerCountHistogram[0] = 0;
                        RemoveDrawObject("hiddendivBullCandidateOsc2");
                        RemoveDrawObject("hiddendivBullCandidatePrice2");
                    }
                }

                #region -- reset variables --
                drawBullishDivCandidateOsc2H = false;
                drawBullishDivCandidatePrice2H = false;
                updateBullishDivCandidateOsc2H = false;
                updateBullishDivCandidatePrice2H = false;
                drawBullSetup2H = false;
                drawBullishDivOnOsc2H = false;
                drawBullishDivOnPrice2H = false;
                drawArrowUp2H = false;
                firstTroughFound2H = false;
                troughCount2H = 0;
                #endregion

                #region -- get price top and osc top --
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
line=6352;
                    int j = 0;
                    if (swingLowType[i] < 0)
                    {
                        refTroughBar2H[troughCount2H] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refTroughLow2H[troughCount2H] = Low[i];
                        else
                            refTroughLow2H[troughCount2H] = swingInput[i];

                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 3) && Histogram[j - 1] < Histogram[j])
                                j = j - 1;
                            refOscTroughBar2H[troughCount2H] = CurrentBar - j;
                            refTroughValue2H[troughCount2H] = Histogram[j];
                            troughCount2H++;
                        }
                        else
                        {
                            refOscTroughBar2H[troughCount2H] = CurrentBar - i;
                            refTroughValue2H[troughCount2H] = Histogram[i];
                            troughCount2H++;
                        }

                    }
                    if ((UseLastSwingOnly && troughCount2H == 1) || troughCount2H == 9) break;
                }
                #endregion

                hiddenbullishPDivHistogram[0] = 0.0;
                minBarOsc = UseOscHighLow && Histogram[1] < Histogram[0] ? CurrentBar - 1 : CurrentBar;
                minValueOsc = UseOscHighLow && Histogram[1] < Histogram[0] ? Histogram[1] : Histogram[0];

                for (int count = 0; count < troughCount2H; count++) //find smallest divergence setup
                {
line=6389;
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] >= refTroughLow2H[count]) ||
                        (!IncludeDoubleTopsAndBottoms && refinput[0] > refTroughLow2H[count])) &&
                        refinput[0] < refinput[1] &&
                        refinput[0] <= MIN(refinput, CurrentBar - refTroughBar2H[count] - 2)[1] &&
                        refTroughValue2H[count] < 0 &&
                        refTroughValue2H[count] > minValueOsc &&
                        refTroughValue2H[count] > MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2H[count] - 6))[1] &&
                        (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2H[count])[0] < 0))
                    {
                        hiddenbullishPDivHistogram[0] = 1.0;
                        hiddenbullishTriggerCountHistogram[0] = TriggerBars + 1;
                        firstTroughBar2H = refTroughBar2H[count];
                        firstTroughLow2H = refTroughLow2H[count];
                        firstOscTroughBar2H = refOscTroughBar2H[count];
                        firstTroughValue2H = refTroughValue2H[count];
                        secondTroughBar2H = CurrentBar;
                        secondTroughLow2H = refinput[0];
                        secondOscTroughBar2H = maxBarOsc;
                        secondTroughValue2H = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("hiddendivBullCandidateOsc2");
                            drawBullishDivCandidateOsc2H = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("hiddendivBullCandidatePrice2");
                            drawBullishDivCandidatePrice2H = true;
                        }
                        if (ShowSetupDots) drawBullSetup2H = true;
                        break;
                    }
                }

                for (int count = troughCount2H - 1; count >= 0; count--) //find largest divergence setup
                {
line=6427;
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] >= refTroughLow2H[count]) || (!IncludeDoubleTopsAndBottoms && refinput[0] > refTroughLow2H[count])) &&
                        refinput[0] < refinput[1] &&
                        refinput[0] <= MIN(refinput, CurrentBar - refTroughBar2H[count] - 2)[1] &&
                        refTroughValue2H[count] < 0 &&
                        refTroughValue2H[count] > minValueOsc &&
                        refTroughValue2H[count] > MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2H[count] - 6))[1] &&
                        (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2H[count])[0] < 0))
                    {
                        replacementTroughBar2H = refOscTroughBar2H[count];
                        replacementTroughLow2H = refTroughLow2H[count];
                        replacementOscTroughBar2H = refOscTroughBar2H[count];
                        replacementTroughValue2H = refTroughValue2H[count];
                        break;
                    }
                }

                inputref = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[0] : swingInput[0];
                if (hiddenbullishPDivHistogram[0] < 0.5)
                {
line=6448;
                    if (hiddenbullishTriggerCountHistogram[1] > 0)
                    {
                        hiddenbullishTriggerCountHistogram[0] = hiddenbullishTriggerCountHistogram[1] - 1;
                        if (inputref < priorSecondTroughLow2H)
                        {
                            if (inputref > priorFirstTroughLow2H)//price stays above
                            {
                                secondTroughBar2H = CurrentBar;
                                secondTroughLow2H = inputref;
                                if (!hidePlots && ShowDivOnPricePanel)
                                {
                                    RemoveDrawObject("hiddendivBullCandidatePrice2");
                                    updateBullishDivCandidatePrice2H = true;
                                }
                            }
                            else if (inputref > priorReplacementTroughLow2H)
                            {
                                firstTroughBar2H = replacementTroughBar2H;
                                firstTroughLow2H = replacementTroughLow2H;
                                firstOscTroughBar2H = replacementOscTroughBar2H;
                                firstTroughValue2H = replacementTroughValue2H;
                                secondTroughBar2H = CurrentBar;
                                secondTroughLow2H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBullCandidateOsc2");
                                    drawBullishDivCandidateOsc2H = true;
                                    RemoveDrawObject("hiddendivBullCandidatePrice2");
                                    drawBullishDivCandidatePrice2H = true;
                                }
                            }
                            else
                                hiddenbullishTriggerCountHistogram[0] = 0;
                        }
                        if (hiddenbullishTriggerCountHistogram[0] > 0 && Histogram[0] < MIN(Histogram, CurrentBar - firstOscTroughBar2H)[1])
                        {
                            secondOscTroughBar2H = CurrentBar;
                            secondTroughValue2H = Histogram[0];
                            if (ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBullCandidateOsc2");
                                updateBullishDivCandidateOsc2H = true;
                            }
                        }
                    }
                }

                if (hiddenbullishTriggerCountHistogram[0] > 0)
                {
line=6498;
                    if ((Close[0] > Low[CurrentBar - secondTroughBar2H]) && (Histogram[0] > Histogram[1]) && Close[0] > Open[0])
                    {
                        hiddenbullishCDivHistogram[0] = 1.0;
                        hiddenbullishTriggerCountHistogram[0] = 0;
                        if (!hidePlots && ShowDivOnOscillatorPanel) drawBullishDivOnOsc2H = true;
                        if (ShowDivOnPricePanel) drawBullishDivOnPrice2H = true;
                        if (showArrows) drawArrowUp2H = true;
                        RemoveDrawObject("hiddendivBullCandidateOsc2");
                        RemoveDrawObject("hiddendivBullCandidatePrice2");

                        if (firstTroughBar2H != memfirstTroughBar2H) cptBullHistogramhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                        memfirstTroughBar2H = firstTroughBar2H;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBullHistogramhdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bullishHistogramHiddenDivProjection[0] = cptBullHistogramhdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else hiddenbullishCDivHistogram[0] = 0.0;
                }
                else
                {
                    hiddenbullishCDivHistogram[0] = 0.0;
                    RemoveDrawObject("hiddendivBullCandidateOsc2");
                    RemoveDrawObject("hiddendivBullCandidatePrice2");
                }
                #endregion

                #region -- draw --
                if (drawObjectsEnabled)
                {
                    bearishDivPlotSeriesMACDBB[0] = 0;
                    bullishDivPlotSeriesMACDBB[0] = 0;
                    bearishDivPlotSeriesHistogram[0] = 0;
                    bullishDivPlotSeriesHistogram[0] = 0;
                    hiddenbearishDivPlotSeriesMACDBB[0] = 0;//#HIDDENDIV
                    hiddenbullishDivPlotSeriesMACDBB[0] = 0; ;//#HIDDENDIV
                    hiddenbearishDivPlotSeriesHistogram[0] = 0;//#HIDDENDIV
                    hiddenbullishDivPlotSeriesHistogram[0] = 0;//#HIDDENDIV

                    DrawOnPricePanel = false;
                    #region -- MACD div --
                    if (PrintMarkers && !hidePlots && ShowDivOnOscillatorPanel && ShowOscillatorDivergences)
                    {
line=6540;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearishDivergenceOP1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullishDivergenceOP1{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{
    	                    if (drawBearishDivCandidateOsc1)
        	                    TriggerCustomEvent(e1=>{ Draw.Line(this, "divBearCandidateOsc1", false, CurrentBar - firstOscPeakBar1, firstPeakValue1, CurrentBar - secondOscPeakBar1, secondPeakValue1, BearColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
            	            if (updateBearishDivCandidateOsc1)
                	            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBearCandidateOsc1", false, CurrentBar - priorFirstOscPeakBar1, priorFirstPeakValue1, CurrentBar - secondOscPeakBar1, secondPeakValue1, BearColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (drawBearishDivOnOsc1)
    	                    {
line=6552;
        	                    if (showBox)
            	                    bearishDivPlotSeriesMACDBB[CurrentBar - secondOscPeakBar1] = secondOscPeakBar1 - firstOscPeakBar1;
                	            else{
           	        	            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("BearishDivergenceOP1{0}", secondPeakBar1), false, CurrentBar - firstOscPeakBar1, firstPeakValue1, CurrentBar - secondOscPeakBar1, secondPeakValue1, BearColor1, DashStyleHelper.Solid, DivWidth1);},0,null);
								}
                        	}

	   	                    if (drawBullishDivCandidateOsc1)
	       	                    TriggerCustomEvent(e1=>{ Draw.Line(this, "divBullCandidateOsc1", false, CurrentBar - firstOscTroughBar1, firstTroughValue1, CurrentBar - secondOscTroughBar1, secondTroughValue1, BullColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	           	            if (updateBullishDivCandidateOsc1)
	               	            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBullCandidateOsc1", false, CurrentBar - priorFirstOscTroughBar1, priorFirstTroughValue1, CurrentBar - secondOscTroughBar1, secondTroughValue1, BullColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (drawBullishDivOnOsc1)
	   	                    {
	       	                    if (showBox)
	           	                    bullishDivPlotSeriesMACDBB[CurrentBar - secondOscTroughBar1] = secondOscTroughBar1 - firstOscTroughBar1;
	               	            else{
          	        	            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("BullishDivergenceOP1{0}", secondTroughBar1), false, CurrentBar - firstOscTroughBar1, firstTroughValue1, CurrentBar - secondOscTroughBar1, secondTroughValue1, BullColor1, DashStyleHelper.Solid, DivWidth1);},0,null);
								}
	                        }
						//},0,null);
                    }
                    #endregion

                    #region -- MACD hidden div --
                    if (PrintMarkers && !hidePlots && ShowDivOnOscillatorPanel && ShowOscillatorHiddenDivergences)
                    {
line=6579;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearishDivergenceOP1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullishDivergenceOP1{0}",cutoffIdx));
						}
                        //Bearish
						//TriggerCustomEvent(o1 =>{	
							if (drawBearishDivCandidateOsc1H)
							    TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBearCandidateOsc1", false, CurrentBar - firstOscPeakBar1H, firstPeakValue1H, CurrentBar - secondOscPeakBar1H, secondPeakValue1H, HiddenBearColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
							if (updateBearishDivCandidateOsc1H)
							    TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBearCandidateOsc1", false, CurrentBar - priorFirstOscPeakBar1H, priorFirstPeakValue1H, CurrentBar - secondOscPeakBar1H, secondPeakValue1H, HiddenBearColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
							if (drawBearishDivOnOsc1H)
							{
							    if (showBox)
							        hiddenbearishDivPlotSeriesMACDBB[CurrentBar - secondOscPeakBar1H] = secondOscPeakBar1H - firstOscPeakBar1H;
							    else{
							        TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("hiddenBearishDivergenceOP1{0}", secondPeakBar1H), false, CurrentBar - firstOscPeakBar1H, firstPeakValue1H, CurrentBar - secondOscPeakBar1H, secondPeakValue1H, HiddenBearColor1, DashStyleHelper.Solid, HiddenDivWidth1);},0,null);
								}
							}
							//-------
							//Bullish
							if (drawBullishDivCandidateOsc1H)
							    TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBullCandidateOsc1", false, CurrentBar - firstOscTroughBar1H, firstTroughValue1H, CurrentBar - secondOscTroughBar1H, secondTroughValue1H, HiddenBullColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
							if (updateBullishDivCandidateOsc1H)
							    TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBullCandidateOsc1", false, CurrentBar - priorFirstOscTroughBar1H, priorFirstTroughValue1H, CurrentBar - secondOscTroughBar1H, secondTroughValue1H, HiddenBullColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
							if (drawBullishDivOnOsc1H)
							{
							    if (showBox)
							        hiddenbullishDivPlotSeriesMACDBB[CurrentBar - secondOscTroughBar1H] = secondOscTroughBar1H - firstOscTroughBar1H;
							    else{
							        TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("hiddenBullishDivergenceOP1{0}", secondTroughBar1H), false, CurrentBar - firstOscTroughBar1H, firstTroughValue1H, CurrentBar - secondOscTroughBar1H, secondTroughValue1H, HiddenBullColor1, DashStyleHelper.Solid, HiddenDivWidth1);},0,null);
								}
							}
						//},0,null);
                    }
                    #endregion

                    #region -- Histo div --
                    if (PrintMarkers && !hidePlots && ShowDivOnOscillatorPanel && ShowHistogramDivergences)
                    {
line=6619;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearishDivergenceOP2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullishDivergenceOP2{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidateOsc2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBearCandidateOsc2", false, CurrentBar - firstOscPeakBar2, firstPeakValue2, CurrentBar - secondOscPeakBar2, secondPeakValue2, BearColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (updateBearishDivCandidateOsc2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBearCandidateOsc2", false, CurrentBar - priorFirstOscPeakBar2, priorFirstPeakValue2, CurrentBar - secondOscPeakBar2, secondPeakValue2, BearColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (drawBearishDivOnOsc2)
	                        {
	                            if (showBox)
	                                bearishDivPlotSeriesHistogram[CurrentBar - secondOscPeakBar2] = secondOscPeakBar2 - firstOscPeakBar2;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("BearishDivergenceOP2{0}", secondPeakBar2), false, CurrentBar - firstOscPeakBar2, firstPeakValue2, CurrentBar - secondOscPeakBar2, secondPeakValue2, BearColor2, DashStyleHelper.Solid, DivWidth2);},0,null);
								}
	                        }
	                        if (drawBullishDivCandidateOsc2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBullCandidateOsc2", false, CurrentBar - firstOscTroughBar2, firstTroughValue2, CurrentBar - secondOscTroughBar2, secondTroughValue2, BullColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (updateBullishDivCandidateOsc2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBullCandidateOsc2", false, CurrentBar - priorFirstOscTroughBar2, priorFirstTroughValue2, CurrentBar - secondOscTroughBar2, secondTroughValue2, BullColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (drawBullishDivOnOsc2)
	                        {
	                            if (showBox)
	                                bullishDivPlotSeriesHistogram[CurrentBar - secondOscTroughBar2] = secondOscTroughBar2 - firstOscTroughBar2;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("BullishDivergenceOP2{0}", secondTroughBar2), false, CurrentBar - firstOscTroughBar2, firstTroughValue2, CurrentBar - secondOscTroughBar2, secondTroughValue2, BullColor2, DashStyleHelper.Solid, DivWidth2);},0,null);
								}
	                        }
						//},0,null);
                    }
                    #endregion

                    #region -- Histo hidden div --
                    if (PrintMarkers && !hidePlots && ShowDivOnOscillatorPanel && ShowHistogramHiddenDivergences)
                    {
line=6656;
Print(6657);
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearishDivergenceOP2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullishDivergenceOP2{0}",cutoffIdx));
						}
Print(6662);
						//TriggerCustomEvent(o1 =>{	
	                        //Bearish
	                        if (drawBearishDivCandidateOsc2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBearCandidateOsc2", false, CurrentBar - firstOscPeakBar2H, firstPeakValue2H, CurrentBar - secondOscPeakBar2H, secondPeakValue2H, HiddenBearColor2, DashStyleHelper.Dash, HiddenDivWidth2);},0,null);
	                        if (updateBearishDivCandidateOsc2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBearCandidateOsc2", false, CurrentBar - priorFirstOscPeakBar2H, priorFirstPeakValue2H, CurrentBar - secondOscPeakBar2H, secondPeakValue2H, HiddenBearColor2, DashStyleHelper.Dash, HiddenDivWidth2);},0,null);
	                        if (drawBearishDivOnOsc2H)
	                        {
	                            if (showBox)
	                                hiddenbearishDivPlotSeriesHistogram[CurrentBar - secondOscPeakBar2H] = secondOscPeakBar2H - firstOscPeakBar2H;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("hiddenBearishDivergenceOP2{0}", secondPeakBar2H), false, CurrentBar - firstOscPeakBar2H, firstPeakValue2H, CurrentBar - secondOscPeakBar2H, secondPeakValue2H, HiddenBearColor2, DashStyleHelper.Solid, HiddenDivWidth2);},0,null);
								}
	                        }
	                        //-------
	                        //Bullish
	                        if (drawBullishDivCandidateOsc2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBullCandidateOsc2", false, CurrentBar - firstOscTroughBar2H, firstTroughValue2H, CurrentBar - secondOscTroughBar2H, secondTroughValue2H, HiddenBullColor2, DashStyleHelper.Dash, HiddenDivWidth2);},0,null);
	                        if (updateBullishDivCandidateOsc2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBullCandidateOsc2", false, CurrentBar - priorFirstOscTroughBar2H, priorFirstTroughValue2H, CurrentBar - secondOscTroughBar2H, secondTroughValue2H, HiddenBullColor2, DashStyleHelper.Dash, HiddenDivWidth2);},0,null);
	                        if (drawBullishDivOnOsc2H)
	                        {
	                            if (showBox)
	                                hiddenbullishDivPlotSeriesHistogram[CurrentBar - secondOscTroughBar2H] = secondOscTroughBar2H - firstOscTroughBar2H;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("hiddenBullishDivergenceOP2{0}", secondTroughBar2H), false, CurrentBar - firstOscTroughBar2H, firstTroughValue2H, CurrentBar - secondOscTroughBar2H, secondTroughValue2H, HiddenBullColor2, DashStyleHelper.Solid, HiddenDivWidth2);},0,null);
								}
	                        }
						//},0,null);
                    }
                    #endregion

                    DrawOnPricePanel = true;
                    #region -- MACD div --
                    if (PrintMarkers && ShowDivOnPricePanel && ShowOscillatorDivergences)
                    {
line=6699;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearishDivergencePP1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullishDivergencePP1{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidatePrice1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBearCandidatePrice1", false, CurrentBar - firstPeakBar1, firstPeakHigh1 + offsetDiv1, CurrentBar - secondPeakBar1, secondPeakHigh1 + offsetDiv1, BearColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (updateBearishDivCandidatePrice1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBearCandidatePrice1", false, CurrentBar - priorFirstPeakBar1, priorFirstPeakHigh1 + offsetDiv1, CurrentBar - secondPeakBar1, secondPeakHigh1 + offsetDiv1, BearColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (drawBearishDivOnPrice1){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("BearishDivergencePP1{0}", secondPeakBar1), false, CurrentBar - firstPeakBar1, firstPeakHigh1 + offsetDiv1, CurrentBar - secondPeakBar1, secondPeakHigh1 + offsetDiv1, BearColor1, DashStyleHelper.Solid, DivWidth1);},0,null);
							}

	                        if (drawBullishDivCandidatePrice1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBullCandidatePrice1", false, CurrentBar - firstTroughBar1, firstTroughLow1 - offsetDiv1, CurrentBar - secondTroughBar1, secondTroughLow1 - offsetDiv1, BullColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (updateBullishDivCandidatePrice1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBullCandidatePrice1", false, CurrentBar - priorFirstTroughBar1, priorFirstTroughLow1 - offsetDiv1, CurrentBar - secondTroughBar1, secondTroughLow1 - offsetDiv1, BullColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (drawBullishDivOnPrice1){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("BullishDivergencePP1{0}", secondTroughBar1), false, CurrentBar - firstTroughBar1, firstTroughLow1 - offsetDiv1, CurrentBar - secondTroughBar1, secondTroughLow1 - offsetDiv1, BullColor1, DashStyleHelper.Solid, DivWidth1);},0,null);
							}
						//},0,null);
                    }
                    if (PrintMarkers && ShowSetupDots && ShowOscillatorDivergences)
                    {
line=6724;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearSetup1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullSetup1{0}",cutoffIdx));
						}
                        if (drawBearSetup1){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("BearSetup1{0}", CurrentBar), true, setupDotString, 0, Low[0] - offsetDraw1, -SetupFontSize1, BearishSetupColor1, setupFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawBullSetup1){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("BullSetup1{0}", CurrentBar), true, setupDotString, 0, High[0] + offsetDraw1, SetupFontSize1, BullishSetupColor1, setupFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    if (PrintMarkers && showArrows && ShowOscillatorDivergences)
                    {
line=6738;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearTrigger1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullTrigger1{0}",cutoffIdx));
						}
                        if (drawArrowDown1){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("BearTrigger1{0}", CurrentBar), true, arrowStringDown, 0, High[0] + offsetDraw1, 2 * TriangleFontSize1 / 3, ArrowDownColor1, triangleFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawArrowUp1){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("BullTrigger1{0}", CurrentBar), true, arrowStringUp, 0, Low[0] - offsetDraw1, -2 * TriangleFontSize1 / 3, ArrowUpColor1, triangleFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    #endregion

                    #region -- MACD hidden div --
                    if (PrintMarkers && ShowDivOnPricePanel && ShowOscillatorHiddenDivergences)
                    {
line=6755;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearishDivergencePP1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullishDivergencePP1{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidatePrice1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBearCandidatePrice1", false, CurrentBar - firstPeakBar1H, firstPeakHigh1H + offsetDiv1, CurrentBar - secondPeakBar1H, secondPeakHigh1H + offsetDiv1, HiddenBearColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
	                        if (updateBearishDivCandidatePrice1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBearCandidatePrice1", false, CurrentBar - priorFirstPeakBar1H, priorFirstPeakHigh1H + offsetDiv1, CurrentBar - secondPeakBar1H, secondPeakHigh1H + offsetDiv1, HiddenBearColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
	                        if (drawBearishDivOnPrice1H){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("hiddenBearishDivergencePP1{0}", secondPeakBar1H), false, CurrentBar - firstPeakBar1H, firstPeakHigh1H + offsetDiv1, CurrentBar - secondPeakBar1H, secondPeakHigh1H + offsetDiv1, HiddenBearColor1, DashStyleHelper.Solid, HiddenDivWidth1);},0,null);
							}

	                        if (drawBullishDivCandidatePrice1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBullCandidatePrice1", false, CurrentBar - firstTroughBar1H, firstTroughLow1H - offsetDiv1, CurrentBar - secondTroughBar1H, secondTroughLow1H - offsetDiv1, HiddenBullColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
	                        if (updateBullishDivCandidatePrice1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBullCandidatePrice1", false, CurrentBar - priorFirstTroughBar1H, priorFirstTroughLow1H - offsetDiv1, CurrentBar - secondTroughBar1H, secondTroughLow1H - offsetDiv1, HiddenBullColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
	                        if (drawBullishDivOnPrice1H){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("hiddenBullishDivergencePP1{0}", secondTroughBar1H), false, CurrentBar - firstTroughBar1H, firstTroughLow1H - offsetDiv1, CurrentBar - secondTroughBar1H, secondTroughLow1H - offsetDiv1, HiddenBullColor1, DashStyleHelper.Solid, HiddenDivWidth1);},0,null);
							}
						//},0,null);
                    }
                    if (PrintMarkers && ShowSetupDots && ShowOscillatorHiddenDivergences)
                    {
line=6780;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearSetup1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullSetup1{0}",cutoffIdx));
						}
                        if (drawBearSetup1H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("hiddenBearSetup1{0}", CurrentBar), true, setupDotString, 0, Low[0] - offsetDraw1, -SetupFontSize1, HiddenBearishSetupColor1, setupFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawBullSetup1H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("hiddenBullSetup1{0}", CurrentBar), true, setupDotString, 0, High[0] + offsetDraw1, SetupFontSize1, HiddenBullishSetupColor1, setupFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    if (PrintMarkers && showArrows && ShowOscillatorHiddenDivergences)
                    {
line=6794;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearTrigger1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullTrigger1{0}",cutoffIdx));
						}
                        if (drawArrowDown1H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("hiddenBearTrigger1{0}", CurrentBar), true, arrowStringDown, 0, High[0] + offsetDraw1, 2 * TriangleFontSize1 / 3, HiddenArrowDownColor1, triangleFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawArrowUp1H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("hiddenBullTrigger1{0}", CurrentBar), true, arrowStringUp, 0, Low[0] - offsetDraw1, -2 * TriangleFontSize1 / 3, HiddenArrowUpColor1, triangleFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    #endregion

                    #region -- HISTO div --
                    if (PrintMarkers && ShowDivOnPricePanel && ShowHistogramDivergences)
                    {
line=6811;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearishDivergencePP2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullishDivergencePP2{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidatePrice2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBearCandidatePrice2", false, CurrentBar - firstPeakBar2, firstPeakHigh2 + offsetDiv2, CurrentBar - secondPeakBar2, secondPeakHigh2 + offsetDiv2, BearColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (updateBearishDivCandidatePrice2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBearCandidatePrice2", false, CurrentBar - priorFirstPeakBar2, priorFirstPeakHigh2 + offsetDiv2, CurrentBar - secondPeakBar2, secondPeakHigh2 + offsetDiv2, BearColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (drawBearishDivOnPrice2){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("BearishDivergencePP2{0}", secondPeakBar2), false, CurrentBar - firstPeakBar2, firstPeakHigh2 + offsetDiv2, CurrentBar - secondPeakBar2, secondPeakHigh2 + offsetDiv2, BearColor2, DashStyleHelper.Solid, DivWidth2);},0,null);
							}
	                        if (drawBullishDivCandidatePrice2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBullCandidatePrice2", false, CurrentBar - firstTroughBar2, firstTroughLow2 - offsetDiv2, CurrentBar - secondTroughBar2, secondTroughLow2 - offsetDiv2, BullColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (updateBullishDivCandidatePrice2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "divBullCandidatePrice2", false, CurrentBar - priorFirstTroughBar2, priorFirstTroughLow2 - offsetDiv2, CurrentBar - secondTroughBar2, secondTroughLow2 - offsetDiv2, BullColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (drawBullishDivOnPrice2){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("BullishDivergencePP2{0}", secondTroughBar2), false, CurrentBar - firstTroughBar2, firstTroughLow2 - offsetDiv2, CurrentBar - secondTroughBar2, secondTroughLow2 - offsetDiv2, BullColor2, DashStyleHelper.Solid, DivWidth2);},0,null);
							}
						//},0,null);
                    }
                    if (PrintMarkers && ShowSetupDots && ShowHistogramDivergences)
                    {
line=6835;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearSetup2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullSetup2{0}",cutoffIdx));
						}
                        if (drawBearSetup2){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("BearSetup2{0}", CurrentBar), true, setupDotString, 0, Low[0] - offsetDraw2, -SetupFontSize2, BearishSetupColor2, setupFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawBullSetup2){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("BullSetup2{0}", CurrentBar), true, setupDotString, 0, High[0] + offsetDraw2, SetupFontSize2, BullishSetupColor2, setupFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    if (PrintMarkers && showArrows && ShowHistogramDivergences)
                    {
line=6849;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearTrigger2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullTrigger2{0}",cutoffIdx));
						}
                        if (drawArrowDown2){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("BearTrigger2{0}", CurrentBar), true, arrowStringDown, 0, High[0] + offsetDraw2, 2 * TriangleFontSize2 / 3, ArrowDownColor2, triangleFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawArrowUp2){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("BullTrigger2{0}", CurrentBar), true, arrowStringUp, 0, Low[0] - offsetDraw2, -2 * TriangleFontSize2 / 3, ArrowUpColor2, triangleFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    #endregion

                    #region -- HISTO hidden div --
                    if (PrintMarkers && ShowDivOnPricePanel && ShowHistogramHiddenDivergences)
                    {
line=6866;
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearishDivergencePP2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullishDivergencePP2{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidatePrice2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBearCandidatePrice2", false, CurrentBar - firstPeakBar2H, firstPeakHigh2H + offsetDiv2, CurrentBar - secondPeakBar2H, secondPeakHigh2H + offsetDiv2, HiddenBearColor2, DashStyleHelper.Dash, HiddenDivWidth2); },0,null);
	                        if (updateBearishDivCandidatePrice2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBearCandidatePrice2", false, CurrentBar - priorFirstPeakBar2H, priorFirstPeakHigh2H + offsetDiv2, CurrentBar - secondPeakBar2H, secondPeakHigh2H + offsetDiv2, HiddenBearColor2, DashStyleHelper.Dash, HiddenDivWidth2); },0,null);
	                        if (drawBearishDivOnPrice2H){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("hiddenBearishDivergencePP2{0}", secondPeakBar2H), false, CurrentBar - firstPeakBar2H, firstPeakHigh2H + offsetDiv2, CurrentBar - secondPeakBar2H, secondPeakHigh2H + offsetDiv2, HiddenBearColor2, DashStyleHelper.Solid, HiddenDivWidth2);},0,null);
							}

	                        if (drawBullishDivCandidatePrice2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBullCandidatePrice2", false, CurrentBar - firstTroughBar2H, firstTroughLow2H - offsetDiv2, CurrentBar - secondTroughBar2H, secondTroughLow2H - offsetDiv2, HiddenBullColor2, DashStyleHelper.Dash, HiddenDivWidth2); },0,null);
	                        if (updateBullishDivCandidatePrice2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, "hiddendivBullCandidatePrice2", false, CurrentBar - priorFirstTroughBar2H, priorFirstTroughLow2H - offsetDiv2, CurrentBar - secondTroughBar2H, secondTroughLow2H - offsetDiv2, HiddenBullColor2, DashStyleHelper.Dash, HiddenDivWidth2);},0,null);
	                        if (drawBullishDivOnPrice2H){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this, string.Format("hiddenBullishDivergencePP2{0}", secondTroughBar2H), false, CurrentBar - firstTroughBar2H, firstTroughLow2H - offsetDiv2, CurrentBar - secondTroughBar2H, secondTroughLow2H - offsetDiv2, HiddenBullColor2, DashStyleHelper.Solid, HiddenDivWidth2);},0,null);
							}
						//},0,null);
                    }
                    if (PrintMarkers && ShowSetupDots && ShowHistogramHiddenDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearSetup2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullSetup2{0}",cutoffIdx));
						}
                        if (drawBearSetup2H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("hiddenBearSetup2{0}", CurrentBar), true, setupDotString, 0, Low[0] - offsetDraw2, -SetupFontSize2, HiddenBearishSetupColor2, setupFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawBullSetup2H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("hiddenBullSetup2{0}", CurrentBar), true, setupDotString, 0, High[0] + offsetDraw2, SetupFontSize2, HiddenBullishSetupColor2, setupFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    if (PrintMarkers && showArrows && ShowHistogramHiddenDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearTrigger2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullTrigger2{0}",cutoffIdx));
						}
                        if (drawArrowDown2H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("hiddenBearTrigger2{0}", CurrentBar), true, arrowStringDown, 0, High[0] + offsetDraw2, 2 * TriangleFontSize2 / 3, HiddenArrowDownColor2, triangleFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawArrowUp2H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this, string.Format("hiddenBullTrigger2{0}", CurrentBar), true, arrowStringUp, 0, Low[0] - offsetDraw2, -2 * TriangleFontSize2 / 3, HiddenArrowUpColor2, triangleFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    #endregion
                }
                #endregion
            }
            else
            {
line=6921;
                #region Bearish divergences between price and BBMACD
                bool drawBearishDivOnOsc1 = false;
                bool drawBearishDivOnPrice1 = false;
                bool drawArrowDown1 = false;
                if (IsFirstTickOfBar)
                {
                    if (bearishTriggerCountMACDBB[1] > 0)
                    {
                        if ((Close[1] < High[CurrentBar - secondPeakBar1]) && (BBMACD[1] < BBMACD[2]) && Close[1] < Open[1])
                        {
                            bearishCDivMACD[0] = (1.0);
                            bearishTriggerCountMACDBB[1] = (0);
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                                drawBearishDivOnOsc1 = true;
                            if (ShowDivOnPricePanel)
                                drawBearishDivOnPrice1 = true;
                            if (showArrows)
                                drawArrowDown1 = true;
                            RemoveDrawObject("divBearCandidateOsc1");
                            RemoveDrawObject("divBearCandidatePrice1");
                            maxcptBearMACDdiv++;
                        }
                        else
                            bearishCDivMACD[0] = (0.0);
                        priorFirstPeakBar1 = firstPeakBar1;
                        priorFirstOscPeakBar1 = firstOscPeakBar1;
                        priorFirstPeakHigh1 = firstPeakHigh1;
                        priorFirstPeakValue1 = firstPeakValue1;
                        priorReplacementPeakValue1 = replacementPeakValue1;
                        priorSecondPeakBar1 = secondPeakBar1;
                        priorSecondOscPeakBar1 = secondOscPeakBar1;
                        priorSecondPeakHigh1 = secondPeakHigh1;
                        priorSecondPeakValue1 = secondPeakValue1;
                        if (BBMACD[1] > firstPeakValue1)
                        {
                            bearishTriggerCountMACDBB[1] = (0);
                            RemoveDrawObject("divBearCandidateOsc1");
                            RemoveDrawObject("divBearCandidatePrice1");
                        }
                    }
                    else
                    {
                        bearishCDivMACD[0] = (0.0);
                        {
                            RemoveDrawObject("divBearCandidateOsc1");
                            RemoveDrawObject("divBearCandidatePrice1");
                        }
                    }
                    bearishPDivMACD[0] = (0.0);
                }
                if (bearishPDivMACD[0] > 0.5)
                {
                    RemoveDrawObject("divBearCandidateOsc1");
                    RemoveDrawObject("divBearCandidatePrice1");
                }
                bool drawBearishDivCandidateOsc1 = false;
                bool drawBearishDivCandidatePrice1 = false;
                bool updateBearishDivCandidateOsc1 = false;
                bool updateBearishDivCandidatePrice1 = false;
                bool drawBearSetup1 = false;
                bool invalidate = swingInput[0] <= swingInput[1] || (IncludeDoubleTopsAndBottoms && swingInput[0] < firstPeakHigh1) || (!IncludeDoubleTopsAndBottoms && swingInput[0] <= firstPeakHigh1);
                if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bearishTriggerCountMACDBB[1] > 0 && invalidate)
                {
line=6985;
                    bearishPDivMACD[0] = (0.0);
                    secondPeakBar1 = priorSecondPeakBar1;
                    secondPeakHigh1 = priorSecondPeakHigh1;
                    updateBearishDivCandidatePrice1 = true;
                }
                else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bearishPDivMACD[0] > 0.5 && invalidate)
                {
line=6993;
                    bearishPDivMACD[0] = (0.0);
                    bearishTriggerCountMACDBB[0] = (0);
                    secondPeakBar1 = priorSecondPeakBar1;
                    secondPeakHigh1 = priorSecondPeakHigh1;
                    RemoveDrawObject("divBearCandidateOsc1");
                    RemoveDrawObject("divBearCandidatePrice1");
                }
                bool firstPeakFound1 = false;
                peakCount1 = 0;
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
line=7005;
                    int j = 0;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                        swingMax = MAX(High, SwingStrength)[1];
                    else
                        swingMax = MAX(Input, SwingStrength)[1];
                    if (swingHighType[i] > 0 || (i > DivMinBars && pre_swingHighType[i] > 0 && !upTrend[0] && Low[0] < Math.Min(swingMin, currentHigh - zigzagDeviation))) // code references zigzag
                    {
                        refPeakBar1[peakCount1] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refPeakHigh1[peakCount1] = High[i];
                        else
                            refPeakHigh1[peakCount1] = swingInput[i];
                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 4) && BBMACD[j - 1] > BBMACD[j])
                                j = j - 1;
                            refOscPeakBar1[peakCount1] = CurrentBar - j;
                            refPeakValue1[peakCount1] = BBMACD[j];
                            peakCount1 = peakCount1 + 1;
                        }
                        else
                        {
                            refOscPeakBar1[peakCount1] = CurrentBar - i;
                            refPeakValue1[peakCount1] = BBMACD[i];
                            peakCount1 = peakCount1 + 1;
                        }
                    }
                    if ((UseLastSwingOnly && peakCount1 == 1) || peakCount1 == 9)
                        break;
                }
                int maxBarOsc = UseOscHighLow && BBMACD[1] > BBMACD[0] ? CurrentBar - 1 : CurrentBar;
                double maxValueOsc = UseOscHighLow && BBMACD[1] > BBMACD[0] ? BBMACD[1] : BBMACD[0];
               
                for (int count = 0; count < peakCount1; count++) //find smallest divergence setup
                {
line=7042;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && High[0] >= refPeakHigh1[count]) || (!IncludeDoubleTopsAndBottoms && High[0] > refPeakHigh1[count]))
                        && High[0] > High[1] && High[0] >= MAX(High, CurrentBar - refPeakBar1[count] - 2)[1] && refPeakValue1[count] > 0 && refPeakValue1[count] > maxValueOsc
                        && refPeakValue1[count] > MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1[count] - 6))[1] && (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1[count])[0] > 0))
                    {
                        bearishPDivMACD[0] = (1.0);
                        bearishTriggerCountMACDBB[0] = (TriggerBars + 1);
                        firstPeakBar1 = refPeakBar1[count];
                        firstPeakHigh1 = refPeakHigh1[count];
                        firstOscPeakBar1 = refOscPeakBar1[count];
                        firstPeakValue1 = refPeakValue1[count];
                        secondPeakBar1 = CurrentBar;
                        secondPeakHigh1 = High[0];
                        secondOscPeakBar1 = maxBarOsc;
                        secondPeakValue1 = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBearCandidateOsc1");
                            drawBearishDivCandidateOsc1 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBearCandidatePrice1");
                            drawBearishDivCandidatePrice1 = true;
                        }
                        if (ShowSetupDots)
                            drawBearSetup1 = true;
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] >= refPeakHigh1[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] > refPeakHigh1[count]))
                        && swingInput[0] > swingInput[1] && swingInput[0] >= MAX(swingInput, CurrentBar - refPeakBar1[count] - 2)[1] && refPeakValue1[count] > 0 && refPeakValue1[count] > maxValueOsc
                        && refPeakValue1[count] > MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1[count] - 6))[1] && (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1[count])[0] > 0))
                    {
                        bearishPDivMACD[0] = (1.0);
                        bearishTriggerCountMACDBB[0] = (TriggerBars + 1);
                        firstPeakBar1 = refPeakBar1[count];
                        firstPeakHigh1 = refPeakHigh1[count];
                        firstOscPeakBar1 = refOscPeakBar1[count];
                        firstPeakValue1 = refPeakValue1[count];
                        secondPeakBar1 = CurrentBar;
                        secondPeakHigh1 = swingInput[0];
                        secondOscPeakBar1 = maxBarOsc;
                        secondPeakValue1 = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBearCandidateOsc1");
                            drawBearishDivCandidateOsc1 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBearCandidatePrice1");
                            drawBearishDivCandidatePrice1 = true;
                        }
                        if (ShowSetupDots)
                            drawBearSetup1 = true;
                        break;
                    }
                    else
                        bearishPDivMACD[0] = (0.0);
                }
                for (int count = peakCount1 - 1; count >= 0; count--) //find largest divergence setup
                {
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && High[0] >= refPeakHigh1[count]) || (!IncludeDoubleTopsAndBottoms && High[0] > refPeakHigh1[count]))
                        && High[0] > High[1] && High[0] >= MAX(High, CurrentBar - refPeakBar1[count] - 2)[1] && refPeakValue1[count] > 0 && refPeakValue1[count] > maxValueOsc
                        && refPeakValue1[count] > MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1[count] - 6))[1] && (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1[count])[0] > 0))
                    {
                        replacementPeakBar1 = refPeakBar1[count];
                        replacementPeakHigh1 = refPeakHigh1[count];
                        replacementOscPeakBar1 = refOscPeakBar1[count];
                        replacementPeakValue1 = refPeakValue1[count];
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] >= refPeakHigh1[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] > refPeakHigh1[count]))
                        && swingInput[0] > swingInput[1] && swingInput[0] >= MAX(swingInput, CurrentBar - refPeakBar1[count] - 2)[1] && refPeakValue1[count] > 0 && refPeakValue1[count] > maxValueOsc
                        && refPeakValue1[count] > MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1[count] - 6))[1] && (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1[count])[0] > 0))
                    {
                        replacementPeakBar1 = refPeakBar1[count];
                        replacementPeakHigh1 = refPeakHigh1[count];
                        replacementOscPeakBar1 = refOscPeakBar1[count];
                        replacementPeakValue1 = refPeakValue1[count];
                        break;
                    }
                }
                if (bearishPDivMACD[0] < 0.5)
                {
                    divergenceActive = true;
                    if (bearishTriggerCountMACDBB[1] > 0)
                    {
                        bearishTriggerCountMACDBB[0] = (bearishTriggerCountMACDBB[1] - 1);
                        if (BBMACD[0] > priorSecondPeakValue1)
                        {
                            if (BBMACD[0] < priorFirstPeakValue1)
                            {
                                secondOscPeakBar1 = CurrentBar;
                                secondPeakValue1 = BBMACD[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBearCandidateOsc1");
                                    updateBearishDivCandidateOsc1 = true;
                                    RemoveDrawObject("divBearCandidatePrice1");
                                    updateBearishDivCandidatePrice1 = true;
                                }
                            }
                            else if (BBMACD[0] < priorReplacementPeakValue1)
                            {
                                firstPeakBar1 = replacementPeakBar1;
                                firstPeakHigh1 = replacementPeakHigh1;
                                firstOscPeakBar1 = replacementOscPeakBar1;
                                firstPeakValue1 = replacementPeakValue1;
                                secondOscPeakBar1 = CurrentBar;
                                secondPeakValue1 = BBMACD[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBearCandidateOsc1");
                                    drawBearishDivCandidateOsc1 = true;
                                    RemoveDrawObject("divBearCandidatePrice1");
                                    drawBearishDivCandidatePrice1 = true;
                                }
                            }
                            else
                            {
                                bearishTriggerCountMACDBB[0] = (0);
                                RemoveDrawObject("divBearCandidateOsc1");
                                RemoveDrawObject("divBearCandidatePrice1");
                                divergenceActive = false;
                            }
                        }
                        else
                        {
                            secondOscPeakBar1 = priorSecondOscPeakBar1;
                            secondPeakValue1 = priorSecondPeakValue1;
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("divBearCandidateOsc1");
                                updateBearishDivCandidateOsc1 = true;
                                RemoveDrawObject("divBearCandidatePrice1");
                                updateBearishDivCandidatePrice1 = true;
                            }
                        }
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low && bearishTriggerCountMACDBB[0] > 0 && High[0] > MAX(High, CurrentBar - firstPeakBar1)[1])
                        {
                            secondPeakBar1 = CurrentBar;
                            secondPeakHigh1 = High[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBearCandidatePrice1");
                                if (divergenceActive)
                                    updateBearishDivCandidatePrice1 = true;
                            }
                        }
                        else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bearishTriggerCountMACDBB[0] > 0 && swingInput[0] > MAX(swingInput, CurrentBar - firstPeakBar1)[1])
                        {
                            secondPeakBar1 = CurrentBar;
                            secondPeakHigh1 = swingInput[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBearCandidatePrice1");
                                if (divergenceActive)
                                    updateBearishDivCandidatePrice1 = true;
                            }
                        }
                    }
                }

                if (bearishTriggerCountMACDBB[0] > 0)
                {
                    if ((Close[0] < High[CurrentBar - secondPeakBar1]) && (BBMACD[0] < BBMACD[1]) && Close[0] < Open[0])
                    {
                        if (firstPeakBar1 != memfirstPeakBar1)
                        {
                            cptBearMACDdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                            maxcptBearMACDdiv = 1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        memfirstPeakBar1 = firstPeakBar1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBearMACDdiv = maxcptBearMACDdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bearishMACDDivProjection[0] = (cptBearMACDdiv);//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else bearishMACDDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec						
                }
                else bearishMACDDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec

                #endregion

                #region Bearish Hidden divergences between price and BBMACD #HIDDENDIV
                drawBearishDivOnOsc1H = false;
                drawBearishDivOnPrice1H = false;
                drawArrowDown1H = false;
                drawBearSetup1H = false;

                #region -- IsFirstTickOfBar - {Reset} --
                if (IsFirstTickOfBar)
                {
                    if (hiddenbearishTriggerCountMACDBB[1] > 0)
                    {
                        if ((Close[1] < High[CurrentBar - secondPeakBar1H]) && (BBMACD[1] < BBMACD[2]) && Close[1] < Open[1])
                        {
                            hiddenbearishCDivMACD[0] = (1.0);
                            hiddenbearishTriggerCountMACDBB[1] = (0);
                            if (!hidePlots && ShowDivOnOscillatorPanel) drawBearishDivOnOsc1H = true;
                            if (ShowDivOnPricePanel) drawBearishDivOnPrice1H = true;
                            if (showArrows) drawArrowDown1H = true;
                            RemoveDrawObject("hiddendivBearCandidateOsc1");
                            RemoveDrawObject("hiddendivBearCandidatePrice1");
                            maxcptBearMACDhdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        else
                            hiddenbearishCDivMACD[0] = (0.0);

                        priorFirstPeakBar1H = firstPeakBar1H;
                        priorFirstOscPeakBar1H = firstOscPeakBar1H;
                        priorFirstPeakHigh1H = firstPeakHigh1H;
                        priorFirstPeakValue1H = firstPeakValue1H;
                        priorReplacementPeakHigh1H = replacementPeakHigh1H;
                        priorReplacementPeakValue1H = replacementPeakValue1H;
                        priorSecondPeakBar1H = secondPeakBar1H;
                        priorSecondOscPeakBar1H = secondOscPeakBar1H;
                        priorSecondPeakValue1H = secondPeakValue1H;
                        priorSecondPeakHigh1H = secondPeakHigh1H;

                        double refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[1] : swingInput[1];
                        if (refinput > firstPeakHigh1H)
                        {
                            hiddenbearishTriggerCountMACDBB[1] = (0);
                            RemoveDrawObject("hiddendivBearCandidateOsc1");
                            RemoveDrawObject("hiddendivBearCandidatePrice1");
                        }
                    }
                    else
                    {
                        hiddenbearishCDivMACD[0] = (0.0);
                        RemoveDrawObject("hiddendivBearCandidateOsc1");
                        RemoveDrawObject("hiddendivBearCandidatePrice1");
                    }
                    hiddenbearishPDivMACD[0] = (0.0);
                }
                #endregion

                if (hiddenbearishPDivMACD[0] > 0.5)
                {
                    RemoveDrawObject("hiddendivBearCandidateOsc1");
                    RemoveDrawObject("hiddendivBearCandidatePrice1");
                }

                #region -- reset variables --
                drawBearishDivCandidateOsc1H = false;
                drawBearishDivCandidatePrice1H = false;
                updateBearishDivCandidateOsc1H = false;
                updateBearishDivCandidatePrice1H = false;
                peakCount1H = 0;
                #endregion

                double refinput1H_0 = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[0] : swingInput[0];
                double refinput1H_1 = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[1] : swingInput[1];
                bool invalidate1H = BBMACD[0] < MAX(BBMACD, CurrentBar - firstOscPeakBar1H)[1] || refinput1H_0 <= refinput1H_1 ||
                    (IncludeDoubleTopsAndBottoms && refinput1H_0 > firstPeakHigh1H) || (!IncludeDoubleTopsAndBottoms && refinput1H_0 >= firstPeakHigh1H);
                if (hiddenbearishTriggerCountMACDBB[1] > 0 && invalidate1H)
                {
                    hiddenbearishPDivMACD[0] = (0.0);
                    secondOscPeakBar1H = priorSecondOscPeakBar1H;
                    secondPeakValue1H = priorSecondPeakValue1H;
                    updateBearishDivCandidateOsc1H = true;
                }
                else if (hiddenbearishPDivMACD[0] > 0.5 && invalidate1H)
                {
                    hiddenbearishPDivMACD[0] = (0.0);
                    hiddenbearishTriggerCountMACDBB[0] = (0);
                    secondOscPeakBar1H = priorSecondOscPeakBar1H;
                    secondPeakValue1H = priorSecondPeakValue1H;
                    RemoveDrawObject("hiddendivBearCandidateOsc1");
                    RemoveDrawObject("hiddendivBearCandidatePrice1");
                }

                #region -- get price top and osc top --
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
                    int j = 0;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                        swingMax = MAX(High, SwingStrength)[1];
                    else
                        swingMax = MAX(Input, SwingStrength)[1];
                    if (swingHighType[i] > 0 || (i > DivMinBars && pre_swingHighType[i] > 0 && !upTrend[0] && Low[0] < Math.Min(swingMin, currentHigh - zigzagDeviation))) // code references zigzag
                    {
                        refPeakBar1H[peakCount1H] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refPeakHigh1H[peakCount1H] = High[i];
                        else
                            refPeakHigh1H[peakCount1H] = swingInput[i];

                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 4) && BBMACD[j - 1] > BBMACD[j])
                                j = j - 1;
                            refOscPeakBar1H[peakCount1H] = CurrentBar - j;
                            refPeakValue1H[peakCount1H] = BBMACD[j];
                            peakCount1H = peakCount1H + 1;
                        }
                        else
                        {
                            refOscPeakBar1H[peakCount1H] = CurrentBar - i;
                            refPeakValue1H[peakCount1H] = BBMACD[i];
                            peakCount1H = peakCount1H + 1;
                        }
                    }
                    if ((UseLastSwingOnly && peakCount1H == 1) || peakCount1H == 9) break;
                }
                #endregion

                maxBarOsc = UseOscHighLow && BBMACD[1] > BBMACD[0] ? CurrentBar - 1 : CurrentBar;
                maxValueOsc = UseOscHighLow && BBMACD[1] > BBMACD[0] ? BBMACD[1] : BBMACD[0];

                #region -- find smallest divergence setup --
                for (int count = 0; count < peakCount1H; count++)
                {
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] <= refPeakHigh1H[count]) ||
                        (!IncludeDoubleTopsAndBottoms && refinput[0] < refPeakHigh1H[count])) &&
                        refinput[0] > refinput[1] &&
                        refinput[0] >= MAX(refinput, CurrentBar - refPeakBar1H[count] - 2)[1] &&
                        refPeakValue1H[count] > 0 &&
                        refPeakValue1H[count] < maxValueOsc &&
                        refPeakValue1H[count] < MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1H[count] - 6))[1] &&
                        (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1H[count])[0] > 0))
                    {
                        hiddenbearishPDivMACD[0] = (1.0);
                        hiddenbearishTriggerCountMACDBB[0] = (TriggerBars + 1);
                        firstPeakBar1H = refPeakBar1H[count];
                        firstPeakHigh1H = refPeakHigh1H[count];
                        firstOscPeakBar1H = refOscPeakBar1H[count];
                        firstPeakValue1H = refPeakValue1H[count];
                        secondPeakBar1H = CurrentBar;
                        secondPeakHigh1H = refinput[0];
                        secondOscPeakBar1H = maxBarOsc;
                        secondPeakValue1H = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("hiddendivBearCandidateOsc1");
                            drawBearishDivCandidateOsc1H = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("hiddendivBearCandidatePrice1");
                            drawBearishDivCandidatePrice1H = true;
                        }
                        if (ShowSetupDots) drawBearSetup1H = true;
                        break;
                    }
                    else hiddenbearishPDivMACD[0] = (0.0);
                }
                #endregion

                #region -- find largest divergence setup --
                for (int count = peakCount1H - 1; count >= 0; count--)
                {
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] <= refPeakHigh1H[count]) || (!IncludeDoubleTopsAndBottoms && refinput[0] < refPeakHigh1H[count])) &&
                        refinput[0] > refinput[1] &&
                        refinput[0] >= MAX(refinput, CurrentBar - refPeakBar1H[count] - 2)[1] &&
                        refPeakValue1H[count] > 0 &&
                        refPeakValue1H[count] < maxValueOsc &&
                        refPeakValue1H[count] < MAX(BBMACD, Math.Max(1, CurrentBar - refOscPeakBar1H[count] - 6))[1] &&
                        (!ResetFilter || MIN(BBMACD, CurrentBar - refOscPeakBar1H[count])[0] > 0))
                    {
                        replacementPeakBar1H = refPeakBar1H[count];
                        replacementPeakHigh1H = refPeakHigh1H[count];
                        replacementOscPeakBar1H = refOscPeakBar1H[count];
                        replacementPeakValue1H = refPeakValue1H[count];
                        break;
                    }
                }
                #endregion

                double inputref = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[0] : swingInput[0];
                if (hiddenbearishPDivMACD[0] < 0.5)
                {
                    divergenceActive = true;
                    if (hiddenbearishTriggerCountMACDBB[1] > 0)
                    {
                        hiddenbearishTriggerCountMACDBB[0] = (hiddenbearishTriggerCountMACDBB[1] - 1);
                        if (inputref > priorSecondPeakHigh1H)
                        {
                            if (inputref < priorFirstPeakHigh1H)//price stays below
                            {
                                secondPeakBar1H = CurrentBar;
                                secondPeakHigh1H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBearCandidateOsc1");
                                    updateBearishDivCandidateOsc1H = true;
                                    RemoveDrawObject("hiddendivBearCandidatePrice1");
                                    updateBearishDivCandidatePrice1H = true;
                                }
                            }
                            else if (inputref < priorReplacementPeakHigh1H)
                            {
                                firstPeakBar1H = replacementPeakBar1H;
                                firstPeakHigh1H = replacementPeakHigh1H;
                                firstOscPeakBar1H = replacementOscPeakBar1H;
                                firstPeakValue1H = replacementPeakValue1H;
                                secondPeakBar1H = CurrentBar;
                                secondPeakHigh1H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBearCandidateOsc1");
                                    drawBearishDivCandidateOsc1H = true;
                                    RemoveDrawObject("hiddendivBearCandidatePrice1");
                                    drawBearishDivCandidatePrice1H = true;
                                }
                            }
                            else
                            {
                                hiddenbearishTriggerCountMACDBB[0] = (0);
                                RemoveDrawObject("hiddendivBearCandidateOsc1");
                                RemoveDrawObject("hiddendivBearCandidatePrice1");
                                divergenceActive = false;
                            }
                        }
                        else
                        {
                            secondPeakBar1H = priorSecondPeakBar1H;
                            secondPeakHigh1H = priorSecondPeakHigh1H;
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBearCandidateOsc1");
                                updateBearishDivCandidateOsc1H = true;
                                RemoveDrawObject("hiddendivBearCandidatePrice1");
                                updateBearishDivCandidatePrice1H = true;
                            }
                        }
                        if (hiddenbearishTriggerCountMACDBB[0] > 0 && BBMACD[0] > MAX(BBMACD, CurrentBar - firstOscPeakBar1H)[1])
                        {
                            secondOscPeakBar1H = CurrentBar;
                            secondPeakValue1H = BBMACD[0];
                            if (ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBearCandidateOsc1");
                                if (divergenceActive) updateBearishDivCandidateOsc1H = true;
                            }
                        }
                    }
                }

                if (hiddenbearishTriggerCountMACDBB[0] > 0)
                {
                    if ((Close[0] < High[CurrentBar - secondPeakBar1H]) && (BBMACD[0] < BBMACD[1]) && Close[0] < Open[0])
                    {
                        if (firstPeakBar1H != memfirstPeakBar1H)
                        {
                            cptBearMACDhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                            maxcptBearMACDhdiv = 1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        memfirstPeakBar1H = firstPeakBar1H;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBearMACDhdiv = maxcptBearMACDhdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bearishMACDHiddenDivProjection[0] = (cptBearMACDhdiv);//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else bearishMACDHiddenDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec						
                }
                else bearishMACDHiddenDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec
                #endregion

                #region Bullish divergences between price and BBMACD
                bool drawBullishDivOnOsc1 = false;
                bool drawBullishDivOnPrice1 = false;
                bool drawArrowUp1 = false;

                if (IsFirstTickOfBar)
                {
                    if (bullishTriggerCountMACDBB[1] > 0)
                    {
                        if ((Close[1] > Low[CurrentBar - secondTroughBar1]) && (BBMACD[1] > BBMACD[2]) && Close[1] > Open[1])
                        {
                            bullishCDivMACD[0] = (1.0);
                            bullishTriggerCountMACDBB[1] = (0);
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                                drawBullishDivOnOsc1 = true;
                            if (ShowDivOnPricePanel)
                                drawBullishDivOnPrice1 = true;
                            if (showArrows)
                                drawArrowUp1 = true;
                            RemoveDrawObject("divBullCandidateOsc1");
                            RemoveDrawObject("divBullCandidatePrice1");
                            maxcptBullMACDdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        else
                            bullishCDivMACD[0] = (0.0);
                        priorFirstTroughBar1 = firstTroughBar1;
                        priorFirstOscTroughBar1 = firstOscTroughBar1;
                        priorFirstTroughLow1 = firstTroughLow1;
                        priorFirstTroughValue1 = firstTroughValue1;
                        priorReplacementTroughValue1 = replacementTroughValue1;
                        priorSecondTroughBar1 = secondTroughBar1;
                        priorSecondOscTroughBar1 = secondOscTroughBar1;
                        priorSecondTroughLow1 = secondTroughLow1;
                        priorSecondTroughValue1 = secondTroughValue1;
                        if (BBMACD[1] < firstTroughValue1)
                        {
                            bullishTriggerCountMACDBB[1] = (0);
                            RemoveDrawObject("divBullCandidateOsc1");
                            RemoveDrawObject("divBullCandidatePrice1");
                        }
                    }
                    else
                    {
                        bullishCDivMACD[0] = (0.0);
                        {
                            RemoveDrawObject("divBullCandidateOsc1");
                            RemoveDrawObject("divBullCandidatePrice1");
                        }
                    }
                    bullishPDivMACD[0] = (0.0);
                }
                if (bullishPDivMACD[0] > 0.5)
                {
                    RemoveDrawObject("divBullCandidateOsc1");
                    RemoveDrawObject("divBullCandidatePrice1");
                }
                bool drawBullishDivCandidateOsc1 = false;
                bool drawBullishDivCandidatePrice1 = false;
                bool updateBullishDivCandidateOsc1 = false;
                bool updateBullishDivCandidatePrice1 = false;
                bool drawBullSetup1 = false;
                invalidate = swingInput[0] >= swingInput[1] || (IncludeDoubleTopsAndBottoms && swingInput[0] > firstTroughLow1) || (!IncludeDoubleTopsAndBottoms && swingInput[0] >= firstTroughLow1);
                if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bullishTriggerCountMACDBB[1] > 0 && invalidate)
                {
                    bullishPDivMACD[0] = (0.0);
                    secondTroughBar1 = priorSecondTroughBar1;
                    secondTroughLow1 = priorSecondTroughLow1;
                    updateBullishDivCandidatePrice1 = true;
                }
                else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bullishPDivMACD[0] > 0.5 && invalidate)
                {
                    bullishPDivMACD[0] = (0.0);
                    bullishTriggerCountMACDBB[0] = (0);
                    secondTroughBar1 = priorSecondTroughBar1;
                    secondTroughLow1 = priorSecondTroughLow1;
                    RemoveDrawObject("divBullCandidateOsc1");
                    RemoveDrawObject("divBullCandidatePrice1");
                }
                bool firstTroughFound1 = false;
                troughCount1 = 0;
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
                    int j = 0;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                        swingMin = MIN(Low, SwingStrength)[1];
                    else
                        swingMin = MIN(Input, SwingStrength)[1];
                    if (swingLowType[i] < 0 || (i > DivMinBars && pre_swingLowType[i] < 0 && upTrend[0] && High[0] > Math.Max(swingMax, currentLow + zigzagDeviation))) // code references zigzag 
                    {
                        refTroughBar1[troughCount1] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refTroughLow1[troughCount1] = Low[i];
                        else
                            refTroughLow1[troughCount1] = swingInput[i];
                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 3) && BBMACD[j - 1] < BBMACD[j])
                                j = j - 1;
                            refOscTroughBar1[troughCount1] = CurrentBar - j;
                            refTroughValue1[troughCount1] = BBMACD[j];
                            troughCount1 = troughCount1 + 1;
                        }
                        else
                        {
                            refOscTroughBar1[troughCount1] = CurrentBar - i;
                            refTroughValue1[troughCount1] = BBMACD[i];
                            troughCount1 = troughCount1 + 1;
                        }
                    }
                    if ((UseLastSwingOnly && troughCount1 == 1) || troughCount1 == 9)
                        break;
                }
                int minBarOsc = UseOscHighLow && BBMACD[1] < BBMACD[0] ? CurrentBar - 1 : CurrentBar;
                double minValueOsc = UseOscHighLow && BBMACD[1] < BBMACD[0] ? BBMACD[1] : BBMACD[0];

                for (int count = 0; count < troughCount1; count++) //find smallest divergence setup
                {
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && Low[0] <= refTroughLow1[count]) || (!IncludeDoubleTopsAndBottoms && Low[0] < refTroughLow1[count]))
                        && Low[0] < Low[1] && Low[0] <= MIN(Low, CurrentBar - refTroughBar1[count] - 2)[1] && refTroughValue1[count] < 0 && refTroughValue1[count] < minValueOsc
                        && refTroughValue1[count] < MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1[count] - 6))[1] && (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1[count])[0] < 0))
                    {
                        bullishPDivMACD[0] = (1.0);
                        bullishTriggerCountMACDBB[0] = (TriggerBars + 1);
                        firstTroughBar1 = refTroughBar1[count];
                        firstTroughLow1 = refTroughLow1[count];
                        firstOscTroughBar1 = refOscTroughBar1[count];
                        firstTroughValue1 = refTroughValue1[count];
                        secondTroughBar1 = CurrentBar;
                        secondTroughLow1 = Low[0];
                        secondOscTroughBar1 = minBarOsc;
                        secondTroughValue1 = minValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBullCandidateOsc1");
                            drawBullishDivCandidateOsc1 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBullCandidatePrice1");
                            drawBullishDivCandidatePrice1 = true;
                        }
                        if (ShowSetupDots)
                            drawBullSetup1 = true;
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] <= refTroughLow1[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] < refTroughLow1[count]))
                        && swingInput[0] < swingInput[1] && swingInput[0] <= MIN(swingInput, CurrentBar - refTroughBar1[count] - 2)[1] && refTroughValue1[count] < 0 && refTroughValue1[count] < minValueOsc
                        && refTroughValue1[count] < MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1[count] - 6))[1] && (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1[count])[0] < 0))
                    {
                        bullishPDivMACD[0] = (1.0);
                        bullishTriggerCountMACDBB[0] = (TriggerBars + 1);
                        firstTroughBar1 = refTroughBar1[count];
                        firstTroughLow1 = refTroughLow1[count];
                        firstOscTroughBar1 = refOscTroughBar1[count];
                        firstTroughValue1 = refTroughValue1[count];
                        secondTroughBar1 = CurrentBar;
                        secondTroughLow1 = swingInput[0];
                        secondOscTroughBar1 = minBarOsc;
                        secondTroughValue1 = minValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBullCandidateOsc1");
                            drawBullishDivCandidateOsc1 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBullCandidatePrice1");
                            drawBullishDivCandidatePrice1 = true;
                        }
                        if (ShowSetupDots)
                            drawBullSetup1 = true;
                        break;
                    }
                    else
                        bullishPDivMACD[0] = (0.0);
                }
                for (int count = troughCount1 - 1; count >= 0; count--) //find largest divergence setup
                {
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && Low[0] <= refTroughLow1[count]) || (!IncludeDoubleTopsAndBottoms && Low[0] < refTroughLow1[count]))
                        && Low[0] < Low[1] && Low[0] <= MIN(Low, CurrentBar - refTroughBar1[count] - 2)[1] && refTroughValue1[count] < 0 && refTroughValue1[count] < minValueOsc
                        && refTroughValue1[count] < MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1[count] - 6))[1] && (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1[count])[0] < 0))
                    {
                        replacementTroughBar1 = refTroughBar1[count];
                        replacementTroughLow1 = refTroughLow1[count];
                        replacementOscTroughBar1 = refOscTroughBar1[count];
                        replacementTroughValue1 = refTroughValue1[count];
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] <= refTroughLow1[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] < refTroughLow1[count]))
                        && swingInput[0] < swingInput[1] && swingInput[0] <= MIN(swingInput, CurrentBar - refTroughBar1[count] - 2)[1] && refTroughValue1[count] < 0 && refTroughValue1[count] < minValueOsc
                        && refTroughValue1[count] < MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1[count] - 6))[1] && (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1[count])[0] < 0))
                    {
                        replacementTroughBar1 = refTroughBar1[count];
                        replacementTroughLow1 = refTroughLow1[count];
                        replacementOscTroughBar1 = refOscTroughBar1[count];
                        replacementTroughValue1 = refTroughValue1[count];
                        break;
                    }
                }

                if (bullishPDivMACD[0] < 0.5)
                {
                    divergenceActive = true;
                    if (bullishTriggerCountMACDBB[1] > 0)
                    {
                        bullishTriggerCountMACDBB[0] = (bullishTriggerCountMACDBB[1] - 1);
                        if (BBMACD[0] < priorSecondTroughValue1)
                        {
                            if (BBMACD[0] > priorFirstTroughValue1)
                            {
                                secondOscTroughBar1 = CurrentBar;
                                secondTroughValue1 = BBMACD[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBullCandidateOsc1");
                                    updateBullishDivCandidateOsc1 = true;
                                    RemoveDrawObject("divBullCandidatePrice1");
                                    updateBullishDivCandidatePrice1 = true;
                                }
                            }
                            else if (BBMACD[0] > priorReplacementTroughValue1)
                            {
                                firstTroughBar1 = replacementTroughBar1;
                                firstTroughLow1 = replacementTroughLow1;
                                firstOscTroughBar1 = replacementOscTroughBar1;
                                firstTroughValue1 = replacementTroughValue1;
                                secondOscTroughBar1 = CurrentBar;
                                secondTroughValue1 = BBMACD[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBullCandidateOsc1");
                                    drawBullishDivCandidateOsc1 = true;
                                    RemoveDrawObject("divBullCandidatePrice1");
                                    drawBullishDivCandidatePrice1 = true;
                                }
                            }
                            else
                            {
                                bullishTriggerCountMACDBB[0] = (0);
                                RemoveDrawObject("divBullCandidateOsc1");
                                RemoveDrawObject("divBullCandidatePrice1");
                                divergenceActive = false;
                            }
                        }
                        else
                        {
                            secondOscTroughBar1 = priorSecondOscTroughBar1;
                            secondTroughValue1 = priorSecondTroughValue1;
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("divBullCandidateOsc1");
                                updateBullishDivCandidateOsc1 = true;
                                RemoveDrawObject("divBullCandidatePrice1");
                                updateBullishDivCandidatePrice1 = true;
                            }
                        }
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low && bullishTriggerCountMACDBB[0] > 0 && Low[0] < MIN(Low, CurrentBar - firstTroughBar1)[1])
                        {
                            secondTroughBar1 = CurrentBar;
                            secondTroughLow1 = Low[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBullCandidatePrice1");
                                if (divergenceActive)
                                    updateBullishDivCandidatePrice1 = true;
                            }
                        }
                        else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bullishTriggerCountMACDBB[0] > 0 && swingInput[0] < MIN(swingInput, CurrentBar - firstTroughBar1)[1])
                        {
                            secondTroughBar1 = CurrentBar;
                            secondTroughLow1 = swingInput[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBullCandidatePrice1");
                                if (divergenceActive)
                                    updateBullishDivCandidatePrice1 = true;
                            }
                        }
                    }
                }

                if (bullishTriggerCountMACDBB[0] > 0)
                {
                    if ((Close[0] > Low[CurrentBar - secondTroughBar1]) && (BBMACD[0] > BBMACD[1]) && Close[0] > Open[0])
                    {
                        if (firstTroughBar1 != memfirstTroughBar1)
                        {
                            cptBullMACDdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                            maxcptBullMACDdiv = 1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        memfirstTroughBar1 = firstTroughBar1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBullMACDdiv = maxcptBullMACDdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bullishMACDDivProjection[0] = (cptBullMACDdiv);//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else bullishMACDDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec						
                }
                else bullishMACDDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec

                #endregion

                #region Bullish Hidden divergences between price and BBMACD #HIDDENDIV
                drawBullishDivOnOsc1H = false;
                drawBullishDivOnPrice1H = false;
                drawArrowUp1H = false;
                drawBullSetup1H = false;

                #region -- IsFirstTickOfBar - {Reset} --
                if (IsFirstTickOfBar)
                {
                    if (hiddenbullishTriggerCountMACDBB[1] > 0)
                    {
                        if ((Close[1] > Low[CurrentBar - secondTroughBar1H]) && (BBMACD[1] > BBMACD[2]) && Close[1] > Open[1])
                        {
                            hiddenbullishCDivMACD[0] = (1.0);
                            hiddenbullishTriggerCountMACDBB[1] = (0);
                            if (!hidePlots && ShowDivOnOscillatorPanel) drawBullishDivOnOsc1H = true;
                            if (ShowDivOnPricePanel) drawBullishDivOnPrice1H = true;
                            if (showArrows) drawArrowUp1H = true;
                            RemoveDrawObject("hiddendivBullCandidateOsc1");
                            RemoveDrawObject("hiddendivBullCandidatePrice1");
                            maxcptBullMACDhdiv++;
                        }
                        else hiddenbullishCDivMACD[0] = (0.0);

                        priorFirstTroughBar1H = firstTroughBar1H;
                        priorFirstOscTroughBar1H = firstOscTroughBar1H;
                        priorFirstTroughLow1H = firstTroughLow1H;
                        priorFirstTroughValue1H = firstTroughValue1H;
                        priorReplacementTroughLow1H = replacementTroughLow1H;
                        priorReplacementTroughValue1H = replacementTroughValue1H;
                        priorSecondTroughBar1H = secondTroughBar1H;
                        priorSecondOscTroughBar1H = secondOscTroughBar1H;
                        priorSecondTroughValue1H = secondTroughValue1H;
                        priorSecondTroughLow1H = secondTroughLow1H;

                        double refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[1] : swingInput[1];
                        if (refinput < firstTroughLow1H)
                        {
                            hiddenbullishTriggerCountMACDBB[1] = (0);
                            RemoveDrawObject("hiddendivBullCandidateOsc1");
                            RemoveDrawObject("hiddendivBullCandidatePrice1");
                        }
                    }
                    else
                    {
                        hiddenbullishCDivMACD[0] = (0.0);
                        RemoveDrawObject("hiddendivBullCandidateOsc1");
                        RemoveDrawObject("hiddendivBullCandidatePrice1");
                    }
                    hiddenbullishPDivMACD[0] = (0.0);
                }
                #endregion

                if (hiddenbullishPDivMACD[0] > 0.5)
                {
                    RemoveDrawObject("hiddendivBullCandidateOsc1");
                    RemoveDrawObject("hiddendivBullCandidatePrice1");
                }

                #region -- reset variables --
                drawBullishDivCandidateOsc1H = false;
                drawBullishDivCandidatePrice1H = false;
                updateBullishDivCandidateOsc1H = false;
                updateBullishDivCandidatePrice1H = false;
                troughCount1H = 0;
                #endregion

                refinput1H_0 = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[0] : swingInput[0];
                refinput1H_1 = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[1] : swingInput[1];
                invalidate1H = BBMACD[0] > MIN(BBMACD, CurrentBar - firstOscTroughBar1H)[1] || refinput1H_0 >= refinput1H_1 ||
                    (IncludeDoubleTopsAndBottoms && refinput1H_0 < firstTroughLow1H) || (!IncludeDoubleTopsAndBottoms && refinput1H_0 <= firstTroughLow1H);

                if (hiddenbullishTriggerCountMACDBB[1] > 0 && invalidate1H)
                {
                    hiddenbullishPDivMACD[0] = (0.0);
                    secondOscTroughBar1H = priorSecondOscTroughBar1H;
                    secondTroughValue1H = priorSecondTroughValue1H;
                    updateBullishDivCandidateOsc1H = true;
                }
                else if (hiddenbullishPDivMACD[0] > 0.5 && invalidate1H)
                {
                    hiddenbullishPDivMACD[0] = (0.0);
                    hiddenbullishTriggerCountMACDBB[0] = (0);
                    secondOscTroughBar1H = priorSecondOscTroughBar1H;
                    secondTroughValue1H = priorSecondTroughValue1H;
                    RemoveDrawObject("hiddendivBullCandidateOsc1");
                    RemoveDrawObject("hiddendivBullCandidatePrice1");
                }

                #region -- get price low and osc low --
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
                    int j = 0;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                        swingMin = MIN(Low, SwingStrength)[1];
                    else
                        swingMin = MIN(Input, SwingStrength)[1];
                    if (swingLowType[i] < 0 || (i > DivMinBars && pre_swingLowType[i] < 0 && upTrend[0] && High[0] > Math.Max(swingMax, currentLow + zigzagDeviation))) // code references zigzag
                    {
                        refTroughBar1H[troughCount1H] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refTroughLow1H[troughCount1H] = Low[i];
                        else
                            refTroughLow1H[troughCount1H] = swingInput[i];

                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 3) && BBMACD[j - 1] < BBMACD[j])
                                j = j - 1;
                            refOscTroughBar1H[troughCount1H] = CurrentBar - j;
                            refTroughValue1H[troughCount1H] = BBMACD[j];
                            troughCount1H++;
                        }
                        else
                        {
                            refOscTroughBar1H[troughCount1H] = CurrentBar - i;
                            refTroughValue1H[troughCount1H] = BBMACD[i];
                            troughCount1H++;
                        }

                    }
                    if ((UseLastSwingOnly && troughCount1H == 1) || troughCount1H == 9) break;
                }
                #endregion

                minBarOsc = UseOscHighLow && BBMACD[1] < BBMACD[0] ? CurrentBar - 1 : CurrentBar;
                minValueOsc = UseOscHighLow && BBMACD[1] < BBMACD[0] ? BBMACD[1] : BBMACD[0];

                #region -- find smallest divergence setup --
                for (int count = 0; count < troughCount1H; count++)
                {
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] >= refTroughLow1H[count]) ||
                        (!IncludeDoubleTopsAndBottoms && refinput[0] > refTroughLow1H[count])) &&
                        refinput[0] < refinput[1] &&
                        refinput[0] <= MIN(refinput, CurrentBar - refTroughBar1H[count] - 2)[1] &&
                        refTroughValue1H[count] < 0 &&
                        refTroughValue1H[count] > minValueOsc &&
                        refTroughValue1H[count] > MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1H[count] - 6))[1] &&
                        (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1H[count])[0] < 0))
                    {
                        hiddenbullishPDivMACD[0] = (1.0);
                        hiddenbullishTriggerCountMACDBB[0] = (TriggerBars + 1);
                        firstTroughBar1H = refTroughBar1H[count];
                        firstTroughLow1H = refTroughLow1H[count];
                        firstOscTroughBar1H = refOscTroughBar1H[count];
                        firstTroughValue1H = refTroughValue1H[count];
                        secondTroughBar1H = CurrentBar;
                        secondTroughLow1H = refinput[0];
                        secondOscTroughBar1H = maxBarOsc;
                        secondTroughValue1H = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("hiddendivBullCandidateOsc1");
                            drawBullishDivCandidateOsc1H = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("hiddendivBullCandidatePrice1");
                            drawBullishDivCandidatePrice1H = true;
                        }
                        if (ShowSetupDots) drawBullSetup1H = true;
                        break;
                    }
                    else hiddenbullishPDivMACD[0] = (0.0);
                }
                #endregion

                #region -- find largest divergence setup --
                for (int count = troughCount1H - 1; count >= 0; count--)
                {
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] >= refTroughLow1H[count]) || (!IncludeDoubleTopsAndBottoms && refinput[0] > refTroughLow1H[count])) &&
                        refinput[0] < refinput[1] &&
                        refinput[0] <= MIN(refinput, CurrentBar - refTroughBar1H[count] - 2)[1] &&
                        refTroughValue1H[count] < 0 &&
                        refTroughValue1H[count] > minValueOsc &&
                        refTroughValue1H[count] > MIN(BBMACD, Math.Max(1, CurrentBar - refOscTroughBar1H[count] - 6))[1] &&
                        (!ResetFilter || MAX(BBMACD, CurrentBar - refOscTroughBar1H[count])[0] < 0))
                    {
                        replacementTroughBar1H = refOscTroughBar1H[count];
                        replacementTroughLow1H = refTroughLow1H[count];
                        replacementOscTroughBar1H = refOscTroughBar1H[count];
                        replacementTroughValue1H = refTroughValue1H[count];
                        break;
                    }
                }
                #endregion

                inputref = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[0] : swingInput[0];
                if (hiddenbullishPDivMACD[0] < 0.5)
                {
                    divergenceActive = true;
                    if (hiddenbullishTriggerCountMACDBB[1] > 0)
                    {
                        hiddenbullishTriggerCountMACDBB[0] = (hiddenbullishTriggerCountMACDBB[1] - 1);
                        if (inputref < priorSecondTroughLow1H)
                        {
                            if (inputref > priorFirstTroughLow1H)//price stays above
                            {
                                secondTroughBar1H = CurrentBar;
                                secondTroughLow1H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBullCandidateOsc1");
                                    drawBullishDivCandidateOsc1H = true;
                                    RemoveDrawObject("hiddendivBullCandidatePrice1");
                                    drawBullishDivCandidatePrice1H = true;
                                }
                            }
                            else if (inputref > priorReplacementTroughLow1H)
                            {
                                firstTroughBar1H = replacementTroughBar1H;
                                firstTroughLow1H = replacementTroughLow1H;
                                firstOscTroughBar1H = replacementOscTroughBar1H;
                                firstTroughValue1H = replacementTroughValue1H;
                                secondTroughBar1H = CurrentBar;
                                secondTroughLow1H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBullCandidateOsc1");
                                    drawBullishDivCandidateOsc1H = true;
                                    RemoveDrawObject("hiddendivBullCandidatePrice1");
                                    drawBullishDivCandidatePrice1H = true;
                                }
                            }
                            else
                            {
                                hiddenbullishTriggerCountMACDBB[0] = (0);
                                RemoveDrawObject("hiddendivBullCandidateOsc1");
                                RemoveDrawObject("hiddendivBullCandidatePrice1");
                                divergenceActive = false;
                            }
                        }
                        else
                        {
                            secondTroughBar1H = priorSecondTroughBar1H;
                            secondTroughLow1H = priorSecondTroughLow1H;
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBullCandidateOsc1");
                                updateBullishDivCandidateOsc1H = true;
                                RemoveDrawObject("hiddendivBullCandidatePrice1");
                                updateBullishDivCandidatePrice1H = true;
                            }
                        }
                        if (hiddenbullishTriggerCountMACDBB[0] > 0 && BBMACD[0] < MIN(BBMACD, CurrentBar - firstOscTroughBar1H)[1])
                        {
                            secondOscTroughBar1H = CurrentBar;
                            secondTroughValue1H = BBMACD[0];
                            if (ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBullCandidateOsc1");
                                if (divergenceActive) updateBullishDivCandidateOsc1H = true;
                            }
                        }
                    }
                }

                if (hiddenbullishTriggerCountMACDBB[0] > 0)
                {
                    if ((Close[0] > Low[CurrentBar - secondTroughBar1H]) && (BBMACD[0] > BBMACD[1]) && Close[0] > Open[0])
                    {
                        if (firstTroughBar1H != memfirstTroughBar1H)
                        {
                            cptBullMACDhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                            maxcptBullMACDhdiv = 1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        memfirstTroughBar1H = firstTroughBar1H;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBullMACDhdiv = maxcptBullMACDhdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bullishMACDHiddenDivProjection[0] = (cptBullMACDhdiv);//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else bullishMACDHiddenDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec						
                }
                else bullishMACDHiddenDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec

                #endregion

                #region Bearish divergences between price and histogram
                bool drawBearishDivOnOsc2 = false;
                bool drawBearishDivOnPrice2 = false;
                bool drawArrowDown2 = false;
                if (IsFirstTickOfBar)
                {
                    if (bearishTriggerCountHistogram[1] > 0)
                    {
                        if ((Close[1] < High[CurrentBar - secondPeakBar2]) && (Histogram[1] < Histogram[2]) && Close[1] < Open[1])
                        {
                            bearishCDivHistogram[0] = (1.0);
                            bearishTriggerCountHistogram[1] = (0);
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                                drawBearishDivOnOsc2 = true;
                            if (ShowDivOnPricePanel)
                                drawBearishDivOnPrice2 = true;
                            if (showArrows)
                                drawArrowDown2 = true;
                            RemoveDrawObject("divBearCandidateOsc2");
                            RemoveDrawObject("divBearCandidatePrice2");
                            maxcptBearHistogramdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        else
                            bearishCDivHistogram[0] = (0.0);
                        priorFirstPeakBar2 = firstPeakBar2;
                        priorFirstOscPeakBar2 = firstOscPeakBar2;
                        priorFirstPeakHigh2 = firstPeakHigh2;
                        priorFirstPeakValue2 = firstPeakValue2;
                        priorReplacementPeakValue2 = replacementPeakValue2;
                        priorSecondPeakBar2 = secondPeakBar2;
                        priorSecondOscPeakBar2 = secondOscPeakBar2;
                        priorSecondPeakHigh2 = secondPeakHigh2;
                        priorSecondPeakValue2 = secondPeakValue2;
                        if (Histogram[1] > firstPeakValue2)
                        {
                            bearishTriggerCountHistogram[1] = (0);
                            RemoveDrawObject("divBearCandidateOsc2");
                            RemoveDrawObject("divBearCandidatePrice2");
                        }
                    }
                    else
                    {
                        bearishCDivHistogram[0] = (0.0);
                        {
                            RemoveDrawObject("divBearCandidateOsc2");
                            RemoveDrawObject("divBearCandidatePrice2");
                        }
                    }
                    bearishPDivHistogram[0] = (0.0);
                }
                if (bearishPDivHistogram[0] > 0.5)
                {
                    RemoveDrawObject("divBearCandidateOsc2");
                    RemoveDrawObject("divBearCandidatePrice2");
                }
                bool drawBearishDivCandidateOsc2 = false;
                bool drawBearishDivCandidatePrice2 = false;
                bool updateBearishDivCandidateOsc2 = false;
                bool updateBearishDivCandidatePrice2 = false;
                bool drawBearSetup2 = false;
                invalidate = swingInput[0] <= swingInput[1] || (IncludeDoubleTopsAndBottoms && swingInput[0] < firstPeakHigh2) || (!IncludeDoubleTopsAndBottoms && swingInput[0] <= firstPeakHigh2);
                if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bearishTriggerCountHistogram[1] > 0 && invalidate)
                {
                    bearishPDivHistogram[0] = (0.0);
                    secondPeakBar2 = priorSecondPeakBar2;
                    secondPeakHigh2 = priorSecondPeakHigh2;
                    updateBearishDivCandidatePrice2 = true;
                }
                else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bearishPDivHistogram[0] > 0.5 && invalidate)
                {
                    bearishPDivHistogram[0] = (0.0);
                    bearishTriggerCountHistogram[0] = (0);
                    secondPeakBar2 = priorSecondPeakBar2;
                    secondPeakHigh2 = priorSecondPeakHigh2;
                    RemoveDrawObject("divBearCandidateOsc2");
                    RemoveDrawObject("divBearCandidatePrice2");
                }
                bool firstPeakFound2 = false;
                peakCount2 = 0;
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
                    int j = 0;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                        swingMax = MAX(High, SwingStrength)[1];
                    else
                        swingMax = MAX(Input, SwingStrength)[1];
                    if (swingHighType[i] > 0 || (i > DivMinBars && pre_swingHighType[i] > 0 && !upTrend[0] && Low[0] < Math.Min(swingMin, currentHigh - zigzagDeviation))) // code references zigzag
                    {
                        refPeakBar2[peakCount2] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refPeakHigh2[peakCount2] = High[i];
                        else
                            refPeakHigh2[peakCount2] = swingInput[i];
                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 4) && Histogram[j - 1] > Histogram[j])
                                j = j - 1;
                            refOscPeakBar2[peakCount2] = CurrentBar - j;
                            refPeakValue2[peakCount2] = Histogram[j];
                            peakCount2 = peakCount2 + 1;
                        }
                        else
                        {
                            refOscPeakBar2[peakCount2] = CurrentBar - i;
                            refPeakValue2[peakCount2] = Histogram[i];
                            peakCount2 = peakCount2 + 1;
                        }
                    }
                    if ((UseLastSwingOnly && peakCount2 == 1) || peakCount2 == 9)
                        break;
                }
                if (UseOscHighLow && Histogram[1] > Histogram[0])
                {
                    maxBarOsc = CurrentBar - 1;
                    maxValueOsc = Histogram[1];
                }
                else
                {
                    maxBarOsc = CurrentBar;
                    maxValueOsc = Histogram[0];
                }
                for (int count = 0; count < peakCount2; count++) //find smallest divergence setup
                {
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && High[0] >= refPeakHigh2[count]) || (!IncludeDoubleTopsAndBottoms && High[0] > refPeakHigh2[count]))
                        && High[0] > High[1] && High[0] >= MAX(High, CurrentBar - refPeakBar2[count] - 2)[1] && refPeakValue2[count] > 0 && refPeakValue2[count] > maxValueOsc
                        && refPeakValue2[count] > MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2[count] - 6))[1] && (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2[count])[0] > 0))
                    {
                        bearishPDivHistogram[0] = (1.0);
                        bearishTriggerCountHistogram[0] = (TriggerBars + 1);
                        firstPeakBar2 = refPeakBar2[count];
                        firstPeakHigh2 = refPeakHigh2[count];
                        firstOscPeakBar2 = refOscPeakBar2[count];
                        firstPeakValue2 = refPeakValue2[count];
                        secondPeakBar2 = CurrentBar;
                        secondPeakHigh2 = High[0];
                        secondOscPeakBar2 = maxBarOsc;
                        secondPeakValue2 = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBearCandidateOsc2");
                            drawBearishDivCandidateOsc2 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBearCandidatePrice2");
                            drawBearishDivCandidatePrice2 = true;
                        }
                        if (ShowSetupDots)
                            drawBearSetup2 = true;
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] >= refPeakHigh2[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] > refPeakHigh2[count]))
                        && swingInput[0] > swingInput[1] && swingInput[0] >= MAX(swingInput, CurrentBar - refPeakBar2[count] - 2)[1] && refPeakValue2[count] > 0 && refPeakValue2[count] > maxValueOsc
                        && refPeakValue2[count] > MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2[count] - 6))[1] && (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2[count])[0] > 0))
                    {
                        bearishPDivHistogram[0] = (1.0);
                        bearishTriggerCountHistogram[0] = (TriggerBars + 1);
                        firstPeakBar2 = refPeakBar2[count];
                        firstPeakHigh2 = refPeakHigh2[count];
                        firstOscPeakBar2 = refOscPeakBar2[count];
                        firstPeakValue2 = refPeakValue2[count];
                        secondPeakBar2 = CurrentBar;
                        secondPeakHigh2 = swingInput[0];
                        secondOscPeakBar2 = maxBarOsc;
                        secondPeakValue2 = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBearCandidateOsc2");
                            drawBearishDivCandidateOsc2 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBearCandidatePrice2");
                            drawBearishDivCandidatePrice2 = true;
                        }
                        if (ShowSetupDots)
                            drawBearSetup2 = true;
                        break;
                    }
                    else
                        bearishPDivHistogram[0] = (0.0);
                }
                for (int count = peakCount2 - 1; count >= 0; count--) //find largest divergence setup
                {
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && High[0] >= refPeakHigh2[count]) || (!IncludeDoubleTopsAndBottoms && High[0] > refPeakHigh2[count]))
                        && High[0] > High[1] && High[0] >= MAX(High, CurrentBar - refPeakBar2[count] - 2)[1] && refPeakValue2[count] > 0 && refPeakValue2[count] > maxValueOsc
                        && refPeakValue2[count] > MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2[count] - 6))[1] && (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2[count])[0] > 0))
                    {
                        replacementPeakBar2 = refPeakBar2[count];
                        replacementPeakHigh2 = refPeakHigh2[count];
                        replacementOscPeakBar2 = refOscPeakBar2[count];
                        replacementPeakValue2 = refPeakValue2[count];
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] >= refPeakHigh2[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] > refPeakHigh2[count]))
                        && swingInput[0] > swingInput[1] && swingInput[0] >= MAX(swingInput, CurrentBar - refPeakBar2[count] - 2)[1] && refPeakValue2[count] > 0 && refPeakValue2[count] > maxValueOsc
                        && refPeakValue2[count] > MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2[count] - 6))[1] && (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2[count])[0] > 0))
                    {
                        replacementPeakBar2 = refPeakBar2[count];
                        replacementPeakHigh2 = refPeakHigh2[count];
                        replacementOscPeakBar2 = refOscPeakBar2[count];
                        replacementPeakValue2 = refPeakValue2[count];
                        break;
                    }
                }
                if (bearishPDivHistogram[0] < 0.5)
                {
                    divergenceActive = true;
                    if (bearishTriggerCountHistogram[1] > 0)
                    {
                        bearishTriggerCountHistogram[0] = (bearishTriggerCountHistogram[1] - 1);
                        if (Histogram[0] > priorSecondPeakValue2)
                        {
                            if (Histogram[0] < priorFirstPeakValue2)
                            {
                                secondOscPeakBar2 = CurrentBar;
                                secondPeakValue2 = Histogram[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBearCandidateOsc2");
                                    updateBearishDivCandidateOsc2 = true;
                                    RemoveDrawObject("divBearCandidatePrice2");
                                    updateBearishDivCandidatePrice2 = true;
                                }
                            }
                            else if (Histogram[0] < priorReplacementPeakValue2)
                            {
                                firstPeakBar2 = replacementPeakBar2;
                                firstPeakHigh2 = replacementPeakHigh2;
                                firstOscPeakBar2 = replacementOscPeakBar2;
                                firstPeakValue2 = replacementPeakValue2;
                                secondOscPeakBar2 = CurrentBar;
                                secondPeakValue2 = Histogram[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBearCandidateOsc2");
                                    drawBearishDivCandidateOsc2 = true;
                                    RemoveDrawObject("divBearCandidatePrice2");
                                    drawBearishDivCandidatePrice2 = true;
                                }
                            }
                            else
                            {
                                bearishTriggerCountHistogram[0] = (0);
                                RemoveDrawObject("divBearCandidateOsc2");
                                RemoveDrawObject("divBearCandidatePrice2");
                                divergenceActive = false;
                            }
                        }
                        else
                        {
                            secondOscPeakBar2 = priorSecondOscPeakBar2;
                            secondPeakValue2 = priorSecondPeakValue2;
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("divBearCandidateOsc2");
                                updateBearishDivCandidateOsc2 = true;
                                RemoveDrawObject("divBearCandidatePrice2");
                                updateBearishDivCandidatePrice2 = true;
                            }
                        }
                        if (divergenceActive && ThisInputType == ARC_VMDSystem_InputType.High_Low && bearishTriggerCountHistogram[0] > 0 && High[0] > MAX(High, CurrentBar - firstPeakBar2)[1])
                        {
                            secondPeakBar2 = CurrentBar;
                            secondPeakHigh2 = High[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBearCandidatePrice2");
                                if (divergenceActive)
                                    updateBearishDivCandidatePrice2 = true;
                            }
                        }
                        else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bearishTriggerCountHistogram[0] > 0 && swingInput[0] > MAX(swingInput, CurrentBar - firstPeakBar2)[1])
                        {
                            secondPeakBar2 = CurrentBar;
                            secondPeakHigh2 = swingInput[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBearCandidatePrice2");
                                if (divergenceActive)
                                    updateBearishDivCandidatePrice2 = true;
                            }
                        }
                    }
                }

                if (bearishTriggerCountHistogram[0] > 0)
                {
                    if ((Close[0] < High[CurrentBar - secondPeakBar2]) && (Histogram[0] < Histogram[1]) && Close[0] < Open[0])
                    {
                        if (firstPeakBar2 != memfirstPeakBar2)
                        {
                            cptBearHistogramdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                            maxcptBearHistogramdiv = 1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        memfirstPeakBar2 = firstPeakBar2;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBearHistogramdiv = maxcptBearHistogramdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bearishHistogramDivProjection[0] = (cptBearHistogramdiv);//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else bearishHistogramDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec						
                }
                else bearishHistogramDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec
                #endregion

                #region Bearish Hidden divergences between price and Histogram #HIDDENDIV
                drawBearishDivOnOsc2H = false;
                drawBearishDivOnPrice2H = false;
                drawArrowDown2H = false;
                drawBearSetup2H = false;

                #region -- IsFirstTickOfBar - {Reset} --
                if (IsFirstTickOfBar)
                {
                    if (hiddenbearishTriggerCountHistogram[1] > 0)
                    {
                        if ((Close[1] < High[CurrentBar - secondPeakBar2H]) && (Histogram[1] < Histogram[2]) && Close[1] < Open[1])
                        {
                            hiddenbearishCDivHistogram[0] = (1.0);
                            hiddenbearishTriggerCountHistogram[1] = (0);
                            if (!hidePlots && ShowDivOnOscillatorPanel) drawBearishDivOnOsc2H = true;
                            if (ShowDivOnPricePanel) drawBearishDivOnPrice2H = true;
                            if (showArrows) drawArrowDown2H = true;
                            RemoveDrawObject("hiddendivBearCandidateOsc2");
                            RemoveDrawObject("hiddendivBearCandidatePrice2");
                            maxcptBearHistogramhdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        else
                            hiddenbearishCDivHistogram[0] = (0.0);

                        priorFirstPeakBar2H = firstPeakBar2H;
                        priorFirstOscPeakBar2H = firstOscPeakBar2H;
                        priorFirstPeakHigh2H = firstPeakHigh2H;
                        priorFirstPeakValue2H = firstPeakValue2H;
                        priorReplacementPeakHigh2H = replacementPeakHigh2H;
                        priorReplacementPeakValue2H = replacementPeakValue2H;
                        priorSecondPeakBar2H = secondPeakBar2H;
                        priorSecondOscPeakBar2H = secondOscPeakBar2H;
                        priorSecondPeakValue2H = secondPeakValue2H;
                        priorSecondPeakHigh2H = secondPeakHigh2H;

                        double refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[1] : swingInput[1];
                        if (refinput > firstPeakHigh2H)
                        {
                            hiddenbearishTriggerCountHistogram[1] = (0);
                            RemoveDrawObject("hiddendivBearCandidateOsc2");
                            RemoveDrawObject("hiddendivBearCandidatePrice2");
                        }
                    }
                    else
                    {
                        hiddenbearishCDivHistogram[0] = (0.0);
                        RemoveDrawObject("hiddendivBearCandidateOsc2");
                        RemoveDrawObject("hiddendivBearCandidatePrice2");
                    }
                    hiddenbearishPDivHistogram[0] = (0.0);
                }
                #endregion

                if (hiddenbearishPDivHistogram[0] > 0.5)
                {
                    RemoveDrawObject("hiddendivBearCandidateOsc2");
                    RemoveDrawObject("hiddendivBearCandidatePrice2");
                }

                #region -- reset variables --
                drawBearishDivCandidateOsc2H = false;
                drawBearishDivCandidatePrice2H = false;
                updateBearishDivCandidateOsc2H = false;
                updateBearishDivCandidatePrice2H = false;
                peakCount2H = 0;
                #endregion

                double refinput2H_0 = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[0] : swingInput[0];
                double refinput2H_1 = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[1] : swingInput[1];
                bool invalidate2H = Histogram[0] < MAX(Histogram, CurrentBar - firstOscPeakBar2H)[1] || refinput2H_0 <= refinput2H_1 ||
                    (IncludeDoubleTopsAndBottoms && refinput2H_0 > firstPeakHigh2H) || (!IncludeDoubleTopsAndBottoms && refinput2H_0 >= firstPeakHigh2H);

                if (hiddenbearishTriggerCountHistogram[1] > 0 && invalidate2H)
                {
                    hiddenbearishPDivHistogram[0] = (0.0);
                    secondOscPeakBar2H = priorSecondOscPeakBar2H;
                    secondPeakValue2H = priorSecondPeakValue2H;
                    updateBearishDivCandidateOsc2H = true;
                }
                else if (hiddenbearishPDivHistogram[0] > 0.5 && invalidate2H)
                {
                    hiddenbearishPDivHistogram[0] = (0.0);
                    hiddenbearishTriggerCountHistogram[0] = (0);
                    secondOscPeakBar2H = priorSecondOscPeakBar2H;
                    secondPeakValue2H = priorSecondPeakValue2H;
                    RemoveDrawObject("hiddendivBearCandidateOsc2");
                    RemoveDrawObject("hiddendivBearCandidatePrice2");
                }

                #region -- get price top and osc top --
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
                    int j = 0;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                        swingMax = MAX(High, SwingStrength)[1];
                    else
                        swingMax = MAX(Input, SwingStrength)[1];
                    if (swingHighType[i] > 0 || (i > DivMinBars && pre_swingHighType[i] > 0 && !upTrend[0] && Low[0] < Math.Min(swingMin, currentHigh - zigzagDeviation))) // code references zigzag
                    {
                        refPeakBar2H[peakCount2H] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refPeakHigh2H[peakCount2H] = High[i];
                        else
                            refPeakHigh2H[peakCount2H] = swingInput[i];

                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 4) && Histogram[j - 1] > Histogram[j])
                                j = j - 1;
                            refOscPeakBar2H[peakCount2H] = CurrentBar - j;
                            refPeakValue2H[peakCount2H] = Histogram[j];
                            peakCount2H = peakCount2H + 1;
                        }
                        else
                        {
                            refOscPeakBar2H[peakCount2H] = CurrentBar - i;
                            refPeakValue2H[peakCount2H] = Histogram[i];
                            peakCount2H = peakCount2H + 1;
                        }
                    }
                    if ((UseLastSwingOnly && peakCount2H == 1) || peakCount2H == 9) break;
                }
                #endregion

                maxBarOsc = UseOscHighLow && Histogram[1] > Histogram[0] ? CurrentBar - 1 : CurrentBar;
                maxValueOsc = UseOscHighLow && Histogram[1] > Histogram[0] ? Histogram[1] : Histogram[0];

                #region -- find smallest divergence setup --
                for (int count = 0; count < peakCount2H; count++)
                {
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] <= refPeakHigh2H[count]) ||
                        (!IncludeDoubleTopsAndBottoms && refinput[0] < refPeakHigh2H[count])) &&
                        refinput[0] > refinput[1] &&
                        refinput[0] >= MAX(refinput, CurrentBar - refPeakBar2H[count] - 2)[1] &&
                        refPeakValue2H[count] > 0 &&
                        refPeakValue2H[count] < maxValueOsc &&
                        refPeakValue2H[count] < MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2H[count] - 6))[1] &&
                        (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2H[count])[0] > 0))
                    {
                        hiddenbearishPDivHistogram[0] = (1.0);
                        hiddenbearishTriggerCountHistogram[0] = (TriggerBars + 1);
                        firstPeakBar2H = refPeakBar2H[count];
                        firstPeakHigh2H = refPeakHigh2H[count];
                        firstOscPeakBar2H = refOscPeakBar2H[count];
                        firstPeakValue2H = refPeakValue2H[count];
                        secondPeakBar2H = CurrentBar;
                        secondPeakHigh2H = refinput[0];
                        secondOscPeakBar2H = maxBarOsc;
                        secondPeakValue2H = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("hiddendivBearCandidateOsc2");
                            drawBearishDivCandidateOsc2H = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("hiddendivBearCandidatePrice2");
                            drawBearishDivCandidatePrice2H = true;
                        }
                        if (ShowSetupDots) drawBearSetup2H = true;
                        break;
                    }
                    else hiddenbearishPDivHistogram[0] = (0.0);
                }
                #endregion

                #region -- find largest divergence setup --
                for (int count = peakCount2H - 1; count >= 0; count--)
                {
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] <= refPeakHigh2H[count]) || (!IncludeDoubleTopsAndBottoms && refinput[0] < refPeakHigh2H[count])) &&
                        refinput[0] > refinput[1] &&
                        refinput[0] >= MAX(refinput, CurrentBar - refPeakBar2H[count] - 2)[1] &&
                        refPeakValue2H[count] > 0 &&
                        refPeakValue2H[count] < maxValueOsc &&
                        refPeakValue2H[count] < MAX(Histogram, Math.Max(1, CurrentBar - refOscPeakBar2H[count] - 6))[1] &&
                        (!ResetFilter || MIN(Histogram, CurrentBar - refOscPeakBar2H[count])[0] > 0))
                    {
                        replacementPeakBar2H = refPeakBar2H[count];
                        replacementPeakHigh2H = refPeakHigh2H[count];
                        replacementOscPeakBar2H = refOscPeakBar2H[count];
                        replacementPeakValue2H = refPeakValue2H[count];
                        break;
                    }
                }
                #endregion

                inputref = ThisInputType == ARC_VMDSystem_InputType.High_Low ? High[0] : swingInput[0];
                if (hiddenbearishPDivHistogram[0] < 0.5)
                {
                    divergenceActive = true;
                    if (hiddenbearishTriggerCountHistogram[1] > 0)
                    {
                        hiddenbearishTriggerCountHistogram[0] = (hiddenbearishTriggerCountHistogram[1] - 1);
                        if (inputref > priorSecondPeakHigh2H)
                        {
                            if (inputref < priorFirstPeakHigh2H)//price stays below
                            {
                                secondPeakBar2H = CurrentBar;
                                secondPeakHigh2H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBearCandidateOsc2");
                                    updateBearishDivCandidateOsc2H = true;
                                    RemoveDrawObject("hiddendivBearCandidatePrice2");
                                    updateBearishDivCandidatePrice2H = true;
                                }
                            }
                            else if (inputref < priorReplacementPeakHigh2H)
                            {
                                firstPeakBar2H = replacementPeakBar2H;
                                firstPeakHigh2H = replacementPeakHigh2H;
                                firstOscPeakBar2H = replacementOscPeakBar2H;
                                firstPeakValue2H = replacementPeakValue2H;
                                secondPeakBar2H = CurrentBar;
                                secondPeakHigh2H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBearCandidateOsc2");
                                    drawBearishDivCandidateOsc2H = true;
                                    RemoveDrawObject("hiddendivBearCandidatePrice2");
                                    drawBearishDivCandidatePrice2H = true;
                                }
                            }
                            else
                            {
                                hiddenbearishTriggerCountHistogram[0] = (0);
                                RemoveDrawObject("hiddendivBearCandidateOsc2");
                                RemoveDrawObject("hiddendivBearCandidatePrice2");
                                divergenceActive = false;
                            }
                        }
                        else
                        {
                            secondPeakBar2H = priorSecondPeakBar2H;
                            secondPeakHigh2H = priorSecondPeakHigh2H;
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBearCandidateOsc2");
                                updateBearishDivCandidateOsc2H = true;
                                RemoveDrawObject("hiddendivBearCandidatePrice2");
                                updateBearishDivCandidatePrice2H = true;
                            }
                        }
                        if (hiddenbearishTriggerCountHistogram[0] > 0 && Histogram[0] > MAX(Histogram, CurrentBar - firstOscPeakBar2H)[1])
                        {
                            secondOscPeakBar2H = CurrentBar;
                            secondPeakValue2H = Histogram[0];
                            if (ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBearCandidateOsc2");
                                if (divergenceActive) updateBearishDivCandidateOsc2H = true;
                            }
                        }
                    }
                }

                if (hiddenbearishTriggerCountHistogram[0] > 0)
                {
                    if ((Close[0] < High[CurrentBar - secondPeakBar2H]) && (Histogram[0] < Histogram[1]) && Close[0] < Open[0])
                    {
                        if (firstPeakBar2H != memfirstPeakBar2H)
                        {
                            cptBearHistogramhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                            maxcptBearHistogramhdiv = 1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        memfirstPeakBar2H = firstPeakBar2H;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBearHistogramhdiv = maxcptBearHistogramhdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bearishHistogramHiddenDivProjection[0] = (cptBearHistogramhdiv);//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else bearishHistogramHiddenDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec						
                }
                else bearishHistogramHiddenDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec

                #endregion

                #region Bullish divergences between price and histogram
                bool drawBullishDivOnOsc2 = false;
                bool drawBullishDivOnPrice2 = false;
                bool drawArrowUp2 = false;
                if (IsFirstTickOfBar)
                {
                    if (bullishTriggerCountHistogram[1] > 0)
                    {
                        if ((Close[1] > Low[CurrentBar - secondTroughBar2]) && (Histogram[1] > Histogram[2]) && Close[1] > Open[1])
                        {
                            bullishCDivHistogram[0] = (1.0);
                            bullishTriggerCountHistogram[1] = (0);
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                                drawBullishDivOnOsc2 = true;
                            if (ShowDivOnPricePanel)
                                drawBullishDivOnPrice2 = true;
                            if (showArrows)
                                drawArrowUp2 = true;
                            RemoveDrawObject("divBullCandidateOsc2");
                            RemoveDrawObject("divBullCandidatePrice2");
                            maxcptBullHistogramdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        else
                            bullishCDivHistogram[0] = (0.0);
                        priorFirstTroughBar2 = firstTroughBar2;
                        priorFirstOscTroughBar2 = firstOscTroughBar2;
                        priorFirstTroughLow2 = firstTroughLow2;
                        priorFirstTroughValue2 = firstTroughValue2;
                        priorReplacementTroughValue2 = replacementTroughValue2;
                        priorSecondTroughBar2 = secondTroughBar2;
                        priorSecondOscTroughBar2 = secondOscTroughBar2;
                        priorSecondTroughLow2 = secondTroughLow2;
                        priorSecondTroughValue2 = secondTroughValue2;
                        if (Histogram[1] < firstTroughValue2)
                        {
                            bullishTriggerCountHistogram[1] = (0);
                            RemoveDrawObject("divBullCandidateOsc2");
                            RemoveDrawObject("divBullCandidatePrice2");
                        }
                    }
                    else
                    {
                        bullishCDivHistogram[0] = (0.0);
                        {
                            RemoveDrawObject("divBullCandidateOsc2");
                            RemoveDrawObject("divBullCandidatePrice2");
                        }
                    }
                    bullishPDivHistogram[0] = (0.0);
                }
                if (bullishPDivHistogram[0] > 0.5)
                {
                    RemoveDrawObject("divBullCandidateOsc2");
                    RemoveDrawObject("divBullCandidatePrice2");
                }
                bool drawBullishDivCandidateOsc2 = false;
                bool drawBullishDivCandidatePrice2 = false;
                bool updateBullishDivCandidateOsc2 = false;
                bool updateBullishDivCandidatePrice2 = false;
                bool drawBullSetup2 = false;
                invalidate = swingInput[0] >= swingInput[1] || (IncludeDoubleTopsAndBottoms && swingInput[0] > firstTroughLow2) || (!IncludeDoubleTopsAndBottoms && swingInput[0] >= firstTroughLow2);
                if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bullishTriggerCountHistogram[1] > 0 && invalidate)
                {
                    bullishPDivHistogram[0] = (0.0);
                    secondTroughBar2 = priorSecondTroughBar2;
                    secondTroughLow2 = priorSecondTroughLow2;
                    updateBullishDivCandidatePrice2 = true;
                }
                else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bullishPDivHistogram[0] > 0.5 && invalidate)
                {
                    bullishPDivHistogram[0] = (0.0);
                    bullishTriggerCountHistogram[0] = (0);
                    secondTroughBar2 = priorSecondTroughBar2;
                    secondTroughLow2 = priorSecondTroughLow2;
                    RemoveDrawObject("divBullCandidateOsc2");
                    RemoveDrawObject("divBullCandidatePrice2");
                }
                bool firstTroughFound2 = false;
                troughCount2 = 0;
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
                    int j = 0;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                        swingMin = MIN(Low, SwingStrength)[1];
                    else
                        swingMin = MIN(Input, SwingStrength)[1];
                    if (swingLowType[i] < 0 || (i > DivMinBars && pre_swingLowType[i] < 0 && upTrend[0] && High[0] > Math.Max(swingMax, currentLow + zigzagDeviation))) // code references zigzag 
                    {
                        refTroughBar2[troughCount2] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refTroughLow2[troughCount2] = Low[i];
                        else
                            refTroughLow2[troughCount2] = swingInput[i];
                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 3) && Histogram[j - 1] < Histogram[j])
                                j = j - 1;
                            refOscTroughBar2[troughCount2] = CurrentBar - j;
                            refTroughValue2[troughCount2] = Histogram[j];
                            troughCount2 = troughCount2 + 1;
                        }
                        else
                        {
                            refOscTroughBar2[troughCount2] = CurrentBar - i;
                            refTroughValue2[troughCount2] = Histogram[i];
                            troughCount2 = troughCount2 + 1;
                        }
                    }
                    if ((UseLastSwingOnly && troughCount2 == 1) || troughCount2 == 9)
                        break;
                }
                if (UseOscHighLow && Histogram[1] < Histogram[0])
                {
                    minBarOsc = CurrentBar - 1;
                    minValueOsc = Histogram[1];
                }
                else
                {
                    minBarOsc = CurrentBar;
                    minValueOsc = Histogram[0];
                }
                for (int count = 0; count < troughCount2; count++) //find smallest divergence setup
                {
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && Low[0] <= refTroughLow2[count]) || (!IncludeDoubleTopsAndBottoms && Low[0] < refTroughLow2[count]))
                        && Low[0] < Low[1] && Low[0] <= MIN(Low, CurrentBar - refTroughBar2[count] - 2)[1] && refTroughValue2[count] < 0 && refTroughValue2[count] < minValueOsc
                        && refTroughValue2[count] < MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2[count] - 6))[1] && (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2[count])[0] < 0))
                    {
                        bullishPDivHistogram[0] = (1.0);
                        bullishTriggerCountHistogram[0] = (TriggerBars + 1);
                        firstTroughBar2 = refTroughBar2[count];
                        firstTroughLow2 = refTroughLow2[count];
                        firstOscTroughBar2 = refOscTroughBar2[count];
                        firstTroughValue2 = refTroughValue2[count];
                        secondTroughBar2 = CurrentBar;
                        secondTroughLow2 = Low[0];
                        secondOscTroughBar2 = minBarOsc;
                        secondTroughValue2 = minValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBullCandidateOsc2");
                            drawBullishDivCandidateOsc2 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBullCandidatePrice2");
                            drawBullishDivCandidatePrice2 = true;
                        }
                        if (ShowSetupDots)
                            drawBullSetup2 = true;
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] <= refTroughLow2[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] < refTroughLow2[count]))
                        && swingInput[0] < swingInput[1] && swingInput[0] <= MIN(swingInput, CurrentBar - refTroughBar2[count] - 2)[1] && refTroughValue2[count] < 0 && refTroughValue2[count] < minValueOsc
                        && refTroughValue2[count] < MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2[count] - 6))[1] && (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2[count])[0] < 0))
                    {
                        bullishPDivHistogram[0] = (1.0);
                        bullishTriggerCountHistogram[0] = (TriggerBars + 1);
                        firstTroughBar2 = refTroughBar2[count];
                        firstTroughLow2 = refTroughLow2[count];
                        firstOscTroughBar2 = refOscTroughBar2[count];
                        firstTroughValue2 = refTroughValue2[count];
                        secondTroughBar2 = CurrentBar;
                        secondTroughLow2 = swingInput[0];
                        secondOscTroughBar2 = minBarOsc;
                        secondTroughValue2 = minValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("divBullCandidateOsc2");
                            drawBullishDivCandidateOsc2 = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("divBullCandidatePrice2");
                            drawBullishDivCandidatePrice2 = true;
                        }
                        if (ShowSetupDots)
                            drawBullSetup2 = true;
                        break;
                    }
                    bullishPDivHistogram[0] = (0.0);
                }
                for (int count = troughCount2 - 1; count >= 0; count--) //find largest divergence setup
                {
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && Low[0] <= refTroughLow2[count]) || (!IncludeDoubleTopsAndBottoms && Low[0] < refTroughLow2[count]))
                        && Low[0] < Low[1] && Low[0] <= MIN(Low, CurrentBar - refTroughBar2[count] - 2)[1] && refTroughValue2[count] < 0 && refTroughValue2[count] < minValueOsc
                        && refTroughValue2[count] < MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2[count] - 6))[1] && (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2[count])[0] < 0))
                    {
                        replacementTroughBar2 = refTroughBar2[count];
                        replacementTroughLow2 = refTroughLow2[count];
                        replacementOscTroughBar2 = refOscTroughBar2[count];
                        replacementTroughValue2 = refTroughValue2[count];
                        break;
                    }
                    else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && ((IncludeDoubleTopsAndBottoms && swingInput[0] <= refTroughLow2[count]) || (!IncludeDoubleTopsAndBottoms && swingInput[0] < refTroughLow2[count]))
                        && swingInput[0] < swingInput[1] && swingInput[0] <= MIN(swingInput, CurrentBar - refTroughBar2[count] - 2)[1] && refTroughValue2[count] < 0 && refTroughValue2[count] < minValueOsc
                        && refTroughValue2[count] < MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2[count] - 6))[1] && (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2[count])[0] < 0))
                    {
                        replacementTroughBar2 = refTroughBar2[count];
                        replacementTroughLow2 = refTroughLow2[count];
                        replacementOscTroughBar2 = refOscTroughBar2[count];
                        replacementTroughValue2 = refTroughValue2[count];
                        break;
                    }
                }
                if (bullishPDivHistogram[0] < 0.5)
                {
                    divergenceActive = true;
                    if (bullishTriggerCountHistogram[1] > 0)
                    {
                        bullishTriggerCountHistogram[0] = (bullishTriggerCountHistogram[1] - 1);
                        if (Histogram[0] < priorSecondTroughValue2)
                        {
                            if (Histogram[0] > priorFirstTroughValue2)
                            {
                                secondOscTroughBar2 = CurrentBar;
                                secondTroughValue2 = Histogram[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBullCandidateOsc2");
                                    updateBullishDivCandidateOsc2 = true;
                                    RemoveDrawObject("divBullCandidatePrice2");
                                    updateBullishDivCandidatePrice2 = true;
                                }
                            }
                            else if (Histogram[0] > priorReplacementTroughValue2)
                            {
                                firstTroughBar2 = replacementTroughBar2;
                                firstTroughLow2 = replacementTroughLow2;
                                firstOscTroughBar2 = replacementOscTroughBar2;
                                firstTroughValue2 = replacementTroughValue2;
                                secondOscTroughBar2 = CurrentBar;
                                secondTroughValue2 = Histogram[0];
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("divBullCandidateOsc2");
                                    drawBullishDivCandidateOsc2 = true;
                                    RemoveDrawObject("divBullCandidatePrice2");
                                    drawBullishDivCandidatePrice2 = true;
                                }
                            }
                            else
                            {
                                bullishTriggerCountHistogram[0] = (0);
                                RemoveDrawObject("divBullCandidateOsc2");
                                RemoveDrawObject("divBullCandidatePrice2");
                                divergenceActive = false;
                            }
                        }
                        else
                        {
                            secondOscTroughBar2 = priorSecondOscTroughBar2;
                            secondTroughValue2 = priorSecondTroughValue2;
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("divBullCandidateOsc2");
                                updateBullishDivCandidateOsc2 = true;
                                RemoveDrawObject("divBullCandidatePrice2");
                                updateBullishDivCandidatePrice2 = true;
                            }
                        }
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low && bullishTriggerCountHistogram[0] > 0 && Low[0] < MIN(Low, CurrentBar - firstTroughBar2)[1])
                        {
                            secondTroughBar2 = CurrentBar;
                            secondTroughLow2 = Low[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBullCandidatePrice2");
                                if (divergenceActive)
                                    updateBullishDivCandidatePrice2 = true;
                            }
                        }
                        else if (ThisInputType != ARC_VMDSystem_InputType.High_Low && bullishTriggerCountHistogram[0] > 0 && swingInput[0] < MIN(swingInput, CurrentBar - firstTroughBar2)[1])
                        {
                            secondTroughBar2 = CurrentBar;
                            secondTroughLow2 = swingInput[0];
                            if (ShowDivOnPricePanel)
                            {
                                RemoveDrawObject("divBullCandidatePrice2");
                                if (divergenceActive)
                                    updateBullishDivCandidatePrice2 = true;
                            }
                        }
                    }
                }

                if (bullishTriggerCountHistogram[0] > 0)
                {
                    if ((Close[0] > Low[CurrentBar - secondTroughBar2]) && (Histogram[0] > Histogram[1]) && Close[0] > Open[0])
                    {
                        if (firstTroughBar2 != memfirstTroughBar2)
                        {
                            cptBullHistogramdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                            maxcptBullHistogramdiv = 1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        memfirstTroughBar2 = firstTroughBar2;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBullHistogramdiv = maxcptBullHistogramdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bullishHistogramDivProjection[0] = (cptBullHistogramdiv);//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else bullishHistogramDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec						
                }
                else bullishHistogramDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec

                #endregion

                #region Bullish Hidden divergences between price and Histogram #HIDDENDIV
                drawBullishDivOnOsc2H = false;
                drawBullishDivOnPrice2H = false;
                drawArrowUp2H = false;
                drawBullSetup2H = false;

                #region -- IsFirstTickOfBar - {Reset} --
                if (IsFirstTickOfBar)
                {
                    if (hiddenbullishTriggerCountHistogram[1] > 0)
                    {
                        if ((Close[1] > Low[CurrentBar - secondTroughBar2H]) && (Histogram[1] > Histogram[2]) && Close[1] > Open[1])
                        {
                            hiddenbullishCDivHistogram[0] = (1.0);
                            hiddenbullishTriggerCountHistogram[1] = (0);
                            if (!hidePlots && ShowDivOnOscillatorPanel) drawBullishDivOnOsc2H = true;
                            if (ShowDivOnPricePanel) drawBullishDivOnPrice2H = true;
                            if (showArrows) drawArrowUp2H = true;
                            RemoveDrawObject("hiddendivBullCandidateOsc2");
                            RemoveDrawObject("hiddendivBullCandidatePrice2");
                            maxcptBullHistogramhdiv++;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        else hiddenbullishCDivHistogram[0] = (0.0);

                        priorFirstTroughBar2H = firstTroughBar2H;
                        priorFirstOscTroughBar2H = firstOscTroughBar2H;
                        priorFirstTroughLow2H = firstTroughLow2H;
                        priorFirstTroughValue2H = firstTroughValue2H;
                        priorReplacementTroughLow2H = replacementTroughLow2H;
                        priorReplacementTroughValue2H = replacementTroughValue2H;
                        priorSecondTroughBar2H = secondTroughBar2H;
                        priorSecondOscTroughBar2H = secondOscTroughBar2H;
                        priorSecondTroughValue2H = secondTroughValue2H;
                        priorSecondTroughLow2H = secondTroughLow2H;

                        double refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[1] : swingInput[1];
                        if (refinput < firstTroughLow2H)
                        {
                            hiddenbullishTriggerCountHistogram[1] = (0);
                            RemoveDrawObject("hiddendivBullCandidateOsc2");
                            RemoveDrawObject("hiddendivBullCandidatePrice2");
                        }
                    }
                    else
                    {
                        hiddenbullishCDivHistogram[0] = (0.0);
                        RemoveDrawObject("hiddendivBullCandidateOsc2");
                        RemoveDrawObject("hiddendivBullCandidatePrice2");
                    }
                    hiddenbullishPDivHistogram[0] = (0.0);
                }
                #endregion

                if (hiddenbullishPDivHistogram[0] > 0.5)
                {
                    RemoveDrawObject("hiddendivBullCandidateOsc2");
                    RemoveDrawObject("hiddendivBullCandidatePrice2");
                }

                #region -- reset variables --
                drawBullishDivCandidateOsc2H = false;
                drawBullishDivCandidatePrice2H = false;
                updateBullishDivCandidateOsc2H = false;
                updateBullishDivCandidatePrice2H = false;
                troughCount2H = 0;
                #endregion

                refinput2H_0 = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[0] : swingInput[0];
                refinput2H_1 = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[1] : swingInput[1];
                invalidate2H = Histogram[0] > MIN(Histogram, CurrentBar - firstOscTroughBar2H)[1] || refinput2H_0 >= refinput2H_1 ||
                    (IncludeDoubleTopsAndBottoms && refinput2H_0 < firstTroughLow2H) || (!IncludeDoubleTopsAndBottoms && refinput2H_0 <= firstTroughLow2H);
                if (hiddenbullishTriggerCountHistogram[1] > 0 && invalidate2H)
                {
                    hiddenbullishPDivHistogram[0] = (0.0);
                    secondOscTroughBar2H = priorSecondOscTroughBar2H;
                    secondTroughValue2H = priorSecondTroughValue2H;
                    updateBullishDivCandidateOsc2H = true;
                }
                else if (hiddenbullishPDivHistogram[0] > 0.5 && invalidate2H)
                {
                    hiddenbullishPDivHistogram[0] = (0.0);
                    hiddenbullishTriggerCountHistogram[0] = (0);
                    secondOscTroughBar2H = priorSecondOscTroughBar2H;
                    secondTroughValue2H = priorSecondTroughValue2H;
                    RemoveDrawObject("hiddendivBullCandidateOsc2");
                    RemoveDrawObject("hiddendivBullCandidatePrice2");
                }

                #region -- get price low and osc low --
                for (int i = DivMinBars; i <= DivMaxBars; i++)
                {
                    int j = 0;
                    if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                        swingMin = MIN(Low, SwingStrength)[1];
                    else
                        swingMin = MIN(Input, SwingStrength)[1];
                    if (swingLowType[i] < 0 || (i > DivMinBars && pre_swingLowType[i] < 0 && upTrend[0] && High[0] > Math.Max(swingMax, currentLow + zigzagDeviation))) // code references zigzag
                    {
                        refTroughBar2H[troughCount2H] = CurrentBar - i;
                        if (ThisInputType == ARC_VMDSystem_InputType.High_Low)
                            refTroughLow2H[troughCount2H] = Low[i];
                        else
                            refTroughLow2H[troughCount2H] = swingInput[i];

                        if (UseOscHighLow)
                        {
                            j = i;
                            while (j > i - Math.Min(DivMinBars, 3) && Histogram[j - 1] < Histogram[j])
                                j = j - 1;
                            refOscTroughBar2H[troughCount2H] = CurrentBar - j;
                            refTroughValue2H[troughCount2H] = Histogram[j];
                            troughCount2H++;
                        }
                        else
                        {
                            refOscTroughBar2H[troughCount2H] = CurrentBar - i;
                            refTroughValue2H[troughCount2H] = Histogram[i];
                            troughCount2H++;
                        }
                    }
                    if ((UseLastSwingOnly && troughCount2H == 1) || troughCount2H == 9) break;
                }
                #endregion

                minBarOsc = UseOscHighLow && Histogram[1] < Histogram[0] ? CurrentBar - 1 : CurrentBar;
                minValueOsc = UseOscHighLow && Histogram[1] < Histogram[0] ? Histogram[1] : Histogram[0];

                #region -- find smallest divergence setup --
                for (int count = 0; count < troughCount2H; count++)
                {
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] >= refTroughLow2H[count]) ||
                        (!IncludeDoubleTopsAndBottoms && refinput[0] > refTroughLow2H[count])) &&
                        refinput[0] < refinput[1] &&
                        refinput[0] <= MIN(refinput, CurrentBar - refTroughBar2H[count] - 2)[1] &&
                        refTroughValue2H[count] < 0 &&
                        refTroughValue2H[count] > minValueOsc &&
                        refTroughValue2H[count] > MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2H[count] - 6))[1] &&
                        (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2H[count])[0] < 0))
                    {
                        hiddenbullishPDivHistogram[0] = (1.0);
                        hiddenbullishTriggerCountHistogram[0] = (TriggerBars + 1);
                        firstTroughBar2H = refTroughBar2H[count];
                        firstTroughLow2H = refTroughLow2H[count];
                        firstOscTroughBar2H = refOscTroughBar2H[count];
                        firstTroughValue2H = refTroughValue2H[count];
                        secondTroughBar2H = CurrentBar;
                        secondTroughLow2H = refinput[0];
                        secondOscTroughBar2H = maxBarOsc;
                        secondTroughValue2H = maxValueOsc;
                        if (!hidePlots && ShowDivOnOscillatorPanel)
                        {
                            RemoveDrawObject("hiddendivBullCandidateOsc2");
                            drawBullishDivCandidateOsc2H = true;
                        }
                        if (ShowDivOnPricePanel)
                        {
                            RemoveDrawObject("hiddendivBullCandidatePrice2");
                            drawBullishDivCandidatePrice2H = true;
                        }
                        if (ShowSetupDots) drawBullSetup2H = true;
                        break;
                    }
                    else hiddenbullishPDivHistogram[0] = (0.0);
                }
                #endregion

                #region -- find largest divergence setup --
                for (int count = troughCount2H - 1; count >= 0; count--)
                {
                    ISeries<double> refinput = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low : swingInput;
                    if (((IncludeDoubleTopsAndBottoms && refinput[0] >= refTroughLow2H[count]) || (!IncludeDoubleTopsAndBottoms && refinput[0] > refTroughLow2H[count])) &&
                        refinput[0] < refinput[1] &&
                        refinput[0] <= MIN(refinput, CurrentBar - refTroughBar2H[count] - 2)[1] &&
                        refTroughValue2H[count] < 0 &&
                        refTroughValue2H[count] > minValueOsc &&
                        refTroughValue2H[count] > MIN(Histogram, Math.Max(1, CurrentBar - refOscTroughBar2H[count] - 6))[1] &&
                        (!ResetFilter || MAX(Histogram, CurrentBar - refOscTroughBar2H[count])[0] < 0))
                    {
                        replacementTroughBar2H = refOscTroughBar2H[count];
                        replacementTroughLow2H = refTroughLow2H[count];
                        replacementOscTroughBar2H = refOscTroughBar2H[count];
                        replacementTroughValue2H = refTroughValue2H[count];
                        break;
                    }
                }
                #endregion

                inputref = ThisInputType == ARC_VMDSystem_InputType.High_Low ? Low[0] : swingInput[0];
                if (hiddenbullishPDivHistogram[0] < 0.5)
                {
                    divergenceActive = true;
                    if (hiddenbullishTriggerCountHistogram[1] > 0)
                    {
                        hiddenbullishTriggerCountHistogram[0] = (hiddenbullishTriggerCountHistogram[1] - 1);
                        if (inputref < priorSecondTroughLow2H)
                        {
                            if (inputref > priorFirstTroughLow2H)//price stays above
                            {
                                secondTroughBar2H = CurrentBar;
                                secondTroughLow2H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBullCandidateOsc2");
                                    drawBullishDivCandidateOsc2H = true;
                                    RemoveDrawObject("hiddendivBullCandidatePrice2");
                                    drawBullishDivCandidatePrice2H = true;
                                }
                            }
                            else if (inputref > priorReplacementTroughLow2H)
                            {
                                firstTroughBar2H = replacementTroughBar2H;
                                firstTroughLow2H = replacementTroughLow2H;
                                firstOscTroughBar2H = replacementOscTroughBar2H;
                                firstTroughValue2H = replacementTroughValue2H;
                                secondTroughBar2H = CurrentBar;
                                secondTroughLow2H = inputref;
                                if (!hidePlots && ShowDivOnOscillatorPanel)
                                {
                                    RemoveDrawObject("hiddendivBullCandidateOsc2");
                                    drawBullishDivCandidateOsc2H = true;
                                    RemoveDrawObject("hiddendivBullCandidatePrice2");
                                    drawBullishDivCandidatePrice2H = true;
                                }
                            }
                            else
                            {
                                hiddenbullishTriggerCountHistogram[0] = (0);
                                RemoveDrawObject("hiddendivBullCandidateOsc2");
                                RemoveDrawObject("hiddendivBullCandidatePrice2");
                                divergenceActive = false;
                            }
                        }
                        else
                        {
                            secondTroughBar2H = priorSecondTroughBar2H;
                            secondTroughLow2H = priorSecondTroughLow2H;
                            if (!hidePlots && ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBullCandidateOsc2");
                                updateBullishDivCandidateOsc2H = true;
                                RemoveDrawObject("hiddendivBullCandidatePrice2");
                                updateBullishDivCandidatePrice2H = true;
                            }
                        }
                        if (hiddenbullishTriggerCountHistogram[0] > 0 && Histogram[0] < MIN(Histogram, CurrentBar - firstOscTroughBar2H)[1])
                        {
                            secondOscTroughBar2H = CurrentBar;
                            secondTroughValue2H = Histogram[0];
                            if (ShowDivOnOscillatorPanel)
                            {
                                RemoveDrawObject("hiddendivBullCandidateOsc2");
                                if (divergenceActive) updateBullishDivCandidateOsc2H = true;
                            }
                        }
                    }
                }

                if (hiddenbullishTriggerCountHistogram[0] > 0)
                {
                    if ((Close[0] > Low[CurrentBar - secondTroughBar2H]) && (Histogram[0] > Histogram[1]) && Close[0] > Open[0])
                    {
                        if (firstTroughBar2H != memfirstTroughBar2H)
                        {
                            cptBullHistogramhdiv = 0;//#BLOOHOUND - added 17.02.03 - AzurITec
                            maxcptBullHistogramhdiv = 1;//#BLOOHOUND - added 17.02.03 - AzurITec
                        }
                        memfirstTroughBar2H = firstTroughBar2H;//#BLOOHOUND - added 17.02.03 - AzurITec
                        cptBullHistogramhdiv = maxcptBullHistogramhdiv;//#BLOOHOUND - added 17.02.03 - AzurITec
                        bullishHistogramHiddenDivProjection[0] = (cptBullHistogramhdiv);//#BLOOHOUND - added 17.02.03 - AzurITec
                    }
                    else bullishHistogramHiddenDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec						
                }
                else bullishHistogramHiddenDivProjection[0] = (0);//#BLOOHOUND - added 17.02.03 - AzurITec

                #endregion

                #region -- draw --
                if (drawObjectsEnabled)
                {
                    bearishDivPlotSeriesMACDBB[0] = (0);
                    hiddenbearishDivPlotSeriesMACDBB[0] = (0);
                    bullishDivPlotSeriesMACDBB[0] = (0);
                    hiddenbullishDivPlotSeriesMACDBB[0] = (0);
                    bearishDivPlotSeriesHistogram[0] = (0);
                    hiddenbearishDivPlotSeriesHistogram[0] = (0);
                    bullishDivPlotSeriesHistogram[0] = (0);
                    hiddenbullishDivPlotSeriesHistogram[0] = (0);
                    DrawOnPricePanel = false;

                    #region -- MACD div --
                    if (PrintMarkers && !hidePlots && ShowDivOnOscillatorPanel && ShowOscillatorDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearishDivergenceOP1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullishDivergenceOP1{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidateOsc1 && ShowOscillatorDivergences)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBearCandidateOsc1", false, CurrentBar - firstOscPeakBar1, firstPeakValue1, CurrentBar - secondOscPeakBar1, secondPeakValue1, BearColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (updateBearishDivCandidateOsc1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBearCandidateOsc1", false, CurrentBar - priorFirstOscPeakBar1, priorFirstPeakValue1, CurrentBar - secondOscPeakBar1, secondPeakValue1, BearColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (drawBearishDivOnOsc1)
	                        {
	                            if (showBox)
	                                bearishDivPlotSeriesMACDBB[CurrentBar - priorSecondOscPeakBar1] = priorSecondOscPeakBar1 - priorFirstOscPeakBar1;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("BearishDivergenceOP1{0}", priorSecondPeakBar1), false, CurrentBar - priorFirstOscPeakBar1, priorFirstPeakValue1, CurrentBar - priorSecondOscPeakBar1, priorSecondPeakValue1, BearColor1, DashStyleHelper.Solid, DivWidth1);},0,null);
								}
	                        }
	                        if (drawBullishDivCandidateOsc1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBullCandidateOsc1", false, CurrentBar - firstOscTroughBar1, firstTroughValue1, CurrentBar - secondOscTroughBar1, secondTroughValue1, BullColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (updateBullishDivCandidateOsc1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBullCandidateOsc1", false, CurrentBar - priorFirstOscTroughBar1, priorFirstTroughValue1, CurrentBar - secondOscTroughBar1, secondTroughValue1, BullColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (drawBullishDivOnOsc1)
	                        {
	                            if (showBox)
	                                bullishDivPlotSeriesMACDBB[CurrentBar - priorSecondOscTroughBar1] =  priorSecondOscTroughBar1 - priorFirstOscTroughBar1;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("BullishDivergenceOP1{0}", priorSecondTroughBar1), false, CurrentBar - priorFirstOscTroughBar1, priorFirstTroughValue1, CurrentBar - priorSecondOscTroughBar1, priorSecondTroughValue1, BullColor1, DashStyleHelper.Solid, DivWidth1);},0,null);
								}
	                        }
						//},0,null);
                    }
                    #endregion

                    #region -- MACD HIDDEN div --
                    if (PrintMarkers && !hidePlots && ShowDivOnOscillatorPanel && ShowOscillatorHiddenDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearishDivergenceOP1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullishDivergenceOP1{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidateOsc1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBearCandidateOsc1", false, CurrentBar - firstOscPeakBar1H, firstPeakValue1H, CurrentBar - secondOscPeakBar1H, secondPeakValue1H, HiddenBearColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
	                        if (updateBearishDivCandidateOsc1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBearCandidateOsc1", false, CurrentBar - priorFirstOscPeakBar1H, priorFirstPeakValue1H, CurrentBar - secondOscPeakBar1H, secondPeakValue1H, HiddenBearColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
	                        if (drawBearishDivOnOsc1H)
	                        {
	                            if (showBox)
	                                hiddenbearishDivPlotSeriesMACDBB[CurrentBar - priorSecondOscPeakBar1H] = priorSecondOscPeakBar1H - priorFirstOscPeakBar1H;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("hiddenBearishDivergenceOP1{0}", priorSecondPeakBar1H), false, CurrentBar - priorFirstOscPeakBar1H, priorFirstPeakValue1H, CurrentBar - priorSecondOscPeakBar1H, priorSecondPeakValue1H, HiddenBearColor1, DashStyleHelper.Solid, HiddenDivWidth1);},0,null);
								}
	                        }
	                        if (drawBullishDivCandidateOsc1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBullCandidateOsc1", false, CurrentBar - firstOscTroughBar1H, firstTroughValue1H, CurrentBar - secondOscTroughBar1H, secondTroughValue1H, HiddenBullColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
	                        if (updateBullishDivCandidateOsc1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBullCandidateOsc1", false, CurrentBar - priorFirstOscTroughBar1H, priorFirstTroughValue1H, CurrentBar - secondOscTroughBar1H, secondTroughValue1H, HiddenBullColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
	                        if (drawBullishDivOnOsc1H)
	                        {
	                            if (showBox)
	                                hiddenbullishDivPlotSeriesMACDBB[CurrentBar - priorSecondOscTroughBar1H] = priorSecondOscTroughBar1H - priorFirstOscTroughBar1H;
	                            else{
									TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("hiddenBullishDivergenceOP1{0}", priorSecondTroughBar1H), false, CurrentBar - priorFirstOscTroughBar1H, priorFirstTroughValue1H, CurrentBar - priorSecondOscTroughBar1H, priorSecondTroughValue1H, HiddenBullColor1, DashStyleHelper.Solid, HiddenDivWidth1);},0,null);
								}
	                        }
						//},0,null);
                    }
                    #endregion

                    #region -- HISTO div --
                    if (PrintMarkers && !hidePlots && ShowDivOnOscillatorPanel && ShowHistogramDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearishDivergenceOP2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullishDivergenceOP2{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidateOsc2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBearCandidateOsc2", false, CurrentBar - firstOscPeakBar2, firstPeakValue2, CurrentBar - secondOscPeakBar2, secondPeakValue2, BearColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (updateBearishDivCandidateOsc2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBearCandidateOsc2", false, CurrentBar - priorFirstOscPeakBar2, priorFirstPeakValue2, CurrentBar - secondOscPeakBar2, secondPeakValue2, BearColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (drawBearishDivOnOsc2)
	                        {
	                            if (showBox)
	                                bearishDivPlotSeriesHistogram[CurrentBar - priorSecondOscPeakBar2] = priorSecondOscPeakBar2 - priorFirstOscPeakBar2;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("BearishDivergenceOP2{0}", priorSecondPeakBar2), false, CurrentBar - priorFirstOscPeakBar2, priorFirstPeakValue2, CurrentBar - priorSecondOscPeakBar2, priorSecondPeakValue2, BearColor2, DashStyleHelper.Solid, DivWidth2);},0,null);
								}
	                        }
	                        if (drawBullishDivCandidateOsc2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBullCandidateOsc2", false, CurrentBar - firstOscTroughBar2, firstTroughValue2, CurrentBar - secondOscTroughBar2, secondTroughValue2, BullColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (updateBullishDivCandidateOsc2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBullCandidateOsc2", false, CurrentBar - priorFirstOscTroughBar2, priorFirstTroughValue2, CurrentBar - secondOscTroughBar2, secondTroughValue2, BullColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (drawBullishDivOnOsc2)
	                        {
	                            if (showBox)
	                                bullishDivPlotSeriesHistogram[CurrentBar - priorSecondOscTroughBar2] = priorSecondOscTroughBar2 - priorFirstOscTroughBar2;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("BullishDivergenceOP2{0}", priorSecondTroughBar2), false, CurrentBar - priorFirstOscTroughBar2, priorFirstTroughValue2, CurrentBar - priorSecondOscTroughBar2, priorSecondTroughValue2, BullColor2, DashStyleHelper.Solid, DivWidth2);},0,null);
								}
	                        }
						//},0,null);
                    }
                    #endregion

                    #region -- HISTO HIDDEN div --
                    if (PrintMarkers && !hidePlots && ShowDivOnOscillatorPanel && ShowHistogramHiddenDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearishDivergenceOP2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullishDivergenceOP2{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidateOsc2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBearCandidateOsc2", false, CurrentBar - firstOscPeakBar2H, firstPeakValue2H, CurrentBar - secondOscPeakBar2H, secondPeakValue2H, HiddenBearColor2, DashStyleHelper.Dash, HiddenDivWidth2);},0,null);
	                        if (updateBearishDivCandidateOsc2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBearCandidateOsc2", false, CurrentBar - priorFirstOscPeakBar2H, priorFirstPeakValue2H, CurrentBar - secondOscPeakBar2H, secondPeakValue2H, HiddenBearColor2, DashStyleHelper.Dash, HiddenDivWidth2);},0,null);
	                        if (drawBearishDivOnOsc2H)
	                        {
	                            if (showBox)
	                                hiddenbearishDivPlotSeriesHistogram[CurrentBar - priorSecondOscPeakBar2H] = priorSecondOscPeakBar2H - priorFirstOscPeakBar2H;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("hiddenBearishDivergenceOP2{0}", priorSecondPeakBar2H), false, CurrentBar - priorFirstOscPeakBar2H, priorFirstPeakValue2H, CurrentBar - priorSecondOscPeakBar2H, priorSecondPeakValue2H, HiddenBearColor2, DashStyleHelper.Solid, HiddenDivWidth2);},0,null);
								}
	                        }

	                        if (drawBullishDivCandidateOsc2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBullCandidateOsc2", false, CurrentBar - firstOscTroughBar2H, firstTroughValue2H, CurrentBar - secondOscTroughBar2H, secondTroughValue2H, HiddenBullColor2, DashStyleHelper.Dash, HiddenDivWidth2);},0,null);
	                        if (updateBullishDivCandidateOsc2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBullCandidateOsc2", false, CurrentBar - priorFirstOscTroughBar2H, priorFirstTroughValue2H, CurrentBar - secondOscTroughBar2H, secondTroughValue2H, HiddenBullColor2, DashStyleHelper.Dash, HiddenDivWidth2);},0,null);
	                        if (drawBullishDivOnOsc2H)
	                        {
	                            if (showBox)
	                                hiddenbullishDivPlotSeriesHistogram[CurrentBar - priorSecondOscTroughBar2H] = priorSecondOscTroughBar2H - priorFirstOscTroughBar2H;
	                            else{
	                                TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("hiddenBullishDivergenceOP2{0}", priorSecondTroughBar2H), false, CurrentBar - priorFirstOscTroughBar2H, priorFirstTroughValue2H, CurrentBar - priorSecondOscTroughBar2H, priorSecondTroughValue2H, HiddenBullColor2, DashStyleHelper.Solid, HiddenDivWidth2);},0,null);
								}
	                        }
						//},0,null);
                    }
                    #endregion

                    DrawOnPricePanel = true;
                    #region -- MACD div --
                    if (PrintMarkers && ShowDivOnPricePanel && ShowOscillatorDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearishDivergencePP1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullishDivergencePP1{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidatePrice1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBearCandidatePrice1", false, CurrentBar - firstPeakBar1, firstPeakHigh1 + offsetDiv1, CurrentBar - secondPeakBar1, secondPeakHigh1 + offsetDiv1, BearColor1, DashStyleHelper.Dash, DivWidth1); },0,null);
	                        if (updateBearishDivCandidatePrice1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBearCandidatePrice1", false, CurrentBar - priorFirstPeakBar1, priorFirstPeakHigh1 + offsetDiv1, CurrentBar - secondPeakBar1, secondPeakHigh1 + offsetDiv1, BearColor1, DashStyleHelper.Dash, DivWidth1); },0,null);
	                        if (drawBearishDivOnPrice1){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("BearishDivergencePP1{0}", priorSecondPeakBar1), false, CurrentBar - priorFirstPeakBar1, priorFirstPeakHigh1 + offsetDiv1, CurrentBar - priorSecondPeakBar1, priorSecondPeakHigh1 + offsetDiv1, BearColor1, DashStyleHelper.Solid, DivWidth1);},0,null);
							}

	                        if (drawBullishDivCandidatePrice1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBullCandidatePrice1", false, CurrentBar - firstTroughBar1, firstTroughLow1 - offsetDiv1, CurrentBar - secondTroughBar1, secondTroughLow1 - offsetDiv1, BullColor1, DashStyleHelper.Dash, DivWidth1); },0,null);
	                        if (updateBullishDivCandidatePrice1)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBullCandidatePrice1", false, CurrentBar - priorFirstTroughBar1, priorFirstTroughLow1 - offsetDiv1, CurrentBar - secondTroughBar1, secondTroughLow1 - offsetDiv1, BullColor1, DashStyleHelper.Dash, DivWidth1);},0,null);
	                        if (drawBullishDivOnPrice1){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("BullishDivergencePP1{0}", priorSecondTroughBar1), false, CurrentBar - priorFirstTroughBar1, priorFirstTroughLow1 - offsetDiv1, CurrentBar - priorSecondTroughBar1, priorSecondTroughLow1 - offsetDiv1, BullColor1, DashStyleHelper.Solid, DivWidth1);},0,null);
							}
						//},0,null);
                    }
                    if (PrintMarkers && ShowSetupDots && ShowOscillatorDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearSetup1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullSetup1{0}",cutoffIdx));
						}
                        if (drawBearSetup1){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("BearSetup1{0}", CurrentBar), true, setupDotString, 0, Low[0] - offsetDraw1, -SetupFontSize1, BearishSetupColor1, setupFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawBullSetup1){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("BullSetup1{0}", CurrentBar), true, setupDotString, 0, High[0] + offsetDraw1, SetupFontSize1, BullishSetupColor1, setupFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    if (PrintMarkers && showArrows && ShowOscillatorDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearTrigger1{0}",cutoffIdx-1));
							RemoveDrawObject(string.Format("BullTrigger1{0}",cutoffIdx-1));
						}
                        if (drawArrowDown1){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("BearTrigger1{0}", CurrentBar-1), true, arrowStringDown, 1, High[1] + offsetDraw1, 2 * TriangleFontSize1 / 3, ArrowDownColor1, triangleFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawArrowUp1){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("BullTrigger1{0}", CurrentBar-1), true, arrowStringUp, 1, Low[1] - offsetDraw1, -2 * TriangleFontSize1 / 3, ArrowUpColor1, triangleFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    #endregion

                    #region -- MACD HIDDEN div --
                    if (PrintMarkers && ShowDivOnPricePanel && ShowOscillatorHiddenDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearishDivergencePP1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullishDivergencePP1{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidatePrice1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBearCandidatePrice1", false, CurrentBar - firstPeakBar1H, firstPeakHigh1H + offsetDiv1, CurrentBar - secondPeakBar1H, secondPeakHigh1H + offsetDiv1, HiddenBearColor1, DashStyleHelper.Dash, HiddenDivWidth1); },0,null);
	                        if (updateBearishDivCandidatePrice1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBearCandidatePrice1", false, CurrentBar - priorFirstPeakBar1H, priorFirstPeakHigh1H + offsetDiv1, CurrentBar - secondPeakBar1H, secondPeakHigh1H + offsetDiv1, HiddenBearColor1, DashStyleHelper.Dash, HiddenDivWidth1); },0,null);
	                        if (drawBearishDivOnPrice1H){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("hiddenBearishDivergencePP1{0}", priorSecondPeakBar1H), false, CurrentBar - priorFirstPeakBar1H, priorFirstPeakHigh1H + offsetDiv1, CurrentBar - priorSecondPeakBar1H, priorSecondPeakHigh1H + offsetDiv1, HiddenBearColor1, DashStyleHelper.Solid, HiddenDivWidth1);},0,null);
							}

	                        if (drawBullishDivCandidatePrice1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBullCandidatePrice1", false, CurrentBar - firstTroughBar1H, firstTroughLow1H - offsetDiv1, CurrentBar - secondTroughBar1H, secondTroughLow1H - offsetDiv1, HiddenBullColor1, DashStyleHelper.Dash, HiddenDivWidth1); },0,null);
	                        if (updateBullishDivCandidatePrice1H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBullCandidatePrice1", false, CurrentBar - priorFirstTroughBar1H, priorFirstTroughLow1H - offsetDiv1, CurrentBar - secondTroughBar1H, secondTroughLow1H - offsetDiv1, HiddenBullColor1, DashStyleHelper.Dash, HiddenDivWidth1);},0,null);
	                        if (drawBullishDivOnPrice1H){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("hiddenBullishDivergencePP1{0}", priorSecondTroughBar1H), false, CurrentBar - priorFirstTroughBar1H, priorFirstTroughLow1H - offsetDiv1, CurrentBar - priorSecondTroughBar1H, priorSecondTroughLow1H - offsetDiv1, HiddenBullColor1, DashStyleHelper.Solid, HiddenDivWidth1);},0,null);
							}
						//},0,null);
                    }
                    if (PrintMarkers && ShowSetupDots && ShowOscillatorHiddenDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearSetup1{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullSetup1{0}",cutoffIdx));
						}
                        if (drawBearSetup1H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("hiddenBearSetup1{0}", CurrentBar), true, setupDotString, 0, Low[0] - offsetDraw1, -SetupFontSize1, HiddenBearishSetupColor1, setupFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}

                        if (drawBullSetup1H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("hiddenBullSetup1{0}", CurrentBar), true, setupDotString, 0, High[0] + offsetDraw1, SetupFontSize1, HiddenBullishSetupColor1, setupFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    if (PrintMarkers && showArrows && ShowOscillatorHiddenDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearTrigger1{0}",cutoffIdx-1));
							RemoveDrawObject(string.Format("hiddenBullTrigger1{0}",cutoffIdx-1));
						}
                        if (drawArrowDown1H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("hiddenBearTrigger1{0}", CurrentBar-1), true, arrowStringDown, 1, High[1] + offsetDraw1, 2 * TriangleFontSize1 / 3, HiddenArrowDownColor1, triangleFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}

                        if (drawArrowUp1H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("hiddenBullTrigger1{0}", CurrentBar-1), true, arrowStringUp, 1, Low[1] - offsetDraw1, -2 * TriangleFontSize1 / 3, HiddenArrowUpColor1, triangleFont1, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    #endregion

                    #region -- HISTO div --
                    if (PrintMarkers && ShowDivOnPricePanel && ShowHistogramDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearishDivergencePP2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullishDivergencePP2{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidatePrice2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBearCandidatePrice2", false, CurrentBar - firstPeakBar2, firstPeakHigh2 + offsetDiv2, CurrentBar - secondPeakBar2, secondPeakHigh2 + offsetDiv2, BearColor2, DashStyleHelper.Dash, DivWidth2); },0,null);
	                        if (updateBearishDivCandidatePrice2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBearCandidatePrice2", false, CurrentBar - priorFirstPeakBar2, priorFirstPeakHigh2 + offsetDiv2, CurrentBar - secondPeakBar2, secondPeakHigh2 + offsetDiv2, BearColor2, DashStyleHelper.Dash, DivWidth2); },0,null);
	                        if (drawBearishDivOnPrice2){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("BearishDivergencePP2{0}", priorSecondPeakBar2), false, CurrentBar - priorFirstPeakBar2, priorFirstPeakHigh2 + offsetDiv2, CurrentBar - priorSecondPeakBar2, priorSecondPeakHigh2 + offsetDiv2, BearColor2, DashStyleHelper.Solid, DivWidth2);},0,null);
							}
	                        if (drawBullishDivCandidatePrice2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBullCandidatePrice2", false, CurrentBar - firstTroughBar2, firstTroughLow2 - offsetDiv2, CurrentBar - secondTroughBar2, secondTroughLow2 - offsetDiv2, BullColor2, DashStyleHelper.Dash, DivWidth2); },0,null);
	                        if (updateBullishDivCandidatePrice2)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"divBullCandidatePrice2", false, CurrentBar - priorFirstTroughBar2, priorFirstTroughLow2 - offsetDiv2, CurrentBar - secondTroughBar2, secondTroughLow2 - offsetDiv2, BullColor2, DashStyleHelper.Dash, DivWidth2);},0,null);
	                        if (drawBullishDivOnPrice2){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("BullishDivergencePP2{0}", priorSecondTroughBar2), false, CurrentBar - priorFirstTroughBar2, priorFirstTroughLow2 - offsetDiv2, CurrentBar - priorSecondTroughBar2, priorSecondTroughLow2 - offsetDiv2, BullColor2, DashStyleHelper.Solid, DivWidth2);},0,null);
							}
						//},0,null);
                    }
                    if (PrintMarkers && ShowSetupDots && ShowHistogramDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearSetup2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("BullSetup2{0}",cutoffIdx));
						}
                        if (drawBearSetup2){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("BearSetup2{0}", CurrentBar), true, setupDotString, 0, Low[0] - offsetDraw2, -SetupFontSize2, BearishSetupColor2, setupFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawBullSetup2){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("BullSetup2{0}", CurrentBar), true, setupDotString, 0, High[0] + offsetDraw2, SetupFontSize2, BullishSetupColor2, setupFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    if (PrintMarkers && showArrows && ShowHistogramDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("BearTrigger2{0}",cutoffIdx-1));
							RemoveDrawObject(string.Format("BullTrigger2{0}",cutoffIdx-1));
						}
                        if (drawArrowDown2){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("BearTrigger2{0}", CurrentBar-1), true, arrowStringDown, 1, High[1] + offsetDraw2, 2 * TriangleFontSize2 / 3, ArrowDownColor2, triangleFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawArrowUp2){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("BullTrigger2{0}", CurrentBar-1), true, arrowStringUp, 1, Low[1] - offsetDraw2, -2 * TriangleFontSize2 / 3, ArrowUpColor2, triangleFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    #endregion

                    #region -- HISTO HIDDEN div --
                    if (PrintMarkers && ShowDivOnPricePanel && ShowHistogramHiddenDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearishDivergencePP2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullishDivergencePP2{0}",cutoffIdx));
						}
						//TriggerCustomEvent(o1 =>{	
	                        if (drawBearishDivCandidatePrice2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBearCandidatePrice2", false, CurrentBar - firstPeakBar2H, firstPeakHigh2H + offsetDiv2, CurrentBar - secondPeakBar2H, secondPeakHigh2H + offsetDiv2, HiddenBearColor2, DashStyleHelper.Dash, HiddenDivWidth2); },0,null);
	                        if (updateBearishDivCandidatePrice2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBearCandidatePrice2", false, CurrentBar - priorFirstPeakBar2H, priorFirstPeakHigh2H + offsetDiv2, CurrentBar - secondPeakBar2H, secondPeakHigh2H + offsetDiv2, HiddenBearColor2, DashStyleHelper.Dash, HiddenDivWidth2); },0,null);
	                        if (drawBearishDivOnPrice2H){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("hiddenBearishDivergencePP2{0}", priorSecondPeakBar2H), false, CurrentBar - priorFirstPeakBar2H, priorFirstPeakHigh2H + offsetDiv2, CurrentBar - priorSecondPeakBar2H, priorSecondPeakHigh2H + offsetDiv2, HiddenBearColor2, DashStyleHelper.Solid, HiddenDivWidth2);},0,null);
							}

	                        if (drawBullishDivCandidatePrice2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBullCandidatePrice2", false, CurrentBar - firstTroughBar2H, firstTroughLow2H - offsetDiv2, CurrentBar - secondTroughBar2H, secondTroughLow2H - offsetDiv2, HiddenBullColor2, DashStyleHelper.Dash, HiddenDivWidth2); },0,null);
	                        if (updateBullishDivCandidatePrice2H)
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,"hiddendivBullCandidatePrice2", false, CurrentBar - priorFirstTroughBar2H, priorFirstTroughLow2H - offsetDiv2, CurrentBar - secondTroughBar2H, secondTroughLow2H - offsetDiv2, HiddenBullColor2, DashStyleHelper.Dash, HiddenDivWidth2);},0,null);
	                        if (drawBullishDivOnPrice2H){
	                            TriggerCustomEvent(e1=>{ Draw.Line(this,string.Format("hiddenBullishDivergencePP2{0}", priorSecondTroughBar2H), false, CurrentBar - priorFirstTroughBar2H, priorFirstTroughLow2H - offsetDiv2, CurrentBar - priorSecondTroughBar2H, priorSecondTroughLow2H - offsetDiv2, HiddenBullColor2, DashStyleHelper.Solid, HiddenDivWidth2);},0,null);
							}
						//},0,null);
                    }
                    if (PrintMarkers && ShowSetupDots && ShowHistogramHiddenDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearSetup2{0}",cutoffIdx));
							RemoveDrawObject(string.Format("hiddenBullSetup2{0}",cutoffIdx));
						}
                        if (drawBearSetup2H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("hiddenBearSetup2{0}", CurrentBar), true, setupDotString, 0, Low[0] - offsetDraw2, -SetupFontSize2, HiddenBearishSetupColor2, setupFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawBullSetup2H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("hiddenBullSetup2{0}", CurrentBar), true, setupDotString, 0, High[0] + offsetDraw2, SetupFontSize2, HiddenBullishSetupColor2, setupFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    if (PrintMarkers && showArrows && ShowHistogramHiddenDivergences)
                    {
						if(IsFirstTickOfBar && cutoffIdx>0) {
							RemoveDrawObject(string.Format("hiddenBearTrigger2{0}",cutoffIdx-1));
							RemoveDrawObject(string.Format("hiddenBullTrigger2{0}",cutoffIdx-1));
						}
                        if (drawArrowDown2H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("hiddenBearTrigger2{0}", CurrentBar-1), true, arrowStringDown, 1, High[1] + offsetDraw2, 2 * TriangleFontSize2 / 3, HiddenArrowDownColor2, triangleFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                        if (drawArrowUp2H){
                            TriggerCustomEvent(e1=>{ Draw.Text(this,string.Format("hiddenBullTrigger2{0}", CurrentBar-1), true, arrowStringUp, 1, Low[1] - offsetDraw2, -2 * TriangleFontSize2 / 3, HiddenArrowUpColor2, triangleFont2, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
						}
                    }
                    #endregion
                }
                #endregion
            }
            #endregion
            #endregion

            #region -- Structure BIAS --

            SRType = drawHigherHighLabel ? 3 : drawLowerHighLabel ? 2 : drawDoubleTopLabel ? 1 : drawDoubleBottomLabel ? -1 : drawHigherLowLabel ? -2 : drawLowerLowLabel ? -3 : 0;
            swingHighsState[0] = drawHigherHighLabel ? 3 : drawLowerHighLabel ? 2 : drawDoubleTopLabel ? 1 : 0;//#SWINGS for BH
            swingLowsState[0] = drawDoubleBottomLabel ? -1 : drawHigherLowLabel ? -2 : drawLowerLowLabel ? -3 : 0;//#SWINGS for BH	

            #region -- Oscillation State --
            int decay = 0;
            if (Calculate!= Calculate.OnBarClose && State!=State.Historical) decay = 1;
            if (SRType != 0 && structureBiasState[decay + 1] == 0)
            {
                #region -- update sequence ---
                //--- Same Trend --
                if (upTrend[1] == upTrend[0])
                {
                    if (sequence.Count == 0) sequence.Add(SRType);
                    else sequence[sequence.Count - 1] = SRType;
                }

                //--- Changing Trend ---
                else if (Calculate == Calculate.OnBarClose && upTrend[1] != upTrend[0])
                {
                    if (sequence.Count < 4) sequence.Add(SRType);
                    else
                    {
                        sequence[0] = sequence[1];
                        sequence[1] = sequence[2];
                        sequence[2] = sequence[3];
                        sequence[3] = SRType;
                    }
                }
                #region -- eachtick --
                else if (Calculate != Calculate.OnBarClose && upTrend[1] != upTrend[0])
                {
                    if (IsFirstTickOfBar)
                    {
                        if (sequence.Count < 4) sequence.Add(SRType);
                        else
                        {
                            sequence[0] = sequence[1];
                            sequence[1] = sequence[2];
                            sequence[2] = sequence[3];
                            sequence[3] = SRType;
                        }
                    }
                    else if (sequence.Count == 0) sequence.Add(SRType);
                    else sequence[sequence.Count - 1] = SRType;
                }
                #endregion
                #endregion

                //Oscillation State
                //Need HH/!LL/HH to go to Up Trend
                //{NEW} !LL/High/!LL/HH to go to Up Trend
                //Need LL/!HH/LL to go to Dw Trend
                //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
                if (sequence.Count < 3) structureBiasState[decay] = 0;
                else if (sequence.Count < 4)
                {
                    if (sequence[0] == 3 && sequence[1] != -3 && sequence[2] == 3) structureBiasState[decay] = 1;
                    else if (sequence[0] == -3 && sequence[1] != 3 && sequence[2] == -3) structureBiasState[decay] = -1;
                    else structureBiasState[decay] = 0;
                }
                else
                {
                    if (sequence[1] == 3 && sequence[2] != -3 && sequence[3] == 3) structureBiasState[decay] = 1;
                    else if (sequence[1] == -3 && sequence[2] != 3 && sequence[3] == -3) structureBiasState[decay] = -1;
                    //{NEW} HL/LH/HL/HH to go to Up Trend
                    else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && sequence[3] == 3) structureBiasState[decay] = 1;
                    //{NEW} LH/HL/LH/LL to go to Up Trend
                    else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && sequence[3] == -3) structureBiasState[decay] = -1;
                    else structureBiasState[decay] = 0;
                }
            }
            #endregion

            #region -- UpTrend State --
            else if (SRType != 0 && structureBiasState[decay + 1] > 0)
            {
                if (IsFirstTickOfBar) sequence.Clear();
                //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
                if (SRType == -3)
                {
                    structureBiasState[decay] = 0;
                    if (IsFirstTickOfBar) sequence.Add(SRType);
                    else if (sequence.Count == 0) sequence.Add(SRType);
                    else sequence[sequence.Count - 1] = SRType;
                }
                else structureBiasState[decay] = 1;
            }
            #endregion

            #region -- DwTrend State --
            else if (SRType != 0 && structureBiasState[decay + 1] < 0)
            {
                if (IsFirstTickOfBar) sequence.Clear();
                //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
                if (SRType == 3)
                {
                    structureBiasState[decay] = 0;
                    if (IsFirstTickOfBar) sequence.Add(SRType);
                    else if (sequence.Count == 0) sequence.Add(SRType);
                    else sequence[sequence.Count - 1] = SRType;
                }
                else structureBiasState[decay] = -1;
            }
            #endregion

            else structureBiasState[decay] = structureBiasState[decay + 1];
            #endregion

            #region -- Setting filter values --  
            if (Calculate == Calculate.OnBarClose)
            {
                if (hiddenbullishCDivMACD[0] == 1.0)//#HIDDENDIV
                    macdBBState[0] = 2.5;
                else if (bullishCDivMACD[0] == 1.0)
                    macdBBState[0] = 2.0;
                else if (bearishCDivMACD[0] == 1.0)
                    macdBBState[0] = -2.0;
                else if (hiddenbearishCDivMACD[0] == 1.0)//#HIDDENDIV
                    macdBBState[0] = -2.5;

                else if (hiddenbullishTriggerCountMACDBB[0] > 0)//#HIDDENDIV
                    macdBBState[0] = 1.5;
                else if (bullishTriggerCountMACDBB[0] > 0)
                    macdBBState[0] = 1.0;
                else if (bearishTriggerCountMACDBB[0] > 0)
                    macdBBState[0] = -1.0;
                else if (hiddenbearishTriggerCountMACDBB[0] > 0)//#HIDDENDIV
                    macdBBState[0] = -1.5;

                else if (macdBBState[1] == 2.5 && !addLow && !updateLow)//#HIDDENDIV
                    macdBBState[0] = 2.5;
                else if (macdBBState[1] == 2.0 && !addLow && !updateLow)
                    macdBBState[0] = 2.0;
                else if (macdBBState[1] == -2.0 && !addHigh && !updateHigh)
                    macdBBState[0] = -2.0;
                else if (macdBBState[1] == -2.5 && !addHigh && !updateHigh)//#HIDDENDIV
                    macdBBState[0] = -2.5;

                else if (acceleration1[0] > 0)
                    macdBBState[0] = 3.0;
                else if (acceleration1[0] < 0)
                    macdBBState[0] = -3.0;
                else
                    macdBBState[0] = 0.0;

                //------------- Histogram -----------------

                if (hiddenbullishCDivHistogram[0] == 1.0)//#HIDDENDIV
                    histogramState[0] = 2.5;
                else if (bullishCDivHistogram[0] == 1.0)
                    histogramState[0] = 2.0;
                else if (bearishCDivHistogram[0] == 1.0)
                    histogramState[0] = -2.0;
                else if (hiddenbearishCDivHistogram[0] == 1.0)//#HIDDENDIV
                    histogramState[0] = -2.5;

                else if (hiddenbullishTriggerCountHistogram[0] > 0)//#HIDDENDIV
                    histogramState[0] = 1.5;
                else if (bullishTriggerCountHistogram[0] > 0)
                    histogramState[0] = 1.0;
                else if (bearishTriggerCountHistogram[0] > 0)
                    histogramState[0] = -1.0;
                else if (hiddenbearishTriggerCountHistogram[0] > 0)//#HIDDENDIV
                    histogramState[0] = -1.5;

                else if (histogramState[1] == 2.5 && !addLow && !updateLow)//#HIDDENDIV
                    histogramState[0] = 2.5;
                else if (histogramState[1] == 2.0 && !addLow && !updateLow)
                    histogramState[0] = 2.0;
                else if (acceleration2[0] > 0)
                    histogramState[0] = 3.0;
                else if (acceleration2[0] < 0)
                    histogramState[0] = -3.0;
                else if (histogramState[1] == -2.0 && !addHigh && !updateHigh)
                    histogramState[0] = -2.0;
                else if (HistogramState[1] == -2.5 && !addHigh && !updateHigh)//#HIDDENDIV
                    histogramState[0] = -2.5;
                else
                    histogramState[0] = 0.0;
            }
            else
            {
                //----------------- MACD --------------------
                if (hiddenbullishCDivMACD[0] == 1.0)//#HIDDENDIV
                    macdBBState[0] = 2.5;
                else if (bullishCDivMACD[0] == 1.0)
                    macdBBState[0] = 2.0;
                else if (bearishCDivMACD[0] == 1.0)
                    macdBBState[0] = -2.0;
                else if (hiddenbearishCDivMACD[0] == 1.0)//#HIDDENDIV
                    macdBBState[0] = -2.5;

                else if (hiddenbullishTriggerCountMACDBB[0] > 0)//#HIDDENDIV
                    macdBBState[0] = 1.5;
                else if (bullishTriggerCountMACDBB[0] > 0)
                    macdBBState[0] = 1.0;
                else if (bearishTriggerCountMACDBB[0] > 0)
                    macdBBState[0] = -1.0;
                else if (hiddenbearishTriggerCountMACDBB[0] > 0)//#HIDDENDIV
                    macdBBState[0] = -1.5;

                else if (macdBBState[1] == 2.5 && !intraBarAddLow && !intraBarUpdateLow)//#HIDDENDIV
                    macdBBState[0] = 2.5;
                else if (macdBBState[1] == 2.0 && !intraBarAddLow && !intraBarUpdateLow)
                    macdBBState[0] = 2.0;
                else if (macdBBState[1] == -2.0 && !intraBarAddHigh && !intraBarUpdateHigh)
                    macdBBState[0] = -2.0;
                else if (macdBBState[1] == -2.5 && !intraBarAddHigh && !intraBarUpdateHigh)//#HIDDENDIV
                    macdBBState[0] = -2.5;

                else if (acceleration1[0] > 0)
                    macdBBState[0] = 3.0;
                else if (acceleration1[0] < 0)
                    macdBBState[0] = -3.0;
                else
                    macdBBState[0] = 0.0;

                //------------- Histogram -----------------
                if (hiddenbullishCDivHistogram[0] == 1.0)//#HIDDENDIV
                    histogramState[0] = 2.5;
                if (bullishCDivHistogram[0] == 1.0)
                    histogramState[0] = 2.0;
                else if (bearishCDivHistogram[0] == 1.0)
                    histogramState[0] = -2.0;
                else if (hiddenbearishCDivHistogram[0] == 1.0)//#HIDDENDIV
                    histogramState[0] = -2.5;

                else if (hiddenbullishTriggerCountHistogram[0] > 0)//#HIDDENDIV
                    histogramState[0] = 1.5;
                else if (bullishTriggerCountHistogram[0] > 0)
                    histogramState[0] = 1.0;
                else if (bearishTriggerCountHistogram[0] > 0)
                    histogramState[0] = -1.0;
                else if (hiddenbearishTriggerCountHistogram[0] > 0)//#HIDDENDIV
                    histogramState[0] = -1.5;

                else if (histogramState[1] == 2.5 && !intraBarAddLow && !intraBarUpdateLow)//#HIDDENDIV
                    histogramState[0] = 2.5;
                else if (histogramState[1] == 2.0 && !intraBarAddLow && !intraBarUpdateLow)
                    histogramState[0] = 2.0;
                else if (histogramState[1] == -2.0 && !intraBarAddHigh && !intraBarUpdateHigh)
                    histogramState[0] = -2.0;
                else if (histogramState[1] == -2.5 && !intraBarAddHigh && !intraBarUpdateHigh)//#HIDDENDIV
                    histogramState[0] = -2.5;

                else if (acceleration2[0] > 0)
                    histogramState[0] = 3.0;
                else if (acceleration2[0] < 0)
                    histogramState[0] = -3.0;
                else
                    histogramState[0] = 0.0;
            }
            #endregion
line=9881;
			#region -- Regular Divergence Signals --
			Sigs[R_DIV].c.Clear();
			if(bullishCDivMACD[0]==1 || bullishCDivHistogram[0]==1){
				Sigs[R_DIV].c.Add(true);
				bool DrawNow = (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences);
				AddOrUpdateEntry(Sigs[R_DIV], "BRD", CurrentBar, DrawNow);
				if(State!=State.Historical && pRDIV_BuySoundWAV!="SOUND OFF" && AlertBar!=CurrentBar){
					AlertBar=CurrentBar;
					Alert(CurrentBar.ToString(), Priority.High,"RegDiv BUY "+BarsPeriod.ToString(),BuySoundFiles[R_DIV],0, Brushes.Green,Brushes.White);
				}
				if(DrawNow && pBuyStripeOpacity>0 && pBuyStripeBrush!=Brushes.Transparent && this.pShowRacingStripes && CurrentBars[0]>1) BackBrushesAll[1] = BuyStripeBrush;
			}
			else if( bearishCDivMACD[0]==1 || bearishCDivHistogram[0]==1){
				Sigs[R_DIV].c.Add(true);
				bool DrawNow = (pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences);
				AddOrUpdateEntry(Sigs[R_DIV], "SRD", CurrentBar, DrawNow);
				if(State!=State.Historical && pRDIV_SellSoundWAV!="SOUND OFF" && AlertBar!=CurrentBar){
					AlertBar=CurrentBar;
					Alert(CurrentBar.ToString(), Priority.High,"RegDiv SELL "+BarsPeriod.ToString(),SellSoundFiles[R_DIV],0, Brushes.Red,Brushes.White);
				}
				if(DrawNow && pSellStripeOpacity>0 && pSellStripeBrush!=Brushes.Transparent && this.pShowRacingStripes && CurrentBars[0]>1) BackBrushesAll[1] = SellStripeBrush;
			}
			#endregion
			#region -- Hidden Divergence Signals --
			Sigs[H_DIV].c.Clear();
			if(hiddenbullishCDivMACD[0]==1 || hiddenbullishCDivHistogram[0]==1){
				Sigs[H_DIV].c.Add(true);
				bool DrawNow = (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences);
				AddOrUpdateEntry(Sigs[H_DIV], "BHD", CurrentBar, DrawNow);
				if(State!=State.Historical && pHDIV_BuySoundWAV!="SOUND OFF" && AlertBar!=CurrentBar){
					AlertBar=CurrentBar;
					Alert(CurrentBar.ToString(), Priority.High,"HiddenDiv BUY "+BarsPeriod.ToString(),BuySoundFiles[H_DIV],0, Brushes.Green,Brushes.White);
				}
				if(DrawNow && pBuyStripeOpacity>0 && pBuyStripeBrush != Brushes.Transparent && this.pShowRacingStripes && CurrentBars[0]>1) BackBrushesAll[1] = BuyStripeBrush;
			}
			if( hiddenbearishCDivMACD[0]==1 || hiddenbearishCDivHistogram[0]==1){
				Sigs[H_DIV].c.Add(true);
				bool DrawNow = (pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences);
				AddOrUpdateEntry(Sigs[H_DIV], "SHD", CurrentBar, DrawNow);
				if(State!=State.Historical && pHDIV_SellSoundWAV!="SOUND OFF" && AlertBar!=CurrentBar){
					AlertBar=CurrentBar;
					Alert(CurrentBar.ToString(), Priority.High,"HiddenDiv SELL "+BarsPeriod.ToString(),SellSoundFiles[H_DIV],0, Brushes.Red,Brushes.White);
				}
				if(DrawNow && pSellStripeOpacity>0 && pSellStripeBrush != Brushes.Transparent && this.pShowRacingStripes && CurrentBars[0]>1) BackBrushesAll[1] = SellStripeBrush;
			}
			#endregion
			#region -- CleanUp intrabar Divergence Signals --
			if((pSignalType == ARC_VMDSystem_SystemTypes.RegularDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences) && !Sigs[R_DIV].IsEntrySignal()){
				if(Sigs[R_DIV].BuySignals.ContainsKey(CurrentBar)){
					if(pBuyStripeOpacity>0 && pBuyStripeBrush!=Brushes.Transparent && CurrentBars[0]>1) BackBrushesAll[1] = null;
					RemoveDrawObject(string.Format("SL {0}-{1}", CurrentBar, Sigs[R_DIV].Name));
					RemoveDrawObject(string.Format("T1 {0}-{1}", CurrentBar, Sigs[R_DIV].Name));
					RemoveDrawObject(string.Format("T2 {0}-{1}", CurrentBar, Sigs[R_DIV].Name));
					Sigs[R_DIV].BuySignals.Remove(CurrentBar);
				}
				else if(Sigs[R_DIV].SellSignals.ContainsKey(CurrentBar)){
					if(pSellStripeOpacity>0 && pSellStripeBrush!=Brushes.Transparent && CurrentBars[0]>1) BackBrushesAll[1] = null;
					RemoveDrawObject(string.Format("SL {0}-{1}", CurrentBar, Sigs[R_DIV].Name));
					RemoveDrawObject(string.Format("T1 {0}-{1}", CurrentBar, Sigs[R_DIV].Name));
					RemoveDrawObject(string.Format("T2 {0}-{1}", CurrentBar, Sigs[R_DIV].Name));
					Sigs[R_DIV].SellSignals.Remove(CurrentBar);
				}
			}
			if((pSignalType == ARC_VMDSystem_SystemTypes.HiddenDiv || pSignalType == ARC_VMDSystem_SystemTypes.BothDivergences) && !Sigs[H_DIV].IsEntrySignal()){
				if(Sigs[H_DIV].BuySignals.ContainsKey(CurrentBar)){
					if(pBuyStripeOpacity>0 && pBuyStripeBrush!=Brushes.Transparent && CurrentBars[0]>1) BackBrushesAll[1] = null;
					RemoveDrawObject(string.Format("SL {0}-{1}", CurrentBar, Sigs[H_DIV].Name));
					RemoveDrawObject(string.Format("T1 {0}-{1}", CurrentBar, Sigs[H_DIV].Name));
					RemoveDrawObject(string.Format("T2 {0}-{1}", CurrentBar, Sigs[H_DIV].Name));
					Sigs[H_DIV].BuySignals.Remove(CurrentBar);
				}
				else if(Sigs[H_DIV].SellSignals.ContainsKey(CurrentBar)){
					if(pSellStripeOpacity>0 && pSellStripeBrush!=Brushes.Transparent && CurrentBars[0]>1) BackBrushesAll[1] = null;
					RemoveDrawObject(string.Format("SL {0}-{1}", CurrentBar, Sigs[H_DIV].Name));
					RemoveDrawObject(string.Format("T1 {0}-{1}", CurrentBar, Sigs[H_DIV].Name));
					RemoveDrawObject(string.Format("T2 {0}-{1}", CurrentBar, Sigs[H_DIV].Name));
					Sigs[H_DIV].SellSignals.Remove(CurrentBar);
				}
			}
			#endregion
line=9962;
			#region bar anticipating stubs
			/*
			double cLow = int.MinValue;
			double cHigh = int.MinValue;
			bool NTRange   =  Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Range;
			bool FullRange =  Bars.BarsType.Name.Contains("NS_FullRange") || Bars.BarsType.Name.Contains("GZT_FullRange");
			bool RenkoBT   =  Bars.BarsType.Name.Contains("NS_RenkoBT")   || Bars.BarsType.Name.Contains("GZT_RenkoBT");
			bool RenkoBXT  =  Bars.BarsType.Name.Contains("NS_RenkoBXT")  || Bars.BarsType.Name.Contains("GZT_RenkoBXT");
			bool PullBack  =  Bars.BarsType.Name.Contains("NS_PullBack")  || Bars.BarsType.Name.Contains("GZT_PullBack");
			bool RenkoBXT_BTMode =  Bars.BarsType.Name.Contains("NS_RenkoBXT_BTMode") || Bars.BarsType.Name.Contains("GZT_RenkoBXT_BTMode");
            #region -- Range and Full Range Bars logic --
            if (NTRange || FullRange)
            {
line=9976;
                double rangeValue = Math.Floor(10000000.0 * (double)Bars.BarsPeriod.Value * Bars.Instrument.MasterInstrument.TickSize) / 10000000.0;
                cLow = High[0] - rangeValue;
                cHigh = Low[0] + rangeValue;
            }
            #endregion

            #region -- NS_RenkoBT logic --
            else if (RenkoBT)
            {
line=9986;
                double body = Bars.BarsPeriod.Value * Bars.Instrument.MasterInstrument.TickSize;
                bool btMode = (int)Bars.BarsPeriod.BaseBarsPeriodValue == 1;
                bool trend = Close[1] > Open[1];

                if (Time[0].CompareTo(Time[1].AddSeconds(Bars.BarsPeriod.Value2)) < 0)
                {
                    cLow = 0;
                    cHigh = 0;
                }
                else if (!btMode)
                {
                    cHigh = Math.Max(Open[0] + body, High[0]);
                    cLow = Math.Min(Open[0] - body, Low[0]);
                }
                else
                {
                    if (trend)
                    {
                        cHigh = Math.Max(RTTS(Close[1] - body / 2) + body, High[0]);
                        cLow = Math.Min(RTTS(Close[1] - body / 2) - body, Low[0]);
                    }
                    else
                    {
                        cHigh = Math.Max(RTTS(Close[1] + body / 2) + body, High[0]);
                        cLow = Math.Min(RTTS(Close[1] + body / 2) - body, Low[0]);
                    }
                }
            }
            #endregion

            #region -- NS_PullBack logic --
            else if (PullBack)
            {
line=10020;
                double pullbacksize = (Bars.BarsPeriod.Value2 - 1) * TickSize;
                double barsize = Bars.BarsPeriod.Value * TickSize;

                if (RTTS(High[0] - Low[0]) <= barsize)
                {
                    cHigh = 0;
                    cLow = 0;
                }
                else
                {
                    cHigh = High[0] - pullbacksize;
                    cLow = Low[0] + pullbacksize;
                }
            }
            #endregion

            #region -- NS_RenkoBXT logic --
            else if (RenkoBXT || RenkoBXT_BTMode)
            {
line=10040;
                bool trend = Close[1] > Open[1];
                double body = Bars.BarsPeriod.Value * Bars.Instrument.MasterInstrument.TickSize;
                double offset = Bars.BarsPeriod.Value2 * Bars.Instrument.MasterInstrument.TickSize;
                double reverse = Bars.BarsPeriod.BaseBarsPeriodValue * Bars.Instrument.MasterInstrument.TickSize;

                if (trend)
                {
                    cHigh = RenkoBXT_BTMode ? Close[1] - offset + body : Open[0] + body;
                    cLow = High[0] - reverse;
                }
                else
                {
                    cLow = RenkoBXT_BTMode ? Close[1] + offset - body : Open[0] - body;
                    cHigh = Low[0] + reverse;
                }
            }
            #endregion
			*/
			#endregion

line=10061;
iz = false;
if(iz){
	Print("------------------    "+Time[0].ToString()+"  Supp Count: "+Sigs[TERMITE].SuppLevels.Count+"  Res Count: "+Sigs[TERMITE].ResLevels.Count);
	foreach(var pl in Sigs[TERMITE].SuppLevels) {
		Print(" S  "+pl.ToString());
	}
	foreach(var pl in Sigs[TERMITE].ResLevels) {
		Print(" R  "+pl.ToString());
	}
}

			#region -- Termite Signals --
			Sigs[TERMITE].c.Clear();
			int soff = 0;
			if(CurrentBar>soff+5){
			if(!upTrend[soff] && upTrend[1+soff]) {//trend reverses down
				Sigs[TERMITE].AddStructure('H', High.GetValueAt(lastHighIdx), lastHighIdx);
#if ONE_TERMITE_SIGNAL_PER_TREND
				Sigs[TERMITE].PermitLongs = false;
				Sigs[TERMITE].PermitShorts = true;
if(iz)Print("3811...Trend starts down, permitting shorts");
#endif
			}
			if(upTrend[soff] && !upTrend[1+soff]) {//trend reverses up
				Sigs[TERMITE].AddStructure('L', Low.GetValueAt(lastLowIdx), lastLowIdx);
#if ONE_TERMITE_SIGNAL_PER_TREND
				Sigs[TERMITE].PermitLongs  = true;
				Sigs[TERMITE].PermitShorts = false;
if(iz)Print("3817...Trend starts up, permitting longs");
#endif
			}
if(iz)Print("   longs ");
			if(Sigs[TERMITE].SwingHighABars.Count>1){
				Sigs[TERMITE].c.Add(LevelCrossed(TERMITE, 'B', Low[2+soff], Open[1+soff], High[1+soff], Low[1+soff], Close[1+soff], upTrend[0]));
//if(iz) Print(string.Format("{0}  {1} - {2} ", Sigs[TERMITE].c.Last().ToString(), High[1+soff].ToString(), Low[1+soff].ToString()));
				Sigs[TERMITE].c.Add(BBMACDLine[1+soff] > 0);
//if(iz) Print(string.Format("{0}  {1} > {2}", Sigs[TERMITE].c.Last().ToString(),BBMACDLine[1+soff].ToString(),0));
				Sigs[TERMITE].c.Add(BBMACDLine[1+soff] > Upper[1+soff]);
//if(iz) Print(string.Format("{0}  {1} > {2}", Sigs[TERMITE].c.Last().ToString(),BBMACDLine[1+soff].ToString(),Upper[1+soff].ToString()));
				Sigs[TERMITE].c.Add(Upper[1+soff] > 0);
//if(iz) Print(string.Format("{0}  {1} > {2}", Sigs[TERMITE].c.Last().ToString(),Upper[1+soff].ToString(),0));
				Sigs[TERMITE].c.Add(Histogram[1+soff] > 0);
			}
			if(Sigs[TERMITE].PermitLongs && Sigs[TERMITE].IsEntrySignal()){
				bool DrawNow = pSignalType == ARC_VMDSystem_SystemTypes.Termite;
				AddOrUpdateEntry(Sigs[TERMITE], "BT", CurrentBar-soff, DrawNow);
#if ONE_TERMITE_SIGNAL_PER_TREND
				Sigs[TERMITE].PermitLongs = false;
if(iz)Print("3834...Long signal printed, LONGS are not permitted now");
#endif
				if(State!=State.Historical && pTermiteBuySoundWAV!="SOUND OFF" && AlertBar!=CurrentBar){
					AlertBar=CurrentBar;
					Alert(CurrentBar.ToString(), Priority.High,"Termite BUY "+BarsPeriod.ToString(),BuySoundFiles[TERMITE],0, Brushes.Green,Brushes.White);
				}
				if(DrawNow && pBuyStripeOpacity>0 && pBuyStripeBrush != Brushes.Transparent && this.pShowRacingStripes && IsValidRBar(1+soff)) BackBrushesAll.Set(CurrentBar-(1+soff), BuyStripeBrush);
//Print("TBuy at "+Time[0].ToString()+"   "+Sigs[TERMITE].BuySignals[CurrentBar].ToStr());

			}
if(iz)Print("   shorts ");
			Sigs[TERMITE].c.Clear();
			if(Sigs[TERMITE].SwingLowABars.Count>1){
				Sigs[TERMITE].c.Add(LevelCrossed(TERMITE, 'S', High[2+soff], Open[1+soff], High[1+soff], Low[1+soff], Close[1+soff], upTrend[0]));
//if(iz) Print(string.Format("{0}  {1} - {2} ", Sigs[TERMITE].c.Last().ToString(), High[1+soff].ToString(), Low[1+soff].ToString()));
				Sigs[TERMITE].c.Add(BBMACDLine[1+soff] < 0);
//if(iz) Print(string.Format("{0}  {1} < {2}", Sigs[TERMITE].c.Last().ToString(), BBMACDLine[1+soff].ToString(),0));
				Sigs[TERMITE].c.Add(BBMACDLine[1+soff] < Lower[1+soff]);
//if(iz) Print(string.Format("{0}  {1} < {2}", Sigs[TERMITE].c.Last().ToString(), BBMACDLine[1+soff].ToString(), Lower[1+soff].ToString()));
				Sigs[TERMITE].c.Add(Lower[1+soff] < 0);
//if(iz) Print(string.Format("{0}  {1} > {2}", Sigs[TERMITE].c.Last().ToString(), Lower[1+soff].ToString(),0));
				Sigs[TERMITE].c.Add(Histogram[1+soff] < 0);
			}
			if(Sigs[TERMITE].PermitShorts && Sigs[TERMITE].IsEntrySignal()) {
				bool DrawNow = pSignalType == ARC_VMDSystem_SystemTypes.Termite;
				AddOrUpdateEntry(Sigs[TERMITE], "ST", CurrentBar-soff, DrawNow);
#if ONE_TERMITE_SIGNAL_PER_TREND
				Sigs[TERMITE].PermitShorts = false;
if(iz)Print("3855...Short signal printed, SHORTS are not permitted now");
#endif
				if(State!=State.Historical && pTermiteSellSoundWAV!="SOUND OFF" && AlertBar!=CurrentBar){
					AlertBar=CurrentBar;
					Alert(CurrentBar.ToString(), Priority.High,"Termite SELL "+BarsPeriod.ToString(),SellSoundFiles[TERMITE],0, Brushes.Red,Brushes.White);
				}
				if(DrawNow && pSellStripeOpacity>0 && pSellStripeBrush != Brushes.Transparent && this.pShowRacingStripes && IsValidRBar(1+soff)) BackBrushesAll.Set(CurrentBar-(1+soff), SellStripeBrush);
//Print("TSell at "+Time[0].ToString()+"   "+Sigs[TERMITE].SellSignals[CurrentBar].ToStr());
			}
line=10145;
			if(Sigs[TERMITE].SwingHighABars.Count>0 && Sigs[TERMITE].SwingLowABars.Count>0){
				FindAndDisqualifySRLevels(TERMITE, High[3+soff], Low[3+soff], High[2+soff], Low[2+soff], Close[2+soff]);
			}
			}
			#endregion
			//Print(SystemSignal[0]+"    "+(SystemSignal[0]!=0 ? "ENTRY":""));
line=10152;
}catch(Exception e){Print(line+": "+e.ToString());}
        }
//===================================================================================================================
        private double RTTS(double r) { 
			int t = (int)Math.Round(r/TickSize);
			return t*TickSize;
		}
//===================================================================================================================
		public override void OnRenderTargetChanged()
		{
			#region -- Brush disposal --
			if(ChannelBkgDXBrush!=null      && !ChannelBkgDXBrush.IsDisposed)      ChannelBkgDXBrush.Dispose();      ChannelBkgDXBrush = null;
			if(BullishBkgDXBrush!=null      && !BullishBkgDXBrush.IsDisposed)      BullishBkgDXBrush.Dispose();      BullishBkgDXBrush = null;
			if(BearishBkgDXBrush!=null      && !BearishBkgDXBrush.IsDisposed)      BearishBkgDXBrush.Dispose();      BearishBkgDXBrush = null;
			if(DeepBullishBkgDXBrush!=null  && !DeepBullishBkgDXBrush.IsDisposed)  DeepBullishBkgDXBrush.Dispose();  DeepBullishBkgDXBrush = null;
			if(DeepBearishBkgDXBrush!=null  && !DeepBearishBkgDXBrush.IsDisposed)  DeepBearishBkgDXBrush.Dispose();  DeepBearishBkgDXBrush= null;
			if(OppositeBkgDXBrush!=null     && !OppositeBkgDXBrush.IsDisposed)     OppositeBkgDXBrush.Dispose();     OppositeBkgDXBrush = null;
			if(DataTableDXBrush!=null       && !DataTableDXBrush.IsDisposed)       DataTableDXBrush.Dispose();       DataTableDXBrush = null;
			if(BullishDivergenceDXBrush!=null      && !BullishDivergenceDXBrush.IsDisposed)      BullishDivergenceDXBrush.Dispose();    BullishDivergenceDXBrush = null;
			if(BearishDivergenceDXBrush!=null      && !BearishDivergenceDXBrush.IsDisposed)      BearishDivergenceDXBrush.Dispose();    BearishDivergenceDXBrush = null;
			if(BullishAccelerationDXBrush!=null    && !BullishAccelerationDXBrush.IsDisposed)    BullishAccelerationDXBrush.Dispose();  BullishAccelerationDXBrush = null;
			if(BearishAccelerationDXBrush!=null    && !BearishAccelerationDXBrush.IsDisposed)    BearishAccelerationDXBrush.Dispose();  BearishAccelerationDXBrush = null;
//			if(!=null      && !.IsDisposed)      .Dispose();            = null;
//			if(!=null      && !.IsDisposed)      .Dispose();            = null;
			#endregion -------------------------------------
			if(RenderTarget!=null){
				#region -- Create Brushes --
				BullishBkgDXBrush         = BullishBackgroundColor.ToDxBrush(RenderTarget);
				BullishBkgDXBrush.Opacity = BackgroundOpacity/100f;
				BearishBkgDXBrush         = BearishBackgroundColor.ToDxBrush(RenderTarget);
				BearishBkgDXBrush.Opacity = BackgroundOpacity/100f;

				DeepBullishBkgDXBrush     = DeepBullishBackgroundColor.ToDxBrush(RenderTarget);
				DeepBullishBkgDXBrush.Opacity = BackgroundOpacity/100f;
				DeepBearishBkgDXBrush     = DeepBearishBackgroundColor.ToDxBrush(RenderTarget);
				DeepBearishBkgDXBrush.Opacity = BackgroundOpacity/100f;

				OppositeBkgDXBrush     = OppositeBackgroundColor.ToDxBrush(RenderTarget);
				OppositeBkgDXBrush.Opacity = BackgroundOpacity/100f;

				DataTableDXBrush = DataTableColor.ToDxBrush(RenderTarget);
				BullishDivergenceDXBrush = BullishDivergenceColor.ToDxBrush(RenderTarget);
				BearishDivergenceDXBrush = BearishDivergenceColor.ToDxBrush(RenderTarget);

				BullishAccelerationDXBrush = BullishAccelerationColor.ToDxBrush(RenderTarget);
				BearishAccelerationDXBrush = BearishAccelerationColor.ToDxBrush(RenderTarget);
				ChannelBkgDXBrush = ChannelColor.ToDxBrush(RenderTarget);
	            ChannelBkgDXBrush.Opacity = ChannelOpacity / 100f;
				#endregion --------------------------------------
			}
		}
//===================================================================================================================
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			#region -- Draw a temporary message on the chart --
			if(MsgOnChart.Length>0 && TimeOfMessagePrint == DateTime.MinValue){
				TimeOfMessagePrint = DateTime.Now;
				Draw.TextFixed(this, "MsgOnChart",MsgOnChart,TextPosition.Center,Brushes.White, new SimpleFont("Arial",14),Brushes.Transparent,Brushes.Black,100);
				MsgOnChart = string.Empty;
			}
			if(TimeOfMessagePrint != DateTime.MinValue){
				var ts = new TimeSpan(DateTime.Now.Ticks - TimeOfMessagePrint.Ticks);
				if(ts.TotalSeconds>10){
					RemoveDrawObject("MsgOnChart");
					TimeOfMessagePrint = DateTime.MinValue;
				}
			}
			#endregion
//			while(BkgChangesQue.Count>0){
////				Print("BkgChangesQue.Count: "+BkgChangesQue.Count+"  Last: "+BkgChangesQue[0][1].ToString()+"  Current: "+BkgChangesQue[0][0].ToString());
//				try{
//					UpdateBackgroundStripes(BkgChangesQue[0][1], BkgChangesQue[0][0]);
//				}catch(Exception eee){Print("bkg: "+eee.ToString());}
//				BkgChangesQue.RemoveAt(0);
//			}
	        #region -- OnRender : Custom Drawing --  
			last_visible_bar = ChartBars.ToIndex;
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            int lastBarIndex = Math.Min(CurrentBar, ChartBars.ToIndex);//RIGHT BAR idx (absolute)
            if (lastBarIndex < BarsRequiredToPlot) return;

            int firstBarIndex = Math.Max(BarsRequiredToPlot, ChartBars.FromIndex);//LEFT BAR idx (absolute)
try{
			#region -- Draw TradePlan EP, SL, T1 and T2 rays --
			double EP = double.MinValue;
			if(RMaB != lastBarIndex){
				int max = int.MinValue;
				Sigs[TERMITE].RightmostVisibleSignal = 0;
				foreach(var k in Sigs[TERMITE].BuySignals.Keys)  if(k <= lastBarIndex) max = Math.Max(max,k);
				foreach(var k in Sigs[TERMITE].SellSignals.Keys) if(k <= lastBarIndex) max = Math.Max(max,k);
				if(max > 0) Sigs[TERMITE].RightmostVisibleSignal = max;

				max = int.MinValue;
				Sigs[H_DIV].RightmostVisibleSignal = 0;
				foreach(var k in Sigs[H_DIV].BuySignals.Keys)  if(k <= lastBarIndex) max = Math.Max(max,k);
				foreach(var k in Sigs[H_DIV].SellSignals.Keys) if(k <= lastBarIndex) max = Math.Max(max,k);
				if(max > 0) Sigs[H_DIV].RightmostVisibleSignal = max;

				max = int.MinValue;
				Sigs[R_DIV].RightmostVisibleSignal = 0;
				foreach(var k in Sigs[R_DIV].BuySignals.Keys)  if(k <= lastBarIndex) max = Math.Max(max,k);
				foreach(var k in Sigs[R_DIV].SellSignals.Keys) if(k <= lastBarIndex) max = Math.Max(max,k);
				if(max > 0) Sigs[R_DIV].RightmostVisibleSignal = max;

				last_trade_signal_bar = CalculateMostRecentSignalABar(pSignalType);
				if(this.pTradePlanVisible)
					DrawTradePlanLines(ref EP, ref last_trade_signal_bar);
				if(EP==int.MinValue || last_trade_signal_bar<0){
					RemoveDrawObject("E-ray");
					RemoveDrawObject("SL-ray");
					RemoveDrawObject("T1-ray");
					RemoveDrawObject("T2-ray");
line=10265;
				}

			}
			RMaB = lastBarIndex;
			#endregion -----------------------------
}catch(Exception e1){Print(line+":  OnRender e1: "+e1.ToString());}

            SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

            #region -- Zero Line --
            drawLine(0, 0, lastBarIndex, firstBarIndex, ZerolineColor, ZerolineStyle, ZerolineWidth, chartControl, chartScale); 
            #endregion

			#region -- Draw Channel + Div on indicator panel + flooding on momo panel --
            bool drawbbchannel = CurrentBar > BarsRequiredToPlot && ChannelOpacity > 0;
            int divergenceSpan = 0;
//	Print("7953  Background flooding: "+BackgroundFlooding.ToString());

            for (int i = lastBarIndex; i >= firstBarIndex; i--)
            {
                try
                {
                    #region -- draw Bollinger Channel --
                    if (drawbbchannel){
//						int x = chartControl.GetXByBarIndex(chartControl.BarsArray[0], i);
//						int y = chartScale.GetYByValue(-3);
//						RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x,y),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
//						var y0 = chartScale.GetYByValue(Upper.GetValueAt(i));
//						var y1 = chartScale.GetYByValue(Upper.GetValueAt(i - 1));
//						var y2 = chartScale.GetYByValue(Lower.GetValueAt(i - 1));
//						var y3 = chartScale.GetYByValue(Lower.GetValueAt(i));
//						var x0 = chartControl.GetXByBarIndex(chartControl.BarsArray[0], i);
//						var x1 = chartControl.GetXByBarIndex(chartControl.BarsArray[0], i - 1);
//if(i==lastBarIndex) {
//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x0,y0),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x1,y1),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x1,y2),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x0,y3),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
//}
                        drawRegion(
							new double[] { Upper.GetValueAt(i), Upper.GetValueAt(i-1), Lower.GetValueAt(i-1), Lower.GetValueAt(i) }, 
							new int[] { i, i-1, i-1, i }, 
							ChannelBkgDXBrush, chartControl, chartScale);//25.05.16 - beta11 code breaking change
					}
                    #endregion

                    #region -- BEAR DIV MACD --
                    if (bearishDivPlotSeriesMACDBB.IsValidDataPointAt(i))
                    {
                        divergenceSpan = bearishDivPlotSeriesMACDBB.GetValueAt(i);
                        if (divergenceSpan > 0) drawLine(BBMACD.GetValueAt(i), BBMACD.GetValueAt(i - divergenceSpan), i-1, i - divergenceSpan-1, BearColor1, DashStyleHelper.Solid, DivWidth1, chartControl, chartScale);                        
                    }
                    #endregion

                    #region -- BEAR HIDDEN DIV MACD --
                    if (hiddenbearishDivPlotSeriesMACDBB.IsValidDataPointAt(i))
                    {
                        divergenceSpan = hiddenbearishDivPlotSeriesMACDBB.GetValueAt(i);
                        if (divergenceSpan > 0) drawLine(BBMACD.GetValueAt(i), BBMACD.GetValueAt(i - divergenceSpan), i-1, i - divergenceSpan-1, HiddenBearColor1, DashStyleHelper.Solid, HiddenDivWidth1, chartControl, chartScale);                        
                    }
                    #endregion

                    #region -- BULL DIV MACD --
                    if (bullishDivPlotSeriesMACDBB.IsValidDataPointAt(i))
                    {
                        divergenceSpan = bullishDivPlotSeriesMACDBB.GetValueAt(i);
                        if (divergenceSpan > 0) drawLine(BBMACD.GetValueAt(i), BBMACD.GetValueAt(i - divergenceSpan), i-1, i - divergenceSpan-1, BullColor1, DashStyleHelper.Solid, DivWidth1, chartControl, chartScale);
                    }
                    #endregion

                    #region -- BULL HIDDEN DIV MACD --
                    if (hiddenbullishDivPlotSeriesMACDBB.IsValidDataPointAt(i))
                    {
                        divergenceSpan = hiddenbullishDivPlotSeriesMACDBB.GetValueAt(i);
                        if (divergenceSpan > 0) drawLine(BBMACD.GetValueAt(i), BBMACD.GetValueAt(i - divergenceSpan), i-1, i - divergenceSpan-1, HiddenBullColor1, DashStyleHelper.Solid, HiddenDivWidth1, chartControl, chartScale);
                    }
                    #endregion

                    #region -- BEAR DIV HISTO --
                    if (bearishDivPlotSeriesHistogram.IsValidDataPointAt(i))
                    {
                        divergenceSpan = bearishDivPlotSeriesHistogram.GetValueAt(i);
                        if (divergenceSpan > 0) drawLine(Histogram.GetValueAt(i), Histogram.GetValueAt(i - divergenceSpan), i-1, i - divergenceSpan-1, BearColor2, DashStyleHelper.Solid, DivWidth2, chartControl, chartScale);
                    }
                    #endregion

                    #region -- BEAR HIDDEN DIV HISTO --
                    if (hiddenbearishDivPlotSeriesHistogram.IsValidDataPointAt(i))
                    {
                        divergenceSpan = hiddenbearishDivPlotSeriesHistogram.GetValueAt(i);
                        if (divergenceSpan > 0) drawLine(Histogram.GetValueAt(i), Histogram.GetValueAt(i - divergenceSpan), i-1, i - divergenceSpan-1, HiddenBearColor2, DashStyleHelper.Solid, HiddenDivWidth2, chartControl, chartScale);
                    }
                    #endregion

                    #region -- BULL DIV HISTO --
                    if (bullishDivPlotSeriesHistogram.IsValidDataPointAt(i))
                    {
                        divergenceSpan = bullishDivPlotSeriesHistogram.GetValueAt(i);
                        if (divergenceSpan > 0) drawLine(Histogram.GetValueAt(i), Histogram.GetValueAt(i - divergenceSpan), i-1, i - divergenceSpan-1, BullColor2, DashStyleHelper.Solid, DivWidth2, chartControl, chartScale);
                    }
                    #endregion

                    #region -- BULL HIDDEN DIV HISTO --
                    if (hiddenbullishDivPlotSeriesHistogram.IsValidDataPointAt(i))
                    {
                        divergenceSpan = hiddenbullishDivPlotSeriesHistogram.GetValueAt(i);
                        if (divergenceSpan > 0) drawLine(Histogram.GetValueAt(i), Histogram.GetValueAt(i - divergenceSpan), i-1, i - divergenceSpan-1, HiddenBullColor2, DashStyleHelper.Solid, HiddenDivWidth2, chartControl, chartScale);
                    }
                    #endregion

                    //##MODIF## AzurITec - 18.05.2016
                    #region -- flooding on momo panel only --
                    if (BackgroundFlooding != ARC_VMDSystem_Flooding.None)
                    {
                        int[] indexes = new int[] { i, i + 1, i + 1, i };
                        double[] minmax = new double[] { chartScale.MaxValue, chartScale.MaxValue, chartScale.MinValue, chartScale.MinValue };
                        if (BackgroundFlooding == ARC_VMDSystem_Flooding.Histogram)
                        {
                            if (Histogram.GetValueAt(i) > 0)
                                drawRegion(minmax, indexes, BullishBkgDXBrush, chartControl, chartScale, false, true);
                            else if (Histogram.GetValueAt(i) < 0)
                                drawRegion(minmax, indexes, BearishBkgDXBrush, chartControl, chartScale, false, true);
                            else if (Histogram.GetValueAt(i + 1) > 0)
                                drawRegion(minmax, indexes, BullishBkgDXBrush, chartControl, chartScale, false, true);
                            else
                                drawRegion(minmax, indexes, BearishBkgDXBrush, chartControl, chartScale, false, true);
                        }
                        else if (BackgroundFlooding == ARC_VMDSystem_Flooding.Structure)
                        {
                            if (StructureBiasState.GetValueAt(i) > 0)
                                drawRegion(minmax, indexes, BullishBkgDXBrush, chartControl, chartScale, false, true);
                            else if (StructureBiasState.GetValueAt(i) < 0)
                                drawRegion(minmax, indexes, BearishBkgDXBrush, chartControl, chartScale, false, true);
                        }
                        else
                        {
                            if (StructureBiasState.GetValueAt(i) > 0)
                            {
                                if (Histogram.GetValueAt(i) > 0)
                                    drawRegion(minmax, indexes, DeepBullishBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i) < 0)
                                    drawRegion(minmax, indexes, OppositeBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i + 1) > 0)
                                    drawRegion(minmax, indexes, DeepBullishBkgDXBrush, chartControl, chartScale, false, true);
                                else
                                    drawRegion(minmax, indexes, OppositeBkgDXBrush, chartControl, chartScale, false, true);
                            }
                            else if (StructureBiasState.GetValueAt(i) < 0)
                            {
                                if (Histogram.GetValueAt(i) > 0)
                                    drawRegion(minmax, indexes, OppositeBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i) < 0)
                                    drawRegion(minmax, indexes, DeepBearishBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i + 1) > 0)
                                    drawRegion(minmax, indexes, OppositeBkgDXBrush, chartControl, chartScale, false, true);
                                else
                                    drawRegion(minmax, indexes, DeepBearishBkgDXBrush, chartControl, chartScale, false, true);
                            }
                            else
                            {
                                if (Histogram.GetValueAt(i) > 0)
                                    drawRegion(minmax, indexes, BullishBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i) < 0)
                                    drawRegion(minmax, indexes, BearishBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i + 1) > 0)
                                    drawRegion(minmax, indexes, BullishBkgDXBrush, chartControl, chartScale, false, true);
                                else
                                    drawRegion(minmax, indexes, BearishBkgDXBrush, chartControl, chartScale, false, true);
                            }
                        }
                    }
                    #endregion

                }
                catch (Exception) { }//After testing, didn't find any problem. Let Try Catch to avoid crashes...
            }
            #endregion

            #region -- excursion levels --
            try
            {
                int idxMin = lastBarIndex;
                int idxMax = firstBarIndex;
                int x1;

                int idxHLineStart = idxMax;
                if (PlotStyleLevels == PlotStyle.HLine) idxMax = idxMin;

                for (int i = idxMin; i >= idxMax; i--)
                {
                    x1 = PlotStyleLevels == PlotStyle.HLine ? idxHLineStart : i - 1;
                    #region -- Excursion Levels --
                    if (DisplayLevel3)
                    {   
                        drawLine(PriceExcursionUL3.GetValueAt(i), PriceExcursionUL3.GetValueAt(i - 1), i, x1, Level3Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                        drawLine(PriceExcursionLL3.GetValueAt(i), PriceExcursionLL3.GetValueAt(i - 1), i, x1, Level3Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                    }
                    if (DisplayLevel2)
                    {
                        drawLine(PriceExcursionUL2.GetValueAt(i), PriceExcursionUL2.GetValueAt(i - 1), i, x1, Level2Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                        drawLine(PriceExcursionLL2.GetValueAt(i), PriceExcursionLL2.GetValueAt(i - 1), i, x1, Level2Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                    }
                    if (DisplayLevel1)
                    {
                        drawLine(PriceExcursionUL1.GetValueAt(i), PriceExcursionUL1.GetValueAt(i - 1), i, x1, Level1Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                        drawLine(PriceExcursionLL1.GetValueAt(i), PriceExcursionLL1.GetValueAt(i - 1), i, x1, Level1Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                    }
                    #endregion
                }
            }
            catch (Exception) { }//thrown if scrollback to chart first bar
            #endregion

			if(OverprintSentimentBox) base.OnRender(chartControl, chartScale);
            #region -- Draw the Sentiment Box --
            if (showBox && SentimentBoxLocation != ARC_VMDSystem_SentimentBoxLocations.Hide)
            {
                float maxStringWidth1 = getTextWidth(maxString1, dataFont1);
                float maxStringWidth2 = getTextWidth(maxString2, dataFont2);
                float maxStringWidth = Math.Max(maxStringWidth1, maxStringWidth2);

                float offset1 = ChartPanel.X + ChartPanel.W - 1.2f * maxStringWidth;
				if(SentimentBoxLocation == ARC_VMDSystem_SentimentBoxLocations.Left){
					offset1 = ChartPanel.X+10f;
				}
                float offset2 = offset1 + 0.03f * maxStringWidth;
                float offset3 = offset1 + 0.08f * maxStringWidth;
                float offset6 = offset1 + 1.17f * maxStringWidth;
                float pos11 = ChartPanel.Y + 0.01f * ChartPanel.H;
                float pos12 = ChartPanel.Y + 0.97f * ChartPanel.H;
                float midPoint = ChartPanel.Y + 0.49f * ChartPanel.H;
                float pos1, pos1f, pos2, pos2f, pos3, pos3f, pos4, pos4f, pos5, pos6, pos6f;

                if (ShowSentimentInBox && !ShowBiasInBox)
                {
                    pos1 = midPoint - 3.0f * (float)dataStringHeight;
                    pos2 = midPoint - 1.5f * (float)dataStringHeight;
                    pos3 = midPoint + 0.5f * (float)dataStringHeight;
                    pos4 = midPoint + 2.0f * (float)dataStringHeight;
                    pos1f = midPoint - 3.2f * (float)dataStringHeight;
                    pos2f = midPoint - 1.7f * (float)dataStringHeight;
                    pos3f = midPoint + 0.3f * (float)dataStringHeight;
                    pos4f = midPoint + 1.8f * (float)dataStringHeight;
                    pos5 = pos6 = pos6f = 0;
                }
                else if (ShowSentimentInBox && ShowBiasInBox)
                {

                    pos5 = midPoint - 4.8f * (float)dataStringHeight;
                    pos6f = midPoint - 3.5f * (float)dataStringHeight;
                    pos6 = midPoint - 3.3f * (float)dataStringHeight;
                    pos1 = midPoint - 1.3f * (float)dataStringHeight;
                    pos2f = midPoint - 0f * (float)dataStringHeight;
                    pos2 = midPoint + 0.2f * (float)dataStringHeight;
                    pos3 = midPoint + 2.2f * (float)dataStringHeight;
                    pos4f = midPoint + 3.5f * (float)dataStringHeight;
                    pos4 = midPoint + 3.7f * (float)dataStringHeight;
                    pos1f = midPoint - 3.2f * (float)dataStringHeight;
                    pos3f = midPoint + 0.3f * (float)dataStringHeight;
                }
                else
                {
                    pos1 = pos2 = pos2f = pos3 = pos4 = pos4f = 0;
                    pos5 = midPoint - 1.3f * (float)dataStringHeight;
                    pos6f = midPoint - 0f * (float)dataStringHeight;
                    pos6 = midPoint + 0.2f * (float)dataStringHeight;
                }
                
                //draw the box
				//JQ 11.26.2017
				// Bug 12782. The set right margin is causing the shifting of the SDV bar when the PP bar and the Divergence indicator
                // are all on the same chart. This could be a NT8 issue as it appears the BarMarginRight is only applied to the
				// primary bar (PP) rather than the secondary bar SDV). For now, I will disable the setrightmargin properties
				// until I have a chance to talk to NT about this issue.
				// --start--
                // if (SetRightSideMargin) ChartControl.Properties.BarMarginRight = Convert.ToInt32(1.25f * maxStringWidth);
				// --end--

                drawRectangle(offset2, pos11, 1.14f * maxStringWidth, 0.99f * ChartPanel.H - 3, DataTableDXBrush);
                drawLine((double)offset2, (double)offset6, (double)pos11, (double)pos11, TextBoxOutlineColor, DashStyleHelper.Solid, 1);
                drawLine((double)offset2, (double)offset6, (double)pos12, (double)pos12, TextBoxOutlineColor, DashStyleHelper.Solid, 1);
                drawLine((double)offset2, (double)offset2, (double)pos11, (double)pos12, TextBoxOutlineColor, DashStyleHelper.Solid, 1);
                drawLine((double)offset6, (double)offset6, (double)pos11, (double)pos12, TextBoxOutlineColor, DashStyleHelper.Solid, 1);

                filterValue1 = macdBBState.GetValueAt(lastBarIndex);//macdBBState.GetValueAt(CurrentBar - lastBarIndex);
                filterValue2 = histogramState.GetValueAt(lastBarIndex);//histogramState.GetValueAt(CurrentBar - lastBarIndex);
                filterValue3 = StructureBiasState.GetValueAt(lastBarIndex);

                if (ShowBiasInBox)
                {
                    #region -- BIAS State --
                    drawstring("STRUCTURE BIAS:", offset1 + 0.1f * maxStringWidth, pos5, dataFont1, TextColor, SharpDX.DirectWrite.TextAlignment.Leading);
                    if (filterValue3 > 0)
                    {
                        drawRectangle(offset3, pos6f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishDivergenceDXBrush);
                        drawstring(UpBiasString, offset3, pos6, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue3 < 0)
                    {
                        drawRectangle(offset3, pos6f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishDivergenceDXBrush);
                        drawstring(DwBiasString, offset3, pos6, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else
                    {
                        drawLine(offset3, offset3 + 1.04f * maxStringWidth, pos6f, pos6f, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3, offset3 + 1.04f * maxStringWidth, pos6f + 1.4f * dataStringHeight, pos6f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3, offset3, pos6f, pos6f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3 + 1.04f * maxStringWidth, offset3 + 1.04f * maxStringWidth, pos6f, pos6f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawstring(NeutralBiasString, offset3, pos6 + 0.1f * dataStringHeight, dataFont1, TextColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    #endregion
                }
                    if (ShowSentimentInBox)
                {
                    #region -- MACD BB --
                    drawstring("MACD BB:", offset1 + 0.1f * maxStringWidth, pos1, dataFont1, TextColor, SharpDX.DirectWrite.TextAlignment.Leading);
                    if (filterValue1 > 2.5)
                    {
                        drawRectangle(offset3, pos2f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishAccelerationDXBrush);
                        drawstring(BullAccString, offset3, pos2, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue1 > 2.0)
                    {
                        drawRectangle(offset3, pos2f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishDivergenceDXBrush);
                        drawstring(BullHDivCString, offset3, pos2, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue1 > 1.5)
                    {
                        drawRectangle(offset3, pos2f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishDivergenceDXBrush);
                        drawstring(BullDivCString, offset3, pos2, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue1 > 1.0)
                    {
                        drawRectangle(offset3, pos2f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishDivergenceDXBrush);
                        drawstring(BullHDivPString, offset3, pos2, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue1 > 0.5)
                    {
                        drawRectangle(offset3, pos2f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishDivergenceDXBrush);
                        drawstring(BullDivPString, offset3, pos2, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue1 < -2.5)
                    {
                        drawRectangle(offset3, pos2f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishAccelerationDXBrush);
                        drawstring(BearAccString, offset3, pos2, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue1 < -2.0)
                    {
                        drawRectangle(offset3, pos2f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishDivergenceDXBrush);
                        drawstring(BearHDivCString, offset3, pos2, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue1 < -1.5)
                    {
                        drawRectangle(offset3, pos2f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishDivergenceDXBrush);
                        drawstring(BearDivCString, offset3, pos2, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue1 < -1.0)
                    {
                        drawRectangle(offset3, pos2f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishDivergenceDXBrush);
                        drawstring(BearHDivPString, offset3, pos2, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue1 < -0.5)
                    {
                        drawRectangle(offset3, pos2f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishDivergenceDXBrush);
                        drawstring(BearDivPString, offset3, pos2, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else
                    {
                        drawLine(offset3, offset3 + 1.04f * maxStringWidth, pos2f, pos2f, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3, offset3 + 1.04f * maxStringWidth, pos2f + 1.4f * dataStringHeight, pos2f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3, offset3, pos2f, pos2f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3 + 1.04f * maxStringWidth, offset3 + 1.04f * maxStringWidth, pos2f, pos2f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawstring(NeutralString, offset3, pos2 + 0.1f * dataStringHeight, dataFont1, TextColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    #endregion

                    #region -- HISTOGRAM --
                    drawstring("HISTOGRAM:", offset1 + 0.1f * maxStringWidth, pos3, dataFont1, TextColor, SharpDX.DirectWrite.TextAlignment.Leading);
                    if (filterValue2 > 2.5)
                    {
                        drawRectangle(offset3, pos4f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishAccelerationDXBrush);
                        drawstring(BullAccString, offset3, pos4, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue2 > 2.0)
                    {
                        drawRectangle(offset3, pos4f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishDivergenceDXBrush);
                        drawstring(BullHDivCString, offset3, pos4, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue2 > 1.5)
                    {
                        drawRectangle(offset3, pos4f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishDivergenceDXBrush);
                        drawstring(BullDivCString, offset3, pos4, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue2 > 1.0)
                    {
                        drawRectangle(offset3, pos4f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishDivergenceDXBrush);
                        drawstring(BullHDivPString, offset3, pos4, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue2 > 0.5)
                    {
                        drawRectangle(offset3, pos4f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishDivergenceDXBrush);
                        drawstring(BullDivPString, offset3, pos4, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue2 < -2.5)
                    {
                        drawRectangle(offset3, pos4f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishAccelerationDXBrush);
                        drawstring(BearAccString, offset3, pos4, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue2 < -2.0)
                    {
                        drawRectangle(offset3, pos4f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishDivergenceDXBrush);
                        drawstring(BearHDivCString, offset3, pos4, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue2 < -1.5)
                    {
                        drawRectangle(offset3, pos4f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishDivergenceDXBrush);
                        drawstring(BearDivCString, offset3, pos4, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue2 < -1.0)
                    {
                        drawRectangle(offset3, pos4f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishDivergenceDXBrush);
                        drawstring(BearHDivPString, offset3, pos4, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue2 < -0.5)
                    {
                        drawRectangle(offset3, pos4f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishDivergenceDXBrush);
                        drawstring(BearDivPString, offset3, pos4, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else
                    {
                        drawLine(offset3, offset3 + 1.04f * maxStringWidth, pos4f, pos4f, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3, offset3 + 1.04f * maxStringWidth, pos4f + 1.4f * dataStringHeight, pos4f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3, offset3, pos4f, pos4f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3 + 1.04f * maxStringWidth, offset3 + 1.04f * maxStringWidth, pos4f, pos4f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawstring(NeutralString, offset3, pos4 + 0.1f * dataStringHeight, dataFont1, TextColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    #endregion
                }
            }
            #endregion
			if(!OverprintSentimentBox) base.OnRender(chartControl, chartScale);

            RenderTarget.AntialiasMode = oldAntialiasMode;
	        #endregion
        }

        #region -- drawing functions { AzurITec } --
        //Draw Rectangle Region. x and y as pixel coordinate, w and h in pixel too.
        private void drawRectangle(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush, int opacity = 100)
        {
            drawRegion(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush);
        }

        //Draw Region between 4 points. Coordinates are in pixel.
//        private void drawRegion(Point[] points, Brush color, int opacity)
//        {
//            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
//            linebrush.Opacity = opacity / 100f;

//            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

//            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
//            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
//            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
//            sink1.AddLines(vectors);
//            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
//            sink1.Close();

//            RenderTarget.FillGeometry(geo1, linebrush);
//            geo1.Dispose();
//            sink1.Dispose();
//            linebrush.Dispose();
//        }

        private void drawRegion(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
        {
            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();
        }

        //Draw Region between 4 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        //##MODIF## AzurITec - 18.05.2016
//        private void drawRegion(double[] yValues, int[] xIndex, Brush color, int opacity, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false, bool atMiddle = false)
//        {
//#if USE_WPF_COORDS
//            drawRegion(new Point[]{
//                    new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[0])),
//                    new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[1])),
//                    new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[2])),
//                    new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[3]))
//                },
//                color,
//                opacity
//                );
//#else
//            drawRegion(new Point[]{
//                    new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[0])),
//                    new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[1])),
//                    new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[2])),
//                    new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[3]))
//                },
//                color,
//                opacity
//                );
//#endif
//        }
        private void drawRegion(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false, bool atMiddle = false)
        {
#if USE_WPF_COORDS
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[3]))
                },
                dxbrush
                );
#else
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[3]))
                },
                dxbrush
                );
#endif
        }

        //Draw a line between 2 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawLine(double val1, double val2, int idxslot1, int idxslot2, Brush couleur, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false)
        {
            SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

#if USE_WPF_COORDS
            Point p0 = new Point(GetX0(idxslot1, chartControl), drawOnPricePanel ? 0 : ChartPanel.Y + chartScale.GetYByValueWpf(val1));
            Point p1 = new Point(GetX0(idxslot2, chartControl), drawOnPricePanel ? 0 : ChartPanel.Y + chartScale.GetYByValueWpf(val2));
#else
            Point p0 = new Point(GetX0(idxslot1, chartControl), drawOnPricePanel ? 0 : chartScale.GetYByValue(val1));
            Point p1 = new Point(GetX0(idxslot2, chartControl), drawOnPricePanel ? 0 : chartScale.GetYByValue(val2));
#endif
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }
        //Draw a line between 2 points in pixel coordinates.        
        private void drawLine(double x1, double x2, double y1, double y2, Brush couleur, DashStyleHelper dashstyle, int width)
        {
            SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            Point p0 = new Point(x1, y1);
            Point p1 = new Point(x2, y2);
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }

        //Draw a text at {x;y} coordinates in pixel.
        private void drawstring(string text, double x, double y, SimpleFont font, Brush textBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                )
            { TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

			var textBrushDX = textBrush.ToDxBrush(RenderTarget);
            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
			textBrushDX.Dispose(); textBrushDX=null;

            textLayout.Dispose();
            textFormat.Dispose();
        }

        private float getTextWidth(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }

        //retrieve the x coordinate in pixel of a a relative bar index.
        //##MODIF## AzurITec - 18.05.2016
        private int GetX0(int bars, ChartControl chartControl, bool atMiddle = false) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars) - (atMiddle ? (int)(chartControl.Properties.BarDistance / 2) : 0); }//NEW VERSION NT8        
        #endregion

        #region -- PLOTS --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BBMACD { get { return Values[BBMACDIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BBMACDFrame { get { return Values[BBMACDFrameIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BBMACDLine { get { return Values[BBMACDLineIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Average { get { return Values[AverageIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Upper { get { return Values[UpperIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Lower { get { return Values[LowerIDX]; } }

        /// <summary>
        /// RJ5Group LLC
        /// </summary>
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Histogram { get { return Values[HistogramIDX]; } }

        /// <summary>
        /// //rj RJ5GROUP code Algorithm
        /// </summary>
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionUL3 { get { return Values[PriceExcursionUL3IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionUL2 { get { return Values[PriceExcursionUL2IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionUL1 { get { return Values[PriceExcursionUL1IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionLL1 { get { return Values[PriceExcursionLL1IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionLL2 { get { return Values[PriceExcursionLL2IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionLL3 { get { return Values[PriceExcursionLL3IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionMAX { get { return Values[PriceExcursionMAXIDX]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionMIN { get { return Values[PriceExcursionMINIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> SystemSignal { get { return Values[SystemSignalIDX]; } }

		#endregion

        #region -- Exposed DataSeries --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BearishMACDDivProjection { get { return bearishMACDDivProjection; } }//#BLOOHOUND - added 17.02.03 - AzurITec
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BullishMACDDivProjection { get { return bullishMACDDivProjection; } }//#BLOOHOUND - added 17.02.03 - AzurITec
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BearishHistogramDivProjection { get { return bearishHistogramDivProjection; } }//#BLOOHOUND - added 17.02.03 - AzurITec
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BullishHistogramDivProjection { get { return bullishHistogramDivProjection; } }//#BLOOHOUND - added 17.02.03 - AzurITec

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BearishMACDHiddenDivProjection { get { return bearishMACDHiddenDivProjection; } }//#BLOOHOUND - added 17.02.03 - AzurITec
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BullishMACDHiddenDivProjection { get { return bullishMACDHiddenDivProjection; } }//#BLOOHOUND - added 17.02.03 - AzurITec
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BearishHistogramHiddenDivProjection { get { return bearishHistogramHiddenDivProjection; } }//#BLOOHOUND - added 17.02.03 - AzurITec
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BullishHistogramHiddenDivProjection { get { return bullishHistogramHiddenDivProjection; } }//#BLOOHOUND - added 17.02.03 - AzurITec
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> StructureBiasState { get { return structureBiasState; } }//#STRBIAS
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> SwingHighsState { get { return swingHighsState; } }//#SWINGS
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> SwingLowsState { get { return swingLowsState; } }//#SWINGS

        #region -- Trend Filters --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BBDotTrend { get { return bbDotTrend; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> MomoSignum { get { return momoSignum; } }
        #endregion

        //rj RJ5GROUP code Algorithm
        #region -- Setup Signals --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BearishPDivMACD { get { return bearishPDivMACD; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BullishPDivMACD { get { return bullishPDivMACD; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BearishPDivHistogram { get { return bearishPDivHistogram; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BullishPDivHistogram { get { return bullishPDivHistogram; } }
        #endregion

        #region -- Divergence Signals --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BearishCDivMACD { get { return bearishCDivMACD; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BullishCDivMACD { get { return bullishCDivMACD; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BearishCDivHistogram { get { return bearishCDivHistogram; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BullishCDivHistogram { get { return bullishCDivHistogram; } }
        #endregion

        #region -- Complex States --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> MACDBBState { get { return macdBBState; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> HistogramState { get { return histogramState; } }
        #endregion

        #endregion
//===================================================================================================================
		private string AddSoundFolder(string wav){
			if(wav=="SOUND OFF") return "";
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds",wav);
		}
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }
//===================================================================================================================

        #region ------------------ Properties ----------------------------
		#region Load pulldown parameters
		internal class LoadRayTemplates : StringConverter
		{
			#region LoadRayTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Ray"};
				RayTemplates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(RayTemplates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
		internal class LoadLineTemplates : StringConverter
		{
			#region LoadLineTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Line"};
				RayTemplates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(RayTemplates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
		#endregion

		[NinjaScriptProperty]
		[Display(Name = "Optimize for Speed", GroupName = "Parameters", Description = "Improve run-time performance (reduces the number of historical chart markers", Order = 0)]
		public ARC_VMDSystem_OptimizeSpeedSettings OptimizeSpeed { get; set; }

		[Display(Order = 10, Name = "Signal Type", GroupName = "System Signals", Description = "")]
		public ARC_VMDSystem_SystemTypes pSignalType { get; set; }

		[Display(Order = 20, Name = "SL Ticks", GroupName = "System Signals", Description = "")]
		public int pSLTicks { get; set;}

		[Display(Order = 30, Name = "T1 Ticks", GroupName = "System Signals", Description = "")]
		public int pT1Ticks { get; set;}

		[Display(Order = 40, Name = "T2 Ticks", GroupName = "System Signals", Description = "")]
		public int pT2Ticks { get; set;}

		[Display(Order = 50, Name = "Show Trade Plan?", GroupName = "System Signals", Description = "")]
		public bool pTradePlanVisible { get; set;}

		[Display(Order = 60, Name = "Historical TP markers", GroupName = "System Signals", Description = "")]
		public ARC_VMDSystem_SignalVisualTypes pHistorical_TP_Markers { get; set;}

		[Display(Order = 70, Name = "Current TP markers?", GroupName = "System Signals", Description = "")]
		public ARC_VMDSystem_SignalVisualTypes pCurrent_TP_Markers { get; set;}

		[Display(Order = 80, Name = "Text font", GroupName = "System Signals", Description = "")]
		public SimpleFont pTextFont { get; set;}

		[Display(Order = 85, Name = "Marker Offset", GroupName = "System Signals", Description = "Number of bars to the left of the entry bar")]
		public int pMarkerOffset { get; set;}

		[Display(Order = 90, Name = "Show SL?", GroupName = "System Signals", Description = "")]
		public bool pSLVisible { get; set;}

		[Display(Order = 100, Name = "Show T1?", GroupName = "System Signals", Description = "")]
		public bool pT1Visible { get; set;}

		[Display(Order = 110, Name = "Show T2?", GroupName = "System Signals", Description = "")]
		public bool pT2Visible { get; set;}

		[Display(Order = 115, Name = "Structure Disqualifier", GroupName = "System Signals", Description="When is a strucutre level disuqalified?  On close, or intrabar?")]
		public ARC_VMDSystem_StructureDisqualifierType pStructureDisq {get;set;}

		[XmlIgnore]
		[Display(Order = 120, Name = "Buy Arrow Color", GroupName = "System Signals", Description = "Color of the buy signal arrow")]
		public Brush pBuyBrush { get; set; }
			    [Browsable(false)]
			    public string pBuyBrushSerialize {get { return Serialize.BrushToString(pBuyBrush);} set {pBuyBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 130, Name = "Sell Arrow Color", GroupName = "System Signals", Description = "Color of the sell signal arrow")]
		public Brush pSellBrush { get; set; }
			    [Browsable(false)]
			    public string pSellBrushSerialize {get { return Serialize.BrushToString(pSellBrush);} set {pSellBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 140, Name = "SL Square Color", GroupName = "System Signals", Description = "Color of the SL marker")]
		public Brush pSLBrush { get; set; }
			    [Browsable(false)]
			    public string pSLBrushSerialize {get { return Serialize.BrushToString(pSLBrush);} set {pSLBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 150, Name = "T1 Triangle Color", GroupName = "System Signals", Description = "Color of the T1 marker")]
		public Brush pT1Brush { get; set; }
			    [Browsable(false)]
			    public string pT1BrushSerialize {get { return Serialize.BrushToString(pT1Brush);} set {pT1Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 160, Name = "T2 Triangle Color", GroupName = "System Signals", Description = "Color of the T2 marker")]
		public Brush pT2Brush { get; set; }
			    [Browsable(false)]
			    public string pT2BrushSerialize {get { return Serialize.BrushToString(pT2Brush);} set {pT2Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 170, Name = "Flag Text", GroupName = "System Signals", Description = "Color of the text of the TradePlan Flags")]
		public Brush pFlagTextBrush { get; set; }
			    [Browsable(false)]
			    public string pFlagTextBrushSerialize {get { return Serialize.BrushToString(pFlagTextBrush);} set {pFlagTextBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 180, Name = "Flag Background", GroupName = "System Signals", Description = "Color of the background of the TradePlan Flags")]
		public Brush pFlagBkgBrush { get; set; }
			    [Browsable(false)]
			    public string pFlagBkgBrushSerialize {get { return Serialize.BrushToString(pFlagBkgBrush);} set {pFlagBkgBrush = Serialize.StringToBrush(value); }}

		[Display(Order = 185, Name = "Show Racing Stripes?", GroupName = "System Signals", Description = "")]
		public bool pShowRacingStripes {get;set;}

		[XmlIgnore]
		[Display(Order = 190, Name = "Buy Stripe", GroupName = "System Signals", Description = "Color of the background on a BUY signal")]
		public Brush pBuyStripeBrush { get; set; }
			    [Browsable(false)]
			    public string pBuyStripeBrushSerialize {get { return Serialize.BrushToString(pBuyStripeBrush);} set {pBuyStripeBrush = Serialize.StringToBrush(value); }}

		[Range(0,100)]
		[Display(Order = 200, Name = "Buy Stripe Op.", GroupName = "System Signals", Description = "Opacity of BUY background stripe")]
		public int pBuyStripeOpacity { get; set;}

		[XmlIgnore]
		[Display(Order = 210, Name = "Sell Stripe", GroupName = "System Signals", Description = "Color of the background on a SELL signal")]
		public Brush pSellStripeBrush { get; set; }
			    [Browsable(false)]
			    public string pSellStripeBrushSerialize {get { return Serialize.BrushToString(pSellStripeBrush);} set {pSellStripeBrush = Serialize.StringToBrush(value); }}

		[Range(0,100)]
		[Display(Order = 220, Name = "Sell Stripe Op.", GroupName = "System Signals", Description = "Opacity of SELL background stripe")]
		public int pSellStripeOpacity { get; set;}

//		[Display(Order = 170, Name = "Entry RayTemplate", GroupName = "System Signals", ResourceType = typeof(Custom.Resource))]
//		[RefreshProperties(RefreshProperties.All)]
//		[TypeConverter(typeof(LoadRayTemplates))]
//		public string pRayTemplateName_EP { get; set; }

//		[Display(Order = 180, Name = "SL RayTemplate", GroupName = "System Signals", ResourceType = typeof(Custom.Resource))]
//		[RefreshProperties(RefreshProperties.All)]
//		[TypeConverter(typeof(LoadRayTemplates))]
//		public string pRayTemplateName_SL { get; set; }

//		[Display(Order = 190, Name = "T1 RayTemplate", GroupName = "System Signals", ResourceType = typeof(Custom.Resource))]
//		[RefreshProperties(RefreshProperties.All)]
//		[TypeConverter(typeof(LoadRayTemplates))]
//		public string pRayTemplateName_T1 { get; set; }

//		[Display(Order = 200, Name = "T2 RayTemplate", GroupName = "System Signals", ResourceType = typeof(Custom.Resource))]
//		[RefreshProperties(RefreshProperties.All)]
//		[TypeConverter(typeof(LoadRayTemplates))]
//		public string pRayTemplateName_T2 { get; set; }

		[Display(Order = 230, Name = "TradePlan LineLength", GroupName = "System Signals", Description = "Length (in bars) of the trade plan lines (EP, SL, T1 and T2)")]
		public int pTradePlan_LineLength { get; set;}

		[Display(Order = 240, Name = "Entry LineTemplate", GroupName = "System Signals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadLineTemplates))]
		public string pLineTemplateName_EP { get; set; }

		[Display(Order = 250, Name = "SL LineTemplate", GroupName = "System Signals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadLineTemplates))]
		public string pLineTemplateName_SL { get; set; }

		[Display(Order = 260, Name = "T1 LineTemplate", GroupName = "System Signals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadLineTemplates))]
		public string pLineTemplateName_T1 { get; set; }

		[Display(Order = 270, Name = "T2 LineTemplate", GroupName = "System Signals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadLineTemplates))]
		public string pLineTemplateName_T2 { get; set; }

		[Description("WAV file to play for Termite BUY signals, 'SOUND OFF' to turn off the alert")]
        [Display(Order = 280, Name = "Termite Buy Sound", GroupName = "System Signals")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pTermiteBuySoundWAV		{ get; set; }

		[Description("WAV file to play for Termite SELL signals, 'SOUND OFF' to turn off the alert")]
        [Display(Order = 290, Name = "Termite Sell Sound", GroupName = "System Signals")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pTermiteSellSoundWAV		{ get; set; }

		[Description("WAV file to play for Regular Div BUY signals, 'SOUND OFF' to turn off the alert")]
        [Display(Order = 300, Name = "RegDiv Buy Sound", GroupName = "System Signals")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pRDIV_BuySoundWAV		{ get; set; }

		[Description("WAV file to play for Regular Div SELL signals, 'SOUND OFF' to turn off the alert")]
        [Display(Order = 310, Name = "RegDiv Sell Sound", GroupName = "System Signals")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pRDIV_SellSoundWAV		{ get; set; }

		[Description("WAV file to play for Hidden Div BUY signals, 'SOUND OFF' to turn off the alert")]
        [Display(Order = 310, Name = "HidDiv Buy Sound", GroupName = "System Signals")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pHDIV_BuySoundWAV		{ get; set; }

		[Description("WAV file to play for Hidden Div SELL signals, 'SOUND OFF' to turn off the alert")]
        [Display(Order = 320, Name = "HidDiv Sell Sound", GroupName = "System Signals")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pHDIV_SellSoundWAV		{ get; set; }

		#region GroupName = "MACDBB Parameters"
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Period Bollinger Band", GroupName = "MACDBB Parameters", Description = "Band Period for Bollinger Band", Order = 0)]
        public int BandPeriod { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Lookback fast EMA", GroupName = "MACDBB Parameters", Description = "Period for fast EMA", Order = 1)]
        public int Fast { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Lookback slow EMA", GroupName = "MACDBB Parameters", Description = "Period for slow EMA", Order = 2)]
        public int Slow { get; set; }

        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Std. dev. multiplier", GroupName = "MACDBB Parameters", Description = "Number of standard deviations", Order = 3)]
        public double StdDevNumber { get; set; }
        #endregion

        #region GroupName = "SwingTrend Parameters"
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 0)]
        public int SwingStrength { get; set; }

        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Deviation multiplier", GroupName = "SwingTrend Parameters", Description = "Multiplier used to calculate minimum deviation as an ATR multiple", Order = 1)]
        public double MultiplierMD { get; set; }

        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Sensitivity double tops/bottoms", GroupName = "SwingTrend Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 2)]
        public double MultiplierDTB { get; set; }
        #endregion

        #region GroupName = "Divergence Options"
        [NinjaScriptProperty]
        [Display(Name = "Select data input for swings", GroupName = "Divergence Options", Description = "Select data input for swing highs and lows", Order = 0)]
        public ARC_VMDSystem_InputType ThisInputType { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Adjust divergence", GroupName = "Divergence Options", Description = "Connect divergence line to oscillator peaks and troughs when possible", Order = 1)]
        public bool UseOscHighLow { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Include double tops & bottoms", GroupName = "Divergence Options", Description = "When set to true divergences may be calculated from double tops and bottoms on the price chart", Order = 2)]
        public bool IncludeDoubleTopsAndBottoms { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Recent divergences only", GroupName = "Divergence Options", Description = "Only use last swing high and low to detect divergences", Order = 3)]
        public bool UseLastSwingOnly { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Reset filter", GroupName = "Divergence Options", Description = "When set to true, a zeroline cross will reset any divergence", Order = 4)]
        public bool ResetFilter { get; set; }
        #endregion

        #region GroupName = "Divergence Parameters"
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Div. max bars back", GroupName = "Divergence Parameters", Description = "Maximum distance in bars allowed for the divergence", Order = 0)]
        public int DivMaxBars { get; set; }

        [NinjaScriptProperty]
        [Range(3, int.MaxValue)]
        [Display(Name = "Div. min bars back", GroupName = "Divergence Parameters", Description = "Minimum distance in bars required for the divergence", Order = 1)]
        public int DivMinBars { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Max. trigger bars", GroupName = "Divergence Parameters", Description = "Maximum number of bars between divergence and trigger signal", Order = 2)]
        public int TriggerBars { get; set; }
        #endregion

        #region GroupName = "Display Options Oscillator Panel"
        [Display(Name = "Background Flooding", GroupName = "Display Options Oscillator Panel", Description = "Choose the type of background flooding to show", Order = 1)]
        public ARC_VMDSystem_Flooding BackgroundFlooding { get; set; }

        [Display(Name = "Display Histogram Sentiment in box", GroupName = "Display Options Oscillator Panel", Description = "Option to display or remove the Histogram Sentiment in Box", Order = 2)]
        public bool ShowSentimentInBox { get; set; }

        [Display(Name = "Display Structure Bias in box", GroupName = "Display Options Oscillator Panel", Description = "Option to display or remove the Structure Bias in Box", Order = 3)]
        public bool ShowBiasInBox { get; set; }
        #endregion

        #region GroupName = "Display Options Swing Trend"
        [Range(1, double.MaxValue)]
        [Display(Name = "Dotsize swing dots", GroupName = "Display Options Swing Trend", Description = "Dotsize for swing dots representing swing highs and swing lows", Order = 0)]
        public int SwingDotSize { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Fontsize swing labels", GroupName = "Display Options Swing Trend", Description = "Dotsize for swing labels for swing highs and swing lows", Order = 1)]
        public int LabelFontSize { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Width swing legs", GroupName = "Display Options Swing Trend", Description = "Select thickness of swing legs connecting swing highs and lows", Order = 2)]
        public int SwingLegWidth { get; set; }

        [Display(Name = "Show swing dots", GroupName = "Display Options Swing Trend", Description = "Show dots for swing highs and lows", Order = 3)]
        public bool ShowZigzagDots { get; set; }

        [Display(Name = "Show swing labels", GroupName = "Display Options Swing Trend", Description = "Show labels for swing highs and lows", Order = 4)]
        public bool ShowZigzagLabels { get; set; }

        [Display(Name = "Show swing legs", GroupName = "Display Options Swing Trend", Description = "Show swing legs connecting swing highs and lows", Order = 5)]
        public bool ShowZigzagLegs { get; set; }

        [Display(Name = "Dash style swing legs", GroupName = "Display Options Swing Trend", Description = "Dash style for swing legs.", Order = 6)]
        public DashStyleHelper SwingLegStyle { get; set; }
        #endregion

        #region GroupName = "Display Options Divergences"
        [Display(Name = "Show divergences on price panel", GroupName = "Display Options Divergences", Description = "Show divergences with trendlines on the price panel", Order = 0)]
        public bool ShowDivOnPricePanel { get; set; }

        [Display(Name = "Show divergences on second panel", GroupName = "Display Options Divergences", Description = "Show divergences with trendlines on the oscillator panel", Order = 1)]
        public bool ShowDivOnOscillatorPanel { get; set; }

        [Display(Name = "Show MACDBB divergences", GroupName = "Display Options Divergences", Description = "Show divergences between price and oscillator", Order = 2)]
        public bool ShowOscillatorDivergences { get; set; }

        [Display(Name = "Show MACDBB Hidden divergences", GroupName = "Display Options Divergences", Description = "Show Hidden divergences between price and oscillator", Order = 3)]
        public bool ShowOscillatorHiddenDivergences { get; set; }

        [Display(Name = "Show histogram divergences", GroupName = "Display Options Divergences", Description = "Show divergences between price and histogram", Order = 4)]
        public bool ShowHistogramDivergences { get; set; }

        [Display(Name = "Show histogram Hidden divergences", GroupName = "Display Options Divergences", Description = "Show Hidden divergences between price and histogram", Order = 5)]
        public bool ShowHistogramHiddenDivergences { get; set; }

        [Display(Name = "Show divergence setup dots", GroupName = "Display Options Divergences", Description = "Show set up dots for potential divergences", Order = 6)]
        public bool ShowSetupDots { get; set; }
        #endregion

		//rj RJ5GROUP code Algorithm
		#region GroupName = "Display Options Price Excursions"
		[Display(GroupName = "Display Options Price Excursions", Description = "Display Level 1", Order = 0)]
		public bool DisplayLevel1 { get; set; }

		[Display(GroupName = "Display Options Price Excursions", Description = "Display Level 2", Order = 1)]
		public bool DisplayLevel2 { get; set; }

		[Display(GroupName = "Display Options Price Excursions", Description = "Display Level 3", Order = 2)]
		public bool DisplayLevel3 { get; set; }
		#endregion

		#region GroupName = "Plot Parameters"
		[Range(1, int.MaxValue)]
		[Display(Name = "Dot size MACD", GroupName = "Plot Parameters", Description = "Dotsize for MACD dots", Order = 0)]
		public int DotSize { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width connectors", GroupName = "Plot Parameters", Description = "Width for MACD connectors.", Order = 1)]
		public int Plot2Width { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width average", GroupName = "Plot Parameters", Description = "Width for Average of Bollinger Bands.", Order = 2)]
		public int Plot3Width { get; set; }

		[Display(Name = "Dash style average", GroupName = "Plot Parameters", Description = "DashStyleHelper for Average of Bollinger Bands.", Order = 3)]
		public DashStyleHelper Dash3Style { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width Bollinger Bands", GroupName = "Plot Parameters", Description = "Width for Bollinger Bands.", Order = 4)]
		public int Plot4Width { get; set; }

		[Display(Name = "Dash style Bollinger Bands", GroupName = "Plot Parameters", Description = "DashStyleHelper for Bollinger Bands.", Order = 5)]
		public DashStyleHelper Dash4Style { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width zeroline", GroupName = "Plot Parameters", Description = "Width for Zero Line.", Order = 6)]
		public int ZerolineWidth { get; set; }

		[Display(Name = "Dash style zeroline", GroupName = "Plot Parameters", Description = "DashStyleHelper for Zero Line.", Order = 7)]
		public DashStyleHelper ZerolineStyle { get; set; }

		[Range(0, 100)]
		[Display(Name = "Opacity channel shading", GroupName = "Plot Parameters", Description = "Opacity for shading the area between the Bollinger Bands", Order = 8)]
		public int ChannelOpacity { get; set; }

		[Range(0, 100)]
		[Display(Name = "Opacity background flooding", GroupName = "Plot Parameters", Description = "Opacity used for flooding the chart background", Order = 9)]
		public int BackgroundOpacity { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width histogram bars", GroupName = "Plot Parameters", Description = "Width for the Histogram Momo.", Order = 10)]
		public int MomoWidth { get; set; }
		#endregion

		#region GroupName = "Plot Colors"
		[XmlIgnore]
		[Display(Name = "Rising dots above channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 0)]
		public Brush DotsUpRisingColor { get; set; }
		[Browsable(false)]
		public string DotsUpRisingColorSerialize
		{
		    get { return Serialize.BrushToString(DotsUpRisingColor); }
		    set { DotsUpRisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Rising dots inside/below channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 1)]
		public Brush DotsDownRisingColor { get; set; }
		[Browsable(false)]
		public string DotsDownRisingColorSerialize
		{
		    get { return Serialize.BrushToString(DotsDownRisingColor); }
		    set { DotsDownRisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling dots below channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 2)]
		public Brush DotsDownFallingColor { get; set; }
		[Browsable(false)]
		public string DotsDownFallingColorSerialize
		{
		    get { return Serialize.BrushToString(DotsDownFallingColor); }
		    set { DotsDownFallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling dots inside/above channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 3)]
		public Brush DotsUpFallingColor { get; set; }
		[Browsable(false)]
		public string DotsUpFallingColorSerialize
		{
		    get { return Serialize.BrushToString(DotsUpFallingColor); }
		    set { DotsUpFallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Dots rim", GroupName = "Plot Colors", Description = "Select Color", Order = 4)]
		public Brush DotsRimColor { get; set; }
		[Browsable(false)]
		public string DotsRimColorSerialize
		{
		    get { return Serialize.BrushToString(DotsRimColor); }
		    set { DotsRimColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger average", GroupName = "Plot Colors", Description = "Select Color", Order = 5)]
		public Brush BBAverageColor { get; set; }
		[Browsable(false)]
		public string BBAverageColorSerialize
		{
		    get { return Serialize.BrushToString(BBAverageColor); }
		    set { BBAverageColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger upper band", GroupName = "Plot Colors", Description = "Select Color", Order = 6)]
		public Brush BBUpperColor { get; set; }
		[Browsable(false)]
		public string BBUpperColorSerialize
		{
		    get { return Serialize.BrushToString(BBUpperColor); }
		    set { BBUpperColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger lower band", GroupName = "Plot Colors", Description = "Select Color", Order = 7)]
		public Brush BBLowerColor { get; set; }
		[Browsable(false)]
		public string BBLowerColorSerialize
		{
		    get { return Serialize.BrushToString(BBLowerColor); }
		    set { BBLowerColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Hi Color", GroupName = "Plot Colors", Description = "Select Color", Order = 8)]
		public Brush HistUpColor { get; set; }
		[Browsable(false)]
		public string HistUpColorSerialize
		{
		    get { return Serialize.BrushToString(HistUpColor); }
		    set { HistUpColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Down Color", GroupName = "Plot Colors", Description = "Select Color", Order = 9)]
		public Brush HistDownColor { get; set; }
		[Browsable(false)]
		public string HistDownColorSerialize
		{
		    get { return Serialize.BrushToString(HistDownColor); }
		    set { HistDownColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Zeroline", GroupName = "Plot Colors", Description = "Select Color", Order = 10)]
		public Brush ZerolineColor { get; set; }
		[Browsable(false)]
		public string ZerolineColorSerialize
		{
		    get { return Serialize.BrushToString(ZerolineColor); }
		    set { ZerolineColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Connector", GroupName = "Plot Colors", Description = "Select Color", Order = 11)]
		public Brush ConnectorColor { get; set; }
		[Browsable(false)]
		public string ConnectorColorSerialize
		{
		    get { return Serialize.BrushToString(ConnectorColor); }
		    set { ConnectorColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Channel shading", GroupName = "Plot Colors", Description = "Select Color", Order = 12)]
		public Brush ChannelColor { get; set; }
		[Browsable(false)]
		public string ChannelColorSerialize
		{
		    get { return Serialize.BrushToString(ChannelColor); }
		    set { ChannelColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Deep Bearish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 17)]
		public Brush DeepBearishBackgroundColor { get; set; }
		[Browsable(false)]
		public string DeepBearishBackgroundColorSerialize
		{
		    get { return Serialize.BrushToString(DeepBearishBackgroundColor); }
		    set { DeepBearishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bearish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 16)]
		public Brush BearishBackgroundColor { get; set; }
		[Browsable(false)]
		public string BearishBackgroundColorSerialize
		{
		    get { return Serialize.BrushToString(BearishBackgroundColor); }
		    set { BearishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Opposite background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 15)]
		public Brush OppositeBackgroundColor { get; set; }
		[Browsable(false)]
		public string OppositeBackgroundColorSerialize
		{
		    get { return Serialize.BrushToString(OppositeBackgroundColor); }
		    set { OppositeBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bullish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 14)]
		public Brush BullishBackgroundColor { get; set; }
		[Browsable(false)]
		public string BullishBackgroundColorSerialize
		{
		    get { return Serialize.BrushToString(BullishBackgroundColor); }
		    set { BullishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Deep Bullish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 13)]
		public Brush DeepBullishBackgroundColor { get; set; }
		[Browsable(false)]
		public string DeepBullishBackgroundColorSerialize
		{
		    get { return Serialize.BrushToString(DeepBullishBackgroundColor); }
		    set { DeepBullishBackgroundColor = Serialize.StringToBrush(value); }
		}
		#endregion

		//rj RJ5GROUP code Algorithm
		#region Category("Price Excursion - Plot Colors")
		[XmlIgnore]
		[Display(Name = "Color level 1 ", GroupName = "Price Excursion - Plot Colors", Description = "Select Color for Level 1 lines", Order = 0)]
		public Brush Level1Color { get; set; }
		[Browsable(false)]
		public string Level1ColorSerialize
		{
		    get { return Serialize.BrushToString(Level1Color); }
		    set { Level1Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Color level 2 ", GroupName = "Price Excursion - Plot Colors", Description = "Select Color for Level 2 lines", Order = 1)]
		public Brush Level2Color { get; set; }
		[Browsable(false)]
		public string Level2ColorSerialize
		{
		    get { return Serialize.BrushToString(Level2Color); }
		    set { Level2Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Color level 3 ", GroupName = "Price Excursion - Plot Colors", Description = "Select Color for Level 3 lines", Order = 2)]
		public Brush Level3Color { get; set; }
		[Browsable(false)]
		public string Level3ColorSerialize
		{
		    get { return Serialize.BrushToString(Level3Color); }
		    set { Level3Color = Serialize.StringToBrush(value); }
		}
		#endregion

		//rj RJ5GROUP code Algorithm
		#region Category("Price Excursion - Plot Colors")
		[Display(Name = "Plot style for Level Lines", GroupName = "Price Excursion - Plot Parameters", Description = "PlotStyle for Level Lines", Order = 0)]
		public PlotStyle PlotStyleLevels { get; set; }

		[Display(Name = "Dash style for Level Lines", GroupName = "Price Excursion - Plot Parameters", Description = "DashStyleHelper for level lines", Order = 1)]
		public DashStyleHelper DashStyleHelperLevels { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width for level lines", GroupName = "Price Excursion - Plot Parameters", Description = "Width for level lines", Order = 2)]
		public int PlotWidthLevels { get; set; }
		#endregion

        #region Category("MACD Divergences - Plot Parameters")
        [Range(1, int.MaxValue)]
        [Display(Name = "Width divergence lines", GroupName = "MACD Divergences - Plot Parameters", Description = "Select thickness for MACD divergence lines on both price panel and oscillator panel", Order = 0)]
        public int DivWidth1 { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Divergences offset", GroupName = "MACD Divergences - Plot Parameters", Description = "ATR percentage which is used to set the distance between divergence lines and price bars", Order = 1)]
        public double OffsetMultiplier3 { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Drawing objects offset", GroupName = "MACD Divergences - Plot Parameters", Description = "ATR percentage which is used to set the distance between setups/triggers drawing objects and price bars", Order = 2)]
        public double OffsetMultiplier1 { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Triggers object size", GroupName = "MACD Divergences - Plot Parameters", Description = "Select the size for the triggers drawing object", Order = 3)]
        public int TriangleFontSize1 { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Setups dot size", GroupName = "MACD Divergences - Plot Parameters", Description = "Select the size for the setups drawing object", Order = 4)]
        public int SetupFontSize1 { get; set; }
        #endregion

        #region Category("MACD Hidden Divergences - Plot Parameters")
        [Range(1, int.MaxValue)]
        [Display(Name = "Width Hidden divergence lines", GroupName = "MACD Hidden Divergences - Plot Parameters", Description = "Select thickness for MACD Hidden divergence lines on both price panel and oscillator panel", Order = 0)]
        public int HiddenDivWidth1 { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Hidden Divergences offset", GroupName = "MACD Hidden Divergences - Plot Parameters", Description = "ATR percentage which is used to set the distance between Hidden divergence lines and price bars", Order = 1)]
        public double HiddenOffsetMultiplier3 { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Drawing objects offset", GroupName = "MACD Hidden Divergences - Plot Parameters", Description = "ATR percentage which is used to set the distance between setups/triggers drawing objects and price bars", Order = 2)]
        public double HiddenOffsetMultiplier1 { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Triggers object size", GroupName = "MACD Hidden Divergences - Plot Parameters", Description = "Select the size for the triggers drawing object", Order = 3)]
        public int HiddenTriangleFontSize1 { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Setups dot size", GroupName = "MACD Hidden Divergences - Plot Parameters", Description = "Select the size for the setups drawing object", Order = 4)]
        public int HiddenSetupFontSize1 { get; set; }
        #endregion

        #region Category("Histogram Divergences - Plot Parameters")
        [Range(1, int.MaxValue)]
        [Display(Name = "Width divergence lines", GroupName = "Histogram Divergences - Plot Parameters", Description = "Select thickness for histogram divergence lines on both price panel and oscillator panel", Order = 0)]
        public int DivWidth2 { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Divergences offset", GroupName = "Histogram Divergences - Plot Parameters", Description = "ATR percentage which is used to set the distance between divergence lines and price bars", Order = 1)]
        public double OffsetMultiplier4 { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Drawing objects offset", GroupName = "Histogram Divergences - Plot Parameters", Description = "ATR precentage which is used to set the distance between setups/triggers drawing objects and price bars", Order = 2)]
        public double OffsetMultiplier2 { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Triggers object size", GroupName = "Histogram Divergences - Plot Parameters", Description = "Select the size for the triggers drawing object", Order = 3)]
        public int TriangleFontSize2 { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Setups dot size", GroupName = "Histogram Divergences - Plot Parameters", Description = "Select the size for the setups drawing object", Order = 4)]
        public int SetupFontSize2 { get; set; }
        #endregion

        #region Category("Histogram Hidden Divergences - Plot Parameters")
        [Range(1, int.MaxValue)]
        [Display(Name = "Width Hidden divergence lines", GroupName = "Histogram Hidden Divergences - Plot Parameters", Description = "Select thickness for histogram Hidden divergence lines on both price panel and oscillator panel", Order = 0)]
        public int HiddenDivWidth2 { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Hidden Divergences offset", GroupName = "Histogram Hidden Divergences - Plot Parameters", Description = "ATR percentage which is used to set the distance between Hidden divergence lines and price bars", Order = 1)]
        public double HiddenOffsetMultiplier4 { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Drawing objects offset", GroupName = "Histogram Hidden Divergences - Plot Parameters", Description = "ATR precentage which is used to set the distance between setups/triggers drawing objects and price bars", Order = 2)]
        public double HiddenOffsetMultiplier2 { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Triggers object size", GroupName = "Histogram Hidden Divergences - Plot Parameters", Description = "Select the size for the triggers drawing object", Order = 3)]
        public int HiddenTriangleFontSize2 { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Setups dot size", GroupName = "Histogram Hidden Divergences - Plot Parameters", Description = "Select the size for the setups drawing object", Order = 4)]
        public int HiddenSetupFontSize2 { get; set; }
        #endregion

        #region Category("MACD Divergences - Plot Colors")
        [XmlIgnore]
        [Display(Name = "Setups bearish trendlines", GroupName = "MACD Divergences - Plot Colors", Description = "Select color for bearish divergence lines", Order = 0)]
        public Brush BearColor1 { get; set; }
        [Browsable(false)]
        public string BearColor1Serialize
        {
            get { return Serialize.BrushToString(BearColor1); }
            set { BearColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bullish trendlines", GroupName = "MACD Divergences - Plot Colors", Description = "Select color for bullish divergence lines", Order = 1)]
        public Brush BullColor1 { get; set; }
        [Browsable(false)]
        public string BullColor1Serialize
        {
            get { return Serialize.BrushToString(BullColor1); }
            set { BullColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Triggers bearish objects", GroupName = "MACD Divergences - Plot Colors", Description = "Select color for bearish triggers objects", Order = 2)]
        public Brush ArrowDownColor1 { get; set; }
        [Browsable(false)]
        public string ArrowDownColor1Serialize
        {
            get { return Serialize.BrushToString(ArrowDownColor1); }
            set { ArrowDownColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Triggers bullish objects", GroupName = "MACD Divergences - Plot Colors", Description = "Select color for bullish triggers objects", Order = 3)]
        public Brush ArrowUpColor1 { get; set; }
        [Browsable(false)]
        public string ArrowUpColor1Serialize
        {
            get { return Serialize.BrushToString(ArrowUpColor1); }
            set { ArrowUpColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bearish dots", GroupName = "MACD Divergences - Plot Colors", Description = "Select color for bearish setups dots", Order = 4)]
        public Brush BearishSetupColor1 { get; set; }
        [Browsable(false)]
        public string BearishSetupColor1Serialize
        {
            get { return Serialize.BrushToString(BearishSetupColor1); }
            set { BearishSetupColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bullish dots", GroupName = "MACD Divergences - Plot Colors", Description = "Select color for bullish setups dots", Order = 5)]
        public Brush BullishSetupColor1 { get; set; }
        [Browsable(false)]
        public string BullishSetupColor1Serialize
        {
            get { return Serialize.BrushToString(BullishSetupColor1); }
            set { BullishSetupColor1 = Serialize.StringToBrush(value); }
        }
        #endregion

        #region Category("MACD Hidden Divergences - Plot Colors")
        [XmlIgnore]
        [Display(Name = "Setups bearish trendlines", GroupName = "MACD Hidden Divergences - Plot Colors", Description = "Select color for bearish Hidden divergence lines", Order = 0)]
        public Brush HiddenBearColor1 { get; set; }
        [Browsable(false)]
        public string HiddenBearColor1Serialize
        {
            get { return Serialize.BrushToString(HiddenBearColor1); }
            set { HiddenBearColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bullish trendlines", GroupName = "MACD Hidden Divergences - Plot Colors", Description = "Select color for bullish Hidden divergence lines", Order = 1)]
        public Brush HiddenBullColor1 { get; set; }
        [Browsable(false)]
        public string HiddenBullColor1Serialize
        {
            get { return Serialize.BrushToString(HiddenBullColor1); }
            set { HiddenBullColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Triggers bearish objects", GroupName = "MACD Hidden Divergences - Plot Colors", Description = "Select color for bearish triggers objects", Order = 2)]
        public Brush HiddenArrowDownColor1 { get; set; }
        [Browsable(false)]
        public string HiddenArrowDownColor1Serialize
        {
            get { return Serialize.BrushToString(HiddenArrowDownColor1); }
            set { HiddenArrowDownColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Triggers bullish objects", GroupName = "MACD Hidden Divergences - Plot Colors", Description = "Select color for bullish triggers objects", Order = 3)]
        public Brush HiddenArrowUpColor1 { get; set; }
        [Browsable(false)]
        public string HiddenArrowUpColor1Serialize
        {
            get { return Serialize.BrushToString(HiddenArrowUpColor1); }
            set { HiddenArrowUpColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bearish dots", GroupName = "MACD Hidden Divergences - Plot Colors", Description = "Select color for bearish setups dots", Order = 4)]
        public Brush HiddenBearishSetupColor1 { get; set; }
        [Browsable(false)]
        public string HiddenBearishSetupColor1Serialize
        {
            get { return Serialize.BrushToString(HiddenBearishSetupColor1); }
            set { HiddenBearishSetupColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bullish dots", GroupName = "MACD Hidden Divergences - Plot Colors", Description = "Select color for bullish setups dots", Order = 5)]
        public Brush HiddenBullishSetupColor1 { get; set; }
        [Browsable(false)]
        public string HiddenBullishSetupColor1Serialize
        {
            get { return Serialize.BrushToString(HiddenBullishSetupColor1); }
            set { HiddenBullishSetupColor1 = Serialize.StringToBrush(value); }
        }
        #endregion

        #region Category("Histogram Divergences - Plot Colors")
        [XmlIgnore]
        [Display(Name = "Setups bearish trendlines", GroupName = "Histogram Divergences - Plot Colors", Description = "Select color for bearish divergence lines", Order = 0)]
        public Brush BearColor2 { get; set; }
        [Browsable(false)]
        public string BearColor2Serialize
        {
            get { return Serialize.BrushToString(BearColor2); }
            set { BearColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bullish trendlines", GroupName = "Histogram Divergences - Plot Colors", Description = "Select color for bullish divergence lines", Order = 1)]
        public Brush BullColor2 { get; set; }
        [Browsable(false)]
        public string BullColor2Serialize
        {
            get { return Serialize.BrushToString(BullColor2); }
            set { BullColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Triggers bearish objects", GroupName = "Histogram Divergences - Plot Colors", Description = "Select color for bearish triggers objects", Order = 2)]
        public Brush ArrowDownColor2 { get; set; }
        [Browsable(false)]
        public string ArrowDownColor2Serialize
        {
            get { return Serialize.BrushToString(ArrowDownColor2); }
            set { ArrowDownColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Triggers bullish objects", GroupName = "Histogram Divergences - Plot Colors", Description = "Select color for bullish triggers objects", Order = 3)]
        public Brush ArrowUpColor2 { get; set; }
        [Browsable(false)]
        public string ArrowUpColor2Serialize
        {
            get { return Serialize.BrushToString(ArrowUpColor2); }
            set { ArrowUpColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bearish dots", GroupName = "Histogram Divergences - Plot Colors", Description = "Select color for bearish setups dots", Order = 4)]
        public Brush BearishSetupColor2 { get; set; }
        [Browsable(false)]
        public string BearishSetupColor2Serialize
        {
            get { return Serialize.BrushToString(BearishSetupColor2); }
            set { BearishSetupColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bullish dots", GroupName = "Histogram Divergences - Plot Colors", Description = "Select color for bullish setups dots", Order = 5)]
        public Brush BullishSetupColor2 { get; set; }
        [Browsable(false)]
        public string BullishSetupColor2Serialize
        {
            get { return Serialize.BrushToString(BullishSetupColor2); }
            set { BullishSetupColor2 = Serialize.StringToBrush(value); }
        }
        #endregion

        #region Category("Histogram Hidden Divergences - Plot Colors")
        [XmlIgnore]
        [Display(Name = "Setups bearish trendlines", GroupName = "Histogram Hidden Divergences - Plot Colors", Description = "Select color for bearish Hidden divergence lines", Order = 0)]
        public Brush HiddenBearColor2 { get; set; }
        [Browsable(false)]
        public string HiddenBearColor2Serialize
        {
            get { return Serialize.BrushToString(HiddenBearColor2); }
            set { HiddenBearColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bullish trendlines", GroupName = "Histogram Hidden Divergences - Plot Colors", Description = "Select color for bullish Hidden divergence lines", Order = 1)]
        public Brush HiddenBullColor2 { get; set; }
        [Browsable(false)]
        public string HiddenBullColor2Serialize
        {
            get { return Serialize.BrushToString(HiddenBullColor2); }
            set { HiddenBullColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Triggers bearish objects", GroupName = "Histogram Hidden Divergences - Plot Colors", Description = "Select color for bearish triggers objects", Order = 2)]
        public Brush HiddenArrowDownColor2 { get; set; }
        [Browsable(false)]
        public string HiddenArrowDownColor2Serialize
        {
            get { return Serialize.BrushToString(HiddenArrowDownColor2); }
            set { HiddenArrowDownColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Triggers bullish objects", GroupName = "Histogram Hidden Divergences - Plot Colors", Description = "Select color for bullish triggers objects", Order = 3)]
        public Brush HiddenArrowUpColor2 { get; set; }
        [Browsable(false)]
        public string HiddenArrowUpColor2Serialize
        {
            get { return Serialize.BrushToString(HiddenArrowUpColor2); }
            set { HiddenArrowUpColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bearish dots", GroupName = "Histogram Hidden Divergences - Plot Colors", Description = "Select color for bearish setups dots", Order = 4)]
        public Brush HiddenBearishSetupColor2 { get; set; }
        [Browsable(false)]
        public string HiddenBearishSetupColor2Serialize
        {
            get { return Serialize.BrushToString(HiddenBearishSetupColor2); }
            set { HiddenBearishSetupColor2 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Setups bullish dots", GroupName = "Histogram Hidden Divergences - Plot Colors", Description = "Select color for bullish setups dots", Order = 5)]
        public Brush HiddenBullishSetupColor2 { get; set; }
        [Browsable(false)]
        public string HiddenBullishSetupColor2Serialize
        {
            get { return Serialize.BrushToString(HiddenBullishSetupColor2); }
            set { HiddenBullishSetupColor2 = Serialize.StringToBrush(value); }
        }
        #endregion

        #region GroupName = "Sentiment Box - Colors"
        [XmlIgnore]
        [Display(Name = "Bearish Acceleration", GroupName = "Sentiment Box - Colors", Description = "Select color for bearish acceleration signal", Order = 1)]
        public Brush BearishAccelerationColor { get; set; }
        [Browsable(false)]
        public string BearishAccelerationColorSerialize
        {
            get { return Serialize.BrushToString(BearishAccelerationColor); }
            set { BearishAccelerationColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bearish Divergence", GroupName = "Sentiment Box - Colors", Description = "Select color for bearish divergence signal", Order = 2)]
        public Brush BearishDivergenceColor { get; set; }
        [Browsable(false)]
        public string BearishDivergenceColorSerialize
        {
            get { return Serialize.BrushToString(BearishDivergenceColor); }
            set { BearishDivergenceColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bearish Foreground", GroupName = "Sentiment Box - Colors", Description = "Select color for bearish foreground text", Order = 3)]
        public Brush BearishForegroundColor { get; set; }
        [Browsable(false)]
        public string BearishForegroundColorSerialize
        {
            get { return Serialize.BrushToString(BearishForegroundColor); }
            set { BearishForegroundColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bullish Acceleration", GroupName = "Sentiment Box - Colors", Description = "Select color for bullish acceleration signal", Order = 3)]
        public Brush BullishAccelerationColor { get; set; }
        [Browsable(false)]
        public string BullishAccelerationColorSerialize
        {
            get { return Serialize.BrushToString(BullishAccelerationColor); }
            set { BullishAccelerationColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bullish Divergence", GroupName = "Sentiment Box - Colors", Description = "Select color for bullish divergence signal", Order = 4)]
        public Brush BullishDivergenceColor { get; set; }
        [Browsable(false)]
        public string BullishDivergenceColorSerialize
        {
            get { return Serialize.BrushToString(BullishDivergenceColor); }
            set { BullishDivergenceColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bullish Foreground", GroupName = "Sentiment Box - Colors", Description = "Select color for bullish foreground text", Order = 5)]
        public Brush BullishForegroundColor { get; set; }
        [Browsable(false)]
        public string BullishForegroundColorSerialize
        {
            get { return Serialize.BrushToString(BullishForegroundColor); }
            set { BullishForegroundColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Box Outline Color", GroupName = "Sentiment Box - Colors", Description = "Select color if there is no bullish or bearish indication", Order = 6)]
        public Brush TextBoxOutlineColor { get; set; }
        [Browsable(false)]
        public string TextBoxOutlineColorSerialize
        {
            get { return Serialize.BrushToString(TextBoxOutlineColor); }
            set { TextBoxOutlineColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Text Color", GroupName = "Sentiment Box - Colors", Description = "Select color if there is no bullish or bearish indication", Order = 7)]
        public Brush TextColor { get; set; }
        [Browsable(false)]
        public string TextColorSerialize
        {
            get { return Serialize.BrushToString(TextColor); }
            set { TextColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Background Color", GroupName = "Sentiment Box - Colors", Description = "Select color for back ground of display", Order = 8)]
        public Brush DataTableColor { get; set; }
        [Browsable(false)]
        public string DataTableColorSerialize
        {
            get { return Serialize.BrushToString(DataTableColor); }
            set { DataTableColor = Serialize.StringToBrush(value); }
        }
        #endregion

		//JQ 11.26.2017
		// Bug 12782. The set right margin is causing the shifting of the SDV bar when the PP bar and the Divergence indicator
        // are all on the same chart. This could be a NT8 issue as it appears the BarMarginRight is only applied to the
		// primary bar (PP) rather than the secondary bar SDV). For now, I will disable the setrightmargin properties
		// until I have a chance to talk to NT about this issue.
		// --start--
        #region Category("Sentiment Box - Parameters")
//        [Display(Name = "Set right side margin", GroupName = "Sentiment Box - Parameters", Description = "When set to true the margin required between the last bar and the chart boundary is set as needed for the box", Order = 1)]
//        public bool SetRightSideMargin { get; set; }
		// --End--

		[Range(1, int.MaxValue)]
		[Display(Name = "Fontsize", GroupName = "Sentiment Box - Parameters", Description = "Select fontsize for text which appears in the box", Order = 0)]
		public int DataFontSize { get; set; }

		[Display(Name = "Location", GroupName = "Sentiment Box - Parameters", Description = "Select location of the sentiment box", Order = 10)]
		public ARC_VMDSystem_SentimentBoxLocations SentimentBoxLocation { get; set; }

		[Display(Name = "Overprint?", GroupName = "Sentiment Box - Parameters", Description = "Will the sentiment box print on top of the histogram?", Order = 20)]
		public bool OverprintSentimentBox { get; set; }
		#endregion

        #region Category("Sentiment Box - Text Elements")
        [Display(Name = "Bullish Acceleration", GroupName = "Sentiment Box - Text Elements", Description = "Select text for bullish acceleration", Order = 1)]
        public string BullAccString { get; set; }

        [Display(Name = "Confirmed bull divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bullish divergence", Order = 4)]
        public string BullDivCString { get; set; }

        [Display(Name = "Potential bull divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bullish divergence", Order = 9)]
        public string BullDivPString { get; set; }

        [Display(Name = "Confirmed bull hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bullish hidden divergence", Order = 5)]
        public string BullHDivCString { get; set; }

        [Display(Name = "Potential bull hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bullish hidden divergence", Order = 10)]
        public string BullHDivPString { get; set; }

        [Display(Name = "Bearish Acceleration", GroupName = "Sentiment Box - Text Elements", Description = "Select text for bearish acceleration", Order = 0)]
        public string BearAccString { get; set; }

        [Display(Name = "Confirmed bear divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bearish divergence", Order = 2)]
        public string BearDivCString { get; set; }

        [Display(Name = "Potential bear divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bearish divergence", Order = 7)]
        public string BearDivPString { get; set; }

        [Display(Name = "Confirmed bear hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bearish hidden divergence", Order = 3)]
        public string BearHDivCString { get; set; }

        [Display(Name = "Potential bear hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bearish hidden divergence", Order = 8)]
        public string BearHDivPString { get; set; }

        [Display(Name = "Neutral condition", GroupName = "Sentiment Box - Text Elements", Description = "Select text for neutral condition without bullish or bearish indications", Order = 6)]
        public string NeutralString { get; set; }

        [Display(Name = "Up Trend Bias", GroupName = "Sentiment Box - Text Elements", Description = "Select text for Up Trend Bias", Order = 11)]
        public string UpBiasString { get; set; }

        [Display(Name = "Neutral Bias", GroupName = "Sentiment Box - Text Elements", Description = "Select text for Neutral Bias", Order = 12)]
        public string NeutralBiasString { get; set; }

        [Display(Name = "Down Trend Bias", GroupName = "Sentiment Box - Text Elements", Description = "Select text for Down Trend Bias", Order = 13)]
        public string DwBiasString { get; set; }
        #endregion

        [Display(Name = "Button Text", GroupName = "Indicator Display", Description = "", Order = 20)]
		public string pButtonText {get;set;}

        //---start--
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }
        //--end--
        #endregion
    }
}
public enum ARC_VMDSystem_InputType { High_Low, Close, Median, Typical }
public enum ARC_VMDSystem_Flooding { None, Histogram, Structure, Both }
public enum ARC_VMDSystem_ExcursionStyle { Static, Dynamic }
public enum ARC_VMDSystem_SentimentBoxLocations {Left, Right, Hide}
public enum ARC_VMDSystem_OptimizeSpeedSettings {Max, Min, None}
public enum ARC_VMDSystem_SystemTypes {None, Termite, BothDivergences, HiddenDiv, RegularDiv}
public enum ARC_VMDSystem_SignalVisualTypes {ON, OFF}
public enum ARC_VMDSystem_StructureDisqualifierType {ClosePrice, Intrabar}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_VMDSystem[] cacheARC_VMDSystem;
		public ARC.ARC_VMDSystem ARC_VMDSystem(ARC_VMDSystem_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB, ARC_VMDSystem_InputType thisInputType, bool useOscHighLow, bool includeDoubleTopsAndBottoms, bool useLastSwingOnly, bool resetFilter, int divMaxBars, int divMinBars, int triggerBars)
		{
			return ARC_VMDSystem(Input, optimizeSpeed, bandPeriod, fast, slow, stdDevNumber, swingStrength, multiplierMD, multiplierDTB, thisInputType, useOscHighLow, includeDoubleTopsAndBottoms, useLastSwingOnly, resetFilter, divMaxBars, divMinBars, triggerBars);
		}

		public ARC.ARC_VMDSystem ARC_VMDSystem(ISeries<double> input, ARC_VMDSystem_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB, ARC_VMDSystem_InputType thisInputType, bool useOscHighLow, bool includeDoubleTopsAndBottoms, bool useLastSwingOnly, bool resetFilter, int divMaxBars, int divMinBars, int triggerBars)
		{
			if (cacheARC_VMDSystem != null)
				for (int idx = 0; idx < cacheARC_VMDSystem.Length; idx++)
					if (cacheARC_VMDSystem[idx] != null && cacheARC_VMDSystem[idx].OptimizeSpeed == optimizeSpeed && cacheARC_VMDSystem[idx].BandPeriod == bandPeriod && cacheARC_VMDSystem[idx].Fast == fast && cacheARC_VMDSystem[idx].Slow == slow && cacheARC_VMDSystem[idx].StdDevNumber == stdDevNumber && cacheARC_VMDSystem[idx].SwingStrength == swingStrength && cacheARC_VMDSystem[idx].MultiplierMD == multiplierMD && cacheARC_VMDSystem[idx].MultiplierDTB == multiplierDTB && cacheARC_VMDSystem[idx].ThisInputType == thisInputType && cacheARC_VMDSystem[idx].UseOscHighLow == useOscHighLow && cacheARC_VMDSystem[idx].IncludeDoubleTopsAndBottoms == includeDoubleTopsAndBottoms && cacheARC_VMDSystem[idx].UseLastSwingOnly == useLastSwingOnly && cacheARC_VMDSystem[idx].ResetFilter == resetFilter && cacheARC_VMDSystem[idx].DivMaxBars == divMaxBars && cacheARC_VMDSystem[idx].DivMinBars == divMinBars && cacheARC_VMDSystem[idx].TriggerBars == triggerBars && cacheARC_VMDSystem[idx].EqualsInput(input))
						return cacheARC_VMDSystem[idx];
			return CacheIndicator<ARC.ARC_VMDSystem>(new ARC.ARC_VMDSystem(){ OptimizeSpeed = optimizeSpeed, BandPeriod = bandPeriod, Fast = fast, Slow = slow, StdDevNumber = stdDevNumber, SwingStrength = swingStrength, MultiplierMD = multiplierMD, MultiplierDTB = multiplierDTB, ThisInputType = thisInputType, UseOscHighLow = useOscHighLow, IncludeDoubleTopsAndBottoms = includeDoubleTopsAndBottoms, UseLastSwingOnly = useLastSwingOnly, ResetFilter = resetFilter, DivMaxBars = divMaxBars, DivMinBars = divMinBars, TriggerBars = triggerBars }, input, ref cacheARC_VMDSystem);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_VMDSystem ARC_VMDSystem(ARC_VMDSystem_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB, ARC_VMDSystem_InputType thisInputType, bool useOscHighLow, bool includeDoubleTopsAndBottoms, bool useLastSwingOnly, bool resetFilter, int divMaxBars, int divMinBars, int triggerBars)
		{
			return indicator.ARC_VMDSystem(Input, optimizeSpeed, bandPeriod, fast, slow, stdDevNumber, swingStrength, multiplierMD, multiplierDTB, thisInputType, useOscHighLow, includeDoubleTopsAndBottoms, useLastSwingOnly, resetFilter, divMaxBars, divMinBars, triggerBars);
		}

		public Indicators.ARC.ARC_VMDSystem ARC_VMDSystem(ISeries<double> input , ARC_VMDSystem_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB, ARC_VMDSystem_InputType thisInputType, bool useOscHighLow, bool includeDoubleTopsAndBottoms, bool useLastSwingOnly, bool resetFilter, int divMaxBars, int divMinBars, int triggerBars)
		{
			return indicator.ARC_VMDSystem(input, optimizeSpeed, bandPeriod, fast, slow, stdDevNumber, swingStrength, multiplierMD, multiplierDTB, thisInputType, useOscHighLow, includeDoubleTopsAndBottoms, useLastSwingOnly, resetFilter, divMaxBars, divMinBars, triggerBars);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_VMDSystem ARC_VMDSystem(ARC_VMDSystem_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB, ARC_VMDSystem_InputType thisInputType, bool useOscHighLow, bool includeDoubleTopsAndBottoms, bool useLastSwingOnly, bool resetFilter, int divMaxBars, int divMinBars, int triggerBars)
		{
			return indicator.ARC_VMDSystem(Input, optimizeSpeed, bandPeriod, fast, slow, stdDevNumber, swingStrength, multiplierMD, multiplierDTB, thisInputType, useOscHighLow, includeDoubleTopsAndBottoms, useLastSwingOnly, resetFilter, divMaxBars, divMinBars, triggerBars);
		}

		public Indicators.ARC.ARC_VMDSystem ARC_VMDSystem(ISeries<double> input , ARC_VMDSystem_OptimizeSpeedSettings optimizeSpeed, int bandPeriod, int fast, int slow, double stdDevNumber, int swingStrength, double multiplierMD, double multiplierDTB, ARC_VMDSystem_InputType thisInputType, bool useOscHighLow, bool includeDoubleTopsAndBottoms, bool useLastSwingOnly, bool resetFilter, int divMaxBars, int divMinBars, int triggerBars)
		{
			return indicator.ARC_VMDSystem(input, optimizeSpeed, bandPeriod, fast, slow, stdDevNumber, swingStrength, multiplierMD, multiplierDTB, thisInputType, useOscHighLow, includeDoubleTopsAndBottoms, useLastSwingOnly, resetFilter, divMaxBars, divMinBars, triggerBars);
		}
	}
}

#endregion
