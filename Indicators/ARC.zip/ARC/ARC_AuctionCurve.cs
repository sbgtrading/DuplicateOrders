#define DoLicense
#define MODERATORS
//#define ENABLE_CURRENTCURVE
//#define USE_WPF_COORDS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using System.Threading;
using System.Globalization;
using System.Linq;

using System.Windows.Automation;
using System.Windows.Controls;
//using System.Windows.Input;
using System.Windows;
#endregion

#region Author/Copyright
/*********************************************************************
****************************** NeuroStreet ***************************
**********************************************************************
* Author NT8 : Kriss { AzurITec } + Ben Letto {SBG Trading}
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##########################################################################################################################
--------------------------------------------------------------------------------------------------------------------------
v1.0    - Jun 12 2018  + Launch - StructureSwing code borrowed from GF_System_MTF, Curve drawing code from SDVolumeZones
--------------------------------------------------------------------------------------------------------------------------
v1.1    - Jul 13 2018  + Added "Show Midline" feature to 'StructureDetector Parameters'
					   + Fixed - was not printing all price/percent values on curve at 0 and 100
--------------------------------------------------------------------------------------------------------------------------
v1.2    - Jul 31 2018  + Bug fix to printing of midline
--------------------------------------------------------------------------------------------------------------------------
v1.3    - Sept 7 2018  + Added/enhanced support for MarketAnalyzer (PermissiveSignal, CurveState, StructureState)
                       + Removed "DisplayName"...it was preventing customization of MarketAnalyzer header info
--------------------------------------------------------------------------------------------------------------------------
v1.4    - Sept 13 2018 + Changed logic for current day DailyCurve.  See both code statements under "commented out for v1.4"
--------------------------------------------------------------------------------------------------------------------------
v1.5    - Oct 26 2018  + Added Aggressive Buy, Sell Permissive Signal types
--------------------------------------------------------------------------------------------------------------------------
v1.6    - Nov 20 2018  + Changed Structure Detector to a more comprehensive Sentiment triple box, for StructureBias, CurveState and Permission
--------------------------------------------------------------------------------------------------------------------------
v1.7    - March 1 2019 + Removed the public properties for "CurrentCurve".  The NinjaScript footer code ignores conditional compilation regions, thus making inaccurate NinjaScript footer code
--------------------------------------------------------------------------------------------------------------------------
v1.8    - Dec 10 2019  + Moved all Series<double> inits to the DataLoaded state, for compatibility with 8.0.20.0
--------------------------------------------------------------------------------------------------------------------------
		PermissiveSignal:
			CONSERVATIVE_UP   = 1
			CONSERVATIVE_DOWN = -1
			AGGRESSIVE_UP     = 2
			AGGRESSIVE_DOWN   = -2
		CurveState:
			Positive if above midline
			Negative if below midline
		StructureState:
			DOWN = -1
			NONE = 0
			UP = 1

*/
#endregion

#region -- Global Enums --
	public enum ARC_AuctionCurve_StructureQualifiers {OnTick, OnBarClose}
	public enum ARC_AuctionCurve_SentimentDetectionMode {OFF, OnClose, OnTick}
	public enum ARC_AuctionCurve_SentimentDialogLoc {TopRight, BottomRight, TopLeft, BottomLeft, Center}
	public enum ARC_AuctionCurve_CurveBasis {ATR_HL, Structure}
#endregion
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	#region -- Category Order --
	[CategoryOrder(" Parameters",                    10)]
	[CategoryOrder("Sentiment Parameters",           20)]
	[CategoryOrder("StructureDetector Parameters",   30)]
	[CategoryOrder("SwingTrend Parameters",          40)]
	[CategoryOrder("Daily Zone Count",               50)]
	[CategoryOrder("Daily Curve",                    60)]
	[CategoryOrder("ATR Forecaster",                 70)]
	[CategoryOrder("Indicator Version",             180)]
	#endregion

    public class ARC_AuctionCurve : Indicator
    {
		private const int UP   = 1;
		private const int FLAT = 0;
		private const int DOWN = -1;
		private const int CONSERVATIVE_UP   = 1;
		private const int CONSERVATIVE_DOWN = -1;
		private const int AGGRESSIVE_UP   = 2;
		private const int AGGRESSIVE_DOWN = -2;

		private string OnStateChange_StatusMsg = string.Empty;
		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "AuctionCurve";
		
//v1.9 - Changed DisplayName to clean up the NT IndicatorDialog
		private string VERSION = "v1.9.2 Dec.9.20";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "7035", "4970", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsDebug = false;
        public override string DisplayName { get { if(ChartControl==null) return pButtonText; else return "ARC_AuctionCurve"; } }

#if !ENABLE_CURRENTCURVE
		#region -- Current Curve --
		private bool		cShowCurve = false;
		private int		cCurveLineThickness = 2;
		private int		cCurveLocX = 87;
		private int		cCurveLength = 60;
		private Brush		cLineColor = Brushes.Black;
		private double		cPercent1 = 0;
		private double		cPercent2 = 25;
		private double		cPercent3 = 50;
		private double		cPercent4 = 75;
		private double		cPercent5 = 100;
		private int		cCurveOpacity1 = 30;
		private int		cCurveOpacity2 = 10;
		private int		cCurveOpacity3 = 10;
		private int		cCurveOpacity4 = 30;
		private Brush		cCurveAreaColor1 = Brushes.Green;
		private Brush		cCurveAreaColor2 = Brushes.LightGreen;
		private Brush		cCurveAreaColor3 = Brushes.LightCoral;
		private Brush		cCurveAreaColor4 = Brushes.Red;
				//cDefiance = 170;
//				cBreakATR = 10;
		public bool		cDisplayPrice = false;
		public bool		cDisplayPercent = false;
		public bool		cDisplayText = true;
		private SimpleFont		cTextFont = new SimpleFont("Arial", 12);
		#endregion
#endif

		private int line = 0;
		private bool generalError = false;

		#region  ----- Variables for button interface ----- 
		private int pButtonSize = 15;
		private string toolbarname = "NSAcutionCurveToolBar", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;

		private Menu MenuControlContainer;
		private MenuItem MenuControl, miSelectedCurve;

		private MenuItem miRecalculate1, miRecalculate2;
		private TextBox tb_SwingStrength, tb_QualifyingATRperiod, tb_QualifyingATRmult;
		private TextBox tb_DailyPercent1,tb_DailyPercent2,tb_DailyPercent3,tb_DailyPercent4,tb_DailyPercent5;
		private TextBox tb_MaxWidthInMargin, tb_dCurve_XLoc, tb_dCurveLength;
		private Label gLabel, lbl_dCurveLength, lbl_dCurveXLoc, lbl_DailyPercent2, lbl_DailyPercent1;
#if ENABLE_CURRENTCURVE
		private MenuItem btn_PreventOverlap;
		private TextBox tb_cCurve_XLoc, tb_cCurveLength;
		private Label lbl_cCurveLength, lbl_cCurveXLoc;
#endif
		private Button gCmdup, gCmddw;
		private Button btn_DailyPercent2up, btn_DailyPercent2dn;
		private Button btn_DailyPercent1up, btn_DailyPercent1dn;
		private double[] cache_Percents_4zone = new double[5]{100,75,50,25,0};
		private double[] cache_Percents_2zone = new double[5]{100,50,0,0,0};


        private MouseManager MM;
		#endregion

		//private bool ParameterChanged = false;
		//private double dailyHigh = double.MinValue;
		//private double dailyLow = double.MaxValue;
		//private double YesterdayHigh = 0;
		//private double YesterdayLow = 0;
        private int diff = 0;
//		private int FinalDesiredMargin = 0;
//		private int iRightSidePaddingMin = 15;
		SortedDictionary<double, int> AllLevels = new SortedDictionary<double, int>();
		SharpDX.Direct2D1.Brush dCurveAreaDXBrush1 = null;
		SharpDX.Direct2D1.Brush dCurveAreaDXBrush2 = null;
		SharpDX.Direct2D1.Brush dCurveAreaDXBrush3 = null;
		SharpDX.Direct2D1.Brush dCurveAreaDXBrush4 = null;
		SharpDX.Direct2D1.Brush dLineDXBrush = null;
		SharpDX.Direct2D1.Brush MidlineDXBrush_Value = null;
		SharpDX.Direct2D1.Brush MidlineDXBrush_Retail = null;
		SharpDX.Direct2D1.Brush cCurveAreaDXBrush1 = null;
		SharpDX.Direct2D1.Brush cCurveAreaDXBrush2 = null;
		SharpDX.Direct2D1.Brush cCurveAreaDXBrush3 = null;
		SharpDX.Direct2D1.Brush cCurveAreaDXBrush4 = null;
		SharpDX.Direct2D1.Brush cLineDXBrush = null;
        private DashStyleHelper pDashStyle = DashStyleHelper.Solid;
//		SharpDX.Direct2D1.Brush DXBrushes_LightGray = null;
//		SharpDX.Direct2D1.Brush DXBrushes_LightGreen = null;
//		SharpDX.Direct2D1.Brush DXBrushes_Black = null;
//		SharpDX.Direct2D1.Brush ZoneHDXBrush = null;
//        private Pen ZoneH = new Pen(Brushes.Black, 3);

		SharpDX.Direct2D1.Brush ButtonPenDXBrush = null;
		private Pen ButtonPen = new Pen(Brushes.Black, 1);
        private Brush ButtonBrush = Brushes.LightGray;
        private Brush ButtonTextBrush = Brushes.Black;
        private SimpleFont ButtonFont = new SimpleFont("Arial", 12) { Bold = true };
        private SessionIterator sessionIterator0;
		private ATR theATR;

		#region ----------  UI button pulldown  ----------
		#region ----- ChangeTextBoxValue -----
		private void ChangeTextValue(string Name, string Value, double Delta){
line=513;
try{
			Value = Value.Replace("-",string.Empty).Trim();//no negative values allowed
			double incr = 0;
			if(!double.IsNaN(Delta)) {
				incr = Delta > 0 ? 1 : (Delta < 0 ? -1 : 0);
			}
line=520;
			//Print("Name: "+Name);
			if (Value.Length > 0)
			{
				if (Name.StartsWith("tb_SwingStrength")) {
line=524;
					Value = Value.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
					if(incr!=0){
						SwingStrength = Math.Max(1,Math.Min(200,Convert.ToInt32(Value) + (int)incr));
						tb_SwingStrength.Text = SwingStrength.ToString();
					}else
						tb_SwingStrength.Text = Value;
					if(!double.IsNaN(Delta))
						this.InformUserAboutRecalculation();
				}
				else if (Name.StartsWith("tb_QualifyingATRperiod")) {
line=535;
					Value = Value.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
					if(incr!=0){
						QualifyingATRperiod = Math.Max(1,Math.Min(100,Convert.ToInt32(Value) + (int)incr));
						tb_QualifyingATRperiod.Text = QualifyingATRperiod.ToString();
					}else
						tb_QualifyingATRperiod.Text = Value;
					if(!double.IsNaN(Delta))
						this.InformUserAboutRecalculation();
				}
				else if (Name.StartsWith("tb_QualifyingATRmult")) {
line=547;
					if(incr!=0){
						QualifyingATRmult = Math.Max(0,Math.Min(200,Convert.ToDouble(Value) + (Delta>0?1:-1)));
						tb_QualifyingATRmult.Text = QualifyingATRmult.ToString();
					}else
						tb_QualifyingATRmult.Text = Value;
					if(!double.IsNaN(Delta))
						this.InformUserAboutRecalculation();
				}else if (Name.StartsWith("tb_DailyPercent1")) {
line=556;
					if(incr!=0){
						dPercent1 = Math.Max(0,Math.Min(100,Convert.ToDouble(Value) + (Delta>0?1:-1)));
					}else{
						dPercent1 = Convert.ToDouble(Value);
					}
					dPercent1 = Math.Min(dPercent1, dPercent2);
					tb_DailyPercent1.Text = dPercent1.ToString("0");
					if(this.dZoneCount==2){
						this.cache_Percents_2zone[2] = dPercent1;
					}else{
						this.cache_Percents_4zone[4] = dPercent1;
					}
				}else if (Name.StartsWith("tb_DailyPercent2")) {
line=563;//			Print("tbPct2: "+tb_DailyPercent2.Text+"  "+incr+"   delta: "+Delta);
					if(incr!=0){
						dPercent2 = Math.Max(0,Math.Min(100,Convert.ToDouble(Value) + (Delta>0?1:-1)));
					}else{
						dPercent2 = Convert.ToDouble(Value);
					}
					dPercent2 = Math.Min(dPercent2, dPercent3);
					tb_DailyPercent2.Text = dPercent2.ToString("0");
					if(this.dZoneCount==2){
						this.cache_Percents_2zone[2] = dPercent2;
					}else{
						this.cache_Percents_4zone[3] = dPercent2;
					}
				}else if (Name.StartsWith("tb_DailyPercent3")) {
line=570;
					if(incr!=0){
						dPercent3 = Math.Max(0,Math.Min(100,Convert.ToDouble(Value) + (Delta>0?1:-1)));
					}else{
						dPercent3 = Convert.ToDouble(Value);
					}
					dPercent3 = Math.Min(dPercent3, dPercent4);
					tb_DailyPercent3.Text = dPercent3.ToString("0");
					if(this.dZoneCount==2){
						this.cache_Percents_2zone[2] = dPercent3;
					}else{
						this.cache_Percents_4zone[2] = dPercent3;
					}
				}else if (Name.StartsWith("tb_DailyPercent4")) {
line=577;
					if(incr!=0){
						dPercent4 = Math.Max(0,Math.Min(100,Convert.ToDouble(Value) + (Delta>0?1:-1)));
					}else{
						dPercent4 = Convert.ToDouble(Value);
					}
					dPercent4 = Math.Min(dPercent4, dPercent5);
					tb_DailyPercent4.Text = dPercent4.ToString("0");
					if(this.dZoneCount==2){
						this.cache_Percents_2zone[1] = dPercent4;
//						Print("[0]: "+this.cache_Percents_2zone[0]);
//						Print("[1]: "+this.cache_Percents_2zone[1]);
//						Print("[2]: "+this.cache_Percents_2zone[2]);
//						Print("");
					}else{
//						Print("[0]: "+this.cache_Percents_4zone[0]);
//						Print("[1]: "+this.cache_Percents_4zone[1]);
//						Print("[2]: "+this.cache_Percents_4zone[2]);
//						Print("[3]: "+this.cache_Percents_4zone[3]);
//						Print("[4]: "+this.cache_Percents_4zone[4]);
//						Print("");
						this.cache_Percents_4zone[1] = dPercent4;
					}
				}else if (Name.StartsWith("tb_DailyPercent5")) {
line=584;
					if(incr!=0){
						dPercent5 = Math.Max(0,Math.Min(100,Convert.ToDouble(Value) + (Delta>0?1:-1)));
					}else{
						dPercent5 = Convert.ToDouble(Value);
					}
					dPercent5 = Math.Min(dPercent5, 100);
					tb_DailyPercent5.Text = dPercent5.ToString("0");
					if(this.dZoneCount==2){
						this.cache_Percents_2zone[0] = dPercent5;
					}else{
						this.cache_Percents_4zone[0] = dPercent5;
					}
				}else if(Name.StartsWith("tb_MaxWidthInMargin")){
line=591;
					if(incr!=0){
						this.MaxWidthInMargin = Math.Max(0,Convert.ToInt32(Value) + (Delta>0?5:-5));
						tb_MaxWidthInMargin.Text = this.MaxWidthInMargin.ToString();
					}else
						tb_MaxWidthInMargin.Text = Value;
					if(MaxWidthInMargin>0){
line=598;
#if ENABLE_CURRENTCURVE
						tb_cCurve_XLoc.Background = Brushes.White;
						tb_cCurveLength.Background = Brushes.White;
						tb_cCurve_XLoc.Foreground = Brushes.White;
						tb_cCurveLength.Foreground = Brushes.White;
						lbl_cCurveLength.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
						lbl_cCurveXLoc.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
						btn_PreventOverlap.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
#endif
#if ENABLE_REFINING_LOC
						tb_dCurve_XLoc.Background = Brushes.White;
						tb_dCurveLength.Background = Brushes.White;
						tb_dCurve_XLoc.Foreground = Brushes.White;
						tb_dCurveLength.Foreground = Brushes.White;

						lbl_dCurveLength.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
						lbl_dCurveXLoc.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
#endif
					}else{
line=580;
#if ENABLE_CURRENTCURVE
						tb_cCurve_XLoc.Background = Brushes.Black;
						tb_cCurveLength.Background = Brushes.Black;
						tb_cCurve_XLoc.Foreground = Brushes.White;
						tb_cCurveLength.Foreground = Brushes.White;
						lbl_cCurveLength.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
						lbl_cCurveXLoc.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
						btn_PreventOverlap.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
#endif
#if ENABLE_REFINING_LOC
						tb_dCurve_XLoc.Background = Brushes.Black;
						tb_dCurveLength.Background = Brushes.Black;
						tb_dCurve_XLoc.Foreground = Brushes.White;
						tb_dCurveLength.Foreground = Brushes.White;

						lbl_dCurveLength.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
						lbl_dCurveXLoc.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
#endif
					}
#if ENABLE_CURRENTCURVE
				}else if(Name.StartsWith("tb_cCurve_XLoc")){
line=600;
					if(incr!=0){
						if(MaxWidthInMargin<=0){
							this.cCurveLocX = Math.Max(0,Math.Min(100,Convert.ToInt32(Value) + (Delta>0?1:-1)));
							tb_cCurve_XLoc.Text = this.cCurveLocX.ToString();
						}
					}else
						tb_cCurve_XLoc.Text = Value;
#endif
				}else if(Name.StartsWith("tb_dCurve_XLoc")){
line=610;
					if(incr!=0){
						if(MaxWidthInMargin<=0){
							this.dCurveLocX = Math.Max(0,Math.Min(100,Convert.ToInt32(Value) + (Delta>0?1:-1)));
							tb_dCurve_XLoc.Text = this.dCurveLocX.ToString();
						}
					}else
						tb_dCurve_XLoc.Text = Value;
#if ENABLE_CURRENTCURVE
				}else if(Name.StartsWith("tb_cCurveLength")){
line=620;
					if(incr!=0){
						if(MaxWidthInMargin<=0){
							this.cCurveLength = Math.Max(0,Convert.ToInt32(Value) + (Delta>0?2:-2));
							tb_cCurveLength.Text = this.cCurveLength.ToString();
						}
					}else
						tb_cCurveLength.Text = Value;
#endif
				}else if(Name.StartsWith("tb_dCurveLength")){
line=630;
					if(incr!=0){
						if(MaxWidthInMargin<=0){
							this.dCurveLength = Math.Max(0,Convert.ToInt32(Value) + (Delta>0?2:-2));
							tb_dCurveLength.Text = this.dCurveLength.ToString();
						}
					}else
						tb_dCurveLength.Text = Value;
				}
			    ChartControl.InvalidateVisual();
line=640;
			}
}catch(Exception e){Print(line+": "+e.ToString());}
		}
		#endregion
		#region ----- MouseWheelEvent -----
        private void MouseWheelEvent(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
			TextBox txtSender = sender as TextBox;
			string intxt = txtSender.Text;
			ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 1 : -1);
        }
		#endregion
		#region  ----- createMktStructure_Menu ----- 
        private Grid createMktStructure_Menu(string tb_Value, string tb_ATRPeriodValue, string tb_ATRMultValue)
        {
			const int rHeight = 26;

			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
//			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

			int row = 0;
			//line 1 - SwingStrength
			#region ----- SwingStrength -----
			Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Swing Strength: " };
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 2);

			tb_SwingStrength = new TextBox() { Name = "tb_SwingStrength" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_SwingStrength.Text = tb_Value;
			tb_SwingStrength.MouseWheel += MouseWheelEvent;
			tb_SwingStrength.KeyDown += menuTxtbox_KeyDown;
//			tb_SwingStrength.TextChanged += NumericValueChanged;
			tb_SwingStrength.SetValue(Grid.ColumnProperty, 1);
			tb_SwingStrength.SetValue(Grid.RowProperty, row);
			tb_SwingStrength.SetValue(Grid.RowSpanProperty, 2);

			Button up1 = new Button() { Name = "SwingStrength_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			Button dw1 = new Button() { Name = "SwingStrength_dw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl1);
            grid.Children.Add(tb_SwingStrength);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion
			row = row+3;
			//line 2 - ATRperiod
			#region ----- ATR Period -----
			lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Qualifying ATR period: " };
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 2);

			this.tb_QualifyingATRperiod = new TextBox() { Name = "tb_QualifyingATRperiod" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_QualifyingATRperiod.Text = tb_ATRPeriodValue;
			tb_QualifyingATRperiod.KeyDown += menuTxtbox_KeyDown;
			tb_QualifyingATRperiod.MouseWheel += MouseWheelEvent;
//			tb_SwingStrength.TextChanged += NumericValueChanged;
			tb_QualifyingATRperiod.SetValue(Grid.ColumnProperty, 1);
			tb_QualifyingATRperiod.SetValue(Grid.RowProperty, row);
			tb_QualifyingATRperiod.SetValue(Grid.RowSpanProperty, 2);

			up1 = new Button() { Name = "QATRperiod_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			dw1 = new Button() { Name = "QATRperiod_dw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl1);
            grid.Children.Add(tb_QualifyingATRperiod);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion
			row = row + 2;
			//line 2 - ATRperiod
			#region ----- ATR Mult -----
			lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Qualifying ATR mult: " };
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 2);

			this.tb_QualifyingATRmult = new TextBox() { Name = "tb_QualifyingATRmult" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_QualifyingATRmult.Text = tb_ATRMultValue;
			tb_QualifyingATRmult.KeyDown += menuTxtbox_KeyDown;
			tb_QualifyingATRmult.MouseWheel += MouseWheelEvent;
			tb_QualifyingATRmult.SetValue(Grid.ColumnProperty, 1);
			tb_QualifyingATRmult.SetValue(Grid.RowProperty, row);
			tb_QualifyingATRmult.SetValue(Grid.RowSpanProperty, 2);

			up1 = new Button() { Name = "QATRmult_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			dw1 = new Button() { Name = "QATRmult_dw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl1);
            grid.Children.Add(tb_QualifyingATRmult);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion

            return grid;
        }
		#endregion
		#region  ----- createPercentages_Menu ----- 
        private Grid createPercentages_Menu()
        {
			#region ----- Setup grid -----
			const int rHeight = 26;

			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			#endregion

			int row = 0;
			#region ----- DailyPercent5 -----
			var lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), Content = "Daily % #1: " };
			lbl1.FontWeight = FontWeights.Normal;
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 3);//give it a little more vertical room to print the lower part of a lowercase "g"

			tb_DailyPercent5 = new TextBox() { Name = "tb_DailyPercent5" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_DailyPercent5.Text = dPercent5.ToString("0");
			tb_DailyPercent5.VerticalAlignment = VerticalAlignment.Center;
			tb_DailyPercent5.MouseWheel += MouseWheelEvent;
			tb_DailyPercent5.KeyDown += menuTxtbox_KeyDown;
			tb_DailyPercent5.SetValue(Grid.ColumnProperty, 1);
			tb_DailyPercent5.SetValue(Grid.RowProperty, row);
			tb_DailyPercent5.SetValue(Grid.RowSpanProperty, 2);

			var up1 = new Button() { Name = "tb_DailyPercent5_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			var dw1 = new Button() { Name = "tb_DailyPercent5_dn" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl1);
            grid.Children.Add(tb_DailyPercent5);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion
			row = row+3;
			#region ----- DailyPercent4 -----
			lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), Content = "Daily % #2: " };
			lbl1.FontWeight = FontWeights.Normal;
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 3);//give it a little more vertical room to print the lower part of a lowercase "g"

			tb_DailyPercent4 = new TextBox() { Name = "tb_DailyPercent4" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_DailyPercent4.Text = dPercent4.ToString("0");
			tb_DailyPercent4.VerticalAlignment = VerticalAlignment.Center;
			tb_DailyPercent4.MouseWheel += MouseWheelEvent;
			tb_DailyPercent4.KeyDown += menuTxtbox_KeyDown;
			tb_DailyPercent4.SetValue(Grid.ColumnProperty, 1);
			tb_DailyPercent4.SetValue(Grid.RowProperty, row);
			tb_DailyPercent4.SetValue(Grid.RowSpanProperty, 2);

			up1 = new Button() { Name = "tb_DailyPercent4_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			dw1 = new Button() { Name = "tb_DailyPercent4_dn" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl1);
            grid.Children.Add(tb_DailyPercent4);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion
			row = row+3;
			#region ----- DailyPercent3 -----
			lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), Content = "Daily % #3: " };
			lbl1.FontWeight = FontWeights.Normal;
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 3);//give it a little more vertical room to print the lower part of a lowercase "g"

			tb_DailyPercent3 = new TextBox() { Name = "tb_DailyPercent3" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_DailyPercent3.Text = dPercent3.ToString("0");
			tb_DailyPercent3.VerticalAlignment = VerticalAlignment.Center;
			tb_DailyPercent3.MouseWheel += MouseWheelEvent;
			tb_DailyPercent3.KeyDown += menuTxtbox_KeyDown;
			tb_DailyPercent3.SetValue(Grid.ColumnProperty, 1);
			tb_DailyPercent3.SetValue(Grid.RowProperty, row);
			tb_DailyPercent3.SetValue(Grid.RowSpanProperty, 2);

			up1 = new Button() { Name = "tb_DailyPercent3_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			dw1 = new Button() { Name = "tb_DailyPercent3_dn" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl1);
            grid.Children.Add(tb_DailyPercent3);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion
			row = row+3;
			#region ----- DailyPercent2 -----
			lbl_DailyPercent2 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), Content = "Daily % #4: " };
			lbl_DailyPercent2.FontWeight = FontWeights.Normal;
			lbl_DailyPercent2.SetValue(Grid.ColumnProperty, 0);
			lbl_DailyPercent2.SetValue(Grid.RowProperty, row);
			lbl_DailyPercent2.SetValue(Grid.RowSpanProperty, 3);//give it a little more vertical room to print the lower part of a lowercase "g"

			tb_DailyPercent2 = new TextBox() { Name = "tb_DailyPercent2" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_DailyPercent2.Text = dPercent2.ToString("0");
			tb_DailyPercent2.VerticalAlignment = VerticalAlignment.Center;
			tb_DailyPercent2.MouseWheel += MouseWheelEvent;
			tb_DailyPercent2.KeyDown += menuTxtbox_KeyDown;
			tb_DailyPercent2.SetValue(Grid.ColumnProperty, 1);
			tb_DailyPercent2.SetValue(Grid.RowProperty, row);
			tb_DailyPercent2.SetValue(Grid.RowSpanProperty, 2);

			btn_DailyPercent2up = new Button() { Name = "tb_DailyPercent2_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			btn_DailyPercent2dn = new Button() { Name = "tb_DailyPercent2_dn" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			btn_DailyPercent2up.Click += cmdupdw_Click;
			btn_DailyPercent2up.SetValue(Grid.ColumnProperty, 2);
			btn_DailyPercent2up.SetValue(Grid.RowProperty, row);
			btn_DailyPercent2dn.Click += cmdupdw_Click;
			btn_DailyPercent2dn.SetValue(Grid.ColumnProperty, 2);
			btn_DailyPercent2dn.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl_DailyPercent2);
            grid.Children.Add(tb_DailyPercent2);
            grid.Children.Add(btn_DailyPercent2up);
            grid.Children.Add(btn_DailyPercent2dn);
			#endregion
			row = row+3;
			#region ----- DailyPercent1 -----
			lbl_DailyPercent1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), Content = "Daily % #5: " };
			lbl_DailyPercent1.FontWeight = FontWeights.Normal;
			lbl_DailyPercent1.SetValue(Grid.ColumnProperty, 0);
			lbl_DailyPercent1.SetValue(Grid.RowProperty, row);
			lbl_DailyPercent1.SetValue(Grid.RowSpanProperty, 3);//give it a little more vertical room to print the lower part of a lowercase "g"

			tb_DailyPercent1 = new TextBox() { Name = "tb_DailyPercent1" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_DailyPercent1.Text = dPercent1.ToString("0");
			tb_DailyPercent1.VerticalAlignment = VerticalAlignment.Center;
			tb_DailyPercent1.MouseWheel += MouseWheelEvent;
			tb_DailyPercent1.KeyDown += menuTxtbox_KeyDown;
			tb_DailyPercent1.SetValue(Grid.ColumnProperty, 1);
			tb_DailyPercent1.SetValue(Grid.RowProperty, row);
			tb_DailyPercent1.SetValue(Grid.RowSpanProperty, 2);

			btn_DailyPercent1up = new Button() { Name = "tb_DailyPercent1_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			btn_DailyPercent1dn = new Button() { Name = "tb_DailyPercent1_dn" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			btn_DailyPercent1up.Click += cmdupdw_Click;
			btn_DailyPercent1up.SetValue(Grid.ColumnProperty, 2);
			btn_DailyPercent1up.SetValue(Grid.RowProperty, row);
			btn_DailyPercent1dn.Click += cmdupdw_Click;
			btn_DailyPercent1dn.SetValue(Grid.ColumnProperty, 2);
			btn_DailyPercent1dn.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl_DailyPercent1);
            grid.Children.Add(tb_DailyPercent1);
            grid.Children.Add(btn_DailyPercent1up);
            grid.Children.Add(btn_DailyPercent1dn);
			#endregion
			if(this.dZoneCount==2){
				lbl_DailyPercent1.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
				tb_DailyPercent1.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
				btn_DailyPercent1up.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
				btn_DailyPercent1dn.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);

				lbl_DailyPercent2.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
				tb_DailyPercent2.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
				btn_DailyPercent2up.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
				btn_DailyPercent2dn.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
			}else{
				lbl_DailyPercent1.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
				tb_DailyPercent1.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
				btn_DailyPercent1up.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
				btn_DailyPercent1dn.SetValue(UIElement.VisibilityProperty, Visibility.Visible);

				lbl_DailyPercent2.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
				tb_DailyPercent2.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
				btn_DailyPercent2up.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
				btn_DailyPercent2dn.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
			}

			return grid;
		}
		#endregion
		#region  ----- createVisuals_Menu ----- 
        private Grid createVisuals_Menu(string MaxWidthInMarginStr, string CurrentXLoc, string CurrentCurveWidth, string DailyXLoc, string DailyCurveWidth)
        {
			#region ----- Setup grid -----
			const int rHeight = 26;

			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
#if ENABLE_CURRENTCURVE
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
#endif
			#endregion

			int row = 0;
			#region ----- MaxWidthInMargin -----
			Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0), Content = "Fit in margin (width): " };
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 3);//give it a little more vertical room to print the lower part of a lowercase "g"

			tb_MaxWidthInMargin = new TextBox() { Name = "tb_MaxWidthInMargin" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_MaxWidthInMargin.Text = MaxWidthInMarginStr;
			tb_MaxWidthInMargin.VerticalAlignment = VerticalAlignment.Center;
			tb_MaxWidthInMargin.MouseWheel += MouseWheelEvent;
			tb_MaxWidthInMargin.KeyDown += menuTxtbox_KeyDown;
			tb_MaxWidthInMargin.SetValue(Grid.ColumnProperty, 1);
			tb_MaxWidthInMargin.SetValue(Grid.RowProperty, row);
			tb_MaxWidthInMargin.SetValue(Grid.RowSpanProperty, 2);

			Button up1 = new Button() { Name = "tb_MaxWidthInMargin_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			Button dw1 = new Button() { Name = "tb_MaxWidthInMargin_dw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl1);
            grid.Children.Add(tb_MaxWidthInMargin);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion
			row = row+3;
			//line 2 - CurrentCurve XLoc
#if ENABLE_REFINING_LOC
#if ENABLE_CURRENTCURVE
			#region ----- CurrentCurve XLoc -----
			lbl_cCurveXLoc = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Current Curve XLoc: " };
			lbl_cCurveXLoc.SetValue(Grid.ColumnProperty, 0);
			lbl_cCurveXLoc.SetValue(Grid.RowProperty, row);
			lbl_cCurveXLoc.SetValue(Grid.RowSpanProperty, 2);

			tb_cCurve_XLoc = new TextBox() { Name = "tb_cCurve_XLoc" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_cCurve_XLoc.Text = CurrentXLoc;
			tb_cCurve_XLoc.KeyDown += menuTxtbox_KeyDown;
			tb_cCurve_XLoc.MouseWheel += MouseWheelEvent;
			if(MaxWidthInMargin>0){
				tb_cCurve_XLoc.Background = Brushes.White;
				lbl_cCurveXLoc.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
			}else{
				tb_cCurve_XLoc.Background = Brushes.Black;
				lbl_cCurveXLoc.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
			}
			tb_cCurve_XLoc.SetValue(Grid.ColumnProperty, 1);
			tb_cCurve_XLoc.SetValue(Grid.RowProperty, row);
			tb_cCurve_XLoc.SetValue(Grid.RowSpanProperty, 2);

			up1 = new Button() { Name = "tb_cCurve_XLoc_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			dw1 = new Button() { Name = "tb_cCurve_XLoc_dw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl_cCurveXLoc);
            grid.Children.Add(tb_cCurve_XLoc);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion
			row = row+2;
			//line 4 - CurrentCurve Length
			#region ----- CurrentCurve Length -----
			lbl_cCurveLength = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Current Curve Width: " };
			lbl_cCurveLength.SetValue(Grid.ColumnProperty, 0);
			lbl_cCurveLength.SetValue(Grid.RowProperty, row);
			lbl_cCurveLength.SetValue(Grid.RowSpanProperty, 2);

			tb_cCurveLength = new TextBox() { Name = "tb_cCurveLength" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_cCurveLength.Text = CurrentCurveWidth;
			tb_cCurveLength.KeyDown += menuTxtbox_KeyDown;
			tb_cCurveLength.MouseWheel += MouseWheelEvent;
			if(MaxWidthInMargin>0) {
				tb_cCurveLength.Background = Brushes.White;
				lbl_cCurveLength.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
			}else{
				tb_cCurveLength.Background = Brushes.Black;
				lbl_cCurveLength.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
			}
			tb_cCurveLength.SetValue(Grid.ColumnProperty, 1);
			tb_cCurveLength.SetValue(Grid.RowProperty, row);
			tb_cCurveLength.SetValue(Grid.RowSpanProperty, 2);

			up1 = new Button() { Name = "tb_cCurveLength_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			dw1 = new Button() { Name = "tb_cCurveLength_dw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl_cCurveLength);
            grid.Children.Add(tb_cCurveLength);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion
			row = row + 2;
#endif
			//line 6 - DailyCurve XLoc
			#region ----- DailyCurve XLoc -----
			lbl_dCurveXLoc = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Daily Curve XLoc: " };
			lbl_dCurveXLoc.SetValue(Grid.ColumnProperty, 0);
			lbl_dCurveXLoc.SetValue(Grid.RowProperty, row);
			lbl_dCurveXLoc.SetValue(Grid.RowSpanProperty, 2);

			tb_dCurve_XLoc = new TextBox() { Name = "tb_dCurve_XLoc" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_dCurve_XLoc.Text = DailyXLoc;
			tb_dCurve_XLoc.KeyDown += menuTxtbox_KeyDown;
			tb_dCurve_XLoc.MouseWheel += MouseWheelEvent;
			if(MaxWidthInMargin>0) {
				tb_dCurve_XLoc.Background = Brushes.White;
				lbl_dCurveXLoc.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
			}else{
				tb_dCurve_XLoc.Background = Brushes.Black;
				lbl_dCurveXLoc.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
			}
			tb_dCurve_XLoc.SetValue(Grid.ColumnProperty, 1);
			tb_dCurve_XLoc.SetValue(Grid.RowProperty, row);
			tb_dCurve_XLoc.SetValue(Grid.RowSpanProperty, 2);

			up1 = new Button() { Name = "tb_dCurve_XLoc_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			dw1 = new Button() { Name = "tb_dCurve_XLoc_dw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl_dCurveXLoc);
            grid.Children.Add(tb_dCurve_XLoc);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion
			row = row+2;
			//line 8 - DailyCurve Length
			#region ----- DailyCurve Length -----
			lbl_dCurveLength = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Daily Curve Width: " };
			lbl_dCurveLength.SetValue(Grid.ColumnProperty, 0);
			lbl_dCurveLength.SetValue(Grid.RowProperty, row);
			lbl_dCurveLength.SetValue(Grid.RowSpanProperty, 2);

			tb_dCurveLength = new TextBox() { Name = "tb_dCurveLength" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			tb_dCurveLength.Text = DailyCurveWidth;
			tb_dCurveLength.KeyDown += menuTxtbox_KeyDown;
			tb_dCurveLength.MouseWheel += MouseWheelEvent;
			if(MaxWidthInMargin>0) {
				tb_dCurveLength.Background = Brushes.White;
				lbl_dCurveLength.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
			}else{
				tb_dCurveLength.Background = Brushes.Black;
				lbl_dCurveLength.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
			}
			tb_dCurveLength.SetValue(Grid.ColumnProperty, 1);
			tb_dCurveLength.SetValue(Grid.RowProperty, row);
			tb_dCurveLength.SetValue(Grid.RowSpanProperty, 2);

			up1 = new Button() { Name = "tb_dCurveLength_up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			dw1 = new Button() { Name = "tb_dCurveLength_dw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			up1.Click += cmdupdw_Click;
			up1.SetValue(Grid.ColumnProperty, 2);
			up1.SetValue(Grid.RowProperty, row);
			dw1.Click += cmdupdw_Click;
			dw1.SetValue(Grid.ColumnProperty, 2);
			dw1.SetValue(Grid.RowProperty, row+1);

			grid.Children.Add(lbl_dCurveLength);
            grid.Children.Add(tb_dCurveLength);
            grid.Children.Add(up1);
            grid.Children.Add(dw1);
			#endregion
			row = row + 2;
#endif
			//line 10 - PreventOverlap
            return grid;
        }
		#endregion

        #region  ----- cmdupdw_Click ----- 
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
			Button cmd = sender as Button;
			if (cmd.Name.Contains("SwingStrength")){
				ChangeTextValue("tb_SwingStrength", tb_SwingStrength.Text, cmd.Name.Contains("_up") ? 1 : -1);
			}
			else if (cmd.Name.Contains("tb_MaxWidthInMargin")){
				ChangeTextValue("tb_MaxWidthInMargin", tb_MaxWidthInMargin.Text, cmd.Name.Contains("_up") ? 1 : -1);
			}
			else if (cmd.Name.Contains("QATRperiod")){
				ChangeTextValue("tb_QualifyingATRperiod", tb_QualifyingATRperiod.Text, cmd.Name.Contains("_up") ? 1 : -1);
			}
			else if (cmd.Name.Contains("tb_DailyPercent1")){
				ChangeTextValue("tb_DailyPercent1", tb_DailyPercent1.Text, cmd.Name.Contains("_up") ? 1 : -1);
			}
			else if (cmd.Name.Contains("tb_DailyPercent2")){
				Print(cmd.Name);
				ChangeTextValue("tb_DailyPercent2", tb_DailyPercent2.Text, cmd.Name.Contains("_up") ? 1 : -1);
			}
			else if (cmd.Name.Contains("tb_DailyPercent3")){
				ChangeTextValue("tb_DailyPercent3", tb_DailyPercent3.Text, cmd.Name.Contains("_up") ? 1 : -1);
			}
			else if (cmd.Name.Contains("tb_DailyPercent4")){
				ChangeTextValue("tb_DailyPercent4", tb_DailyPercent4.Text, cmd.Name.Contains("_up") ? 1 : -1);
			}
			else if (cmd.Name.Contains("tb_DailyPercent5")){
				ChangeTextValue("tb_DailyPercent5", tb_DailyPercent5.Text, cmd.Name.Contains("_up") ? 1 : -1);
			}
			else if (cmd.Name.Contains("QATRmult")){
				ChangeTextValue("tb_QualifyingATRmult", tb_QualifyingATRmult.Text, cmd.Name.Contains("_up") ? 0.2 : -0.2);
			}else
				Print("updw click   cmb.Name: "+cmd.Name);
        }
        #endregion

		#region  ----- menuTxtbox_KeyDown ----- 
		private void menuTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			e.Handled = true;
			TextBox txtSender = sender as TextBox;
			int keyVal = (int)e.Key;

			if(MaxWidthInMargin>0){
				if(txtSender.Name.StartsWith("tb_cCurve_XLoc")) return;
				if(txtSender.Name.StartsWith("tb_dCurve_XLoc")) return;
				if(txtSender.Name.StartsWith("tb_cCurveLength")) return;
				if(txtSender.Name.StartsWith("tb_dCurveLength")) return;
			}

			int value = -1;
			if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
				value = keyVal - (int)System.Windows.Input.Key.D0;
			else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
				value = keyVal - (int)System.Windows.Input.Key.NumPad0;

			bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.Decimal;
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.OemPeriod;
			if (isNumeric || e.Key == System.Windows.Input.Key.Back)
			{
				string newText = value != -1 ? value.ToString() : "";
				if(!txtSender.Text.Contains(".")){
					if(e.Key==System.Windows.Input.Key.Decimal) newText = ".";
					else if(e.Key==System.Windows.Input.Key.OemPeriod) newText = ".";
				}
				int tbPosition = txtSender.SelectionStart;
				try{
					if(txtSender.SelectedText.Length==0)
						txtSender.Text = txtSender.Text.Insert(tbPosition, newText);
					else
						txtSender.Text.Replace(txtSender.SelectedText, newText);
				}catch(Exception t){Print(t.ToString());}
				txtSender.Select(tbPosition + 1, 0);
			}
			ChangeTextValue(txtSender.Name, txtSender.Text, 0);
		}
		#endregion

		#region  ----- MenuItem_Click ----- 
		private void MenuItem_Click(object sender, EventArgs e)
		{
			MenuItem item = sender as MenuItem;
			if(item==null) return;
            #region -- showDailyCurve --
            if (item.Name.StartsWith("miShowDailyCurve"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.dShowCurve = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                } else {
                    this.dShowCurve = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
            #endregion
            #region -- showDailyLabels --
            if (item.Name.StartsWith("miShowDailyLabels"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.dDisplayText = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                } else {
                    this.dDisplayText = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
            #endregion
            #region -- showDailyPercent --
            if (item.Name.StartsWith("miShowDailyPercent"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.dDisplayPercent = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                } else {
                    this.dDisplayPercent = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
            #endregion
            #region -- showDailyPrice --
            if (item.Name.StartsWith("miShowDailyPrice"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.dDisplayPrice = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                } else {
                    this.dDisplayPrice = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
            #endregion
			#region -- miDailyZoneCount --
            if (item.Name.StartsWith("miDailyZoneCount"))
            {
                if (item.Header.ToString().EndsWith("2")) {
                    this.dZoneCount = 4;
                    item.Header = item.Header.ToString().Replace("2","4");
					cache_Percents_2zone[0] = dPercent5;
					cache_Percents_2zone[1] = dPercent4;
					cache_Percents_2zone[2] = dPercent3;
					cache_Percents_2zone[3] = 0;
					cache_Percents_2zone[4] = 0;
					dPercent5 = cache_Percents_4zone[0];
					dPercent4 = cache_Percents_4zone[1];
					dPercent3 = cache_Percents_4zone[2];
					dPercent2 = cache_Percents_4zone[3];
					dPercent1 = cache_Percents_4zone[4];
					tb_DailyPercent5.Text = dPercent5.ToString("0");
					tb_DailyPercent4.Text = dPercent4.ToString("0");
					tb_DailyPercent3.Text = dPercent3.ToString("0");
					tb_DailyPercent2.Text = dPercent2.ToString("0");
					tb_DailyPercent1.Text = dPercent1.ToString("0");
					tb_DailyPercent5.InvalidateVisual();
					tb_DailyPercent4.InvalidateVisual();
					tb_DailyPercent3.InvalidateVisual();

					lbl_DailyPercent2  .SetValue(UIElement.VisibilityProperty, Visibility.Visible);
					tb_DailyPercent2   .SetValue(UIElement.VisibilityProperty, Visibility.Visible);
					btn_DailyPercent2up.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
					btn_DailyPercent2dn.SetValue(UIElement.VisibilityProperty, Visibility.Visible);

					lbl_DailyPercent1  .SetValue(UIElement.VisibilityProperty, Visibility.Visible);
					tb_DailyPercent1   .SetValue(UIElement.VisibilityProperty, Visibility.Visible);
					btn_DailyPercent1up.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
					btn_DailyPercent1dn.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
                } else {
                    this.dZoneCount = 2;
					cache_Percents_4zone[0] = dPercent5;
					cache_Percents_4zone[1] = dPercent4;
					cache_Percents_4zone[2] = dPercent3;
					cache_Percents_4zone[3] = dPercent2;
					cache_Percents_4zone[4] = dPercent1;
					dPercent5 = cache_Percents_2zone[0];
					dPercent4 = cache_Percents_2zone[1];
					dPercent3 = cache_Percents_2zone[2];
					dPercent2 = 0;
					dPercent1 = 0;
					tb_DailyPercent5.Text = dPercent5.ToString("0");
					tb_DailyPercent4.Text = dPercent4.ToString("0");
					tb_DailyPercent3.Text = dPercent3.ToString("0");
					tb_DailyPercent5.InvalidateVisual();
					tb_DailyPercent4.InvalidateVisual();
					tb_DailyPercent3.InvalidateVisual();

					item.Header = item.Header.ToString().Replace("4","2");
					lbl_DailyPercent2  .SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
					tb_DailyPercent2   .SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
					btn_DailyPercent2up.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
					btn_DailyPercent2dn.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);

					lbl_DailyPercent1  .SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
					tb_DailyPercent1   .SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
					btn_DailyPercent1up.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
					btn_DailyPercent1dn.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
                }
            }
			#endregion

			#region CurrentCurve
			/*
            #region -- showCurrentCurve --
            if (item.Name.StartsWith("miShowCurrentCurve"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.cShowCurve = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                } else {
                    this.cShowCurve = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
            #endregion
            #region -- showCurrentLabels --
            if (item.Name.StartsWith("miShowCurrentLabels"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.cDisplayText = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                } else {
                    this.cDisplayText = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
            #endregion
            #region -- showCurrentPercent --
            if (item.Name.StartsWith("miShowCurrentPercent"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.cDisplayPercent = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                } else {
                    this.cDisplayPercent = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
            #endregion
            #region -- showCurrentPrice --
            if (item.Name.StartsWith("miShowCurrentPrice"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.cDisplayPrice = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                } else {
                    this.cDisplayPrice = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
			#endregion
			#region -- btn_PreventOverlap --
			if(item.Name.Contains("btn_PreventOverlap")){
				if(MaxWidthInMargin>0) return;
//this.PreventVisualOverlap ? "Curves cannot overlap" : "Curves CAN overlap"
                if (item.Header.ToString().Contains("cannot overlap")) {
                    this.PreventVisualOverlap = false;
                    item.Header = "Curves CAN overlap";
                } else {
                    this.PreventVisualOverlap = true;
                    item.Header = "Curves cannot overlap";
                }
			}
			#endregion
			*/
			#endregion

//			System.Windows.Forms.SendKeys.SendWait("{F5}");
		    ChartControl.InvalidateVisual();
        }
		#endregion

        #region  ----- structureMenuItem_Click ----- 
        private void structureMenuItem_Click(object sender, EventArgs e)
        {
			MenuItem item = sender as MenuItem;
			#region -- Change qualifier --
			if (item.Name.Contains("miMarketStructureQualifier"))
			{
				if (item.Header.ToString().Contains("OnTick")) {
					this.StructureQualifier = ARC_AuctionCurve_StructureQualifiers.OnBarClose;
					item.Header     = item.Header.ToString().Replace("OnTick","OnBarClose");
					item.FontWeight = FontWeights.Normal;
					InformUserAboutRecalculation();
				} else {
					this.StructureQualifier = ARC_AuctionCurve_StructureQualifiers.OnTick;
					item.Header     = item.Header.ToString().Replace("OnBarClose","OnTick");
					item.FontWeight = FontWeights.Normal;
					InformUserAboutRecalculation();
				}
            }
            #endregion
            #region -- showMarketStructureClick --
            if (item.Name.Contains( "miMarketStructureLines"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.ShowStructureLines = false;
                    item.Header     = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                }
                else
                {
                    this.ShowStructureLines = true;
                    item.Header     = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
            #endregion
            #region -- miShowStructureBkg --
            else if (item.Name.Contains("miShowStructureBkg"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.ShowStructureBackground = false;
                    item.Header     = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
					InformUserAboutRecalculation();
                }
                else
                {
                    this.ShowStructureBackground = true;
                    item.Header     = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
					InformUserAboutRecalculation();
                }
            }
            #endregion
            #region -- miShowStructureLabels --
            else if (item.Name.Contains( "miShowStructureLabels"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.ShowStructureLabels = false;
                    item.Header     = item.Header.ToString().Replace("ON","OFF");
					item.FontWeight = FontWeights.Light;
                }
                else
                {
                    this.ShowStructureLabels = true;
                    item.Header     = item.Header.ToString().Replace("OFF","ON");
					item.FontWeight = FontWeights.Normal;
                }
            }
			#endregion
			#region -- miSentimentDetectionMode --
			else if (item.Name.Contains( "miSentimentDetectionMode"))
			{
			    if (item.Header.ToString().EndsWith("OFF"))
			    {
			        this.SentimentDetectionMode = ARC_AuctionCurve_SentimentDetectionMode.OnClose;
			        item.Header     = item.Header.ToString().Replace("OFF","OnClose");
					item.FontWeight = FontWeights.Normal;
			    }
			    else if (item.Header.ToString().EndsWith("OnClose"))
			    {
			        this.SentimentDetectionMode = ARC_AuctionCurve_SentimentDetectionMode.OnTick;
			        item.Header     = item.Header.ToString().Replace("OnClose","OnTick");
					item.FontWeight = FontWeights.Normal;
			    }
			    else if (item.Header.ToString().EndsWith("OnTick"))
			    {
			        this.SentimentDetectionMode = ARC_AuctionCurve_SentimentDetectionMode.OFF;
			        item.Header     = item.Header.ToString().Replace("OnTick","OFF");
					item.FontWeight = FontWeights.Light;
			    }
			}
			#endregion
			#region -- miSentimentDialogLoc --
			else if (item.Name.Contains( "miSentimentDialogLoc"))
			{
				if(SentimentDetectionMode == ARC_AuctionCurve_SentimentDetectionMode.OFF)
					item.FontWeight = FontWeights.Light;
				else
					item.FontWeight = FontWeights.Normal;
			    if (item.Header.ToString().EndsWith("TopLeft"))
			    {
			        SentimentDialogLoc = ARC_AuctionCurve_SentimentDialogLoc.TopRight;
			        item.Header     = item.Header.ToString().Replace("TopLeft",SentimentDialogLoc.ToString());
			    }
				else if (item.Header.ToString().EndsWith("TopRight"))
			    {
			        SentimentDialogLoc = ARC_AuctionCurve_SentimentDialogLoc.Center;
			        item.Header     = item.Header.ToString().Replace("TopRight",SentimentDialogLoc.ToString());
			    }
				else if (item.Header.ToString().EndsWith("Center"))
			    {
			        SentimentDialogLoc = ARC_AuctionCurve_SentimentDialogLoc.BottomLeft;
			        item.Header     = item.Header.ToString().Replace("Center",SentimentDialogLoc.ToString());
			    }
				else if (item.Header.ToString().EndsWith("BottomLeft"))
			    {
			        SentimentDialogLoc = ARC_AuctionCurve_SentimentDialogLoc.BottomRight;
			        item.Header     = item.Header.ToString().Replace("BottomLeft",SentimentDialogLoc.ToString());
			    }
				else if (item.Header.ToString().EndsWith("BottomRight"))
			    {
			        SentimentDialogLoc = ARC_AuctionCurve_SentimentDialogLoc.TopLeft;
			        item.Header     = item.Header.ToString().Replace("BottomRight",SentimentDialogLoc.ToString());
			    }
			}
			#endregion
			ChartControl.InvalidateVisual();
        }
        #endregion

        #region  ----- NumericValueChanged ----- 
		private string currentTextEdit;
		private void NumericValueChanged(object sender, TextChangedEventArgs e)
		{
//			TextBox txtSender = sender as TextBox;
//			string intxt = txtSender.Text;
//			intxt = intxt.Replace("-",string.Empty);
//			intxt = intxt.Trim();
//			if (intxt.Length > 0)
//			{
//				if (txtSender.Name.Contains("tb_SwingStrength")) {
//					intxt = intxt.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
//					SwingStrength = Math.Max(1,Math.Min(200,Convert.ToInt32(intxt)));
//					txtSender.Text = SwingStrength.ToString();
//					this.InformUserAboutRecalculation();
//				}
//				else if (txtSender.Name.Contains("tb_QualifyingATRperiod")) {
//					intxt = intxt.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
//					int num = Math.Max(1,Math.Min(100,Convert.ToInt32(intxt)));
//					this.QualifyingATRperiod   = num;
//					txtSender.Text   = num.ToString();
//				}
//				else if (txtSender.Name.Contains("Changetb_QualifyingATRmult")) {
//					double num = Math.Max(0,Math.Min(200,Convert.ToDouble(intxt)));
//					this.QualifyingATRmult   = num;
//					txtSender.Text   = num.ToString();
//				}
//				else if (txtSender.Name.StartsWith("TradePlan_EntryAreaSize")) {
//					double num = Convert.ToDouble(intxt);
//					bool isInRange = num>=0.0 && num<=3;
//					if(isInRange){
//						if(num>0.01 && num<=3) this.EntryAreaSize_inATRs = num;
//						txtSender.Text            = intxt;
//						ParameterChanged          = true;
//			            ChartControl.InvalidateVisual();
//					}
//				}
//				else if (txtSender.Name.StartsWith("TradePlan_SLsize")) {
//					double num = Convert.ToDouble(intxt);
//					bool isInRange = num>=0.0 && num<=100;
//					if(isInRange){
//						this.SLsize_inATRs = num;
//						txtSender.Text     = intxt;
//						ParameterChanged   = true;
//			            ChartControl.InvalidateVisual();
//					}
//				}
//				else if (txtSender.Name.StartsWith("TradePlan_T1size")){
//					double num = Convert.ToDouble(intxt);
//					bool isInRange = num>=0.0 && num<=100;
//					if(isInRange){
//						this.PT1size_inSLs = num;
//						txtSender.Text      = intxt;
//						ParameterChanged    = true;
//			            ChartControl.InvalidateVisual();
//					}
//				}
//				else if (txtSender.Name.StartsWith("TradePlan_T2size")){
//					double num = Convert.ToDouble(intxt);
//					bool isInRange = num>=0.0 && num<=100;
//					if(isInRange){
//						this.PT2size_inSLs = num;
//						txtSender.Text      = intxt;
//						ParameterChanged    = true;
//			            ChartControl.InvalidateVisual();
//					}
//				}
//			}
		}
		#endregion

//=====================================================================================================
		private void InformUserAboutRecalculation(){
			if(miRecalculate1!=null){
				miRecalculate1.Background = Brushes.Yellow;
				miRecalculate1.FontWeight = FontWeights.Bold;
				miRecalculate1.FontStyle  = FontStyles.Italic;
			}
			if(miRecalculate2!=null){
				miRecalculate2.Background = Brushes.Yellow;
				miRecalculate2.FontWeight = FontWeights.Bold;
				miRecalculate2.FontStyle  = FontStyles.Italic;
			}
		}
		private void ResetRecalculationUI(){
			if(miRecalculate1!=null){
				miRecalculate1.FontWeight = FontWeights.Normal;
				miRecalculate1.FontStyle  = FontStyles.Normal;
				miRecalculate1.Background = null;
			}
			if(miRecalculate2!=null){
				miRecalculate2.FontWeight = FontWeights.Normal;
				miRecalculate2.FontStyle  = FontStyles.Normal;
				miRecalculate2.Background = null;
			}
		}
		#region  ----- addACToolBar ----- 
		private void addACToolBar()
		{
			gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
			gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
			gLabel = new Label();//#RJBug001

			MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
			MenuControl          = new MenuItem {Name="NSAC"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Yellow, Header = pButtonText, Foreground = Brushes.White, Background = Brushes.Maroon, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);

			miSelectedCurve = new MenuItem {Header = "Curve basis: "+pSelectedCurve.ToString().Replace("ATRHL","ATR & HL"), Name = "miSelectedCurve"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			miSelectedCurve.Click += delegate (object o, RoutedEventArgs e){
				if(pSelectedCurve == ARC_AuctionCurve_CurveBasis.Structure)
					pSelectedCurve = ARC_AuctionCurve_CurveBasis.ATR_HL;
				else
					pSelectedCurve = ARC_AuctionCurve_CurveBasis.Structure;
				InformUserAboutRecalculation();
				miSelectedCurve.Header = "Curve basis: " + this.pSelectedCurve.ToString().Replace("ATRHL","ATR & HL");
				ForceRefresh();
			};
			miSelectedCurve.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled=true;
				if(pSelectedCurve == ARC_AuctionCurve_CurveBasis.Structure)
					pSelectedCurve = ARC_AuctionCurve_CurveBasis.ATR_HL;
				else
					pSelectedCurve = ARC_AuctionCurve_CurveBasis.Structure;
				InformUserAboutRecalculation();
				miSelectedCurve.Header = "Curve basis: " + this.pSelectedCurve.ToString().Replace("ATRHL","ATR & HL");
				ForceRefresh();
//				if(e.Delta>0) {
//				}
			};
			MenuControl.Items.Add(miSelectedCurve);
			#region -- Recalc --
			miRecalculate2 = new MenuItem { Header = "RE-CALCULATE Curve", Name = "btn_Recalc2"+uID, HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate2.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				this.SwingStrength       = Math.Max(1,Math.Min(200,Convert.ToInt32(tb_SwingStrength.Text)));
				this.QualifyingATRperiod = Math.Max(1,Math.Min(100,Convert.ToInt32(tb_QualifyingATRperiod.Text)));
				this.QualifyingATRmult   = Math.Max(0.00,Math.Min(200,Convert.ToDouble(tb_QualifyingATRmult.Text)));
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			MenuControl.Items.Add(miRecalculate2);
			#endregion

			#region Daily curve visual controls
			var miShowDailyCurve = new MenuItem { Header = dShowCurve ? "Daily Curve ON" : "Daily Curve OFF", Name = "miShowDailyCurve"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			if(!dShowCurve) miShowDailyCurve.FontWeight = FontWeights.Light;
			miShowDailyCurve.Click += MenuItem_Click;
			MenuControl.Items.Add(miShowDailyCurve);

			var miShowDailyLabels = new MenuItem { Header = dDisplayText ? "Daily Curve Labels ON" : "Daily Curve Labels OFF", Name = "miShowDailyLabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			if(!dDisplayText) miShowDailyLabels.FontWeight = FontWeights.Light;
			miShowDailyLabels.Click += MenuItem_Click;
			MenuControl.Items.Add(miShowDailyLabels);

			var miShowDailyPrice = new MenuItem { Header = dDisplayPrice ? "Daily Curve Price ON" : "Daily Curve Price OFF", Name = "miShowDailyPrice"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			if(!dDisplayPrice) miShowDailyPrice.FontWeight = FontWeights.Light;
			miShowDailyPrice.Click += MenuItem_Click;
			MenuControl.Items.Add(miShowDailyPrice);

			var miShowDailyPercent = new MenuItem { Header = dDisplayPercent ? "Daily Curve % ON" : "Daily Curve % OFF", Name = "miShowDailyPercent"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			if(!dDisplayPercent) miShowDailyPercent.FontWeight = FontWeights.Light;
			miShowDailyPercent.Click += MenuItem_Click;
			MenuControl.Items.Add(miShowDailyPercent);

			MenuControl.Items.Add(new Separator());

			var mi = new MenuItem { Header = "Sentiment Detection "+SentimentDetectionMode.ToString(), Name = "miSentimentDetectionMode"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(SentimentDetectionMode == ARC_AuctionCurve_SentimentDetectionMode.OFF) 
				mi.FontWeight = FontWeights.Light;
			else
				mi.FontWeight = FontWeights.Normal;
			mi.Click += structureMenuItem_Click;
			MenuControl.Items.Add(mi);

			mi = new MenuItem { Header = "Sentiment Dialog "+SentimentDialogLoc.ToString(), Name = "miSentimentDialogLoc"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			mi.FontWeight = FontWeights.Light;
			mi.Click += structureMenuItem_Click;
			MenuControl.Items.Add(mi);

			#endregion
			MenuControl.Items.Add(new Separator());

			var miDailyZoneCount = new MenuItem { Header = "Number of zones: "+dZoneCount.ToString(), Name = "miDailyZoneCount"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			miDailyZoneCount.Click += MenuItem_Click;
			MenuControl.Items.Add(miDailyZoneCount);

			MenuControl.Items.Add(new Separator());

			MenuControl.Items.Add(createPercentages_Menu());

#if ENABLE_CURRENTCURVE
			#region Current curve visual controls
			MenuItem miShowCurrentCurve = new MenuItem { Header = cShowCurve ? "Current Curve ON" : "Current Curve OFF", Name = "miShowCurrentCurve"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			if(!cShowCurve) miShowCurrentCurve.FontWeight = FontWeights.Light;
			miShowCurrentCurve.Click += MenuItem_Click;
			MenuControl.Items.Add(miShowCurrentCurve);

			MenuItem miShowCurrentLabels = new MenuItem { Header = cDisplayText ? "Current Curve Labels ON" : "Current Curve Labels OFF", Name = "miShowCurrentLabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			if(!cDisplayText) miShowCurrentLabels.FontWeight = FontWeights.Light;
			miShowCurrentLabels.Click += MenuItem_Click;
			MenuControl.Items.Add(miShowCurrentLabels);

			MenuItem miShowCurrentPrice = new MenuItem { Header = cDisplayPrice ? "Current Curve Price ON" : "Current Curve Price OFF", Name = "miShowCurrentPrice"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			if(!cDisplayPrice) miShowCurrentPrice.FontWeight = FontWeights.Light;
			miShowCurrentPrice.Click += MenuItem_Click;
			MenuControl.Items.Add(miShowCurrentPrice);

			MenuItem miShowCurrentPercent = new MenuItem { Header = cDisplayPercent ? "Current Curve % ON" : "Current Curve % OFF", Name = "miShowCurrentPercent"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			if(!cDisplayPercent) miShowCurrentPercent.FontWeight = FontWeights.Light;
			miShowCurrentPercent.Click += MenuItem_Click;
			MenuControl.Items.Add(miShowCurrentPercent);
			#endregion
#endif
			#region -- RegMarketStructure --
			MenuItem miMarketStructure = new MenuItem { Header = "Market Structure", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miMarketStructureLines = new MenuItem { Header = ShowStructureLines ? "Structure Lines ON" : "Structure Lines OFF", Name = "miMarketStructureLines"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(!ShowStructureLines) miMarketStructureLines.FontWeight = FontWeights.Light;
			miMarketStructureLines.Click += structureMenuItem_Click;
			miMarketStructure.Items.Add(miMarketStructureLines);

			MenuItem miShowStructureLabels = new MenuItem { Header = ShowStructureLabels ? "Structure Labels ON" : "Structure Labels OFF", Name = "miShowStructureLabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(!ShowStructureLabels) miShowStructureLabels.FontWeight = FontWeights.Light;
			miShowStructureLabels.Click += structureMenuItem_Click;
			miMarketStructure.Items.Add(miShowStructureLabels);

			mi = new MenuItem { Header = ShowStructureBackground ? "Structure Background ON" : "Structure Background OFF", Name = "miShowStructureBkg"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(!ShowStructureBackground) mi.FontWeight = FontWeights.Light;
			mi.Click += structureMenuItem_Click;
			miMarketStructure.Items.Add(mi);

			miMarketStructure.Items.Add(new Separator());
			miMarketStructure.Items.Add(createMktStructure_Menu(this.SwingStrength.ToString(), this.QualifyingATRperiod.ToString(), this.QualifyingATRmult.ToString()));

			MenuItem miMarketStructureQualifier = new MenuItem { Header = "Qualifier Price '"+ this.StructureQualifier.ToString()+"'", Name = "miMarketStructureQualifier"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miMarketStructureQualifier.Click += structureMenuItem_Click;
			miMarketStructure.Items.Add(miMarketStructureQualifier);

			miMarketStructure.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			#region -- Recalc --
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE Structure", Name = "btn_Recalc1"+uID, HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				this.SwingStrength       = Math.Max(1,Math.Min(200,Convert.ToInt32(tb_SwingStrength.Text)));
				this.QualifyingATRperiod = Math.Max(1,Math.Min(100,Convert.ToInt32(tb_QualifyingATRperiod.Text)));
				this.QualifyingATRmult   = Math.Max(0.00,Math.Min(200,Convert.ToDouble(tb_QualifyingATRmult.Text)));
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			miMarketStructure.Items.Add(miRecalculate1);
			#endregion
			//------------------

			#endregion
			MenuControl.Items.Add(miMarketStructure);

			MenuItem miWidthSettings = new MenuItem { Header = "Width Settings", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			miWidthSettings.Items.Add(createVisuals_Menu(this.MaxWidthInMargin.ToString(), this.cCurveLocX.ToString(),this.cCurveLength.ToString(), this.dCurveLocX.ToString(), this.dCurveLength.ToString()));
			MenuControl.Items.Add(miWidthSettings);
#if ENABLE_CURRENTCURVE
			#region ----- PreventOverlap -----
			btn_PreventOverlap = new MenuItem { Header = this.PreventVisualOverlap ? "Curves cannot overlap" : "Curves CAN overlap", Name = "btn_PreventOverlap"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Normal, FontSize = 13 };
			btn_PreventOverlap.Click += MenuItem_Click;
			if(MaxWidthInMargin>0)
				btn_PreventOverlap.SetValue(UIElement.VisibilityProperty, Visibility.Hidden);
			else
				btn_PreventOverlap.SetValue(UIElement.VisibilityProperty, Visibility.Visible);
			miWidthSettings.Items.Add(btn_PreventOverlap);
			#endregion
#endif
//			#region -- Reg AvgTickCalculators --
//			MenuItem miAvgTickCalcs = new MenuItem { Header = "Avg Tick Calculators",Name = "AvgTickCalculatorsLabel"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
//			miAvgTickCalcs.Items.Add(miAvgSL = new MenuItem { Header = "Avg SL: ", Name = "AvgSL_"+uID, Foreground = Brushes.Black });
//			miAvgTickCalcs.Items.Add(miAvgT1 = new MenuItem { Header = "Avg T1: ", Name = "AvgT1_"+uID, Foreground = Brushes.Black });
//			miAvgTickCalcs.Items.Add(miAvgT2 = new MenuItem { Header = "Avg T2: ", Name = "AvgT2_"+uID, Foreground = Brushes.Black });

//			MenuControl.Items.Add(miAvgTickCalcs);
//			#endregion

			indytoolbar.Children.Add(MenuControlContainer);
		}
		#endregion
		#endregion

		private StructureBiasClass StructureMgr = null;
		private class StructureBiasClass {
			#region  ----- StructureBias class ----- 
			public class HLtuple{
				public double H;
				public double L;
				public HLtuple(double h, double l) {H=h; L=l;}
			}
			public int    SwingStrength = 0;
			public bool   isHLBased     = false;
			public double MultiplierMD  = 0;
			public double MultiplierDTB = 0;
			public Series<int> Bias;
			public Brush UpTrendColorTinted   = null;
			public Brush DownTrendColorTinted = null;
			public string StatusMsg = string.Empty;
			public SortedDictionary<int,double>      AllPivots     = new SortedDictionary<int,double>();
			public SortedDictionary<DateTime,double> StructureHigh = new SortedDictionary<DateTime,double>();
			public SortedDictionary<DateTime,double> StructureLow  = new SortedDictionary<DateTime,double>();
			public DateTime SessionDate = DateTime.MinValue;
			public SortedDictionary<DateTime,HLtuple> DailyStructureHL  = new SortedDictionary<DateTime,HLtuple>();
			public List<int> AllPivotsKeys = new List<int>();
//			public bool IsRising = false;
			public double ExtremePriceOfCurrentSwing = double.NaN;

			private double MostRecentStructureChangeHigh = 0;
			private double MostRecentStructureChangeLow = 0;
			public double CurrentDailyHigh = double.MinValue;
			public double CurrentDailyLow  = double.MaxValue;

			#region  ----- internals ----- 
			private Series<bool>   upTrend;
			private Series<double> pre_swingHighType;
			private Series<double> pre_swingLowType;
			private Series<double> swingHighType;
			private Series<double> swingLowType;
			private double swingMax;
			private double swingMin;
			private double zigzagDeviation;
			private bool updateHigh;
			private bool updateLow;
			private bool addHigh;
			private bool addLow;
			private double currentHigh;
			private double currentLow;
			private int lastLowIdx;
			private int lastHighIdx;
			private int priorSwingHighIdx;
			private int priorSwingLowIdx;
			private int highCount;
			private int lowCount;
			private int preLastHighIdx;
			private int preLastLowIdx;
			private double marginUp;
			private double marginDown;
			private double preCurrentHigh;
			private double preCurrentLow;
			private bool intraBarUpdateHigh;
			private bool intraBarUpdateLow;
			private bool intraBarAddHigh;
			private bool intraBarAddLow;
			#endregion

			#region  ----- v internals ----- 
	        private bool vdrawHigherHighLabel   = false;
	        private bool vdrawLowerHighLabel    = false;
	        private bool vdrawDoubleTopLabel    = false;
	        private bool vdrawLowerLowLabel     = false;
	        private bool vdrawHigherLowLabel    = false;
	        private bool vdrawDoubleBottomLabel = false;
			private Series<bool>   vupTrend;
			private Series<double> vpre_swingHighType;
			private Series<double> vpre_swingLowType;
			private Series<double> vswingHighType;
			private Series<double> vswingLowType;
			private Series<double> vavgTrueRange;
			private Series<double> vswingInput;
			private double vswingMax;
			private double vswingMin;
			private double vzigzagDeviation;
			private bool vupdateHigh;
			private bool vupdateLow;
			private bool vaddHigh;
			private bool vaddLow;
			private double vcurrentHigh;
			private double vcurrentLow;
			private int vlastLowIdx;
			private int vlastHighIdx;
			private int vpriorSwingHighIdx;
			private int vpriorSwingLowIdx;
			private int vhighCount;
			private int vlowCount;
			private int vpreLastHighIdx;
			private int vpreLastLowIdx;
			private double vmarginUp;
			private double vmarginDown;
			private double vpreCurrentHigh;
			private double vpreCurrentLow;
			private bool vintraBarUpdateHigh;
			private bool vintraBarUpdateLow;
			private bool vintraBarAddHigh;
			private bool vintraBarAddLow;
			#endregion

			#region generic internals
			private ISeries<double> High;
			private ISeries<double> Low;
			private ISeries<double> Close;
			private int  SRType = 0;
			private int  preSRType = 0;
	        public System.Collections.Generic.List<int> sequence = new System.Collections.Generic.List<int>(3);
			#endregion

			public StructureBiasClass(NinjaScriptBase Chart_Bars, ISeries<double> high, ISeries<double> low, ISeries<double> close, int swingStrength, bool use_HL, double multiplierMD, double multiplierDTB, Brush trendUpColor, int opacityUp, Brush trendDownColor, int opacityDown){
				#region  ----- constructor ----- 
				High  = high;
				Low   = low;
				Close = close;
				vupTrend           = new Series<bool>  (Chart_Bars,MaximumBarsLookBack.Infinite);
				vpre_swingHighType = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vpre_swingLowType  = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vswingHighType     = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vswingLowType      = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				Bias               = new Series<int>   (Chart_Bars,MaximumBarsLookBack.Infinite);
				upTrend            = new Series<bool>  (Chart_Bars,MaximumBarsLookBack.Infinite);
				pre_swingHighType  = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				pre_swingLowType   = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				swingHighType      = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				swingLowType       = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vavgTrueRange      = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				SwingStrength = swingStrength;
				isHLBased	  = use_HL;
				MultiplierMD  = multiplierMD;
				MultiplierDTB = multiplierDTB;
				UpTrendColorTinted         = trendUpColor.Clone();
				UpTrendColorTinted.Opacity = opacityUp / 100f;
				UpTrendColorTinted.Freeze();
				DownTrendColorTinted         = trendDownColor.Clone();
				DownTrendColorTinted.Opacity = opacityDown / 100f;
				DownTrendColorTinted.Freeze();
				#endregion
			}
			private double MAX(ISeries<double> series, int lookback, int rbar_offset){
				double max = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) {
						if(i>=series.Count) return max;
						max = Math.Max(max, series[i]);
					}
				}catch{}
				return max;
			}
			private double MIN(ISeries<double> series, int lookback, int rbar_offset){
				double min = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) {
						if(i>=series.Count) return min;
						min = Math.Min(min, series[i]);
					}
				}catch{}
				return min;
			}
			public void AddToAllPivots(int idx, double price){
				AllPivots[idx] = price;
				AllPivotsKeys  = new List<int>(AllPivots.Keys);
				AllPivotsKeys.Reverse();
				#region Clean up swings when consecutive swings are lows or highs
				if(AllPivots.Count>4){
					var keysToRemove = new List<int>();
					for(int i =0; i<3; i++){
						if(AllPivots[AllPivotsKeys[i]] < 0 && AllPivots[AllPivotsKeys[i+1]] < 0)
							keysToRemove.Add(AllPivotsKeys[i+1]);
						else if(AllPivots[AllPivotsKeys[i]] > 0 && AllPivots[AllPivotsKeys[i+1]] > 0)
							keysToRemove.Add(AllPivotsKeys[i+1]);
					}
					if(keysToRemove.Count>0){
						foreach(int key in keysToRemove){
							AllPivots.Remove(key);
						}
						AllPivotsKeys  = new List<int>(AllPivots.Keys);
						AllPivotsKeys.Reverse();
					}
				}
				#endregion
//				IsRising = price<0;//if we put in a new swing low, then structure is rising, a new swing high means structure is falling
			}


			public void CalculateIt(int CurrentBar, ISeries<double>Input, bool IsFirstTickOfBar, NinjaTrader.NinjaScript.Calculate Calculate, NinjaTrader.NinjaScript.State State, double atr256, ARC_AuctionCurve_StructureQualifiers qualifier){
StatusMsg = string.Empty;
				#region ----- CalculateIt -----
int line=1585;
				try{
				#region --- Calculate ZigZag ---

				swingMax = MAX(isHLBased ? High : Input, SwingStrength, 1);
				swingMin = MIN(isHLBased ? Low  : Input, SwingStrength, 1);
line=1344;
				pre_swingHighType[0] = 0;
				pre_swingLowType[0]  = 0;
				swingHighType[0] = 0;
				swingLowType[0]  = 0;

line=1350;
				updateHigh = upTrend[1] && (isHLBased ? High[0] : Input[0]) > currentHigh;
				updateLow = !upTrend[1] && (isHLBased ? Low[0]  : Input[0]) < currentLow;
				addHigh = !upTrend[1] && !((isHLBased ? Low[0]  : Input[0]) < currentLow) && (isHLBased ? High[0] : Input[0]) > Math.Max(swingMax, currentLow);
				addLow = upTrend[1]   && !((isHLBased ? High[0] : Input[0]) > currentHigh) && (isHLBased ? Low[0] : Input[0]) < Math.Min(swingMin, currentHigh);

line=1356;
	            upTrend[0] = upTrend[1];
	            #endregion
	            #region -- New High --
	            if (addHigh)
	            {
line=1641;
	                //-- update zigzag H/L --
	                upTrend[0] = true;
	                int lookback = CurrentBar - lastLowIdx;
line=1645;
	                swingLowType[lookback] = pre_swingLowType[lookback];
					AddToAllPivots(lastLowIdx, -Low[lookback]);
					if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnTick)
						ExtremePriceOfCurrentSwing = MIN(Low, lookback,0);
					else
						ExtremePriceOfCurrentSwing = MIN(Close, lookback,0);
line=1652;
	                double newHigh = double.MinValue;
	                int j = 0;
	                for (int i = 0; i < CurrentBar - lastLowIdx; i++)
	                {
	                    if ((isHLBased ? High[i] : Input[i]) > newHigh)
	                    {
	                        newHigh = (isHLBased ? High[i] : Input[i]);
	                        j = i;
	                    }
	                }
line=1663;
	                currentHigh = newHigh;
	                priorSwingHighIdx = lastHighIdx;
	                lastHighIdx = CurrentBar - j;
	            }
	            #endregion
	            #region -- uptrend --
	            else if (updateHigh)
	            {
line=1672;
	                upTrend[0] = true;
	                pre_swingHighType[CurrentBar - lastHighIdx] = 0;
line=1675;
	                currentHigh = (isHLBased ? High[0] : Input[0]);
	                lastHighIdx = CurrentBar;
	            }
	            #endregion

	            #region -- New Low --
	            else if (addLow)
	            {
line=1684;
	                upTrend[0] = false;
	                int lookback = CurrentBar - lastHighIdx;
	                swingHighType[lookback] = pre_swingHighType[lookback];
					AddToAllPivots(lastHighIdx, High[lookback]);
line=1689;
					if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnTick)
						ExtremePriceOfCurrentSwing = MAX(High, lookback, 0);
					else
						ExtremePriceOfCurrentSwing = MAX(Close, lookback, 0);
//StatusMsg = "  2060 ExtremePrice: "+ExtremePriceOfCurrentSwing.ToString();
	                double newLow = double.MaxValue;
line=1695;
	                int j = 0;
	                for (int i = 0; i < CurrentBar - lastHighIdx; i++)
	                {
	                    if ((isHLBased ? Low[i] : Input[i]) < newLow)
	                    {
	                        newLow = (isHLBased ? Low[i] : Input[i]);
	                        j = i;
	                    }
	                }
	                currentLow = newLow;
	                priorSwingLowIdx = lastLowIdx;
	                lastLowIdx = CurrentBar - j;
	            }
	            #endregion
	            #region -- dwtrend --
	            else if (updateLow)
	            {
line=1713;
	                upTrend[0] = false;
	                pre_swingLowType[CurrentBar - lastLowIdx] = 0;
line=1716;
	                currentLow = (isHLBased ? Low[0] : Input[0]);
	                lastLowIdx = CurrentBar;
	            }
	            #endregion

	            #region -- Init zigzag states --

line=1724;
				vavgTrueRange[0] = atr256;

	            if (CurrentBar < 2)
	            {
line=1729;
	                vupTrend[0] = true;
	                vpre_swingHighType[0] = 0;
	                vpre_swingLowType[0] = 0;
	                vswingHighType[0] = 0;
	                vswingLowType[0] = 0;
	            }
	            #endregion

	            #region -- OnBarClose --
	            else if (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose)
	            {
line=1741;
	                vzigzagDeviation = MultiplierMD * vavgTrueRange[0];
	                vswingMax = MAX(isHLBased ? High : Input, SwingStrength, 1);
	                vswingMin = MIN(isHLBased ? Low : Input, SwingStrength, 1);

	                vpre_swingHighType[0] = 0;
	                vpre_swingLowType[0] = 0;
	                vswingHighType[0] = 0;
	                vswingLowType[0] = 0;

	                vupdateHigh = vupTrend[1] && (isHLBased ? High[0] : vswingInput[0]) > vcurrentHigh;
	                vupdateLow = !vupTrend[1] && (isHLBased ? Low[0] : vswingInput[0]) < vcurrentLow;
	                vaddHigh = !vupTrend[1] && !((isHLBased ? Low[0] : vswingInput[0]) < vcurrentLow) && (isHLBased ? High[0] : vswingInput[0]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
	                vaddLow = vupTrend[1] && !((isHLBased ? High[0] : vswingInput[0]) > vcurrentHigh) && (isHLBased ? Low[0] : vswingInput[0]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

	                vupTrend[0] = vupTrend[1];

line=1758;
	                #region -- New High --
	                if (vaddHigh)
	                {
line=1762;
	                    vupTrend[0] = true;
	                    int lookback = CurrentBar - vlastLowIdx;
	                    vswingLowType[lookback] = vpre_swingLowType[lookback];
						AddToAllPivots(vlastLowIdx, -Low[lookback]);
line=1767;
	                    double vnewHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastLowIdx; i++)
	                    {
	                        if ((isHLBased ? High[i] : vswingInput[i]) > vnewHigh)
	                        {
	                            vnewHigh = (isHLBased ? High[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
line=1778;
	                    vcurrentHigh = vnewHigh;
	                    vpriorSwingHighIdx = vlastHighIdx;
	                    vlastHighIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- uptrend --
	                else if (vupdateHigh)
	                {
line=1788;
	                    vupTrend[0] = true;
	                    vpre_swingHighType[CurrentBar - vlastHighIdx] = 0;
	                    vcurrentHigh = (isHLBased ? High[0] : vswingInput[0]);
	                    vlastHighIdx = CurrentBar;
	                }
	                #endregion

	                #region -- New Low --
	                else if (vaddLow)
	                {
line=1799;
	                    vupTrend[0] = false;
	                    int lookback = CurrentBar - vlastHighIdx;
	                    vswingHighType[lookback] = vpre_swingHighType[lookback];
						AddToAllPivots(vlastHighIdx, High[lookback]);
line=1804;
	                    double vnewLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastHighIdx; i++)
	                    {
	                        if ((isHLBased ? Low[i] : vswingInput[i]) < vnewLow)
	                        {
	                            vnewLow = (isHLBased ? Low[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
line=1815;
	                    vcurrentLow = vnewLow;
	                    vpriorSwingLowIdx = vlastLowIdx;
	                    vlastLowIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- dwtrend --
	                else if (vupdateLow)
	                {
line=1825;
	                    vupTrend[0] = false;
	                    vpre_swingLowType[CurrentBar - vlastLowIdx] = 0;
	                    vcurrentLow = (isHLBased ? Low[0] : vswingInput[0]);
	                    vlastLowIdx = CurrentBar;
	                }
	                #endregion

	                #region re-init drawing states at each new bar before calculous

line=1835;
	                vdrawHigherHighLabel = false;
	                vdrawLowerHighLabel = false;
	                vdrawDoubleTopLabel = false;
	                vdrawLowerLowLabel = false;
	                vdrawHigherLowLabel = false;
	                vdrawDoubleBottomLabel = false;
	                
	                #endregion

	                #region -- UP || HH --
	                if (vaddHigh || vupdateHigh)
	                {
line=1848;
	                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;

	                    double vmarginUp = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) + MultiplierDTB * vavgTrueRange[vhighCount];
	                    double vmarginDown = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) - MultiplierDTB * vavgTrueRange[vhighCount];

	                    #endregion
	                    // end new code

	                    #region -- Set NEW drawing states --

line=1862;
	                    if (vcurrentHigh > vmarginUp) vdrawHigherHighLabel = true;
	                    else if (vcurrentHigh < vmarginDown) vdrawLowerHighLabel = true;
	                    else vdrawDoubleTopLabel = true;

	                    if (vcurrentHigh > vmarginUp)
	                        vpre_swingHighType[vhighCount] = 3;
	                    else if (vcurrentHigh < vmarginDown)
	                        vpre_swingHighType[vhighCount] = 1;
	                    else
	                        vpre_swingHighType[vhighCount] = 2;
	                    #endregion
	                }

	                #region -- DW || LL --
	                else if (vaddLow || vupdateLow)
	                {
line=1880;
	                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;

						double vmarginDown = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) - MultiplierDTB * vavgTrueRange[vlowCount];
	                    double vmarginUp = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) + MultiplierDTB * vavgTrueRange[vlowCount];

	                    #region -- Set NEW drawing states --

	                    if (vcurrentLow < vmarginDown) vdrawLowerLowLabel = true;
	                    else if (vcurrentLow > vmarginUp) vdrawHigherLowLabel = true;
	                    else vdrawDoubleBottomLabel = true;
	                    
	                    if (vcurrentLow < vmarginDown)
	                        vpre_swingLowType[vlowCount] = -3;
	                    else if (vcurrentLow > vmarginUp)
	                        vpre_swingLowType[vlowCount] = -1;
	                    else
	                        vpre_swingLowType[vlowCount] = -2;
	                    #endregion
	                }
	                #endregion
	            }
                #endregion

	            #region else if (IsFirstTickOfBar)
	            else if (IsFirstTickOfBar)
	            {
line=1912;
	                vzigzagDeviation = MultiplierMD * vavgTrueRange[1];
	                vswingMax = MAX(isHLBased ? High : Input, SwingStrength, 2);
	                vswingMin = MIN(isHLBased ? Low : Input, SwingStrength, 2);

	                vpre_swingHighType[0] = 0;
	                vpre_swingLowType[0] = 0;
	                vswingHighType[0] = 0;
	                vswingLowType[0] = 0;

	                vupdateHigh = vupTrend[1] && (isHLBased ? High[1] : vswingInput[1]) > vcurrentHigh;
	                vupdateLow = !vupTrend[1] && (isHLBased ? Low[1] : vswingInput[1]) < vcurrentLow;
	                vaddHigh = !vupTrend[1] && !((isHLBased ? Low[1] : vswingInput[1]) < vcurrentLow) && (isHLBased ? High[1] : vswingInput[1]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
	                vaddLow = vupTrend[1] && !((isHLBased ? High[1] : vswingInput[1]) > vcurrentHigh) && (isHLBased ? Low[1] : vswingInput[1]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

	                vupTrend[0] = vupTrend[1];

	                #region -- New High --
	                if (vaddHigh)
	                {
line=1932;
	                    vupTrend[0] = true;
	                    int lookback = CurrentBar - vlastLowIdx;
	                    vswingLowType[lookback] = vpre_swingLowType[lookback];
						AddToAllPivots(vlastLowIdx, -Low[lookback]);
	                    double vnewHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 1; i < CurrentBar - vlastLowIdx; i++)
	                    {
	                        if ((isHLBased ? High[i] : vswingInput[i]) > vnewHigh)
	                        {
	                            vnewHigh = (isHLBased ? High[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vcurrentHigh = vnewHigh;
	                    vpriorSwingHighIdx = vlastHighIdx;
	                    vlastHighIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- UPtrend --
	                else if (vupdateHigh)
	                {
line=1956;
	                    vupTrend[0] = true;
	                    vpre_swingHighType[CurrentBar - vlastHighIdx] = 0;
	                    vcurrentHigh = (isHLBased ? High[1] : vswingInput[1]);
	                    vlastHighIdx = CurrentBar - 1;
	                }
	                #endregion

	                #region -- New Low --
	                else if (vaddLow)
	                {
line=1967;
	                    vupTrend[0] = false;
	                    int lookback = CurrentBar - vlastHighIdx;
	                    vswingHighType[lookback] = vpre_swingHighType[lookback];
						AddToAllPivots(vlastHighIdx, High[lookback]);
	                    double vnewLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 1; i < CurrentBar - vlastHighIdx; i++)
	                    {
	                        if ((isHLBased ? Low[i] : vswingInput[i]) < vnewLow)
	                        {
	                            vnewLow = (isHLBased ? Low[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vcurrentLow = vnewLow;
	                    vpriorSwingLowIdx = vlastLowIdx;
	                    vlastLowIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- DWtrend --
	                else if (updateLow)
	                {
line=1991;
	                    vupTrend[0] = false;
	                    vpre_swingLowType[CurrentBar - vlastLowIdx] = 0;
	                    vcurrentLow = isHLBased ? Low[1] : vswingInput[1];
	                    vlastLowIdx = CurrentBar - 1;
	                }
	                #endregion

	                #region re-init drawing states at each new bar before calculous

	                vdrawHigherHighLabel = false;
	                vdrawLowerHighLabel = false;
	                vdrawDoubleTopLabel = false;
	                vdrawLowerLowLabel = false;
	                vdrawHigherLowLabel = false;
	                vdrawDoubleBottomLabel = false;

	                #endregion

line=2010;
	                #region -- UP || HH --
	                if (vaddHigh || vupdateHigh)
	                {
	                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;

	                    double vmarginUp = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) + MultiplierDTB * vavgTrueRange[vhighCount];
	                    double vmarginDown = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) - MultiplierDTB * vavgTrueRange[vhighCount];

	                    #region -- Set NEW drawing states --

	                    if (vcurrentHigh > vmarginUp) vdrawHigherHighLabel = true;
	                    else if (vcurrentHigh < vmarginDown) vdrawLowerHighLabel = true;
	                    else vdrawDoubleTopLabel = true;
	                    
	                    if (vcurrentHigh > vmarginUp)
	                        vpre_swingHighType[vhighCount] = 3;
	                    else if (currentHigh < vmarginDown)
	                        vpre_swingHighType[vhighCount] = 1;
	                    else
	                        vpre_swingHighType[vhighCount] = 2;
	                    #endregion
	                }
	                #endregion

	                #region -- DW || LL --
	                else if (vaddLow || vupdateLow)
	                {
line=2040;
	                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;

	                    double vmarginDown = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) - MultiplierDTB * vavgTrueRange[vlowCount];
	                    double vmarginUp = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) + MultiplierDTB * vavgTrueRange[vlowCount];

	                    #region -- Set NEW drawing states --

	                    if (vcurrentLow < vmarginDown) vdrawLowerLowLabel = true;
	                    else if (vcurrentLow > vmarginUp) vdrawHigherLowLabel = true;
	                    else vdrawDoubleBottomLabel = true;
	                    
	                    if (vcurrentLow < vmarginDown)
	                        vpre_swingLowType[vlowCount] = -3;
	                    else if (vcurrentLow > vmarginUp)
	                        vpre_swingLowType[vlowCount] = -1;
	                    else
	                        vpre_swingLowType[vlowCount] = -2;
	                    #endregion
	                }
	                #endregion
	            }
	            #endregion
line=2065;
	            #region -- OnPriceChange or OnEachTick --
	            if (Calculate != NinjaTrader.NinjaScript.Calculate.OnBarClose)
	            {
line=2069;
	                vintraBarUpdateHigh = vupTrend[0] && (isHLBased ? High[0] : vswingInput[0]) > vcurrentHigh;
	                vintraBarUpdateLow = !vupTrend[0] && (isHLBased ? Low[0] : vswingInput[0]) < vcurrentLow;
	                vintraBarAddHigh = !vupTrend[0] && !((isHLBased ? Low[0] : vswingInput[0]) < vcurrentLow) && (isHLBased ? High[0] : vswingInput[0]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
	                vintraBarAddLow = vupTrend[0] && !((isHLBased ? High[0] : vswingInput[0]) > vcurrentHigh) && (isHLBased ? Low[0] : vswingInput[0]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

	                #region -- new HH --
	                if (vintraBarAddHigh)
	                {
line=2078;
	                    double vnewHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastLowIdx; i++)
	                    {
	                        if ((isHLBased ? High[i] : vswingInput[i]) > vnewHigh)
	                        {
	                            vnewHigh = (isHLBased ? High[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vpreCurrentHigh = vnewHigh;
	                    vpreLastHighIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- uptrend --
	                else if (vintraBarUpdateHigh)
	                {
line=2097;
	                    vpreCurrentHigh = (isHLBased ? High[0] : vswingInput[0]);
	                    vpreLastHighIdx = CurrentBar;
	                }
	                #endregion

	                #region -- new LL --
	                if (vintraBarAddLow)
	                {
line=2106;
	                    double vnewLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastHighIdx; i++)
	                    {
	                        if ((isHLBased ? Low[i] : vswingInput[i]) < vnewLow)
	                        {
	                            vnewLow = isHLBased ? Low[i] : vswingInput[i];
	                            j = i;
	                        }
	                    }
	                    vpreCurrentLow = vnewLow;
	                    vpreLastLowIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- dwtrend --
	                else if (vintraBarUpdateLow)
	                {
line=2125;
	                    vpreCurrentLow = (isHLBased ? Low[0] : vswingInput[0]);
	                    vpreLastLowIdx = CurrentBar;
	                }
	                #endregion

	                #region -- UP || HH --
	                if (vintraBarAddHigh || vintraBarUpdateHigh)
	                {
line=2134;
	                    int vprePriorHighCount = vintraBarAddHigh ? CurrentBar - vlastHighIdx : CurrentBar - vpriorSwingHighIdx;
	                    int vpreHighCount = CurrentBar - vpreLastHighIdx;
	                    int vprePriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    int vpreLowCount = CurrentBar - vlastLowIdx;

	                    #region ---- StructureBias RealTime ---
	                    double vmarginUp, vmarginDown;
	                    if (isHLBased)//ThisInputType == gztVMDivInputType.High_Low)
	                    {
	                        vmarginUp = High[vprePriorHighCount] + MultiplierDTB * vavgTrueRange[vpreHighCount];
	                        vmarginDown = High[vprePriorHighCount] - MultiplierDTB * vavgTrueRange[vpreHighCount];
	                    }
	                    else
	                    {
	                        vmarginUp = vswingInput[vprePriorHighCount] + MultiplierDTB * vavgTrueRange[vpreHighCount];
	                        vmarginDown = vswingInput[vprePriorHighCount] - MultiplierDTB * vavgTrueRange[vpreHighCount];
	                    }

	                    if (vpreCurrentHigh > vmarginUp) preSRType = 3;
	                    else if (vpreCurrentHigh < vmarginDown) preSRType = Math.Max(preSRType, 2);
	                    else preSRType = Math.Max(preSRType, 1);
	                    #endregion
	                }
	                #endregion

	                #region -- DW || LL --
	                else if (vintraBarAddLow || vintraBarUpdateLow)
	                {
line=2163;
	                    int vprePriorLowCount = vintraBarAddLow ? CurrentBar - vlastLowIdx : CurrentBar - vpriorSwingLowIdx;
	                    int vpreLowCount = CurrentBar - vpreLastLowIdx;
	                    int vprePriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    int vpreHighCount = CurrentBar - vlastHighIdx;

	                    #region ---- StructureBias RealTime ---
	                    double vmarginUp, vmarginDown;
	                    if (isHLBased)//ThisInputType == gztVMDivInputType.High_Low)
	                    {
	                        vmarginDown = Low[vprePriorLowCount] - MultiplierDTB * vavgTrueRange[vpreLowCount];
	                        vmarginUp = Low[vprePriorLowCount] + MultiplierDTB * vavgTrueRange[vpreLowCount];
	                    }
	                    else
	                    {
	                        vmarginDown = vswingInput[vprePriorLowCount] - MultiplierDTB * vavgTrueRange[vpreLowCount];
	                        vmarginUp = vswingInput[vprePriorLowCount] + MultiplierDTB * vavgTrueRange[vpreLowCount];
	                    }
	                    if (vpreCurrentLow < vmarginDown) preSRType = -3;
	                    else if (vpreCurrentLow > vmarginUp) preSRType = Math.Min(preSRType, -2);
	                    else preSRType = Math.Min(preSRType, -1);
	                    #endregion
	                }
	                #endregion
	                //Is it possible ??
	                else
	                {
	                    preSRType = 0;
	                }

	                #region ---- StructureBias RealTime ---
	                if (CurrentBar < 2) Bias[0] = FLAT;
	                else
	                {
line=2197;
	                    if (preSRType == 0) Bias[0] = Bias[1];

	                    #region -- Oscillation State --
	                    else if (Bias[1] == FLAT)
	                    {
	                        //Oscillation State
	                        //Need HH/!LL/HH to go to Up Trend
	                        //{NEW} !LL/High/!LL/HH to go to Up Trend
	                        //Need LL/!HH/LL to go to Dw Trend
	                        //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
	                        if (sequence.Count < 2) Bias[0] = FLAT;
	                        else if (sequence.Count < 3)
	                        {
	                            if (sequence[0] == 3 && sequence[1] != -3 && preSRType == 3) Bias[0] = UP;
	                            else if (sequence[0] == -3 && sequence[1] != 3 && preSRType == -3) Bias[0] = DOWN;
	                            else Bias[0] = FLAT;
	                        }
	                        else
	                        {
	                            if (sequence[1] == 3 && sequence[2] != -3 && preSRType == 3) Bias[0] = UP;
	                            else if (sequence[1] == -3 && sequence[2] != 3 && preSRType == -3) Bias[0] = DOWN;
	                            //{NEW} HL/LH/HL/HH to go to Up Trend
	                            else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && preSRType == 3) Bias[0] = UP;
	                            //{NEW} LH/HL/LH/LL to go to Up Trend
	                            else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && preSRType == -3) Bias[0] = DOWN;
	                            else Bias[0] = FLAT;
	                        }
	                    }
	                    #endregion

	                    #region -- UpTrend State --
	                    else if (Bias[1] > FLAT)
	                    {
line=2231;
	                        //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
	                        if (preSRType == -3) Bias[0] = FLAT;
	                        else Bias[0] = UP;
	                    }
	                    #endregion

	                    #region -- DwTrend State --
	                    else if (Bias[1] < FLAT)
	                    {
line=2241;
	                        //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
	                        if (preSRType == 3) Bias[0] = FLAT;
	                        else Bias[0] = DOWN;
	                    }
	                    #endregion

	                    else Bias[0] = Bias[1];
	                }
	                #endregion
	            }
	            #endregion
line=2253;
				if(upTrend[0]){
					ExtremePriceOfCurrentSwing = Math.Max(ExtremePriceOfCurrentSwing, qualifier == ARC_AuctionCurve_StructureQualifiers.OnBarClose ? Close[0]:High[0]);
				}else{
					ExtremePriceOfCurrentSwing = Math.Min(ExtremePriceOfCurrentSwing, qualifier == ARC_AuctionCurve_StructureQualifiers.OnBarClose ? Close[0]:Low[0]);
				}
//StatusMsg = StatusMsg + "\n  2623 Extreme: "+ExtremePriceOfCurrentSwing.ToString();
	            #region -- Structure BIAS --
	            SRType = vdrawHigherHighLabel ? 3 : vdrawLowerHighLabel ? 2 : vdrawDoubleTopLabel ? 1 : vdrawDoubleBottomLabel ? -1 : vdrawHigherLowLabel ? -2 : vdrawLowerLowLabel ? -3 : 0;

	            #region -- Oscillation State --
	            int decay = 0;
	            if (Calculate!= NinjaTrader.NinjaScript.Calculate.OnBarClose && State != NinjaTrader.NinjaScript.State.Historical) decay = 1;

	            if (SRType != 0 && Bias[decay + 1] == FLAT)
	            {
line=2267;
	                #region -- update sequence ---
	                //--- Same Trend --
	                if (vupTrend[1] == vupTrend[0])
	                {
	                    if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
//StatusMsg = "Sequence updated to SameTrend...SRType "+SRType+"   count:"+sequence.Count;
	                }

	                //--- Changing Trend ---
	                else if (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose && upTrend[1] != upTrend[0])
	                {
line=2274;
	                    if (sequence.Count < 4) 
							sequence.Add(SRType);
	                    else
	                    {
	                        sequence[0] = sequence[1];
	                        sequence[1] = sequence[2];
	                        sequence[2] = sequence[3];
	                        sequence[3] = SRType;
	                    }
//StatusMsg = "Sequence updated to ChangingTrend...SRType "+SRType+"   count:"+sequence.Count;
	                }
	                #region -- eachtick --
	                else if (Calculate != NinjaTrader.NinjaScript.Calculate.OnBarClose && vupTrend[1] != vupTrend[0])
	                {
line=2292;
	                    if (IsFirstTickOfBar)
	                    {
	                        if (sequence.Count < 4) sequence.Add(SRType);
	                        else
	                        {
	                            sequence[0] = sequence[1];
	                            sequence[1] = sequence[2];
	                            sequence[2] = sequence[3];
	                            sequence[3] = SRType;
	                        }
	                    }
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                #endregion
	                #endregion
line=2309;

	                //Oscillation State
	                //Need HH/!LL/HH to go to Up Trend
	                //{NEW} !LL/High/!LL/HH to go to Up Trend
	                //Need LL/!HH/LL to go to Dw Trend
	                //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
	                if (sequence.Count < 3) Bias[decay] = FLAT;
	                else if (sequence.Count < 4)
	                {
line=2319;
	                    if (sequence[0] == 3 && sequence[1] != -3 && sequence[2] == 3) Bias[decay] = UP;
	                    else if (sequence[0] == -3 && sequence[1] != 3 && sequence[2] == -3) Bias[decay] = DOWN;
	                    else Bias[decay] = FLAT;
	                }
	                else
	                {
line=2326;
	                    if (sequence[1] == 3 && sequence[2] != -3 && sequence[3] == 3) Bias[decay] = UP;
	                    else if (sequence[1] == -3 && sequence[2] != 3 && sequence[3] == -3) Bias[decay] = DOWN;
	                    //{NEW} HL/LH/HL/HH to go to Up Trend
	                    else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && sequence[3] == 3) Bias[decay] = UP;
	                    //{NEW} LH/HL/LH/LL to go to Up Trend
	                    else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && sequence[3] == -3) Bias[decay] = DOWN;
	                    else Bias[decay] = FLAT;
	                }
	            }
	            #endregion

	            #region -- UpTrend State --
	            else if (SRType != 0 && Bias[decay + 1] > FLAT)
	            {
line=2341;
	                if (IsFirstTickOfBar) sequence.Clear();
	                //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
	                if (SRType == -3)
	                {
	                    Bias[decay] = FLAT;
	                    if (IsFirstTickOfBar) sequence.Add(SRType);
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                else Bias[decay] = UP;
	            }
	            #endregion

	            #region -- DwTrend State --
	            else if (SRType != 0 && Bias[decay + 1] < FLAT)
	            {
line=2358;
	                if (IsFirstTickOfBar) sequence.Clear();
	                //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
	                if (SRType == 3)
	                {
	                    Bias[decay] = FLAT;
	                    if (IsFirstTickOfBar) sequence.Add(SRType);
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                else Bias[decay] = DOWN;
	            }
	            #endregion

				else Bias[decay] = Bias[decay + 1];
	            #endregion
line=2374;
				}catch(Exception e){StatusMsg = "---------------"+line.ToString()+":  StructureMgr\n\n"+e.ToString() + "---------------";}
#endregion
				}

			//================================================================================================
			public void UpdateSessionDate(DateTime t, double high, double low, SessionIterator sessionIterator0){
				CurrentDailyHigh = Math.Max(high, CurrentDailyHigh);
				CurrentDailyLow = Math.Min(low, CurrentDailyLow);
				DateTime currentDate = SessionDate.Date;
				if(sessionIterator0 == null)
					SessionDate = t.Date;
				else if(sessionIterator0.IsNewSession(t, true)) {
					sessionIterator0.CalculateTradingDay(t, true);
					SessionDate = sessionIterator0.ActualTradingDayExchange.Date;
				}
				if(currentDate.Day != SessionDate.Day){
					CurrentDailyHigh = high;
					CurrentDailyLow = low;
				}
			}
			//================================================================================================
			public void DeleteBrokenStructureSwings(double low, double high, double close1, ARC_AuctionCurve_StructureQualifiers qualifier){
				#region  ----- DeleteBrokenStructureSwings ----- 
				var deletes = new List<DateTime>(5);
				foreach(var kvp in StructureHigh){
					if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnTick && kvp.Value >= close1 && high >= kvp.Value)
						deletes.Add(kvp.Key);
					else if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnBarClose && close1 >= kvp.Value)
						deletes.Add(kvp.Key);
				}
				foreach(var dt in deletes) StructureHigh.Remove(dt);

				deletes.Clear();
//StatusMsg = "low: "+low.ToString()+"   Close1: "+close1.ToString()+"   "+qualifier.ToString();
				foreach(var kvp in StructureLow){
//StatusMsg = string.Format("{0}\nStruct Low at   {1}",StatusMsg,kvp.Value.ToString());
					if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnTick && kvp.Value <= close1 && low <= kvp.Value)
						deletes.Add(kvp.Key);
					else if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnBarClose && close1 <= kvp.Value)
						deletes.Add(kvp.Key);
				}
				foreach(var dt in deletes) {
//StatusMsg = string.Format("{0}\nremoving Low at {1}",StatusMsg,dt.ToString());
					StructureLow.Remove(dt);
				}

				foreach(var kvp in DailyStructureHL){
					//Remove any DailyStructure H or L that has been broken by current price action
					if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnTick){
						if(high > kvp.Value.H) DailyStructureHL[kvp.Key].H = double.MinValue;
						if(low < kvp.Value.L)  DailyStructureHL[kvp.Key].L = double.MaxValue;
					}
					else if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnBarClose){
						if(close1 > kvp.Value.H) DailyStructureHL[kvp.Key].H = double.MinValue;
						if(close1 < kvp.Value.L) DailyStructureHL[kvp.Key].L = double.MaxValue;
					}
				}
				#endregion
			}
			//================================================================================================
			public void CalculateStructureSwings(DateTime t, double close, double low, double high, double atr_qualifying_distance, ARC_AuctionCurve_StructureQualifiers qualifier){
				#region ----- CalculateStructureSwings -----
				if(AllPivots.Count<2) return;
try{
//StatusMsg = "CalculateStructureSwings "+t.ToString();
				double p0 = AllPivots[AllPivotsKeys[0]];
				double p1 = AllPivots[AllPivotsKeys[1]];
				double the_price = double.NaN;
//StatusMsg = StatusMsg +"\n ... start of CalculateStructureSwings";
				if(p0 > 0 && p0!=MostRecentStructureChangeHigh){//current swing is upward, with a defined high
//StatusMsg = string.Format("{0}\n{1}",StatusMsg,"current swing is upward, with a defined high");
					double qualifying_price = Math.Abs(p1) - atr_qualifying_distance;
//StatusMsg = StatusMsg + "\n   2816 QualifyingPrice: "+qualifying_price.ToString();
					if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnBarClose){
						if(close < qualifying_price) {
							MostRecentStructureChangeHigh = p0;
							StructureHigh[t] = p0;
							the_price = p0;
//StatusMsg = string.Format("{0}\n{1} {2}",StatusMsg,"New structure high established at ",p0);
						}
					}else if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnTick){
						if(low < qualifying_price) {
							MostRecentStructureChangeHigh = p0;
							StructureHigh[t] = p0;
							the_price = p0;
//StatusMsg = string.Format("{0}\n{1} {2}",StatusMsg,"New structure high established at ",p0);
						}
					}
					#region Update the DailyStructureHL if this high is higher than current daily structure high
					if(!DailyStructureHL.ContainsKey(SessionDate.Date))
						DailyStructureHL[SessionDate.Date] = new HLtuple(double.MinValue,double.MaxValue);
					if(!double.IsNaN(the_price))
						DailyStructureHL[SessionDate.Date].H = Math.Max(DailyStructureHL[SessionDate].H, CurrentDailyHigh);
					#endregion
				}else if(p0<0 && -p0 != MostRecentStructureChangeLow){//current swing is downward, with a defined low
//StatusMsg = string.Format("{0}\n{1}",StatusMsg,"current swing is downward, with a defined low");
					double qualifying_price = p1 + atr_qualifying_distance;
//StatusMsg = StatusMsg + "\n   2840 QualifyingPrice: "+qualifying_price.ToString();
					if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnBarClose){
						if(close > qualifying_price) {
							the_price = Math.Abs(p0);
							MostRecentStructureChangeLow = the_price;
							StructureLow[t] = the_price;
//StatusMsg = string.Format("{0}\n{1} {2}",StatusMsg,"New structure low established at ",p0);
						}
					}else if(qualifier == ARC_AuctionCurve_StructureQualifiers.OnTick){
						if(high > qualifying_price) {
							the_price = Math.Abs(p0);
							MostRecentStructureChangeLow = the_price;
							StructureLow[t] = the_price;
//StatusMsg = string.Format("{0}\n{1} {2}",StatusMsg,"New structure low established at ",p0);
						}
					}
					#region Update the DailyStructureHL if this low is lower than current daily structure low
					if(!DailyStructureHL.ContainsKey(SessionDate.Date))
						DailyStructureHL[SessionDate.Date] = new HLtuple(double.MinValue,double.MaxValue);
					if(!double.IsNaN(the_price))
						DailyStructureHL[SessionDate.Date].L = Math.Min(DailyStructureHL[SessionDate.Date].L, CurrentDailyLow);
					#endregion
				}
}catch(Exception e){StatusMsg = StatusMsg +"  "+e.ToString();}
				#endregion
//StatusMsg = StatusMsg +"\n ... exiting CalculateStructureSwings";
			}
			public double GetStructureHighAbove(double current_high){
				return GetStructureHighAbove(current_high, DateTime.MaxValue);
			}
			public double GetStructureLowBelow(double current_low){
				return GetStructureLowBelow(current_low, DateTime.MaxValue);
			}
			public double GetStructureHighAbove(double current_high, DateTime prior_to){
				var keys = (from dt in StructureHigh.Keys
					where dt<prior_to
					select dt).OrderByDescending(c => c).ToList();
				//keys is a list of dates, youngest date first
				for(int i = 0; i<keys.Count; i++){
					if(StructureHigh[keys[i]] > current_high) {
						return StructureHigh[keys[i]];
					}
				}
				return double.NaN;
			}
			public double GetStructureLowBelow(double current_low, DateTime prior_to){
				var keys = (from dt in StructureLow.Keys
					where dt<prior_to
					select dt).OrderByDescending(c => c).ToList();
				//keys is a list of dates, youngest date first
				for(int i = 0; i<keys.Count; i++)
					if(StructureLow[keys[i]] < current_low) return StructureLow[keys[i]];
				return double.NaN;
			}
			public double GetDailyStructureHL(double key_price, DateTime prior_to, char type){
				var keys = (from dt in DailyStructureHL.Keys
					where dt<prior_to
					select dt).OrderByDescending(c => c).ToList();
				if(type=='H'){
					for(int i = 0; i<keys.Count; i++){
						if(DailyStructureHL[keys[i]].H > key_price) return DailyStructureHL[keys[i]].H;
					}
				}
				else if(type=='L'){
					for(int i = 0; i<keys.Count; i++){
						if(DailyStructureHL[keys[i]].L < key_price) return DailyStructureHL[keys[i]].L;
					}
				}
				return double.NaN;
			}
			#endregion
		}

		private StructureDetectorClass StructureDetector = null;
		private class StructureDetectorClass{
			#region StructureDetector
public string Status = "";
			public const int DOWN = -1;
			public const int NONE = 0;
			public const int UP = 1;
			public SortedDictionary<int,int> OnCloseBiases = new SortedDictionary<int,int>();//abs bar num and 0=DOWN, 1=None, 2=UP
			public SortedDictionary<int,int> OnTickBiases  = new SortedDictionary<int,int>(); //abs bar num and 0=DOWN, 1=None, 2=UP
			public int OnTickBias;
			public int OnCloseBias;
			private int LastABarCalculated = 0;
			public StructureDetectorClass(){
				OnTickBias = NONE;
				OnCloseBias = NONE;
			}
			public void Update(int CurABar, double CurHigh, double CurLow, double CurClose, SortedDictionary<int,double> AllPivots){
				double current_high_pivotprice = double.MinValue;
				double current_low_pivotprice  = double.MinValue;
				#region -- calculate current swing high and swing low - exit out if both are not found --
				var keys = AllPivots.Keys.ToList();
				double swingprice = 0;
				for(int p = keys.Count-1; p>0; p--){
					swingprice = AllPivots[keys[p]];
					if(swingprice > 0) current_high_pivotprice = swingprice;
					if(swingprice < 0) current_low_pivotprice = Math.Abs(swingprice);
					if(current_high_pivotprice != double.MinValue && current_low_pivotprice != double.MinValue) break;
				}
				if(current_high_pivotprice == double.MinValue || current_low_pivotprice == double.MinValue) return;
				#endregion
				#region -- determine OnCloseBiases bias --
Status ="";
				if(OnCloseBiases.Count>0){
					keys = OnCloseBiases.Keys.ToList();
					if(!OnCloseBiases.ContainsKey(CurABar)) {
						OnCloseBiases[CurABar] = OnCloseBiases[keys[keys.Count-1]];
Status = CurABar.ToString()+": new bar, added "+OnCloseBiases[CurABar].ToString()+" to dict";
					}
Status = Status + "\nClose"+CurClose.ToString()+" current swing Low: "+current_low_pivotprice.ToString()+"  High: "+current_high_pivotprice.ToString();
					if(OnCloseBiases[CurABar] == UP){
						if(CurClose < current_low_pivotprice) OnCloseBiases[CurABar] = DOWN;
Status = Status+"\n"+CurABar.ToString()+": was 2 up, is now "+OnCloseBiases[CurABar].ToString();
					}
					else if(OnCloseBiases[CurABar] == DOWN){
						if(CurClose > current_high_pivotprice) OnCloseBiases[CurABar] = UP;
Status = Status+"\n"+CurABar.ToString()+": was 0 down, is now "+OnCloseBiases[CurABar].ToString();
					}
					else if(OnCloseBiases[CurABar] == NONE){
						if(CurClose > current_high_pivotprice) OnCloseBiases[CurABar] = UP;
						else if(CurClose < current_low_pivotprice) OnCloseBiases[CurABar] = DOWN;
Status = Status+"\n"+CurABar.ToString()+": was NONE, is now "+OnCloseBiases[CurABar].ToString();
					}
				}else{
					OnCloseBiases[CurABar] = NONE;
				}
				#endregion
				#region -- determine OnTickBiases bias --
				if(OnTickBiases.Count>0){
					keys = OnTickBiases.Keys.ToList();
					if(!OnTickBiases.ContainsKey(CurABar)) OnTickBiases[CurABar] = OnTickBiases[keys[keys.Count-1]];
					if(OnTickBiases[CurABar] == UP){
						if(CurLow < current_low_pivotprice) OnTickBiases[CurABar] = DOWN;
					}
					else if(OnTickBiases[CurABar] == DOWN){
						if(CurHigh > current_high_pivotprice) OnTickBiases[CurABar] = UP;
					}
					else if(OnTickBiases[CurABar] == NONE){
						if(CurHigh > current_high_pivotprice) OnTickBiases[CurABar] = UP;
						else if(CurLow < current_low_pivotprice) OnTickBiases[CurABar] = DOWN;
					}
				}else{
					OnTickBiases[CurABar] = NONE;
				}
				#endregion
			}
			public void CalculateBiasesAtAbsBar(int abs_bar, int CurrentBar){
				bool do_calculation = abs_bar == CurrentBar || abs_bar == this.LastABarCalculated;
				LastABarCalculated = abs_bar;
				if(!do_calculation) return;//no need to waste cpu if the calculation has already been done for this abs_bar
				bool FoundOnTickAnswer = false;
				bool FoundOnCloseAnswer = false;
				for(int barptr = abs_bar; !FoundOnTickAnswer && !FoundOnCloseAnswer && barptr>0; barptr--){
					if(!FoundOnTickAnswer && OnTickBiases.ContainsKey(barptr)) {
						OnTickBias = OnTickBiases[barptr];
						FoundOnTickAnswer = true;
					}
					if(!FoundOnCloseAnswer && OnCloseBiases.ContainsKey(barptr)) {
						OnCloseBias = OnCloseBiases[barptr];
						FoundOnCloseAnswer = true;
//Status = Status + "\n"+barptr.ToString()+": "+OnCloseBiases[barptr].ToString();
					}
				}
			}
			#endregion
		}

		private class CurveData{
			#region -- CurveData --
			public double PriceHigh;
			public double PriceLow;
			public double High;
			public double Retail;
			public double MidValue;
			public double Wholesale;
			public double Low;
			public bool IsUndefined = true;
//			public bool BorrowingYH;
//			public bool BorrowingYL;
			public CurveData(int zonecount, double high, double low, double pct0, double pct25, double pct50, double pct75, double pct100){
				Update(zonecount, high, low, pct0, pct25, pct50, pct75, pct100);
//				BorrowingYH = true;
//				BorrowingYL = true;
			}
			public void Update(int ZoneCount, double high, double low, double pct0, double pct25, double pct50, double pct75, double pct100){
				if(double.IsNaN(high) || double.IsNaN(low)){
					IsUndefined = true;
				}else{
					PriceHigh = high;
					PriceLow  = low;
					double range = PriceHigh-PriceLow;
					if(ZoneCount==4){
						High      = PriceLow + range * pct100/100.0;
						Low       = PriceLow + range * pct0/100.0; 
						Retail    = PriceLow + range * pct75/100.0;
						MidValue  = PriceLow + range * pct50/100.0;
						Wholesale = PriceLow + range * pct25/100.0;
					}else{
						High      = PriceLow + range * pct100/100.0;
						Low       = PriceLow + range * pct50/100.0; 
						Retail    = PriceLow + range * pct100/100.0;
						MidValue  = PriceLow + range * pct75/100.0;
						Wholesale = PriceLow + range * pct50/100.0;
					}
				}
			}
			#endregion
		}
        //--- curve
        private double Price100P = 0;
        private double Price0P   = 0;
//		private int pOpacity1    = 100;
        private int pButtonSpace = 6;
        private int CB    = 0;
        private double CH = 0;
        private double CL = 0;
		private CurveData DailyCurve   = new CurveData(4, double.NaN,0,0,0,0,0,0);
		private CurveData CurrentCurve = new CurveData(4, double.NaN,0,0,0,0,0,0);
		private CurveData AlternateCurve = new CurveData(4, double.NaN,0,0,0,0,0,0);
		private Series<double> dCurve1;
		private Series<double> dCurve2;
		private Series<double> dCurve3;
		private Series<double> dCurve4;
		private Series<double> dCurve5;
		private Series<double> cCurve1;
		private Series<double> cCurve2;
		private Series<double> cCurve3;
		private Series<double> cCurve4;
		private Series<double> cCurve5;
		private Series<double> aCurve1;
		private Series<double> aCurve2;
		private Series<double> aCurve3;
		private Series<double> aCurve4;
		private Series<double> aCurve5;

		#region -- ATRForecaster variables --
		private List<double> atr = new List<double>();
		private double MaxATR = 0;
		//private double MinATR = double.MaxValue;
		private double AvgATR = 0;
		private double CurHigh = 0;
		private double CurLow = double.MaxValue;
		private DateTime LaunchTime = DateTime.Now;
		private bool DeletedWarningMessage = false;
		private bool CheckedData = false;
		private DateTime TradingDay=DateTime.MinValue, PriorTradingDay = DateTime.MinValue;
		private double FixedMaxUpperPrice = 0;
		private double FixedMaxLowerPrice = 0;
		private double FixedAvgUpperPrice = 0;
		private double FixedAvgLowerPrice = 0;
		
		private Series<double> MaxUpper, MaxLower, AvgUpper, AvgLower, Mid, FMaxUpper, FMaxLower, FAvgUpper, FAvgLower;
		#endregion ----------------------------
		private DateTime currentDate = DateTime.MinValue;
		private double currentHigh = 0, currentLow=0, priorDayHigh=0, priorDayLow=0;
		private Series<double> PriorHigh;
		private Series<double> PriorLow;

        #region --- EXPOSED CURVE ---
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveD1 { get { return dCurve1; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveD2 { get { return dCurve2; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveD3 { get { return dCurve3; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveD4 { get { return dCurve4; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveD5 { get { return dCurve5; } }
#if ENABLE_CURRENTCURVE
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveC1 { get { return cCurve1; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveC2 { get { return cCurve2; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveC3 { get { return cCurve3; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveC4 { get { return cCurve4; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exCurveC5 { get { return cCurve5; } }
#endif
        #endregion

        protected override void OnStateChange()
        {
line = 3234;
			#region  ----- OnStateChange ----- 
try{
			OnStateChange_StatusMsg = string.Empty;
            #region ----- State == State.SetDefaults -----
            if (State == State.SetDefaults)
            {
				PrintTo = PrintTo.OutputTab1;
				Description             = @"Multi-timeframe fib levels with trade plans";
				Name                    = "ARC_AuctionCurve";
				Calculate               = Calculate.OnBarClose;
				IsOverlay               = true;
				PaintPriceMarkers       = false;
				DisplayInDataBox        = true;
				IsAutoScale             = false;
				ArePlotsConfigurable    = true;
				ZOrder                  = 0;
				DrawOnPricePanel        = true;
				ScaleJustification      = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive = true;
				AddPlot(new Stroke(Brushes.Transparent,	1), PlotStyle.Dot, "StructureState");
				AddPlot(new Stroke(Brushes.Transparent,	1), PlotStyle.Dot, "CurveState");
				AddPlot(new Stroke(Brushes.Transparent,	1), PlotStyle.Dot, "PermissiveSignal");

				#region -- ATRForecaster set defaults --
				ATR_period					= 14;
				LookbackDays				= 90;
				UserReqestsDataCheck = false;
				#endregion -----------------------------
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
				IsDebug = IsDebug && (NinjaTrader.Cbi.License.MachineId.CompareTo("B0D2E9D1C802E279D3678D7DE6A33CE4")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);

				if(IsDebug && false){
					AddPlot(new Stroke(Brushes.Cyan,2), PlotStyle.Dot, "DailyCurve Top");
					AddPlot(new Stroke(Brushes.Cyan,2), PlotStyle.Dot, "DailyCurve Bottom");
					AddPlot(new Stroke(Brushes.LightYellow,1), PlotStyle.Cross, "CurrentCurve Top");
					AddPlot(new Stroke(Brushes.LightYellow,1), PlotStyle.Cross, "CurrentCurve Bottom");
					AddPlot(new Stroke(Brushes.Lime,1), PlotStyle.Line, "DailyLow");
				}

				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
				#region ----- SwingTrend Defaults -----
				SwingStrength  = 3;
				isHLBased      = true;
				MultiplierMD   = 0;
				MultiplierDTB  = 0;
				ShowStructureLines  = true;
				ShowStructureBackground = false;
				UpTrendColor        = Brushes.Green;
				OpacityUpTrendBkg   = 20;
				DownTrendColor      = Brushes.Maroon;
				OpacityDownTrendBkg = 20;
				UpLineColor     = Brushes.DarkGreen;
				DownLineColor   = Brushes.Red;
				ZZLineThickness = 2;
				//pStructureLabelFontSize = 12;
				pZZlabelFont = new SimpleFont("Arial",12);
				ShowStructureLabels = false;
				#endregion

				pButtonText = "Auction Curve";
				SentimentDetectionMode        = ARC_AuctionCurve_SentimentDetectionMode.OnClose;
				SentimentDialogLoc            = ARC_AuctionCurve_SentimentDialogLoc.TopLeft;
				StructureDialogFont           = new SimpleFont("Arial",14);
				StructureDialogBkg_UpBrush    = Brushes.LimeGreen;
				StructureDialogBkg_DownBrush  = Brushes.Red;
				StructureDialogText_UpBrush   = Brushes.White;
				StructureDialogText_DownBrush = Brushes.White;
				StructureDialogBkg_UpOpacity   = 90;
				StructureDialogBkg_DownOpacity = 90;
				VerboseSentimentDialog = true;
				pSelectedCurve = ARC_AuctionCurve_CurveBasis.Structure;

				StructureQualifier  = ARC_AuctionCurve_StructureQualifiers.OnTick;
				QualifyingATRmult   = 0.0;
				QualifyingATRperiod = 13;
				MaxWidthInMargin    = 100;

				#region -- Daily Curve --
				dShowCurve = true;
				dCurveLineThickness = 2;
				dCurveLocX   = 96;
				dCurveLength = 84;
				dLineColor   = Brushes.Black;
				dPercent1    = 0;
				dPercent2    = 0;
				dPercent3    = 0;
				dPercent4    = 50;
				dPercent5    = 100;
				dZoneCount   = 2;
				cache_Percents_4zone[0] = 100;
				cache_Percents_4zone[1] = 75;
				cache_Percents_4zone[2] = 50;
				cache_Percents_2zone[0] = 100;
				cache_Percents_2zone[1] = 50;
				cache_Percents_2zone[2] = 0;
				dCurveOpacity1 = 40;
				dCurveOpacity2 = 20;
				dCurveOpacity3 = 20;
				dCurveOpacity4 = 40;
				dCurveAreaColor1 = Brushes.Green;
				dCurveAreaColor2 = Brushes.LightGreen;
				dCurveAreaColor3 = Brushes.LightCoral;
				dCurveAreaColor4 = Brushes.Red;
				//dDefiance = 170;
//				dBreakATR = 10;
				dDisplayPrice   = false;
				dDisplayPercent = false;
				dDisplayText    = true;
				dTextFont       = new SimpleFont("Arial", 12);

				MidlineThickness   = 2;
				MidlineValueColor  = Brushes.Green;
				MidlineRetailColor = Brushes.Red;
				Extend50Line = true;

				#endregion
#if ENABLE_CURRENTCURVE
				PreventVisualOverlap = true;
				#region -- Current Curve --
				cShowCurve = true;
				cCurveLineThickness = 2;
				cCurveLocX     = 87;
				cCurveLength   = 60;
				cLineColor     = Brushes.Black;
				cPercent1      = 0;
				cPercent2      = 25;
				cPercent3      = 50;
				cPercent4      = 75;
				cPercent5      = 100;
				cCurveOpacity1 = 30;
				cCurveOpacity2 = 10;
				cCurveOpacity3 = 10;
				cCurveOpacity4 = 30;
				cCurveAreaColor1 = Brushes.Green;
				cCurveAreaColor2 = Brushes.LightGreen;
				cCurveAreaColor3 = Brushes.LightCoral;
				cCurveAreaColor4 = Brushes.Red;
				//cDefiance = 170;
//				cBreakATR = 10;
				cDisplayPrice   = false;
				cDisplayPercent = false;
				cDisplayText    = true;
				cTextFont       = new SimpleFont("Arial", 12);
				#endregion
#endif
                #region -- Indicator Display --
                //iButtonSize = 13;
                //iButtonTextSize = 10;
                #endregion

            }
            #endregion

            #region ----- State == State.Configure ----- 
            if (State == State.Configure)
            {
				SetZOrder(int.MaxValue-1);
				Calculate = Calculate.OnBarClose;
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				AddDataSeries(Data.BarsPeriodType.Minute, 1440);
                MM = new MouseManager();
			}
            #endregion

line = 3153;
            #region  ----- State == State.Historical ----- 
            if (State == State.Historical)
            {
                sessionIterator0 = new SessionIterator(BarsArray[0]);
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;
                        
                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

                            addACToolBar();
                            
                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

//                            ChartPanel.KeyUp += ChartPanel_KeyUp;
//                            ChartPanel.MouseUp += ChartPanel_MouseUp;
//                            ChartPanel.MouseMove += ChartPanel_MouseMove;
//                            ChartPanel.MouseDown += ChartPanel_MouseDown;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion
            }
            #endregion

            #region  ----- State == State.DataLoaded ----- 
            if (State == State.DataLoaded)
            {
				theATR = ATR(BarsArray[1], this.ATR_period);
				StructureMgr = new StructureBiasClass(this, Highs[0], Lows[0], Closes[0], SwingStrength, isHLBased, MultiplierMD, MultiplierDTB, UpTrendColor, OpacityUpTrendBkg, DownTrendColor, OpacityDownTrendBkg);
				StructureDetector = new StructureDetectorClass();
				dCurve1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				dCurve2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				dCurve3 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				dCurve4 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				dCurve5 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				aCurve1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				aCurve2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				aCurve3 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				aCurve4 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				aCurve5 = new Series<double>(this, MaximumBarsLookBack.Infinite);
#if ENABLE_CURRENTCURVE
				cCurve1 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				cCurve2 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				cCurve3 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				cCurve4 = new Series<double>(this, MaximumBarsLookBack.Infinite);
				cCurve5 = new Series<double>(this, MaximumBarsLookBack.Infinite);
#endif
				PriorHigh = new Series<double>(this, MaximumBarsLookBack.Infinite);
				PriorLow = new Series<double>(this, MaximumBarsLookBack.Infinite);
				MaxUpper  = new Series<double>(this);
				MaxLower  = new Series<double>(this);
				AvgUpper  = new Series<double>(this);
				AvgLower  = new Series<double>(this);
				Mid       = new Series<double>(this);
				FMaxUpper = new Series<double>(this);
				FMaxLower = new Series<double>(this);
				FAvgUpper = new Series<double>(this);
				FAvgLower = new Series<double>(this);
            }
            #endregion

            #region  ----- State == State.Realtime ----- 
            if (State == State.Realtime)
            {
            }
            #endregion
			
            #region  ----- State == State.Terminated ----- 
            if(State == State.Terminated)
            {
line=3066;
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
//                if (this.ChartControl != null)
//                {
//                    ChartPanel.KeyUp -= ChartPanel_KeyUp;
//                    ChartPanel.MouseUp -= ChartPanel_MouseUp;
//                    ChartPanel.MouseMove -= ChartPanel_MouseMove;
//                    ChartPanel.MouseDown -= ChartPanel_MouseDown;
//                }
            }
            #endregion
}catch(Exception e){
	OnStateChange_StatusMsg = string.Format("{0}:  OnStateChange: \n{1}", line, e.ToString());
	Print(OnStateChange_StatusMsg);
	Draw.TextFixed(this,"InitError","ARC_AuctionCurve\n\nError during initialization...are you connected to your active datafeed?\n\nSee OutputWindow for more details", TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Maroon,Brushes.Maroon,80);
}
            #endregion
        }
		//====================================================
		#region  ----- TabSelectionChangedHandler ----- 
		private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}
		#endregion

		#region -- ATRForecaster supporting methods --
		//=====================================================================================
		private double Round2Tick(double p){ 
			long pi = 0;
			try{
				pi = Convert.ToInt64(p/TickSize); return Convert.ToDouble(pi)*TickSize;
			}catch{}
			return p;
		}
		//=====================================================================================
        protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
        {
            if (BarsInProgress == 1)
                return;
			if(!DeletedWarningMessage && UserReqestsDataCheck){
				var ts = new TimeSpan(DateTime.Now.Ticks - LaunchTime.Ticks);
				if(ts.TotalSeconds>10){
					RemoveDrawObject("shortdata");
					DeletedWarningMessage = true;
				}
			}
		}
		#endregion -----------------------------------

		protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
line=3517;
try{

			if (!Data.BarsType.CreateInstance(Bars.BarsPeriod.BarsPeriodType).IsIntraday) return;
//			if (generalError) return;

			StructureState[0]   = FLAT;
			CurveState[0]       = FLAT;
			PermissiveSignal[0] = FLAT;

			if(BarsInProgress == 0 && CurrentBar>3){
line=3528;
				StructureMgr.CalculateIt(CurrentBar, Close, IsFirstTickOfBar, Calculate, State, ATR(256)[0], StructureQualifier);
				if(ShowStructureBackground){
					#region -- Set BackBrushes based on StructureBias --
					if(this.OpacityUpTrendBkg>0 && UpTrendColor != Brushes.Transparent && StructureMgr.Bias[0] == UP){
						BackBrushes[0] = StructureMgr.UpTrendColorTinted;
					}
					if(this.OpacityDownTrendBkg>0 && DownTrendColor != Brushes.Transparent && StructureMgr.Bias[0] == DOWN){
						BackBrushes[0] = StructureMgr.DownTrendColorTinted;
					}
					#endregion
				}

line=3541;
				#region -- Update StructureMgr data --
				if(UseSessionDate)
					StructureMgr.UpdateSessionDate(Time[0], High[0], Low[0], sessionIterator0);
				else
					StructureMgr.UpdateSessionDate(Time[0], High[0], Low[0], null);
				StructureMgr.DeleteBrokenStructureSwings(Low[0], High[0], Close[1], this.StructureQualifier);
				StructureMgr.CalculateStructureSwings(Time[0], Close[0], Low[0], High[0], ATR(QualifyingATRperiod)[0] * QualifyingATRmult, this.StructureQualifier);
				
//Print("Plots length: "+Plots.Length);
				#endregion

				#region -- Update StructureDetector data and biases -- 
				if(StructureMgr.AllPivots.Count>2){
					StructureDetector.Update(CurrentBars[0], High[0], Low[0], Close[0], StructureMgr.AllPivots);
					StructureDetector.CalculateBiasesAtAbsBar(CurrentBars[0], CurrentBars[0]);
					if(SentimentDetectionMode == ARC_AuctionCurve_SentimentDetectionMode.OnClose)
						StructureState[0] = (StructureDetector.OnCloseBias);
					else
						StructureState[0] = (StructureDetector.OnTickBias);
//Print(Time[0].ToString()+":    "+StructureState[0]);
				}
				#endregion

				#region If developer is running this code, print a dot on each structure low and high
				if(IsDebug && false){
					var kk = StructureMgr.StructureHigh.Keys.ToList();
					kk.Reverse();
					for(int k = 0; k < StructureMgr.StructureHigh.Count; k++){
						Draw.Dot(this,kk[k].ToString()+" Hs",false,kk[k],StructureMgr.StructureHigh[kk[k]],Brushes.Blue);
					}
					kk = StructureMgr.StructureLow.Keys.ToList();
					kk.Reverse();
					for(int k = 0; k < StructureMgr.StructureLow.Count; k++){
						Draw.Dot(this,kk[k].ToString()+" Ls",false,kk[k],StructureMgr.StructureLow[kk[k]],Brushes.Red);
					}
				}
				#endregion

				if(BarsInProgress==0) {
//				calculate current structure high/low, and determine top and bottom of the DailyCurve graphic
line=3583;
					double cs_high = 0;//"cs" is current structure...structure formed on the current day
					double cs_low  = 0;
					if(StructureQualifier == ARC_AuctionCurve_StructureQualifiers.OnBarClose){
						cs_high = StructureMgr.GetStructureHighAbove(Math.Max(StructureMgr.ExtremePriceOfCurrentSwing, Close[0]));
						cs_low  = StructureMgr.GetStructureLowBelow(Math.Min(StructureMgr.ExtremePriceOfCurrentSwing, Close[0]));
					}else{
						cs_high = StructureMgr.GetStructureHighAbove(Math.Max(StructureMgr.ExtremePriceOfCurrentSwing, High[0]));
						cs_low  = StructureMgr.GetStructureLowBelow(Math.Min(StructureMgr.ExtremePriceOfCurrentSwing, Low[0]));
					}
						
					double maxhigh = double.MinValue;
					double minlow  = double.MaxValue;
					if(!double.IsNaN(cs_high) && !double.IsNaN(cs_low)){
						CurrentCurve.Update(4, cs_high, cs_low, cPercent1, cPercent2, cPercent3, cPercent4, cPercent5);
						CurrentCurve.IsUndefined = false;
					}else{
						CurrentCurve.IsUndefined = true;
					}

line=3603;
					double ds_high = 0;//"ds" is daily structure...daily-termed structure formed on the highest and lowest structure of previous days
					double ds_low  = 0;
					if(StructureQualifier == ARC_AuctionCurve_StructureQualifiers.OnBarClose){
						ds_high = StructureMgr.GetDailyStructureHL(Math.Max(StructureMgr.ExtremePriceOfCurrentSwing, Close[0]), Time[0], 'H');
						ds_low  = StructureMgr.GetDailyStructureHL(Math.Min(StructureMgr.ExtremePriceOfCurrentSwing, Close[0]), Time[0], 'L');
					}else{
						ds_high = StructureMgr.GetDailyStructureHL(Math.Max(StructureMgr.ExtremePriceOfCurrentSwing, High[0]), Time[0], 'H');
						ds_low  = StructureMgr.GetDailyStructureHL(Math.Min(StructureMgr.ExtremePriceOfCurrentSwing, Low[0]), Time[0], 'L');
					}
//if(Time[0].Day>=11) {
//	try{
//	Draw.Dot(this, CurrentBars[0].ToString()+"H",false,0,StructureMgr.DailyStructureHL[StructureMgr.SessionDate].H,Brushes.Yellow);
//	Draw.Dot(this, CurrentBars[0].ToString()+"L",false,0,StructureMgr.DailyStructureHL[StructureMgr.SessionDate].L,Brushes.White);
//	}catch{}
//}
					if(!double.IsNaN(cs_high) && !double.IsNaN(cs_low) && StructureMgr.DailyStructureHL.ContainsKey(StructureMgr.SessionDate)){
line=3616;
						//current day structure is in place today, so it will be a defined daily curve, just check the prior days structure high and low to see if they are beyond the current day structure high and low
						maxhigh = ds_high;
						//if(!double.IsNaN(ds_high)) maxhigh = Math.Max(ds_high,cs_high); //commented out for v1.4
						if(StructureMgr.DailyStructureHL[StructureMgr.SessionDate].H == StructureMgr.CurrentDailyHigh) maxhigh=StructureMgr.DailyStructureHL[StructureMgr.SessionDate].H;
						minlow  = ds_low;
						//if(!double.IsNaN(ds_low)) minlow = Math.Min(ds_low,cs_low);//commented out for v1.4
						if(StructureMgr.DailyStructureHL[StructureMgr.SessionDate].L == StructureMgr.CurrentDailyLow) minlow=StructureMgr.DailyStructureHL[StructureMgr.SessionDate].L;
//if(Time[0].Day>=11) {
//	Print(Time[0].ToString()+"  ds_low: "+ds_high.ToString()+"   DailyStructureHL.L: "+StructureMgr.DailyStructureHL[StructureMgr.SessionDate].L);
//}
//Print(string.Format("3621:\n    P1:{0} P2:{1} P3:{2} P4:{3} P5:{4}",dPercent1, dPercent2, dPercent3, dPercent4, dPercent5));
						DailyCurve.Update(pdZoneCount, maxhigh, minlow, dPercent1, dPercent2, dPercent3, dPercent4, dPercent5);
						DailyCurve.IsUndefined = false;

					} else if(double.IsNaN(cs_high) && double.IsNaN(cs_low)){
line=3626;
						//current structure is NOT place today for either high or low, so if prior day structure is in place, then it will be a defined daily curve
						maxhigh = ds_high;
						minlow  = ds_low;
						if(double.IsNaN(ds_high) || double.IsNaN(ds_low)){
							//neither daily structure high or low are defined, invalid curve
							DailyCurve.IsUndefined = true;
						}else{
							DailyCurve.Update(pdZoneCount, maxhigh, minlow, dPercent1, dPercent2, dPercent3, dPercent4, dPercent5);
							DailyCurve.IsUndefined = false;
						}

					} else if(double.IsNaN(cs_high) && !double.IsNaN(cs_low)){
line=3639;
						//current structure high is NOT place today, so if prior day structure is in place, then it will be a defined daily curve
						if(double.IsNaN(ds_high)){
							//neither current or daily structure high are defined, invalid curve
							DailyCurve.IsUndefined = true;
						}else{
							maxhigh = ds_high;
							minlow  = Math.Min(ds_low,cs_low);
							DailyCurve.Update(pdZoneCount, maxhigh, minlow, dPercent1, dPercent2, dPercent3, dPercent4, dPercent5);
							DailyCurve.IsUndefined = false;
						}
						
					} else if(!double.IsNaN(cs_high) && double.IsNaN(cs_low)){
line=3652;
//Print(Time[0].ToString()+"  2627");
						//current structure low is NOT place today, so if prior day structure is in place, then it will be a defined daily curve
						if(double.IsNaN(ds_low)){
							//neither current or daily structure low are defined, invalid curve
							DailyCurve.IsUndefined = true;
						}else{
							minlow  = ds_low;
							maxhigh = Math.Max(ds_high,cs_high);
							DailyCurve.Update(pdZoneCount, maxhigh, minlow, dPercent1, dPercent2, dPercent3, dPercent4, dPercent5);
							DailyCurve.IsUndefined = false;
						}
					}
				}
				#region -- PriorDay HL --
				if(BarsInProgress == 0){
					if (!Bars.BarsType.IsIntraday){
						currentHigh = Highs[0][0];
						currentLow = Lows[0][0];
					}

					// If the current data is not the same date as the current bar then its a new session
					if (currentDate != sessionIterator0.GetTradingDay(Time[0]))
					{
						// The current day OHLC values are now the prior days value so set
						// them to their respect indicator series for plotting
						priorDayHigh	= currentHigh;
						priorDayLow		= currentLow;

						PriorHigh[0]	= priorDayHigh;
						PriorLow[0]		= priorDayLow;

						// Initilize the current day settings to the new days data
						currentHigh 	=	Highs[0][0];
						currentLow		=	Lows[0][0];

						currentDate 	=	sessionIterator0.GetTradingDay(Times[0][0]);
					}
					else // The current day is the same day
					{
						// Set the current day OHLC values
						currentHigh 	=	Math.Max(currentHigh, Highs[0][0]);
						currentLow		=	Math.Min(currentLow, Lows[0][0]);

						PriorHigh[0] = priorDayHigh;
						PriorLow[0] = priorDayLow;
					}
				}
				#endregion --------------
			}
			#region -- ATRForecaster calculation --
			if(CurrentBars[0] > BarsArray[0].Count-5 && !CheckedData && UserReqestsDataCheck){
				CheckedData = true;
				int shortage = (LookbackDays + ATR_period - atr.Count);
				//Print("Shortage: "+shortage);
				if(shortage>1) 
					Draw.TextFixed(this, "shortdata","'AuctionCurve' needs approx "+(LookbackDays + ATR_period - atr.Count)+"-more days of historical data\n\n\n.",TextPosition.BottomLeft);
				else if(shortage==1) 
					Draw.TextFixed(this, "shortdata","'AuctionCurve' needs at least 1 more day of historical data\n\n\n.",TextPosition.BottomLeft);
			}
//var inzone = Time[0].Hour==11 && Time[0].Day==31 && Time[0].Minute==12;
			if(BarsInProgress==1) {
				atr.Add( theATR[0]);
				while(atr.Count > this.LookbackDays + ATR_period) atr.RemoveAt(0);
//Print(Times[1][0].ToString()+"  Last ATR: "+atr.Last());
				MaxATR = double.MinValue;
				//MinATR = double.MaxValue;
//				for(int i = 0; i<Math.Min(LookbackDays, atr.Count); i++){
//					MaxATR = Math.Max(atr[atr.Count-1-i], MaxATR);
//Print("   atr[atr.Count-1-i: "+atr[atr.Count-1-i]+"   MaxATR: "+MaxATR);
					//MinATR = Math.Min(atr[atr.Count-1-i], MinATR);
//				}
				AvgATR = atr.Average();
				MaxATR = atr.Max();
//Print(Times[1][0].ToString()+"   MaxATR: "+MaxATR);Av
				return;
			}
			if(BarsInProgress == 0){
				sessionIterator0.CalculateTradingDay(Times[0][0],true);
				PriorTradingDay = TradingDay;
				TradingDay = sessionIterator0.GetTradingDay(Times[0][0]);
				bool isNewSession = (TradingDay != PriorTradingDay);
//if(inzone)Print(Time[0].ToString());
				if(isNewSession){
//if(CurrentBars[0]>2)Draw.Dot(this,"EOS"+Times[0][0].ToString(), false,0,Opens[0][0], Brushes.Red);
					CurHigh = Highs[0][0];
					CurLow  = Lows[0][0];
					double ATRAvgDistance   = Round2Tick(AvgATR/2.0);
//					this.FixedAvgUpperPrice = (CurHigh+CurLow)/2.0 + ATRAvgDistance;
//					this.FixedAvgLowerPrice = (CurHigh+CurLow)/2.0 - ATRAvgDistance;
					this.FixedAvgUpperPrice = Opens[0][0]+ATRAvgDistance;
					this.FixedAvgLowerPrice = Opens[0][0]-ATRAvgDistance;
					double ATRMaxDistance   = Round2Tick(MaxATR/2.0);
//					this.FixedMaxUpperPrice = (CurHigh+CurLow)/2.0 + ATRMaxDistance;
//					this.FixedMaxLowerPrice = (CurHigh+CurLow)/2.0 - ATRMaxDistance;
					this.FixedMaxUpperPrice = Opens[0][0]+ATRMaxDistance;
					this.FixedMaxLowerPrice = Opens[0][0]-ATRMaxDistance;
					//BackBrush = Brushes.Yellow;
					//Draw.Dot(this,TradingDay.ToString(),false,0,Low[0],Brushes.Yellow);
				}else{
					CurHigh = Math.Max(CurHigh, Highs[0][0]);
					CurLow  = Math.Min(CurLow, Lows[0][0]);
				}
//if(inzone)Print(4296);
				Mid[0] = (CurHigh + CurLow)/2.0;
				AlternateCurve.IsUndefined = false;
				if(this.pShowDynamicLevels){
					#region -- Dynamic levels --
					MaxUpper[0] = Round2Tick(Mid[0] + MaxATR/2.0);
					MaxLower[0] = Round2Tick(Mid[0] - MaxATR/2.0);
//if(inzone)Print("MaxUpper: "+MaxUpper[0]+"  MaxLower: "+MaxLower[0]);
					double maxhigh = Math.Max(PriorHigh[0], MaxUpper[0]);
					double minlow = Math.Min(PriorLow[0], MaxLower[0]);
					AlternateCurve.Update(pdZoneCount, maxhigh, minlow, dPercent1, dPercent2, dPercent3, dPercent4, dPercent5);
					AvgUpper[0] = Round2Tick(Mid[0] + AvgATR/2.0);
					AvgLower[0] = Round2Tick(Mid[0] - AvgATR/2.0);
					#endregion
				}
				if(this.pShowFixedLevels){
//if(inzone)Print(4310);
					FMaxUpper[0] = FixedMaxUpperPrice;
					FMaxLower[0] = FixedMaxLowerPrice;
					double maxhigh = Math.Max(PriorHigh[0], FMaxUpper[0]);
					double minlow = Math.Min(PriorLow[0], FMaxLower[0]);
					AlternateCurve.Update(pdZoneCount, maxhigh, minlow, dPercent1, dPercent2, dPercent3, dPercent4, dPercent5);
//if(IsDebug && Time[0].Day==30 && Time[0].Hour==7 && Time[0].Minute==0)
//	Print("ACurve:  PriorLow[0]: "+PriorLow[0]+"  FMaxLower[0]: "+FMaxLower[0]+"   "+MaxATR);

					FAvgUpper[0] = FixedAvgUpperPrice;
					FAvgLower[0] = FixedAvgLowerPrice;
				}
				if(AlternateCurve!=null && !AlternateCurve.IsUndefined){
					aCurve1[0] = AlternateCurve.High;
					aCurve2[0] = AlternateCurve.Retail;
					aCurve3[0] = AlternateCurve.MidValue;
					aCurve4[0] = AlternateCurve.Wholesale;
					aCurve5[0] = AlternateCurve.Low;
					if(pSelectedCurve == ARC_AuctionCurve_CurveBasis.ATR_HL){
						CurveState[0] = 0;
						if(this.dZoneCount==4){
							if(Close[0] > AlternateCurve.Retail)         CurveState[0] = 2;
							else if(Close[0] > AlternateCurve.MidValue)  CurveState[0] = 1;
							else if(Close[0] > AlternateCurve.Wholesale) CurveState[0] = -1;
							else if(Close[0] > AlternateCurve.Low)       CurveState[0] = -2;
	//						Print(Time[0].ToString()+"   CurveState: "+CurveState[0]);
						}else if(this.dZoneCount==2){
							if(Close[0] > AlternateCurve.MidValue) CurveState[0] = 1;
							if(Close[0] < AlternateCurve.MidValue) CurveState[0] = -1;
//if(Time[0].Day==14 && Time[0].Hour==2 && Time[0].Minute==20) Print(Time[0].ToString()+"   CurveState: "+CurveState[0]+"   AltCurve.Midvalue: "+DailyCurve.MidValue);
						}
					}
				}
			}
			#endregion -------------------------------
//if(inzone)Print("4343  BIP: "+BarsInProgress);

line=3667;
			if(BarsInProgress==0 && CurrentBars[0]>3){
				#region Update daily and current curve dataseries
//if(inzone) Print(Time[0].ToString()+"  DailyCurve Undefined: "+DailyCurve.IsUndefined.ToString());
				if(DailyCurve!=null && !DailyCurve.IsUndefined){
					dCurve1[0] = DailyCurve.High;
					dCurve2[0] = DailyCurve.Retail;
					dCurve3[0] = DailyCurve.MidValue;
					dCurve4[0] = DailyCurve.Wholesale;
					dCurve5[0] = DailyCurve.Low;
					if(pSelectedCurve == ARC_AuctionCurve_CurveBasis.Structure){
						CurveState[0] = 0;
						if(this.dZoneCount==4){
							if(Close[0] > DailyCurve.Retail)         CurveState[0] = 2;
							else if(Close[0] > DailyCurve.MidValue)  CurveState[0] = 1;
							else if(Close[0] > DailyCurve.Wholesale) CurveState[0] = -1;
							else if(Close[0] > DailyCurve.Low)       CurveState[0] = -2;
//if(inzone) Print(Time[0].ToString()+"   CurveState: "+CurveState[0]);
						}else if(this.dZoneCount==2){
							if(Close[0] > DailyCurve.MidValue) CurveState[0] = 1;
							if(Close[0] < DailyCurve.MidValue) CurveState[0] = -1;
	//Print(Time[0].ToString()+"   CurveState: "+CurveState[0]+"   DailyCurve.Midvalue: "+DailyCurve.MidValue);
						}
					}
//if(IsDebug){
//	if(CurveState[0]>0) BackBrushes[0] = Brushes.Maroon;
//	if(CurveState[0]<0) BackBrushes[0] = Brushes.DarkGreen;
//}
				}else{
					dCurve1.Reset();
					dCurve2.Reset();
					dCurve3.Reset();
					dCurve4.Reset();
					dCurve5.Reset();
				}
//if(inzone)Print(4380);
#if ENABLE_CURRENTCURVE
				#region current curve
				if(CurrentCurve!=null && !CurrentCurve.IsUndefined){
					cCurve1[0] = CurrentCurve.High;
					cCurve2[0] = CurrentCurve.Retail;
					cCurve3[0] = CurrentCurve.MidValue;
					cCurve4[0] = CurrentCurve.Wholesale;
					cCurve5[0] = CurrentCurve.Low;
				}else{
					cCurve1.Reset();
					cCurve2.Reset();
					cCurve3.Reset();
					cCurve4.Reset();
					cCurve5.Reset();
				}
				#endregion
#endif
				#endregion
				if(StructureState[0] == StructureDetectorClass.UP && CurveState[0]<0)
					PermissiveSignal[0] = CONSERVATIVE_UP;
				else if(StructureState[0] == StructureDetectorClass.DOWN && CurveState[0]>0)
					PermissiveSignal[0] = CONSERVATIVE_DOWN;
				else if(StructureState[0] == StructureDetectorClass.DOWN && CurveState[0]<0)
					PermissiveSignal[0] = AGGRESSIVE_UP;
				else if(StructureState[0] == StructureDetectorClass.UP && CurveState[0]>0)
					PermissiveSignal[0] = AGGRESSIVE_DOWN;
//Print(Time[0].ToString()+"   Permissive: "+PermissiveSignal[0]);
				if(Plots.Length>3){
					Values[3][0] = dCurve1[0];
					Values[4][0] = dCurve5[0];
					Values[5][0] = StructureMgr.CurrentDailyLow;
#if ENABLE_CURRENTCURVE
					Values[5][0] = cCurve1[0];
					Values[6][0] = cCurve5[0];
					Values[7][0] = StructureMgr.CurrentDailyLow;
#endif
				}
			}
//if(inzone)Print(4419);
//Print("Panel: "+this.Panel+"  CB: "+CurrentBars[0]+"   Bars.Count: "+Bars.Count);
if(IsDebug && CurrentBars[0] > Bars.Count-50){
	string s=null;
	if(this.Panel==0){
		s = string.Format("{0} is on MarketAnalyzer\t{1}-bars\t{2}-zones\t{3} midline price\tCurveState: {4}",
							Instrument.MasterInstrument.Name,
							Bars.Count,
							this.pdZoneCount,
							Instrument.MasterInstrument.FormatPrice(DailyCurve.MidValue),
							CurveState[0]);
	}else if(this.Panel==-1){
		s = string.Format("{0} is on chart\t{1}-bars\t{2}-zones\t{3} midline price\tCurveState: {4}",
							Instrument.MasterInstrument.Name,
							Bars.Count,
							this.pdZoneCount,
							Instrument.MasterInstrument.FormatPrice(DailyCurve.MidValue),
							CurveState[0]);
	}else if(this.Panel>0){
		s = string.Format("{0} is on subpanel\t{1}-bars\t{2}-zones\t{3} midline price\tCurveState: {4}",
							Instrument.MasterInstrument.Name,
							Bars.Count,
							this.pdZoneCount,
							Instrument.MasterInstrument.FormatPrice(DailyCurve.MidValue),
							CurveState[0]);
	}
	//if(s!=null && IsDebug) Print(s);
}
}catch(Exception obue){Print(line+":  "+obue.ToString());}
        }
//=======================================================================================================================


		SharpDX.Direct2D1.Brush lineBrushUp, lineBrushDown = null;
//=======================================================================================================================
		public override void OnRenderTargetChanged()
		{
			#region -- OnRenderTargetChanged --
			if(dCurveAreaDXBrush1!=null && !dCurveAreaDXBrush1.IsDisposed)   dCurveAreaDXBrush1.Dispose();   dCurveAreaDXBrush1   = null;
			if(RenderTarget!=null){
				dCurveAreaDXBrush1 = dCurveAreaColor1.ToDxBrush(RenderTarget);
				dCurveAreaDXBrush1.Opacity = dCurveOpacity1/100f;
			}
			if(dCurveAreaDXBrush2!=null && !dCurveAreaDXBrush2.IsDisposed)   dCurveAreaDXBrush2.Dispose();   dCurveAreaDXBrush2   = null;
			if(RenderTarget!=null){
				dCurveAreaDXBrush2 = dCurveAreaColor2.ToDxBrush(RenderTarget);
				dCurveAreaDXBrush2.Opacity = dCurveOpacity2/100f;
			}
			if(dCurveAreaDXBrush3!=null && !dCurveAreaDXBrush3.IsDisposed)   dCurveAreaDXBrush3.Dispose();   dCurveAreaDXBrush3   = null;
			if(RenderTarget!=null){
				dCurveAreaDXBrush3 = dCurveAreaColor3.ToDxBrush(RenderTarget);
				dCurveAreaDXBrush3.Opacity = dCurveOpacity3/100f;
			}
			if(dCurveAreaDXBrush4!=null && !dCurveAreaDXBrush4.IsDisposed)   dCurveAreaDXBrush4.Dispose();   dCurveAreaDXBrush4   = null;
			if(RenderTarget!=null){
				dCurveAreaDXBrush4 = dCurveAreaColor4.ToDxBrush(RenderTarget);
				dCurveAreaDXBrush4.Opacity = dCurveOpacity4/100f;
			}
			if(dLineDXBrush!=null && !dLineDXBrush.IsDisposed)   dLineDXBrush.Dispose();   dLineDXBrush   = null;
			if(RenderTarget!=null){
				dLineDXBrush = dLineColor.ToDxBrush(RenderTarget);
			}
			if(cCurveAreaDXBrush1!=null && !cCurveAreaDXBrush1.IsDisposed)   cCurveAreaDXBrush1.Dispose();   cCurveAreaDXBrush1   = null;
			if(RenderTarget!=null){
				cCurveAreaDXBrush1 = cCurveAreaColor1.ToDxBrush(RenderTarget);
				cCurveAreaDXBrush1.Opacity = cCurveOpacity1/100f;
			}
			if(cCurveAreaDXBrush2!=null && !cCurveAreaDXBrush2.IsDisposed)   cCurveAreaDXBrush2.Dispose();   cCurveAreaDXBrush2   = null;
			if(RenderTarget!=null){
				cCurveAreaDXBrush2 = cCurveAreaColor2.ToDxBrush(RenderTarget);
				cCurveAreaDXBrush2.Opacity = cCurveOpacity2/100f;
			}
			if(cCurveAreaDXBrush3!=null && !cCurveAreaDXBrush3.IsDisposed)   cCurveAreaDXBrush3.Dispose();   cCurveAreaDXBrush3   = null;
			if(RenderTarget!=null){
				cCurveAreaDXBrush3 = cCurveAreaColor3.ToDxBrush(RenderTarget);
				cCurveAreaDXBrush3.Opacity = cCurveOpacity3/100f;
			}
			if(cCurveAreaDXBrush4!=null && !cCurveAreaDXBrush4.IsDisposed)   cCurveAreaDXBrush4.Dispose();   cCurveAreaDXBrush4   = null;
			if(RenderTarget!=null){
				cCurveAreaDXBrush4 = cCurveAreaColor4.ToDxBrush(RenderTarget);
				cCurveAreaDXBrush4.Opacity = cCurveOpacity4/100f;
			}
			if(cLineDXBrush!=null && !cLineDXBrush.IsDisposed)   cLineDXBrush.Dispose();   cLineDXBrush   = null;
			if(RenderTarget!=null){
				cLineDXBrush = cLineColor.ToDxBrush(RenderTarget);
			}
			if(ButtonPenDXBrush!=null && !ButtonPenDXBrush.IsDisposed)   ButtonPenDXBrush.Dispose();   ButtonPenDXBrush   = null;
			if(RenderTarget!=null){
				ButtonPenDXBrush = ButtonBrush.ToDxBrush(RenderTarget);
			}
			if(MidlineDXBrush_Value!=null && !MidlineDXBrush_Value.IsDisposed)   MidlineDXBrush_Value.Dispose();   MidlineDXBrush_Value   = null;
			if(RenderTarget!=null){
				MidlineDXBrush_Value = MidlineValueColor.ToDxBrush(RenderTarget);
			}
			if(MidlineDXBrush_Retail!=null && !MidlineDXBrush_Retail.IsDisposed)   MidlineDXBrush_Retail.Dispose();   MidlineDXBrush_Retail   = null;
			if(RenderTarget!=null){
				MidlineDXBrush_Retail = MidlineRetailColor.ToDxBrush(RenderTarget);
			}
			if(lineBrushUp!=null && !lineBrushUp.IsDisposed)   lineBrushUp.Dispose();   lineBrushUp   = null;
			if(RenderTarget!=null){
				lineBrushUp = UpLineColor.ToDxBrush(RenderTarget);
			}
			if(lineBrushDown!=null && !lineBrushDown.IsDisposed)   lineBrushDown.Dispose();   lineBrushDown   = null;
			if(RenderTarget!=null){
				lineBrushDown = DownLineColor.ToDxBrush(RenderTarget);
			}
			#endregion
		}
//=======================================================================================================================
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
            #region -- conditions to return --
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (Bars == null || ChartControl == null) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
			//if (IsInHitTest) return;
            #endregion
line=4597;

			#region ----- Init DX Brushes -----
//			var fillbrush = Brushes.White.ToDxBrush(RenderTarget);
//			dCurveAreaDXBrush1 = this..ToDxBrush(RenderTarget);
//			dCurveAreaDXBrush2 = this.dCurveAreaColor2.ToDxBrush(RenderTarget);
//			dCurveAreaDXBrush3 = this.dCurveAreaColor3.ToDxBrush(RenderTarget);
//			dCurveAreaDXBrush4 = this.dCurveAreaColor4.ToDxBrush(RenderTarget);
//			dCurveAreaDXBrush1.Opacity = dCurveOpacity1/100f;
//			dCurveAreaDXBrush2.Opacity = dCurveOpacity2/100f;
//			dCurveAreaDXBrush3.Opacity = dCurveOpacity3/100f;
//			dCurveAreaDXBrush4.Opacity = dCurveOpacity4/100f;
//			dLineDXBrush = this.dLineColor.ToDxBrush(RenderTarget);
//			cCurveAreaDXBrush1 = this.cCurveAreaColor1.ToDxBrush(RenderTarget);
//			cCurveAreaDXBrush2 = this.cCurveAreaColor2.ToDxBrush(RenderTarget);
//			cCurveAreaDXBrush3 = this.cCurveAreaColor3.ToDxBrush(RenderTarget);
//			cCurveAreaDXBrush4 = this.cCurveAreaColor4.ToDxBrush(RenderTarget);
//			cCurveAreaDXBrush1.Opacity = cCurveOpacity1/100f;
//			cCurveAreaDXBrush2.Opacity = cCurveOpacity2/100f;
//			cCurveAreaDXBrush3.Opacity = cCurveOpacity3/100f;
//			cCurveAreaDXBrush4.Opacity = cCurveOpacity4/100f;
//			cLineDXBrush = this.cLineColor.ToDxBrush(RenderTarget);
//			ButtonPenDXBrush = this.ButtonBrush.ToDxBrush(RenderTarget);
//			MidlineDXBrush_Value = MidlineValueColor.ToDxBrush(RenderTarget);
//			MidlineDXBrush_Retail = MidlineRetailColor.ToDxBrush(RenderTarget);
			#endregion
try{
			int rmab = BarsArray[0].GetBar(Times[0].GetValueAt(Math.Min(BarsArray[0].Count-1,ChartBars.ToIndex)));
			if(rmab==BarsArray[0].Count-1 && Calculate == Calculate.OnBarClose) rmab = rmab-1;

			int x1 = 0;
			int y1 = 0;
			int x2 = 0;
			int y2 = 0;
line=4631;
			#region -- draw structure --            
			if (ShowStructureLines)
			{
			    RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

				if (rmab >= 2)
				{
					//var StructureLabelBrush = Brushes.White.ToDxBrush(RenderTarget);
					var keys = new System.Collections.Generic.List<int>(StructureMgr.AllPivots.Keys);
				    int j = keys.Count-1;
					double swingprice2 = Closes[0].GetValueAt(1);
					double swingprice1 = Closes[0].GetValueAt(1);
					float vTextOffset = 0;
					int swingABar1 = 1;
				    while (j > 0) { 
						j = j - 1;
						if(keys[j] < ChartBars.FromIndex) {
							swingABar1 = keys[j];
							swingprice1 = Math.Abs(StructureMgr.AllPivots[swingABar1]);
							break;
						}
					}//j is now the first swing point prior to the first bar on the chart
//try{
						var lineBrush = 'U';
						string zzId0 = "";
						for (int i = j; i<keys.Count /*&& keys[i] <= rmab*/; i++)
						{
							bool Ics_lowSwing = false;
							int swingabar = keys[i];
							double swingprice = StructureMgr.AllPivots[swingabar];
							if(swingprice < 0) {
								swingprice = Math.Abs(swingprice);
								lineBrush = 'D';
								if(swingprice<swingprice2) zzId0 = "LL";
								else if(swingprice>swingprice2) zzId0 = "HL";
								else zzId0 = "DB";
								Ics_lowSwing = true;
							}else{
								lineBrush = 'U';
								if(swingprice<swingprice2) zzId0 = "LH";
								else if(swingprice>swingprice2) zzId0 = "HH";
								else zzId0 = "DT";
							}

							x1 = ChartControl.GetXByBarIndex(ChartBars, swingabar);
							x2 = ChartControl.GetXByBarIndex(ChartBars, swingABar1);

							y1 = chartScale.GetYByValue(swingprice);
							y2 = chartScale.GetYByValue(swingprice1);

							drawLine(x1, x2, y1, y2, lineBrush=='U' ? lineBrushUp : lineBrushDown, DashStyleHelper.Solid, ZZLineThickness);
							if (ShowStructureLabels)
							{
//try{
								char StructureLabelBrush = ' ';
							    float[] SZ  = getTextHeightAndWidth(zzId0, pZZlabelFont);
							    if (!Ics_lowSwing){
									StructureLabelBrush = 'U';
									vTextOffset = -SZ[0] -3f;
								} else if (Ics_lowSwing) {
									StructureLabelBrush = 'D';
									vTextOffset = 3f;
								}
//Print("SZ[0]: "+SZ[0]+"  SZ[1]: "+SZ[1]);
							    drawString(zzId0, x1 - SZ[1] / 2, y1 + vTextOffset, pZZlabelFont, StructureLabelBrush=='U' ? lineBrushUp:lineBrushDown , SharpDX.DirectWrite.TextAlignment.Center);                                            
//}catch(Exception onr){Print("OnRender: "+onr.ToString());}
							}
							swingprice2 = swingprice1;
							swingprice1 = swingprice;
							swingABar1  = swingabar;
						}
//}catch(Exception onr){Print(line+":  OnRender: "+onr.ToString());}
				}
				RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
			}
            #endregion

			//base.OnRender(chartControl, chartScale);

line=4711;
			#region ----- temp draw curve high and low -----
			int RemainBars = ChartBars.ToIndex;
//			x1 = ChartControl.GetXByBarIndex(ChartBars, ChartBars.FromIndex);
//			x2 = x1;
//			y1 = int.MinValue;
//			y2 = int.MinValue;
//			for(int abar = ChartBars.FromIndex; abar<=rmab; abar++){
//				x2 = x1;
//				x1 = ChartControl.GetXByBarIndex(ChartBars, abar);
//				y2 = y1;
//				y1 = chartScale.GetYByValue(dCurve1.GetValueAt(abar));
//				if(y2!=int.MinValue){
//					drawLine(x1, x2, y1, y2, fillbrush, DashStyleHelper.Solid, 2);
//				}
//			}
//Draw.Dot(this,CurrentBar.ToString(),false,0,dCurve1.GetValueAt(rmab),Brushes.Yellow);
//Draw.Dot(this,CurrentBar.ToString()+"xx",false,0,dCurve5.GetValueAt(rmab),Brushes.Yellow);

//			x1 = ChartControl.GetXByBarIndex(ChartBars, ChartBars.FromIndex);
//			x2 = x1;
//			y1 = int.MinValue;
//			y2 = int.MinValue;
//			for(int abar = ChartBars.FromIndex; abar<=rmab; abar++){
//				x2 = x1;
//				x1 = ChartControl.GetXByBarIndex(ChartBars, abar);
//				y2 = y1;
//				y1 = chartScale.GetYByValue(dCurve5.GetValueAt(abar));
//				if(y2!=int.MinValue){
//					drawLine(x1, x2, y1, y2, fillbrush, DashStyleHelper.Solid, 2);
//				}
//			}
			#endregion

line=4745;
			int lmPixel = ChartPanel.X;
			int rmPixel = ChartPanel.X + ChartPanel.W;
			#region ----- Set initial location of Current Curve -----
			int cXL = ChartPanel.X + ChartPanel.W * cCurveLocX/100 - cCurveLength/2;
			int cXR = cXL + cCurveLength;
			if(cXL < lmPixel){//current curve is left of left chart edge, move it into view
				int xshift = lmPixel - cXL;
				cXL = cXL + xshift;
				cXR = cXR + xshift;
			}
			if(cXR > rmPixel){//current curve is right of right chart edge, move it into view
				int xshift = rmPixel - cXR;
				cXL = cXL - xshift;
				cXR = cXR - xshift;
			}
			#endregion
			#region ----- Set initial location of Daily Curve -----
			int dXL = ChartPanel.X + ChartPanel.W * dCurveLocX/100 - dCurveLength/2;
			int dXR = dXL + dCurveLength;
			if(dXL < lmPixel){//daily curve is left of left chart edge, move it into view
				int xshift = lmPixel - dXL;
				dXL = dXL + xshift;
				dXR = dXR + xshift;
			}
			if(dXR > rmPixel){//daily curve is right of right chart edge, move it into view
				int xshift = rmPixel - dXR;
				dXL = dXL - xshift;
				dXR = dXR - xshift;
			}
			#endregion
line=4776;
//RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(ChartPanel.X,50),10,10),Brushes.Yellow.ToDxBrush(RenderTarget));
//RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(ChartPanel.W,50),10,10),Brushes.Yellow.ToDxBrush(RenderTarget));
			if(MaxWidthInMargin>0){
				#region ----- Squeeze curve visuals into the right margin
				int MarginSize = (int)(Math.Min(MaxWidthInMargin,ChartControl.Properties.BarMarginRight) * 0.9);
				if(dShowCurve && cShowCurve){
					cXL = rmPixel - MarginSize;
					dXL = rmPixel - MarginSize/2+1;
					cXR = dXL;
					dXR = ChartPanel.W;
				}else if(cShowCurve){
					if(cCurveLength > MarginSize){
						cXL = rmPixel - MarginSize;
						cXR = rmPixel;
					}else{
						int center = rmPixel - MarginSize/2;
						cXL = center - cCurveLength/2;
						cXR = cXL + cCurveLength;
					}
				}else if(dShowCurve){
					if(dCurveLength > MarginSize){
						dXL = rmPixel - MarginSize;
						dXR = rmPixel;
					}else{
						int center = rmPixel - MarginSize/2;
						dXL = center - dCurveLength/2;
						dXR = dXL + dCurveLength;
					}
				}
				#endregion
			} else if (PreventVisualOverlap &&
					dShowCurve && dCurve1.IsValidDataPointAt(rmab) && cShowCurve && cCurve1.IsValidDataPointAt(rmab)){
				#region ----- Adjust curve visuals if overlap has occurred -----
				if(cXL < dXR && cXL > dXL && cXR < dXR && cXR > dXL){//if current curve is completely inside of daily curve
					int diffL = Math.Abs(cXL-dXL);
					int diffR = Math.Abs(cXR-dXR);
					if(diffL <= diffR){
						int xshift = cXR - dXL;
						cXL = cXL - xshift;
						cXR = cXR - xshift;
					} else {
						int xshift = dXR - cXL;
						cXL = cXL + xshift;
						cXR = cXR + xshift;
					}
				}else if(cXL < dXR && cXL > dXL){//if current curve has its left-edge inside of the daily curve, shift current to the right of daily
					int xshift = dXR - cXL;
					cXL = cXL + xshift;
					cXR = cXR + xshift;
				}else if(cXR < dXR && cXR > dXL){//if current curve has its right-edge inside of the daily curve, shift current to the left of daily
					int xshift = cXR - dXL;
					cXL = cXL - xshift;
					cXR = cXR - xshift;
				}
				#endregion
			}
line=4833;
			if(MaxWidthInMargin<=0){
				#region ----- Keep curves on the visual area of the chart, move them if necessary -----
				int maxXpixel = Math.Max(cXR,dXR);
				int minXpixel = Math.Min(cXL,dXL);
				if(maxXpixel > rmPixel){
					int xshift = maxXpixel - rmPixel;
					cXL = cXL - xshift;
					cXR = cXR - xshift;
					dXL = dXL - xshift;
					dXR = dXR - xshift;
				}
				if(minXpixel < lmPixel){
					int xshift = lmPixel - minXpixel;
					cXL = cXL + xshift;
					cXR = cXR + xshift;
					dXL = dXL + xshift;
					dXR = dXR + xshift;
				}
				#endregion
			}

line=4855;
			#region -- Draw Curve --
			var TextDXBrush = dLineDXBrush;
			if(pSelectedCurve == ARC_AuctionCurve_CurveBasis.ATR_HL){
				CH = aCurve1.GetValueAt(rmab);
				CL = aCurve5.GetValueAt(rmab);
				if (dShowCurve && aCurve1.IsValidDataPointAt(rmab))
				{
				    if (CH != 99999999 && CL != 0) {
						if(dLineColor == BackBrush){
							TextDXBrush = ContrastingColor((SolidColorBrush)dLineColor).ToDxBrush(RenderTarget);
						}
						DrawCurve(chartScale, rmab, dXL, dXR, CH, CL, RemainBars, 0, true, dTextFont, dDisplayText, dDisplayPercent, dDisplayPrice, dPercent1, dPercent2, dPercent3, dPercent4, dPercent5, dCurveLineThickness, dCurveAreaDXBrush1, dCurveAreaDXBrush2, dCurveAreaDXBrush3, dCurveAreaDXBrush4, dLineDXBrush, TextDXBrush);
						//DailyCurveWasDrawn = true;
					}
				}
			}else{
				CH = dCurve1.GetValueAt(rmab);
				CL = dCurve5.GetValueAt(rmab);
				if (dShowCurve && dCurve1.IsValidDataPointAt(rmab))
				{
				    if (CH != 99999999 && CL != 0) {
						if(dLineColor == BackBrush){
							TextDXBrush = ContrastingColor((SolidColorBrush)dLineColor).ToDxBrush(RenderTarget);
						}
						DrawCurve(chartScale, rmab, dXL, dXR, CH, CL, RemainBars, 0, true, dTextFont, dDisplayText, dDisplayPercent, dDisplayPrice, dPercent1, dPercent2, dPercent3, dPercent4, dPercent5, dCurveLineThickness, dCurveAreaDXBrush1, dCurveAreaDXBrush2, dCurveAreaDXBrush3, dCurveAreaDXBrush4, dLineDXBrush, TextDXBrush);
						//DailyCurveWasDrawn = true;
					}
				}
			}
			#endregion
#if ENABLE_CURRENTCURVE
			#region -- Draw Current Curve --
			CH = cCurve1.GetValueAt(rmab);
			CL = cCurve5.GetValueAt(rmab);
			TextDXBrush = cLineDXBrush;

			if (cShowCurve && cCurve1.IsValidDataPointAt(rmab))
			{
			    if (CH != 99999999 && CL != 0) {
					if(cLineColor == BackBrush){
						TextDXBrush = ContrastingColor((SolidColorBrush)cLineColor).ToDxBrush(RenderTarget);
					}
					DrawCurve(chartScale, rmab, cXL, cXR, CH, CL, RemainBars, 0, true, cTextFont, cDisplayText, cDisplayPercent, cDisplayPrice, cPercent1, cPercent2, cPercent3, cPercent4, cPercent5, cCurveLineThickness, cCurveAreaDXBrush1, cCurveAreaDXBrush2, cCurveAreaDXBrush3, cCurveAreaDXBrush4, cLineDXBrush, TextDXBrush);
				}
			}
			#endregion
#endif
line=4903;
			StructureDetector.CalculateBiasesAtAbsBar(rmab, CurrentBars[0]);
//Print(Times[0].GetValueAt(rmab).ToString()+":    "+StructureDetector.OnCloseBias+"   "+StructureDetector.Status);
			if(SentimentDetectionMode == ARC_AuctionCurve_SentimentDetectionMode.OnClose)
				DrawSentimentDialog(chartScale, dCurveLineThickness, CurveState.GetValueAt(rmab), StructureDetector.OnCloseBias, PermissiveSignal.GetValueAt(rmab), SentimentDialogLoc, rmab);
			else if(SentimentDetectionMode == ARC_AuctionCurve_SentimentDetectionMode.OnTick)
				DrawSentimentDialog(chartScale, dCurveLineThickness, CurveState.GetValueAt(rmab), StructureDetector.OnTickBias, PermissiveSignal.GetValueAt(rmab), SentimentDialogLoc, rmab);
}catch(Exception eee){Print(line+":  ARC_AuctionCurve: "+eee.ToString());}
//ARC_AuctionCurve_SentimentDetectionMode {OFF, OnClose, OnTick}
//ARC_AuctionCurve_SentimentDialogLoc {TopRight, BottomRight, TopLeft, BottomLeft, Center}

//			if(fillbrush!=null && !fillbrush.IsDisposed) fillbrush.Dispose(); 
//			fillbrush = null;

			#region Dispose of DX Brushes
//			if(cCurveAreaDXBrush1!=null && !cCurveAreaDXBrush1.IsDisposed) cCurveAreaDXBrush1.Dispose(); 
//			cCurveAreaDXBrush1 = null;
//			if(cCurveAreaDXBrush2!=null && !cCurveAreaDXBrush2.IsDisposed) cCurveAreaDXBrush2.Dispose(); 
//			cCurveAreaDXBrush2 = null;
//			if(cCurveAreaDXBrush3!=null && !cCurveAreaDXBrush3.IsDisposed) cCurveAreaDXBrush3.Dispose(); 
//			cCurveAreaDXBrush3 = null;
//			if(cCurveAreaDXBrush4!=null && !cCurveAreaDXBrush4.IsDisposed) cCurveAreaDXBrush4.Dispose(); 
//			cCurveAreaDXBrush4 = null;

//			if(cLineDXBrush!=null && !cLineDXBrush.IsDisposed) cLineDXBrush.Dispose(); 
//			cLineDXBrush = null;
			
//			if(dCurveAreaDXBrush1!=null && !dCurveAreaDXBrush1.IsDisposed) dCurveAreaDXBrush1.Dispose(); 
//			dCurveAreaDXBrush1 = null;
//			if(dCurveAreaDXBrush2!=null && !dCurveAreaDXBrush2.IsDisposed) dCurveAreaDXBrush2.Dispose(); 
//			dCurveAreaDXBrush2 = null;
//			if(dCurveAreaDXBrush3!=null && !dCurveAreaDXBrush3.IsDisposed) dCurveAreaDXBrush3.Dispose(); 
//			dCurveAreaDXBrush3 = null;
//			if(dCurveAreaDXBrush4!=null && !dCurveAreaDXBrush4.IsDisposed) dCurveAreaDXBrush4.Dispose(); 
//			dCurveAreaDXBrush4 = null;

//			if(dLineDXBrush!=null && !dLineDXBrush.IsDisposed) dLineDXBrush.Dispose(); 
//			dLineDXBrush = null;

//			if(TextDXBrush!=null && !TextDXBrush.IsDisposed) TextDXBrush.Dispose(); 
//			TextDXBrush = null;
//			if(ButtonPenDXBrush!=null && !ButtonPenDXBrush.IsDisposed) ButtonPenDXBrush.Dispose();
//			ButtonPenDXBrush = null;
			
			
//			if(MidlineDXBrush_Value!=null && !MidlineDXBrush_Value.IsDisposed) MidlineDXBrush_Value.Dispose();
//			MidlineDXBrush_Value = null;
//			if(MidlineDXBrush_Retail!=null && !MidlineDXBrush_Retail.IsDisposed) MidlineDXBrush_Retail.Dispose();
//			MidlineDXBrush_Retail = null;
			#endregion
		}
		//======================================================================================================
		private void DrawSentimentDialog(ChartScale chartscale, int LineWidth, double CurveBias, double StructureBias, double Permission, ARC_AuctionCurve_SentimentDialogLoc Loc, int abs_bar){
			string[] msg = new string[3]{"N/A","N/A","N/A"};
			SharpDX.Direct2D1.Brush[] bkg_brush  = new SharpDX.Direct2D1.Brush[3]{null,null,null};
			SharpDX.Direct2D1.Brush[] text_brush = new SharpDX.Direct2D1.Brush[3]{null,null,null};

			if(CurveBias < 0){
				if(VerboseSentimentDialog) msg[0] = "Curve:  VALUE"; else msg[0] = "VALUE";
				bkg_brush[0] = StructureDialogBkg_UpBrush.ToDxBrush(RenderTarget);
				bkg_brush[0].Opacity = StructureDialogBkg_UpOpacity/100f;
				text_brush[0] = StructureDialogText_UpBrush.ToDxBrush(RenderTarget);
			}
			else if(CurveBias > 0){
				if(VerboseSentimentDialog) msg[0] = "Curve: RETAIL"; else msg[0] = "RETAIL";
				bkg_brush[0] = StructureDialogBkg_DownBrush.ToDxBrush(RenderTarget);
				bkg_brush[0].Opacity = StructureDialogBkg_DownOpacity/100f;
				text_brush[0] = StructureDialogText_DownBrush.ToDxBrush(RenderTarget);
			}else{
				if(VerboseSentimentDialog) msg[0] = "Curve:  N/A"; else msg[0] = "N/A";
				bkg_brush[0] = Brushes.Black.ToDxBrush(RenderTarget);
				bkg_brush[0].Opacity = 1f;
				text_brush[0] = Brushes.DimGray.ToDxBrush(RenderTarget);
			}
			if(StructureBias == StructureDetectorClass.UP){
				if(VerboseSentimentDialog) msg[1] = "Structure:  UP"; else msg[1] = "UP";
				bkg_brush[1] = StructureDialogBkg_UpBrush.ToDxBrush(RenderTarget);
				bkg_brush[1].Opacity = StructureDialogBkg_UpOpacity/100f;
				text_brush[1] = StructureDialogText_UpBrush.ToDxBrush(RenderTarget);
			}
			else if(StructureBias == StructureDetectorClass.DOWN){
				if(VerboseSentimentDialog) msg[1] = "Structure:  DOWN"; else msg[1] = "DOWN";
				bkg_brush[1] = StructureDialogBkg_DownBrush.ToDxBrush(RenderTarget);
				bkg_brush[1].Opacity = StructureDialogBkg_DownOpacity/100f;
				text_brush[1] = StructureDialogText_DownBrush.ToDxBrush(RenderTarget);
			}
			if(Permission == CONSERVATIVE_UP){
				if(VerboseSentimentDialog) msg[2] = "Permission:  Conservative BUY"; else msg[2] = "Conservative BUY";
				bkg_brush[2] = StructureDialogBkg_UpBrush.ToDxBrush(RenderTarget);
				bkg_brush[2].Opacity = StructureDialogBkg_UpOpacity/100f;
				text_brush[2] = StructureDialogText_UpBrush.ToDxBrush(RenderTarget);
			}
			else if(Permission == CONSERVATIVE_DOWN){
				if(VerboseSentimentDialog) msg[2] = "Permission:  Conservative SELL"; else msg[2] = "Conservative SELL";
				bkg_brush[2] = StructureDialogBkg_DownBrush.ToDxBrush(RenderTarget);
				bkg_brush[2].Opacity = StructureDialogBkg_DownOpacity/100f;
				text_brush[2] = StructureDialogText_DownBrush.ToDxBrush(RenderTarget);
			}
			else if(Permission == AGGRESSIVE_UP){
				if(VerboseSentimentDialog) msg[2] = "Permission:  Aggressive BUY"; else msg[2] = "Aggressive BUY";
				bkg_brush[2] = Brushes.Black.ToDxBrush(RenderTarget);
				bkg_brush[2].Opacity = 1f;
				text_brush[2] = StructureDialogBkg_UpBrush.ToDxBrush(RenderTarget);
			}
			else if(Permission == AGGRESSIVE_DOWN){
				if(VerboseSentimentDialog) msg[2] = "Permission:  Aggressive SELL"; else msg[2] = "Aggressive SELL";
				bkg_brush[2] = Brushes.Black.ToDxBrush(RenderTarget);
				bkg_brush[2].Opacity = 1f;
				text_brush[2] = StructureDialogBkg_DownBrush.ToDxBrush(RenderTarget);
			}else{
				if(VerboseSentimentDialog) msg[2] = "Permission:  N/A"; else msg[2] = "N/A";
				bkg_brush[2] = Brushes.Black.ToDxBrush(RenderTarget);
				bkg_brush[2].Opacity = 1f;
				text_brush[2] = Brushes.DimGray.ToDxBrush(RenderTarget);
			}
			//else
			//	bkg_brush = Brushes.Yellow.ToDxBrush(RenderTarget);
			float xf = 100f;
			float yf = 100f;
			float txt_margin = 3f;
			float HeightPerCell = (float)StructureDialogFont.Size + txt_margin*2f;
			float halfCellHeight = HeightPerCell/2f;
			float halfFontHeight = (float)StructureDialogFont.Size/2f;

			var hw0 = getTextHeightAndWidth(msg[0], StructureDialogFont);
			var hw1 = getTextHeightAndWidth(msg[1], StructureDialogFont);
			var hw2 = getTextHeightAndWidth(msg[2], StructureDialogFont);
			var hw = new float[2]{txt_margin*2f + Math.Max(hw0[0], Math.Max(hw1[0],hw2[0])) , Math.Max(hw0[1], Math.Max(hw1[1],hw2[1]))};

			
			if(Loc == ARC_AuctionCurve_SentimentDialogLoc.TopLeft){
				xf = ChartPanel.X + 20f;
				yf = ChartPanel.Y + 30f;
			}
			else if(Loc == ARC_AuctionCurve_SentimentDialogLoc.BottomLeft){
				xf = ChartPanel.X + 20f;
				yf = ChartPanel.Y + ChartPanel.H - 40f - text_brush.Length*HeightPerCell;
			}
			else if(Loc == ARC_AuctionCurve_SentimentDialogLoc.TopRight){
				xf = ChartPanel.X + ChartPanel.W - hw[1] - 40f;
				yf = ChartPanel.Y + 30f;
			}
			else if(Loc == ARC_AuctionCurve_SentimentDialogLoc.BottomRight){
				xf = ChartPanel.X + ChartPanel.W - hw[1] - 40f;
				yf = ChartPanel.Y + ChartPanel.H - 30f - text_brush.Length*HeightPerCell;
			}
			else if(Loc == ARC_AuctionCurve_SentimentDialogLoc.Center){
				xf = ChartPanel.X + ChartPanel.W/2f - (hw[1] + 16f)/2f;
				yf = ChartPanel.Y + ChartPanel.H/2f - (hw[0] + 16f + text_brush.Length*HeightPerCell)/2f;
			}

			var yellowDXBrush= Brushes.Yellow.ToDxBrush(RenderTarget);
			for(int i = 0; i<text_brush.Length; i++){
				if(msg[i].Length>0){
					RenderTarget.FillRectangle(new SharpDX.RectangleF(xf-8f, yf-halfCellHeight, hw[1]+16f, hw[0]), bkg_brush[i]);
					drawString(msg[i], xf, yf-halfFontHeight, StructureDialogFont, text_brush[i], SharpDX.DirectWrite.TextAlignment.Leading, -9999f);
					yf = yf + HeightPerCell + 4f;
				}

				if(bkg_brush[i] !=null && !bkg_brush[i].IsDisposed)  bkg_brush[i].Dispose();  bkg_brush[i] = null;
				if(text_brush[i]!=null && !text_brush[i].IsDisposed) text_brush[i].Dispose(); text_brush[i] = null;
			}
			yellowDXBrush.Dispose();
		}

		//======================================================================================================
        #region -- Mouse Utilities --
        private int ClickedBar1, ClickedBar2;
        private double ClickedPrice1, ClickedPrice2;
        private ChartScale gbChartScale;
        private bool AddNextRectangle = false;
		//======================================================================================================
        private void ChartPanel_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            Point coords = e.GetPosition(ChartPanel);
            MM.X = (int)coords.X;
            MM.Y = (int)coords.Y;
//            ChartControl.InvalidateVisual();
        }
		//======================================================================================================
        private void ChartPanel_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            System.Windows.Input.MouseEventArgs mouse = (System.Windows.Input.MouseEventArgs)e;
            #region -- Click Over Curve --
//            if (ZoneSnapHover) iIncludeZone = !iIncludeZone;//Curve Z button
//            if (ZoneSnapHover2) iCompositeAEnabled = !iCompositeAEnabled;//Curve P button
            #endregion
            ChartControl.InvalidateVisual();
        }
        private List<HorizontalLine> DeleteTags = new List<HorizontalLine>();
        private bool MouseIn(Rect area, int xFrame, int yFrame) { return MM.X >= area.Left - xFrame && MM.X <= area.Right + xFrame && MM.Y >= area.Top - yFrame && MM.Y <= area.Bottom + yFrame; }
        #endregion

		#region DrawCurve
		//======================================================================================================
        private void DrawCurve(ChartScale chartscale, int abs_bar, int xL, int xR, double HighPrice, double LowPrice, int LeftBar, int RightBar, bool ShowButtons, SimpleFont font, bool DisplayText, bool DisplayPercent, bool DisplayPrice, double Percent1, double Percent2, double Percent3, double Percent4, double Percent5, int Width, SharpDX.Direct2D1.Brush CurveDXBrush1, SharpDX.Direct2D1.Brush CurveDXBrush2, SharpDX.Direct2D1.Brush CurveDXBrush3, SharpDX.Direct2D1.Brush CurveDXBrush4, SharpDX.Direct2D1.Brush LineDXBrush, SharpDX.Direct2D1.Brush TextDXBrush)
        {
			Price100P = HighPrice;
			Price0P   = LowPrice;

			if (Price0P   >= chartscale.MaxValue) {return;}
			if (Price100P <= chartscale.MinValue) {return;}

			#region -- calculate coordinates --
//			int DesiredMargin = CurveLength + diff + iRightSidePaddingMin;
//			FinalDesiredMargin = Math.Max(FinalDesiredMargin, DesiredMargin);

			int x1 = xL;//ChartPanel.X + ChartPanel.W * xLocPct/100 - CurveLength/2;
			int x2 = xR;//x1+CurveLength;//RightBar == 0 ? ChartPanel.W : ChartControl.GetXByBarIndex(ChartBars, RightBar);
			int y1 = chartscale.GetYByValue(Price100P);
			int y2 = chartscale.GetYByValue(Price0P);

			if (y2 - y1 <= 0) return;
			#endregion

			AllLevels.Clear();
			#region -- draw curve zone + frame + values --
			//zones must be first, then lines then frame
			if(dZoneCount==4){
				DrawFibZone(chartscale, true, Percent1, Percent2, CurveDXBrush1, Width, pDashStyle, LineDXBrush, "Deep Value",  DisplayText, font, x1, x2);
				DrawFibZone(chartscale, true, Percent2, Percent3, CurveDXBrush2, Width, pDashStyle, LineDXBrush, "Value",       DisplayText, font, x1, x2);
				DrawFibZone(chartscale, true, Percent3, Percent4, CurveDXBrush3, Width, pDashStyle, LineDXBrush, "Retail",      DisplayText, font, x1, x2);
				DrawFibZone(chartscale, true, Percent4, Percent5, CurveDXBrush4, Width, pDashStyle, LineDXBrush, "Deep Retail", DisplayText, font, x1, x2);
			}else if(dZoneCount==2){
				DrawFibZone(chartscale, true, Percent3, Percent4, CurveDXBrush2, Width, pDashStyle, LineDXBrush, "Value",  DisplayText, font, x1, x2);
				DrawFibZone(chartscale, true, Percent4, Percent5, CurveDXBrush3, Width, pDashStyle, LineDXBrush, "Retail", DisplayText, font, x1, x2);
			}
//Print("Drawing curve");
			SimpleFont fontSmaller = (SimpleFont)font.Clone();
			fontSmaller.Size = font.Size-2;
			if(dZoneCount==4){
				DrawFib(chartscale, true, Percent1, LineDXBrush, TextDXBrush, Width, pDashStyle, DisplayPercent, DisplayPrice, fontSmaller, x1, x2);
    	        DrawFib(chartscale, true, Percent2, LineDXBrush, TextDXBrush, Width, pDashStyle, DisplayPercent, DisplayPrice, fontSmaller, x1, x2);
        	    DrawFib(chartscale, true, Percent3, LineDXBrush, TextDXBrush, Width, pDashStyle, DisplayPercent, DisplayPrice, fontSmaller, x1, x2);
            	DrawFib(chartscale, true, Percent4, LineDXBrush, TextDXBrush, Width, pDashStyle, DisplayPercent, DisplayPrice, fontSmaller, x1, x2);
            	DrawFib(chartscale, true, Percent5, LineDXBrush, TextDXBrush, Width, pDashStyle, DisplayPercent, DisplayPrice, fontSmaller, x1, x2);
			}else if(dZoneCount==2){
            	DrawFib(chartscale, true, Percent3, LineDXBrush, TextDXBrush, Width, pDashStyle, DisplayPercent, DisplayPrice, fontSmaller, x1, x2);
            	DrawFib(chartscale, true, Percent4, LineDXBrush, TextDXBrush, Width, pDashStyle, DisplayPercent, DisplayPrice, fontSmaller, x1, x2);
            	DrawFib(chartscale, true, Percent5, LineDXBrush, TextDXBrush, Width, pDashStyle, DisplayPercent, DisplayPrice, fontSmaller, x1, x2);
			}
			if(Extend50Line){
				try{
					var linebrush = MidlineDXBrush_Retail;
//					if(CurveState.GetValueAt(abs_bar)<0) linebrush = MidlineDXBrush_Value;
	                double MidPrice = Price0P + (Price100P - Price0P) * (dZoneCount==4 ? Percent3:Percent4) / 100;
					if(Closes[0].GetValueAt(abs_bar)<MidPrice) linebrush = MidlineDXBrush_Value;
	                float ymid = (float)chartscale.GetYByValue(MidPrice);
					RenderTarget.DrawLine(new SharpDX.Vector2(0f,ymid), new SharpDX.Vector2((float)ChartPanel.W, ymid), linebrush, MidlineThickness);
				}catch(Exception e4237){Print("e4237: "+e4237.ToString());}
			}

			if (!IsInHitTest) drawRectangle(new Rect(x1, y1, x2 - x1, y2 - y1), LineDXBrush, Width, pDashStyle);
            #endregion

            #region -- Curve Buttons --
//            if (iPCalcM != "Minute")
//            {
//                Rect HoverCurve = new Rect(x1 - 6, y1 - 6, x2 - x1 + 4 + 12, y2 - y1 + 12);
//                if (MM.X >= HoverCurve.Left && MM.X <= HoverCurve.Right && MM.Y >= HoverCurve.Top && MM.Y <= HoverCurve.Bottom)
//                {
//                    var y5 = chartscale.GetYByValue(Price0P);
//                    var B1 = new Rect((int)x1 + pButtonSpace + 1, (int)y5 - pButtonSpace - iButtonSize - 1, iButtonSize, iButtonSize);
//                    var B2 = new Rect((int)x1 + pButtonSpace + 1 + iButtonSize + pButtonSpace, (int)y5 - pButtonSpace - iButtonSize - 1, iButtonSize, iButtonSize);

//                    #region -- Z button --
//                    if (!IsInHitTest)
//                    {
//                        drawRegion(B1, DXBrushes_LightGray);
//                        drawRectangle(B1, ButtonPenDXBrush, (int)ButtonPen.Thickness);
//                        drawstring("Z", B1.X, B1.Y, ButtonFont, DXBrushes_Black, null, SharpDX.DirectWrite.TextAlignment.Center, (float)B1.Width);
//                    }
//                    #endregion

//                    #region -- HighLight --
//                    if (!IsInHitTest)
//                    {
//                        drawRegion(B2, DXBrushes_LightGray);
//                        drawRectangle(B2, ButtonPenDXBrush, (int)ButtonPen.Thickness);
//                        drawstring("P", B2.X, B2.Y, ButtonFont, DXBrushes_Black, null, SharpDX.DirectWrite.TextAlignment.Center, (float)B2.Width);
//                    }
//                    #endregion

//                    if (MouseIn(B1, 2, 2))
//                    {
//                        ZoneSnapHover = true;
//                        if (!IsInHitTest) drawRectangle(B1, ZoneHDXBrush, Width+1);
//                    }
//                    if (MouseIn(B2, 2, 2))
//                    {
//                        ZoneSnapHover2 = true;
//                        if (!IsInHitTest) drawRectangle(B2, ZoneHDXBrush, Width+1);
//                    }
//                    if (!IsInHitTest) drawRectangle(new Rect(x1, y1, x2 - x1, y2 - y1), ZoneHDXBrush, Width+1);
//                }
//            }
            #endregion
		}
		#endregion

		#region Draw Fibs
		//======================================================================================================
		private void DrawFibZone(ChartScale chartScale, bool Active, double Percent1, double Percent2, SharpDX.Direct2D1.Brush dxbrush, int pWidth1, DashStyleHelper pDash, SharpDX.Direct2D1.Brush LineDXBrush, string NameZ, bool DisplayText, SimpleFont font, int x1, int x2)
        {
            if (Active)
            {
                double TFPrice = Price0P + (Price100P - Price0P) * Percent1 / 100;
                double TFPrice2 = Price0P + (Price100P - Price0P) * Percent2 / 100;
                double TFPercent = Percent1;

                var y5 = chartScale.GetYByValue(TFPrice);
                var y6 = chartScale.GetYByValue(TFPrice2);
//                var y5 = PrintEnabled && Percent1 == 0 ? GetBoxPixel(TFPrice, "Bottom") : chartScale.GetYByValue(TFPrice);
//                var y6 = PrintEnabled && Percent2 == 100 ? GetBoxPixel(TFPrice2, "Top") - 1 : chartScale.GetYByValue(TFPrice2);
                var y7 = Math.Min(y5, y6);
                var y8 = Math.Max(y5, y6);

                var B1 = new Rect(x1, y7, x2 - x1 + 1, y8 - y7);

                if (!IsInHitTest) drawRegion(B1, dxbrush);
                if (DisplayText && !IsInHitTest) {
					drawstring(NameZ, B1.X, B1.Y + (B1.Height - font.Size) / 2, font, LineDXBrush, null, SharpDX.DirectWrite.TextAlignment.Center, (int)B1.Width);
				}
            }
        }
		//======================================================================================================
        private void DrawFib(ChartScale chartScale, bool Active, double Percent, SharpDX.Direct2D1.Brush linedxbrush, SharpDX.Direct2D1.Brush textdxbrush, int Width, DashStyleHelper pDash, bool DisplayPercent, bool DisplayPrice, SimpleFont font, int x1, int x2)
        {
            if (Active)
            {
//                Brush Brush1 = iColor.Clone();
//                Brush1.Opacity = pOpacity1 / 100d;
//                Brush1.Freeze();

                double TFPrice = Price0P + (Price100P - Price0P) * Percent / 100;
                double TFPercent = Percent;

                if (!AllLevels.ContainsKey(TFPrice))
                {
                    AllLevels.Add(TFPrice, 1);
                    var y5 = chartScale.GetYByValue(TFPrice);
                    if (!IsInHitTest) drawLine(x1, x2, y5, y5, linedxbrush, pDash, Width);

                    string fibst = GetText(TFPercent, TFPrice, DisplayPercent, DisplayPrice);

                    if ((DisplayPercent || DisplayPrice) && !IsInHitTest)
                    {
                        float fibsz = getTextWidth(fibst, font);
                        var x5 = x2 - (int)fibsz - 4;
//Print(fibst+"  2686  "+ x5+"  "+y5);
                        drawstring(fibst, x5, y5 - font.Size/1.5f, font, textdxbrush, null, SharpDX.DirectWrite.TextAlignment.Leading);
                    }
                }
            }
        }
		//======================================================================================================
        private string GetText(double TFPercent, double TFPrice, bool DisplayPercent, bool DisplayPrice)
        {
            string fibst = string.Empty;
            if (DisplayPercent) fibst = TFPercent.ToString() + "%";
            if (fibst != string.Empty && DisplayPrice) fibst = fibst + "  ";
            if (DisplayPrice) fibst = fibst + FormatPriceMarker(TFPrice);
            return fibst;
        }
		#endregion

        #region --- internal class MouseManager --- #REMARQUE : NOT SURE IF IT NEEDS TO BE IMPLEMENTED ----
		//======================================================================================================
        internal class MouseManager
        {
            public int HoverIndex { get; set; }
            public bool Dragging { get; set; }
            public int X { get; set; }
            public int Y { get; set; }
            public int XStart { get; set; }
            public int YStart { get; set; }
            public int Index { get; set; }

            public MouseManager()
            {
                HoverIndex = -1;
                Dragging = false;
                X = 0;
                Y = 0;
                XStart = 0;
                YStart = 0;
                Index = 0;
            }

            public void Clear()
            {
                HoverIndex = -1;
                Dragging = false;
                X = 0;
                Y = 0;
                XStart = 0;
                YStart = 0;
                Index = 0;
            }
        }
        #endregion

		#region supporting code
		//set the color to Black or White depending on background color
		public Brush ContrastingColor(SolidColorBrush background)
		{
		    // Counting the perceptive luminance - human eye favors green color... 
		    double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
		    if (a < 0.5) return Brushes.Black; // bright colors - black font
		    else return Brushes.White; // dark colors - white font
		}

		private float[] getTextHeightAndWidth(string text, SimpleFont font){
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			float[] result = new float[2]{(float)font.Size, textLayout.Metrics.Width};

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return result;
		}
		private float getTextWidth(string text, SimpleFont font)
		{
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

		    float textwidth = textLayout.Metrics.Width;

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return textwidth;
		}
		private float getTextHeight(string text, SimpleFont font)
		{
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

		    float textheight = textLayout.Metrics.Height;

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return textheight;
		}
		#region drawstring
		//Draw a text at {x;y} coordinates in pixel.
		private void drawString(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxTextWidth = -9999f)
		{
		    SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        ) { TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, MaxTextWidth <= 0f ? getTextWidth(text, font) : MaxTextWidth, float.MaxValue);

		    RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

		    textLayout.Dispose();
		    textFormat.Dispose();
		}
		private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.Direct2D1.Brush bkgBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxTextWidth = -9999f, float MaxX = -9999f)
		{
			#region drawstring
			if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
			SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();

			var textFormat = new SharpDX.DirectWrite.TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
			)
				{ TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, (MaxTextWidth>0 ? MaxTextWidth : ChartPanel.W/3), ChartPanel.H);
			if(x<0) x = Math.Abs(x) - textLayout.Metrics.Width - 5;

			if(MaxX>0)
				x = Math.Min(x, MaxX - 3f - textLayout.Metrics.Width);

			y = y - textLayout.Metrics.Height/2.0;
			if (bkgBrush!=null && bkgBrush.Opacity>0) {
				double xl = x - 3;
				double xr = x + textLayout.Metrics.Width + 3;
				double yt = y - 1;
				double yb = y+textLayout.Metrics.Height + 2;
				if(textAlignment==SharpDX.DirectWrite.TextAlignment.Trailing){
					xr = x + textLayout.Metrics.LayoutWidth +3;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				else if(textAlignment==SharpDX.DirectWrite.TextAlignment.Center){
					xr = x + textLayout.Metrics.LayoutWidth/2 + 3 + textLayout.Metrics.Width/2;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				var bkgBox = new System.Windows.Point[]
				{	new System.Windows.Point(xl, yt),
					new System.Windows.Point(xl, yb),
					new System.Windows.Point(xr, yb),
					new System.Windows.Point(xr, yt),
				};
				drawRegion(bkgBox, bkgBrush);
			}
			RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			textLayout.Dispose();
			textFormat.Dispose();
			#endregion
		}
		#endregion

		private void drawLine(double x1, double x2, double y1, double y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle = DashStyleHelper.Solid, int width = 1, int opacity = 100)
		{
		    dxbrush.Opacity = opacity / 100f;
		    SharpDX.Direct2D1.DashStyle _dashstyle;
		    if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

		    SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
		    SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

		    RenderTarget.DrawLine(new SharpDX.Vector2((float)x1,(float)y1), new SharpDX.Vector2((float)x2,(float)y2), dxbrush, width, strokestyle);

		    strokestyle.Dispose();
		}
		
        //Draw Region. Rect in pixel coordinate.
        private void drawRegion(Rect rectangle, SharpDX.Direct2D1.Brush color)//, int opacity = 100)
        {
            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, color);
        }
        //Draw Region. x and y as pixel coordinate, w and h in pixel too.
        private void drawRegion(double x, double y, double w, double h, SharpDX.Direct2D1.Brush color)
        {
            drawRegion(
				new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, 
				color);
        }
		private void drawRegion(System.Windows.Point[] points, SharpDX.Direct2D1.Brush dxbrush)
		{
		    SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

		    SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
		    SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
		    sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
		    sink1.AddLines(vectors);
		    sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
		    sink1.Close();

		    RenderTarget.FillGeometry(geo1, dxbrush);
		    geo1.Dispose();
		    sink1.Dispose();
		}

		//Draw a line between 2 points. 'x1' and 'x2' are pixel locations, the y value is the numerical value (ie price / oscillator value)
		private void drawLine(double val1, double val2, float x1, float x2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = true)
		{
			if(double.IsNaN(val1) || double.IsNaN(val2)) {Print("Val is NaN"); return;}
			//SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.DashStyle _dashstyle;
			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

			SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
			SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

			SharpDX.Vector2 v1 = new SharpDX.Vector2(x1, drawOnPricePanel ? chartScale.GetYByValue(val1) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val1));
			SharpDX.Vector2 v2 = new SharpDX.Vector2(x2, drawOnPricePanel ? chartScale.GetYByValue(val2) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val2));
//Print("\nv1: "+v1.X+", "+v1.Y+"   "+val1);
//Print("v2: "+v2.X+", "+v2.Y+"   "+val2);
			RenderTarget.DrawLine(v1, v2, dxbrush, width, strokestyle);

			strokestyle.Dispose();
		}
		private void drawRectangle(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush, int width, DashStyleHelper dashstyle = DashStyleHelper.Solid)
		{
			drawRectangle(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, dxbrush, dashstyle, width);
		}
		//Draw Rectangle. x and y as pixel coordinate, w and h in pixel too.
		private void drawRectangle(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
		{
			drawRectangle(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush, dashstyle, width);
		}
		private void drawRectangle(Point[] points, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
		{
			drawLine(points[0].X, points[1].X, points[0].Y, points[1].Y, dxbrush, dashstyle, width);
			drawLine(points[1].X, points[2].X, points[1].Y, points[2].Y, dxbrush, dashstyle, width);
			drawLine(points[2].X, points[3].X, points[2].Y, points[3].Y, dxbrush, dashstyle, width);
			drawLine(points[3].X, points[0].X, points[3].Y, points[0].Y, dxbrush, dashstyle, width);
		}
		#endregion

		#region -- Parameters --

		[NinjaScriptProperty]
		[Display(Name = "Curve basis", GroupName = " Parameters", Description = "What is the basis for the Curve", Order = 00)]
		public ARC_AuctionCurve_CurveBasis pSelectedCurve {get;set;}

		[NinjaScriptProperty]
		[Display(Name = "Structure Qualifier", GroupName = " Parameters", Description = "When is a structure change qualified?", Order = 05)]
		public ARC_AuctionCurve_StructureQualifiers StructureQualifier {get;set;}
		[NinjaScriptProperty]
		[Range(0,200)]
		[Display(Name = "Qualifier ATR mult", GroupName = " Parameters", Description = "When is a structure change qualified?", Order = 10)]
		public double QualifyingATRmult {get;set;}
		[NinjaScriptProperty]
		[Range(1,100)]
		[Display(Name = "Qualifier ATR period", GroupName = " Parameters", Description = "ATR period for structure change qualification?", Order = 15)]
		public int QualifyingATRperiod {get;set;}
		
//		[Display(Name = "Use Session Date", GroupName = " Parameters", Description = "Use Session date as the reset period for daily H/L, if not, then it will use calendar date as reset", Order = 20)]
		public bool UseSessionDate = true;//{get;set;}

#if ENABLE_CURRENTCURVE
		[Display(Name = "Prevent Overlap", GroupName = " Parameters", Description = "Automatically moves current curve away from daily curve so that no visual overlap occurs", Order = 30)]
		public bool PreventVisualOverlap {get;set;}
#else
		public bool PreventVisualOverlap = false;
#endif
        [Display(Name = "Button Text", GroupName = " Parameters", Description = "", Order = 40)]
		public string pButtonText {get;set;}

		[Display(Name = "Mode", GroupName = "Sentiment Parameters", Description = "Type of fast-structure detection", Order = 10)]
		public ARC_AuctionCurve_SentimentDetectionMode SentimentDetectionMode { get; set; }
		[Display(Name = "Location", GroupName = "Sentiment Parameters", Description = "Location (on chart) of the sentiment dialog", Order = 20)]
		public ARC_AuctionCurve_SentimentDialogLoc SentimentDialogLoc { get; set; }
		[Display(Name = "Verbose", GroupName = "Sentiment Parameters", Description = "Verbose = true means the Sentiment Dialog will contain the headings", Order = 30)]
		public bool VerboseSentimentDialog { get; set; }

		#region StructureDetector Parameters

		[Display(Name = "Font", GroupName = "StructureDetector Parameters", Description = "Font for structure detector dialog", Order = 30)]
		public SimpleFont StructureDialogFont {get; set;}

		[XmlIgnore]
		[Display(Name = "Up Text color", GroupName = "StructureDetector Parameters", Description = "Color of text of up-biased structure dialog box", Order = 40)]
		public Brush StructureDialogText_UpBrush { get; set; }
		[XmlIgnore]
		[Display(Name = "Down Text color", GroupName = "StructureDetector Parameters", Description = "Color of text of down-biased structure dialog box", Order = 50)]
		public Brush StructureDialogText_DownBrush { get; set; }

		[XmlIgnore]
		[Display(Name = "Up Bkg color", GroupName = "StructureDetector Parameters", Description = "Color of background of up-biased structure dialog box", Order = 60)]
		public Brush StructureDialogBkg_UpBrush { get; set; }
		[Range(0, 100)]
		[Display(Name = "Up Bkg Opacity", GroupName = "StructureDetector Parameters", Description = "Opacity of background coloron UP structure", Order = 70)]
		public int StructureDialogBkg_UpOpacity { get; set; }

		[XmlIgnore]
		[Display(Name = "Down Bkg color", GroupName = "StructureDetector Parameters", Description = "Color of background of down-biased structure dialog box", Order = 80)]
		public Brush StructureDialogBkg_DownBrush { get; set; }
		[Range(0, 100)]
		[Display(Name = "Down Bkg Opacity", GroupName = "StructureDetector Parameters", Description = "Opacity of background coloron UP structure", Order = 90)]
		public int StructureDialogBkg_DownOpacity { get; set; }

		#region brush serializers
			[Browsable(false)]
			public string SDetector_UpBkgTrendColorSerialize
			{get { return Serialize.BrushToString(StructureDialogBkg_UpBrush); }
                                        set { StructureDialogBkg_UpBrush = Serialize.StringToBrush(value); }}
			[Browsable(false)]
			public string SDetector_DnBkgTrendColorSerialize
			{get { return Serialize.BrushToString(StructureDialogBkg_DownBrush); }
                                        set { StructureDialogBkg_DownBrush = Serialize.StringToBrush(value); }}
			[Browsable(false)]
			public string SDetector_UpTextTrendColorSerialize
			{get { return Serialize.BrushToString(StructureDialogText_UpBrush); }
                                        set { StructureDialogText_UpBrush = Serialize.StringToBrush(value); }}
			[Browsable(false)]
			public string SDetector_DnTextTrendColorSerialize
			{get { return Serialize.BrushToString(StructureDialogText_DownBrush); }
                                        set { StructureDialogText_DownBrush = Serialize.StringToBrush(value); }}
		#endregion
		#endregion

		#region -- SwingTrend Parameters --

		[Display(Name = "Use Highs/Lows", GroupName = "SwingTrend Parameters", Description = "Use High/Lows or Input", Order = 5)]
		public bool isHLBased { get; set; }

		[Range(1, 200)]
		[Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 10)]
		public int SwingStrength { get; set; }

		[Range(0, double.MaxValue)]
		[Display(Name = "Deviation multiplier", GroupName = "SwingTrend Parameters", Description = "Multiplier used to calculate minimum as an ATR multiple", Order = 15)]
		public double MultiplierMD { get; set; }

		[Range(0, double.MaxValue)]
		[Display(Name = "Sensitivity double tops/bottoms", GroupName = "SwingTrend Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 20)]
		public double MultiplierDTB { get; set; }

		[Display(Name = "Show Background Color", GroupName = "SwingTrend Parameters", Description = "Colorize the background up/down structure trend zones", Order = 30)]
		public bool ShowStructureBackground {get;set;}

		[XmlIgnore]
		[Display(Name = "Up-trend bkg color", GroupName = "SwingTrend Parameters", Description = "Background color for up-trending structure", Order = 35)]
		public Brush UpTrendColor { get; set; }
		[Browsable(false)]
		public string UpTrendColorSerialize
		{get { return Serialize.BrushToString(UpTrendColor); }
                                        set { UpTrendColor = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Name = "Opacity (up-trend)", GroupName = "SwingTrend Parameters", Description = "Opacity of the up-trend background color", Order = 40)]
		public int OpacityUpTrendBkg { get; set; }

		[XmlIgnore]
		[Display(Name = "Down-trend bkg color", GroupName = "SwingTrend Parameters", Description = "Background color for down-trending structure", Order = 45)]
		public Brush DownTrendColor { get; set; }
		[Browsable(false)]
		public string DownTrendColorSerialize
		{get { return Serialize.BrushToString(DownTrendColor); }
                                        set { DownTrendColor = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Name = "Opacity (down-trend)", GroupName = "SwingTrend Parameters", Description = "Opacity of the down-trend background color", Order = 50)]
		public int OpacityDownTrendBkg { get; set; }


		[Display(Name = "Show Lines", GroupName = "SwingTrend Parameters", Description = "Show structure trend lines", Order = 53)]
		public bool ShowStructureLines {get;set;}

		[XmlIgnore]
		[Display(Name = "Up-trend line color", GroupName = "SwingTrend Parameters", Description = "Line color for up-trending structure", Order = 55)]
		public Brush UpLineColor { get; set; }
		[Browsable(false)]
		public string UpLineColorSerialize
		{get { return Serialize.BrushToString(UpLineColor); }
		                                set { UpLineColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Down-trend line color", GroupName = "SwingTrend Parameters", Description = "Line color for down-trending structure", Order = 60)]
		public Brush DownLineColor { get; set; }
		[Browsable(false)]
		public string DownLineColorSerialize
		{get { return Serialize.BrushToString(DownLineColor); }
		                                set { DownLineColor = Serialize.StringToBrush(value); }}
		[Range(1, 10)]
		[Display(Name = "Line Thickness", GroupName = "SwingTrend Parameters", Description = "Thickness of structure lines", Order = 65)]
		public int ZZLineThickness {get;set;}

		[Display(Name = "Show Labels", GroupName = "SwingTrend Parameters", Description = "Show zigzag labels (e.g. 'HH' or 'LH', etc)", Order = 70)]
		public bool ShowStructureLabels{get;set;}

		[Display(Name = "Font size", GroupName = "SwingTrend Parameters", Description = "Font for structure labels", Order = 80)]
        public SimpleFont pZZlabelFont { get; set; }

		#endregion

		private int pdZoneCount = 2;
		[NinjaScriptProperty]
		[Display(Name = "Number of zones", GroupName = "Daily Zone Count", Description = "Select either 2 or 4 zones on the curve", Order = 120)]
		public int dZoneCount { 
			get {return pdZoneCount;}
			set{ if(value<4) pdZoneCount = 2; else pdZoneCount = 4;}
		}

		#region -- Daily Curve --
		[Display(Name = "Curve Enabled", GroupName = "Daily Curve", Description = "", Order = 00)]
		public bool dShowCurve { get; set; }

//        [NinjaScriptProperty]
//        [Range(0, 1000)]
//        [Display(Name = "Defiance ATR (%)", GroupName = "Daily Curve", Description = "", Order = 10)]
//        public int diDefiance { get; set; }

//        [NinjaScriptProperty]
//        [Range(0, 1000)]
//        [Display(Name = "Break H/L ATR (%)", GroupName = "Daily Curve", Description = "", Order = 20)]
//        public int dBreakATR { get; set; }

//        [NinjaScriptProperty]
//        [Display(Name = "Zone Snap Enabled", GroupName = "Daily Curve", Description = "", Order = 30)]
//        public bool diIncludeZone { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "Percent 1", GroupName = "Daily Curve", Description = "", Order = 40)]
		public double dPercent5 { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "Percent 2", GroupName = "Daily Curve", Description = "", Order = 50)]
		public double dPercent4 { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "Percent 3", GroupName = "Daily Curve", Description = "", Order = 60)]
		public double dPercent3 { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "Percent 4", GroupName = "Daily Curve", Description = "", Order = 70)]
		public double dPercent2 { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "Percent 5", GroupName = "Daily Curve", Description = "", Order = 80)]
		public double dPercent1 { get; set; }

		[Display(Name = "Show Name Labels", GroupName = "Daily Curve", Description = "", Order = 90)]
		public bool dDisplayText { get; set; }

		[Display(Name = "Show Percent Labels", GroupName = "Daily Curve", Description = "", Order = 100)]
		public bool dDisplayPercent { get; set; }

		[XmlIgnore]
		[Display(Name = "Deep Retail Area Color", GroupName = "Daily Curve", Description = "", Order = 120)]
		public Brush dCurveAreaColor4 { get; set; }
		[Browsable(false)]
		public string dCurveAreaColor4Serialize
		{get { return Serialize.BrushToString(dCurveAreaColor4); } set { dCurveAreaColor4 = Serialize.StringToBrush(value); }
		}

		[Range(0, 100)]
		[Display(Name = "Deep Retail Area Opacity (%)", GroupName = "Daily Curve", Description = "The opacity in percent.", Order = 130)]
		public int dCurveOpacity4 { get; set; }

		[XmlIgnore]
		[Display(Name = "Retail Area Color", GroupName = "Daily Curve", Description = "", Order = 140)]
		public Brush dCurveAreaColor3 { get; set; }
		[Browsable(false)]
		public string dCurveAreaColor3Serialize
		{
		    get { return Serialize.BrushToString(dCurveAreaColor3); }
		    set { dCurveAreaColor3 = Serialize.StringToBrush(value); }
		}

		[Range(0, 100)]
		[Display(Name = "Retail Area Opacity (%)", GroupName = "Daily Curve", Description = "The opacity in percent.", Order = 150)]
		public int dCurveOpacity3 { get; set; }

		[XmlIgnore]
		[Display(Name = "Value Area Color", GroupName = "Daily Curve", Description = "", Order = 160)]
		public Brush dCurveAreaColor2 { get; set; }
		[Browsable(false)]
		public string dCurveAreaColor2Serialize
		{
		    get { return Serialize.BrushToString(dCurveAreaColor2); }
		    set { dCurveAreaColor2 = Serialize.StringToBrush(value); }
		}

		[Range(0, 100)]
		[Display(Name = "Value Area Opacity (%)", GroupName = "Daily Curve", Description = "The opacity in percent.", Order = 170)]
		public int dCurveOpacity2 { get; set; }

		[XmlIgnore]
		[Display(Name = "Deep Value Area Color", GroupName = "Daily Curve", Description = "", Order = 180)]
		public Brush dCurveAreaColor1 { get; set; }
		[Browsable(false)]
		public string dCurveAreaColor1Serialize
		{
		    get { return Serialize.BrushToString(dCurveAreaColor1); }
		    set { dCurveAreaColor1 = Serialize.StringToBrush(value); }
		}

		[Range(0, 100)]
		[Display(Name = "Deep Value Area Opacity (%)", GroupName = "Daily Curve", Description = "The opacity in percent.", Order = 190)]
		public int dCurveOpacity1 { get; set; }

		[XmlIgnore]
		[Display(Name = "Outline Color", GroupName = "Daily Curve", Description = "", Order = 200)]
		public Brush dLineColor { get; set; }
		[Browsable(false)]
		public string diLineColor1Serialize
		{
		    get { return Serialize.BrushToString(dLineColor); }
		    set { dLineColor = Serialize.StringToBrush(value); }
		}

		[Range(1, int.MaxValue)]
		[Display(Name = "Outline Width", GroupName = "Daily Curve", Description = "", Order = 210)]
		public int dCurveLineThickness { get; set; }

		[Display(Name = "Text Font", GroupName = "Daily Curve", Description = "Choose your font style curve text.", Order = 220)]
		public SimpleFont dTextFont { get; set; }

		[Range(0, int.MaxValue)]
		[Display(Name = "Max width in margin", GroupName = "Daily Curve", Description = "Max width of the curves, if squeezed into the right-side margin space, set to 0 to turn-off this squeezing", Order = 230)]
		public int MaxWidthInMargin {get;set;}

		[Range(0, 100)]
		[Display(Name = "Curve Loc X", GroupName = "Daily Curve", Description = "Location of curve, as a % of chart width", Order = 240)]
		public int dCurveLocX { get; set; }

		[Range(0, int.MaxValue)]
		[Display(Name = "Curve Width", GroupName = "Daily Curve", Description = "adjust the curve length, in pixels.", Order = 250)]
		public int dCurveLength { get; set; }

		[Display(Name = "Show Price Labels", GroupName = "Daily Curve", Description = "", Order = 260)]
		public bool dDisplayPrice { get; set; }

		#region Midline
		[Display(Name = "Show Midline", GroupName = "Daily Curve", Description = "Show midline of the curve as a fully extended line, color to be based on current price in relation to the midline of the AuctionCurve", Order = 270)]
		public bool Extend50Line { get; set; }
		[Range(1f, 100f)]
		[Display(Name = "Midline Thickness", GroupName = "Daily Curve", Description = "Midline thickness", Order = 280)]
		public float MidlineThickness { get; set; }

		[XmlIgnore]
		[Display(Name = "Midline Retail", GroupName = "Daily Curve", Description = "Color of midline when price is in the Retail area of the curve", Order = 290)]
		public Brush MidlineRetailColor { get; set; }
		[Browsable(false)]
		public string MidlineRetailColorSerialize
		{get { return Serialize.BrushToString(MidlineRetailColor); } set { MidlineRetailColor = Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(Name = "Midline Value", GroupName = "Daily Curve", Description = "Color of midline when price is in the Value area of the curve", Order = 300)]
		public Brush MidlineValueColor { get; set; }
		[Browsable(false)]
		public string MidlineValueColorSerialize
		{get { return Serialize.BrushToString(MidlineValueColor); } set { MidlineValueColor = Serialize.StringToBrush(value); }
		}
		#endregion

		#endregion

		#region -- ATR Forecaster category
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="ATR_period", Order=10, GroupName="ATR Forecaster")]
		public int ATR_period
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="LookbackDays", Order=20, GroupName="ATR Forecaster")]
		public int LookbackDays
		{ get; set; }

		[Display(Name="Check for sufficient data", Order=30, GroupName="ATR Forecaster")]
		public bool UserReqestsDataCheck
		{ get; set; }

		private bool pShowFixedLevels = true;
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name="Show Fixed Levels", Order=40, GroupName="ATR Forecaster")]
		public bool ShowFixedLevels
		{	get { return pShowFixedLevels; }
			set { pShowFixedLevels = value; 
					pShowDynamicLevels = !value;}
		}

		private bool pShowDynamicLevels = false;
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name="Show Dynamic Levels", Order=50, GroupName="ATR Forecaster")]
		public bool ShowDynamicLevels
		{	get { return pShowDynamicLevels; }
			set { pShowDynamicLevels = value; 
					pShowFixedLevels = !value;}
		}

		#endregion -----------------------
		#endregion
//        #region -- Indicator Display --====================================
//        [Range(0, 100)]
//        [Display(Name = "Chart Button Size (Pixels)", GroupName = "Indicator Display", Description = "", Order = 00)]
//        public int iButtonSize { get; set; }

//        [Range(0, 100)]
//        [Display(Name = "Chart Button Text Size", GroupName = "Indicator Display", Description = "font will match as configured for the main chart. adjust the size here.", Order = 10)]
//        public int iButtonTextSize { get; set; }
//        #endregion
		#region -- Plots --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> StructureState { get { Update(); return Values[0]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> CurveState { get { Update(); return Values[1]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PermissiveSignal { get { Update(); return Values[2]; } }

//		[Range(1, int.MaxValue)]
//		[Display(Name = "Line width major lines", GroupName = "Plots", Description = "Width for major lines.", Order = 2)]
//		public int LineWidthStrong { get; set; }

		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_AuctionCurve[] cacheARC_AuctionCurve;
		public ARC.ARC_AuctionCurve ARC_AuctionCurve(ARC_AuctionCurve_CurveBasis pSelectedCurve, ARC_AuctionCurve_StructureQualifiers structureQualifier, double qualifyingATRmult, int qualifyingATRperiod, int dZoneCount, double dPercent5, double dPercent4, double dPercent3, double dPercent2, double dPercent1, int aTR_period, int lookbackDays, bool showFixedLevels, bool showDynamicLevels)
		{
			return ARC_AuctionCurve(Input, pSelectedCurve, structureQualifier, qualifyingATRmult, qualifyingATRperiod, dZoneCount, dPercent5, dPercent4, dPercent3, dPercent2, dPercent1, aTR_period, lookbackDays, showFixedLevels, showDynamicLevels);
		}

		public ARC.ARC_AuctionCurve ARC_AuctionCurve(ISeries<double> input, ARC_AuctionCurve_CurveBasis pSelectedCurve, ARC_AuctionCurve_StructureQualifiers structureQualifier, double qualifyingATRmult, int qualifyingATRperiod, int dZoneCount, double dPercent5, double dPercent4, double dPercent3, double dPercent2, double dPercent1, int aTR_period, int lookbackDays, bool showFixedLevels, bool showDynamicLevels)
		{
			if (cacheARC_AuctionCurve != null)
				for (int idx = 0; idx < cacheARC_AuctionCurve.Length; idx++)
					if (cacheARC_AuctionCurve[idx] != null && cacheARC_AuctionCurve[idx].pSelectedCurve == pSelectedCurve && cacheARC_AuctionCurve[idx].StructureQualifier == structureQualifier && cacheARC_AuctionCurve[idx].QualifyingATRmult == qualifyingATRmult && cacheARC_AuctionCurve[idx].QualifyingATRperiod == qualifyingATRperiod && cacheARC_AuctionCurve[idx].dZoneCount == dZoneCount && cacheARC_AuctionCurve[idx].dPercent5 == dPercent5 && cacheARC_AuctionCurve[idx].dPercent4 == dPercent4 && cacheARC_AuctionCurve[idx].dPercent3 == dPercent3 && cacheARC_AuctionCurve[idx].dPercent2 == dPercent2 && cacheARC_AuctionCurve[idx].dPercent1 == dPercent1 && cacheARC_AuctionCurve[idx].ATR_period == aTR_period && cacheARC_AuctionCurve[idx].LookbackDays == lookbackDays && cacheARC_AuctionCurve[idx].ShowFixedLevels == showFixedLevels && cacheARC_AuctionCurve[idx].ShowDynamicLevels == showDynamicLevels && cacheARC_AuctionCurve[idx].EqualsInput(input))
						return cacheARC_AuctionCurve[idx];
			return CacheIndicator<ARC.ARC_AuctionCurve>(new ARC.ARC_AuctionCurve(){ pSelectedCurve = pSelectedCurve, StructureQualifier = structureQualifier, QualifyingATRmult = qualifyingATRmult, QualifyingATRperiod = qualifyingATRperiod, dZoneCount = dZoneCount, dPercent5 = dPercent5, dPercent4 = dPercent4, dPercent3 = dPercent3, dPercent2 = dPercent2, dPercent1 = dPercent1, ATR_period = aTR_period, LookbackDays = lookbackDays, ShowFixedLevels = showFixedLevels, ShowDynamicLevels = showDynamicLevels }, input, ref cacheARC_AuctionCurve);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_AuctionCurve ARC_AuctionCurve(ARC_AuctionCurve_CurveBasis pSelectedCurve, ARC_AuctionCurve_StructureQualifiers structureQualifier, double qualifyingATRmult, int qualifyingATRperiod, int dZoneCount, double dPercent5, double dPercent4, double dPercent3, double dPercent2, double dPercent1, int aTR_period, int lookbackDays, bool showFixedLevels, bool showDynamicLevels)
		{
			return indicator.ARC_AuctionCurve(Input, pSelectedCurve, structureQualifier, qualifyingATRmult, qualifyingATRperiod, dZoneCount, dPercent5, dPercent4, dPercent3, dPercent2, dPercent1, aTR_period, lookbackDays, showFixedLevels, showDynamicLevels);
		}

		public Indicators.ARC.ARC_AuctionCurve ARC_AuctionCurve(ISeries<double> input , ARC_AuctionCurve_CurveBasis pSelectedCurve, ARC_AuctionCurve_StructureQualifiers structureQualifier, double qualifyingATRmult, int qualifyingATRperiod, int dZoneCount, double dPercent5, double dPercent4, double dPercent3, double dPercent2, double dPercent1, int aTR_period, int lookbackDays, bool showFixedLevels, bool showDynamicLevels)
		{
			return indicator.ARC_AuctionCurve(input, pSelectedCurve, structureQualifier, qualifyingATRmult, qualifyingATRperiod, dZoneCount, dPercent5, dPercent4, dPercent3, dPercent2, dPercent1, aTR_period, lookbackDays, showFixedLevels, showDynamicLevels);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_AuctionCurve ARC_AuctionCurve(ARC_AuctionCurve_CurveBasis pSelectedCurve, ARC_AuctionCurve_StructureQualifiers structureQualifier, double qualifyingATRmult, int qualifyingATRperiod, int dZoneCount, double dPercent5, double dPercent4, double dPercent3, double dPercent2, double dPercent1, int aTR_period, int lookbackDays, bool showFixedLevels, bool showDynamicLevels)
		{
			return indicator.ARC_AuctionCurve(Input, pSelectedCurve, structureQualifier, qualifyingATRmult, qualifyingATRperiod, dZoneCount, dPercent5, dPercent4, dPercent3, dPercent2, dPercent1, aTR_period, lookbackDays, showFixedLevels, showDynamicLevels);
		}

		public Indicators.ARC.ARC_AuctionCurve ARC_AuctionCurve(ISeries<double> input , ARC_AuctionCurve_CurveBasis pSelectedCurve, ARC_AuctionCurve_StructureQualifiers structureQualifier, double qualifyingATRmult, int qualifyingATRperiod, int dZoneCount, double dPercent5, double dPercent4, double dPercent3, double dPercent2, double dPercent1, int aTR_period, int lookbackDays, bool showFixedLevels, bool showDynamicLevels)
		{
			return indicator.ARC_AuctionCurve(input, pSelectedCurve, structureQualifier, qualifyingATRmult, qualifyingATRperiod, dZoneCount, dPercent5, dPercent4, dPercent3, dPercent2, dPercent1, aTR_period, lookbackDays, showFixedLevels, showDynamicLevels);
		}
	}
}

#endregion
