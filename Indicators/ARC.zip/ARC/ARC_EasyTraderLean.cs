#define DoLicense
#define MODERATORS
#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Windows.Controls;
using System.IO;

using EasyTraderLean.UI;
using System.Windows.Automation;
using System.Diagnostics;
using EasyTraderLean.Settings;
using EasyTraderLean.UI.UI;
using EasyTraderLean.Bridge;
using ARC.AlgoSupLean;
using ARC.AlgoSup.All;
using System.Collections.Concurrent;
using ARC.CTESup.UI;
using manager = ARC.CTESup;

#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC
{

    #region RegHelper

    public class ArcAlgoNewAccountNameFinderLean : TypeConverter
    {
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            if (context == null)
                return null;

            System.Collections.ArrayList list = new System.Collections.ArrayList();

            for (int i = 0; i < Account.All.Count; i++)
            {
                if (Account.All[i].ConnectionStatus == ConnectionStatus.Connected)
                    list.Add(Account.All[i].Name);
            }

            return new TypeConverter.StandardValuesCollection(list);
        }

        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        { return true; }
    }

    public class ArcAlgoNewTemplatesFolderFinderLean : TypeConverter
    {
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            if (context == null)
            { return null; }
            System.Collections.ArrayList list = new System.Collections.ArrayList();

            DirectoryInfo dir = new DirectoryInfo(System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "templates", "EasyAlgo"));
            FileInfo[] files = null;
            if (dir != null && dir.Exists)
            {
                files = dir.GetFiles("*.xml");
                foreach (FileInfo fi in files)
                {
                    list.Add(fi.Name.Replace(fi.Extension, string.Empty));
                }
            }
            return new TypeConverter.StandardValuesCollection(list);
        }
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        { return true; }
    }

    #endregion

    public class ARCEasyTraderLean : Indicator
    {
        #region Indicator Versioning
        public string VERSION = "v1.0.6 12-Apr-2023";
        /// <summary>
        /// v1.0.1:  Created the software from the base Easy Trader
        /// v1.0.2:  Changed PositionManagerAccount to set the OrderIdentified flag to false if the entry order is rejected
        /// v1.0.3:  Updated the code to use ConcurrentDictionary instead of simple Dictionary for the buttons to eliminate any thread locking
        /// v1.0.4:  Nuked everything but the basics
        ///          Updated the back end of the ea to be a static class that takes care of all the EA's not just the one
        /// v1.0.5:  Fixed the too many stops bug
        /// v1.0.6:  Fixed Account not updating unless it is refreshed.
        ///          Fixed indicator not updating in the UI
        ///          Fixed Error message when you hit execute
        ///          Fixed Position never being null
        /// </summary>

        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }
        #endregion

        #region Licensing Stuff
        private bool ValidLicense = true;
        private bool LicenseChecked = true;
        private string UserId = string.Empty;
        private string MachineId = string.Empty;
        string ModuleName = "EasyTrader (Lean)";
        private string fileName;
        private static int etCounters = 0;
        private int stateMessage = 0;
        #region LicErrorMessageHandler
        static class LicErrorMessageHandler
        {
            static System.Collections.Generic.SortedDictionary<string, long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string, long>();
            static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

            static public void SetModuleExpired(string moduleToExpire)
            {
                ExpiredModules.Add(moduleToExpire);
            }
            static public bool IsExpired(string moduleToCheck)
            {
                return ExpiredModules.Contains(moduleToCheck);
            }
            static public bool IsDuplicate(string new_msg)
            {
                var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
                foreach (string keymsg in keys)
                {
                    if (keymsg.CompareTo(new_msg) == 0)
                    {
                        var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
                        if (ts.TotalMinutes < 2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
                            return true;
                        ErrorMessages[new_msg] = DateTime.Now.Ticks;
                        return false;
                    }
                }
                ErrorMessages[new_msg] = DateTime.Now.Ticks;
                return false;
            }
        }
        #endregion
        List<string> Expected_ISTagSet = new List<string>() { "22344", "13377", "25900", "27405"};//27405 is Annual Membership
        #region ARCLicense
        #region --  Registry class  --
        public class ModifyRegistry
        {
            public int NO_KEY_DEFINED = -1;
            public int ERROR_READING_KEY = -2;
            public string ErrorStatus = string.Empty;

            private bool showError = true;
            /// <summary>
            /// A property to show or hide error messages 
            /// (default = false)
            /// </summary>
            public bool ShowError
            {
                get { return showError; }
                set { showError = value; }
            }

            private string subKey = "Software\\NeuroStreet\\Settings";
            /// <summary>
            /// A property to set the SubKey value
            /// (default = "SOFTWARE\\" + Application.ProductName.ToUpper())
            /// </summary>
            public string SubKey
            {
                get { return subKey; }
                set { subKey = value; }
            }

            private Microsoft.Win32.RegistryKey baseRegistryKey = Microsoft.Win32.Registry.CurrentUser;
            /// <summary>
            /// A property to set the BaseRegistryKey value.
            /// (default = Registry.LocalMachine)
            /// </summary>
            public Microsoft.Win32.RegistryKey BaseRegistryKey
            {
                get { return baseRegistryKey; }
                set { baseRegistryKey = value; }
            }

            /* **************************************************************************
			 * **************************************************************************/

            /// <summary>
            /// To read a registry key.
            /// input: KeyName (string)
            /// output: value (string) 
            /// </summary>
            public int Read(string KeyName, NinjaTrader.NinjaScript.IndicatorBase parent)
            {
                // Opening the registry key
                var rk = baseRegistryKey;
                // Open a subKey as read-only
                var sk1 = rk.OpenSubKey(subKey);
                // If the RegistrySubKey doesn't exist -> (null)
                if (sk1 == null)
                {
                    return NO_KEY_DEFINED;
                }
                else
                {
                    try
                    {
                        // If the RegistryKey exists I get its value
                        // or null is returned.
                        return Convert.ToInt32(sk1.GetValue(KeyName));
                    }
                    catch (Exception e)
                    {
                        ErrorStatus = e.ToString();
                        // AAAAAAAAAAARGH, an error!
                        if (parent != null) ShowErrorMessage(e, "Reading registry " + KeyName, parent);
                        return ERROR_READING_KEY;
                    }
                }
            }

            /* **************************************************************************
			 * **************************************************************************/

            /// <summary>
            /// To write into a registry key.
            /// input: KeyName (string) , Value (object)
            /// output: true or false 
            /// </summary>
            public bool Write(string KeyName, object Value, NinjaTrader.NinjaScript.IndicatorBase parent)
            {
                try
                {
                    // Setting
                    var rk = baseRegistryKey;
                    // I have to use CreateSubKey 
                    // (create or open it if already exits), 
                    // 'cause OpenSubKey open a subKey as read-only
                    var sk1 = rk.CreateSubKey(subKey);
                    // Save the value
                    sk1.SetValue(KeyName, Value);

                    return true;
                }
                catch (Exception e)
                {
                    ErrorStatus = e.ToString();
                    // AAAAAAAAAAARGH, an error!
                    ShowErrorMessage(e, "Writing registry " + KeyName, parent);
                    return false;
                }
            }

            /* **************************************************************************
			 * **************************************************************************/

            /// <summary>
            /// To delete a registry key.
            /// input: KeyName (string)
            /// output: true or false 
            /// </summary>
            public bool DeleteKey(string KeyName, NinjaTrader.NinjaScript.IndicatorBase parent)
            {
                try
                {
                    // Setting
                    var rk = baseRegistryKey;
                    var sk1 = rk.CreateSubKey(subKey);
                    // If the RegistrySubKey doesn't exists -> (true)
                    if (sk1 == null)
                        return true;
                    else
                        sk1.DeleteValue(KeyName);

                    return true;
                }
                catch (Exception e)
                {
                    ErrorStatus = e.ToString();
                    // AAAAAAAAAAARGH, an error!
                    ShowErrorMessage(e, "Deleting SubKey " + subKey, parent);
                    return false;
                }
            }

            /* **************************************************************************
			 * **************************************************************************/

            /// <summary>
            /// To delete a sub key and any child.
            /// input: void
            /// output: true or false 
            /// </summary>
            public bool DeleteSubKeyTree(NinjaTrader.NinjaScript.IndicatorBase parent)
            {
                try
                {
                    // Setting
                    var rk = baseRegistryKey;
                    var sk1 = rk.OpenSubKey(subKey);
                    // If the RegistryKey exists, I delete it
                    if (sk1 != null)
                        rk.DeleteSubKeyTree(subKey);

                    return true;
                }
                catch (Exception e)
                {
                    ErrorStatus = e.ToString();
                    // AAAAAAAAAAARGH, an error!
                    ShowErrorMessage(e, "Deleting SubKey " + subKey, parent);
                    return false;
                }
            }

            /* **************************************************************************
			 * **************************************************************************/

            /// <summary>
            /// Retrive the count of subkeys at the current key.
            /// input: void
            /// output: number of subkeys
            /// </summary>
            public int SubKeyCount(NinjaTrader.NinjaScript.IndicatorBase parent)
            {
                try
                {
                    // Setting
                    var rk = baseRegistryKey;
                    var sk1 = rk.OpenSubKey(subKey);
                    // If the RegistryKey exists...
                    if (sk1 != null)
                        return sk1.SubKeyCount;
                    else
                        return 0;
                }
                catch (Exception e)
                {
                    ErrorStatus = e.ToString();
                    // AAAAAAAAAAARGH, an error!
                    ShowErrorMessage(e, "Retriving subkeys of " + subKey, parent);
                    return 0;
                }
            }

            /* **************************************************************************
			 * **************************************************************************/

            /// <summary>
            /// Retrive the count of values in the key.
            /// input: void
            /// output: number of keys
            /// </summary>
            public int ValueCount(NinjaTrader.NinjaScript.IndicatorBase parent)
            {
                try
                {
                    // Setting
                    var rk = baseRegistryKey;
                    var sk1 = rk.OpenSubKey(subKey);
                    // If the RegistryKey exists...
                    if (sk1 != null)
                        return sk1.ValueCount;
                    else
                        return 0;
                }
                catch (Exception e)
                {
                    ErrorStatus = e.ToString();
                    // AAAAAAAAAAARGH, an error!
                    ShowErrorMessage(e, "Retriving keys of " + subKey, parent);
                    return 0;
                }
            }

            /* **************************************************************************
			 * **************************************************************************/

            private void ShowErrorMessage(Exception e, string Title, NinjaTrader.NinjaScript.IndicatorBase parent)
            {
                if (showError)
                    parent.Print(e.Message);
            }
        }
        #endregion ----------------------------------------
        ModifyRegistry Reg = new ModifyRegistry();
        private int NewCustId = -1;
        private string XORCipher(string data, string key2)
        {
            #region xorcipher
            if (data == null) return null;
            if (key2 == null) return null;
            int dataLen = data.Length;
            char[] output = new char[dataLen];

            var chars = key2.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
                if (chars[i] < '0' || chars[i] > '9') chars[i] = '0';
            key2 = new String(chars);

            //			while(key2.Length<32)
            //				key2 = string.Format("{0}0",key2);
            //			chars = key2.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
                chars[i] = (char)((int)'a' + 2 * ((int)chars[i] - (int)'0'));
            var key1 = string.Empty;
            for (int i = chars.Length - 1; i >= 0; i--)
            {
                key1 = string.Format("{0}{1}", key1, chars[i]);
            }

            //Print("Key1 ("+key1.Length+"): '"+key1+"'");
            //Print("Key2 ("+key2.Length+"): '"+key2+"'");
            if (key1 != key2)
            {
                int keyLen = key1.Length;
                for (int i = 0; i < dataLen; ++i)
                    output[i] = (char)(data[i] ^ key1[i % keyLen]);
                //Print("Pass1: "+key1);
                //Print(this.FromCharArrayToHexString(output));
                keyLen = key2.Length;
                for (int i = 0; i < dataLen; ++i)
                    output[i] = (char)(output[i] ^ key2[i % keyLen]);
                //Print("Pass2: "+key2);
                //Print(this.FromCharArrayToHexString(output));
                keyLen = key1.Length;
                for (int i = 0; i < dataLen; ++i)
                    output[i] = (char)(output[i] ^ key1[i % keyLen]);
                //Print("Pass3: "+key1);
                //Print(this.FromCharArrayToHexString(output));
            }
            else
            {
                var keyLen = key2.Length;
                for (int i = 0; i < dataLen; ++i)
                    output[i] = (char)(data[i] ^ key2[i % keyLen]);
            }
            #endregion
            return new string(output);
        }
        private char[] FromHexToByteArray(string input)
        {
            #region FromHexToByteArray
            input = input.Trim();
            if (input.Length == 0)
            {
                //Print("FromHexToByteArray, input string zero length");
                return null;
            }
            char[] result = new char[input.Length / 2];
            try
            {
                int i = 0;
                int r = 0;
                string s = null;
                uint u = 0;
                //Print("input.Length: "+input.Length);
                //Print("result.Length: "+result.Length);
                while (i < input.Length)
                {
                    //Print("  r: "+r);
                    //Print("  i: "+i);
                    s = input.Substring(i, 2);
                    if (uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u))
                    {
                        //Print(r+" '"+s+"'   "+u);
                        result[r] = Convert.ToChar(u);
                    }
                    else
                    {
                        Print("FromHexToByteArray, could not covert hex:" + s + " to uint");
                        return null;
                    }
                    r++;
                    i = i + 2;
                }
            }
            catch (Exception e)
            {
                Print("FromHexToByteArray, conversion terminated:" + e.ToString());
                return null;
            }
            #endregion
            return result;
        }
        private string FromCharArrayToHexString(char[] input)
        {
            #region FromCharArrayToHexString
            if (input.Length == 0)
            {
                Print("FromCharArrayToHexString, input string zero length");
                return null;
            }
            //			if(input.Length%2!=0) {
            //				Print("FromCharArrayToHexString, input string length not even number");
            //				return null;
            //			}
            var result = new System.Text.StringBuilder();
            try
            {
                int i = 0;
                int inval = 0;
                string hex = "";
                while (i < input.Length)
                {
                    inval = (int)input[i];
                    hex = string.Format("{00:x}", inval);
                    if (hex.Length == 1) result.Append("0");
                    result.Append(hex);
                    i = i + 1;
                }
            }
            catch (Exception e)
            {
                Print("FromCharArrayToHexString, conversion terminated:" + e.ToString());
                return null;
            }
            #endregion
            var str = result.ToString();
            return str;
        }
        private bool FileIsOld = false;
        private DateTime IndicatorLaunchDT = DateTime.Now;
        private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
        //=====================================================================================================================
        #region Supporting methods
        private string NSConfigDirectory = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NS_config");
        private string ARCConfigDirectory = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ARCAI_license");
        //===========================================================================
        private bool IsoFileExists(string IsoFileName, ref bool FileIsOld)
        {
            string fullpath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
            var fileinfo = new System.IO.FileInfo(fullpath);
            DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
            FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
            //Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
            return System.IO.File.Exists(fullpath);

            //			return System.IO.File.Exists(fullpath);
        }
        //===========================================================================
        private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage)
        {
            try
            {
                IsoFileName = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
                //Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
                System.IO.File.WriteAllText(IsoFileName, WriteThisText);

            }
            catch (Exception err)
            {
                ErrorMessage = err.ToString();
                Print("Error " + ErrorMessage);
            }
        }
        //===========================================================================
        private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage)
        {
            /*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

            string result = string.Empty;
            bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
            var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
            if (InputFileExists)
            {//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
                try
                {
                    var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
                    foreach (string L in lines)
                    {
                        if (L.Trim().StartsWith(@"//")) continue;
                        else if (L.Trim().Length == 0) continue;
                        else result = L.Trim();
                    }
                }
                catch (Exception err)
                {
                    ErrorMessage = IsoFileName + " IsoFile read error: " + err.ToString();
                    Print(ErrorMessage);
                }
            }
            if (result.CompareTo(InText) == 0)
            {
                //Print("265:  returning: "+InText);//don't save the InText if matches the stored info
            }
            else if (SaveInText && InText.Trim().Length > 0)
            {
                //Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
                OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
                result = InText;
            }
            return result;
        }
        #endregion
        private int GetCustID(bool PingRegistry)
        {
            #region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
            int ret_custid = -1;
            string folder = ARCConfigDirectory;
            if (!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
            string search = "arccid_*.txt";
            var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
            if (IsDebug) Print("Searching for " + folder + ", arccid_*.txt...");
            if (filCustom != null)
            {
                foreach (System.IO.FileInfo fi in filCustom)
                {
                    if (IsDebug) Print("   reading filename: " + fi.Name);
                    var elements = fi.Name.Split(new char[] { '_', '.' }, StringSplitOptions.RemoveEmptyEntries);
                    if (elements.Length > 1)
                        ret_custid = int.Parse(elements[1]);
                    if (IsDebug) Print("  CustID: " + ret_custid);
                }
            }
            if (ret_custid == -1)
            {
                folder = NSConfigDirectory;
                if (IsDebug) Print("Searching for " + folder + ", nscid_*.txt...");
                search = "nscid_*.txt";
                filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
                if (filCustom != null)
                {
                    foreach (System.IO.FileInfo fi in filCustom)
                    {
                        if (IsDebug) Print("   reading filename: " + fi.Name);
                        var elements = fi.Name.Split(new char[] { '_', '.' }, StringSplitOptions.RemoveEmptyEntries);
                        if (elements.Length > 1)
                            ret_custid = int.Parse(elements[1]);
                        if (IsDebug) Print("   CustID: " + ret_custid);
                    }
                }
            }
            if (ret_custid == -1 && PingRegistry)
            {
                //the config file doesn't exist, create one based on what is recovered from the registry
                try
                {
                    if (IsDebug) Print(" ARCCID file is getting custid from registry because of file missing");
                    ret_custid = Reg.Read("custid", this);
                }
                catch (Exception ex2)
                {
                    if (IsDebug) Print("Registry read error: " + ex2.ToString());
                    if (!LicErrorMessageHandler.IsDuplicate(ex2.ToString())) LogMsg("Please run your 'ARC_LicenseActivator v1' and supply your ARCAI Contact ID number", Cbi.LogLevel.Alert);
                    return -1;
                }
            }
            if (ret_custid > 0)
            {
                System.IO.File.WriteAllText(
                    System.IO.Path.Combine(ARCConfigDirectory, "arccid_" + ret_custid.ToString().Trim() + ".txt"),
                    ret_custid.ToString()
                );
            }
            return ret_custid;
            #endregion
        }
        private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort)
        {
            MachineId = NinjaTrader.Cbi.License.MachineId;
            if (IsDebug) Print("Running ARC License now");
            #region -- NSLicense --
            //if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
            if (LicErrorMessageHandler.IsExpired(ModuleName))
            {
                NewCustId = GetCustID(true);
                UserId = NewCustId.ToString();
                return false;
            }//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
            double HOURS_BETWEEN_PINGS = 48;
            string ErrorMessage = string.Empty;
            bool ValidLicense = false;
            string NL = Environment.NewLine;

            string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt", ModuleName);
            string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

            bool ValidateViaAPI = true;
            long ExpireLongInt = 0;
            string ExpiryDateEncrypted = "";
            #region -- Should we ping the server again? --
            if (IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld))
            {
                if (IsDebug) Print(" Iso file exists...FileIsOld?: " + FileIsOld.ToString());
                //This determines if we need to ping the server again.  Fewer API pings increase speed of verification
                //If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
                //Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
                ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
                if (ExpiryDateEncrypted.Trim().Length > 0)
                {
                    var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
                    if (IsDebug) Print("   Decrypted: " + ExpireDateDecrypted);
                    if (ExpireDateDecrypted.Contains(MachineId))
                    {//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
                        string datestr = ExpireDateDecrypted.Remove(0, ExpireDateDecrypted.IndexOf(':') + 1);
                        if (IsDebug) Print("   DateStr from Iso:  '" + datestr + "'");
                        long.TryParse(datestr, out ExpireLongInt);
                        ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
                        if (IsDebug) Print(" Validate via API: " + ValidateViaAPI.ToString());
                    }
                }
            }
            else
            {
                if (IsDebug) Print(" Iso file not found");
            }
            #endregion

            if (!ValidateViaAPI)
            {
                var d = new DateTime(ExpireLongInt);
                ValidLicense = true;
                UserId = "-9999";
                if (IsDebug) Print(" License is considered valid,  Date from DateStr:  '" + d.ToString() + "'" + "    hours: " + HOURS_BETWEEN_PINGS);
            }
            else
            {
                if (IsDebug) Print(" Getting custid from file");
                NewCustId = GetCustID(true);
                #region -- Read config folder for ContactID --
                //				string folder = ARCConfigDirectory;
                //				string search = "arccid_*.txt";
                //				var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
                //				if(filCustom!=null){
                //					foreach(System.IO.FileInfo fi in filCustom){
                //						var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
                //						if(elements.Length>1)
                //							NewCustId = int.Parse(elements[1]);
                //					}
                //				}else{//the config file doesn't exist, create one based on what is recovered from the registry
                //					try{
                //if(IsDebug) Print(" ARCCID file is getting custid from registry because of file missing");
                //						NewCustId = Reg.Read("custid", this);
                //					}catch(Exception ex2){
                //if(IsDebug) Print("Registry read error: "+ex2.ToString());
                //						if(!LicErrorMessageHandler.IsDuplicate(ex2.ToString())) LogMsg("Please run your 'ARC_LicenseActivator v1' and supply your ARCAI Contact ID number", Cbi.LogLevel.Alert);
                //						return false;
                //					}
                //					if(NewCustId>0){
                //						System.IO.File.WriteAllText(
                //							System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+NewCustId.ToString().Trim()+".txt"),
                //							NewCustId.ToString()
                //						);
                //					}
                //				}
                #endregion
                //if(IsDebug) NewCustId = 239389;
                if (IsDebug) Print("Infusionsoft ContactID:  " + NewCustId);
                UserId = NewCustId.ToString();
#if MODERATORS
                bool IsSeanKozak = UserId.CompareTo("42277") == 0;
                if (IsSeanKozak) return true;
                //if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
                string keyString = Math.Abs(DateTime.Now.Ticks / (DateTime.Now.Second + 10)).ToString("0");
                bool WebsiteFound = false;
                keyString = keyString.Replace("0", string.Empty).Trim();
                if (keyString.Length > 32)
                    keyString = keyString.Substring(0, 32);

                string responseHexStr = string.Empty;
                string msgCB = string.Empty;
                string URL = string.Empty;
                if (IsDebug) Print("Sending webclient request");
                //				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
                {
                    responseHexStr = string.Empty;
                    if (FirstPort < 8080 || LastPort < 8080)
                        //						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
                        URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
                    else
                        URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, NinjaTrader.Cbi.License.MachineId, ModuleName, keyString, UserId);
                    //Print(Port+"   URL: "+url);
                    //if(FirstPort==7070) continue;
                    //continue;
                    try
                    {
                        #region -- Do the license check --
                        var parameters = new System.Collections.Specialized.NameValueCollection();
                        var values = new System.Collections.Generic.Dictionary<string, string>
                            {
                                { "nscustid", NewCustId.ToString() },
                                { "custnum",  MachineId },
                                { "platform", "ninjatrader"},
                                { "version",  ModuleName+" "+indicatorVersion},
                                { "datetime", DateTime.Now.ToString()},
                                { "random",   this.Name}
                            };
                        if (IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
                        var paramstring = string.Empty;
                        foreach (var kvp in values)
                        {
                            if (IsDebug) Print(string.Concat("   ", kvp.Key, ":  ", kvp.Value, Environment.NewLine));
                            parameters.Add(kvp.Key, kvp.Value);
                            if (paramstring.Length == 0)
                                paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
                            else
                                paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
                        }
                        #endregion

                        if (IsDebug) Print(string.Concat("   ", URL, " ?" + paramstring, Environment.NewLine));

                        #region -- Create WebClient and post request --
                        var ntWebClient = new System.Net.WebClient();
                        ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
                        ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
                        System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

                        if (IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
                        try
                        {
                            byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
                            responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
                            if (IsDebug) Print(string.Concat(responseArray.Length, "-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
                            msgCB = string.Empty;
                            WebsiteFound = true;
                        }
                        catch (Exception er)
                        {
                            if (IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
                            msgCB = er.ToString();
                            WebsiteFound = false;
                        }
                        #endregion
                        //==========================================
                    }
                    catch (Exception err)
                    {
                        WebsiteFound = false;
                        msgCB = string.Concat(msgCB, "===================", Environment.NewLine, err.Message);
                    }
                }
                if (!WebsiteFound)
                {
                    msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
                    if (IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}", NL, ModuleName, URL, responseHexStr, msgCB));
                    System.Windows.Forms.Clipboard.SetText(string.Format("==============={0}{1}{0}===============", NL, msgCB));
                    msgCB = string.Format(".Send this msg to {1}{0}(this info has already been copied to your clipboard){0}{2}", NL, SupportEmailAddress, msgCB);
                    if (!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
                    return false;
                }

                string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
                msgCB = string.Empty;
                var ISTagsList = plainText.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                if (IsDebug) Print("PlainText response from api: " + plainText);
                ValidLicense = false;
                foreach (var tag in ISTagsList) if (Expected_ISTagSet.Contains(tag)) { ValidLicense = true; break; }
                if (!ValidLicense)
                {
                    msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
                    System.Windows.Forms.Clipboard.SetText(string.Format("==============={0}{1}{0}===============", NL, msgCB));
                    msgCB = string.Format(".{1}{0}(this info has already been copied to your clipboard)", NL, msgCB);
                    if (!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
                    LicErrorMessageHandler.SetModuleExpired(ModuleName);
                    OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
                }
                else
                {
                    var expire_date_string = string.Format("{0} License good until: {1}", MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).Ticks.ToString());
                    if (IsDebug) Print("License is valid...will Expire: " + expire_date_string);
                    ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
                    OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
                    //Print("ErrorMessage: '"+ErrorMessage+"'");
                }
            }
            return ValidLicense;
            #endregion
            //==============================================================
        }
		private void LogMsg(string msg, LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, LogLevel.Warning);
		}
        #endregion

        bool IsDebug = false;

        #region Other Shit
        private Image PMOnImage;
        private Image PMOffImage;

        private Account oAccount;

        private System.Globalization.CultureInfo cultureFormat;
        private System.Globalization.NumberFormatInfo currencyFormat;
        #endregion

        //		private string ErrorMsgTxt = "EasyTrader was not shut down correctly last time it ran (perhaps the result of NinjaTrader crash).\nIn case of a crash, there is a possibility that some orders and/or live trades\nare now out of sync. You must ensure that the account state,\nas displayed here, reflects the state on your broker account.\nIn case of discrepancies, do not use EasyTrader until the state is fully synchronized";
        private string ErrorMsgTxt = "EasyTrader was not shut down correctly last time it ran (perhaps the result of NinjaTrader crash). In case of a crash, there is a possibility that some orders and/or live tradesare now out of sync. You must ensure that the account state, as displayed here, reflects the state on your broker account. In case of discrepancies, do not use EasyTrader until the state is fully synchronized";
        private DateTime ErrorPrintedAt = DateTime.MinValue;
        #endregion

        /// <summary>
        /// Files to export:
        /// Indicators:
        /// - ARC_EAActionQue
        /// - ARC_EasyTraderLean
        /// - ARC_EAUtils
        /// - ARC_EAVisualModelLean
        /// - ArcCteBackEnd
        /// - ArcCteUiEngine
        /// References:
        /// - EasyTraderLean.UI
        /// - Xceed.Wpf.Toolkit
        /// </summary>

        #region Floating Variables
        public string productName = "ARC_EasyTrader (Lean)";

        //bool
        private int _iWaitingOnClick = 0;
        private int _iDecimalPlaces = 0;
        private double _dAtr = 0;
        private double _dMax = 0;
        private double _dMin = 0;
        private double _dLastSwingLow = 0;
        private double _dLastSwingHigh = 0;
        private double _dHighWaterMark = 0;
        private bool _bWorking = true;
        private bool _bIsChart = true;
        private bool _bAa = false;
        private bool _bIsBlocked = false;
        private bool _bDoneForTheDay = false;
        private bool _bHwmMinReached = false;
        private bool _bAllowUpdateBidAskSpread = true;
        private bool _bAllowUpdatePnL = true;
        private bool panA = false;
        private bool _bUpdatedIndicator = false;
        private bool _bNeedsReset = false;
        private bool _bAlreadyCheckedChartTrader = false;
        private string _sAccountCurrencyCulture = "en-US";
        private TextPosition _tpChartNoteTextPosition = TextPosition.BottomLeft;
        //Others
        private ChartTrader _ChartTrader = null;
        private ChartScale _ChartScale = null;
        private PositionManagerAccount _PositionManager = new PositionManagerAccount();
        //private NSPositionInfo _PositionInfo = null;
        private EasyTraderSettings _EasyTraderSettings = null;
        private PositionPlanner _Plan1Long = null;
        private PositionPlanner _Plan1Short = null;
        #endregion

        #region Controls
        //Chart Basics, Buttons and other
        private Chart chW = null;
        private Grid chG = null;

        //Controls
        private ConcurrentDictionary<string, Button> but = new ConcurrentDictionary<string, Button>();
        private ConcurrentDictionary<string, Separator> sep = new ConcurrentDictionary<string, Separator>();
        private EasyTraderLean.UI.UI.EasyTrader.EasyTrader _EasyTraderControl = null;
        #endregion

        #region On State Change
        protected override void OnStateChange()
        {
            //Adding Updating the states for the state dependent functions
            _PositionManager.SetState(State);
            UpdatePlanState(State);

            switch (State)
            {
                #region Set Defaults
                case State.SetDefaults:

                    #region Default Crap
                    this.Name = string.Format("{0}", productName);

                    IsOverlay = true;
                    Calculate = Calculate.OnPriceChange;
                    MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
                    this.IsSuspendedWhileInactive = false;
                    #endregion

                    #region Settings

                    #region Account Parameters
                    AccountName = "Sim101";
                    AccountCurrency = ARCEasyTraderLeanAccountCurrency.USD;
                    OrderTimeInForce = ARCEasyTraderLeanTimeInForce.GTC;
                    AccountBalance = 0;
                    #endregion

                    #region Trade Plan 1 Parameters
                    PlanLineEntryColorL1 = Brushes.Black;
                    PlanLineEntryColorS1 = Brushes.Black;
                    PlanLineStopColor1 = Brushes.Maroon;
                    PlanLineTargetColor1 = Brushes.Navy;
                    #endregion

                    #region General Visual Parameters
                    LineLength = 200;
                    ChartNoteTextFontSize = 12;
                    ChartNoteColor = Brushes.Black;
                    ChartNoteTextPosition = "Bottom Left";
                    PlanningTextFontSize = 12;
                    ButtonText_WhenHid = "Show";
                    ButtonText_WhenShown = "Hide";
                    AverageLineColor = Brushes.Yellow;
                    FlagsBackgroundColor = Brushes.WhiteSmoke;
                    FlagsTextColor = Brushes.Black;
                    ShowShortOrderNames = true;
                    ShowPanel = true;
                    #endregion

                    #region Display
                    TextFont = new SimpleFont("Century Gothic", 14);
                    TextColor = Brushes.Black;
                    PlanLongEntryStroke = new Stroke(Brushes.Black, DashStyleHelper.Solid, 2);
                    PlanLongStopStroke = new Stroke(Brushes.Maroon, DashStyleHelper.Solid, 2);
                    PlanLongTargetStroke = new Stroke(Brushes.Navy, DashStyleHelper.Solid, 2);
                    PlanShortEntryStroke = new Stroke(Brushes.Black, DashStyleHelper.Solid, 2);
                    PlanShortStopStroke = new Stroke(Brushes.Maroon, DashStyleHelper.Solid, 2);
                    PlanShortTargetStroke = new Stroke(Brushes.Navy, DashStyleHelper.Solid, 2);
                    PlanHoveredStroke = new Stroke(Brushes.SlateGray, DashStyleHelper.Solid, 2);
                    #endregion

                    #endregion

                    break;
                #endregion

                #region Configure
                case State.Configure:

                    #region Licensing Stuff
                    IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
#if DoLicense
					//Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
					if(!LicenseChecked){
						ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
						LicenseChecked = true;
					}
					//RemoveDrawObject("lictext");
#endif
                    string docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                    string dirPath = Path.Combine(docs, "NinjaTrader 8", "cache");
                    if (!System.IO.Directory.Exists(dirPath)) System.IO.Directory.CreateDirectory(dirPath);
                    fileName = Path.Combine(dirPath, "ea_cache.etc");

                    if (etCounters <= 0)
                    {
                        Interlocked.Increment(ref etCounters);
                        if (System.IO.Directory.Exists(dirPath) && File.Exists(fileName))
                        {
                            ErrorPrintedAt = DateTime.Now;
                        }
                    }
                    else
                    {
                        Interlocked.Increment(ref etCounters);
                        stateMessage = 2;
                    }
                    #endregion

                    #region Add Plot
                    //AddPlot(ActiveTrailLineColor, PlotStyle.Hash, "TrailValueActive");
                    //AddPlot(ViewingTrailLineColor, PlotStyle.Hash, "TrailValueViewing");
                    #endregion

                    break;
                #endregion

                #region Other States
                case State.DataLoaded:
                    try
                    {

                        #region Initialize Shit
                        //_PositionInfo = new NSPositionInfo(AccountName, Instrument);
                        //_PositionInfo.PositionUpdated += _PositionInfo_PositionUpdated;
                        _EasyTraderSettings = new EasyTraderSettings();
                        _EasyTraderSettings.SetDefaults();
                        _EasyTraderSettings.PositionDisplaySettings.DecimalPlaces = TickSize.GetDecimalPlaces();
                        _EasyTraderSettings.BidAskSpreadSettings.DecimalPlaces = TickSize.GetDecimalPlaces();
                        #endregion

                        #region Update Things from user inputs
                        if (!string.IsNullOrEmpty(AccountName) && !string.IsNullOrWhiteSpace(AccountName))
                            _EasyTraderSettings.AccountSelectorSettings.SelectedAccount = AccountName;

                        switch (ChartNoteTextPosition)
                        {
                            case "Bottom Left": _tpChartNoteTextPosition = TextPosition.BottomLeft; break;
                            case "Bottom Right": _tpChartNoteTextPosition = TextPosition.BottomRight; break;
                            case "Top Left": _tpChartNoteTextPosition = TextPosition.TopLeft; break;
                            case "Top Right": _tpChartNoteTextPosition = TextPosition.TopRight; break;
                            case "Center": _tpChartNoteTextPosition = TextPosition.Center; break;
                        }

                        #region Account Currency Culture
                        //"en-US" USD
                        //"fr-FR" EURO
                        //"ja-JP" JPY
                        //"en-GB" GBP
                        //"de-CH" CHF - must set the currency Symbol after the culture info
                        //.NumberFormat.CurrencySymbol = "CHF";
                        //"en-AU" AUD
                        //"en-CA" CAD
                        //"en-NZ" NZD
                        switch (AccountCurrency)
                        {
                            case ARCEasyTraderLeanAccountCurrency.USD: _sAccountCurrencyCulture = "en-US"; break;
                            case ARCEasyTraderLeanAccountCurrency.EUR: _sAccountCurrencyCulture = "fr-FR"; break;
                            case ARCEasyTraderLeanAccountCurrency.JPY: _sAccountCurrencyCulture = "ja-JP"; break;
                            case ARCEasyTraderLeanAccountCurrency.GBP: _sAccountCurrencyCulture = "en-GB"; break;
                            case ARCEasyTraderLeanAccountCurrency.CHF: _sAccountCurrencyCulture = "de-CH"; break;
                            case ARCEasyTraderLeanAccountCurrency.AUD: _sAccountCurrencyCulture = "en-AU"; break;
                            case ARCEasyTraderLeanAccountCurrency.CAD: _sAccountCurrencyCulture = "en-CA"; break;
                            case ARCEasyTraderLeanAccountCurrency.NZD: _sAccountCurrencyCulture = "en-NZ"; break;
                        }
                        _EasyTraderSettings.PositionDisplaySettings.AccountCurrencyCulture = _sAccountCurrencyCulture;
                        #endregion

                        #endregion

                        #region Update Account and other shit
                        _PositionManager.UpdateSettings(_EasyTraderSettings);
                        if (!string.IsNullOrEmpty(_EasyTraderSettings.AccountSelectorSettings.SelectedAccount) && Account.All.Count > 0)
                        {
                            bool bInitialized = false;
                            _PositionManager.Initialize(this);
                            List<string> lstAccounts = new List<string>();
                            for (int i = 0; i < Account.All.Count; i++)
                            {
                                if (Account.All[i].ConnectionStatus == ConnectionStatus.Connected)
                                {
                                    lstAccounts.Add(Account.All[i].Name);
                                }
                            }
                            _EasyTraderSettings.AccountSelectorSettings.Accounts = lstAccounts;
                        }
                        else
                            _EasyTraderSettings.AccountSelectorSettings.Accounts = new List<string>();
                        #endregion

                        #region Instrument Decimal Places
                        string sTickSize = Instrument.MasterInstrument.TickSize.ToString();
                        ;
                        if (sTickSize.Contains("E"))
                        {
                            _iDecimalPlaces = Convert.ToInt32(sTickSize[sTickSize.Length - 1].ToString());
                        }
                        else
                        {
                            string[] sAfterDecimals = sTickSize.Split('.');
                            _iDecimalPlaces = sAfterDecimals.Length == 1 ? 0 : sAfterDecimals[1].Length;
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        Log("Failed Data Loaded\r\n" + ex.ToString(), LogLevel.Information);
                    }
                    break;

                case State.Historical:
                    _bIsChart = IsRunningIn() == "Chart";
                    if (!_bAa && _bIsChart)
                    {
                        addToToolbar();
                    }

                    #region Initialize Plans
                    ColorSettings longColors = new ColorSettings()
                    {
                        Font = TextFont,
                        Text = TextColor,
                        Entry = PlanLongEntryStroke,
                        Stop = PlanLongStopStroke,
                        Target = PlanLongTargetStroke,
                        Hovered = PlanHoveredStroke,
                        FlagBackground = FlagsBackgroundColor,
                        FlagLength = LineLength,
                        ShortOrderNames = ShowShortOrderNames
                    };
                    ColorSettings shortColors = new ColorSettings()
                    {
                        Font = TextFont,
                        Text = TextColor,
                        Entry = PlanShortEntryStroke,
                        Stop = PlanShortStopStroke,
                        Target = PlanShortTargetStroke,
                        Hovered = PlanHoveredStroke,
                        FlagBackground = FlagsBackgroundColor,
                        FlagLength = LineLength,
                        ShortOrderNames = ShowShortOrderNames
                    };
                    _Plan1Long = new PositionPlanner(manager.ETradeType.Long, _EasyTraderSettings, longColors);
                    _Plan1Short = new PositionPlanner(manager.ETradeType.Short, _EasyTraderSettings, shortColors);
                    #endregion

                    break;
                case State.Realtime:
                    CheckIfAccountsMatch();
                    break;
                case State.Terminated:
                    if (_bAa && _bIsChart) { Cleaner(); }
                    //if (_PositionInfo != null)
                    //    _PositionInfo.Dispose();
                    if (ChartControl == null)
                        return;
                    InvokeActionCC(() =>
                    {
                        if (_PositionManager != null)
                            _PositionManager.Dispose();
                    });
                    break;
                    #endregion
            }
        }
        #endregion

        #region On Bar Update
        protected override void OnBarUpdate()
        {
            #region Licensing
#if DoLicense

            if (!ValidLicense)
            {
                this.IsVisible = false;
                Draw.TextFixed(this, "lictext", ModuleName + " license not valid\n" + MachineId + "  " + UserId + "\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@nstradingacademy.com for assistance", TextPosition.Center, Brushes.White, new SimpleFont("Arial", 12), Brushes.Black, Brushes.Black, 90);
                IsVisible = false;
                RemovePanel();

                ////To Add later
                //ShowHideState = 0;
                //ButtonShowHide.Header = "EasyTrader License Error";
                return;
            }
#if FREE_TRIAL_VERSION
			if(FileIsOld){
				var fts = new TimeSpan(DateTime.Now.Ticks- this.FreeTrialDT.Ticks);
				if(fts.TotalSeconds > 300){
					FileIsOld = false;
					RemoveDrawObject("freetrialnotice");
				}
			}
#endif
#endif
            #endregion

            if (State == State.Historical)
            {
                return;
            }

            if (_bAa && !_bAlreadyCheckedChartTrader)
                CheckIfAccountsMatch();

            if (_bNeedsReset && _bAa)
                ReloadChart();

            UpdateIndicator();

            //Check Potential Position
            //try
            {
                CalculatePositionSize(_EasyTraderSettings.TargetStopSettings.StopValue, Closes[0][0]);
            }
            //catch (Exception ex)
            //{
            //    Log(DateTime.Now + " " + "CalculatePositionSize\r\n" + ex.ToString(), LogLevel.Information);
            //}
        }
        #endregion

        #region Objects

        #region State Objects

        #region Update Plan States
        private void UpdatePlanState(State state)
        {
            if(_Plan1Long != null)
                _Plan1Long.SetState(State);
            if (_Plan1Short != null)
                _Plan1Short.SetState(State);
        }
        #endregion

        #region Historical

        #region Add All things to the toolbar
        private void addToToolbar()
        {
            if (this.ChartControl != null)
            {
                ChartControl.Dispatcher.InvokeAsync((Action)(() => {
                    try
                    {
                        #region Show Chart Trader
                        NinjaTrader.Gui.Chart.ChartHelper.SetChartTraderVisibility(this.ChartControl, ChartTraderVisibility.Visible);
                        Window window = Window.GetWindow(ChartControl.Parent);
                        _ChartTrader = Window.GetWindow(ChartControl.Parent).FindFirst("ChartWindowChartTraderControl") as ChartTrader;
                        if (_ChartTrader != null)
                        {
                            NinjaTrader.Gui.Tools.AccountSelector aSelector = Window.GetWindow(ChartControl.Parent).FindFirst("ChartTraderControlAccountSelector") as NinjaTrader.Gui.Tools.AccountSelector;
                            if (aSelector != null)
                            {
                                aSelector.SelectedItem = Account.DbGet(_EasyTraderSettings.AccountSelectorSettings.SelectedAccount);
                            }
                            NinjaTrader.Gui.Chart.ChartHelper.SetChartTraderVisibility(this.ChartControl, ChartTraderVisibility.VisibleCollapsed);
                        }
                        #endregion

                        #region Initialize Tool Strip Stuff
                        chW = Window.GetWindow(this.ChartControl.Parent) as Chart;
                        if (chW == null)
                        {
                            //Print("no chart window");
                            return;
                        }
                        chG = chW.MainTabControl.Parent as System.Windows.Controls.Grid; //
                        #endregion

                        #region Adding Shit to chart
                        _EasyTraderSettings.PositionDisplaySettings.DecimalPlaces = _iDecimalPlaces;
                        _EasyTraderSettings.BidAskSpreadSettings.DecimalPlaces = _iDecimalPlaces;

                        _EasyTraderControl = new EasyTraderLean.UI.UI.EasyTrader.EasyTrader(_EasyTraderSettings.Clone() as EasyTraderSettings, this);
                        _EasyTraderControl.UiBackend.OnButtonWasClicked += UiButtonClicked;
                        _EasyTraderControl.UiBackend.OnSettingsWereUpdated += UiSettingsUpdated;
                        //UpdateAllSettings();

                        addButton("bShowHide", ShowPanel ? ButtonText_WhenShown : ButtonText_WhenHid, 11, ColorUtils.BrushFromArgb(255, 6, 55, 74), Brushes.Gold, "Arial", OnOffB);
                        #endregion

                        #region Chart Events
                        ChartControl.PreviewMouseMove += new MouseEventHandler(Chart_MouseMove);
                        ChartControl.MouseDown += new MouseButtonEventHandler(Chart_MouseDown);
                        //_EasyTraderControl.KeyDown += ChartControl_PreviewKeyDown;
                        //_EasyTraderControl.KeyUp += ChartControl_PreviewKeyUp;
                        #endregion

                        #region Tab Management
                        if (tabSelected())
                            InsertControl();
                        else
                            RemoveControl();

                        if (!ShowPanel)
                            RemovePanel();
                        chW.MainTabControl.SelectionChanged += tabChanged;
                        _bAa = true;
                        #endregion
                    }
                    catch (Exception ex) { Log(ex.ToString(), LogLevel.Information); }
                }));
            }
        }
        #endregion

        #region Add Separator
        private void addSep(string name)
        {
            try
            {
                Separator sep = new Separator();
                sep.Name = name;
                sep.Visibility = Visibility.Visible;
                if (!chW.MainMenu.Contains(sep)) chW.MainMenu.Add(sep);
                this.sep.TryAdd(name, sep);
            }
            catch (Exception ex) { Log(ex.ToString(), LogLevel.Information); }
        }
        #endregion

        #region Add Button
        private void addButton(string name, string text, double fontSize, Brush background, Brush textColor, string fontFamily, RoutedEventHandler reh)
        {
            try
            {
                Style s = new Style();

                s.TargetType = typeof(Button);
                s.Setters.Add(new Setter(Button.FontSizeProperty, fontSize));
                s.Setters.Add(new Setter(Button.BackgroundProperty, background));
                s.Setters.Add(new Setter(Button.ForegroundProperty, textColor));
                s.Setters.Add(new Setter(Button.FontFamilyProperty, new FontFamily(fontFamily)));
                s.Setters.Add(new Setter(Button.FontWeightProperty, FontWeights.Bold));
                s.Setters.Add(new Setter(Button.BorderBrushProperty, textColor));
                s.Setters.Add(new Setter(Button.BorderThicknessProperty, new Thickness(2)));

                Button but = new Button();
                but.Style = s;
                but.Name = name;
                but.Content = text;
                but.IsEnabled = true;
                but.HorizontalAlignment = HorizontalAlignment.Left;

                but.Click += reh;

                chW.MainMenu.Add(but);

                but.Visibility = Visibility.Collapsed;
                this.but.TryAdd(name, but);
            }
            catch (Exception ex) { Log(ex.ToString(), LogLevel.Information); }
        }
        #endregion

        #region Tab Selected
        private bool tabSelected()
        {
            bool tabSelected = false;
            foreach (System.Windows.Controls.TabItem tab in chW.MainTabControl.Items)
            {
                if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chW.MainTabControl.SelectedItem)
                    tabSelected = true;
            }
            return tabSelected;
        }
        #endregion

        #region Insert Control
        protected void InsertControl()
        {
            foreach (KeyValuePair<string, Button> b in but)
            {
                b.Value.Visibility = Visibility.Visible;
            }

            foreach (KeyValuePair<string, Separator> c in sep)
            {
                c.Value.Visibility = Visibility.Visible;
            }
            if (ShowPanel)
                InsertPanel();
        }
        #endregion

        #region Insert Panel
        protected void InsertPanel()
        {
            if (panA) return;

            int iChartTraderStartColumn = System.Windows.Controls.Grid.GetColumn(_ChartTrader);
            // a new column is added to the right of ChartTrader
            chG.ColumnDefinitions.Insert((iChartTraderStartColumn + 2), new System.Windows.Controls.ColumnDefinition() { Width = new GridLength(284) });
            // all items to the right of the ChartTrader are shifted to the right
            for (int i = 0; i < chG.Children.Count; i++)
                if (System.Windows.Controls.Grid.GetColumn(chG.Children[i]) > iChartTraderStartColumn)
                    System.Windows.Controls.Grid.SetColumn(chG.Children[i], System.Windows.Controls.Grid.GetColumn(chG.Children[i]) + 1);

            Grid.SetColumn(_EasyTraderControl, System.Windows.Controls.Grid.GetColumn(_ChartTrader) + 2);
            Grid.SetRow(_EasyTraderControl, System.Windows.Controls.Grid.GetRow(chW.MainTabControl));
            chG.Children.Add(_EasyTraderControl);

            panA = true;
        }
        #endregion

        #region Remove Control
        protected void RemoveControl()
        {
            foreach (KeyValuePair<string, Button> b in but)
            {
                b.Value.Visibility = Visibility.Collapsed;
            }

            foreach (KeyValuePair<string, Separator> c in sep)
            {
                c.Value.Visibility = Visibility.Collapsed;
            }

            RemovePanel();
        }
        #endregion

        #region Remove Panel
        protected void RemovePanel()
        {
            if (!panA) return;

            if (_EasyTraderControl != null)
            {
                if (chG.Children.Contains(_EasyTraderControl))
                {
                    // remove the column of our added grid
                    chG.ColumnDefinitions.RemoveAt(System.Windows.Controls.Grid.GetColumn(_EasyTraderControl));
                    // then remove the grid
                    chG.Children.Remove(_EasyTraderControl);

                    // if the childs column is 1 (so we can move it to 0) and the column is to the right of the column we are removing, shift it left
                    for (int i = 0; i < chG.Children.Count; i++)
                        if (System.Windows.Controls.Grid.GetColumn(chG.Children[i]) > 0 && System.Windows.Controls.Grid.GetColumn(chG.Children[i]) > System.Windows.Controls.Grid.GetColumn(_EasyTraderControl))
                            System.Windows.Controls.Grid.SetColumn(chG.Children[i], System.Windows.Controls.Grid.GetColumn(chG.Children[i]) - 1);
                }
            }

            panA = false;
        }
        #endregion

        #region Is Running In
        private string IsRunningIn()
        {
            // Find the top most NinjaScriptBase
            NinjaScriptBase topMost = this;
            for (; topMost.Parent != null; topMost = topMost.Parent) { }

            // Check if it is a Market Analyzer Indicator Column
            MarketAnalyzerColumns.IndicatorMarketAnalyzerColumn ma = topMost as MarketAnalyzerColumns.IndicatorMarketAnalyzerColumn;

            if (ma != null)
                return "Market Analyzer";

            // Check if its a SuperDom Indicator
            IndicatorSuperDomBase sd = topMost as IndicatorSuperDomBase;

            if (sd != null)
                return "Super DOM";

            // Check if it is a chart indicator
            IndicatorBase ib = topMost as IndicatorBase;

            if (ib != null)
                return "Chart";

            return "Unknown";
        }
        #endregion

        #endregion

        #region Termination

        #region Cleaner
        private void Cleaner()
        {
            if (this.ChartControl != null)
            {
                if (chW == null) { chW = Window.GetWindow(ChartControl.Parent) as Chart; }
                if (chW != null)
                {
                    ChartControl.Dispatcher.InvokeAsync(() => 
                    {
                        chW.MainTabControl.SelectionChanged -= tabChanged;

                        #region Chart Events
                        if (ChartControl != null)
                        {
                            ChartControl.PreviewMouseMove -= Chart_MouseMove;
                            ChartControl.MouseDown -= Chart_MouseDown;
                        }
                        //_EasyTraderControl.KeyDown -= ChartControl_PreviewKeyDown;
                        //_EasyTraderControl.KeyUp -= ChartControl_PreviewKeyUp;
                        #endregion

                        RemoveControl();

                        _EasyTraderControl.Dispose();
                        _EasyTraderControl = null;

                        #region Stops and Targets
                        foreach (KeyValuePair<string, Separator> b in sep)
                            rco(b.Value);
                        sep.Clear();
                        foreach (KeyValuePair<string, Button> b in but)
                            rco(b.Value, OnOffB);
                        but.Clear();
                        #endregion

                        _EasyTraderControl = null;
                    });
                }
            }
        }
        #endregion

        #region Remove Chart Object
        private void rco(Button obj, RoutedEventHandler reh)
        {
            if (obj != null)
            {
                obj.Click -= reh;
                if (chW.MainMenu.Contains(obj)) chW.MainMenu.Remove(obj);
                obj = null;
            }
        }
        private void rco(Separator obj)
        {
            if (obj != null)
            {
                if (chW.MainMenu.Contains(obj)) chW.MainMenu.Remove(obj);
                obj = null;
            }
        }
        #endregion

        #endregion

        #region Check If Accounts Match
        private void CheckIfAccountsMatch()
        {
            InvokeActionCC(() =>
            {
                if (_ChartTrader == null)
                {
                    _bNeedsReset = true;
                    return;
                }
                NinjaTrader.Gui.Tools.AccountSelector aSelector = Window.GetWindow(ChartControl.Parent).FindFirst("ChartTraderControlAccountSelector") as NinjaTrader.Gui.Tools.AccountSelector;
                if (aSelector == null || aSelector.SelectedAccount.Name != _EasyTraderSettings.AccountSelectorSettings.SelectedAccount)
                {
                    _bNeedsReset = true;
                    return;
                }
                _bAlreadyCheckedChartTrader = true;
            });
        }
        #endregion

        #endregion

        #region Backend to UI

        #region Update Indicator
        private void UpdateIndicator()
        {
            if (State != State.Realtime || _bUpdatedIndicator || _EasyTraderControl == null)
                return;
            _bUpdatedIndicator = true;
            InvokeAction(() =>
            {
                _EasyTraderControl.UiBackend.UpdateIndicator(this);
            }, _EasyTraderControl.Dispatcher);
        }
        #endregion

        #region Update Entry Quantity
        private void UpdateEntryQuantity()
        {
            if (State != State.Realtime)
                return;
            EntryQuantitySettings settings = _EasyTraderSettings.EntryQuantitySettings.Clone() as EntryQuantitySettings;
            if (_EasyTraderControl != null)
            {
                InvokeAction(() =>
                {
                    _EasyTraderControl.UiBackend.BackendToUI(DataUpdated.Quantity, settings, true);
                }, _EasyTraderControl.Dispatcher);
            }
        }
        #endregion

        #region Update Stop Target
        private void UpdateStopTarget(TargetStopSettings settings)
        {
            if (State != State.Realtime)
                return;
            if (settings == null)
                settings = _EasyTraderSettings.TargetStopSettings.Clone() as TargetStopSettings;
            else
                _EasyTraderSettings.TargetStopSettings.UpdateSettings(settings);
            if (_EasyTraderControl != null)
            {
                InvokeAction(() =>
                {
                    _EasyTraderControl.UiBackend.BackendToUI(DataUpdated.TargetStop, settings, true);
                }, _EasyTraderControl.Dispatcher);
            }
        }
        #endregion

        #region Update Risk Reward
        private void UpdateRiskReward(TradePlannerSettings settings)
        {
            if (State != State.Realtime)
                return;
            if (settings == null)
                settings = _EasyTraderSettings.TargetStopSettings.Clone() as TradePlannerSettings;
            else
                _EasyTraderSettings.TradePlannerSettingsPlan.UpdateRiskReward(settings);
            if (_EasyTraderControl != null)
            {
                InvokeAction(() =>
                {
                    _EasyTraderControl.UiBackend.BackendToUI(DataUpdated.RiskReward, settings, true);
                }, _EasyTraderControl.Dispatcher);
            }
        }
        #endregion

        #region Update Both StopTarget and RiskReward
        private void UpdateStopTargetAndRiskReward(TargetStopSettings settingsTS, TradePlannerSettings settingsRR)
        {
            if (State != State.Realtime)
                return;
            if (settingsTS == null)
                settingsTS = _EasyTraderSettings.TargetStopSettings.Clone() as TargetStopSettings;
            else
                _EasyTraderSettings.TargetStopSettings.UpdateSettings(settingsTS);
            if (settingsRR == null)
                settingsRR = _EasyTraderSettings.TargetStopSettings.Clone() as TradePlannerSettings;
            else
                _EasyTraderSettings.TradePlannerSettingsPlan.UpdateRiskReward(settingsRR);
            if (_EasyTraderControl != null)
            {
                InvokeAction(() =>
                {
                    _EasyTraderControl.UiBackend.BackendToUI(DataUpdated.TargetStop, settingsTS, true);
                    _EasyTraderControl.UiBackend.BackendToUI(DataUpdated.RiskReward, settingsRR, true);
                }, _EasyTraderControl.Dispatcher);
            }
        }
        #endregion

        #region Update All Settings
        private void UpdateAllSettings()
        {
            EasyTraderSettings settings = _EasyTraderSettings.Clone() as EasyTraderSettings;
            if (_EasyTraderControl != null)
            {
                InvokeAction(() =>
                {
                    _EasyTraderControl.UiBackend.BackendToUI(DataUpdated.All, settings, true);
                }, _EasyTraderControl.Dispatcher);
            }
        }
        #endregion

        #region Update Account
        private void UpdateAccount()
        {
            AccountSelectorSettings settings = _EasyTraderSettings.AccountSelectorSettings.Clone() as AccountSelectorSettings;
            if (_EasyTraderControl != null)
            {
                InvokeAction(() =>
                {
                    _EasyTraderControl.UiBackend.BackendToUI(DataUpdated.AccountList, settings, false);
                }, _EasyTraderControl.Dispatcher);
            }
        }
        #endregion

        #region Update Plans
        private void ResetPlans()
        {
            if (State != State.Realtime)
                return;
            _EasyTraderSettings.TradePlannerSettingsPlan.Plan1.Long = false;
            _EasyTraderSettings.TradePlannerSettingsPlan.Plan1.Short = false;
            TradePlannerSettings settings = _EasyTraderSettings.TradePlannerSettingsPlan.Clone() as TradePlannerSettings;
            if (_EasyTraderControl != null)
            {
                InvokeAction(() =>
                {
                    _EasyTraderControl.UiBackend.BackendToUI(DataUpdated.UpdatePlans, settings, false);
                }, _EasyTraderControl.Dispatcher);
            }
        }
        #endregion

        #region Invoke Action
        private void InvokeActionCC(Action p)
        {
            if (ChartControl.Dispatcher.CheckAccess())
            {
                p();
            }
            else
            {
                ChartControl.Dispatcher.InvokeAsync(p);
            }
        }
        private void InvokeAction(Action p, System.Windows.Threading.Dispatcher dispatcher)
        {
            if (dispatcher.CheckAccess())
            {
                p();
            }
            else
            {
                dispatcher.InvokeAsync(p);
            }
        }
        #endregion

        #region Invoke Action General
        private void InvokeActionGeneral(Action p)
        {
            if (Dispatcher.CheckAccess())
            {
                p();
            }
            else
            {
                Dispatcher.InvokeAsync(p);
            }
        }
        #endregion

        #endregion

        #region Event Handlers

        #region Tab Changed
        private void tabChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0)
                return;
            TabItem tI = e.AddedItems[0] as TabItem;
            if (tI == null)
                return;
            ChartTab chT = tI.Content as ChartTab;
            if (chT == null)
                return;
            if (tabSelected()) InsertControl(); else RemoveControl();
        }
        #endregion

        #region On Off Button Click
        private void OnOffB(object s, EventArgs e)
        {
            try
            {
                Button b = s as Button;
                if (b != null)
                {
                    switch (b.Name)
                    {
                        case "bShowHide":
                            ShowPanel = !ShowPanel;
                            b.Content = ShowPanel ? ButtonText_WhenShown : ButtonText_WhenHid;
                            if (ShowPanel)
                                InsertPanel();
                            else
                                RemovePanel();
                            ChartControl.InvalidateVisual();
                            break;
                    }
                }
            }
            catch (Exception ex) { Log("OnOffB  " + ex.ToString(), LogLevel.Information); }
        }
        #endregion

        #region UI Button Clicked
        private void UiButtonClicked(object sender, ButtonWasClickedEventArgs e)
        {
            if (sender == null || e == null)
                return;
            switch (e.ButtonClicked)
            {
                case ButtonClicked.Close:
                    _PositionManager.Exit(manager.EExitType.All);
                    //UpdatePositionDisplay();
                    break;
                case ButtonClicked.CloseAllInstrument:
                    _PositionManager.ExitInstrument();
                    //UpdatePositionDisplay();
                    break;
                case ButtonClicked.FlattenAllEasyAlgo:
                    _PositionManager.ExitEverything();
                    //UpdatePositionDisplay();
                    break;
                case ButtonClicked.Buy:
                    if(_iWaitingOnClick < 1)
                        _iWaitingOnClick = 1;
                    else
                        _iWaitingOnClick = 0;
                    break;
                case ButtonClicked.BuyMRKT:
                    if (!_bIsBlocked && !_bDoneForTheDay)
                    {
                        _PositionManager.Enter(manager.ETradeType.Long, _EasyTraderSettings.EntryQuantitySettings.Quantity);
                        //UpdatePositionDisplay();
                    }
                    break;
                case ButtonClicked.BuyLMT:
                    if (!_bIsBlocked && !_bDoneForTheDay)
                        _PositionManager.Enter(manager.ETradeType.Long, _EasyTraderSettings.EntryQuantitySettings.Quantity, GetCurrentBid());
                    break;
                case ButtonClicked.BuyStop:
                    if (!_bIsBlocked && !_bDoneForTheDay)
                        _PositionManager.Enter(manager.ETradeType.Long, _EasyTraderSettings.EntryQuantitySettings.Quantity, GetCurrentAsk());
                    break;
                case ButtonClicked.Sell:
                    if (_iWaitingOnClick > -1)
                        _iWaitingOnClick = -1;
                    else
                        _iWaitingOnClick = 0;
                    break;
                case ButtonClicked.SellMRKT:
                    if (!_bIsBlocked && !_bDoneForTheDay)
                    {
                        _PositionManager.Enter(manager.ETradeType.Short, _EasyTraderSettings.EntryQuantitySettings.Quantity);
                        //UpdatePositionDisplay();
                    }
                    break;
                case ButtonClicked.SellLMT:
                    if (!_bIsBlocked && !_bDoneForTheDay)
                        _PositionManager.Enter(manager.ETradeType.Short, _EasyTraderSettings.EntryQuantitySettings.Quantity, GetCurrentAsk());
                    break;
                case ButtonClicked.SellStop:
                    if (!_bIsBlocked && !_bDoneForTheDay)
                        _PositionManager.Enter(manager.ETradeType.Short, _EasyTraderSettings.EntryQuantitySettings.Quantity, GetCurrentBid());
                    break;
                case ButtonClicked.RiskRewardExecuteMPlan:
                    if (_Plan1Long.IsEnabled)
                    {
                        _PositionManager.Enter(_Plan1Long, true, true);
                        _Plan1Long.IsEnabled = false;
                    }
                    else if (_Plan1Short.IsEnabled)
                    {
                        _PositionManager.Enter(_Plan1Short, false, true);
                        _Plan1Short.IsEnabled = false;
                    }
                    ResetPlans();
                    ChartControl.InvalidateVisual();
                    break;
                case ButtonClicked.RiskRewardExecuteLPlan:
                    if (_Plan1Long.IsEnabled)
                    {
                        _PositionManager.Enter(_Plan1Long, true);
                        _Plan1Long.IsEnabled = false;
                    }
                    if (_Plan1Short.IsEnabled)
                    {
                        _PositionManager.Enter(_Plan1Short, false);
                        _Plan1Short.IsEnabled = false;
                    }
                    ResetPlans();
                    ChartControl.InvalidateVisual();
                    break;
            }
        }
        #endregion

        #region UI Settings Updated
        private void UiSettingsUpdated(object sender, SettingsWereUpdatedEventArgs e)
        {
            if (sender == null || e == null)
                return;
            bool bSettingsWereUpdated = true;
            switch (e.SettingsUpdated)
            {
                case Settings.All: _EasyTraderSettings.UpdateSettings(e.Settings); break;
                case Settings.EntryQuantity: _EasyTraderSettings.EntryQuantitySettings.UpdateSettings(e.Settings); break;
                case Settings.Selector: _EasyTraderSettings.SelectorSettings.UpdateSettings(e.Settings); break;
                case Settings.Settings: _EasyTraderSettings.SettingsSettings.UpdateSettings(e.Settings); break;
                case Settings.Sizing: 
                    _EasyTraderSettings.SizingSettings.UpdateSettings(e.Settings);
                    CalculatePositionSize(_EasyTraderSettings.TargetStopSettings.StopValue, Closes[0][0]);
                    break;
                case Settings.TargetStop: _EasyTraderSettings.TargetStopSettings.UpdateSettings(e.Settings); break;
                case Settings.AccountSelector:
                    if(_EasyTraderSettings.AccountSelectorSettings.SelectedAccount != (e.Settings as AccountSelectorSettings).SelectedAccount)
                    {
                        AccountName = (e.Settings as AccountSelectorSettings).SelectedAccount;
                        ReloadChart();
                    }
                    break;
                //Plan
                case Settings.TradePlannerPlan: _EasyTraderSettings.TradePlannerSettingsPlan.UpdateSettings(e.Settings); UpdateActivePlans(); break;
                default: bSettingsWereUpdated = false; break;
            }
            if (bSettingsWereUpdated)
            {
                CalculateRiskReward();
                PopagateSettingsUpdatePlan();
                _PositionManager.UpdateSettings(_EasyTraderSettings);
            }
        }
        #endregion

        #region Chart Click and Move Events
        private void Chart_MouseMove(object sender, MouseEventArgs e)
        {
            //plans
            float eX = ChartingExtensions.ConvertToHorizontalPixels(e.GetPosition(ChartPanel as IInputElement).X, ChartControl.PresentationSource);
            float eY = ChartingExtensions.ConvertToVerticalPixels(e.GetPosition(ChartPanel as IInputElement).Y, ChartControl.PresentationSource);

            //Plans
            //Plan 1 Long
            if (_Plan1Long.IsEnabled)
            {
                if (e.LeftButton == MouseButtonState.Released)
                    _Plan1Long.CheckHover(eX, eY);
                _Plan1Long.MouseDown(e.LeftButton == MouseButtonState.Pressed);
                _Plan1Long.MouseMove(eX, eY, this);
                if (_Plan1Long.IsAnyGrabbed)
                {
                    OnlyUpdate(1);
                    e.Handled = true;
                    if (!_Plan1Long.Position.Entry.IsGrabbed)
                    {
                        CalculatePositionSize(_EasyTraderSettings.TargetStopSettings.StopValue, Closes[0][0], false);
                        UpdateStopTargetAndRiskReward(_Plan1Long.Position.GetTargetStopSettings(), _Plan1Long.Position.GetRiskReward());
                    }
                    return;
                }
            }
            //Plan 1 Short
            if (_Plan1Short.IsEnabled)
            {
                if (e.LeftButton == MouseButtonState.Released)
                    _Plan1Short.CheckHover(eX, eY);
                _Plan1Short.MouseDown(e.LeftButton == MouseButtonState.Pressed);
                _Plan1Short.MouseMove(eX, eY, this);
                if (_Plan1Short.IsAnyGrabbed)
                {
                    OnlyUpdate(-1);
                    e.Handled = true;
                    if (!_Plan1Short.Position.Entry.IsGrabbed)
                    {
                        CalculatePositionSize(_EasyTraderSettings.TargetStopSettings.StopValue, Closes[0][0], false);
                        UpdateStopTargetAndRiskReward(_Plan1Short.Position.GetTargetStopSettings(), _Plan1Short.Position.GetRiskReward());
                    }
                    return;
                }
            }
        }
        private void Chart_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                //click entry
                float eX = ChartingExtensions.ConvertToHorizontalPixels(e.GetPosition(ChartPanel as IInputElement).X, ChartControl.PresentationSource);
                float eY = ChartingExtensions.ConvertToVerticalPixels(e.GetPosition(ChartPanel as IInputElement).Y, ChartControl.PresentationSource);
                if (_iWaitingOnClick == 1)
                {
                    if (!_bIsBlocked && !_bDoneForTheDay)
                    {
                        double dPrice = _ChartScale.GetValueByY(eY);
                        _PositionManager.Enter(manager.ETradeType.Long, _EasyTraderSettings.EntryQuantitySettings.Quantity, dPrice);
                    }
                    _iWaitingOnClick = 0;
                }
                else if (_iWaitingOnClick == -1)
                {
                    if (!_bIsBlocked && !_bDoneForTheDay)
                    {
                        double dPrice = _ChartScale.GetValueByY(eY);
                        _PositionManager.Enter(manager.ETradeType.Short, _EasyTraderSettings.EntryQuantitySettings.Quantity, dPrice);
                    }
                    _iWaitingOnClick = 0;
                }
            }
        }
        #endregion

        #region Reload Chart
        private void ReloadChart()
        {
            InvokeActionCC(() =>
            {
                Window window = Window.GetWindow(ChartControl.Parent);
                window.Focus();
                System.Windows.Forms.SendKeys.SendWait("{F5}");
            });
        }
        #endregion

        #endregion

        #region Default NT Functions

        #region On Render
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            if (Bars == null || chartControl == null || chartScale == null
#if DoLicense
                || !ValidLicense
#endif
                ) return;

            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1)
                return;

            _ChartScale = chartScale;

            if (!IsOverlay)
                IsOverlay = true;

            base.OnRender(chartControl, chartScale);

            //Plans
            _Plan1Long.Draw(RenderTarget, chartControl, chartScale, Instrument);
            _Plan1Short.Draw(RenderTarget, chartControl, chartScale, Instrument);
        }
        #endregion

        #region Clone
        //public override object Clone()
        //{
        //    ARCEasyTraderLean trader = base.Clone() as ARCEasyTraderLean;
        //    if(trader != null)
        //        lock(_sUniqueID)
        //            trader.SetIDs(_sUniqueID);
        //    return trader;
        //}
        #endregion

        #endregion

        #region Functions

        #region Plan Functions

        #region Update Active Plans
        private void UpdateActivePlans()
        {
            ActivatePlan(_Plan1Long, _EasyTraderSettings.TargetStopSettings.IsPlan && _EasyTraderSettings.TradePlannerSettingsPlan.Plan1.Long);
            ActivatePlan(_Plan1Short, _EasyTraderSettings.TargetStopSettings.IsPlan && _EasyTraderSettings.TradePlannerSettingsPlan.Plan1.Short);
        }
        #endregion

        #region Activate Plan
        private void ActivatePlan(PositionPlanner plan, bool active)
        {
            if (plan.IsEnabled != active)
            {
                plan.IsEnabled = active;
                plan.UpdateEntryPrice(_EasyTraderSettings, this);
                if(plan.IsEnabled)
                    UpdateRiskReward(plan.Position.GetRiskReward());
            }
        }
        #endregion

        #region Propagate Settings Update
        private void PopagateSettingsUpdatePlan()
        {
            bool bAnyEnabled = false;
            if (_Plan1Long.IsEnabled)
            {
                _Plan1Long.UpdateSettings(_EasyTraderSettings, this);
                UpdateRiskReward(_Plan1Long.Position.GetRiskReward());
                bAnyEnabled = true;
            }
            if (_Plan1Short.IsEnabled)
            {
                _Plan1Short.UpdateSettings(_EasyTraderSettings, this);
                UpdateRiskReward(_Plan1Short.Position.GetRiskReward());
                bAnyEnabled = true;
            }
            if (!bAnyEnabled)
            {
                UpdateRiskReward(_EasyTraderSettings.TradePlannerSettingsPlan);
            }
            InvokeActionCC(() => { ChartControl.InvalidateVisual(); });
        }
        #endregion

        #region Only Update Plan
        private void OnlyUpdate(int plan)
        {
            if (plan != 1) _Plan1Long.StopUpdating();
            if (plan != -1) _Plan1Short.StopUpdating();
        }
        #endregion

        #region Calculate Risk Reward
        private void CalculateRiskReward()
        {
            double dTickValue = TickSize * Instrument.MasterInstrument.PointValue;
            _EasyTraderSettings.TradePlannerSettingsPlan.RiskTicks = _EasyTraderSettings.TargetStopSettings.StopValue * _EasyTraderSettings.EntryQuantitySettings.Quantity;
            _EasyTraderSettings.TradePlannerSettingsPlan.Risk = _EasyTraderSettings.TradePlannerSettingsPlan.RiskTicks * dTickValue;

            double dTarget1Ticks = 0;
            double dTarget2Ticks = 0;
            double dTarget3Ticks = 0;

            if (_EasyTraderSettings.TargetStopSettings.Target1.UseTarget)
            {
                dTarget1Ticks = (_EasyTraderSettings.TargetStopSettings.UseRiskReward
                    ? Math.Round(_EasyTraderSettings.TargetStopSettings.StopValue * _EasyTraderSettings.TargetStopSettings.Target1.RiskRewardMultiplier, 0)
                    : _EasyTraderSettings.TargetStopSettings.Target1.Target) * _EasyTraderSettings.TargetStopSettings.Target1.Quantity;
                if (_EasyTraderSettings.TargetStopSettings.Target2.UseTarget)
                {
                    dTarget2Ticks = (_EasyTraderSettings.TargetStopSettings.UseRiskReward
                        ? Math.Round(_EasyTraderSettings.TargetStopSettings.StopValue * _EasyTraderSettings.TargetStopSettings.Target2.RiskRewardMultiplier, 0)
                        : _EasyTraderSettings.TargetStopSettings.Target2.Target) * _EasyTraderSettings.TargetStopSettings.Target2.Quantity;
                    if (_EasyTraderSettings.TargetStopSettings.Target3.UseTarget)
                    {
                        dTarget3Ticks = (_EasyTraderSettings.TargetStopSettings.UseRiskReward
                            ? Math.Round(_EasyTraderSettings.TargetStopSettings.StopValue * _EasyTraderSettings.TargetStopSettings.Target3.RiskRewardMultiplier, 0)
                            : _EasyTraderSettings.TargetStopSettings.Target3.Target) * _EasyTraderSettings.TargetStopSettings.Target3.Quantity;
                    }
                }
            }
            _EasyTraderSettings.TradePlannerSettingsPlan.RewardTicks = dTarget1Ticks + dTarget2Ticks + dTarget3Ticks;
            _EasyTraderSettings.TradePlannerSettingsPlan.Reward = _EasyTraderSettings.TradePlannerSettingsPlan.RewardTicks * dTickValue;
            _EasyTraderSettings.TradePlannerSettingsPlan.Ratio = _EasyTraderSettings.TradePlannerSettingsPlan.Reward == 0 || _EasyTraderSettings.TradePlannerSettingsPlan.Risk == 0
                ? 0 : _EasyTraderSettings.TradePlannerSettingsPlan.Reward / _EasyTraderSettings.TradePlannerSettingsPlan.Risk;
        }
        #endregion

        #endregion

        #region Calculate Position Size
        private void CalculatePositionSize(double stopTicks, double entryPrice, bool updatePlans = true)
        {
            int iForexDivizor = 10000;
            double dTickValue = Instrument.MasterInstrument.PointValue / (1 / Instrument.MasterInstrument.TickSize);
            int iResult = _EasyTraderSettings.EntryQuantitySettings.Quantity;
            switch (_EasyTraderSettings.SizingSettings.SizingTechnique)
            {
                //case ESizingTechnique.Static:
                //    return _Settings.EntryQuantitySettings.Quantity;
                case ESizingTechnique.DollarValue:
                    double dMaxCapital = _EasyTraderSettings.SizingSettings.SizingDollarRisk;
                    if (Instrument.MasterInstrument.InstrumentType == InstrumentType.Forex)
                    {
                        double ps_position_size = Convert.ToInt32(Math.Floor(dMaxCapital / (dTickValue * stopTicks)));
                        iResult = RoundDown(ps_position_size, iForexDivizor);
                    }
                    // NON Currency Instrument
                    else
                        iResult = Convert.ToInt32(Math.Floor(dMaxCapital / (dTickValue * stopTicks)));
                    break;
                case ESizingTechnique.FixedFractional:
                    double dAcctValue = AccountBalance;// AccountBalance != 0 ? AccountBalance : _PositionInfo.AccountBalance;
                    double dMaxCapitalFF = dAcctValue * (_EasyTraderSettings.SizingSettings.SizingRisk / 100);
                    if (Instrument.MasterInstrument.InstrumentType == InstrumentType.Forex && Instrument.MasterInstrument.Name.Length == 6)
                    {
                        string sCurrency = AccountCurrency.ToString();
                        string sBasePair = Instrument.MasterInstrument.Name.Substring(0, 3);
                        string sQuotePair = Instrument.MasterInstrument.Name.Substring(3, 3);
                        double dCurrencyPairUnits = sBasePair == "JPY" || sQuotePair == "JPY" ? 100 : 10000;
                        double dValueInBase = 0;

                        if (sQuotePair == sCurrency)
                            dValueInBase = dMaxCapitalFF;
                        else if (sBasePair == sCurrency)
                            dValueInBase = dMaxCapitalFF * (1 / entryPrice);
                        else if (sCurrency != sQuotePair && sCurrency != sBasePair)
                            dValueInBase = dMaxCapitalFF * (1 / entryPrice);

                        double ps_position_size = Convert.ToInt32(Math.Floor(dValueInBase / (dCurrencyPairUnits * stopTicks)));
                        iResult = RoundDown(ps_position_size, iForexDivizor);
                    }
                    // NON Currency Instrument
                    else
                        iResult = Convert.ToInt32(Math.Floor(dMaxCapitalFF / (dTickValue * stopTicks)));
                    break;
            }
            if (iResult != _EasyTraderSettings.EntryQuantitySettings.Quantity)
            {
                _EasyTraderSettings.EntryQuantitySettings.Quantity = iResult;
                PopagateSettingsUpdatePlan();
                if (updatePlans)
                {
                    CalculateTargetsNStops(_EasyTraderSettings.EntryQuantitySettings.Quantity);
                    UpdateStopTargetAndRiskReward(null, null);
                }
                //if(_Settings.TargetStopSettings.Target1.Quantity > 
                UpdateEntryQuantity();
            }
            //return 0;
        }
        #endregion

        #region Calculate Targets N Stops
        public void CalculateTargetsNStops(int iQuantity)
        {
            if (_EasyTraderSettings.TargetStopSettings.Target1.Quantity >= iQuantity)
            {
                _EasyTraderSettings.TargetStopSettings.Target1.Quantity = iQuantity;
                _EasyTraderSettings.TargetStopSettings.Target2.UseTarget = false;
                _EasyTraderSettings.TargetStopSettings.Target3.UseTarget = false;
            }
            else if (_EasyTraderSettings.TargetStopSettings.Target1.Quantity + _EasyTraderSettings.TargetStopSettings.Target2.Quantity >= iQuantity)
            {
                _EasyTraderSettings.TargetStopSettings.Target2.Quantity = iQuantity - _EasyTraderSettings.TargetStopSettings.Target1.Quantity;
                _EasyTraderSettings.TargetStopSettings.Target3.UseTarget = false;
            }
            else if (_EasyTraderSettings.TargetStopSettings.Target1.Quantity + _EasyTraderSettings.TargetStopSettings.Target2.Quantity + _EasyTraderSettings.TargetStopSettings.Target3.Quantity >= iQuantity)
            {
                _EasyTraderSettings.TargetStopSettings.Target3.Quantity = iQuantity - _EasyTraderSettings.TargetStopSettings.Target1.Quantity - _EasyTraderSettings.TargetStopSettings.Target2.Quantity;
            }
        }
        #endregion

        #region Get Multiple
        private int RoundDown(double value, int divizor)
        {
            if (divizor == 0)
                return Convert.ToInt32(Math.Floor(value));
            return Convert.ToInt32(Math.Floor(value / (double)divizor) * divizor);
        }
        #endregion

        #region Set IDs
        //public void SetIDs(List<StoreIDs> values)
        //{
        //    lock (values)
        //    {
        //        lock (_sUniqueID)
        //        {
        //            _sUniqueID.Clear();
        //            if (values.Count > 0)
        //            {
        //                for (int i = 0; i < values.Count; i++)
        //                    _sUniqueID.Add(values[i].Clone() as StoreIDs);
        //            }
        //        }
        //    }
        //}
        #endregion

        #endregion

        #region Display

        #region Text Position
        internal class MyTextPosition : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Bottom Left", "Bottom Right", "Center", "Top Left", "Top Right" });
            }
        }
        #endregion

        #region Display Name
        public override string DisplayName
        {
            get { return string.Format("{0}", productName); }
        }
        #endregion

        #endregion

        #endregion

        #region Properties

        #region Public but hidden
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public Series<double> TrailValueActive
        {
            get { return Values[0]; }
        }
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public Series<double> TrailValueViewing
        {
            get { return Values[1]; }
        }
        #endregion

        #region Account Parameters
        [NinjaScriptProperty]
        [Display(Name = "Trading Account", Description = "Selected account", GroupName = "Account Parameters", Order = 1)]
        [TypeConverter(typeof(ArcAlgoNewAccountNameFinderLean))]
        public string AccountName { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Account Currency", Description = "Forex Position Sizing Account Currency", GroupName = "Account Parameters", Order = 2)]
        public ARCEasyTraderLeanAccountCurrency AccountCurrency { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Order Time In Force", Description = "", GroupName = "Account Parameters", Order = 8)]
        public ARCEasyTraderLeanTimeInForce OrderTimeInForce { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Account Balance", Description = "", GroupName = "Account Parameters", Order = 200)]
        public double AccountBalance { get; set; }
        #endregion

        #region Trade Plan 1 Parameters		

        private Brush iPlanLineEntryColorL1 = Brushes.DarkGreen;
        [XmlIgnore()]
        [NinjaScriptProperty]
        [Display(Name = "Entry Long Line Color", Description = "", GroupName = "Trade Plan 1 Parameters", Order = 3)]
        public Brush PlanLineEntryColorL1 { get; set; }
        [Browsable(false)]
        public string PlanLineEntryLColorSerialize1
        {
            get { return Serialize.BrushToString(PlanLineEntryColorL1); }
            set { PlanLineEntryColorL1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore()]
        [NinjaScriptProperty]
        [Display(Name = "Entry Short Line Color", Description = "", GroupName = "Trade Plan 1 Parameters", Order = 4)]
        public Brush PlanLineEntryColorS1 { get; set; }

        [Browsable(false)]
        public string PlanLineEntrySColorSerialize1
        {
            get { return Serialize.BrushToString(PlanLineEntryColorS1); }
            set { PlanLineEntryColorS1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore()]
        [NinjaScriptProperty]
        [Display(Name = "Stop Line Color", Description = "", GroupName = "Trade Plan 1 Parameters", Order = 5)]
        public Brush PlanLineStopColor1 { get; set; }
        [Browsable(false)]
        public string PlanLineStopColorSerialize1
        {
            get { return Serialize.BrushToString(PlanLineStopColor1); }
            set { PlanLineStopColor1 = Serialize.StringToBrush(value); }
        }

        [XmlIgnore()]
        [NinjaScriptProperty]
        [Display(Name = "Target Line Color", Description = "", GroupName = "Trade Plan 1 Parameters", Order = 6)]
        public Brush PlanLineTargetColor1 { get; set; }
        [Browsable(false)]
        public string PlanLineTargetColorSerialize1
        {
            get { return Serialize.BrushToString(PlanLineTargetColor1); }
            set { PlanLineTargetColor1 = Serialize.StringToBrush(value); }
        }

        #endregion

        #region General Visual Parameters

        [NinjaScriptProperty]
        [Display(Name = "Entry / Target / Stop Line Length", Description = "Line length for the Target(s), stop, and entry line.  ", GroupName = "General Visual Parameters", Order = 2)]
        public int LineLength { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Note Font Size", Description = "Select the font to use for the text", GroupName = "General Visual Parameters", Order = 10)]
        public int ChartNoteTextFontSize { get; set; }

        [XmlIgnore()]
        [NinjaScriptProperty]
        [Display(Name = "Note Text Color", Description = "", GroupName = "General Visual Parameters", Order = 20)]
        public Brush ChartNoteColor { get; set; }
        [Browsable(false)]
        public string ChartNoteColorSerialize
        {
            get { return Serialize.BrushToString(ChartNoteColor); }
            set { ChartNoteColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [Display(Name = "Note Text Position", Description = "", GroupName = "General Visual Parameters", Order = 30)]
        [TypeConverter(typeof(MyTextPosition))]
        public string ChartNoteTextPosition { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Plan Font Size", Description = "", GroupName = "General Visual Parameters", Order = 40)]
        public int PlanningTextFontSize { get; set; }

        [Display(Name = "Button Txt When Hid", Description = "Text on the button when EasyTrader is hidden from view", GroupName = "General Visual Parameters", Order = 100)]
        public string ButtonText_WhenHid { get; set; }

        [Display(Name = "Button Txt When Shown", Description = "Text on the button when EasyTrader is in view", GroupName = "General Visual Parameters", Order = 110)]
        public string ButtonText_WhenShown { get; set; }

        [XmlIgnore()]
        [NinjaScriptProperty]
        [Display(Name = "Average Line Color", Description = "", GroupName = "General Visual Parameters", Order = 120)]
        public Brush AverageLineColor { get; set; }
        [Browsable(false)]
        public string AverageLineColorSerialize
        {
            get { return Serialize.BrushToString(AverageLineColor); }
            set { AverageLineColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore()]
        [NinjaScriptProperty]
        [Display(Name = "Flags Background Color", Description = "", GroupName = "General Visual Parameters", Order = 130)]
        public Brush FlagsBackgroundColor { get; set; }
        [Browsable(false)]
        public string FlagsBackgroundColorSerialize
        {
            get { return Serialize.BrushToString(FlagsBackgroundColor); }
            set { FlagsBackgroundColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore()]
        [NinjaScriptProperty]
        [Display(Name = "Flags Text Color", Description = "", GroupName = "General Visual Parameters", Order = 140)]
        public Brush FlagsTextColor { get; set; }
        [Browsable(false)]
        public string FlagsTextColorSerialize
        {
            get { return Serialize.BrushToString(FlagsTextColor); }
            set { FlagsTextColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [Display(Name = "Show Short Order Names", Description = "", GroupName = "General Visual Parameters", Order = 150)]
        public bool ShowShortOrderNames { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Panel", Description = "", GroupName = "General Visual Parameters", Order = 160)]
        public bool ShowPanel { get; set; }

        #endregion

        #region Display
        [NinjaScriptProperty]
        [Display(Name = "Text Font", Description = "Choose your font style for the propting text displayed on the top left of the chart", Order = 10, GroupName = "Display")]
        public SimpleFont TextFont { get; set; }

        [XmlIgnore]
        [Display(Name = "Text color", Description = "Choose the color with which to paint the inside of the box", Order = 20, GroupName = "Display")]
        public Brush TextColor { get; set; }
        [Browsable(false)]
        public string _TextColor { get { return Serialize.BrushToString(TextColor); } set { TextColor = Serialize.StringToBrush(value); } }

        [NinjaScriptProperty]
        [Display(Name = "Plan - Long Entry Line Properties", Description = "", Order = 100, GroupName = "Display")]
        public Stroke PlanLongEntryStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Plan - Long Stop Line Properties", Description = "", Order = 110, GroupName = "Display")]
        public Stroke PlanLongStopStroke { get; set; }
        [NinjaScriptProperty]
        [Display(Name = "Plan - Long Target Line Properties", Description = "", Order = 120, GroupName = "Display")]
        public Stroke PlanLongTargetStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Plan - Short Entry Line Properties", Description = "", Order = 200, GroupName = "Display")]
        public Stroke PlanShortEntryStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Plan - Short Stop Line Properties", Description = "", Order = 210, GroupName = "Display")]
        public Stroke PlanShortStopStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Plan - Short Target Line Properties", Description = "", Order = 220, GroupName = "Display")]
        public Stroke PlanShortTargetStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Plan - Hovered Line Properties", Description = "", Order = 300, GroupName = "Display")]
        public Stroke PlanHoveredStroke { get; set; }
        #endregion

        #endregion

    }

}


public enum ARCEasyTraderLeanAccountCurrency
{
    USD,
    EUR,
    JPY,
    GBP,
    CHF,
    AUD,
    CAD,
    NZD,
}

public enum ARCEasyTraderLeanPlotLinesTextPosition
{
    RIGHT,
    LEFT
}

public enum ARCEasyTraderLeanEntryCommand
{
    ADD,
    REMOVE,
    UPDATE_ALL,
    UPDATE_FINISH,
    UPDATE_PNL,
    ENTER_MANUAL_ENTRIES,
    CANCEL_MANUAL_ENTRIES,
    DISPLAY_USER_MESSAGE,
    REMOVE_ALL_PLAN
}

public enum ARCEasyTraderLeanDrawingType
{
    AllObjects,
    ArrowUp,
    ArrowDown,
    TriangleUp,
    TriangleDown,
    ArrowLine,
    Diamond,
    Dot,
    Square,
    VerticalLine,
    Text
}

public enum ARCEasyTraderLeanEntryType
{
    Market,
    LimitOnClose
}
public enum ARCEasyTraderLeanExitOnSignal
{
    Ignore,
    Exit,
    Reverse
}

public enum ARCEasyTraderLeanTradeOn
{
    LiveBar,
    BarClose
}

public enum ARCEasyTraderLeanTrailFrequency
{
    EachTick,
    BarClose
}

public enum ARCEasyTraderLeanTimeInForce
{
    GTC,
    DAY
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARCEasyTraderLean[] cacheARCEasyTraderLean;
		public ARC.ARCEasyTraderLean ARCEasyTraderLean(string accountName, ARCEasyTraderLeanAccountCurrency accountCurrency, ARCEasyTraderLeanTimeInForce orderTimeInForce, double accountBalance, Brush planLineEntryColorL1, Brush planLineEntryColorS1, Brush planLineStopColor1, Brush planLineTargetColor1, int lineLength, int chartNoteTextFontSize, Brush chartNoteColor, string chartNoteTextPosition, int planningTextFontSize, Brush averageLineColor, Brush flagsBackgroundColor, Brush flagsTextColor, bool showShortOrderNames, bool showPanel, SimpleFont textFont, Stroke planLongEntryStroke, Stroke planLongStopStroke, Stroke planLongTargetStroke, Stroke planShortEntryStroke, Stroke planShortStopStroke, Stroke planShortTargetStroke, Stroke planHoveredStroke)
		{
			return ARCEasyTraderLean(Input, accountName, accountCurrency, orderTimeInForce, accountBalance, planLineEntryColorL1, planLineEntryColorS1, planLineStopColor1, planLineTargetColor1, lineLength, chartNoteTextFontSize, chartNoteColor, chartNoteTextPosition, planningTextFontSize, averageLineColor, flagsBackgroundColor, flagsTextColor, showShortOrderNames, showPanel, textFont, planLongEntryStroke, planLongStopStroke, planLongTargetStroke, planShortEntryStroke, planShortStopStroke, planShortTargetStroke, planHoveredStroke);
		}

		public ARC.ARCEasyTraderLean ARCEasyTraderLean(ISeries<double> input, string accountName, ARCEasyTraderLeanAccountCurrency accountCurrency, ARCEasyTraderLeanTimeInForce orderTimeInForce, double accountBalance, Brush planLineEntryColorL1, Brush planLineEntryColorS1, Brush planLineStopColor1, Brush planLineTargetColor1, int lineLength, int chartNoteTextFontSize, Brush chartNoteColor, string chartNoteTextPosition, int planningTextFontSize, Brush averageLineColor, Brush flagsBackgroundColor, Brush flagsTextColor, bool showShortOrderNames, bool showPanel, SimpleFont textFont, Stroke planLongEntryStroke, Stroke planLongStopStroke, Stroke planLongTargetStroke, Stroke planShortEntryStroke, Stroke planShortStopStroke, Stroke planShortTargetStroke, Stroke planHoveredStroke)
		{
			if (cacheARCEasyTraderLean != null)
				for (int idx = 0; idx < cacheARCEasyTraderLean.Length; idx++)
					if (cacheARCEasyTraderLean[idx] != null && cacheARCEasyTraderLean[idx].AccountName == accountName && cacheARCEasyTraderLean[idx].AccountCurrency == accountCurrency && cacheARCEasyTraderLean[idx].OrderTimeInForce == orderTimeInForce && cacheARCEasyTraderLean[idx].AccountBalance == accountBalance && cacheARCEasyTraderLean[idx].PlanLineEntryColorL1 == planLineEntryColorL1 && cacheARCEasyTraderLean[idx].PlanLineEntryColorS1 == planLineEntryColorS1 && cacheARCEasyTraderLean[idx].PlanLineStopColor1 == planLineStopColor1 && cacheARCEasyTraderLean[idx].PlanLineTargetColor1 == planLineTargetColor1 && cacheARCEasyTraderLean[idx].LineLength == lineLength && cacheARCEasyTraderLean[idx].ChartNoteTextFontSize == chartNoteTextFontSize && cacheARCEasyTraderLean[idx].ChartNoteColor == chartNoteColor && cacheARCEasyTraderLean[idx].ChartNoteTextPosition == chartNoteTextPosition && cacheARCEasyTraderLean[idx].PlanningTextFontSize == planningTextFontSize && cacheARCEasyTraderLean[idx].AverageLineColor == averageLineColor && cacheARCEasyTraderLean[idx].FlagsBackgroundColor == flagsBackgroundColor && cacheARCEasyTraderLean[idx].FlagsTextColor == flagsTextColor && cacheARCEasyTraderLean[idx].ShowShortOrderNames == showShortOrderNames && cacheARCEasyTraderLean[idx].ShowPanel == showPanel && cacheARCEasyTraderLean[idx].TextFont == textFont && cacheARCEasyTraderLean[idx].PlanLongEntryStroke == planLongEntryStroke && cacheARCEasyTraderLean[idx].PlanLongStopStroke == planLongStopStroke && cacheARCEasyTraderLean[idx].PlanLongTargetStroke == planLongTargetStroke && cacheARCEasyTraderLean[idx].PlanShortEntryStroke == planShortEntryStroke && cacheARCEasyTraderLean[idx].PlanShortStopStroke == planShortStopStroke && cacheARCEasyTraderLean[idx].PlanShortTargetStroke == planShortTargetStroke && cacheARCEasyTraderLean[idx].PlanHoveredStroke == planHoveredStroke && cacheARCEasyTraderLean[idx].EqualsInput(input))
						return cacheARCEasyTraderLean[idx];
			return CacheIndicator<ARC.ARCEasyTraderLean>(new ARC.ARCEasyTraderLean(){ AccountName = accountName, AccountCurrency = accountCurrency, OrderTimeInForce = orderTimeInForce, AccountBalance = accountBalance, PlanLineEntryColorL1 = planLineEntryColorL1, PlanLineEntryColorS1 = planLineEntryColorS1, PlanLineStopColor1 = planLineStopColor1, PlanLineTargetColor1 = planLineTargetColor1, LineLength = lineLength, ChartNoteTextFontSize = chartNoteTextFontSize, ChartNoteColor = chartNoteColor, ChartNoteTextPosition = chartNoteTextPosition, PlanningTextFontSize = planningTextFontSize, AverageLineColor = averageLineColor, FlagsBackgroundColor = flagsBackgroundColor, FlagsTextColor = flagsTextColor, ShowShortOrderNames = showShortOrderNames, ShowPanel = showPanel, TextFont = textFont, PlanLongEntryStroke = planLongEntryStroke, PlanLongStopStroke = planLongStopStroke, PlanLongTargetStroke = planLongTargetStroke, PlanShortEntryStroke = planShortEntryStroke, PlanShortStopStroke = planShortStopStroke, PlanShortTargetStroke = planShortTargetStroke, PlanHoveredStroke = planHoveredStroke }, input, ref cacheARCEasyTraderLean);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARCEasyTraderLean ARCEasyTraderLean(string accountName, ARCEasyTraderLeanAccountCurrency accountCurrency, ARCEasyTraderLeanTimeInForce orderTimeInForce, double accountBalance, Brush planLineEntryColorL1, Brush planLineEntryColorS1, Brush planLineStopColor1, Brush planLineTargetColor1, int lineLength, int chartNoteTextFontSize, Brush chartNoteColor, string chartNoteTextPosition, int planningTextFontSize, Brush averageLineColor, Brush flagsBackgroundColor, Brush flagsTextColor, bool showShortOrderNames, bool showPanel, SimpleFont textFont, Stroke planLongEntryStroke, Stroke planLongStopStroke, Stroke planLongTargetStroke, Stroke planShortEntryStroke, Stroke planShortStopStroke, Stroke planShortTargetStroke, Stroke planHoveredStroke)
		{
			return indicator.ARCEasyTraderLean(Input, accountName, accountCurrency, orderTimeInForce, accountBalance, planLineEntryColorL1, planLineEntryColorS1, planLineStopColor1, planLineTargetColor1, lineLength, chartNoteTextFontSize, chartNoteColor, chartNoteTextPosition, planningTextFontSize, averageLineColor, flagsBackgroundColor, flagsTextColor, showShortOrderNames, showPanel, textFont, planLongEntryStroke, planLongStopStroke, planLongTargetStroke, planShortEntryStroke, planShortStopStroke, planShortTargetStroke, planHoveredStroke);
		}

		public Indicators.ARC.ARCEasyTraderLean ARCEasyTraderLean(ISeries<double> input , string accountName, ARCEasyTraderLeanAccountCurrency accountCurrency, ARCEasyTraderLeanTimeInForce orderTimeInForce, double accountBalance, Brush planLineEntryColorL1, Brush planLineEntryColorS1, Brush planLineStopColor1, Brush planLineTargetColor1, int lineLength, int chartNoteTextFontSize, Brush chartNoteColor, string chartNoteTextPosition, int planningTextFontSize, Brush averageLineColor, Brush flagsBackgroundColor, Brush flagsTextColor, bool showShortOrderNames, bool showPanel, SimpleFont textFont, Stroke planLongEntryStroke, Stroke planLongStopStroke, Stroke planLongTargetStroke, Stroke planShortEntryStroke, Stroke planShortStopStroke, Stroke planShortTargetStroke, Stroke planHoveredStroke)
		{
			return indicator.ARCEasyTraderLean(input, accountName, accountCurrency, orderTimeInForce, accountBalance, planLineEntryColorL1, planLineEntryColorS1, planLineStopColor1, planLineTargetColor1, lineLength, chartNoteTextFontSize, chartNoteColor, chartNoteTextPosition, planningTextFontSize, averageLineColor, flagsBackgroundColor, flagsTextColor, showShortOrderNames, showPanel, textFont, planLongEntryStroke, planLongStopStroke, planLongTargetStroke, planShortEntryStroke, planShortStopStroke, planShortTargetStroke, planHoveredStroke);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARCEasyTraderLean ARCEasyTraderLean(string accountName, ARCEasyTraderLeanAccountCurrency accountCurrency, ARCEasyTraderLeanTimeInForce orderTimeInForce, double accountBalance, Brush planLineEntryColorL1, Brush planLineEntryColorS1, Brush planLineStopColor1, Brush planLineTargetColor1, int lineLength, int chartNoteTextFontSize, Brush chartNoteColor, string chartNoteTextPosition, int planningTextFontSize, Brush averageLineColor, Brush flagsBackgroundColor, Brush flagsTextColor, bool showShortOrderNames, bool showPanel, SimpleFont textFont, Stroke planLongEntryStroke, Stroke planLongStopStroke, Stroke planLongTargetStroke, Stroke planShortEntryStroke, Stroke planShortStopStroke, Stroke planShortTargetStroke, Stroke planHoveredStroke)
		{
			return indicator.ARCEasyTraderLean(Input, accountName, accountCurrency, orderTimeInForce, accountBalance, planLineEntryColorL1, planLineEntryColorS1, planLineStopColor1, planLineTargetColor1, lineLength, chartNoteTextFontSize, chartNoteColor, chartNoteTextPosition, planningTextFontSize, averageLineColor, flagsBackgroundColor, flagsTextColor, showShortOrderNames, showPanel, textFont, planLongEntryStroke, planLongStopStroke, planLongTargetStroke, planShortEntryStroke, planShortStopStroke, planShortTargetStroke, planHoveredStroke);
		}

		public Indicators.ARC.ARCEasyTraderLean ARCEasyTraderLean(ISeries<double> input , string accountName, ARCEasyTraderLeanAccountCurrency accountCurrency, ARCEasyTraderLeanTimeInForce orderTimeInForce, double accountBalance, Brush planLineEntryColorL1, Brush planLineEntryColorS1, Brush planLineStopColor1, Brush planLineTargetColor1, int lineLength, int chartNoteTextFontSize, Brush chartNoteColor, string chartNoteTextPosition, int planningTextFontSize, Brush averageLineColor, Brush flagsBackgroundColor, Brush flagsTextColor, bool showShortOrderNames, bool showPanel, SimpleFont textFont, Stroke planLongEntryStroke, Stroke planLongStopStroke, Stroke planLongTargetStroke, Stroke planShortEntryStroke, Stroke planShortStopStroke, Stroke planShortTargetStroke, Stroke planHoveredStroke)
		{
			return indicator.ARCEasyTraderLean(input, accountName, accountCurrency, orderTimeInForce, accountBalance, planLineEntryColorL1, planLineEntryColorS1, planLineStopColor1, planLineTargetColor1, lineLength, chartNoteTextFontSize, chartNoteColor, chartNoteTextPosition, planningTextFontSize, averageLineColor, flagsBackgroundColor, flagsTextColor, showShortOrderNames, showPanel, textFont, planLongEntryStroke, planLongStopStroke, planLongTargetStroke, planShortEntryStroke, planShortStopStroke, planShortTargetStroke, planHoveredStroke);
		}
	}
}

#endregion
