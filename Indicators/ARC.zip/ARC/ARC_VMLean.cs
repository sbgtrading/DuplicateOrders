//#define USE_WPF_COORDS
#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using SharpDX.DirectWrite;
using System.Windows.Controls;
using System.Windows.Automation;
#endregion

#region -- Author / Infos version --
/*********************************************************************
************************* Golden Zone Trading ************************
**********************************************************************
* Authors NT7 : Harry / RJ { RJ5GROUP }
* Author NT8 : Kriss { AzurITec }
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
v1.001  - 24.03.2016    + Conversion from NT7 to NT8b10. Modified the draw of div in indicator panel by using the SharpDX method in the OnRender section (RT behaviour on historical data)
						+ VERIFIED : Velocity MomoDiv Calculation
						+ VERIFIED : ExcursionValues and plot + colors
						+ VERIFIED : Zigzag calculation + draw @ CalculateOnBarClose and EachTick
						+ VERIFIED : Div calculation + draw @ CalculateOnBarClose and EachTick
                        - Need to check default settings for display (different to NT7) and order in setting window
----------------------------------------------------------------------
v1.002  - 27.03.2016    + [FIXED] Bug BG001 found by Sean and Fixed
						+ [FIXED] Bug BG002 found by Sean and Fixed		
						- Bug BG003 found by Sean - Need to investigate. Suspect NT8 bug
----------------------------------------------------------------------
v1.003  - 07.04.2016    + [NT8 BUG] : Bug BG003 signaled to NinjaTrader and will be fixed in next Beta.
						+ Default settings modified with Sean
						+ AntiAlias Mode from "Aliased" to "PerPrimitive" to get smooth lines (no hash) when drawn with SharpDX Functions.
----------------------------------------------------------------------
v1.004 - 08.04.2016     + VERIFIED : Exposed DataSeries
                        + minor changes in the default settings and DisplayName
----------------------------------------------------------------------
v1.005 - 18.05.2016     + Change Floodig option from bool to enum
                        + [FINAL] version so far.
----------------------------------------------------------------------
v1.006 - 25.05.2016     + Beta11 code breaking change with OnRender Method
                        + [FIXED] Bug BG003 - Beta 11 fixed this bug.
----------------------------------------------------------------------
v1.007  - 05.09.2016    + Compatible Beta13 RC1
----------------------------------------------------------------------
v1.008  - 22.09.2016    + Added //[NinjaScriptProperty] Attribute to be called from PPTrades indicator
                        + Created Custom Namespace for enum to be called from PPTrades.
----------------------------------------------------------------------
v1.009  - 22.09.2016    + Compatible Beta14 RC2
                        + Changed Opacity Settings to simplify code
----------------------------------------------------------------------
v1.010  - 06.02.2017    + added hidden divergences. See #HIDDENDIV
----------------------------------------------------------------------
v1.10   - 21.03.2017    + All NT7 changes coded
----------------------------------------------------------------------
######################################################################
~~~~~~~~~~~~~~~~~~~~~~~~~ BUGS/ LIMITATIONS ~~~~~~~~~~~~~~~~~~~~~~~~~~
LIM001 : At that time (NT8beta10) there is no official way to draw on price panel from indicator panel using SharpDX methods. See thread : http://ninjatrader.com/support/forum/showthread.php?p=453383#post453383
LIM002 [FIXED] : The native Draw.Line function always draw above custom draw using SharpDX. As a result, the div on osc panel are drawn above the sentiment box. [FIX : use of custom plot]

----------------------------------------------------------------------
Bug BG001 [FIXED] : PriceExcursionLL3 plots above PriceExcursionUL3. Was a CC problem regarding plots index constantes.
Bug BG002 [FIXED] : BBLine not showing. Forgot to write the draw function of BBLine after code optimization
Bug BG003 [FIXED in B11] : On CL05-16 24.03.2016 @ 11:59, a div (MACD+Histo) is drawn on indicator panel. 
						   On PP, the line isn't drawn and the arrows are drawn at the beginning of the div. 
						   It happens on a succession of phantom bars. Could be a bug from NT8 because the timestamp of each bar is the same to the ms.
----------------------------------------------------------------------
v1.11   - 11.26.2017   + JQ 11.26.2017
	Bug 12782. The set right margin is causing the shifting of the SDV bar when the PP bar and the Divergence indicator
	are all on the same chart. This could be a NT8 issue as it appears the BarMarginRight is only applied to the
	primary bar (PP) rather than the secondary bar (SDV). For now, I will disable the setrightmargin properties
	until I have a chance to talk to NT about this issue.
	+ Added version Number on the property dialog box
----------------------------------------------------------------------
v1.12   - Feb.17.2018   + BenLetto
	In response to NT8.0.12.0, removed all calls to "wpf" coordinate calculations
	Also, removed repetitive DXBrush creation/disposal to help improve performance.  DXBrushes are now created once in the beginning of the OnRender method
----------------------------------------------------------------------
v1.2   - Oct.11.2018   + BenLetto
	Removed numerous sloppy string concatinations, replaced with string.Format()
	Added "SentimentBoxLocation" so user can select location of Sentiment box
	Added - OverprintSentimentBox true/false, SentimentBox will now overprint the plotted info by moving base.OnRender up in the code
	Added "OptimizeSpeed" parameter to limit the number of chart marker and font objects printed to the price chart
----------------------------------------------------------------------
*/
#endregion

//TAGS : ##MODIF HERE## / ##DEFAULT VALUE TO CHECK## / ##HARD CODED## / ##??##

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region -- Category Order --
    [CategoryOrder("Parameters", 1)]
    [CategoryOrder("Divergence Options", 10)]
    [CategoryOrder("Divergence Parameters", 20)]
    [CategoryOrder("MACDBB Parameters", 30)]
    [CategoryOrder("SwingTrend Parameters", 40)]
    [CategoryOrder("Display Options Divergences", 50)]
    [CategoryOrder("Display Options Oscillator Panel", 60)]
    [CategoryOrder("Display Options Price Excursions", 65)]
    [CategoryOrder("Display Options Swing Trend", 70)]
    [CategoryOrder("Histogram Divergences - Plot Colors", 80)]
    [CategoryOrder("Histogram Divergences - Plot Parameters", 90)]
    [CategoryOrder("Histogram Hidden Divergences - Plot Colors", 100)]
    [CategoryOrder("Histogram Hidden Divergences - Plot Parameters", 110)]
    [CategoryOrder("MACD Divergences - Plot Colors", 120)]
    [CategoryOrder("MACD Divergences - Plot Parameters", 130)]
    [CategoryOrder("MACD Hidden Divergences - Plot Colors", 140)]
    [CategoryOrder("MACD Hidden Divergences - Plot Parameters", 150)]
    [CategoryOrder("Plot Colors", 160)]
    [CategoryOrder("Plot Parameters", 170)]
    [CategoryOrder("Price Excursion - Plot Colors", 180)]
    [CategoryOrder("Price Excursion - Plot Parameters", 190)]
    [CategoryOrder("Sentiment Box - Colors", 200)]
    [CategoryOrder("Sentiment Box - Parameters", 210)]
    [CategoryOrder("Sentiment Box - Text Elements", 220)]
    #endregion
    public class ARC_VMLean : Indicator
    {
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "VMLean";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "25900", "9961", "819", "875", "27405"};
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsDebug = false;


        private const string VERSION = "v2.0 3-May-2022";
		//v1.6 - changed IsSuspendedWhileInactive to "false" to solve the wandering structure line mislocations
		//v1.7 - Moved all data-dependent inits to DataLoaded state (out of Configure state), for NT8.0.20.0 compatibility
		//v1.8 - Added scrollwheel support for Structure SwingStrength and Sensitivity
		//v1.9 - Fixed bbDotTrend...it was outputting zeroes only
		//v2.0 - Implemented OnRenderTargetChanged, added pEnableSwingCalculation
		
        #region ---- Variables ---- 
        #region -- Bloodhound --
        private Series<double> structureBiasState;
        private Series<double> swingHighsState;
        private Series<double> swingLowsState;

		#endregion

        #region -- Structure BIAS + Swings --
        private List<int> sequence = new List<int>(3);//#STRBIAS
        private int SRType, preSRType;//#STRBIAS  
		private SharpDX.Direct2D1.Brush BullishDivergenceDXBrush, BearishDivergenceDXBrush, DataTableDXBrush, OppositeBkgDXBrush;
		private SharpDX.Direct2D1.Brush BullishBkgDXBrush, BearishBkgDXBrush, ChannelBkgDXBrush;
		private SharpDX.Direct2D1.Brush DeepBullishBkgDXBrush, DeepBearishBkgDXBrush;
        #endregion

        #region -- velocity momo  --
        private MACD BMACD;
        private MACD MACD1;
        private MACD MACD2;
        private MACD MACD3;
        private MACD MACD4;
        private StdDev SDBB;
        #endregion

        #region -- zigzag indicator -- 
        private int lastHighIdx = 0;
        private int lastLowIdx = 0;
        private int priorSwingHighIdx = 0;
        private int priorSwingLowIdx = 0;
        private int highCount = 0;
        private int lowCount = 0;
        private int preLastHighIdx = 0;
        private int preLastLowIdx = 0;
        private double zigzagDeviation = 0.0;
        private double currentHigh = 0.0;
        private double currentLow = 0.0;
        private double swingMax = 0.0;
        private double swingMin = 0.0;
        private double preCurrentHigh = 0.0;
        private double preCurrentLow = 0.0;
        private bool addHigh = false;
        private bool updateHigh = false;
        private bool addLow = false;
        private bool updateLow = false;
        private bool drawHigherHighDot = false;
        private bool drawLowerHighDot = false;
        private bool drawDoubleTopDot = false;
        private bool drawLowerLowDot = false;
        private bool drawHigherLowDot = false;
        private bool drawDoubleBottomDot = false;
        private bool drawHigherHighLabel = false;
        private bool drawLowerHighLabel = false;
        private bool drawDoubleTopLabel = false;
        private bool drawLowerLowLabel = false;
        private bool drawHigherLowLabel = false;
        private bool drawDoubleBottomLabel = false;
        private bool drawSwingLegUp = false;
        private bool drawSwingLegDown = false;
        private bool intraBarAddHigh = false;
        private bool intraBarUpdateHigh = false;
        private bool intraBarAddLow = false;
        private bool intraBarUpdateLow = false;

        private SimpleFont labelFont = null;
        private SimpleFont swingDotFont = null;
        private int pixelOffset1 = 10;               //##HARD CODED##
        private int pixelOffset2 = 10;               //##HARD CODED##
        private string dotString = "n";              //##HARD CODED##

        private ATR avgTrueRange;
        private Series<double> swingInput;
        private Series<int> pre_swingHighType;
        private Series<int> pre_swingLowType;
        private Series<int> swingHighType;
        private Series<int> swingLowType;
        private Series<int> acceleration1;
        private Series<int> acceleration2;
        private Series<bool> upTrend;
        #endregion

        ARC_VMLean_InputType ThisInputType = ARC_VMLean_InputType.High_Low;

        private Series<double> bbDotTrend;

        #region -- Box --
        private SimpleFont dataFont1 = null;
        private SimpleFont dataFont2 = null;

        private System.Windows.TextAlignment textAlignmentCenter = System.Windows.TextAlignment.Center;

        private double filterValue1 = 0.0;
        private double filterValue2 = 0.0;
        private double filterValue3 = 0.0;

        private double dataStringHeight = 0.0;//##MODIF HERE## was float
        private string maxString1 = "";
        private string maxString2 = "";
        #endregion

        private SMA ExcursionSeries;

        #endregion

        #region -- Index Constants to change Plot order and superposition. Lower index goes below --        
        private const int BBMACDIDX = 12;
        private const int BBMACDFrameIDX = 11;
        private const int BBMACDLineIDX = 10;
        private const int AverageIDX = 9;
        private const int UpperIDX = 8;
        private const int LowerIDX = 7;
        private const int HistogramIDX = 6;
        private const int PriceExcursionUL3IDX = 5;
        private const int PriceExcursionUL2IDX = 4;
        private const int PriceExcursionUL1IDX = 3;
        private const int PriceExcursionLL1IDX = 2;
        private const int PriceExcursionLL2IDX = 1;
        private const int PriceExcursionLL3IDX = 0;
        private const int PriceExcursionMAXIDX = 14;
        private const int PriceExcursionMINIDX = 13;
        #endregion

//        public override string DisplayName { get { return "ARC_VMLean"; } }

        #region -- Toolbar variables --
        private string toolbarname = "NSVMLeanToolBar", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private Grid indytoolbar;

        private Menu MenuControlContainer;
        private MenuItem MenuControl;

        //private ComboBox comboMTF, comboZFM, comboProfile;
        private MenuItem miDivOptions1, miDivOptions2, miDivOptions3, miDivOptions4, miRecalculate1;
        private MenuItem miDisplayOptions1, miDisplayOptions2, miDisplayOptions3, miDisplayOptions4, miDisplayOptions5, miDisplayOptions6, miDisplayOptions7;
        private MenuItem miExcursionLevels1, miExcursionLevels2, miExcursionLevels3, miMarketStructure1, miMarketStructure2;
        private ComboBox comboExcursionStyle, comboFlooding;
        private TextBox nudMTF, nudZFM, nudMST1, nudMST2, nudCRV1, nudCRV2;
        
        private Button gCmdup;
        private Button gCmddw;
        private Label gLabel;
        #endregion

        #region -- Toolbar Management Utilities --
        #region -- addToolBar --
        private void addToolBar()
        {
            gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            gLabel = new Label();//#RJBug001

            MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
            MenuControl = new MenuItem {Name="NSVML"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Lime, Header = pButtonText, Foreground = Brushes.Lime, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
            MenuControlContainer.Items.Add(MenuControl);

            MenuItem item;
            Separator separator;

            #region -- MarketStructure --
            MenuItem miMarketStructure = new MenuItem { Header = "Swing Trend Parameters", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miMarketStructure1 = new MenuItem { Header = "Structure Swings " + (ShowZigzagLegs ? "ON" : "OFF"), Name = "btMarketStructure_trends"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miMarketStructure1.Click += MarketStructure_Click;
            miMarketStructure.Items.Add(miMarketStructure1);

            miMarketStructure2 = new MenuItem { Header = "Structure Labels " + (ShowZigzagLabels ? "ON" : "OFF"), Name = "btMarketStructure_labels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miMarketStructure2.Click += MarketStructure_Click;
            miMarketStructure.Items.Add(miMarketStructure2);

            miMarketStructure.Items.Add(createMSTMenu(MultiplierDTB.ToString(), SwingStrength.ToString()));

            separator = new Separator();
            miMarketStructure.Items.Add(separator);

            miRecalculate1 = new MenuItem { Header = "RE-CALCULATE MARKET STRUCTURE", Name = "marketStructureClick"+uID, 
				HorizontalAlignment = HorizontalAlignment.Center, 
				FontWeight = FontWeights.Normal,
				FontStyle = FontStyles.Normal,
				Background = null
			};
            miRecalculate1.Click += ReloadChart_Click;
            miMarketStructure.Items.Add(miRecalculate1);
            //------------------

			if(!pEnableSwingCalculation) miMarketStructure.IsEnabled = false;
			MenuControl.Items.Add(miMarketStructure);
            #endregion

            #region -- Excursion Levels --
            MenuItem miExcursionLevels = new MenuItem { Header = "Excursion Levels", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            bool isMasterOn = DisplayLevel1 || DisplayLevel2 || DisplayLevel3;
            item = new MenuItem { Header = "--- MASTER " + (isMasterOn ? "ON" : "OFF") + " ---", Name = "btExcursionLevels_Master"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            item.Click += RefreshChart_Click;
            miExcursionLevels.Items.Add(item);

            miExcursionLevels1 = new MenuItem { Header = "Show Level 1 " + (DisplayLevel1 ? "ON" : "OFF"), Name = "btExcursionLevels_Level1"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miExcursionLevels1.Click += RefreshChart_Click;
            miExcursionLevels.Items.Add(miExcursionLevels1);

            miExcursionLevels2 = new MenuItem { Header = "Show Level 2 " + (DisplayLevel2 ? "ON" : "OFF"), Name = "btExcursionLevels_Level2"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miExcursionLevels2.Click += RefreshChart_Click;
            miExcursionLevels.Items.Add(miExcursionLevels2);

            miExcursionLevels3 = new MenuItem { Header = "Show Level 3 " + (DisplayLevel3 ? "ON" : "OFF"), Name = "btExcursionLevels_Level3"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miExcursionLevels3.Click += RefreshChart_Click;
            miExcursionLevels.Items.Add(miExcursionLevels3);

            List<string> cbItems = new List<string>();
            foreach (var pt in Enum.GetValues(typeof(ARC_VMLean_ExcursionStyle))) cbItems.Add(pt.ToString());            
            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Lines' Mode :" };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            comboExcursionStyle = new ComboBox() { Name = "comboExcursionStyle" + uID, MinWidth = 86, Width = 86, MaxWidth = 86, Margin = new Thickness(5, 0, 0, 0) };
            foreach (string cbitem in cbItems) comboExcursionStyle.Items.Add(cbitem);
            comboExcursionStyle.SelectedItem = PlotStyleLevels == PlotStyle.HLine ? ARC_VMLean_ExcursionStyle.Static.ToString() : ARC_VMLean_ExcursionStyle.Dynamic.ToString();
            comboExcursionStyle.SelectionChanged += ExcursionStyleValueChanged;
            comboExcursionStyle.SetValue(Grid.ColumnProperty, 1);
            comboExcursionStyle.SetValue(Grid.RowProperty, 0);
            grid.Children.Add(lbl1);
            grid.Children.Add(comboExcursionStyle);
            miExcursionLevels.Items.Add(grid);

            MenuControl.Items.Add(miExcursionLevels);
            #endregion

            #region -- Sentiment --
            MenuItem miSentiment = new MenuItem {Name="miSentimentSettings"+uID, Header = "Sentiment Settings", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            item = new MenuItem { Header = "Show Structure Bias " + (ShowBiasInBox ? "ON" : "OFF"), Name = "btSentiment_Bias"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            item.Click += RefreshChart_Click;
            miSentiment.Items.Add(item);

            cbItems = new List<string>();
            foreach (var pt in Enum.GetValues(typeof(ARC_VMLean_Flooding))) {
				if(!pEnableSwingCalculation && pt.ToString().StartsWith("Structure")) continue;
				cbItems.Add(pt.ToString());
			}
            grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });
            lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Flooding :" };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            comboFlooding = new ComboBox() { Name = "comboFlooding" + uID, MinWidth = 86, Width = 86, MaxWidth = 86, Margin = new Thickness(5, 0, 0, 0) };
            foreach (string cbitem in cbItems) comboFlooding.Items.Add(cbitem);
            comboFlooding.SelectedItem = BackgroundFlooding.ToString();
            comboFlooding.SelectionChanged += FloodingValueChanged;
            comboFlooding.SetValue(Grid.ColumnProperty, 1);
            comboFlooding.SetValue(Grid.RowProperty, 0);
            grid.Children.Add(lbl1);
            grid.Children.Add(comboFlooding);
            miSentiment.Items.Add(grid);

            MenuControl.Items.Add(miSentiment);
            #endregion

            indytoolbar.Children.Add(MenuControlContainer);
        }
        #endregion
//=====================================================================================================
		private void InformUserAboutRecalculation(){
			miRecalculate1.Background = Brushes.Yellow;
			miRecalculate1.FontWeight = FontWeights.Bold;
			miRecalculate1.FontStyle = FontStyles.Italic;
		}
		private void ResetRecalculationUI(){
			miRecalculate1.FontWeight = FontWeights.Normal;
			miRecalculate1.FontStyle = FontStyles.Normal;
			miRecalculate1.Background = null;
		}
//=====================================================================================================
        private Grid createMSTMenu(string nudValue1, string nudValue2)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(55) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - MST1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Sensitivity :" };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudMST1 = new TextBox() { Name = "MST1txtbox" + uID, MinWidth = 60, Width = 60, MaxWidth = 60, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST1.Text = nudValue1;
            nudMST1.KeyDown += menuTxtbox_KeyDown;
            nudMST1.TextChanged += NumericUpDownValueChanged;
			nudMST1.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0) MultiplierDTB = MultiplierDTB+0.1;
				else MultiplierDTB = MultiplierDTB-0.1;
				MultiplierDTB = Math.Max(0,MultiplierDTB);
				nudMST1.Text = MultiplierDTB.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
				};
			nudMST1.SetValue(Grid.ColumnProperty, 1);
            nudMST1.SetValue(Grid.ColumnSpanProperty, 2);
            nudMST1.SetValue(Grid.RowProperty, 0);
            nudMST1.SetValue(Grid.RowSpanProperty, 2);
            
            //line 2 - MST2
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Strength : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudMST2 = new TextBox() { Name = "MST2txtbox" + uID, MinWidth = 50, Width = 50, MaxWidth = 50, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST2.Text = nudValue2;
            nudMST2.KeyDown += menuTxtbox_KeyDown;
            nudMST2.TextChanged += NumericUpDownValueChanged;
			nudMST2.MouseWheel += delegate (object o, MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0) SwingStrength++;
				else SwingStrength--;
				SwingStrength = Math.Max(1,SwingStrength);
				nudMST2.Text = SwingStrength.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
				};
            nudMST2.SetValue(Grid.ColumnProperty, 1);
            nudMST2.SetValue(Grid.RowProperty, 2);
            nudMST2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = "MST2cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = "MST2cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 2);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMST1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudMST2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            return grid;
        }

        //---------- Events ------------------------------------------------
        #region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #region -- DoubleEditKeyPress -- 
        private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtSender = sender as TextBox;

            int keyVal = (int)e.Key;
            int value = -1;
            if (keyVal >= (int)Key.D0 && keyVal <= (int)Key.D9) value = keyVal - (int)Key.D0;
            else if (keyVal >= (int)Key.NumPad0 && keyVal <= (int)Key.NumPad9) value = keyVal - (int)Key.NumPad0;

            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);

            if (isNumeric || e.Key == Key.Back || (e.Key == Key.Decimal && txtSender.Name.StartsWith("MST1txtbox")))
            {
                string newText = value != -1 ? value.ToString() : e.Key == Key.Decimal ? System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator : "";
                int tbPosition = txtSender.SelectionStart;
                txtSender.Text = txtSender.SelectedText == "" ? txtSender.Text.Insert(tbPosition, newText) : txtSender.Text.Replace(txtSender.SelectedText, newText);
                txtSender.Select(tbPosition + 1, 0);
            }
        }
        #endregion

        #region -- DoubleEditTextChanged --
        private string currentTextEdit;
        private void NumericUpDownValueChanged(object sender, EventArgs e)
        {
            TextBox txtSender = sender as TextBox;
            if (txtSender.Text.Length > 0)
            {
                float result;
                bool isNumeric = float.TryParse(txtSender.Text, out result);

                if (isNumeric) currentTextEdit = txtSender.Text;
                else
                {
                    txtSender.Text = currentTextEdit;
                    txtSender.Select(txtSender.Text.Length, 0);
                }
                if (txtSender.Name.StartsWith("MST1txtbox")) MultiplierDTB = Convert.ToDouble(nudMST1.Text);
                else if (txtSender.Name.StartsWith("MST2txtbox")) SwingStrength = Convert.ToInt32(nudMST2.Text);
            }
        }
        #endregion

        #region private void cmdupdw_Click(object sender, RoutedEventArgs e)
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
            Button cmd = sender as Button;
            if (cmd.Name.Contains("MST2cmdup")) nudMST2.Text = (Math.Min(999999999, Convert.ToInt32(nudMST2.Text) + 1)).ToString();
            else if (cmd.Name.Contains("MST2cmddw")) nudMST2.Text = (Math.Max(1, Convert.ToInt32(nudMST2.Text) - 1)).ToString();
        }
        #endregion

        #region -- MarketStructure_Click --
        private void MarketStructure_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //----------- Divergences Options -------------------
            if (item != null && item.Name.StartsWith("btMarketStructure_trends")) ShowZigzagLegs = !ShowZigzagLegs;
            else if (item != null && item.Name.StartsWith("btMarketStructure_labels")) ShowZigzagLabels = !ShowZigzagLabels;

            miMarketStructure1.Header = "Structure Swings " + (ShowZigzagLegs ? "ON" : "OFF");
            miMarketStructure2.Header = "Structure Labels " + (ShowZigzagLabels ? "ON" : "OFF");
        }

        #endregion

        #region -- FloodingValueChanged --
        private void FloodingValueChanged(object sender, EventArgs e)
        {
            ARC_VMLean_Flooding backgroundFlooding;
            Enum.TryParse((string)comboFlooding.SelectedItem, out backgroundFlooding);
            BackgroundFlooding = backgroundFlooding;
            RefreshChart_Click(null, null);
        }
        #endregion

        #region -- ExcursionStyleValueChanged --
        private void ExcursionStyleValueChanged(object sender, EventArgs e)
        {
            PlotStyleLevels = (string)comboExcursionStyle.SelectedItem == ARC_VMLean_ExcursionStyle.Static.ToString() ? PlotStyle.HLine : PlotStyle.Line;
            RefreshChart_Click(null, null);
        }
        #endregion

        #region -- RefreshChart_Click --
        private void RefreshChart_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                MenuItem item = sender as MenuItem;

                //----------- Excursion Levels -------------------
                if (item.Name.Contains("btExcursionLevels"))
                {
                    if (item.Name.StartsWith("btExcursionLevels_Level1")) DisplayLevel1 = !DisplayLevel1;
                    else if (item.Name.StartsWith("btExcursionLevels_Level2")) DisplayLevel2 = !DisplayLevel2;
                    else if (item.Name.StartsWith("btExcursionLevels_Level3")) DisplayLevel3 = !DisplayLevel3;
                    else if (item.Name.StartsWith("btExcursionLevels_Master"))
                    {
                        bool master = ((string)(item.Header)).Contains("ON");
                        master = !master;
                        item.Header = "--- MASTER " + (master ? "ON" : "OFF") + " ---";

                        DisplayLevel1 = master;
                        DisplayLevel2 = master;
                        DisplayLevel3 = master;
                    }

                    miExcursionLevels1.Header = "Show Level 1 " + (DisplayLevel1 ? "ON" : "OFF");
                    miExcursionLevels2.Header = "Show Level 2 " + (DisplayLevel2 ? "ON" : "OFF");
                    miExcursionLevels3.Header = "Show Level 3 " + (DisplayLevel3 ? "ON" : "OFF");
                }
                else if (item.Name.StartsWith("btSentiment_Bias"))
                {
                    ShowBiasInBox = !ShowBiasInBox;
                    item.Header = "Show Structure Bias " + (ShowBiasInBox ? "ON" : "OFF");
                }
            }

            ChartControl.InvalidateVisual();
        }
        #endregion

        #region -- ReloadChart_Click --
        private void ReloadChart_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //----------- Market Structure -------------------
            if (item.Name.StartsWith("marketStructureClick"))
            {
                try
                {
                    MultiplierDTB = Math.Max(0, Convert.ToDouble(nudMST1.Text));
                    SwingStrength = Math.Max(1, Convert.ToInt32(nudMST2.Text));
					ResetRecalculationUI();
				}
                catch (Exception){ }
            }

            System.Windows.Forms.SendKeys.SendWait("{F5}");
        }
        #endregion

        #region -- ModifyDisplayOptionsSetting_Click --
        private void ModifyDisplayOptionsSetting_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            //-----------Market Structure------------------ -
            if (item.Name.StartsWith("marketStructureClick"))
            {
                MultiplierDTB = Convert.ToDouble(nudMST1.Text);
                SwingStrength = Convert.ToInt32(nudMST2.Text);
				ResetRecalculationUI();
            }
        }
        #endregion

        #endregion

        protected override void OnStateChange()
        {
            #region State == State.SetDefaults  
            if (State == State.SetDefaults)
            {
				//Description = @"The NS_VelocityMomoDiv Measures 2 components of momentum:  1) the velocity histogram measures minor cycles of Multiple timeframe momentum cycles and act as a leading guage of momentum before a trend has started  2)(Moving Average Convergence/Divergence) is a trend following momentum indicator that shows the relationship between two moving averages of prices.";
				Name = "ARC_VMLean";
				ArePlotsConfigurable = false;
				DrawOnPricePanel = false;
				AreLinesConfigurable = false;
				DrawOnPricePanel = false;
				PaintPriceMarkers = false;
				pEnableSwingCalculation = false;
				ZOrder = -1;
				MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				ScaleJustification = ScaleJustification.Right;
				IsSuspendedWhileInactive = false;
				Calculate = Calculate.OnEachTick;
				IsOverlay = false;
				DisplayInDataBox = true;

				uID = DateTime.Now.Ticks.ToString();//prevent multiple toolbar with same name

				#region INIT Plots / Lines 

				//rj RJ5GROUP code Algorithm
				AddPlot(new Stroke(Brushes.Red), PlotStyle.HLine, "PriceExcursionLL3");
				AddPlot(new Stroke(Brushes.Blue), PlotStyle.HLine, "PriceExcursionLL2");
				AddPlot(new Stroke(Brushes.Black), PlotStyle.HLine, "PriceExcursionLL1");
				AddPlot(new Stroke(Brushes.Black), PlotStyle.HLine, "PriceExcursionUL1");
				AddPlot(new Stroke(Brushes.Blue), PlotStyle.HLine, "PriceExcursionUL2");
				AddPlot(new Stroke(Brushes.Red), PlotStyle.HLine, "PriceExcursionUL3");
				//rj RJ5GROUP code Algorithm

				//AddLine(Brushes.Gray, 0, "Zeroline");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Bar, "Histogram");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "Lower");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "Upper");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "Average");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Line, "BBMACDLine");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Dot, "BBMACDFrame");
				AddPlot(new Stroke(Brushes.Gray), PlotStyle.Dot, "BBMACD");

				AddPlot(new Stroke(Brushes.Black,0.1f), PlotStyle.Line, "PriceExcursionMAX");
				AddPlot(new Stroke(Brushes.Black, 0.1f), PlotStyle.Line, "PriceExcursionMIN");
				#endregion

				pButtonText = "VMLean";


                #region MACDBB Parameters
                BandPeriod = 10;
                Fast = 12;
                Slow = 26;
                StdDevNumber = 1.0;
                #endregion

                #region INIT Properties to Default Values 
                #region SwingTrend Parameters 
                SwingStrength = 3;
                MultiplierMD = 0.0;
                MultiplierDTB = 0.0;
                #endregion

                #region Display Options Oscillator Panel 
                //BackgroundFloodingPanel = gztFloodPanel.None;//##MODIF## AzurITec - 18.05.2016
                ShowBiasInBox = true;
                BackgroundFlooding = ARC_VMLean_Flooding.None;
                #endregion

                #region Display Options Swing Trend 
                SwingDotSize = 7;
                LabelFontSize = 10;
                SwingLegWidth = 2;
                ShowZigzagDots = false;
                ShowZigzagLabels = false;
                ShowZigzagLegs = false;
                SwingLegStyle = DashStyleHelper.Solid;
		        pUpSwingLineColor = Brushes.Black;
        		pDownSwingLineColor = Brushes.Black;
				pUpLabelColor = Brushes.Black;
				pDownLabelColor = Brushes.Black;
				pDoubleTopBottomColor = Brushes.Black;
                #endregion

                //rj RJ5GROUP code Algorithm
                #region Display Options Price Excursions 
                DisplayLevel1 = false;
                DisplayLevel2 = true;
                DisplayLevel3 = true;
                #endregion

				OptimizeSpeed = ARC_VMLean_OptimizeSpeedSettings.Max;
				OverprintSentimentBox = false;

                #region Plot Parameters 
                DotSizeMACD = 2;
                Plot2Width = 2;
                Plot3Width = 2;
                Plot4Width = 2;
                Dash3Style = DashStyleHelper.Dot;
                Dash4Style = DashStyleHelper.Solid;
                ZerolineWidth = 1;
                ZerolineStyle = DashStyleHelper.Solid;
                MomoWidth = 6;

                DeepBullishBackgroundColor = Brushes.DarkGreen;
                BullishBackgroundColor = Brushes.Green;
                OppositeBackgroundColor = Brushes.Gray;
                BearishBackgroundColor = Brushes.Red;
                DeepBearishBackgroundColor = Brushes.DarkRed;
                BackgroundOpacity = 30;//##DEFAULT VALUE TO CHECK##
                ChannelColor = Brushes.DodgerBlue;
                ChannelOpacity = 20;
                #endregion

                #region Plot Colors 
                DotsUpRisingColor = Brushes.Green;
                DotsDownRisingColor = Brushes.Green;
                DotsDownFallingColor = Brushes.Red;
                DotsUpFallingColor = Brushes.Red;
                DotsRimColor = Brushes.Black;
                BBAverageColor = Brushes.Transparent;
                BBUpperColor = Brushes.Black;
                BBLowerColor = Brushes.Black;
                HistUpColor = Brushes.LimeGreen;
                HistDownColor = Brushes.Maroon;
                ZerolineColor = Brushes.Black;
                ConnectorColor = Brushes.White;
                #endregion

                //rj RJ5GROUP code Algorithm
                #region Price Excursion: Plot Colors / Parameters 
                Level1Color = Brushes.WhiteSmoke;
                Level2Color = Brushes.Blue;
                Level3Color = Brushes.Red;
                PlotStyleLevels = PlotStyle.HLine;
                DashStyleHelperLevels = DashStyleHelper.Solid;
                PlotWidthLevels = 3;
                #endregion

                #region Sentiment Box: Colors 
                BearishAccelerationColor = Brushes.Red;
                BearishDivergenceColor = Brushes.Red;
                BearishForegroundColor = Brushes.Black;
                BullishAccelerationColor = Brushes.Lime;
                BullishDivergenceColor = Brushes.Lime;
                BullishForegroundColor = Brushes.Black;
                TextBoxOutlineColor = Brushes.MidnightBlue;
                TextColor = Brushes.White;
                DataTableColor = Brushes.MidnightBlue;
                #endregion

                #region Sentiment Box: Parameters 
				//JQ 11.26.2017
				// Bug 12782. The set right margin is causing the shifting of the SDV bar when the PP bar and the Divergence indicator
                // are all on the same chart. This could be a NT8 issue as it appears the BarMarginRight is only applied to the
				// primary bar (PP) rather than the secondary bar SDV). For now, I will disable the setrightmargin properties
				// until I have a chance to talk to NT about this issue.
				// --start--
//                SetRightSideMargin = true;
				// --end--
                DataFontSize = 12;
				SentimentBoxLocation = ARC_VMLean_SentimentBoxLocations.Right;
				#endregion

                #region Sentiment Box: Text Elements 
                BullAccString = "Bullish Acc";
                BullDivCString = "Bullish Div (C)";
                BullDivPString = "Bullish Div (P)";
                BullHDivCString = "Bullish HDiv (C)";
                BullHDivPString = "Bullish HDiv (P)";
                BearAccString = "Bearish Acc";
                BearDivCString = "Bearish Div (C)";
                BearDivPString = "Bearish Div (P)";
                BearHDivCString = "Bearish HDiv (C)";
                BearHDivPString = "Bearish HDiv (P)";
                NeutralString = "Neutral";
                UpBiasString = "Up Trend";//#STRBIAS
                DwBiasString = "Down Trend";//#STRBIAS
                NeutralBiasString = "Oscillation";//#STRBIAS     
                #endregion

                #endregion
			}
			#endregion

			#region State == State.Configure  
			else if (State == State.Configure)
			{
#if DoLicense
//				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
                #region INIT Fonts  
                labelFont = new SimpleFont("Arial", LabelFontSize);
                swingDotFont = new SimpleFont("Webdings", SwingDotSize) { Bold = true };
                dataFont1 = new SimpleFont("Arial", Math.Max(1, DataFontSize - 2)) { Bold = true };
                dataFont2 = new SimpleFont("Arial", DataFontSize) { Bold = true };

                //Get string size (H / W) for Sentiment BOX
                dataStringHeight = dataFont2.Size;

                maxString1 = "STRUCTURE BIAS" + 1;

                List<string> boxStrings = new List<string>() { NeutralString, BullAccString, BullDivCString, BullDivPString, BullHDivCString, BullHDivPString, BearAccString, BearDivCString, BearDivPString, BearHDivCString, BearHDivPString, UpBiasString, DwBiasString, NeutralBiasString };
                maxString2 = boxStrings.Aggregate("", (max, cur) => max.Length > cur.Length ? max : cur);
                maxString2 = maxString2 + 1;
                #endregion

                #region -- Set default to plots --
                Plots[BBMACDIDX].Width = DotSizeMACD;
                Plots[BBMACDIDX].DashStyleHelper = DashStyleHelper.Dot;
                Plots[BBMACDFrameIDX].Width = DotSizeMACD + 1;
                Plots[BBMACDFrameIDX].DashStyleHelper = DashStyleHelper.Dot;
                Plots[BBMACDLineIDX].Width = Plot2Width;
                Plots[AverageIDX].Width = Plot3Width;
                Plots[AverageIDX].DashStyleHelper = Dash3Style;
                Plots[UpperIDX].Width = Plot4Width;
                Plots[UpperIDX].DashStyleHelper = Dash4Style;
                Plots[LowerIDX].Width = Plot4Width;
                Plots[LowerIDX].DashStyleHelper = Dash4Style;
                Plots[HistogramIDX].Width = MomoWidth;
                Plots[HistogramIDX].DashStyleHelper = DashStyleHelper.Solid;

                //rj RJ5GROUP code Algorithm
                if (false)
                {
                    Plots[PriceExcursionUL3IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionUL3IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionUL3IDX].PlotStyle = PlotStyleLevels;
                    Plots[PriceExcursionUL2IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionUL2IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionUL2IDX].PlotStyle = PlotStyleLevels;
                    Plots[PriceExcursionUL1IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionUL1IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionUL1IDX].PlotStyle = PlotStyleLevels;
                    Plots[PriceExcursionLL1IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionLL1IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionLL1IDX].PlotStyle = PlotStyleLevels;
                    Plots[PriceExcursionLL2IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionLL2IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionLL2IDX].PlotStyle = PlotStyleLevels;
                    Plots[PriceExcursionLL3IDX].Width = PlotWidthLevels;
                    Plots[PriceExcursionLL3IDX].DashStyleHelper = DashStyleHelper.Solid;
                    Plots[PriceExcursionLL3IDX].PlotStyle = PlotStyleLevels;
                }
                //rj RJ5GROUP code Algorithm

                //Lines[0].Width = ZerolineWidth;
                //Lines[0].DashStyleHelper = ZerolineStyle;
                //Lines[0].Brush = ZerolineColor;

                Plots[BBMACDFrameIDX].Brush = DotsRimColor;
                Plots[BBMACDLineIDX].Brush = ConnectorColor;
                Plots[AverageIDX].Brush = BBAverageColor;
                Plots[UpperIDX].Brush = BBUpperColor;
                Plots[LowerIDX].Brush = BBLowerColor;

                //rj RJ5GROUP code Algorithm
                Plots[PriceExcursionUL3IDX].Brush = Brushes.Transparent;
                Plots[PriceExcursionUL2IDX].Brush = Brushes.Transparent;
                Plots[PriceExcursionUL1IDX].Brush = Brushes.Transparent;
                Plots[PriceExcursionLL1IDX].Brush = Brushes.Transparent;
                Plots[PriceExcursionLL2IDX].Brush = Brushes.Transparent;
                Plots[PriceExcursionLL3IDX].Brush = Brushes.Transparent;
                
                Plots[PriceExcursionMAXIDX].Brush = Level3Color;
                Plots[PriceExcursionMINIDX].Brush = Level3Color;
                //rj RJ5GROUP code Algorithm
                #endregion
            }
            #endregion

			#region -- DataLoaded --
			else if(State == State.DataLoaded){
				#region INIT Series  
				swingInput        = new Series<double>(this);
				pre_swingHighType = new Series<int>(this);
				pre_swingLowType  = new Series<int>(this);
				swingHighType     = new Series<int>(this);
				swingLowType      = new Series<int>(this);
				acceleration1     = new Series<int>(this);
				acceleration2     = new Series<int>(this);
				upTrend           = new Series<bool>(this);

				bbDotTrend = new Series<double>(this);

				structureBiasState = new Series<double>(this, MaximumBarsLookBack.Infinite);//#STRBIAS
				swingHighsState    = new Series<double>(this, MaximumBarsLookBack.Infinite);//#STRBIAS
				swingLowsState     = new Series<double>(this, MaximumBarsLookBack.Infinite);//#STRBIAS
				#endregion

				#region INIT external Series  
				BMACD = MACD(Input, Fast, Slow, BandPeriod);
				SDBB  = StdDev(BMACD, BandPeriod);
				MACD1 = MACD(8, 20, 20);
				MACD2 = MACD(10, 20, 20);
				MACD3 = MACD(20, 60, 20);
				MACD4 = MACD(60, 240, 20);
				avgTrueRange = ATR(256);
				ExcursionSeries = SMA(ATR(256), 65);//rj RJ5GROUP code Algorithm
				#endregion
			}
			#endregion

            #region State == State.Historical  
            else if (State == State.Historical)
            {
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;

                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new Grid { Visibility = Visibility.Collapsed };

                            addToolBar();

                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;
                            
                            foreach (TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion
            }
            #endregion

            #region State == State.Terminated
            else if (State == State.Terminated)
            {
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
						indytoolbar = null;
						try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
							indytoolbar = null;
							try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
							chartWindow = null;
						}));
					}
				}
            }
            #endregion
        }
//===============================================================================================================
        protected override void OnBarUpdate()
        {
int line=1411;
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
try{
line=1421;
            #region --- Calculate VelocityMomo ---  
            double macdValue = BMACD[0];
            double average = BMACD.Avg[0];
            double stdDevValue = SDBB[0];

            BBMACD[0] = macdValue;
            BBMACDLine[0] = macdValue;
            BBMACDFrame[0] = macdValue;//used for drawing only
            Average[0] = average;
            Upper[0] = average + StdDevNumber * stdDevValue;
            Lower[0] = average - StdDevNumber * stdDevValue;
            Histogram[0] = MACD1.Diff[0] + MACD2.Diff[0] + MACD3.Diff[0] + MACD4.Diff[0];
            #endregion
            #region -- Color BB + Histo plots --  
line = 2453;
            if (CurrentBars[0] > 0)
            {
                #region -- Histogram --
                if (Histogram[0] > 0)
                {
                    PlotBrushes[HistogramIDX][0] = HistUpColor;
                }
                else if (Histogram[0] < 0)
                {
                    PlotBrushes[HistogramIDX][0] = HistDownColor;
                }
                else
                {
                    PlotBrushes[HistogramIDX][0] = PlotBrushes[HistogramIDX][1];
                }
                #endregion
                #region -- MACD --
				bbDotTrend[0] = 0.0;
                if (IsRising(BBMACD))
                {
                    if (BBMACD[0] > Upper[0])
                    {
                        bbDotTrend[0] = 2.0;
                        PlotBrushes[BBMACDIDX][0] = DotsUpRisingColor;
                    }
                    else
                    {
                        bbDotTrend[0] = 1.0;
                        PlotBrushes[BBMACDIDX][0] = DotsDownRisingColor;
                    }
                }
                else if (IsFalling(BBMACD))
                {
                    if (BBMACD[0] < Lower[0])
                    {
                        bbDotTrend[0] = -2.0;
                        PlotBrushes[BBMACDIDX][0] = DotsDownFallingColor;
                    }
                    else
                    {
                        bbDotTrend[0] = -1.0;
                        PlotBrushes[BBMACDIDX][0] = DotsUpFallingColor;
                    }
                }
                else
                {
                    bbDotTrend[0] = bbDotTrend[1];
                    PlotBrushes[BBMACDIDX][0] = PlotBrushes[BBMACDIDX][1];
                }
                #endregion
            }
            #endregion

line=1502;
            //rj RJ5GROUP code Algorithm
            #region --- Calculate ExcursionValue ---  
            //Excursion Algorithm
            double ExcursionValue = ExcursionSeries[0];
            //Plots
            PriceExcursionUL1[0] = ExcursionValue;
            PriceExcursionLL1[0] = -ExcursionValue;
            PriceExcursionUL2[0] = ExcursionValue * 2;
            PriceExcursionLL2[0] = ExcursionValue * -2;
            PriceExcursionUL3[0] = ExcursionValue * 3;
            PriceExcursionLL3[0] = ExcursionValue * -3;
            if (CurrentBars[0] > 0) PriceExcursionMAX.Reset(1);
            PriceExcursionMAX[0] = ExcursionValue * 3;
            if (CurrentBars[0] > 0) PriceExcursionMIN.Reset(1);
            PriceExcursionMIN[0] = ExcursionValue * -3;

            #region -- Show/Hide Excursion levels --  
            if (IsFirstTickOfBar)
            {
                if (!DisplayLevel1)
                {
                    PlotBrushes[PriceExcursionUL1IDX][0] = Brushes.Transparent;
                    PlotBrushes[PriceExcursionLL1IDX][0] = Brushes.Transparent;
                }
                if (!DisplayLevel2)
                {
                    PlotBrushes[PriceExcursionUL2IDX][0] = Brushes.Transparent;
                    PlotBrushes[PriceExcursionLL2IDX][0] = Brushes.Transparent;
                }
                if (!DisplayLevel3)
                {
                    PlotBrushes[PriceExcursionUL3IDX][0] = Brushes.Transparent;
                    PlotBrushes[PriceExcursionLL3IDX][0] = Brushes.Transparent;
                }
            }
            #endregion
            
            #endregion

line=1546;
			if(pEnableSwingCalculation)
			{
				#region -- Swings calculation engine --
	            #region -- Init zigzag states --    
	            if (CurrentBars[0] < 2)
	            {
line=1552;
	                upTrend[0] = true;
	                pre_swingHighType[0] = 0;
	                pre_swingLowType[0] = 0;
	                swingHighType[0] = 0;
	                swingLowType[0] = 0;
	            }
	            #endregion

	            #region else if (Calculate == Calculate.OnBarClose)
	            else if (Calculate == Calculate.OnBarClose)
	            {
	line=1564;
	                bool useHL = ThisInputType == ARC_VMLean_InputType.High_Low;
	
	                zigzagDeviation = MultiplierMD * avgTrueRange[0];
	                swingMax = MAX(useHL ? High : Input, SwingStrength)[1];
	                swingMin = MIN(useHL ? Low : Input, SwingStrength)[1];
	
	                pre_swingHighType[0] = 0;
	                pre_swingLowType[0] = 0;
	                swingHighType[0] = 0;
	                swingLowType[0] = 0;
	
	                updateHigh = upTrend[1] && (useHL ? Highs[0][0] : swingInput[0]) > currentHigh;
	                updateLow = !upTrend[1] && (useHL ? Lows[0][0] : swingInput[0]) < currentLow;
	                addHigh = !upTrend[1] && !((useHL ? Lows[0][0] : swingInput[0]) < currentLow) && (useHL ? Highs[0][0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
	                addLow = upTrend[1] && !((useHL ? Highs[0][0] : swingInput[0]) > currentHigh) && (useHL ? Lows[0][0] : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);
	
	                upTrend[0] = upTrend[1];
	
	line=1583;
	                #region -- New High --
	                if (addHigh)
	                {
	                    upTrend[0] = true;
	                    int lookback = CurrentBars[0] - lastLowIdx;
	                    swingLowType[lookback] = pre_swingLowType[lookback];
	                    double newHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBars[0] - lastLowIdx; i++)
	                    {
	                        if ((useHL ? Highs[0][i] : swingInput[i]) > newHigh)
	                        {
	                            newHigh = (useHL ? Highs[0][i] : swingInput[i]);
	                            j = i;
	                        }
	                    }
	line=1600;
	                    currentHigh = newHigh;
	                    priorSwingHighIdx = lastHighIdx;
	                    lastHighIdx = CurrentBars[0] - j;
	                }
	                #endregion
	
	                #region -- uptrend --
	                else if (updateHigh)
	                {
	line=1610;
	                    upTrend[0] = true;
	                    if (ShowZigzagDots) RemoveDrawObject(string.Format("swingHighDot{0}", lastHighIdx));
	                    if (ShowZigzagLabels) RemoveDrawObject(string.Format("swingHighLabel{0}", lastHighIdx));
	                    if (ShowZigzagLegs) RemoveDrawObject(string.Format("swingLegUp{0}", lastHighIdx));
	                    pre_swingHighType[CurrentBars[0] - lastHighIdx] = 0;
	                    currentHigh = (useHL ? Highs[0][0] : swingInput[0]);
	                    lastHighIdx = CurrentBars[0];
	                }
	                #endregion
	
	                #region -- New Low --
	                else if (addLow)
	                {
	line=1624;
	                    upTrend[0] = false;
	                    int lookback = CurrentBars[0] - lastHighIdx;
	                    swingHighType[lookback] = pre_swingHighType[lookback];
	                    double newLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBars[0] - lastHighIdx; i++)
	                    {
	                        if ((useHL ? Lows[0][i] : swingInput[i]) < newLow)
	                        {
	                            newLow = (useHL ? Lows[0][i] : swingInput[i]);
	                            j = i;
	                        }
	                    }
	line=1638;
	                    currentLow = newLow;
	                    priorSwingLowIdx = lastLowIdx;
	                    lastLowIdx = CurrentBars[0] - j;
	                }
	                #endregion
	
	                #region -- dwtrend --
	                else if (updateLow)
	                {
	line=1648;
	                    upTrend[0] = false;
	                    if (ShowZigzagDots) RemoveDrawObject(string.Format("swingLowDot{0}", lastLowIdx));
	                    if (ShowZigzagLabels) RemoveDrawObject(string.Format("swingLowLabel{0}", lastLowIdx));
	                    if (ShowZigzagLegs) RemoveDrawObject(string.Format("swingLegDown{0}", lastLowIdx));
	                    pre_swingLowType[CurrentBars[0] - lastLowIdx] = 0;
	                    currentLow = (useHL ? Lows[0][0] : swingInput[0]);
	                    lastLowIdx = CurrentBars[0];
	                }
	                #endregion
	
	                #region re-init drawing states at each new bar before calculous
	                if (ShowZigzagDots)
	                {
	                    drawHigherHighDot = false;
	                    drawLowerHighDot = false;
	                    drawDoubleTopDot = false;
	                    drawLowerLowDot = false;
	                    drawHigherLowDot = false;
	                    drawDoubleBottomDot = false;
	                }
	
	                drawHigherHighLabel = false;
	                drawLowerHighLabel = false;
	                drawDoubleTopLabel = false;
	                drawLowerLowLabel = false;
	                drawHigherLowLabel = false;
	                drawDoubleBottomLabel = false;
	                
	                if (ShowZigzagLegs)
	                {
	                    drawSwingLegUp = false;
	                    drawSwingLegDown = false;
	                }
	                #endregion
	
	                #region -- UP || HH --
	                if (addHigh || updateHigh)
	                {
	line=1687;
	                    int priorHighCount = CurrentBars[0] - priorSwingHighIdx;
	                    int priorLowCount = CurrentBars[0] - priorSwingLowIdx;
	                    highCount = CurrentBars[0] - lastHighIdx;
	                    lowCount = CurrentBars[0] - lastLowIdx;
	
	                    double marginUp = (useHL ? Highs[0][priorHighCount] : swingInput[priorHighCount]) + MultiplierDTB * avgTrueRange[highCount];
	                    double marginDown = (useHL ? Highs[0][priorHighCount] : swingInput[priorHighCount]) - MultiplierDTB * avgTrueRange[highCount];
	
	line=1696;
	                    // new code goes here
	                    #region -- Calculate acceleration on BBMACD and Histo --
	                    if (currentHigh > Highs[0][priorHighCount] && (BBMACD[highCount] > 0 && BBMACD[0] > 0) && BBMACD[highCount] > BBMACD[priorHighCount])
	                        acceleration1[0] = 2;
	                    else if (currentHigh <= Highs[0][priorHighCount] && (BBMACD[highCount] > 0 && BBMACD[0] > 0) && acceleration1[lowCount] == 1)
	                        acceleration1[0] = 1;
	                    else if (currentHigh <= Highs[0][priorHighCount] && (BBMACD[highCount] < 0 && BBMACD[0] < 0) && acceleration1[lowCount] == -2)
	                        acceleration1[0] = -1;
	                    else
	                        acceleration1[0] = 0;
	                    if (currentHigh > Highs[0][priorHighCount] && Histogram[highCount] > 0 && Histogram[0] > 0 && Histogram[highCount] > Histogram[priorHighCount])
	                        acceleration2[0] = 2;
	                    else if (currentHigh <= Highs[0][priorHighCount] && Histogram[highCount] > 0 && Histogram[0] > 0 && acceleration2[lowCount] == 1)
	                        acceleration2[0] = 1;
	                    else if (currentHigh <= Highs[0][priorHighCount] && Histogram[highCount] < 0 && Histogram[0] < 0 && acceleration2[lowCount] == -2)
	                        acceleration2[0] = -1;
	                    else
	                        acceleration2[0] = 0;
	                    #endregion
	                    // end new code
	
	line=1718;
	                    #region -- Set NEW drawing states --
	                    if (ShowZigzagDots)
	                    {
	                        if (currentHigh > marginUp)
	                            drawHigherHighDot = true;
	                        else if (currentHigh < marginDown)
	                            drawLowerHighDot = true;
	                        else
	                            drawDoubleTopDot = true;
	                    }
	
	                    if (currentHigh > marginUp) drawHigherHighLabel = true;
	                    else if (currentHigh < marginDown) drawLowerHighLabel = true;
	                    else drawDoubleTopLabel = true;
	
	line=1734;
	                    if (ShowZigzagLegs)
	                        drawSwingLegUp = true;
	                    if (currentHigh > marginUp)
	                        pre_swingHighType[highCount] = 3;
	                    else if (currentHigh < marginDown)
	                        pre_swingHighType[highCount] = 1;
	                    else
	                        pre_swingHighType[highCount] = 2;
	                    #endregion
	                }
	                #endregion
	
	                #region -- DW || LL --
	                else if (addLow || updateLow)
	                {
	line=1750;
	                    int priorLowCount = CurrentBars[0] - priorSwingLowIdx;
	                    int priorHighCount = CurrentBars[0] - priorSwingHighIdx;
	                    lowCount = CurrentBars[0] - lastLowIdx;
	                    highCount = CurrentBars[0] - lastHighIdx;
	
	                    double marginDown = (useHL ? Lows[0][priorLowCount] : swingInput[priorLowCount]) - MultiplierDTB * avgTrueRange[lowCount];
	                    double marginUp = (useHL ? Lows[0][priorLowCount] : swingInput[priorLowCount]) + MultiplierDTB * avgTrueRange[lowCount];
	
	line=1759;
	                    // new code goes here
	                    #region -- Calculate acceleration on BBMACD and Histo --
	                    if (currentLow < Lows[0][priorLowCount] && (BBMACD[lowCount] < 0 && BBMACD[0] < 0) && BBMACD[lowCount] < BBMACD[priorLowCount])
	                        acceleration1[0] = -2;
	                    else if (currentLow >= Lows[0][priorLowCount] && (BBMACD[lowCount] < 0 && BBMACD[0] < 0) && acceleration1[highCount] == -1)
	                        acceleration1[0] = -1;
	                    else if (currentLow >= Lows[0][priorLowCount] && (BBMACD[lowCount] > 0 && BBMACD[0] > 0) && acceleration1[highCount] == 2)
	                        acceleration1[0] = 1;
	                    else
	                        acceleration1[0] = 0;
	                    if (currentLow < Lows[0][priorLowCount] && Histogram[lowCount] < 0 && Histogram[0] < 0 && Histogram[lowCount] < Histogram[priorLowCount])
	                        acceleration2[0] = -2;
	                    else if (currentLow >= Lows[0][priorLowCount] && Histogram[lowCount] < 0 && Histogram[0] < 0 && acceleration2[highCount] == -1)
	                        acceleration2[0] = -1;
	                    else if (currentLow >= Lows[0][priorLowCount] && Histogram[lowCount] > 0 && Histogram[0] > 0 && acceleration2[highCount] == 2)
	                        acceleration2[0] = 1;
	                    else
	                        acceleration2[0] = 0;
	                    #endregion
	                    // end new code
	
	line=1781;
	                    #region -- Set NEW drawing states --
	                    if (ShowZigzagDots)
	                    {
	                        if (currentLow < marginDown)
	                            drawLowerLowDot = true;
	                        else if (currentLow > marginUp)
	                            drawHigherLowDot = true;
	                        else
	                            drawDoubleBottomDot = true;
	                    }
	
	line=1793;
	                    if (currentLow < marginDown) drawLowerLowLabel = true;
	                    else if (currentLow > marginUp) drawHigherLowLabel = true;
	                    else drawDoubleBottomLabel = true;
	                    
	                    if (ShowZigzagLegs)
	                        drawSwingLegDown = true;
	                    if (currentLow < marginDown)
	                        pre_swingLowType[lowCount] = -3;
	                    else if (currentLow > marginUp)
	                        pre_swingLowType[lowCount] = -1;
	                    else
	                        pre_swingLowType[lowCount] = -2;
	                    #endregion
	                }
	                #endregion
	
	                //Is it possible ??
	                else
	                {
	line=1813;
	                    if ((acceleration1[1] > 0 && BBMACD[0] > 0) || (acceleration1[1] < 0 && BBMACD[0] < 0))
	                        acceleration1[0] = acceleration1[1];
	                    else
	                        acceleration1[0] = 0;
	                    if ((acceleration2[1] > 0 && Histogram[0] > 0) || (acceleration2[1] < 0 && Histogram[0] < 0))
	                        acceleration2[0] = acceleration2[1];
	                    else
	                        acceleration2[0] = 0;
	                }
	            }
	            #endregion
	
	            #region else if (IsFirstTickOfBar)
	            else if (IsFirstTickOfBar)
	            {
	line=1829;
	                bool useHL = ThisInputType == ARC_VMLean_InputType.High_Low;
	                zigzagDeviation = MultiplierMD * avgTrueRange[1];
	                swingMax = MAX(useHL ? High : Input, SwingStrength)[2];
	                swingMin = MIN(useHL ? Low : Input, SwingStrength)[2];
	
	                pre_swingHighType[0] = 0;
	                pre_swingLowType[0] = 0;
	                swingHighType[0] = 0;
	                swingLowType[0] = 0;
	
	                updateHigh = upTrend[1] && (useHL ? Highs[0][1] : swingInput[1]) > currentHigh;
	                updateLow = !upTrend[1] && (useHL ? Lows[0][1] : swingInput[1]) < currentLow;
	                addHigh = !upTrend[1] && !((useHL ? Lows[0][1] : swingInput[1]) < currentLow) && (useHL ? Highs[0][1] : swingInput[1]) > Math.Max(swingMax, currentLow + zigzagDeviation);
	                addLow = upTrend[1] && !((useHL ? Highs[0][1] : swingInput[1]) > currentHigh) && (useHL ? Lows[0][1] : swingInput[1]) < Math.Min(swingMin, currentHigh - zigzagDeviation);
	
	                upTrend[0] = upTrend[1];
	
	line=1847;
	                #region -- New High --
	                if (addHigh)
	                {
	                    upTrend[0] = true;
	                    int lookback = CurrentBars[0] - lastLowIdx;
	                    swingLowType[lookback] = pre_swingLowType[lookback];
	                    double newHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 1; i < CurrentBars[0] - lastLowIdx; i++)
	                    {
	                        if ((useHL ? Highs[0][i] : swingInput[i]) > newHigh)
	                        {
	                            newHigh = (useHL ? Highs[0][i] : swingInput[i]);
	                            j = i;
	                        }
	                    }
	                    currentHigh = newHigh;
	                    priorSwingHighIdx = lastHighIdx;
	                    lastHighIdx = CurrentBars[0] - j;
	                }
	                #endregion
	
	                #region -- UPtrend --
	                else if (updateHigh)
	                {
	line=1873;
	                    upTrend[0] = true;
	                    if (ShowZigzagDots)
	                        RemoveDrawObject(string.Format("swingHighDot{0}", lastHighIdx));
	                    if (ShowZigzagLabels)
	                        RemoveDrawObject(string.Format("swingHighLabel{0}", lastHighIdx));
	                    if (ShowZigzagLegs)
	                        RemoveDrawObject(string.Format("swingLegUp{0}", lastHighIdx));
	                    pre_swingHighType[CurrentBars[0] - lastHighIdx] = 0;
	                    currentHigh = (useHL ? Highs[0][1] : swingInput[1]);
	                    lastHighIdx = CurrentBars[0] - 1;
	                }
	                #endregion
	
	                #region -- New Low --
	                else if (addLow)
	                {
	line=1890;
	                    upTrend[0] = false;
	                    int lookback = CurrentBars[0] - lastHighIdx;
	                    swingHighType[lookback] = pre_swingHighType[lookback];
	                    double newLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 1; i < CurrentBars[0] - lastHighIdx; i++)
	                    {
	                        if ((useHL ? Lows[0][i] : swingInput[i]) < newLow)
	                        {
	                            newLow = (useHL ? Lows[0][i] : swingInput[i]);
	                            j = i;
	                        }
	                    }
	                    currentLow = newLow;
	                    priorSwingLowIdx = lastLowIdx;
	                    lastLowIdx = CurrentBars[0] - j;
	                }
	                #endregion
	
	                #region -- DWtrend --
	                else if (updateLow)
	                {
	line=1913;
	                    upTrend[0] = false;
	                    if (ShowZigzagDots)
	                        RemoveDrawObject(string.Format("swingLowDot{0}", lastLowIdx));
	                    if (ShowZigzagLabels)
	                        RemoveDrawObject(string.Format("swingLowLabel{0}", lastLowIdx));
	                    if (ShowZigzagLegs)
	                        RemoveDrawObject(string.Format("swingLegDown{0}", lastLowIdx));
	                    pre_swingLowType[CurrentBars[0] - lastLowIdx] = 0;
	                    currentLow = useHL ? Lows[0][1] : swingInput[1];
	                    lastLowIdx = CurrentBars[0] - 1;
	                }
	                #endregion
	
	                #region re-init drawing states at each new bar before calculous
	                if (ShowZigzagDots)
	                {
	                    drawHigherHighDot = false;
	                    drawLowerHighDot = false;
	                    drawDoubleTopDot = false;
	                    drawLowerLowDot = false;
	                    drawHigherLowDot = false;
	                    drawDoubleBottomDot = false;
	                }
	
	                drawHigherHighLabel = false;
	                drawLowerHighLabel = false;
	                drawDoubleTopLabel = false;
	                drawLowerLowLabel = false;
	                drawHigherLowLabel = false;
	                drawDoubleBottomLabel = false;
	
	                if (ShowZigzagLegs)
	                {
	                    drawSwingLegUp = false;
	                    drawSwingLegDown = false;
	                }
	                #endregion
	
	                #region -- UP || HH --
	                if (addHigh || updateHigh)
	                {
	line=1955;
	                    int priorHighCount = CurrentBars[0] - priorSwingHighIdx;
	                    highCount = CurrentBars[0] - lastHighIdx;
	                    lowCount = CurrentBars[0] - lastLowIdx;
	
	                    double marginUp = (useHL ? Highs[0][priorHighCount] : swingInput[priorHighCount]) + MultiplierDTB * avgTrueRange[highCount];
	                    double marginDown = (useHL ? Highs[0][priorHighCount] : swingInput[priorHighCount]) - MultiplierDTB * avgTrueRange[highCount];
	
	                    #region -- Set NEW drawing states --
	                    if (ShowZigzagDots)
	                    {
	                        if (currentHigh > marginUp)
	                            drawHigherHighDot = true;
	                        else if (currentHigh < marginDown)
	                            drawLowerHighDot = true;
	                        else
	                            drawDoubleTopDot = true;
	                    }
	
	line=1974;
	                    if (currentHigh > marginUp) drawHigherHighLabel = true;
	                    else if (currentHigh < marginDown) drawLowerHighLabel = true;
	                    else drawDoubleTopLabel = true;
	                    
	                    if (ShowZigzagLegs)
	                        drawSwingLegUp = true;
	                    if (currentHigh > marginUp)
	                        pre_swingHighType[highCount] = 3;
	                    else if (currentHigh < marginDown)
	                        pre_swingHighType[highCount] = 1;
	                    else
	                        pre_swingHighType[highCount] = 2;
	                    #endregion
	                }
	                #endregion
	
	                #region -- DW || LL --
	                else if (addLow || updateLow)
	                {
	line=1994;
	                    int priorLowCount = CurrentBars[0] - priorSwingLowIdx;
	                    lowCount = CurrentBars[0] - lastLowIdx;
	                    highCount = CurrentBars[0] - lastHighIdx;
	
	                    double marginDown = (useHL ? Lows[0][priorLowCount] : swingInput[priorLowCount]) - MultiplierDTB * avgTrueRange[lowCount];
	                    double marginUp = (useHL ? Lows[0][priorLowCount] : swingInput[priorLowCount]) + MultiplierDTB * avgTrueRange[lowCount];
	
	                    #region -- Set NEW drawing states --
	                    if (ShowZigzagDots)
	                    {
	                        if (currentLow < marginDown)
	                            drawLowerLowDot = true;
	                        else if (currentLow > marginUp)
	                            drawHigherLowDot = true;
	                        else
	                            drawDoubleBottomDot = true;
	                    }
	
	line=2013;
	                    if (currentLow < marginDown) drawLowerLowLabel = true;
	                    else if (currentLow > marginUp) drawHigherLowLabel = true;
	                    else drawDoubleBottomLabel = true;
	                    
	                    if (ShowZigzagLegs)
	                        drawSwingLegDown = true;
	                    if (currentLow < marginDown)
	                        pre_swingLowType[lowCount] = -3;
	                    else if (currentLow > marginUp)
	                        pre_swingLowType[lowCount] = -1;
	                    else
	                        pre_swingLowType[lowCount] = -2;
	                    #endregion
	                }
	                #endregion
	            }
	            #endregion
	line=2032;
	            #region if (Calculate != Calculate.OnBarClose)
	            if (Calculate != Calculate.OnBarClose)
	            {
	                bool useHL = ThisInputType == ARC_VMLean_InputType.High_Low;
	
	                intraBarUpdateHigh = upTrend[0] && (useHL ? Highs[0][0] : swingInput[0]) > currentHigh;
	                intraBarUpdateLow = !upTrend[0] && (useHL ? Lows[0][0] : swingInput[0]) < currentLow;
	                intraBarAddHigh = !upTrend[0] && !((useHL ? Lows[0][0] : swingInput[0]) < currentLow) && (useHL ? Highs[0][0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
	                intraBarAddLow = upTrend[0] && !((useHL ? Highs[0][0] : swingInput[0]) > currentHigh) && (useHL ? Lows[0][0] : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);
	
	line=2043;
	                #region -- new HH --
	                if (intraBarAddHigh)
	                {
	                    double newHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBars[0] - lastLowIdx; i++)
	                    {
	                        if ((useHL ? Highs[0][i] : swingInput[i]) > newHigh)
	                        {
	                            newHigh = (useHL ? Highs[0][i] : swingInput[i]);
	                            j = i;
	                        }
	                    }
	                    preCurrentHigh = newHigh;
	                    preLastHighIdx = CurrentBars[0] - j;
	                }
	                #endregion
	
	                #region -- uptrend --
	                else if (intraBarUpdateHigh)
	                {
	line=2065;
	                    preCurrentHigh = (useHL ? Highs[0][0] : swingInput[0]);
	                    preLastHighIdx = CurrentBars[0];
	                }
	                #endregion
	
	line=2071;
	                #region -- new LL --
	                if (intraBarAddLow)
	                {
	line=2075;
	                    double newLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBars[0] - lastHighIdx; i++)
	                    {
	                        if ((useHL ? Lows[0][i] : swingInput[i]) < newLow)
	                        {
	                            newLow = useHL ? Lows[0][i] : swingInput[i];
	                            j = i;
	                        }
	                    }
	                    preCurrentLow = newLow;
	                    preLastLowIdx = CurrentBars[0] - j;
	                }
	                #endregion
	
	                #region -- dwtrend --
	                else if (intraBarUpdateLow)
	                {
	line=2094;
	                    preCurrentLow = (useHL ? Lows[0][0] : swingInput[0]);
	                    preLastLowIdx = CurrentBars[0];
	                }
	                #endregion
	
	                #region -- UP || HH --
	                if (intraBarAddHigh || intraBarUpdateHigh)
	                {
	line=2103;
	                    int prePriorHighCount = intraBarAddHigh ? CurrentBars[0] - lastHighIdx : CurrentBars[0] - priorSwingHighIdx;
	                    int preHighCount = CurrentBars[0] - preLastHighIdx;
	                    //int prePriorLowCount = CurrentBars[0] - priorSwingLowIdx;
	                    int preLowCount = CurrentBars[0] - lastLowIdx;
	
	                    #region -- Calculate acceleration on BBMACD and Histo --
	                    if (preCurrentHigh > Highs[0][prePriorHighCount] && (BBMACD[preHighCount] > 0 && BBMACD[0] > 0) && BBMACD[preHighCount] > BBMACD[prePriorHighCount])
	                        acceleration1[0] = 2;
	                    else if (preCurrentHigh <= Highs[0][prePriorHighCount] && (BBMACD[preHighCount] > 0 && BBMACD[0] > 0) && acceleration1[preLowCount] == 1)
	                        acceleration1[0] = 1;
	                    else if (preCurrentHigh <= Highs[0][prePriorHighCount] && (BBMACD[preHighCount] < 0 && BBMACD[0] < 0) && acceleration1[preLowCount] == -2)
	                        acceleration1[0] = -1;
	                    else
	                        acceleration1[0] = 0;
	                    if (preCurrentHigh > Highs[0][prePriorHighCount] && Histogram[preHighCount] > 0 && Histogram[0] > 0 && Histogram[preHighCount] > Histogram[prePriorHighCount])
	                        acceleration2[0] = 2;
	                    else if (preCurrentHigh <= Highs[0][prePriorHighCount] && Histogram[preHighCount] > 0 && Histogram[0] > 0 && acceleration2[preLowCount] == 1)
	                        acceleration2[0] = 1;
	                    else if (preCurrentHigh <= Highs[0][prePriorHighCount] && Histogram[preHighCount] < 0 && Histogram[0] < 0 && acceleration2[preLowCount] == -2)
	                        acceleration2[0] = -1;
	                    else
	                        acceleration2[0] = 0;
	                    #endregion
	
	line=2128;
	                    #region ---- StructureBias RealTime ---
	                    double marginUp, marginDown;
	                    if (ThisInputType == ARC_VMLean_InputType.High_Low)
	                    {
	                        marginUp = Highs[0][prePriorHighCount] + MultiplierDTB * avgTrueRange[preHighCount];
	                        marginDown = Highs[0][prePriorHighCount] - MultiplierDTB * avgTrueRange[preHighCount];
	                    }
	                    else
	                    {
	                        marginUp = swingInput[prePriorHighCount] + MultiplierDTB * avgTrueRange[preHighCount];
	                        marginDown = swingInput[prePriorHighCount] - MultiplierDTB * avgTrueRange[preHighCount];
	                    }
	
	                    if (preCurrentHigh > marginUp) preSRType = 3;//#STRBIAS
	                    else if (preCurrentHigh < marginDown) preSRType = Math.Max(preSRType, 2);//#STRBIAS
	                    else preSRType = Math.Max(preSRType, 1);//#STRBIAS
	                    #endregion
	                }
	                #endregion
	
	                #region -- DW || LL --
	                else if (intraBarAddLow || intraBarUpdateLow)
	                {
	line=2152;
	                    int prePriorLowCount = intraBarAddLow ? CurrentBars[0] - lastLowIdx : CurrentBars[0] - priorSwingLowIdx;
	                    int preLowCount = CurrentBars[0] - preLastLowIdx;
	                    //int prePriorHighCount = CurrentBars[0] - priorSwingHighIdx;
	                    int preHighCount = CurrentBars[0] - lastHighIdx;
	
	                    #region -- Calculate acceleration on BBMACD and Histo --
	                    if (preCurrentLow < Lows[0][prePriorLowCount] && (BBMACD[preLowCount] < 0 && BBMACD[0] < 0) && BBMACD[preLowCount] < BBMACD[prePriorLowCount])
	                        acceleration1[0] = -2;
	                    else if (preCurrentLow >= Lows[0][prePriorLowCount] && (BBMACD[preLowCount] < 0 && BBMACD[0] < 0) && acceleration1[preHighCount] == -1)
	                        acceleration1[0] = -1;
	                    else if (preCurrentLow >= Lows[0][prePriorLowCount] && (BBMACD[preLowCount] > 0 && BBMACD[0] > 0) && acceleration1[preHighCount] == 2)
	                        acceleration1[0] = 1;
	                    else
	                        acceleration1[0] = 0;
	                    if (preCurrentLow < Lows[0][prePriorLowCount] && Histogram[preLowCount] < 0 && Histogram[0] < 0 && Histogram[preLowCount] < Histogram[prePriorLowCount])
	                        acceleration2[0] = -2;
	                    else if (preCurrentLow >= Lows[0][prePriorLowCount] && Histogram[preLowCount] < 0 && Histogram[0] < 0 && acceleration2[preHighCount] == -1)
	                        acceleration2[0] = -1;
	                    else if (preCurrentLow >= Lows[0][prePriorLowCount] && Histogram[preLowCount] > 0 && Histogram[0] > 0 && acceleration2[preHighCount] == 2)
	                        acceleration2[0] = 1;
	                    else
	                        acceleration2[0] = 0;
	                    #endregion
	
	line=2177;
	                    #region ---- StructureBias RealTime ---
	                    double marginUp, marginDown;
	                    if (ThisInputType == ARC_VMLean_InputType.High_Low)
	                    {
	                        marginDown = Lows[0][prePriorLowCount] - MultiplierDTB * avgTrueRange[preLowCount];
	                        marginUp = Lows[0][prePriorLowCount] + MultiplierDTB * avgTrueRange[preLowCount];
	                    }
	                    else
	                    {
	                        marginDown = swingInput[prePriorLowCount] - MultiplierDTB * avgTrueRange[preLowCount];
	                        marginUp = swingInput[prePriorLowCount] + MultiplierDTB * avgTrueRange[preLowCount];
	                    }
	                    if (preCurrentLow < marginDown) preSRType = -3;//#STRBIAS
	                    else if (preCurrentLow > marginUp) preSRType = Math.Min(preSRType, -2);//#STRBIAS
	                    else preSRType = Math.Min(preSRType, -1);//#STRBIAS
	                    #endregion
	                }
	                #endregion
	
	                //Is it possible ??
	                else
	                {
	line=2200;
	                    if ((acceleration1[1] > 0 && BBMACD[0] > 0) || (acceleration1[1] < 0 && BBMACD[0] < 0))
	                        acceleration1[0] = acceleration1[1];
	                    else
	                        acceleration1[0] = 0;
	                    if ((acceleration2[1] > 0 && Histogram[0] > 0) || (acceleration2[1] < 0 && Histogram[0] < 0))
	                        acceleration2[0] = acceleration2[1];
	                    else
	                        acceleration2[0] = 0;
	
	                    preSRType = 0;//#STRBIAS
	                }
	
	                #region ---- StructureBias RealTime ---
	                if (CurrentBars[0] < 2) 
						structureBiasState[0] = 0;
	                else
	                {
	line=2218;
	                    if (preSRType == 0) structureBiasState[0] = structureBiasState[1];
	
	                    #region -- Oscillation State --
	                    else if (structureBiasState[1] == 0)
	                    {
	                        //Oscillation State
	                        //Need HH/!LL/HH to go to Up Trend
	                        //{NEW} !LL/High/!LL/HH to go to Up Trend
	                        //Need LL/!HH/LL to go to Dw Trend
	                        //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
	                        if (sequence.Count < 2) structureBiasState[0] = 0;
	                        else if (sequence.Count < 3)
	                        {
	line=2232;
	                            if (sequence[0] == 3 && sequence[1] != -3 && preSRType == 3) structureBiasState[0] = 1;
	                            else if (sequence[0] == -3 && sequence[1] != 3 && preSRType == -3) structureBiasState[0] = -1;
	                            else structureBiasState[0] = 0;
	                        }
	                        else
	                        {
	line=2239;
	                            if (sequence[1] == 3 && sequence[2] != -3 && preSRType == 3) structureBiasState[0] = 1;
	                            else if (sequence[1] == -3 && sequence[2] != 3 && preSRType == -3) structureBiasState[0] = -1;
	                            //{NEW} HL/LH/HL/HH to go to Up Trend
	                            else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && preSRType == 3) structureBiasState[0] = 1;
	                            //{NEW} LH/HL/LH/LL to go to Up Trend
	                            else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && preSRType == -3) structureBiasState[0] = -1;
	                            else structureBiasState[0] = 0;
	                        }
	                    }
	                    #endregion
	
	                    #region -- UpTrend State --
	                    else if (structureBiasState[1] > 0)
	                    {
	line=2254;
	                        //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
	                        if (preSRType == -3) structureBiasState[0] = 0;
	                        else structureBiasState[0] = 1;
	                    }
	                    #endregion
	
	                    #region -- DwTrend State --
	                    else if (structureBiasState[1] < 0)
	                    {
	line=2264;
	                        //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
	                        if (preSRType == 3) structureBiasState[0] = 0;
	                        else structureBiasState[0] = -1;
	                    }
	                    #endregion
	
	                    else structureBiasState[0] = structureBiasState[1];
	                }
	                #endregion
	            }
	            #endregion
	
				int cutoffIdx = int.MinValue;
				int cb = CurrentBars[0];
				if(State==State.Historical) cb = Bars.Count;
				if(OptimizeSpeed == ARC_VMLean_OptimizeSpeedSettings.Min) cutoffIdx = cb-500;
				else if(OptimizeSpeed == ARC_VMLean_OptimizeSpeedSettings.Max) cutoffIdx = cb-100;
				bool PrintMarkers = CurrentBars[0]>cutoffIdx;
	
	line=2284;
	            if (Calculate == Calculate.OnBarClose || IsFirstTickOfBar)
	            {
	                DrawOnPricePanel = true;
	                #region -- Draw zigzag --    
	                if (PrintMarkers && ShowZigzagDots && ThisInputType == ARC_VMLean_InputType.High_Low)
	                {
	line=2291;
						if(IsFirstTickOfBar && cutoffIdx>0){
							RemoveDrawObject(string.Format("swingHighDot{0}",cutoffIdx));
							RemoveDrawObject(string.Format("swingLowDot{0}",cutoffIdx));
						}
	                    if (drawHigherHighDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, Highs[0][highCount], SwingDotSize / 2, pUpSwingLineColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawLowerHighDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, Highs[0][highCount], SwingDotSize / 2, pDownSwingLineColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawDoubleTopDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, Highs[0][highCount], SwingDotSize / 2, pDoubleTopBottomColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    if (drawLowerLowDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, Lows[0][lowCount], SwingDotSize / 2, pDownSwingLineColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawHigherLowDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, Lows[0][lowCount], SwingDotSize / 2, pUpSwingLineColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawDoubleBottomDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, Lows[0][lowCount], SwingDotSize / 2, pDoubleTopBottomColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                }
	                else if (PrintMarkers && ShowZigzagDots)
	                {
	line=2311;
						if(IsFirstTickOfBar && cutoffIdx>0){
							RemoveDrawObject(string.Format("swingHighDot{0}",cutoffIdx));
							RemoveDrawObject(string.Format("swingLowDot{0}",cutoffIdx));
						}
	                    if (drawHigherHighDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, swingInput[highCount], SwingDotSize / 2, pUpSwingLineColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawLowerHighDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, swingInput[highCount], SwingDotSize / 2, pDownSwingLineColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawDoubleTopDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingHighDot{0}", lastHighIdx), true, dotString, highCount, swingInput[highCount], SwingDotSize / 2, pUpSwingLineColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    if (drawLowerLowDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, swingInput[lowCount], SwingDotSize / 2, pDownSwingLineColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawHigherLowDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, swingInput[lowCount], SwingDotSize / 2, pUpSwingLineColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawDoubleBottomDot)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingLowDot{0}", lastLowIdx), true, dotString, lowCount, swingInput[lowCount], SwingDotSize / 2, pDownSwingLineColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                }
	                if (PrintMarkers && ShowZigzagLabels)
	                {
	line=2331;
						if(IsFirstTickOfBar && cutoffIdx>0){
							RemoveDrawObject(string.Format("swingHighLabel{0}",cutoffIdx));
							RemoveDrawObject(string.Format("swingLowLabel{0}",cutoffIdx));
						}
	                    if (drawHigherHighLabel)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingHighLabel{0}", lastHighIdx), true, "HH", highCount, Highs[0][highCount], (int)(labelFont.Size) + pixelOffset1, pUpLabelColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawLowerHighLabel)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingHighLabel{0}", lastHighIdx), true, "LH", highCount, Highs[0][highCount], (int)(labelFont.Size) + pixelOffset1, pDownLabelColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawDoubleTopLabel)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingHighLabel{0}", lastHighIdx), true, "DT", highCount, Highs[0][highCount], (int)(labelFont.Size) + pixelOffset1, pDoubleTopBottomColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    if (drawLowerLowLabel)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingLowLabel{0}", lastLowIdx), true, "LL", lowCount, Lows[0][lowCount], -(int)(labelFont.Size) - pixelOffset2, pDownLabelColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawHigherLowLabel)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingLowLabel{0}", lastLowIdx), true, "HL", lowCount, Lows[0][lowCount], -(int)(labelFont.Size) - pixelOffset2, pUpLabelColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                    else if (drawDoubleBottomLabel)
	                        TriggerCustomEvent(o1 =>{ Draw.Text(this, string.Format("swingLowLabel{0}", lastLowIdx), true, "DB", lowCount, Lows[0][lowCount], -(int)(labelFont.Size) - pixelOffset2, pDoubleTopBottomColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);},0,null);
	                }
	                if (PrintMarkers && ShowZigzagLegs && ThisInputType == ARC_VMLean_InputType.High_Low)
	                {
	line=2351;
						if(IsFirstTickOfBar && cutoffIdx>0){
							RemoveDrawObject(string.Format("swingLegUp{0}",cutoffIdx));
							RemoveDrawObject(string.Format("swingLegDown{0}",cutoffIdx));
						}
	                    if (drawSwingLegUp)
		                    TriggerCustomEvent(o1 =>{ Draw.Line(this, string.Format("swingLegUp{0}", lastHighIdx), false, lowCount, Lows[0][lowCount], highCount, Highs[0][highCount], pUpSwingLineColor, SwingLegStyle, SwingLegWidth);},0,null);
	    	            if (drawSwingLegDown)
	        	            TriggerCustomEvent(o1 =>{ Draw.Line(this, string.Format("swingLegDown{0}", lastLowIdx), false, highCount, Highs[0][highCount], lowCount, Lows[0][lowCount], pDownSwingLineColor, SwingLegStyle, SwingLegWidth);},0,null);
	                }
	                else if (PrintMarkers && ShowZigzagLegs)
	                {
	line=2365;
						if(IsFirstTickOfBar && cutoffIdx>0){
							RemoveDrawObject(string.Format("swingLegUp{0}",cutoffIdx));
							RemoveDrawObject(string.Format("swingLegDown{0}",cutoffIdx));
						}
	                    if (drawSwingLegUp)
		                    TriggerCustomEvent(o1 =>{ Draw.Line(this, string.Format("swingLegUp{0}", lastHighIdx), false, lowCount, swingInput[lowCount], highCount, swingInput[highCount], pUpSwingLineColor, SwingLegStyle, SwingLegWidth);},0,null);
	    	            if (drawSwingLegDown)
	        	            TriggerCustomEvent(o1 =>{ Draw.Line(this, string.Format("swingLegDown{0}", lastLowIdx), false, highCount, swingInput[highCount], lowCount, swingInput[lowCount], pDownSwingLineColor, SwingLegStyle, SwingLegWidth);	},0,null);
	                }
	                #endregion
	            }
				#endregion  -------------------
			}

            #region --- init before having enough bars --- 
            if (CurrentBars[0] < BarsRequiredToPlot + 55)
            {
line=2385;
                structureBiasState[0] = 0;//#STRBIAS
                SRType = 0;//#STRBIAS
                swingHighsState[0] = 0;//#STRBIAS
                swingLowsState[0] = 0;//#STRBIAS
                return;
            }
            #endregion

            #region -- Structure BIAS --
line = 2341;
			if(pEnableSwingCalculation){
	            SRType = drawHigherHighLabel ? 3 : drawLowerHighLabel ? 2 : drawDoubleTopLabel ? 1 : drawDoubleBottomLabel ? -1 : drawHigherLowLabel ? -2 : drawLowerLowLabel ? -3 : 0;
    	        swingHighsState[0] = drawHigherHighLabel ? 3 : drawLowerHighLabel ? 2 : drawDoubleTopLabel ? 1 : 0;//#SWINGS for BH
        	    swingLowsState[0] = drawDoubleBottomLabel ? -1 : drawHigherLowLabel ? -2 : drawLowerLowLabel ? -3 : 0;//#SWINGS for BH	

line = 2346;
	            #region -- Oscillation State --
	            int decay = 0;
	            if (Calculate!= Calculate.OnBarClose && State!=State.Historical) decay = 1;
	            if (SRType != 0 && structureBiasState[decay + 1] == 0)
	            {
	                #region -- update sequence ---
	                //--- Same Trend --
	                if (upTrend[1] == upTrend[0])
	                {
	                    if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }

	                //--- Changing Trend ---
	                else if (Calculate == Calculate.OnBarClose && upTrend[1] != upTrend[0])
	                {
	                    if (sequence.Count < 4) sequence.Add(SRType);
	                    else
	                    {
	                        sequence[0] = sequence[1];
	                        sequence[1] = sequence[2];
	                        sequence[2] = sequence[3];
	                        sequence[3] = SRType;
	                    }
	                }
	                #region -- eachtick --
	                else if (Calculate != Calculate.OnBarClose && upTrend[1] != upTrend[0])
	                {
	                    if (IsFirstTickOfBar)
	                    {
	                        if (sequence.Count < 4) sequence.Add(SRType);
	                        else
	                        {
	                            sequence[0] = sequence[1];
	                            sequence[1] = sequence[2];
	                            sequence[2] = sequence[3];
	                            sequence[3] = SRType;
	                        }
	                    }
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                #endregion
             	   #endregion

	                //Oscillation State
	                //Need HH/!LL/HH to go to Up Trend
	                //{NEW} !LL/High/!LL/HH to go to Up Trend
	                //Need LL/!HH/LL to go to Dw Trend
	                //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
	                if (sequence.Count < 3) structureBiasState[decay] = 0;
	                else if (sequence.Count < 4)
	                {
	                    if (sequence[0] == 3 && sequence[1] != -3 && sequence[2] == 3) structureBiasState[decay] = 1;
	                    else if (sequence[0] == -3 && sequence[1] != 3 && sequence[2] == -3) structureBiasState[decay] = -1;
	                    else structureBiasState[decay] = 0;
	                }
	                else
	                {
	                    if (sequence[1] == 3 && sequence[2] != -3 && sequence[3] == 3) structureBiasState[decay] = 1;
	                    else if (sequence[1] == -3 && sequence[2] != 3 && sequence[3] == -3) structureBiasState[decay] = -1;
	                    //{NEW} HL/LH/HL/HH to go to Up Trend
	                    else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && sequence[3] == 3) structureBiasState[decay] = 1;
	                    //{NEW} LH/HL/LH/LL to go to Up Trend
	                    else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && sequence[3] == -3) structureBiasState[decay] = -1;
	                    else structureBiasState[decay] = 0;
	                }
	            }
	            #endregion

	            #region -- UpTrend State --
	            else if (SRType != 0 && structureBiasState[decay + 1] > 0)
	            {
line = 2420;
	                if (IsFirstTickOfBar) sequence.Clear();
	                //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
	                if (SRType == -3)
	                {
	                    structureBiasState[decay] = 0;
	                    if (IsFirstTickOfBar) sequence.Add(SRType);
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                else structureBiasState[decay] = 1;
	            }
	            #endregion

	            #region -- DwTrend State --
	            else if (SRType != 0 && structureBiasState[decay + 1] < 0)
	            {
line = 2437;
	                if (IsFirstTickOfBar) sequence.Clear();
	                //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
	                if (SRType == 3)
	                {
	                    structureBiasState[decay] = 0;
	                    if (IsFirstTickOfBar) sequence.Add(SRType);
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                else structureBiasState[decay] = -1;
	            }
	            #endregion

	            else structureBiasState[decay] = structureBiasState[decay + 1];
			}
            #endregion

}catch(Exception e){Print(line+": "+e.ToString());}
        }
		public override void OnRenderTargetChanged()
		{
			#region -- OnRenderTargetChanged --
			if(BullishBkgDXBrush!=null && !BullishBkgDXBrush.IsDisposed) {BullishBkgDXBrush.Dispose(); BullishBkgDXBrush=null;}
			if(RenderTarget!=null){
				BullishBkgDXBrush         = BullishBackgroundColor.ToDxBrush(RenderTarget);
				BullishBkgDXBrush.Opacity = BackgroundOpacity/100f;
			}

			if(BearishBkgDXBrush!=null && !BearishBkgDXBrush.IsDisposed) {BearishBkgDXBrush.Dispose(); BearishBkgDXBrush=null;}
			if(RenderTarget!=null){
				BearishBkgDXBrush         = BearishBackgroundColor.ToDxBrush(RenderTarget);
				BearishBkgDXBrush.Opacity = BackgroundOpacity/100f;
			}
			if(DeepBullishBkgDXBrush!=null && !DeepBullishBkgDXBrush.IsDisposed) {DeepBullishBkgDXBrush.Dispose(); DeepBullishBkgDXBrush=null;}
			if(RenderTarget!=null){
				DeepBullishBkgDXBrush         = DeepBullishBackgroundColor.ToDxBrush(RenderTarget);
				DeepBullishBkgDXBrush.Opacity = BackgroundOpacity/100f;
			}
			if(DeepBearishBkgDXBrush!=null && !DeepBearishBkgDXBrush.IsDisposed) {DeepBearishBkgDXBrush.Dispose(); DeepBearishBkgDXBrush=null;}
			if(RenderTarget!=null){
				DeepBearishBkgDXBrush         = DeepBearishBackgroundColor.ToDxBrush(RenderTarget);
				DeepBearishBkgDXBrush.Opacity = BackgroundOpacity/100f;
			}
			if(OppositeBkgDXBrush!=null && !OppositeBkgDXBrush.IsDisposed) {OppositeBkgDXBrush.Dispose(); OppositeBkgDXBrush=null;}
			if(RenderTarget!=null){
				OppositeBkgDXBrush         = OppositeBackgroundColor.ToDxBrush(RenderTarget);
				OppositeBkgDXBrush.Opacity = BackgroundOpacity/100f;
			}
			if(ChannelBkgDXBrush!=null && !ChannelBkgDXBrush.IsDisposed) {ChannelBkgDXBrush.Dispose(); ChannelBkgDXBrush=null;}
			if(RenderTarget!=null){
				ChannelBkgDXBrush = ChannelColor.ToDxBrush(RenderTarget);
	            ChannelBkgDXBrush.Opacity = ChannelOpacity / 100f;
			}
//			if(aa!=null && !aa.IsDisposed) {aa.Dispose(); aa=null;}
			if(ShowBiasInBox){
				if(DataTableDXBrush!=null && !DataTableDXBrush.IsDisposed) {DataTableDXBrush.Dispose(); DataTableDXBrush=null;}
				if(RenderTarget!=null){
					DataTableDXBrush = DataTableColor.ToDxBrush(RenderTarget);
				}
				if(BullishDivergenceDXBrush!=null && !BullishDivergenceDXBrush.IsDisposed) {BullishDivergenceDXBrush.Dispose(); BullishDivergenceDXBrush=null;}
				if(RenderTarget!=null){
					BullishDivergenceDXBrush = BullishDivergenceColor.ToDxBrush(RenderTarget);
				}
				if(BearishDivergenceDXBrush!=null && !BearishDivergenceDXBrush.IsDisposed) {BearishDivergenceDXBrush.Dispose(); BearishDivergenceDXBrush=null;}
				if(RenderTarget!=null){
					BearishDivergenceDXBrush = BearishDivergenceColor.ToDxBrush(RenderTarget);
				}
			}
			#endregion
		}
//===================================================================================================================
        #region -- OnRender : Custom Drawing --  
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            int lastBarIndex = Math.Min(CurrentBars[0], ChartBars.ToIndex);//RIGHT BAR idx (absolute)
            if (lastBarIndex < BarsRequiredToPlot) return;

            int firstBarIndex = Math.Max(BarsRequiredToPlot, ChartBars.FromIndex);//LEFT BAR idx (absolute)

            SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

            #region -- Zero Line --
            drawLine(0, 0, lastBarIndex, firstBarIndex, ZerolineColor, ZerolineStyle, ZerolineWidth, chartControl, chartScale);            
            #endregion

			#region -- Draw Channel + Div on indicator panel + flooding on momo panel --
            bool drawbbchannel = CurrentBars[0] > BarsRequiredToPlot && ChannelOpacity > 0;
            int divergenceSpan = 0;
//	Print("7953  Background flooding: "+BackgroundFlooding.ToString());

            for (int i = lastBarIndex; i >= firstBarIndex; i--)
            {
                try
                {
                    #region -- draw Bollinger Channel --
                    if (drawbbchannel){
//						int x = chartControl.GetXByBarIndex(chartControl.BarsArray[0], i);
//						int y = chartScale.GetYByValue(-3);
//						RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x,y),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
//						var y0 = chartScale.GetYByValue(Upper.GetValueAt(i));
//						var y1 = chartScale.GetYByValue(Upper.GetValueAt(i - 1));
//						var y2 = chartScale.GetYByValue(Lower.GetValueAt(i - 1));
//						var y3 = chartScale.GetYByValue(Lower.GetValueAt(i));
//						var x0 = chartControl.GetXByBarIndex(chartControl.BarsArray[0], i);
//						var x1 = chartControl.GetXByBarIndex(chartControl.BarsArray[0], i - 1);
//if(i==lastBarIndex) {
//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x0,y0),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x1,y1),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x1,y2),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x0,y3),5,5),Brushes.Yellow.ToDxBrush(RenderTarget));
//}
                        drawRegion(
							new double[] { Upper.GetValueAt(i), Upper.GetValueAt(i-1), Lower.GetValueAt(i-1), Lower.GetValueAt(i) }, 
							new int[] { i, i-1, i-1, i }, 
							ChannelBkgDXBrush, chartControl, chartScale);//25.05.16 - beta11 code breaking change
					}
                    #endregion

                    //##MODIF## AzurITec - 18.05.2016
                    #region -- flooding on momo panel only --
                    if (BackgroundFlooding != ARC_VMLean_Flooding.None)
                    {
                        int[] indexes = new int[] { i, i + 1, i + 1, i };
                        double[] minmax = new double[] { chartScale.MaxValue, chartScale.MaxValue, chartScale.MinValue, chartScale.MinValue };
                        if (BackgroundFlooding == ARC_VMLean_Flooding.Histogram)
                        {
                            if (Histogram.GetValueAt(i) > 0)
                                drawRegion(minmax, indexes, BullishBkgDXBrush, chartControl, chartScale, false, true);
                            else if (Histogram.GetValueAt(i) < 0)
                                drawRegion(minmax, indexes, BearishBkgDXBrush, chartControl, chartScale, false, true);
                            else if (Histogram.GetValueAt(i + 1) > 0)
                                drawRegion(minmax, indexes, BullishBkgDXBrush, chartControl, chartScale, false, true);
                            else
                                drawRegion(minmax, indexes, BearishBkgDXBrush, chartControl, chartScale, false, true);
                        }
                        else if (BackgroundFlooding == ARC_VMLean_Flooding.Structure)
                        {
                            if (structureBiasState.GetValueAt(i) > 0)
                                drawRegion(minmax, indexes, BullishBkgDXBrush, chartControl, chartScale, false, true);
                            else if (structureBiasState.GetValueAt(i) < 0)
                                drawRegion(minmax, indexes, BearishBkgDXBrush, chartControl, chartScale, false, true);
                        }
                        else
                        {
                            if (structureBiasState.GetValueAt(i) > 0)
                            {
                                if (Histogram.GetValueAt(i) > 0)
                                    drawRegion(minmax, indexes, DeepBullishBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i) < 0)
                                    drawRegion(minmax, indexes, OppositeBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i + 1) > 0)
                                    drawRegion(minmax, indexes, DeepBullishBkgDXBrush, chartControl, chartScale, false, true);
                                else
                                    drawRegion(minmax, indexes, OppositeBkgDXBrush, chartControl, chartScale, false, true);
                            }
                            else if (structureBiasState.GetValueAt(i) < 0)
                            {
                                if (Histogram.GetValueAt(i) > 0)
                                    drawRegion(minmax, indexes, OppositeBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i) < 0)
                                    drawRegion(minmax, indexes, DeepBearishBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i + 1) > 0)
                                    drawRegion(minmax, indexes, OppositeBkgDXBrush, chartControl, chartScale, false, true);
                                else
                                    drawRegion(minmax, indexes, DeepBearishBkgDXBrush, chartControl, chartScale, false, true);
                            }
                            else
                            {
                                if (Histogram.GetValueAt(i) > 0)
                                    drawRegion(minmax, indexes, BullishBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i) < 0)
                                    drawRegion(minmax, indexes, BearishBkgDXBrush, chartControl, chartScale, false, true);
                                else if (Histogram.GetValueAt(i + 1) > 0)
                                    drawRegion(minmax, indexes, BullishBkgDXBrush, chartControl, chartScale, false, true);
                                else
                                    drawRegion(minmax, indexes, BearishBkgDXBrush, chartControl, chartScale, false, true);
                            }
                        }
                    }
                    #endregion

                }
                catch (Exception) { }//After testing, didn't find any problem. Let Try Catch to avoid crashes...
            }
            #endregion

            #region -- excursion levels --
            try
            {
                int idxMin = lastBarIndex;
                int idxMax = firstBarIndex;
                int x1;

                int idxHLineStart = idxMax;
                if (PlotStyleLevels == PlotStyle.HLine) idxMax = idxMin;

                for (int i = idxMin; i >= idxMax; i--)
                {
                    x1 = PlotStyleLevels == PlotStyle.HLine ? idxHLineStart : i - 1;
                    #region -- Excursion Levels --
                    if (DisplayLevel3)
                    {   
                        drawLine(PriceExcursionUL3.GetValueAt(i), PriceExcursionUL3.GetValueAt(i - 1), i, x1, Level3Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                        drawLine(PriceExcursionLL3.GetValueAt(i), PriceExcursionLL3.GetValueAt(i - 1), i, x1, Level3Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                    }
                    if (DisplayLevel2)
                    {
                        drawLine(PriceExcursionUL2.GetValueAt(i), PriceExcursionUL2.GetValueAt(i - 1), i, x1, Level2Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                        drawLine(PriceExcursionLL2.GetValueAt(i), PriceExcursionLL2.GetValueAt(i - 1), i, x1, Level2Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                    }
                    if (DisplayLevel1)
                    {
                        drawLine(PriceExcursionUL1.GetValueAt(i), PriceExcursionUL1.GetValueAt(i - 1), i, x1, Level1Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                        drawLine(PriceExcursionLL1.GetValueAt(i), PriceExcursionLL1.GetValueAt(i - 1), i, x1, Level1Color, DashStyleHelper.Solid, PlotWidthLevels, chartControl, chartScale);
                    }
                    #endregion
                }
            }
            catch (Exception) { }//thrown if scrollback to chart first bar
            #endregion

			if(OverprintSentimentBox) base.OnRender(chartControl, chartScale);
            #region -- Draw the Sentiment Box --
            if (pEnableSwingCalculation && ShowBiasInBox && SentimentBoxLocation != ARC_VMLean_SentimentBoxLocations.Hide)
            {
                float maxStringWidth1 = getTextWidth(maxString1, dataFont1);
                float maxStringWidth2 = getTextWidth(maxString2, dataFont2);
                float maxStringWidth = Math.Max(maxStringWidth1, maxStringWidth2);

                float offset1 = ChartPanel.X + ChartPanel.W - 1.2f * maxStringWidth;
				if(SentimentBoxLocation == ARC_VMLean_SentimentBoxLocations.Left){
					offset1 = ChartPanel.X+10f;
				}
                float offset2 = offset1 + 0.03f * maxStringWidth;
                float offset3 = offset1 + 0.08f * maxStringWidth;
                float offset6 = offset1 + 1.17f * maxStringWidth;
                float pos11 = ChartPanel.Y + 0.01f * ChartPanel.H;
                float pos12 = ChartPanel.Y + 0.97f * ChartPanel.H;
                float midPoint = ChartPanel.Y + 0.49f * ChartPanel.H;
                float pos1, pos1f, pos2, pos2f, pos3, pos3f, pos4, pos4f, pos5, pos6, pos6f;

                pos1  = pos2 = pos2f = pos3 = pos4 = pos4f = 0;
                pos5  = midPoint - 1.3f * (float)dataStringHeight;
                pos6f = midPoint - 0f * (float)dataStringHeight;
                pos6  = midPoint + 0.2f * (float)dataStringHeight;
                
                drawRectangle(offset2, pos11, 1.14f * maxStringWidth, 0.99f * ChartPanel.H - 3, DataTableDXBrush);
                drawLine((double)offset2, (double)offset6, (double)pos11, (double)pos11, TextBoxOutlineColor, DashStyleHelper.Solid, 1);
                drawLine((double)offset2, (double)offset6, (double)pos12, (double)pos12, TextBoxOutlineColor, DashStyleHelper.Solid, 1);
                drawLine((double)offset2, (double)offset2, (double)pos11, (double)pos12, TextBoxOutlineColor, DashStyleHelper.Solid, 1);
                drawLine((double)offset6, (double)offset6, (double)pos11, (double)pos12, TextBoxOutlineColor, DashStyleHelper.Solid, 1);

                filterValue3 = structureBiasState.GetValueAt(lastBarIndex);

                if (ShowBiasInBox)
                {
                    #region -- BIAS State --
                    drawstring("STRUCTURE BIAS:", offset1 + 0.1f * maxStringWidth, pos5, dataFont1, TextColor, SharpDX.DirectWrite.TextAlignment.Leading);
                    if (filterValue3 > 0)
                    {
                        drawRectangle(offset3, pos6f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BullishDivergenceDXBrush);
                        drawstring(UpBiasString, offset3, pos6, dataFont2, BullishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else if (filterValue3 < 0)
                    {
                        drawRectangle(offset3, pos6f, 1.04f * maxStringWidth, 1.4f * dataStringHeight, BearishDivergenceDXBrush);
                        drawstring(DwBiasString, offset3, pos6, dataFont2, BearishForegroundColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    else
                    {
                        drawLine(offset3, offset3 + 1.04f * maxStringWidth, pos6f, pos6f, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3, offset3 + 1.04f * maxStringWidth, pos6f + 1.4f * dataStringHeight, pos6f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3, offset3, pos6f, pos6f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawLine(offset3 + 1.04f * maxStringWidth, offset3 + 1.04f * maxStringWidth, pos6f, pos6f + 1.4f * dataStringHeight, TextColor, DashStyleHelper.Solid, 1);
                        drawstring(NeutralBiasString, offset3, pos6 + 0.1f * dataStringHeight, dataFont1, TextColor, SharpDX.DirectWrite.TextAlignment.Center, 1.04f * maxStringWidth);
                    }
                    #endregion
                }
            }
            #endregion
			if(!OverprintSentimentBox) base.OnRender(chartControl, chartScale);

            RenderTarget.AntialiasMode = oldAntialiasMode;
//			ChannelBkgDXBrush.Dispose();  ChannelBkgDXBrush = null;
//			BullishBkgDXBrush.Dispose();  BullishBkgDXBrush=null;
//			BearishBkgDXBrush.Dispose();  BearishBkgDXBrush=null;
//			DeepBullishBkgDXBrush.Dispose();  DeepBullishBkgDXBrush=null;
//			DeepBearishBkgDXBrush.Dispose();  DeepBearishBkgDXBrush=null;
//			OppositeBkgDXBrush.Dispose();     OppositeBkgDXBrush=null;
//			if(ShowBiasInBox){
//				DataTableDXBrush.Dispose();       DataTableDXBrush = null;
//				BullishDivergenceDXBrush.Dispose(); BullishDivergenceDXBrush = null;
//				BearishDivergenceDXBrush.Dispose(); BearishDivergenceDXBrush = null;
//			}
        }
        #endregion

        #region -- drawing functions { AzurITec } --
        //Draw Rectangle Region. x and y as pixel coordinate, w and h in pixel too.
        private void drawRectangle(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush, int opacity = 100)
        {
            drawRegion(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush);
        }

        private void drawRegion(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
        {
            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();
        }

        private void drawRegion(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false, bool atMiddle = false)
        {
#if USE_WPF_COORDS
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[3]))
                },
                dxbrush
                );
#else
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[3]))
                },
                dxbrush
                );
#endif
        }

        //Draw a line between 2 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawLine(double val1, double val2, int idxslot1, int idxslot2, Brush couleur, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false)
        {
            SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

#if USE_WPF_COORDS
            Point p0 = new Point(GetX0(idxslot1, chartControl), drawOnPricePanel ? 0 : ChartPanel.Y + chartScale.GetYByValueWpf(val1));
            Point p1 = new Point(GetX0(idxslot2, chartControl), drawOnPricePanel ? 0 : ChartPanel.Y + chartScale.GetYByValueWpf(val2));
#else
            Point p0 = new Point(GetX0(idxslot1, chartControl), drawOnPricePanel ? 0 : chartScale.GetYByValue(val1));
            Point p1 = new Point(GetX0(idxslot2, chartControl), drawOnPricePanel ? 0 : chartScale.GetYByValue(val2));
#endif
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }
        //Draw a line between 2 points in pixel coordinates.        
        private void drawLine(double x1, double x2, double y1, double y2, Brush couleur, DashStyleHelper dashstyle, int width)
        {
            SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            Point p0 = new Point(x1, y1);
            Point p1 = new Point(x2, y2);
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }

        //Draw a text at {x;y} coordinates in pixel.
        private void drawstring(string text, double x, double y, SimpleFont font, Brush textBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                )
            { TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

			var textBrushDX = textBrush.ToDxBrush(RenderTarget);
            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
			textBrushDX.Dispose(); textBrushDX=null;

            textLayout.Dispose();
            textFormat.Dispose();
        }

        private float getTextWidth(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }

        //retrieve the x coordinate in pixel of a a relative bar index.
        //##MODIF## AzurITec - 18.05.2016
        private int GetX0(int bars, ChartControl chartControl, bool atMiddle = false) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars) - (atMiddle ? (int)(chartControl.Properties.BarDistance / 2) : 0); }//NEW VERSION NT8        
        #endregion

        #region -- Properties ------------------------------------------------------------
        
        #region -- PLOTS --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BBMACD { get { return Values[BBMACDIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BBMACDFrame { get { return Values[BBMACDFrameIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BBMACDLine { get { return Values[BBMACDLineIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Average { get { return Values[AverageIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Upper { get { return Values[UpperIDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Lower { get { return Values[LowerIDX]; } }

        /// <summary>
        /// RJ5Group LLC
        /// </summary>
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Histogram { get { return Values[HistogramIDX]; } }

        /// <summary>
        /// //rj RJ5GROUP code Algorithm
        /// </summary>
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionUL3 { get { return Values[PriceExcursionUL3IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionUL2 { get { return Values[PriceExcursionUL2IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionUL1 { get { return Values[PriceExcursionUL1IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionLL1 { get { return Values[PriceExcursionLL1IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionLL2 { get { return Values[PriceExcursionLL2IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionLL3 { get { return Values[PriceExcursionLL3IDX]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionMAX { get { return Values[PriceExcursionMAXIDX]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> PriceExcursionMIN { get { return Values[PriceExcursionMINIDX]; } }
        #endregion

        #region -- Exposed DataSeries --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> StructureBiasState { get { return structureBiasState; } }//#STRBIAS
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> SwingHighsState { get { return swingHighsState; } }//#SWINGS
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> SwingLowsState { get { return swingLowsState; } }//#SWINGS

        #region -- Trend Filters --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> BBDotTrend { get { return bbDotTrend; } }

        #endregion

        #endregion

        //[NinjaScriptProperty]
        [Display(Name = "Optimize for Speed", GroupName = "Parameters", Description = "Improve run-time performance (reduces the number of historical chart markers", Order = 0)]
        public ARC_VMLean_OptimizeSpeedSettings OptimizeSpeed { get; set; }

		#region GroupName = "MACDBB Parameters"
        //[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Period Bollinger Band", GroupName = "MACDBB Parameters", Description = "Band Period for Bollinger Band", Order = 0)]
        public int BandPeriod { get; set; }

        //[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Lookback fast EMA", GroupName = "MACDBB Parameters", Description = "Period for fast EMA", Order = 1)]
        public int Fast { get; set; }

        //[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Lookback slow EMA", GroupName = "MACDBB Parameters", Description = "Period for slow EMA", Order = 2)]
        public int Slow { get; set; }

        //[NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Std. dev. multiplier", GroupName = "MACDBB Parameters", Description = "Number of standard deviations", Order = 3)]
        public double StdDevNumber { get; set; }
        #endregion

        #region GroupName = "SwingTrend Parameters"
        [Display(Name = "Enable Swing Calc", GroupName = "SwingTrend Parameters", Description = "No swings will be available if this is NOT enabled", Order = 0)]
		public bool pEnableSwingCalculation {get;set;}

        //[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 10)]
        public int SwingStrength { get; set; }

        //[NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Deviation multiplier", GroupName = "SwingTrend Parameters", Description = "Multiplier used to calculate minimum deviation as an ATR multiple", Order = 20)]
        public double MultiplierMD { get; set; }

        //[NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Sensitivity double tops/bottoms", GroupName = "SwingTrend Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 30)]
        public double MultiplierDTB { get; set; }
        #endregion

        #region GroupName = "Display Options Oscillator Panel"
        [Display(Name = "Background Flooding", GroupName = "Display Options Oscillator Panel", Description = "Choose the type of background flooding to show", Order = 1)]
        public ARC_VMLean_Flooding BackgroundFlooding { get; set; }

        [Display(Name = "Display Structure Bias in box", GroupName = "Display Options Oscillator Panel", Description = "Option to display or remove the Structure Bias in Box", Order = 3)]
        public bool ShowBiasInBox { get; set; }
        #endregion

		#region GroupName = "Display Options Swing Trend"
		[Range(1, int.MaxValue)]
		[Display(Name = "Dotsize swing dots", GroupName = "Display Options Swing Trend", Description = "Dotsize for swing dots representing swing highs and swing lows", Order = 0)]
		public int SwingDotSize { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Fontsize swing labels", GroupName = "Display Options Swing Trend", Description = "Dotsize for swing labels for swing highs and swing lows", Order = 10)]
		public int LabelFontSize { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Width swing legs", GroupName = "Display Options Swing Trend", Description = "Select thickness of swing legs connecting swing highs and lows", Order = 20)]
		public int SwingLegWidth { get; set; }

		[Display(Name = "Show swing dots", GroupName = "Display Options Swing Trend", Description = "Show dots for swing highs and lows", Order = 30)]
		public bool ShowZigzagDots { get; set; }

		[Display(Name = "Show swing labels", GroupName = "Display Options Swing Trend", Description = "Show labels for swing highs and lows", Order = 40)]
		public bool ShowZigzagLabels { get; set; }
		[XmlIgnore]
		[Display(Name = "Rising Swing Label Color", GroupName = "Display Options Swing Trend", Description = "Select Color", Order = 50)]
		public Brush pUpLabelColor { get; set; }
				[Browsable(false)]
				public string UpSwingLabelColorSerialize {get { return Serialize.BrushToString(pUpLabelColor); }set { pUpLabelColor = Serialize.StringToBrush(value); } }

		[XmlIgnore]
		[Display(Name = "Falling Swing Label Color", GroupName = "Display Options Swing Trend", Description = "Select Color", Order = 60)]
		public Brush pDownLabelColor { get; set; }
				[Browsable(false)]
				public string DownSwingLabelColorSerialize {get { return Serialize.BrushToString(pDownLabelColor); }set { pDownLabelColor = Serialize.StringToBrush(value); } }

		[Display(Name = "Show swing legs", GroupName = "Display Options Swing Trend", Description = "Show swing legs connecting swing highs and lows", Order = 70)]
		public bool ShowZigzagLegs { get; set; }

		[Display(Name = "Dash style swing legs", GroupName = "Display Options Swing Trend", Description = "Dash style for swing legs.", Order = 80)]
		public DashStyleHelper SwingLegStyle { get; set; }

		[XmlIgnore]
		[Display(Name = "Rising leg color", GroupName = "Display Options Swing Trend", Description = "Select Color", Order = 90)]
		public Brush pUpSwingLineColor { get; set; }
				[Browsable(false)]
				public string UpSwingLineColorSerialize {get { return Serialize.BrushToString(pUpSwingLineColor); }set { pUpSwingLineColor = Serialize.StringToBrush(value); } }

		[XmlIgnore]
		[Display(Name = "Falling leg color", GroupName = "Display Options Swing Trend", Description = "Select Color", Order = 100)]
		public Brush pDownSwingLineColor { get; set; }
				[Browsable(false)]
				public string DownSwingLineColorSerialize {get { return Serialize.BrushToString(pDownSwingLineColor); }set { pDownSwingLineColor = Serialize.StringToBrush(value); } }

		[XmlIgnore]
		[Display(Name = "Double top/bottom leg color", GroupName = "Display Options Swing Trend", Description = "Select Color", Order = 110)]
		public Brush pDoubleTopBottomColor { get; set; }
				[Browsable(false)]
				public string DoubleTopBottomColorSerialize {get { return Serialize.BrushToString(pDoubleTopBottomColor); }set { pDoubleTopBottomColor = Serialize.StringToBrush(value); } }
		#endregion

        //rj RJ5GROUP code Algorithm
        #region GroupName = "Display Options Price Excursions"
        [Display(GroupName = "Display Options Price Excursions", Description = "Display Level 1", Order = 0)]
        public bool DisplayLevel1 { get; set; }

        [Display(GroupName = "Display Options Price Excursions", Description = "Display Level 2", Order = 1)]
        public bool DisplayLevel2 { get; set; }

        [Display(GroupName = "Display Options Price Excursions", Description = "Display Level 3", Order = 2)]
        public bool DisplayLevel3 { get; set; }
        #endregion

        #region GroupName = "Plot Parameters"
        [Range(1, int.MaxValue)]
        [Display(Name = "Dot size MACD", GroupName = "Plot Parameters", Description = "Dotsize for MACD dots", Order = 0)]
        public int DotSizeMACD { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Width connectors", GroupName = "Plot Parameters", Description = "Width for MACD connectors.", Order = 1)]
        public int Plot2Width { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Width average", GroupName = "Plot Parameters", Description = "Width for Average of Bollinger Bands.", Order = 2)]
        public int Plot3Width { get; set; }

        [Display(Name = "Dash style average", GroupName = "Plot Parameters", Description = "DashStyleHelper for Average of Bollinger Bands.", Order = 3)]
        public DashStyleHelper Dash3Style { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Width Bollinger Bands", GroupName = "Plot Parameters", Description = "Width for Bollinger Bands.", Order = 4)]
        public int Plot4Width { get; set; }

        [Display(Name = "Dash style Bollinger Bands", GroupName = "Plot Parameters", Description = "DashStyleHelper for Bollinger Bands.", Order = 5)]
        public DashStyleHelper Dash4Style { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Width zeroline", GroupName = "Plot Parameters", Description = "Width for Zero Line.", Order = 6)]
        public int ZerolineWidth { get; set; }

        [Display(Name = "Dash style zeroline", GroupName = "Plot Parameters", Description = "DashStyleHelper for Zero Line.", Order = 7)]
        public DashStyleHelper ZerolineStyle { get; set; }

        [Range(0, 100)]
        [Display(Name = "Opacity channel shading", GroupName = "Plot Parameters", Description = "Opacity for shading the area between the Bollinger Bands", Order = 8)]
        public int ChannelOpacity { get; set; }

        [Range(0, 100)]
        [Display(Name = "Opacity background flooding", GroupName = "Plot Parameters", Description = "Opacity used for flooding the chart background", Order = 9)]
        public int BackgroundOpacity { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Width histogram bars", GroupName = "Plot Parameters", Description = "Width for the Histogram Momo.", Order = 10)]
        public int MomoWidth { get; set; }
        #endregion

        #region GroupName = "Plot Colors"
        [XmlIgnore]
        [Display(Name = "Rising dots above channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 0)]
        public Brush DotsUpRisingColor { get; set; }
        [Browsable(false)]
        public string DotsUpRisingColorSerialize
        {
            get { return Serialize.BrushToString(DotsUpRisingColor); }
            set { DotsUpRisingColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Rising dots inside/below channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 1)]
        public Brush DotsDownRisingColor { get; set; }
        [Browsable(false)]
        public string DotsDownRisingColorSerialize
        {
            get { return Serialize.BrushToString(DotsDownRisingColor); }
            set { DotsDownRisingColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Falling dots below channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 2)]
        public Brush DotsDownFallingColor { get; set; }
        [Browsable(false)]
        public string DotsDownFallingColorSerialize
        {
            get { return Serialize.BrushToString(DotsDownFallingColor); }
            set { DotsDownFallingColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Falling dots inside/above channel ", GroupName = "Plot Colors", Description = "Select Color", Order = 3)]
        public Brush DotsUpFallingColor { get; set; }
        [Browsable(false)]
        public string DotsUpFallingColorSerialize
        {
            get { return Serialize.BrushToString(DotsUpFallingColor); }
            set { DotsUpFallingColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Dots rim", GroupName = "Plot Colors", Description = "Select Color", Order = 4)]
        public Brush DotsRimColor { get; set; }
        [Browsable(false)]
        public string DotsRimColorSerialize
        {
            get { return Serialize.BrushToString(DotsRimColor); }
            set { DotsRimColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bollinger average", GroupName = "Plot Colors", Description = "Select Color", Order = 5)]
        public Brush BBAverageColor { get; set; }
        [Browsable(false)]
        public string BBAverageColorSerialize
        {
            get { return Serialize.BrushToString(BBAverageColor); }
            set { BBAverageColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bollinger upper band", GroupName = "Plot Colors", Description = "Select Color", Order = 6)]
        public Brush BBUpperColor { get; set; }
        [Browsable(false)]
        public string BBUpperColorSerialize
        {
            get { return Serialize.BrushToString(BBUpperColor); }
            set { BBUpperColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bollinger lower band", GroupName = "Plot Colors", Description = "Select Color", Order = 7)]
        public Brush BBLowerColor { get; set; }
        [Browsable(false)]
        public string BBLowerColorSerialize
        {
            get { return Serialize.BrushToString(BBLowerColor); }
            set { BBLowerColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Momo Histogram Hi Color", GroupName = "Plot Colors", Description = "Select Color", Order = 8)]
        public Brush HistUpColor { get; set; }
        [Browsable(false)]
        public string HistUpColorSerialize
        {
            get { return Serialize.BrushToString(HistUpColor); }
            set { HistUpColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Momo Histogram Down Color", GroupName = "Plot Colors", Description = "Select Color", Order = 9)]
        public Brush HistDownColor { get; set; }
        [Browsable(false)]
        public string HistDownColorSerialize
        {
            get { return Serialize.BrushToString(HistDownColor); }
            set { HistDownColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Zeroline", GroupName = "Plot Colors", Description = "Select Color", Order = 10)]
        public Brush ZerolineColor { get; set; }
        [Browsable(false)]
        public string ZerolineColorSerialize
        {
            get { return Serialize.BrushToString(ZerolineColor); }
            set { ZerolineColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Connector", GroupName = "Plot Colors", Description = "Select Color", Order = 11)]
        public Brush ConnectorColor { get; set; }
        [Browsable(false)]
        public string ConnectorColorSerialize
        {
            get { return Serialize.BrushToString(ConnectorColor); }
            set { ConnectorColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Channel shading", GroupName = "Plot Colors", Description = "Select Color", Order = 12)]
        public Brush ChannelColor { get; set; }
        [Browsable(false)]
        public string ChannelColorSerialize
        {
            get { return Serialize.BrushToString(ChannelColor); }
            set { ChannelColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Deep Bearish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 17)]
        public Brush DeepBearishBackgroundColor { get; set; }
        [Browsable(false)]
        public string DeepBearishBackgroundColorSerialize
        {
            get { return Serialize.BrushToString(DeepBearishBackgroundColor); }
            set { DeepBearishBackgroundColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bearish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 16)]
        public Brush BearishBackgroundColor { get; set; }
        [Browsable(false)]
        public string BearishBackgroundColorSerialize
        {
            get { return Serialize.BrushToString(BearishBackgroundColor); }
            set { BearishBackgroundColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Opposite background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 15)]
        public Brush OppositeBackgroundColor { get; set; }
        [Browsable(false)]
        public string OppositeBackgroundColorSerialize
        {
            get { return Serialize.BrushToString(OppositeBackgroundColor); }
            set { OppositeBackgroundColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bullish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 14)]
        public Brush BullishBackgroundColor { get; set; }
        [Browsable(false)]
        public string BullishBackgroundColorSerialize
        {
            get { return Serialize.BrushToString(BullishBackgroundColor); }
            set { BullishBackgroundColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Deep Bullish background flooding", GroupName = "Plot Colors", Description = "Select Color", Order = 13)]
        public Brush DeepBullishBackgroundColor { get; set; }
        [Browsable(false)]
        public string DeepBullishBackgroundColorSerialize
        {
            get { return Serialize.BrushToString(DeepBullishBackgroundColor); }
            set { DeepBullishBackgroundColor = Serialize.StringToBrush(value); }
        }
        #endregion

        //rj RJ5GROUP code Algorithm
        #region Category("Price Excursion - Plot Colors")
        [XmlIgnore]
        [Display(Name = "Color level 1 ", GroupName = "Price Excursion - Plot Colors", Description = "Select Color for Level 1 lines", Order = 0)]
        public Brush Level1Color { get; set; }
        [Browsable(false)]
        public string Level1ColorSerialize
        {
            get { return Serialize.BrushToString(Level1Color); }
            set { Level1Color = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Color level 2 ", GroupName = "Price Excursion - Plot Colors", Description = "Select Color for Level 2 lines", Order = 1)]
        public Brush Level2Color { get; set; }
        [Browsable(false)]
        public string Level2ColorSerialize
        {
            get { return Serialize.BrushToString(Level2Color); }
            set { Level2Color = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Color level 3 ", GroupName = "Price Excursion - Plot Colors", Description = "Select Color for Level 3 lines", Order = 2)]
        public Brush Level3Color { get; set; }
        [Browsable(false)]
        public string Level3ColorSerialize
        {
            get { return Serialize.BrushToString(Level3Color); }
            set { Level3Color = Serialize.StringToBrush(value); }
        }
        #endregion

        //rj RJ5GROUP code Algorithm
        #region Category("Price Excursion - Plot Parameters")
        [Display(Name = "Plot style for Level Lines", GroupName = "Price Excursion - Plot Parameters", Description = "PlotStyle for Level Lines", Order = 0)]
        public PlotStyle PlotStyleLevels { get; set; }

        [Display(Name = "Dash style for Level Lines", GroupName = "Price Excursion - Plot Parameters", Description = "DashStyleHelper for level lines", Order = 1)]
        public DashStyleHelper DashStyleHelperLevels { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Width for level lines", GroupName = "Price Excursion - Plot Parameters", Description = "Width for level lines", Order = 2)]
        public int PlotWidthLevels { get; set; }
        #endregion

        #region GroupName = "Sentiment Box - Colors"
        [XmlIgnore]
        [Display(Name = "Bearish Acceleration", GroupName = "Sentiment Box - Colors", Description = "Select color for bearish acceleration signal", Order = 1)]
        public Brush BearishAccelerationColor { get; set; }
        [Browsable(false)]
        public string BearishAccelerationColorSerialize
        {
            get { return Serialize.BrushToString(BearishAccelerationColor); }
            set { BearishAccelerationColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bearish Divergence", GroupName = "Sentiment Box - Colors", Description = "Select color for bearish divergence signal", Order = 2)]
        public Brush BearishDivergenceColor { get; set; }
        [Browsable(false)]
        public string BearishDivergenceColorSerialize
        {
            get { return Serialize.BrushToString(BearishDivergenceColor); }
            set { BearishDivergenceColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bearish Foreground", GroupName = "Sentiment Box - Colors", Description = "Select color for bearish foreground text", Order = 3)]
        public Brush BearishForegroundColor { get; set; }
        [Browsable(false)]
        public string BearishForegroundColorSerialize
        {
            get { return Serialize.BrushToString(BearishForegroundColor); }
            set { BearishForegroundColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bullish Acceleration", GroupName = "Sentiment Box - Colors", Description = "Select color for bullish acceleration signal", Order = 3)]
        public Brush BullishAccelerationColor { get; set; }
        [Browsable(false)]
        public string BullishAccelerationColorSerialize
        {
            get { return Serialize.BrushToString(BullishAccelerationColor); }
            set { BullishAccelerationColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bullish Divergence", GroupName = "Sentiment Box - Colors", Description = "Select color for bullish divergence signal", Order = 4)]
        public Brush BullishDivergenceColor { get; set; }
        [Browsable(false)]
        public string BullishDivergenceColorSerialize
        {
            get { return Serialize.BrushToString(BullishDivergenceColor); }
            set { BullishDivergenceColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bullish Foreground", GroupName = "Sentiment Box - Colors", Description = "Select color for bullish foreground text", Order = 5)]
        public Brush BullishForegroundColor { get; set; }
        [Browsable(false)]
        public string BullishForegroundColorSerialize
        {
            get { return Serialize.BrushToString(BullishForegroundColor); }
            set { BullishForegroundColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Box Outline Color", GroupName = "Sentiment Box - Colors", Description = "Select color if there is no bullish or bearish indication", Order = 6)]
        public Brush TextBoxOutlineColor { get; set; }
        [Browsable(false)]
        public string TextBoxOutlineColorSerialize
        {
            get { return Serialize.BrushToString(TextBoxOutlineColor); }
            set { TextBoxOutlineColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Text Color", GroupName = "Sentiment Box - Colors", Description = "Select color if there is no bullish or bearish indication", Order = 7)]
        public Brush TextColor { get; set; }
        [Browsable(false)]
        public string TextColorSerialize
        {
            get { return Serialize.BrushToString(TextColor); }
            set { TextColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Background Color", GroupName = "Sentiment Box - Colors", Description = "Select color for back ground of display", Order = 8)]
        public Brush DataTableColor { get; set; }
        [Browsable(false)]
        public string DataTableColorSerialize
        {
            get { return Serialize.BrushToString(DataTableColor); }
            set { DataTableColor = Serialize.StringToBrush(value); }
        }
        #endregion

		//JQ 11.26.2017
		// Bug 12782. The set right margin is causing the shifting of the SDV bar when the PP bar and the Divergence indicator
        // are all on the same chart. This could be a NT8 issue as it appears the BarMarginRight is only applied to the
		// primary bar (PP) rather than the secondary bar SDV). For now, I will disable the setrightmargin properties
		// until I have a chance to talk to NT about this issue.
		// --start--
//        [Display(Name = "Set right side margin", GroupName = "Sentiment Box - Parameters", Description = "When set to true the margin required between the last bar and the chart boundary is set as needed for the box", Order = 1)]
//        public bool SetRightSideMargin { get; set; }
		// --End--

        #region Category("Sentiment Box - Parameters")
		[Range(1, int.MaxValue)]
		[Display(Name = "Fontsize", GroupName = "Sentiment Box - Parameters", Description = "Select fontsize for text which appears in the box", Order = 0)]
		public int DataFontSize { get; set; }

		[Display(Name = "Location", GroupName = "Sentiment Box - Parameters", Description = "Select location of the sentiment box", Order = 10)]
		public ARC_VMLean_SentimentBoxLocations SentimentBoxLocation { get; set; }

		[Display(Name = "Overprint?", GroupName = "Sentiment Box - Parameters", Description = "Will the sentiment box print on top of the histogram?", Order = 20)]
		public bool OverprintSentimentBox { get; set; }
		#endregion

        #region Category("Sentiment Box - Text Elements")
        [Display(Name = "Bullish Acceleration", GroupName = "Sentiment Box - Text Elements", Description = "Select text for bullish acceleration", Order = 1)]
        public string BullAccString { get; set; }

        [Display(Name = "Confirmed bull divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bullish divergence", Order = 4)]
        public string BullDivCString { get; set; }

        [Display(Name = "Potential bull divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bullish divergence", Order = 9)]
        public string BullDivPString { get; set; }

        [Display(Name = "Confirmed bull hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bullish hidden divergence", Order = 5)]
        public string BullHDivCString { get; set; }

        [Display(Name = "Potential bull hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bullish hidden divergence", Order = 10)]
        public string BullHDivPString { get; set; }

        [Display(Name = "Bearish Acceleration", GroupName = "Sentiment Box - Text Elements", Description = "Select text for bearish acceleration", Order = 0)]
        public string BearAccString { get; set; }

        [Display(Name = "Confirmed bear divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bearish divergence", Order = 2)]
        public string BearDivCString { get; set; }

        [Display(Name = "Potential bear divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bearish divergence", Order = 7)]
        public string BearDivPString { get; set; }

        [Display(Name = "Confirmed bear hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for confirmed bearish hidden divergence", Order = 3)]
        public string BearHDivCString { get; set; }

        [Display(Name = "Potential bear hidden divergence", GroupName = "Sentiment Box - Text Elements", Description = "Select text for potential bearish hidden divergence", Order = 8)]
        public string BearHDivPString { get; set; }

        [Display(Name = "Neutral condition", GroupName = "Sentiment Box - Text Elements", Description = "Select text for neutral condition without bullish or bearish indications", Order = 6)]
        public string NeutralString { get; set; }

        [Display(Name = "Up Trend Bias", GroupName = "Sentiment Box - Text Elements", Description = "Select text for Up Trend Bias", Order = 11)]
        public string UpBiasString { get; set; }

        [Display(Name = "Neutral Bias", GroupName = "Sentiment Box - Text Elements", Description = "Select text for Neutral Bias", Order = 12)]
        public string NeutralBiasString { get; set; }

        [Display(Name = "Down Trend Bias", GroupName = "Sentiment Box - Text Elements", Description = "Select text for Down Trend Bias", Order = 13)]
        public string DwBiasString { get; set; }
        #endregion

        [Display(Name = "Button Text", GroupName = "Indicator Display", Description = "", Order = 20)]
		public string pButtonText {get;set;}
        //---start--
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }
        //--end--
        #endregion
    }
}
public enum ARC_VMLean_InputType { High_Low, Close, Median, Typical }
public enum ARC_VMLean_Flooding { None, Histogram, Structure, Both }
public enum ARC_VMLean_ExcursionStyle { Static, Dynamic }
public enum ARC_VMLean_SentimentBoxLocations {Left, Right, Hide}
public enum ARC_VMLean_OptimizeSpeedSettings {Max,Min,None}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_VMLean[] cacheARC_VMLean;
		public ARC.ARC_VMLean ARC_VMLean()
		{
			return ARC_VMLean(Input);
		}

		public ARC.ARC_VMLean ARC_VMLean(ISeries<double> input)
		{
			if (cacheARC_VMLean != null)
				for (int idx = 0; idx < cacheARC_VMLean.Length; idx++)
					if (cacheARC_VMLean[idx] != null &&  cacheARC_VMLean[idx].EqualsInput(input))
						return cacheARC_VMLean[idx];
			return CacheIndicator<ARC.ARC_VMLean>(new ARC.ARC_VMLean(), input, ref cacheARC_VMLean);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_VMLean ARC_VMLean()
		{
			return indicator.ARC_VMLean(Input);
		}

		public Indicators.ARC.ARC_VMLean ARC_VMLean(ISeries<double> input )
		{
			return indicator.ARC_VMLean(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_VMLean ARC_VMLean()
		{
			return indicator.ARC_VMLean(Input);
		}

		public Indicators.ARC.ARC_VMLean ARC_VMLean(ISeries<double> input )
		{
			return indicator.ARC_VMLean(input);
		}
	}
}

#endregion
