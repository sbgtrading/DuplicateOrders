#define DoLicense
#define MODERATORS

// Copyright (C) 2019, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX.DirectWrite;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    [CategoryOrder("Parameters", 10)]
    [CategoryOrder("Region Visuals", 20)]
    [CategoryOrder("Text Visuals", 30)]
	/// </summary>
	public class ARC_ATRCurve : Indicator
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "ATRCurve";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "10437", "27405"};//27405 is Annual Membership
		private string indicatorVersion = "v1.0";
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				if(UserId.CompareTo("41855")==0) return true;// Richard Webber  rwebber12@shaw.ca
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		//private Series<double> curveRegion;
		private List<double> RegionDividerPcts = new List<double>();
		private List<double> RegionLevelsPts = new List<double>();

		bool IsLive = false;
		bool InitComplete = false;
		bool InitATR = true;
		double UpperCurveLevel = double.MaxValue;
		double LowerCurveLevel = 0;
		List<string> RiskLabels = new List<string>();
		
		private SharpDX.Direct2D1.Brush Region1BrushDX,Region2BrushDX,Region3BrushDX,Region4BrushDX;
		private SharpDX.Direct2D1.Brush RegionLabelTextBrushDX, RegionLabelBkgBrushDX;
//		private class RegionData{
//			private double LevelPct = 0;
//			private double LevelPts = 0;
//			private string RiskStmt = "";
//			public RegionData(double pts, string risk_stmt){
//				LevelPts = pts; RiskStmt = risk_stmt;
//			}
//		}
//		private SortedDictionary<double,RegionData> RegionMarkings = new SortedDictionary<double,RegionData>();//level pct is the key
//========================================================================================================
		protected override void OnStateChange()
		{
			#region OnStateChange
			if (State == State.SetDefaults)
			{
				#region -- SetDefaults --
//				Description					= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionATR;
				Name						= "ARC_ATR Curve";
				IsSuspendedWhileInactive	= true;
				pPeriod						= 1;
				Calculate = Calculate.OnPriceChange;
				this.BarsRequiredToPlot = pPeriod+3;

				pLookbackPeriod    = 365;
				pQualifyingPeaks   = 4;
				pQualifyingValleys = 4;
				pQualifyingPeaks   = 4;
				pPctLevels         = "25,50,75";
				RangeLowColor      = Brushes.Goldenrod;
				RangeHighColor     = Brushes.Goldenrod;
				pRegion1Color = Brushes.DarkGreen;
				pRegion1LineColor = Brushes.Black;
				pRegion2Color = Brushes.LightGreen;
				pRegion2LineColor = Brushes.Black;
				pRegion3Color = Brushes.LightCoral;
				pRegion3LineColor = Brushes.Black;
				pRegion4Color = Brushes.Maroon;
				pRegion4LineColor = Brushes.Black;
				pRegionLabelTextColor = Brushes.White;
				pRegionLabelBkgColor = Brushes.Black;
				pRegion1Opacity = 25;
				pRegion2Opacity = 25;
				pRegion3Opacity = 25;
				pRegion4Opacity = 25;
				pRegionLevelFont = new SimpleFont("Arial", 18);
				pShowRegionLevels = false;
				
				pRiskLabels2 = "Low,High";
				pRiskLabels3 = "Low,Med,High";
				pRiskLabels4 = "Low,Med,High,Extreme";

				AddPlot(Brushes.Yellow, "ATR");
				AddPlot(new Stroke(Brushes.Yellow, 1), PlotStyle.Dot, "ATRnow");
				AddPlot(Brushes.Transparent, "CurveRegion");
				#endregion
			}
			if (State == State.Configure)
			{
				//curveRegion = new Series<double>(this);
				IsDebug = System.IO.File.Exists(@"c:\222222222222.txt");
				IsDebug = IsDebug && (NinjaTrader.Cbi.License.MachineId.CompareTo("CB15E08BE30BC80628CFF6010471FA2A")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion
			}
			if (State == State.DataLoaded)
			{
//				ClearOutputWindow();
				#region -- DataLoaded --
				IsLive = true;
				var temparray = pPctLevels.Split(new char[]{',',';',' ','|',':'}, StringSplitOptions.RemoveEmptyEntries);
				foreach(var tas in temparray){
					string tass = tas.Replace(" ",string.Empty).Replace("-",string.Empty).Replace("_",string.Empty);
					double tassd = 0;
					if(double.TryParse(tass.Trim(), out tassd)) {
						if(tassd>0 && tassd<100 && !RegionDividerPcts.Contains(tassd)) RegionDividerPcts.Add(tassd);
					}else{
						Log("Parameter error on 'Pct Levels' input to 'NS ATR Curve' indicator",NinjaTrader.Cbi.LogLevel.Error);
					}
				}
				RegionDividerPcts.Sort();
				if(RegionDividerPcts.Count>1 && RegionDividerPcts[0]>RegionDividerPcts.Last())
					RegionDividerPcts.Reverse();//lowest region divider pct value is at the lowest index
				if(RegionDividerPcts.Count == 0)
					Log("Error on 'Pct Levels' input to 'NS ATR Curve' indicator\nEnter at least 1 number",NinjaTrader.Cbi.LogLevel.Error);
				#endregion

				var array = new string[1];
				if(RegionDividerPcts.Count == 1) array = pRiskLabels2.Split(new char[]{',',';','|'}, StringSplitOptions.None);
				if(RegionDividerPcts.Count == 2) array = pRiskLabels3.Split(new char[]{',',';','|'}, StringSplitOptions.None);
				if(RegionDividerPcts.Count == 3) array = pRiskLabels4.Split(new char[]{',',';','|'}, StringSplitOptions.None);

				foreach(var x in array) {
					RiskLabels.Add(x.Trim());
				}
				RiskLabels.Insert(0, "");//puts a blank risk statement below the Lower range line
				RiskLabels.Add("");//puts a blank risk statement above the Upper range line

			}
			#endregion
		}
//========================================================================================================
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Atr { get { return Values[0]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> AtrNow { get { return Values[1]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> CurveRegion { get { return Values[2]; } }
//========================================================================================================
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif

			double high0	= High[0];
			double low0		= Low[0];

//			if (InitATR){
//				InitATR = false;
//				Atr[0] = high0 - low0;
//				return;
//			}
			Atr[0] = high0 - low0;
			if(CurrentBar > 5+BarsRequiredToPlot){
				double close1	 = Close[1];
				double trueRange = Math.Max(Math.Abs(low0 - close1), Math.Max(high0 - low0, Math.Abs(high0 - close1)));
				Atr[0]			 = ((Math.Min(CurrentBar + 1, pPeriod) - 1 ) * Atr[1] + trueRange) / Math.Min(CurrentBar + 1, pPeriod);
			}
			if(CurrentBars[0]>0) AtrNow.Reset(1);
			AtrNow[0] = Atr[0];

//			var IsOnChart = ChartControl != null;
//			if(CurrentBars[0] > Bars.Count-5 && (!InitComplete || IsFirstTickOfBar)){
			if((!InitComplete || IsFirstTickOfBar)){
				InitComplete = true;
				List<double> atrsValley = new List<double>();
				List<double> atrsPeak = new List<double>();
				for(int abar = CurrentBars[0]-2; abar>1 && abar>CurrentBars[0]-pLookbackPeriod; abar--){
					if(Atr.GetValueAt(abar-1) < Atr.GetValueAt(abar) && Atr.GetValueAt(abar+1) < Atr.GetValueAt(abar)) atrsPeak.Add(Atr.GetValueAt(abar));
					if(Atr.GetValueAt(abar-1) > Atr.GetValueAt(abar) && Atr.GetValueAt(abar+1) > Atr.GetValueAt(abar)) atrsValley.Add(Atr.GetValueAt(abar));
				}
				if(atrsPeak.Count > 0 && atrsValley.Count > 0){
					UpperCurveLevel = atrsPeak.Max();
					LowerCurveLevel = atrsValley.Min();
					atrsPeak.Sort();
					atrsValley.Sort();
					if(atrsValley.Count>1 && atrsValley[0]>atrsValley.Last()) atrsValley.Reverse(); //lowest ATRs are at the lowest indexes
					if(atrsValley.Count > pQualifyingValleys+1) {
						LowerCurveLevel = atrsValley[pQualifyingValleys];
//for(int k=0; k<pQualifyingValleys; k++) Print("Valleys:   "+atrsValley[k]);
//Print("LowerCurveLevel: "+LowerCurveLevel);
					}
					if(atrsPeak.Count>1 && atrsPeak[0]<atrsPeak.Last()) atrsPeak.Reverse(); //highest ATRs are at the highest indexes
					if(atrsPeak.Count > pQualifyingPeaks+1) {
						UpperCurveLevel = atrsPeak[pQualifyingPeaks];
//for(int k=0; k<pQualifyingValleys; k++) Print("Peaks:   "+atrsPeak[k]);
//Print("UpperCurveLevel: "+UpperCurveLevel);
					}
//Print("");
//Print(Time[0].ToString());
//Print("Atrs.Count: "+atrs.Count);
//Print("UpperLevel: "+UpperCurveLevel);
//Print("LowerLevel: "+LowerCurveLevel);
				}//else Print(Time[0].ToString()+"  Atrs.Count was 0");
			}
			//if(CurrentBars[0] > Bars.Count-5)
			{
				RegionLevelsPts = new List<double>();
				double range = UpperCurveLevel - LowerCurveLevel;
				foreach(var dividerpct in RegionDividerPcts){
					RegionLevelsPts.Add(range * dividerpct/100.0 + LowerCurveLevel);
				}
				RegionLevelsPts.Add(LowerCurveLevel);
				RegionLevelsPts.Add(UpperCurveLevel);
				RegionLevelsPts.Sort();
				if(RegionLevelsPts[0] > RegionLevelsPts.Last()) RegionLevelsPts.Reverse();
			}
//Print("");
			CurveRegion[0] = 0;
			for(int i = RegionLevelsPts.Count-1; i>=0; i--){
//Print(i+"   Lvl: "+RegionLevelsPts[i]);
				if(Atr.GetValueAt(CurrentBars[0]) > RegionLevelsPts[i]) {
					CurveRegion[0] = i+1;
//Print("    ------- found it");
					break;
				}
			}
//Print("  Region: "+CurveRegion[0]+"    ATR: "+Atr[0]);
		}
//=============================================================================================================
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			#region OnRender
			if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            int lastBarIndex = Math.Min(CurrentBar, ChartBars.ToIndex);//RIGHT BAR idx (absolute)
            if (lastBarIndex < BarsRequiredToPlot) return;
			base.OnRender(chartControl, chartScale);
int line=218;
try{
            int firstBarIndex = Math.Max(BarsRequiredToPlot, ChartBars.FromIndex);//LEFT BAR idx (absolute)

            SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

line=225;
            drawLine(UpperCurveLevel, UpperCurveLevel, lastBarIndex, firstBarIndex, RangeHighColor, DashStyleHelper.Solid, 1, chartControl, chartScale);
            drawLine(LowerCurveLevel, LowerCurveLevel, lastBarIndex, firstBarIndex, RangeLowColor, DashStyleHelper.Solid, 1, chartControl, chartScale);

			var LLine = LowerCurveLevel;
line=230;
			for(int i = 0; i<RegionLevelsPts.Count; i++){
				#region -- Draw shaded regions --
				if(i==1) {
line=233;
					if(i!=RegionLevelsPts.Count-1) drawLine(RegionLevelsPts[i], RegionLevelsPts[i], lastBarIndex, firstBarIndex, pRegion1LineColor, DashStyleHelper.Solid, 1, chartControl, chartScale);
					if(pRegion1Opacity>0) drawRegion(
						new double[] { RegionLevelsPts[i], RegionLevelsPts[i], LLine, LLine }, 
						new int[]    { 0, CurrentBars[0], CurrentBars[0], 0 }, 
						Region1BrushDX, chartControl, chartScale, false, false);
					LLine = RegionLevelsPts[i];
				}
				if(i==2) {
line=242;
					if(i!=RegionLevelsPts.Count-1) drawLine(RegionLevelsPts[i], RegionLevelsPts[i], lastBarIndex, firstBarIndex, pRegion2LineColor, DashStyleHelper.Solid, 1, chartControl, chartScale);
					if(pRegion2Opacity>0) drawRegion(
						new double[] { RegionLevelsPts[i], RegionLevelsPts[i], LLine, LLine }, 
						new int[]    { 0, CurrentBars[0], CurrentBars[0], 0 }, 
						Region2BrushDX, chartControl, chartScale, false, false);
					LLine = RegionLevelsPts[i];
				}
				if(i==3) {
line=251;
					if(i!=RegionLevelsPts.Count-1) drawLine(RegionLevelsPts[i], RegionLevelsPts[i], lastBarIndex, firstBarIndex, pRegion3LineColor, DashStyleHelper.Solid, 1, chartControl, chartScale);
					if(pRegion3Opacity>0) drawRegion(
						new double[] { RegionLevelsPts[i], RegionLevelsPts[i], LLine, LLine }, 
						new int[]    { 0, CurrentBars[0], CurrentBars[0], 0 }, 
						Region3BrushDX, chartControl, chartScale, false, false);
					LLine = RegionLevelsPts[i];
				}
				if(i==4) {
line=260;
					if(i!=RegionLevelsPts.Count-1) drawLine(RegionLevelsPts[i], RegionLevelsPts[i], lastBarIndex, firstBarIndex, pRegion4LineColor, DashStyleHelper.Solid, 1, chartControl, chartScale);
					if(pRegion4Opacity>0) drawRegion(
						new double[] { RegionLevelsPts[i], RegionLevelsPts[i], LLine, LLine }, 
						new int[]    { 0, CurrentBars[0], CurrentBars[0], 0 }, 
						Region4BrushDX, chartControl, chartScale, false, false);
					LLine = RegionLevelsPts[i];
				}
				#endregion
			}
}catch(Exception e){Print(line+"  "+e.ToString());}
try{
			if(pShowRegionLevels){
				double PriorLevel = 0;
				double RiskLabelYpts = 0;
				int X_pts_pct_txt = 20;
				int X_risk_txt = 200;
				var LabelText = string.Format("{0}-pts  {1}%", Instrument.MasterInstrument.FormatPrice(LowerCurveLevel), "0");
				drawstring(LabelText, X_pts_pct_txt, chartScale.GetYByValue(LowerCurveLevel) - pRegionLevelFont.Size / 2, pRegionLevelFont, SharpDX.DirectWrite.TextAlignment.Trailing);
				LabelText = string.Format("{0}-pts  {1}%", Instrument.MasterInstrument.FormatPrice(UpperCurveLevel), "100");
				drawstring(LabelText, X_pts_pct_txt, chartScale.GetYByValue(UpperCurveLevel) - pRegionLevelFont.Size / 2, pRegionLevelFont, SharpDX.DirectWrite.TextAlignment.Trailing);
				LabelText = string.Empty;
				for(int i = 0; i<=RegionLevelsPts.Count; i++){
					if(i>0 && i<RegionLevelsPts.Count && i<=RegionDividerPcts.Count){
						LabelText = string.Format("{0}-pts  {1}%", Instrument.MasterInstrument.FormatPrice(RegionLevelsPts[i]), i==0 ? string.Empty : RegionDividerPcts[i-1].ToString("0"));
						if(LabelText.Length>0)
							drawstring(LabelText, X_pts_pct_txt, chartScale.GetYByValue(RegionLevelsPts[i]) - pRegionLevelFont.Size / 2, pRegionLevelFont, SharpDX.DirectWrite.TextAlignment.Trailing);
						RiskLabelYpts = (RegionLevelsPts[i]-PriorLevel)/2+PriorLevel;
						PriorLevel = RegionLevelsPts[i];
					} else {
						RiskLabelYpts = (UpperCurveLevel-PriorLevel)/2+PriorLevel;
					}
					LabelText = RiskLabels[i];
					if(LabelText.Length>0){
						if(pShowCurrentRegionRisk && i== CurveRegion.GetValueAt(CurrentBars[0]))
							drawstring(LabelText, X_risk_txt, chartScale.GetYByValue(RiskLabelYpts) - pRegionLevelFont.Size / 2, pRegionLevelFont, SharpDX.DirectWrite.TextAlignment.Trailing);
						else if(!pShowCurrentRegionRisk)
							drawstring(LabelText, X_risk_txt, chartScale.GetYByValue(RiskLabelYpts) - pRegionLevelFont.Size / 2, pRegionLevelFont, SharpDX.DirectWrite.TextAlignment.Trailing);
					}
				}
			}
}catch(Exception e){Print(line+"  "+e.ToString());}
			#endregion
		}
//=============================================================================================================
		public override void OnRenderTargetChanged()
		{
			if(Region1BrushDX!=null      && !Region1BrushDX.IsDisposed)      Region1BrushDX.Dispose();      Region1BrushDX = null;
			if(Region2BrushDX!=null      && !Region2BrushDX.IsDisposed)      Region2BrushDX.Dispose();      Region2BrushDX = null;
			if(Region3BrushDX!=null      && !Region3BrushDX.IsDisposed)      Region3BrushDX.Dispose();      Region3BrushDX = null;
			if(Region4BrushDX!=null      && !Region4BrushDX.IsDisposed)      Region4BrushDX.Dispose();      Region4BrushDX = null;
			if(RegionLabelTextBrushDX!=null && !RegionLabelTextBrushDX.IsDisposed)      RegionLabelTextBrushDX.Dispose();      RegionLabelTextBrushDX = null;
			if(RegionLabelBkgBrushDX!=null  && !RegionLabelBkgBrushDX.IsDisposed)      RegionLabelBkgBrushDX.Dispose();      RegionLabelBkgBrushDX = null;
//			if(X!=null      && !X.IsDisposed)      X.Dispose();      X = null;
			if(RenderTarget!=null){
				Region1BrushDX = pRegion1Color.ToDxBrush(RenderTarget);
				Region1BrushDX.Opacity = pRegion1Opacity / 100f;
				Region2BrushDX = pRegion2Color.ToDxBrush(RenderTarget);
				Region2BrushDX.Opacity = pRegion2Opacity / 100f;
				Region3BrushDX = pRegion3Color.ToDxBrush(RenderTarget);
				Region3BrushDX.Opacity = pRegion3Opacity / 100f;
				Region4BrushDX = pRegion4Color.ToDxBrush(RenderTarget);
				Region4BrushDX.Opacity = pRegion4Opacity / 100f;
				RegionLabelTextBrushDX = pRegionLabelTextColor.ToDxBrush(RenderTarget);
				RegionLabelBkgBrushDX = pRegionLabelBkgColor.ToDxBrush(RenderTarget);
			}
		}
//=============================================================================================================
		#region ------ Drawing routines ----------------------------------------
        private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            if (x < 0 || y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
            //SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            var textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                Convert.ToSingle(font.Size)
                )
            { TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
            var textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

			drawRegion(new Point[]{new Point(x-5, y-5), new Point(x-5, y-5+font.Size+10), new Point(x-5+textLayout.Metrics.Width+10, y-5+font.Size+10), new Point(x-5+textLayout.Metrics.Width+10, y-5)}, RegionLabelBkgBrushDX);

            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, RegionLabelTextBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
        }
        private float getTextWidth(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                Convert.ToSingle(font.Size)
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }
		//Draw a line between 2 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawLine(double val1, double val2, int idxslot1, int idxslot2, Brush couleur, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false)
        {
            SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

#if USE_WPF_COORDS
            Point p0 = new Point(GetX0(idxslot1, chartControl), drawOnPricePanel ? 0 : ChartPanel.Y + chartScale.GetYByValueWpf(val1));
            Point p1 = new Point(GetX0(idxslot2, chartControl), drawOnPricePanel ? 0 : ChartPanel.Y + chartScale.GetYByValueWpf(val2));
#else
            Point p0 = new Point(GetX0(idxslot1, chartControl), drawOnPricePanel ? 0 : chartScale.GetYByValue(val1));
            Point p1 = new Point(GetX0(idxslot2, chartControl), drawOnPricePanel ? 0 : chartScale.GetYByValue(val2));
#endif
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }
        private void drawRegion(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
        {
            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();
        }
        private void drawRegion(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false, bool atMiddle = false)
        {
#if USE_WPF_COORDS
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:ChartPanel.Y + chartScale.GetYByValueWpf(yValues[3]))
                },
                dxbrush
                );
#else
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[3]))
                },
                dxbrush
                );
#endif
        }
		private int GetX0(int bars, ChartControl chartControl, bool atMiddle = false) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars) - (atMiddle ? (int)(chartControl.Properties.BarDistance / 2) : 0); }//NEW VERSION NT8        
		#endregion

//========================================================================================================
		#region Properties
		#region -- parameters --
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Order = 10, ResourceType = typeof(Custom.Resource), Name = "ATR Period", GroupName = "Parameters")]
		public int pPeriod { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Order = 20, ResourceType = typeof(Custom.Resource), Name = "Lookback (bars)", GroupName = "Parameters")]
		public int pLookbackPeriod { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Order = 30, ResourceType = typeof(Custom.Resource), Name = "Qualifying Peaks", Description = "Number of ATR peaks to help identify the upper limit of the curve", GroupName = "Parameters")]
		public int pQualifyingPeaks { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Order = 40, ResourceType = typeof(Custom.Resource), Name = "Qualifying Valleys", Description = "Number of ATR valleys to help identify the lower limit of the curve", GroupName = "Parameters")]
		public int pQualifyingValleys { get; set; }

		[NinjaScriptProperty]
		[Display(Order = 50, ResourceType = typeof(Custom.Resource), Name = "Percent levels", Description = "Enter '25,50,75' for 4 regions, enter '10,90' for 3 regions, enter '50' for 2 regions", GroupName = "Parameters")]
		public string pPctLevels { get; set; }
		#endregion ----------------------------------

		#region Region Visuals
		[XmlIgnore]
		[Display(Order = 10, Name = "Range Low",            GroupName = "Region Visuals", Description = "")]
		public Brush RangeLowColor { get; set; }
				[Browsable(false)]
				public string RangeLowColor_Serialize
				{get { return Serialize.BrushToString(RangeLowColor); } set { RangeLowColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 11, Name = "Range High",           GroupName = "Region Visuals", Description = "")]
		public Brush RangeHighColor { get; set; }
				[Browsable(false)]
				public string RangeHighColor_Serialize
				{get { return Serialize.BrushToString(RangeHighColor); } set { RangeHighColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 20, Name = "Region#1 Line",        GroupName = "Region Visuals", Description = "")]
		public Brush pRegion1LineColor { get; set; }
				[Browsable(false)]
				public string pRegion1LineColor_Serialize
				{get { return Serialize.BrushToString(pRegion1LineColor); } set { pRegion1LineColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 30, Name = "Region#2 Line",        GroupName = "Region Visuals", Description = "")]
		public Brush pRegion2LineColor { get; set; }
				[Browsable(false)]
				public string pRegion2LineColor_Serialize
				{get { return Serialize.BrushToString(pRegion2LineColor); } set { pRegion2LineColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 40, Name = "Region#3 Line",         GroupName = "Region Visuals", Description = "")]
		public Brush pRegion3LineColor { get; set; }
				[Browsable(false)]
				public string pRegion3LineColor_Serialize
				{get { return Serialize.BrushToString(pRegion3LineColor); } set { pRegion3LineColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 50, Name = "Region#4 Line",         GroupName = "Region Visuals", Description = "")]
		public Brush pRegion4LineColor { get; set; }
				[Browsable(false)]
				public string pRegion4LineColor_Serialize
				{get { return Serialize.BrushToString(pRegion4LineColor); } set { pRegion4LineColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 60, Name = "Region#1 Zone",         GroupName = "Region Visuals", Description = "")]
		public Brush pRegion1Color { get; set; } 
				[Browsable(false)]
				public string pRegion1Color_Serialize
				{get { return Serialize.BrushToString(pRegion1Color); } set { pRegion1Color = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Order = 61, Name = "Region#1 Zone opacity", GroupName = "Region Visuals", Description = "")]
		public float pRegion1Opacity {get;set;}

		[XmlIgnore]
		[Display(Order = 70, Name = "Region#2 Zone",         GroupName = "Region Visuals", Description = "")]
		public Brush pRegion2Color { get; set; }
				[Browsable(false)]
				public string pRegion2Color_Serialize
				{get { return Serialize.BrushToString(pRegion2Color); } set { pRegion2Color = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Order = 71, Name = "Region#2 Zone opacity", GroupName = "Region Visuals", Description = "")]
		public float pRegion2Opacity {get;set;}

		[XmlIgnore]
		[Display(Order = 80, Name = "Region#3 Zone",         GroupName = "Region Visuals", Description = "")]
		public Brush pRegion3Color { get; set; } 
				[Browsable(false)]
				public string pRegion3Color_Serialize
				{get { return Serialize.BrushToString(pRegion3Color); } set { pRegion3Color = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Order = 81, Name = "Region#3 Zone opacity", GroupName = "Region Visuals", Description = "")]
		public float pRegion3Opacity {get;set;}

		[XmlIgnore]
		[Display(Order = 90, Name = "Region#4 Zone",         GroupName = "Region Visuals", Description = "")]
		public Brush pRegion4Color { get; set; }
				[Browsable(false)]
				public string pRegion4Color_Serialize
				{get { return Serialize.BrushToString(pRegion4Color); } set { pRegion4Color = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Order = 91, Name = "Region#4 Zone opacity", GroupName = "Region Visuals", Description = "")]
		public float pRegion4Opacity {get;set;}
		#endregion ----------------------------------------

		#region Text Visuals -------------------------------------
		[Display(Order = 10, Name = "Show Region Levels?", Description = "Print region levels on the region lines?", GroupName = "Text Visuals")]
		public bool pShowRegionLevels { get; set; }

		[Display(Order = 20, Name = "Region Level font",    GroupName = "Text Visuals", Description = "")]
		public SimpleFont pRegionLevelFont { get; set; }

		[XmlIgnore]
		[Display(Order = 30, Name = "Font Text Color",    GroupName = "Text Visuals", Description = "")]
		public Brush pRegionLabelTextColor { get; set; }
				[Browsable(false)]
				public string pRegionLabelTextColor_Serialize
				{get { return Serialize.BrushToString(pRegionLabelTextColor); } set { pRegionLabelTextColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 40, Name = "Text Bkg Color",    GroupName = "Text Visuals", Description = "")]
		public Brush pRegionLabelBkgColor { get; set; }
				[Browsable(false)]
				public string pRegionLabelBkgColor_Serialize
				{get { return Serialize.BrushToString(pRegionLabelBkgColor); } set { pRegionLabelBkgColor = Serialize.StringToBrush(value); }}

		[Display(Order = 50, Name = "2-region Risk Labels", Description = "Labels for regions when 2-regions are requested", GroupName = "Text Visuals")]
		public string pRiskLabels2 { get; set; }

		[Display(Order = 60, Name = "3-region Risk Labels", Description = "Labels for regions when 3-regions are requested", GroupName = "Text Visuals")]
		public string pRiskLabels3 { get; set; }

		[Display(Order = 70, Name = "4-region Risk Labels", Description = "Labels for regions when 4-regions are requested", GroupName = "Text Visuals")]
		public string pRiskLabels4 { get; set; }

		[Display(Order = 80, Name = "Show Current Region only?", Description = "Print risk label on the current region?", GroupName = "Text Visuals")]
		public bool pShowCurrentRegionRisk { get; set; }

		#endregion -------------------------
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_ATRCurve[] cacheARC_ATRCurve;
		public ARC.ARC_ATRCurve ARC_ATRCurve(int pPeriod, int pLookbackPeriod, int pQualifyingPeaks, int pQualifyingValleys, string pPctLevels)
		{
			return ARC_ATRCurve(Input, pPeriod, pLookbackPeriod, pQualifyingPeaks, pQualifyingValleys, pPctLevels);
		}

		public ARC.ARC_ATRCurve ARC_ATRCurve(ISeries<double> input, int pPeriod, int pLookbackPeriod, int pQualifyingPeaks, int pQualifyingValleys, string pPctLevels)
		{
			if (cacheARC_ATRCurve != null)
				for (int idx = 0; idx < cacheARC_ATRCurve.Length; idx++)
					if (cacheARC_ATRCurve[idx] != null && cacheARC_ATRCurve[idx].pPeriod == pPeriod && cacheARC_ATRCurve[idx].pLookbackPeriod == pLookbackPeriod && cacheARC_ATRCurve[idx].pQualifyingPeaks == pQualifyingPeaks && cacheARC_ATRCurve[idx].pQualifyingValleys == pQualifyingValleys && cacheARC_ATRCurve[idx].pPctLevels == pPctLevels && cacheARC_ATRCurve[idx].EqualsInput(input))
						return cacheARC_ATRCurve[idx];
			return CacheIndicator<ARC.ARC_ATRCurve>(new ARC.ARC_ATRCurve(){ pPeriod = pPeriod, pLookbackPeriod = pLookbackPeriod, pQualifyingPeaks = pQualifyingPeaks, pQualifyingValleys = pQualifyingValleys, pPctLevels = pPctLevels }, input, ref cacheARC_ATRCurve);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_ATRCurve ARC_ATRCurve(int pPeriod, int pLookbackPeriod, int pQualifyingPeaks, int pQualifyingValleys, string pPctLevels)
		{
			return indicator.ARC_ATRCurve(Input, pPeriod, pLookbackPeriod, pQualifyingPeaks, pQualifyingValleys, pPctLevels);
		}

		public Indicators.ARC.ARC_ATRCurve ARC_ATRCurve(ISeries<double> input , int pPeriod, int pLookbackPeriod, int pQualifyingPeaks, int pQualifyingValleys, string pPctLevels)
		{
			return indicator.ARC_ATRCurve(input, pPeriod, pLookbackPeriod, pQualifyingPeaks, pQualifyingValleys, pPctLevels);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_ATRCurve ARC_ATRCurve(int pPeriod, int pLookbackPeriod, int pQualifyingPeaks, int pQualifyingValleys, string pPctLevels)
		{
			return indicator.ARC_ATRCurve(Input, pPeriod, pLookbackPeriod, pQualifyingPeaks, pQualifyingValleys, pPctLevels);
		}

		public Indicators.ARC.ARC_ATRCurve ARC_ATRCurve(ISeries<double> input , int pPeriod, int pLookbackPeriod, int pQualifyingPeaks, int pQualifyingValleys, string pPctLevels)
		{
			return indicator.ARC_ATRCurve(input, pPeriod, pLookbackPeriod, pQualifyingPeaks, pQualifyingValleys, pPctLevels);
		}
	}
}

#endregion
