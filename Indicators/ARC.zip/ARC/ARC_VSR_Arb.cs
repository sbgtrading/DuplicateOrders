#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
//using System.Diagnostics.CodeAnalysis;
using System.Windows;
//using System.Reflection;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using System.Windows.Controls;
//using System.Windows.Input;
//using System.IO;
using SharpDX;
using System.Text;
using SharpDX.DirectWrite;
using System.Windows.Media.Imaging;
using System.Linq;
using NinjaTrader.NinjaScript.Indicators.ARC.Sup;
#endregion

public enum ARC_VSR_Arb_Locations    {TopLeft,TopRight,Center,BottomLeft,BottomRight}
public enum ARC_VSR_Arb_ChartMarkers {None, Arrow, Dot, Diamond, Square, Triangle, ArrowLine, Text}
public enum ARC_VSR_Arb_ScaleType    {Percentage, RawNumbers}
public enum ARC_VSR_Arb_CalcModels   {Version1, Version2}

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[CategoryOrder("Visual Parameters",10)]
	[CategoryOrder("Sensitivity",30)]
	[CategoryOrder("Volume Arb Alert",40)]
	[CategoryOrder("Speed Arb Alert",50)]
	[CategoryOrder("Range Arb Alert",60)]
//    [TypeConverter("NinjaTrader.NinjaScript.Indicators.VSRArbConverter")]
	public class ARC_VSR_Arb : Indicator 
	{
		private float VOL_SCALE_MIN   = 0;
		private float VOL_SCALE_MAX   = 200;
		private float SPEED_SCALE_MIN = 0;
		private float SPEED_SCALE_MAX = 100;
		private float RANGE_SCALE_MIN = 0;
		private float RANGE_SCALE_MAX = 100;
		private int VArb_AudibleAlertBar = 0;
		private int RArb_AudibleAlertBar = 0;
		private int SArb_AudibleAlertBar = 0;
		private int VArb_SignalCount = 0;
		private int RArb_SignalCount = 0;
		private int SArb_SignalCount = 0;
		private string MsgText       = null;
		private DateTime RecalcAt    = DateTime.Now;

		private bool IsDebug        = false;
		private bool ValidLicense   = false;
		private bool IsExpired      = true;

		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "VSRArb";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "18165", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		#region RegGauge
		public class ClassGauge
		{        
			#region RegHelper
			internal class NT7MeasureStringData
			{
				public float Height;
				public float Width;
				
				public NT7MeasureStringData()
				{
					
				}
			}
				
			
			internal class NT7Graphics
			{
				SharpDX.Direct2D1.RenderTarget rt;
			
				public NT7Graphics(SharpDX.Direct2D1.RenderTarget rt)
				{
					this.rt = rt;
				}
				
				public void FillEllipse(Brush b, float x, float y, float w, float h)
				{
					float half = w / 2;
					float x0 = Convert.ToSingle (x + half - 1);
					float y0 = Convert.ToSingle (y + half - 1);
					SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
					SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f); 
					var brush = b.ToDxBrush(this.rt);
					this.rt.FillEllipse(ellipse, brush);
					brush.Dispose();
					brush=null;
				}

				public void FillEllipse(SharpDX.Direct2D1.Brush brush, float x, float y, float w, float h)
				{
					float half = w / 2;
					float x0 = Convert.ToSingle(x + half - 1);
					float y0 = Convert.ToSingle(y + half - 1);
					SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
					SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f);
					this.rt.FillEllipse(ellipse, brush);
				}

				public void DrawLine(Stroke s, float x1, float y1, float x2, float y2)
				{
					System.Windows.Point startPoint	= new System.Windows.Point(x1, y1);
					System.Windows.Point endPoint		= new System.Windows.Point(x2, y2);
					var brush = s.Brush.ToDxBrush(this.rt);
					this.rt.DrawLine(startPoint.ToVector2(), endPoint.ToVector2(), brush, s.Width, s.StrokeStyle);
					brush.Dispose();brush=null;
				}

				public void DrawLine(SharpDX.Direct2D1.Brush brush, float width, float x1, float y1, float x2, float y2)
				{
					System.Windows.Point startPoint = new System.Windows.Point(x1, y1);
					System.Windows.Point endPoint = new System.Windows.Point(x2, y2);
					this.rt.DrawLine(startPoint.ToVector2(), endPoint.ToVector2(), brush, width);
				}

				public void DrawString(String text, SimpleFont f, Brush b, float x, float y)
				{
					this.DrawString(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading);
				}
				
				public void DrawStringRotated(String text, SimpleFont f, Brush b, float x, float y, float iAngle)
				{
					this.DrawStringRotated(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading, iAngle);
				}				
				
				public void DrawString(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta)
				{
					TextFormat textFormat		= 
						new TextFormat(
							Core.Globals.DirectWriteFactory, 
							f.Family.ToString(), 
							(f.Bold?SharpDX.DirectWrite.FontWeight.Bold:SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal, 
							SharpDX.DirectWrite.FontStretch.Normal, 
							Convert.ToSingle(f.Size)) 
							{ 
								TextAlignment = ta, 
								WordWrapping = WordWrapping.NoWrap 
							};
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,w,h);//(float)f.Size);
					
					System.Windows.Point upperTextPoint	= new System.Windows.Point(x,y);
					var brush = b.ToDxBrush(this.rt);
					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					brush.Dispose();brush=null;
				}

				public void DrawString(String text, SimpleFont f, SharpDX.Direct2D1.Brush brush, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta)
				{
					TextFormat textFormat =
						new TextFormat(
							Core.Globals.DirectWriteFactory,
							f.Family.ToString(),
							(f.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal,
							SharpDX.DirectWrite.FontStretch.Normal,
							Convert.ToSingle(f.Size))
						{
							TextAlignment = ta,
							WordWrapping = WordWrapping.NoWrap
						};

					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, w, h);//(float)f.Size);

					System.Windows.Point upperTextPoint = new System.Windows.Point(x, y);
					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
				}

				public void DrawStringRotated(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta, float iAngle)
				{
					TextFormat textFormat		= 
						new TextFormat(
							Core.Globals.DirectWriteFactory, 
							f.Family.ToString(), 
							(f.Bold?SharpDX.DirectWrite.FontWeight.Bold:SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal, 
							SharpDX.DirectWrite.FontStretch.Normal, 
							Convert.ToSingle(f.Size)) 
							{ 
								TextAlignment = ta, 
								WordWrapping = WordWrapping.NoWrap 
							};
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,w,h);//(float)f.Size);
					
					System.Windows.Point upperTextPoint	= new System.Windows.Point(x,y);
								
					SharpDX.Matrix3x2 savedTransform = this.rt.Transform;
					
					this.rt.Transform = SharpDX.Matrix3x2.Rotation(iAngle, new SharpDX.Vector2(x, y));	
					
					var brush = b.ToDxBrush(this.rt);
					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					brush.Dispose();brush=null;
							
					this.rt.Transform = savedTransform;																		
				}

				public void DrawStringRotated(String text, SimpleFont f, SharpDX.Direct2D1.Brush brush, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta, float iAngle)
				{
					TextFormat textFormat =
						new TextFormat(
							Core.Globals.DirectWriteFactory,
							f.Family.ToString(),
							(f.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal,
							SharpDX.DirectWrite.FontStretch.Normal,
							Convert.ToSingle(f.Size))
						{
							TextAlignment = ta,
							WordWrapping = WordWrapping.NoWrap
						};

					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, w, h);//(float)f.Size);

					System.Windows.Point upperTextPoint = new System.Windows.Point(x, y);

					SharpDX.Matrix3x2 savedTransform = this.rt.Transform;

					this.rt.Transform = SharpDX.Matrix3x2.Rotation(iAngle, new SharpDX.Vector2(x, y));

					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

					this.rt.Transform = savedTransform;
				}

				public NT7MeasureStringData MeasureString( String text, SimpleFont f)
				{
					NT7MeasureStringData sd = new NT7MeasureStringData();
					
					TextFormat textFormat		= new TextFormat(Core.Globals.DirectWriteFactory, f.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal,
													SharpDX.DirectWrite.FontStyle.Normal, SharpDX.DirectWrite.FontStretch.Normal, Convert.ToSingle(f.Size)) 
													{ TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading, WordWrapping = WordWrapping.NoWrap };
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,400,Convert.ToSingle(f.Size));
					
													
					sd.Height = Convert.ToSingle( textLayout.Metrics.Height);
					sd.Width = Convert.ToSingle( textLayout.Metrics.Width);
													
					return sd;
				}
			}
			
			#endregion
			
	        public ClassGauge(float iX, float iY, float iHeight, float iWidth)
	        {            
	            X = (int)iX;
	            Y = (int)iY;

	            Major_Width = (int)iWidth;
	            Major_Height = (int)iHeight;

	            Width = (int)iWidth - m_BaseMajorRadiusHeight;
	            Height = (int)iHeight - m_BaseMajorRadiusHeight;
				
	            this.m_Center = new System.Windows.Point(Major_Width / 2 - Major_Width / 25, Major_Height / 2);
				
				m_Center.X += 144;
				m_Center.Y += 8;				

	            //#####################################################################
				InitBaseValue(20, 0, 0);
	        }

	        public void InitBaseValue(Int32 nNumberStringMargin, Int32 ScaleHeight, Int32 GaugeScreenSize)
	        {
	            Int32 absRadius = 0;
	            absRadius = Major_Width / 2 - nNumberStringMargin - GaugeScreenSize;
	            BaseLineRadiusHeight = ScaleHeight;
	            if (ScaleHeight == 0)
	            {
	                nAnotherLineRadius = (2 * absRadius) / 9;
	                BaseLineRadiusHeight = nAnotherLineRadius / 2;
	            }

	            NeedleWidth = BaseLineRadiusHeight/4;

	            ScaleLinesMajorOuterRadius = absRadius - m_BaseLineRadiusHeight;
	            ScaleLinesMajorInnerRadius = absRadius;

	            ScaleLinesMinorOuterRadius = absRadius - 5;
	            ScaleLinesMinorInnerRadius = absRadius - m_BaseLineRadiusHeight;

	            ScaleLinesInterOuterRadius = absRadius - 3;
	            ScaleLinesInterInnerRadius = absRadius - m_BaseLineRadiusHeight;

	            ScaleNumbersRadius = absRadius + 0/*nNumberStringMargin*/;
	            NeedleRadius = absRadius - m_BaseLineRadiusHeight / 2;
	        }

	        #region Variables
			Stroke blackStroke = new Stroke(Brushes.Black);
			
	        private int Width = 0;
	        private int Height = 0;
	        private int Major_Width = 0;
	        private int Major_Height = 0;
	        private int X = 0;
	        private int Y = 0;
	        private Boolean drawGaugeBackground = true;
	        private SharpDX.Direct2D1.Bitmap gaugeBitmap;
	        
	        private const Byte ZERO = 0;
	        private const Byte NUMOFCAPS = 5;
	        private const Byte NUMOFRANGES = 5;        

	        private Boolean[] m_valueIsInRange = { false, false, false, false, false };
	        private Boolean[] m_RangeEnabled = { true, true, false, false, false };
	        private Single[] m_RangeStartValue = { -100.0f, 300.0f, 0.0f, 0.0f, 0.0f };
	        private Single[] m_RangeEndValue = { 300.0f, 400.0f, 0.0f, 0.0f, 0.0f };        

	        private Int32 m_BaseMajorRadiusHeight = 10;        
	        private Int32 nAnotherLineRadius = 50;

	        private Brush m_BaseArcColor = Brushes.Gray;
	        private Int32 m_BaseArcRadius = 80;
	        private Int32 m_BaseArcStart = 232;
	        private Int32 m_BaseArcSweep = 252;
	        private Int32 m_BaseArcWidth = 2;
	                
	        private Single m_MinValue = -50;
	        private Single m_MaxValue = 50;

	        private Single fontBoundY1;
	        private Single fontBoundY2;        

	        private Single m_ScaleLinesMajorStepValue = 50.0f;
	        private Brush m_ScaleLinesMajorColor = Brushes.Black;        
	        private Int32 m_ScaleLinesMajorWidth = 2;
	        private Int32 m_ScaleLinesMinorNumOf = 9;
	        private Brush m_ScaleLinesMinorColor = Brushes.Gray;        
	        private Int32 m_ScaleLinesMinorWidth = 1;
	        private Brush m_ScaleLinesInterColor = Brushes.Black;        
	        private Int32 m_ScaleLinesInterWidth = 1;        
	        private Brush m_NeedleColor2 = Brushes.DimGray;        

	        #endregion

	        #region Init Process Variable
	        public Brush BackBrush { get; set; }

	        private Brush needleBrush1 = Brushes.LemonChiffon;
			private SharpDX.Direct2D1.Brush dxNeedleBrush1 = null;

	        public Brush NeedleBrush1
	        {
	            set { needleBrush1 = value; }
	            get { return needleBrush1; }
	        }

	        private Brush needleBrush2 = Brushes.Blue;
			private SharpDX.Direct2D1.Brush dxNeedleBrush2 = null;
			public Brush NeedleBrush2
	        {
	            set { needleBrush2 = value; }
	            get { return needleBrush2; }
	        }

	        private Brush needleBrush3 = Brushes.HotPink;
			private SharpDX.Direct2D1.Brush dxNeedleBrush3 = null;
			public Brush NeedleBrush3
	        {
	            set { needleBrush3 = value; }
	            get { return needleBrush3; }
	        }

	        private Int32 m_NeedleType = 1;
	        public Int32 NeedleType
	        {
	            get{return m_NeedleType;}
	            set{m_NeedleType = value;}
	        }

	        private Int32 m_NeedleRadius = 80;
	        public Int32 NeedleRadius
	        {
	            get{return m_NeedleRadius;}
	            set{m_NeedleRadius = value;}
	        }

	        private Int32 m_NeedleWidth = 3;
	        public Int32 NeedleWidth
	        {
	            get{return m_NeedleWidth;}
	            set{m_NeedleWidth = value;}
	        }

	        private System.Windows.Point m_Center = new System.Windows.Point(100, 100);
	        public System.Windows.Point Center
	        {
	            get{return m_Center;}
	            set{m_Center = value;}
	        }

	        private Int32 m_BaseLineRadiusHeight = 20;
	        public Int32 BaseLineRadiusHeight
	        {
	            get{return m_BaseLineRadiusHeight;}
	            set{m_BaseLineRadiusHeight = value;  }
	        }

	        private Int32 m_ScaleLinesMajorOuterRadius = 80;
	        public Int32 ScaleLinesMajorOuterRadius
	        {
	            get{return m_ScaleLinesMajorOuterRadius;}
	            set{m_ScaleLinesMajorOuterRadius = value;}
	        }

	        private Int32 m_ScaleLinesMajorInnerRadius = 70;
	        public Int32 ScaleLinesMajorInnerRadius
	        {
	            get{return m_ScaleLinesMajorInnerRadius;}
	            set{m_ScaleLinesMajorInnerRadius = value;}
	        }

	        private Int32 m_ScaleLinesMinorInnerRadius = 75;
	        public Int32 ScaleLinesMinorInnerRadius
	        {
	            get{return m_ScaleLinesMinorInnerRadius;}
	            set{m_ScaleLinesMinorInnerRadius = value;}
	        }

	        private Int32 m_ScaleLinesMinorOuterRadius = 80;
	        public Int32 ScaleLinesMinorOuterRadius
	        {
	            get{return m_ScaleLinesMinorOuterRadius;}
	            set{m_ScaleLinesMinorOuterRadius = value;}
	        }

	        private Int32 m_ScaleLinesInterInnerRadius = 73;
	        public Int32 ScaleLinesInterInnerRadius
	        {
	            get{return m_ScaleLinesInterInnerRadius;}
	            set{m_ScaleLinesInterInnerRadius = value;}
	        }

	        private Int32 m_ScaleLinesInterOuterRadius = 80;
	        public Int32 ScaleLinesInterOuterRadius
	        {
	            get{return m_ScaleLinesInterOuterRadius;}
	            set{m_ScaleLinesInterOuterRadius = value;}
	        }

	        private Int32 m_ScaleNumbersRadius = 95;
	        public Int32 ScaleNumbersRadius
	        {
	            get{return m_ScaleNumbersRadius;}
	            set{m_ScaleNumbersRadius = value;}
	        }

	        public Int32 m_ScaleNumbersStartScaleLine = 0;
	        public Int32 ScaleNumbersStartScaleLine
	        {
	            get{return m_ScaleNumbersStartScaleLine;}
	            set{m_ScaleNumbersStartScaleLine = value;}
	        }

	        private Brush m_ScaleNumbersBrush = Brushes.DarkSlateGray;
	        public Brush ScaleNumbersBrush
	        {
	            get{return m_ScaleNumbersBrush;}
	            set{m_ScaleNumbersBrush = value;}
	        }

	        private Int32 m_ScaleNumbersRotation = 0;
	        public Int32 ScaleNumbersRotation
	        {
	            get{return m_ScaleNumbersRotation;}
	            set
	            { 
	                m_ScaleNumbersRotation = value;
	                                
	            }
	        }

	        private Byte m_CapIdx = 1;
	        private Brush[] m_CapBrush = { Brushes.Black, Brushes.Black, Brushes.Black, Brushes.Black, Brushes.Black };
	        private Brush CapBrush
	        {
	            get
	            {
	                return m_CapBrush[m_CapIdx];
	            }
	            set
	            {
	                if (m_CapBrush[m_CapIdx] != value)
	                {
	                    m_CapBrush[m_CapIdx] = value;
	                    CapBrushs = m_CapBrush;
	                    drawGaugeBackground = true;
	                    //Refresh();
	                }
	            }
	        }
	        public Brush[] CapBrushs
	        {
	            get{return m_CapBrush;}
	            set{m_CapBrush = value;}
	        }

	        private String[] m_CapText = { "", "", "", "", "" };
	        public String CapText
	        {
	            get{return m_CapText[m_CapIdx];}
	            set
	            {
	                if (m_CapText[m_CapIdx] != value)
	                {
	                    m_CapText[m_CapIdx] = value;
	                    CapsText = m_CapText;
	                    drawGaugeBackground = true;
	                    //Refresh();
	                }
	            }
	        }

	        public String[] CapsText
	        {
	            get{return m_CapText;}
	            set
	            {
	                for (Int32 counter = 0; counter < 5; counter++)
	                {
	                    m_CapText[counter] = value[counter];
	                }
	            }
	        }

	        private System.Windows.Point[] m_CapPosition = { new System.Windows.Point(10, 10), new System.Windows.Point(10, 10), new System.Windows.Point(10, 10), new System.Windows.Point(10, 10), new System.Windows.Point(10, 10) };
	        public System.Windows.Point CapPosition
	        {
	            get{return m_CapPosition[m_CapIdx];}
	            set
	            {
	                if (m_CapPosition[m_CapIdx] != value)
	                {
	                    m_CapPosition[m_CapIdx] = value;
	                    CapsPosition = m_CapPosition;
	                    drawGaugeBackground = true;
	                    //Refresh();
	                }
	            }
	        }

	        public System.Windows.Point[] CapsPosition
	        {
	            get
	            {
	                return m_CapPosition;
	            }
	            set
	            {
	                m_CapPosition = value;
	            }
	        }

	        private SimpleFont m_Font = new SimpleFont("Arial", 14);
	        public SimpleFont MyFont
	        {
	            get{return m_Font;}
	            set{m_Font = value;}
	        }

	        private Brush titleBrush = Brushes.DarkSlateGray;
	        public Brush TitleBrush
	        {
	            set { titleBrush = value; }
	            get { return titleBrush; }
	        }

	        private string titleGauge = "TitleGauge";
	        public string TitleGauge
	        {
	            set { titleGauge = value; }
	            get { return titleGauge; }
	        }

	        private float titleGaugePtX = -10;
	        public float TitleGaugePtX
	        {
	            set { titleGaugePtX = value; }
	            get { return titleGaugePtX; }
	        }

	        private float titleGaugePtY = 15;
	        public float TitleGaugePtY
	        {
	            set { titleGaugePtY = value; }
	            get { return titleGaugePtY; }
	        }

	        private SimpleFont titleFontGauge = new SimpleFont("Aril", 10);        
	        public SimpleFont TitleFontGauge
	        {
	            get { return titleFontGauge; }
	            set { titleFontGauge = value; }
	        }

	        private Single m_value1;
	        public Single Value1
	        {
	            get{return m_value1;}
	            set
	            {
	                if (m_value1 != value)
	                {
	                    m_value1 = Math.Min(Math.Max(value, m_MinValue), m_MaxValue);
	                    drawGaugeBackground = true;                    
	                    
	                }
	            }
	        }

	        private Single m_value2;

	        public Single Value2
	        {
	            get{return m_value2;}
	            set
	            {
	                if (m_value2 != value)
	                {
	                    m_value2 = Math.Min(Math.Max(value, m_MinValue), m_MaxValue);
	                    drawGaugeBackground = true;                    
	                    
	                }
	            }
	        }

	        private Single m_value3;
	        public Single Value3
	        {
	            get{return m_value3;}
	            set
	            {
	                if (m_value3 != value)
	                {
	                    m_value3 = Math.Min(Math.Max(value, m_MinValue), m_MaxValue);
	                    drawGaugeBackground = true;
	                    
	                }
	            }
	        }
	        #endregion

	        #region helper

	        public void InitTitle_Gauge(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleGauge = strTitle;
	            TitleFontGauge = nFont;
	            TitleGaugePtX = nX;
	            TitleGaugePtY = nY;	            
	        }
	        #endregion

			public void InitDxBrushes(SharpDX.Direct2D1.RenderTarget renderTarget)
            {
				if (dxNeedleBrush1 != null) { dxNeedleBrush1.Dispose(); dxNeedleBrush1 = null; }
				if (dxNeedleBrush2 != null) { dxNeedleBrush2.Dispose(); dxNeedleBrush2 = null; }
				if (dxNeedleBrush3 != null) { dxNeedleBrush3.Dispose(); dxNeedleBrush3 = null; }

				if (renderTarget == null)
                {
					return;
                }

				dxNeedleBrush1 = NeedleBrush1.ToDxBrush(renderTarget);
				dxNeedleBrush2 = NeedleBrush2.ToDxBrush(renderTarget);
				dxNeedleBrush3 = NeedleBrush3.ToDxBrush(renderTarget);
			}
	    }	

		#endregion

		#region RegThermometer
	    internal class ClassThermometerBar
	    {
			#region RegHelper
			
			internal class NT7MeasureStringData
			{
				public float Height;
				public float Width;
				
				public NT7MeasureStringData()
				{
					
				}
			}
				
			
			internal class NT7Graphics
			{
				SharpDX.Direct2D1.RenderTarget rt;
			
				public NT7Graphics(SharpDX.Direct2D1.RenderTarget rt)
				{
					this.rt = rt;
				}
				
				public void DrawEllipse(Stroke s, RectangleF rect)
				{
					this.DrawEllipse(s, rect.X, rect.Y, rect.Width, rect.Height);
				}
				
				public void DrawEllipse(Stroke s, float x, float y, float w, float h)
				{
					float half = w / 2;
					float x0 = Convert.ToSingle (x + half - 1);
					float y0 = Convert.ToSingle (y + half - 1);
					SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
					SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f); 
					var brush = s.Brush.ToDxBrush(this.rt);
					this.rt.DrawEllipse(ellipse, brush,s.Width);
					brush.Dispose();brush=null;
				}
				
				public void FillEllipse(Brush b, RectangleF rect)
				{
					this.FillEllipse(b, rect.X, rect.Y, rect.Width, rect.Height);
				}
				
				public void FillEllipse(Brush b, float x, float y, float w, float h)
				{
					float half = w / 2;
					float x0 = Convert.ToSingle (x + half - 1);
					float y0 = Convert.ToSingle (y + half - 1);
					SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
					SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f); 
					var brush = b.ToDxBrush(this.rt);
					this.rt.FillEllipse(ellipse, brush);
					brush.Dispose();brush=null;
				}
				
				public void DrawRectangle(Stroke s, RectangleF rect)
				{
					this.DrawRectangle(s,rect.X, rect.Y, rect.Width, rect.Height);
				}
				
				public void DrawRectangle(Stroke s, float x, float y, float w, float h)
				{
					SharpDX.RectangleF rectf = new SharpDX.RectangleF(x, y, w, h);
					var brush = s.Brush.ToDxBrush(this.rt);
					this.rt.DrawRectangle(rectf, brush,s.Width);
					brush.Dispose();brush=null;
				}
				
				public void FillRectangle(Brush b, RectangleF rect)
				{
					this.FillRectangle(b,rect.X, rect.Y, rect.Width, rect.Height);
				}
				
				public void FillRectangle(Brush b, float x, float y, float w, float h)
				{
					SharpDX.RectangleF rectf = new SharpDX.RectangleF(x, y, w, h);
					var brush = b.ToDxBrush(this.rt);
					this.rt.FillRectangle(rectf, brush);
					brush.Dispose();brush=null;
				}
				
				public void DrawLine(Stroke s, float x1, float y1, float x2, float y2)
				{
					System.Windows.Point startPoint	= new System.Windows.Point(x1, y1);
					System.Windows.Point endPoint		= new System.Windows.Point(x2, y2);
					var brush = s.Brush.ToDxBrush(this.rt);
					this.rt.DrawLine(startPoint.ToVector2(), endPoint.ToVector2(), brush, s.Width, s.StrokeStyle);
					brush.Dispose();brush=null;
				}
				
				public void DrawString(String text, SimpleFont f, Brush b, RectangleF rect, SharpDX.DirectWrite.TextAlignment ta)
				{
					this.DrawString(text, f, b, rect.X, rect.Y, rect.Width, rect.Height, ta);
				}
				
				public void DrawString(String text, SimpleFont f, Brush b, RectangleF rect)
				{
					this.DrawString(text, f, b, rect.X, rect.Y);
				}
				
				public void DrawString(String text, SimpleFont f, Brush b, float x, float y)
				{
					this.DrawString(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading);
				}
				
				public void DrawStringRotated(String text, SimpleFont f, Brush b, float x, float y, float iAngle)
				{
					this.DrawStringRotated(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading, iAngle);
				}				
				
				public void DrawString(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta)
				{
					TextFormat textFormat		= 
						new TextFormat(
							Core.Globals.DirectWriteFactory, 
							f.Family.ToString(), 
							(f.Bold?SharpDX.DirectWrite.FontWeight.Bold:SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal, 
							SharpDX.DirectWrite.FontStretch.Normal, 
							Convert.ToSingle(f.Size)) 
							{ 
								TextAlignment = ta, 
								WordWrapping = WordWrapping.NoWrap 
							};
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,w,h);//(float)f.Size);
					
					System.Windows.Point upperTextPoint	= new System.Windows.Point(x,y);
					var brush = b.ToDxBrush(this.rt);
					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					brush.Dispose();brush=null;
				}
				
				public void DrawStringRotated(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta, float iAngle)
				{
					TextFormat textFormat		= 
						new TextFormat(
							Core.Globals.DirectWriteFactory, 
							f.Family.ToString(), 
							(f.Bold?SharpDX.DirectWrite.FontWeight.Bold:SharpDX.DirectWrite.FontWeight.Normal),
							SharpDX.DirectWrite.FontStyle.Normal, 
							SharpDX.DirectWrite.FontStretch.Normal, 
							Convert.ToSingle(f.Size))
							{ 
								TextAlignment = ta, 
								WordWrapping = WordWrapping.NoWrap 
							};
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,w,h);//(float)f.Size);
					
					System.Windows.Point upperTextPoint	= new System.Windows.Point(x,y);
								
					SharpDX.Matrix3x2 savedTransform = this.rt.Transform;
					
					this.rt.Transform = SharpDX.Matrix3x2.Rotation(iAngle, new SharpDX.Vector2(x, y));	
					var brush = b.ToDxBrush(this.rt);
					this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					brush.Dispose();brush=null;
							
					this.rt.Transform = savedTransform;																		
				}				
				
				public NT7MeasureStringData MeasureString( String text, SimpleFont f)
				{
					NT7MeasureStringData sd = new NT7MeasureStringData();
					
					TextFormat textFormat		= new TextFormat(Core.Globals.DirectWriteFactory, f.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal,
													SharpDX.DirectWrite.FontStyle.Normal, SharpDX.DirectWrite.FontStretch.Normal, Convert.ToSingle(f.Size)) 
													{ TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading, WordWrapping = WordWrapping.NoWrap };
													
					TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,400,Convert.ToSingle(f.Size));
					
													
					sd.Height = Convert.ToSingle( textLayout.Metrics.Height);
					sd.Width = Convert.ToSingle( textLayout.Metrics.Width);
													
					return sd;
				}
				
				public void FillPolygon(Brush b, System.Windows.Point[] p)
				{
					SharpDX.Direct2D1.PathGeometry	g		= null;
					SharpDX.Direct2D1.GeometrySink	sink	= null;
					
					if (sink == null)
					{
						g			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						sink		= g.Open();
						
					}
					
					sink.BeginFigure(new SharpDX.Vector2(Convert.ToSingle(p[0].X), Convert.ToSingle(p[0].Y)), SharpDX.Direct2D1.FigureBegin.Filled);
					for(int pidx = 1; pidx < p.Length; pidx++)
					{
						sink.AddLine(new SharpDX.Vector2(Convert.ToSingle(p[pidx].X), Convert.ToSingle(p[pidx].Y)));
					}
					sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
					sink.Close();
					
					if (g != null)
					{
						var brush = b.ToDxBrush(this.rt);
						this.rt.FillGeometry(g, brush); 
						brush.Dispose();brush=null;
						g.Dispose();
						sink.Dispose();
						g = null;
						sink = null;
					}
				}
				
				public void DrawPolygon(Stroke s, System.Windows.Point[] p)
				{
					SharpDX.Direct2D1.PathGeometry	g		= null;
					SharpDX.Direct2D1.GeometrySink	sink	= null;
					
					if (sink == null)
					{
						g			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						sink		= g.Open();
						
					}
					
					sink.BeginFigure(new SharpDX.Vector2(Convert.ToSingle(p[0].X) ,Convert.ToSingle(p[0].Y)), SharpDX.Direct2D1.FigureBegin.Filled);
					for(int pidx = 1; pidx < p.Length; pidx++)
					{
						sink.AddLine(new SharpDX.Vector2(Convert.ToSingle(p[pidx].X), Convert.ToSingle(p[pidx].Y)));
					}
					sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
					sink.Close();
					
					if (g != null)
					{
						var brush = s.Brush.ToDxBrush(this.rt);
						this.rt.DrawGeometry(g,brush); 
						brush.Dispose();brush=null;
						
						g.Dispose();
						sink.Dispose();
						g = null;
						sink = null;
					}
				}
			}
			#endregion

	        public ClassThermometerBar(float iHeight, float iWidth)
	        {
	            m_width = iWidth;
	            m_height = iHeight;            
	        }

			#region RegInputs
			
	        // Corner Round
	        private float cornerRadius = 5;        
	        public float CornerRadius
	        {
	            set { cornerRadius = value; }
	            get { return cornerRadius; }
	        }

	        // Temperature Value1
	        private float val1 = 0;        
	        public float Value1
	        {
	            set { val1 = value; }
	            get { return val1; }
	        }
	        // Temperature Value2
	        private float val2 = 0;        
	        public float Value2
	        {
	            set { val2 = value;  }
	            get { return val2; }
	        }
	        // Temperature Value3
	        private float val3 = 0;        
	        public float Value3
	        {
	            set { val3 = value;  }
	            get { return val3; }
	        }

	        // Bar 1 Max Value
	        private float scale1_Max = 50;        
	        public float Scale1_Max
	        {
	            set { scale1_Max = value; }
	            get { return scale1_Max; }
	        }

	        // Bar 1 Min Value
	        private float scale1_Min = -20;        
	        public float Scale1_Min
	        {
	            set { scale1_Min = value; }
	            get { return scale1_Min; }
	        }

	        // Bar 2 Max Value
	        private float scale2_Max = 50;        
	        public float Scale2_Max
	        {
	            set { scale2_Max = value; }
	            get { return scale2_Max; }
	        }

	        // Bar 2 Min Value
	        private float scale2_Min = -20;        
	        public float Scale2_Min
	        {
	            set { scale2_Min = value; }
	            get { return scale2_Min; }
	        }

	        // Bar 3 Max Value
	        private float scale3_Max = 50;        
	        public float Scale3_Max
	        {
	            set { scale3_Max = value; }
	            get { return scale3_Max; }
	        }

	        // Bar 3 Min Value
	        private float scale3_Min = -20;        
	        public float Scale3_Min
	        {
	            set { scale3_Min = value; }
	            get { return scale3_Min; }
	        }

	        // Bar 1 Margin
	        private float bar_margin_TopBottom1 = 15;        
	        public float Bar_margin_TopBottom1
	        {
	            set { bar_margin_TopBottom1 = value; }
	            get { return bar_margin_TopBottom1; }
	        }
	        // Bar 2 Margin
	        private float bar_margin_TopBottom2 = 15;
	        public float Bar_margin_TopBottom2
	        {
	            set { bar_margin_TopBottom2 = value; }
	            get { return bar_margin_TopBottom2; }
	        }
	        // Bar 3 Margin
	        private float bar_margin_TopBottom3 = 15;
	        public float Bar_margin_TopBottom3
	        {
	            set { bar_margin_TopBottom3 = value; }
	            get { return bar_margin_TopBottom3; }
	        }

	        // Current Value Font
	        private SimpleFont tempFont = new SimpleFont("Times New Roman", 13);        
	        public SimpleFont TempFont
	        {
	            set { tempFont = value; }
	            get { return tempFont; }
	        }

	        
	        private Brush titleColor = Brushes.DarkSlateGray;        
	        public Brush TitleColor
	        {
	            set { titleColor = value; }
	            get { return titleColor; }
	        }

	        //Bar1 Big scale counts
	        private int bigScale1 = 5;        
	        public int BigScale1
	        {
	            set { bigScale1 = value; }
	            get { return bigScale1; }
	        }

	        //Bar2 Big scale counts
	        private int bigScale2 = 5;        
	        public int BigScale2
	        {
	            set { bigScale2 = value; }
	            get { return bigScale2; }
	        }

	        //Bar3 Big scale counts
	        private int bigScale3 = 5;        
	        public int BigScale3
	        {
	            set { bigScale3 = value; }
	            get { return bigScale3; }
	        }

	        private string titleBar1 = "Bar1";        
	        public string TitleBar1
	        {
	            set { titleBar1 = value; }
	            get { return titleBar1; }
	        }

	        private string titleBar2 = "Bar2";
	        public string TitleBar2
	        {
	            set { titleBar2 = value; }
	            get { return titleBar2; }
	        }

	        private string titleBar3 = "Bar3";
	        public string TitleBar3
	        {
	            set { titleBar3 = value; }
	            get { return titleBar3; }
	        }

	        private float titlePtXBar1 = 15;
	        public float TitlePtXBar1
	        {
	            set { titlePtXBar1 = value; }
	            get { return titlePtXBar1; }
	        }

	        private float titlePtXBar2 = 15;
	        public float TitlePtXBar2
	        {
	            set { titlePtXBar2 = value; }
	            get { return titlePtXBar2; }
	        }

	        private float titlePtXBar3 = 15;
	        public float TitlePtXBar3
	        {
	            set { titlePtXBar3 = value; }
	            get { return titlePtXBar3; }
	        }

	        private float titlePtYBar1 = 15;
	        public float TitlePtYBar1
	        {
	            set { titlePtYBar1 = value; }
	            get { return titlePtYBar1; }
	        }

	        private float titlePtYBar2 = 15;
	        public float TitlePtYBar2
	        {
	            set { titlePtYBar2 = value; }
	            get { return titlePtYBar2; }
	        }

	        private float titlePtYBar3 = 15;
	        public float TitlePtYBar3
	        {
	            set { titlePtYBar3 = value; }
	            get { return titlePtYBar3; }
	        }

	        private SimpleFont titleFontBar1 = new SimpleFont("Aril", 14);        
	        public SimpleFont TitleFontBar1
	        {
	            get { return titleFontBar1; }
	            set { titleFontBar1 = value; }
	        }

	        private SimpleFont titleFontBar2 = new SimpleFont("Aril", 14);        
	        public SimpleFont TitleFontBar2
	        {
	            get { return titleFontBar2; }
	            set { titleFontBar2 = value; }
	        }

	        private SimpleFont titleFontBar3 = new SimpleFont("Aril", 14);        
	        public SimpleFont TitleFontBar3
	        {
	            get { return titleFontBar3; }
	            set { titleFontBar3 = value; }
	        }

	        // bar small scale counts
	        private int smallScale = 5;        
	        public int SmallScale
	        {
	            set { smallScale = value; }
	            get { return smallScale; }
	        }

	        // scale Font
	        private SimpleFont drawFont = new SimpleFont("Aril", 9);        
	        public SimpleFont DrawFont
	        {
	            get { return drawFont; }
	            set { drawFont = value; }
	        }

	        // Font Color
	        private Brush drawColor = Brushes.White;        
	        public Brush DrawColor
	        {
	            set { drawColor = value; }
	            get { return drawColor; }
	        }

	        // Outline line color
	        private Brush dialOutLineColor = Brushes.Gray;        
	        public Brush DialOutLineColor
	        {
	            set { dialOutLineColor = value; }
	            get { return dialOutLineColor; }
	        }

	        // Main BackColor
	        private Brush dialBackColor = Brushes.Gray;        
	        public Brush DialBackColor
	        {
	            set { dialBackColor = value; }
	            get { return dialBackColor; }
	        }

	        // Big Scale Color
	        private Brush bigScaleColor = Brushes.Black;        
	        public Brush BigScaleColor
	        {
	            set { bigScaleColor = value; }
	            get { return bigScaleColor; }
	        }

	        // Small Scale Color
	        private Brush smallScaleColor = Brushes.Black;        
	        public Brush SmallScaleColor
	        {
	            set { smallScaleColor = value; }
	            get { return smallScaleColor; }
	        }

	        // Value bar backColor
	        private Brush mercuryBackColor = Brushes.LightGray;        
	        public Brush MercuryBackColor
	        {
	            set { mercuryBackColor = value; }
	            get { return mercuryBackColor; }
	        }

	        // Color really Value
	        private Brush mercuryColor = Brushes.Blue;        
	        public Brush MercuryColor
	        {
	            set { mercuryColor = value; }
	            get { return mercuryColor; }
	        }
			
			#endregion

	        #region RegFunctions
	        public void InitBaseVal_Bar1(float nScaleMin, float nScaleMax, int barTopBottomMargin, int nBigscale)
	        {
	            Bar_margin_TopBottom1 = barTopBottomMargin;
	            BigScale1 = nBigscale;
	            Scale1_Min = nScaleMin;
	            Scale1_Max = nScaleMax;
	        }

	        public void InitBaseVal_Bar2(float nScaleMin, float nScaleMax, int barTopBottomMargin, int nBigscale)
	        {
	            Bar_margin_TopBottom2 = barTopBottomMargin;
	            BigScale2 = nBigscale;
	            Scale2_Min = nScaleMin;
	            Scale2_Max = nScaleMax;
	        }

	        public void InitBaseVal_Bar3(float nScaleMin, float nScaleMax, int barTopBottomMargin, int nBigscale)
	        {
	            Bar_margin_TopBottom3 = barTopBottomMargin;
	            BigScale3 = nBigscale;
	            Scale3_Min = nScaleMin;
	            Scale3_Max = nScaleMax;
	        }

	        public void InitTitle_Bar1(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleBar1 = strTitle;
	            TitleFontBar1 = nFont;
	            TitlePtXBar1 = nX;            
	            TitlePtYBar1 = nY;            
	        }

	        public void InitTitle_Bar2(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleBar2 = strTitle;
	            TitleFontBar2 = nFont;
	            TitlePtXBar2 = nX;
	            TitlePtYBar2 = nY;
	        }

	        public void InitTitle_Bar3(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleBar3 = strTitle;
	            TitleFontBar3 = nFont;
	            TitlePtXBar3 = nX;
	            TitlePtYBar3 = nY;
	        }

	        private void DrawRotatedTextAt(SharpDX.Direct2D1.RenderTarget iRenderTarget, NT7Graphics iGraphics, float angle, string txt, int x, int y, SimpleFont iFont, Brush iBrush)
	        {				
				iGraphics.DrawStringRotated(txt, iFont, iBrush, x, y, angle);
	        }
			
			#endregion
					
	        private float X;
	        private float Y;
	        private float H1;
	        private float H2;
	        private float H3;
	        private float m_width;
	        private float m_height;
	        private Stroke p, s_p;
	        //private Brush b;        
	        
	        public void ThermometerControl_Paint(SharpDX.Direct2D1.RenderTarget iRenderTarget, float originX, float originY, NinjaTrader.NinjaScript.IndicatorBase parent)
	        {
				NT7Graphics graphics = new NT7Graphics(iRenderTarget);
				
	            // truncate Values
	            if (val1 > scale1_Max)
	            {
	                val1 = scale1_Max;
	            }
	            if (val1 < scale1_Min)
	            {
	                val1 = scale1_Min;
	            }

	            if (val2 > scale2_Max)
	            {
	                val2 = scale2_Max;
	            }
	            if (val2 < scale2_Min)
	            {
	                val2 = scale2_Min;
	            }

	            if (val3 > scale3_Max)
	            {
	                val3 = scale3_Max;
	            }
	            if (val3 < scale3_Min)
	            {
	                val3 = scale3_Min;
	            }

	            //graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;            

	            X = m_width - 2;
	            Y = m_height - 2;
	            
	            float barPoint_X = X * 2 / 5;
	            float barEllipseHeight = X / (5 * CornerRadius);
	            float barRealHeight1 = Y - 2 * bar_margin_TopBottom1;
	            float barRealHeight2 = Y - 2 * bar_margin_TopBottom2;
	            float barRealHeight3 = Y - 2 * bar_margin_TopBottom3;

	            for (int i=0; i<3; i++)
	            {
	                float barMargin = 0;
	                float barRHeight = 0;
	                switch (i)
	                {
	                    case 0:
	                        barMargin = bar_margin_TopBottom1; barRHeight = barRealHeight1;
	                        break;
	                    case 1:
	                        barMargin = bar_margin_TopBottom2; barRHeight = barRealHeight2;
	                        break;
	                    case 2:
	                        barMargin = bar_margin_TopBottom3; barRHeight = barRealHeight3;
	                        break;
	                }
	                //Draw Outline
	                //@-1
	                p = new Stroke(dialOutLineColor, 2);
					
					// This draws the outlines around each one
	                //graphics.DrawLine(p, i * X, X / (2 * CornerRadius), i * X, (Y - X / (2 * CornerRadius)));
	                //graphics.DrawLine(p, (i+1) * X, X / (2 * CornerRadius), (i + 1) * X, (Y - X / (2 * CornerRadius)));
	                //e.Graphics.DrawArc(p, i * X, 0, X, X / CornerRadius, 180, 180);
	                //e.Graphics.DrawArc(p, i * X, (Y - X / CornerRadius), X, X / CornerRadius, 0, 180);							
					

	                //Draw BackColor
	                float nX = X - 8;
	                float nY = Y - 8;                
//	                b = this.dialBackColor;
	                int dx = 4;
	                int dy = 4;                
	                graphics.FillRectangle(dialBackColor, originX+ (2 * i + 1) * dx + i * nX, nX / (2 * CornerRadius) + dy +originY, nX, (nY - nX / (2 * CornerRadius) - dy));

					// This draws the ellipse around each bar
	                //graphics.FillEllipse(b, (2 * i + 1) * dx + i * nX, dy, nX, nX / CornerRadius);
	               	//graphics.FillEllipse(b, (2 * i + 1) * dx + i * nX, (nY - nX / CornerRadius) + dy, nX, nX / CornerRadius);

	                //Draw Value background                
	                //graphics.FillEllipse(Brushes.Green, i * X + barPoint_X, barMargin - 4, X / 5, barEllipseHeight);                
	                //graphics.FillEllipse(this.mercuryColor, i * X + barPoint_X, (Y - barMargin), X / 5, barEllipseHeight);

					RectangleF gradientRect0 = new RectangleF(originX+ i * X + barPoint_X, (barMargin + barEllipseHeight / 2) +originY, X / 5, barRHeight);														
					LinearGradientBrush lgb0 = new LinearGradientBrush();
					
					lgb0.StartPoint = new System.Windows.Point(gradientRect0.TopLeft.X, gradientRect0.TopLeft.Y);
					lgb0.EndPoint = new System.Windows.Point(gradientRect0.BottomRight.X,gradientRect0.BottomRight.Y);
					
					GradientStop redGS = new GradientStop(Colors.Red, 0.75);
					lgb0.GradientStops.Add(redGS);

					GradientStop yellowGS = new GradientStop(Colors.Yellow, 0.5);
					lgb0.GradientStops.Add(yellowGS);		
					
					GradientStop greenGS = new GradientStop(Colors.Green, 0.25);
				    lgb0.GradientStops.Add(greenGS);

		            graphics.FillRectangle(lgb0, originX+ i * X + barPoint_X, (barMargin + barEllipseHeight / 2) +originY, X / 5, barRHeight);						
	            }							
	                        
	            //StringFormat format = new StringFormat();            
	            p = new Stroke(bigScaleColor, 2);           
	            s_p = new Stroke(smallScaleColor, 1);       
//	            Brush drawBrush = drawColor.Clone();
//				drawBrush.Freeze();
	            //format.Alignment = StringAlignment.Near;         

				float rotationAngle = -1.57079633f;
	            // Position current value           
	            
	            //@-1
	            int nScaleHeight1 = (int)(scale1_Max - scale1_Min);            
//parent.Print("\nnScaleHeight1: "+nScaleHeight1+" = scale1_Max/Min: "+scale1_Max+" - "+scale1_Min);
	            float smallInterval1 = Convert.ToSingle(barRealHeight1) / nScaleHeight1;
//parent.Print("\nsmallInterval1: "+smallInterval1+" = barRealHeight1/nScaleHeight1: "+barRealHeight1+" / "+nScaleHeight1);
	            H1 = barRealHeight1 * (val1 - scale1_Min) / (scale1_Max - scale1_Min);
//parent.Print("H1: "+H1+" = barRealHeight: "+barRealHeight1+" * (val1: "+val1+" - scale1_Min: "+scale1_Min+") / (scale1_Max-Min: "+scale1_Max+" - "+scale1_Min);
	            float absValueHeight1 = barRealHeight1 - H1;
//parent.Print("AbsValueH1: "+absValueHeight1+" = barRealHeight1-H1: "+barRealHeight1+" - "+H1);
	            //Draw current value
	            if (absValueHeight1 == 0) absValueHeight1 = 1f;
								
				RectangleF gradientRect = new RectangleF(originX+ 0 * X + barPoint_X, bar_margin_TopBottom1 +originY, X / 5, absValueHeight1);				
				LinearGradientBrush lgb1 = 
					new LinearGradientBrush(
						Colors.LightGray, 
						Colors.Gray, 
						new System.Windows.Point(gradientRect.TopLeft.X, gradientRect.TopLeft.Y),
						new System.Windows.Point(gradientRect.BottomRight.X,gradientRect.BottomRight.Y));
				
	            graphics.FillRectangle(lgb1,originX+  0 * X + barPoint_X, bar_margin_TopBottom1 +originY, X / 5, absValueHeight1);


	            //@-2
	            int nScaleHeight2 = (int)(scale2_Max - scale2_Min);
	            float smallInterval2 = Convert.ToSingle(barRealHeight2) / nScaleHeight2;

	            H2 = barRealHeight2 * (val2 - scale2_Min) / (scale2_Max - scale2_Min);
	            float absValueHeight2 = barRealHeight2 - H2;
	            //Draw current value
	            if (absValueHeight2 == 0) absValueHeight2 = 1f;
				
				RectangleF gradientRect2 = new RectangleF(originX+ 1 * X + barPoint_X, bar_margin_TopBottom2 +originY, X / 5, absValueHeight2);				
				LinearGradientBrush lgb2 = 
					new LinearGradientBrush(
						Colors.LightGray, 
						Colors.Gray, 
						new System.Windows.Point(gradientRect2.TopLeft.X, gradientRect2.TopLeft.Y),
						new System.Windows.Point(gradientRect2.BottomRight.X,gradientRect2.BottomRight.Y));
				
	            graphics.FillRectangle(lgb2, originX+ 1 * X + barPoint_X, bar_margin_TopBottom2 +originY, X / 5, absValueHeight2);

	            //@-3            
	            int nScaleHeight3 = (int)(scale3_Max - scale3_Min);
	            float smallInterval3 = Convert.ToSingle(barRealHeight3) / nScaleHeight3;

	            H3 = barRealHeight3 * (val3 - scale3_Min) / (scale3_Max - scale3_Min);
	            float absValueHeight3 = barRealHeight3 - H3;
	            //Draw current value
	            if (absValueHeight3 == 0) absValueHeight3 = 1f;
				
				RectangleF gradientRect3 = new RectangleF(originX+ 2 * X + barPoint_X, bar_margin_TopBottom3 +originY, X / 5, absValueHeight3);				
				LinearGradientBrush lgb3 = 
					new LinearGradientBrush(
						Colors.LightGray, 
						Colors.Gray, 
						new System.Windows.Point(gradientRect3.TopLeft.X, gradientRect3.TopLeft.Y),
						new System.Windows.Point(gradientRect3.BottomRight.X,gradientRect3.BottomRight.Y));
				
	            graphics.FillRectangle(lgb3, originX+ 2 * X + barPoint_X, bar_margin_TopBottom3 +originY, X / 5, absValueHeight3);	          
	             
	            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	            //@-1
	            int tempNum1 = (int)scale1_Max;            
	            for (int i = 0; i <= nScaleHeight1; i++)
	            {
	                float d = bigScale1 / smallScale;
	                if (tempNum1 % d == 0)
	                {
	                    float s_s_y = bar_margin_TopBottom1 + i * smallInterval1 +originY;
	                    graphics.DrawLine(s_p, originX+ 0 * X + barPoint_X + X / 15, s_s_y, originX+ 0 * X + barPoint_X + 2 * X / 15, s_s_y);

	                    if (tempNum1 % bigScale1 == 0)
	                    {                        
	                        graphics.DrawLine(p, originX+ 0 * X + barPoint_X, s_s_y, originX+ 0 * X + barPoint_X + X / 5, s_s_y); // ??? ????????? ?????????  
	                        
							NT7MeasureStringData szTxt = graphics.MeasureString(tempNum1.ToString(), drawFont);
	                        DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, tempNum1.ToString(), (int)(originX+ 0 * X + barPoint_X - 3 * X / 12), (int)(s_s_y + szTxt.Width / 2), drawFont, drawColor);
	                    }
	                }
	                tempNum1 -= 1;    // Scale Number
	            }

	            //@-2
	            int tempNum2 = (int)scale2_Max;
	            for (int i = 0; i <= nScaleHeight2; i++)
	            {
	                float d = bigScale2 / smallScale;
	                if (tempNum2 % d == 0)
	                {
	                    float s_s_y = bar_margin_TopBottom2 + i * smallInterval2 +originY;
	                    graphics.DrawLine(s_p, originX+ 1 * X + barPoint_X + X / 15, s_s_y, originX+ 1 * X + barPoint_X + 2 * X / 15, s_s_y);

	                    if (tempNum2 % bigScale2 == 0)
	                    {
	                        graphics.DrawLine(p, originX+ 1 * X + barPoint_X, s_s_y, originX+ 1 * X + barPoint_X + X / 5, s_s_y); // ??? ????????? ?????????  

							NT7MeasureStringData szTxt = graphics.MeasureString(tempNum2.ToString(), drawFont);							
	                        DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, tempNum2.ToString(), (int)(originX+ 1 * X + barPoint_X - 3 * X / 12), (int)(s_s_y + szTxt.Width / 2), drawFont, drawColor);
	                    }
	                }
	                tempNum2 -= 1;    // Scale Number
	            }

	            //@-3
	            int tempNum3 = (int)scale3_Max;
	            for (int i = 0; i <= nScaleHeight3; i++)
	            {
	                float d = bigScale3 / smallScale;
	                if (tempNum3 % d == 0)
	                {
	                    float s_s_y = bar_margin_TopBottom3 + i * smallInterval3 +originY;
	                    graphics.DrawLine(s_p, originX+ 2 * X + barPoint_X + X / 15, s_s_y, originX+ 2 * X + barPoint_X + 2 * X / 15, s_s_y);

	                    if (tempNum3 % bigScale3 == 0)
	                    {
	                        graphics.DrawLine(p, originX+ 2 * X + barPoint_X, s_s_y, originX+ 2 * X + barPoint_X + X / 5, s_s_y); // ??? ????????? ?????????  

							NT7MeasureStringData szTxt = graphics.MeasureString(tempNum3.ToString(), drawFont);
							
	                        DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, tempNum3.ToString(), (int)(originX+ 2 * X + barPoint_X - 3 * X / 12), (int)(s_s_y + szTxt.Width / 2), drawFont, drawColor);
	                    }
	                }
	                tempNum3 -= 1;    // Scale Number
	            }


	            //Draw Title
	            //@-1            
	            NT7MeasureStringData szTitle1 = graphics.MeasureString(titleBar1.ToString(), titleFontBar1);
	            DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, titleBar1.ToString(), (int)(originX+ 0 * X + barPoint_X + titlePtXBar1 - 1), (int)(Y/2 + titlePtYBar1 + szTitle1.Width / 2 +originY), titleFontBar1, titleColor);
	            //@-2
	            NT7MeasureStringData szTitle2 = graphics.MeasureString(titleBar2.ToString(), titleFontBar2);
	            DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, titleBar2.ToString(), (int)(originX+ 1 * X + barPoint_X + titlePtXBar2 - 1), (int)(Y / 2 + titlePtYBar2 + szTitle2.Width / 2 +originY), titleFontBar2, titleColor);
	            //@-3
	            NT7MeasureStringData szTitle3 = graphics.MeasureString(titleBar3.ToString(), titleFontBar3);
	            DrawRotatedTextAt(iRenderTarget, graphics, rotationAngle, titleBar3.ToString(), (int)(originX+ 2 * X + barPoint_X + titlePtXBar3 - 1), (int)(Y / 2 + titlePtYBar3 + szTitle3.Width / 2 +originY), titleFontBar3, titleColor);
	            
	            //Draw Polygon

	            //@-1
	            System.Windows.Point[] pt1 = new System.Windows.Point[] {
	                new System.Windows.Point((int)(originX+ 0 * X + barPoint_X + X / 10), (int)(bar_margin_TopBottom1 + absValueHeight1 +originY)),
	                new System.Windows.Point((int)(originX+ 0 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom1 + absValueHeight1 - X / 15 +originY)),
	                new System.Windows.Point((int)(originX+ 0 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom1 + absValueHeight1 + X / 15 +originY)) };
	            graphics.FillPolygon(Brushes.Crimson, pt1);
	            //@-2
	            System.Windows.Point[] pt2 = new System.Windows.Point[] {
	                new System.Windows.Point((int)(originX+ 1 * X + barPoint_X + X / 10), (int)(bar_margin_TopBottom2 + absValueHeight2 +originY)),
	                new System.Windows.Point((int)(originX+ 1 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom2 + absValueHeight2 - X / 15 +originY)),
	                new System.Windows.Point((int)(originX+ 1 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom2 + absValueHeight2 + X / 15 +originY)) };
	            graphics.FillPolygon(Brushes.Crimson, pt2);
	            //@-3
	            System.Windows.Point[] pt3 = new System.Windows.Point[] {
	                new System.Windows.Point((int)(originX+ 2 * X + barPoint_X + X / 10), (int)(bar_margin_TopBottom3 + absValueHeight3 +originY)),
	                new System.Windows.Point((int)(originX+ 2 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom3 + absValueHeight3 - X / 15 +originY)),
	                new System.Windows.Point((int)(originX+ 2 * X + barPoint_X + X / 10 + X / 5), (int)(bar_margin_TopBottom3 + absValueHeight3 + X / 15 +originY)) };
	            graphics.FillPolygon(Brushes.Crimson, pt3);
	        }
				
			private double DegreeToRadian(double angle)
			{
				return Math.PI * angle / 180.0;
			}
			
			private double RadianToDegree(double angle)
			{
				return angle * (180.0 / Math.PI);
			}			

	       
	    }		
		#endregion

        private const string productName = "ARC_VSR_Arb";

        public override string DisplayName {	get{return productName;}	}

        private const string VERSION = "v1.11 12.Apr.2022";
		//1.11 introduced the Infusionsoft licensing system (transitioning away from the fixed license key system)
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		#region RegBarVisualInputs
		
		private SimpleFont iBarFont = new SimpleFont("Arial Black", 11){ Size = 11, Bold = true };

		private ARC_VSR_Arb_CalcModels iCalculationModel = ARC_VSR_Arb_CalcModels.Version2;
        [Display(Order = 10, Name = "Calc Model", Description = "", GroupName = "Visual Parameters")]       
		public ARC_VSR_Arb_CalcModels CalculationModel
		{
            get { return iCalculationModel; }
            set { iCalculationModel = value; }
        }

		private ARC_VSR_Arb_Locations iGraphicLocation = ARC_VSR_Arb_Locations.TopLeft;
        [Display(Order = 20, Name = "Location", Description = "", GroupName = "Visual Parameters")]       
		public ARC_VSR_Arb_Locations GraphicLocation 
		{
            get { return iGraphicLocation; }
            set { iGraphicLocation = value; }
        }
		private int pGraphicSize = 8;
		[Display(Order = 30, Name = "Size", Description = "1 to 10", GroupName = "Visual Parameters")]       
		public int GraphicSize
		{
            get { return pGraphicSize; }
            set { pGraphicSize = Math.Max(1,Math.Min(10,value)); }
        }

		private bool pEnableGradientHisto = false;
		[Display(Order = 50, Name = "Enable Gradient histo?", Description = "Use a gradient (if your computer supports it)", GroupName = "Visual Parameters")]       
		public bool EnableGradientHisto
		{
            get { return pEnableGradientHisto; }
            set { pEnableGradientHisto = value; }
        }
		private Brush pSolidHistoColor = Brushes.Yellow;
		[XmlIgnore()]
		[Display(Order = 60, Name = "Solid Histo Color", Description = "", GroupName = "Visual Parameters")]       
		public Brush SolidHistoColor
		{
		    get { return pSolidHistoColor; }
		    set { pSolidHistoColor = value; }
		}
					[Browsable(false)]
					public string pSolidHistoColorSerialize
					{
						get { return Serialize.BrushToString(pSolidHistoColor); }
						set { pSolidHistoColor = Serialize.StringToBrush(value); }
					}

		#endregion

		#region RegGaugeVisualInputs

		private SimpleFont iTextFontGauge = new SimpleFont("Arial Black", 14){ Size = 14, Bold = true };

		private Brush iBackgroundColor = Brushes.Black;
		[XmlIgnore()]
        [Display(Name = "Background Color", Description = "", GroupName = "Visual Parameters")]       
		public Brush BackgroundColor
        {
            get { return iBackgroundColor; }
            set { iBackgroundColor = value; }
        }
				[Browsable(false)]
				public string BackgroundColorSerialize {get { return Serialize.BrushToString(iBackgroundColor); } set { iBackgroundColor = Serialize.StringToBrush(value); }}		
		private float iBackgroundOpacity = 90f;
		[XmlIgnore()]
        [Display(Name = "Background Opacity", Description = "", GroupName = "Visual Parameters")]       
		public float BackgroundOpacity
        {
            get { return iBackgroundOpacity; }
            set { iBackgroundOpacity = Math.Max(0f,Math.Min(100f,value)); }
        }
		private Brush iTextColor = Brushes.White;
		[XmlIgnore()]
        [Display(Name = "Text Color", Description = "", GroupName = "Visual Parameters")]       
		public Brush TextColor
        {
            get { return iTextColor; }
            set { iTextColor = value; }
        }
				[Browsable(false)]
				public string TextColorSerialize {get { return Serialize.BrushToString(iTextColor); }set { iTextColor = Serialize.StringToBrush(value); }}

		private string pButtonText = "VSR Arb";
        [Display(Name = "Button text", Description = "", GroupName = "Visual Parameters")]       
		public string ButtonText
        {
            get { return pButtonText; }
            set { pButtonText = value; }
        }
		#endregion

		#region RegSensitivity

		private int iRangeSpeedSensitivity = 1;
//		[Display(Order = 10, Name = "Range Sensitivity", Description = "", GroupName = "Sensitivity")]       
//		public int RangeSpeedSensitivity
//        {
//            get { return iRangeSpeedSensitivity; }
//            set { iRangeSpeedSensitivity = Math.Max(1, value); }
//        }

		private ARC_VSR_Arb_ScaleType pScaleType = ARC_VSR_Arb_ScaleType.Percentage;
		[RefreshProperties(RefreshProperties.All)] // Needed to refresh the property grid when the value changes
		[Display(Order = 20, Name = "Scale", Description = "", GroupName = "Sensitivity")]       
		public ARC_VSR_Arb_ScaleType ScaleType
        {
            get { return pScaleType; }
            set { pScaleType = value; }
        }

		#endregion

		#region VolumeArb Alerts

		private bool pEnableVolumeArbSignal = true;
		[Display(Order = 10, Name = "Enable", Description = "", GroupName = "Volume Arb Alert")]       
		public bool EnableVolumeArbSignal
        {
            get { return pEnableVolumeArbSignal; }
            set { pEnableVolumeArbSignal = value; }
        }

		#region -- Value based thresholds --
		private int iVArb_SpeedThreshold = 20; 
		[Display(Order = 20, Name = "Speed Threshold <", Description = "Speed must be below this value to trigger alert", GroupName = "Volume Arb Alert")]       
		public int VArb_SpeedThreshold
		{
		    get { return iVArb_SpeedThreshold; }
		    set { iVArb_SpeedThreshold = value; }
		}		
		private int iVArb_RangeThreshold = 20; 
		[Display(Order = 30, Name = "Range Threshold <", Description = "Range must be below this value to trigger alert", GroupName = "Volume Arb Alert")]       
		public int VArb_RangeThreshold
		{
		    get { return iVArb_RangeThreshold; }
		    set { iVArb_RangeThreshold = value; }
		}
		private int iVArb_VolumeThreshold = 150; 
		[Display(Order = 40, Name = "Volume Threshold >", Description = "Volume must be ABOVE this value to trigger alert", GroupName = "Volume Arb Alert")]       
		public int VArb_VolumeThreshold
		{
			get { return iVArb_VolumeThreshold; }
			set { iVArb_VolumeThreshold = value; }
		}
		#endregion

		#region -- Pct based thresholds --
		private int iVArb_SpeedThresholdPct = 45;
		[Display(Order = 50, Name = "Speed Threshold % <", Description = "Speed must be below this value to trigger alert", GroupName = "Volume Arb Alert")]       
		public int VArb_SpeedThresholdPct
		{
		    get { return iVArb_SpeedThresholdPct; }
		    set { iVArb_SpeedThresholdPct = value; }
		}
		private int iVArb_RangeThresholdPct = 45;
		[Display(Order = 60, Name = "Range Threshold % <", Description = "Range must be below this value to trigger alert", GroupName = "Volume Arb Alert")]       
		public int VArb_RangeThresholdPct
		{
		    get { return iVArb_RangeThresholdPct; }
		    set { iVArb_RangeThresholdPct = value; }
		}
		private int iVArb_VolumeThresholdPct = 85;
		[Display(Order = 70, Name = "Volume Threshold % >", Description = "Volume must be ABOVE this value to trigger alert", GroupName = "Volume Arb Alert")]       
		public int VArb_VolumeThresholdPct
		{
		    get { return iVArb_VolumeThresholdPct; }
		    set { iVArb_VolumeThresholdPct = value; }
		}
		#endregion

		private string iVArb_SoundAlert = "SOUND OFF"; 
		[TypeConverter(typeof(LoadSoundFileList))]
		[Display(Order = 80, Name = "Sound File", Description = "", GroupName = "Volume Arb Alert")]
		public string VArb_SoundAlert
		{
		    get { return iVArb_SoundAlert; }
		    set { iVArb_SoundAlert = value; }
		}		
		private ARC_VSR_Arb_ChartMarkers pVArb_ChartMarker = ARC_VSR_Arb_ChartMarkers.None;
//		[Display(Order = 90, Name = "Chart Marker", Description = "Chart marker type", GroupName = "Volume Arb Alert")]       
//		public ARC_VSR_Arb_ChartMarkers VArb_ChartMarker
//		{
//			get { return pVArb_ChartMarker; }
//			set { pVArb_ChartMarker = value; }
//		}
		private Brush pVArb_MarkerColor = Brushes.Yellow;
//		[XmlIgnore()]
//		[Display(Order = 100, Name = "Marker Color", Description = "", GroupName = "Volume Arb Alert")]
//		public Brush VArb_MarkerColor
//		{
//		    get { return pVArb_MarkerColor; }
//		    set { pVArb_MarkerColor = value; }
//		}
//					[Browsable(false)]
//					public string pVArb_MarkerColorSerialize
//					{get { return Serialize.BrushToString(pVArb_MarkerColor); }set { pVArb_MarkerColor = Serialize.StringToBrush(value); }}

		private Brush pVArb_RacingStripeColor = Brushes.White;
		[XmlIgnore()]
		[Display(Order = 110, Name = "Racing Stripe Color", Description = "", GroupName = "Volume Arb Alert")]
		public Brush VArb_RacingStripeColor
		{
		    get { return pVArb_RacingStripeColor; }
		    set { pVArb_RacingStripeColor = value; }
		}
					[Browsable(false)]
					public string pVArb_RacingStripeColorSerialize
					{get { return Serialize.BrushToString(pVArb_RacingStripeColor); }set { pVArb_RacingStripeColor = Serialize.StringToBrush(value); }}
		#endregion

		#region Range Arb Alerts
		private bool pEnableRArbSignal = true;
		[Display(Order = 10, Name = "Enable", Description = "", GroupName = "Range Arb Alert")]       
		public bool EnableRArbSignal
        {
            get { return pEnableRArbSignal; }
            set { pEnableRArbSignal = value; }
        }

		#region -- Value based thresholds --
		private int iRArb_SpeedThreshold = 20; 
		[Display(Order = 20, Name = "Speed Threshold <", Description = "Speed must be below this value to trigger alert", GroupName = "Range Arb Alert")]       
		public int RArb_SpeedThreshold
		{
		    get { return iRArb_SpeedThreshold; }
		    set { iRArb_SpeedThreshold = value; }
		}
		private int iRArb_RangeThreshold = 80; 
		[Display(Order = 30, Name = "Range Threshold >", Description = "Range must be ABOVE this value to trigger alert", GroupName = "Range Arb Alert")]       
		public int RArb_RangeThreshold
		{
		    get { return iRArb_RangeThreshold; }
		    set { iRArb_RangeThreshold = value; }
		}
		private int iRArb_VolumeThreshold = 100; 
		[Display(Order = 40, Name = "Volume Threshold <", Description = "Volume must be below this value to trigger alert", GroupName = "Range Arb Alert")]       
		public int RArb_VolumeThreshold
		{
		    get { return iRArb_VolumeThreshold; }
		    set { iRArb_VolumeThreshold = value; }
		}
		#endregion

		#region -- Pct based thresholds --
		private int iRArb_SpeedThresholdPct = 40;
		[Display(Order = 50, Name = "Speed Threshold % <", Description = "Speed must be below this value to trigger alert", GroupName = "Range Arb Alert")]       
		public int RArb_SpeedThresholdPct
		{
		    get { return iRArb_SpeedThresholdPct; }
		    set { iRArb_SpeedThresholdPct = value; }
		}
		private int iRArb_RangeThresholdPct = 80;
		[Display(Order = 60, Name = "Range Threshold % >", Description = "Range must be ABOVE this value to trigger alert", GroupName = "Range Arb Alert")]       
		public int RArb_RangeThresholdPct
		{
		    get { return iRArb_RangeThresholdPct; }
		    set { iRArb_RangeThresholdPct = value; }
		}
		private int iRArb_VolumeThresholdPct = 40;
		[Display(Order = 70, Name = "Volume Threshold % <", Description = "Volume must be below this value to trigger alert", GroupName = "Range Arb Alert")]       
		public int RArb_VolumeThresholdPct
		{
		    get { return iRArb_VolumeThresholdPct; }
		    set { iRArb_VolumeThresholdPct = value; }
		}
		#endregion

		private string iRArb_SoundAlert = "SOUND OFF"; 
		[TypeConverter(typeof(LoadSoundFileList))]
		[Display(Order = 80, Name = "Sound File", Description = "", GroupName = "Range Arb Alert")]
		public string RArb_SoundAlert
		{
		    get { return iRArb_SoundAlert; }
		    set { iRArb_SoundAlert = value; }
		}		

		private ARC_VSR_Arb_ChartMarkers pRArb_ChartMarker = ARC_VSR_Arb_ChartMarkers.None;
//		[Display(Order = 90, Name = "Chart Marker", Description = "Chart marker type", GroupName = "Range Arb Alert")]       
//		public ARC_VSR_Arb_ChartMarkers RArb_ChartMarker
//		{
//			get { return pRArb_ChartMarker; }
//			set { pRArb_ChartMarker = value; }
//		}
		private Brush pRArb_MarkerColor = Brushes.Yellow;
//		[XmlIgnore()]
//		[Display(Order = 100, Name = "Marker Color", Description = "", GroupName = "Range Arb Alert")]
//		public Brush RArb_MarkerColor
//		{
//		    get { return pRArb_MarkerColor; }
//		    set { pRArb_MarkerColor = value; }
//		}
//					[Browsable(false)]
//					public string pRArb_MarkerColorSerialize
//					{get { return Serialize.BrushToString(pRArb_MarkerColor); }set { pRArb_MarkerColor = Serialize.StringToBrush(value); }}

		private Brush pRArb_RacingStripeColor = Brushes.White;
		[XmlIgnore()]
		[Display(Order = 110, Name = "Racing Stripe Color", Description = "", GroupName = "Range Arb Alert")]
		public Brush RArb_RacingStripeColor
		{
		    get { return pRArb_RacingStripeColor; }
		    set { pRArb_RacingStripeColor = value; }
		}
					[Browsable(false)]
					public string pRArb_RacingStripeColorSerialize
					{get { return Serialize.BrushToString(pRArb_RacingStripeColor); }set { pRArb_RacingStripeColor = Serialize.StringToBrush(value); }}
		#endregion

		#region Speed Arb Alerts

		private bool pEnableSpeedArbSignal = true;
		[Display(Order = 10, Name = "Enable", Description = "", GroupName = "Speed Arb Alert")]       
		public bool EnableSpeedArbSignal
        {
            get { return pEnableSpeedArbSignal; }
            set { pEnableSpeedArbSignal = value; }
        }

		#region -- Value based thresholds --
		private int iSArb_SpeedThreshold = 80; 
		[Display(Order = 20, Name = "Speed Threshold >", Description = "Speed must be ABOVE this value to trigger alert", GroupName = "Speed Arb Alert")]       
		public int SArb_SpeedThreshold
		{
		    get { return iSArb_SpeedThreshold; }
		    set { iSArb_SpeedThreshold = value; }
		}		
		private int iSArb_RangeThreshold = 20; 
		[Display(Order = 30, Name = "Range Threshold <", Description = "Range must be below this value to trigger alert", GroupName = "Speed Arb Alert")]       
		public int SArb_RangeThreshold
		{
		    get { return iSArb_RangeThreshold; }
		    set { iSArb_RangeThreshold = value; }
		}	
		private int iSArb_VolumeThreshold = 100; 
		[Display(Order = 40, Name = "Volume Threshold <", Description = "Volume must be below this value to trigger alert", GroupName = "Speed Arb Alert")]       
		public int SArb_VolumeThreshold
		{
		    get { return iSArb_VolumeThreshold; }
		    set { iSArb_VolumeThreshold = value; }
		}
		#endregion

		#region -- Pct based thresholds --
		private int iSArb_SpeedThresholdPct = 60;
		[Display(Order = 50, Name = "Speed Threshold % >", Description = "Speed must be ABVOVE this value to trigger alert", GroupName = "Speed Arb Alert")]       
		public int SArb_SpeedThresholdPct
		{
		    get { return iSArb_SpeedThresholdPct; }
		    set { iSArb_SpeedThresholdPct = value; }
		}
		private int iSArb_RangeThresholdPct = 40;
		[Display(Order = 60, Name = "Range Threshold % <", Description = "Range must be below this value to trigger alert", GroupName = "Speed Arb Alert")]       
		public int SArb_RangeThresholdPct
		{
		    get { return iSArb_RangeThresholdPct; }
		    set { iSArb_RangeThresholdPct = value; }
		}
		private int iSArb_VolumeThresholdPct = 40;
		[Display(Order = 70, Name = "Volume Threshold % <", Description = "Volume must be below this value to trigger alert", GroupName = "Speed Arb Alert")]       
		public int SArb_VolumeThresholdPct
		{
		    get { return iSArb_VolumeThresholdPct; }
		    set { iSArb_VolumeThresholdPct = value; }
		}
		#endregion

		private string iSArb_SoundAlert = "SOUND OFF"; 
		[TypeConverter(typeof(LoadSoundFileList))]
		[Display(Order = 80, Name = "Sound File", Description = "", GroupName = "Speed Arb Alert")]
		public string SArb_SoundAlert
		{
		    get { return iSArb_SoundAlert; }
		    set { iSArb_SoundAlert = value; }
		}

		private ARC_VSR_Arb_ChartMarkers pSArb_ChartMarker = ARC_VSR_Arb_ChartMarkers.None;
//		[Display(Order = 90, Name = "Chart Marker", Description = "Chart marker type", GroupName = "Speed Arb Alert")]       
//		public ARC_VSR_Arb_ChartMarkers SArb_ChartMarker
//		{
//			get { return pSArb_ChartMarker; }
//			set { pSArb_ChartMarker = value; }
//		}
		private Brush pSArb_MarkerColor = Brushes.Yellow;
//		[XmlIgnore()]
//		[Display(Order = 100, Name = "Marker Color", Description = "", GroupName = "Speed Arb Alert")]
//		public Brush SArb_MarkerColor
//		{
//		    get { return pSArb_MarkerColor; }
//		    set { pSArb_MarkerColor = value; }
//		}
//					[Browsable(false)]
//					public string pSArb_MarkerColorSerialize
//					{get { return Serialize.BrushToString(pSArb_MarkerColor); }set { pSArb_MarkerColor = Serialize.StringToBrush(value); }}

		private Brush pSArb_RacingStripeColor = Brushes.White;
		[XmlIgnore()]
		[Display(Order = 110, Name = "Racing Stripe Color", Description = "", GroupName = "Speed Arb Alert")]
		public Brush SArb_RacingStripeColor
		{
		    get { return pSArb_RacingStripeColor; }
		    set { pSArb_RacingStripeColor = value; }
		}
					[Browsable(false)]
					public string pSArb_RacingStripeColorSerialize
					{get { return Serialize.BrushToString(pSArb_RacingStripeColor); }set { pSArb_RacingStripeColor = Serialize.StringToBrush(value); }}

		#endregion

		#region -- Toolbar --
		private string toolbarname = "ARC_VSR_Arb_Toolbar", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;

		private Menu MenuControlContainer;
		private MenuItem MenuControl, miVolArbOnOff, miSpeedArbOnOff, miRangeArbOnOff;
		private Label lbl_VArb_VolumeThreshold, lbl_VArb_SpeedThreshold, lbl_VArb_RangeThreshold;
		private Label lbl_SArb_VolumeThreshold, lbl_SArb_SpeedThreshold, lbl_SArb_RangeThreshold;
		private Label lbl_RArb_VolumeThreshold, lbl_RArb_SpeedThreshold, lbl_RArb_RangeThreshold;
		private TextBox nud_VArb_VolumeThreshold, nud_VArb_SpeedThreshold, nud_VArb_RangeThreshold;
		private TextBox nud_SArb_VolumeThreshold, nud_SArb_SpeedThreshold, nud_SArb_RangeThreshold;
		private TextBox nud_RArb_VolumeThreshold, nud_RArb_SpeedThreshold, nud_RArb_RangeThreshold;
		private MenuItem miRecalculate1;
		#endregion

		private ARC_VSRRange  indRange;
		private ARC_VSRVolume indVolume;		
		private ARC_VSRSpeed  indSpeed;		

//		private ClassGauge CG = null;
		private ClassThermometerBar CT = null;		

		private bool bGraphicsInitialized;

		private Brush backBrush;
		private Stroke backPen;

		private Series<double> sExtrnRange, sExtrnVolume, sExtrnSpeed;

		private int idTag;			
		private bool bCanAlertTrigger;


	#region OnStateChange

	protected override void OnStateChange()
	{
		switch (State)
		{
			case State.SetDefaults:
				IsOverlay = true;
				this.Calculate = Calculate.OnEachTick;            
				this.ArePlotsConfigurable = false;
				this.Name = productName;//string.Format("{0} {1} ", productName, productVersion);

				break;

			case State.Configure:
				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion
				this.idTag = 0;
				this.bGraphicsInitialized = false;

				string bts = "MINUTES";
				if(BarsArray[0].BarsType.BuiltFrom == BarsPeriodType.Tick)
					bts = "SECONDS";

				VOL_SCALE_MAX = (iCalculationModel == ARC_VSR_Arb_CalcModels.Version2 || this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage) ? 100f : Convert.ToInt32(VOL_SCALE_MAX);

				this.indRange = ARC_VSRRange(bts, iCalculationModel==ARC_VSR_Arb_CalcModels.Version1 ? "A": "B");
				this.indRange.MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				this.indRange.key = 10812655;			
				this.indRange.iAveragePeriod = this.iRangeSpeedSensitivity;

				this.indVolume = ARC_VSRVolume(bts, iCalculationModel==ARC_VSR_Arb_CalcModels.Version1 ? "A": "B");
				this.indVolume.MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				this.indVolume.key = 10812655;
					
				this.indSpeed = ARC_VSRSpeed(bts, iCalculationModel==ARC_VSR_Arb_CalcModels.Version1 ? "A": "B");
				this.indSpeed.MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				this.indSpeed.iAveragePeriod = this.iRangeSpeedSensitivity;
				this.indSpeed.key = 10812655;						
				break;

			case State.DataLoaded:

				#region -- Add Custom Toolbar --
				if (!isToolBarButtonAdded && ChartControl != null)
				{

					Dispatcher.BeginInvoke(new Action(() =>
					{
						ChartControl.AllowDrop = false;
						chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
						if (chartWindow == null) return;

						foreach (DependencyObject item in chartWindow.MainMenu) if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

						if (!isToolBarButtonAdded)
						{
							indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Hidden };

							addToolBar();

							chartWindow.MainMenu.Add(indytoolbar);
							chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

							foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
							System.Windows.Automation.AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
						}
					}));
				}
				#endregion

				this.backBrush	= this.iBackgroundColor.Clone();
				this.backBrush.Opacity = iBackgroundOpacity / 100f;
				this.backBrush.Freeze();
				this.backPen = new Stroke(this.iBackgroundColor);			
									                   
				this.sExtrnRange  = new Series<double>(this, MaximumBarsLookBack.Infinite);
				this.sExtrnVolume = new Series<double>(this, MaximumBarsLookBack.Infinite);
				this.sExtrnSpeed  = new Series<double>(this, MaximumBarsLookBack.Infinite);
					
				break;

			#region -- terminated --
			case State.Terminated:
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
				break;
				#endregion
		}
	}

	#endregion

	#region -- addToolBar --
		private void addToolBar()
		{
			int rHeight = 26;
			MenuControlContainer = new Menu { Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Center };
			MenuControl = new MenuItem { BorderThickness = new Thickness(2), BorderBrush = Brushes.Pink, Header = pButtonText, Foreground = Brushes.Pink, Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);

			miVolArbOnOff   = new MenuItem { Header = "Volume Arb "+(pEnableVolumeArbSignal ? "ON":"OFF"), Name = "VolArbOnOff",   Foreground = Brushes.Black, FontWeight = FontWeights.Bold, IsCheckable = true, IsChecked = this.pEnableVolumeArbSignal,   StaysOpenOnClick = true };
			miSpeedArbOnOff = new MenuItem { Header = "Speed Arb "+(pEnableSpeedArbSignal ? "ON":"OFF"),   Name = "SpeedArbOnOff", Foreground = Brushes.Black, FontWeight = FontWeights.Bold, IsCheckable = true, IsChecked = this.pEnableSpeedArbSignal,    StaysOpenOnClick = true };
			miRangeArbOnOff   = new MenuItem { Header = "Range Arb "+(pEnableRArbSignal ? "ON":"OFF"),  Name = "RangeArbOnOff",   Foreground = Brushes.Black, FontWeight = FontWeights.Bold, IsCheckable = true, IsChecked = this.pEnableRArbSignal, StaysOpenOnClick = true };

			#region -- Arb on/off switches --
			miVolArbOnOff.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pEnableVolumeArbSignal = !this.pEnableVolumeArbSignal;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miVolArbOnOff.IsChecked = pEnableVolumeArbSignal;
						miVolArbOnOff.Header = "Volume Arb "+(pEnableVolumeArbSignal ? "ON":"OFF");
						if(pEnableVolumeArbSignal){
							lbl_VArb_SpeedThreshold.Foreground    = Brushes.Black;
							lbl_VArb_VolumeThreshold.Foreground   = Brushes.Black;
							lbl_VArb_RangeThreshold.Foreground = Brushes.Black;
							nud_VArb_SpeedThreshold.Visibility    = Visibility.Visible;
							nud_VArb_VolumeThreshold.Visibility   = Visibility.Visible;
							nud_VArb_RangeThreshold.Visibility = Visibility.Visible;
						}else{
							lbl_VArb_SpeedThreshold.Foreground    = Brushes.Silver;
							lbl_VArb_VolumeThreshold.Foreground   = Brushes.Silver;
							lbl_VArb_RangeThreshold.Foreground = Brushes.Silver;
							nud_VArb_SpeedThreshold.Visibility    = Visibility.Hidden;
							nud_VArb_VolumeThreshold.Visibility   = Visibility.Hidden;
							nud_VArb_RangeThreshold.Visibility = Visibility.Hidden;
						}
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miVolArbOnOff.IsChecked = pEnableVolumeArbSignal;
							miVolArbOnOff.Header = "Volume Arb "+(pEnableVolumeArbSignal ? "ON":"OFF");
							if(pEnableVolumeArbSignal){
								lbl_VArb_SpeedThreshold.Foreground    = Brushes.Black;
								lbl_VArb_VolumeThreshold.Foreground   = Brushes.Black;
								lbl_VArb_RangeThreshold.Foreground = Brushes.Black;
								nud_VArb_SpeedThreshold.Visibility    = Visibility.Visible;
								nud_VArb_VolumeThreshold.Visibility   = Visibility.Visible;
								nud_VArb_RangeThreshold.Visibility = Visibility.Visible;
							}else{
								lbl_VArb_SpeedThreshold.Foreground    = Brushes.Silver;
								lbl_VArb_VolumeThreshold.Foreground   = Brushes.Silver;
								lbl_VArb_RangeThreshold.Foreground = Brushes.Silver;
								nud_VArb_SpeedThreshold.Visibility    = Visibility.Hidden;
								nud_VArb_VolumeThreshold.Visibility   = Visibility.Hidden;
								nud_VArb_RangeThreshold.Visibility = Visibility.Hidden;
							}
						}));
					}
				}
			};
			miSpeedArbOnOff.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pEnableSpeedArbSignal = !pEnableSpeedArbSignal;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miSpeedArbOnOff.IsChecked = pEnableSpeedArbSignal;
						miSpeedArbOnOff.Header = "Speed Arb "+(pEnableSpeedArbSignal ? "ON":"OFF");
						if(pEnableSpeedArbSignal){
							lbl_SArb_SpeedThreshold.Foreground    = Brushes.Black;
							lbl_SArb_VolumeThreshold.Foreground   = Brushes.Black;
							lbl_SArb_RangeThreshold.Foreground = Brushes.Black;
							nud_SArb_SpeedThreshold.Visibility    = Visibility.Visible;
							nud_SArb_VolumeThreshold.Visibility   = Visibility.Visible;
							nud_SArb_RangeThreshold.Visibility = Visibility.Visible;
						}else{
							lbl_SArb_SpeedThreshold.Foreground    = Brushes.Silver;
							lbl_SArb_VolumeThreshold.Foreground   = Brushes.Silver;
							lbl_SArb_RangeThreshold.Foreground = Brushes.Silver;
							nud_SArb_SpeedThreshold.Visibility    = Visibility.Hidden;
							nud_SArb_VolumeThreshold.Visibility   = Visibility.Hidden;
							nud_SArb_RangeThreshold.Visibility = Visibility.Hidden;
						}
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miSpeedArbOnOff.IsChecked = pEnableSpeedArbSignal;
							miSpeedArbOnOff.Header = "Speed Arb "+(pEnableSpeedArbSignal ? "ON":"OFF");
							if(pEnableSpeedArbSignal){
								lbl_SArb_SpeedThreshold.Foreground    = Brushes.Black;
								lbl_SArb_VolumeThreshold.Foreground   = Brushes.Black;
								lbl_SArb_RangeThreshold.Foreground = Brushes.Black;
								nud_SArb_SpeedThreshold.Visibility    = Visibility.Visible;
								nud_SArb_VolumeThreshold.Visibility   = Visibility.Visible;
								nud_SArb_RangeThreshold.Visibility = Visibility.Visible;
							}else{
								lbl_SArb_SpeedThreshold.Foreground    = Brushes.Silver;
								lbl_SArb_VolumeThreshold.Foreground   = Brushes.Silver;
								lbl_SArb_RangeThreshold.Foreground = Brushes.Silver;
								nud_SArb_SpeedThreshold.Visibility    = Visibility.Hidden;
								nud_SArb_VolumeThreshold.Visibility   = Visibility.Hidden;
								nud_SArb_RangeThreshold.Visibility = Visibility.Hidden;
							}
						}));
					}
				}
			};
			miRangeArbOnOff.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pEnableRArbSignal = !pEnableRArbSignal;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miRangeArbOnOff.IsChecked = pEnableRArbSignal;
						miRangeArbOnOff.Header = "Range Arb "+(pEnableRArbSignal ? "ON":"OFF");
						if(pEnableRArbSignal){
							lbl_RArb_SpeedThreshold.Foreground    = Brushes.Black;
							lbl_RArb_VolumeThreshold.Foreground   = Brushes.Black;
							lbl_RArb_RangeThreshold.Foreground = Brushes.Black;
							nud_RArb_SpeedThreshold.Visibility    = Visibility.Visible;
							nud_RArb_VolumeThreshold.Visibility   = Visibility.Visible;
							nud_RArb_RangeThreshold.Visibility = Visibility.Visible;
						}else{
							lbl_RArb_SpeedThreshold.Foreground    = Brushes.Silver;
							lbl_RArb_VolumeThreshold.Foreground   = Brushes.Silver;
							lbl_RArb_RangeThreshold.Foreground = Brushes.Silver;
							nud_RArb_SpeedThreshold.Visibility    = Visibility.Hidden;
							nud_RArb_VolumeThreshold.Visibility   = Visibility.Hidden;
							nud_RArb_RangeThreshold.Visibility = Visibility.Hidden;
						}
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miRangeArbOnOff.IsChecked = pEnableRArbSignal;
							miRangeArbOnOff.Header = "Range Arb "+(pEnableRArbSignal ? "ON":"OFF");
							if(pEnableRArbSignal){
								lbl_RArb_SpeedThreshold.Foreground    = Brushes.Black;
								lbl_RArb_VolumeThreshold.Foreground   = Brushes.Black;
								lbl_RArb_RangeThreshold.Foreground = Brushes.Black;
								nud_RArb_SpeedThreshold.Visibility    = Visibility.Visible;
								nud_RArb_VolumeThreshold.Visibility   = Visibility.Visible;
								nud_RArb_RangeThreshold.Visibility = Visibility.Visible;
							}else{
								lbl_RArb_SpeedThreshold.Foreground    = Brushes.Silver;
								lbl_RArb_VolumeThreshold.Foreground   = Brushes.Silver;
								lbl_RArb_RangeThreshold.Foreground = Brushes.Silver;
								nud_RArb_SpeedThreshold.Visibility    = Visibility.Hidden;
								nud_RArb_VolumeThreshold.Visibility   = Visibility.Hidden;
								nud_RArb_RangeThreshold.Visibility = Visibility.Hidden;
							}
						}));
					}
				}
			};
			MenuControl.Items.Add(miVolArbOnOff);
			#endregion

			#region -- VolArb values --
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });


			#region -- Volume text box --
            lbl_VArb_VolumeThreshold = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Volume threshold: >", FontWeight = FontWeights.Normal };
            lbl_VArb_VolumeThreshold.SetValue(Grid.ColumnProperty, 0);
            lbl_VArb_VolumeThreshold.SetValue(Grid.RowProperty, 0);

			nud_VArb_VolumeThreshold = new TextBox() { Name = "txtbox_VArb_VolumeThreshold" + uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_VArb_VolumeThreshold.Text = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? iVArb_VolumeThresholdPct.ToString() : iVArb_VolumeThreshold.ToString();
			nud_VArb_VolumeThreshold.KeyDown += menuTxtbox_KeyDown;
            nud_VArb_VolumeThreshold.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(VOL_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0 : Convert.ToInt32(VOL_SCALE_MIN);
				int x = nud_VArb_VolumeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_VArb_VolumeThreshold.Text);
				if(x>max) {
					nud_VArb_VolumeThreshold.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_VArb_VolumeThreshold.Text = min.ToString();
					x=min;
				}
				if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage)
					this.iVArb_VolumeThresholdPct = x;
				else
					this.iVArb_VolumeThreshold = x;
			};
			nud_VArb_VolumeThreshold.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(VOL_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(VOL_SCALE_MIN);
				int x = nud_VArb_VolumeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_VArb_VolumeThreshold.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iVArb_VolumeThresholdPct = x;
						nud_VArb_VolumeThreshold.Text = x.ToString();
					}else{
						this.iVArb_VolumeThreshold = x;
						nud_VArb_VolumeThreshold.Text = x.ToString();
					}
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iVArb_VolumeThresholdPct = x;
						nud_VArb_VolumeThreshold.Text = x.ToString();
					}else{
						this.iVArb_VolumeThreshold = x;
						nud_VArb_VolumeThreshold.Text = x.ToString();
					}
				}
			};
			nud_VArb_VolumeThreshold.SetValue(Grid.ColumnProperty, 1);
            nud_VArb_VolumeThreshold.SetValue(Grid.RowProperty, 0);
            grid.Children.Add(lbl_VArb_VolumeThreshold);
            grid.Children.Add(nud_VArb_VolumeThreshold);
			#endregion
			#region -- Speed text box --
            lbl_VArb_SpeedThreshold = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Speed threshold: <", FontWeight = FontWeights.Normal };
            lbl_VArb_SpeedThreshold.SetValue(Grid.ColumnProperty, 0);
            lbl_VArb_SpeedThreshold.SetValue(Grid.RowProperty, 1);

			nud_VArb_SpeedThreshold = new TextBox() { Name = "txtbox_VArb_SpeedThreshold" + uID, Background = Brushes.Silver, Foreground=Brushes.Black, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_VArb_SpeedThreshold.Text = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? iVArb_SpeedThresholdPct.ToString() : iVArb_SpeedThreshold.ToString();
			nud_VArb_SpeedThreshold.KeyDown += menuTxtbox_KeyDown;
            nud_VArb_SpeedThreshold.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(SPEED_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0 : Convert.ToInt32(SPEED_SCALE_MIN);
				int x = nud_VArb_SpeedThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_VArb_SpeedThreshold.Text);
				if(x>max) {
					nud_VArb_SpeedThreshold.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_VArb_SpeedThreshold.Text = min.ToString();
					x=min;
				}
				if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage)
					this.iVArb_SpeedThresholdPct = x;
				else
					this.iVArb_SpeedThreshold = x;
			};
			nud_VArb_SpeedThreshold.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(SPEED_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(SPEED_SCALE_MIN);
				int x = nud_VArb_SpeedThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_VArb_SpeedThreshold.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iVArb_SpeedThresholdPct = x;
						nud_VArb_SpeedThreshold.Text = x.ToString();
					}else{
						this.iVArb_SpeedThreshold = x;
						nud_VArb_SpeedThreshold.Text = x.ToString();
					}
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iVArb_SpeedThresholdPct = x;
						nud_VArb_SpeedThreshold.Text = x.ToString();
					}else{
						this.iVArb_SpeedThreshold = x;
						nud_VArb_SpeedThreshold.Text = x.ToString();
					}
				}
			};
			nud_VArb_SpeedThreshold.SetValue(Grid.ColumnProperty, 1);
            nud_VArb_SpeedThreshold.SetValue(Grid.RowProperty, 1);
            grid.Children.Add(lbl_VArb_SpeedThreshold);
            grid.Children.Add(nud_VArb_SpeedThreshold);
			#endregion
			#region -- RangeRange text box --
            lbl_VArb_RangeThreshold = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Range threshold: <", FontWeight = FontWeights.Normal };
            lbl_VArb_RangeThreshold.SetValue(Grid.ColumnProperty, 0);
            lbl_VArb_RangeThreshold.SetValue(Grid.RowProperty, 2);

			nud_VArb_RangeThreshold = new TextBox() { Name = "txtbox_VArb_RangeThreshold" + uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_VArb_RangeThreshold.Text = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? iVArb_RangeThresholdPct.ToString() : iVArb_RangeThreshold.ToString();
			nud_VArb_RangeThreshold.KeyDown += menuTxtbox_KeyDown;
            nud_VArb_RangeThreshold.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(RANGE_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0 : Convert.ToInt32(RANGE_SCALE_MIN);
				int x = nud_VArb_RangeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_VArb_RangeThreshold.Text);
				if(x>max) {
					nud_VArb_RangeThreshold.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_VArb_RangeThreshold.Text = min.ToString();
					x=min;
				}
				if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage)
					this.iVArb_RangeThresholdPct = x;
				else
					this.iVArb_RangeThreshold = x;
			};
			nud_VArb_RangeThreshold.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(RANGE_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(RANGE_SCALE_MIN);
				int x = nud_VArb_RangeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_VArb_RangeThreshold.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iVArb_RangeThresholdPct = x;
						nud_VArb_RangeThreshold.Text = x.ToString();
					}else{
						this.iVArb_RangeThreshold = x;
						nud_VArb_RangeThreshold.Text = x.ToString();
					}
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iVArb_RangeThresholdPct = x;
						nud_VArb_RangeThreshold.Text = x.ToString();
					}else{
						this.iVArb_RangeThreshold = x;
						nud_VArb_RangeThreshold.Text = x.ToString();
					}
				}
			};
			nud_VArb_RangeThreshold.SetValue(Grid.ColumnProperty, 1);
            nud_VArb_RangeThreshold.SetValue(Grid.RowProperty, 2);
            grid.Children.Add(lbl_VArb_RangeThreshold);
            grid.Children.Add(nud_VArb_RangeThreshold);
			#endregion
			MenuControl.Items.Add(grid);

			if(pEnableVolumeArbSignal){
				lbl_VArb_SpeedThreshold.Foreground    = Brushes.Black;
				lbl_VArb_VolumeThreshold.Foreground   = Brushes.Black;
				lbl_VArb_RangeThreshold.Foreground = Brushes.Black;
				nud_VArb_SpeedThreshold.Visibility    = Visibility.Visible;
				nud_VArb_VolumeThreshold.Visibility   = Visibility.Visible;
				nud_VArb_RangeThreshold.Visibility = Visibility.Visible;
			}else{
				lbl_VArb_SpeedThreshold.Foreground    = Brushes.Silver;
				lbl_VArb_VolumeThreshold.Foreground   = Brushes.Silver;
				lbl_VArb_RangeThreshold.Foreground = Brushes.Silver;
				nud_VArb_SpeedThreshold.Visibility    = Visibility.Hidden;
				nud_VArb_VolumeThreshold.Visibility   = Visibility.Hidden;
				nud_VArb_RangeThreshold.Visibility = Visibility.Hidden;
			}
			#endregion

			MenuControl.Items.Add(miSpeedArbOnOff);

			#region -- SpeedArb values --
			grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

			#region -- Volume text box --
            lbl_SArb_VolumeThreshold = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Volume threshold: <", FontWeight = FontWeights.Normal };
            lbl_SArb_VolumeThreshold.SetValue(Grid.ColumnProperty, 0);
            lbl_SArb_VolumeThreshold.SetValue(Grid.RowProperty, 0);

			nud_SArb_VolumeThreshold = new TextBox() { Name = "txtbox_SArb_VolumeThreshold" + uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_SArb_VolumeThreshold.Text = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? iSArb_VolumeThresholdPct.ToString() : iSArb_VolumeThreshold.ToString();
			nud_SArb_VolumeThreshold.KeyDown += menuTxtbox_KeyDown;
            nud_SArb_VolumeThreshold.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(VOL_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0 : Convert.ToInt32(VOL_SCALE_MIN);
				int x = nud_SArb_VolumeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_SArb_VolumeThreshold.Text);
				if(x>max) {
					nud_SArb_VolumeThreshold.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_SArb_VolumeThreshold.Text = min.ToString();
					x=min;
				}
				if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage)
					this.iSArb_VolumeThresholdPct = x;
				else
					this.iSArb_VolumeThreshold = x;
			};
			nud_SArb_VolumeThreshold.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(VOL_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(VOL_SCALE_MIN);
				int x = nud_SArb_VolumeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_SArb_VolumeThreshold.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iSArb_VolumeThresholdPct = x;
						nud_SArb_VolumeThreshold.Text = x.ToString();
					}else{
						this.iSArb_VolumeThreshold = x;
						nud_SArb_VolumeThreshold.Text = x.ToString();
					}
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iSArb_VolumeThresholdPct = x;
						nud_SArb_VolumeThreshold.Text = x.ToString();
					}else{
						this.iSArb_VolumeThreshold = x;
						nud_SArb_VolumeThreshold.Text = x.ToString();
					}
				}
			};
			nud_SArb_VolumeThreshold.SetValue(Grid.ColumnProperty, 1);
            nud_SArb_VolumeThreshold.SetValue(Grid.RowProperty, 0);
            grid.Children.Add(lbl_SArb_VolumeThreshold);
            grid.Children.Add(nud_SArb_VolumeThreshold);
			#endregion
			#region -- Speed text box --
            lbl_SArb_SpeedThreshold = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Speed threshold: >", FontWeight = FontWeights.Normal };
            lbl_SArb_SpeedThreshold.SetValue(Grid.ColumnProperty, 0);
            lbl_SArb_SpeedThreshold.SetValue(Grid.RowProperty, 1);

			nud_SArb_SpeedThreshold = new TextBox() { Name = "txtbox_SArb_SpeedThreshold" + uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_SArb_SpeedThreshold.Text = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? iSArb_SpeedThresholdPct.ToString() : iSArb_SpeedThreshold.ToString();
			nud_SArb_SpeedThreshold.KeyDown += menuTxtbox_KeyDown;
            nud_SArb_SpeedThreshold.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(SPEED_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0 : Convert.ToInt32(SPEED_SCALE_MIN);
				int x = nud_SArb_SpeedThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_SArb_SpeedThreshold.Text);
				if(x>max) {
					nud_SArb_SpeedThreshold.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_SArb_SpeedThreshold.Text = min.ToString();
					x=min;
				}
				if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage)
					this.iSArb_SpeedThresholdPct = x;
				else
					this.iSArb_SpeedThreshold = x;
			};
			nud_SArb_SpeedThreshold.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(SPEED_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(SPEED_SCALE_MIN);
				int x = nud_SArb_SpeedThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_SArb_SpeedThreshold.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iSArb_SpeedThresholdPct = x;
						nud_SArb_SpeedThreshold.Text = x.ToString();
					}else{
						this.iSArb_SpeedThreshold = x;
						nud_SArb_SpeedThreshold.Text = x.ToString();
					}
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iSArb_SpeedThresholdPct = x;
						nud_SArb_SpeedThreshold.Text = x.ToString();
					}else{
						this.iSArb_SpeedThreshold = x;
						nud_SArb_SpeedThreshold.Text = x.ToString();
					}
				}
			};
			nud_SArb_SpeedThreshold.SetValue(Grid.ColumnProperty, 1);
            nud_SArb_SpeedThreshold.SetValue(Grid.RowProperty, 1);
            grid.Children.Add(lbl_SArb_SpeedThreshold);
            grid.Children.Add(nud_SArb_SpeedThreshold);
			#endregion
			#region -- RangeRange text box --
            lbl_SArb_RangeThreshold = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Range threshold: <", FontWeight = FontWeights.Normal };
            lbl_SArb_RangeThreshold.SetValue(Grid.ColumnProperty, 0);
            lbl_SArb_RangeThreshold.SetValue(Grid.RowProperty, 2);

			nud_SArb_RangeThreshold = new TextBox() { Name = "txtbox_SArb_RangeThreshold" + uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_SArb_RangeThreshold.Text = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? iSArb_RangeThresholdPct.ToString() : iSArb_RangeThreshold.ToString();
			nud_SArb_RangeThreshold.KeyDown += menuTxtbox_KeyDown;
            nud_SArb_RangeThreshold.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(RANGE_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0 : Convert.ToInt32(RANGE_SCALE_MIN);
				int x = nud_SArb_RangeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_SArb_RangeThreshold.Text);
				if(x>max) {
					nud_SArb_RangeThreshold.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_SArb_RangeThreshold.Text = min.ToString();
					x=min;
				}
				if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage)
					this.iSArb_RangeThresholdPct = x;
				else
					this.iSArb_RangeThreshold = x;
			};
			nud_SArb_RangeThreshold.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(RANGE_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(RANGE_SCALE_MIN);
				int x = nud_SArb_RangeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_SArb_RangeThreshold.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iSArb_RangeThresholdPct = x;
						nud_SArb_RangeThreshold.Text = x.ToString();
					}else{
						this.iSArb_RangeThreshold = x;
						nud_SArb_RangeThreshold.Text = x.ToString();
					}
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iSArb_RangeThresholdPct = x;
						nud_SArb_RangeThreshold.Text = x.ToString();
					}else{
						this.iSArb_RangeThreshold = x;
						nud_SArb_RangeThreshold.Text = x.ToString();
					}
				}
			};
			nud_SArb_RangeThreshold.SetValue(Grid.ColumnProperty, 1);
            nud_SArb_RangeThreshold.SetValue(Grid.RowProperty, 2);
            grid.Children.Add(lbl_SArb_RangeThreshold);
            grid.Children.Add(nud_SArb_RangeThreshold);
			#endregion
			MenuControl.Items.Add(grid);

			if(pEnableSpeedArbSignal){
				lbl_SArb_SpeedThreshold.Foreground    = Brushes.Black;
				lbl_SArb_VolumeThreshold.Foreground   = Brushes.Black;
				lbl_SArb_RangeThreshold.Foreground = Brushes.Black;
				nud_SArb_SpeedThreshold.Visibility    = Visibility.Visible;
				nud_SArb_VolumeThreshold.Visibility   = Visibility.Visible;
				nud_SArb_RangeThreshold.Visibility = Visibility.Visible;
			}else{
				lbl_SArb_SpeedThreshold.Foreground    = Brushes.Silver;
				lbl_SArb_VolumeThreshold.Foreground   = Brushes.Silver;
				lbl_SArb_RangeThreshold.Foreground = Brushes.Silver;
				nud_SArb_SpeedThreshold.Visibility    = Visibility.Hidden;
				nud_SArb_VolumeThreshold.Visibility   = Visibility.Hidden;
				nud_SArb_RangeThreshold.Visibility = Visibility.Hidden;
			}
			#endregion

			MenuControl.Items.Add(miRangeArbOnOff);

			#region -- RangeRArb values --
			grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

			#region -- Volume text box --
            lbl_RArb_VolumeThreshold = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Volume threshold: <", FontWeight = FontWeights.Normal };
            lbl_RArb_VolumeThreshold.SetValue(Grid.ColumnProperty, 0);
            lbl_RArb_VolumeThreshold.SetValue(Grid.RowProperty, 0);

			nud_RArb_VolumeThreshold = new TextBox() { Name = "txtbox_RArb_VolumeThreshold" + uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_RArb_VolumeThreshold.Text = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? iRArb_VolumeThresholdPct.ToString() : iRArb_VolumeThreshold.ToString();
			nud_RArb_VolumeThreshold.KeyDown += menuTxtbox_KeyDown;
            nud_RArb_VolumeThreshold.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(VOL_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0 : Convert.ToInt32(VOL_SCALE_MIN);
				int x = nud_RArb_VolumeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_RArb_VolumeThreshold.Text);
				if(x>max) {
					nud_RArb_VolumeThreshold.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_RArb_VolumeThreshold.Text = min.ToString();
					x=min;
				}
				if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage)
					this.iRArb_VolumeThresholdPct = x;
				else
					this.iRArb_VolumeThreshold = x;
			};
			nud_RArb_VolumeThreshold.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(VOL_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(VOL_SCALE_MIN);
				int x = nud_RArb_VolumeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_RArb_VolumeThreshold.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iRArb_VolumeThresholdPct = x;
						nud_RArb_VolumeThreshold.Text = x.ToString();
					}else{
						this.iRArb_VolumeThreshold = x;
						nud_RArb_VolumeThreshold.Text = x.ToString();
					}
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iRArb_VolumeThresholdPct = x;
						nud_RArb_VolumeThreshold.Text = x.ToString();
					}else{
						this.iRArb_VolumeThreshold = x;
						nud_RArb_VolumeThreshold.Text = x.ToString();
					}
				}
			};
			nud_RArb_VolumeThreshold.SetValue(Grid.ColumnProperty, 1);
            nud_RArb_VolumeThreshold.SetValue(Grid.RowProperty, 0);
            grid.Children.Add(lbl_RArb_VolumeThreshold);
            grid.Children.Add(nud_RArb_VolumeThreshold);
			#endregion
			#region -- Speed text box --
            lbl_RArb_SpeedThreshold = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Speed threshold: <", FontWeight = FontWeights.Normal };
            lbl_RArb_SpeedThreshold.SetValue(Grid.ColumnProperty, 0);
            lbl_RArb_SpeedThreshold.SetValue(Grid.RowProperty, 1);

			nud_RArb_SpeedThreshold = new TextBox() { Name = "txtbox_RArb_SpeedThreshold" + uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_RArb_SpeedThreshold.Text = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? iRArb_SpeedThresholdPct.ToString() : iRArb_SpeedThreshold.ToString();
			nud_RArb_SpeedThreshold.KeyDown += menuTxtbox_KeyDown;
            nud_RArb_SpeedThreshold.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(SPEED_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0 : Convert.ToInt32(SPEED_SCALE_MIN);
				int x = nud_RArb_SpeedThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_RArb_SpeedThreshold.Text);
				if(x>max) {
					nud_RArb_SpeedThreshold.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_RArb_SpeedThreshold.Text = min.ToString();
					x=min;
				}
				if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage)
					this.iRArb_SpeedThresholdPct = x;
				else
					this.iRArb_SpeedThreshold = x;
			};
			nud_RArb_SpeedThreshold.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(SPEED_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(SPEED_SCALE_MIN);
				int x = nud_RArb_SpeedThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_RArb_SpeedThreshold.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iRArb_SpeedThresholdPct = x;
						nud_RArb_SpeedThreshold.Text = x.ToString();
					}else{
						this.iRArb_SpeedThreshold = x;
						nud_RArb_SpeedThreshold.Text = x.ToString();
					}
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iRArb_SpeedThresholdPct = x;
						nud_RArb_SpeedThreshold.Text = x.ToString();
					}else{
						this.iRArb_SpeedThreshold = x;
						nud_RArb_SpeedThreshold.Text = x.ToString();
					}
				}
			};
			nud_RArb_SpeedThreshold.SetValue(Grid.ColumnProperty, 1);
            nud_RArb_SpeedThreshold.SetValue(Grid.RowProperty, 1);
            grid.Children.Add(lbl_RArb_SpeedThreshold);
            grid.Children.Add(nud_RArb_SpeedThreshold);
			#endregion
			#region -- RangeRange text box --
            lbl_RArb_RangeThreshold = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Range threshold: >", FontWeight = FontWeights.Normal };
            lbl_RArb_RangeThreshold.SetValue(Grid.ColumnProperty, 0);
            lbl_RArb_RangeThreshold.SetValue(Grid.RowProperty, 2);

			nud_RArb_RangeThreshold = new TextBox() { Name = "txtbox_RArb_RangeThreshold" + uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_RArb_RangeThreshold.Text = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? iRArb_RangeThresholdPct.ToString() : iRArb_RangeThreshold.ToString();
			nud_RArb_RangeThreshold.KeyDown += menuTxtbox_KeyDown;
            nud_RArb_RangeThreshold.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(RANGE_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0 : Convert.ToInt32(RANGE_SCALE_MIN);
				int x = nud_RArb_RangeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_RArb_RangeThreshold.Text);
				if(x>max) {
					nud_RArb_RangeThreshold.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_RArb_RangeThreshold.Text = min.ToString();
					x=min;
				}
				if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage)
					this.iRArb_RangeThresholdPct = x;
				else
					this.iRArb_RangeThreshold = x;
			};
			nud_RArb_RangeThreshold.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(RANGE_SCALE_MAX);
				int min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(RANGE_SCALE_MIN);
				int x = nud_RArb_RangeThreshold.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_RArb_RangeThreshold.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iRArb_RangeThresholdPct = x;
						nud_RArb_RangeThreshold.Text = x.ToString();
					}else{
						this.iRArb_RangeThreshold = x;
						nud_RArb_RangeThreshold.Text = x.ToString();
					}
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
						this.iRArb_RangeThresholdPct = x;
						nud_RArb_RangeThreshold.Text = x.ToString();
					}else{
						this.iRArb_RangeThreshold = x;
						nud_RArb_RangeThreshold.Text = x.ToString();
					}
				}
			};
			nud_RArb_RangeThreshold.SetValue(Grid.ColumnProperty, 1);
            nud_RArb_RangeThreshold.SetValue(Grid.RowProperty, 2);
            grid.Children.Add(lbl_RArb_RangeThreshold);
            grid.Children.Add(nud_RArb_RangeThreshold);
			#endregion
			MenuControl.Items.Add(grid);

			if(pEnableRArbSignal){
				lbl_RArb_SpeedThreshold.Foreground    = Brushes.Black;
				lbl_RArb_VolumeThreshold.Foreground   = Brushes.Black;
				lbl_RArb_RangeThreshold.Foreground = Brushes.Black;
				nud_RArb_SpeedThreshold.Visibility    = Visibility.Visible;
				nud_RArb_VolumeThreshold.Visibility   = Visibility.Visible;
				nud_RArb_RangeThreshold.Visibility = Visibility.Visible;
			}else{
				lbl_RArb_SpeedThreshold.Foreground    = Brushes.Silver;
				lbl_RArb_VolumeThreshold.Foreground   = Brushes.Silver;
				lbl_RArb_RangeThreshold.Foreground = Brushes.Silver;
				nud_RArb_SpeedThreshold.Visibility    = Visibility.Hidden;
				nud_RArb_VolumeThreshold.Visibility   = Visibility.Hidden;
				nud_RArb_RangeThreshold.Visibility = Visibility.Hidden;
			}
			#endregion

			MenuControl.Items.Add(new Separator());

			#region -- Recalc Profiles --
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE signals", HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			MenuControl.Items.Add(miRecalculate1);
			#endregion

			indytoolbar.Children.Add(MenuControlContainer);
		}
        #region private void menuTxtbox_KeyDown()
        private void menuTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtBoxSender = sender as TextBox;
			int max = 100;
			int min = 0;
			string startval = txtBoxSender.Text;
//Print(txtBoxSender.Name+":  menuTxtBox_KeyDown: "+txtBoxSender.Text);

			if(txtBoxSender.Name.Contains("SpeedThreshold")){
				max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(SPEED_SCALE_MAX);
				min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(SPEED_SCALE_MIN);
			}else if(txtBoxSender.Name.Contains("VolumeThreshold")){
				max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(VOL_SCALE_MAX);
				min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(VOL_SCALE_MIN);
			}else if(txtBoxSender.Name.Contains("RangeThreshold")){
				max = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 100 : Convert.ToInt32(RANGE_SCALE_MAX);
				min = this.pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? 0   : Convert.ToInt32(RANGE_SCALE_MIN);
			}
//Print("      max: "+max+"  min: "+min);
			try{
	            int keyVal = (int)e.Key;
	            int value = -1;
	            if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
					value = keyVal - (int)System.Windows.Input.Key.D0;
	            else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
					value = keyVal - (int)System.Windows.Input.Key.NumPad0;

	            bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);

//Print("IsNumberic: "+isNumeric.ToString());

				if (isNumeric || e.Key == System.Windows.Input.Key.Back)
    	        {
	                string newText    = value != -1 ? value.ToString() : "";
    	            int tbPosition    = txtBoxSender.SelectionStart;
        	        txtBoxSender.Text = txtBoxSender.SelectedText == "" ? txtBoxSender.Text.Insert(tbPosition, newText) : txtBoxSender.Text.Replace(txtBoxSender.SelectedText, newText);
            	    txtBoxSender.Select(tbPosition + 1, 0);
					int x = string.IsNullOrEmpty(txtBoxSender.Text.Trim()) ? min : Convert.ToInt32(txtBoxSender.Text);
					x = Math.Max(min, Math.Min(max,x));
					txtBoxSender.Text = x.ToString();
//Print("     text: "+txtBoxSender.Text);
				}
			}catch{
				txtBoxSender.Text = startval;
            }
        }
        #endregion
//=====================================================================================================
		private void InformUserAboutRecalculation(){
			miRecalculate1.Background = Brushes.Yellow;
			miRecalculate1.FontWeight = FontWeights.Bold;
			miRecalculate1.FontStyle  = FontStyles.Italic;
		}
		private void ResetRecalculationUI(){
			VArb_SignalCount = 0;
			RArb_SignalCount = 0;
			SArb_SignalCount = 0;
			MsgText = null;
			RecalcAt = DateTime.Now;
			miRecalculate1.FontWeight = FontWeights.Normal;
			miRecalculate1.FontStyle  = FontStyles.Normal;
			miRecalculate1.Background = null;
		}
//=====================================================================================================
		#region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Hidden;
		}
		#endregion

		#endregion

		List<int> VArb_SignalBar = new List<int>(){-1};
		List<int> SArb_SignalBar = new List<int>(){-1};
		List<int> RArb_SignalBar = new List<int>(){-1};
//===================================================================================================================================
        protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(CurrentBars[0] < 5)
				return;

			if(backBrushDX==null) ForceRefresh();

			double volupct = 0;
			double speedpct = 0;
			double rangepct = 0;
			if(this.IsFirstTickOfBar && State == State.Realtime)
				this.bCanAlertTrigger = true;
//if(Times[0][0].Day== 13 && Times[0][0].Hour== 12 && Times[0][0].Minute== 30) Print(Times[0][0].ToString() + ":  "+pScaleType.ToString()+"  "+indVolume.ForecastValue[0].ToString()+"  cur: "+indVolume.CurrentValue[0].ToString());
			this.sExtrnRange[0]  = this.ComputePercent(this.indRange.ForecastValue[0],  this.indRange.CurrentValue[0]);
			this.sExtrnVolume[0] = this.ComputePercent(this.indVolume.ForecastValue[0], this.indVolume.CurrentValue[0]) / (iCalculationModel==ARC_VSR_Arb_CalcModels.Version1 && pScaleType == ARC_VSR_Arb_ScaleType.Percentage ? (VOL_SCALE_MAX-VOL_SCALE_MIN)/100.0 : 1);
			this.sExtrnSpeed[0]  = this.ComputePercent(this.indSpeed.ForecastValue[0],  this.indSpeed.CurrentValue[0]);
//if(IsFirstTickOfBar) Print(Times[0][0].ToString()+"     "+sExtrnSpeed[0].ToString("0.0")+"        forecast: "+indSpeed.ForecastValue[0]+"  val: "+indSpeed.CurrentValue[0]);
			if(pEnableVolumeArbSignal || pEnableSpeedArbSignal || pEnableRArbSignal){
				BackBrush = null;
				#region -- Find/draw arb signals --
				if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
					#region -- Calculate pct based thresholds
					volupct  = Math.Max(VOL_SCALE_MIN,Math.Min(VOL_SCALE_MAX,sExtrnVolume[0]));
					volupct = (volupct-VOL_SCALE_MIN) / (VOL_SCALE_MAX-VOL_SCALE_MIN) * 100.0;

					speedpct  = Math.Max(SPEED_SCALE_MIN,Math.Min(SPEED_SCALE_MAX,sExtrnSpeed[0]));
					speedpct = (speedpct-SPEED_SCALE_MIN) / (SPEED_SCALE_MAX-SPEED_SCALE_MIN) * 100.0;

					rangepct  = Math.Max(RANGE_SCALE_MIN,Math.Min(RANGE_SCALE_MAX,sExtrnRange[0]));
					rangepct = (rangepct-RANGE_SCALE_MIN) / (RANGE_SCALE_MAX-RANGE_SCALE_MIN) * 100.0;
//bool InZone = Times[0][0].Day==30 && Times[0][0].Hour==1 && Times[0][0].Minute==28;
					if(pEnableVolumeArbSignal){
						if(    rangepct   <= this.iVArb_RangeThresholdPct
							&& speedpct <= this.iVArb_SpeedThresholdPct
							&& volupct  >= this.iVArb_VolumeThresholdPct
							){
								if(CurrentBar != VArb_AudibleAlertBar)
									this.SignalAlert(this.iVArb_SoundAlert);
								VArb_AudibleAlertBar = CurrentBar;
								if(VArb_SignalBar[0]!=CurrentBar) VArb_SignalBar.Insert(0,CurrentBar);
								if(State==State.Historical) VArb_SignalCount++;
								//if(IsDebug) BackBrush = Brushes.Yellow;
							}
					else
						if(VArb_SignalBar[0] == CurrentBar) VArb_SignalBar.RemoveAt(0);
					}
					if(pEnableRArbSignal){
						if(    rangepct   >= this.iRArb_RangeThresholdPct
							&& speedpct <= this.iRArb_SpeedThresholdPct
							&& volupct  <= this.iRArb_VolumeThresholdPct
							){
								if(CurrentBar != RArb_AudibleAlertBar)
									this.SignalAlert(this.iRArb_SoundAlert);
								RArb_AudibleAlertBar = CurrentBar;
								if(RArb_SignalBar[0]!=CurrentBar) RArb_SignalBar.Insert(0,CurrentBar);
								if(State==State.Historical) RArb_SignalCount++;
								//if(IsDebug) BackBrush = Brushes.Yellow;
							}
						else
							if(RArb_SignalBar[0] == CurrentBar) RArb_SignalBar.RemoveAt(0);
					}
					if(pEnableSpeedArbSignal){
//if(InZone && IsDebug) Print(Times[0][0].ToString()+"   atr: "+rangepct.ToString("0.0")+"  speed: "+speedpct.ToString("0.0")+"   volume: "+volupct.ToString("0.0"));
						if(    rangepct   <= this.iSArb_RangeThresholdPct
							&& speedpct >= this.iSArb_SpeedThresholdPct
							&& volupct  <= this.iSArb_VolumeThresholdPct
							){
								if(CurrentBar != SArb_AudibleAlertBar)
									this.SignalAlert(this.iSArb_SoundAlert);
								SArb_AudibleAlertBar =CurrentBar;
								if(SArb_SignalBar[0]!=CurrentBar) SArb_SignalBar.Insert(0,CurrentBar);
								if(State==State.Historical) SArb_SignalCount++;
								//if(IsDebug) BackBrush = Brushes.Yellow;
							}
						else
							if(SArb_SignalBar[0] == CurrentBar) SArb_SignalBar.RemoveAt(0);
					}
					#endregion
				}else{
					#region -- Calculate raw value thresholds --
					if(pEnableVolumeArbSignal){
						if(    this.sExtrnRange[0] <= this.iVArb_RangeThreshold
							&& this.sExtrnSpeed[0]    <= this.iVArb_SpeedThreshold
							&& this.sExtrnVolume[0]   >= this.iVArb_VolumeThreshold
							){
								if(CurrentBar != VArb_AudibleAlertBar)
									this.SignalAlert(this.iVArb_SoundAlert);
								VArb_AudibleAlertBar = CurrentBar;
								if(VArb_SignalBar[0]!=CurrentBar) VArb_SignalBar.Insert(0,CurrentBar);
								if(State==State.Historical) VArb_SignalCount++;
	//							if(IsDebug) BackBrushes[0] = Brushes.Yellow;
							}
						else
							if(VArb_SignalBar[0] == CurrentBar) VArb_SignalBar.RemoveAt(0);
					}
					if(pEnableRArbSignal){
						if(    this.sExtrnRange[0] >= this.iRArb_RangeThreshold
							&& this.sExtrnSpeed[0]    <= this.iRArb_SpeedThreshold
							&& this.sExtrnVolume[0]   <= this.iRArb_VolumeThreshold
							){
								if(CurrentBar != RArb_AudibleAlertBar)
									this.SignalAlert(this.iRArb_SoundAlert);
								RArb_AudibleAlertBar = CurrentBar;
								if(RArb_SignalBar[0]!=CurrentBar) RArb_SignalBar.Insert(0,CurrentBar);
								if(State==State.Historical) RArb_SignalCount++;
	//							if(IsDebug) BackBrushes[0] = Brushes.Yellow;
							}
					else
						if(RArb_SignalBar[0] == CurrentBar) RArb_SignalBar.RemoveAt(0);
					}
					if(pEnableSpeedArbSignal){
						if(    this.sExtrnRange[0] <= this.iSArb_RangeThreshold
							&& this.sExtrnSpeed[0]    >= this.iSArb_SpeedThreshold
							&& this.sExtrnVolume[0]   <= this.iSArb_VolumeThreshold
							){
								if(CurrentBar != SArb_AudibleAlertBar)
									this.SignalAlert(this.iSArb_SoundAlert);
								SArb_AudibleAlertBar = CurrentBar;
								if(SArb_SignalBar[0]!=CurrentBar) SArb_SignalBar.Insert(0,CurrentBar);
								if(State==State.Historical) SArb_SignalCount++;
//								if(IsDebug) BackBrushes[0] = Brushes.Yellow;
							}
						else
							if(SArb_SignalBar[0] == CurrentBar) SArb_SignalBar.RemoveAt(0);
					}
					#endregion
				}

				if(pEnableVolumeArbSignal){
					string tag = string.Format("VoluArb {0}",CurrentBar);
					if(VArb_SignalBar[0] == CurrentBar){
						if(pVArb_ChartMarker != ARC_VSR_Arb_ChartMarkers.None){
							RemoveDrawObject(tag);
							DrawChartMarker(pVArb_ChartMarker, tag, pVArb_MarkerColor);
						}
						if(pVArb_RacingStripeColor != Brushes.Transparent)
							BackBrush = pVArb_RacingStripeColor;
//if(IsDebug) Print(Times[0][0].ToString()+"   vol: "+volupct.ToString("0")+"   speed: "+speedpct.ToString("0")+"   atr: "+rangepct.ToString("0"));
					}else {
						RemoveDrawObject(tag);
						if(RArb_SignalBar[0]!=CurrentBar && SArb_SignalBar[0]!=CurrentBar) BackBrush = null;
					}
				}

				if(pEnableRArbSignal){
					string tag = string.Format("RangeArb {0}",CurrentBar);
					if(RArb_SignalBar[0] == CurrentBar){
						if(pRArb_ChartMarker != ARC_VSR_Arb_ChartMarkers.None){
							RemoveDrawObject(tag);
							DrawChartMarker(pRArb_ChartMarker, tag, pRArb_MarkerColor);
						}
						if(pRArb_RacingStripeColor != Brushes.Transparent)
							BackBrush = pRArb_RacingStripeColor;
					}else{
						RemoveDrawObject(tag);
						if(VArb_SignalBar[0]!=CurrentBar && SArb_SignalBar[0]!=CurrentBar) BackBrush = null;
					}
				}

				if(pEnableSpeedArbSignal){
					string tag = string.Format("SpeedArb {0}",CurrentBar);
					if(SArb_SignalBar[0] == CurrentBar){
						if(pSArb_ChartMarker != ARC_VSR_Arb_ChartMarkers.None){
							RemoveDrawObject(tag);
							DrawChartMarker(pSArb_ChartMarker, tag, pSArb_MarkerColor);
						}
						if(pSArb_RacingStripeColor != Brushes.Transparent)
							BackBrush = pSArb_RacingStripeColor;
					}else{
						RemoveDrawObject(tag);
						if(VArb_SignalBar[0]!=CurrentBar && RArb_SignalBar[0]!=CurrentBar) BackBrush = null;
					}
				}
				#endregion

				if(VArb_SignalCount>0){
					MsgText = "Volume arb signal count: "+VArb_SignalCount.ToString();
					VArb_SignalCount = 0;
				}
				if(RArb_SignalCount>0){
					if(MsgText==null) MsgText = MsgText+Environment.NewLine+"Range arb signal count: "+RArb_SignalCount.ToString();
					else MsgText = "Range arb signal count: "+RArb_SignalCount.ToString();
					RArb_SignalCount = 0;
				}
				if(SArb_SignalCount>0){
					if(MsgText==null) MsgText = MsgText+Environment.NewLine+"Speed arb signal count: "+SArb_SignalCount.ToString();
					else MsgText = "Speed arb signal count: "+SArb_SignalCount.ToString();
					SArb_SignalCount = 0;
				}
			}
        }
//==============================================================================================
		private void DrawChartMarker(ARC_VSR_Arb_ChartMarkers mkr, string tag, Brush brush){
			if(mkr == ARC_VSR_Arb_ChartMarkers.Arrow)		   Draw.ArrowUp    (this, tag, false, 0, Lows[0][0]-TickSize, brush);
			else if(mkr == ARC_VSR_Arb_ChartMarkers.Dot)	   Draw.Dot        (this, tag, false, 0, Lows[0][0]-TickSize, brush);
			else if(mkr == ARC_VSR_Arb_ChartMarkers.Diamond)   Draw.Diamond    (this, tag, false, 0, Lows[0][0]-TickSize, brush);
			else if(mkr == ARC_VSR_Arb_ChartMarkers.Square)	   Draw.Square     (this, tag, false, 0, Lows[0][0]-TickSize, brush);
			else if(mkr == ARC_VSR_Arb_ChartMarkers.ArrowLine) Draw.ArrowLine  (this, tag, 0,     Lows[0][0]-TickSize - (Highs[0][0]-Lows[0][0]), 0, Lows[0][0]-TickSize, brush);
			else if(mkr == ARC_VSR_Arb_ChartMarkers.Triangle)  Draw.TriangleUp (this, tag, false, 0, Lows[0][0]-TickSize, brush);
			else if(mkr == ARC_VSR_Arb_ChartMarkers.Text)	   Draw.Text       (this, tag, false, "VSR", 0, Lows[0][0]-TickSize, 10, brush, ChartControl.Properties.LabelFont, System.Windows.TextAlignment.Center,Brushes.Transparent,Brushes.Transparent,100);
		}

		
//==============================================================================================
		private void SetGraphic(int iOffset)
		{
			if(CT == null){
				return;
			}

			try
			{
				double range  = sExtrnRange.GetValueAt(iOffset);
				double volume = sExtrnVolume.GetValueAt(iOffset);
				double speed  = sExtrnSpeed.GetValueAt(iOffset);

				// Protect against invalid seed values until the data is correct.
				if(
					!IsFinite(range)	
					|| !IsFinite(volume)	
					|| !IsFinite(speed)	
					)
					return;

				// Forecasted Volume
				CT.Value1 = Convert.ToSingle(volume);
				// Forecasted Speed
				CT.Value2 = Convert.ToSingle(speed);
				// Forecasted Range
				CT.Value3 = Convert.ToSingle(range);	
			}
			catch(Exception e)
			{
				Print(e.Message);
				Log("ARC VSA Arb - SetGraphic Exception = " + e.ToString(), NinjaTrader.Cbi.LogLevel.Error);
			}			
		}
		
        private bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value) && value < double.MaxValue;
        }

		#region RegAlerts
		
		private void SignalAlert(string wav)
		{
			if(!this.bCanAlertTrigger)
				return;
			
			if(wav != "SOUND OFF"){// && this.iEnableSoundAlert)
				this.PlaySound(AddSoundFolder(wav));				
				this.idTag++;
			}
		}
		//======================================================================================================
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
		#endregion

		#region RegNormalizing
		
		private float ComputePercent(double iForecast, double iCurrent)
		{
			if(iForecast == 0)
			{
				//Log("NS VSR - ComputePercent Exception = Div/0; Call " + iCall.ToString(), NinjaTrader.Cbi.LogLevel.Error);
				return 0;
			}
			
			if(iCurrent > iForecast)
				return Convert.ToSingle(100.0 * (iCurrent / iForecast));
						
			return Math.Min(100, Convert.ToSingle(100.0 * (1.0 - (Math.Abs(iForecast - iCurrent) / iForecast))));
		}
		
		#endregion

		#region RegGraphics
		
		#region RegNT7toNT8Class
		
		internal class NT7MeasureStringData
		{
			public float Height;
			public float Width;
			
			public NT7MeasureStringData()
			{
				
			}
		}
			
		internal class NT7Graphics
		{
			SharpDX.Direct2D1.RenderTarget rt;
		
			public NT7Graphics(SharpDX.Direct2D1.RenderTarget rt)
			{
				this.rt = rt;
			}
			
			public void DrawEllipse(Stroke s, RectangleF rect)
			{
				this.DrawEllipse(s, rect.X, rect.Y, rect.Width, rect.Height);
			}
			
			public void DrawEllipse(Stroke s, float x, float y, float w, float h)
			{
				float half = w / 2;
				float x0 = Convert.ToSingle (x + half - 1);
				float y0 = Convert.ToSingle (y + half - 1);
				SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
				SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f); 
				var brush = s.Brush.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawEllipse(ellipse, brush,s.Width);
				brush.Dispose();brush=null;
			}
			
			public void FillEllipse(Brush b, RectangleF rect)
			{
				this.FillEllipse(b, rect.X, rect.Y, rect.Width, rect.Height);
			}
			
			public void FillEllipse(Brush b, float x, float y, float w, float h)
			{
				float half = w / 2;
				float x0 = Convert.ToSingle (x + half - 1);
				float y0 = Convert.ToSingle (y + half - 1);
				SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
				SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f); 
				var brush = b.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.FillEllipse(ellipse, brush);
				brush.Dispose();brush=null;
			}
			
			public void DrawRectangle(Stroke s, RectangleF rect)
			{
				this.DrawRectangle(s,rect.X, rect.Y, rect.Width, rect.Height);
			}
			
			public void DrawRectangle(Stroke s, float x, float y, float w, float h)
			{
				SharpDX.RectangleF rectf = new SharpDX.RectangleF(x, y, w, h);
				var brush = s.Brush.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawRectangle(rectf, brush,s.Width);
				brush.Dispose();brush=null;
			}
			
			public void FillRectangle(Brush b, RectangleF rect)
			{
				this.FillRectangle(b,rect.X, rect.Y, rect.Width, rect.Height);
			}
			
			public void FillRectangle(Brush b, float x, float y, float w, float h)
			{
				SharpDX.RectangleF rectf = new SharpDX.RectangleF(x, y, w, h);
				var brush = b.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.FillRectangle(rectf, brush);
				brush.Dispose();brush=null;
			}
			
			public void DrawLine(Stroke s, float x1, float y1, float x2, float y2)
			{
				System.Windows.Point startPoint	= new System.Windows.Point(x1, y1);
				System.Windows.Point endPoint		= new System.Windows.Point(x2, y2);
				var brush = s.Brush.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawLine(startPoint.ToVector2(), endPoint.ToVector2(), brush, s.Width, s.StrokeStyle);
				brush.Dispose();brush=null;
			}
			
			public void DrawString(String text, SimpleFont f, Brush b, RectangleF rect, SharpDX.DirectWrite.TextAlignment ta)
			{
				this.DrawString(text, f, b, rect.X, rect.Y, rect.Width, rect.Height, ta);
			}
			
			public void DrawString(String text, SimpleFont f, Brush b, RectangleF rect)
			{
				this.DrawString(text, f, b, rect.X, rect.Y);
			}
			
			public void DrawString(String text, SimpleFont f, Brush b, float x, float y)
			{
				this.DrawString(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading);
			}
			
			public void DrawString(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta)
			{
				TextFormat textFormat		= 
					new TextFormat(
						Core.Globals.DirectWriteFactory, 
						f.Family.ToString(), 
						(f.Bold?SharpDX.DirectWrite.FontWeight.Bold:SharpDX.DirectWrite.FontWeight.Normal),
						SharpDX.DirectWrite.FontStyle.Normal, 
						SharpDX.DirectWrite.FontStretch.Normal, 
						Convert.ToSingle(f.Size)) 
						{ 
							TextAlignment = ta, 
							WordWrapping = WordWrapping.NoWrap 
						};
												
				TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,w,h);//(float)f.Size);
				
				System.Windows.Point upperTextPoint	= new System.Windows.Point(x,y);
				var brush = b.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
				brush.Dispose();brush=null;
			}
			
			public NT7MeasureStringData MeasureString( String text, SimpleFont f)
			{
				NT7MeasureStringData sd = new NT7MeasureStringData();
				
				TextFormat textFormat		= new TextFormat(Core.Globals.DirectWriteFactory, f.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal,
												SharpDX.DirectWrite.FontStyle.Normal, SharpDX.DirectWrite.FontStretch.Normal, Convert.ToSingle(f.Size)) 
												{ TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading, WordWrapping = WordWrapping.NoWrap };
												
				TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory,text,textFormat,400,Convert.ToSingle(f.Size));
				
												
				sd.Height = Convert.ToSingle( textLayout.Metrics.Height);
				sd.Width = Convert.ToSingle( textLayout.Metrics.Width);
												
				return sd;
			}
			
			public void FillPolygon(Brush b, System.Windows.Point[] p)
			{
				SharpDX.Direct2D1.PathGeometry	g		= null;
				SharpDX.Direct2D1.GeometrySink	sink	= null;
				
				if (sink == null)
				{
					g			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					sink		= g.Open();
					
				}
				
				sink.BeginFigure(new SharpDX.Vector2(Convert.ToSingle(p[0].X),Convert.ToSingle(p[0].Y)), SharpDX.Direct2D1.FigureBegin.Filled);
				for(int pidx = 1; pidx < p.Length; pidx++)
				{
					sink.AddLine(new SharpDX.Vector2(Convert.ToSingle(p[pidx].X), Convert.ToSingle(p[pidx].Y)));
				}
				sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
				sink.Close();
				
				if (g != null)
				{
					var brush = b.ToDxBrush(this.rt);
					if (brush == null) return;
					this.rt.FillGeometry(g,brush); 
					brush.Dispose();brush=null;
					
					g.Dispose();
					sink.Dispose();
					g = null;
					sink = null;
				}
			}
			
			public void DrawPolygon(Stroke s, System.Windows.Point[] p)
			{
				SharpDX.Direct2D1.PathGeometry	g		= null;
				SharpDX.Direct2D1.GeometrySink	sink	= null;
				
				if (sink == null)
				{
					g			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					sink		= g.Open();
					
				}
				
				sink.BeginFigure(new SharpDX.Vector2(Convert.ToSingle(p[0].X),Convert.ToSingle(p[0].Y)), SharpDX.Direct2D1.FigureBegin.Filled);
				for(int pidx = 1; pidx < p.Length; pidx++)
				{
					sink.AddLine(new SharpDX.Vector2(Convert.ToSingle(p[pidx].X), Convert.ToSingle(p[pidx].Y)));
				}
				sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
				sink.Close();
				
				if (g != null)
				{
					var brush = s.Brush.ToDxBrush(this.rt);
					if (brush == null) return;
					this.rt.DrawGeometry(g,brush); 
					brush.Dispose();brush=null;
					
					g.Dispose();
					sink.Dispose();
					g = null;
					sink = null;
				}
			}
		}
		
		#endregion
		
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }


//====================================================================================================================================
		private SharpDX.Direct2D1.Brush backBrushDX = null;
		private SharpDX.Direct2D1.Brush txtBrushDX  = null;
		private SharpDX.Direct2D1.Brush SolidHistoBrushDX  = null;
		private SharpDX.Direct2D1.Brush gradientBrushDX    = null;
        public override void OnRenderTargetChanged()
        {
			//Dispose DX brushes
			if(backBrushDX!=null && !backBrushDX.IsDisposed) {backBrushDX.Dispose(); backBrushDX=null;}
			if(txtBrushDX!=null        && !txtBrushDX.IsDisposed)        {txtBrushDX.Dispose();         txtBrushDX=null;}
			if(SolidHistoBrushDX!=null && !SolidHistoBrushDX.IsDisposed) {SolidHistoBrushDX.Dispose();  SolidHistoBrushDX=null;}

			//create DX brushes
			if(RenderTarget!=null && backBrush!=null)  {backBrushDX = backBrush.ToDxBrush(RenderTarget);}
			if(RenderTarget!=null && iTextColor!=null) {txtBrushDX  = iTextColor.ToDxBrush(RenderTarget);}
			if(RenderTarget!=null && pSolidHistoColor!=null) {SolidHistoBrushDX  = this.pSolidHistoColor.ToDxBrush(RenderTarget);}
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			if (!IsVisible) return;
			if (chartControl==null) return;
#if DoLicense
			if (!ValidLicense) return;
#endif
			if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
			if(RenderTarget!=null && backBrush!=null && backBrushDX == null) {backBrushDX = backBrush.ToDxBrush(RenderTarget);}
			if(RenderTarget!=null && iTextColor!=null && txtBrushDX == null) {txtBrushDX  = iTextColor.ToDxBrush(RenderTarget);}
int line = 3489;
try{

line=3500;
			//NT7Graphics graphics = new NT7Graphics(RenderTarget);
			var RMaB       = Math.Max(1,Math.Min(ChartBars.ToIndex, BarsArray[0].Count-1));
			var txtFormat  = iBarFont.ToDirectWriteTextFormat();
			var txtLayout  = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, "100.", txtFormat, (float)(ChartPanel.X + ChartPanel.W), Convert.ToSingle(iBarFont.Size));
			float txtwidth100 = txtLayout.Metrics.Width;
			float FontHeight  = txtLayout.Metrics.Height;
			float marginLRTB  = 5f;
			float HistoHeight = FontHeight;

			float ratio = pGraphicSize/10f;
			float w     = marginLRTB*2f + (675 * ratio) + txtwidth100;
			float h     = marginLRTB*2f + (FontHeight + HistoHeight + 1f)*3f;
			var bounds  = new RectangleF(0, 0, w, h);
			float originX = 0;
			float originY = 0;

			if(MsgText!=null){
				var ts = new TimeSpan(DateTime.Now.Ticks - RecalcAt.Ticks);
				if(ts.TotalSeconds>5){
					MsgText = null;
					ForceRefresh();
				}else{
					txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, MsgText, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
					if(txtBrushDX!=null) {
						originX = bounds.Width*0.5f;
						originY = bounds.Height*0.66f;
						if(iGraphicLocation != ARC_VSR_Arb_Locations.TopLeft && iGraphicLocation != ARC_VSR_Arb_Locations.TopRight){
							originX = 10f;
							originY = bounds.Height*0.2f;
						}
						RenderTarget.DrawText(MsgText, txtFormat, new SharpDX.RectangleF(originX, originY, txtLayout.Metrics.Width, txtLayout.Metrics.Height), txtBrushDX);
					}
				}
			}

			var originalMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
			originX = 0;
			originY = 0;
			bool IsOnRight = false;
			if(iGraphicLocation == ARC_VSR_Arb_Locations.TopLeft){
				originX = 10f;
				originY = 20f;
			}else if(iGraphicLocation == ARC_VSR_Arb_Locations.TopRight){
				IsOnRight = true;
				originX = ChartPanel.W - (bounds.Width);
				originY = 10f;
			}else if(iGraphicLocation == ARC_VSR_Arb_Locations.Center){
				originX = (ChartPanel.W - (bounds.Width))/2f;
				originY = (ChartPanel.H - bounds.Height)/2f;
			}else if(iGraphicLocation == ARC_VSR_Arb_Locations.BottomLeft){
				originX = 10f;
				originY = ChartPanel.H - bounds.Height - FontHeight;
			}else if(iGraphicLocation == ARC_VSR_Arb_Locations.BottomRight){
				IsOnRight = true;
				originX = ChartPanel.W - (bounds.Width);
				originY = ChartPanel.H - bounds.Height - FontHeight;
			}
			bounds.X = originX;
			bounds.Y = originY;
			if(backBrushDX!=null) RenderTarget.FillRectangle(bounds, backBrushDX);
//				RenderTarget.DrawRectangle(backPen, originX, bounds.Top +originY, w-h, 252);

			// Initial Draw and Setup
			if (!this.bGraphicsInitialized)
			{
				this.bGraphicsInitialized = true;
				this.DrawGraphics(new SharpDX.RectangleF(originX, bounds.Top + originY, (int)w, (int)h));
			}
			this.SetGraphic(Math.Max(0, Math.Min(CurrentBars[0] - 1, chartControl.LastSlotPainted)));

			float x = bounds.X + marginLRTB;
			originX = x;
			float xHisto = x;//+ txtLayout.Metrics.Width*1.5f;
			float HistoMaxWidth = bounds.Width - marginLRTB*2f - txtwidth100;
			float y = bounds.Y + marginLRTB;
			float histoWidth = 0f;

		//draw 1st histo bar for "Volume"
			#region -- 1st thermometer --
			txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, "Volume", txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
			if(txtBrushDX!=null) {
				RenderTarget.DrawText("Volume", txtFormat, new SharpDX.RectangleF(x, y, txtLayout.Metrics.Width, txtLayout.Metrics.Height), txtBrushDX);
				y = y + FontHeight;
			}
			var gradientRect0 = new RectangleF(xHisto, y+1f, HistoMaxWidth, HistoHeight-2f);
			#region -- Create gradientBrushDX --
			var lgb0 = new LinearGradientBrush();
			if(pEnableGradientHisto){
				lgb0.StartPoint = new System.Windows.Point(gradientRect0.TopLeft.X, gradientRect0.TopLeft.Y);
				lgb0.EndPoint = new System.Windows.Point(gradientRect0.BottomRight.X,gradientRect0.BottomRight.Y);

				var redGS = new GradientStop(Colors.Red, 0.75);
				lgb0.GradientStops.Add(redGS);

				var yellowGS = new GradientStop(Colors.Yellow, 0.5);
				lgb0.GradientStops.Add(yellowGS);

				var greenGS = new GradientStop(Colors.Green, 0.25);
				lgb0.GradientStops.Add(greenGS);
				gradientBrushDX = lgb0.ToDxBrush(RenderTarget);
				#endregion
				RenderTarget.FillRectangle(gradientRect0, gradientBrushDX);//draw gradient rectangle
			}else{
				RenderTarget.FillRectangle(gradientRect0, SolidHistoBrushDX);
			}

			string histoValText = string.Empty;
			double val = Math.Max(0, Math.Min(sExtrnVolume.GetValueAt(RMaB), VOL_SCALE_MAX));
			if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage && VOL_SCALE_MAX!=100){
				val = val/Convert.ToDouble(VOL_SCALE_MAX);
				histoWidth = HistoMaxWidth * Convert.ToSingle(val);
				histoValText = (100*val).ToString("0");
			}else{
				histoWidth = HistoMaxWidth * Convert.ToSingle(val)/VOL_SCALE_MAX;
				histoValText = (val).ToString("0");
			}
			x = xHisto + histoWidth;
			if(backBrushDX!=null) RenderTarget.FillRectangle(new SharpDX.RectangleF(x, y, HistoMaxWidth-histoWidth, HistoHeight), backBrushDX);//blank-out the rightside of the gradient area, based on the size of the histo bar
			txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, histoValText, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
			if(txtBrushDX!=null) RenderTarget.DrawText(histoValText, txtFormat, new SharpDX.RectangleF(x + 5f, y, txtLayout.Metrics.Width*1.5f, txtLayout.Metrics.Height), txtBrushDX);
			#endregion

		//draw 2nd histo bar for "Speed"
			#region -- 2nd thermometer --
			x = originX;
			y = y + HistoHeight;
			txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, "Speed", txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
			if(txtBrushDX!=null) {
				RenderTarget.DrawText("Speed", txtFormat, new SharpDX.RectangleF(x,y, txtLayout.Metrics.Width, txtLayout.Metrics.Height), txtBrushDX);
				y = y + FontHeight;
			}

			gradientRect0.Y = y+1f;
			if(pEnableGradientHisto){
				gradientBrushDX.Dispose();
				lgb0.StartPoint = new System.Windows.Point(gradientRect0.TopLeft.X, gradientRect0.TopLeft.Y);
				lgb0.EndPoint   = new System.Windows.Point(gradientRect0.BottomRight.X,gradientRect0.BottomRight.Y);
				gradientBrushDX = lgb0.ToDxBrush(RenderTarget);
				RenderTarget.FillRectangle(gradientRect0, gradientBrushDX);//draw gradient rectangle
			}else{
				RenderTarget.FillRectangle(gradientRect0, SolidHistoBrushDX);
			}

			val = Math.Max(0, Math.Min(sExtrnSpeed.GetValueAt(RMaB), SPEED_SCALE_MAX));
			if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage && SPEED_SCALE_MAX!=100){
				val = val/SPEED_SCALE_MAX * 100f;
				histoWidth = HistoMaxWidth * Convert.ToSingle(val);
				histoValText = (100*val).ToString("0");
			}else{
				histoWidth = HistoMaxWidth * Convert.ToSingle(val)/SPEED_SCALE_MAX;
				histoValText = (val).ToString("0");
			}
			x = xHisto + histoWidth;
			if(backBrushDX!=null) RenderTarget.FillRectangle(new SharpDX.RectangleF(x, y, HistoMaxWidth-histoWidth, HistoHeight), backBrushDX);//blank-out the rightside of the gradient area, based on the size of the histo bar
			txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, histoValText, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
			if(txtBrushDX!=null) RenderTarget.DrawText(histoValText, txtFormat, new SharpDX.RectangleF(xHisto + histoWidth+5f, y, txtLayout.Metrics.Width*1.5f, txtLayout.Metrics.Height), txtBrushDX);
			#endregion

		//draw 3rd histo bar for "Range"
			#region -- 3rd thermometer --
			x = originX;
			y = y + HistoHeight;
			txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, "Range", txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
			if(txtBrushDX!=null){
				RenderTarget.DrawText("Range", txtFormat, new SharpDX.RectangleF(x,y, txtLayout.Metrics.Width, txtLayout.Metrics.Height), txtBrushDX);
				y = y + FontHeight;
			}

			gradientRect0.Y = y+1f;
			if(pEnableGradientHisto){
				gradientBrushDX.Dispose();
				lgb0.StartPoint = new System.Windows.Point(gradientRect0.TopLeft.X, gradientRect0.TopLeft.Y);
				lgb0.EndPoint   = new System.Windows.Point(gradientRect0.BottomRight.X,gradientRect0.BottomRight.Y);
				gradientBrushDX = lgb0.ToDxBrush(RenderTarget);
				RenderTarget.FillRectangle(gradientRect0, gradientBrushDX);//draw gradient rectangle
			}else{
				RenderTarget.FillRectangle(gradientRect0, SolidHistoBrushDX);
			}

			val = Math.Max(0, Math.Min(sExtrnRange.GetValueAt(RMaB), RANGE_SCALE_MAX));
			if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage && RANGE_SCALE_MAX!=100){
				val = val/RANGE_SCALE_MAX * 100f;
				histoWidth = HistoMaxWidth * Convert.ToSingle(val);
				histoValText = (100*val).ToString("0");
			}else{
				histoWidth = HistoMaxWidth * Convert.ToSingle(val)/RANGE_SCALE_MAX;
				histoValText = (val).ToString("0");
			}
			x = xHisto + histoWidth;
			if(backBrushDX!=null) RenderTarget.FillRectangle(new SharpDX.RectangleF(x, y, HistoMaxWidth-histoWidth, HistoHeight), backBrushDX);//blank-out the rightside of the gradient area, based on the size of the histo bar
			txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, histoValText, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
			if(txtBrushDX!=null) RenderTarget.DrawText(histoValText, txtFormat, new SharpDX.RectangleF(xHisto + histoWidth+5f, y, txtLayout.Metrics.Width*1.5f, txtLayout.Metrics.Height), txtBrushDX);
			#endregion

			if(pScaleType == ARC_VSR_Arb_ScaleType.Percentage){
				x = xHisto + (0.25f * HistoMaxWidth);
				var v1 = new SharpDX.Vector2(x, bounds.Y+marginLRTB);
				var v2 = new SharpDX.Vector2(x, v1.Y + bounds.Height-marginLRTB*2f);
				RenderTarget.DrawLine(v1, v2, txtBrushDX);
				x = xHisto + (0.5f * HistoMaxWidth);
				v1.X = x;
				v2.X = x;
				RenderTarget.DrawLine(v1, v2, txtBrushDX);
				x = xHisto + (0.75f * HistoMaxWidth);
				v1.X = x;
				v2.X = x;
				RenderTarget.DrawLine(v1, v2, txtBrushDX);
			}
line=3682;
//				this.CT.ThermometerControl_Paint(RenderTarget, originX, originY, this);

			RenderTarget.AntialiasMode = originalMode;
			if(gradientBrushDX!=null && !gradientBrushDX.IsDisposed) {gradientBrushDX.Dispose(); gradientBrushDX=null;}
} catch(Exception ex) {
	Log(line+":   Exception in OnRender: " + ex.Message + "\n" + ex.StackTrace, Cbi.LogLevel.Error);
}
		}

// ////////////////////////////////////////////////////////////////
		public void DrawGraphics(SharpDX.RectangleF iDrawBox)
		{
			int nBar_X = (int)iDrawBox.X;
			int nBar_Y = (int)iDrawBox.Y;
			int mBar_Width  = (int)iDrawBox.Width - (int)iDrawBox.Height;
			int mBar_Height = (int)iDrawBox.Height;

			SharpDX.RectangleF mBar_rect = new SharpDX.RectangleF(nBar_X, nBar_Y, mBar_Width / 3, mBar_Height);
			PlotBars(mBar_rect);		

//			int nCircle_Padding_Top = 10;
//			int nCircle_Padding_Right = 10;
//			int nCircle_Padding_Bottom = 10;
//			int nCircle_Padding_Left = 10;

//			int nCircle_X = mBar_Width;
//			int nCircle_Y = 0;
//			int mCircle_Width = (int)iDrawBox.Height;
//			int mCircle_Height = (int)iDrawBox.Height;

//			nCircle_X += nCircle_Padding_Left;
//			nCircle_Y += nCircle_Padding_Top;
//			mCircle_Width -= (nCircle_Padding_Right + nCircle_Padding_Left);
//			mCircle_Height -= (nCircle_Padding_Top + nCircle_Padding_Bottom);

//			SharpDX.RectangleF mCircle_rect = new SharpDX.RectangleF(nCircle_X, nCircle_Y, mCircle_Width, mCircle_Height);
//			PlotGauge(mCircle_rect);
		}

		private void PlotBars(SharpDX.RectangleF iBounds)
		{
			this.CT = new ClassThermometerBar(iBounds.Height, iBounds.Width);            

			this.CT.TitleColor = this.iTextColor;
			this.CT.DrawColor = this.iTextColor;

			this.CT.InitTitle_Bar1("Volume", this.iBarFont, 12, 90);
			this.CT.InitBaseVal_Bar1(VOL_SCALE_MIN, VOL_SCALE_MAX, 20, 20);

			this.CT.InitTitle_Bar2("Speed", this.iBarFont, 12, 86);
			this.CT.InitBaseVal_Bar2(SPEED_SCALE_MIN, SPEED_SCALE_MAX, 20, 10);

			this.CT.InitTitle_Bar3("Range", this.iBarFont, 12, 92);
			this.CT.InitBaseVal_Bar3(RANGE_SCALE_MIN, RANGE_SCALE_MAX, 20, 10);  			
		}		

		
		#endregion
		
		#region RegBloodHoundInterface
		
		[Browsable(false)]    
        [XmlIgnore()]
		public Series<double> RangeForecast
		{
			get 
			{
				return sExtrnRange;
			}
		}
		[Browsable(false)]    
        [XmlIgnore()]
		public Series<double> VolumeForecast
		{
			get 
			{
				return sExtrnVolume;
			}
		}
		[Browsable(false)]    
        [XmlIgnore()]
		public Series<double> SpeedForecast
		{
			get 
			{
				return sExtrnSpeed;
			}
		}	

		#endregion	

    }
    public class VSRArbConverter : IndicatorBaseConverter // or StrategyBaseConverter
    {
		#region VSRArbConverter
        public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object component, Attribute[] attrs)
        {
            // we need the indicator instance which actually exists on the grid
            ARC_VSR_Arb indicator = component as ARC_VSR_Arb;

            // base.GetProperties ensures we have all the properties (and associated property grid editors)
            // NinjaTrader internal logic determines for a given indicator
            PropertyDescriptorCollection propertyDescriptorCollection = base.GetPropertiesSupported(context)
                                                                        ? base.GetProperties(context, component, attrs)
                                                                        : TypeDescriptor.GetProperties(component, attrs);

			if (indicator == null || propertyDescriptorCollection == null)
			    return propertyDescriptorCollection;
//NinjaTrader.Code.Output.Process("", PrintTo.OutputTab1);
			// These values are will be shown/hidden (toggled) based on "ShowHideToggle" bool value
			List<PropertyDescriptor> toggles = new List<PropertyDescriptor>();
			if(indicator.ScaleType == ARC_VSR_Arb_ScaleType.Percentage){
				try{ toggles.Add(propertyDescriptorCollection["RArb_VolumeThreshold"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["RArb_RangeThreshold"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["RArb_SpeedThreshold"]);} catch(Exception e){indicator.Print(e.ToString());}

				try{ toggles.Add(propertyDescriptorCollection["SArb_VolumeThreshold"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["SArb_RangeThreshold"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["SArb_SpeedThreshold"]);} catch(Exception e){indicator.Print(e.ToString());}

				try{ toggles.Add(propertyDescriptorCollection["VArb_VolumeThreshold"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["VArb_RangeThreshold"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["VArb_SpeedThreshold"]);} catch(Exception e){indicator.Print(e.ToString());}
			}else{
				try{ toggles.Add(propertyDescriptorCollection["RArb_VolumeThresholdPct"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["RArb_RangeThresholdPct"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["RArb_SpeedThresholdPct"]);} catch(Exception e){indicator.Print(e.ToString());}

				try{ toggles.Add(propertyDescriptorCollection["SArb_VolumeThresholdPct"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["SArb_RangeThresholdPct"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["SArb_SpeedThresholdPct"]);} catch(Exception e){indicator.Print(e.ToString());}

				try{ toggles.Add(propertyDescriptorCollection["VArb_VolumeThresholdPct"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["VArb_RangeThresholdPct"]);} catch(Exception e){indicator.Print(e.ToString());}
				try{ toggles.Add(propertyDescriptorCollection["VArb_SpeedThresholdPct"]);} catch(Exception e){indicator.Print(e.ToString());}
			}
			if(toggles != null) {
				foreach(var pp in toggles) propertyDescriptorCollection.Remove(pp);
			}
			toggles.Clear();

			return propertyDescriptorCollection;
        }

        // Important: This must return true otherwise the type convetor will not be called
        public override bool GetPropertiesSupported(ITypeDescriptorContext context)
        { return true; }
		#endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_VSR_Arb[] cacheARC_VSR_Arb;
		public ARC.ARC_VSR_Arb ARC_VSR_Arb()
		{
			return ARC_VSR_Arb(Input);
		}

		public ARC.ARC_VSR_Arb ARC_VSR_Arb(ISeries<double> input)
		{
			if (cacheARC_VSR_Arb != null)
				for (int idx = 0; idx < cacheARC_VSR_Arb.Length; idx++)
					if (cacheARC_VSR_Arb[idx] != null &&  cacheARC_VSR_Arb[idx].EqualsInput(input))
						return cacheARC_VSR_Arb[idx];
			return CacheIndicator<ARC.ARC_VSR_Arb>(new ARC.ARC_VSR_Arb(), input, ref cacheARC_VSR_Arb);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_VSR_Arb ARC_VSR_Arb()
		{
			return indicator.ARC_VSR_Arb(Input);
		}

		public Indicators.ARC.ARC_VSR_Arb ARC_VSR_Arb(ISeries<double> input )
		{
			return indicator.ARC_VSR_Arb(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_VSR_Arb ARC_VSR_Arb()
		{
			return indicator.ARC_VSR_Arb(Input);
		}

		public Indicators.ARC.ARC_VSR_Arb ARC_VSR_Arb(ISeries<double> input )
		{
			return indicator.ARC_VSR_Arb(input);
		}
	}
}

#endregion
