#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
//using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
//using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
//using NinjaTrader.NinjaScript.Indicators;
using System.Windows.Controls;
#endregion

public enum ARC_SoundWave_OnOff {On, Off}
public enum ARC_SoundWave_WAVorDynamic {WAV, Dynamic}
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[CategoryOrder("Parameters",     10)]
	[CategoryOrder("Audio Loudness", 20)]
	[CategoryOrder("Custom Visuals", 30)]
	[CategoryOrder("Indicator Version", 1000)]
	public class ARC_SoundWave : Indicator
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "SoundWave";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "26845", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
				if(UserId.CompareTo("416913")==0) return true;// James Hyland  osmovalve@yahoo.com
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

        public override string DisplayName { get { return "SoundWave"; } }
		//private string VERSION = "v1.0 26-Oct-23";
		private string VERSION = "v1.1 21-Mar-24";//added the WAV files option, instead of the dynamic sound generator
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; }}

		#region  ----- Variables for button interface ----- 
		private string toolbarname = "ARCSoundWaveTB", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;

		private Menu MenuControlContainer;
		private MenuItem MenuControl;

		private MenuItem miRecalculate1, miSoundOnOff0, miSoundOnOff1, miSoundOnOff2, miSoundOnOff3, miSoundOnOff4, miSoundOnOff5, miSoundOnOff6, miSoundOnOff7;
		private MenuItem miFlipTheTape, miGraphicLocation;
		#endregion
		private int rHeight = 26;
		#region ----------  UI button pulldown  ----------
		#region ----- ChangeTextBoxValue -----
		private void ChangeTextValue(string Name, string Value, double Delta){
try{
			double incr = 0;
			if(!double.IsNaN(Delta)) {
				incr = Delta > 0 ? 1 : (Delta < 0 ? -1 : 0);
			}
//Print1("Name: "+Name+"   Value: "+Value+"    Delta: "+Delta);
			if (Value.Length > 0)
			{
				#region -- TICK --
//				if (Name.Contains("TICK_PctileOB")) {
//					if(incr!=0){
//						pTICK_PctileOB = Math.Max(0,Math.Min(1,Convert.ToDouble(Value) + incr/100.0));
//						tb_TICK_PctileOB.Text = pTICK_PctileOB.ToString();
//					}else{
//						pTICK_PctileOB = Math.Max(0,Math.Min(1,Convert.ToDouble(Value)));
//						tb_TICK_PctileOB.Text = Value;
//					}
//					ForceRefresh();
//					this.InformUserAboutRecalculation();
//				}
				#endregion ----------------- TICK
			}
}catch(Exception e){Print1(line+": "+e.ToString());}
		}
		#endregion
		#region  ----- createDoubleTextBox ----- 
        private Grid createDoubleTextBox(string name, string HeaderTxt, ref Label lbl, ref TextBox tb, string tb_Value)
        {
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });

			int row = 0;
			tb = new TextBox() { Name = name + uID, HorizontalContentAlignment=HorizontalAlignment.Center, VerticalContentAlignment=VerticalAlignment.Center, 
				MinWidth = 25, Width = 50, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0)};
			tb.Text = tb_Value;
			if(name.Contains("Pctile"))
				tb.ToolTip = "Hold down left-shift to decrease increment value to 0.01";
			else if(name.Contains("Manual"))
				tb.ToolTip = "Hold down left-shift to increase increment value to 5";
			tb.KeyDown += numericTxtbox_KeyDown;
			tb.SetValue(Grid.ColumnProperty, 1);
			tb.SetValue(Grid.RowProperty, row);
			tb.SetValue(Grid.RowSpanProperty, 2);
			lbl = new Label() { FontWeight=FontWeights.Normal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = HeaderTxt};
			lbl.SetValue(Grid.ColumnProperty, 0);
			lbl.SetValue(Grid.RowProperty, row);
			lbl.SetValue(Grid.RowSpanProperty, 2);
			grid.Children.Add(lbl);
            grid.Children.Add(tb);
			if(name.Contains("TICK_PctileOB")){
				#region ----- TICK_PctileOB -----
//				tb.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
//					e.Handled = true;
//					var original = pTICK_PctileOB;
//					var incr = 0.05;
//					if(System.Windows.Input.Keyboard.IsKeyDown(System.Windows.Input.Key.LeftShift))incr = 0.01;
//					if(e.Delta>0) pTICK_PctileOB = pTICK_PctileOB + incr; else pTICK_PctileOB = pTICK_PctileOB - incr;
//					pTICK_PctileOB = Math.Max(0.0,Math.Min(1,pTICK_PctileOB));
//					if(original != pTICK_PctileOB) InformUserAboutRecalculation();
//					var temp = Convert.ToInt32(pTICK_PctileOB/incr);
//					pTICK_PctileOB = temp * incr;
//					tb_TICK_PctileOB.Text = pTICK_PctileOB.ToString();
//					ForceRefresh();
//					};
				#endregion
			}

            return grid;
        }
		#endregion
		#region  ----- createIntegerTextBox ----- 
        private Grid createIntegerTextBox(string name, string HeaderTxt, ref Label lbl, ref TextBox tb, string tb_Value)
        {
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });

			int row = 0;
			lbl = new Label() { Name = name + uID, FontWeight = FontWeights.Normal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = HeaderTxt};
			lbl.SetValue(Grid.ColumnProperty, 0);
			lbl.SetValue(Grid.RowProperty, row);
			lbl.SetValue(Grid.RowSpanProperty, 2);

			tb = new TextBox() { Name = name + uID, HorizontalContentAlignment=HorizontalAlignment.Center, VerticalContentAlignment=VerticalAlignment.Center, 
				MinWidth = 25, Width = 50, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0)};
			tb.Text = tb_Value;
//			tb.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
//				e.Handled = true;
//				var tbi = (TextBox)o;
//				ChangeTextValue(tbi.Name, tbi.Text, e.Delta);
//				if(tbi.Name.Contains("TICK_ProximityBars")){
//					if(tbi.Text.Trim().Length>0){
//						int v = Math.Max(1,Convert.ToInt32(tbi.Text));
//						Inst[1].ProximityBars = v;
//					}else {Inst[1].ProximityBars = 1; tbi.Text = "1";}
//				}
//			};

			tb.KeyDown += numericTxtbox_KeyDown;
			tb.SetValue(Grid.ColumnProperty, 1);
			tb.SetValue(Grid.RowProperty, row);
			tb.SetValue(Grid.RowSpanProperty, 2);
			grid.Children.Add(lbl);
            grid.Children.Add(tb);

            return grid;
        }
		#endregion
		#region ----- createDateTextBox -----
        private Grid createDateTextBox(string name, string HeaderTxt, ref TextBox tb, string tb_Value)
        {
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
//			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
//			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(30) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });

			int row = 0;
			var lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = HeaderTxt, FontWeight=FontWeights.Normal };
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 2);

			tb = new TextBox() { Name = name + uID, FontWeight=FontWeights.Normal, HorizontalContentAlignment=HorizontalAlignment.Center, VerticalContentAlignment=VerticalAlignment.Center, MinWidth = 25, Width = 75, MaxWidth = 105, Height = rHeight, Margin = new Thickness(5, 0, 0, 0)};
			tb.Text = tb_Value;
//			tb.KeyDown += menuDateTxtbox_KeyDown;

			tb.SetValue(Grid.ColumnProperty, 1);
			tb.SetValue(Grid.RowProperty, row);
			tb.SetValue(Grid.RowSpanProperty, 2);
			grid.Children.Add(lbl1);
            grid.Children.Add(tb);

            return grid;
        }
		#endregion
		#region ------ numericTxtBox_KeyDown ------
		private string KeepTheseChars(string instr, string keepthese){
			string result = "";
			for(int i = 0; i<instr.Length; i++){
				if(keepthese.Contains(instr[i])) result = string.Format("{0}{1}",result,instr[i]);
			}
			return result.Replace(" ",string.Empty);
		}
		double temp = 0;
		private void numericTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			e.Handled  = true;
			TextBox txtSender = sender as TextBox;
			var s      = txtSender.Text;
			int keyVal = (int)e.Key;
			double value = double.MinValue;
			if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
				value = keyVal - (int)System.Windows.Input.Key.D0;
			else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
				value = keyVal - (int)System.Windows.Input.Key.NumPad0;

			bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.Decimal;
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.OemPeriod;
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.OemMinus;
			if (isNumeric || e.Key == System.Windows.Input.Key.Back)
			{
				string newText = value != double.MinValue ? value.ToString() : (e.Key==System.Windows.Input.Key.OemMinus ? "-" : string.Empty);
				if(!txtSender.Text.Contains(".")){
					if(e.Key == System.Windows.Input.Key.Decimal) newText = ".";
					else if(e.Key == System.Windows.Input.Key.OemPeriod) newText = ".";
				}
				int tbPosition = txtSender.SelectionStart;
				try{
					if(txtSender.SelectedText.Length==0)
						txtSender.Text = txtSender.Text.Insert(tbPosition, newText);
					else{
						txtSender.Text.Replace(txtSender.SelectedText, "");
						var s1 = txtSender.Text.Substring(0,tbPosition);
						var s2 = txtSender.Text.Substring(tbPosition + txtSender.SelectionLength);
						txtSender.Text = txtSender.Text.Substring(0, tbPosition)+ newText+s2;
					}
					txtSender.SelectionStart = tbPosition+1;
				}catch(Exception t){Print1(t.ToString());}
			}
			if(txtSender.Name.Contains("ProximityBars"))
				s = KeepTheseChars(txtSender.Text,"0123456789");
			else
				s = KeepTheseChars(txtSender.Text,"-0123456789.");
			if(s==string.Empty) {txtSender.Text = ""; return;}
			if(s=="-") {txtSender.Text = "-"; return;}
			if(s==".") txtSender.Text = "0.";
			ChangeTextValue(txtSender.Name, txtSender.Text, 0);
		}
		#endregion

//=====================================================================================================
		bool RestartRequired = false;
		private void InformUserAboutRecalculation(){
			if(miRecalculate1!=null){
				miRecalculate1.Background = Brushes.Yellow;
				miRecalculate1.FontWeight = FontWeights.Bold;
				miRecalculate1.FontStyle  = FontStyles.Italic;
				RestartRequired = true;
			}
		}
		private void ResetRecalculationUI(){
			if(miRecalculate1!=null){
				miRecalculate1.FontWeight = FontWeights.Normal;
				miRecalculate1.FontStyle  = FontStyles.Normal;
				miRecalculate1.Background = null;
				RestartRequired = false;
			}
		}
		#region  ----- addToolBar ----- 
		private void addToolBar()
		{

			MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
			var schoolbusyellow  = new SolidColorBrush(Color.FromArgb(255, 255, 240, 31));schoolbusyellow.Freeze();
			MenuControl          = new MenuItem { Name="ARC_SoundWave"+uID, BorderThickness = new Thickness(2), BorderBrush = schoolbusyellow, Header = pButtonText, Foreground = schoolbusyellow, Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);

			#region -- Sound enable controls --
			int k = 0;
			miSoundOnOff0 = new MenuItem { Header = "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff0.ToString(), Name = "miSoundOnOff"+k+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miSoundOnOff0.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pSoundOnOff0 = pSoundOnOff0 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 0;
				tv.Data[i].Silenced = pSoundOnOff0 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff0.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff0.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			miSoundOnOff0.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				pSoundOnOff0 = pSoundOnOff0 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 0;
				tv.Data[i].Silenced = pSoundOnOff0 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff0.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff0.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			if(tv.Data[k].Symbol[0]=='-') miSoundOnOff0.IsEnabled = false; else miSoundOnOff0.IsEnabled = true;
			miSoundOnOff0.Header = (tv.Data[k].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff0.ToString());
			MenuControl.Items.Add(miSoundOnOff0);
//==============================================================
			k = 1;
			miSoundOnOff1 = new MenuItem { Header = "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff1.ToString(), Name = "miSoundOnOff"+k+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miSoundOnOff1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pSoundOnOff1 = pSoundOnOff1 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 1;
				tv.Data[i].Silenced = pSoundOnOff1 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff1.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff1.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			miSoundOnOff1.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				pSoundOnOff1 = pSoundOnOff1 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 1;
				tv.Data[i].Silenced = pSoundOnOff1 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff1.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff1.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			if(tv.Data[k].Symbol[0]=='-') miSoundOnOff1.IsEnabled = false; else miSoundOnOff1.IsEnabled = true;
			miSoundOnOff1.Header = (tv.Data[k].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff1.ToString());
			MenuControl.Items.Add(miSoundOnOff1);
//==============================================================
			k = 2;
			miSoundOnOff2 = new MenuItem { Header = "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff2.ToString(), Name = "miSoundOnOff"+k+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miSoundOnOff2.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pSoundOnOff2 = pSoundOnOff2 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 2;
				tv.Data[i].Silenced = pSoundOnOff2 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff2.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff2.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			miSoundOnOff2.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				pSoundOnOff2 = pSoundOnOff2 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 2;
				tv.Data[i].Silenced = pSoundOnOff2 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff2.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff2.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			if(tv.Data[k].Symbol[0]=='-') miSoundOnOff2.IsEnabled = false; else miSoundOnOff2.IsEnabled = true;
			miSoundOnOff2.Header = (tv.Data[k].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff2.ToString());
			MenuControl.Items.Add(miSoundOnOff2);
//==============================================================
			k = 3;
			miSoundOnOff3 = new MenuItem { Header = "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff3.ToString(), Name = "miSoundOnOff"+k+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miSoundOnOff3.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pSoundOnOff3 = pSoundOnOff3 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 3;
				tv.Data[i].Silenced = pSoundOnOff3 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff3.Header = "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff3.ToString();
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			miSoundOnOff3.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				pSoundOnOff3 = pSoundOnOff3 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 3;
				tv.Data[i].Silenced = pSoundOnOff3 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff3.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff3.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			if(tv.Data[k].Symbol[0]=='-') miSoundOnOff3.IsEnabled = false; else miSoundOnOff3.IsEnabled = true;
			miSoundOnOff3.Header = (tv.Data[k].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff3.ToString());
			MenuControl.Items.Add(miSoundOnOff3);
//==============================================================
			k = 4;
			miSoundOnOff4 = new MenuItem { Header = "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff4.ToString(), Name = "miSoundOnOff"+k+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miSoundOnOff4.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pSoundOnOff4 = pSoundOnOff4 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 4;
				tv.Data[i].Silenced = pSoundOnOff4 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff4.Header = "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff4.ToString();
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			miSoundOnOff4.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				pSoundOnOff4 = pSoundOnOff4 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 4;
				tv.Data[i].Silenced = pSoundOnOff4 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff4.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff4.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			if(tv.Data[k].Symbol[0]=='-') miSoundOnOff4.IsEnabled = false; else miSoundOnOff4.IsEnabled = true;
			miSoundOnOff4.Header = (tv.Data[k].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff4.ToString());
			MenuControl.Items.Add(miSoundOnOff4);
//==============================================================
			k = 5;
			miSoundOnOff5 = new MenuItem { Header = "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff5.ToString(), Name = "miSoundOnOff"+k+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miSoundOnOff5.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pSoundOnOff5 = pSoundOnOff5 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 5;
				tv.Data[i].Silenced = pSoundOnOff5 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff5.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff5.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			miSoundOnOff5.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				pSoundOnOff5 = pSoundOnOff5 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 5;
				tv.Data[i].Silenced = pSoundOnOff5 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff5.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff5.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			if(tv.Data[k].Symbol[0]=='-') miSoundOnOff5.IsEnabled = false; else miSoundOnOff5.IsEnabled = true;
			miSoundOnOff5.Header = (tv.Data[k].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff5.ToString());
			MenuControl.Items.Add(miSoundOnOff5);
//==============================================================
			k = 6;
			miSoundOnOff6 = new MenuItem { Header = "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff6.ToString(), Name = "miSoundOnOff"+k+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miSoundOnOff6.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pSoundOnOff6 = pSoundOnOff6 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 6;
				tv.Data[i].Silenced = pSoundOnOff6 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff6.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff6.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			miSoundOnOff6.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				pSoundOnOff6 = pSoundOnOff6 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 6;
				tv.Data[i].Silenced = pSoundOnOff6 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff6.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff6.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			if(tv.Data[k].Symbol[0]=='-') miSoundOnOff6.IsEnabled = false; else miSoundOnOff6.IsEnabled = true;
			miSoundOnOff6.Header = (tv.Data[k].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff6.ToString());
			MenuControl.Items.Add(miSoundOnOff6);
//==============================================================
			k = 7;
			miSoundOnOff7 = new MenuItem { Header = "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff7.ToString(), Name = "miSoundOnOff"+k+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miSoundOnOff7.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pSoundOnOff7 = pSoundOnOff7 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 7;
				tv.Data[i].Silenced = pSoundOnOff7 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff7.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff7.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			miSoundOnOff7.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				pSoundOnOff7 = pSoundOnOff7 == ARC_SoundWave_OnOff.On ? ARC_SoundWave_OnOff.Off : ARC_SoundWave_OnOff.On;
				int i = 7;
				tv.Data[i].Silenced = pSoundOnOff7 == ARC_SoundWave_OnOff.Off;
				if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = 0;
				miSoundOnOff7.Header = (tv.Data[i].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[i].Symbol+": "+this.pSoundOnOff7.ToString());
//				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			if(tv.Data[k].Symbol[0]=='-') miSoundOnOff7.IsEnabled = false; else miSoundOnOff7.IsEnabled = true;
			miSoundOnOff7.Header = (tv.Data[k].Symbol[0]=='-' ? "disabled" : "Sound "+tv.Data[k].Symbol+": "+this.pSoundOnOff7.ToString());
			MenuControl.Items.Add(miSoundOnOff7);
//==============================================================
			#endregion

			MenuControl.Items.Add(new Separator());
			//===============================================================================
			#region -- FlipTheTape --
			miFlipTheTape = new MenuItem { Header = "Tape Flipped? "+this.pFlipTheTape.ToString(), Name = "miFlipTheTape"+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miFlipTheTape.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pFlipTheTape = !pFlipTheTape;
				tv.Data[0].FlipTheTape = pFlipTheTape;
				tv.Data[1].FlipTheTape = pFlipTheTape;
				tv.Data[2].FlipTheTape = pFlipTheTape;
				tv.Data[3].FlipTheTape = pFlipTheTape;
				tv.Data[4].FlipTheTape = pFlipTheTape;
				tv.Data[5].FlipTheTape = pFlipTheTape;
				tv.Data[6].FlipTheTape = pFlipTheTape;
				tv.Data[7].FlipTheTape = pFlipTheTape;
				miFlipTheTape.Header = "Tape Flipped? "+this.pFlipTheTape.ToString();
				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			miFlipTheTape.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				pFlipTheTape = !pFlipTheTape;
				tv.Data[0].FlipTheTape = pFlipTheTape;
				tv.Data[1].FlipTheTape = pFlipTheTape;
				tv.Data[2].FlipTheTape = pFlipTheTape;
				tv.Data[3].FlipTheTape = pFlipTheTape;
				tv.Data[4].FlipTheTape = pFlipTheTape;
				tv.Data[5].FlipTheTape = pFlipTheTape;
				tv.Data[6].FlipTheTape = pFlipTheTape;
				tv.Data[7].FlipTheTape = pFlipTheTape;
				miFlipTheTape.Header = "Tape Flipped? "+this.pFlipTheTape.ToString();
				InformUserAboutRecalculation();
//				ForceRefresh();
			};
			miFlipTheTape.Header = "Tape Flipped? "+this.pFlipTheTape.ToString();
			MenuControl.Items.Add(miFlipTheTape);
			#endregion
			//===============================================================================
			miGraphicLocation = new MenuItem { Header = "Location "+this.pGraphicLocation.ToString().Replace(" ",string.Empty), Name = "miGraphicLocation"+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miGraphicLocation.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(pGraphicLocation == TextPosition.BottomLeft) pGraphicLocation = TextPosition.BottomRight;
				else if(pGraphicLocation == TextPosition.BottomRight) pGraphicLocation = TextPosition.Center;
				else if(pGraphicLocation == TextPosition.Center) pGraphicLocation = TextPosition.TopLeft;
				else if(pGraphicLocation == TextPosition.TopLeft) pGraphicLocation = TextPosition.TopRight;
				else if(pGraphicLocation == TextPosition.TopRight) pGraphicLocation = TextPosition.BottomLeft;
				tv.RecalcTable = true;
				miGraphicLocation.Header = "Location "+this.pGraphicLocation.ToString().Replace(" ",string.Empty);
				ForceRefresh();
			};
			miGraphicLocation.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0){
					if(pGraphicLocation == TextPosition.BottomLeft) pGraphicLocation = TextPosition.BottomRight;
					else if(pGraphicLocation == TextPosition.BottomRight) pGraphicLocation = TextPosition.Center;
					else if(pGraphicLocation == TextPosition.Center) pGraphicLocation = TextPosition.TopLeft;
					else if(pGraphicLocation == TextPosition.TopLeft) pGraphicLocation = TextPosition.TopRight;
					else if(pGraphicLocation == TextPosition.TopRight) pGraphicLocation = TextPosition.BottomLeft;
				}else{
					if(pGraphicLocation == TextPosition.BottomLeft) pGraphicLocation = TextPosition.TopRight;
					else if(pGraphicLocation == TextPosition.BottomRight) pGraphicLocation = TextPosition.BottomLeft;
					else if(pGraphicLocation == TextPosition.Center) pGraphicLocation = TextPosition.BottomRight;
					else if(pGraphicLocation == TextPosition.TopLeft) pGraphicLocation = TextPosition.Center;
					else if(pGraphicLocation == TextPosition.TopRight) pGraphicLocation = TextPosition.TopLeft;
				}
				tv.RecalcTable = true;
				miGraphicLocation.Header = "Location "+this.pGraphicLocation.ToString().Replace(" ",string.Empty);
				ForceRefresh();
			};
			miGraphicLocation.Header = "Location "+this.pGraphicLocation.ToString().Replace(" ",string.Empty);
			MenuControl.Items.Add(miGraphicLocation);

			//===============================================================================
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
//				Draw.TextFixed(this, "DataLoadingMsg", "Reclaculating profiles in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			MenuControl.Items.Add(miRecalculate1);
	//- - - - - - - - - - - - - 
			#region -- Recalc --
//			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", Name = "btn_Recalc1"+uID, HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
//			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
//				ResetRecalculationUI();
//				System.Windows.Forms.SendKeys.SendWait("{F5}");
//			};
//			MenuControl.Items.Add(miRecalculate1);
			#endregion
		//------------------

			indytoolbar.Children.Add(MenuControlContainer);
		}
		#endregion
		#endregion
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "ARC_SoundWave";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DrawOnPricePanel							= true;
				IsSuspendedWhileInactive = false;

				pHistoCalcBasis = ARC_SoundWaveEngine_HistoBasis.SumTotal;
				pSecondsLookback = 3;
				pThresholdSmoothingPeriod = 200;
				pSoundsMode = ARC_SoundWave_WAVorDynamic.Dynamic;
				pHiAlertWAV = "HiPitch_1500Hz.wav";
				pMidAlertWAV = "MidPitch_1000Hz.wav";
				pLowAlertWAV = "LowPitch_500Hz.wav";
				pSensitivityFactor0 = 50;
				pSensitivityFactor1 = 50;
				pSensitivityFactor2 = 50;
				pSensitivityFactor3 = 50;
				pSensitivityFactor4 = 50;
				pSensitivityFactor5 = 50;
				pSensitivityFactor6 = 50;
				pSensitivityFactor7 = 50;
				pNBarLookback = 0;
				pShowExpirationDates = false;
				pAudioVolume_HiAlert = 100;
				pAudioVolume_MedAlert = 80;
				pAudioVolume_Alert = 60;
				pGraphRegionSize = 300f;
				pShowTapeFlipStatus = true;
				pButtonText = "SoundWave";
				pGraphicLocation = TextPosition.TopLeft;

				pSmoothingType = ARC_SoundWaveEngine_SmoothingType.Simple;

				pSmallNegativeHistoBrush = Brushes.DarkRed;
				pBigNegativeHistoBrush = Brushes.Magenta;
				pSmallPositiveHistoBrush = Brushes.DarkGreen;
				pBigPositiveHistoBrush = Brushes.Lime;
				pGraphicBoxBrush = Brushes.Yellow;
				pGraphicBoxFillBrush = Brushes.Black;
				pSymbol1 = "ES 06-25";
				pSymbol2 = "NQ 06-25";
				pSymbol3 = "YM 06-25";
				pSymbol4 = "RTY 06-25";
				pSymbol5 = "none";
				pSymbol6 = "none";
				pSymbol7 = "none";
				pFlipTheTape = false;
			}
			else if (State == State.Configure)
			{
				IsDebug=System.IO.File.Exists("c:\\222222222222.txt");
				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion

				#region -- Configure --
				tv.Data.Add(new RowData(GetSymbolName(Instruments[0].FullName), 0,0, pSensitivityFactor0, pFlipTheTape));
				swe0 = ARC_SoundWaveEngine(BarsArray[0], pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor0, pSmoothingType, pFlipTheTape);
				tv.Data[0].Silenced = pSoundOnOff0 == ARC_SoundWave_OnOff.Off;

				var btype = BarsPeriodType.Minute;
				var s = pSymbol1.ToUpper().Trim();
				if(s.Length>0 && s!="NONE" && s.CompareTo(Instruments[0].FullName)!=0){
					AddDataSeries(s, btype, 1);
					tv.Data.Add(new RowData(GetSymbolName(Instruments[1].FullName), 0,0, pSensitivityFactor1, pFlipTheTape));
					try{
						swe1 = ARC_SoundWaveEngine(BarsArray[1], pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor1, pSmoothingType, pFlipTheTape);
					}catch(Exception e){Print1(line+":  Err: "+e.ToString()); tv.Data.Last().Symbol = "-";}
				}else{
					tv.Data.Add(new RowData("-", 0,0,0, pFlipTheTape));
					AddDataSeries(Instruments[0].FullName, btype, 1);
				}
				tv.Data[1].Silenced = pSoundOnOff1 == ARC_SoundWave_OnOff.Off;

				s = pSymbol2.ToUpper().Trim();
				if(s.Length>0 && s!="NONE" && s.CompareTo(Instruments[0].FullName)!=0){
					AddDataSeries(s, btype, 1);
					tv.Data.Add(new RowData(GetSymbolName(Instruments[2].FullName), 0,0, pSensitivityFactor2, pFlipTheTape));
					try{
						swe2 = ARC_SoundWaveEngine(BarsArray[2], pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor2, pSmoothingType, pFlipTheTape);
					}catch(Exception e){Print1(line+":  Err: "+e.ToString()); tv.Data.Last().Symbol = "-";}
				}else{
					tv.Data.Add(new RowData("-", 0,0,0, pFlipTheTape));
					AddDataSeries(Instruments[0].FullName, btype, 1);
				}
				tv.Data[2].Silenced = pSoundOnOff2 == ARC_SoundWave_OnOff.Off;

				s = pSymbol3.ToUpper().Trim();
				if(s.Length>0 && s!="NONE" && s.CompareTo(Instruments[0].FullName)!=0){
					AddDataSeries(s, btype, 1);
					tv.Data.Add(new RowData(GetSymbolName(Instruments[3].FullName), 0,0, pSensitivityFactor3, pFlipTheTape));
					try{
						swe3 = ARC_SoundWaveEngine(BarsArray[3], pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor3, pSmoothingType, pFlipTheTape);
					}catch(Exception e){Print1(line+":  Err: "+e.ToString()); tv.Data.Last().Symbol = "-";}
				}else{
					tv.Data.Add(new RowData("-", 0,0,0, pFlipTheTape));
					AddDataSeries(Instruments[0].FullName, btype, 1);
				}
				tv.Data[3].Silenced = pSoundOnOff3 == ARC_SoundWave_OnOff.Off;

				s = pSymbol4.ToUpper().Trim();
				if(s.Length>0 && s!="NONE" && s.CompareTo(Instruments[0].FullName)!=0){
					AddDataSeries(s, btype, 1);
					tv.Data.Add(new RowData(GetSymbolName(Instruments[4].FullName), 0,0, pSensitivityFactor4, pFlipTheTape));
					try{
						swe4 = ARC_SoundWaveEngine(BarsArray[4], pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor4, pSmoothingType, pFlipTheTape);
					}catch(Exception e){Print1(line+":  Err: "+e.ToString()); tv.Data.Last().Symbol = "-";}
				}else{
					tv.Data.Add(new RowData("-", 0,0,0, pFlipTheTape));
					AddDataSeries(Instruments[0].FullName, btype, 1);
				}
				tv.Data[4].Silenced = pSoundOnOff4 == ARC_SoundWave_OnOff.Off;

				s = pSymbol5.ToUpper().Trim();
				if(s.Length>0 && s!="NONE" && s.CompareTo(Instruments[0].FullName)!=0){
					AddDataSeries(s, btype, 1);
					tv.Data.Add(new RowData(GetSymbolName(Instruments[5].FullName), 0,0, pSensitivityFactor5, pFlipTheTape));
					try{
						swe5 = ARC_SoundWaveEngine(BarsArray[5], pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor5, pSmoothingType, pFlipTheTape);
					}catch(Exception e){Print1(line+":  Err: "+e.ToString()); tv.Data.Last().Symbol = "-";}
				}else{
					tv.Data.Add(new RowData("-", 0,0,0, pFlipTheTape));
					AddDataSeries(Instruments[0].FullName, btype, 1);
				}
				tv.Data[5].Silenced = pSoundOnOff5 == ARC_SoundWave_OnOff.Off;

				s = pSymbol6.ToUpper().Trim();
				if(s.Length>0 && s!="NONE" && s.CompareTo(Instruments[0].FullName)!=0){
					AddDataSeries(s, btype, 1);
					tv.Data.Add(new RowData(GetSymbolName(Instruments[6].FullName), 0,0, pSensitivityFactor6, pFlipTheTape));
					try{
						swe6 = ARC_SoundWaveEngine(BarsArray[6], pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor6, pSmoothingType, pFlipTheTape);
					}catch(Exception e){Print1(line+":  Err: "+e.ToString()); tv.Data.Last().Symbol = "-";}
				}else{
					tv.Data.Add(new RowData("-", 0,0,0, pFlipTheTape));
					AddDataSeries(Instruments[0].FullName, btype, 1);
				}
				tv.Data[6].Silenced = pSoundOnOff6 == ARC_SoundWave_OnOff.Off;

				s = pSymbol7.ToUpper().Trim();
				if(s.Length>0 && s!="NONE" && s.CompareTo(Instruments[0].FullName)!=0){
					AddDataSeries(s, btype, 1);
					tv.Data.Add(new RowData(GetSymbolName(Instruments[7].FullName), 0,0, pSensitivityFactor7, pFlipTheTape));
					try{
						swe7 = ARC_SoundWaveEngine(BarsArray[7], pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor7, pSmoothingType, pFlipTheTape);
					}catch(Exception e){Print1(line+":  Err: "+e.ToString()); tv.Data.Last().Symbol = "-";}
				}else{
					tv.Data.Add(new RowData("-", 0,0,0, pFlipTheTape));
					AddDataSeries(Instruments[0].FullName, btype, 1);
				}
				tv.Data[7].Silenced = pSoundOnOff7 == ARC_SoundWave_OnOff.Off;
				#endregion
			}
			else if (State == State.DataLoaded){
//				LaunchTime = DateTime.MaxValue;
//				for(int x = 0; x<BarsArray.Length; x++){
//					if(BarsArray[x].LastBarTime < LaunchTime) LaunchTime = BarsArray[x].LastBarTime;
//	Print1("Instrument "+Instruments[x].FullName+"  "+BarsArray[x].LastBarTime.ToString()+"    "+BarsArray[x].BarsPeriod.ToString());
//				}
				Draw.TextFixed(this,"connectioninfo","SoundWave waiting for data connection",TextPosition.TopLeft);
				TicksToNextBeep = Convert.ToInt64(TimeSpan.TicksPerSecond/3.0);
	            #region -- Add Custom Toolbar --
	            if (!isToolBarButtonAdded && ChartControl != null)
	                Dispatcher.BeginInvoke(new Action(() =>
	                {
	                    chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
	                    if (chartWindow == null) return;
	                    
	                    foreach (DependencyObject item in chartWindow.MainMenu) if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

	                    if (!isToolBarButtonAdded)
	                    {
	                        indytoolbar = new Grid { Visibility = Visibility.Collapsed };

	                        addToolBar();
	                        
	                        chartWindow.MainMenu.Add(indytoolbar);
	                        chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

	                        foreach (TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
	                        System.Windows.Automation.AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
	                    }
	                }));
	            #endregion

			}else if (State == State.Realtime){
				LaunchTime = BarsArray[1].LastBarTime;
				if(ChartControl==null) PrintTo = PrintTo.OutputTab1;
				else PrintTo = PrintTo.OutputTab2;
			}
            else if(State == State.Terminated)
            {
	            #region  ----- State == State.Terminated ----- 
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
	            #endregion
            }
		}
//===============================================================================================
		#region  ----- TabSelectionChangedHandler ----- 
		private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}
		#endregion
//===============================================================================================

		private DateTime LaunchTime = DateTime.MinValue;
		private string GetSymbolName(string symbol){
			if(pShowExpirationDates) return symbol;
			var s = symbol.Split(new char[]{' '}, StringSplitOptions.RemoveEmptyEntries);
			if(s.Length>=1) return s[0]; else return symbol;
		}
		int c = 0;
		string lastprint = "";
		private void Print1(string s){
			if(!IsDebug) return;
			if(c<20000 && lastprint.CompareTo(s)!=0) Print ("SWave:  "+s);
			lastprint=s;
			c++;
		}
		private void Print1(int s){
			if(!IsDebug) return;
			Print ("SWave:  "+s);
		}
		ARC_SoundWaveEngine swe0 = null;
		ARC_SoundWaveEngine swe1 = null;
		ARC_SoundWaveEngine swe2 = null;
		ARC_SoundWaveEngine swe3 = null;
		ARC_SoundWaveEngine swe4 = null;
		ARC_SoundWaveEngine swe5 = null;
		ARC_SoundWaveEngine swe6 = null;
		ARC_SoundWaveEngine swe7 = null;
		int line = 0;
//		List<string> errors = new List<string>();
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			int bip = BarsInProgress;
			if(CurrentBars[bip]<2) return;
try{
			if(bip==0 && swe0!=null){
				tv.Data[bip].HiThresh = swe0.Threshold[1];
				tv.Data[bip].LoThresh = -swe0.Threshold[1];
				tv.Data[bip].Val = swe0.Flow[0];
//errors.Add(string.Format("{0}:{1}    Val:  {2}  Thresh: {3} ",Times[1][0].Second, Times[1][0].Millisecond, tv.Data[bip].Val, tv.Data[bip].HiThresh.ToString()));
			}else if(bip==1 && swe1!=null){
				tv.Data[bip].HiThresh = swe1.Threshold[1];
				tv.Data[bip].LoThresh = -swe1.Threshold[1];
				tv.Data[bip].Val = swe1.Flow[0];
			}else if(bip==2 && swe2!=null){
				tv.Data[bip].HiThresh = swe2.Threshold[1];
				tv.Data[bip].LoThresh = -swe2.Threshold[1];
				tv.Data[bip].Val = swe2.Flow[0];
			}else if(bip==3 && swe3!=null){
				tv.Data[bip].HiThresh = swe3.Threshold[1];
				tv.Data[bip].LoThresh = -swe3.Threshold[1];
				tv.Data[bip].Val = swe3.Flow[0];
			}else if(bip==4 && swe4!=null){
				tv.Data[bip].HiThresh = swe4.Threshold[1];
				tv.Data[bip].LoThresh = -swe4.Threshold[1];
				tv.Data[bip].Val = swe4.Flow[0];
			}else if(bip==5 && swe5!=null){
				tv.Data[bip].HiThresh = swe5.Threshold[1];
				tv.Data[bip].LoThresh = -swe5.Threshold[1];
				tv.Data[bip].Val = swe5.Flow[0];
			}else if(bip==6 && swe6!=null){
				tv.Data[bip].HiThresh = swe6.Threshold[1];
				tv.Data[bip].LoThresh = -swe6.Threshold[1];
				tv.Data[bip].Val = swe6.Flow[0];
			}else if(bip==7 && swe7!=null){
				tv.Data[bip].HiThresh = swe7.Threshold[1];
				tv.Data[bip].LoThresh = -swe7.Threshold[1];
				tv.Data[bip].Val = swe7.Flow[0];
			}
			if(bip != 0) ForceRefresh();
}catch(Exception e){Print1(line+": "+e.ToString());}
		}
		private TableVisuals tv = new TableVisuals();
//=======================================================================================================================
		SharpDX.DirectWrite.TextLayout textLayout = null;
		SharpDX.DirectWrite.TextFormat textFormat = null;
		SharpDX.DirectWrite.TextFormat textFormatBold = null;
		SharpDX.DirectWrite.TextFormat textFormatHeader = null;
		SharpDX.DirectWrite.TextFormat textFormat_SensFactors = null;
		SimpleFont font = new SimpleFont("Arial",15);
		private class RowData{
			public string Symbol   = "";
			public double Val      = 0;//current histogram value
			public double PriorVal = 0;//histo value on prior tick - if the current val == prior val, no audible alerts are played
			public double LoThresh  = 0;
			public double HiThresh  = 0;
			public double PxPerUnit = 0;
			public int SensitivityFactor = 0;
			public bool FlipTheTape = false;
			public string Info = string.Empty;
			public bool Silenced = false;
			public long TimeOfNextBeep = long.MaxValue;//this is the earliest time that an audible signal will play on this instrument, this gets adjusted within OnRender during the intialization logic
//			public bool SoundOnOff = true;
			public RowData(string symbol, double lowerval, double upperval, int sensitivityfactor, bool flipthetape){Symbol = symbol; LoThresh = lowerval; HiThresh = upperval; SensitivityFactor=sensitivityfactor; FlipTheTape = flipthetape;}
		}
		private class TableVisuals{
			public bool RecalcTable   = true;
			public float TableLeftX   = 0;
			public float LowerThreshX = 0;
			public float UpperThreshX = 0;
			public float GraphLeftX   = 0;
			public float GraphTopY    = 0;
			public float GraphRightX  = 0;
			public float GraphCenterX = 0;
			public float GraphRowHeight = 0;
//			public float BkgWidth     = 0;
			public float TableHeight    = 0;
			public float SymbolColWidth = 0;
			public float SFColumnWidth = 0;
			public int RowCount = 0;
			public SharpDX.RectangleF BkgRect;
			public SharpDX.RectangleF GraphRect;
			public SharpDX.RectangleF TableHeaderRect;
			public List<RowData> Data = new List<RowData>();
		}

		long TicksToNextBeep = 0;
		float left_margin = 10f;
		SharpDX.Vector2 vL;
		SimpleFont smallfont = new SimpleFont("Arial",12);
		SimpleFont headerfont = new SimpleFont("Arial",18);
		float PanelW = 0;
		float PanelH = 0;
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale){
			SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
try{
            #region -- conditions to return --
            if (Bars == null || ChartControl == null || ChartBars==null) return;
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
			if (IsInHitTest) return;
			if (!IsConnected) return;
            #endregion

			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
			float y = 50f;
			var c1 = PanelW != ChartPanel.W || PanelH != ChartPanel.H;
			PanelW = ChartPanel.W;
			PanelH = ChartPanel.H; // Print1("W: "+PanelW+"  H: "+PanelH);
			if(c1 || tv.RecalcTable){
				#region -- Initialize table values --
				tv.RecalcTable = false;
				tv.SFColumnWidth = 0f;
				#region --- Init Text Format variables ---
				if(pShowSensitivityFactors)
				{
					textFormat_SensFactors = new SharpDX.DirectWrite.TextFormat(
				        Core.Globals.DirectWriteFactory,
				        smallfont.FamilySerialize,
				        SharpDX.DirectWrite.FontWeight.Bold,
				        smallfont.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				        SharpDX.DirectWrite.FontStretch.Normal,
				        (float)smallfont.Size
				        );
					for(int i = 0; i<Instruments.Length; i++){
						if(tv.Data[i].Symbol[0]=='-') continue;
						tv.Data[i].Info = string.Format("{0}% SF", tv.Data[i].SensitivityFactor.ToString("0"));
						textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, tv.Data[i].Info, textFormat_SensFactors, float.MaxValue, float.MaxValue);
						tv.SFColumnWidth = Math.Max(tv.SFColumnWidth, textLayout.Metrics.Width);
					}
				}
line=1577;
				textFormat = new SharpDX.DirectWrite.TextFormat(
			        Core.Globals.DirectWriteFactory,
			        font.FamilySerialize,
			        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
			        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
			        SharpDX.DirectWrite.FontStretch.Normal,
			        (float)font.Size
			        );
line=1586;
				textFormatHeader = new SharpDX.DirectWrite.TextFormat(
			        Core.Globals.DirectWriteFactory,
			        headerfont.FamilySerialize,
			        SharpDX.DirectWrite.FontWeight.Bold,
			        headerfont.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
			        SharpDX.DirectWrite.FontStretch.Normal,
			        (float)headerfont.Size
			        );
line=1595;
				textFormatBold = new SharpDX.DirectWrite.TextFormat(
			        Core.Globals.DirectWriteFactory,
			        font.FamilySerialize,
			        SharpDX.DirectWrite.FontWeight.Bold,
			        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
			        SharpDX.DirectWrite.FontStretch.Normal,
			        (float)font.Size
			        );
				#endregion
				tv.RowCount = 0;
				for(int i = 0; i<Instruments.Length; i++){
					if(tv.Data[i].Symbol[0]=='-') continue;
					tv.RowCount++;
					//now, calculate the width of the symbol column, find the largest symbol name
					textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, tv.Data[i].Symbol, textFormatBold, float.MaxValue, float.MaxValue);
					tv.SymbolColWidth = Math.Max(tv.SymbolColWidth, textLayout.Metrics.Width);
					if(!tv.Data[i].Silenced) tv.Data[i].TimeOfNextBeep = LaunchTime.Ticks + TimeSpan.TicksPerSecond*3;//mandatory silence for 3 seconds after recalc of table
				}
				#region -- Calculate x y width and height values for table --
				tv.TableLeftX      = 10f;//these are settings for TopLeft position
				tv.GraphTopY       = y;
				tv.GraphLeftX      = tv.TableLeftX + tv.SymbolColWidth+ left_margin + 4f;
				tv.GraphRightX     = tv.GraphLeftX + pGraphRegionSize;
				tv.GraphRowHeight  = textLayout.Metrics.Height+4f;
				tv.GraphCenterX    = tv.GraphLeftX + pGraphRegionSize/2;
				tv.LowerThreshX    = tv.GraphLeftX + pGraphRegionSize/4;
				tv.UpperThreshX    = tv.GraphLeftX + pGraphRegionSize * 3.0f/4.0f;
				tv.TableHeaderRect = new SharpDX.RectangleF(tv.TableLeftX + left_margin, tv.GraphTopY-Convert.ToSingle(font.Size)-11f, pGraphRegionSize, Convert.ToSingle(font.Size + 8.0));
				float BkgWidth     = tv.GraphLeftX + pGraphRegionSize + (pShowSensitivityFactors ? tv.SFColumnWidth:0f) + left_margin-7f;
				tv.BkgRect   = new SharpDX.RectangleF(tv.TableLeftX, tv.TableHeaderRect.Y-3f, BkgWidth, Convert.ToSingle(tv.GraphRowHeight * tv.RowCount + 28 + (tv.TableHeaderRect.Height)));
//Print1("a xywh: "+tv.BkgRect.X+"  "+tv.BkgRect.Y+"  "+tv.BkgRect.Width+"  "+tv.BkgRect.Height);
				tv.GraphRect = new SharpDX.RectangleF(tv.GraphLeftX, tv.GraphTopY, pGraphRegionSize, tv.GraphRowHeight * tv.RowCount + 8);
				if(pGraphicLocation == TextPosition.TopRight){
					tv.TableLeftX      = ChartPanel.W - tv.BkgRect.Width;
					tv.GraphLeftX      = tv.TableLeftX + tv.SymbolColWidth+ left_margin + 4f;
					tv.GraphRightX     = tv.GraphLeftX + pGraphRegionSize;
					tv.GraphCenterX    = tv.GraphLeftX + pGraphRegionSize/2;
					tv.LowerThreshX    = tv.GraphLeftX + pGraphRegionSize/4;
					tv.UpperThreshX    = tv.GraphLeftX + pGraphRegionSize * 3.0f/4.0f;
					tv.TableHeaderRect = new SharpDX.RectangleF(tv.TableLeftX + left_margin, tv.GraphTopY-Convert.ToSingle(font.Size)-11f, pGraphRegionSize, Convert.ToSingle(font.Size + 8.0));
					tv.BkgRect   = new SharpDX.RectangleF(tv.TableLeftX, tv.TableHeaderRect.Y-3f, BkgWidth, Convert.ToSingle(tv.GraphRowHeight * tv.RowCount + 28 + (tv.TableHeaderRect.Height)));
					tv.GraphRect = new SharpDX.RectangleF(tv.GraphLeftX, tv.GraphTopY, pGraphRegionSize, tv.GraphRowHeight * tv.RowCount + 8);
				}else if(pGraphicLocation == TextPosition.BottomRight){
					y = ChartPanel.H - tv.BkgRect.Height;
					tv.TableLeftX      = ChartPanel.W - tv.BkgRect.Width;
					tv.GraphTopY       = y;
					tv.GraphLeftX      = tv.TableLeftX + tv.SymbolColWidth+ left_margin + 4f;
					tv.GraphRightX     = tv.GraphLeftX + pGraphRegionSize;
					tv.GraphCenterX    = tv.GraphLeftX + pGraphRegionSize/2;
					tv.LowerThreshX    = tv.GraphLeftX + pGraphRegionSize/4;
					tv.UpperThreshX    = tv.GraphLeftX + pGraphRegionSize * 3.0f/4.0f;
					tv.TableHeaderRect = new SharpDX.RectangleF(tv.TableLeftX + left_margin, tv.GraphTopY-Convert.ToSingle(font.Size)-11f, pGraphRegionSize, Convert.ToSingle(font.Size + 8.0));
					tv.BkgRect   = new SharpDX.RectangleF(tv.TableLeftX, tv.TableHeaderRect.Y-3f, BkgWidth, Convert.ToSingle(tv.GraphRowHeight * tv.RowCount + 28 + (tv.TableHeaderRect.Height)));
					tv.GraphRect = new SharpDX.RectangleF(tv.GraphLeftX, tv.GraphTopY, pGraphRegionSize, tv.GraphRowHeight * tv.RowCount + 8);
				}else if(pGraphicLocation == TextPosition.Center){
					y = ChartPanel.H/2f - tv.BkgRect.Height/2f;
					tv.TableLeftX      = ChartPanel.W/2f - tv.BkgRect.Width/2f;
					tv.GraphTopY       = y;
					tv.GraphLeftX      = tv.TableLeftX + tv.SymbolColWidth+ left_margin + 4f;
					tv.GraphRightX     = tv.GraphLeftX + pGraphRegionSize;
					tv.GraphCenterX    = tv.GraphLeftX + pGraphRegionSize/2;
					tv.LowerThreshX    = tv.GraphLeftX + pGraphRegionSize/4;
					tv.UpperThreshX    = tv.GraphLeftX + pGraphRegionSize * 3.0f/4.0f;
					tv.TableHeaderRect = new SharpDX.RectangleF(tv.TableLeftX + left_margin, tv.GraphTopY-Convert.ToSingle(font.Size)-11f, pGraphRegionSize, Convert.ToSingle(font.Size + 8.0));
					tv.BkgRect   = new SharpDX.RectangleF(tv.TableLeftX, tv.TableHeaderRect.Y-3f, BkgWidth, Convert.ToSingle(tv.GraphRowHeight * tv.RowCount + 28 + (tv.TableHeaderRect.Height)));
					tv.GraphRect = new SharpDX.RectangleF(tv.GraphLeftX, tv.GraphTopY, pGraphRegionSize, tv.GraphRowHeight * tv.RowCount + 8);
				}else if(pGraphicLocation == TextPosition.BottomLeft){
					y = ChartPanel.H - tv.BkgRect.Height;
					tv.GraphTopY       = y;
					tv.TableHeaderRect = new SharpDX.RectangleF(tv.TableLeftX + left_margin, tv.GraphTopY-Convert.ToSingle(font.Size)-11f, pGraphRegionSize, Convert.ToSingle(font.Size + 8.0));
					tv.BkgRect   = new SharpDX.RectangleF(tv.TableLeftX, tv.TableHeaderRect.Y-3f, BkgWidth, Convert.ToSingle(tv.GraphRowHeight * tv.RowCount + 28 + (tv.TableHeaderRect.Height)));
					tv.GraphRect = new SharpDX.RectangleF(tv.GraphLeftX, tv.GraphTopY, pGraphRegionSize, tv.GraphRowHeight * tv.RowCount + 8);
				}
				#endregion
				#endregion
			}
			#region -- Draw the table --
			if(GraphicBoxFillBrushDX!=null){
				RenderTarget.FillRectangle(tv.BkgRect, GraphicBoxFillBrushDX);
			}
			textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, "SoundWave", textFormatHeader, float.MaxValue, float.MaxValue);
			if(GraphicBoxBrushDX!=null){
				RenderTarget.DrawTextLayout(new SharpDX.Vector2(tv.TableHeaderRect.X, tv.TableHeaderRect.Y + 2f), textLayout, GraphicBoxBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
				var str = RestartRequired ? "Recalc required" : (pShowTapeFlipStatus ? (pFlipTheTape? "Tape: Flipped":"Tape: Normal"):"");
				if(str!=""){
					textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, str, textFormatHeader, float.MaxValue, float.MaxValue);
					RenderTarget.DrawTextLayout(new SharpDX.Vector2(tv.BkgRect.X + tv.BkgRect.Width - textLayout.Metrics.Width-left_margin, tv.TableHeaderRect.Y + 2f), textLayout, GraphicBoxBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
				}
			}
			#region -- Draw table, histos and instrument text
			if(textLayout!=null && !textLayout.IsDisposed) textLayout.Dispose();
			vL = new SharpDX.Vector2(tv.TableLeftX+left_margin, tv.GraphTopY+2f);
			var vT1 = new SharpDX.Vector2(0, tv.GraphTopY + 2f);
			var vT2 = new SharpDX.Vector2(0, tv.GraphTopY + tv.GraphRowHeight-2f);
			y = tv.GraphTopY+3f;
line=1648;
			float HistoY = tv.GraphTopY + 3f;
			float HistoHeight = tv.GraphRowHeight - 4f;
			int row = 0;
			char PosOrNeg = 'P';
			char BigOrSmall = ' ';
			for(int i = 0; i<Instruments.Length; i++){
				if(tv.Data[i].Symbol[0] == '-') continue;
				tv.Data[i].PxPerUnit = (tv.UpperThreshX - tv.GraphCenterX)/(tv.Data[i].HiThresh);
				y = HistoY + tv.GraphRowHeight * row; row++;
				vL.Y  = y + 3f;
				if(tv.Data[i].Val > 0){
					PosOrNeg = 'P';
					BigOrSmall = tv.Data[i].Val > tv.Data[i].HiThresh ? 'B' : 'S';
					RenderTarget.FillRectangle(new SharpDX.RectangleF(tv.GraphCenterX+1f, vL.Y, Convert.ToSingle(Math.Min(tv.GraphRect.Width/2.05f, tv.Data[i].PxPerUnit * tv.Data[i].Val)), HistoHeight), BigOrSmall == 'B' ? bigPositiveHistoBrushDX : smallPositiveHistoBrushDX);
				}
				vT1.Y = vL.Y;
				vT2.Y = vL.Y + HistoHeight;
				vT1.X = tv.UpperThreshX;
				vT2.X = tv.UpperThreshX;
//				if(BigOrSmall=='B')
//					RenderTarget.DrawLine(vT1, vT2, GraphicBoxBrushDX, 2f);//right threshold line
//				else
					RenderTarget.DrawLine(vT1, vT2, GraphicBoxBrushDX, 2f);//right threshold line

				if(tv.Data[i].Val < 0){
					PosOrNeg = 'N';
					BigOrSmall = tv.Data[i].Val < tv.Data[i].LoThresh ? 'B' : 'S';
					if(tv.Data[i].HiThresh != - tv.Data[i].LoThresh) tv.Data[i].PxPerUnit = (tv.GraphCenterX - tv.LowerThreshX)/(-tv.Data[i].LoThresh);
					RenderTarget.FillRectangle(new SharpDX.RectangleF(tv.GraphCenterX-1f, vL.Y, Convert.ToSingle(Math.Max(-tv.GraphRect.Width/2.05f, tv.Data[i].PxPerUnit * tv.Data[i].Val)), HistoHeight), BigOrSmall == 'B' ? bigNegativeHistoBrushDX : smallNegativeHistoBrushDX);
				}else
					BigOrSmall = ' ';//this ensures the left threshold line will be GraphicBoxBrush colored
				textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, tv.Data[i].Symbol, textFormatBold, float.MaxValue, float.MaxValue);
				RenderTarget.DrawTextLayout(vL, textLayout, PosOrNeg == 'P' ? (BigOrSmall == 'B' ? bigPositiveHistoBrushDX:smallPositiveHistoBrushDX) : (BigOrSmall == 'B' ? bigNegativeHistoBrushDX:smallNegativeHistoBrushDX), SharpDX.Direct2D1.DrawTextOptions.NoSnap);

				if(tv.Data[i].Info!=string.Empty){
					textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, tv.Data[i].Info, textFormat_SensFactors, float.MaxValue, float.MaxValue);
					RenderTarget.DrawTextLayout(new SharpDX.Vector2(tv.GraphRightX+5f, vL.Y+3f), textLayout, GraphicBoxBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
				}
				vT1.X = tv.LowerThreshX;
				vT2.X = tv.LowerThreshX;
//				if(BigOrSmall=='B')
//					RenderTarget.DrawLine(vT1, vT2, GraphicBoxBrushDX, 2f);//left threshold line
//				else
					RenderTarget.DrawLine(vT1, vT2, GraphicBoxBrushDX, 2f);//left threshold line
			}
			#endregion
			if(GraphicBoxBrushDX!=null) {
				RenderTarget.DrawRectangle(tv.GraphRect, GraphicBoxBrushDX, 2f);
//				RenderTarget.DrawRectangle(tv.TableHeaderRect, GraphicBoxBrushDX, 2f);
				RenderTarget.DrawLine(new SharpDX.Vector2(tv.GraphCenterX, tv.GraphTopY), new SharpDX.Vector2(tv.GraphCenterX, tv.GraphTopY+tv.GraphRect.Height), GraphicBoxBrushDX);
			}
line=1692;
			#endregion -- end of Draw table
			var now = (Cbi.Connection.PlaybackConnection != null ? Cbi.Connection.PlaybackConnection.Now : Core.Globals.Now);
			for(int i = 0; i<Instruments.Length; i++){

				if(tv.Data[i].Symbol[0] == '-' || tv.Data[i].Silenced) continue;
				if(tv.Data[i].Val != tv.Data[i].PriorVal && now.Ticks > tv.Data[i].TimeOfNextBeep){
					if(tv.Data[i].Val > 0){
						ushort pitch = Convert.ToUInt16(Math.Max(0,Math.Min(2000, Math.Abs(tv.Data[i].HiThresh - tv.Data[i].Val) / tv.Data[i].HiThresh * 800)) + 1500);
						if(pAudioVolume_HiAlert>0 && tv.Data[i].Val > 2*tv.Data[i].HiThresh){
//errors.Add(string.Format("{0}:{1}     BEEP LONG   Val > 2xHi  {2} > {3} ",t.Second, t.Millisecond,tv.Data[i].Val,tv.Data[i].HiThresh.ToString("0")));
							if(pSoundsMode == ARC_SoundWave_WAVorDynamic.Dynamic)
								PlayBeep(pitch, 15, now.Ticks, ref tv.Data[i].TimeOfNextBeep, Convert.ToUInt16(pAudioVolume_HiAlert/100.0*16380));
							else if(pSoundsMode == ARC_SoundWave_WAVorDynamic.WAV && pHiAlertWAV!="NONE")
								PlaySound(AddSoundFolder(pHiAlertWAV));
						}
						else if(pAudioVolume_MedAlert>0 && tv.Data[i].Val > 1.5*tv.Data[i].HiThresh){
//errors.Add(string.Format("{0}:{1}     BEEP LONG   Val > 1.5xHi  {2} > {3} ",t.Second, t.Millisecond,tv.Data[i].Val,tv.Data[i].HiThresh.ToString("0")));
							if(pSoundsMode == ARC_SoundWave_WAVorDynamic.Dynamic)
								PlayBeep(pitch, 15, now.Ticks, ref tv.Data[i].TimeOfNextBeep, Convert.ToUInt16(pAudioVolume_MedAlert/100.0*16380));
							else if(pSoundsMode == ARC_SoundWave_WAVorDynamic.WAV && pMidAlertWAV!="NONE")
								PlaySound(AddSoundFolder(pMidAlertWAV));
						}
						else if(pAudioVolume_Alert>0 && tv.Data[i].Val > tv.Data[i].HiThresh){
//errors.Add(string.Format("{0}:{1}     BEEP LONG   Val > Hi  {2} > {3} ",t.Second, t.Millisecond,tv.Data[i].Val,tv.Data[i].HiThresh.ToString("0")));
							if(pSoundsMode == ARC_SoundWave_WAVorDynamic.Dynamic)
								PlayBeep(pitch, 15, now.Ticks, ref tv.Data[i].TimeOfNextBeep, Convert.ToUInt16(pAudioVolume_Alert/100.0*16380));
							else if(pSoundsMode == ARC_SoundWave_WAVorDynamic.WAV && pLowAlertWAV!="NONE")
								PlaySound(AddSoundFolder(pLowAlertWAV));
						}
					}else{
						ushort pitch = Convert.ToUInt16(Math.Max(0,Math.Min(2000, Math.Abs((tv.Data[i].LoThresh - tv.Data[i].Val) / tv.Data[i].LoThresh) * 800)) + 1500);
						if(pAudioVolume_HiAlert>0 && tv.Data[i].Val < 2*tv.Data[i].LoThresh){
//errors.Add(string.Format("{0}:{1}     BEEP SHORT   Val < 2xLo  {2} < {3} ",t.Second, t.Millisecond, tv.Data[i].Val,tv.Data[i].HiThresh.ToString("0")));
							if(pSoundsMode == ARC_SoundWave_WAVorDynamic.Dynamic)
								PlayBeep(pitch, 15, now.Ticks, ref tv.Data[i].TimeOfNextBeep, Convert.ToUInt16(pAudioVolume_HiAlert/100.0*16380));
							else if(pSoundsMode == ARC_SoundWave_WAVorDynamic.WAV && pHiAlertWAV!="NONE")
								PlaySound(AddSoundFolder(pHiAlertWAV));
						}
						else if(pAudioVolume_MedAlert>0 && tv.Data[i].Val < 1.5*tv.Data[i].LoThresh){
//errors.Add(string.Format("{0}:{1}     BEEP SHORT   Val < 1.5xLo  {2} < {3} ",t.Second, t.Millisecond, tv.Data[i].Val,tv.Data[i].HiThresh.ToString("0")));
							if(pSoundsMode == ARC_SoundWave_WAVorDynamic.Dynamic)
								PlayBeep(pitch, 15, now.Ticks, ref tv.Data[i].TimeOfNextBeep, Convert.ToUInt16(pAudioVolume_MedAlert/100.0*16380));
							else if(pSoundsMode == ARC_SoundWave_WAVorDynamic.WAV && pMidAlertWAV!="NONE")
								PlaySound(AddSoundFolder(pMidAlertWAV));
						}
						else if(pAudioVolume_Alert>0 && tv.Data[i].Val < tv.Data[i].LoThresh){
//errors.Add(string.Format("{0}:{1}     BEEP SHORT   Val < Lo  {2} < {3} ",t.Second, t.Millisecond, tv.Data[i].Val,tv.Data[i].HiThresh.ToString("0")));
							if(pSoundsMode == ARC_SoundWave_WAVorDynamic.Dynamic)
								PlayBeep(pitch, 15, now.Ticks, ref tv.Data[i].TimeOfNextBeep, Convert.ToUInt16(pAudioVolume_Alert/100.0*16380));
							else if(pSoundsMode == ARC_SoundWave_WAVorDynamic.WAV && pLowAlertWAV!="NONE")
								PlaySound(AddSoundFolder(pLowAlertWAV));
						}
					}
				}
			}

}catch(Exception e){Print1(line+":  "+e.ToString());}

			RenderTarget.AntialiasMode = OSM;
			if(textLayout!=null && !textLayout.IsDisposed) textLayout.Dispose(); textLayout=null;
//			if(textFormat!=null && !textFormat.IsDisposed) textFormat.Dispose(); textFormat=null;
		}
//Prints the status of the price feed

		bool IsConnected = false;
		#region -- OnConnectionStatusUpdate --
		protected override void OnConnectionStatusUpdate(ConnectionStatusEventArgs connectionStatusUpdate)
		{
			if(connectionStatusUpdate.PriceStatus == ConnectionStatus.Connected)
			{
				IsConnected = true;
				//Print1("SoundWave Connected to price feed at " + DateTime.Now);
				RemoveDrawObject("connectioninfo");
			}

			else
			{
				IsConnected = false;
				//Print1("SoundWave Connection to price feed lost at: " + DateTime.Now);
				Draw.TextFixed(this,"connectioninfo","SoundWave waiting for data connection",TextPosition.TopLeft);
				ForceRefresh();
			}
		}
		#endregion --------------------------------
//=======================================================================================================================
		private SharpDX.Direct2D1.Brush bigPositiveHistoBrushDX, bigNegativeHistoBrushDX, smallPositiveHistoBrushDX, smallNegativeHistoBrushDX;
		private SharpDX.Direct2D1.Brush GraphicBoxBrushDX, GraphicBoxFillBrushDX;
        public override void OnRenderTargetChanged()
        {
			#region -- ORTC --
			if(bigNegativeHistoBrushDX!=null   && !bigNegativeHistoBrushDX.IsDisposed)   {bigNegativeHistoBrushDX.Dispose();   bigNegativeHistoBrushDX=null;}
			if(RenderTarget!=null) bigNegativeHistoBrushDX = pBigNegativeHistoBrush.ToDxBrush(RenderTarget);

			if(smallNegativeHistoBrushDX!=null   && !smallNegativeHistoBrushDX.IsDisposed)   {smallNegativeHistoBrushDX.Dispose();   smallNegativeHistoBrushDX=null;}
			if(RenderTarget!=null) smallNegativeHistoBrushDX = pSmallNegativeHistoBrush.ToDxBrush(RenderTarget);

			if(bigPositiveHistoBrushDX!=null   && !bigPositiveHistoBrushDX.IsDisposed)   {bigPositiveHistoBrushDX.Dispose();   bigPositiveHistoBrushDX=null;}
			if(RenderTarget!=null) bigPositiveHistoBrushDX = pBigPositiveHistoBrush.ToDxBrush(RenderTarget);

			if(smallPositiveHistoBrushDX!=null   && !smallPositiveHistoBrushDX.IsDisposed)   {smallPositiveHistoBrushDX.Dispose();   smallPositiveHistoBrushDX=null;}
			if(RenderTarget!=null) smallPositiveHistoBrushDX = pSmallPositiveHistoBrush.ToDxBrush(RenderTarget);

			if(GraphicBoxBrushDX!=null   && !GraphicBoxBrushDX.IsDisposed)   {GraphicBoxBrushDX.Dispose();   GraphicBoxBrushDX=null;}
			if(RenderTarget!=null) GraphicBoxBrushDX = pGraphicBoxBrush.ToDxBrush(RenderTarget);

			if(GraphicBoxFillBrushDX!=null   && !GraphicBoxFillBrushDX.IsDisposed)   {GraphicBoxFillBrushDX.Dispose();   GraphicBoxFillBrushDX=null;}
			if(RenderTarget!=null) GraphicBoxFillBrushDX = pGraphicBoxFillBrush.ToDxBrush(RenderTarget);
			#endregion
		}
//=======================================================================================================================
		#region PlayBeep
		Random rnd = new Random(2);
        public void PlayBeep(UInt16 frequency, int msDuration, long TimeTicks, ref long TimeOfNextBeep, UInt16 volume = 16380)
        {//https://stackoverflow.com/questions/203890/creating-sine-or-square-wave-in-c-sharp
			TimeOfNextBeep = TimeTicks + Convert.ToInt64(TicksToNextBeep*rnd.NextDouble()*2.0);//this will move the bip apart to help reduce audio overlap
			TriggerCustomEvent(o2 =>{
            try
            {
//Print1("Beeping at frequency: "+frequency+"  rnd: "+d);
                var mStrm = new System.IO.MemoryStream();
                var writer = new System.IO.BinaryWriter(mStrm);

                const double TAU = 2 * Math.PI;
                int formatChunkSize = 16;
                int headerSize = 8;
                short formatType = 1;
                short tracks = 1;
                int samplesPerSecond = 5000;
                short bitsPerSample = 16;
                short frameSize = (short)(tracks * ((bitsPerSample + 7) / 8));
                int bytesPerSecond = samplesPerSecond * frameSize;
                int waveSize = 4;
                int samples = (int)((decimal)samplesPerSecond * msDuration / 1000);
                int dataChunkSize = samples * frameSize;
                int fileSize = waveSize + headerSize + formatChunkSize + headerSize + dataChunkSize;
                // var encoding = new System.Text.UTF8Encoding();
                writer.Write(0x46464952); // = encoding.GetBytes("RIFF")
                writer.Write(fileSize);
                writer.Write(0x45564157); // = encoding.GetBytes("WAVE")
                writer.Write(0x20746D66); // = encoding.GetBytes("fmt ")
                writer.Write(formatChunkSize);
                writer.Write(formatType);
                writer.Write(tracks);
                writer.Write(samplesPerSecond);
                writer.Write(bytesPerSecond);
                writer.Write(frameSize);
                writer.Write(bitsPerSample);
                writer.Write(0x61746164); // = encoding.GetBytes("data")
                writer.Write(dataChunkSize);
                {
                    double theta = frequency * TAU / (double)samplesPerSecond;
                    // 'volume' is UInt16 with range 0 thru Uint16.MaxValue ( = 65 535)
                    // we need 'amp' to have the range of 0 thru Int16.MaxValue ( = 32 767)
                    double amp = volume >> 2; // so we simply set amp = volume / 2
                    for (int step = 0; step < samples; step++)
                    {
                        short s = (short)(amp * Math.Sin(theta * (double)step));
                        writer.Write(s);
                    }
                }

                mStrm.Seek(0, System.IO.SeekOrigin.Begin);
                new System.Media.SoundPlayer(mStrm).Play();
                writer.Close();
                mStrm.Close();
            }catch(Exception e) { Console.WriteLine(e.ToString()); }
	},0,null);
			} // public static void PlayBeep(UInt16 frequency, int msDuration, UInt16 volume = 16383)
		#endregion ------------------

		#region --- Properties ---
		private ARC_SoundWaveEngine_HistoBasis pHistoCalcBasis;
		private ARC_SoundWaveEngine_QtyBasis pQtyBasis;
//		[Display(Order=10, Name="Flow calc basis", GroupName = "Parameters", Description="Ticks count, or SumTotal")]
//		public ARC_SoundWaveEngine_HistoBasis pHistoCalcBasis
//		{get;set;}

//		[Display(Order=20, Name="Qty Basis", GroupName = "Parameters", Description="")]
//		public ARC_SoundWaveEngine_QtyBasis pQtyBasis
//		{get;set;}

		#region -- Parameters --
		[Range(1, double.MaxValue), NinjaScriptProperty]
		[Display(Order=30, Name="Seconds Lookback", GroupName="Parameters")]
		public double pSecondsLookback
		{ get; set; }

		[Range(1, int.MaxValue)]
		[Display(Order=40, Name="Thresh Smoothing period (bars)", GroupName="Parameters")]
		public int pThresholdSmoothingPeriod
		{ get; set; }

		[Display(Order=50, Name="Smoothing type", Description="", GroupName="Parameters")]
		public ARC_SoundWaveEngine_SmoothingType pSmoothingType
		{get;set;}

		private int pNBarLookback = 0;
//		[Display(Order=70, Name="N-bar lookback histos", GroupName="Parameters")]
//		public int pNBarLookback
//		{get;set;}

		[Display(Order=80, Name="Show Expirations?", GroupName="Parameters")]
		public bool pShowExpirationDates
		{get;set;}

		[Display(Order=90, Name="Sounds mode", Description="'WAV' will use the 3 WAV files - more stable method for sound generation.  'Dynamic' will use a more advanced algo for generating sounds dynamically (not compatible with some older computers)", GroupName="Parameters")]
		public ARC_SoundWave_WAVorDynamic pSoundsMode
		{get;set;}

		#region ---- Audible --
		private string AddSoundFolder(string wav){
			wav = wav.Replace("<inst>",Instrument.MasterInstrument.Name);
//			if(IsDebug)Print("ARC_StructureBoss"+wav);
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav.Trim());
		}
		internal class LoadFileList : StringConverter
		{
			#region LoadFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles(search);
				}catch{}

				var list = new System.Collections.Generic.List<string>();//new string[filCustom.Length+1];
				list.Add("NONE");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}

		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		[Display(Order = 100, Name = "Hi Alert wAV", Description="WAV to play when a Hi Alert occurs", GroupName = "Parameters", ResourceType = typeof(Custom.Resource))]
		public string pHiAlertWAV
		{ get; set; }

		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		[Display(Order = 110, Name = "Mid Alert wAV", Description="WAV to play when a Middle Alert occurs", GroupName = "Parameters", ResourceType = typeof(Custom.Resource))]
		public string pMidAlertWAV
		{ get; set; }

		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		[Display(Order = 120, Name = "Low Alert wAV", Description="WAV to play when a Low Alert occurs", GroupName = "Parameters", ResourceType = typeof(Custom.Resource))]
		public string pLowAlertWAV
		{ get; set; }
		#endregion

		#endregion

		[Display(Order=2, Name="Show Sensitivity Factors", Description="Display them to the right of the histos", GroupName="Data")]
		public bool pShowSensitivityFactors
		{get;set;}

		[Range(0, 100)]
		[Display(Order=7, Name="Sensitivity Factor (chart)", Description="0 = numerous signals, 100 = few signals", GroupName="Data")]
		public int pSensitivityFactor0
		{ get; set; }
		[Display(Order=8, Name="Sound alert (chart)", Description="", GroupName="Data")]
		public ARC_SoundWave_OnOff pSoundOnOff0
		{get;set;}
		[Display(Order=9, Name="Flip the tape?", Description="", GroupName="Data")]
		public bool pFlipTheTape
		{get;set;}

		[Display(Order=10, Name="Symbol 1", GroupName="Data")]
		public string pSymbol1
		{get;set;}
		private double pThresholdMultiplier1 = 1;
		[Range(0, 100)]
		[Display(Order=11, Name="Sensitivity Factor 1", Description="0 = numerous signals, 100 = few signals", GroupName="Data")]
		public int pSensitivityFactor1
		{ get; set; }
		[Display(Order=12, Name="Sound alert 1", Description="", GroupName="Data")]
		public ARC_SoundWave_OnOff pSoundOnOff1
		{get;set;}

		[Display(Order=20, Name="Symbol 2", GroupName="Data")]
		public string pSymbol2
		{get;set;}
		[Range(0, 100)]
		[Display(Order=21, Name="Sensitivity Factor 2", Description="0 = numerous signals, 100 = few signals", GroupName="Data")]
		public int pSensitivityFactor2
		{ get; set; }
		[Display(Order=22, Name="Sound alert 2", Description="", GroupName="Data")]
		public ARC_SoundWave_OnOff pSoundOnOff2
		{get;set;}

		[Display(Order=30, Name="Symbol 3", GroupName="Data")]
		public string pSymbol3
		{get;set;}
		[Range(0, 100)]
		[Display(Order=31, Name="Sensitivity Factor 3", Description="0 = numerous signals, 100 = few signals", GroupName="Data")]
		public int pSensitivityFactor3
		{ get; set; }
		[Display(Order=32, Name="Sound alert 3", Description="", GroupName="Data")]
		public ARC_SoundWave_OnOff pSoundOnOff3
		{get;set;}

		[Display(Order=40, Name="Symbol 4", GroupName="Data")]
		public string pSymbol4
		{get;set;}
		[Range(0, 100)]
		[Display(Order=41, Name="Sensitivity Factor 4", Description="0 = numerous signals, 100 = few signals", GroupName="Data")]
		public int pSensitivityFactor4
		{ get; set; }
		[Display(Order=42, Name="Sound alert 4", Description="", GroupName="Data")]
		public ARC_SoundWave_OnOff pSoundOnOff4
		{get;set;}

		[Display(Order=50, Name="Symbol 5", GroupName="Data")]
		public string pSymbol5
		{get;set;}
		[Range(0, 100)]
		[Display(Order=51, Name="Sensitivity Factor 5", Description="0 = numerous signals, 100 = few signals", GroupName="Data")]
		public int pSensitivityFactor5
		{ get; set; }
		[Display(Order=52, Name="Sound alert 5", Description="", GroupName="Data")]
		public ARC_SoundWave_OnOff pSoundOnOff5
		{get;set;}

		[Display(Order=60, Name="Symbol 6", GroupName="Data")]
		public string pSymbol6
		{get;set;}
		[Range(0, 100)]
		[Display(Order=61, Name="Sensitivity Factor 6", Description="0 = numerous signals, 100 = few signals", GroupName="Data")]
		public int pSensitivityFactor6
		{ get; set; }
		[Display(Order=62, Name="Sound alert 6", Description="", GroupName="Data")]
		public ARC_SoundWave_OnOff pSoundOnOff6
		{get;set;}

		[Display(Order=70, Name="Symbol 7", GroupName="Data")]
		public string pSymbol7
		{get;set;}
		[Range(0, 100)]
		[Display(Order=71, Name="Sensitivity Factor 7", Description="0 = numerous signals, 100 = few signals", GroupName="Data")]
		public int pSensitivityFactor7
		{ get; set; }
		[Display(Order=72, Name="Sound alert 7", Description="", GroupName="Data")]
		public ARC_SoundWave_OnOff pSoundOnOff7
		{get;set;}

		[Range(0,100)]
		[Display(Order=10, Name="Hi Alert %", GroupName="Audio Loudness", Description="Percent of max loudness, 0-100")]
		public UInt16 pAudioVolume_HiAlert
		{get;set;}
		[Range(0,100)]
		[Display(Order=20, Name="Med Alert %", GroupName="Audio Loudness", Description="Percent of max loudness, 0-100")]
		public UInt16 pAudioVolume_MedAlert
		{get;set;}
		[Range(0,100)]
		[Display(Order=30, Name="Alert %", GroupName="Audio Loudness", Description="Percent of max loudness, 0-100")]
		public UInt16 pAudioVolume_Alert
		{get;set;}

		#region -- Custom Visuals --
		[Range(0f,float.MaxValue)]
		[Display(Order=5, Name="Horizontal size in pixels", Description="", GroupName="Custom Visuals")]
		public float pGraphRegionSize
		{get;set;}

		[XmlIgnore]
		[Display(Order=10, Name="Up Flow above Threshold", Description="", GroupName="Custom Visuals")]
		public Brush pBigPositiveHistoBrush{ get; set; }
					[Browsable(false)]
					public string pBigPositiveHistoBrush_{
							get { return Serialize.BrushToString(pBigPositiveHistoBrush); }
							set { pBigPositiveHistoBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order=20, Name="Up Flow below Threshold", Description="", GroupName="Custom Visuals")]
		public Brush pSmallPositiveHistoBrush{ get; set; }
					[Browsable(false)]
					public string pSmallPositiveHistoBrush_{
							get { return Serialize.BrushToString(pSmallPositiveHistoBrush); }
							set { pSmallPositiveHistoBrush = Serialize.StringToBrush(value); }}

		
		[XmlIgnore]
		[Display(Order=30, Name="Down Flow above Threshold", Description="", GroupName="Custom Visuals")]
		public Brush pBigNegativeHistoBrush{ get; set; }
					[Browsable(false)]
					public string pBigNegativeHistoBrush_{
							get { return Serialize.BrushToString(pBigNegativeHistoBrush); }
							set { pBigNegativeHistoBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order=40, Name="Down Flow below Threshold", Description="", GroupName="Custom Visuals")]
		public Brush pSmallNegativeHistoBrush{ get; set; }
					[Browsable(false)]
					public string pSmallNegativeHistoBrush_{
							get { return Serialize.BrushToString(pSmallNegativeHistoBrush); }
							set { pSmallNegativeHistoBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order=50, Name="Graph Box Outline", Description="", GroupName="Custom Visuals")]
		public Brush pGraphicBoxBrush{ get; set; }
					[Browsable(false)]
					public string pGraphicBoxBrush_{
							get { return Serialize.BrushToString(pGraphicBoxBrush); }
							set { pGraphicBoxBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order=60, Name="Graph Box Fill", Description="", GroupName="Custom Visuals")]
		public Brush pGraphicBoxFillBrush{ get; set; }
					[Browsable(false)]
					public string pGraphicBoxFillBrush_{
							get { return Serialize.BrushToString(pGraphicBoxFillBrush); }
							set { pGraphicBoxFillBrush = Serialize.StringToBrush(value); }}
        
		[Display(Order = 70, Name = "Show Tape Flip Status?", GroupName = "Custom Visuals", Description = "")]
		public bool pShowTapeFlipStatus {get;set;}
		
		[Display(Order = 80, Name = "Loc of graphics", GroupName = "Custom Visuals", Description = "")]
		public TextPosition pGraphicLocation {get;set;}

		[Display(Order = 90, Name = "Button Text", GroupName = "Custom Visuals", Description = "")]
		public string pButtonText {get;set;}
		#endregion
//		[XmlIgnore]
//		[Display(Order=40, Name="Sell stripe", Description="", GroupName="Custom Visuals")]
//		public Brush pBkgStripeSellBrush{ get; set; }
//					[Browsable(false)]
//					public string pBkgStripeSellBrush_{
//							get { return Serialize.BrushToString(pBkgStripeSellBrush); }
//							set { pBkgStripeSellBrush = Serialize.StringToBrush(value); }}

	
//		[NinjaScriptProperty]
//		[Display(Order=30, Name="Use Net diff?", Description="...if false, use raw tick counts", GroupName="Parameters")]
//		public bool pUseNetDiff
//		{ get; set; }

		#endregion

		#region -- Plots --
//		[Browsable(false)]
//		[XmlIgnore]
//		public Series<double> UpCount
//		{
//			get { return Values[0]; }
//		}
//		[Browsable(false)]
//		[XmlIgnore]
//		public Series<double> DnCount
//		{
//			get { return Values[1]; }
//		}

//		[Browsable(false)]
//		[XmlIgnore]
//		public Series<double> AvgUpper
//		{
//			get { return Values[2]; }
//		}

//		[Browsable(false)]
//		[XmlIgnore]
//		public Series<double> AvgLower
//		{
//			get { return Values[3]; }
//		}

//		[Browsable(false)]
//		[XmlIgnore]
//		public Series<double> Velocity
//		{
//			get { return Values[4]; }
//		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_SoundWave[] cacheARC_SoundWave;
		public ARC.ARC_SoundWave ARC_SoundWave(double pSecondsLookback)
		{
			return ARC_SoundWave(Input, pSecondsLookback);
		}

		public ARC.ARC_SoundWave ARC_SoundWave(ISeries<double> input, double pSecondsLookback)
		{
			if (cacheARC_SoundWave != null)
				for (int idx = 0; idx < cacheARC_SoundWave.Length; idx++)
					if (cacheARC_SoundWave[idx] != null && cacheARC_SoundWave[idx].pSecondsLookback == pSecondsLookback && cacheARC_SoundWave[idx].EqualsInput(input))
						return cacheARC_SoundWave[idx];
			return CacheIndicator<ARC.ARC_SoundWave>(new ARC.ARC_SoundWave(){ pSecondsLookback = pSecondsLookback }, input, ref cacheARC_SoundWave);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_SoundWave ARC_SoundWave(double pSecondsLookback)
		{
			return indicator.ARC_SoundWave(Input, pSecondsLookback);
		}

		public Indicators.ARC.ARC_SoundWave ARC_SoundWave(ISeries<double> input , double pSecondsLookback)
		{
			return indicator.ARC_SoundWave(input, pSecondsLookback);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_SoundWave ARC_SoundWave(double pSecondsLookback)
		{
			return indicator.ARC_SoundWave(Input, pSecondsLookback);
		}

		public Indicators.ARC.ARC_SoundWave ARC_SoundWave(ISeries<double> input , double pSecondsLookback)
		{
			return indicator.ARC_SoundWave(input, pSecondsLookback);
		}
	}
}

#endregion
