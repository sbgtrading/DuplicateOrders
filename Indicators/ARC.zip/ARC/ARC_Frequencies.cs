#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Automation;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
//using NinjaTrader.NinjaScript.Indicators.ARC;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
	public enum ARC_Frequencies2_TradePlanType
    {
        None,
        UserDefined,
        PatternDefined
    }
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
//    #region -- Category Order --
//    [CategoryOrder("Parameters", 0)]
//    [CategoryOrder("Indicator Version", 999)]
//	#endregion


    public class ARC_Frequencies : Indicator
	{

		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "Frequencies";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "11879", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsDebug = false;

        private const string VERSION = "v1.3.2 Aug.19.2021";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		private class PatternHistory
        {
            public string Name { get; set; }
            public int BarIndex { get; set; }
            public int DIndex { get; set; }
            public int OIndex { get; set; }
            public int PaternId { get; set; }
            public bool IsDrawn { get; set; }
            public bool IsLive { get; set; }
            public int Depth { get; set; }
            public double Stop { get; set; }
            public double Target { get; set; }

            public PatternHistory()
            {
                IsDrawn = false;
            }
        }

		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }

		#region Variables
        private int MaxBarToD = 15;
        private double ExtCD = 0.886;
        private int ExtCR1TypeSearch = 0;
        private int RangeForPointD = 1;
        private int patternId = 1;

        private double _barhigh = 0;
        private double _barlow = 0;
        private int _barindex = 0;
		private int MaxBarsBack = 500;
		private int MaxDepth = 40;
		private int MinDepth = 10;
		private string patName;
		private int [] patBars = {0, 0, 0, 0, 0, 0};
        private bool patReversal;
		
		private List<int> depths;
        private List<PatternHistory> Patterns;

        private string vBullBear = "";
        private string vNamePattern = "";
        private string vBullBearToNumberPattern = "";
        private string vNamePatternToNumberPattern = "";
        private int maxPeak, vPatOnOff, vPatNew = 0;
        private double hBar, lBar;
        private bool FlagForD = true;
        private int TimeForDmin = 0, TimeForDminToNumberPattern;
        private int TimeForDmax = 0, TimeForDmaxToNumberPattern;
        private double LevelForDmin = 0, LevelForDminToNumberPattern;
        private double LevelForDmax = 0, LevelForDmaxToNumberPattern;
        private List<double> PeakPriceX;
        private List<double> PeakPriceA;
        private List<double> PeakPriceB;
        private List<double> PeakPriceC;
        private List<double> PeakPriceD;
        private List<int> PeakTimeX;
        private List<int> PeakTimeA;
        private List<int> PeakTimeB;
        private List<int> PeakTimeC;
        private List<int> PeakTimeD;
        private int countCR1 = 0;
		private int lastD = -1;
        private Brush localTextColor;
        private SimpleFont localLabelFont;
        #endregion
        #region -- Toolbar variables --
        private string toolbarname = "NSPatternFinderToolBar", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private Grid indytoolbar;

        private Menu MenuControlContainer;
        private MenuItem MenuControl;

        //private ComboBox comboMTF, comboZFM, comboProfile;
        private MenuItem miGeneral1, miGeneral2, miGeneral3, miGeneral4, miGeneral5, miGeneral6, miGeneral7, miGeneral8;
        private MenuItem miRatio1, miRatio2, miRatio3, miRatio4, miRatio5, miRatio6, miRatio7, miRatio8;
        private MenuItem miTradingPlan1, miTradingPlan2, miTradingPlan3, miTradingPlan4, miTradingPlan5;

        private Button gCmdup;
        private Button gCmddw;
        private Label gLabel;
        #endregion

        #region -- Toolbar Management Utilities --
        #region private void addToolBar()
        private void addToolBar()
        {
            gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            gLabel = new Label();//#RJBug001

            MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
            MenuControl = new MenuItem {Name="NSFreq"+uID,  BorderThickness = new Thickness(2), BorderBrush = Brushes.Orange, Header = pButtonText, Foreground = Brushes.Orange, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
            MenuControlContainer.Items.Add(MenuControl);

            MenuItem item;
            Separator separator;
            #region -- General --
            MenuItem miGeneral = new MenuItem { Header = "General", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miGeneral1 = new MenuItem { Header = "Show Potential Ratio " + (this.ShowPotential ? "ON" : "OFF"), Name = "btGeneral_Potential", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral1.Click += General_Click;
            miGeneral.Items.Add(miGeneral1);

            miGeneral2 = new MenuItem { Header = "Show Confirmed Ratio " + (this.ShowConfirmed ? "ON" : "OFF"), Name = "btGeneral_Confirmed", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral2.Click += General_Click;
            miGeneral.Items.Add(miGeneral2);

            miGeneral3 = new MenuItem { Header = "Show Historical Ratios " + (this.ShowHistorical ? "ON" : "OFF"), Name = "btGeneral_Historical", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral3.Click += General_Click;
            miGeneral.Items.Add(miGeneral3);

            miGeneral4 = new MenuItem { Header = "Show Long Ratios " + (this.ShowLong ? "ON" : "OFF"), Name = "btGeneral_Long", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral4.Click += General_Click;
            miGeneral.Items.Add(miGeneral4);

            miGeneral5 = new MenuItem { Header = "Show Short Ratios " + (this.ShowShort ? "ON" : "OFF"), Name = "btGeneral_Short", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miGeneral5.Click += General_Click;
            miGeneral.Items.Add(miGeneral5);
            //------------------

            MenuControl.Items.Add(miGeneral);
            #endregion

            #region -- Ratios --
            MenuItem miRatio = new MenuItem { Header = "Ratios", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miRatio1 = new MenuItem { Header = "Show CRM1/CRW1 Ratio " + (this.ShowCR1 ? "ON" : "OFF"), Name = "btRatio_CR1", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miRatio1.Click += General_Click;
            miRatio.Items.Add(miRatio1);

            miRatio2 = new MenuItem { Header = "Show CRM2/CRW2 Ratio " + (ShowCR2 ? "ON" : "OFF"), Name = "btRatio_CR2", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miRatio2.Click += General_Click;
            miRatio.Items.Add(miRatio2);

            miRatio3 = new MenuItem { Header = "Show CRM3/CRW3 Ratio " + (ShowCR3 ? "ON" : "OFF"), Name = "btRatio_CR3", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miRatio3.Click += General_Click;
            miRatio.Items.Add(miRatio3);

            miRatio4 = new MenuItem { Header = "Show CRM4/CRW4 Ratio " + (ShowCR4 ? "ON" : "OFF"), Name = "btRatio_CR4", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miRatio4.Click += General_Click;
            miRatio.Items.Add(miRatio4);

            miRatio5 = new MenuItem { Header = "Show RRM1/RRW1 Ratio " + (ShowRR1 ? "ON" : "OFF"), Name = "btRatio_RR1", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miRatio5.Click += General_Click;
            miRatio.Items.Add(miRatio5);

            miRatio6 = new MenuItem { Header = "Show RRM2/RRW2 Ratio " + (ShowRR2 ? "ON" : "OFF"), Name = "btRatio_RR2", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miRatio6.Click += General_Click;
            miRatio.Items.Add(miRatio6);

            miRatio7 = new MenuItem { Header = "Show RRM3/RRW3 Ratio " + (ShowRR3 ? "ON" : "OFF"), Name = "btRatio_RR3", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miRatio7.Click += General_Click;
            miRatio.Items.Add(miRatio7);

            miRatio8 = new MenuItem { Header = "Show RRM4/RRW4 Ratio " + (ShowRR4 ? "ON" : "OFF"), Name = "btRatio_RR4", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miRatio8.Click += General_Click;
            miRatio.Items.Add(miRatio8);
            //------------------

            MenuControl.Items.Add(miRatio);
            #endregion

            #region -- Trading Plan --
            MenuItem miTradingPlan = new MenuItem { Header = "Trading Plan", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            miTradingPlan1 = new MenuItem { Header = "Trading Plan 1 " + (this.TradePlan == ARC_Frequencies2_TradePlanType.PatternDefined ? "ON" : "OFF"), Name = "btPlan_1", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miTradingPlan1.Click += TradingPlan_Click;
            miTradingPlan.Items.Add(miTradingPlan1);

            miTradingPlan2 = new MenuItem { Header = "Trading Plan 2 " + (this.TradePlan == ARC_Frequencies2_TradePlanType.UserDefined ? "ON" : "OFF"), Name = "btPlan_2", Foreground = Brushes.Black, StaysOpenOnClick = true };
            miTradingPlan2.Click += TradingPlan_Click;
            miTradingPlan.Items.Add(miTradingPlan2);

            miTradingPlan3 = new MenuItem { Header = "SL Ticks:   " + StopTicks.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };

            miTradingPlan3.Click += delegate (object o, RoutedEventArgs e) {
                #region -- Click --
                e.Handled = true;
                StopTicks++;
                miTradingPlan3.Header = "SL Ticks:   " + StopTicks.ToString();
				InformUserAboutRecalculation();
//                UpdateChart();
                #endregion
            };
            miTradingPlan3.MouseWheel += delegate (object o, MouseWheelEventArgs e) {
                #region -- Mousewheel --
                e.Handled = true;
                if (e.Delta > 0)
                {
                    StopTicks++;
                }
                else
                {
                    StopTicks--;
                }
                miTradingPlan3.Header = "SL Ticks:   " + StopTicks.ToString();
				InformUserAboutRecalculation();
//                UpdateChart();
                #endregion
            };
            miTradingPlan.Items.Add(miTradingPlan3);

            //=============================================================================
            #region -- T1 ticks --
            this.miTradingPlan4 = new MenuItem { Header = "T1 Ticks:   " + Target1Ticks.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };

            miTradingPlan4.Click += delegate (object o, RoutedEventArgs e) {
                #region -- Click --
                e.Handled = true;
                Target1Ticks++;
                miTradingPlan4.Header = "T1 Ticks:   " + Target1Ticks.ToString();
				InformUserAboutRecalculation();
//                UpdateChart();
                #endregion
            };
            miTradingPlan4.MouseWheel += delegate (object o, MouseWheelEventArgs e) {
                #region -- Mousewheel --
                e.Handled = true;
                if (e.Delta > 0)
                {
                    Target1Ticks++;
                }
                else
                {
                    Target1Ticks--;
                }
                miTradingPlan4.Header = "T1 Ticks:   " + Target1Ticks.ToString();
				InformUserAboutRecalculation();
//                UpdateChart();
                #endregion
            };
            miTradingPlan.Items.Add(miTradingPlan4);
            #endregion
            //=============================================================================
            #region -- T2 ticks --
            this.miTradingPlan5 = new MenuItem { Header = "T2 Ticks:   " + Target2Ticks.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };

            miTradingPlan5.Click += delegate (object o, RoutedEventArgs e) {
                #region -- Click --
                e.Handled = true;
                Target1Ticks++;
                miTradingPlan4.Header = "T2 Ticks:   " + Target2Ticks.ToString();
				InformUserAboutRecalculation();
//                UpdateChart();
                #endregion
            };
            miTradingPlan5.MouseWheel += delegate (object o, MouseWheelEventArgs e) {
                #region -- Mousewheel --
                e.Handled = true;
                if (e.Delta > 0)
                {
                    Target2Ticks++;
                }
                else
                {
                    Target2Ticks--;
                }
                miTradingPlan5.Header = "T2 Ticks:   " + Target2Ticks.ToString();
				InformUserAboutRecalculation();
//                UpdateChart();
                #endregion
            };
            miTradingPlan.Items.Add(miTradingPlan5);
            #endregion
            //=============================================================================

            MenuControl.Items.Add(miTradingPlan);

            #endregion
            separator = new Separator();
            MenuControl.Items.Add(separator);

            miRecalculate1 = new MenuItem { Header = "RE-CALCULATE RATIOS", Name = "patternsClick", HorizontalAlignment = HorizontalAlignment.Center, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = false };
            miRecalculate1.Click += ReloadChart_Click;
            MenuControl.Items.Add(miRecalculate1);

            indytoolbar.Children.Add(MenuControlContainer);
        }
        #endregion
//=====================================================================================================
//		private bool RecalculateButtonHit = false;
		MenuItem miRecalculate1;
		private void InformUserAboutRecalculation(bool RecalcBtnHitSetting = false){
			miRecalculate1.Background = Brushes.Yellow;
			miRecalculate1.FontWeight = FontWeights.Bold;
			miRecalculate1.FontStyle  = FontStyles.Italic;
//			RecalculateButtonHit = RecalcBtnHitSetting;
//			if(!RecalculateButtonHit) {
//				DrawOnPricePanel = false;
//				Draw.TextFixed(this,"recalcnow",". Hit 'RE-CALCULATE RATIOS' to enact your changes .",TextPosition.Center, Brushes.Yellow, new SimpleFont("Arial",18), Brushes.Yellow, Brushes.Black, 100);
//				ForceRefresh();
//			}
		}
		private void ResetRecalculationUI(){
			miRecalculate1.FontWeight = FontWeights.Normal;
			miRecalculate1.FontStyle = FontStyles.Normal;
			miRecalculate1.Background = null;
//			RecalculateButtonHit = true;
		}
		#endregion
//================================================================
        #region -- General_Click --
        private void General_Click(object sender, EventArgs e)
        {
            //Print(sender.ToString());

            MenuItem item = sender as MenuItem;
            if (item != null && item.Name == "btGeneral_Potential") ShowPotential = !ShowPotential;
            else if (item != null && item.Name == "btGeneral_Confirmed") ShowConfirmed = !ShowConfirmed;
            else if (item != null && item.Name == "btGeneral_Historical") ShowHistorical = !ShowHistorical;
            else if (item != null && item.Name == "btGeneral_Long") ShowLong = !ShowLong;
            else if (item != null && item.Name == "btGeneral_Short") ShowShort = !ShowShort;
            else if (item != null && item.Name == "btRatio_CR1") ShowCR1 = !ShowCR1;
            else if (item != null && item.Name == "btRatio_CR2") ShowCR2 = !ShowCR2;
            else if (item != null && item.Name == "btRatio_CR3") ShowCR3 = !ShowCR3;
            else if (item != null && item.Name == "btRatio_CR4") ShowCR4 = !ShowCR4;
            else if (item != null && item.Name == "btRatio_RR1") ShowRR1 = !ShowRR1;
            else if (item != null && item.Name == "btRatio_RR2") ShowRR2 = !ShowRR2;
            else if (item != null && item.Name == "btRatio_RR3") ShowRR3 = !ShowRR3;
            else if (item != null && item.Name == "btRatio_RR4") ShowRR4 = !ShowRR4;

            miGeneral1.Header = "Show Potential Ratio " + (this.ShowPotential ? "ON" : "OFF");
            miGeneral2.Header = "Show Confirmed Ratio " + (this.ShowConfirmed ? "ON" : "OFF");
            miGeneral3.Header = "Show Historical Ratios " + (this.ShowHistorical ? "ON" : "OFF");
            miGeneral4.Header = "Show Long Ratios " + (this.ShowLong ? "ON" : "OFF");
            miGeneral5.Header = "Show Short Ratios " + (this.ShowShort ? "ON" : "OFF");
            miRatio1.Header = "Show CRM1/CRW1 Ratio " + (this.ShowCR1 ? "ON" : "OFF");
            miRatio2.Header = "Show CRM2/CRW2 Ratio " + (ShowCR2 ? "ON" : "OFF");
            miRatio3.Header = "Show CRM3/CRW3 Ratio " + (ShowCR3 ? "ON" : "OFF");
            miRatio4.Header = "Show CRM4/CRW4 Ratio " + (ShowCR4 ? "ON" : "OFF");
            miRatio5.Header = "Show RRM1/RRW1 Ratio " + (ShowRR1 ? "ON" : "OFF");
            miRatio6.Header = "Show RRM2/RRW2 Ratio " + (ShowRR2 ? "ON" : "OFF");
            miRatio7.Header = "Show RRM3/RRW3 Ratio " + (ShowRR3 ? "ON" : "OFF");
            miRatio8.Header = "Show RRM4/RRW4 Ratio " + (ShowRR4 ? "ON" : "OFF");
			InformUserAboutRecalculation();
        }
        #endregion

        #region -- TradingPlan_Click --
        private void TradingPlan_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;
            if (item != null && item.Name == "btPlan_1")
            {
                if(TradePlan == ARC_Frequencies2_TradePlanType.PatternDefined)
                {
                    TradePlan = ARC_Frequencies2_TradePlanType.None;
                }
                else
                {
                    TradePlan = ARC_Frequencies2_TradePlanType.PatternDefined;
                }
            }
            else if (item != null && item.Name == "btPlan_2")
            {
                if (TradePlan == ARC_Frequencies2_TradePlanType.UserDefined)
                {
                    TradePlan = ARC_Frequencies2_TradePlanType.None;
                }
                else
                {
                    TradePlan = ARC_Frequencies2_TradePlanType.UserDefined;
                }
            }

            miTradingPlan1.Header = "Trading Plan 1 " + (this.TradePlan == ARC_Frequencies2_TradePlanType.PatternDefined ? "ON" : "OFF");
            miTradingPlan2.Header = "Trading Plan 2 " + (this.TradePlan == ARC_Frequencies2_TradePlanType.UserDefined ? "ON" : "OFF");
        }

        #endregion

        #region -- ReloadChart_Click --
        private void ReloadChart_Click(object sender, EventArgs e)
        {
if(IsDebug) ClearOutputWindow();
            System.Windows.Forms.SendKeys.SendWait("{F5}");
        }

        private void UpdateChart()
        {
if(IsDebug) ClearOutputWindow();
            System.Windows.Forms.SendKeys.SendWait("{F5}");
        }

        #endregion

        #region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion


        //#endregion

        public override string DisplayName { get { return "ARC_Frequencies"; } }

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"Indicator to display Chart Frequencies";
				Name								= "ARC_Frequencies";
				Calculate							= Calculate.OnBarClose;
				IsOverlay							= true;
				DisplayInDataBox					= true;
				DrawOnPricePanel					= true;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
				PaintPriceMarkers					= true;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				MaximumBarsLookBack					= MaximumBarsLookBack.Infinite;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive			= true;
                ShowPotential = true;
                ShowConfirmed = true;
                ShowHistorical = true;
				MaxFibDelta					= 0.1;
                ShowLong = true;
                ShowShort = true;
				BullCR1Color					= Brushes.Blue;
				BearCR1Color					= Brushes.Red;
                BullCR2Color = Brushes.Blue;
                BearCR2Color = Brushes.Red;
                BullCR3Color = Brushes.Blue;
                BearCR3Color = Brushes.Red;
                BullRR1Color = Brushes.Blue;
                BearRR1Color = Brushes.Red;
                BullRR2Color = Brushes.Blue;
                BearRR2Color = Brushes.Red;
                BullRR3Color = Brushes.Blue;
                BearRR3Color = Brushes.Red;
                BullRR4Color = Brushes.Blue;
                BearRR4Color = Brushes.Red;
                BullCR4Color = Brushes.Blue;
                BearCR4Color = Brushes.Red;
                ShowCR1 = true;
				ShowCR2	= true;
				ShowRR1	= true;
				ShowRR2	= true;
				ShowRR3	= true;
				ShowRR4	= true;
                ShowCR3 = true;
                ShowCR4 = true;
                CR1Opacity = 20;
                CR2Opacity = 20;
                CR3Opacity = 20;
                CR4Opacity = 20;
                RR1Opacity = 20;
                RR2Opacity = 20;
                Five0Opacity = 20;
                RR4Opacity = 20;
                EntryLineColor = Brushes.Blue;
                StopLineColor = Brushes.OrangeRed;
                TargetLineColor = Brushes.LimeGreen;
                TradePlan = ARC_Frequencies2_TradePlanType.PatternDefined;
				pEmailAddress = string.Empty;
                StopTicks = 30;
                Target1Ticks = 30;
                Target2Ticks = 60;
				LineLength = 10;
				ShowLarge = true;
				ShowSmall = true;
                ShowInfoBox = true;
				AlertSoundFile = "SOUND OFF";
				pButtonText = "Frequencies";

				Random rnd = new Random();
				int rndV = rnd.Next(0, 100000);
                uID = DateTime.Now.Ticks.ToString() + rndV.ToString();//prevent multiple toolbar with same name
                LabelColor = Brushes.LightGray;
                localLabelFont = new SimpleFont("Arial", 11);
			}
			else if (State == State.Configure)
			{
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
#endif
                Calculate = Calculate.OnBarClose;
                depths = new List<int>();
				
				MaxDepth = ShowLarge ? 40 : 22;
				MinDepth = ShowSmall ? 10 : 24;
				
				for(int i = MinDepth; i < 16; i++)
				{
					depths.Add(i);
				}
				for(int i = Math.Max(MinDepth, 16); i < Math.Min(30, MaxDepth); i+=2)
				{
					depths.Add(i);
				}
                for (int i = Math.Max(MinDepth, 30); i < Math.Min(80, MaxDepth); i += 5)
                {
                    depths.Add(i);
                }
//Print("Depths count: "+depths.Count);
//foreach(var xx in depths)Print("Depths:  "+xx);
                depths.Reverse();
			}
			else if(State == State.DataLoaded)
			{
				EmailAlertABar = BarsArray[0].Count;
			}
			else if(State == State.Historical)
			{
                Patterns = new List<PatternHistory>();

                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                   {
                            chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                            if (chartWindow == null) return;

                            foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                            if (!isToolBarButtonAdded)
                            {
                                indytoolbar = new Grid { Visibility = Visibility.Collapsed };

                                addToolBar();

                                chartWindow.MainMenu.Add(indytoolbar);
                                chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                                foreach (TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                                AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                            }
                        }));
                }
                #endregion
            }
            else if (State == State.Terminated)
            {
                if (chartWindow != null)
                {
                    if (indytoolbar != null)
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            chartWindow.MainMenu.Remove(indytoolbar);
                            indytoolbar = null;

                            chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
                            chartWindow = null;
                        }));
                    }
                }
            }
        }

        #region ContrastColor
        private Color ContrastColor(Color color)
		{
    		byte d = 0;

    		// Counting the perceptive luminance - human eye favors green color... 
    		double a = 1 - ( 0.299 * color.R + 0.587 * color.G + 0.114 * color.B)/255;

    		if (a < 0.5)
       			d = 0; // bright colors - black font
    		else
       			d = 255; // dark colors - white font

    		return  Color.FromRgb(d, d, d);
		}
		#endregion
		
		private int EmailAlertABar = 0;
		#region CR1
        private void _CR1(int Depth)
        {
            int i, j, k, m, shift;

            double min_DeltaCR1 = (1 - MaxFibDelta);
            double max_DeltaCR1 = (1 + MaxFibDelta);
            double vl0382 = min_DeltaCR1 * 0.382;
            double vl05 = min_DeltaCR1 * 0.5;
            double vh05 = max_DeltaCR1 * 0.5;
            double vl0618 = min_DeltaCR1 * 0.618;
            double vh0618 = max_DeltaCR1 * 0.618;
            double vl0786 = min_DeltaCR1 * 0.786;
            double vh0786 = max_DeltaCR1 * 0.786;
            double vl0886 = min_DeltaCR1 * 0.886;
            double vh0886 = max_DeltaCR1 * 0.886;
            double vl1128 = min_DeltaCR1 * 1.128;
            double vh1128 = max_DeltaCR1 * 1.128;
            double vl1272 = min_DeltaCR1 * 1.272;
            double vh1272 = max_DeltaCR1 * 1.272;
            double vl1414 = min_DeltaCR1 * 1.414;
            double vh1414 = max_DeltaCR1 * 1.414;
            double vl15 = min_DeltaCR1 * 1.5;
            double vh15 = max_DeltaCR1 * 1.5;
            double vl1618 = min_DeltaCR1 * 1.61803399;
            double vh1618 = max_DeltaCR1 * 1.61803399;
            double vh1732 = max_DeltaCR1 * 1.732;
            double vl2236 = min_DeltaCR1 * 2.236;
            double vh2236 = max_DeltaCR1 * 2.236;
            double vh2618 = max_DeltaCR1 * 2.618;
            double vh3618 = max_DeltaCR1 * 3.618;

            double LevelDA1382, LevelDA1618, LevelDA2, LevelDA2618, LevelDA3618, LevelDA4618, LevelDC1382, LevelDC1618, LevelDC2, LevelDC2618,
            LevelDC3618, LevelDC4618;
            double LevelForD;
            int timeLineD;
            double bartoD;
			double ProjectedD;
			double target1 = 0, target2 = 0, target3 = 0, far = 0, stop = 0, near = 0;

            int[] aXABCD = 
            {
                0,
                0,
                0,
                0,
                0,
                0
            };
            double retXD = 0;
            double retXB = 0;
            double retBD = 0;
            double retAC = 0;
            double retOA = 0;
            double XA = 0, BC = 0, XC = 0;

            double vDelta0 = 1E-06;
            int vNull = 0;
            int O     = 0, X = 1, A = 2, B = 3, C = 4, D = 5;
            string nameObj1, nameObj2, nameObj3;
            string vBull     = "Bullish";
            string vBear     = "Bearish";
            string vCR1      = "CR1";
            string vCR2      = "CR2";
            string vRR1      = "RR1";
            string vRR2      = "RR2";
            string vCR3      = "CR3";
            string vAB_CD    = "AB=CD";
            string v3_drives = "Three Drives";
            string v5sub0    = "5-0 Pattern";
			string vCR4      = "CR4";
            int[] aNumBarPeak;
            double[] zz = new double[CurrentBar];

            int colorPattern;

            maxPeak = 0;

            aNumBarPeak = new int[CurrentBar];

            int nextSwing = 0;
            for (shift = 0; shift < CurrentBar; shift++)
            {
                zz[shift] = 0;
				if(double.IsNaN(ARC_Frequencies_Single(Depth).zz[shift]) || ARC_Frequencies_Single(Depth).zz[shift] == 0)
				{
					continue;
				}
                if (nextSwing >= 0 && ARC_Frequencies_Single(Depth).zz[shift] >= High[shift])
                {
                    zz[shift] = ARC_Frequencies_Single(Depth).zz[shift];
                    nextSwing = -1;
                    aNumBarPeak[maxPeak] = shift;
                    maxPeak++;
                }
                if (nextSwing <= 0 && ARC_Frequencies_Single(Depth).zz[shift] <= Low[shift])
                {
                    zz[shift] = ARC_Frequencies_Single(Depth).zz[shift];
                    nextSwing = 1;
                    aNumBarPeak[maxPeak] = shift;
                    maxPeak++;
                }
                //Print("Shift: " + shift + ", maxPeak: " + maxPeak);
                if(maxPeak > 7)
                {
                    break;
                }
            }
//			if(Depth == 10)
//	            Print("Indicator " + Instrument.MasterInstrument.Name + ", " + maxPeak + ", last Peak: " + aNumBarPeak[0]);
            //Print("Depth: " + Depth + ", MaxPeak: " + maxPeak);

            bartoD = 1.618 * (aNumBarPeak[4] - aNumBarPeak[0]);
            //Print(bartoD);

            aXABCD[D] = aNumBarPeak[0];

            k = 0;
            if(!ShowPotential || State == State.Historical)
            {
                k = 1;
            }
            int start = -1, limit;
            if(HistoryCalculated)
            {
                if (ShowConfirmed || ShowHistorical)
                {
                    start = 1;
                }
                else if (ShowPotential)
                {
                    start = 0;
                }
                else
                {
                    start = -1;
                }
            }
            else
            {
                if(ShowHistorical)
                {
                    start = maxPeak - 7;
                }
                else if(ShowConfirmed)
                {
                    start = 1;
                }
                else if (ShowPotential)
                {
                    start = 0;
                }

            }
            if (ShowPotential)
            {
                limit = 0;
            }
            else
            {
                limit = 1;
            }
            //Print("Depth: " + Depth + ", Start: " + start + ", Limit: " + limit);
            for(k = start; k >= limit; k--)
            {
                vBullBear = "";
                vNamePattern = "";
                aXABCD[O] = aNumBarPeak[k + 5];
                aXABCD[X] = aNumBarPeak[k + 4];
                aXABCD[A] = aNumBarPeak[k + 3];
                aXABCD[B] = aNumBarPeak[k + 2];
                aXABCD[C] = aNumBarPeak[k + 1];
                aXABCD[D] = aNumBarPeak[k];
				
				if(lastD >= 0 && aXABCD[D] >= lastD)
				{
                    //Print("Issue: " + lastD);
					//k++;
					//continue;
				}

                if ((zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[X]]) && (zz[aXABCD[X]] > zz[aXABCD[D]]) && ((zz[aXABCD[C]] - zz[aXABCD[D]]) >= (zz[aXABCD[A]] - zz[aXABCD[B]]) * ExtCD))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[D]]) && (zz[aXABCD[D]] > zz[aXABCD[X]]) && ((zz[aXABCD[C]] - zz[aXABCD[D]]) >= (zz[aXABCD[A]] - zz[aXABCD[B]]) * ExtCD))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[X]] > zz[aXABCD[D]]) && (zz[aXABCD[D]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && ((zz[aXABCD[D]] - zz[aXABCD[C]]) >= (zz[aXABCD[B]] - zz[aXABCD[A]]) * ExtCD))
                {
                    vBullBear = vBear;
                }
                else if ((zz[aXABCD[D]] > zz[aXABCD[X]]) && (zz[aXABCD[X]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && ((zz[aXABCD[D]] - zz[aXABCD[C]]) >= (zz[aXABCD[B]] - zz[aXABCD[A]]) * ExtCD))
                {
                    vBullBear = vBear;
                }
                else if ((zz[aXABCD[O]] > zz[aXABCD[A]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && (zz[aXABCD[A]] > zz[aXABCD[X]]) && (zz[aXABCD[D]] > zz[aXABCD[B]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[A]] > zz[aXABCD[O]]) && (zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[X]] > zz[aXABCD[A]]) && (zz[aXABCD[B]] > zz[aXABCD[D]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]))
                {
                    vBullBear = vBear;
                }
                else if ((zz[aXABCD[O]] > zz[aXABCD[A]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && (zz[aXABCD[A]] > zz[aXABCD[X]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[A]] > zz[aXABCD[O]]) && (zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[X]] > zz[aXABCD[A]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]))
                {
                    vBullBear = vBear;
                }
                else if ((zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[D]]) && ((zz[aXABCD[C]] - zz[aXABCD[D]]) >= (zz[aXABCD[A]] - zz[aXABCD[B]]) * ExtCD))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[D]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && ((zz[aXABCD[D]] - zz[aXABCD[C]]) >= (zz[aXABCD[B]] - zz[aXABCD[A]]) * ExtCD))
                {
                    vBullBear = vBear;
                }
                else if ((zz[aXABCD[O]] > zz[aXABCD[A]]) && (zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[A]] > zz[aXABCD[X]]) && (zz[aXABCD[C]] > zz[aXABCD[D]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]) && (zz[aXABCD[X]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[D]]))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[A]] > zz[aXABCD[O]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && (zz[aXABCD[X]] > zz[aXABCD[A]]) && (zz[aXABCD[D]] > zz[aXABCD[C]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]) && (zz[aXABCD[B]] > zz[aXABCD[X]]) && (zz[aXABCD[D]] > zz[aXABCD[B]]))
                {
                    vBullBear = vBear;
                }

                if (vBullBear.Length > 0)
                {
                    if (vBullBear == vBull)
                    {
                        retOA = (zz[aXABCD[X]] - zz[aXABCD[A]]) / (zz[aXABCD[X]] - zz[aXABCD[O]] + vDelta0);
                        retXB = (zz[aXABCD[A]] - zz[aXABCD[B]]) / (zz[aXABCD[A]] - zz[aXABCD[X]] + vDelta0);
                        retXD = (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]]) / (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[X]] + vDelta0);
                        retBD = (zz[aXABCD[C]] - zz[aXABCD[D]]) / (zz[aXABCD[C]] - zz[aXABCD[B]] + vDelta0);
                        retAC = (zz[aXABCD[C]] - zz[aXABCD[B]]) / (zz[aXABCD[A]] - zz[aXABCD[B]] + vDelta0);
                        if (RangeForPointD > 0 && FlagForD)
                        {
                  			XC = zz[aXABCD[C]] - zz[aXABCD[X]];
                            XA = zz[aXABCD[A]] - zz[aXABCD[X]];
                            BC = zz[aXABCD[C]] - zz[aXABCD[B]];
                        }
                    }
                    else if (vBullBear == vBear)
                    {
                        retOA = (zz[aXABCD[A]] - zz[aXABCD[X]]) / (zz[aXABCD[O]] - zz[aXABCD[X]] + vDelta0);
                        retXB = (zz[aXABCD[B]] - zz[aXABCD[A]]) / (zz[aXABCD[X]] - zz[aXABCD[A]] + vDelta0);
                        retXD = (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]])) / (zz[aXABCD[X]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]) + vDelta0);
                        retBD = (zz[aXABCD[D]] - zz[aXABCD[C]]) / (zz[aXABCD[B]] - zz[aXABCD[C]] + vDelta0);
                        retAC = (zz[aXABCD[B]] - zz[aXABCD[C]]) / (zz[aXABCD[B]] - zz[aXABCD[A]] + vDelta0);
                        if (RangeForPointD > 0 && FlagForD)
                        {
		                  	XC = zz[aXABCD[X]] - zz[aXABCD[C]];
                            XA = zz[aXABCD[X]] - zz[aXABCD[A]];
                            BC = zz[aXABCD[B]] - zz[aXABCD[C]];
                        }
                    }

                    if (ShowCR1 && retAC >= vl0382 && retAC <= vh0886 && retXD >= vl0618 && retXD <= vh0786 && retBD >= vl1272 && retBD <= vh1618 && retXB >= vl0618 && retXB <= vh0618)
                    {
                        vNamePattern = vCR1;
                        // CR1
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] - XA * vh0786, zz[aXABCD[C]] - BC * vh2236);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] - XA * vl0618, zz[aXABCD[C]] - BC * vl1128);
								ProjectedD = (LevelForDmin + LevelForDmax)/2;
								ProjectedD = Instrument.MasterInstrument.RoundToTickSize(ProjectedD);
								target1 = ProjectedD + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.382;
								target2 = ProjectedD + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.618;
								target3 = ProjectedD + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.5;
								far = LevelForDmin;
								stop = zz[aXABCD[X]] - TickSize;
                                patName = "CRM1";
                            }
                            else if (vBullBear == vBear)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] + XA * vl0618, zz[aXABCD[C]] + BC * vl1128);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] + XA * vh0786, zz[aXABCD[C]] + BC * vh2236);
								ProjectedD = (LevelForDmin + LevelForDmax)/2;
								ProjectedD = Instrument.MasterInstrument.RoundToTickSize(ProjectedD);
								target1 = ProjectedD - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.382;
								target2 = ProjectedD - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.618;
								target3 = ProjectedD - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.5;
								far = LevelForDmax;
								stop = zz[aXABCD[X]] + TickSize;
                                patName = "CRW1";
                            }
                            patReversal = false;
                        }
                    }
                    else if (ShowRR1 && retAC >= vl0382 && retAC <= vh0886 && retXD >= vl1272 && retXD <= vh1618 && retBD >= vl1618 && retBD <= vh2618 && retXB >= vl0786 && retXB <= vh0786)
                    {
                        vNamePattern = vRR1;
                        // RR1
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] - XA * vh1618, zz[aXABCD[C]] - BC * vh2618);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] - XA * vl1272, zz[aXABCD[C]] - BC * vl1272);
								target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.382;
								target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.618;
								target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.5;
								far = LevelForDmin;
								stop = Math.Min(zz[aXABCD[A]] - XA * vh1618, zz[aXABCD[C]] - BC * vh2618) - TickSize;
                                patName = "RRM1";
                            }
                            else if (vBullBear == vBear)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] + XA * vl1272, zz[aXABCD[C]] + BC * vl1272);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] + XA * vh1618, zz[aXABCD[C]] + BC * vh2618);
								target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.382;
								target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.618;
								target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.5;
								far = LevelForDmax;
								stop = Math.Max(zz[aXABCD[A]] + XA * vh1618, zz[aXABCD[C]] + BC * vh2618) + TickSize;
                                patName = "RRW1";
                            }
                            patReversal = true;
                        }
                    }
                    else if (ShowRR2 && retAC >= vl0382 && retAC <= vh0886 && retXD >= vl1618 && retXD <= vh1618 && retBD >= vl2236 && retBD <= vh3618 && retXB >= vl0382 && retXB <= vh0618)
                    {
                        vNamePattern = vRR2;
                        // RR2
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] - XA * vh1618, zz[aXABCD[C]] - BC * vh3618);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] - XA * vl1618, zz[aXABCD[C]] - BC * vl2236);
								target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.382;
								target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.618;
								target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.5;
								far = LevelForDmin;
								stop = (zz[aXABCD[A]] - XA * 2) - TickSize;
                                patName = "RRM2";
                            }
                            else if (vBullBear == vBear)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] + XA * vl1618, zz[aXABCD[C]] + BC * vl2236);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] + XA * vh1618, zz[aXABCD[C]] + BC * vh3618);
								target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.382;
								target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.618;
								target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.5;
								far = LevelForDmax;
								stop = (zz[aXABCD[A]] + XA * 2) + TickSize;
                                patName = "RRW2";
                            }
                            patReversal = true;
                        }
                    }
                    else if (ShowCR2 && retAC >= vl0382 && retAC <= vh0886 && retXD >= vl0886 && retXD <= vh0886 && retBD >= vl1618 && retBD <= vh2618 && retXB >= vl0382 && retXB <= vh05)
                    {
                        vNamePattern = vCR2;
                        // CR2
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] - XA * vh0886, zz[aXABCD[C]] - BC * vh2618);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] - XA * vl0886, zz[aXABCD[C]] - BC * vl1272);
								target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.382;
								target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.618;
								target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.5;
								far = LevelForDmin;
								stop = zz[aXABCD[X]] - TickSize;
                                patName = "CRM2";
                            }
                            else if (vBullBear == vBear)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] + XA * vl0886, zz[aXABCD[C]] + BC * vl1272);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] + XA * vh0886, zz[aXABCD[C]] + BC * vh2618);
								target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.382;
								target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.618;
								target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.5;
								far = LevelForDmax;
								stop = zz[aXABCD[X]] + TickSize;
                                patName = "CRW2";
                            }
                            patReversal = false;
                        }
                    }

					else if (ShowCR4 && retXB >= vl0382 && retXB <= vh0618 && retAC >= vl1128 && retAC <= vh1414 && retBD > vl1272 && retBD < 2 && retXD >= vl0786 && retXD <= vh0786)
					{
                        vNamePattern = vCR4;
                        // CR4
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
								LevelForDmin = zz[aXABCD[C]] - XC * vh0786;
								LevelForDmax = zz[aXABCD[C]] - XC * vl0786;
								target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.382;
								target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.618;
								target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.5;
								far = LevelForDmin;
								stop = zz[aXABCD[X]] - TickSize;
                                patName = "CRM4";
                            }
                            else if (vBullBear == vBear)
                            {
								LevelForDmin = zz[aXABCD[C]] + XC * vl0786;
								LevelForDmax = zz[aXABCD[C]] + XC * vh0786;
								target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.382;
								target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.618;
								target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.5;
								far = LevelForDmax;
								stop = zz[aXABCD[X]] + TickSize;
                                patName = "CRW4";
                            }
                            patReversal = false;
                        }
                    }
                    else if (ShowRR3 && retAC >= vl1618 && retAC <= vh2236 && retBD >= vl05 && retBD <= vh05 && retXB >= vl1128 && retXB <= vh1618 && retOA <= vh0886)
                    {
                        vNamePattern = v5sub0;
                        // 5-0
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
                                LevelForDmin = zz[aXABCD[C]] - BC * vh0618;
                                LevelForDmax = zz[aXABCD[C]] - BC * vl0382;
								target1 = zz[aXABCD[C]];
								target2 = (zz[aXABCD[C]] - zz[aXABCD[B]])/2 + zz[aXABCD[C]];
								target3 = zz[aXABCD[C]];
								far = LevelForDmin;
								stop = zz[aXABCD[C]] - BC * vh0786 - TickSize;
                                patName = "RRM3";
                            }
                            else if (vBullBear == vBear)
                            {
								target1 = zz[aXABCD[C]];
								target2 = zz[aXABCD[C]] - (zz[aXABCD[B]] - zz[aXABCD[C]])/2;
								target3 = zz[aXABCD[C]];
                                LevelForDmin = zz[aXABCD[C]] + BC * vl0382;
                                LevelForDmax = zz[aXABCD[C]] + BC * vh0618;
								far = LevelForDmax;
								stop = zz[aXABCD[C]] + BC * vh0786 + TickSize;
                                patName = "RRW3";
                            }
                            patReversal = true;
                        }
                    }
                    else if (ShowRR4 && (retOA >= vl05 && retOA <= vh0618 && retAC >= vl05 && retAC <= vh0786) && ((retXB >= vl1272 && retXB <= vh1272 && retBD >= vl1272 && retBD <= vh1272) || (retXB >= vl15 && retXB <= vh15 && retBD >= vl15 && retBD <= vh15) || (retXB >= vl1618 && retXB <= vh1618 && retBD >= vl1618 && retBD <= vh1618))) 
                    {
                        vNamePattern = v3_drives;
                        // Three Drives
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
								target1 = zz[aXABCD[C]];
								target2 = zz[aXABCD[A]];
								target3 = zz[aXABCD[C]];
                                if ((retBD >= vl1272) && (retBD <= vh1272))
                                {
                                    LevelForDmin = zz[aXABCD[C]] - BC * vh1414;
                                    LevelForDmax = zz[aXABCD[C]] - BC * vl1128;
                                }
                                else if ((retBD >= vl1414) && (retBD <= vh1414))
                                {
                                    LevelForDmin = zz[aXABCD[C]] - BC * vh15;
                                    LevelForDmax = zz[aXABCD[C]] - BC * vl1272;
                                }
                                else if ((retBD >= vl15) && (retBD <= vh15))
                                {
                                    LevelForDmin = zz[aXABCD[C]] - BC * vh1618;
                                    LevelForDmax = zz[aXABCD[C]] - BC * vl1414;
                                }
                                else if ((retBD >= vl1618) && (retBD <= vh1618))
                                {
                                    LevelForDmin = zz[aXABCD[C]] - BC * vh1732;
                                    LevelForDmax = zz[aXABCD[C]] - BC * vl15;
                                }
								far = LevelForDmin;
								stop = LevelForDmin - TickSize;
                                patName = "RRM4";
                            }
                            else if (vBullBear == vBear)
                            {
								target1 = zz[aXABCD[C]];
								target2 = zz[aXABCD[A]];
								target3 = zz[aXABCD[C]];
                                if ((retBD >= vl1272) && (retBD <= vh1272))
                                {
                                    LevelForDmin = zz[aXABCD[C]] + BC * vl1128;
                                    LevelForDmax = zz[aXABCD[C]] + BC * vh1414;
                                }
                                else if ((retBD >= vl1414) && (retBD <= vh1414))
                                {
                                    LevelForDmin = zz[aXABCD[C]] + BC * vl1272;
                                    LevelForDmax = zz[aXABCD[C]] + BC * vh15;
                                }
                                else if ((retBD >= vl15) && (retBD <= vh15))
                                {
                                    LevelForDmin = zz[aXABCD[C]] + BC * vl1414;
                                    LevelForDmax = zz[aXABCD[C]] + BC * vh1618;
                                }
                                else if ((retBD >= vl1618) && (retBD <= vh1618))
                                {
                                    LevelForDmin = zz[aXABCD[C]] + BC * vl15;
                                    LevelForDmax = zz[aXABCD[C]] + BC * vh1732;
                                }
								far = LevelForDmax;
								stop = LevelForDmax + TickSize;
                                patName = "RRW4";
                            }
                            patReversal = true;
                       }
                    }
                    else if (ShowCR3 && retAC >= vl1128 && retAC <= vh1618 && retBD >= vl1618 && retBD <= vh2236 && retXD >= vl0886 && retXD <= vh1128)
                    {
               			vNamePattern=vCR3; // CR3
               			if (RangeForPointD > 0 && FlagForD)
                 		{
                  			if (vBullBear == vBull)
                    		{
                     			LevelForDmin = Math.Min(zz[aXABCD[C]]-XC*vh1128,zz[aXABCD[C]]-BC*vh2236);
                     			LevelForDmax = Math.Max(zz[aXABCD[C]]-XC*vl0886,zz[aXABCD[C]]-BC*vl1618);
                                target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]]) * 0.382;
                                target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]]) * 0.618;
                                target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]]) * 0.5;
                                far = LevelForDmin;
                                stop = Math.Min(zz[aXABCD[D]] - (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]]) * 0.382, far - TickSize);
                                patName = "CRM3";
                            }
                            else if (vBullBear == vBear)
							{
								LevelForDmin = Math.Min(zz[aXABCD[C]]+XC*vl0886,zz[aXABCD[C]]+BC*vl1618);
								LevelForDmax = Math.Max(zz[aXABCD[C]]+XC*vh1128,zz[aXABCD[C]]+BC*vh2236);
                                target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]])) * 0.382;
                                target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]])) * 0.618;
                                target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]])) * 0.5;
                                far = LevelForDmax;
                                stop = Math.Max(zz[aXABCD[X]] + (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]])) * 0.382, far + TickSize);
                                patName = "CRW3";
                            }
                        }
                        patReversal = false;
		            }
                }
                if (vNamePattern.Length > 0 /* && aXABCD[D] < bartoD + 2*/)
                {
//Print("Pattern: " + vBullBear + " Name: " + patName + " 0: " + Time[aXABCD[0]].ToString() + " X: " + Time[aXABCD[X]].ToString() + " A: " + Time[aXABCD[X]].ToString() + " B: " + Time[aXABCD[B]].ToString() + " C: " + Time[aXABCD[C]].ToString() + " D: " + Time[aXABCD[D]].ToString() + " k: " + k);
                    //Print(Time[aXABCD[D]].ToString() + "_" + Depth.ToString() + "_" + vNamePattern);
                    if (vBullBear == vBull && !ShowLong)
                    {
                        continue;
                    }
                    if(vBullBear == vBear && !ShowShort)
                    {
                        continue;
                    }
                    vPatOnOff = 1;
                    PatternHistory currentPattern = Patterns.FirstOrDefault(p => p.BarIndex == CurrentBar - aXABCD[C] && p.OIndex == CurrentBar - aXABCD[O] && p.Name == patName);
                    if (currentPattern == null)
                    {
                        //Print("Indicator, New Pattern: " + patName + ", " + aXABCD[D] + ", " + CurrentBar +", Depth: " + Depth + ", Stop: " + stop + ", Target: " + target1 + ", on Instrument: " + Instrument.MasterInstrument.Name + ", Period: " + BarsPeriod.ToString());
                        currentPattern = new PatternHistory { BarIndex = CurrentBar - aXABCD[C], OIndex = CurrentBar - aXABCD[O], Name = patName, PaternId = patternId++, IsLive = k == 0 ? true : false, Depth = Depth, Stop = stop, Target = target1 };
                        Patterns.Add(currentPattern);
						if(State == State.Realtime && k == 0)
						{
							SoundAlert();
							if(!string.IsNullOrEmpty(pEmailAddress) && EmailAlertABar < CurrentBars[0]) {
								EmailAlertABar = CurrentBars[0];
								Log("Email sent:  Frequency trade on "+Instrument.MasterInstrument.Name+" "+currentPattern.Name,LogLevel.Information);
								SendMail(pEmailAddress, "Frequency trade on "+Instrument.MasterInstrument.Name+" "+currentPattern.Name, "Auto generated alert from your NinjaTrader platform");
							}
						}
                    }

                    if (Depth > currentPattern.Depth)
                    {
//                        Print("Indicator New Pattern Depth: " + Depth + ", Name: " + currentPattern.Name);
                        currentPattern.Depth = Depth;
                        currentPattern.IsLive = k == 0;
                        currentPattern.IsDrawn = false;
                    }

                    if (currentPattern.Depth != Depth)
                    {
                        continue;
                    }

                    if (currentPattern.IsLive)
                    {
                        if (currentPattern.DIndex != CurrentBar - aXABCD[D] || currentPattern.Stop != stop || currentPattern.Target != target1)
                        {
                            currentPattern.DIndex = CurrentBar - aXABCD[D];
							currentPattern.Stop = stop;
							currentPattern.Target = target1;
                            currentPattern.IsDrawn = false;
                        }
                    }
//                    else
//                    {
//                        if(k == 0)
//                        {
////                            Print("Indicator Resurrects pattern: " + currentPattern.Name);
//                            currentPattern.IsLive = true;
//                            currentPattern.DIndex = CurrentBar - aXABCD[D];
//                            currentPattern.IsDrawn = false;
//                        }
//                    }

                    if (currentPattern.IsDrawn)
                    {
                        continue;
                    }
                    lastD = aXABCD[D];

                    //---------------------------------------------
					int digits = BitConverter.GetBytes(decimal.GetBits((decimal)(double)TickSize)[3])[2];
					string fmt = "F" + digits;
					SimpleFont ft = new SimpleFont("Courier New", 16);
                    //Font ft = new Font(FontFamily.GenericMonospace,10f,FontStyle.Regular);

                    Brush BullPatternColor = Brushes.Blue, BearPatternColor = Brushes.Red;
                    localTextColor = LabelColor;
                    int opacity = 20;

                    if(vNamePattern == vCR1)
                    {
                        BullPatternColor = BullCR1Color;
                        BearPatternColor = BearCR1Color;
                        opacity = CR1Opacity;
                    }
                    else if(vNamePattern == vCR2)
                    {
                        BullPatternColor = BullCR2Color;
                        BearPatternColor = BearCR2Color;
                        opacity = CR2Opacity;
                    }
                    else if (vNamePattern == vCR3)
                    {
                        BullPatternColor = BullCR3Color;
                        BearPatternColor = BearCR3Color;
                        opacity = CR3Opacity;
                    }
                    else if (vNamePattern == vRR1)
                    {
                        BullPatternColor = BullRR1Color;
                        BearPatternColor = BearRR1Color;
                        opacity = RR1Opacity;
                    }
                    else if (vNamePattern == vRR2)
                    {
                        BullPatternColor = BullRR2Color;
                        BearPatternColor = BearRR2Color;
                        opacity = RR2Opacity;
                    }
                    else if (vNamePattern == v5sub0)
                    {
                        BullPatternColor = BullRR3Color;
                        BearPatternColor = BearRR3Color;
                        opacity = Five0Opacity;
                    }
                    else if (vNamePattern == v3_drives)
                    {
                        BullPatternColor = BullRR4Color;
                        BearPatternColor = BearRR4Color;
                        opacity = RR4Opacity;
                    }
                    else if (vNamePattern == vCR4)
                    {
                        BullPatternColor = BullCR4Color;
                        BearPatternColor = BearCR4Color;
                        opacity = CR4Opacity;
                    }

                    DashStyleHelper dashStyle = DashStyleHelper.Solid;
                    if(currentPattern.IsLive)
                    {
                        dashStyle = DashStyleHelper.Dot;
                    }
                    string suffix = "";
                    if(ShowHistorical/* && !currentPattern.IsLive*/)
                    {
                        suffix = "_" + currentPattern.PaternId;
                    }
                    else
                    {
                        suffix = "_1";
                    }
					ProjectedD = (LevelForDmin + LevelForDmax)/2;
					ProjectedD = Instrument.MasterInstrument.RoundToTickSize(ProjectedD);
                    if (this.TradePlan != ARC_Frequencies2_TradePlanType.None)
                    {
                        Draw.Line(this, "ProjectedD" + suffix, false, aXABCD[D] + 3, ProjectedD, Math.Max(aXABCD[D] - 10, 0), ProjectedD, EntryLineColor, DashStyleHelper.Solid, 2);
                        Draw.Text(this, "ProjectedDLabel" + suffix, false, "Projected D", Math.Max(aXABCD[D] - 10, 0), ProjectedD, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                    }

                    if(this.TradePlan == ARC_Frequencies2_TradePlanType.UserDefined)
                    {
						double slpts = StopTicks * TickSize;
						double t1pts = Target1Ticks * TickSize;
						double t2pts = Target2Ticks * TickSize;
						if(IsDebug){//use a Range base calculation for SL, T1 and T2.  
							double sum = 0;
							for(int r=0; r<14 && r<CurrentBars[0]; r++){
								sum = sum + Range()[r];
							}
							slpts = Instrument.MasterInstrument.RoundToTickSize(sum/14.0) * StopTicks/10;//the multiple is 1/10th of StopTicks value
							t1pts = slpts * Target1Ticks/10;//the multiple is 1/10th of Target1Ticks value
							t2pts = slpts * Target2Ticks/10;//the multiple is 1/10th of Target2Ticks value
						}
                        if(vBullBear == vBull)
                        {
                            stop = ProjectedD - slpts;
                            target1 = ProjectedD + t1pts;
                            target2 = ProjectedD + t2pts;
                        }
                        else
                        {
                            stop = ProjectedD + slpts;
                            target1 = ProjectedD - t1pts;
                            target2 = ProjectedD - t2pts;
                        }
                    }
					if(vNamePattern == v3_drives || vNamePattern == v5sub0)
					{
	                    if (vBullBear == vBull)
    	                {
	                        nameObj1 = "Ratio_Line_XA" + suffix;
							Draw.Line(this, nameObj1, true, aXABCD[X], zz[aXABCD[X]], aXABCD[A], zz[aXABCD[A]], BullPatternColor, dashStyle, 3); 
	                        nameObj1 = "Ratio_Line_AB" + suffix;
							Draw.Line(this, nameObj1, true, aXABCD[A], zz[aXABCD[A]], aXABCD[B], zz[aXABCD[B]], BullPatternColor, dashStyle, 3); 
	                        nameObj2 = "Ratio_Line_BC" + suffix;
							Draw.Line(this, nameObj2, true, aXABCD[B], zz[aXABCD[B]], aXABCD[C], zz[aXABCD[C]], BullPatternColor, dashStyle, 3); 
	                        nameObj3 = "Ratio_Line_CD" + suffix;
							Draw.Line(this, nameObj3, true, aXABCD[C], zz[aXABCD[C]], aXABCD[D], zz[aXABCD[D]], BullPatternColor, dashStyle, 3); 
							near = Math.Max(zz[aXABCD[D]], LevelForDmax);
                            Draw.Text(this, "RatioName" + suffix, true, patName, aXABCD[X], zz[aXABCD[X]], -10, ChartControl.Properties.ChartText, localLabelFont, TextAlignment.Left, null, BullPatternColor, 20);
                            string text = "Ratio:  Bullish " + patName + " at " + Time[aXABCD[D]].ToString();
                            if (TradePlan != ARC_Frequencies2_TradePlanType.None)
                            {
                                if (currentPattern.IsLive)
                                {
                                    Draw.Rectangle(this, "Ratio_Ghost_Rect", true, Math.Max(aXABCD[D], 2), near, 0, far, Brushes.Transparent, Brushes.LawnGreen, 30);
                                }
                                Draw.Line(this, "StopLevel" + suffix, false, aXABCD[D] + 1, stop, Math.Max(aXABCD[D] - 10, 0), stop, StopLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "StopLevelLabel" + suffix, false, "Stop", Math.Max(aXABCD[D] - 10, 0), stop, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                Draw.Line(this, "TargetLevel1" + suffix, false, aXABCD[D] + 1, target1, Math.Max(aXABCD[D] - 10, 0), target1, TargetLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "TargetLevelLabel1" + suffix, false, "Target 1", Math.Max(aXABCD[D] - 10, 0), target1, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                Draw.Line(this, "TargetLevel2" + suffix, false, aXABCD[D] + 1, target2, Math.Max(aXABCD[D] - 10, 0), target2, TargetLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "TargetLevelLabel2" + suffix, false, "Target 2", Math.Max(aXABCD[D] - 10, 0), target2, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                text += "\nStop: " + stop.ToString(fmt) + "\nTarget 1: " + target1.ToString(fmt) + "\nTarget 2: " + target2.ToString(fmt);
                            }
                            //patEntry = (target1 + stop)/2 - TickSize;
                            //Draw.Line(this, "patEntryLine", false, aXABCD[D] + 3, patEntry, Math.Max(aXABCD[D] - 10, 0), patEntry, EntryLineColor, DashStyleHelper.Solid, 2);
                            //Draw.Text(this, "patEntryLineLabel1", false, "Risk Reward Neutral Line", Math.Max(aXABCD[D] - 10, 0), patEntry, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                            if (ShowInfoBox && currentPattern.IsLive)
                            {
                                Draw.TextFixed(this, "PatternLabel", text, TextPosition.TopLeft, ChartControl.Properties.ChartText, ft, BullPatternColor, BullPatternColor, 20);
                            }
						}
	                    else
    	                {
	                        nameObj1 = "Ratio_Line_XA" + suffix;
							Draw.Line(this, nameObj1, true, aXABCD[X], zz[aXABCD[X]], aXABCD[A], zz[aXABCD[A]], BearPatternColor, dashStyle, 3); 
	                        nameObj1 = "Ratio_Line_AB" + suffix;
							Draw.Line(this, nameObj1, true, aXABCD[A], zz[aXABCD[A]], aXABCD[B], zz[aXABCD[B]], BearPatternColor, dashStyle, 3); 
	                        nameObj2 = "Ratio_Line_BC" + suffix;
							Draw.Line(this, nameObj2, true, aXABCD[B], zz[aXABCD[B]], aXABCD[C], zz[aXABCD[C]], BearPatternColor, dashStyle, 3); 
	                        nameObj3 = "Ratio_Line_CD" + suffix;
							Draw.Line(this, nameObj3, true, aXABCD[C], zz[aXABCD[C]], aXABCD[D], zz[aXABCD[D]], BearPatternColor, dashStyle, 3); 
							near = Math.Min(zz[aXABCD[D]], LevelForDmin);
                            Draw.Text(this, "RatioName" + suffix, true, patName, aXABCD[X], zz[aXABCD[X]], 10, ChartControl.Properties.ChartText, localLabelFont, TextAlignment.Left, null, BearPatternColor, 20);
                            string text = "Ratio:  Bearish " + patName + " at " + Time[aXABCD[D]].ToString();
                            if (TradePlan != ARC_Frequencies2_TradePlanType.None)
                            {
                                if (currentPattern.IsLive)
                                {
                                    Draw.Rectangle(this, "Ratio_Ghost_Rect", true, Math.Max(aXABCD[D], 2), near, 0, far, Brushes.Transparent, Brushes.LawnGreen, 30);
                                }
                                Draw.Line(this, "StopLevel" + suffix, false, aXABCD[D] + 1, stop, Math.Max(aXABCD[D] - 10, 0), stop, StopLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "StopLevelLabel" + suffix, false, "Stop", Math.Max(aXABCD[D] - 10, 0), stop, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                Draw.Line(this, "TargetLevel1" + suffix, false, aXABCD[D] + 1, target1, Math.Max(aXABCD[D] - 10, 0), target1, TargetLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "TargetLevelLabel1" + suffix, false, "Target 1", Math.Max(aXABCD[D] - 10, 0), target1, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                Draw.Line(this, "TargetLevel2" + suffix, false, aXABCD[D] + 1, target2, Math.Max(aXABCD[D] - 10, 0), target2, TargetLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "TargetLevelLabel2" + suffix, false, "Target 2", Math.Max(aXABCD[D] - 10, 0), target2, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                text += "\nStop: " + stop.ToString(fmt) + "\nTarget 1: " + target1.ToString(fmt) + "\nTarget 2: " + target2.ToString(fmt);
                            }
                            //patEntry = (target1 + stop)/2 + TickSize;
                            //Draw.Line(this, "patEntryLine", false, aXABCD[D] + 3, patEntry, Math.Max(aXABCD[D] - 10, 0), patEntry, EntryLineColor, DashStyleHelper.Solid, 2);
                            //Draw.Text(this, "patEntryLineLabel1", false, "Risk Reward Neutral Line", Math.Max(aXABCD[D] - 10, 0), patEntry, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                            if (ShowInfoBox && currentPattern.IsLive)
                            {
                                Draw.TextFixed(this, "PatternLabel", text, TextPosition.TopLeft, ChartControl.Properties.ChartText, ft, BearPatternColor, BearPatternColor, 20);
                            }
						}
					}
					else
					{
						if (vBullBear == vBull)
						{
							nameObj1 = "Ratio_Triangle_XAB" + suffix;// + vBullBear + " " + vNamePattern + "_" + (CurrentBar - aXABCD[D]).ToString();
							nameObj2 = "Ratio_Triangle_BCD" + suffix;// + vBullBear + " " + vNamePattern + "_" + (CurrentBar - aXABCD[D]).ToString();
							nameObj3 = "Ratio_Ghost_Rect";
							near = Math.Max(zz[aXABCD[D]], LevelForDmax);
							var tri1 = Draw.Triangle(this, nameObj1, true, aXABCD[X], zz[aXABCD[X]], aXABCD[A], zz[aXABCD[A]], aXABCD[B], zz[aXABCD[B]], BullPatternColor, BullPatternColor, opacity);
                            tri1.OutlineStroke.DashStyleHelper = dashStyle;
                            var tri2 = Draw.Triangle(this, nameObj2, true, aXABCD[B], zz[aXABCD[B]], aXABCD[C], zz[aXABCD[C]], aXABCD[D], zz[aXABCD[D]], BullPatternColor, BullPatternColor, opacity);
                            tri2.OutlineStroke.DashStyleHelper = dashStyle;
                            Draw.Text(this, "RatioName" + suffix, true, patName, aXABCD[X], zz[aXABCD[X]], -10, ChartControl.Properties.ChartText, localLabelFont, TextAlignment.Left, null, BullPatternColor, 20);
                            string text = "Ratio:  Bullish " + patName + " at " + Time[aXABCD[D]].ToString();
                            if (TradePlan != ARC_Frequencies2_TradePlanType.None)
                            {
                                if (currentPattern.IsLive) Draw.Rectangle(this, nameObj3, true, Math.Max(aXABCD[D], 2), near, 0, far, Brushes.Transparent, Brushes.LawnGreen, 30);
                                Draw.Line(this, "StopLevel" + suffix, false, aXABCD[D] + 1, stop, Math.Max(aXABCD[D] - 10, 0), stop, StopLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "StopLevelLabel" + suffix, false, "Stop", Math.Max(aXABCD[D] - 10, 0), stop, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                Draw.Line(this, "TargetLevel1" + suffix, false, aXABCD[D] + 1, target1, Math.Max(aXABCD[D] - 10, 0), target1, TargetLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "TargetLevelLabel1" + suffix, false, "Target 1", Math.Max(aXABCD[D] - 10, 0), target1, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                Draw.Line(this, "TargetLevel2" + suffix, false, aXABCD[D] + 1, target2, Math.Max(aXABCD[D] - 10, 0), target2, TargetLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "TargetLevelLabel2" + suffix, false, "Target 2", Math.Max(aXABCD[D] - 10, 0), target2, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                text += "\nStop: " + stop.ToString(fmt) + "\nTarget 1: " + target1.ToString(fmt) + "\nTarget 2: " + target2.ToString(fmt);
                            }
                            //patEntry = (target1 + stop)/2 - TickSize;
                            //Draw.Line(this, "patEntryLine", false, aXABCD[D] + 3, patEntry, Math.Max(aXABCD[D] - 10, 0), patEntry, EntryLineColor, DashStyleHelper.Solid, 2);
                            //Draw.Text(this, "patEntryLineLabel1", false, "Risk Reward Neutral Line", Math.Max(aXABCD[D] - 10, 0), patEntry, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                            if (ShowInfoBox && currentPattern.IsLive)
                            {
                                Draw.TextFixed(this, "PatternLabel", text, TextPosition.TopLeft, ChartControl.Properties.ChartText, ft, BullPatternColor, BullPatternColor, 20);
                            }
						}
						// if (vBullBear == vBear)
						else
						{
							nameObj1 = "Ratio_Triangle_XAB" + suffix;// + vBullBear + " " + vNamePattern + "_" + (CurrentBar - aXABCD[D]).ToString();
							nameObj2 = "Ratio_Triangle_BCD" + suffix;// + vBullBear + " " + vNamePattern + "_" + (CurrentBar - aXABCD[D]).ToString();
							nameObj3 = "Ratio_Ghost_Rect";
							near = Math.Min(zz[aXABCD[D]], LevelForDmin);
                            var tri1 = Draw.Triangle(this, nameObj1, true, aXABCD[X], zz[aXABCD[X]], aXABCD[A], zz[aXABCD[A]], aXABCD[B], zz[aXABCD[B]], BearPatternColor, BearPatternColor, opacity);
                            tri1.OutlineStroke.DashStyleHelper = dashStyle;
                            var tri2 = Draw.Triangle(this, nameObj2, true, aXABCD[B], zz[aXABCD[B]], aXABCD[C], zz[aXABCD[C]], aXABCD[D], zz[aXABCD[D]], BearPatternColor, BearPatternColor, opacity);
                            tri2.OutlineStroke.DashStyleHelper = dashStyle;
                            Draw.Text(this, "RatioName" + suffix, true, patName, aXABCD[X], zz[aXABCD[X]], 10, ChartControl.Properties.ChartText, localLabelFont, TextAlignment.Left, null, BearPatternColor, 20);
                            string text = "Ratio:  Bearish " + patName + " at " + Time[aXABCD[D]].ToString();
                            if (TradePlan != ARC_Frequencies2_TradePlanType.None)
                            {
                                if (currentPattern.IsLive) Draw.Rectangle(this, nameObj3, true, Math.Max(aXABCD[D], 2), near, 0, far, Brushes.Transparent, Brushes.LawnGreen, 30);
                                Draw.Line(this, "StopLevel" + suffix, false, aXABCD[D] + 1, stop, Math.Max(aXABCD[D] - 10, 0), stop, StopLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "StopLevelLabel" + suffix, false, "Stop", Math.Max(aXABCD[D] - 10, 0), stop, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                Draw.Line(this, "TargetLevel1" + suffix, false, aXABCD[D] + 1, target1, Math.Max(aXABCD[D] - 10, 0), target1, TargetLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "TargetLevelLabel1" + suffix, false, "Target 1", Math.Max(aXABCD[D] - 10, 0), target1, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                Draw.Line(this, "TargetLevel2" + suffix, false, aXABCD[D] + 1, target2, Math.Max(aXABCD[D] - 10, 0), target2, TargetLineColor, DashStyleHelper.Solid, 2);
                                Draw.Text(this, "TargetLevelLabel2" + suffix, false, "Target 2", Math.Max(aXABCD[D] - 10, 0), target2, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                                text += "\nStop: " + stop.ToString(fmt) + "\nTarget 1: " + target1.ToString(fmt) + "\nTarget 2: " + target2.ToString(fmt);
                            }
                            //patEntry = (target1 + stop)/2 + TickSize;
                            //Draw.Line(this, "patEntryLine", false, aXABCD[D] + 3, patEntry, Math.Max(aXABCD[D] - 10, 0), patEntry, EntryLineColor, DashStyleHelper.Solid, 2);
                            //Draw.Text(this, "patEntryLineLabel1", false, "Risk Reward Neutral Line", Math.Max(aXABCD[D] - 10, 0), patEntry, 0, localTextColor, localLabelFont, TextAlignment.Left, null, null, 0);
                            if (ShowInfoBox && currentPattern.IsLive)
                            {
                                Draw.TextFixed(this, "PatternLabel", text, TextPosition.TopLeft, ChartControl.Properties.ChartText, ft, BearPatternColor, BearPatternColor, 20);
                            }
						}
					}

                    currentPattern.IsDrawn = true;
                    /*if(!ShowHistorical)
                    {
                        return;
                    }*/
                }
                else
                {
                    if (lastD == -1)
					{
                    	vBullBear = "";
                    	vNamePattern = "";
                    	vBullBearToNumberPattern = "";
                    	vNamePatternToNumberPattern = "";
      //                  Print("Remove 1");
						//RemoveDrawObjects();
						//Draw.TextFixed(this, "PatternLabel", "No Patterns Found", TextPosition.TopLeft, ChartControl.Properties.ChartText, ChartControl.Properties.LabelFont, null, null, 0);
					}
                }
                //k++;

            }
        }
		#endregion

        private void RemoveLivePattern()
        {
            RemoveDrawObject("Ratio_Ghost_Rect");
			RemoveDrawObject("PatternLabel");
        }

        private bool HistoryCalculated = false;

        protected override void OnBarUpdate()
		{
			//if(Calculate != Calculate.OnBarClose && CurrentBar < Bars.Count - 1) return;
			if(CurrentBar < MaxBarsBack) return;
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
int line = 2305;
            if (CurrentBar == _barindex && High[0] == _barhigh && Low[0] == _barlow)
                return;
line=2308;//  Print(Time[0].ToString()+": "+line);
            if (CurrentBar != _barindex)
            {
                _barindex = CurrentBar;
            }
            _barhigh = High[0];
            _barlow = Low[0];
            vPatOnOff = 0;
			lastD = -1;
			
line=2318;//  Print(Time[0].ToString()+": "+line);
            foreach (int depth in depths)
            {
                _CR1(depth);
            }
			
			List<IDrawingTool> drawObjects = DrawObjects.ToList();
			Patterns.ForEach(p =>
            {
                if(p.DIndex >= CurrentBar - LineLength && TradePlan != ARC_Frequencies2_TradePlanType.None)
                {
                    ExtendTargetLines(ShowHistorical ? p.PaternId : 1, drawObjects);
                }
                if (p.IsLive && TradePlan != ARC_Frequencies2_TradePlanType.None)
                {
                    if (High[0] > Math.Max(p.Stop, p.Target) || Low[0] < Math.Min(p.Stop, p.Target))
                    {
						//Print("Stop Or target Are reached on " + p.Name);
                        p.IsLive = false;
                        p.IsDrawn = false;
                        SolidifyPattern(ShowHistorical ? p.PaternId : 1, drawObjects);
                    }
					if(TradePlan == ARC_Frequencies2_TradePlanType.None && CurrentBar > p.DIndex + 10)
					{
                        p.IsLive = false;
                        p.IsDrawn = false;
                        SolidifyPattern(ShowHistorical ? p.PaternId : 1, drawObjects);
					}
                }
            });
        }
//============================================================================================
        protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
        {
            //Print("OnMarketData: " + marketDataUpdate.Last);
            List<IDrawingTool> drawObjects = DrawObjects.ToList();

			if (marketDataUpdate.MarketDataType != MarketDataType.Last || Math.Abs(marketDataUpdate.Price) < double.Epsilon)
            {
                return;
            }
            Patterns.ForEach(p =>
            {
                if (p.IsLive && TradePlan != ARC_Frequencies2_TradePlanType.None)
                {
                    if (marketDataUpdate.Price > Math.Max(p.Stop, p.Target) || marketDataUpdate.Price < Math.Min(p.Stop, p.Target))
                    {
                        p.IsLive = false;
                        p.IsDrawn = false;
                        SolidifyPattern(ShowHistorical ? p.PaternId : 1, drawObjects);
                    }
                }
				else if(p.IsLive && TradePlan == ARC_Frequencies2_TradePlanType.None && CurrentBar > p.DIndex + 10)
				{
                    p.IsLive = false;
                    p.IsDrawn = false;
                    SolidifyPattern(ShowHistorical ? p.PaternId : 1, drawObjects);
				}
            });
        }

        public override string ToString()
        {
            return this.Name;
        }

        private void SolidifyPattern(int id, List<IDrawingTool> drawObjects)
        {
            string suffix = "_" + id.ToString();
            string nameObj = "Ratio_Line_XA" + suffix;
            SolidifyLine(nameObj, drawObjects); 
            nameObj = "Ratio_Line_AB" + suffix;
            SolidifyLine(nameObj, drawObjects);
            nameObj = "Ratio_Line_BC" + suffix;
            SolidifyLine(nameObj, drawObjects);
            nameObj = "Ratio_Line_CD" + suffix;
            SolidifyLine(nameObj, drawObjects);
            nameObj = "Ratio_Triangle_XAB" + suffix;
            SolidifyTriangle(nameObj, drawObjects);
            nameObj = "Ratio_Triangle_BCD" + suffix;
            SolidifyTriangle(nameObj, drawObjects);
            RemoveDrawObject("Ratio_Ghost_Rect");
            RemoveDrawObject("PatternLabel");
        }

        private void SolidifyLine(string name, List<IDrawingTool> drawObjects)
        {
            DrawingTools.Line lineObject = (DrawingTools.Line)drawObjects.FirstOrDefault(o => o.Tag == name);
			//Print("Line is null: " + (lineObject == null).ToString());
            if(lineObject != null)
			{
                lineObject.Stroke.DashStyleHelper = DashStyleHelper.Solid;
			}
        }

        private void SolidifyTriangle(string name, List<IDrawingTool> drawObjects)
        {
            Triangle lineObject = (Triangle)drawObjects.FirstOrDefault(o => o.Tag == name);
			//Print("Triangle is null: " + (lineObject == null).ToString());
            if(lineObject != null)
			{
                lineObject.OutlineStroke.DashStyleHelper = DashStyleHelper.Solid;
			}
        }
		
		private void ExtendTargetLines(int id, List<IDrawingTool> drawObjects)
		{
			int line=2424;
	            string suffix       = string.Format("_{0}", id.ToString());
	            string lineNameObj  = string.Format("StopLevel{0}", suffix);
	            string labelNameObj = string.Format("StopLevelLabel{0}", suffix);
			try{line=2428;
	            ExtendTargetLine(lineNameObj, labelNameObj, drawObjects);
			}catch(Exception e){Print(DateTime.Now.ToString()+": "+line+" "+e.ToString());}
	            lineNameObj  = string.Format("TargetLevel1{0}", suffix);
	            labelNameObj = string.Format("TargetLevelLabel1{0}",suffix);
			try{line=2433;
	            ExtendTargetLine(lineNameObj, labelNameObj, drawObjects);
			}catch(Exception e){Print(DateTime.Now.ToString()+": "+line+" "+e.ToString());}
	            lineNameObj  = string.Format("TargetLevel2{0}", suffix);
	            labelNameObj = string.Format("TargetLevelLabel2{0}", suffix);
			try{line=2438;
	            ExtendTargetLine(lineNameObj, labelNameObj, drawObjects);
			}catch(Exception e){Print(DateTime.Now.ToString()+": "+line+" "+e.ToString());}
	            lineNameObj  = string.Format("ProjectedD{0}", suffix);
	            labelNameObj = string.Format("ProjectedDLabel{0}", suffix);
			try{line=2443;
	            ExtendTargetLine(lineNameObj, labelNameObj, drawObjects);
			}catch(Exception e){Print(DateTime.Now.ToString()+": "+line+" "+e.ToString());}
        }

        private void ExtendTargetLine(string lineName, string labelName, List<IDrawingTool> drawObjects)
		{
            DrawingTools.Line lineObject = (DrawingTools.Line)drawObjects.FirstOrDefault(o => o.Tag == lineName);
            if(lineObject == null)
                return;
            if (CurrentBar - lineObject.StartAnchor.SlotIndex <= LineLength)
            {
                lineObject.EndAnchor.SlotIndex = CurrentBar;
                DrawingTools.Text textObject = (DrawingTools.Text)drawObjects.FirstOrDefault(o => o.Tag == labelName);
                textObject.Anchor.SlotIndex = CurrentBar;
            }
        }
		
		private void SoundAlert()
		{
			string alertSoundFile = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", AlertSoundFile.Trim());
			bool fileVerified = System.IO.File.Exists(alertSoundFile);
			if(fileVerified)
			{
				PlaySound(alertSoundFile);
			}
		}

        #region Properties
        [Range(0, double.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Max Deviation", Description="Maximum Deviation From the ratio parameters", Order=1, GroupName="Parameters")]
		public double MaxFibDelta
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Potential Ratio", Order = 2, GroupName = "Parameters")]
		public bool ShowPotential
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Confirmed Ratio", Order = 3, GroupName = "Parameters")]
		public bool ShowConfirmed
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Historical Ratios", Order = 4, GroupName = "Parameters")]
		public bool ShowHistorical
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Large Ratios", Order = 5, GroupName = "Parameters")]
		public bool ShowLarge
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Small Ratios", Order = 6, GroupName = "Parameters")]
		public bool ShowSmall
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Long Ratios", Order = 10, GroupName = "Parameters")]
		public bool ShowLong
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Short Ratios", Order = 11, GroupName = "Parameters")]
		public bool ShowShort
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name= "Alert Sound File", Order=31, GroupName="Parameters")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string AlertSoundFile
		{ get; set; }
		
		//[NinjaScriptProperty]
		[Display(Name= "Email address", Order=32, GroupName="Parameters")]
		public string pEmailAddress {get;set;}

        [NinjaScriptProperty]
        [Display(Name = "Show Info Box", Order = 33, GroupName = "Parameters")]
        public bool ShowInfoBox
        { get; set; }

        [Display(Name = "Button Text", GroupName = "Parameters", Description = "", Order = 40)]
		public string pButtonText {get;set;}

		[NinjaScriptProperty]
		[Display(Name = "Trade Plan", Order = 1, GroupName = "Trade Plan")]
		public ARC_Frequencies2_TradePlanType TradePlan
		{ get; set; }

		[XmlIgnore]
		[Display(Name = "Entry Line Color", Order = 2, GroupName = "Trade Plan")]
		public Brush EntryLineColor
		{ get; set; }

				[Browsable(false)]
				public string EntryLineColorSerializable { get { return Serialize.BrushToString(EntryLineColor); } set { EntryLineColor = Serialize.StringToBrush(value); }        }

		[XmlIgnore]
		[Display(Name = "Stop Line Color", Order = 3, GroupName = "Trade Plan")]
		public Brush StopLineColor
		{ get; set; }

				[Browsable(false)]
				public string StopLineColorSerializable{ get { return Serialize.BrushToString(StopLineColor); } set { StopLineColor = Serialize.StringToBrush(value); }		}

		[XmlIgnore]
		[Display(Name = "Target Line Color", Order = 4, GroupName = "Trade Plan")]
		public Brush TargetLineColor
		{ get; set; }

				[Browsable(false)]
				public string TargetLineColorSerializable { get { return Serialize.BrushToString(TargetLineColor); } set { TargetLineColor = Serialize.StringToBrush(value); }        }

		[XmlIgnore]
		[Display(Name = "Label Color", Order = 5, GroupName = "Trade Plan")]
		public Brush LabelColor
		{ get; set; }

				[Browsable(false)]
				public string LabelColorSerializable { get { return Serialize.BrushToString(LabelColor); } set { LabelColor = Serialize.StringToBrush(value); }	}


		[Range(1, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name = "Line Length", Order = 6, GroupName = "Trade Plan")]
		public int LineLength
		{ get; set; }

		[Range(0, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name = "Stop Ticks", Order = 11, GroupName = "Trade Plan")]
		public int StopTicks
		{ get; set; }

		[Range(0, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name = "Target 1 Ticks", Order = 12, GroupName = "Trade Plan")]
		public int Target1Ticks
		{ get; set; }

		[Range(0, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name = "Target 2 Ticks", Order = 13, GroupName = "Trade Plan")]
		public int Target2Ticks
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Ratio", Order=1, GroupName= "CRM1/CRW1 Ratio")]
		public bool ShowCR1
		{ get; set; }

		[XmlIgnore]
		[Display(Name = "Bull Ratio Color", Order = 2, GroupName = "CRM1/CRW1 Ratio")]
		public Brush BullCR1Color
		{ get; set; }

				[Browsable(false)]
				public string BullCR1ColorSerializable{ get { return Serialize.BrushToString(BullCR1Color); } set { BullCR1Color = Serialize.StringToBrush(value); }		}

		[XmlIgnore]
		[Display(Name = "Bear Ratio Color", Order = 3, GroupName = "CRM1/CRW1 Ratio")]
		public Brush BearCR1Color
		{ get; set; }

				[Browsable(false)]
				public string BearCR1ColorSerializable
				{
				    get { return Serialize.BrushToString(BearCR1Color); }
				    set { BearCR1Color = Serialize.StringToBrush(value); }
				}

		[Range(0, 100)]
		[NinjaScriptProperty]
		[Display(Name = "Fill Opacity", Order = 4, GroupName = "CRM1/CRW1 Ratio")]
		public int CR1Opacity
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Ratio", Order=1, GroupName= "CRM2/CRW2 Ratio")]
		public bool ShowCR2
		{ get; set; }

		[XmlIgnore]
		[Display(Name = "Bull Color", Order = 2, GroupName = "CRM2/CRW2 Ratio")]
		public Brush BullCR2Color
		{ get; set; }

				[Browsable(false)]
				public string BullCR2ColorSerializable
				{
				    get { return Serialize.BrushToString(BullCR2Color); }
				    set { BullCR2Color = Serialize.StringToBrush(value); }
				}

		[XmlIgnore]
		[Display(Name = "Bear Color", Order = 3, GroupName = "CRM2/CRW2 Ratio")]
		public Brush BearCR2Color
		{ get; set; }

				[Browsable(false)]
				public string BearCR2ColorSerializable
				{
				    get { return Serialize.BrushToString(BearCR2Color); }
				    set { BearCR2Color = Serialize.StringToBrush(value); }
				}

		[Range(0, 100)]
		[NinjaScriptProperty]
		[Display(Name = "Fill Opacity", Order = 4, GroupName = "CRM2/CRW2 Ratio")]
		public int CR2Opacity
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Ratio", Order = 1, GroupName = "CRM3/CRW3 Ratio")]
		public bool ShowCR3
		{ get; set; }

		[XmlIgnore]
		[Display(Name = "Bull Color", Order = 2, GroupName = "CRM3/CRW3 Ratio")]
		public Brush BullCR3Color
		{ get; set; }

				[Browsable(false)]
				public string BullCR3ColorSerializable
				{
				    get { return Serialize.BrushToString(BullCR3Color); }
				    set { BullCR3Color = Serialize.StringToBrush(value); }
				}

		[XmlIgnore]
		[Display(Name = "Bear Color", Order = 3, GroupName = "CRM3/CRW3 Ratio")]
		public Brush BearCR3Color
		{ get; set; }

				[Browsable(false)]
				public string BearCR3ColorSerializable
				{
				    get { return Serialize.BrushToString(BearCR3Color); }
				    set { BearCR3Color = Serialize.StringToBrush(value); }
				}

		[Range(0, 100)]
		[NinjaScriptProperty]
		[Display(Name = "Fill Opacity", Order = 4, GroupName = "CRM3/CRW3 Ratio")]
		public int CR3Opacity
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Ratio", Order=1, GroupName= "RRM1/RRW1 Ratio")]
		public bool ShowRR1
		{ get; set; }

		[XmlIgnore]
		[Display(Name = "Bull Color", Order = 2, GroupName = "RRM1/RRW1 Ratio")]
		public Brush BullRR1Color
		{ get; set; }

				[Browsable(false)]
				public string BullRR1ColorSerializable
				{
				    get { return Serialize.BrushToString(BullRR1Color); }
				    set { BullRR1Color = Serialize.StringToBrush(value); }
				}

		[XmlIgnore]
		[Display(Name = "Bear Color", Order = 3, GroupName = "RRM1/RRW1 Ratio")]
		public Brush BearRR1Color
		{ get; set; }

				[Browsable(false)]
				public string BearRR1ColorSerializable
				{
				    get { return Serialize.BrushToString(BearRR1Color); }
				    set { BearRR1Color = Serialize.StringToBrush(value); }
				}

		[Range(0, 100)]
		[NinjaScriptProperty]
		[Display(Name = "Fill Opacity", Order = 4, GroupName = "RRM1/RRW1 Ratio")]
		public int RR1Opacity
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Ratio", Order=1, GroupName= "RRM2/RRW2 Ratio")]
		public bool ShowRR2
		{ get; set; }

		[XmlIgnore]
		[Display(Name = "Bull Color", Order = 2, GroupName = "RRM2/RRW2 Ratio")]
		public Brush BullRR2Color
		{ get; set; }

				[Browsable(false)]
				public string BullRR2ColorSerializable
				{
				    get { return Serialize.BrushToString(BullRR2Color); }
				    set { BullRR2Color = Serialize.StringToBrush(value); }
				}

		[XmlIgnore]
		[Display(Name = "Bear Color", Order = 3, GroupName = "RRM2/RRW2 Ratio")]
		public Brush BearRR2Color
		{ get; set; }

		[Browsable(false)]
		public string BearRR2ColorSerializable
		{
		    get { return Serialize.BrushToString(BearRR2Color); }
		    set { BearRR2Color = Serialize.StringToBrush(value); }
		}

		[Range(0, 100)]
		[NinjaScriptProperty]
		[Display(Name = "Fill Opacity", Order = 4, GroupName = "RRM2/RRW2 Ratio")]
		public int RR2Opacity
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Ratio", Order=1, GroupName= "RRM3/RRW3 Ratio")]
		public bool ShowRR3
		{ get; set; }

		[XmlIgnore]
		[Display(Name = "Bull Color", Order = 2, GroupName = "RRM3/RRW3 Ratio")]
		public Brush BullRR3Color
		{ get; set; }

				[Browsable(false)]
				public string BullRR3ColorSerializable
				{
				    get { return Serialize.BrushToString(BullRR3Color); }
				    set { BullRR3Color = Serialize.StringToBrush(value); }
				}

		[XmlIgnore]
		[Display(Name = "Bear Color", Order = 3, GroupName = "RRM3/RRW3 Ratio")]
		public Brush BearRR3Color
		{ get; set; }

				[Browsable(false)]
				public string BearRR3ColorSerializable
				{
				    get { return Serialize.BrushToString(BearRR3Color); }
				    set { BearRR3Color = Serialize.StringToBrush(value); }
				}

		[Range(0, 100)]
		[NinjaScriptProperty]
		[Display(Name = "Fill Opacity", Order = 4, GroupName = "RRM3/RRW3 Ratio")]
		public int Five0Opacity
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Ratio", Order=1, GroupName= "RRM4/RRW4 Ratio")]
		public bool ShowRR4
		{ get; set; }

		[XmlIgnore]
		[Display(Name = "Bull Color", Order = 2, GroupName = "RRM4/RRW4 Ratio")]
		public Brush BullRR4Color
		{ get; set; }

				[Browsable(false)]
				public string BullRR4ColorSerializable
				{
				    get { return Serialize.BrushToString(BullRR4Color); }
				    set { BullRR4Color = Serialize.StringToBrush(value); }
				}

		[XmlIgnore]
		[Display(Name = "Bear Color", Order = 3, GroupName = "RRM4/RRW4 Ratio")]
		public Brush BearRR4Color
		{ get; set; }

				[Browsable(false)]
				public string BearRR4ColorSerializable
				{
				    get { return Serialize.BrushToString(BearRR4Color); }
				    set { BearRR4Color = Serialize.StringToBrush(value); }
				}

		[Range(0, 100)]
		[NinjaScriptProperty]
		[Display(Name = "Fill Opacity", Order = 4, GroupName = "RRM4/RRW4 Ratio")]
		public int RR4Opacity
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Show Ratio", Order=1, GroupName= "CRM4/CRW4 Ratio")]
		public bool ShowCR4
		{ get; set; }

		[XmlIgnore]
		[Display(Name = "Bull Color", Order = 2, GroupName = "CRM4/CRW4 Ratio")]
		public Brush BullCR4Color
		{ get; set; }

				[Browsable(false)]
				public string BullCR4ColorSerializable
				{
				    get { return Serialize.BrushToString(BullCR4Color); }
				    set { BullCR4Color = Serialize.StringToBrush(value); }
				}

		[XmlIgnore]
		[Display(Name = "Bear Color", Order = 3, GroupName = "CRM4/CRW4 Ratio")]
		public Brush BearCR4Color
		{ get; set; }

				[Browsable(false)]
				public string BearCR4ColorSerializable
				{
				    get { return Serialize.BrushToString(BearCR4Color); }
				    set { BearCR4Color = Serialize.StringToBrush(value); }
				}

		[Range(0, 100)]
		[NinjaScriptProperty]
		[Display(Name = "Fill Opacity", Order = 4, GroupName = "CRM4/CRW4 Ratio")]
		public int CR4Opacity
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_Frequencies[] cacheARC_Frequencies;
		public ARC.ARC_Frequencies ARC_Frequencies(double maxFibDelta, bool showPotential, bool showConfirmed, bool showHistorical, bool showLarge, bool showSmall, bool showLong, bool showShort, string alertSoundFile, bool showInfoBox, ARC_Frequencies2_TradePlanType tradePlan, int lineLength, int stopTicks, int target1Ticks, int target2Ticks, bool showCR1, int cR1Opacity, bool showCR2, int cR2Opacity, bool showCR3, int cR3Opacity, bool showRR1, int rR1Opacity, bool showRR2, int rR2Opacity, bool showRR3, int five0Opacity, bool showRR4, int rR4Opacity, bool showCR4, int cR4Opacity)
		{
			return ARC_Frequencies(Input, maxFibDelta, showPotential, showConfirmed, showHistorical, showLarge, showSmall, showLong, showShort, alertSoundFile, showInfoBox, tradePlan, lineLength, stopTicks, target1Ticks, target2Ticks, showCR1, cR1Opacity, showCR2, cR2Opacity, showCR3, cR3Opacity, showRR1, rR1Opacity, showRR2, rR2Opacity, showRR3, five0Opacity, showRR4, rR4Opacity, showCR4, cR4Opacity);
		}

		public ARC.ARC_Frequencies ARC_Frequencies(ISeries<double> input, double maxFibDelta, bool showPotential, bool showConfirmed, bool showHistorical, bool showLarge, bool showSmall, bool showLong, bool showShort, string alertSoundFile, bool showInfoBox, ARC_Frequencies2_TradePlanType tradePlan, int lineLength, int stopTicks, int target1Ticks, int target2Ticks, bool showCR1, int cR1Opacity, bool showCR2, int cR2Opacity, bool showCR3, int cR3Opacity, bool showRR1, int rR1Opacity, bool showRR2, int rR2Opacity, bool showRR3, int five0Opacity, bool showRR4, int rR4Opacity, bool showCR4, int cR4Opacity)
		{
			if (cacheARC_Frequencies != null)
				for (int idx = 0; idx < cacheARC_Frequencies.Length; idx++)
					if (cacheARC_Frequencies[idx] != null && cacheARC_Frequencies[idx].MaxFibDelta == maxFibDelta && cacheARC_Frequencies[idx].ShowPotential == showPotential && cacheARC_Frequencies[idx].ShowConfirmed == showConfirmed && cacheARC_Frequencies[idx].ShowHistorical == showHistorical && cacheARC_Frequencies[idx].ShowLarge == showLarge && cacheARC_Frequencies[idx].ShowSmall == showSmall && cacheARC_Frequencies[idx].ShowLong == showLong && cacheARC_Frequencies[idx].ShowShort == showShort && cacheARC_Frequencies[idx].AlertSoundFile == alertSoundFile && cacheARC_Frequencies[idx].ShowInfoBox == showInfoBox && cacheARC_Frequencies[idx].TradePlan == tradePlan && cacheARC_Frequencies[idx].LineLength == lineLength && cacheARC_Frequencies[idx].StopTicks == stopTicks && cacheARC_Frequencies[idx].Target1Ticks == target1Ticks && cacheARC_Frequencies[idx].Target2Ticks == target2Ticks && cacheARC_Frequencies[idx].ShowCR1 == showCR1 && cacheARC_Frequencies[idx].CR1Opacity == cR1Opacity && cacheARC_Frequencies[idx].ShowCR2 == showCR2 && cacheARC_Frequencies[idx].CR2Opacity == cR2Opacity && cacheARC_Frequencies[idx].ShowCR3 == showCR3 && cacheARC_Frequencies[idx].CR3Opacity == cR3Opacity && cacheARC_Frequencies[idx].ShowRR1 == showRR1 && cacheARC_Frequencies[idx].RR1Opacity == rR1Opacity && cacheARC_Frequencies[idx].ShowRR2 == showRR2 && cacheARC_Frequencies[idx].RR2Opacity == rR2Opacity && cacheARC_Frequencies[idx].ShowRR3 == showRR3 && cacheARC_Frequencies[idx].Five0Opacity == five0Opacity && cacheARC_Frequencies[idx].ShowRR4 == showRR4 && cacheARC_Frequencies[idx].RR4Opacity == rR4Opacity && cacheARC_Frequencies[idx].ShowCR4 == showCR4 && cacheARC_Frequencies[idx].CR4Opacity == cR4Opacity && cacheARC_Frequencies[idx].EqualsInput(input))
						return cacheARC_Frequencies[idx];
			return CacheIndicator<ARC.ARC_Frequencies>(new ARC.ARC_Frequencies(){ MaxFibDelta = maxFibDelta, ShowPotential = showPotential, ShowConfirmed = showConfirmed, ShowHistorical = showHistorical, ShowLarge = showLarge, ShowSmall = showSmall, ShowLong = showLong, ShowShort = showShort, AlertSoundFile = alertSoundFile, ShowInfoBox = showInfoBox, TradePlan = tradePlan, LineLength = lineLength, StopTicks = stopTicks, Target1Ticks = target1Ticks, Target2Ticks = target2Ticks, ShowCR1 = showCR1, CR1Opacity = cR1Opacity, ShowCR2 = showCR2, CR2Opacity = cR2Opacity, ShowCR3 = showCR3, CR3Opacity = cR3Opacity, ShowRR1 = showRR1, RR1Opacity = rR1Opacity, ShowRR2 = showRR2, RR2Opacity = rR2Opacity, ShowRR3 = showRR3, Five0Opacity = five0Opacity, ShowRR4 = showRR4, RR4Opacity = rR4Opacity, ShowCR4 = showCR4, CR4Opacity = cR4Opacity }, input, ref cacheARC_Frequencies);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_Frequencies ARC_Frequencies(double maxFibDelta, bool showPotential, bool showConfirmed, bool showHistorical, bool showLarge, bool showSmall, bool showLong, bool showShort, string alertSoundFile, bool showInfoBox, ARC_Frequencies2_TradePlanType tradePlan, int lineLength, int stopTicks, int target1Ticks, int target2Ticks, bool showCR1, int cR1Opacity, bool showCR2, int cR2Opacity, bool showCR3, int cR3Opacity, bool showRR1, int rR1Opacity, bool showRR2, int rR2Opacity, bool showRR3, int five0Opacity, bool showRR4, int rR4Opacity, bool showCR4, int cR4Opacity)
		{
			return indicator.ARC_Frequencies(Input, maxFibDelta, showPotential, showConfirmed, showHistorical, showLarge, showSmall, showLong, showShort, alertSoundFile, showInfoBox, tradePlan, lineLength, stopTicks, target1Ticks, target2Ticks, showCR1, cR1Opacity, showCR2, cR2Opacity, showCR3, cR3Opacity, showRR1, rR1Opacity, showRR2, rR2Opacity, showRR3, five0Opacity, showRR4, rR4Opacity, showCR4, cR4Opacity);
		}

		public Indicators.ARC.ARC_Frequencies ARC_Frequencies(ISeries<double> input , double maxFibDelta, bool showPotential, bool showConfirmed, bool showHistorical, bool showLarge, bool showSmall, bool showLong, bool showShort, string alertSoundFile, bool showInfoBox, ARC_Frequencies2_TradePlanType tradePlan, int lineLength, int stopTicks, int target1Ticks, int target2Ticks, bool showCR1, int cR1Opacity, bool showCR2, int cR2Opacity, bool showCR3, int cR3Opacity, bool showRR1, int rR1Opacity, bool showRR2, int rR2Opacity, bool showRR3, int five0Opacity, bool showRR4, int rR4Opacity, bool showCR4, int cR4Opacity)
		{
			return indicator.ARC_Frequencies(input, maxFibDelta, showPotential, showConfirmed, showHistorical, showLarge, showSmall, showLong, showShort, alertSoundFile, showInfoBox, tradePlan, lineLength, stopTicks, target1Ticks, target2Ticks, showCR1, cR1Opacity, showCR2, cR2Opacity, showCR3, cR3Opacity, showRR1, rR1Opacity, showRR2, rR2Opacity, showRR3, five0Opacity, showRR4, rR4Opacity, showCR4, cR4Opacity);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_Frequencies ARC_Frequencies(double maxFibDelta, bool showPotential, bool showConfirmed, bool showHistorical, bool showLarge, bool showSmall, bool showLong, bool showShort, string alertSoundFile, bool showInfoBox, ARC_Frequencies2_TradePlanType tradePlan, int lineLength, int stopTicks, int target1Ticks, int target2Ticks, bool showCR1, int cR1Opacity, bool showCR2, int cR2Opacity, bool showCR3, int cR3Opacity, bool showRR1, int rR1Opacity, bool showRR2, int rR2Opacity, bool showRR3, int five0Opacity, bool showRR4, int rR4Opacity, bool showCR4, int cR4Opacity)
		{
			return indicator.ARC_Frequencies(Input, maxFibDelta, showPotential, showConfirmed, showHistorical, showLarge, showSmall, showLong, showShort, alertSoundFile, showInfoBox, tradePlan, lineLength, stopTicks, target1Ticks, target2Ticks, showCR1, cR1Opacity, showCR2, cR2Opacity, showCR3, cR3Opacity, showRR1, rR1Opacity, showRR2, rR2Opacity, showRR3, five0Opacity, showRR4, rR4Opacity, showCR4, cR4Opacity);
		}

		public Indicators.ARC.ARC_Frequencies ARC_Frequencies(ISeries<double> input , double maxFibDelta, bool showPotential, bool showConfirmed, bool showHistorical, bool showLarge, bool showSmall, bool showLong, bool showShort, string alertSoundFile, bool showInfoBox, ARC_Frequencies2_TradePlanType tradePlan, int lineLength, int stopTicks, int target1Ticks, int target2Ticks, bool showCR1, int cR1Opacity, bool showCR2, int cR2Opacity, bool showCR3, int cR3Opacity, bool showRR1, int rR1Opacity, bool showRR2, int rR2Opacity, bool showRR3, int five0Opacity, bool showRR4, int rR4Opacity, bool showCR4, int cR4Opacity)
		{
			return indicator.ARC_Frequencies(input, maxFibDelta, showPotential, showConfirmed, showHistorical, showLarge, showSmall, showLong, showShort, alertSoundFile, showInfoBox, tradePlan, lineLength, stopTicks, target1Ticks, target2Ticks, showCR1, cR1Opacity, showCR2, cR2Opacity, showCR3, cR3Opacity, showRR1, rR1Opacity, showRR2, rR2Opacity, showRR3, five0Opacity, showRR4, rR4Opacity, showCR4, cR4Opacity);
		}
	}
}

#endregion
