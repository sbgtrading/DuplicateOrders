#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
using ARC.AlgoSup.All;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace ARC.CTESup
{
	public static class ArcCteBackEnd
	{
        private static Dictionary<string, AccountManager> _dicAccounts = new Dictionary<string, AccountManager>();
        private static bool _bAccountsInitialized = false;

        public static void EnterTrade(string account, Instrument instrument, ETradeType TradeType, TradeSettings settings, double closePrice, string id)
        {
            CheckAccounts();
            if (!_dicAccounts.ContainsKey(account))
                AddAccount(account);
            _dicAccounts[account].EnterTrade(instrument, TradeType, settings, closePrice, id);
        }

        public static void ExitTrade(string account, Instrument instrument, EExitType exitType, string id)
        {
            CheckAccounts();
            if (!_dicAccounts.ContainsKey(account))
                AddAccount(account);
            _dicAccounts[account].ExitTrade(exitType, "", instrument);
        }

        public static void ExitInstrument(Instrument instrument)
        {
            CheckAccounts();
            IEnumerable<string> ids = _dicAccounts.Keys;
            foreach(string id in ids)
                _dicAccounts[id].ExitTrade(EExitType.All, string.Empty, instrument);
        }

        public static void ExitEverything()
        {
            CheckAccounts();
            IEnumerable<string> ids = _dicAccounts.Keys;
            foreach (string id in ids)
                _dicAccounts[id].ExitTrade(EExitType.All);
        }

        private static void CheckAccounts()
        {
            if (_bAccountsInitialized)
                return;

            if (Account.All.Count == 0)
                return;

            foreach (Account account in Account.All)
                AddAccount(account);

            _bAccountsInitialized = true;
        }

        private static void AddAccount(Account account)
        {
            if (!_dicAccounts.ContainsKey(account.Name))
                _dicAccounts.Add(account.Name, new AccountManager(account));
        }
        private static void AddAccount(string account)
        {
            if (!_dicAccounts.ContainsKey(account))
                _dicAccounts.Add(account, new AccountManager(account));
        }
    }

	public class AccountManager
	{
		private Account _Account = null;
        private Dictionary<long, PositionManagerAccount> _Positions = new Dictionary<long, PositionManagerAccount>();

        #region Constructors
        public AccountManager() { }

        public AccountManager(string account)
        {
            if (Account.DbGet(account) != null)
                _Account = Account.DbGet(account);
            SubScribeToAccount();
        }

        public AccountManager(Account account)
        {
            if (account != null)
                _Account = account;
            SubScribeToAccount();
        }
        #endregion

        #region Enter Trade
        public void EnterTrade(Instrument instrument, ETradeType TradeType, TradeSettings settings, double closePrice, string id)
        {
            OrderTo actions = new OrderTo();

            if (_Positions.Count == 0 || !_Positions.ContainsKey(instrument.Id))
                _Positions.Add(instrument.Id, new PositionManagerAccount(instrument));
            _Positions[instrument.Id].Enter(TradeType, settings, closePrice, _Account, id, ref actions);

            ExecuteOrders(actions);
        }
        #endregion

        #region Exit Trade
        public void ExitTrade(EExitType exit, string tradeId = "", Instrument instrument = null)
        {
            OrderTo actions = new OrderTo();

            IEnumerable<long> iDs = _Positions.Keys;
            foreach (long id in iDs)
            {
                if (instrument == null || instrument.Id == id)
                    _Positions[id].Exit(exit, _Account, tradeId, ref actions);
            }

            ExecuteOrders(actions);
        }
        #endregion

        #region Functions
        private void SubScribeToAccount()
        {
            if (_Account == null)
                return;
            _Account.OrderUpdate += Account_OrderUpdate;
            _Account.PositionUpdate += _Account_PositionUpdate;
        }
        #endregion

        #region Order Updates
        private void Account_OrderUpdate(object sender, OrderEventArgs e)
        {
            if (e.Order != null)
                ProcessOrderUpdate(e);
        }

        private void _Account_PositionUpdate(object sender, PositionEventArgs e)
        {
            if (e.Position == null || !_Positions.ContainsKey(e.Position.Instrument.Id))
                return;
            _Positions[e.Position.Instrument.Id].PositionUpdate(e);
        }

        private void ProcessOrderUpdate(OrderEventArgs order)
        {
            if (_Account == null || _Positions.Count == 0 || !_Positions.ContainsKey(order.Order.Instrument.Id))
                return;
            OrderTo actions = new OrderTo();
            _Positions[order.Order.Instrument.Id].ProcessOrderUpdate(_Account, order, ref actions);
            ExecuteOrders(actions);
        }
        #endregion

        #region Internal Functions
        private void ExecuteOrders(OrderTo orders)
        {
            if (orders.Change.Count > 0)
                _Account.Change(orders.Change.ToArray());
            if (orders.Cancel.Count > 0)
                _Account.Cancel(orders.Cancel.ToArray());
            if (orders.Submit.Count > 0)
                _Account.Submit(orders.Submit.ToArray());
        }
        #endregion
    }

    #region Position Manager Account
    public class PositionManagerAccount : IDisposable
    {
        #region Floating Variables
        private List<NsPosition> _PositionsShort = new List<NsPosition>();
        private List<NsPosition> _PositionsLong = new List<NsPosition>();
        private Instrument _Instrument = null;
        private Position _Position = null;
        #endregion

        #region Constructors
        public PositionManagerAccount() { }
        public PositionManagerAccount(Instrument instrument)
        {
            _Instrument = instrument;
        }
        #endregion

        #region Initialize
        public void Initialize(Instrument instrument)
        {
            _Instrument = instrument;
        }
        #endregion

        #region Order Updates
        public void PositionUpdate(PositionEventArgs e)
        {
            _Position = e.Position;
        }

        public void ProcessOrderUpdate(Account account, OrderEventArgs order, ref OrderTo actions)
        {
            bool bIsOrderIdentified = false;
            lock (_PositionsLong)
            {
                if (_PositionsLong.Count > 0)
                {
                    double dCurrentLongStopValue = _PositionsLong[0].WorkingTradeStopPrice;
                    for (int i = _PositionsLong.Count - 1; i >= 0; i--)
                    {
                        actions = _PositionsLong[i].ProcessOrderUpdate(account, order, actions, dCurrentLongStopValue);
                        if (_PositionsLong[i].OrderIdentified)
                            bIsOrderIdentified = true;
                        if (_PositionsLong[i].PositionState == ETradeState.Nothing)
                            _PositionsLong.RemoveAt(i);
                    }
                }
            }
            lock (_PositionsShort)
            {
                if (_PositionsShort.Count > 0)
                {
                    double dCurrentShortStopValue = _PositionsShort[0].WorkingTradeStopPrice;
                    for (int i = _PositionsShort.Count - 1; i >= 0; i--)
                    {
                        actions = _PositionsShort[i].ProcessOrderUpdate(account, order, actions, dCurrentShortStopValue);
                        if (_PositionsShort[i].OrderIdentified)
                            bIsOrderIdentified = true;
                        if (_PositionsShort[i].PositionState == ETradeState.Nothing)
                            _PositionsShort.RemoveAt(i);
                    }
                }
            }
        }
        #endregion

        #region Entry
        public void Enter(ETradeType TradeType, TradeSettings settings, double closePrice, Account account, string id, ref OrderTo actions)
        {
            if (TradeType == ETradeType.Long && _PositionsShort.Count == 0)
            {
                NsPosition position = CreatePosition(TradeType, settings, closePrice, account, _Instrument, id, ref actions);
                _PositionsLong.Add(position);
            }
            else if (TradeType == ETradeType.Short && _PositionsLong.Count == 0)
            {
                NsPosition position = CreatePosition(TradeType, settings, closePrice, account, _Instrument, id, ref actions);
                _PositionsShort.Add(position);
            }
        }
        #endregion

        #region Exit
        public void Exit(EExitType exitType, Account account, string id, ref OrderTo actions)
        {
            if (_Instrument == null)
                return;
            if (exitType.HasFlag(EExitType.Long) || exitType.HasFlag(EExitType.All))
            {
                if ((_Position == null || _Position.MarketPosition == MarketPosition.Long) && _PositionsLong.Count > 0)
                {
                    for (int i = 0; i < _PositionsLong.Count; i++)
                    {
                        if (_PositionsLong[i] != null && (string.IsNullOrEmpty(id) || _PositionsLong[i].ID == id))
                            actions = _PositionsLong[i].Exit(_Instrument, account, exitType, actions);
                    }
                }
            }
            if (exitType.HasFlag(EExitType.Short) || exitType.HasFlag(EExitType.All))
            {
                if ((_Position == null || _Position.MarketPosition == MarketPosition.Short) && _PositionsShort.Count > 0)
                {
                    for (int i = 0; i < _PositionsShort.Count; i++)
                        if (_PositionsShort[i] != null && (string.IsNullOrEmpty(id) || _PositionsShort[i].ID == id))
                            actions = _PositionsShort[i].Exit(_Instrument, account, exitType, actions);
                }
            }
        }
        #endregion

        #region Interfaces
        public void Dispose()
        {

        }
        #endregion

        #region Internal Functions
        private NsPosition CreatePosition(ETradeType tradeType, TradeSettings settings, double closePrice, Account account, Instrument instrument, string id, ref OrderTo actions)
        {
            NsPosition position = new NsPosition(tradeType, settings, closePrice, account, instrument, id, ref actions);
            return position;
        }
        #endregion
    }
    #endregion

    #region Single Position
    public class NsPosition : IDisposable
    {
        #region Floating Variables
        private NsOrder _oEntry = null;
        private NsOrder _oStop = null;
        private List<NsOrder> _lstTarget = null;
        private ETradeType _TradeType = ETradeType.Long;
        private ETradeState _TradeState = ETradeState.Nothing;
        private string _sID = string.Empty;
        private TradeSettings _Settings = null;
        private bool _bAllStopsPlaced = false;
        #endregion

        #region Contructors
        public NsPosition() { }
        public NsPosition(ETradeType tradeType, TradeSettings settings, double closePrice, Account account, Instrument instrument, string id, ref OrderTo actions)
        {
            _TradeType = tradeType;
            _sID = id;
            _Settings = settings;

            _oEntry = new NsOrder(String.Format("{0} {1}", "Entry", _TradeType == ETradeType.Long ? "Long" : "Short"), settings.Entry.Price, settings.Entry.Quantity,
                _TradeType == ETradeType.Long ? OrderAction.Buy : OrderAction.SellShort);
            if (_oEntry.Price > 0)
            {
                if (_oEntry.Price >= closePrice)
                    _oEntry.OrderType = _TradeType == ETradeType.Long ? OrderType.StopMarket : OrderType.Limit;
                else if (_oEntry.Price <= closePrice)
                    _oEntry.OrderType = _TradeType == ETradeType.Long ? OrderType.Limit : OrderType.StopMarket;
                else
                    _oEntry.OrderType = OrderType.Market;
            }
            else
                _oEntry.OrderType = OrderType.Market;

            _oStop = new NsOrder(String.Format("{0} {1}", "Stop", _TradeType == ETradeType.Long ? "Long" : "Short"), settings.Stop.Price, settings.Stop.Quantity,
                _TradeType == ETradeType.Long ? OrderAction.Sell : OrderAction.BuyToCover, OrderType.StopMarket);
            _lstTarget = new List<NsOrder>();

            //build target list for initialize
            if (settings.Targets.Count > 0)
            {
                for(int i = 0; i < settings.Targets.Count; i++)
                    _lstTarget.Add(new NsOrder(String.Format("{0} {2} {1}", "Target", _TradeType == ETradeType.Long ? "Long" : "Short", i + 1),
                        settings.Targets[i].Price, settings.Targets[i].Quantity, _TradeType == ETradeType.Long ? OrderAction.Sell : OrderAction.BuyToCover, OrderType.Limit));
            }

            actions = _oEntry.Enter(instrument, account, -1, actions);

            _TradeState = ETradeState.EntrySubmitted;
        }
        #endregion

        #region Exit
        public OrderTo Exit(Instrument instrument, Account account, EExitType exitType, OrderTo actions)
        {
            if (_oStop != null)
                actions = _oStop.Exit(instrument, account, exitType, actions);
            if (_lstTarget != null && _lstTarget.Count > 0)
                for (int i = 0; i < _lstTarget.Count; i++)
                    actions = _lstTarget[i].Exit(instrument, account, exitType, actions);
            if (_oEntry != null)
                actions = _oEntry.Exit(instrument, account, exitType, actions);
            //Here we check to make sure that something has been submitted so we know to make sure to look in the order update to update the trade state as well, after the exit is complete
            if (actions.HasSomethingInIt())
                _TradeState = ETradeState.ExitSubmitted;
            else if (_TradeState != ETradeState.ExitSubmitted)
                _TradeState = ETradeState.Nothing;
            return actions;
        }
        #endregion

        #region ProcessOrderUpdate
        public OrderTo ProcessOrderUpdate(Account account, OrderEventArgs order, OrderTo actions, double dStopPriceForMerge)
        {
            OrderIdentified = false;
            if (_oEntry.IsOrderLive)
            {
                //we check to make sure that the order is the entry and that it is in a correct state for processing
                bool result = _oEntry.ProcessOrderUpdate(order) == 1;
                //if the order is identified, irespective of the state that it is in, then we set the flag that the order is identified so that we can let the higher ups know and manage it accordingly
                if (_oEntry.OrderIdentified)
                    OrderIdentified = true;
                if (result)
                {
                    switch (order.Order.OrderState)
                    {
                        case OrderState.Filled:
                        case OrderState.PartFilled:
                            _TradeState = ETradeState.StopTargetSubmitted;
                            _oEntry.Price = _oEntry.Order.AverageFillPrice;
                            actions = PlaceStopsTargets(order.Order.Instrument, account, actions, dStopPriceForMerge);
                            break;
                        case OrderState.Cancelled:
                        case OrderState.Rejected:
                            _oEntry.Order = null;
                            _oEntry.Oco = String.Empty;
                            OrderIdentified = false;
                            _TradeState = ETradeState.Nothing;
                            break;

                    }
                }
            }
            if (_oStop.IsOrderLive)
            {
                int result = _oStop.ProcessOrderUpdate(order);
                if (_oStop.OrderIdentified)
                    OrderIdentified = true;
                if (result == 1)
                {
                    if (_oStop.Order.OrderState == OrderState.Rejected && _TradeState == ETradeState.StopTargetSubmitted)
                        actions = _oEntry.Exit(order.Order.Instrument, account, EExitType.All, actions);
                    _oStop.Order = null;
                    _oStop.Oco = String.Empty;
                    //if the stop is hit then the entire trade should go flat, meaning cancel all targets that are submitted
                    if (!IsTargetLive())
                    {
                        _oEntry.Order = null;
                        _oEntry.Oco = String.Empty;
                        _TradeState = ETradeState.Nothing;
                    }
                    else if (_lstTarget.Count > 0)
                    {
                        for (int i = 0; i < _lstTarget.Count; i++)
                            actions = _lstTarget[i].Exit(order.Order.Instrument, account, EExitType.All, actions);
                    }
                }
                else if(result == 2)
                {
                    if (_oEntry.Order.Quantity == _oEntry.Order.Filled && _oEntry.Order.Filled == _oStop.Order.Quantity)
                        _bAllStopsPlaced = true;
                    if (_oEntry.Order.Filled != _oStop.Order.Quantity)
                        actions = PlaceStopsTargets(order.Order.Instrument, account, actions, dStopPriceForMerge);
                }
            }
            if (IsTargetLive())
            {
                bool bStopChangedNoNeedToCancel = false;
                int iQty = _oEntry.Quantity;
                for (int i = 0; i < _lstTarget.Count; i++)
                {
                    if (_lstTarget[i].IsOrderLive)
                    {
                        int result = _lstTarget[i].ProcessOrderUpdate(order);
                        if (_lstTarget[i].OrderIdentified)
                            OrderIdentified = true;
                        if (result == 1)
                        {
                            if (_lstTarget[i].Order.OrderState == OrderState.Rejected && _TradeState == ETradeState.StopTargetSubmitted)
                                actions = _oEntry.Exit(order.Order.Instrument, account, EExitType.All, actions);
                            _lstTarget[i].Order = null;
                            _lstTarget[i].Oco = String.Empty;
                            _lstTarget[i].Active = false;
                            //need to remove these targets from the entry and stop to make sure that if we hit the exit key then we don't get unexpected results
                            iQty -= _lstTarget[i].Quantity;
                            if (iQty == 0)
                                actions = _oStop.Exit(order.Order.Instrument, account, EExitType.All, actions);
                            else
                                actions = ChangeStopQuantity(iQty, actions);
                        }
                        else if (result == 2)
                        {
                            actions = PlaceStopsTargets(order.Order.Instrument, account, actions, dStopPriceForMerge);
                        }
                    }
                }
                _oEntry.Quantity = iQty;
                if (!IsTargetLive())
                {
                    int iTargetQuantity = _lstTarget.Where(x => x.Active).Sum(x => x.Quantity);
                    if (!_oStop.IsOrderLive)
                    {
                        _oEntry.Order = null;
                        _oEntry.Oco = String.Empty;
                        _TradeState = ETradeState.Nothing;
                        //if OCO is selected then we need to change the stop quantity to match the number of positions still open
                    }
                    //else if(iTargetQuantity > 0 && iTargetQuantity == _oStop.Values.Quantity)
                    //    actions = _oStop.Exit(indicator.Instrument, account, EExitType.All, actions);
                }
            }
            if (_TradeState == ETradeState.ExitSubmitted &&
                (((order.Order.OrderState == OrderState.Filled || order.Order.OrderState == OrderState.PartFilled) && order.Order.Name.Contains("Exit")) ||
                ((order.Order.OrderState == OrderState.Cancelled || order.Order.OrderState == OrderState.CancelPending || order.Order.OrderState == OrderState.CancelSubmitted) && order.Order.Name.Contains("Entry"))))
            //if the exit is submitted and it is filled then we change the trade state
            //if entry is canceled then we remove the order
            {
                if (order.Order.Name.Contains("Entry"))
                {
                    bool result = _oEntry.ProcessOrderUpdate(order) == 1;
                    if (result)
                    {
                        _oEntry.Order = null;
                        _oEntry.Oco = String.Empty;
                        _TradeState = ETradeState.Nothing;
                    }
                }
                else
                {
                    _TradeState = ETradeState.Nothing;
                    OrderIdentified = true;
                }
            }
            return actions;
        }
        #endregion

        #region Stop & Target
        private OrderTo PlaceStopsTargets(Instrument instrument, Account account, OrderTo actions, double dStopPriceForMerge)
        {
            //place stops
            if(!_bAllStopsPlaced)
                actions = PlaceStop(instrument, account, actions, dStopPriceForMerge);
            //place targets (if any)
            actions = PlaceTargets(instrument, account, actions);
            return actions;
        }

        public OrderTo PlaceStop(Instrument instrument, Account account, OrderTo actions, double dStopPriceForMerge)
        {
            if (_oStop.Order == null || _oStop.Order.OrderState == OrderState.Cancelled || _oStop.Order.OrderState == OrderState.Filled)
            {
                _oStop.Price = _oEntry.Order.AverageFillPrice + (_TradeType == ETradeType.Long ? -1 : 1) * _Settings.Stop.Ticks * instrument.MasterInstrument.TickSize;
                if (dStopPriceForMerge != 0)
                    _oStop.Price = dStopPriceForMerge;
                if (_oStop.Price != 0)
                    actions = _oStop.Enter(instrument, account, _oEntry.Order.Filled, actions);
            }
            else if (_oStop.Order != null && _oStop.Order.Quantity != _oEntry.Order.Filled)
                actions = _oStop.ChangeQuantity(_oEntry.Order.Filled, actions);

            return actions;
        }

        public OrderTo PlaceTargets(Instrument instrument, Account account, OrderTo actions)
        {
            if (_lstTarget.Count > 0)
            {
                double difference = Math.Abs(_oEntry.Order.AverageFillPrice - _oStop.Price);
                int iFilled = _oEntry.Order.Filled;
                for (int i = 0; i < _lstTarget.Count; i++)
                {
                    if (iFilled <= 0)
                        break;
                    if (_lstTarget[i].Active && _Settings.Targets[i].Ticks != 0)
                    {
                        if (_lstTarget[i].Order == null || _lstTarget[i].Order.OrderState == OrderState.Cancelled || _lstTarget[i].Order.OrderState == OrderState.Filled)
                        {
                            _lstTarget[i].Price = _oEntry.Order.AverageFillPrice + (_TradeType == ETradeType.Long ? 1 : -1) * _Settings.Targets[i].Ticks * instrument.MasterInstrument.TickSize;
                            if (_lstTarget[i].Price > 0)
                                actions = _lstTarget[i].Enter(instrument, account, Math.Min(iFilled, _lstTarget[i].DesiredQuantity), actions);
                        }
                        else if (_lstTarget[i].Order != null)
                        {
                            if (_lstTarget[i].Order.Quantity != Math.Min(iFilled, _lstTarget[i].DesiredQuantity))
                                actions = _lstTarget[i].ChangeQuantity(Math.Min(iFilled, _lstTarget[i].DesiredQuantity), actions);
                            iFilled -= Math.Max(_lstTarget[i].Order.Quantity, _lstTarget[i].Order.QuantityChanged);
                        }
                    }
                    else
                        break;
                }
            }
            return actions;
        }

        private bool IsTargetLive()
        {
            if (_lstTarget.Count > 0)
            {
                for (int i = 0; i < _lstTarget.Count; i++)
                    if (_lstTarget[i].IsOrderLive)
                        return true;
            }
            return false;
        }
        #endregion

        #region Change Stop Quantity
        public OrderTo ChangeStopQuantity(int quantity, OrderTo actions)
        {
            if (_oStop == null || _oStop.Order == null)
                return actions;
            actions = _oStop.ChangeQuantity(quantity, actions);
            return actions;
        }
        #endregion

        #region Interface Stuff
        public void Dispose()
        {
            _TradeState = ETradeState.Nothing;
            _oEntry.Dispose(); _oEntry = null;
            _oStop.Dispose(); _oStop = null;
            if (_lstTarget.Count > 0)
                for (int i = 0; i < _lstTarget.Count; i++)
                    _lstTarget[i].Dispose();
            _lstTarget.Clear();
            _lstTarget = null;
        }
        #endregion

        #region Properties
        public ETradeState PositionState
        {
            get { return _TradeState; }
        }
        public bool OrderIdentified { get; set; }
        public double WorkingTradeStopPrice
        {
            get
            {
                return _oStop != null && _oStop.Order != null ? _oStop.Order.StopPrice : 0;
            }
        }

        public string ID
        {
            get { return _sID; }
        }
        #endregion
    }
    #endregion

    #region Single Order
    public class NsOrder : IDisposable
    {
        #region Properties
        public bool Active { get; set; }
        public string Name { get; set; }
        public string Oco { get; set; }
        public double Price { get; set; }
        public int DesiredQuantity { get; set; }
        public int Quantity { get; set; }
        public bool QuantityChange { get; set; }
        public bool OrderIdentified { get; set; }
        public OrderAction Action { get; set; }
        public OrderType OrderType { get; set; }
        public Order Order { get; set; }
        public bool IsOrderLive
        {
            get { return Active && Order != null; }
        }
        #endregion

        #region Contructors
        public NsOrder(string name, double price, int quantity, OrderAction orderAction, OrderType orderType = OrderType.Market, bool active = true)
        {
            Action = orderAction;
            Name = name;
            OrderType = orderType;
            Active = active;
            Oco = String.Empty;
            Price = price;
            Quantity = quantity;
            DesiredQuantity = quantity;
        }
        #endregion

        #region Enter
        public OrderTo Enter(Instrument instrument, Account account, int quantity, OrderTo actions)
        {
            if (Active)
            {
                if (quantity != -1)
                    Quantity = quantity;
                if (Quantity == 0)
                    return actions;
                double dLimit = OrderType == OrderType.Limit ? Price : 0;
                double dStop = OrderType == OrderType.StopMarket ? Price : 0;
                Order = account.CreateOrder(instrument, Action, OrderType, OrderEntry.Automated, TimeInForce.Gtc, Quantity, dLimit, dStop, Oco, Name, NinjaTrader.Core.Globals.MaxDate, null);
                actions.Submit.Add(Order);
            }
            return actions;
        }
        #endregion

        #region Exit
        public OrderTo Exit(Instrument instrument, Account account, EExitType exitType, OrderTo actions)
        {
            if (IsOrderLive)
            {
                if (Order.OrderState == OrderState.Working || Order.OrderState == OrderState.Accepted)
                {
                    actions.Cancel.Add(Order);
                }
                else if (Order.OrderState == OrderState.Filled)
                {
                    Order order = account.CreateOrder(instrument, Order.OrderAction.GetOpposingOrderAction(), OrderType.Market, OrderEntry.Automated, TimeInForce.Gtc, Quantity, 0, 0, Oco, "Exit " + Name, NinjaTrader.Core.Globals.MaxDate, null);
                    actions.Submit.Add(order);
                    Order = null;
                }
            }
            return actions;
        }
        #endregion

        #region Change Quantity
        public OrderTo ChangeQuantity(int quantity, OrderTo actions)
        {
            if (IsOrderLive)
            {
                if (Order.OrderState == OrderState.Working || Order.OrderState == OrderState.Accepted)
                {
                    if (Order.Quantity != quantity && (!QuantityChange || Order.QuantityChanged != quantity))
                    {
                        Quantity = quantity;
                        Order.QuantityChanged = quantity;
                        QuantityChange = true;
                        actions.Change.Add(Order);
                    }
                }
            }
            return actions;
        }
        #endregion

        #region Process Order Update
        public int ProcessOrderUpdate(OrderEventArgs order)
        {
            OrderIdentified = false;
            if (Order != null && order.Order.Id == Order.Id)
            {
                //Normal Order Shit
                OrderIdentified = true;
                if (order.Order.OrderState == OrderState.Filled || order.Order.OrderState == OrderState.PartFilled)
                    return 1;
                else if (order.Order.OrderState == OrderState.Cancelled)
                    return 1;
                else if (order.Order.OrderState == OrderState.Working || order.Order.OrderState == OrderState.Accepted)
                {
                    Price = order.Order.OrderType == OrderType.Limit ? order.Order.LimitPrice : order.Order.StopPrice;
                    return 2;
                }
                //Error Handling
                if (order.Error != ErrorCode.NoError)
                {
                    switch (order.Error)
                    {
                        case ErrorCode.UnableToChangeOrder:
                            Order.QuantityChanged = Order.Quantity;
                            Order.LimitPriceChanged = Order.LimitPrice;
                            Order.StopPriceChanged = Order.StopPrice;
                            break;
                    }
                }
                //Complete Order Rejection
                if (order.Order.OrderState == OrderState.Rejected)
                    return 1;
            }
            return 0;
        }
        #endregion

        #region Cleaners
        public void Clean()
        {
            Order = null;
            Oco = String.Empty;
        }

        public void Dispose()
        {
            Clean();
            Active = false;
        }
        #endregion
    }
    #endregion

    #region Trade Settings
    public class TradeSettings
    {
        private List<TradeDetails> _lstTargets = new List<TradeDetails>();
        public TradeDetails Entry { get; set; }
        public TradeDetails Stop { get; set; }
        public List<TradeDetails> Targets { get { return _lstTargets; } set { _lstTargets = value; } }
    }
    #endregion

    #region Trade Details
    public class TradeDetails
    {
        public double Price { get; set; }
        public double Ticks { get; set; }
        public int Quantity { get; set; }
    }
    #endregion

    #region Order To (Account Speciffic)
    public class OrderTo
    {
        public List<Order> Cancel { get; set; }
        public List<Order> Submit { get; set; }
        public List<Order> Change { get; set; }
        public OrderTo()
        {
            Cancel = new List<Order>();
            Submit = new List<Order>();
            Change = new List<Order>();
        }
        public bool HasSomethingInIt()
        {
            return Cancel.Count > 0 || Submit.Count > 0 || Change.Count > 0;
        }
    }
    #endregion

    #region Enums

    #region Attach Order Type
    public enum AttachOrderType
    {
        Entry,
        Stop,
        Target
    }
    #endregion

    #region Trade Type
    public enum ETradeType
    {
        Long,
        Short
    }
    #endregion

    #region Exit Type
    public enum EExitType
    {
        Long,
        Short,
        All
    }
    #endregion

    #region Trade State
    public enum ETradeState
    {
        Nothing,
        EntrySubmitted,
        StopTargetSubmitted,
        ExitSubmitted,
        //RejectedAndResubmitting,
        //RejectedAndCanceling

        //These last 2 we think we might not need to implement but we have put them in as a placeholder
    }
    #endregion

    #region Settings Update
    public enum ESettingsUpdate
    {
        AlwaysUpdate,
        UpdateTrailOnly,
        UpdateTrailStopTargetQuantity,
        NeverUpdate
    }
    #endregion

    #endregion

}
