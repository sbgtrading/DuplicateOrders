#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using ARC_Waves;
using SharpDX.DirectWrite;
using System.Windows.Controls;
using System.Windows.Automation;
#endregion

#region Author/Copyright
/*********************************************************************
************************* Golden Zone Trading ************************
**********************************************************************
* Author NT7 : -
* Author NT8 : Kriss { AzurITec }
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
v1.000  - 06.05.2016    + Conversion from NT7 to NT8b10 as is (no change nor optimization).
----------------------------------------------------------------------
v1.001  - 11.12.2017    + JQ - BUG #12621 - Problem with Waves toolbar not showing up in multiple tabs.
						+ Added indicator version number on the property window.
----------------------------------------------------------------------
*/
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	#region Enums
    public enum NSWavesCountSide { UP = 1, DOWN = 0 }
    public enum NSWavesName
    {
        RAZ = 0,
        V1 = 1,
        V2A = 21, V2B = 22, V2C = 23,
        V3 = 3, V31 = 31, V32A = 321, V32B = 322, V32C = 323, V33 = 33, V34A = 341, V34B = 342, V34C = 343, V35 = 35,
        V4A = 41, V4B = 42, V4C = 43,
        V51 = 51, V52 = 52, V53 = 53, V54 = 54, V55 = 55, V5 = 5,
        V5Y = 61, V5Z = 62, VC = 63
    };
    public enum NSILVType { INVALID, VALID, LIMIT }
    public enum NSPRZType { CORRECTIVE, IMPULSIVE }
//	public enum ARC_Waves_SentimentDetectionMode {OFF, OnClose, OnTick}
	public enum ARC_Waves_SentimentDialogLoc {TopRight, BottomRight, TopLeft, BottomLeft, Center, None}
	#endregion

	#region Category order
    [CategoryOrder("SwingTrend Parameters", 1)]
    [CategoryOrder("SwingTrend Display", 2)]
    [CategoryOrder("Countdown Display", 3)]
    [CategoryOrder("Guides Display", 4)]
    [CategoryOrder("Zones Display", 5)]
    [CategoryOrder("Wave 2", 10)]
    [CategoryOrder("Wave 3", 11)]
    [CategoryOrder("Wave 4", 12)]
    [CategoryOrder("Wave 5", 13)]
    [CategoryOrder("Wave abc", 14)]
	#endregion
    public class ARC_Waves : Indicator
	{
		private const int DT_TYPE = 99;
		private const int DB_TYPE = -99;
		private const int HH_TYPE = 1;
		private const int LH_TYPE = 2;
		private const int LL_TYPE = -1;
		private const int HL_TYPE = -2;
		private const bool PEAK = true;
		private const bool VALLEY = false;

		private const int UP = 1;
		private const int DOWN = -1;
		private const int FLAT = 0;
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "Waves";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<240)//time limit = 240 minutes...messages are considered duplicates if they are less than 240 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "3500", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsDebug = false;

		private Series<int> StructureDirection;
		private Countdown[] decompte;
		
		//v1.5 - Moved Series<double> inits to DataLoaded state, for NT8.0.20.0 compatibility
		//v1.6 - corrected height of Structure Flooding zones...used ChartPanel.H
				//Changed ImpTXT to "Tgt" and CorTXT to "Cor"
				//Fixed UI - Bearish "Display Objective Zones" and "Display Corrective Zones" was changing bullish menu item text.
		//v1.7 - Added the Structure Bias box on chart
				//Prevented the "Display Last Count" or "Display Historical Count" on/off from affecting the appearance of the swing lines
		//v1.8 - Added custom button text
		//v1.9 - Fixed StructureDirection bug by defining and using StructureHighNodePrice and StructureLowNodePrice

		private const string VERSION = "v1.10 July 18 2020";

        #region --- List/Series ---
        private Series<bool> upTrend;
        //private Series<double> UpCount, DownCount;
		private double StructureHighNodePrice = 0;
		private double StructureLowNodePrice = 0;
        private List<ElliottPivot> ElliottPivotDecUP;
        private List<ElliottPivot> ElliottPivotDecDW;
        private List<ElliottPivot> tmpElliottPivotDecUP;
        private List<ElliottPivot> tmpElliottPivotDecDW;
        #endregion

        #region -- zigzag variables --
        private Series<int> pre_swingHighType;
        private Series<int> pre_swingLowType;
        private Series<int> swingHighType;
        private Series<int> swingLowType;
        private double swingMax, swingMin;
        private bool updateHigh, updateLow, addHigh = false, addLow = false;
        private double currentHigh;
        private double currentLow;
        private int lastHighIdx = 0;
        private int lastLowIdx = 0;
        private int priorSwingHighIdx = 0;
        private int priorSwingLowIdx = 0;
		private SortedDictionary<int,double[]> SwingHighsDict = new SortedDictionary<int,double[]>();//key[0] is the price, key[1] is the type HH(1) or LH{2), LL(-1), LH(-2}
		private SortedDictionary<int,double[]> SwingLowsDict = new SortedDictionary<int,double[]>();
        #endregion
        #region -- zigzag indicator from VMDivergences -- 
        private int vlastHighIdx = 0;
        private int vlastLowIdx = 0;
        private int vpriorSwingHighIdx = 0;
        private int vpriorSwingLowIdx = 0;
        private int vhighCount = 0;
        private int vlowCount = 0;
        private int vpreLastHighIdx = 0;
        private int vpreLastLowIdx = 0;
        private double vzigzagDeviation = 0.0;
        private double vcurrentHigh = 0.0;
        private double vcurrentLow = 0.0;
        private double vswingMax = 0.0;
        private double vswingMin = 0.0;
        private double vpreCurrentHigh = 0.0;
        private double vpreCurrentLow = 0.0;
        private bool vaddHigh = false;
        private bool vupdateHigh = false;
        private bool vaddLow = false;
        private bool vupdateLow = false;
        private bool vdrawHigherHighDot = false;
        private bool vdrawLowerHighDot = false;
        private bool vdrawDoubleTopDot = false;
        private bool vdrawLowerLowDot = false;
        private bool vdrawHigherLowDot = false;
        private bool vdrawDoubleBottomDot = false;
        private bool vdrawHigherHighLabel = false;
        private bool vdrawLowerHighLabel = false;
        private bool vdrawDoubleTopLabel = false;
        private bool vdrawLowerLowLabel = false;
        private bool vdrawHigherLowLabel = false;
        private bool vdrawDoubleBottomLabel = false;
        private bool vdrawSwingLegUp = false;
        private bool vdrawSwingLegDown = false;
        private bool vintraBarAddHigh = false;
        private bool vintraBarUpdateHigh = false;
        private bool vintraBarAddLow = false;
        private bool vintraBarUpdateLow = false;
        private Series<double> structureBiasState;
//        private Series<double> swingHighsState;
//        private Series<double> swingLowsState;

        #region -- Structure BIAS + Swings --
        private List<int> sequence = new List<int>(3);//#STRBIAS
        private int SRType, preSRType;//#STRBIAS  
        #endregion

//        private SimpleFont labelFont = null;
//        private SimpleFont swingDotFont = null;
//        private int pixelOffset1 = 10;               //##HARD CODED##
//        private int pixelOffset2 = 10;               //##HARD CODED##
//        private Brush upColor = Brushes.LimeGreen;//##HARD CODED##
//        private Brush downColor = Brushes.Red;      //##HARD CODED##
//        private Brush doubleTopBottomColor = Brushes.Yellow;   //##HARD CODED##
//        private string dotString = "n";              //##HARD CODED##

        private ATR vavgTrueRange;
        private Series<double> vswingInput;
        private Series<int> vpre_swingHighType;
        private Series<int> vpre_swingLowType;
        private Series<int> vswingHighType;
        private Series<int> vswingLowType;
//        private Series<int> vacceleration1;
//        private Series<int> vacceleration2;
        private Series<bool> vupTrend;
        #endregion

        #region -- Waves/Guides names --
        private const string NAME_V1 = "1";
        private const string NAME_V2A = "2a";
        private const string NAME_V2B = "2b/3.1";
        private const string NAME_V2C = "2c";
        private const string NAME_V3 = "3";
        private const string NAME_V31 = "3.1";
        private const string NAME_V32A = "3.2a";
        private const string NAME_V32B = "3.2b";
        private const string NAME_V32C = "3.2c";
        private const string NAME_V33 = "3.3";
        private const string NAME_V34A = "3.4a";
        private const string NAME_V34B = "3.4b";
        private const string NAME_V34C = "3.4c";
        private const string NAME_V35 = "3.5";
        private const string NAME_V4A = "4a";
        private const string NAME_V4B = "4b/5.1";
        private const string NAME_V4C = "4c";
        private const string NAME_V51 = "5.1";
        private const string NAME_V52 = "5.2";
        private const string NAME_V53 = "5.3";
        private const string NAME_V54 = "5.4";
        private const string NAME_V55 = "5.5";
        private const string NAME_V5 = "5";
        private const string NAME_V5Y = "A";
        private const string NAME_V5Z = "B";
        private const string NAME_VC = "C";

        private const string invTXT = "Inv ";
        private const string valTXT = "Val ";
        private const string trgTXT = "Lim ";
        private const string CorTXT = "Cor V";
        private const string ImpTXT = "Tgt V";
        #endregion
		
		SharpDX.Direct2D1.Brush fillbkgUp_DXBrush = null;
		SharpDX.Direct2D1.Brush fillbkgDown_DXBrush = null;
		SharpDX.Direct2D1.Brush StructureDialogBkg_UpDXBrush = null;
		SharpDX.Direct2D1.Brush StructureDialogBkg_DownDXBrush = null;
		SharpDX.Direct2D1.Brush StructureDialogText_UpDXBrush = null;
		SharpDX.Direct2D1.Brush StructureDialogText_DownDXBrush = null;
		SharpDX.Direct2D1.Brush iUpDXBrush = null;
		SharpDX.Direct2D1.Brush iDownDXBrush = null;
		SharpDX.Direct2D1.Brush iNeutralDXBrush = null;
        //--------------------- Virtuals --------------------
        //public override string DisplayName { get { return "ARC_Waves"; } }
        
        protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name		= "ARC_Waves";
				AddPlot(new Stroke(Brushes.Transparent, 1),          PlotStyle.Dot, "UpCount");
				AddPlot(new Stroke(Brushes.Transparent, 1),          PlotStyle.Dot, "DownCount");

                #region -- UI Settings --
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                MaximumBarsLookBack = NinjaTrader.NinjaScript.MaximumBarsLookBack.Infinite;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = true;
                #endregion

				SentimentDialogLoc            = ARC_Waves_SentimentDialogLoc.TopLeft;
				StructureDialogFont           = new SimpleFont("Arial",14);
				StructureDialogBkg_UpBrush    = Brushes.LimeGreen;
				StructureDialogBkg_DownBrush  = Brushes.Red;
				StructureDialogText_UpBrush   = Brushes.White;
				StructureDialogText_DownBrush = Brushes.White;
				StructureDialogBkg_UpOpacity   = 90;
				StructureDialogBkg_DownOpacity = 90;
				VerboseSentimentDialog = true;
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A";

                #region -- Input Settings --
                zoneFont = new SimpleFont("Arial", 12) { Bold = true };
                zoneAlpha = 50;
                displayImpZonesUp = true;
                displayCorZonesUp = true;
                displayZoneLabelsUp = true;
                ColZVRetUP = Brushes.DarkGreen;
                ColZVImpUP = Brushes.DarkGreen;
                displayImpZonesDw = true;
                displayCorZonesDw = true;
                displayZoneLabelsDw = true;
                ColZVRetDW = Brushes.DarkRed;
                ColZVImpDW = Brushes.DarkRed;

                ivlFont = new SimpleFont("Arial", 12) { Bold = true };
                ivlAlpha = 50;
                ilvThickness = 3;
                displayValidUp = true;
                displayLimitUp = true;
                displayInvalidUp = true;
                ColVLUP = Brushes.DarkGreen;
                ColTLUP = Brushes.DarkGreen;
                ColILUP = Brushes.DarkGreen;
                displayLineLabelsUp = true;
                displayValidDw = true;
                displayLimitDw = true;
                displayInvalidDw = true;
                ColVLDW = Brushes.DarkRed;
                ColTLDW = Brushes.DarkRed;
                ColILDW = Brushes.DarkRed;
                displayLineLabelsDw = true;

                countFont = new SimpleFont("Arial", 16) { Bold = true };
                ColDecUP = Brushes.DarkGreen;
                displayLastUp = false;
                displayHistUp = false;
                displayLabelsUp = false;
                ColDecDW = Brushes.DarkRed;
                displayLastDw = false;
                displayHistDw = false;
                displayLabelsDw = false;

                showZZ = true;
				showZZFlooding = false;
                zzwidth = 2;
                zzColor = Brushes.Black;
                pBkgUpColor = Brushes.Green;
                pBkgDownColor = Brushes.Maroon;
				pzzTrendBkgOpacity = 3;
				pShowSwingLabels = true;
                SwingLabelFont = new SimpleFont("Arial", 12);
				pTextOffset = 15;
				iUpBrush = Brushes.Lime;
				iDownBrush = Brushes.DarkRed;
				iNeutralBrush = Brushes.Silver;

//                SwingStrength = 3;
                useHL = true;
                #endregion
				pButtonText = "Waves";

                #region -- Ratios (input) --
                RetV2Max = 100;
                ExtVbMax = -12.8;
                RetVcMin = 100;
                ExtV3Min = 112.8;
                RetV4Max = 12.8;
                ExtV5Min = 61.8;

                ObjV2min = 50;
                ObjV2max = 61.8;
                ObjV3min = 161.8;
                ObjV3max = 200;
                ObjV4min = 23.6;
                ObjV4max = 44.7;
                ObjV5min = 61.8;
                ObjV5max = 86.6;
                #endregion
            }
            else if (State == State.Configure)
            {
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
                ElliottPivotDecUP = new List<ElliottPivot>();
                ElliottPivotDecDW = new List<ElliottPivot>();

                decompte = new Countdown[2];
            }
			else if (State == State.DataLoaded){
				// JQ 11/11/2017 - add a unique toolbar name fo reach instance
				// JQ - BUG #12621 - Problem with Waves toolbar not showing up in multiple tabs.
				uID = "Waves"+Instrument.MasterInstrument.Name+DateTime.Now.Ticks.ToString();

                upTrend    = new Series<bool>(this);
//                UpCount = new Series<double>(this);
//                DownCount = new Series<double>(this);

                pre_swingHighType  = new Series<int>(this);
                pre_swingLowType   = new Series<int>(this);
                swingHighType      = new Series<int>(this);
                swingLowType       = new Series<int>(this);
				StructureDirection = new Series<int>(this);
				
				#region from VMDivergences
                vavgTrueRange = ATR(256);
                vswingInput = new Series<double>(this);
                vpre_swingHighType = new Series<int>(this);
                vpre_swingLowType = new Series<int>(this);
                vswingHighType = new Series<int>(this);
                vswingLowType = new Series<int>(this);
                vupTrend = new Series<bool>(this);
                structureBiasState = new Series<double>(this, MaximumBarsLookBack.Infinite);//#STRBIAS

				#endregion
			}
            else if (State == State.Historical)
            {
                #region -- Add Custom Toolbar --
				   if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;
                        
                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

                            addToolBar();
                            
                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));

                #endregion
            }
            #region State == State.Terminated
            else if (State == State.Terminated)
            {
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
						indytoolbar = null;
						try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
							indytoolbar = null;
							try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
							chartWindow = null;
						}));
					}
				}
            }
            #endregion
        }
        
        protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			#region --- init ---
			if (CurrentBar < 2)
			{
				upTrend[0] = true;
				pre_swingHighType[0] = 0;
				pre_swingLowType[0] = 0;
				swingHighType[0] = 0;
				swingLowType[0] = 0;
				return;
			}
			#endregion

			UpCount[0] = UpCount[1];
			DownCount[0] = DownCount[1];

			#region --- Calculate ZigZag ---                
			swingMax = MAX(useHL ? High : Input, SwingStrength)[1];
			swingMin = MIN(useHL ? Low  : Input, SwingStrength)[1];

			pre_swingHighType[0] = 0;
			pre_swingLowType[0]  = 0;
			swingHighType[0] = 0;
			swingLowType[0]  = 0;

			updateHigh =  upTrend[1] && (useHL ? High[0]   : Input[0]) > currentHigh;
			updateLow  = !upTrend[1] && (useHL ? Low[0]    : Input[0]) < currentLow;
			addHigh    = !upTrend[1] && !((useHL ? Low[0]  : Input[0]) < currentLow)  && (useHL ? High[0] : Input[0]) > Math.Max(swingMax, currentLow);
			addLow     =  upTrend[1] && !((useHL ? High[0] : Input[0]) > currentHigh) && (useHL ? Low[0]  : Input[0]) < Math.Min(swingMin, currentHigh);

			upTrend[0] = upTrend[1];
			#endregion

            #region -- New High --
            if (addHigh)
            {
                //-- update zigzag H/L --
                upTrend[0] = true;
                int lookback = CurrentBar - lastLowIdx;
                swingLowType[lookback] = pre_swingLowType[lookback];
                double newHigh = double.MinValue;
                int j = 0;
                for (int i = 0; i < CurrentBar - lastLowIdx; i++)
                {
                    if ((useHL ? High[i] : Input[i]) > newHigh)
                    {
                        newHigh = (useHL ? High[i] : Input[i]);
                        j = i;
                    }
                }
				int SwingType = int.MinValue;
				if(ElliottPivotDecDW.Count>0){
					var h0 = High.GetValueAt(lastHighIdx);
					var h1 = High.GetValueAt(priorSwingHighIdx);
                    double vmarginUp   = h0 + MultiplierDTB * vavgTrueRange[0];
                    double vmarginDown = h0 - MultiplierDTB * vavgTrueRange[0];
					if(h1>=vmarginDown && h1<=vmarginUp) SwingType = DT_TYPE;
					else if(h0 > h1)  SwingType = HH_TYPE;
					else if(h0 < h1)  SwingType = LH_TYPE;
					ElliottPivotDecUP.Last().SwingType = SwingType;
					ElliottPivotDecDW.Last().SwingType = SwingType;
				}
// DT(99), DB(-99), HH(1) or LH{2), LL(-1), HL(-2}

                currentHigh       = newHigh;
                priorSwingHighIdx = lastHighIdx;
                lastHighIdx       = CurrentBar - j;
				if(ElliottPivotDecDW.Count>0){
					var L0 = Low.GetValueAt(lastLowIdx);
					var L1 = Low.GetValueAt(priorSwingLowIdx);
                    double vmarginUp = L0 + MultiplierDTB * vavgTrueRange[0];
                    double vmarginDown = L0 - MultiplierDTB * vavgTrueRange[0];
					if(L1>=vmarginDown && L1<=vmarginUp) SwingType = DB_TYPE;
					else if(L0 > L1) SwingType = HL_TYPE;
					else if(L0 < L1) SwingType = LL_TYPE;
				}
                //-- Manage Elliott countdown --
                Pivot px = new Pivot(CurrentBar, lastLowIdx, Bars.GetTime(lastLowIdx), currentLow, VALLEY, SwingType);
                ElliottPivotDecUP.Add(new ElliottPivot(px));
                ElliottPivotDecDW.Add(new ElliottPivot(px));
				StructureLowNodePrice = currentLow;
//Draw.Diamond(this,"ch"+CurrentBar.ToString(), false, 0, Lows[0].GetValueAt(priorSwingLowIdx), Brushes.Blue);
                if (decompte[(int)NSWavesCountSide.UP] == null) decompte[(int)NSWavesCountSide.UP] = new Countdown(px);
                else GestionDecompte(NSWavesCountSide.UP);
                if (decompte[(int)NSWavesCountSide.DOWN] != null) GestionDecompte(NSWavesCountSide.DOWN);
            }
            #endregion

            #region -- uptrend --
            else if (updateHigh)
            {
                upTrend[0] = true;
                pre_swingHighType[CurrentBar - lastHighIdx] = 0;
                currentHigh = (useHL ? High[0] : Input[0]);
                lastHighIdx = CurrentBar;
            }
            #endregion

			#region -- New Low --
			else if (addLow)
			{
				upTrend[0] = false;
				int lookback = CurrentBar - lastHighIdx;
				swingHighType[lookback] = pre_swingHighType[lookback];
				double newLow = double.MaxValue;
				int j = 0;
				for (int i = 0; i < CurrentBar - lastHighIdx; i++)
				{
                    if ((useHL ? Low[i] : Input[i]) < newLow)
                    {
                        newLow = (useHL ? Low[i] : Input[i]);
                        j = i;
                    }
				}
				int SwingType = int.MinValue;
				if(ElliottPivotDecDW.Count>0){
					var L0 = Low.GetValueAt(lastLowIdx);
					var L1 = Low.GetValueAt(priorSwingLowIdx);
                    double vmarginUp = L0 + MultiplierDTB * vavgTrueRange[0];
                    double vmarginDown = L0 - MultiplierDTB * vavgTrueRange[0];
					if(L1>=vmarginDown && L1<=vmarginUp) SwingType = DB_TYPE;
					else if(L0 > L1) SwingType = HL_TYPE;
					else if(L0 < L1) SwingType = LL_TYPE;
// DT(99), DB(-99), HH(1) or LH{2), LL(-1), LH(-2}
					ElliottPivotDecUP.Last().SwingType = SwingType;
					ElliottPivotDecDW.Last().SwingType = SwingType;
				}

				currentLow = newLow;
				priorSwingLowIdx = lastLowIdx;
				lastLowIdx = CurrentBar - j;
				if(ElliottPivotDecDW.Count>0){
					var h0 = High.GetValueAt(lastHighIdx);
					var h1 = High.GetValueAt(priorSwingHighIdx);
                    double vmarginUp   = h0 + MultiplierDTB * vavgTrueRange[0];
                    double vmarginDown = h0 - MultiplierDTB * vavgTrueRange[0];
					if(h1>=vmarginDown && h1<=vmarginUp) SwingType = DT_TYPE;
					else if(h0 > h1)  SwingType = HH_TYPE;
					else if(h0 < h1)  SwingType = LH_TYPE;
				}

				//-- Manage Elliott countdown --
				Pivot px = new Pivot(CurrentBar, lastHighIdx, Bars.GetTime(lastHighIdx), currentHigh, PEAK, SwingType);
				ElliottPivotDecUP.Add(new ElliottPivot(px));
				ElliottPivotDecDW.Add(new ElliottPivot(px));
				StructureHighNodePrice = currentHigh;
//Draw.Diamond(this,"cl"+CurrentBar.ToString(), false, 0, Highs[0].GetValueAt(priorSwingHighIdx), Brushes.Red);

				if (decompte[(int)NSWavesCountSide.DOWN] == null) decompte[(int)NSWavesCountSide.DOWN] = new Countdown(px);
				else GestionDecompte(NSWavesCountSide.DOWN);
				if (decompte[(int)NSWavesCountSide.UP] != null) GestionDecompte(NSWavesCountSide.UP);
            }
            #endregion

            #region -- dwtrend --
            else if (updateLow)
            {
                upTrend[0] = false;
                pre_swingLowType[CurrentBar - lastLowIdx] = 0;
                currentLow = (useHL ? Low[0] : Input[0]);
                lastLowIdx = CurrentBar;
            }
            #endregion

			if(Closes[0][0] > StructureHighNodePrice)     StructureDirection[0] = UP;
			else if(Closes[0][0] < StructureLowNodePrice) StructureDirection[0] = DOWN;
			else StructureDirection[0] = StructureDirection[1];

//            UpCount[0] = UpCount[0];
//            DwCount[0] = DownCount[0];
//================================================================
            #region --- Calculate VMDivergences ZigZag + Intrabar Structure BIAS ---

            #region -- Init zigzag states --    
            if (CurrentBar < 2)
            {
                vupTrend[0] = true;
                vpre_swingHighType[0] = 0;
                vpre_swingLowType[0] = 0;
                vswingHighType[0] = 0;
                vswingLowType[0] = 0;
            }
            #endregion

            #region else if (Calculate == Calculate.OnBarClose)
            else if (Calculate == Calculate.OnBarClose)
            {
                vzigzagDeviation = MultiplierMD * vavgTrueRange[0];
                vswingMax = MAX(useHL ? High : Input, SwingStrength)[1];
                vswingMin = MIN(useHL ? Low : Input, SwingStrength)[1];
//Print(vzigzagDeviation+"   atr: "+vavgTrueRange[0]);
//Draw.Dot(this,"mup"+CurrentBars[0].ToString(), false, 0, vswingMax, Brushes.Red);
//Draw.Diamond(this,"mdn"+CurrentBars[0].ToString(), false, 0, vswingMin, Brushes.Blue);

                vpre_swingHighType[0] = 0;
                vpre_swingLowType[0] = 0;
                vswingHighType[0] = 0;
                vswingLowType[0] = 0;

                vupdateHigh = vupTrend[1] && (useHL ? High[0] : vswingInput[0]) > vcurrentHigh;
                vupdateLow = !vupTrend[1] && (useHL ? Low[0] : vswingInput[0]) < vcurrentLow;
                vaddHigh = !vupTrend[1] && !((useHL ? Low[0] : vswingInput[0]) < vcurrentLow) && (useHL ? High[0] : vswingInput[0]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
                vaddLow = vupTrend[1] && !((useHL ? High[0] : vswingInput[0]) > vcurrentHigh) && (useHL ? Low[0] : vswingInput[0]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

                vupTrend[0] = vupTrend[1];

                #region -- New High --
                if (vaddHigh)
                {
                    vupTrend[0] = true;
                    int lookback = CurrentBar - vlastLowIdx;
                    vswingLowType[lookback] = vpre_swingLowType[lookback];
                    double vnewHigh = double.MinValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - vlastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : vswingInput[i]) > vnewHigh)
                        {
                            vnewHigh = (useHL ? High[i] : vswingInput[i]);
                            j = i;
                        }
                    }

                    vcurrentHigh = vnewHigh;
                    vpriorSwingHighIdx = vlastHighIdx;
                    vlastHighIdx = CurrentBar - j;
                }
                #endregion

                #region -- uptrend --
                else if (vupdateHigh)
                {
                    vupTrend[0] = true;
//                    if (ShowZigzagDots) RemoveDrawObject("swingHighDot" + lastHighIdx);
//                    if (ShowZigzagLabels) RemoveDrawObject("swingHighLabel" + lastHighIdx);
//                    if (ShowZigzagLegs) RemoveDrawObject("swingLegUp" + lastHighIdx);
                    vpre_swingHighType[CurrentBar - vlastHighIdx] = 0;
                    vcurrentHigh = (useHL ? High[0] : vswingInput[0]);
                    vlastHighIdx = CurrentBar;
                }
                #endregion

                #region -- New Low --
                else if (vaddLow)
                {
                    vupTrend[0] = false;
                    int lookback = CurrentBar - vlastHighIdx;
                    vswingHighType[lookback] = vpre_swingHighType[lookback];
                    double vnewLow = double.MaxValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - vlastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : vswingInput[i]) < vnewLow)
                        {
                            vnewLow = (useHL ? Low[i] : vswingInput[i]);
                            j = i;
                        }
                    }
                    vcurrentLow = vnewLow;
                    vpriorSwingLowIdx = vlastLowIdx;
                    vlastLowIdx = CurrentBar - j;
                }
                #endregion

                #region -- dwtrend --
                else if (vupdateLow)
                {
                    vupTrend[0] = false;
//                    if (ShowZigzagDots) RemoveDrawObject("swingLowDot" + lastLowIdx);
//                    if (ShowZigzagLabels) RemoveDrawObject("swingLowLabel" + lastLowIdx);
//                    if (ShowZigzagLegs) RemoveDrawObject("swingLegDown" + lastLowIdx);
                    vpre_swingLowType[CurrentBar - vlastLowIdx] = 0;
                    vcurrentLow = (useHL ? Low[0] : vswingInput[0]);
                    vlastLowIdx = CurrentBar;
                }
                #endregion

                #region re-init drawing states at each new bar before calculous
//                if (ShowZigzagDots)
//                {
//                    drawHigherHighDot = false;
//                    drawLowerHighDot = false;
//                    drawDoubleTopDot = false;
//                    drawLowerLowDot = false;
//                    drawHigherLowDot = false;
//                    drawDoubleBottomDot = false;
//                }

                vdrawHigherHighLabel = false;
                vdrawLowerHighLabel = false;
                vdrawDoubleTopLabel = false;
                vdrawLowerLowLabel = false;
                vdrawHigherLowLabel = false;
                vdrawDoubleBottomLabel = false;
                
//                if (ShowZigzagLegs)
//                {
//                    drawSwingLegUp = false;
//                    drawSwingLegDown = false;
//                }
                #endregion

                #region -- UP || HH --
                if (vaddHigh || vupdateHigh)
                {
                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
                    vhighCount = CurrentBar - vlastHighIdx;
                    vlowCount = CurrentBar - vlastLowIdx;

                    double vmarginUp = (useHL ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) + MultiplierDTB * vavgTrueRange[vhighCount];
                    double vmarginDown = (useHL ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) - MultiplierDTB * vavgTrueRange[vhighCount];

                    // new code goes here
//                    #region -- Calculate acceleration on BBMACD and Histo --
//                    if (currentHigh > High[priorHighCount] && (BBMACD[highCount] > 0 && BBMACD[0] > 0) && BBMACD[highCount] > BBMACD[priorHighCount])
//                        acceleration1[0] = 2;
//                    else if (currentHigh <= High[priorHighCount] && (BBMACD[highCount] > 0 && BBMACD[0] > 0) && acceleration1[lowCount] == 1)
//                        acceleration1[0] = 1;
//                    else if (currentHigh <= High[priorHighCount] && (BBMACD[highCount] < 0 && BBMACD[0] < 0) && acceleration1[lowCount] == -2)
//                        acceleration1[0] = -1;
//                    else
//                        acceleration1[0] = 0;
//                    if (currentHigh > High[priorHighCount] && Histogram[highCount] > 0 && Histogram[0] > 0 && Histogram[highCount] > Histogram[priorHighCount])
//                        acceleration2[0] = 2;
//                    else if (currentHigh <= High[priorHighCount] && Histogram[highCount] > 0 && Histogram[0] > 0 && acceleration2[lowCount] == 1)
//                        acceleration2[0] = 1;
//                    else if (currentHigh <= High[priorHighCount] && Histogram[highCount] < 0 && Histogram[0] < 0 && acceleration2[lowCount] == -2)
//                        acceleration2[0] = -1;
//                    else
//                        acceleration2[0] = 0;
                    #endregion
                    // end new code

                    #region -- Set NEW drawing states --
//                    if (ShowZigzagDots)
//                    {
//                        if (currentHigh > marginUp)
//                            drawHigherHighDot = true;
//                        else if (currentHigh < marginDown)
//                            drawLowerHighDot = true;
//                        else
//                            drawDoubleTopDot = true;
//                    }

                    if (vcurrentHigh > vmarginUp) vdrawHigherHighLabel = true;
                    else if (vcurrentHigh < vmarginDown) vdrawLowerHighLabel = true;
                    else vdrawDoubleTopLabel = true;

//                    if (ShowZigzagLegs)
//                        drawSwingLegUp = true;
                    if (vcurrentHigh > vmarginUp)
                        vpre_swingHighType[vhighCount] = 3;
                    else if (vcurrentHigh < vmarginDown)
                        vpre_swingHighType[vhighCount] = 1;
                    else
                        vpre_swingHighType[vhighCount] = 2;
                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (vaddLow || vupdateLow)
                {
                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
                    vlowCount = CurrentBar - vlastLowIdx;
                    vhighCount = CurrentBar - vlastHighIdx;

					double vmarginDown = (useHL ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) - MultiplierDTB * vavgTrueRange[vlowCount];
                    double vmarginUp = (useHL ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) + MultiplierDTB * vavgTrueRange[vlowCount];

                    #region -- Calculate acceleration on BBMACD and Histo --
//                    if (currentLow < Low[priorLowCount] && (BBMACD[lowCount] < 0 && BBMACD[0] < 0) && BBMACD[lowCount] < BBMACD[priorLowCount])
//                        acceleration1[0] = -2;
//                    else if (currentLow >= Low[priorLowCount] && (BBMACD[lowCount] < 0 && BBMACD[0] < 0) && acceleration1[highCount] == -1)
//                        acceleration1[0] = -1;
//                    else if (currentLow >= Low[priorLowCount] && (BBMACD[lowCount] > 0 && BBMACD[0] > 0) && acceleration1[highCount] == 2)
//                        acceleration1[0] = 1;
//                    else
//                        acceleration1[0] = 0;
//                    if (currentLow < Low[priorLowCount] && Histogram[lowCount] < 0 && Histogram[0] < 0 && Histogram[lowCount] < Histogram[priorLowCount])
//                        acceleration2[0] = -2;
//                    else if (currentLow >= Low[priorLowCount] && Histogram[lowCount] < 0 && Histogram[0] < 0 && acceleration2[highCount] == -1)
//                        acceleration2[0] = -1;
//                    else if (currentLow >= Low[priorLowCount] && Histogram[lowCount] > 0 && Histogram[0] > 0 && acceleration2[highCount] == 2)
//                        acceleration2[0] = 1;
//                    else
//                        acceleration2[0] = 0;
                    #endregion

                    #region -- Set NEW drawing states --
//                    if (ShowZigzagDots)
//                    {
//                        if (currentLow < marginDown)
//                            drawLowerLowDot = true;
//                        else if (currentLow > marginUp)
//                            drawHigherLowDot = true;
//                        else
//                            drawDoubleBottomDot = true;
//                    }

                    if (vcurrentLow < vmarginDown) vdrawLowerLowLabel = true;
                    else if (vcurrentLow > vmarginUp) vdrawHigherLowLabel = true;
                    else vdrawDoubleBottomLabel = true;
                    
//                    if (ShowZigzagLegs)
//                        drawSwingLegDown = true;
                    if (vcurrentLow < vmarginDown)
                        vpre_swingLowType[vlowCount] = -3;
                    else if (vcurrentLow > vmarginUp)
                        vpre_swingLowType[vlowCount] = -1;
                    else
                        vpre_swingLowType[vlowCount] = -2;
                    #endregion
                }
                #endregion

                //Is it possible ??
                else
                {
//                    if ((acceleration1[1] > 0 && BBMACD[0] > 0) || (acceleration1[1] < 0 && BBMACD[0] < 0))
//                        acceleration1[0] = acceleration1[1];
//                    else
//                        acceleration1[0] = 0;
//                    if ((acceleration2[1] > 0 && Histogram[0] > 0) || (acceleration2[1] < 0 && Histogram[0] < 0))
//                        acceleration2[0] = acceleration2[1];
//                    else
//                        acceleration2[0] = 0;
                }
            }
            #endregion

            #region else if (IsFirstTickOfBar)
            else if (IsFirstTickOfBar)
            {
                vzigzagDeviation = MultiplierMD * vavgTrueRange[1];
                vswingMax = MAX(useHL ? High : Input, SwingStrength)[2];
                vswingMin = MIN(useHL ? Low : Input, SwingStrength)[2];

                vpre_swingHighType[0] = 0;
                vpre_swingLowType[0]  = 0;
                vswingHighType[0]     = 0;
                vswingLowType[0]      = 0;

                vupdateHigh = vupTrend[1] && (useHL ? High[1] : vswingInput[1]) > vcurrentHigh;
                vupdateLow  = !vupTrend[1] && (useHL ? Low[1] : vswingInput[1]) < vcurrentLow;
                vaddHigh    = !vupTrend[1] && !((useHL ? Low[1] : vswingInput[1]) < vcurrentLow) && (useHL ? High[1] : vswingInput[1]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
                vaddLow     = vupTrend[1] && !((useHL ? High[1] : vswingInput[1]) > vcurrentHigh) && (useHL ? Low[1] : vswingInput[1]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

                vupTrend[0] = vupTrend[1];

                #region -- New High --
                if (vaddHigh)
                {
                    vupTrend[0] = true;
                    int lookback = CurrentBar - vlastLowIdx;
                    vswingLowType[lookback] = vpre_swingLowType[lookback];
                    double vnewHigh = double.MinValue;
                    int j = 0;
                    for (int i = 1; i < CurrentBar - vlastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : vswingInput[i]) > vnewHigh)
                        {
                            vnewHigh = (useHL ? High[i] : vswingInput[i]);
                            j = i;
                        }
                    }
                    vcurrentHigh = vnewHigh;
                    vpriorSwingHighIdx = vlastHighIdx;
                    vlastHighIdx = CurrentBar - j;
                }
                #endregion

                #region -- UPtrend --
                else if (vupdateHigh)
                {
                    vupTrend[0] = true;
//                    if (ShowZigzagDots)
//                        RemoveDrawObject("swingHighDot" + lastHighIdx);
//                    if (ShowZigzagLabels)
//                        RemoveDrawObject("swingHighLabel" + lastHighIdx);
//                    if (ShowZigzagLegs)
//                        RemoveDrawObject("swingLegUp" + lastHighIdx);
                    vpre_swingHighType[CurrentBar - vlastHighIdx] = 0;
                    vcurrentHigh = (useHL ? High[1] : vswingInput[1]);
                    vlastHighIdx = CurrentBar - 1;
                }
                #endregion

                #region -- New Low --
                else if (vaddLow)
                {
                    vupTrend[0] = false;
                    int lookback = CurrentBar - vlastHighIdx;
                    vswingHighType[lookback] = vpre_swingHighType[lookback];
                    double vnewLow = double.MaxValue;
                    int j = 0;
                    for (int i = 1; i < CurrentBar - vlastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : vswingInput[i]) < vnewLow)
                        {
                            vnewLow = (useHL ? Low[i] : vswingInput[i]);
                            j = i;
                        }
                    }
                    vcurrentLow = vnewLow;
                    vpriorSwingLowIdx = vlastLowIdx;
                    vlastLowIdx = CurrentBar - j;
                }
                #endregion

                #region -- DWtrend --
                else if (updateLow)
                {
                    vupTrend[0] = false;
//                    if (ShowZigzagDots)
//                        RemoveDrawObject("swingLowDot" + lastLowIdx);
//                    if (ShowZigzagLabels)
//                        RemoveDrawObject("swingLowLabel" + lastLowIdx);
//                    if (ShowZigzagLegs)
//                        RemoveDrawObject("swingLegDown" + lastLowIdx);
                    vpre_swingLowType[CurrentBar - vlastLowIdx] = 0;
                    vcurrentLow = useHL ? Low[1] : vswingInput[1];
                    vlastLowIdx = CurrentBar - 1;
                }
                #endregion

                #region re-init drawing states at each new bar before calculous
//                if (ShowZigzagDots)
//                {
//                    drawHigherHighDot = false;
//                    drawLowerHighDot = false;
//                    drawDoubleTopDot = false;
//                    drawLowerLowDot = false;
//                    drawHigherLowDot = false;
//                    drawDoubleBottomDot = false;
//                }

                vdrawHigherHighLabel = false;
                vdrawLowerHighLabel = false;
                vdrawDoubleTopLabel = false;
                vdrawLowerLowLabel = false;
                vdrawHigherLowLabel = false;
                vdrawDoubleBottomLabel = false;

//                if (ShowZigzagLegs)
//                {
//                    drawSwingLegUp = false;
//                    drawSwingLegDown = false;
//                }
                #endregion

                #region -- UP || HH --
                if (vaddHigh || vupdateHigh)
                {
                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
                    vhighCount = CurrentBar - vlastHighIdx;
                    vlowCount = CurrentBar - vlastLowIdx;

                    double vmarginUp = (useHL ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) + MultiplierDTB * vavgTrueRange[vhighCount];
                    double vmarginDown = (useHL ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) - MultiplierDTB * vavgTrueRange[vhighCount];

                    #region -- Set NEW drawing states --
//                    if (ShowZigzagDots)
//                    {
//                        if (currentHigh > marginUp)
//                            drawHigherHighDot = true;
//                        else if (currentHigh < marginDown)
//                            drawLowerHighDot = true;
//                        else
//                            drawDoubleTopDot = true;
//                    }

                    if (vcurrentHigh > vmarginUp) vdrawHigherHighLabel = true;
                    else if (vcurrentHigh < vmarginDown) vdrawLowerHighLabel = true;
                    else vdrawDoubleTopLabel = true;
                    
//                    if (ShowZigzagLegs)
//                        drawSwingLegUp = true;
                    if (vcurrentHigh > vmarginUp)
                        vpre_swingHighType[vhighCount] = 3;
                    else if (currentHigh < vmarginDown)
                        vpre_swingHighType[vhighCount] = 1;
                    else
                        vpre_swingHighType[vhighCount] = 2;
                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (vaddLow || vupdateLow)
                {
                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
                    vlowCount  = CurrentBar - vlastLowIdx;
                    vhighCount = CurrentBar - vlastHighIdx;

                    double vmarginDown = (useHL ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) - MultiplierDTB * vavgTrueRange[vlowCount];
                    double vmarginUp   = (useHL ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) + MultiplierDTB * vavgTrueRange[vlowCount];

                    #region -- Set NEW drawing states --
//                    if (ShowZigzagDots)
//                    {
//                        if (currentLow < marginDown)
//                            drawLowerLowDot = true;
//                        else if (currentLow > marginUp)
//                            drawHigherLowDot = true;
//                        else
//                            drawDoubleBottomDot = true;
//                    }

                    if (vcurrentLow < vmarginDown) vdrawLowerLowLabel = true;
                    else if (vcurrentLow > vmarginUp) vdrawHigherLowLabel = true;
                    else vdrawDoubleBottomLabel = true;
                    
//                    if (ShowZigzagLegs)
//                        drawSwingLegDown = true;
                    if (vcurrentLow < vmarginDown)
                        vpre_swingLowType[vlowCount] = -3;
                    else if (vcurrentLow > vmarginUp)
                        vpre_swingLowType[vlowCount] = -1;
                    else
                        vpre_swingLowType[vlowCount] = -2;
                    #endregion
                }
                #endregion
            }
            #endregion

            #region if (Calculate != Calculate.OnBarClose)
            if (Calculate != Calculate.OnBarClose)
            {
                vintraBarUpdateHigh = vupTrend[0] && (useHL ? High[0] : vswingInput[0]) > vcurrentHigh;
                vintraBarUpdateLow  = !vupTrend[0] && (useHL ? Low[0] : vswingInput[0]) < vcurrentLow;
                vintraBarAddHigh    = !vupTrend[0] && !((useHL ? Low[0] : vswingInput[0]) < vcurrentLow) && (useHL ? High[0] : vswingInput[0]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
                vintraBarAddLow     = vupTrend[0] && !((useHL ? High[0] : vswingInput[0]) > vcurrentHigh) && (useHL ? Low[0] : vswingInput[0]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

                #region -- new HH --
                if (vintraBarAddHigh)
                {
                    double vnewHigh = double.MinValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - vlastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : vswingInput[i]) > vnewHigh)
                        {
                            vnewHigh = (useHL ? High[i] : vswingInput[i]);
                            j = i;
                        }
                    }
                    vpreCurrentHigh = vnewHigh;
                    vpreLastHighIdx = CurrentBar - j;
                }
                #endregion

                #region -- uptrend --
                else if (vintraBarUpdateHigh)
                {
                    vpreCurrentHigh = (useHL ? High[0] : vswingInput[0]);
                    vpreLastHighIdx = CurrentBar;
                }
                #endregion

                #region -- new LL --
                if (vintraBarAddLow)
                {
                    double vnewLow = double.MaxValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - vlastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : vswingInput[i]) < vnewLow)
                        {
                            vnewLow = useHL ? Low[i] : vswingInput[i];
                            j = i;
                        }
                    }
                    vpreCurrentLow = vnewLow;
                    vpreLastLowIdx = CurrentBar - j;
                }
                #endregion

                #region -- dwtrend --
                else if (vintraBarUpdateLow)
                {
                    vpreCurrentLow = (useHL ? Low[0] : vswingInput[0]);
                    vpreLastLowIdx = CurrentBar;
                }
                #endregion

                #region -- UP || HH --
                if (vintraBarAddHigh || vintraBarUpdateHigh)
                {
                    int vprePriorHighCount = vintraBarAddHigh ? CurrentBar - vlastHighIdx : CurrentBar - vpriorSwingHighIdx;
                    int vpreHighCount = CurrentBar - vpreLastHighIdx;
                    int vprePriorLowCount = CurrentBar - vpriorSwingLowIdx;
                    int vpreLowCount = CurrentBar - vlastLowIdx;

                    #region -- Calculate acceleration on BBMACD and Histo --
//                    if (preCurrentHigh > High[prePriorHighCount] && (BBMACD[preHighCount] > 0 && BBMACD[0] > 0) && BBMACD[preHighCount] > BBMACD[prePriorHighCount])
//                        acceleration1[0] = 2;
//                    else if (preCurrentHigh <= High[prePriorHighCount] && (BBMACD[preHighCount] > 0 && BBMACD[0] > 0) && acceleration1[preLowCount] == 1)
//                        acceleration1[0] = 1;
//                    else if (preCurrentHigh <= High[prePriorHighCount] && (BBMACD[preHighCount] < 0 && BBMACD[0] < 0) && acceleration1[preLowCount] == -2)
//                        acceleration1[0] = -1;
//                    else
//                        acceleration1[0] = 0;
//                    if (preCurrentHigh > High[prePriorHighCount] && Histogram[preHighCount] > 0 && Histogram[0] > 0 && Histogram[preHighCount] > Histogram[prePriorHighCount])
//                        acceleration2[0] = 2;
//                    else if (preCurrentHigh <= High[prePriorHighCount] && Histogram[preHighCount] > 0 && Histogram[0] > 0 && acceleration2[preLowCount] == 1)
//                        acceleration2[0] = 1;
//                    else if (preCurrentHigh <= High[prePriorHighCount] && Histogram[preHighCount] < 0 && Histogram[0] < 0 && acceleration2[preLowCount] == -2)
//                        acceleration2[0] = -1;
//                    else
//                        acceleration2[0] = 0;
                    #endregion

                    #region ---- StructureBias RealTime ---
                    double vmarginUp, vmarginDown;
                    if (useHL)//ThisInputType == NSVMDivInputType.High_Low)
                    {
                        vmarginUp   = High[vprePriorHighCount] + MultiplierDTB * vavgTrueRange[vpreHighCount];
                        vmarginDown = High[vprePriorHighCount] - MultiplierDTB * vavgTrueRange[vpreHighCount];
                    }
                    else
                    {
                        vmarginUp   = vswingInput[vprePriorHighCount] + MultiplierDTB * vavgTrueRange[vpreHighCount];
                        vmarginDown = vswingInput[vprePriorHighCount] - MultiplierDTB * vavgTrueRange[vpreHighCount];
                    }

                    if (vpreCurrentHigh > vmarginUp) preSRType = 3;//#STRBIAS
                    else if (vpreCurrentHigh < vmarginDown) preSRType = Math.Max(preSRType, 2);//#STRBIAS
                    else preSRType = Math.Max(preSRType, 1);//#STRBIAS
                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (vintraBarAddLow || vintraBarUpdateLow)
                {
                    int vprePriorLowCount  = vintraBarAddLow ? CurrentBar - vlastLowIdx : CurrentBar - vpriorSwingLowIdx;
                    int vpreLowCount       = CurrentBar - vpreLastLowIdx;
                    int vprePriorHighCount = CurrentBar - vpriorSwingHighIdx;
                    int vpreHighCount      = CurrentBar - vlastHighIdx;

                    #region -- Calculate acceleration on BBMACD and Histo --
//                    if (preCurrentLow < Low[prePriorLowCount] && (BBMACD[preLowCount] < 0 && BBMACD[0] < 0) && BBMACD[preLowCount] < BBMACD[prePriorLowCount])
//                        acceleration1[0] = -2;
//                    else if (preCurrentLow >= Low[prePriorLowCount] && (BBMACD[preLowCount] < 0 && BBMACD[0] < 0) && acceleration1[preHighCount] == -1)
//                        acceleration1[0] = -1;
//                    else if (preCurrentLow >= Low[prePriorLowCount] && (BBMACD[preLowCount] > 0 && BBMACD[0] > 0) && acceleration1[preHighCount] == 2)
//                        acceleration1[0] = 1;
//                    else
//                        acceleration1[0] = 0;
//                    if (preCurrentLow < Low[prePriorLowCount] && Histogram[preLowCount] < 0 && Histogram[0] < 0 && Histogram[preLowCount] < Histogram[prePriorLowCount])
//                        acceleration2[0] = -2;
//                    else if (preCurrentLow >= Low[prePriorLowCount] && Histogram[preLowCount] < 0 && Histogram[0] < 0 && acceleration2[preHighCount] == -1)
//                        acceleration2[0] = -1;
//                    else if (preCurrentLow >= Low[prePriorLowCount] && Histogram[preLowCount] > 0 && Histogram[0] > 0 && acceleration2[preHighCount] == 2)
//                        acceleration2[0] = 1;
//                    else
//                        acceleration2[0] = 0;
                    #endregion

                    #region ---- StructureBias RealTime ---
                    double vmarginUp, vmarginDown;
                    if (useHL)//ThisInputType == NSVMDivInputType.High_Low)
                    {
                        vmarginDown = Low[vprePriorLowCount] - MultiplierDTB * vavgTrueRange[vpreLowCount];
                        vmarginUp = Low[vprePriorLowCount] + MultiplierDTB * vavgTrueRange[vpreLowCount];
                    }
                    else
                    {
                        vmarginDown = vswingInput[vprePriorLowCount] - MultiplierDTB * vavgTrueRange[vpreLowCount];
                        vmarginUp = vswingInput[vprePriorLowCount] + MultiplierDTB * vavgTrueRange[vpreLowCount];
                    }
                    if (vpreCurrentLow < vmarginDown) preSRType = -3;//#STRBIAS
                    else if (vpreCurrentLow > vmarginUp) preSRType = Math.Min(preSRType, -2);//#STRBIAS
                    else preSRType = Math.Min(preSRType, -1);//#STRBIAS
                    #endregion
                }
                #endregion

                //Is it possible ??
                else
                {
//                    if ((acceleration1[1] > 0 && BBMACD[0] > 0) || (acceleration1[1] < 0 && BBMACD[0] < 0))
//                        acceleration1[0] = acceleration1[1];
//                    else
//                        acceleration1[0] = 0;
//                    if ((acceleration2[1] > 0 && Histogram[0] > 0) || (acceleration2[1] < 0 && Histogram[0] < 0))
//                        acceleration2[0] = acceleration2[1];
//                    else
//                        acceleration2[0] = 0;

                    preSRType = 0;//#STRBIAS
                }
                #region ---- StructureBias RealTime ---
                if (CurrentBar < 2) structureBiasState[0] = FLAT;
                else
                {
                    if (preSRType == 0) structureBiasState[0] = structureBiasState[1];

                    #region -- Oscillation State --
                    else if (structureBiasState[1] == FLAT)
                    {
                        //Oscillation State
                        //Need HH/!LL/HH to go to Up Trend
                        //{NEW} !LL/High/!LL/HH to go to Up Trend
                        //Need LL/!HH/LL to go to Dw Trend
                        //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
                        if (sequence.Count < 2) structureBiasState[0] = FLAT;
                        else if (sequence.Count < 3)
                        {
                            if (sequence[0] == 3 && sequence[1] != -3 && preSRType == 3) structureBiasState[0] = UP;
                            else if (sequence[0] == -3 && sequence[1] != 3 && preSRType == -3) structureBiasState[0] = DOWN;
                            else structureBiasState[0] = FLAT;
                        }
                        else
                        {
                            if (sequence[1] == 3 && sequence[2] != -3 && preSRType == 3) structureBiasState[0] = UP;
                            else if (sequence[1] == -3 && sequence[2] != 3 && preSRType == -3) structureBiasState[0] = DOWN;
                            //{NEW} HL/LH/HL/HH to go to Up Trend
                            else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && preSRType == 3) structureBiasState[0] = UP;
                            //{NEW} LH/HL/LH/LL to go to Up Trend
                            else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && preSRType == -3) structureBiasState[0] = DOWN;
                            else structureBiasState[0] = FLAT;
                        }
                    }
                    #endregion

                    #region -- UpTrend State --
                    else if (structureBiasState[1] > FLAT)
                    {
                        //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
                        if (preSRType == -3) structureBiasState[0] = FLAT;
                        else structureBiasState[0] = UP;
                    }
                    #endregion

                    #region -- DwTrend State --
                    else if (structureBiasState[1] < FLAT)
                    {
                        //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
                        if (preSRType == 3) structureBiasState[0] = FLAT;
                        else structureBiasState[0] = DOWN;
                    }
                    #endregion

                    else structureBiasState[0] = structureBiasState[1];
                }
                #endregion
            }
            #endregion

//Draw.Dot(this,"prehigh"+CurrentBar.ToString(), false,0,vpreCurrentHigh, Brushes.Red);
//Draw.Dot(this,"prelow"+CurrentBar.ToString(), false,0,vpreCurrentLow, Brushes.Green);
//            if (Calculate == Calculate.OnBarClose || IsFirstTickOfBar)
//            {
//                DrawOnPricePanel = true;
                #region -- Draw zigzag using chart objects --    
//                if (ShowZigzagDots && ThisInputType == NSVMDivInputType.High_Low)
//                {
//                    if (drawHigherHighDot)
//                        Draw.Text(this, "swingHighDot" + lastHighIdx, true, dotString, highCount, High[highCount], SwingDotSize / 2, upColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawLowerHighDot)
//                        Draw.Text(this, "swingHighDot" + lastHighIdx, true, dotString, highCount, High[highCount], SwingDotSize / 2, downColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawDoubleTopDot)
//                        Draw.Text(this, "swingHighDot" + lastHighIdx, true, dotString, highCount, High[highCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    if (drawLowerLowDot)
//                        Draw.Text(this, "swingLowDot" + lastLowIdx, true, dotString, lowCount, Low[lowCount], SwingDotSize / 2, downColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawHigherLowDot)
//                        Draw.Text(this, "swingLowDot" + lastLowIdx, true, dotString, lowCount, Low[lowCount], SwingDotSize / 2, upColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawDoubleBottomDot)
//                        Draw.Text(this, "swingLowDot" + lastLowIdx, true, dotString, lowCount, Low[lowCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                }
//                else if (ShowZigzagDots)
//                {
//                    if (drawHigherHighDot)
//                        Draw.Text(this, "swingHighDot" + lastHighIdx, true, dotString, highCount, swingInput[highCount], SwingDotSize / 2, upColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawLowerHighDot)
//                        Draw.Text(this, "swingHighDot" + lastHighIdx, true, dotString, highCount, swingInput[highCount], SwingDotSize / 2, downColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawDoubleTopDot)
//                        Draw.Text(this, "swingHighDot" + lastHighIdx, true, dotString, highCount, swingInput[highCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    if (drawLowerLowDot)
//                        Draw.Text(this, "swingLowDot" + lastLowIdx, true, dotString, lowCount, swingInput[lowCount], SwingDotSize / 2, downColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawHigherLowDot)
//                        Draw.Text(this, "swingLowDot" + lastLowIdx, true, dotString, lowCount, swingInput[lowCount], SwingDotSize / 2, upColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawDoubleBottomDot)
//                        Draw.Text(this, "swingLowDot" + lastLowIdx, true, dotString, lowCount, swingInput[lowCount], SwingDotSize / 2, doubleTopBottomColor, swingDotFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                }
//                if (ShowZigzagLabels)
//                {
//                    if (drawHigherHighLabel)
//                        Draw.Text(this, "swingHighLabel" + lastHighIdx, true, "HH", highCount, High[highCount], (int)(labelFont.Size) + pixelOffset1, upColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawLowerHighLabel)
//                        Draw.Text(this, "swingHighLabel" + lastHighIdx, true, "LH", highCount, High[highCount], (int)(labelFont.Size) + pixelOffset1, downColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawDoubleTopLabel)
//                        Draw.Text(this, "swingHighLabel" + lastHighIdx, true, "DT", highCount, High[highCount], (int)(labelFont.Size) + pixelOffset1, doubleTopBottomColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    if (drawLowerLowLabel)
//                        Draw.Text(this, "swingLowLabel" + lastLowIdx, true, "LL", lowCount, Low[lowCount], -(int)(labelFont.Size) - pixelOffset2, downColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawHigherLowLabel)
//                        Draw.Text(this, "swingLowLabel" + lastLowIdx, true, "HL", lowCount, Low[lowCount], -(int)(labelFont.Size) - pixelOffset2, upColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                    else if (drawDoubleBottomLabel)
//                        Draw.Text(this, "swingLowLabel" + lastLowIdx, true, "DB", lowCount, Low[lowCount], -(int)(labelFont.Size) - pixelOffset2, doubleTopBottomColor, labelFont, textAlignmentCenter, Brushes.Transparent, Brushes.Transparent, 0);
//                }
//                if (ShowZigzagLegs && ThisInputType == NSVMDivInputType.High_Low)
//                {
//                    if (drawSwingLegUp)
//                        Draw.Line(this, "swingLegUp" + lastHighIdx, false, lowCount, Low[lowCount], highCount, High[highCount], upColor, SwingLegStyle, SwingLegWidth);
//                    if (drawSwingLegDown)
//                        Draw.Line(this, "swingLegDown" + lastLowIdx, false, highCount, High[highCount], lowCount, Low[lowCount], downColor, SwingLegStyle, SwingLegWidth);
//                }
//                else if (ShowZigzagLegs)
//                {
//                    if (drawSwingLegUp)
//                        Draw.Line(this, "swingLegUp" + lastHighIdx, false, lowCount, swingInput[lowCount], highCount, swingInput[highCount], upColor, SwingLegStyle, SwingLegWidth);
//                    if (drawSwingLegDown)
//                        Draw.Line(this, "swingLegDown" + lastLowIdx, false, highCount, swingInput[highCount], lowCount, swingInput[lowCount], downColor, SwingLegStyle, SwingLegWidth);
//                }
                #endregion
//            }

           // #endregion
            #region -- Structure BIAS --

            SRType = vdrawHigherHighLabel ? 3 : vdrawLowerHighLabel ? 2 : vdrawDoubleTopLabel ? 1 : vdrawDoubleBottomLabel ? -1 : vdrawHigherLowLabel ? -2 : vdrawLowerLowLabel ? -3 : 0;
//            swingHighsState[0] = vdrawHigherHighLabel ? 3 : vdrawLowerHighLabel ? 2 : vdrawDoubleTopLabel ? 1 : 0;//#SWINGS for BH
//            swingLowsState[0] = vdrawDoubleBottomLabel ? -1 : vdrawHigherLowLabel ? -2 : vdrawLowerLowLabel ? -3 : 0;//#SWINGS for BH	

            #region -- Oscillation State --
            int decay = 0;
            if (Calculate!= Calculate.OnBarClose && State!=State.Historical) decay = 1;
            if (SRType != 0 && structureBiasState[decay + 1] == FLAT)
            {
                #region -- update sequence ---
                //--- Same Trend --
                if (vupTrend[1] == vupTrend[0])
                {
                    if (sequence.Count == 0) sequence.Add(SRType);
                    else sequence[sequence.Count - 1] = SRType;
                }

                //--- Changing Trend ---
                else if (Calculate == Calculate.OnBarClose && upTrend[1] != upTrend[0])
                {
                    if (sequence.Count < 4) sequence.Add(SRType);
                    else
                    {
                        sequence[0] = sequence[1];
                        sequence[1] = sequence[2];
                        sequence[2] = sequence[3];
                        sequence[3] = SRType;
                    }
                }
                #region -- eachtick --
                else if (Calculate != Calculate.OnBarClose && vupTrend[1] != vupTrend[0])
                {
                    if (IsFirstTickOfBar)
                    {
                        if (sequence.Count < 4) sequence.Add(SRType);
                        else
                        {
                            sequence[0] = sequence[1];
                            sequence[1] = sequence[2];
                            sequence[2] = sequence[3];
                            sequence[3] = SRType;
                        }
                    }
                    else if (sequence.Count == 0) sequence.Add(SRType);
                    else sequence[sequence.Count - 1] = SRType;
                }
                #endregion
                #endregion

                //Oscillation State
                //Need HH/!LL/HH to go to Up Trend
                //{NEW} !LL/High/!LL/HH to go to Up Trend
                //Need LL/!HH/LL to go to Dw Trend
                //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
                if (sequence.Count < 3) structureBiasState[decay] = FLAT;
                else if (sequence.Count < 4)
                {
                    if (sequence[0] == 3 && sequence[1] != -3 && sequence[2] == 3) structureBiasState[decay] = UP;
                    else if (sequence[0] == -3 && sequence[1] != 3 && sequence[2] == -3) structureBiasState[decay] = DOWN;
                    else structureBiasState[decay] = FLAT;
                }
                else
                {
                    if (sequence[1] == 3 && sequence[2] != -3 && sequence[3] == 3) structureBiasState[decay] = UP;
                    else if (sequence[1] == -3 && sequence[2] != 3 && sequence[3] == -3) structureBiasState[decay] = DOWN;
                    //{NEW} HL/LH/HL/HH to go to Up Trend
                    else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && sequence[3] == 3) structureBiasState[decay] = UP;
                    //{NEW} LH/HL/LH/LL to go to Up Trend
                    else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && sequence[3] == -3) structureBiasState[decay] = DOWN;
                    else structureBiasState[decay] = FLAT;
                }
            }
            #endregion

            #region -- UpTrend State --
            else if (SRType != 0 && structureBiasState[decay + 1] > FLAT)
            {
                if (IsFirstTickOfBar) sequence.Clear();
                //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
                if (SRType == -3)
                {
                    structureBiasState[decay] = FLAT;
                    if (IsFirstTickOfBar)         sequence.Add(SRType);
                    else if (sequence.Count == 0) sequence.Add(SRType);
                    else sequence[sequence.Count - 1] = SRType;
                }
                else structureBiasState[decay] = UP;
            }
            #endregion

            #region -- DwTrend State --
            else if (SRType != 0 && structureBiasState[decay + 1] < FLAT)
            {
                if (IsFirstTickOfBar) sequence.Clear();
                //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
                if (SRType == 3)
                {
                    structureBiasState[decay] = FLAT;
                    if (IsFirstTickOfBar)         sequence.Add(SRType);
                    else if (sequence.Count == 0) sequence.Add(SRType);
                    else sequence[sequence.Count - 1] = SRType;
                }
                else structureBiasState[decay] = DOWN;
            }
            #endregion

            else structureBiasState[decay] = structureBiasState[decay + 1];

            #endregion
//================================================================
        }
//========================================================================================================================================
		public override void OnRenderTargetChanged()
		{
			#region -- Brush disposal --
			//if(BullishBkgDXBrush!=null && !BullishBkgDXBrush.IsDisposed) {BullishBkgDXBrush.Dispose();  BullishBkgDXBrush=null;}
			if(fillbkgUp_DXBrush!=null && !fillbkgUp_DXBrush.IsDisposed) {fillbkgUp_DXBrush.Dispose(); fillbkgUp_DXBrush=null;}
			if(fillbkgDown_DXBrush!=null && !fillbkgDown_DXBrush.IsDisposed) {fillbkgDown_DXBrush.Dispose(); fillbkgDown_DXBrush=null;}
			if(StructureDialogText_UpDXBrush!=null && !StructureDialogText_UpDXBrush.IsDisposed) {StructureDialogText_UpDXBrush.Dispose(); StructureDialogText_UpDXBrush=null;}
			if(StructureDialogText_DownDXBrush!=null && !StructureDialogText_DownDXBrush.IsDisposed) {StructureDialogText_DownDXBrush.Dispose(); StructureDialogText_DownDXBrush=null;}
			if(StructureDialogBkg_UpDXBrush!=null && !StructureDialogBkg_UpDXBrush.IsDisposed) {StructureDialogBkg_UpDXBrush.Dispose(); StructureDialogBkg_UpDXBrush=null;}
			if(StructureDialogBkg_DownDXBrush!=null && !StructureDialogBkg_DownDXBrush.IsDisposed) {StructureDialogBkg_DownDXBrush.Dispose(); StructureDialogBkg_DownDXBrush=null;}
			if(iUpDXBrush!=null      && !iUpDXBrush.IsDisposed)      {iUpDXBrush.Dispose();      iUpDXBrush=null;}
			if(iDownDXBrush!=null    && !iDownDXBrush.IsDisposed)    {iDownDXBrush.Dispose();    iDownDXBrush=null;}
			if(iNeutralDXBrush!=null && !iNeutralDXBrush.IsDisposed) {iNeutralDXBrush.Dispose(); iNeutralDXBrush=null;}
			#endregion

			#region -- Brush Creation --
			if(RenderTarget!=null){
				fillbkgUp_DXBrush = pBkgUpColor.ToDxBrush(RenderTarget);
				fillbkgUp_DXBrush.Opacity = this.pzzTrendBkgOpacity/10f;
				fillbkgDown_DXBrush = pBkgDownColor.ToDxBrush(RenderTarget);
				fillbkgDown_DXBrush.Opacity = this.pzzTrendBkgOpacity/10f;
				StructureDialogText_UpDXBrush = StructureDialogText_UpBrush.ToDxBrush(RenderTarget);
				StructureDialogText_DownDXBrush = StructureDialogText_DownBrush.ToDxBrush(RenderTarget);
				StructureDialogBkg_UpDXBrush = StructureDialogBkg_UpBrush.ToDxBrush(RenderTarget);
				StructureDialogBkg_DownDXBrush = StructureDialogBkg_DownBrush.ToDxBrush(RenderTarget);
				StructureDialogBkg_UpDXBrush.Opacity = StructureDialogBkg_UpOpacity/100f;
				StructureDialogBkg_DownDXBrush.Opacity = StructureDialogBkg_DownOpacity/100f;
				iUpDXBrush      = iUpBrush.ToDxBrush(RenderTarget);
				iDownDXBrush    = iDownBrush.ToDxBrush(RenderTarget);
				iNeutralDXBrush = iNeutralBrush.ToDxBrush(RenderTarget);
			}
			#endregion
		}
//========================================================================================================================================
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			if (!IsVisible) return;
			var oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

			int lastBarIndex = ChartBars.ToIndex;
			int firstBarIndex = Math.Max(BarsRequiredToPlot, ChartBars.FromIndex);//-20???
			int x1 = 0, x2 = 0, y1 = 0, y2 = 0;
            
			#region -- Structure flooding of background --
			if(this.showZZFlooding && this.pzzTrendBkgOpacity>0){
				float barwidth = ChartControl.Properties.BarDistance;
				int panelheight = (int)ChartPanel.H;
				float halfBar = barwidth / 2.0f;
				float x_1 = chartControl.GetXByBarIndex(ChartBars, firstBarIndex) - halfBar;
				for(int abar = firstBarIndex; abar<=lastBarIndex; abar++){
//if(structureBiasState.GetValueAt(abar)==UP) Print(Bars.GetTime(abar).ToString()+"  UP");
//else if(structureBiasState.GetValueAt(abar)==DOWN) Print(Bars.GetTime(abar).ToString()+"  DOWN");
//else Print(Bars.GetTime(abar).ToString()+"  flat");
					float x_2 = x_1 + barwidth;
					if(structureBiasState.GetValueAt(abar)==UP)		   FillRect(x_1, x_2, panelheight, 0, fillbkgUp_DXBrush);
					else if(structureBiasState.GetValueAt(abar)==DOWN) FillRect(x_1, x_2, panelheight, 0, fillbkgDown_DXBrush);
					x_1 = x_1 + barwidth;
				}
			}
			#endregion
			base.OnRender(chartControl, chartScale);

			int idxFirstPivot = 0, idxLastPivot = 0;
			try { 
				idxFirstPivot = Math.Max(0, ElliottPivotDecUP.TakeWhile(s => s.BarSlotFound < firstBarIndex).ToList().Count - 1); }//First left Pivot outside of window
			catch (Exception) { }
			try { 
				idxLastPivot = Math.Min(ElliottPivotDecUP.Count, ElliottPivotDecUP.TakeWhile(s => s.BarSlotFound < lastBarIndex).ToList().Count); }//First right Pivot outside of window (or last)
			catch (Exception) { }

			if(pShowSwingLabels && !IsInHitTest){
				var pivots = ElliottPivotDecUP;//.Where(s=> s.BarSlotFound >=idxFirstPivot && s.BarSlotFound<=idxLastPivot).ToList();
				int brush_id = 0;
				foreach(var piv in pivots){
					string label    = "";
					switch (piv.SwingType){
						case HH_TYPE: label = "HH"; brush_id = 1; break;
						case HL_TYPE: label = "HL"; brush_id = 1; break;
						case LH_TYPE: label = "LH"; brush_id = -1;break;
						case LL_TYPE: label = "LL"; brush_id = -1;break;
						case DT_TYPE: label = "DT"; brush_id = 0; break;
						case DB_TYPE: label = "DB"; brush_id = 0; break;
					}
					if(label.Length>0){
						x1 = ChartControl.GetXByBarIndex(chartControl.BarsArray[0], piv.PivotBarSlot);
						y1 = chartScale.GetYByValue(piv.Price);
						var SZ = getTextWidth(label, SwingLabelFont);
						if(piv.IsPeak)
							drawString(label, x1 - SZ / 2, y1 - pTextOffset - SwingLabelFont.Size, SwingLabelFont, 
								brush_id==1 ? iUpDXBrush : (brush_id== -1 ? iDownDXBrush : iNeutralDXBrush), 
								SharpDX.DirectWrite.TextAlignment.Center);
						else
							drawString(label, x1 - SZ / 2, y1 + pTextOffset - SwingLabelFont.Size, SwingLabelFont, 
								brush_id==1 ? iUpDXBrush : (brush_id== -1 ? iDownDXBrush : iNeutralDXBrush), 
								SharpDX.DirectWrite.TextAlignment.Center);                                            
					}
				}
// DT(99), DB(-99), HH(1) or LH{2), LL(-1), LH(-2}

			}
			if (idxLastPivot <= 0) return;
            #region -- bullish count --
            //-- get list of bullish pivots depending on display settings --
            tmpElliottPivotDecUP = ElliottPivotDecUP.GetRange(idxFirstPivot, idxLastPivot - idxFirstPivot);//pivots inside window
            int idxLastUpStart = -1;
            if (tmpElliottPivotDecUP.Count(b => b.Name == "0") > 0) idxLastUpStart = tmpElliottPivotDecUP.IndexOf(tmpElliottPivotDecUP.Last(b => b.Name == "0"));
            if ((!displayHistUp && !displayLastUp) || (displayHistUp && !displayLastUp && idxLastUpStart <= 0)) tmpElliottPivotDecUP = null;
            else if (idxLastUpStart > 0 && !displayHistUp && displayLastUp) tmpElliottPivotDecUP = tmpElliottPivotDecUP.GetRange(idxLastUpStart, tmpElliottPivotDecUP.Count - idxLastUpStart);//last pivots only
            else if (idxLastUpStart > 0 && displayHistUp && !displayLastUp) tmpElliottPivotDecUP = tmpElliottPivotDecUP.GetRange(0, idxLastUpStart);//historical only - not really usefull but possible

			if (tmpElliottPivotDecUP != null)
            {
                for (int i = 0; i < tmpElliottPivotDecUP.Count; i++)
                {
                    y1 = chartScale.GetYByValue(tmpElliottPivotDecUP[i].Price);
                    x1 = chartControl.GetXByBarIndex(ChartBars, tmpElliottPivotDecUP[i].PivotBarSlot);
                                        
                    #region -- {x2,y2} coordinates --
                    if (i < tmpElliottPivotDecUP.Count - 1)
                    {
                        y2 = chartScale.GetYByValue(tmpElliottPivotDecUP[i + 1].Price);
                        x2 = ChartControl.GetXByBarIndex(ChartBars, tmpElliottPivotDecUP[i + 1].PivotBarSlot);
                    }
                    else
                    {
                        double y2Price = tmpElliottPivotDecUP[i].Price;
                        int x2Slot = tmpElliottPivotDecUP[i].PivotBarSlot;
                        if (tmpElliottPivotDecUP[i].IsPeak)
                        {
                            for (int b = lastBarIndex; b > tmpElliottPivotDecUP[i].PivotBarSlot; b--)
                            {
                                double minPrice = useHL ? Bars.GetLow(b) : Bars.GetClose(b);
                                if (minPrice <= y2Price)
                                {
                                    y2Price = minPrice;
                                    x2Slot = b;
                                }
                            }
                            y2 = chartScale.GetYByValue(y2Price);
                            x2 = ChartControl.GetXByBarIndex(ChartBars, x2Slot);
                        }
                        else
                        {
                            for (int b = lastBarIndex; b > tmpElliottPivotDecUP[i].PivotBarSlot; b--)
                            {
                                double maxPrice = useHL ? Bars.GetHigh(b) : Bars.GetClose(b);
                                if (maxPrice >= y2Price)
                                {
                                    y2Price = maxPrice;
                                    x2Slot = b;
                                }
                            }
                        }
                        y2 = chartScale.GetYByValue(y2Price);
                        x2 = ChartControl.GetXByBarIndex(ChartBars, x2Slot);
                    }
                    #endregion

                    #region ----------- Zigzag --------------
//					if (showZZ && (displayLastUp || (!displayLastUp && i < tmpElliottPivotDecUP.Count - 1))) {
                    if (showZZ) {
						drawline(x1, x2, y1, y2, zzColor, DashStyleHelper.Solid, zzwidth);
					}
                    #endregion

                    #region ----------- Count Letters -----------
                    if (displayLabelsUp)
                    {
                        float upstringWidth = getTextWidth(tmpElliottPivotDecUP[i].Name, countFont);
                        drawstring(tmpElliottPivotDecUP[i].Name, x1 - (int)(upstringWidth / 2), y1 + (int)(tmpElliottPivotDecUP[i].IsPeak ? -1.2 * countFont.Size : 0.2 * countFont.Size), countFont, ColDecUP, SharpDX.DirectWrite.TextAlignment.Center);                        
                    }
                    #endregion

                    #region ----------- ILVs -----------
                    if (displayValidUp || displayLimitUp || displayInvalidUp)
                    {
                        foreach (KeyValuePair<string, double[]> pair in tmpElliottPivotDecUP[i].IVL)
                        {
                            int y3 = chartScale.GetYByValue(pair.Value[1]);
                            int x2IVL = x2;
                            int rightIndex = i < tmpElliottPivotDecUP.Count - 1 ? tmpElliottPivotDecUP[i + 1].PivotBarSlot : lastBarIndex;
                            for (int b = tmpElliottPivotDecUP[i].PivotBarSlot; b <= rightIndex; b++)
                            {
                                double bhigh = Math.Max(Bars.GetHigh(b - 1), Bars.GetHigh(b));
                                double blow = Math.Min(Bars.GetLow(b - 1), Bars.GetLow(b));
                                if (bhigh > pair.Value[1] && pair.Value[1] > blow)
                                {
                                    x2IVL = ChartControl.GetXByBarIndex(ChartBars, b);
                                    break;
                                }
                            }
                            bool withLabel = pair.Value[0] >= 0 && displayLineLabelsUp;
                            NSILVType ilvtype = getILVType(pair.Key);
                            if (ilvtype == NSILVType.INVALID && displayInvalidUp) drawITVL(withLabel, string.Format("{0}{1}",invTXT, pair.Key), x1, x2IVL, y3, ColILUP);
                            else if (ilvtype == NSILVType.VALID && displayValidUp) drawITVL(withLabel, string.Format("{0}{1}",valTXT, pair.Key), x1, x2IVL, y3, ColVLUP);
                            else if (ilvtype == NSILVType.LIMIT && displayLimitUp) drawITVL(withLabel, string.Format("{0}{1}",trgTXT, pair.Key), x1, x2IVL, y3, ColTLUP);
                        }
                    }
                    #endregion

                    #region ----------- Zones -----------
                    if (displayImpZonesUp || displayCorZonesUp)
                    {
                        foreach (KeyValuePair<string, double[]> pair in tmpElliottPivotDecUP[i].Zones)
                        {
                            int y3Min = chartScale.GetYByValue(pair.Value[1]);
                            int y3Max = chartScale.GetYByValue(pair.Value[2]);
                            int x2IVL = x2;
                            int rightIndex = i < tmpElliottPivotDecUP.Count - 1 ? tmpElliottPivotDecUP[i + 1].PivotBarSlot : lastBarIndex;
                            for (int b = tmpElliottPivotDecUP[i].PivotBarSlot; b <= rightIndex; b++)
                            {
                                double bhigh = Math.Max(Bars.GetHigh(b - 1), Bars.GetHigh(b));
                                double blow = Math.Min(Bars.GetLow(b - 1), Bars.GetLow(b));
                                if (bhigh > Math.Max(pair.Value[1], pair.Value[2]) && Math.Min(pair.Value[1], pair.Value[2]) > blow)
                                {
                                    x2IVL = ChartControl.GetXByBarIndex(ChartBars, b);
                                    break;
                                }
                            }
                            bool withLabel = pair.Value[0] >= 0 && displayZoneLabelsUp;
                            NSPRZType prztype = getPRZType(pair.Key);
                            if (prztype == NSPRZType.CORRECTIVE && displayCorZonesUp) drawPRZ(withLabel, string.Format("{0}{1}", CorTXT, pair.Key), x1, x2IVL, y3Min, y3Max, ColZVRetUP);
                            else if (prztype == NSPRZType.IMPULSIVE && displayImpZonesUp) drawPRZ(withLabel, string.Format("{0}{1}", ImpTXT, pair.Key), x1, x2IVL, y3Min, y3Max, ColZVImpUP);
                        }
                    }
                    #endregion
                }
            }
            #endregion

			#region -- bearish count --
			//-- get list of bearish pivots depending on display settings --
			tmpElliottPivotDecDW = ElliottPivotDecDW.GetRange(idxFirstPivot, idxLastPivot - idxFirstPivot);//pivots inside window
			int idxLastDwStart = -1;
			if (tmpElliottPivotDecDW.Count(b => b.Name == "0") > 0) idxLastDwStart = tmpElliottPivotDecDW.IndexOf(tmpElliottPivotDecDW.Last(b => b.Name == "0"));
			if ((!displayHistDw && !displayLastDw) || (displayHistDw && !displayLastDw && idxLastDwStart <= 0)) tmpElliottPivotDecDW = null;
			else if (idxLastDwStart > 0 && !displayHistDw && displayLastDw) tmpElliottPivotDecDW = tmpElliottPivotDecDW.GetRange(idxLastDwStart, tmpElliottPivotDecDW.Count - idxLastDwStart);//last pivots only
			else if (idxLastDwStart > 0 && displayHistDw && !displayLastDw) tmpElliottPivotDecDW = tmpElliottPivotDecDW.GetRange(0, idxLastDwStart);//historical only - not really usefull but possible

			if (tmpElliottPivotDecDW != null)
			{
                for (int i = 0; i < tmpElliottPivotDecDW.Count; i++)
                {
					y1 = chartScale.GetYByValue(tmpElliottPivotDecDW[i].Price);
					x1 = chartControl.GetXByBarIndex(ChartBars, tmpElliottPivotDecDW[i].PivotBarSlot);

                    #region -- {x2,y2} coordinates --
                    if (i < tmpElliottPivotDecDW.Count - 1)
                    {
                        y2 = chartScale.GetYByValue(tmpElliottPivotDecDW[i + 1].Price);
                        x2 = chartControl.GetXByBarIndex(ChartBars, tmpElliottPivotDecDW[i + 1].PivotBarSlot);
                    }
                    else
                    {
                        double y2Price = tmpElliottPivotDecDW[i].Price;
                        int x2Slot = tmpElliottPivotDecDW[i].PivotBarSlot;
                        if (tmpElliottPivotDecDW[i].IsPeak)
                        {
                            for (int b = lastBarIndex; b > tmpElliottPivotDecDW[i].PivotBarSlot; b--)
                            {
                                double minPrice = useHL ? Bars.GetLow(b) : Bars.GetClose(b);
                                if (minPrice <= y2Price)
                                {
                                    y2Price = minPrice;
                                    x2Slot = b;
                                }
                            }
                            y2 = chartScale.GetYByValue(y2Price);
                            x2 = chartControl.GetXByBarIndex(ChartBars, x2Slot);
                        }
                        else
                        {
                            for (int b = lastBarIndex; b > tmpElliottPivotDecDW[i].PivotBarSlot; b--)
                            {
                                double maxPrice = useHL ? Bars.GetHigh(b) : Bars.GetClose(b);
                                if (maxPrice >= y2Price)
                                {
                                    y2Price = maxPrice;
                                    x2Slot = b;
                                }
                            }
                        }
                        y2 = chartScale.GetYByValue(y2Price);
                        x2 = chartControl.GetXByBarIndex(ChartBars, x2Slot);
                    }
                    #endregion

					#region ----------- Zigzag --------------
//					if (showZZ && (displayLastDw || (!displayLastDw && i < tmpElliottPivotDecDW.Count - 1))) 
					if (showZZ) 
						drawline(x1, x2, y1, y2, zzColor, DashStyleHelper.Solid, zzwidth);
					#endregion

					#region ----------- Count Letters -----------
					if (displayLabelsDw)
					{
					    float dwstringWidth = getTextWidth(tmpElliottPivotDecDW[i].Name, countFont);
					    drawstring(tmpElliottPivotDecDW[i].Name, x1 - (int)(dwstringWidth / 2), y1 + (int)(tmpElliottPivotDecDW[i].IsPeak ? -2 * countFont.Size : (int)(1 * countFont.Size)), countFont, ColDecDW, SharpDX.DirectWrite.TextAlignment.Center);
					}
					#endregion

					#region ----------- ILVs -----------
					if (displayValidDw || displayLimitDw || displayInvalidDw)
					{
                        foreach (KeyValuePair<string, double[]> pair in tmpElliottPivotDecDW[i].IVL)
                        {
							int y3 = chartScale.GetYByValue(pair.Value[1]);
							int x2IVL = x2;
							int rightIndex = i < tmpElliottPivotDecDW.Count - 1 ? tmpElliottPivotDecDW[i + 1].PivotBarSlot : lastBarIndex;
							for (int b = tmpElliottPivotDecDW[i].PivotBarSlot; b <= rightIndex; b++)
							{
								double bhigh = Math.Max(Bars.GetHigh(b - 1), Bars.GetHigh(b));
								double blow = Math.Min(Bars.GetLow(b - 1), Bars.GetLow(b));
								if (bhigh > pair.Value[1] && pair.Value[1] > blow)
								{
								    x2IVL = ChartControl.GetXByBarIndex(ChartBars, b);
								    break;
								}
							}

							bool withLabel = pair.Value[0] >= 0 && displayLineLabelsDw;
							NSILVType ilvtype = getILVType(pair.Key);
							if (ilvtype == NSILVType.INVALID && displayInvalidDw) drawITVL(withLabel, string.Format("{0}{1}", invTXT, pair.Key), x1, x2IVL, y3, ColILDW);
							else if (ilvtype == NSILVType.VALID && displayValidDw) drawITVL(withLabel, string.Format("{0}{1}", valTXT, pair.Key), x1, x2IVL, y3, ColVLDW);
							else if (ilvtype == NSILVType.LIMIT && displayLimitDw) drawITVL(withLabel, string.Format("{0}{1}", trgTXT, pair.Key), x1, x2IVL, y3, ColTLDW);
                        }
                    }
                    #endregion

                    #region ----------- Zones -----------
                    if (displayImpZonesDw || displayCorZonesDw)
                    {
                        foreach (KeyValuePair<string, double[]> pair in tmpElliottPivotDecDW[i].Zones)
                        {
                            int y3Min = chartScale.GetYByValue(pair.Value[1]);
                            int y3Max = chartScale.GetYByValue(pair.Value[2]);
                            int x2IVL = x2;
                            int rightIndex = i < tmpElliottPivotDecDW.Count - 1 ? tmpElliottPivotDecDW[i + 1].PivotBarSlot : lastBarIndex;
                            for (int b = tmpElliottPivotDecDW[i].PivotBarSlot; b <= rightIndex; b++)
                            {
                                double bhigh = Math.Max(Bars.GetHigh(b - 1), Bars.GetHigh(b));
                                double blow = Math.Min(Bars.GetLow(b - 1), Bars.GetLow(b));
                                if (bhigh > Math.Max(pair.Value[1], pair.Value[2]) && Math.Min(pair.Value[1], pair.Value[2]) > blow)
                                {
                                    x2IVL = ChartControl.GetXByBarIndex(ChartBars, b);
                                    break;
                                }
                            }
                            bool withLabel = pair.Value[0] >= 0 && displayZoneLabelsDw;
                            NSPRZType prztype = getPRZType(pair.Key);
                            if (prztype == NSPRZType.CORRECTIVE && displayCorZonesDw) drawPRZ(withLabel, string.Format("{0}{1}", CorTXT, pair.Key), x1, x2IVL, y3Min, y3Max, ColZVRetDW);
                            else if (prztype == NSPRZType.IMPULSIVE && displayImpZonesDw) drawPRZ(withLabel, string.Format("{0}{1}", ImpTXT, pair.Key), x1, x2IVL, y3Min, y3Max, ColZVImpDW);
                        }
                    }
                    #endregion
                }
            }
//			if (tmpElliottPivotDecDW == null && tmpElliottPivotDecUP == null && showZZ){
            if (showZZ){
	            tmpElliottPivotDecDW = ElliottPivotDecDW.GetRange(idxFirstPivot, idxLastPivot - idxFirstPivot);//pivots inside window
                for (int i = 0; i < tmpElliottPivotDecDW.Count; i++)
                {
                    y1 = chartScale.GetYByValue(tmpElliottPivotDecDW[i].Price);
                    x1 = ChartControl.GetXByBarIndex(ChartBars, tmpElliottPivotDecDW[i].PivotBarSlot);

                    #region -- {x2,y2} coordinates --
                    if (i < tmpElliottPivotDecDW.Count - 1)
                    {
                        y2 = chartScale.GetYByValue(tmpElliottPivotDecDW[i + 1].Price);
                        x2 = ChartControl.GetXByBarIndex(ChartBars, tmpElliottPivotDecDW[i + 1].PivotBarSlot);
                    }
                    else
                    {
                        double y2Price = tmpElliottPivotDecDW[i].Price;
                        int x2Slot = tmpElliottPivotDecDW[i].PivotBarSlot;
                        if (tmpElliottPivotDecDW[i].IsPeak)
                        {
                            for (int b = lastBarIndex; b > tmpElliottPivotDecDW[i].PivotBarSlot; b--)
                            {
                                double minPrice = useHL ? Bars.GetLow(b) : Bars.GetClose(b);
                                if (minPrice <= y2Price)
                                {
                                    y2Price = minPrice;
                                    x2Slot = b;
                                }
                            }
                            y2 = chartScale.GetYByValue(y2Price);
                            x2 = ChartControl.GetXByBarIndex(ChartBars, x2Slot);
                        }
                        else
                        {
                            for (int b = lastBarIndex; b > tmpElliottPivotDecDW[i].PivotBarSlot; b--)
                            {
                                double maxPrice = useHL ? Bars.GetHigh(b) : Bars.GetClose(b);
                                if (maxPrice >= y2Price)
                                {
                                    y2Price = maxPrice;
                                    x2Slot = b;
                                }
                            }
                        }
                        y2 = chartScale.GetYByValue(y2Price);
                        x2 = ChartControl.GetXByBarIndex(ChartBars, x2Slot);
                    }
                    #endregion

					drawline(x1, x2, y1, y2, zzColor, DashStyleHelper.Solid, zzwidth);
				}

			}

            #endregion

			int rmab = BarsArray[0].GetBar(Times[0].GetValueAt(Math.Min(BarsArray[0].Count-1,ChartBars.ToIndex)));
			if(rmab == BarsArray[0].Count-1 && Calculate == Calculate.OnBarClose) rmab = rmab-1;

			DrawSentimentDialog(chartScale, StructureDirection.GetValueAt(rmab), SentimentDialogLoc, rmab);

			RenderTarget.AntialiasMode = oldAntialiasMode;
        }
//========================================================================================================================================
		private void DrawSentimentDialog(ChartScale chartscale, int Direction, ARC_Waves_SentimentDialogLoc Loc, int abs_bar){
			if(Loc == ARC_Waves_SentimentDialogLoc.None) return;
			#region -- DrawSentimentDialog --
			string msg = "N/A";
			if(Direction == UP){
				if(VerboseSentimentDialog) msg = "Structure:  UP"; else msg = "UP";
			}
			else if(Direction == DOWN){
				if(VerboseSentimentDialog) msg = "Structure:  DOWN"; else msg = "DOWN";
			}
			//else
			//	bkg_brush = Brushes.Yellow.ToDxBrush(RenderTarget);
			float xf = 100f;
			float yf = 100f;
			float txt_margin = 3f;
			float HeightPerCell = (float)StructureDialogFont.Size + txt_margin*2f;
			float halfCellHeight = HeightPerCell/2f;
			float halfFontHeight = (float)StructureDialogFont.Size/2f;

			var hw0 = getTextHeightAndWidth(msg, StructureDialogFont);
			var hw = new float[2]{txt_margin*2f + hw0[0], hw0[1]};

			
			if(Loc == ARC_Waves_SentimentDialogLoc.TopLeft){
				xf = ChartPanel.X + 20f;
				yf = ChartPanel.Y + 30f;
			}
			else if(Loc == ARC_Waves_SentimentDialogLoc.BottomLeft){
				xf = ChartPanel.X + 20f;
				yf = ChartPanel.Y + ChartPanel.H - 40f - HeightPerCell;
			}
			else if(Loc == ARC_Waves_SentimentDialogLoc.TopRight){
				xf = ChartPanel.X + ChartPanel.W - hw[1] - 40f;
				yf = ChartPanel.Y + 30f;
			}
			else if(Loc == ARC_Waves_SentimentDialogLoc.BottomRight){
				xf = ChartPanel.X + ChartPanel.W - hw[1] - 40f;
				yf = ChartPanel.Y + ChartPanel.H - 30f - HeightPerCell;
			}
			else if(Loc == ARC_Waves_SentimentDialogLoc.Center){
				xf = ChartPanel.X + ChartPanel.W/2f - (hw[1] + 16f)/2f;
				yf = ChartPanel.Y + ChartPanel.H/2f - (hw[0] + 16f + HeightPerCell)/2f;
			}

			if(msg.Length>0){
				if(Direction==UP){
					RenderTarget.FillRectangle(new SharpDX.RectangleF(xf-8f, yf-halfCellHeight, hw[1]+16f, hw[0]), StructureDialogBkg_UpDXBrush);
					drawString(msg, xf, yf-halfFontHeight, StructureDialogFont, StructureDialogText_UpDXBrush, SharpDX.DirectWrite.TextAlignment.Leading, -9999f);
				}else if(Direction==DOWN){
					RenderTarget.FillRectangle(new SharpDX.RectangleF(xf-8f, yf-halfCellHeight, hw[1]+16f, hw[0]), StructureDialogBkg_DownDXBrush);
					drawString(msg, xf, yf-halfFontHeight, StructureDialogFont, StructureDialogText_DownDXBrush, SharpDX.DirectWrite.TextAlignment.Leading, -9999f);
				}
				yf = yf + HeightPerCell + 4f;
			}
			#endregion
		}
//========================================================================================================================================
		#region -- getTextHeightAndWidth --
		private float[] getTextHeightAndWidth(string text, SimpleFont font){
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			float[] result = new float[2]{(float)font.Size, textLayout.Metrics.Width};

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return result;
		}
		#endregion
		#region -- drawstring --
		//Draw a text at {x;y} coordinates in pixel.
		private void drawString(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxTextWidth = -9999f)
		{
		    SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        ) { TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, MaxTextWidth <= 0f ? getTextWidth(text, font) : MaxTextWidth, float.MaxValue);

		    RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

		    textLayout.Dispose();
		    textFormat.Dispose();
		}
		private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.Direct2D1.Brush bkgBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxTextWidth = -9999f, float MaxX = -9999f)
		{
			#region drawstring
			if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
			SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();

			var textFormat = new SharpDX.DirectWrite.TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
			)
				{ TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, (MaxTextWidth>0 ? MaxTextWidth : ChartPanel.W/3), ChartPanel.H);
			if(x<0) x = Math.Abs(x) - textLayout.Metrics.Width - 5;

			if(MaxX>0)
				x = Math.Min(x, MaxX - 3f - textLayout.Metrics.Width);

			y = y - textLayout.Metrics.Height/2.0;
			if (bkgBrush!=null && bkgBrush.Opacity>0) {
				double xl = x - 3;
				double xr = x + textLayout.Metrics.Width + 3;
				double yt = y - 1;
				double yb = y+textLayout.Metrics.Height + 2;
				if(textAlignment==SharpDX.DirectWrite.TextAlignment.Trailing){
					xr = x + textLayout.Metrics.LayoutWidth +3;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				else if(textAlignment==SharpDX.DirectWrite.TextAlignment.Center){
					xr = x + textLayout.Metrics.LayoutWidth/2 + 3 + textLayout.Metrics.Width/2;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				var bkgBox = new System.Windows.Point[]
				{	new System.Windows.Point(xl, yt),
					new System.Windows.Point(xl, yb),
					new System.Windows.Point(xr, yb),
					new System.Windows.Point(xr, yt),
				};
				drawRegion(bkgBox, bkgBrush);
			}
			RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			textLayout.Dispose();
			textFormat.Dispose();
			#endregion
		}
		#endregion
		#region -- drawRegion --
        //Draw Region. Rect in pixel coordinate.
        private void drawRegion(Rect rectangle, SharpDX.Direct2D1.Brush color)//, int opacity = 100)
        {
            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, color);
        }
        //Draw Region. x and y as pixel coordinate, w and h in pixel too.
        private void drawRegion(double x, double y, double w, double h, SharpDX.Direct2D1.Brush color)
        {
            drawRegion(
				new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, 
				color);
        }
		private void drawRegion(System.Windows.Point[] points, SharpDX.Direct2D1.Brush dxbrush)
		{
		    SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

		    SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
		    SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
		    sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
		    sink1.AddLines(vectors);
		    sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
		    sink1.Close();

		    RenderTarget.FillGeometry(geo1, dxbrush);
		    geo1.Dispose();
		    sink1.Dispose();
		}
		#endregion
//========================================================================================================================================

        //----------------- Drawing Functions -------------------
		#region Drawing Functions
        private void drawline(int x1, int x2, int y1, int y2, Brush couleur, DashStyleHelper dashstyle, int width)
        {
            SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            Point p0 = new Point(x1, y1);
            Point p1 = new Point(x2, y2);
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }
        private void drawstring(string text, double x, double y, SimpleFont font, Brush textBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            if (x < 0 || y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
            SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                )
            { TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);
//Print("2225:  "+x+"    "+text);
            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textBrush.ToDxBrush(RenderTarget), SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
        }
        private float getTextWidth(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }
        private void drawITVL(bool withLabel, string name, int x1, int x2, int y, Brush color)
        {
            drawline(x1, x2, y, y, color, DashStyleHelper.Solid, ilvThickness);
            if (!withLabel) return;

            double h = ivlFont.Size;
            drawstring(name, x1, (int)(y - h), ivlFont, color, SharpDX.DirectWrite.TextAlignment.Center);
        }
        private void fillPolygon(Point[] points, Brush color, int opacity = 100)
        {
            SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            linebrush.Opacity = opacity / 100f;

            //SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };
            SharpDX.Vector2[] vectors = new SharpDX.Vector2[points.Count() - 1];
            for (int v = 1; v < points.Count(); v++) vectors[v - 1] = points[v].ToVector2();

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, linebrush);
            geo1.Dispose();
            sink1.Dispose();
            linebrush.Dispose();

            RenderTarget.AntialiasMode = oldAntialiasMode;
        }
        private void fillPolygon(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
        {
            SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

            //SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };
            SharpDX.Vector2[] vectors = new SharpDX.Vector2[points.Count() - 1];
            for (int v = 1; v < points.Count(); v++) vectors[v - 1] = points[v].ToVector2();

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();

            RenderTarget.AntialiasMode = oldAntialiasMode;
        }
        private void drawPRZ(bool withLabel, string name, int x1, int x2, int ymin, int ymax, Brush color)
        {
            Point[] zonePath = { new Point(x1, ymin), new Point(x2, ymin), new Point(x2, ymax), new Point(x1, ymax) };
            fillPolygon(zonePath, color, zoneAlpha);

            if (!withLabel) return;

            double h = zoneFont.Size;
            int y = (ymin + ymax) / 2;
            drawstring(name, x1, (int)(y - h), zoneFont, color, SharpDX.DirectWrite.TextAlignment.Center);
        }

        private void FillRect(float x1, float x2, float ymin, float ymax, SharpDX.Direct2D1.Brush dxbrush)
        {
            Point[] zonePath = { new Point(x1, ymin), new Point(x2, ymin), new Point(x2, ymax), new Point(x1, ymax) };
            fillPolygon(zonePath, dxbrush);
        }
		#endregion

        //--------------------- Functions -----------------------
        #region private NSILVType getILVType(string name)
        private NSILVType getILVType(string name)
        {
            if (name == NAME_V2A || name == NAME_V32A || name == NAME_V34A || name == NAME_V4A || name == NAME_V52 || name == NAME_V54) return NSILVType.INVALID;
            else if (name == NAME_V3 || name == NAME_V5 || name == NAME_VC) return NSILVType.VALID;
            else return NSILVType.LIMIT;
        }
        #endregion

        #region private NSPRZType getPRZType(string name)
        private NSPRZType getPRZType(string name)
        {
            if (name == NAME_V2A || name == NAME_V32A || name == NAME_V34A || name == NAME_V4A || name == NAME_V52 || name == NAME_V54) return NSPRZType.CORRECTIVE;
            else return NSPRZType.IMPULSIVE;
        }
        #endregion
        
        #region private void GetITVL(string ITVL,bool newTxtIdx, int sens)
        private void GetITVL(string ITVL, bool newTxtIdx, int sens)
        {
            double res = 0;
            switch (ITVL)
            {
                //IL
                case NAME_V2A: res = decompte[sens].Wave1.End.Price - (decompte[sens].Wave1.End.Price - decompte[sens].Wave1.Start.Price) * RetV2Max / 100; break;
                case NAME_V32A: res = decompte[sens].SubWave1.End.Price - (decompte[sens].SubWave1.End.Price - decompte[sens].SubWave1.Start.Price) * RetV2Max / 100; break;
                case NAME_V34A: res = decompte[sens].SubWave1.End.Price - (decompte[sens].SubWave1.End.Price - decompte[sens].SubWave1.Start.Price) * RetV4Max / 100; break;
                case NAME_V4A: res = decompte[sens].Wave1.End.Price - (decompte[sens].Wave1.End.Price - decompte[sens].Wave1.Start.Price) * RetV4Max / 100; break;
                case NAME_V52: res = decompte[sens].SubWave1.End.Price - (decompte[sens].SubWave1.End.Price - decompte[sens].SubWave1.Start.Price) * RetV2Max / 100; break;
                case NAME_V54: res = decompte[sens].SubWave1.End.Price - (decompte[sens].SubWave1.End.Price - decompte[sens].SubWave1.Start.Price) * RetV4Max / 100; break;
                //TL
                case NAME_V2B: res = decompte[sens].Wave1.End.Price - (decompte[sens].Wave1.End.Price - decompte[sens].Wave1.Start.Price) * ExtVbMax / 100; break;
                case NAME_V2C: res = decompte[sens].Wave3.End.Price - (decompte[sens].Wave3.End.Price - decompte[sens].Wave3.Start.Price) * RetVcMin / 100; break;
                case NAME_V32B: res = decompte[sens].SubWave1.End.Price - (decompte[sens].SubWave1.End.Price - decompte[sens].SubWave1.Start.Price) * ExtVbMax / 100; break;
                case NAME_V32C: res = decompte[sens].SubWave1.End.Price - (decompte[sens].SubWave1.End.Price - decompte[sens].SubWave1.Start.Price) * RetV2Max / 100; break;
                case NAME_V34B: res = decompte[sens].SubWave3.End.Price - (decompte[sens].SubWave3.End.Price - decompte[sens].SubWave3.Start.Price) * ExtVbMax / 100; break;
                case NAME_V4B: res = decompte[sens].Wave3.End.Price - (decompte[sens].Wave3.End.Price - decompte[sens].Wave3.Start.Price) * ExtVbMax / 100; break;
                case NAME_V4C: res = decompte[sens].Wave5.End.Price - (decompte[sens].Wave5.End.Price - decompte[sens].Wave5.Start.Price) * RetV2Max / 100; break;
                //VL
                case NAME_V3: res = decompte[sens].Wave2.End.Price + (decompte[sens].Wave1.End.Price - decompte[sens].Wave1.Start.Price) * ExtV3Min / 100; break;
                case NAME_V5: res = decompte[sens].Wave4.End.Price + (decompte[sens].Wave3.End.Price - decompte[sens].Wave3.Start.Price) * ExtV5Min / 100; break;
                case NAME_VC: res = decompte[sens].WaveY.End.Price; break;
            }
            if (sens > 0) ElliottPivotDecUP.Last().IVL.Add(ITVL, new double[] { newTxtIdx ? 0 : -1, res });
            else ElliottPivotDecDW.Last().IVL.Add(ITVL, new double[] { newTxtIdx ? 0 : -1, res });
        }
        #endregion

        #region private void GetPRZ(string PRZ,bool newTxtIdx, int sens)
        private void GetPRZ(string PRZ, bool newTxtIdx, int sens)
        {
            double min = 0, max = 0;
            switch (PRZ)
            {
                //COR
                case NAME_V2A:
                    min = decompte[sens].Wave1.End.Price - (decompte[sens].Wave1.End.Price - decompte[sens].Wave1.Start.Price) * ObjV2min / 100;
                    max = decompte[sens].Wave1.End.Price - (decompte[sens].Wave1.End.Price - decompte[sens].Wave1.Start.Price) * ObjV2max / 100;
                    break;
                case NAME_V32A:
                    min = decompte[sens].SubWave1.End.Price - (decompte[sens].SubWave1.End.Price - decompte[sens].SubWave1.Start.Price) * ObjV2min / 100;
                    max = decompte[sens].SubWave1.End.Price - (decompte[sens].SubWave1.End.Price - decompte[sens].SubWave1.Start.Price) * ObjV2max / 100;
                    break;
                case NAME_V34A:
                    min = decompte[sens].SubWave3.End.Price - (decompte[sens].SubWave3.End.Price - decompte[sens].SubWave3.Start.Price) * ObjV4min / 100;
                    max = decompte[sens].SubWave3.End.Price - (decompte[sens].SubWave3.End.Price - decompte[sens].SubWave3.Start.Price) * ObjV4max / 100;
                    break;
                case NAME_V4A:
                    min = decompte[sens].Wave3.End.Price - (decompte[sens].Wave3.End.Price - decompte[sens].Wave3.Start.Price) * ObjV4min / 100;
                    max = decompte[sens].Wave3.End.Price - (decompte[sens].Wave3.End.Price - decompte[sens].Wave3.Start.Price) * ObjV4max / 100;
                    break;
                case NAME_V52:
                    min = decompte[sens].SubWave1.End.Price - (decompte[sens].SubWave1.End.Price - decompte[sens].SubWave1.Start.Price) * ObjV2min / 100;
                    max = decompte[sens].SubWave1.End.Price - (decompte[sens].SubWave1.End.Price - decompte[sens].SubWave1.Start.Price) * ObjV2max / 100;
                    break;
                case NAME_V54:
                    min = decompte[sens].SubWave3.End.Price - (decompte[sens].SubWave3.End.Price - decompte[sens].SubWave3.Start.Price) * ObjV4min / 100;
                    max = decompte[sens].SubWave3.End.Price - (decompte[sens].SubWave3.End.Price - decompte[sens].SubWave3.Start.Price) * ObjV4max / 100;
                    break;
                //IMP
                case NAME_V3:
                    min = decompte[sens].Wave2.End.Price + (decompte[sens].Wave1.End.Price - decompte[sens].Wave1.Start.Price) * ObjV3min / 100;
                    max = decompte[sens].Wave2.End.Price + (decompte[sens].Wave1.End.Price - decompte[sens].Wave1.Start.Price) * ObjV3max / 100;
                    break;
                case NAME_V5:
                    min = decompte[sens].Wave4.End.Price + (decompte[sens].Wave3.End.Price - decompte[sens].Wave3.Start.Price) * ObjV5min / 100;
                    max = decompte[sens].Wave4.End.Price + (decompte[sens].Wave3.End.Price - decompte[sens].Wave3.Start.Price) * ObjV5max / 100;
                    break;
            }
            if (sens > 0) ElliottPivotDecUP.Last().Zones.Add(PRZ, new double[] { newTxtIdx ? 0 : -1, min, max });
            else ElliottPivotDecDW.Last().Zones.Add(PRZ, new double[] { newTxtIdx ? 0 : -1, min, max });
        }
        #endregion

        #region private void GestionDecompte(int sens,Point px))
        private void GestionDecompte(NSWavesCountSide side)
        {
            Pivot px = side > 0 ? ElliottPivotDecUP.Last() : ElliottPivotDecDW.Last();

            int SIGNE = side == 0 ? -1 : 1;
            int OFFSET = side == 0 ? 2 : 1;
            switch (decompte[(int)side].LastPrp)
            {
                case "0":
                    #region --- V0->V1
                    px.Name = NAME_V1;
                    decompte[(int)side].LastPrp = "1";
                    decompte[(int)side].LastImp = "0";
                    decompte[(int)side].LastCor = "0";
                    decompte[(int)side].Wave1.End = px;

                    if (side > 0) UpCount[0] = (int)NSWavesName.V1;
                    else DownCount[0] = (int)NSWavesName.V1;

                    GetITVL(NAME_V2A, true, (int)side);
                    GetITVL(NAME_V2B, true, (int)side);
                    GetPRZ(NAME_V2A, true, (int)side);
                    #endregion
                    break;
                case "1":
                    #region --- V1->V2a ou (x)0
                    if (CallGreater(px.Price, RetV2Max, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.Start.Price, -1, 1, SIGNE))
                    {
                        px.Name = NAME_V2A;
                        decompte[(int)side].LastPrp = "2";
                        decompte[(int)side].LastImp = "0";
                        decompte[(int)side].LastCor = "a";
                        decompte[(int)side].Wave2.Start = decompte[(int)side].Wave1.End;
                        decompte[(int)side].Wave2.End = px;
                        decompte[(int)side].Wavea.Start = decompte[(int)side].Wave1.End;
                        decompte[(int)side].Wavea.End = px;

                        if (side > 0) UpCount[0] = (int)NSWavesName.V2A;
                        else DownCount[0] = (int)NSWavesName.V2A;

                        GetITVL(NAME_V2A, false, (int)side);
                        GetITVL(NAME_V2B, false, (int)side);
                        GetITVL(NAME_V3, true, (int)side);
                        GetPRZ(NAME_V2A, false, (int)side);
                        GetPRZ(NAME_V3, true, (int)side);
                    }
                    else
                    {
                        //V2 invalide retour ?? 0
                        decompte[(int)side].Reset(px);
                        if (side > 0) UpCount[0] = (int)NSWavesName.RAZ;
                        else DownCount[0] = (int)NSWavesName.RAZ;
                    }
                    #endregion
                    break;
                case "2":
                    #region --- V2abc
                    switch (decompte[(int)side].LastCor)
                    {
                        case "a":
                        case "c":
                            #region --- V2a/V2c -> V2B/V31. - V31. - V3
                            if (CallLower(px.Price, ExtVbMax, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.Start.Price, -1, 1, SIGNE))
                            {
                                px.Name = NAME_V2B;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "2";
                                decompte[(int)side].LastImp = "0";
                                decompte[(int)side].LastCor = "b";
                                decompte[(int)side].Wave3.Start = decompte[(int)side].Wave2.End;
                                decompte[(int)side].Wave3.End = px;
                                decompte[(int)side].Waveb.Start = decompte[(int)side].Wave2.End;
                                decompte[(int)side].Waveb.End = px;
                                decompte[(int)side].SubWave1.Start = decompte[(int)side].Wave2.End;
                                decompte[(int)side].SubWave1.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V2B;
                                else DownCount[0] = (int)NSWavesName.V2B;

                                GetITVL(NAME_V2A, false, (int)side);
                                GetITVL(NAME_V2C, true, (int)side);
                                GetITVL(NAME_V2B, false, (int)side);
                                GetITVL(NAME_V3, false, (int)side);
                                GetPRZ(NAME_V2A, false, (int)side);
                                GetPRZ(NAME_V3, false, (int)side);
                            }
                            else if (CallGreater(px.Price, ExtV3Min, decompte[(int)side].Wave2.End.Price, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.Start.Price, 1, 2, SIGNE))
                            {
                                px.Name = NAME_V3;
                                //px.SetFont(fontbig);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "3";
                                decompte[(int)side].LastImp = "0";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].Wave3.Start = decompte[(int)side].Wave2.End;
                                decompte[(int)side].Wave3.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V3;
                                else DownCount[0] = (int)NSWavesName.V3;

                                GetITVL(NAME_V4A, true, (int)side);
                                GetITVL(NAME_V4B, true, (int)side);
                                GetPRZ(NAME_V4A, true, (int)side);
                            }
                            else
                            {
                                px.Name = NAME_V31;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "3";
                                decompte[(int)side].LastImp = "1";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].Wave3.Start = decompte[(int)side].Wave2.End;
                                decompte[(int)side].Wave3.End = px;
                                decompte[(int)side].SubWave1.Start = decompte[(int)side].Wave2.End;
                                decompte[(int)side].SubWave1.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V31;
                                else DownCount[0] = (int)NSWavesName.V31;

                                GetITVL(NAME_V2A, false, (int)side);
                                GetITVL(NAME_V32A, true, (int)side);
                                GetITVL(NAME_V32B, true, (int)side);
                                GetITVL(NAME_V3, false, (int)side);
                                GetPRZ(NAME_V32A, true, (int)side);
                                GetPRZ(NAME_V3, false, (int)side);
                            }
                            #endregion
                            break;
                        case "b":
                            #region --- V2b/V31. -> V2c - V32.a - (x)0
                            if (CallGreater(px.Price, RetVcMin, decompte[(int)side].Wave3.End.Price, decompte[(int)side].Wave3.End.Price, decompte[(int)side].Wave3.Start.Price, -1, 3, SIGNE))
                            {
                                px.Name = NAME_V32A;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "3";
                                decompte[(int)side].LastImp = "2";
                                decompte[(int)side].LastCor = "a";
                                decompte[(int)side].SubWave2.Start = decompte[(int)side].SubWave1.End;
                                decompte[(int)side].SubWave2.End = px;
                                decompte[(int)side].Wavea.Start = decompte[(int)side].SubWave1.End;
                                decompte[(int)side].Wavea.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V32A;
                                else DownCount[0] = (int)NSWavesName.V32A;

                                GetITVL(NAME_V2A, false, (int)side);
                                GetITVL(NAME_V32A, true, (int)side);
                                GetITVL(NAME_V32B, true, (int)side);
                                GetITVL(NAME_V3, false, (int)side);
                                GetPRZ(NAME_V32A, true, (int)side);
                                GetPRZ(NAME_V3, false, (int)side);
                            }
                            else if (CallGreater(px.Price, RetV2Max, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.Start.Price, -1, 4, SIGNE))
                            {
                                px.Name = NAME_V2C;
                                //px.SetFont(fontbig);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "2";
                                decompte[(int)side].LastImp = "0";
                                decompte[(int)side].LastCor = "c";
                                decompte[(int)side].Wave2.End = px;
                                decompte[(int)side].Wavec.Start = decompte[(int)side].Waveb.End;
                                decompte[(int)side].Wavec.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V2C;
                                else DownCount[0] = (int)NSWavesName.V2C;

                                GetITVL(NAME_V2A, false, (int)side);
                                GetITVL(NAME_V2B, false, (int)side);
                                GetITVL(NAME_V3, false, (int)side);
                                GetPRZ(NAME_V2A, false, (int)side);
                                GetPRZ(NAME_V3, false, (int)side);
                            }
                            else
                            {
                                //V2 invalide retour ?? 0
                                decompte[(int)side].Reset(px);
                                //px.SetFont(fontbig);
                                //px.SetColor(inv_couleur);
                                if (side > 0) UpCount[0] = (int)NSWavesName.RAZ;
                                else DownCount[0] = (int)NSWavesName.RAZ;
                            }
                            #endregion
                            break;
                        default: break;
                    }
                    #endregion
                    break;
                case "3":
                    #region ----- V3/0.1.2.3.4.5.
                    switch (decompte[(int)side].LastImp)
                    {
                        case "0":
                        case "5":
                            #region ----- V3/V35. -> V4A - (x)0
                            if (CallGreater(px.Price, RetV4Max, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.Start.Price, -1, 5, SIGNE))
                            {
                                px.Name = NAME_V4A;
                                //px.SetFont(fontbig);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "4";
                                decompte[(int)side].LastImp = "0";
                                decompte[(int)side].LastCor = "a";
                                decompte[(int)side].Wave4.Start = decompte[(int)side].Wave3.End;
                                decompte[(int)side].Wave4.End = px;
                                decompte[(int)side].Wavea.Start = decompte[(int)side].Wave3.End;
                                decompte[(int)side].Wavea.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V4A;
                                else DownCount[0] = (int)NSWavesName.V4A;

                                GetITVL(NAME_V4A, false, (int)side);
                                GetITVL(NAME_V4B, false, (int)side);
                                GetITVL(NAME_V5, true, (int)side);
                                GetPRZ(NAME_V4A, false, (int)side);
                                GetPRZ(NAME_V5, true, (int)side);
                            }
                            else
                            {
                                //V2 invalide retour ?? 0
                                decompte[(int)side].Reset(px);
                                if (side > 0) UpCount[0] = (int)NSWavesName.RAZ;
                                else DownCount[0] = (int)NSWavesName.RAZ;
                                //px.SetFont(fontbig);
                                //px.SetColor(inv_couleur);
                            }
                            #endregion
                            break;
                        case "1":
                            #region ----- V31. -> V32.a - x(0)
                            if (CallGreater(px.Price, RetV2Max, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.Start.Price, -1, 3, SIGNE))
                            {
                                px.Name = NAME_V32A;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "3";
                                decompte[(int)side].LastImp = "2";
                                decompte[(int)side].LastCor = "a";
                                decompte[(int)side].SubWave2.Start = decompte[(int)side].SubWave1.End;
                                decompte[(int)side].SubWave2.End = px;
                                decompte[(int)side].Wavea.Start = decompte[(int)side].SubWave1.End;
                                decompte[(int)side].Wavea.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V32A;
                                else DownCount[0] = (int)NSWavesName.V32A;

                                GetITVL(NAME_V2A, false, (int)side);
                                GetITVL(NAME_V32A, false, (int)side);
                                GetITVL(NAME_V32B, false, (int)side);
                                GetITVL(NAME_V3, false, (int)side);
                                GetPRZ(NAME_V32A, false, (int)side);
                                GetPRZ(NAME_V3, false, (int)side);
                            }
                            else
                            {
                                //V2 invalide retour ?? 0
                                decompte[(int)side].Reset(px);
                                if (side > 0) UpCount[0] = (int)NSWavesName.RAZ;
                                else DownCount[0] = (int)NSWavesName.RAZ;
                                //px.SetFont(fontbig);
                                //px.SetColor(inv_couleur);
                            }
                            #endregion
                            break;
                        case "2":
                            switch (decompte[(int)side].LastCor)
                            {
                                case "a":
                                case "c":
                                    #region ----- V32.a/V32.c -> V32.b - V33. - V3
                                    if (CallLower(px.Price, ExtVbMax, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.Start.Price, -1, 2, SIGNE))
                                    {
                                        px.Name = NAME_V32B;
                                        //px.SetFont(fontsmall);
                                        //px.SetColor(couleur);
                                        decompte[(int)side].LastPrp = "3";
                                        decompte[(int)side].LastImp = "2";
                                        decompte[(int)side].LastCor = "b";
                                        decompte[(int)side].SubWave3.Start = decompte[(int)side].SubWave2.End;
                                        decompte[(int)side].SubWave3.End = px;
                                        decompte[(int)side].Waveb.Start = decompte[(int)side].SubWave2.End;
                                        decompte[(int)side].Waveb.End = px;

                                        if (side > 0) UpCount[0] = (int)NSWavesName.V32B;
                                        else DownCount[0] = (int)NSWavesName.V32B;

                                        GetITVL(NAME_V2A, false, (int)side);
                                        GetITVL(NAME_V32A, false, (int)side);
                                        GetITVL(NAME_V32B, false, (int)side);
                                        GetITVL(NAME_V3, false, (int)side);
                                        GetPRZ(NAME_V32A, false, (int)side);
                                        GetPRZ(NAME_V3, false, (int)side);
                                    }
                                    else if (CallLower(px.Price, ExtV3Min, decompte[(int)side].Wave2.End.Price, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.Start.Price, 1, 3, SIGNE))
                                    {
                                        px.Name = NAME_V33;
                                        //px.SetFont(fontsmall);
                                        //px.SetColor(couleur);
                                        decompte[(int)side].LastPrp = "3";
                                        decompte[(int)side].LastImp = "3";
                                        decompte[(int)side].LastCor = "0";
                                        decompte[(int)side].Wave3.End = px;
                                        decompte[(int)side].SubWave3.Start = decompte[(int)side].SubWave2.End;
                                        decompte[(int)side].SubWave3.End = px;

                                        if (side > 0) UpCount[0] = (int)NSWavesName.V33;
                                        else DownCount[0] = (int)NSWavesName.V33;

                                        GetITVL(NAME_V34A, true, (int)side);
                                        GetITVL(NAME_V34B, true, (int)side);
                                        GetITVL(NAME_V3, false, (int)side);
                                        GetPRZ(NAME_V34A, true, (int)side);
                                        GetPRZ(NAME_V3, false, (int)side);
                                    }
                                    else
                                    {
                                        //V3 valide
                                        px.Name = NAME_V3;
                                        //px.SetFont(fontbig);
                                        //px.SetColor(couleur);
                                        decompte[(int)side].LastPrp = "3";
                                        decompte[(int)side].LastImp = "0";
                                        decompte[(int)side].LastCor = "0";
                                        decompte[(int)side].Wave3.End = px;

                                        if (side > 0) UpCount[0] = (int)NSWavesName.V3;
                                        else DownCount[0] = (int)NSWavesName.V3;

                                        GetITVL(NAME_V4A, true, (int)side);
                                        GetITVL(NAME_V4B, true, (int)side);
                                        GetPRZ(NAME_V4A, true, (int)side);
                                    }
                                    #endregion
                                    break;
                                case "b":
                                    #region ----- V32.b -> 32.c - 2C - (x)0 OU 32.c - (x)0
                                    if (CallGreater(px.Price, RetV2Max, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.Start.Price, -1, 6, SIGNE))
                                    {
                                        px.Name = NAME_V32C;
                                        //px.SetFont(fontsmall);
                                        //px.SetColor(couleur);
                                        decompte[(int)side].LastPrp = "3";
                                        decompte[(int)side].LastImp = "2";
                                        decompte[(int)side].LastCor = "c";
                                        decompte[(int)side].SubWave2.End = px;
                                        decompte[(int)side].Wavec.Start = decompte[(int)side].Waveb.End;
                                        decompte[(int)side].Wavec.End = px;

                                        if (side > 0) UpCount[0] = (int)NSWavesName.V32C;
                                        else DownCount[0] = (int)NSWavesName.V32C;

                                        GetITVL(NAME_V2A, false, (int)side);
                                        GetITVL(NAME_V32A, false, (int)side);
                                        GetITVL(NAME_V32B, false, (int)side);
                                        GetITVL(NAME_V3, false, (int)side);
                                        GetPRZ(NAME_V32A, false, (int)side);
                                        GetPRZ(NAME_V3, false, (int)side);
                                    }
                                    else if (CallInside(decompte[(int)side].Wavea.Start.Price, decompte[(int)side].Wave1.Start.Price, decompte[(int)side].Wave1.End.Price, ExtVbMax, px.Price, RetV2Max, SIGNE))
                                    {
                                        px.Name = NAME_V2C;
                                        //px.SetFont(fontbig);
                                        //px.SetColor(couleur);
                                        decompte[(int)side].LastPrp = "2";
                                        decompte[(int)side].LastImp = "0";
                                        decompte[(int)side].LastCor = "c";
                                        decompte[(int)side].Wave2.End = px;
                                        decompte[(int)side].Wavec.End = px;

                                        if (side > 0) UpCount[0] = (int)NSWavesName.V2C;
                                        else DownCount[0] = (int)NSWavesName.V2C;

                                        GetITVL(NAME_V2A, false, (int)side);
                                        GetITVL(NAME_V2B, true, (int)side);
                                        GetITVL(NAME_V3, false, (int)side);
                                        GetPRZ(NAME_V2A, true, (int)side);
                                        GetPRZ(NAME_V3, false, (int)side);
                                    }
                                    else
                                    {//retour ?? 0
                                        decompte[(int)side].Reset(px);
                                        //px.SetFont(fontbig);
                                        //px.SetColor(inv_couleur);
                                        if (side > 0) UpCount[0] = (int)NSWavesName.RAZ;
                                        else DownCount[0] = (int)NSWavesName.RAZ;
                                    }
                                    #endregion
                                    break;
                            }
                            break;
                        case "3":
                            #region ----- V33. -> V34.a - x(0)
                            if (CallGreater(px.Price, RetV4Max, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.Start.Price, -1, 7, SIGNE))
                            {
                                px.Name = NAME_V34A;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "3";
                                decompte[(int)side].LastImp = "4";
                                decompte[(int)side].LastCor = "a";
                                decompte[(int)side].SubWave4.Start = decompte[(int)side].SubWave3.End;
                                decompte[(int)side].SubWave4.End = px;
                                decompte[(int)side].Wavea.Start = decompte[(int)side].SubWave3.End;
                                decompte[(int)side].Wavea.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V34A;
                                else DownCount[0] = (int)NSWavesName.V34A;

                                GetITVL(NAME_V34A, false, (int)side);
                                GetITVL(NAME_V34B, false, (int)side);
                                GetITVL(NAME_V3, false, (int)side);
                                GetPRZ(NAME_V34A, false, (int)side);
                                GetPRZ(NAME_V3, false, (int)side);
                            }
                            else
                            {
                                //V2 invalide retour ?? 0
                                decompte[(int)side].Reset(px);
                                if (side > 0) UpCount[0] = (int)NSWavesName.RAZ;
                                else DownCount[0] = (int)NSWavesName.RAZ;
                                //px.SetFont(fontbig);
                                //px.SetColor(inv_couleur);                                
                            }
                            #endregion
                            break;
                        case "4":
                            switch (decompte[(int)side].LastCor)
                            {
                                case "a":
                                case "c":
                                    #region ----- V34.a/V34.c -> V34.b - V35
                                    if (CallLower(px.Price, ExtVbMax, decompte[(int)side].SubWave3.End.Price, decompte[(int)side].SubWave3.End.Price, decompte[(int)side].SubWave3.Start.Price, -1, 4, SIGNE))
                                    {
                                        px.Name = NAME_V34B;
                                        //px.SetFont(fontsmall);
                                        //px.SetColor(couleur);
                                        decompte[(int)side].LastPrp = "3";
                                        decompte[(int)side].LastImp = "4";
                                        decompte[(int)side].LastCor = "b";
                                        decompte[(int)side].Wave3.End = px;
                                        decompte[(int)side].Waveb.Start = decompte[(int)side].Wavea.End;
                                        decompte[(int)side].Waveb.End = px;

                                        if (side > 0) UpCount[0] = (int)NSWavesName.V34B;
                                        else DownCount[0] = (int)NSWavesName.V34B;

                                        GetITVL(NAME_V34A, false, (int)side);
                                        GetITVL(NAME_V34B, false, (int)side);
                                        GetITVL(NAME_V3, false, (int)side);
                                        GetPRZ(NAME_V34A, false, (int)side);
                                        GetPRZ(NAME_V3, false, (int)side);
                                    }
                                    else
                                    {
                                        px.Name = NAME_V35;
                                        //px.SetFont(fontbig);
                                        //px.SetColor(couleur);
                                        decompte[(int)side].LastPrp = "3";
                                        decompte[(int)side].LastImp = "5";
                                        decompte[(int)side].LastCor = "0";
                                        decompte[(int)side].Wave3.End = px;
                                        decompte[(int)side].SubWave5.Start = decompte[(int)side].SubWave4.End;
                                        decompte[(int)side].SubWave5.End = px;

                                        if (side > 0) UpCount[0] = (int)NSWavesName.V35;
                                        else DownCount[0] = (int)NSWavesName.V35;

                                        GetITVL(NAME_V4A, true, (int)side);
                                        GetITVL(NAME_V4B, true, (int)side);
                                        GetPRZ(NAME_V4A, true, (int)side);
                                    }
                                    #endregion
                                    break;
                                case "b":
                                    #region ----- V34.b -> V34.c - x(0)
                                    if (CallGreater(px.Price, RetV4Max, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.Start.Price, -1, 8, SIGNE))
                                    {
                                        px.Name = NAME_V34C;
                                        //px.SetFont(fontsmall);
                                        //px.SetColor(couleur);
                                        decompte[(int)side].LastPrp = "3";
                                        decompte[(int)side].LastImp = "4";
                                        decompte[(int)side].LastCor = "c";
                                        decompte[(int)side].SubWave4.End = px;
                                        decompte[(int)side].Wavec.Start = decompte[(int)side].Waveb.End;
                                        decompte[(int)side].Wavec.End = px;

                                        if (side > 0) UpCount[0] = (int)NSWavesName.V34C;
                                        else DownCount[0] = (int)NSWavesName.V34C;

                                        GetITVL(NAME_V34A, false, (int)side);
                                        GetITVL(NAME_V34B, false, (int)side);
                                        GetITVL(NAME_V3, false, (int)side);
                                        GetPRZ(NAME_V34A, false, (int)side);
                                        GetPRZ(NAME_V3, false, (int)side);
                                    }
                                    else
                                    {
                                        //V2 invalide retour ?? 0
                                        decompte[(int)side].Reset(px);
                                        if (side > 0) UpCount[0] = (int)NSWavesName.RAZ;
                                        else DownCount[0] = (int)NSWavesName.RAZ;
                                        //px.SetFont(fontbig);
                                        //px.SetColor(inv_couleur);
                                    }
                                    #endregion
                                    break;
                                default: break;
                            }
                            break;
                        default: break;
                    }
                    #endregion
                    break;
                case "4":
                    #region --- V4abc
                    switch (decompte[(int)side].LastCor)
                    {
                        case "a":
                        case "c":
                            #region --- V4A/V4C -> V4B/V51. - V51.
                            if (CallLower(px.Price, ExtVbMax, decompte[(int)side].Wave3.End.Price, decompte[(int)side].Wave3.End.Price, decompte[(int)side].Wave3.Start.Price, -1, 5, SIGNE))
                            {
                                px.Name = NAME_V4B;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "4";
                                decompte[(int)side].LastImp = "0";
                                decompte[(int)side].LastCor = "b";
                                decompte[(int)side].Wave5.Start = decompte[(int)side].Wave4.End;
                                decompte[(int)side].Wave5.End = px;
                                decompte[(int)side].Waveb.Start = decompte[(int)side].Wave4.End;
                                decompte[(int)side].Waveb.End = px;
                                decompte[(int)side].SubWave1.Start = decompte[(int)side].Wave4.End;
                                decompte[(int)side].SubWave1.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V4B;
                                else DownCount[0] = (int)NSWavesName.V4B;

                                GetITVL(NAME_V4A, false, (int)side);
                                GetITVL(NAME_V4B, false, (int)side);
                                GetITVL(NAME_V4C, true, (int)side);
                                GetITVL(NAME_V5, false, (int)side);
                                GetPRZ(NAME_V4A, false, (int)side);
                                GetPRZ(NAME_V5, false, (int)side);
                            }
                            else
                            {
                                //sinon V51.
                                px.Name = NAME_V51;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "5";
                                decompte[(int)side].LastImp = "1";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].Wave5.Start = decompte[(int)side].Wave4.End;
                                decompte[(int)side].Wave5.End = px;
                                decompte[(int)side].SubWave1.Start = decompte[(int)side].Wave4.End;
                                decompte[(int)side].SubWave1.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V51;
                                else DownCount[0] = (int)NSWavesName.V51;

                                GetITVL(NAME_V52, true, (int)side);
                                GetITVL(NAME_V5, false, (int)side);
                                GetPRZ(NAME_V52, true, (int)side);
                                GetPRZ(NAME_V5, false, (int)side);
                            }
                            #endregion
                            break;
                        case "b":
                            #region --- V4B/V51. -> V4C - V52. - 0
                            if (CallGreater(px.Price, RetV2Max, decompte[(int)side].Wave5.End.Price, decompte[(int)side].Wave5.End.Price, decompte[(int)side].Wave5.Start.Price, -1, 9, SIGNE))
                            {
                                px.Name = NAME_V52;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "5";
                                decompte[(int)side].LastImp = "2";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].SubWave2.Start = decompte[(int)side].SubWave1.End;
                                decompte[(int)side].SubWave2.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V52;
                                else DownCount[0] = (int)NSWavesName.V52;

                                GetITVL(NAME_V52, true, (int)side);
                                GetITVL(NAME_V5, false, (int)side);
                                GetPRZ(NAME_V52, true, (int)side);
                                GetPRZ(NAME_V5, false, (int)side);
                            }
                            else if (CallGreater(px.Price, RetV4Max, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.End.Price, decompte[(int)side].Wave1.Start.Price, -1, 10, SIGNE))
                            {
                                px.Name = NAME_V4C;
                                //px.SetFont(fontbig);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "4";
                                decompte[(int)side].LastImp = "0";
                                decompte[(int)side].LastCor = "c";
                                decompte[(int)side].Wave4.End = px;
                                decompte[(int)side].Wavec.Start = decompte[(int)side].Waveb.End;
                                decompte[(int)side].Wavec.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V4C;
                                else DownCount[0] = (int)NSWavesName.V4C;

                                GetITVL(NAME_V4A, false, (int)side);
                                GetITVL(NAME_V4B, false, (int)side);
                                GetITVL(NAME_V5, false, (int)side);
                                GetPRZ(NAME_V4A, false, (int)side);
                                GetPRZ(NAME_V5, false, (int)side);
                            }
                            else
                            {
                                //retour ?? 0
                                decompte[(int)side].Reset(px);
                                //px.SetFont(fontbig);
                                //px.SetColor(couleur);
                                if (side > 0) UpCount[0] = (int)NSWavesName.RAZ;
                                else DownCount[0] = (int)NSWavesName.RAZ;
                            }
                            #endregion
                            break;
                        default: break;
                    }
                    #endregion
                    break;
                case "5":
                    #region ----- V5/0.1.2.3.4.5.
                    switch (decompte[(int)side].LastImp)
                    {
                        case "1":
                            #region ----- V51. -> V52. - VY
                            if (CallGreater(px.Price, RetV2Max, decompte[(int)side].Wave5.End.Price, decompte[(int)side].Wave5.End.Price, decompte[(int)side].Wave5.Start.Price, -1, 9, SIGNE))
                            {
                                px.Name = NAME_V52;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "5";
                                decompte[(int)side].LastImp = "2";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].SubWave2.Start = decompte[(int)side].Wave5.End;
                                decompte[(int)side].SubWave2.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V52;
                                else DownCount[0] = (int)NSWavesName.V52;

                                GetITVL(NAME_V52, false, (int)side);
                                GetITVL(NAME_V5, false, (int)side);
                                GetPRZ(NAME_V52, false, (int)side);
                                GetPRZ(NAME_V5, false, (int)side);
                            }
                            else//A
                            {
                                px.Name = NAME_V5Y;
                                //px.SetFont(fontYZ);
                                //px.SetColor(couleurYZ);
                                decompte[(int)side].LastPrp = "5";
                                decompte[(int)side].LastImp = "Y";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].WaveY.Start = decompte[(int)side].SubWave1.End;
                                decompte[(int)side].WaveY.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V5Y;
                                else DownCount[0] = (int)NSWavesName.V5Y;
                            }
                            #endregion
                            break;
                        case "2":
                            #region ----- V52. -> V53. - VZ
                            if (CallGreater(px.Price, RetV2Max, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].Wave4.End.Price, decompte[(int)side].Wave4.End.Price, 1, 11, SIGNE))
                            {
                                px.Name = NAME_V53;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "5";
                                decompte[(int)side].LastImp = "3";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].Wave5.End = px;
                                decompte[(int)side].SubWave3.Start = decompte[(int)side].SubWave2.End;
                                decompte[(int)side].SubWave3.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V53;
                                else DownCount[0] = (int)NSWavesName.V53;

                                GetITVL(NAME_V54, true, (int)side);
                                GetITVL(NAME_V5, false, (int)side);
                                GetPRZ(NAME_V54, true, (int)side);
                                GetPRZ(NAME_V5, false, (int)side);
                            }
                            else//B
                            {
                                px.Name = NAME_V5Z;
                                //px.SetFont(fontYZ);
                                //px.SetColor(couleurYZ);
                                decompte[(int)side].LastPrp = "5";
                                decompte[(int)side].LastImp = "Z";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].WaveY.End = decompte[(int)side].SubWave2.End;
                                decompte[(int)side].WaveZ.Start = decompte[(int)side].SubWave2.End;
                                decompte[(int)side].WaveZ.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V5Z;
                                else DownCount[0] = (int)NSWavesName.V5Z;

                                GetITVL(NAME_VC, true, (int)side);
                            }
                            #endregion
                            break;
                        case "3":
                            #region ----- V53. -> V54. - VY
                            if (CallGreater(px.Price, RetV4Max, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.End.Price, decompte[(int)side].SubWave1.Start.Price, -1, 12, SIGNE))
                            {
                                px.Name = NAME_V54;
                                //px.SetFont(fontsmall);
                                //px.SetColor(couleur);
                                decompte[(int)side].LastPrp = "5";
                                decompte[(int)side].LastImp = "4";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].SubWave4.Start = decompte[(int)side].SubWave3.End;
                                decompte[(int)side].SubWave4.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V54;
                                else DownCount[0] = (int)NSWavesName.V54;

                                GetITVL(NAME_V54, false, (int)side);
                                GetITVL(NAME_V5, false, (int)side);
                                GetPRZ(NAME_V54, false, (int)side);
                                GetPRZ(NAME_V5, false, (int)side);
                            }
                            else
                            {
                                px.Name = NAME_V5Y;
                                //px.SetFont(fontYZ);
                                //px.SetColor(couleurYZ);
                                decompte[(int)side].LastPrp = "5";
                                decompte[(int)side].LastImp = "Y";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].WaveY.Start = decompte[(int)side].SubWave3.End;
                                decompte[(int)side].WaveY.End = px;

                                if (side > 0) UpCount[0] = (int)NSWavesName.V5Y;
                                else DownCount[0] = (int)NSWavesName.V5Y;
                            }
                            #endregion
                            break;
                        case "4":
                            #region ----- V54. -> V55.
                            px.Name = NAME_V55;
                            //px.SetFont(fontbig);
                            //px.SetColor(couleur);
                            decompte[(int)side].LastPrp = "5";
                            decompte[(int)side].LastImp = "5";
                            decompte[(int)side].LastCor = "0";
                            decompte[(int)side].Wave5.End = px;
                            decompte[(int)side].SubWave5.Start = decompte[(int)side].SubWave4.End;
                            decompte[(int)side].SubWave5.End = px;

                            if (side > 0) UpCount[0] = (int)NSWavesName.V55;
                            else DownCount[0] = (int)NSWavesName.V55;
                            #endregion
                            break;
                        case "5":
                            #region ----- V55. -> VY
                            px.Name = NAME_V5Y;
                            //px.SetFont(fontYZ);
                            //px.SetColor(couleurYZ);
                            decompte[(int)side].LastPrp = "5";
                            decompte[(int)side].LastImp = "Y";
                            decompte[(int)side].LastCor = "0";
                            decompte[(int)side].WaveY.Start = decompte[(int)side].SubWave5.End;
                            decompte[(int)side].WaveY.End = px;

                            if (side > 0) UpCount[0] = (int)NSWavesName.V5Y;
                            else DownCount[0] = (int)NSWavesName.V5Y;
                            #endregion
                            break;
                        case "Y":
                            #region ----- VY -> VZ
                            px.Name = NAME_V5Z;
                            //px.SetFont(fontYZ);
                            //px.SetColor(couleurYZ);
                            decompte[(int)side].LastPrp = "5";
                            decompte[(int)side].LastImp = "Z";
                            decompte[(int)side].LastCor = "0";
                            decompte[(int)side].WaveZ.Start = decompte[(int)side].WaveY.End;
                            decompte[(int)side].WaveZ.End = px;

                            if (side > 0) UpCount[0] = (int)NSWavesName.V5Z;
                            else DownCount[0] = (int)NSWavesName.V5Z;

                            GetITVL(NAME_VC, true, (int)side);
                            #endregion
                            break;
                        case "Z":
                            #region ----- VZ. -> VY - 0
                            if (CallLower(px.Price, ExtVbMax, decompte[(int)side].WaveY.End.Price, decompte[(int)side].WaveY.End.Price, decompte[(int)side].WaveY.End.Price, 1, 5, SIGNE))
                            {
                                decompte[(int)side].Reset(px);
                                if (side > 0) UpCount[0] = (int)NSWavesName.RAZ;
                                else DownCount[0] = (int)NSWavesName.RAZ;
                                //px.SetFont(fontbig);
                                //px.SetColor(couleur);
                            }
                            else
                            {
                                px.Name = NAME_V5Y;
                                //px.SetFont(fontYZ);
                                //px.SetColor(couleurYZ);
                                decompte[(int)side].LastPrp = "5";
                                decompte[(int)side].LastImp = "Y";
                                decompte[(int)side].LastCor = "0";
                                decompte[(int)side].WaveY.Start = decompte[(int)side].WaveZ.End;
                                decompte[(int)side].WaveY.End = px;
                                if (side > 0) UpCount[0] = (int)NSWavesName.V5Y;
                                else DownCount[0] = (int)NSWavesName.V5Y;
                            }
                            #endregion
                            break;
                        default: break;
                    }
                    #endregion
                    break;
                default:
                    decompte[(int)side].Reset(px);
                    if (side > 0) UpCount[0] = (int)NSWavesName.RAZ;
                    else DownCount[0] = (int)NSWavesName.RAZ;
                    break;
            }
        }
        #endregion
        
        #region -- private bool Callxyz() --
        private bool CallInside(double prix, double v1, double v2, double v3, double v4, double v5, double SIGNE) { return SIGNE * prix <= SIGNE * (v2 - (v2 - v1) * v3 / 100) && SIGNE * v4 >= SIGNE * (v2 - (v2 - v1) * v5 / 100); }
        private bool CallGreater(double prix, double RET, double v2, double v3, double v4, double v5, double v6, double SIGNE)
        {
            if (v5 > 0) return SIGNE * prix >= SIGNE * (v2 + (v3 - v4) * RET / 100);
            else return SIGNE * prix >= SIGNE * (v2 - (v3 - v4) * RET / 100);
        }
        private bool CallLower(double prix, double RET, double v2, double v3, double v4, double v5, double v6, double SIGNE)
        {
            if (v5 > 0) return SIGNE * prix <= SIGNE * (v2 + (v3 - v4) * RET / 100);
            else return SIGNE * prix <= SIGNE * (v2 - (v3 - v4) * RET / 100);
        }
        #endregion

        //--------------------- Toolbar -----------------------
        #region -- Toolbar Management Utilities --
        #region -- Toolbar variables --
        private string toolbarname = "NSWavesToolBar", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private Grid indytoolbar;

        private Menu MenuControlContainer;
        private MenuItem MenuControl, btn1_RecalcIndicator;
        private TextBox nudMultiplierDTB;
        private TextBox nudSwingStrength;
        private Button gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??"
        private Button gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??"
        private Label gLabel = new Label();

        private MenuItem bulloption1, bulloption2, bullguideoption1, bullguideoption2, bullguideoption3, bullzoneoption1, bullzoneoption2;
        private MenuItem bearoption1, bearoption2, bearguideoption1, bearguideoption2, bearguideoption3, bearzoneoption1, bearzoneoption2;
		private MenuItem miShowSwingLabels;
        #endregion

        #region private void addSDVToolBar()
        private void addToolBar()
        {
			MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
			MenuControl = new MenuItem {Name="NSWaves"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Violet, Header = pButtonText, Foreground = Brushes.Violet, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);

			#region -- RegMarketStructure --
			MenuItem miMarketStructure = new MenuItem { Header = "Swing Trend Parameters", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			var miMarketStructure1 = new MenuItem { Header = "Structure Swings " + (showZZ ? "ON" : "OFF"), Name = "btMarketStructure_trends"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miMarketStructure1.Click += DisplaySettings_Click;
			miMarketStructure.Items.Add(miMarketStructure1);

			var miMarketStructureFlooding = new MenuItem { Header = "Structure Flooding " + (showZZFlooding ? "ON" : "OFF"), Name = "btMarketStructure_flooding"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miMarketStructureFlooding.Click += DisplaySettings_Click;
			miMarketStructure.Items.Add(miMarketStructureFlooding);

			var mi = new MenuItem { Header = "Sentiment Dialog "+SentimentDialogLoc.ToString(), Name = "miSentimentDialogLoc"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			mi.FontWeight = FontWeights.Normal;
			mi.Click += structureMenuItem_Click;
			miMarketStructure.Items.Add(mi);

			miShowSwingLabels = new MenuItem { Header = "Show Swing Labels "+(pShowSwingLabels ? "ON":"OFF"), Name = "showSwingLabels"+uID, HorizontalAlignment = HorizontalAlignment.Left, StaysOpenOnClick = true };
			miShowSwingLabels.Click += delegate (object o, RoutedEventArgs e){
				pShowSwingLabels = !pShowSwingLabels;
				miShowSwingLabels.Header = "Show Swing Labels "+(pShowSwingLabels ? "ON":"OFF");
				ForceRefresh();
			};
			miMarketStructure.Items.Add(miShowSwingLabels);
			//------------------
			miMarketStructure.Items.Add(createMSTMenu(MultiplierDTB.ToString(), this.SwingStrength.ToString()));

			btn1_RecalcIndicator = new MenuItem { Header = "RE-CALCULATE MARKET STRUCTURE", Name = "marketStructureClick"+uID, HorizontalAlignment = HorizontalAlignment.Center, 
				FontWeight = FontWeights.Normal,
				FontStyle = FontStyles.Normal,
				Foreground = Brushes.Black,
				Background = null
			};
			btn1_RecalcIndicator.Click += delegate (object o, RoutedEventArgs e){
				System.Windows.Forms.SendKeys.SendWait("{F5}");
				ResetRecalculationUI();
			};
			miMarketStructure.Items.Add(btn1_RecalcIndicator);
			//------------------

			MenuControl.Items.Add(miMarketStructure);
			#endregion

            #region -- Bullish Count --
            MenuItem tsmiBullishCount = new MenuItem { Header = "Bullish Count", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
            bool isMasterOn = displayLastUp || displayHistUp;

            MenuItem tsmiBullishCount0 = new MenuItem { Header = "---MASTER " + (isMasterOn ? "ON" : "OFF") + "-- - ", Name = "btBull_Master"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBullishCount0.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishCount.Items.Add(tsmiBullishCount0);

            bulloption1 = new MenuItem { Header = "Display Last Count " + (displayLastUp ? "ON" : "OFF"), Name = "btBull_last"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bulloption1.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishCount.Items.Add(bulloption1);

            bulloption2 = new MenuItem { Header = "Display Historical Counts " + (displayHistUp ? "ON" : "OFF"), Name = "btBull_hist"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bulloption2.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishCount.Items.Add(bulloption2);

            MenuItem tsmiBullishCount4 = new MenuItem { Header = "Display Count Labels " + (displayLabelsUp ? "ON" : "OFF"), Name = "btBull_label"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBullishCount4.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishCount.Items.Add(tsmiBullishCount4);

            #region ------------ Guide -------------
            MenuItem tsmiBullishGuide = new MenuItem { Header = "Guide Display", Foreground = Brushes.Black, StaysOpenOnClick = true };
            isMasterOn = displayValidUp || displayLimitUp || displayInvalidUp;

            MenuItem tsmiBullishGuide0 = new MenuItem { Header = "--- MASTER " + (isMasterOn ? "ON" : "OFF") + " ---", Name = "btBull_GuideMaster"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBullishGuide0.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishGuide.Items.Add(tsmiBullishGuide0);

            bullguideoption1 = new MenuItem { Header = "Display Validation Lines " + (displayValidUp ? "ON" : "OFF"), Name = "btBull_valid"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bullguideoption1.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishGuide.Items.Add(bullguideoption1);

            bullguideoption2 = new MenuItem { Header = "Display Limit Lines " + (displayLimitUp ? "ON" : "OFF"), Name = "btBull_limit"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bullguideoption2.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishGuide.Items.Add(bullguideoption2);

            bullguideoption3 = new MenuItem { Header = "Display Invalidation Lines " + (displayInvalidUp ? "ON" : "OFF"), Name = "btBull_invalid"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bullguideoption3.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishGuide.Items.Add(bullguideoption3);

            MenuItem tsmiBullishGuide4 = new MenuItem { Header = "Display Labels " + (displayLineLabelsUp ? "ON" : "OFF"), Name = "btBull_linelabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBullishGuide4.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishGuide.Items.Add(tsmiBullishGuide4);

            tsmiBullishCount.Items.Add(tsmiBullishGuide);
            #endregion

            #region ------------ Zone -------------
            MenuItem tsmiBullishZones = new MenuItem { Header = "Zones Display", Foreground = Brushes.Black, StaysOpenOnClick = true };
            isMasterOn = displayImpZonesUp || displayCorZonesUp;

            MenuItem tsmiBullishZones0 = new MenuItem { Header = "--- MASTER " + (isMasterOn ? "ON" : "OFF") + " ---", Name = "btBull_ZoneMaster"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBullishZones0.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishZones.Items.Add(tsmiBullishZones0);

            bullzoneoption1 = new MenuItem { Header = "Display Objective Zones " + (displayImpZonesUp ? "ON" : "OFF"), Name = "btBull_impulsive"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bullzoneoption1.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishZones.Items.Add(bullzoneoption1);

            bullzoneoption2 = new MenuItem { Header = "Display Corrective Zones " + (displayCorZonesUp ? "ON" : "OFF"), Name = "btBull_corrective"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bullzoneoption2.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishZones.Items.Add(bullzoneoption2);

            MenuItem tsmiBullishZones3 = new MenuItem { Header = "Display Zones Labels " + (displayZoneLabelsUp ? "ON" : "OFF"), Name = "btBull_zonelabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBullishZones3.Click += ModifyDisplaySettingsUpCount_Click;
            tsmiBullishZones.Items.Add(tsmiBullishZones3);

            tsmiBullishCount.Items.Add(tsmiBullishZones);
            #endregion

            MenuControl.Items.Add(tsmiBullishCount);
            #endregion

            #region -- Bearish Count --
            MenuItem tsmiBearishCount = new MenuItem { Header = "Bearish Count", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
            isMasterOn = displayLastDw || displayHistDw;

            MenuItem tsmiBearishCount0 = new MenuItem { Header = "---MASTER " + (isMasterOn ? "ON" : "OFF") + "-- - ", Name = "btBear_Master"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBearishCount0.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishCount.Items.Add(tsmiBearishCount0);

            bearoption1 = new MenuItem { Header = "Display Last Count " + (displayLastDw ? "ON" : "OFF"), Name = "btBear_last"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bearoption1.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishCount.Items.Add(bearoption1);

            bearoption2 = new MenuItem { Header = "Display Historical Counts " + (displayHistDw ? "ON" : "OFF"), Name = "btBear_hist"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bearoption2.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishCount.Items.Add(bearoption2);

            MenuItem tsmiBearishCount4 = new MenuItem { Header = "Display Count Labels " + (displayLabelsDw ? "ON" : "OFF"), Name = "btBear_label"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBearishCount4.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishCount.Items.Add(tsmiBearishCount4);

            #region ------------ Guide -------------
            MenuItem tsmiBearishGuide = new MenuItem { Header = "Guide Display", Foreground = Brushes.Black, StaysOpenOnClick = true };
            isMasterOn = displayValidDw || displayLimitDw || displayInvalidDw;

            MenuItem tsmiBearishGuide0 = new MenuItem { Header = "--- MASTER " + (isMasterOn ? "ON" : "OFF") + " ---", Name = "btBear_GuideMaster"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBearishGuide0.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishGuide.Items.Add(tsmiBearishGuide0);

            bearguideoption1 = new MenuItem { Header = "Display Validation Lines " + (displayValidDw ? "ON" : "OFF"), Name = "btBear_valid"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bearguideoption1.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishGuide.Items.Add(bearguideoption1);

            bearguideoption2 = new MenuItem { Header = "Display Limit Lines " + (displayLimitDw ? "ON" : "OFF"), Name = "btBear_limit"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bearguideoption2.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishGuide.Items.Add(bearguideoption2);

            bearguideoption3 = new MenuItem { Header = "Display Invalidation Lines " + (displayInvalidDw ? "ON" : "OFF"), Name = "btBear_invalid"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bearguideoption3.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishGuide.Items.Add(bearguideoption3);

            MenuItem tsmiBearishGuide4 = new MenuItem { Header = "Display Labels " + (displayLineLabelsDw ? "ON" : "OFF"), Name = "btBear_linelabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBearishGuide4.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishGuide.Items.Add(tsmiBearishGuide4);

            tsmiBearishCount.Items.Add(tsmiBearishGuide);
            #endregion

            #region ------------ Zone -------------
            MenuItem tsmiBearishZones = new MenuItem { Header = "Zones Display", Foreground = Brushes.Black, StaysOpenOnClick = true };
            isMasterOn = displayImpZonesDw || displayCorZonesDw;

            MenuItem tsmiBearishZones0 = new MenuItem { Header = "--- MASTER " + (isMasterOn ? "ON" : "OFF") + " ---", Name = "btBear_ZoneMaster"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBearishZones0.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishZones.Items.Add(tsmiBearishZones0);

            bearzoneoption1 = new MenuItem { Header = "Display Objective Zones " + (displayImpZonesDw ? "ON" : "OFF"), Name = "btBear_impulsive"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bearzoneoption1.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishZones.Items.Add(bearzoneoption1);

            bearzoneoption2 = new MenuItem { Header = "Display Corrective Zones " + (displayCorZonesDw ? "ON" : "OFF"), Name = "btBear_corrective"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            bearzoneoption2.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishZones.Items.Add(bearzoneoption2);

            MenuItem tsmiBearishZones3 = new MenuItem { Header = "Display Zones Labels " + (displayZoneLabelsDw ? "ON" : "OFF"), Name = "btBear_zonelabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            tsmiBearishZones3.Click += ModifyDisplaySettingsDwCount_Click;
            tsmiBearishZones.Items.Add(tsmiBearishZones3);

            tsmiBearishCount.Items.Add(tsmiBearishZones);
            #endregion

            MenuControl.Items.Add(tsmiBearishCount);
            #endregion

            indytoolbar.Children.Add(MenuControlContainer);
        }
//==========================================================================================================================
		private void InformUserAboutRecalculation(){
			btn1_RecalcIndicator.Background = Brushes.Yellow;
			btn1_RecalcIndicator.FontWeight = FontWeights.Bold;
			btn1_RecalcIndicator.FontStyle = FontStyles.Italic;
		}
		private void ResetRecalculationUI(){
			btn1_RecalcIndicator.FontWeight = FontWeights.Normal;
			btn1_RecalcIndicator.FontStyle = FontStyles.Normal;
			btn1_RecalcIndicator.Background = null;
		}
//===================================================================================================================================

        #endregion
        #region  ----- structureMenuItem_Click ----- 
        private void structureMenuItem_Click(object sender, EventArgs e)
        {
			MenuItem item = sender as MenuItem;
			#region -- Change qualifier --
//			if (item.Name.Contains("miMarketStructureQualifier"))
//			{
//				if (item.Header.ToString().Contains("OnTick")) {
//					this.StructureQualifier = ARC_Waves_StructureQualifiers.OnBarClose;
//					item.Header     = item.Header.ToString().Replace("OnTick","OnBarClose");
//					item.FontWeight = FontWeights.Normal;
//					InformUserAboutRecalculation();
//				} else {
//					this.StructureQualifier = ARC_Waves_StructureQualifiers.OnTick;
//					item.Header     = item.Header.ToString().Replace("OnBarClose","OnTick");
//					item.FontWeight = FontWeights.Normal;
//					InformUserAboutRecalculation();
//				}
//            }
            #endregion
            #region -- showMarketStructureClick --
//            if (item.Name.Contains( "miMarketStructureLines"))
//            {
//                if (item.Header.ToString().EndsWith("ON"))
//                {
//                    this.ShowStructureLines = false;
//                    item.Header     = item.Header.ToString().Replace("ON","OFF");
//					item.FontWeight = FontWeights.Light;
//                }
//                else
//                {
//                    this.ShowStructureLines = true;
//                    item.Header     = item.Header.ToString().Replace("OFF","ON");
//					item.FontWeight = FontWeights.Normal;
//                }
//            }
            #endregion
            #region -- miShowStructureBkg --
//            else if (item.Name.Contains("miShowStructureBkg"))
//            {
//                if (item.Header.ToString().EndsWith("ON"))
//                {
//                    this.ShowStructureBackground = false;
//                    item.Header     = item.Header.ToString().Replace("ON","OFF");
//					item.FontWeight = FontWeights.Light;
//					InformUserAboutRecalculation();
//                }
//                else
//                {
//                    this.ShowStructureBackground = true;
//                    item.Header     = item.Header.ToString().Replace("OFF","ON");
//					item.FontWeight = FontWeights.Normal;
//					InformUserAboutRecalculation();
//                }
//            }
            #endregion
            #region -- miShowStructureLabels --
//            else if (item.Name.Contains( "miShowStructureLabels"))
//            {
//                if (item.Header.ToString().EndsWith("ON"))
//                {
//                    this.ShowStructureLabels = false;
//                    item.Header     = item.Header.ToString().Replace("ON","OFF");
//					item.FontWeight = FontWeights.Light;
//                }
//                else
//                {
//                    this.ShowStructureLabels = true;
//                    item.Header     = item.Header.ToString().Replace("OFF","ON");
//					item.FontWeight = FontWeights.Normal;
//                }
//            }
			#endregion
			#region -- miSentimentDetectionMode --
//			else if (item.Name.Contains( "miSentimentDetectionMode"))
//			{
//			    if (item.Header.ToString().EndsWith("OFF"))
//			    {
//			        this.SentimentDetectionMode = ARC_Waves_SentimentDetectionMode.OnClose;
//			        item.Header     = item.Header.ToString().Replace("OFF","OnClose");
//					item.FontWeight = FontWeights.Normal;
//			    }
//			    else if (item.Header.ToString().EndsWith("OnClose"))
//			    {
//			        this.SentimentDetectionMode = ARC_Waves_SentimentDetectionMode.OnTick;
//			        item.Header     = item.Header.ToString().Replace("OnClose","OnTick");
//					item.FontWeight = FontWeights.Normal;
//			    }
//			    else if (item.Header.ToString().EndsWith("OnTick"))
//			    {
//			        this.SentimentDetectionMode = ARC_Waves_SentimentDetectionMode.OFF;
//			        item.Header     = item.Header.ToString().Replace("OnTick","OFF");
//					item.FontWeight = FontWeights.Light;
//			    }
//			}
			#endregion
			#region -- miSentimentDialogLoc --
			if (item.Name.Contains( "miSentimentDialogLoc"))
			{
//				if(SentimentDetectionMode == ARC_Waves_SentimentDetectionMode.OFF)
//					item.FontWeight = FontWeights.Light;
//				else
//					item.FontWeight = FontWeights.Normal;
			    if (item.Header.ToString().EndsWith("TopLeft"))
			    {
			        SentimentDialogLoc = ARC_Waves_SentimentDialogLoc.TopRight;
			        item.Header     = item.Header.ToString().Replace("TopLeft",SentimentDialogLoc.ToString());
			    }
				else if (item.Header.ToString().EndsWith("TopRight"))
			    {
			        SentimentDialogLoc = ARC_Waves_SentimentDialogLoc.Center;
			        item.Header     = item.Header.ToString().Replace("TopRight",SentimentDialogLoc.ToString());
			    }
				else if (item.Header.ToString().EndsWith("Center"))
			    {
			        SentimentDialogLoc = ARC_Waves_SentimentDialogLoc.BottomLeft;
			        item.Header     = item.Header.ToString().Replace("Center",SentimentDialogLoc.ToString());
			    }
				else if (item.Header.ToString().EndsWith("BottomLeft"))
			    {
			        SentimentDialogLoc = ARC_Waves_SentimentDialogLoc.BottomRight;
			        item.Header     = item.Header.ToString().Replace("BottomLeft",SentimentDialogLoc.ToString());
			    }
				else if (item.Header.ToString().EndsWith("BottomRight"))
			    {
			        SentimentDialogLoc = ARC_Waves_SentimentDialogLoc.None;
			        item.Header     = item.Header.ToString().Replace("BottomRight",SentimentDialogLoc.ToString());
			    }
				else if (item.Header.ToString().EndsWith("None"))
			    {
			        SentimentDialogLoc = ARC_Waves_SentimentDialogLoc.TopLeft;
			        item.Header     = item.Header.ToString().Replace("None",SentimentDialogLoc.ToString());
			    }
			}
			#endregion
			ChartControl.InvalidateVisual();
        }
        #endregion
        //------------ Misc ------------------------------------------------
        #region -- createMSTMenu(string nudValue1, string nudValue2) --
        private Grid createMSTMenu(string nudValue1, string nudValue2)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - MST1
            Label lbl1 = new Label() {Content = "Sensitivity :", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0) };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudMultiplierDTB = new TextBox() { Name = "MultiplierDTB"+uID, MinWidth = 60, Width = 60, MaxWidth = 60, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMultiplierDTB.Text = nudValue1;
            nudMultiplierDTB.KeyDown += menuTxtbox_KeyDown;
            nudMultiplierDTB.TextChanged += NumericUpDownValueChanged;
			nudMultiplierDTB.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
				double num = MultiplierDTB + (e.Delta>0 ? 0.1 : -0.1);
				bool isInRange = num>=0 && num<=999999;
				if(isInRange){
					MultiplierDTB   = num;
					nudMultiplierDTB.Text = num.ToString("0.0");
					InformUserAboutRecalculation();
					ForceRefresh();
				}
			};

            nudMultiplierDTB.SetValue(Grid.ColumnProperty, 1);
            nudMultiplierDTB.SetValue(Grid.ColumnSpanProperty, 2);
            nudMultiplierDTB.SetValue(Grid.RowProperty, 0);
            nudMultiplierDTB.SetValue(Grid.RowSpanProperty, 2);

			//line 2 - MST2
            Label lbl2 = new Label() {Content = "Strength : ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0) };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudSwingStrength = new TextBox() { Name = "SwingStrength" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudSwingStrength.Text     = nudValue2;
            nudSwingStrength.KeyDown += menuTxtbox_KeyDown;
            nudSwingStrength.TextChanged += NumericUpDownValueChanged;
			nudSwingStrength.MouseWheel  += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
				int num = pSwingStrength + (e.Delta>0 ? 1 : -1);
				bool isInRange = num>=1 && num<=100;
				if(isInRange){
					pSwingStrength = num;
					nudSwingStrength.Text = num.ToString("0");
					InformUserAboutRecalculation();
					ForceRefresh();
				}
			};

            nudSwingStrength.SetValue(Grid.ColumnProperty,  1);
            nudSwingStrength.SetValue(Grid.RowProperty,     2);
            nudSwingStrength.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = "MST2cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = "MST2cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 2);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMultiplierDTB);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudSwingStrength);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            return grid;
        }
        #endregion

        //---------- Events ------------------------------------------------
        #region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            System.Windows.Controls.TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #region private void cmdupdw_Click(object sender, RoutedEventArgs e) 
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
            Button cmd = sender as Button;
			int num = nudSwingStrength.Text.Trim()==string.Empty ? 0 : Convert.ToInt32(nudSwingStrength.Text);
            if (cmd.Name.Contains("MST2cmdup"))      {
				nudSwingStrength.Text = (Math.Min(999999999, num + 1)).ToString();
				InformUserAboutRecalculation();
			}
            else if (cmd.Name.Contains("MST2cmddw")) {
				nudSwingStrength.Text = (Math.Max(1, num - 1)).ToString();
				InformUserAboutRecalculation();
			}
        }
        #endregion

        #region private void menuTxtbox_KeyDown(object sender, KeyEventArgs e) 
        private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;

            int keyVal = (int)e.Key;
            int value = -1;
            if (keyVal >= (int)Key.D0 && keyVal <= (int)Key.D9) value = keyVal - (int)Key.D0;
            else if (keyVal >= (int)Key.NumPad0 && keyVal <= (int)Key.NumPad9) value = keyVal - (int)Key.NumPad0;

            if (value == -1) return;

            TextBox txtSender = sender as TextBox;
            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);
            if (isNumeric || e.Key == Key.Back || (e.Key == Key.Decimal && txtSender.Name.Contains("MultiplierDTB")))
            {
                string newText = value != -1 ? value.ToString() : e.Key == Key.Decimal ? System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator : "";
                int tbPosition = txtSender.SelectionStart;
                txtSender.Text = txtSender.SelectedText == "" ? txtSender.Text.Insert(tbPosition, newText) : txtSender.Text.Replace(txtSender.SelectedText, newText);
                txtSender.Select(tbPosition + 1, 0);
            }
        }
        #endregion

        #region private void NumericUpDownValueChanged(object TextChangedEventArgs, EventArgs e) 
        private void NumericUpDownValueChanged(object sender, TextChangedEventArgs e)
        {
			InformUserAboutRecalculation();
			var item = sender as TextBox;

			if(item.Name.Contains("SwingStrength")){
				if(nudSwingStrength.Text.Trim()!=string.Empty)
		            SwingStrength = Convert.ToInt32(nudSwingStrength.Text);
				else
					SwingStrength = 1;
			}
			if(item.Name.Contains("MultiplierDTB")){
				if(nudMultiplierDTB.Text.Trim()!=string.Empty)
		            MultiplierDTB = Convert.ToDouble(nudMultiplierDTB.Text);
				else
					MultiplierDTB = 0;
			}
        }
        #endregion

        #region private void ModifyDisplaySettingsUpCount_Click(object sender, EventArgs e)
        private void ModifyDisplaySettingsUpCount_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region ----------- Main -------------------
            if (item != null && item.Name.Contains("btBull_last"))
            {
                displayLastUp = !displayLastUp;
                item.Header = "Display Last Count " + (displayLastUp ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBull_hist"))
            {
                displayHistUp = !displayHistUp;
                item.Header = "Display Historical Counts " + (displayHistUp ? "ON" : "OFF");
            }
            else if (item.Name.Contains("btBull_Master"))
            {
                bool master = item.Header.ToString().Contains("ON");
                master = !master;
                displayLastUp = master;
                displayHistUp = master;

                item.Header = "--- MASTER " + (master ? "ON" : "OFF") + " ---";
                bulloption1.Header = "Display Last Count " + (displayLastUp ? "ON" : "OFF");
                bulloption2.Header = "Display Historical Counts " + (displayHistUp ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBull_label"))
            {
                displayLabelsUp = !displayLabelsUp;
                item.Header = "Display Count Labels " + (displayLabelsUp ? "ON" : "OFF");
            }
            #endregion

            #region ----------- GUIDE -------------------
            else if (item != null && item.Name.Contains("btBull_valid"))
            {
                displayValidUp = !displayValidUp;
                item.Header = "Display Validation Lines " + (displayValidUp ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBull_limit"))
            {
                displayLimitUp = !displayLimitUp;
                item.Header = "Display Limit Lines " + (displayLimitUp ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBull_invalid"))
            {
                displayInvalidUp = !displayInvalidUp;
                item.Header = "Display Invalidation Lines " + (displayInvalidUp ? "ON" : "OFF");
            }
            else if (item.Name.Contains("btBull_GuideMaster"))
            {
                bool master = item.Header.ToString().Contains("ON");
                master = !master;
                displayValidUp = master;
                displayLimitUp = master;
                displayInvalidUp = master;

                item.Header = "--- MASTER " + (master ? "ON" : "OFF") + " ---";
                bullguideoption1.Header = "Display Validation Lines " + (displayValidUp ? "ON" : "OFF");
                bullguideoption2.Header = "Display Limit Lines " + (displayLimitUp ? "ON" : "OFF");
                bullguideoption3.Header = "Display Invalidation Lines " + (displayInvalidUp ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBull_linelabels"))
            {
                displayLineLabelsUp = !displayLineLabelsUp;
                item.Header = "Display Labels " + (displayLineLabelsUp ? "ON" : "OFF");
            }
            #endregion

            #region ----------- Zones -------------------
            else if (item != null && item.Name.Contains("btBull_impulsive"))
            {
                displayImpZonesUp = !displayImpZonesUp;
                bullzoneoption1.Header = "Display Objective Zones " + (displayImpZonesUp ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBull_corrective"))
            {
                displayCorZonesUp = !displayCorZonesUp;
                bullzoneoption2.Header = "Display Corrective Zones " + (displayCorZonesUp ? "ON" : "OFF");
            }
            else if (item.Name.Contains("btBull_ZoneMaster"))
            {
                bool master = item.Header.ToString().Contains("ON");
                master = !master;
                displayImpZonesUp = master;
                displayCorZonesUp = master;

                item.Header = "--- MASTER " + (master ? "ON" : "OFF") + " ---";
                bullzoneoption1.Header = "Display Objective Zones " + (displayImpZonesUp ? "ON" : "OFF");
                bullzoneoption2.Header = "Display Corrective Zones " + (displayCorZonesUp ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBull_zonelabels"))
            {
                displayZoneLabelsUp = !displayZoneLabelsUp;
                item.Header = "Display Zones Labels " + (displayZoneLabelsUp ? "ON" : "OFF");
            }
            #endregion

            ForceRefresh();
        }
        #endregion

        #region private void ModifyDisplaySettingsDwCount_Click(object sender, EventArgs e)
        private void ModifyDisplaySettingsDwCount_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region ----------- Main -------------------
            if (item != null && item.Name.Contains("btBear_last"))
            {
                displayLastDw = !displayLastDw;
                item.Header = "Display Last Count " + (displayLastDw ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBear_hist"))
            {
                displayHistDw = !displayHistDw;
                item.Header = "Display Historical Counts " + (displayHistDw ? "ON" : "OFF");
            }
            else if (item.Name.Contains("btBear_Master"))
            {
                bool master = item.Header.ToString().Contains("ON");
                master = !master;
                displayLastDw = master;
                displayHistDw = master;

                item.Header = "--- MASTER " + (master ? "ON" : "OFF") + " ---";
                bulloption1.Header = "Display Last Count " + (displayLastDw ? "ON" : "OFF");
                bulloption2.Header = "Display Historical Counts " + (displayHistDw ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBear_label"))
            {
                displayLabelsDw = !displayLabelsDw;
                item.Header = "Display Count Labels " + (displayLabelsDw ? "ON" : "OFF");
            }
            #endregion

            #region ----------- GUIDE -------------------
            else if (item != null && item.Name.Contains("btBear_valid"))
            {
                displayValidDw = !displayValidDw;
                item.Header = "Display Validation Lines " + (displayValidDw ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBear_limit"))
            {
                displayLimitDw = !displayLimitDw;
                item.Header = "Display Limit Lines " + (displayLimitDw ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBear_invalid"))
            {
                displayInvalidDw = !displayInvalidDw;
                item.Header = "Display Invalidation Lines " + (displayInvalidDw ? "ON" : "OFF");
            }
            else if (item.Name.Contains("btBear_GuideMaster"))
            {
                bool master = item.Header.ToString().Contains("ON");
                master = !master;
                displayValidDw = master;
                displayLimitDw = master;
                displayInvalidDw = master;

                item.Header = "--- MASTER " + (master ? "ON" : "OFF") + " ---";
                bullguideoption1.Header = "Display Validation Lines " + (displayValidDw ? "ON" : "OFF");
                bullguideoption2.Header = "Display Limit Lines " + (displayLimitDw ? "ON" : "OFF");
                bullguideoption3.Header = "Display Invalidation Lines " + (displayInvalidDw ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBear_linelabels"))
            {
                displayLineLabelsDw = !displayLineLabelsDw;
                item.Header = "Display Labels " + (displayLineLabelsDw ? "ON" : "OFF");
            }
            #endregion

            #region ----------- Zones -------------------
            else if (item != null && item.Name.Contains("btBear_impulsive"))
            {
                displayImpZonesDw = !displayImpZonesDw;
                bearzoneoption1.Header = "Display Objective Zones " + (displayImpZonesDw ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBear_corrective"))
            {
                displayCorZonesDw = !displayCorZonesDw;
                bearzoneoption2.Header = "Display Corrective Zones " + (displayCorZonesDw ? "ON" : "OFF");
            }
            else if (item.Name.Contains("btBear_ZoneMaster"))
            {
                bool master = item.Header.ToString().Contains("ON");
                master = !master;
                displayImpZonesDw = master;
                displayCorZonesDw = master;

                item.Header = "--- MASTER " + (master ? "ON" : "OFF") + " ---";
                bearzoneoption1.Header = "Display Objective Zones " + (displayImpZonesDw ? "ON" : "OFF");
                bearzoneoption2.Header = "Display Corrective Zones " + (displayCorZonesDw ? "ON" : "OFF");
            }
            else if (item != null && item.Name.Contains("btBear_zonelabels"))
            {
                displayZoneLabelsDw = !displayZoneLabelsDw;
                item.Header = "Display Zones Labels " + (displayZoneLabelsDw ? "ON" : "OFF");
            }
            #endregion

            ForceRefresh();
        }
        #endregion

        #region private void mstMenuItem_Click(object sender, EventArgs e) 
        private void DisplaySettings_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            #region -- showMarketStructureClick --
            if (item.Name.Contains("btMarketStructure_trends"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.showZZ = false;
                    item.Header = "Structure Swings OFF";
                }
                else
                {
                    this.showZZ = true;
                    item.Header = "Structure Swings ON";
                }
            }
            #endregion

            #region -- showMarketStructureFloodingClick --
            if (item.Name.Contains("btMarketStructure_flooding"))
            {
                if (item.Header.ToString().Contains("ON"))
                {
                    this.showZZFlooding = false;
                    item.Header = "Structure Flooding OFF";
                }
                else
                {
                    this.showZZFlooding = true;
                    item.Header = "Structure Flooding ON";
                }
//				if(showZZFlooding && pzzTrendBkgOpacity>0){
//					zzTrendUpBkgBrush = Brushes.Green.Clone();
//					zzTrendUpBkgBrush.Opacity = pzzTrendBkgOpacity / 10.0;
//					zzTrendUpBkgBrush.Freeze();
//					zzTrendDownBkgBrush = Brushes.Maroon.Clone();
//					zzTrendDownBkgBrush.Opacity = pzzTrendBkgOpacity / 10.0;
//					zzTrendDownBkgBrush.Freeze();
//  //Print("Opacity: "+zzTrendUpBkgBrush.Opacity);
//				}else{
//					zzTrendUpBkgBrush = null;
//					zzTrendDownBkgBrush = null;
//				}
            }
            #endregion
            ForceRefresh();
        }
        #endregion

        #endregion

        //--------------------- Properties ------------------
        #region -- DataSeries --- 
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> UpCount { get {return Values[0]; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> DownCount { get {return Values[1]; } }
        #endregion
		
        #region -- Parameters --
        #region -- SwingTrend Parameters --
        [NinjaScriptProperty]
        [Display(Name = "Use Highs/Lows", GroupName = "SwingTrend Parameters", Description = "Use High/Lows or Input", Order = 30)]
        public bool useHL { get; set; }

		private int pSwingStrength = 3;
        [NinjaScriptProperty]
        [Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 0)]
        public int SwingStrength
		{	get { return pSwingStrength; }
			set { pSwingStrength = Math.Max(1,value); }
		}
        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Deviation multiplier", GroupName = "SwingTrend Parameters", Description = "Multiplier used to calculate minimum deviation as an ATR multiple, only used when you uncheck 'Use Highs/Lows'", Order = 10)]
        public double MultiplierMD { get; set; }

        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Sensitivity double tops/bottoms", GroupName = "SwingTrend Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 20)]
        public double MultiplierDTB { get; set; }

		[Display(Name = "Location", GroupName = "SwingTrend Parameters", Description = "Location (on chart) of the sentiment dialog", Order = 40)]
		public ARC_Waves_SentimentDialogLoc SentimentDialogLoc { get; set; }

		[Display(Name = "Verbose", GroupName = "SwingTrend Parameters", Description = "Verbose = true means the Sentiment Dialog will contain the headings", Order = 50)]
		public bool VerboseSentimentDialog { get; set; }

        #endregion
		
		#region -- StructureDetector --
		[Display(Name = "Font", GroupName = "StructureDetector Parameters", Description = "Font for structure detector dialog", Order = 30)]
		public SimpleFont StructureDialogFont {get; set;}

		[XmlIgnore]
		[Display(Name = "Up Text color", GroupName = "StructureDetector Parameters", Description = "Color of text of up-biased structure dialog box", Order = 40)]
		public Brush StructureDialogText_UpBrush { get; set; }
		[XmlIgnore]
		[Display(Name = "Down Text color", GroupName = "StructureDetector Parameters", Description = "Color of text of down-biased structure dialog box", Order = 50)]
		public Brush StructureDialogText_DownBrush { get; set; }

		[XmlIgnore]
		[Display(Name = "Up Bkg color", GroupName = "StructureDetector Parameters", Description = "Color of background of up-biased structure dialog box", Order = 60)]
		public Brush StructureDialogBkg_UpBrush { get; set; }
		[Range(0, 100)]
		[Display(Name = "Up Bkg Opacity", GroupName = "StructureDetector Parameters", Description = "Opacity of background coloron UP structure", Order = 70)]
		public int StructureDialogBkg_UpOpacity { get; set; }

		[XmlIgnore]
		[Display(Name = "Down Bkg color", GroupName = "StructureDetector Parameters", Description = "Color of background of down-biased structure dialog box", Order = 80)]
		public Brush StructureDialogBkg_DownBrush { get; set; }
		[Range(0, 100)]
		[Display(Name = "Down Bkg Opacity", GroupName = "StructureDetector Parameters", Description = "Opacity of background coloron UP structure", Order = 90)]
		public int StructureDialogBkg_DownOpacity { get; set; }
		#endregion

		#region brush serializers
			[Browsable(false)]
			public string SDetector_UpBkgTrendColorSerialize
			{get { return Serialize.BrushToString(StructureDialogBkg_UpBrush); }
                                        set { StructureDialogBkg_UpBrush = Serialize.StringToBrush(value); }}
			[Browsable(false)]
			public string SDetector_DnBkgTrendColorSerialize
			{get { return Serialize.BrushToString(StructureDialogBkg_DownBrush); }
                                        set { StructureDialogBkg_DownBrush = Serialize.StringToBrush(value); }}
			[Browsable(false)]
			public string SDetector_UpTextTrendColorSerialize
			{get { return Serialize.BrushToString(StructureDialogText_UpBrush); }
                                        set { StructureDialogText_UpBrush = Serialize.StringToBrush(value); }}
			[Browsable(false)]
			public string SDetector_DnTextTrendColorSerialize
			{get { return Serialize.BrushToString(StructureDialogText_DownBrush); }
                                        set { StructureDialogText_DownBrush = Serialize.StringToBrush(value); }}
		#endregion

        #region -- SwingTrend Display --
        [Display(Name = "Display Swing Trends", GroupName = "SwingTrend Display", Description = "Display Swing Trends", Order = 0)]
        public bool showZZ { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Swing Trends Width", GroupName = "SwingTrend Display", Description = "Swing Trends Width", Order = 10)]
        public int zzwidth { get; set; }

        [XmlIgnore]
        [Display(Name = "Swing Trends Color", GroupName = "SwingTrend Display", Description = "Swing Trends Color", Order = 20)]
        public Brush zzColor { get; set; }
        [Browsable(false)]
        public string zzColorSerialize
        {get { return Serialize.BrushToString(zzColor); }
                                        set { zzColor = Serialize.StringToBrush(value); }}

        [Display(Name = "Display Swing Labels", GroupName = "SwingTrend Display", Description = "Swing labels 'HH','LL'", Order = 30)]
        public bool pShowSwingLabels { get; set; }

        [Display(Name = "Separation Swing Labels", GroupName = "SwingTrend Display", Description = "Distance (pixels) of swing labels from nodes", Order = 35)]
		public int pTextOffset {get;set;}

		[Display(Name = "Swing Labels Font", GroupName = "SwingTrend Display", Description = "Choose your font style swing label text.", Order = 40)]
		public SimpleFont SwingLabelFont { get; set; }

		[XmlIgnore]
		[Display(Name = "Upswing Color", GroupName = "SwingTrend Display", Description = "Select color for uptrend", Order = 1)]
		public Brush iUpBrush { get; set; }
		[Browsable(false)]
		public string UpColorColorSerialize
		{	get {  return Serialize.BrushToString(iUpBrush); }
											set { iUpBrush = Serialize.StringToBrush(value); }        }

		[XmlIgnore]
		[Display(Name = "Downswing Color", GroupName = "SwingTrend Display", Description = "Select color for downtrend", Order = 2)]
		public Brush iDownBrush { get; set; }
		[Browsable(false)]
		public string downColorSerialize
		{	get { return Serialize.BrushToString(iDownBrush); }
										   set { iDownBrush = Serialize.StringToBrush(value); }        }

		[XmlIgnore]
		[Display(Name = "Double Top/Bottom Color", GroupName = "SwingTrend Display", Description = "Select color for double tops and double bottoms", Order = 3)]
		public Brush iNeutralBrush { get; set; }
		[Browsable(false)]
		public string NeutralColorSerialize
		{	get { return Serialize.BrushToString(iNeutralBrush); }
										   set { iNeutralBrush = Serialize.StringToBrush(value); }        }

		[Display(Name = "Flood color on trends?", GroupName = "SwingTrend Trend Display", Description = "Display Swing Trends with background color", Order = 0)]
        public bool showZZFlooding { get; set; }

        [Range(0, 10)]
        [Display(Name = "Flooding Color Opacity", GroupName = "SwingTrend Trend Display", Description = "Opacity of background color for trend flooding", Order = 1)]
        public int pzzTrendBkgOpacity { get; set; }

		[XmlIgnore]
        [Display(Name = "Bkg Up Trend", GroupName = "SwingTrend Trend Display", Description = "Color of background when up-trend structure is present", Order = 2)]
        public Brush pBkgUpColor { get; set; }
        [Browsable(false)]
        public string pBkgUpColorSerialize
        {get { return Serialize.BrushToString(pBkgUpColor); }
                                        set { pBkgUpColor = Serialize.StringToBrush(value); }}

        [XmlIgnore]
        [Display(Name = "Bkg Down Trend", GroupName = "SwingTrend Trend Display", Description = "Color of background when down-trend structure is present", Order = 3)]
        public Brush pBkgDownColor { get; set; }
        [Browsable(false)]
        public string pBkgDownColorSerialize
        {get { return Serialize.BrushToString(pBkgDownColor); }
                                        set { pBkgDownColor = Serialize.StringToBrush(value); }}

		#endregion

        #region -- Countdown Display --
        [Display(Name = "Countdown Font", GroupName = "Countdown Display", Description = "Countdown Font", Order = 0)]
        public SimpleFont countFont { get; set; }

        [XmlIgnore]
        [Display(Name = "Bullish Countdown Color", GroupName = "Countdown Display", Description = "Bullish Countdown Color", Order = 1)]
        public Brush ColDecUP { get; set; }
        [Browsable(false)]
        public string ColDecUPSerialize
        {
            get { return Serialize.BrushToString(ColDecUP); }
            set { ColDecUP = Serialize.StringToBrush(value); }
        }
        [Display(Name = "Display Current Bullish Countdown", GroupName = "Countdown Display", Description = "Display Current Bullish Countdown", Order = 2)]
        public bool displayLastUp { get; set; }
        [Display(Name = "Display Historical Bullish Countdown", GroupName = "Countdown Display", Description = "Display Historical Bullish Countdown", Order = 3)]
        public bool displayHistUp { get; set; }
        [Display(Name = "Display Bullish Waves Labels", GroupName = "Countdown Display", Description = "Display Bullish Waves Labels", Order = 4)]
        public bool displayLabelsUp { get; set; }

        [XmlIgnore]
        [Display(Name = "Bearish Countdown Color", GroupName = "Countdown Display", Description = "Bearish Countdown Color", Order = 5)]
        public Brush ColDecDW { get; set; }
        [Browsable(false)]
        public string ColDecDWSerialize
        {
            get { return Serialize.BrushToString(ColDecDW); }
            set { ColDecDW = Serialize.StringToBrush(value); }
        }
        [Display(Name = "Display Current Bearish Countdown", GroupName = "Countdown Display", Description = "Display Current Bearish Countdown", Order = 7)]
        public bool displayLastDw { get; set; }
        [Display(Name = "Display Historical Bearish Countdown", GroupName = "Countdown Display", Description = "Display Historical Bearish Countdown", Order = 8)]
        public bool displayHistDw { get; set; }
        [Display(Name = "Display Bearish Waves Labels", GroupName = "Countdown Display", Description = "Display Bearish Waves Labels", Order = 9)]
        public bool displayLabelsDw { get; set; }
        #endregion

        #region -- Guides Display --
        [Display(Name = "Guides Font", GroupName = "Guides Display", Description = "Guides Font", Order = 0)]
        public SimpleFont ivlFont { get; set; }
        [Range(0, 100)]
        [Display(Name = "Tags Transparency", GroupName = "Guides Display", Description = "Guide Tags Transparency", Order = 1)]
        public int ivlAlpha { get; set; }
        [Range(1, 100)]
        [Display(Name = "Guide Lines Thickness", GroupName = "Guides Display", Description = "Guide Lines Thickness", Order = 2)]
        public int ilvThickness { get; set; }

        //--- Bullish
        [Display(Name = "Bullish Validation Levels", GroupName = "Guides Display", Description = "Display Guides for Bullish Validation Levels", Order = 13)]
        public bool displayValidUp { get; set; }
        [Display(Name = "Bullish Limit Levels", GroupName = "Guides Display", Description = "Display Guides for Bullish Limit Levels", Order = 14)]
        public bool displayLimitUp { get; set; }
        [Display(Name = "Bullish Invalidation Levels", GroupName = "Guides Display", Description = "Display Guides for Bullish Invalidation Levels", Order = 15)]
        public bool displayInvalidUp { get; set; }

        [XmlIgnore]
        [Display(Name = "Bullish Validation Color", GroupName = "Guides Display", Description = "Bullish Validation Color", Order = 16)]
        public Brush ColVLUP { get; set; }
        [Browsable(false)]
        public string ColVLUPSerialize
        {
            get { return Serialize.BrushToString(ColVLUP); }
            set { ColVLUP = Serialize.StringToBrush(value); }
        }
        [XmlIgnore]
        [Display(Name = "Bullish Limit Color", GroupName = "Guides Display", Description = "Bullish Limit Color", Order = 17)]
        public Brush ColTLUP { get; set; }
        [Browsable(false)]
        public string ColTLUPSerialize
        {
            get { return Serialize.BrushToString(ColTLUP); }
            set { ColTLUP = Serialize.StringToBrush(value); }
        }
        [XmlIgnore]
        [Display(Name = "Bullish Invalidation Color", GroupName = "Guides Display", Description = "Bullish Invalidation Color", Order = 18)]
        public Brush ColILUP { get; set; }
        [Browsable(false)]
        public string ColILUPSerialize
        {
            get { return Serialize.BrushToString(ColILUP); }
            set { ColILUP = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Bullish Guides Labels", GroupName = "Guides Display", Description = "Display Bullish Guides Labels", Order = 19)]
        public bool displayLineLabelsUp { get; set; }

        //--- Bearish
        [Display(Name = "Bearish Validation Levels", GroupName = "Guides Display", Description = "Display Guides for Bearish Validation Levels", Order = 23)]
        public bool displayValidDw { get; set; }
        [Display(Name = "Bearish Limit Levels", GroupName = "Guides Display", Description = "Display Guides for Bearish Limit Levels", Order = 24)]
        public bool displayLimitDw { get; set; }
        [Display(Name = "Bearish Invalidation Levels", GroupName = "Guides Display", Description = "Display Guides for Bearish Invalidation Levels", Order = 25)]
        public bool displayInvalidDw { get; set; }

        [XmlIgnore]
        [Display(Name = "Bearish Validation Color", GroupName = "Guides Display", Description = "Bearish Validation Color", Order = 26)]
        public Brush ColVLDW { get; set; }
        [Browsable(false)]
        public string ColVLDWSerialize
        {
            get { return Serialize.BrushToString(ColVLDW); }
            set { ColVLDW = Serialize.StringToBrush(value); }
        }
        [XmlIgnore]
        [Display(Name = "Bearish Limit Color", GroupName = "Guides Display", Description = "Bearish Limit Color", Order = 27)]
        public Brush ColTLDW { get; set; }
        [Browsable(false)]
        public string ColTLDWSerialize
        {
            get { return Serialize.BrushToString(ColTLDW); }
            set { ColTLDW = Serialize.StringToBrush(value); }
        }
        [XmlIgnore]
        [Display(Name = "Bearish Invalidation Color", GroupName = "Guides Display", Description = "Bearish Invalidation Color", Order = 28)]
        public Brush ColILDW { get; set; }
        [Browsable(false)]
        public string ColILDWSerialize
        {
            get { return Serialize.BrushToString(ColILDW); }
            set { ColILDW = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Bearish Guides Labels", GroupName = "Guides Display", Description = "Display Bearish Guides Labels", Order = 29)]
        public bool displayLineLabelsDw { get; set; }
        #endregion

        #region -- Zones Display --
        [Display(Name = "Zones Font", GroupName = "Zones Display", Description = "Zones Font", Order = 0)]
        public SimpleFont zoneFont { get; set; }
        [Range(0, 100)]
        [Display(Name = "Zones Tags Transparency", GroupName = "Zones Display", Description = "Zones Transparency", Order = 1)]
        public int zoneAlpha { get; set; }


        //--- Bullish
        [Display(Name = "Bullish Objective Zones", GroupName = "Zones Display", Description = "Display Objective Zones for Bullish Countdown", Order = 11)]
        public bool displayImpZonesUp { get; set; }
        [Display(Name = "Bullish Corrective Zones", GroupName = "Zones Display", Description = "Display Corrective Zones for Bullish Countdown", Order = 12)]
        public bool displayCorZonesUp { get; set; }
        [Display(Name = "Bullish Countdown Zones Labels", GroupName = "Zones Display", Description = "Display Zones Labels for Bullish Countdown", Order = 13)]
        public bool displayZoneLabelsUp { get; set; }

        [XmlIgnore]
        [Display(Name = "Bullish Retracement Zones Color", GroupName = "Zones Display", Description = "Bullish Retracement Zones Color", Order = 14)]
        public Brush ColZVRetUP { get; set; }
        [Browsable(false)]
        public string ColZVRetUPSerialize
        {
            get { return Serialize.BrushToString(ColZVRetUP); }
            set { ColZVRetUP = Serialize.StringToBrush(value); }
        }
        [XmlIgnore]
        [Display(Name = "Bullish Impulsive Zones Color", GroupName = "Zones Display", Description = "Bullish Impulsive Zones Color", Order = 15)]
        public Brush ColZVImpUP { get; set; }
        [Browsable(false)]
        public string ColZVImpUPSerialize
        {
            get { return Serialize.BrushToString(ColZVImpUP); }
            set { ColZVImpUP = Serialize.StringToBrush(value); }
        }

        //--- Bearish
        [Display(Name = "Bearish Objective Zones", GroupName = "Zones Display", Description = "Display Objective Zones for Bearish Countdown", Order = 21)]
        public bool displayImpZonesDw { get; set; }
        [Display(Name = "Bearish Corrective Zones", GroupName = "Zones Display", Description = "Display Corrective Zones for Bearish Countdown", Order = 22)]
        public bool displayCorZonesDw { get; set; }
        [Display(Name = "Bearish Countdown Zones Labels", GroupName = "Zones Display", Description = "Display Zones Labels for Bearish Countdown", Order = 23)]
        public bool displayZoneLabelsDw { get; set; }

        [XmlIgnore]
        [Display(Name = "Bearish Retracement Zones Color", GroupName = "Zones Display", Description = "Bearish Retracement Zones Color", Order = 24)]
        public Brush ColZVRetDW { get; set; }
        [Browsable(false)]
        public string ColZVRetDWSerialize
        {
            get { return Serialize.BrushToString(ColZVRetDW); }
            set { ColZVRetDW = Serialize.StringToBrush(value); }
        }
        [XmlIgnore]
        [Display(Name = "Bearish Impulsive Zones Color", GroupName = "Zones Display", Description = "Bearish Impulsive Zones Color", Order = 25)]
        public Brush ColZVImpDW { get; set; }
        [Browsable(false)]
        public string ColZVImpDWSerialize
        {
            get { return Serialize.BrushToString(ColZVImpDW); }
            set { ColZVImpDW = Serialize.StringToBrush(value); }
        }
        #endregion

        #region -- Vague2 --
        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Max Retracement (%)", GroupName = "Wave 2", Description = "", Order = 10)]
        public double RetV2Max { get; set; }

        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Min Zone retracement", GroupName = "Wave 2", Description = "", Order = 11)]
        public double ObjV2min { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Max Zone retracement", GroupName = "Wave 2", Description = "", Order = 12)]
        public double ObjV2max { get; set; }
        #endregion

        #region -- Vague3 --
        [NinjaScriptProperty]
        [Display(Name = "Min Projection (%)", GroupName = "Wave 3", Description = "", Order = 11)]
        public double ExtV3Min { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Min Zone Projection", GroupName = "Wave 3", Description = "", Order = 12)]
        public double ObjV3min { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Max Zone Projection", GroupName = "Wave 3", Description = "", Order = 13)]
        public double ObjV3max { get; set; }
        #endregion

        #region -- Vague4 --
        [NinjaScriptProperty]
        [Display(Name = "% of W1 overlap", GroupName = "Wave 4", Description = "", Order = 11)]
        public double RetV4Max { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Min Zone retracement", GroupName = "Wave 4", Description = "", Order = 12)]
        public double ObjV4min { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Max Zone retracement", GroupName = "Wave 4", Description = "", Order = 13)]
        public double ObjV4max { get; set; }
        #endregion

        #region -- Vague5 --
        [NinjaScriptProperty]
        [Display(Name = "Min Projection (%)", GroupName = "Wave 5", Description = "", Order = 10)]
        public double ExtV5Min { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Min Zone Projection", GroupName = "Wave 5", Description = "", Order = 11)]
        public double ObjV5min { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Max Zone Projection", GroupName = "Wave 5", Description = "", Order = 12)]
        public double ObjV5max { get; set; }
        #endregion

        #region -- Vague abc --
        [NinjaScriptProperty]
        [Display(Name = "Wave b Max Extension (%)", GroupName = "Wave abc", Description = "", Order = 1)]
        public double ExtVbMax { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Wave c Min Retracement (%)", GroupName = "Wave abc", Description = "", Order = 2)]
        public double RetVcMin { get; set; }
			
        #endregion
		[Description("Button text - enter how you want the UI button to be labeled")]
		[Display(Order = 10, Name = "Button Txt",  GroupName = "Visuals", ResourceType = typeof(Custom.Resource))]
		public string pButtonText {get;set;}

		/*
	    * JQ 11.12.2017
	    * Added indicator version number on the property window.
        * */
		//---start--
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }
		//--end--	

        #endregion
    }
}

#region namespace ARC_Waves
namespace ARC_Waves
{
	#region public class Pivot
	public class Pivot
	{
		private string name;
		public string Name { get { return name; } set { name = value; } }
		private DateTime date;
		public DateTime Date { get { return date; } set { date = value; } }
		private int barSlotFound;
		public int BarSlotFound { get { return barSlotFound; } set { barSlotFound = value; } }
		private int pivotBarSlot;
		public int PivotBarSlot { get { return pivotBarSlot; } set { pivotBarSlot = value; } }
		private double price;
		public double Price { get { return price; } set { price = value; } }
		private bool isPeak;
		public bool IsPeak { get { return isPeak; } set { isPeak = value; } }
		public int SwingType;

// DT(99), DB(-99), HH(1) or LH{2), LL(-1), LH(-2}
		public Pivot() { }
		public Pivot(int barslotfound, int pivotbarslot, DateTime date, double price, bool ispeak, int swingType){
			barSlotFound = barslotfound;
			pivotBarSlot = pivotbarslot;
			this.date  = date;
			this.price = price;
			this.name  = "";
			isPeak     = ispeak;
			SwingType  = swingType;
		}
		public Pivot(int barslotfound, int pivotbarslot, DateTime date, double price, bool ispeak) : this(barslotfound, pivotbarslot, date, price, ispeak, "") { }
		public Pivot(int barslotfound, int pivotbarslot, DateTime date, double price, bool ispeak, string name)
		{
			barSlotFound = barslotfound;
			pivotBarSlot = pivotbarslot;
			this.date  = date;
			this.price = price;
			this.name  = name;
			isPeak     = ispeak;
			SwingType  = int.MinValue;
        }
    }
    #endregion

    #region public class Wave
    public class Wave
    {
        private Pivot start;
        private Pivot end;

        public Pivot Start { get { return start; } set { start = value; } }
        public Pivot End { get { return end; } set { end = value; } }

        public Wave()
        {
            start = new Pivot();
            end = new Pivot();
        }
    }
    #endregion

    #region public class Countdown
    public class Countdown
    {
        private string lastPrp = "";
        public string LastPrp { get { return lastPrp; } set { lastPrp = value; } }
        private string lastCor = "";
        public string LastCor { get { return lastCor; } set { lastCor = value; } }
        private string lastImp = "";
        public string LastImp { get { return lastImp; } set { lastImp = value; } }

        private Wave w1;
        public Wave Wave1 { get { return w1; } set { w1 = value; } }
        private Wave w2;
        public Wave Wave2 { get { return w2; } set { w2 = value; } }
        private Wave w3;
        public Wave Wave3 { get { return w3; } set { w3 = value; } }
        private Wave w4;
        public Wave Wave4 { get { return w4; } set { w4 = value; } }
        private Wave w5;
        public Wave Wave5 { get { return w5; } set { w5 = value; } }
        private Wave wa;
        public Wave Wavea { get { return wa; } set { wa = value; } }
        private Wave wb;
        public Wave Waveb { get { return wb; } set { wb = value; } }
        private Wave wc;
        public Wave Wavec { get { return wc; } set { wc = value; } }

        private Wave subw1;
        public Wave SubWave1 { get { return subw1; } set { subw1 = value; } }
        private Wave subw2;
        public Wave SubWave2 { get { return subw2; } set { subw2 = value; } }
        private Wave subw3;
        public Wave SubWave3 { get { return subw3; } set { subw3 = value; } }
        private Wave subw4;
        public Wave SubWave4 { get { return subw4; } set { subw4 = value; } }
        private Wave subw5;
        public Wave SubWave5 { get { return subw5; } set { subw5 = value; } }

        private Wave vx;
        public Wave WaveX { get { return vx; } set { vx = value; } }
        private Wave vy;
        public Wave WaveY { get { return vy; } set { vy = value; } }
        private Wave vz;
        public Wave WaveZ { get { return vz; } set { vz = value; } }

        public Countdown() : this(null) { }
        public Countdown(Pivot pivot)
        {
            this.w1 = new Wave();
            this.w2 = new Wave();
            this.w3 = new Wave();
            this.w4 = new Wave();
            this.w5 = new Wave();
            this.wa = new Wave();
            this.wb = new Wave();
            this.wc = new Wave();
            this.subw1 = new Wave();
            this.subw2 = new Wave();
            this.subw3 = new Wave();
            this.subw4 = new Wave();
            this.subw5 = new Wave();
            this.vx = new Wave();
            this.vy = new Wave();
            this.vz = new Wave();

            Reset(pivot);
        }
        public void Reset(Pivot pivot)
        {
            this.lastPrp = "0";
            this.LastCor = "0";
            this.LastImp = "0";
            if (pivot != null)
            {
                pivot.Name = "0";
                w1.Start = pivot;
            }
        }
    }
    #endregion

    #region public class ElliottPivot
    public class ElliottPivot : Pivot
    {
        private Dictionary<string, double[]> ivl;
        private Dictionary<string, double[]> zones;

        public Dictionary<string, double[]> IVL { get { return ivl; } set { ivl = value; } }
        public Dictionary<string, double[]> Zones { get { return zones; } set { zones = value; } }

        public ElliottPivot(Pivot pivot)
        {
            ivl = new Dictionary<string, double[]>(4);
            zones = new Dictionary<string, double[]>(2);
            base.BarSlotFound = pivot.BarSlotFound;
            base.PivotBarSlot = pivot.PivotBarSlot;
            base.Date = pivot.Date;
            base.Name = pivot.Name;
            base.Price = pivot.Price;
            base.IsPeak = pivot.IsPeak;
			base.SwingType = pivot.SwingType;
        }
    }
    #endregion
}
#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_Waves[] cacheARC_Waves;
		public ARC.ARC_Waves ARC_Waves(bool useHL, int swingStrength, double multiplierMD, double multiplierDTB, double retV2Max, double objV2min, double objV2max, double extV3Min, double objV3min, double objV3max, double retV4Max, double objV4min, double objV4max, double extV5Min, double objV5min, double objV5max, double extVbMax, double retVcMin)
		{
			return ARC_Waves(Input, useHL, swingStrength, multiplierMD, multiplierDTB, retV2Max, objV2min, objV2max, extV3Min, objV3min, objV3max, retV4Max, objV4min, objV4max, extV5Min, objV5min, objV5max, extVbMax, retVcMin);
		}

		public ARC.ARC_Waves ARC_Waves(ISeries<double> input, bool useHL, int swingStrength, double multiplierMD, double multiplierDTB, double retV2Max, double objV2min, double objV2max, double extV3Min, double objV3min, double objV3max, double retV4Max, double objV4min, double objV4max, double extV5Min, double objV5min, double objV5max, double extVbMax, double retVcMin)
		{
			if (cacheARC_Waves != null)
				for (int idx = 0; idx < cacheARC_Waves.Length; idx++)
					if (cacheARC_Waves[idx] != null && cacheARC_Waves[idx].useHL == useHL && cacheARC_Waves[idx].SwingStrength == swingStrength && cacheARC_Waves[idx].MultiplierMD == multiplierMD && cacheARC_Waves[idx].MultiplierDTB == multiplierDTB && cacheARC_Waves[idx].RetV2Max == retV2Max && cacheARC_Waves[idx].ObjV2min == objV2min && cacheARC_Waves[idx].ObjV2max == objV2max && cacheARC_Waves[idx].ExtV3Min == extV3Min && cacheARC_Waves[idx].ObjV3min == objV3min && cacheARC_Waves[idx].ObjV3max == objV3max && cacheARC_Waves[idx].RetV4Max == retV4Max && cacheARC_Waves[idx].ObjV4min == objV4min && cacheARC_Waves[idx].ObjV4max == objV4max && cacheARC_Waves[idx].ExtV5Min == extV5Min && cacheARC_Waves[idx].ObjV5min == objV5min && cacheARC_Waves[idx].ObjV5max == objV5max && cacheARC_Waves[idx].ExtVbMax == extVbMax && cacheARC_Waves[idx].RetVcMin == retVcMin && cacheARC_Waves[idx].EqualsInput(input))
						return cacheARC_Waves[idx];
			return CacheIndicator<ARC.ARC_Waves>(new ARC.ARC_Waves(){ useHL = useHL, SwingStrength = swingStrength, MultiplierMD = multiplierMD, MultiplierDTB = multiplierDTB, RetV2Max = retV2Max, ObjV2min = objV2min, ObjV2max = objV2max, ExtV3Min = extV3Min, ObjV3min = objV3min, ObjV3max = objV3max, RetV4Max = retV4Max, ObjV4min = objV4min, ObjV4max = objV4max, ExtV5Min = extV5Min, ObjV5min = objV5min, ObjV5max = objV5max, ExtVbMax = extVbMax, RetVcMin = retVcMin }, input, ref cacheARC_Waves);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_Waves ARC_Waves(bool useHL, int swingStrength, double multiplierMD, double multiplierDTB, double retV2Max, double objV2min, double objV2max, double extV3Min, double objV3min, double objV3max, double retV4Max, double objV4min, double objV4max, double extV5Min, double objV5min, double objV5max, double extVbMax, double retVcMin)
		{
			return indicator.ARC_Waves(Input, useHL, swingStrength, multiplierMD, multiplierDTB, retV2Max, objV2min, objV2max, extV3Min, objV3min, objV3max, retV4Max, objV4min, objV4max, extV5Min, objV5min, objV5max, extVbMax, retVcMin);
		}

		public Indicators.ARC.ARC_Waves ARC_Waves(ISeries<double> input , bool useHL, int swingStrength, double multiplierMD, double multiplierDTB, double retV2Max, double objV2min, double objV2max, double extV3Min, double objV3min, double objV3max, double retV4Max, double objV4min, double objV4max, double extV5Min, double objV5min, double objV5max, double extVbMax, double retVcMin)
		{
			return indicator.ARC_Waves(input, useHL, swingStrength, multiplierMD, multiplierDTB, retV2Max, objV2min, objV2max, extV3Min, objV3min, objV3max, retV4Max, objV4min, objV4max, extV5Min, objV5min, objV5max, extVbMax, retVcMin);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_Waves ARC_Waves(bool useHL, int swingStrength, double multiplierMD, double multiplierDTB, double retV2Max, double objV2min, double objV2max, double extV3Min, double objV3min, double objV3max, double retV4Max, double objV4min, double objV4max, double extV5Min, double objV5min, double objV5max, double extVbMax, double retVcMin)
		{
			return indicator.ARC_Waves(Input, useHL, swingStrength, multiplierMD, multiplierDTB, retV2Max, objV2min, objV2max, extV3Min, objV3min, objV3max, retV4Max, objV4min, objV4max, extV5Min, objV5min, objV5max, extVbMax, retVcMin);
		}

		public Indicators.ARC.ARC_Waves ARC_Waves(ISeries<double> input , bool useHL, int swingStrength, double multiplierMD, double multiplierDTB, double retV2Max, double objV2min, double objV2max, double extV3Min, double objV3min, double objV3max, double retV4Max, double objV4min, double objV4max, double extV5Min, double objV5min, double objV5max, double extVbMax, double retVcMin)
		{
			return indicator.ARC_Waves(input, useHL, swingStrength, multiplierMD, multiplierDTB, retV2Max, objV2min, objV2max, extV3Min, objV3min, objV3max, retV4Max, objV4min, objV4max, extV5Min, objV5min, objV5max, extVbMax, retVcMin);
		}
	}
}

#endregion
