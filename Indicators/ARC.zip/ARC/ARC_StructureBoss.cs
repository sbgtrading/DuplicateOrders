#define DoLicense
#define MODERATORS
//#define DO_LICENSE_v1  //this is for StructureBoss prior to ARC release

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Windows.Controls;
#endregion
/*
Supercharge Your Small Account
with the Revolutionary Strategy Wall Street
Doesn’t Want You to Know

Attention NinjaTrader user!  I made this indicator for you!
	To reward you for being a dedicated trader, I’ve put together a one-of-a-kind system for you. 
	It’s brand new and you’re one of the first people to receive it!


============ output from Jounce AI
5 Steps to Successful Day Trading with NinjaTrader and ARC_StructureBoss
Getting Started with NinjaTrader: An Overview for Day Traders
How to Leverage StructureBoss to Maximize Your Profits in Futures Markets
Quick Tips for Beginner Day Traders Using NinjaTrader and StructureBoss
The Latest Strategies for Trading Equities and Crypto with NinjaTrader and StructureBoss
The Benefits of Using StructureBoss for Day Trading
How to Maximize Your Profits with StructureBoss
The Advantages of Day Trading with NinjaTrader
Create a Winning Day Trading Strategy with StructureBoss
Successful Strategies for Day Trading with StructureBoss
============
*/
//  The Ballsiest Offer I Ever Made…That Can Make YOU a winning trader!

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    [CategoryOrder("Comments", 5)]
    [CategoryOrder("NinjaScriptParameters", 10)]
    [CategoryOrder("Position Sizing", 20)]
    [CategoryOrder("Custom Visuals", 30)]
	[CategoryOrder("Audible",60)]
	[CategoryOrder("Email",70)]
    [CategoryOrder("Indicator Version", 1000)]
    [CategoryOrder("~ License ~", 1000)]
	public class ARC_StructureBoss : Indicator
	{
        private const string VERSION = "v1.2 21.Dec.2023";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		private bool IsDebug = false;
		private bool ValidLicense  = true;
		private bool IsExpired     = true;
		private bool LicenseChecked = false;
		private string UserId       = string.Empty;
		private string MachineId    = string.Empty;
		string ModuleName = "StructureBoss";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "25900", "26999"};
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		private Series<double>		zigZagHighZigZags;
		private Series<double>		zigZagLowZigZags;
		private Series<double>		zigZagHighSeries;
		private Series<double>		zigZagLowSeries;
		private ATR atr;

		private double				currentZigZagHigh;
		private double				currentZigZagLow;
		private int					lastSwingIdx;
		private int					lastSwingHighIdx=0;
		private int					lastSwingLowIdx=0;
		private double				lastSwingPrice;
		private int 				startIndex;
		private int					trendDir;
		private List<int> InSessionABars = new List<int>();
		string DaysOfWeekToTradeNumber;
		double tick_value_dollars = 0;
		SortedDictionary<DayOfWeek,double> DollarsRiskPerTrade = new SortedDictionary<DayOfWeek, double>();
		private bool pShowSLsquares = false;
		private bool IsStock = false;
//version after 230216
		//	changed start/stop time vertical colored lines - only print if both the Day is enabled (pDaysOfWeekToTrade) and the RiskPerTrade is 'ON', meaning it's a risk of 0 or greater
		//  fixed graph output.  Overall PnL was printing above the graph if the PnL never went below zero
		//  Added "Silence Alerts" button to UI
//version after 23.03.03
		//  Added "Permit addtl trades" setting, add to existing positions if congruent signals appear?
		//  Added "Stop Time" and "EOD Time".  Stop Time is when additional trades are skipped/ignored.  EOD Time is time when all positions go flat
		//  Fixed a minor miscalculation in initial risk points (only affected short trades when $ risk was selected
//version after 23.03.12
		//  Fixed triangle entries appearing after the "Stop time" and before the "EOD time"
		//  Added opacity setting for "Time boundary opacity"
		//  Added opacity setting for "Triangles opacity"
		//  Added "B.E. stop" parameter...separate on/off parameter.  "B.E. Stop" is now a separate option from the Trailing stop
		//  Changed the pnl lines on each trade...horizontal line is the entry price, sloped line is from entry to exit prices
		//  Added SLHistory - print magenta dots where the SL line moved through the history of the trade.
//version after 23.05.02
		//  Changed exit logic...exits can only occur after the entry bar.  Exits cannot occur on the entry bar...this was a bug in previous versions.
		protected override void OnStateChange()
		{
//if(State!=null)Print("ARC_StructureBoss"+State.ToString());
			#region -- OnStateChange --
			if (State == State.SetDefaults)
			{
				Description					= "Trades based on triangle breakouts";
#if DO_LICENSE_v1
				Name						= "StructureBoss";
#else
				Name						= "ARC_StructureBoss";
#endif
				DisplayInDataBox			= false;
				DrawOnPricePanel			= false;
				IsSuspendedWhileInactive	= false;
				IsOverlay					= true;
				PaintPriceMarkers			= false;
				UseHighLow					= true;

				AddPlot(Brushes.White, NinjaTrader.Custom.Resource.NinjaScriptIndicatorNameZigZag);
				AddPlot(new Stroke(Brushes.Lime, 3f), PlotStyle.Line, "W trade PnL");
				AddPlot(new Stroke(Brushes.Red, 3f), PlotStyle.Line, "L trade PnL");
				Plots[1].DashStyleHelper = DashStyleHelper.Dash;
				Plots[2].DashStyleHelper = DashStyleHelper.Dash;

				DisplayInDataBox			= false;
				PaintPriceMarkers			= false;
//				pUpTriangleTemplate			= "Default";
//				pDownTriangleTemplate		= "Default";
				pDeviationType				= PivotPointBoss_DeviationType.Percent;
				pDeviationValue				= 0.15;
				pShowLongs					= true;
				pShowShorts					= true;
				pEngageTrailingStop			= true;
				pEngageBEStop				= true;
				pStartTime					= 800;
				pStopTime					= 1600;
				pEODTime					= 1600;
				pMinContracts = 1;
				pUseStdSLOnly = false;
				pType = PivotPointBoss_Type.Reversing;
				pRewardToRisk				= 1.75;
				pMaxRiskDollarsSunday       = -1;
				pMaxRiskDollarsMonday		= 0;
				pMaxRiskDollarsTuesday		= 0;
				pMaxRiskDollarsWednesday	= 0;
				pMaxRiskDollarsThursday		= 0;
				pMaxRiskDollarsFriday		= 0;
				pMaxRiskDollarsSaturday     = -1;
				pDaysOfWeekToTrade			= "All";
				pTrailingStopATRMult		= 2.5;
				pSLBufferTicks = 0;
				pPrintToOutputWindow		= false;
				pShowDrawdowns    = true;
				pShowDispositions = true;
				pShowPnLByDOW = true;
				pButtonText   = "StructureBoss";
				pPermitSameDirectionEntries = false;
				pTrianglesOpacity = 50;
				pUpTriangleBrush = Brushes.Lime;
				pDownTriangleBrush = Brushes.Magenta;
				pHistoricalTriangleUpBrush = Brushes.DarkGreen;
				pHistoricalTriangleDownBrush = Brushes.Maroon;

				pSummaryTxt_Xpct  = 2;
				pSummaryTxt_Ypct  = 4;
				pSummaryTextBkgOpacity = 90;
				pSilenceAllAlerts = false;
				pBuySetupWAV  = "SOUND OFF";
				pSellSetupWAV = "SOUND OFF";
				pBuyFillWAV   = "SOUND OFF";
				pSellFillWAV  = "SOUND OFF";
				pTrailingStopWAV = "SOUND OFF";
				pEmailSetupSignal = "";
				pEmailFillSignal = "";
				pEmailTrailingStopSignal = "";

				pEntryLineThickness = 2f;
				pSLLineThickness = 2f;
				pTargetLineThickness = 2f;
				pShowPnLLines		 = true;
				pShowSLHistory	     = true;
				pOrderLabelFont		 = new NinjaTrader.Gui.Tools.SimpleFont("Arial",12){Bold=true};
				SummaryFontSize	 = 16;
				pLineHeight			 = 0;
				pTimeLineOpacity	 = 50f;
				pSummaryFont		 = new NinjaTrader.Gui.Tools.SimpleFont("Arial",SummaryFontSize);
				pSundayPlot_Brush    = Brushes.DeepPink;
				pMondayPlot_Brush    = Brushes.Yellow;
				pTuesdayPlot_Brush   = Brushes.Cyan;
				pWednesdayPlot_Brush = Brushes.Lime;
				pThursdayPlot_Brush  = Brushes.Black;
				pFridayPlot_Brush    = Brushes.Red;
				pSaturdayPlot_Brush  = Brushes.Blue;
				AxisFont		 = new NinjaTrader.Gui.Tools.SimpleFont("Arial",12){Bold=false};
			}
			else if (State == State.Configure)
			{
				bool filefound = System.IO.File.Exists(@"c:\222222222222.txt");
				//IsDebug = filefound && (NinjaTrader.Cbi.License.MachineId.CompareTo("CB15E08BE30BC80628CFF6010471FA2A")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("B0D2E9D1C802E279D3678D7DE6A33CE4")==0);
//Print("filefound: "+filefound.ToString()+"   IsDebug: "+IsDebug.ToString());
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion

				IsStock = Instrument.MasterInstrument.InstrumentType==InstrumentType.Stock;

				pOpacity = pTrianglesOpacity;
				currentZigZagHigh	= 0;
				currentZigZagLow	= 0;
				lastSwingIdx		= -1;
				lastSwingPrice		= 0.0;
				trendDir			= 0; // 1 = trend up, -1 = trend down, init = 0
				startIndex 			= int.MinValue;


				DollarsRiskPerTrade[DayOfWeek.Sunday]   = pMaxRiskDollarsSunday;
				DollarsRiskPerTrade[DayOfWeek.Monday]   = pMaxRiskDollarsMonday;
				DollarsRiskPerTrade[DayOfWeek.Tuesday]  = pMaxRiskDollarsTuesday;
				DollarsRiskPerTrade[DayOfWeek.Wednesday]= pMaxRiskDollarsWednesday;
				DollarsRiskPerTrade[DayOfWeek.Thursday] = pMaxRiskDollarsThursday;
				DollarsRiskPerTrade[DayOfWeek.Friday]   = pMaxRiskDollarsFriday;
				DollarsRiskPerTrade[DayOfWeek.Saturday] = pMaxRiskDollarsSaturday;
				DaysOfWeekToTradeNumber = "";
				string res = string.Empty;
				if(pDaysOfWeekToTrade.Trim().ToUpper()=="ALL"){
					pDaysOfWeekToTrade = "Su,M,Tu,W,Th,F,Sa";
					DaysOfWeekToTradeNumber="0,1,2,3,4,5,6";
				}else{
					if(pDaysOfWeekToTrade.Contains("0") || pDaysOfWeekToTrade.ToUpper().Contains("SU")) {res = "Su,";     DaysOfWeekToTradeNumber="0";}
					if(pDaysOfWeekToTrade.Contains("1") || pDaysOfWeekToTrade.ToUpper().Contains("M"))  {res = res+"M,";  DaysOfWeekToTradeNumber= DaysOfWeekToTradeNumber+"1";}
					if(pDaysOfWeekToTrade.Contains("2") || pDaysOfWeekToTrade.ToUpper().Contains("TU")) {res = res+"Tu,"; DaysOfWeekToTradeNumber= DaysOfWeekToTradeNumber+"2";}
					if(pDaysOfWeekToTrade.Contains("3") || pDaysOfWeekToTrade.ToUpper().Contains("W"))  {res = res+"W,";  DaysOfWeekToTradeNumber= DaysOfWeekToTradeNumber+"3";}
					if(pDaysOfWeekToTrade.Contains("4") || pDaysOfWeekToTrade.ToUpper().Contains("TH")) {res = res+"Th,"; DaysOfWeekToTradeNumber= DaysOfWeekToTradeNumber+"4";}
					if(pDaysOfWeekToTrade.Contains("5") || pDaysOfWeekToTrade.ToUpper().Contains("F"))  {res = res+"F,";  DaysOfWeekToTradeNumber= DaysOfWeekToTradeNumber+"5";}
					if(pDaysOfWeekToTrade.Contains("6") || pDaysOfWeekToTrade.ToUpper().Contains("SA")) {res = res+"Sa";  DaysOfWeekToTradeNumber= DaysOfWeekToTradeNumber+"6";}
					if(res.EndsWith(",")) res = res.Substring(0,res.Length-1);
					pDaysOfWeekToTrade = res;
				}
			}
			else if (State == State.DataLoaded)
			{
#if DO_LICENSE_v1
#region old licensing system
				string Status = "";
				if(!IsDebug) {
					CheckLicense(ref ValidLicense, ref ExpirationDT, ref Status);
					if(!ValidLicense){
						SortedDictionary<string,DateTime> ValidMachineIDs = new SortedDictionary<string, DateTime>();
						//ValidMachineIDs["CB15E08BE30BC80628CFF6010471FA2A-Ben-Letto"]   = new DateTime(2029,1,17,0,0,0);
						ValidMachineIDs["E3D59035CB1F394B238FD458CA998D48-David-Eaton"] = new DateTime(2024,3,14,23,0,0);//daveaton@hotmail.com
						ValidMachineIDs["FFEAEA3F383C4D67EF8E72B587325033-Michael-Filighera"] = new DateTime(2024,4,15,23,0,0);//Michael Filighera issued 9/27/2023
						ValidMachineIDs["6D3C71DFFB3F38A8B6334755A6645E5E-Michael-Filighera"] = new DateTime(2024,3,15,23,0,0);//Michael Filighera's client:   Kavon Allen-Hunter (kavonallenhunter@gmail.com) - issued on 29-May-2023

						DateTime ExpireAt = DateTime.MinValue;
						foreach(var kvp in ValidMachineIDs){
							if(kvp.Key.StartsWith(NinjaTrader.Cbi.License.MachineId)){
								ValidLicense = true;
								ExpireAt = kvp.Value;
							}
						}
						if(ValidLicense){
							var ts = ExpireAt - DateTime.Now;
							if(ts.TotalDays < 0){
								ValidLicense = false;
							}
							else if(ts.TotalDays < 4)
								Draw.TextFixed(this, "lic", "ARC_StructureBoss"+ExpireAt.ToString()+
									"\nContact "+SupportEmailAddress+" for activation", TextPosition.BottomLeft);
						}
						if(!ValidLicense)
							Draw.TextFixed(this, "lic", "ARC_StructureBoss"+SupportEmailAddress+" for activation", TextPosition.Center);
					}
				}else{
					ValidLicense = true;
				}
//Print("\n\n\nValid license: "+ValidLicense.ToString());
				if(!ValidLicense){
//Print("    LicPass: "+pLicensePassword);
					if(pLicensePassword.Trim().StartsWith("db")){
						VendorLicense("DayTradingWithRay", "StructureBoss", "www.sbgtradingcorp.com", SupportEmailAddress);
					}else{
						if(pLicensePassword.Contains("enter your"))
							DrawTextFixed("licerror","Your License key must be entered into your LicensePassword parameter\n\n   "+MachineId+"\n\nQuestions? Send your full name and machine id to:  "+this.SupportEmailAddress,TextPosition.Center,Brushes.White,font,Brushes.Maroon,Brushes.Maroon,100);
						else if(IsExpired)
							DrawTextFixed("licerror","License key '"+this.pLicensePassword+"' is expired\n\n   "+MachineId+"\n\nQuestions? Send your full name and machine id to:  "+this.SupportEmailAddress,TextPosition.Center,Brushes.White,font,Brushes.Maroon,Brushes.Maroon,100);
						else
							DrawTextFixed("licerror","License key '"+this.pLicensePassword+"' is not valid for this machine id\n\n   "+MachineId+"\nCheck to see if your machine id changed recently.\n\nQuestions? Send your full name and machine id to:  "+this.SupportEmailAddress,TextPosition.Center,Brushes.White,font,Brushes.Maroon,Brushes.Maroon,100);
						return;
					}
				}
//				if(!ValidLicense) Log(ProductName+" Lic Status: "+Status, LogLevel.Information);
#endregion
#endif
				tick_value_dollars  = Instrument.MasterInstrument.PointValue * TickSize;//$ value per tick
				zigZagHighZigZags	= new Series<double>(this, MaximumBarsLookBack.Infinite);
				zigZagLowZigZags	= new Series<double>(this, MaximumBarsLookBack.Infinite);
				zigZagHighSeries	= new Series<double>(this, MaximumBarsLookBack.Infinite);
				zigZagLowSeries		= new Series<double>(this, MaximumBarsLookBack.Infinite);
				atr = ATR(14);
				if(ChartPanel!=null){
					ChartPanel.KeyDown    += OnKeyDown; 
					ChartPanel.MouseWheel += OnMouseWheel;
					ChartPanel.MouseMove  += OnMouseMove;
				}
			}
			else if (State == State.Historical){
				if (!IsToolBarButtonAdded) AddToolBar();
			}
			else if(State == State.Realtime){
				IsRealTime1 = true;
				IsRealTime2 = true;
			}
			else if(State == State.Terminated){
				if(ChartPanel!=null){
					ChartPanel.KeyDown    -= OnKeyDown;
					ChartPanel.MouseWheel -= OnMouseWheel;
					ChartPanel.MouseMove  -= OnMouseMove;
					Dispatcher.InvokeAsync((Action)(() =>
					{
						if (indytoolbar != null && chartWindow!=null){
						    chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;
							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}
					}));
				}
			}
			#endregion
		}
		#region -- License methods --
#if DO_LICENSE_v1
//			DateTime Now = DateTime.Now;
			NinjaTrader.Gui.Tools.SimpleFont font = new NinjaTrader.Gui.Tools.SimpleFont("Arial",15);
			private string SupportEmailAddress = "support@architectsai.com";
			private string ProductName = "StructureBoss";
			private DateTime ExpirationDT = DateTime.MaxValue;
			double ProductID = 21;//unique product number for StructureBoss
				//CB15608BE30BC80628CFF601047182AA
				//6k*-FJDLB1-FFDIGD-G129
				//1)  anything before the first '-' is ignored
				//2)  "FJDLB1" The last digit in the Mach ID is 2...this translates to "F"...so the first char in password is "F".
				//			Find the first number in the MachID, and the 2nd char after that number is '6', which translates to 'J', the next password char 'J'
				//			The next char after the '6' is '0', which is 'D'
				//			The next char after the '0' is '8' which is 'L'
				//			The next char after the '8' is 'B' which is 'B' (there's no numerical translation for 'B')
				//			The next char after the 'B' is 'E' which is '1'
				//  NOTE:  If a "RBT" is found in this machine id code...then all machine id's are valid...only restricted by the expiration date and module number
				//3)  "FFDIGD" is the expiration date  'F' is 2, 'D' is 0, 'I' is 5, 'G' is 3.  So the expiration date is 220530 (2022-May-30)
				//4)  "G129" is module identifier.  "G" is the multiplier, "G" translates to 3.  So take the 129 and divide by 3...so the Module number is 129/3 = 43.
				//0 = D, 1 = E, 2 = F, 3 = G, 4 = H, 5 = I, 6 = J, 7 = K, 8 = L, 9 = M
		private void CheckLicense(ref bool ValidLicense, ref DateTime ExpiredAt, ref string Status){
			string machid_status = null;
			string date_status = null;
			string prodid_status = null;
			Status = "";
			ExpiredAt = DateTime.MaxValue;
			try
			{
				string licfile = null;
				var path = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"SBG_licenses");
				if(!System.IO.Directory.Exists(path)) {
					System.IO.Directory.CreateDirectory(path);
					var instr = System.IO.Path.Combine(path, "ReadTheseInstructions.txt");
					System.IO.File.WriteAllLines(instr, new string[]{
						"",
						"--- IMPORTANT INSTRUCTIONS ---",
						"",
						"Do not move or remove this folder (SBG_licenses).",
						"That action will result in a license error for all of your StructureBoss related indicators",
						"",
						"Do not delete or remove any of the text files in this folder.",
						"That action will result in a license error for specific StructureBoss related indicators",
						"",
						"Contact "+SupportEmailAddress+" if you need further clarification"
					});
				}
				string search = ProductName+"_*.txt";
				System.IO.DirectoryInfo dirCustom =null;
				System.IO.FileInfo[] filCustom    =null;
				try{
					dirCustom = new System.IO.DirectoryInfo(path);
					filCustom = dirCustom.GetFiles(search);
				}catch{filCustom = null;}

				string lpass = pLicensePassword.Trim().ToLower();
				if(lpass == "<enter password here>" || string.IsNullOrEmpty(lpass)){
					try{//   !#-f1 dl!b1^-fkdidg-f20
						if(filCustom!=null && filCustom.Length>0){
							lpass = filCustom[0].Name.Replace(ProductName+"_",string.Empty).Replace(".txt",string.Empty).Trim();
						}
						pLicensePassword = lpass.ToLower();
					}catch{
						lpass = pLicensePassword.Trim().ToLower();
					}
				}else{
					licfile = System.IO.Path.Combine(path, ProductName+"_"+pLicensePassword.Trim().ToLower()+".txt");
					foreach(var f in filCustom)	{
						if(f.FullName!=licfile) System.IO.File.Delete(f.FullName);
					}
					if(!string.IsNullOrEmpty(pLicensePassword)) {
						System.IO.File.WriteAllText(licfile, "");
					}
				}

				string MachineId = NinjaTrader.Cbi.License.MachineId.ToLower();
			    var chararray = MachineId.ToCharArray();
			    int LastNumber = -1;
			    char CharOfLastNumber = ' ';
			    for (int i = chararray.Length - 1; i >= 0; i--) if (chararray[i] >= '0' && chararray[i] <= '9'){
					CharOfLastNumber = chararray[i];
					LastNumber = (int)CharOfLastNumber - (int)'0'; break;
					machid_status = "i = " + i + " char: " + CharOfLastNumber;
			    }
				var key = KeepTheseChars(pLicensePassword.ToLower().ToCharArray(), "abcdefghijklmnopqrstuvwxyz-0123456789");

				var elems = key.Split(new char[] { '-' }, StringSplitOptions.None);
				int idx = -1;
				ValidLicense = true;
				for (int i = 1; i < elems.Length; i++){
					if (i == 1){//this is the machine id verification segment
						if (elems[i].Contains("rbt")) {machid_status = "wildcard 'rbt' found"; continue;}//"RBT" is the global machine id...it passes this machine id verification
						if (Decode(CharOfLastNumber) != elems[i][0]){
						    machid_status = CharOfLastNumber+"  CofLN: " + Decode(CharOfLastNumber) + "  elems[1]0: " + elems[i][0];
							Status = "Line 138 - "+machid_status;
						    ValidLicense = false; break;//failed
						}else{
							for (int j = 0; j < chararray.Length - 1; j++) 
								if (chararray[j] >= '0' && chararray[j] <= '9') {
									idx = j + LastNumber;
									Status = "Line 144 - "+chararray[j];
									break;
								}
							//machid_status = "LastNumber: " + LastNumber.ToString() + "  idx: " + idx.ToString();
							if (idx < 0){
								Status = "Line 150 - "+machid_status;
								break;//failed
							}else{
								machid_status = string.Format("__{0} 1 {1} = {2}  |", machid_status, Decode(elems[i][1]), chararray[idx]);
								machid_status = string.Format("{0} 2 {1} = {2}  |", machid_status, Decode(elems[i][2]), chararray[idx+1]);
								machid_status = string.Format("{0} 3 {1} = {2}  |", machid_status, Decode(elems[i][3]), chararray[idx+2]);
								machid_status = string.Format("{0} 4 {1} = {2}  |", machid_status, Decode(elems[i][4]), chararray[idx+3]);
								if (Decode(elems[i][1]) != chararray[idx + 0]) { machid_status = machid_status + "*1"; Status=machid_status; ValidLicense = false;break; }//failed
								if (Decode(elems[i][2]) != chararray[idx + 1]) { machid_status = machid_status + "*2"; Status=machid_status; ValidLicense = false;break; }//failed
								if (Decode(elems[i][3]) != chararray[idx + 2]) { machid_status = machid_status + "*3"; Status=machid_status; ValidLicense = false;break; }//failed
								if (Decode(elems[i][4]) != chararray[idx + 3]) { machid_status = machid_status + "*4"; Status=machid_status; ValidLicense = false;break; }//failed
							}
						}
					}
					else if (i == 2)
					{
						var date = string.Format("{0}{1}", Decode(elems[i][0]), Decode(elems[i][1]));
						date_status = string.Format("{0}{1}", date_status, date);
						int yr = int.Parse(date); date = string.Empty;
						date = string.Format("{0}{1}", Decode(elems[i][2]), Decode(elems[i][3]));
						date_status = string.Format("{0}{1}", date_status, date);
						int mo = int.Parse(date); date = string.Empty;
						date = string.Format("{0}{1}", Decode(elems[i][4]), Decode(elems[i][5]));
						date_status = string.Format("{0}{1}", date_status, date);
						int day = int.Parse(date); date = string.Empty;
						ExpiredAt = new DateTime(2000 + yr, mo, day);
						date_status = string.Format("{0}  {1}", date_status, ExpiredAt.ToShortDateString());
						if(ExpiredAt < DateTime.Now) { Status=date_status; ValidLicense=false; break;}
					}
					else if (i == 3 && ProductID>0)
					{
						int Mult = (int)Decode(elems[i][0]) - (int)'0';
						if (Mult>0)
						{
							chararray = elems[i].ToCharArray();
							chararray[0] = '0';//so 'g129' becomes a numerical string of '0129'
							var str = new StringBuilder();
							str.Append(chararray);
							prodid_status = str.ToString();
							double productNum = double.Parse(str.ToString()) / Mult;
							prodid_status = str.ToString() + " mult "+Mult+"  = "+productNum;
							if (productNum>0 && productNum != ProductID) {ExpiredAt = DateTime.MaxValue; Status=prodid_status; ValidLicense=false; break;}
						}
					}
				}
			}
			catch { ValidLicense = false; }
//			Print(ProductName+"  IsValidLicense?  "+ValidLicense.ToString());
			if(!ValidLicense){
				Print("SB machid status: "+machid_status);
				Print("SB date status: "+date_status);
				Print("SB prodid status: "+prodid_status);
			}
		}
		#region -- license support --
		private char Decode(char inchar){
			//0 = D, 1 = E, 2 = F, 3 = G, 4 = H, 5 = I, 6 = J, 7 = K, 8 = L, 9 = M
			if(inchar == '0') return 'd';
			if(inchar == '1') return 'e';
			if(inchar == '2') return 'f';
			if(inchar == '3') return 'g';
			if(inchar == '4') return 'h';
			if(inchar == '5') return 'i';
			if(inchar == '6') return 'j';
			if(inchar == '7') return 'k';
			if(inchar == '8') return 'l';
			if(inchar == '9') return 'm';
			if(inchar == 'd') return '0';
			if(inchar == 'e') return '1';
			if(inchar == 'f') return '2';
			if(inchar == 'g') return '3';
			if(inchar == 'h') return '4';
			if(inchar == 'i') return '5';
			if(inchar == 'j') return '6';
			if(inchar == 'k') return '7';
			if(inchar == 'l') return '8';
			if(inchar == 'm') return '9';
			return inchar;
		}
		private string KeepTheseChars(char[] chararray, string keepers){
			string result = string.Empty;
			for(int i = 0; i<chararray.Length; i++)
				if(keepers.Contains(chararray[i])) result = string.Format("{0}{1}", result,chararray[i]);
			return result;
		}
		#endregion
#endif
		#endregion

		private bool PnLChartToggle = false;
		private bool TimeSlicePnLChartToggle = false;
		private Chart chartWindow;
        private Grid indytoolbar;
		private string toolbarname = "ARCStructureBoss", uID;
//		private Button myButton = null;
		private Menu MenuControlContainer;
		private MenuItem MenuControl, miRecalc;
		private bool IsToolBarButtonAdded = false;
		private bool ShowSummaryTable = true;
		private int SummaryFontSize = 16;
		#region -- AddToolbar --
		private void AddToolBar()
		{
			uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
			Dispatcher.BeginInvoke(new Action(() =>
			{
				chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
				if (chartWindow == null) return;

				foreach (DependencyObject item in chartWindow.MainMenu) if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) IsToolBarButtonAdded = true;

				if (!IsToolBarButtonAdded)
				{
					#region -- initialize toolbar --
				    indytoolbar = new Grid { Visibility = Visibility.Collapsed };

					MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
					MenuControl = new MenuItem {Name="TTbutton"+uID,  BorderThickness = new Thickness(2), BorderBrush = Brushes.Cyan, Header = pButtonText, Foreground = Brushes.White, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Medium, FontSize = 13 };
					MenuControlContainer.Items.Add(MenuControl);
					MenuControl.MouseEnter += delegate (object o, MouseEventArgs e){
						foreach(var i in MenuControl.Items){
							try{
								var kk = (MenuItem)i;
								//Print(kk.Name.ToString());
								if(kk.Name.ToString().StartsWith("ShowOverallPnL")){
									SetFontAndBackground(kk, PnLChartToggle);
								}
								else if(kk.Name.ToString().StartsWith("ShowTimeSlicePnL")){
									SetFontAndBackground(kk, TimeSlicePnLChartToggle);
								}
							}catch{}
						}
					};
					#endregion

					var mi = new MenuItem { Header = "Show Overall PnL", Name = "ShowOverallPnL"+uID, Foreground = Brushes.Black, StaysOpenOnClick = false };
					SetFontAndBackground(mi, PnLChartToggle);
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						PnLChartToggle = !PnLChartToggle; 
						if(TimeSlicePnLChartToggle) TimeSlicePnLChartToggle = false;
						var m = (MenuItem)o;
						SetFontAndBackground(m, PnLChartToggle);
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);

					mi = new MenuItem { Header = "Show Timeslice PnL", Name = "ShowTimeSlicePnL"+uID, Foreground = Brushes.Black, StaysOpenOnClick = false };
					SetFontAndBackground(mi, TimeSlicePnLChartToggle);
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						TimeSlicePnLChartToggle = !TimeSlicePnLChartToggle; 
						if(PnLChartToggle) PnLChartToggle = false;
						var m = (MenuItem)o;
						SetFontAndBackground(m, TimeSlicePnLChartToggle);
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					MenuControl.Items.Add(new Separator());

					#region -- show longs --
					mi = new MenuItem { Header = "Longs?  "+(pShowLongs ? "YES" : "no"), Name = "ShowLongs"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pShowLongs);
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pShowLongs = !pShowLongs; 
						var m = (MenuItem)o;
						m.Header = "Longs?  "+(pShowLongs ? "YES" : "no");
						SetFontAndBackground(m, pShowLongs);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						pShowLongs = !pShowLongs; 
						var m = (MenuItem)o;
						m.Header = "Longs?  "+(pShowLongs ? "YES" : "no");
						SetFontAndBackground(m, pShowLongs);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					#endregion

					#region -- show shorts --
					mi = new MenuItem { Header = "Shorts?  "+(pShowShorts ? "YES" : "no"), Name = "ShowShorts"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pShowShorts);
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pShowShorts = !pShowShorts; 
						var m = (MenuItem)o;
						m.Header = "Shorts?  "+(pShowShorts ? "YES" : "no");
						SetFontAndBackground(m, pShowShorts);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						pShowShorts = !pShowShorts; 
						var m = (MenuItem)o;
						m.Header = "Shorts?  "+(pShowShorts ? "YES" : "no");
						SetFontAndBackground(m, pShowShorts);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
						e.Handled = true;
					};
					MenuControl.Items.Add(mi);
					#endregion

					#region -- Type --
					mi = new MenuItem { Header = "Type "+pType.ToString(), Name = "SignalType"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					mi.FontWeight = FontWeights.Normal;
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						if(pType == PivotPointBoss_Type.Reversing) pType = PivotPointBoss_Type.Trending;
						else pType = PivotPointBoss_Type.Reversing;
						var m = (MenuItem)o;
						m.Header = "Type "+pType.ToString();
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(e.Delta>0){
							if(pType == PivotPointBoss_Type.Trending) pType = PivotPointBoss_Type.Reversing;
							else pType = PivotPointBoss_Type.Trending;
						}else{
							if(pType == PivotPointBoss_Type.Reversing) pType = PivotPointBoss_Type.Trending;
							else pType = PivotPointBoss_Type.Reversing;
						}
						pRewardToRisk = Math.Max(0, pRewardToRisk);
						var m = (MenuItem)o;
						m.Header = "Type "+pType.ToString();
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					#endregion

					#region -- PermitAdditionalEntries --
					mi = new MenuItem { Header = "Permit addlt entries:  "+pPermitSameDirectionEntries.ToString(), Name = "PermitAddtlEntries"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					mi.FontWeight = FontWeights.Normal;
//					mi.ToolTip = "";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pPermitSameDirectionEntries = !pPermitSameDirectionEntries;
						var m = (MenuItem)o;
						m.Header = "Permit addlt entries:  "+pPermitSameDirectionEntries.ToString();
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						pPermitSameDirectionEntries = !pPermitSameDirectionEntries;
						var m = (MenuItem)o;
						m.Header = "Permit addlt entries:  "+pPermitSameDirectionEntries.ToString();
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					#endregion

					#region -- Start time --
					int hr = pStartTime/100;
					int min = pStartTime-hr*100;
					mi = new MenuItem { Header = "Start time  "+hr+":"+min.ToString("00"), Name = "StartTime"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					mi.FontWeight = FontWeights.Normal;
					mi.ToolTip = "This is the time of day we start entering new positions";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pStartTime = 800;
						var m = (MenuItem)o;
						m.Header = "Start time  "+this.pStartTime.ToString();
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						hr = pStartTime/100;
						min = pStartTime-hr*100;
						DateTime ts = new DateTime(2000,1,1,hr,min,0);
						int diff = 10;
						if(e.Delta>0)
							ts = ts.AddMinutes(diff);
						else
							ts = ts.AddMinutes(-diff);
						pStartTime = ts.Hour*100+ts.Minute;
						var m = (MenuItem)o;
						m.Header = string.Format("Start time  {0}:{1}",ts.Hour,ts.Minute.ToString("00"));
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					#endregion
					#region -- Stop entering new trades time --
					hr = pStopTime/100;
					min = pStopTime-hr*100;
					mi = new MenuItem { Header = "Stop time  "+hr+":"+min.ToString("00"), Name = "StopTime"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					mi.FontWeight = FontWeights.Normal;
					mi.ToolTip = "This is the time of day we stop entering new positions";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pStopTime = 1600;
						var m = (MenuItem)o;
						m.Header = "Stop time  "+this.pStopTime.ToString();
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						hr = pStopTime/100;
						min = pStopTime-hr*100;
						DateTime ts = new DateTime(2000,1,1,hr,min,0);
						int diff = 10;
						if(e.Delta>0)
							ts = ts.AddMinutes(diff);
						else
							ts = ts.AddMinutes(-diff);
						pStopTime = ts.Hour*100+ts.Minute;
//						if(pStopTime>pEODTime) pStopTime = pEODTime;//stop time cannot be larger than EOD time
						var m = (MenuItem)o;
						m.Header = string.Format("Stop time  {0}:{1}",ts.Hour,ts.Minute.ToString("00"));
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					#endregion
					#region -- EOD time --
					hr = pEODTime/100;
					min = pEODTime-hr*100;
					mi = new MenuItem { Header = "EOD time  "+hr+":"+min.ToString("00"), Name = "EODTime"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					mi.FontWeight = FontWeights.Normal;
					mi.ToolTip = "This is the time of day we exit any/all open positions";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pEODTime = this.pStopTime;
						var m = (MenuItem)o;
						m.Header = "EOD time  "+this.pEODTime.ToString();
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						hr = pEODTime/100;
						min = pEODTime-hr*100;
						DateTime ts = new DateTime(2000,1,1,hr,min,0);//TimeSpan(hr,min,0);
						int diff = 10;
						if(e.Delta>0)
							ts = ts.AddMinutes(diff);
						else
							ts = ts.AddMinutes(-diff);
						pEODTime = ts.Hour*100+ts.Minute;
						var m = (MenuItem)o;
						m.Header = string.Format("End time  {0}:{1}",ts.Hour,ts.Minute.ToString("00"));
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					#endregion

					#region -- Engage BE Stop --
					mi = new MenuItem { Header = "B.E. stop?  "+(pEngageBEStop ? "YES" : "no"), Name = "EngageBEStop"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pEngageBEStop);
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pEngageBEStop = !pEngageBEStop; 
						var m = (MenuItem)o;
						m.Header = "B.E. stop?  "+(pEngageBEStop ? "YES" : "no");
						SetFontAndBackground(m, pEngageBEStop);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						pEngageBEStop = !pEngageBEStop; 
						SetFontAndBackground(mi, pEngageBEStop);
						if(pEngageBEStop){
							var m = (MenuItem)o;
							m.Header = "B.E. stop?  "+(pEngageBEStop ? "YES" : "no");
							miRecalc.Visibility = Visibility.Visible;
							ForceRefresh();
						}
					};
					MenuControl.Items.Add(mi);
					#endregion

					#region -- Engage TrailingStop --
					mi = new MenuItem { Header = "Trailing stop?  "+(pEngageTrailingStop ? "YES  "+this.pTrailingStopATRMult.ToString("0.0") : "no"), Name = "EngageTrailingStop"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pEngageTrailingStop);
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pEngageTrailingStop = !pEngageTrailingStop; 
						var m = (MenuItem)o;
						m.Header = "Trailing stop? "+(pEngageTrailingStop ? "YES  "+this.pTrailingStopATRMult.ToString("0.0") : "no");
						SetFontAndBackground(m, pEngageTrailingStop);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(pEngageTrailingStop){
							double diff = 0.2;
							if(pTrailingStopATRMult < 1) diff = 0.05;
							if(e.Delta>0)
								pTrailingStopATRMult = pTrailingStopATRMult + diff;
							else
								pTrailingStopATRMult = pTrailingStopATRMult - diff;
							var m = (MenuItem)o;
							m.Header = "Trailing stop? "+(pEngageTrailingStop ? "YES  "+this.pTrailingStopATRMult.ToString(diff==0.05 ? "0.00":"0.0") : "no");
							miRecalc.Visibility = Visibility.Visible;
							ForceRefresh();
						}
					};
					MenuControl.Items.Add(mi);
					#endregion

					#region -- Target RR --
					mi = new MenuItem { Header = "Target RR: "+this.pRewardToRisk.ToString("0.00"), Name = "RR"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					mi.FontWeight = FontWeights.Normal;
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						double diff = 0.2;
						if(pRewardToRisk < 1) diff = 0.05;
						if(e.Delta>0)
							pRewardToRisk = pRewardToRisk + diff;
						else
							pRewardToRisk = pRewardToRisk - diff;
						pRewardToRisk = Math.Round(Math.Max(0, pRewardToRisk),2);
						var m = (MenuItem)o;
						m.Header = "Target RR: "+this.pRewardToRisk.ToString("0.00");
						miRecalc.Visibility = Visibility.Visible;
					};

					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pRewardToRisk = 0.7;
						var m = (MenuItem)o;
						m.Header = "Target RR: "+this.pRewardToRisk.ToString("0.00");
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					#endregion

					#region -- ZigZag value --
					mi = new MenuItem { Header = "ZZ value: "+pDeviationValue.ToString("0.00"), Name = "Deviation"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					mi.FontWeight = FontWeights.Normal;
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(e.Delta>0)
							pDeviationValue += (pDeviationType == PivotPointBoss_DeviationType.Percent ? 0.01 : TickSize);
						else
							pDeviationValue -= (pDeviationType == PivotPointBoss_DeviationType.Percent ? 0.01 : TickSize);
						pDeviationValue = Math.Round(Math.Max(0, pDeviationValue),2);
						var m = (MenuItem)o;
						if(pDeviationType == PivotPointBoss_DeviationType.Percent)
							m.Header = "ZZ value: "+this.pDeviationValue.ToString("0.00");
						else{
							var s = TickSize.ToString().ToCharArray();
							string r=string.Empty;
							foreach(var c in s) if(c=='.') r = r+"."; else r = r+"0";
							m.Header = "ZZ value: "+this.pDeviationValue.ToString(r);
						}
						miRecalc.Visibility = Visibility.Visible;
					};

					MenuControl.Items.Add(mi);
					#endregion

					MenuControl.Items.Add(new Separator());

					#region -- Sunday $ risk --
					mi = new MenuItem { Header = 
						(pMaxRiskDollarsSunday<0 ? "Sun: OFF":(pMaxRiskDollarsSunday > 0 ? "Sun: $"+this.pMaxRiskDollarsSunday.ToString("0")+"/trade" : $"Sun: {pMinContracts}-contract, std SL level")),
						Name = "pMaxRiskDollarsSunday"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pMaxRiskDollarsSunday>=0);
					mi.ToolTip = "Click to turn off";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						if(pMaxRiskDollarsSunday<0) pMaxRiskDollarsSunday = 0;
						else if(pMaxRiskDollarsSunday==0) pMaxRiskDollarsSunday = 200;
						else pMaxRiskDollarsSunday = -1;
						var m = (MenuItem)o;
						if(pMaxRiskDollarsSunday<0)
							m.Header = "Sun: OFF";
						else if(pMaxRiskDollarsSunday==0)
							m.Header = $"Sun: {pMinContracts}-contract, std SL level";
						else
							m.Header = string.Format("Sun: ${0}{1}", this.pMaxRiskDollarsSunday.ToString("0"),"/trade");
						SetFontAndBackground(m, pMaxRiskDollarsSunday>=0);
						DollarsRiskPerTrade[DayOfWeek.Sunday]   = pMaxRiskDollarsSunday;
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(e.Delta>0){
							if(pMaxRiskDollarsSunday<0) pMaxRiskDollarsSunday = 0;
							else pMaxRiskDollarsSunday += 10;
						}else
							pMaxRiskDollarsSunday -= 10;
						if(pMaxRiskDollarsSunday<0) pMaxRiskDollarsSunday = -1;
						SetHeader(mi, "Sun", pMaxRiskDollarsSunday);
						var m = (MenuItem)o;
//						if(pMaxRiskDollarsSunday<0)
//							m.Header = "Sun: OFF";
//						else if(pMaxRiskDollarsSunday==0)
//							m.Header = $"Sun: {pMinContracts}-contract, std SL level";
//						else
//							m.Header = string.Format("Sun: ${0}{1}", this.pMaxRiskDollarsSunday.ToString("0"),"/trade");
						SetFontAndBackground(m, pMaxRiskDollarsSunday>=0);
						DollarsRiskPerTrade[DayOfWeek.Sunday]   = pMaxRiskDollarsSunday;
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};

					MenuControl.Items.Add(mi);
					#endregion
					#region -- Monday $ risk --
					mi = new MenuItem { Header = 
						(pMaxRiskDollarsMonday<0 ? "Mon: OFF":(pMaxRiskDollarsMonday > 0 ? "Mon: $"+this.pMaxRiskDollarsMonday.ToString("0")+"/trade" : $"Mon: {pMinContracts}-contract, std SL level")),
						Name = "pMaxRiskDollarsMonday"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pMaxRiskDollarsMonday>=0);
					mi.ToolTip = "Click to turn off";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						if(pMaxRiskDollarsMonday<0) pMaxRiskDollarsMonday = 0;
						else if(pMaxRiskDollarsMonday==0) pMaxRiskDollarsMonday = 200;
						else pMaxRiskDollarsMonday = -1;
						var m = (MenuItem)o;
						if(Keyboard.IsKeyDown(Key.LeftShift)) SetRisk("All", pMaxRiskDollarsMonday);
						else DollarsRiskPerTrade[DayOfWeek.Monday]  = pMaxRiskDollarsMonday;
						SetHeader(m, "Mon", pMaxRiskDollarsMonday);
						SetFontAndBackground(m, pMaxRiskDollarsMonday>=0);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(e.Delta>0){
							if(pMaxRiskDollarsMonday<0) pMaxRiskDollarsMonday = 0;
							else pMaxRiskDollarsMonday += 10;
						}else
							pMaxRiskDollarsMonday -= 10;
						if(pMaxRiskDollarsMonday<0) pMaxRiskDollarsMonday = -1;
						var m = (MenuItem)o;
						if(Keyboard.IsKeyDown(Key.LeftShift)) SetRisk("All", pMaxRiskDollarsMonday);
						else DollarsRiskPerTrade[DayOfWeek.Monday]  = pMaxRiskDollarsMonday;
						SetHeader(m, "Mon", pMaxRiskDollarsMonday);
						SetFontAndBackground(m, pMaxRiskDollarsMonday>=0);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};

					MenuControl.Items.Add(mi);
					#endregion
					#region -- Tuesday $ risk --
					mi = new MenuItem { Header = 
						(pMaxRiskDollarsTuesday<0 ? "Tue: OFF":(pMaxRiskDollarsTuesday > 0 ? "Tue: $"+this.pMaxRiskDollarsTuesday.ToString("0")+"/trade" : $"Tue: {pMinContracts}-contract, std SL level")),
						Name = "pMaxRiskDollarsTuesday"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pMaxRiskDollarsTuesday>=0);
					mi.ToolTip = "Click to turn off";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						if(pMaxRiskDollarsTuesday<0) pMaxRiskDollarsTuesday = 0;
						else if(pMaxRiskDollarsTuesday==0) pMaxRiskDollarsTuesday = 200;
						else pMaxRiskDollarsTuesday = -1;
						var m = (MenuItem)o;
						if(Keyboard.IsKeyDown(Key.LeftShift)) SetRisk("All", pMaxRiskDollarsTuesday);
						else DollarsRiskPerTrade[DayOfWeek.Tuesday]  = pMaxRiskDollarsTuesday;
						SetHeader(m, "Tue", pMaxRiskDollarsTuesday);
						SetFontAndBackground(m, pMaxRiskDollarsTuesday>=0);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(e.Delta>0){
							if(pMaxRiskDollarsTuesday<0) pMaxRiskDollarsTuesday = 0;
							else pMaxRiskDollarsTuesday += 10;
						}else
							pMaxRiskDollarsTuesday -= 10;
						if(pMaxRiskDollarsTuesday<0) pMaxRiskDollarsTuesday = -1;
						var m = (MenuItem)o;
						if(Keyboard.IsKeyDown(Key.LeftShift)) SetRisk("All", pMaxRiskDollarsTuesday);
						else DollarsRiskPerTrade[DayOfWeek.Tuesday]  = pMaxRiskDollarsTuesday;
						SetHeader(m, "Tue", pMaxRiskDollarsTuesday);
						SetFontAndBackground(m, pMaxRiskDollarsTuesday>=0);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};

					MenuControl.Items.Add(mi);
					#endregion
					#region -- Wednesday $ risk --
					mi = new MenuItem { Header = 
						(pMaxRiskDollarsWednesday<0 ? "Wed: OFF":(pMaxRiskDollarsWednesday > 0 ? "Wed: $"+this.pMaxRiskDollarsWednesday.ToString("0")+"/trade" : $"Wed: {pMinContracts}-contract, std SL level")),
						Name = "pMaxRiskDollarsWednesday"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pMaxRiskDollarsWednesday>=0);
					mi.ToolTip = "Click to turn off";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						if(pMaxRiskDollarsWednesday<0) pMaxRiskDollarsWednesday = 0;
						else if(pMaxRiskDollarsWednesday==0) pMaxRiskDollarsWednesday = 200;
						else pMaxRiskDollarsWednesday = -1;
						var m = (MenuItem)o;
						if(Keyboard.IsKeyDown(Key.LeftShift)) SetRisk("All", pMaxRiskDollarsWednesday);
						else DollarsRiskPerTrade[DayOfWeek.Wednesday]= pMaxRiskDollarsWednesday;
						SetHeader(m, "Wed", pMaxRiskDollarsWednesday);
						SetFontAndBackground(m, pMaxRiskDollarsWednesday>=0);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(e.Delta>0){
							if(pMaxRiskDollarsWednesday<0) pMaxRiskDollarsWednesday = 0;
							else pMaxRiskDollarsWednesday += 10;
						}else
							pMaxRiskDollarsWednesday -= 10;
						if(pMaxRiskDollarsWednesday<0) pMaxRiskDollarsWednesday = -1;
						var m = (MenuItem)o;
						if(Keyboard.IsKeyDown(Key.LeftShift)) SetRisk("All", pMaxRiskDollarsWednesday);
						else DollarsRiskPerTrade[DayOfWeek.Wednesday]= pMaxRiskDollarsWednesday;
						SetHeader(m, "Wed", pMaxRiskDollarsWednesday);
						SetFontAndBackground(m, pMaxRiskDollarsWednesday>=0);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};

					MenuControl.Items.Add(mi);
					#endregion
					#region -- Thursday $ risk --
					mi = new MenuItem { Header = 
						(pMaxRiskDollarsThursday<0 ? "Thu: OFF":(pMaxRiskDollarsThursday > 0 ? "Thu: $"+this.pMaxRiskDollarsThursday.ToString("0")+"/trade" : $"Thu: {pMinContracts}-contract, std SL level")),
						Name = "pMaxRiskDollarsThursday"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pMaxRiskDollarsThursday>=0);
					mi.ToolTip = "Click to turn off";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						if(pMaxRiskDollarsThursday<0) pMaxRiskDollarsThursday = 0;
						else if(pMaxRiskDollarsThursday ==0) pMaxRiskDollarsThursday = 200;
						else pMaxRiskDollarsThursday = -1;
						var m = (MenuItem)o;
						if(Keyboard.IsKeyDown(Key.LeftShift)) SetRisk("All", pMaxRiskDollarsThursday);
						else DollarsRiskPerTrade[DayOfWeek.Thursday] = pMaxRiskDollarsThursday;
						SetHeader(m, "Thu", pMaxRiskDollarsThursday);
						SetFontAndBackground(m, pMaxRiskDollarsThursday>=0);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(e.Delta>0){
							if(pMaxRiskDollarsThursday<0) pMaxRiskDollarsThursday = 0;
							else pMaxRiskDollarsThursday += 10;
						}else
							pMaxRiskDollarsThursday -= 10;
						if(pMaxRiskDollarsThursday<0) pMaxRiskDollarsThursday = -1;
						var m = (MenuItem)o;
						if(Keyboard.IsKeyDown(Key.LeftShift)) SetRisk("All", pMaxRiskDollarsThursday);
						else DollarsRiskPerTrade[DayOfWeek.Thursday] = pMaxRiskDollarsThursday;
						SetHeader(m, "Thu", pMaxRiskDollarsThursday);
						SetFontAndBackground(m, pMaxRiskDollarsThursday>=0);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};

					MenuControl.Items.Add(mi);
					#endregion
					#region -- Friday $ risk --
					mi = new MenuItem { Header = 
						(pMaxRiskDollarsFriday<0 ? "Fri: OFF":(pMaxRiskDollarsFriday > 0 ? "Fri: $"+this.pMaxRiskDollarsFriday.ToString("0")+"/trade" : $"Fri: {pMinContracts}-contract, std SL level")),
						Name = "pMaxRiskDollarsFriday"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pMaxRiskDollarsFriday>=0);
					mi.ToolTip = "Click to turn off";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						if(pMaxRiskDollarsFriday<0) pMaxRiskDollarsFriday = 0;
						else if(pMaxRiskDollarsFriday==0) pMaxRiskDollarsFriday = 200;
						else pMaxRiskDollarsFriday = -1;
						if(Keyboard.IsKeyDown(Key.LeftShift)) SetRisk("All", pMaxRiskDollarsFriday);
						else DollarsRiskPerTrade[DayOfWeek.Friday]   = pMaxRiskDollarsFriday;
						var m = (MenuItem)o;
						SetHeader(m, "Fri", pMaxRiskDollarsFriday);
						SetFontAndBackground(m, pMaxRiskDollarsFriday>=0);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(e.Delta>0){
							if(pMaxRiskDollarsFriday<0) pMaxRiskDollarsFriday = 0;
							else pMaxRiskDollarsFriday += 10;
						}else
							pMaxRiskDollarsFriday -= 10;
						if(pMaxRiskDollarsFriday<0) pMaxRiskDollarsFriday = -1;
						if(Keyboard.IsKeyDown(Key.LeftShift)) SetRisk("All", pMaxRiskDollarsFriday);
						else DollarsRiskPerTrade[DayOfWeek.Friday]   = pMaxRiskDollarsFriday;
						var m = (MenuItem)o;
						SetHeader(m, "Fri", pMaxRiskDollarsFriday);
						SetFontAndBackground(m, pMaxRiskDollarsFriday>=0);
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};

					MenuControl.Items.Add(mi);
					#endregion
					#region -- Saturday $ risk --
					mi = new MenuItem { Header = 
						(pMaxRiskDollarsSaturday<0 ? "Sat: OFF":(pMaxRiskDollarsSaturday > 0 ? "Sat: $"+this.pMaxRiskDollarsSaturday.ToString("0")+"/trade" : $"Sat: {pMinContracts}-contract, std SL level")),
						Name = "pMaxRiskDollarsSaturday"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pMaxRiskDollarsSaturday>=0);
					mi.ToolTip = "Click to turn off";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						if(pMaxRiskDollarsSaturday<0) pMaxRiskDollarsSaturday = 0;
						else if(pMaxRiskDollarsSaturday==0) pMaxRiskDollarsSaturday = 200;
						else pMaxRiskDollarsSaturday = -1;
						var m = (MenuItem)o;
						SetFontAndBackground(m, pMaxRiskDollarsSaturday>=0);
						SetHeader(m, "Sat", pMaxRiskDollarsSaturday);
						DollarsRiskPerTrade[DayOfWeek.Saturday] = pMaxRiskDollarsSaturday;
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(e.Delta>0){
							if(pMaxRiskDollarsSaturday<0) pMaxRiskDollarsSaturday = 0;
							else pMaxRiskDollarsSaturday += 10;
						}else
							pMaxRiskDollarsSaturday -= 10;
						if(pMaxRiskDollarsSaturday<0) pMaxRiskDollarsSaturday = -1;
						var m = (MenuItem)o;
						SetHeader(m, "Sat", pMaxRiskDollarsSaturday);
						SetFontAndBackground(m, pMaxRiskDollarsSaturday>=0);
						DollarsRiskPerTrade[DayOfWeek.Saturday] = pMaxRiskDollarsSaturday;
						miRecalc.Visibility = Visibility.Visible;
						ForceRefresh();
					};

					MenuControl.Items.Add(mi);
					#endregion

					#region -- Font size --
					mi = new MenuItem { Header = "Font size: "+this.SummaryFontSize.ToString("0"), Name = "SummaryFontSize"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					mi.FontWeight = FontWeights.Normal;
					mi.ToolTip = "Click to hide summary text, or set size to 0";
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						ShowSummaryTable = !ShowSummaryTable;
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						if(e.Delta>0)
							SummaryFontSize += 1;
						else
							SummaryFontSize -= 1;
						SummaryFontSize = Math.Max(0, SummaryFontSize);
						var m = (MenuItem)o;
						m.Header = "Font size: "+this.SummaryFontSize.ToString("0");
						if(SummaryFontSize>0)
							pSummaryFont.Size = SummaryFontSize;

						ForceRefresh();
					};

					MenuControl.Items.Add(mi);
					#endregion

					#region -- Show PnL By DOW --
					mi = new MenuItem { Header = "Show PnL by DOW?  "+(pShowPnLByDOW ? "YES":"no"), Name = "pShowPnLByDOW"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pShowPnLByDOW);
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pShowPnLByDOW = !pShowPnLByDOW; 
						var m = (MenuItem)o;
						m.Header = "Show PnL by DOW?  "+(pShowPnLByDOW ? "YES":"no");
						SetFontAndBackground(m, pShowPnLByDOW);
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						pShowPnLByDOW = !pShowPnLByDOW; 
						var m = (MenuItem)o;
						m.Header = "Show PnL by DOW?  "+(pShowPnLByDOW ? "YES":"no");
						SetFontAndBackground(m, pShowPnLByDOW);
						if(pShowPnLByDOW) m.Background = Brushes.LightGray; else m.Background = Brushes.Transparent;
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					#endregion
					#region -- Show Drawdowns --
					mi = new MenuItem { Header = "Show Drawdowns?  "+(pShowDrawdowns ? "YES":"no"), Name = "pShowDrawdowns"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pShowDrawdowns);
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pShowDrawdowns = !pShowDrawdowns; 
						var m = (MenuItem)o;
						m.Header = "Show Drawdowns?  "+(pShowDrawdowns ? "YES":"no");
						SetFontAndBackground(m, pShowDrawdowns);
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						pShowDrawdowns = !pShowDrawdowns; 
						var m = (MenuItem)o;
						m.Header = "Show Drawdowns?  "+(pShowDrawdowns ? "YES":"no");
						SetFontAndBackground(m, pShowDrawdowns);
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					#endregion
					#region -- Show Dispositions --
					mi = new MenuItem { Header = "Show Dispositions?  "+(pShowDispositions ? "YES":"no"), Name = "pShowDispositions"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
					SetFontAndBackground(mi, pShowDispositions);
					mi.Click += delegate (object o, RoutedEventArgs e)
					{
						pShowDispositions = !pShowDispositions; 
						var m = (MenuItem)o;
						m.Header = "Show Dispositions?  "+(pShowDispositions ? "YES":"no");
						SetFontAndBackground(m, pShowDispositions);
						ForceRefresh();
					};
					mi.MouseWheel += delegate (object o, MouseWheelEventArgs e){
						e.Handled = true;
						pShowDispositions = !pShowDispositions; 
						var m = (MenuItem)o;
						m.Header = "Show Dispositions?  "+(pShowDispositions ? "YES":"no");
						SetFontAndBackground(m, pShowDispositions);
						ForceRefresh();
					};
					MenuControl.Items.Add(mi);
					#endregion

					MenuControl.Items.Add(new Separator());

					#region -- Silence alerts --
					mi = new MenuItem { Header = "Audible Alerts "+(pSilenceAllAlerts?"OFF":"ON"), Foreground = Brushes.Black, StaysOpenOnClick = true};
					mi.Click += delegate (object o, RoutedEventArgs e){
						e.Handled = true;
						pSilenceAllAlerts= !pSilenceAllAlerts;
						mi.Header = "Audible Alerts "+(pSilenceAllAlerts?"OFF":"ON");
					};
					MenuControl.Items.Add(mi);
					#endregion

					#region -- Recalc --
					miRecalc = new MenuItem { Header = "Re-calc (F5 key)", Background = Brushes.Yellow, HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false, Visibility=Visibility.Hidden };
					miRecalc.Click += delegate (object o, RoutedEventArgs e){
						e.Handled = true;
						miRecalc.Visibility = Visibility.Hidden;
						System.Windows.Forms.SendKeys.SendWait("{F5}");
					};
					MenuControl.Items.Add(miRecalc);
					#endregion
					#region -- finalize add of toolbar --
					indytoolbar.Children.Add(MenuControlContainer);
					chartWindow.MainMenu.Add(indytoolbar);
				    chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

				    foreach (TabItem tab in chartWindow.MainTabControl.Items) 
						if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
				    System.Windows.Automation.AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
					IsToolBarButtonAdded = true;
					#endregion
				}
			}));
		}
		private void SetFontAndBackground(MenuItem mi, bool TF){
			if(TF) {
				mi.Background = Brushes.LightGray; 
				mi.FontWeight = FontWeights.Bold;
			}
			else{
				mi.Background = Brushes.Transparent;
				mi.FontWeight = FontWeights.Normal;
			}
		}
		private void SetRisk(string days, double riskval){
			foreach(var m in MenuControl.Items) {
				try{
					MenuItem mi = (MenuItem)m;
					//Print(mi.Header.ToString()+"    "+mi.Name);
					if(days == "All"){
						if(mi.Name.StartsWith("pMaxRiskDollarsMonday"))    {pMaxRiskDollarsMonday = riskval;    SetFontAndBackground(mi, pMaxRiskDollarsMonday>=0);    SetHeader(mi, "Mon", pMaxRiskDollarsMonday);}
						if(mi.Name.StartsWith("pMaxRiskDollarsTuesday"))   {pMaxRiskDollarsTuesday = riskval;   SetFontAndBackground(mi, pMaxRiskDollarsTuesday>=0);   SetHeader(mi, "Tue", pMaxRiskDollarsTuesday);}
						if(mi.Name.StartsWith("pMaxRiskDollarsWednesday")) {pMaxRiskDollarsWednesday = riskval; SetFontAndBackground(mi, pMaxRiskDollarsWednesday>=0); SetHeader(mi, "Wed", pMaxRiskDollarsWednesday);}
						if(mi.Name.StartsWith("pMaxRiskDollarsThursday"))  {pMaxRiskDollarsThursday = riskval;  SetFontAndBackground(mi, pMaxRiskDollarsThursday>=0);  SetHeader(mi, "Thu", pMaxRiskDollarsThursday);}
						if(mi.Name.StartsWith("pMaxRiskDollarsFriday"))    {pMaxRiskDollarsFriday = riskval;    SetFontAndBackground(mi, pMaxRiskDollarsFriday>=0);    SetHeader(mi, "Fri", pMaxRiskDollarsFriday);}
					}else{
						if(days.Contains("M")  && mi.Name.StartsWith("pMaxRiskDollarsMonday"))   {pMaxRiskDollarsMonday = riskval;    SetFontAndBackground(mi, pMaxRiskDollarsMonday >= 0);    SetHeader(mi, "Mon", pMaxRiskDollarsMonday);}
						if(days.Contains("Tu") && mi.Name.StartsWith("pMaxRiskDollarsTuesday"))  {pMaxRiskDollarsTuesday = riskval;   SetFontAndBackground(mi, pMaxRiskDollarsTuesday >= 0);   SetHeader(mi, "Tue", pMaxRiskDollarsTuesday);}
						if(days.Contains("W")  && mi.Name.StartsWith("pMaxRiskDollarsWednesday")){pMaxRiskDollarsWednesday = riskval; SetFontAndBackground(mi, pMaxRiskDollarsWednesday >= 0); SetHeader(mi, "Wed", pMaxRiskDollarsWednesday);}
						if(days.Contains("Th") && mi.Name.StartsWith("pMaxRiskDollarsThursday")) {pMaxRiskDollarsThursday = riskval;  SetFontAndBackground(mi, pMaxRiskDollarsThursday >= 0);  SetHeader(mi, "Thu", pMaxRiskDollarsThursday);}
						if(days.Contains("F")  && mi.Name.StartsWith("pMaxRiskDollarsFriday"))   {pMaxRiskDollarsFriday = riskval;    SetFontAndBackground(mi, pMaxRiskDollarsFriday >= 0);    SetHeader(mi, "Fri", pMaxRiskDollarsFriday);}
					}
					DollarsRiskPerTrade[DayOfWeek.Monday]    = pMaxRiskDollarsMonday;
					DollarsRiskPerTrade[DayOfWeek.Tuesday]   = pMaxRiskDollarsTuesday;
					DollarsRiskPerTrade[DayOfWeek.Wednesday] = pMaxRiskDollarsWednesday;
					DollarsRiskPerTrade[DayOfWeek.Thursday]  = pMaxRiskDollarsThursday;
					DollarsRiskPerTrade[DayOfWeek.Friday]    = pMaxRiskDollarsFriday;
				}catch{}
			}
		}
		private void SetHeader(MenuItem m, string dow, double risk){
			if(risk<0)
				m.Header = dow+": OFF";
			else if(risk==0)
				m.Header = dow+$": {pMinContracts}-contract, std SL level";
			else
				m.Header = string.Format(dow+": ${0}{1}", risk.ToString("0"),"/trade");
		}
		private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			var tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}
		#endregion ------------------------------------------------------------------

		private float pOpacity = 100;
		int SelectedDayOfWeek = -1;
		#region -- Mouse and Key events --
		private void OnMouseWheel(object sender, MouseWheelEventArgs e)
		{
			//e.Handled = true;
			if(Keyboard.IsKeyDown(Key.LeftCtrl)){
				e.Handled = true;
				if(e.Delta>0) pOpacity++;
				else pOpacity--;
			}
			if(TimeSlicePnLChartToggle){
				e.Handled = true;
				int incr = e.Delta>0 ? 1 : -1;
				SelectedDayOfWeek += incr;
				if(SelectedDayOfWeek < -1) SelectedDayOfWeek = 6;
				if(SelectedDayOfWeek > 6) SelectedDayOfWeek = -1;
				List<int> ValidDays = new List<int>(){-1};
				if(pMaxRiskDollarsSunday>=0    && DaysOfWeekToTradeNumber.Contains("0")) ValidDays.Add(0);
				if(pMaxRiskDollarsMonday>=0    && DaysOfWeekToTradeNumber.Contains("1")) ValidDays.Add(1);
				if(pMaxRiskDollarsTuesday>=0   && DaysOfWeekToTradeNumber.Contains("2")) ValidDays.Add(2);
				if(pMaxRiskDollarsWednesday>=0 && DaysOfWeekToTradeNumber.Contains("3")) ValidDays.Add(3);
				if(pMaxRiskDollarsThursday>=0  && DaysOfWeekToTradeNumber.Contains("4")) ValidDays.Add(4);
				if(pMaxRiskDollarsFriday>=0    && DaysOfWeekToTradeNumber.Contains("5")) ValidDays.Add(5);
				if(pMaxRiskDollarsSaturday>=0  && DaysOfWeekToTradeNumber.Contains("6")) ValidDays.Add(6);
				if(ValidDays.Count==0) SelectedDayOfWeek = 0;
				else{
					while(!ValidDays.Contains(SelectedDayOfWeek)) {
						SelectedDayOfWeek += incr;
						if(SelectedDayOfWeek < ValidDays.Min()) SelectedDayOfWeek = ValidDays.Max();
						if(SelectedDayOfWeek > ValidDays.Max()) SelectedDayOfWeek = ValidDays.Min();
					}
				}

//				if(SelectedDayOfWeek == 0 && pMaxRiskDollarsSunday<0)    SelectedDayOfWeek += incr;
//				if(SelectedDayOfWeek == 1 && pMaxRiskDollarsMonday<0)    SelectedDayOfWeek += incr;
//				if(SelectedDayOfWeek == 2 && pMaxRiskDollarsTuesday<0)   SelectedDayOfWeek += incr;
//				if(SelectedDayOfWeek == 3 && pMaxRiskDollarsWednesday<0) SelectedDayOfWeek += incr;
//				if(SelectedDayOfWeek == 4 && pMaxRiskDollarsThursday<0)  SelectedDayOfWeek += incr;
//				if(SelectedDayOfWeek == 5 && pMaxRiskDollarsFriday<0)    SelectedDayOfWeek += incr;
//				if(SelectedDayOfWeek == 6 && pMaxRiskDollarsSaturday<0 && pMaxRiskDollarsSunday<0) SelectedDayOfWeek=1;
//				else if(SelectedDayOfWeek == 6 && pMaxRiskDollarsSaturday<0) SelectedDayOfWeek=0;
				//				Print(SelectedDayOfWeek);
			}
			ForceRefresh();
		}
		private void OnKeyDown (object sender, KeyEventArgs e)
		{
			if(e==null) return;
			if(Keyboard.IsKeyDown(Key.LeftCtrl)){
				PnLChartToggle = false;
				TimeSlicePnLChartToggle = false;
				ForceRefresh();
			}
		}
		int MouseX = 0;
		int MouseY = 0;
		public static string SelectedTab = "";
        private void OnMouseMove(object sender, MouseEventArgs e)
        {
			#region -- OnMouseMove -----------------------------------------------------------
			SelectedTab = uID;
			Point coords = e.GetPosition(ChartPanel);
			MouseX = ChartingExtensions.ConvertToHorizontalPixels(coords.X, ChartControl.PresentationSource);//+ barwidth_int;
			MouseY = ChartingExtensions.ConvertToVerticalPixels(coords.Y, ChartControl.PresentationSource);
			if(TimeSlicePnLChartToggle) ForceRefresh();
			#endregion
		}
		#endregion ------------------------

		#region -- LowBar and HighBar methods --
		// Returns the number of bars ago a zig zag low occurred. Returns a value of -1 if a zig zag low is not found within the look back period.
		public int LowBar(int barsAgo, int instance, int lookBackPeriod)
		{
			if (instance < 1)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.ZigZagLowBarInstanceGreaterEqual, GetType().Name, instance));
			if (barsAgo < 0)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.ZigZigLowBarBarsAgoGreaterEqual, GetType().Name, barsAgo));
			if (barsAgo >= Count)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.ZigZagLowBarBarsAgoOutOfRange, GetType().Name, (Count - 1), barsAgo));

			Update();
			for (int idx = CurrentBar - barsAgo - 1; idx >= CurrentBar - barsAgo - 1 - lookBackPeriod; idx--)
			{
				if (idx < 0)
					return -1;
				if (idx >= zigZagLowZigZags.Count)
					continue;

				if (!zigZagLowZigZags.IsValidDataPointAt(idx))
					continue;

				if (instance == 1) // 1-based, < to be save
					return CurrentBar - idx;

				instance--;
			}

			return -1;
		}

		// Returns the number of bars ago a zig zag high occurred. Returns a value of -1 if a zig zag high is not found within the look back period.
		public int HighBar(int barsAgo, int instance, int lookBackPeriod)
		{
			if (instance < 1)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.ZigZagHighBarInstanceGreaterEqual, GetType().Name, instance));
			if (barsAgo < 0)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.ZigZigHighBarBarsAgoGreaterEqual, GetType().Name, barsAgo));
			if (barsAgo >= Count)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.ZigZagHighBarBarsAgoOutOfRange, GetType().Name, (Count - 1), barsAgo));

			Update();
			for (int idx = CurrentBar - barsAgo - 1; idx >= CurrentBar - barsAgo - 1 - lookBackPeriod; idx--)
			{
				if (idx < 0)
					return -1;
				if (idx >= zigZagHighZigZags.Count)
					continue;

				if (!zigZagHighZigZags.IsValidDataPointAt(idx))
					continue;

				if (instance <= 1) // 1-based, < to be save
					return CurrentBar - idx;

				instance--;
			}

			return -1;
		}
		#endregion
		private class NodeData{
			public double Price;
			public char Type;
			public int ABar;
			public NodeData(double price, char type, int abar){
				Price = price;
				Type  = type;
				ABar  = abar;
			}
		}
		private List<NodeData> Nodes = new List<NodeData>();
		bool TradeResultsPrinted = false;
		int CANCELLED_ID = -999;
		bool ss = false;
		SortedDictionary<DayOfWeek,List<double>> PnLByDOW = null;//0-element will be the win count, 1-element will be loss count, all subsequent elements will be the ticks profit for each trade
		List<double> PnL = new List<double>();
		private string PnLText;
		private string PnLByDOWText="";
		private string DrawdownsText="";
		private string DispositionsText="";
		private string StatusText = "";
		private SortedDictionary<string,string> StatusTextDir = new SortedDictionary<string,string>();
		bool InSessionNow = false;
		bool IsBetweenStartAndStopTimes = false;
		private List<int> ABarsAtStopTime = new List<int>();
//=========================================================================================================
		protected override void OnBarUpdate()
		{
#if DO_LICENSE_v1
			if(!ValidLicense) return;
#endif
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
//			Now = Times[0][0];
			if (CurrentBar < 2) // Need at least 3 bars to calculate Low/High
			{
				zigZagHighSeries[0]		= 0;
				zigZagLowSeries[0] 		= 0;
				return;
			}

			int tt1 = ToTime(Times[0][1])/100;
			int tt = ToTime(Times[0][0])/100;
ss = false;//Times[0][0].Day==1;
ss = Times[0][0].Hour==7 && Times[0][0].Minute>=0 && Times[0][0].Day==3 && Times[0][0].Month==10;
int line=2276;
try{
if(ss)Print("\nTime "+Times[0][0].ToString());
				var dow = Times[0].GetValueAt(CurrentBar).DayOfWeek;
				var dowint = (int)dow;
				#region -- Determine in-session or out-of-session --
//				IsBetweenStartAndStopTimes = true;
				InSessionNow = true;
				if(!Bars.BarsType.IsIntraday){
					InSessionABars = null;
				}else{
					InSessionNow = false;
//					IsBetweenStartAndStopTimes = false;
					if(DaysOfWeekToTradeNumber.Contains(dowint.ToString()) && DollarsRiskPerTrade[dow]>=0){
						if(pStartTime == pStopTime){
							InSessionABars = null;
							InSessionNow = true;
							IsBetweenStartAndStopTimes = true;
						}else{
							if(pStartTime < pEODTime){
								if(tt>=pStartTime && tt<pEODTime){
									InSessionABars.Add(CurrentBar);
									InSessionNow = true;
								}
							} else {
								if(tt>=pStartTime || tt < pEODTime){
									InSessionABars.Add(CurrentBar);
									InSessionNow = true;
								}
							}
							bool c1 = tt1<pStartTime;
							bool c2 = Times[0][1].Day != Times[0][0].Day;
							if((c1||c2) && tt >= pStartTime)
								IsBetweenStartAndStopTimes = true;
							if(tt1<pStopTime && tt >= pStopTime){
								IsBetweenStartAndStopTimes = false;
								if(pStopTime!=pEODTime){
									if(ABarsAtStopTime.Count==0) ABarsAtStopTime.Add(CurrentBars[0]);
									else if(ABarsAtStopTime.Last()!=CurrentBars[0]) ABarsAtStopTime.Add(CurrentBars[0]);
								}
//Draw.VerticalLine(this,CurrentBars[0].ToString()+"vv",Times[0][0],Brushes.Yellow);
							}
						}
					}
					if(!InSessionNow) {
						permitteddir = 'A';//at the end of the session, all trade directions are permitted at the start of the next session
//						TradesThisSession = 0;
					}
				}
				#endregion
//Print("InSessionNow: "+InSessionNow.ToString()+"   IsBetweenStartAndStopTimes: "+IsBetweenStartAndStopTimes.ToString()+"   tt1: "+tt1.ToString()+"   Times[0][0]: "+Times[0][0].ToString());
				#region -- Calculate entries/exits --
				int cancelled_count = 0;
				List<KeyValuePair<int,TradeData>> trades = Trades.Where(k=>k.Value.ExitABar == 0).ToList<KeyValuePair<int, TradeData>>();//trades that have not exited
				foreach(var tr in trades){
//					if(tr.Value.EntryABar==0 && InSessionABars!=null && !InSessionABars.Contains(CurrentBar)){//sessions are enabled, and the current bar is out of session
					if(tr.Value.EntryABar==0 && !InSessionNow){//sessions are enabled, and the current bar is out of session
						tr.Value.EntryABar = CANCELLED_ID;
						tr.Value.Disposition = "End of session, this pending order was CANCELLED";
//Draw.Dot(this,tr.Key.ToString(),false,CurrentBar-tr.Key, Medians[0].GetValueAt(tr.Key),Brushes.White);
//						string tag = string.Format("tri {0} {1}RR {2}-contracts", tr.Key, pRewardToRisk, tr.Value.Contracts);
//						RemoveDrawObject(tag);
					}
					#region -- 2bar in profit trailing stop --
					if(tr.Value.EntryABar > 0){
						if(pEngageBEStop && !tr.Value.IsBEEngaged){
							#region -- Check for BE stop engagement -- 
							if(tr.Value.Dir=='L' && tr.Value.EntryPrice < Lows[0][0] && tr.Value.EntryPrice < Lows[0][1]){
								tr.Value.IsBEEngaged = true;
								tr.Value.Disposition = "BE Engaged "+Times[0][0].ToString();
								tr.Value.StopPrice = tr.Value.EntryPrice+TickSize;
if(ss)Print("2bar BE Engaged, stop now at "+tr.Value.StopPrice);
								tr.Value.SLHistory[CurrentBars[0]] = tr.Value.StopPrice;
								if(State != State.Historical) {
									string msg = "Move LONG position trailing stop to "+Instrument.MasterInstrument.FormatPrice(tr.Value.StopPrice);
									if(pTrailingStopWAV!="SOUND OFF") 
										PlayAlert(Nodes[1].ABar.ToString(), msg, AddSoundFolder(pTrailingStopWAV), Brushes.Green);
									if(pEmailTrailingStopSignal.Trim().Length>0)
										SendMail(pEmailTrailingStopSignal.Trim(),"StructureBoss "+Instruments[0].FullName+" "+msg, msg);
//									Alert(DateTime.Now.Ticks.ToString(),Priority.High, msg, AddSoundFolder(pTrailingStopWAV),1,Brushes.Black,Brushes.Green);
//									Print(msg); 
								}
							}
							if(tr.Value.Dir=='S' && tr.Value.EntryPrice > Highs[0][0] && tr.Value.EntryPrice > Highs[0][1]){
								tr.Value.IsBEEngaged = true;
								tr.Value.Disposition = "BE Engaged "+Times[0][0].ToString();
								tr.Value.StopPrice = tr.Value.EntryPrice-TickSize;
if(ss)Print("2bar BE Engaged, stop now at "+tr.Value.StopPrice);
								tr.Value.SLHistory[CurrentBars[0]] = tr.Value.StopPrice;
								if(State != State.Historical){
									string msg = "Move SHORT position trailing stop to "+Instrument.MasterInstrument.FormatPrice(tr.Value.StopPrice);
									if(pTrailingStopWAV!="SOUND OFF") 
										PlayAlert(DateTime.Now.Ticks.ToString(), msg, AddSoundFolder(pTrailingStopWAV), Brushes.Green);
									if(pEmailTrailingStopSignal.Trim().Length>0)
										SendMail(pEmailTrailingStopSignal.Trim(),"StructureBoss "+Instruments[0].FullName+" "+msg, msg);
//									Print("msg"); 
								}
							}
							#endregion
						}
						if(pEngageTrailingStop && (tr.Value.IsBEEngaged || !pEngageBEStop)){
							#region -- Check for trailing stop placement/movement --
							if(tr.Value.Dir == 'L'){
								double tstop = tr.Value.StopPrice;
								tr.Value.StopPrice = Instrument.MasterInstrument.RoundToTickSize(Math.Max(tr.Value.StopPrice, Highs[0][0] - atr[0] * pTrailingStopATRMult));
if(ss)Print("Trailing stop Engaged, stop now at "+tr.Value.StopPrice);
								tr.Value.SLHistory[CurrentBars[0]] = tr.Value.StopPrice;
								if(tstop!=tr.Value.StopPrice) {
									string msg = "Move LONG position trailing stop to "+Instrument.MasterInstrument.FormatPrice(tr.Value.StopPrice);
//Print(tr.Value.EnterAt.ToString()+"    trailing at "+tr.Value.StopPrice);
									if(pTrailingStopWAV!="SOUND OFF") 
										PlayAlert(DateTime.Now.Ticks.ToString(), msg, AddSoundFolder(pTrailingStopWAV), Brushes.Green);
									if(pEmailTrailingStopSignal.Trim().Length>0)
										SendMail(pEmailTrailingStopSignal.Trim(),"StructureBoss "+Instruments[0].FullName+" "+msg, msg);
									tr.Value.Disposition = "Trailing stop advanced from "+tstop.ToString()+" to "+tr.Value.StopPrice.ToString();
								}
							}
							else if(tr.Value.Dir == 'S'){
								double tstop = tr.Value.StopPrice;
								tr.Value.StopPrice = Instrument.MasterInstrument.RoundToTickSize(Math.Min(tr.Value.StopPrice, Lows[0][0] + atr[0] * pTrailingStopATRMult));
if(ss)Print("Trailing stop Engaged, stop now at "+tr.Value.StopPrice);
								tr.Value.SLHistory[CurrentBars[0]] = tr.Value.StopPrice;
								if(tstop!=tr.Value.StopPrice){
									string msg = "Move SHORT position trailing stop to "+Instrument.MasterInstrument.FormatPrice(tr.Value.StopPrice);
									if(pTrailingStopWAV!="SOUND OFF") 
										PlayAlert(DateTime.Now.Ticks.ToString(), msg, AddSoundFolder(pTrailingStopWAV), Brushes.Green);
									if(pEmailTrailingStopSignal.Trim().Length>0)
										SendMail(pEmailTrailingStopSignal.Trim(),"StructureBoss "+Instruments[0].FullName+" "+msg, msg);
									tr.Value.Disposition = "Trailing stop advanced from "+tstop.ToString()+" to "+tr.Value.StopPrice.ToString();
								}
							}
							#endregion
						}
					}
					#endregion
					#region -- determine entries --
					if(!IsBetweenStartAndStopTimes){
						if(tr.Value.EntryABar == 0){
							tr.Value.EntryABar = CANCELLED_ID;
							cancelled_count++;
							tr.Value.Disposition = "Pending entry is CANCELLED, outside of start-stop session times";
						}
					}else{
//						#region -- Skip if the DOW is not permitted
//						var dow = (int)Times[0].GetValueAt(CurrentBar).DayOfWeek;
//						if(!DaysOfWeekToTradeNumber.Contains(dow.ToString())) {continue;}
//						#endregion
if(ss)Print("2427   Signal "+Times[0].GetValueAt(tr.Key).ToString()+" disposition "+tr.Value.Disposition);
						if(tr.Value.EntryABar == 0 && tr.Value.Disposition.StartsWith("Pending")){
							if(tr.Value.Dir=='L' && Median[1]>=tr.Value.CancelPrice && Low[0] < tr.Value.CancelPrice){
								tr.Value.EntryABar = CANCELLED_ID;
								cancelled_count++;
//Draw.Square(this,"aCancelPriceHit "+tr.Key.ToString(),false,CurrentBar-tr.Key, tr.Value.CancelPrice, Brushes.Red);
								tr.Value.Disposition = "Pending entry is CANCELLED, cancel price hit";
//								string tag = string.Format("tri {0} {1}RR {2}-contracts", tr.Key, pRewardToRisk, tr.Value.Contracts);
//								RemoveDrawObject(tag);
							}
							if(tr.Value.Dir=='S' && Median[1]<tr.Value.CancelPrice && High[0] > tr.Value.CancelPrice){
								tr.Value.EntryABar = CANCELLED_ID;
								cancelled_count++;
								tr.Value.Disposition = "Pending entry is CANCELLED, cancel price hit";
//Draw.Square(this,"bCancelPriceHit "+tr.Key.ToString(),false,CurrentBar-tr.Key, tr.Value.CancelPrice, Brushes.Red);
//								string tag = string.Format("tri {0} {1}RR {2}-contracts", tr.Key, pRewardToRisk, tr.Value.Contracts);
//								RemoveDrawObject(tag);
							}
							if(tr.Value.EntryABar != CANCELLED_ID){
								if(tr.Value.Dir=='L' && Low[1]<=tr.Value.EntryPrice && High[0] > tr.Value.EntryPrice){
//									TradesThisSession++;
									if(!pPermitSameDirectionEntries){// && TradesThisSession>0){
										if(pType == PivotPointBoss_Type.Reversing){//buying now, permit shorts after this trade
											permitteddir = 'S';
										}
										else if(pType == PivotPointBoss_Type.Trending){//selling now, permit longs after this trade
											permitteddir = 'L';
										}
									}
									tr.Value.EntryABar   = CurrentBar;
									tr.Value.MFEDist_tks = (High[0] - tr.Value.EntryPrice)/TickSize;
									tr.Value.EnterAt     = Times[0][0];
									tr.Value.Disposition = "Position is filled Long at "+tr.Value.EntryPrice;
Draw.Diamond(this,"Filled "+tr.Key.ToString()+" c:"+tr.Value.Contracts,false,CurrentBar-tr.Key, tr.Value.EntryPrice, Brushes.Blue);
									if(pBuyFillWAV!="SOUND OFF")
										PlayAlert(CurrentBar.ToString(), "Triangle LONG", AddSoundFolder(pBuyFillWAV), Brushes.Green);
									if(pEmailFillSignal.Trim().Length>0)
										SendMail(pEmailFillSignal.Trim(),"StructureBoss LONG filled "+Instruments[0].FullName, "Filled at "+tr.Value.EntryPrice);
								}
//								if(tr.Value.Dir=='S'){
//									Print(Times[0].GetValueAt(tr.Key).ToString()+"   High[1]: "+High[1].ToString()+"   Low[0]: "+Low[0].ToString()+"   EP: "+tr.Value.EntryPrice);
//								}
								if(tr.Value.Dir=='S' && High[1]>tr.Value.EntryPrice && Low[0] < tr.Value.EntryPrice){
//									TradesThisSession++;
									if(!pPermitSameDirectionEntries){// && TradesThisSession>0){
										if(pType == PivotPointBoss_Type.Reversing){//Selling now, permit longs after this trade
											permitteddir = 'L';
										}
										else if(pType == PivotPointBoss_Type.Trending){//Buying now, permit shorts after this trade
											permitteddir = 'S';
										}
									}
									tr.Value.EntryABar   = CurrentBar;
									tr.Value.MFEDist_tks = (tr.Value.EntryPrice - Low[0])/TickSize;
									tr.Value.EnterAt     = Times[0][0];
									tr.Value.Disposition = "Position is filled Short at "+tr.Value.EntryPrice;
Draw.Diamond(this,"Filled "+tr.Key.ToString()+" c:"+tr.Value.Contracts,false,CurrentBar-tr.Key, tr.Value.EntryPrice, Brushes.Blue);
									if(pSellFillWAV!="SOUND OFF")
										PlayAlert(CurrentBar.ToString(), "Triangle SHORT", AddSoundFolder(pSellFillWAV), Brushes.Red);
									if(pEmailFillSignal.Trim().Length>0)
										SendMail(pEmailFillSignal.Trim(),"StructureBoss Short filled "+Instruments[0].FullName, "Filled at "+tr.Value.EntryPrice);
								}
							}
						}
					}
					#endregion
if(ss)Print("Trade is "+tr.Value.Dir+"...SL is "+tr.Value.StopPrice+"  Tgt: "+tr.Value.TargetPrice);
					bool c3 = tr.Value.EntryABar < CurrentBar;
					if(tr.Value.EntryABar>0 && c3)//all positions
					{
						if(!InSessionNow){//sessions are enabled, and the current bar is out of session
							#region -- exit end of day --
							if(tr.Value.EntryABar == 0)//if the entry never got filled, then cancel the setup for that triangle.
								tr.Value.EntryABar = CANCELLED_ID;
							else{
								if(tr.Value.Dir=='L'){
									tr.Value.ExitPrice = Closes[0][0];
									tr.Value.NetDist_tks = Instrument.MasterInstrument.RoundToTickSize(tr.Value.ExitPrice - tr.Value.EntryPrice) / TickSize;
									tr.Value.TksXContracts = tr.Value.NetDist_tks * tr.Value.Contracts;
									tr.Value.MFEDist_tks = Math.Max(tr.Value.MFEDist_tks, tr.Value.NetDist_tks);
									tr.Value.ExitABar = CurrentBar;
									tr.Value.Disposition = "EOD";
									tr.Value.ExitAt = Times[0][0];
									TradeResultsPrinted = false;
//									if(pShowPnLLines) Draw.Line(this,"Line"+tr.Key.ToString(), false, Time.GetValueAt(tr.Key), tr.Value.EntryPrice, Times[0][0], tr.Value.ExitPrice, tr.Value.NetDist_tks>0?"WinnerDashed":"LoserDashed");
								}else{
									tr.Value.ExitPrice = Closes[0][0];
									tr.Value.NetDist_tks = Instrument.MasterInstrument.RoundToTickSize(tr.Value.EntryPrice - tr.Value.ExitPrice) / TickSize;
									tr.Value.TksXContracts = tr.Value.NetDist_tks * tr.Value.Contracts;
									tr.Value.MFEDist_tks = Math.Max(tr.Value.MFEDist_tks, tr.Value.NetDist_tks);
									tr.Value.ExitABar = CurrentBar;
									tr.Value.Disposition = "EOD";
									tr.Value.ExitAt = Times[0][0];
									TradeResultsPrinted = false;
//									if(pShowPnLLines) Draw.Line(this,"Line"+tr.Key.ToString(), false, Time.GetValueAt(tr.Key), tr.Value.EntryPrice, Times[0][0], tr.Value.ExitPrice, tr.Value.NetDist_tks>0?"WinnerDashed":"LoserDashed");
								}
							}
							#endregion
						}else{
//if(ss)Print(Times[0][0].ToString()+"   Long triangle at "+Times[0].GetValueAt(tr.Key).ToString()+"  targPrice = "+tr.Value.TargetPrice+"  high is: "+High[0].ToString());
							if(tr.Value.Dir=='L'){
								if(High[0] > tr.Value.TargetPrice){
									tr.Value.ExitPrice = tr.Value.TargetPrice;
									tr.Value.NetDist_tks = Instrument.MasterInstrument.RoundToTickSize(tr.Value.ExitPrice - tr.Value.EntryPrice) / TickSize;
									tr.Value.TksXContracts = tr.Value.NetDist_tks * tr.Value.Contracts;
									tr.Value.MFEDist_tks = tr.Value.NetDist_tks;
									tr.Value.ExitABar = CurrentBar;
									tr.Value.Disposition = "Tgt";
if(ss)Print(Times[0][0].ToShortTimeString()+"  Disposition: "+tr.Value.Disposition);
									tr.Value.ExitAt = Times[0][0];
									TradeResultsPrinted = false;
//if(ss)Print("Target hit on "+(Times[0].GetValueAt(tr.Key)).ToString());
//if(ss)Print("      High exceeded the target price, "+Times[0][0].ToString()+"  ticks: "+tr.Value.NetDist_tks);
//									if(pShowPnLLines) Draw.Line(this,"Line"+tr.Key.ToString(),false, Time.GetValueAt(tr.Key), tr.Value.EntryPrice, Time.GetValueAt(tr.Value.ExitABar), tr.Value.ExitPrice, tr.Value.NetDist_tks>0?"WinnerDashed":"LoserDashed");
								}else{
									tr.Value.MFEDist_tks = Math.Max(tr.Value.MFEDist_tks, Instrument.MasterInstrument.RoundToTickSize(High[0]-tr.Value.EntryPrice)/TickSize);
if(ss){
	Print("    High[1]:  "+High[1]+"   Low[0]: "+Low[0]+"   SL: "+tr.Value.StopPrice);
}
									if(High[1] >= tr.Value.StopPrice && Low[0] < tr.Value.StopPrice){
										tr.Value.ExitPrice = tr.Value.StopPrice;
										tr.Value.NetDist_tks = -Instrument.MasterInstrument.RoundToTickSize(tr.Value.EntryPrice-tr.Value.ExitPrice) / TickSize;
										tr.Value.TksXContracts = tr.Value.NetDist_tks * tr.Value.Contracts;
//if(ss)Print("      Low exceeded the Stop price");
										tr.Value.ExitABar = CurrentBar;
										if(tr.Value.IsBEEngaged)
											tr.Value.Disposition = "TrailingStop hit";
										else
											tr.Value.Disposition = "SL";
if(ss)Print(Times[0][0].ToShortTimeString()+"  Disposition: "+tr.Value.Disposition);
										tr.Value.ExitAt = Times[0][0];
										TradeResultsPrinted = false;
//										if(pShowPnLLines) Draw.Line(this,"Line"+tr.Key.ToString(),false, Time.GetValueAt(tr.Key), tr.Value.EntryPrice, Time.GetValueAt(tr.Value.ExitABar), tr.Value.ExitPrice, tr.Value.NetDist_tks>0?"WinnerDashed":"LoserDashed");
									}
								}
							}else if(tr.Value.Dir=='S'){
								if(Low[0] < tr.Value.TargetPrice){
									tr.Value.ExitPrice = tr.Value.TargetPrice;
									tr.Value.NetDist_tks = Instrument.MasterInstrument.RoundToTickSize(tr.Value.EntryPrice - tr.Value.ExitPrice) / TickSize;
									tr.Value.TksXContracts = tr.Value.NetDist_tks * tr.Value.Contracts;
									tr.Value.MFEDist_tks = tr.Value.NetDist_tks;
									tr.Value.ExitABar = CurrentBar;
									tr.Value.Disposition = "Tgt";
if(ss)Print(Times[0][0].ToShortTimeString()+"  Disposition: "+tr.Value.Disposition);
									tr.Value.ExitAt = Times[0][0];
									TradeResultsPrinted = false;
//									if(pShowPnLLines) Draw.Line(this,"Line"+tr.Key.ToString(),false, Time.GetValueAt(tr.Key), tr.Value.EntryPrice, Time.GetValueAt(tr.Value.ExitABar), tr.Value.ExitPrice, tr.Value.NetDist_tks>0?"WinnerDashed":"LoserDashed");
								}else{
									tr.Value.MFEDist_tks = Math.Max(tr.Value.MFEDist_tks, Instrument.MasterInstrument.RoundToTickSize(tr.Value.EntryPrice-Low[0]) / TickSize);
									if(Low[1] <= tr.Value.StopPrice && High[0] > tr.Value.StopPrice){
										tr.Value.ExitPrice = tr.Value.StopPrice;
										tr.Value.NetDist_tks = -Instrument.MasterInstrument.RoundToTickSize(tr.Value.ExitPrice-tr.Value.EntryPrice) / TickSize;
										tr.Value.TksXContracts = tr.Value.NetDist_tks * tr.Value.Contracts;
										tr.Value.ExitABar = CurrentBar;
										if(tr.Value.IsBEEngaged)
											tr.Value.Disposition = "TrailingStop hit";
										else
											tr.Value.Disposition = "SL";
if(ss)Print(Times[0][0].ToShortTimeString()+"  Disposition: "+tr.Value.Disposition);
										tr.Value.ExitAt = Times[0][0];
										TradeResultsPrinted = false;
//										if(pShowPnLLines) Draw.Line(this,"Line"+tr.Key.ToString(),false, Time.GetValueAt(tr.Key), tr.Value.EntryPrice, Time.GetValueAt(tr.Value.ExitABar), tr.Value.ExitPrice, tr.Value.NetDist_tks>0?"WinnerDashed":"LoserDashed");
									}
								}
							}
						}
					}
				}
				#region -- Delete all CANCELLED trades --
				if(cancelled_count>0 && Trades.Count>0){
					var xk = Trades.Where(kk=>kk.Value.EntryABar==CANCELLED_ID).Select(kk=>kk.Key).ToList();
					for(int del = 0; del<xk.Count; del++) Trades.Remove(xk[del]);
					TradeKeys = Trades.Keys.ToList();
				}
				#endregion
				#endregion

				#region -- Calculate final PnL --
				if(CurrentBar > BarsArray[0].Count-3 && !TradeResultsPrinted){
					if(pPrintToOutputWindow) Print("-------------------------------------");
					TradeResultsPrinted = true;
					double wins = 0;
					double losses = 0;
					double total_long_trades = 0;
					double total_short_trades = 0;
					double win_contracts = 0;
					double loss_contracts = 0;
					double total_ticks = 0;
					double totalmfe = 0;
					double totalriskdist_tks = 0;
					double win_ticks = 0;
					double loss_ticks = 0;
					double equity_high = 0;
					double equity_low = 0;
					double total_long_ticks = 0;
					double total_short_ticks = 0;
					double total_long_contracts = 0;
					double total_short_contracts = 0;
					double long_win_trades = 0;
					double short_win_trades = 0;
					double long_loss_trades = 0;
					double short_loss_trades = 0;
					double long_win_contracts = 0;
					double short_win_contracts = 0;
					double long_loss_contracts = 0;
					double short_loss_contracts = 0;
					double tradelength_seconds = 0;
					List<double> Drawdowns = new List<double>();
					List<DateTime> dt = new List<DateTime>();
					PnLByDOW = new SortedDictionary<DayOfWeek,List<double>>();//0-element will be the win count, 1-element will be loss count, all subsequent elements will be the ticks profit for each trade
					PnL = new List<double>();
					if(pPrintToOutputWindow) Print("Tks/trade\tEntryAt\tExitAt\tEntry$\tExit$\tDesc\tDir\tQty");//print the header
					PnLByDOW[DayOfWeek.Sunday]    = new List<double>(){0,0};//0-element is win count, 1-element is loss count, and the rest of the list is pnl ticks
					PnLByDOW[DayOfWeek.Monday]    = new List<double>(){0,0};
					PnLByDOW[DayOfWeek.Tuesday]   = new List<double>(){0,0};
					PnLByDOW[DayOfWeek.Wednesday] = new List<double>(){0,0};
					PnLByDOW[DayOfWeek.Thursday]  = new List<double>(){0,0};
					PnLByDOW[DayOfWeek.Friday]    = new List<double>(){0,0};
					PnLByDOW[DayOfWeek.Saturday]  = new List<double>(){0,0};
					var dowid = DayOfWeek.Sunday;
					var Dispositions = new SortedDictionary<string,List<double>>();
					var TurnoverByDate = new SortedDictionary<DateTime, double>();
					var PnLByDay = new SortedDictionary<DateTime, List<double>>();
					foreach(var tr in Trades.Where(k=>k.Value.ExitABar>0)) {
						var d = Times[0].GetValueAt(tr.Value.EntryABar);
						if(!dt.Contains(d.Date)) dt.Add(d.Date);//keep track of days traded

						if(tr.Value.Dir=='L') total_long_contracts = total_long_contracts + tr.Value.Contracts; else total_short_contracts = total_short_contracts+tr.Value.Contracts;

						//for graphing purposes, the dow PnL needs to have the same number of elments as the PnL list...so carry forward the last ticks profit on each day
						if(PnLByDOW[dowid].Count>2)	PnLByDOW[dowid].Add(PnLByDOW[dowid].Last()); else PnLByDOW[dowid].Add(0); dowid = DayOfWeek.Monday;
						if(PnLByDOW[dowid].Count>2)	PnLByDOW[dowid].Add(PnLByDOW[dowid].Last()); else PnLByDOW[dowid].Add(0); dowid = DayOfWeek.Tuesday;
						if(PnLByDOW[dowid].Count>2)	PnLByDOW[dowid].Add(PnLByDOW[dowid].Last()); else PnLByDOW[dowid].Add(0); dowid = DayOfWeek.Wednesday;
						if(PnLByDOW[dowid].Count>2)	PnLByDOW[dowid].Add(PnLByDOW[dowid].Last()); else PnLByDOW[dowid].Add(0); dowid = DayOfWeek.Thursday;
						if(PnLByDOW[dowid].Count>2)	PnLByDOW[dowid].Add(PnLByDOW[dowid].Last()); else PnLByDOW[dowid].Add(0); dowid = DayOfWeek.Friday;
						if(PnLByDOW[dowid].Count>2)	PnLByDOW[dowid].Add(PnLByDOW[dowid].Last()); else PnLByDOW[dowid].Add(0); dowid = DayOfWeek.Saturday;
						if(PnLByDOW[dowid].Count>2)	PnLByDOW[dowid].Add(PnLByDOW[dowid].Last()); else PnLByDOW[dowid].Add(0); dowid = DayOfWeek.Sunday;
						if(PnLByDOW[d.DayOfWeek].Count<=2)
							PnLByDOW[d.DayOfWeek][PnLByDOW[d.DayOfWeek].Count-1] = tr.Value.TksXContracts;
						else
							PnLByDOW[d.DayOfWeek][PnLByDOW[d.DayOfWeek].Count-1] = PnLByDOW[d.DayOfWeek][PnLByDOW[d.DayOfWeek].Count-2] + tr.Value.TksXContracts;

						if(!Dispositions.ContainsKey(tr.Value.Disposition)) Dispositions[tr.Value.Disposition] = new List<double>(){tr.Value.TksXContracts};
						else Dispositions[tr.Value.Disposition].Add(tr.Value.TksXContracts);

						var ts = new TimeSpan(tr.Value.ExitAt.Ticks - tr.Value.EnterAt.Ticks);
						tradelength_seconds = tradelength_seconds + ts.TotalSeconds;
						var td = tr.Value.EnterAt.Date;
						#region -- Calculate turnover - stocks --
						if(IsStock){
							if(!TurnoverByDate.ContainsKey(td)) TurnoverByDate[td] = tr.Value.Contracts * tr.Value.EntryPrice;
							else TurnoverByDate[td] = TurnoverByDate[td] + tr.Value.Contracts * tr.Value.EntryPrice;
						}
						#endregion
						#region -- Calculate PnL By Day for max daily drawdown --
						if(!PnLByDay.ContainsKey(td)) PnLByDay[td] = new List<double>(){tr.Value.TksXContracts};
						else PnLByDay[td].Add(tr.Value.TksXContracts);
						#endregion

						if(tr.Value.NetDist_tks>0){ //Winning trade
							PnLByDOW[d.DayOfWeek][0] = PnLByDOW[d.DayOfWeek][0] + 1;//add a win to the win element (element 0)  for this DOW
							wins++;
							win_contracts += tr.Value.Contracts;
							win_ticks += tr.Value.TksXContracts;
							if(tr.Value.Dir=='L'){
								total_long_trades++;
								long_win_trades++;
								long_win_contracts += tr.Value.Contracts;
								total_long_ticks += tr.Value.TksXContracts;
							}
							else if(tr.Value.Dir=='S'){
								short_win_trades++;
								total_short_trades++;
								short_win_contracts += tr.Value.Contracts;
								total_short_ticks += tr.Value.TksXContracts;
							}
						}else{//losing trade
							PnLByDOW[d.DayOfWeek][1] = PnLByDOW[d.DayOfWeek][1] + 1;//add a loss to the loss element (element 1) for this DOW
							losses++;
							loss_contracts += tr.Value.Contracts;
							loss_ticks += tr.Value.TksXContracts;
							if(tr.Value.Dir=='L'){
								long_loss_trades++;
								total_long_trades++;
								long_loss_contracts+=tr.Value.Contracts;
								total_long_ticks += tr.Value.TksXContracts;
							}
							else if(tr.Value.Dir=='S'){
								short_loss_trades++;
								total_short_trades++;
								short_loss_contracts+=tr.Value.Contracts;
								total_short_ticks += tr.Value.TksXContracts;
							}
						}
						total_ticks += tr.Value.TksXContracts;
						PnL.Add(total_ticks);

						#region -- Calculate drawdowns --
						if(total_ticks > equity_high){
							double drawdown_ticks = equity_high-equity_low;
							if(drawdown_ticks > 0) {
								if(pPrintToOutputWindow) Print("Adding drawdown of "+drawdown_ticks+"-ticks");
								Drawdowns.Add(drawdown_ticks);
							}
							equity_high = total_ticks;
							equity_low = total_ticks;
						}else{
							equity_low = Math.Min(equity_low, total_ticks);
						}
						#endregion ----------------------------------------
						var s = string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}", 
									tr.Value.NetDist_tks,
									Times[0].GetValueAt(tr.Value.EntryABar).ToString(),
									Times[0].GetValueAt(tr.Value.ExitABar).ToString(),
									tr.Value.EntryPrice,
									tr.Value.ExitPrice,
									tr.Value.Disposition,
									tr.Value.Dir=='L'?"Long":"Short",
									tr.Value.Contracts);
						if(pPrintToOutputWindow) Print(s);
						//clipboardstr = string.Format("{0}\n{1}",clipboardstr,s);
						totalriskdist_tks += tr.Value.InitialRiskDist_tks;
						totalmfe += tr.Value.MFEDist_tks;
					}
					dowid = DayOfWeek.Sunday;
					//if the win count is 0, and the loss count is 0 for that day of week, then remove it, it has no trades recorded
					if(PnLByDOW[dowid][0]==0 && PnLByDOW[dowid][1]==0) PnLByDOW.Remove(dowid);	dowid = DayOfWeek.Monday;
					if(PnLByDOW[dowid][0]==0 && PnLByDOW[dowid][1]==0) PnLByDOW.Remove(dowid);	dowid = DayOfWeek.Tuesday;
					if(PnLByDOW[dowid][0]==0 && PnLByDOW[dowid][1]==0) PnLByDOW.Remove(dowid);	dowid = DayOfWeek.Wednesday;
					if(PnLByDOW[dowid][0]==0 && PnLByDOW[dowid][1]==0) PnLByDOW.Remove(dowid);	dowid = DayOfWeek.Thursday;
					if(PnLByDOW[dowid][0]==0 && PnLByDOW[dowid][1]==0) PnLByDOW.Remove(dowid);	dowid = DayOfWeek.Friday;
					if(PnLByDOW[dowid][0]==0 && PnLByDOW[dowid][1]==0) PnLByDOW.Remove(dowid);	dowid = DayOfWeek.Saturday;
					if(PnLByDOW[dowid][0]==0 && PnLByDOW[dowid][1]==0) PnLByDOW.Remove(dowid);

					PnLText = pButtonText+" - "+pType.ToString();
					double tradecount = wins + losses;
					if(tradecount == 0) PnLText = "No trades\nAdd more days of history";
					else{
						double total_contracts = win_contracts + loss_contracts;
						if(pShowLongs && !pShowShorts)      AppendString(ref PnLText, string.Format("Longs only  {0} RR  Swing {1}{2}",this.pRewardToRisk, pDeviationValue, (pDeviationType==PivotPointBoss_DeviationType.Percent ? "%":"-pts") ));
						else if(!pShowLongs && pShowShorts) AppendString(ref PnLText, string.Format("Shorts only  {0} RR  Swing {1}{2}",this.pRewardToRisk, pDeviationValue, (pDeviationType==PivotPointBoss_DeviationType.Percent ? "%":"-pts") ));
						else if(pShowLongs && pShowShorts)  AppendString(ref PnLText, string.Format("Longs & Shorts  {0} RR  Swing {1}{2}",this.pRewardToRisk, pDeviationValue, (pDeviationType==PivotPointBoss_DeviationType.Percent ? "%":"-pts") ));
						AppendString(ref PnLText, InSessionABars!=null ? string.Format("Session {0} to {1}, EOD {2}",pStartTime,pStopTime,pEODTime ) : "24-hr session");
						AppendString(ref PnLText, pEngageTrailingStop ? string.Format("Trailing Stop enabled {0} atr",pTrailingStopATRMult ) : "Trailing Stop OFF");
//						AppendString(ref PnLText, pMaxRiskDollars>0 ? string.Format("Risk per trade ${0}", pMaxRiskDollars ) : "Fixed size - 1 contract per trade");

						AppendString(ref PnLText, string.Format("Trades: {0}  ({1} {2})", tradecount, total_contracts, IsStock ? "shares":"contracts" ));
						AppendString(ref PnLText, "- - -");
//						double win_pct = win_contracts/(total_contracts);
						double win_pct = wins/tradecount;
//						AppendString(ref PnLText, string.Format("W/L W%: {0} / {1}  {2}", win_contracts, loss_contracts, win_pct.ToString("0%")) );
						AppendString(ref PnLText, string.Format("W/L W%: {0} / {1}  {2}", wins, losses, win_pct.ToString("0%")) );
						if(pShowLongs == pShowShorts){
//							win_pct = long_win_contracts/(total_long_contracts);
							win_pct = long_win_trades/(total_long_trades);
//							AppendString(ref PnLText, string.Format("Long: {0} / {1}  {2} \t{3}", long_win_contracts, long_loss_contracts, win_pct.ToString("0%"), (total_long_ticks*tick_value_dollars).ToString("C0") ));
							AppendString(ref PnLText, string.Format("Long: {0} / {1}  {2} \t{3}", long_win_trades, long_loss_trades, win_pct.ToString("0%"), (total_long_ticks*tick_value_dollars).ToString("C0") ));
//							win_pct = short_win_contracts/(total_short_contracts);
							win_pct = short_win_trades/(total_short_trades);
//							AppendString(ref PnLText, string.Format("Short: {0} / {1}  {2} \t{3}", short_win_contracts, short_loss_contracts, win_pct.ToString("0%"), (total_short_ticks*tick_value_dollars).ToString("C0") ));
							AppendString(ref PnLText, string.Format("Short: {0} / {1}  {2} \t{3}", short_win_trades, short_loss_trades, win_pct.ToString("0%"), (total_short_ticks*tick_value_dollars).ToString("C0") ));
						}
						double pnl = total_ticks * tick_value_dollars;
						AppendString(ref PnLText, string.Format("Total PnL: \t{0}", pnl.ToString("C0")) );
						//if(pMinContracts>1 || IsStock)
						{
							double avg_win  = win_ticks * tick_value_dollars/wins;
							double avg_loss = loss_ticks * tick_value_dollars/losses;
							AppendString(ref PnLText, string.Format("Avg win: {0}  loss: {1}", avg_win.ToString("C0"), avg_loss.ToString("C0")) );
							if(pShowLongs && !pShowShorts){
								AppendString(ref PnLText, string.Format("Avg LONG {0} \t{1}", (total_long_ticks*tick_value_dollars/total_long_trades).ToString("C0"), (long_win_trades/total_long_trades).ToString("0%")) );
								AppendString(ref PnLText, string.Format("PF: {0}",(win_ticks/-loss_ticks).ToString("0.00")) );
							}else if(!pShowLongs && pShowShorts){
								AppendString(ref PnLText, string.Format("Avg SHORT {0} \t{1}", (total_short_ticks*tick_value_dollars/total_short_trades).ToString("C0"), (short_win_trades/total_short_trades).ToString("0%")) );
								AppendString(ref PnLText, string.Format("PF: {0}",(win_ticks/-loss_ticks).ToString("0.00")) );
							}else{
								double avgPnL = pnl/(wins+losses);
								if(avgPnL<10)
									AppendString(ref PnLText, string.Format("PF: {0}  Avg $/trade \t{1}",(win_ticks/-loss_ticks).ToString("0.00"), Math.Round(avgPnL,2).ToString("C0")) );
								else
									AppendString(ref PnLText, string.Format("PF: {0}  Avg $/trade \t{1}",(win_ticks/-loss_ticks).ToString("0.00"), Math.Round(avgPnL,0).ToString("C0")) );
							}
							AppendString(ref PnLText, "- - -");

							AppendString(ref PnLText, string.Format("{0} Days traded {1} trades/day  {2}/day", dt.Count.ToString("0"), (tradecount/dt.Count).ToString("0.0") ,(pnl/dt.Count).ToString("C0")) );
							pnl = totalmfe/(wins+losses);
							AppendString(ref PnLText, string.Format("Avg MFE (ticks/trade): {0}", (pnl).ToString("0.0")) );
//						}else{
//							double avg_win  = win_ticks * tick_value_dollars/win_contracts;
//							double avg_loss = loss_ticks * tick_value_dollars/loss_contracts;
//							AppendString(ref PnLText, string.Format("Avg win: {0}  loss: {1}", avg_win.ToString("C0"), avg_loss.ToString("C0")) );
//							if(pShowLongs && !pShowShorts){
//								AppendString(ref PnLText, string.Format("Avg LONG {0} \t{1}", (total_long_ticks*tick_value_dollars/total_long_contracts).ToString("C0"), (long_win_contracts/total_long_contracts).ToString("0%")) );
//								AppendString(ref PnLText, string.Format("PF: {0}",(win_ticks/-loss_ticks).ToString("0.00")) );
//							}else if(!pShowLongs && pShowShorts){
//								AppendString(ref PnLText, string.Format("Avg SHORT {0} \t{1}", (total_short_ticks*tick_value_dollars/total_short_contracts).ToString("C0"), (short_win_contracts/total_short_contracts).ToString("0%")) );
//								AppendString(ref PnLText, string.Format("PF: {0}",(win_ticks/-loss_ticks).ToString("0.00")) );
//							}else{
//								double avgpnl = pnl/total_contracts;
//								if(avgpnl<10)
//									AppendString(ref PnLText, string.Format("PF: {0}  Avg $/{1} \t{2}",(win_ticks/-loss_ticks).ToString("0.00"), IsStock ? "share":"contract", Math.Round(avgpnl,2).ToString("C0")) );
//								else
//									AppendString(ref PnLText, string.Format("PF: {0}  Avg $/{1} \t{2}",(win_ticks/-loss_ticks).ToString("0.00"), IsStock ? "share":"contract", Math.Round(avgpnl,0).ToString("C0")) );
//							}
//							AppendString(ref PnLText, "- - -\t");

//							AppendString(ref PnLText, string.Format("{0} Days traded {1} trades/day  {2}/day", dt.Count.ToString("0"), (tradecount/dt.Count).ToString("0.0") ,Math.Round(pnl/dt.Count,0).ToString("C0")) );
//							pnl = totalmfe/total_contracts;
//							AppendString(ref PnLText, string.Format("Avg MFE (ticks/{0}): {1}", IsStock ? "share":"contract", (pnl).ToString("0.0")) );
						}
						pnl = totalmfe/totalriskdist_tks;
						AppendString(ref PnLText, string.Format("MFE (ticks/tick risked): {0}", (pnl).ToString("0.0")) );
						AppendString(ref PnLText, string.Format("Avg trade age: {0}-minutes", (tradelength_seconds/tradecount/60).ToString("0.0")) );

						if(IsStock){
							AppendString(ref PnLText, string.Format("Turnover/day Max: \t{0}", TurnoverByDate.Values.Max().ToString("C0")) );
							AppendString(ref PnLText, string.Format("Turnover/day Avg: \t{0}", TurnoverByDate.Values.Average().ToString("C0")) );
							AppendString(ref PnLText, string.Format("Turnover/trade Max:\t{0}", Trades.Select(kk=>kk.Value.Turnover).Max().ToString("C0")) );
							AppendString(ref PnLText, string.Format("Turnover/trade Avg:\t{0}", Trades.Select(kk=>kk.Value.Turnover).Average().ToString("C0")) );
						}
						PnLByDOWText = "";
						AppendString(ref PnLByDOWText, "- - -\t");
						AppendString(ref PnLByDOWText, "DoW \t  Ticks  \t  W/L  \t  w%  \t $" );
						foreach(var kvp in PnLByDOW){
							wins = kvp.Value[0];
							losses = kvp.Value[1];
							if(wins==0 && losses==0) continue;
							string s = string.Format("  {0}: \t {1}\t {2}/{3} \t{4} \t{5}", 
									kvp.Key.ToString().Substring(0,2),
									ReduceToThousands(kvp.Value.Last().ToString("0")),
									wins, losses, ((wins/(wins+losses))).ToString("0%"),//remove win count and loss count from the count of all ticks
								(kvp.Value.Last()>0 ? "+":"")+(Math.Round(kvp.Value.Last()*tick_value_dollars,0)).ToString("C0")
							);
							AppendString(ref PnLByDOWText, s);
						}
						if(equity_high > equity_low) Drawdowns.Add(equity_high-equity_low);  //if there's a current drawdown, add it.  This is a floating drawdown
						Drawdowns.Sort();
//if(pPrintToOutputWindow) {
//	int count = 1;
//	foreach(var ddd in Drawdowns){
//		Print(string.Format("# {0} Drawdown (ticks): {1} ",count, ddd.ToString("0")));
//		count++;
//	}
//}
						AppendString(ref DrawdownsText, "- - -\t");
						AppendString(ref DrawdownsText, string.Format("{0} Drawdowns",Drawdowns.Count));
						#region -- Calc intraday drawdown --
						var ddlist = new List<double>();
						double drawdown_ticks = 0;
//Print("---------------------------");
						foreach(var kvp2 in PnLByDay){
							double sum = 0;
							equity_high = 0;
							equity_low = 0;
//Print("Day: "+kvp2.Key.ToString()+"  "+kvp2.Key.DayOfWeek.ToString());
							int ccc = 0;
							foreach(var tk in kvp2.Value){
								sum = sum + tk;
								ccc++;
//Print("   #"+ccc+"  "+tk+"-tks,   curr equity "+sum);
								if(sum > equity_high){
//Print("      > equity_hi "+equity_high);
									drawdown_ticks = equity_high-equity_low;
									if(drawdown_ticks > 0){
										ddlist.Add(drawdown_ticks);
//Print("      drawdown added "+drawdown_ticks);
									}
									equity_high = sum;
									equity_low = sum;
								}else{
									equity_low = Math.Min(equity_low, sum);
//Print("    equity low "+equity_low);
								}
							}
							drawdown_ticks = equity_high-equity_low;
							if(drawdown_ticks > 0){
								ddlist.Add(drawdown_ticks);
//Print("    EOD "+sum+"-equity,  "+drawdown_ticks);
							}
						}
//Print("---------------------------");
						if(ddlist.Count==0) ddlist.Add(0);
line=1941;
						AppendString(ref DrawdownsText, string.Format("EOD Max:\t{0}\tAvg: {1}", (ddlist.Max()*tick_value_dollars).ToString("C0"), (ddlist.Average()*tick_value_dollars).ToString("C0")) );
						#endregion
						if(Drawdowns.Count>0){
							AppendString(ref DrawdownsText, string.Format("Max:\t {0}  \t{1} of pnl",(tick_value_dollars*Drawdowns.Max()).ToString("C0"), (Drawdowns.Max()/total_ticks).ToString("0%")));
							var avg = Math.Round(tick_value_dollars*Drawdowns.Average(),2);
							if(avg.ToString().Length>4) avg = Math.Round(avg,0);
							AppendString(ref DrawdownsText, string.Format("Avg:\t {0}  \t{1} of pnl",(avg).ToString("C0"), (Drawdowns.Average()/total_ticks).ToString("0%")));
						}
						DispositionsText = "";
						AppendString(ref DispositionsText, "- - -\t");
						AppendString(ref DispositionsText, "Dispositions "+Instrument.MasterInstrument.FormatPrice(TickSize));
						foreach(var disp in Dispositions){
							double sum = disp.Value.Sum();
							if(sum>0)
								AppendString(ref DispositionsText, string.Format("{0} \t+{1} \t{2}",disp.Value.Count, (sum*tick_value_dollars).ToString("C0"), disp.Key));
							else
								AppendString(ref DispositionsText, string.Format("{0} \t-{1} \t{2}",disp.Value.Count, (-sum*tick_value_dollars).ToString("C0"), disp.Key));
						}
						if(pPrintToOutputWindow){
							if(pShowPnLByDOW)
								Print(PnLByDOWText);
							if(pShowDrawdowns)
								Print(DrawdownsText);
							if(pShowDispositions)
								Print(DispositionsText);
						}
					}
//					Print("----------------");
//					var dict = Trades.Where(k=>k.Value.EntryABar>0).ToList().OrderBy(k=>k.Key);
//					foreach(var dd in dict){
//						Print(dd.Key.ToString("0")+"-risked,  "+dd.Value.NetDist_tks.ToString("0")+"-gain/loss     ratio: "+(dd.Value.NetDist_tks/dd.Key).ToString("0.000"));
//					}
				}
				#endregion
}catch(Exception eee){Print(line+":  "+eee.ToString());}
			#region -- OnBarUpdate body --
			if (lastSwingPrice == 0.0)
				lastSwingPrice = Input[0];

			ISeries<double> highSeries	= High;
			ISeries<double> lowSeries	= Low;

			if (!UseHighLow)
			{
				highSeries	= Input;
				lowSeries	= Input;
			}

			// Calculation always for 1-bar ago !
			bool isSwingHigh			= highSeries[1].ApproxCompare(highSeries[0]) >= 0
											&& highSeries[1].ApproxCompare(highSeries[2]) >= 0;
			bool isSwingLow				= lowSeries[1].ApproxCompare(lowSeries[0]) <= 0
											&& lowSeries[1].ApproxCompare(lowSeries[2]) <= 0;
			bool isOverHighDeviation	= (pDeviationType == PivotPointBoss_DeviationType.Percent && IsPriceGreater(highSeries[1], (lastSwingPrice * (1.0 + pDeviationValue / 100.0))))
											|| (pDeviationType == PivotPointBoss_DeviationType.Points && IsPriceGreater(highSeries[1], lastSwingPrice + pDeviationValue));
			bool isOverLowDeviation		= (pDeviationType == PivotPointBoss_DeviationType.Percent && IsPriceGreater(lastSwingPrice * (1.0 - pDeviationValue / 100.0), lowSeries[1]))
											|| (pDeviationType == PivotPointBoss_DeviationType.Points && IsPriceGreater(lastSwingPrice - pDeviationValue, lowSeries[1]));

			double	saveValue	= 0.0;
			bool	addHigh		= false;
			bool	addLow		= false;
			bool	updateHigh	= false;
			bool	updateLow	= false;

			if (!isSwingHigh && !isSwingLow)
			{
				zigZagHighSeries[0] = currentZigZagHigh;
				zigZagLowSeries[0]	= currentZigZagLow;
				return;
			}

//			if(isSwingHigh && isSwingLow){
//				if(trendDir == 1){
//					saveValue	= highSeries[1];
//					updateHigh	= true;
//					updateLow   = false;
//					isSwingLow  = false;
//				}else if(trendDir == -1){
//					saveValue	= lowSeries[1];
//					updateLow	= true;
//					updateHigh  = false;
//					isSwingHigh = false;
//				}
//			}
//			else
			if (trendDir <= 0 && isSwingHigh && isOverHighDeviation)
			{
				saveValue	= highSeries[1];
				addHigh		= true;
				trendDir	= 1;
try{
//	Draw.Dot(this,"NewHigh "+CurrentBar.ToString(),   false, 0,                       saveValue, Brushes.Gold);
//	Draw.Dot(this,"LastLow "+lastSwingIdx.ToString(), false, CurrentBar-lastSwingIdx, Lows[0].GetValueAt(lastSwingIdx),Brushes.Gold);
}catch{}
				
			}
			else if (trendDir >= 0 && isSwingLow && isOverLowDeviation)
			{
				saveValue	= lowSeries[1];
				addLow		= true;
				trendDir	= -1;
//Draw.Dot(this,"NewLow "+CurrentBar.ToString(), false,0,saveValue,Brushes.Gold);
			}
			else if (trendDir == 1 && isSwingHigh && IsPriceGreater(highSeries[1], lastSwingPrice))
			{
				saveValue	= highSeries[1];
				updateHigh	= true;
//Draw.Dot(this,"UpdateHigh "+CurrentBar.ToString(), false,0,saveValue,Brushes.Blue);
			}
			else if (trendDir == -1 && isSwingLow && IsPriceGreater(lastSwingPrice, lowSeries[1]))
			{
				saveValue	= lowSeries[1];
				updateLow	= true;
//Draw.Dot(this,"UpdateLow "+CurrentBar.ToString(), false,0,saveValue,Brushes.Blue);
			}
//if(isSwingHigh && isSwingLow) Print(Times[0][0].ToString()+"   trendDir: "+trendDir);
			if (addHigh || addLow || updateHigh || updateLow)
			{
				if (updateHigh && lastSwingIdx >= 0)
				{
					zigZagHighZigZags.Reset(CurrentBar - lastSwingIdx);
					Value.Reset(CurrentBar - lastSwingIdx);
				}
				else if (updateLow && lastSwingIdx >= 0)
				{
					zigZagLowZigZags.Reset(CurrentBar - lastSwingIdx);
					Value.Reset(CurrentBar - lastSwingIdx);
				}

				if (addHigh || updateHigh)
				{
					zigZagHighZigZags[1]	= saveValue;
					currentZigZagHigh 		= saveValue;
					zigZagHighSeries[1]		= currentZigZagHigh;
					lastSwingHighIdx = CurrentBar-1;
					if(lastSwingLowIdx==CurrentBar-1)
						Value[0] = currentZigZagHigh;
					else
						Value[1] = currentZigZagHigh;
					if(Nodes.Count==0 || Nodes[0].Type == 'L')
						Nodes.Insert(0, new NodeData(Value[1], 'H', CurrentBar-1));
					else{
						Nodes[0].Price = Value[1];
						Nodes[0].ABar = CurrentBar-1;
					}
					if(DollarsRiskPerTrade[Times[0][0].DayOfWeek] >= 0 && IsBetweenStartAndStopTimes)
						AddTriangle();
//Draw.Dot(this,CurrentBar.ToString(),false,1,Value[1],Brushes.Yellow);
				}
				else if (addLow || updateLow)
				{
					zigZagLowZigZags[1]	= saveValue;
					currentZigZagLow 	= saveValue;
					zigZagLowSeries[1]	= currentZigZagLow;
					lastSwingLowIdx = CurrentBar-1;
					if(lastSwingHighIdx==CurrentBar-1)
						Value[0] = currentZigZagLow;
					else
						Value[1] = currentZigZagLow;
					if(Nodes.Count==0 || Nodes[0].Type == 'H')
						Nodes.Insert(0, new NodeData(Value[1], 'L', CurrentBar-1));
					else{
						Nodes[0].Price = Value[1];
						Nodes[0].ABar = CurrentBar-1;
					}
					if(DollarsRiskPerTrade[Times[0][0].DayOfWeek] >= 0 && IsBetweenStartAndStopTimes)
						AddTriangle();
				}
				lastSwingIdx	= CurrentBar - 1;
				lastSwingPrice	= saveValue;
			}

			zigZagHighSeries[0]	= currentZigZagHigh;
			zigZagLowSeries[0]	= currentZigZagLow;
			
			if (startIndex == int.MinValue && (zigZagHighZigZags.IsValidDataPoint(1) && zigZagHighZigZags[1] != zigZagHighZigZags[2] || zigZagLowZigZags.IsValidDataPoint(1) && zigZagLowZigZags[1] != zigZagLowZigZags[2]))
				startIndex = CurrentBar - (Calculate == Calculate.OnBarClose ? 2 : 1);
			#endregion
		}
		private string ReduceToThousands(string number){
			if(number.Length >= 9){
				return number.Substring(0, number.Length-6)+"m";
			}else if(number.Length >= 6){
				return number.Substring(0, number.Length-3)+"k";
			}else return number;
		}

		private void AppendString(List<string> r, string s){
			Print(s);
			r.Add(s);
		}
		private void AppendString(ref string r, string s){
			Print(s);
			if(r.Length>0)
				r = string.Format("{0}\n{1}",r,s);
			else r = s;
		}
		private List<string> Tags = new List<string>();
		private class TradeData : ICloneable
		{
			public double Contracts   = 1;
			public int    EntryABar   = 0;
			public double EntryPrice  = 0;
			public double StopPrice   = 0;
			public int    ExitABar    = 0;
			public double ExitPrice   = 0;
			public double TargetPrice = 0;
			public double CancelPrice = 0;
			public double MFEDist_tks = 0;
			public double NetDist_tks = 0;
			public double InitialRiskDist_tks = 0;
			public double TksXContracts = 0;
			public bool   IsBEEngaged = false;
			public SortedDictionary<int,double> SLHistory = new SortedDictionary<int,double>();
			public double Turnover    = 0;//contracts * entry price
			public string Disposition = "";
			public DateTime EnterAt   = DateTime.MinValue;
			public DateTime ExitAt    = DateTime.MinValue;
			public Point[] Nodes      = new Point[3];
			public char Dir;
			public string Status = "";
			public string SLnotes = "";
			public object Clone() {return this.MemberwiseClone();	}
			public TradeData(bool UseStdSLOnly, double TickSize, double MinContracts, double entryprice, double stopprice, double RewardRisk, double cancelprice, double riskDollars, double DollarsPerTick, int aBarLeft, int aBarMid, int aBarRight, double priceLeft, double priceMid, double priceRight, Indicator indi = null){
				EntryPrice = entryprice;
				if(EntryPrice < stopprice) Dir = 'S'; else Dir = 'L';
				InitialRiskDist_tks = Math.Abs(stopprice-EntryPrice)/TickSize;
				double pts_risk = Math.Abs(entryprice-stopprice);
				if(MinContracts >1) DollarsPerTick = DollarsPerTick * MinContracts;
if(indi!=null) indi.Print("\n"+EntryPrice.ToString()+"   "+Dir+"     StopPrice: "+stopprice+"   InitialRisk tks: "+InitialRiskDist_tks+"   $/tick: "+DollarsPerTick+"  risk$: "+riskDollars);
				if(riskDollars>0){//don't over risk a trade...if your max risk is $100, but the triangle puts a stop that is $150 away from your entry, your stop needs to be moved closer to your entry
					double r = riskDollars / (InitialRiskDist_tks * DollarsPerTick);
if(indi!=null) indi.Print("   r: "+r);
					if(r<1){
						pts_risk = riskDollars / DollarsPerTick * TickSize;
						int x = Convert.ToInt32(pts_risk / TickSize);
						pts_risk = x * TickSize;
						SLnotes = "Stoploss adjusted to just "+x+"-ticks to limit your max loss to $"+riskDollars.ToString();
					}
					Contracts = (int)Math.Max(MinContracts, Math.Round(r-0.5,0));
if(indi!=null) indi.Print("  pts_risk: "+pts_risk+"   contracts: "+Contracts);
					if(Dir == 'L')
						StopPrice = EntryPrice - pts_risk;
					else
						StopPrice = EntryPrice + pts_risk;
					if(UseStdSLOnly && StopPrice != stopprice) {
						Status = "ERROR:  Risk "+riskDollars+" is too small for requested SL distance of "+pts_risk;
						SLnotes = Status;
						return;
					}
					InitialRiskDist_tks = Math.Abs(StopPrice-EntryPrice)/TickSize;
					Status = string.Format("{0},a Risk$ {1}  Dollars/Tick: {2}  InitRiskTks {3:0},  Contracts {4}", MinContracts, riskDollars, DollarsPerTick, InitialRiskDist_tks, Contracts);
if(indi!=null) indi.Print("Status: "+Status+"\n");
				}else{
					Contracts = Math.Max(1, (int)MinContracts);
					Status = string.Format("{0},b Risk$ {1}  Dollars/Tick: {2}  InitRiskTks {3:0},  Contracts {4}", MinContracts, riskDollars, DollarsPerTick, InitialRiskDist_tks, Contracts);
					StopPrice = stopprice;
					SLnotes = "Stoploss set to "+StopPrice+"  Qty: "+Contracts;
				}
				int ttk = Convert.ToInt32((pts_risk*RewardRisk) / TickSize);
				double tpts = ttk * TickSize;
				TargetPrice = Dir == 'L' ? EntryPrice + tpts : EntryPrice - tpts;
				CancelPrice = cancelprice;
				Turnover = Contracts * EntryPrice;
				Nodes[0] = new Point(aBarRight, priceRight);
				Nodes[1] = new Point(aBarMid,   priceMid);
				Nodes[2] = new Point(aBarLeft,  priceLeft);
			}
		}
		private SortedDictionary<int,TradeData> Trades = new SortedDictionary<int, TradeData>();
		private string AddSoundFolder(string wav){
			wav = wav.Replace("<inst>",Instrument.MasterInstrument.Name);
//			if(IsDebug)Print("ARC_StructureBoss"+wav);
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}

		List<int> TradeKeys;
		char lastdir = ' ';
		char permitteddir = 'A';//Both long and short
//		int TradesThisSession = 0;
		private void AddTriangle(){
			#region -- AddTriangle --
			if(Nodes.Count<3) return;
			if(InSessionABars!=null && !InSessionABars.Contains(CurrentBar)) return; //if sessions are enabled, but we're out of session region
			string tag = string.Format("tri {0} {1}RR",Nodes[1].ABar, pRewardToRisk);
			RemoveDrawObject(tag);
			if(Tags.Contains(tag)) Tags.Remove(tag);
			Trades.Remove(Nodes[1].ABar);
			int StopPriceId = 0;//2 is the far-left price of the triangle, 0 is the far-right price of the triangle
			double EP = Nodes[1].Price;
			double SL = Nodes[StopPriceId].Price;
			double RiskPts = 0;
//ss = EP==2503.2 && Nodes[1].ABar==2283;//Times[0][0].Hour==11 && Times[0][0].Minute>=20 && Times[0][0].Day==10 && Times[0][0].Month==1;
			if(pType == PivotPointBoss_Type.Reversing){//buy on lower swings, sell on higher swings
				#region -- reversing --
				if(Nodes[0].Type == 'L'){//current swing is a LOW swing
					if(Nodes[2].Price > Nodes[0].Price && pShowLongs && permitteddir != 'S') {//the current node is a lower low
//						if(!pPermitSameDirectionEntries && Trades.Count>0){
//							if(Trades.Last().Value.EntryABar == CANCELLED_ID) lastdir = ' ';
//							else if(Trades.Last().Value.ExitABar > 0)   lastdir = ' ';
//							else if(Trades.Last().Value.Dir == 'L' && Trades.Last().Value.EntryABar == 0) {//this last trade is Long, but has not been filled yet
//								Trades.Last().Value.EntryABar = CANCELLED_ID;
//								lastdir = 'X';
//							}
//						}
						//if(pPermitSameDirectionEntries || lastdir != 'L')
						{
							//lastdir = 'L';
							if(pBuySetupWAV!="SOUND OFF")
								PlayAlert(Nodes[1].ABar.ToString(), "Triangle reverse BUY setup", AddSoundFolder(pBuySetupWAV), Brushes.Green);
							if(pEmailSetupSignal.Trim().Length>0)
								SendMail(pEmailSetupSignal.Trim(),"StructureBoss reversing LONG setup identified "+Instruments[0].FullName, "");
							EP = EP + 2*TickSize;
							if(pSLBufferTicks>0) SL = SL - pSLBufferTicks * TickSize;
							RiskPts = Math.Abs(EP-SL);
//SL = EP - Instrument.MasterInstrument.RoundToTickSize(atr[0] * 1);
//Draw.Diamond(this,"slp"+CurrentBars[0].ToString(),false,0,SL,Brushes.Orange);
							var TD = new TradeData(pUseStdSLOnly, TickSize, pMinContracts, EP, SL, pRewardToRisk, Nodes[0].Price, DollarsRiskPerTrade[Times[0][0].DayOfWeek], tick_value_dollars, Nodes[2].ABar, Nodes[1].ABar, Nodes[0].ABar, Nodes[2].Price, Nodes[1].Price, Nodes[0].Price);
							if(!TD.Status.StartsWith("ERROR")) Trades[Nodes[1].ABar] = (TradeData)TD.Clone(); else return;
							TradeKeys = Trades.Keys.ToList();
							Trades[Nodes[1].ABar].Disposition="Pending LONG entry at "+TD.EntryPrice.ToString();
if(pShowSLsquares) Draw.Square(this,Nodes[1].ABar.ToString()+" "+Trades[Nodes[1].ABar].Status, false, Times[0].GetValueAt(Nodes[1].ABar), SL,Brushes.Red);
//	Print(Trades[Nodes[1].ABar].Status);
						}
					}
				}
				else if(Nodes[0].Type == 'H'){
					if(Nodes[2].Price < Nodes[0].Price && pShowShorts && permitteddir != 'L'){
//						if(!pPermitSameDirectionEntries && Trades.Count>0){
////Draw.Dot(this,Nodes[1].ABar.ToString(),false,CurrentBar-Nodes[1].ABar,Lows[0].GetValueAt(Nodes[1].ABar),Brushes.Yellow);
////							if(Trades.Last().Value.EntryABar!=CANCELLED_ID && Trades.Last().Value.EntryABar==0 && Trades.Last().Value.Dir == 'S') Trades.Last().Value.EntryABar = CANCELLED_ID;
//							if(Trades.Last().Value.EntryABar==CANCELLED_ID) lastdir = ' ';
//							else if(Trades.Last().Value.ExitABar > 0)   lastdir = ' ';
//							else if(Trades.Last().Value.EntryABar == 0){//this last trade hasn't been filled yet, so cancel it and replace it with a better short entry
//								Trades.Last().Value.EntryABar = CANCELLED_ID;
//								lastdir = 'X';
//							}
//						}
						//if(pPermitSameDirectionEntries || lastdir != 'S')
						{
							//lastdir = 'S';
							if(pSellSetupWAV!="SOUND OFF")
								PlayAlert(Nodes[1].ABar.ToString(), "Triangle reverse SELL setup", AddSoundFolder(pSellSetupWAV), Brushes.Red);
							if(pEmailSetupSignal.Trim().Length>0)
								SendMail(pEmailSetupSignal.Trim(),"StructureBoss reversing SELL setup identified "+Instruments[0].FullName, "");
							EP = EP - 2*TickSize;
							if(pSLBufferTicks>0) SL = SL + pSLBufferTicks * TickSize;
							RiskPts = Math.Abs(EP-SL);
//SL = EP + Instrument.MasterInstrument.RoundToTickSize(atr[0] * 1);
//Draw.Diamond(this,"slp"+CurrentBars[0].ToString(),false,0,SL,Brushes.Orange);
							var TD = new TradeData(pUseStdSLOnly, TickSize, pMinContracts, EP, SL, pRewardToRisk, Nodes[0].Price, DollarsRiskPerTrade[Times[0][0].DayOfWeek], tick_value_dollars, Nodes[2].ABar, Nodes[1].ABar, Nodes[0].ABar, Nodes[2].Price, Nodes[1].Price, Nodes[0].Price);
							if(!TD.Status.StartsWith("ERROR")) Trades[Nodes[1].ABar] = (TradeData)TD.Clone(); else return;
							TradeKeys = Trades.Keys.ToList();
							Trades[Nodes[1].ABar].Disposition="Pending SHORT entry at "+TD.EntryPrice.ToString();
if(pShowSLsquares) Draw.Square(this,Nodes[1].ABar.ToString()+" "+Trades[Nodes[1].ABar].Status, false, Times[0].GetValueAt(Nodes[1].ABar), SL,Brushes.Red);
//	Print(Trades[Nodes[1].ABar].Status);
						}
					}
				}
				#endregion
			}else if(pType == PivotPointBoss_Type.Trending){//trending...buy on higher low swings, sell on lower high swings
				#region -- trending --
				if(Nodes[0].Type == 'H'){
					if(Nodes[2].Price > Nodes[0].Price && pShowShorts && permitteddir != 'S'){
//						if(!pPermitSameDirectionEntries && Trades.Count>0){
//							if(Trades.Last().Value.EntryABar == CANCELLED_ID) lastdir = ' ';
//							else if(Trades.Last().Value.ExitABar > 0)   lastdir = ' ';
//							else if(Trades.Last().Value.EntryABar == 0) lastdir = 'S';//on a trend trade, do not jump in on "better"(lower) entry price, wait for a breakout of the further out entry price
//							else if(Trades.Last().Value.EntryABar > 0)  lastdir = Trades.Last().Value.Dir;
//						}
						//if(pPermitSameDirectionEntries || lastdir != 'S')
						{
							//lastdir = 'S';
							if(pSellSetupWAV!="SOUND OFF")
								PlayAlert(Nodes[1].ABar.ToString(), "Triangle trend Sell setup", AddSoundFolder(pSellSetupWAV), Brushes.Red);
							if(pEmailSetupSignal.Trim().Length>0)
								SendMail(pEmailSetupSignal.Trim(),"StructureBoss trend SHORT setup identified "+Instruments[0].FullName, "");
							EP = EP - 2*TickSize;
							if(pSLBufferTicks>0) SL = SL + pSLBufferTicks * TickSize;
							RiskPts = Math.Abs(EP-SL);
//SL = EP + Instrument.MasterInstrument.RoundToTickSize(atr[0] * 1);
//Draw.Diamond(this,"slp"+CurrentBars[0].ToString(),false,0,SL,Brushes.Orange);
							var TD = new TradeData(pUseStdSLOnly, TickSize, pMinContracts, EP, SL, pRewardToRisk, Nodes[2].Price, DollarsRiskPerTrade[Times[0][0].DayOfWeek], tick_value_dollars, Nodes[2].ABar, Nodes[1].ABar, Nodes[0].ABar, Nodes[2].Price, Nodes[1].Price, Nodes[0].Price);
							if(!TD.Status.StartsWith("ERROR")) Trades[Nodes[1].ABar] = (TradeData)TD.Clone(); else return;
if(ss) Print("New trending SHORT setup found   SL at "+TD.StopPrice+"  TP at: "+TD.TargetPrice);
							TradeKeys = Trades.Keys.ToList();
							Trades[Nodes[1].ABar].Disposition="Pending SHORT entry at "+TD.EntryPrice.ToString();
if(pShowSLsquares) Draw.Square(this,Nodes[1].ABar.ToString()+" "+Trades[Nodes[1].ABar].Status, false, Times[0].GetValueAt(Nodes[1].ABar), SL,Brushes.Red);
//	Print(Trades[Nodes[1].ABar].Status);
						}
					}
				}
				else if(Nodes[0].Type == 'L'){
					if(Nodes[2].Price < Nodes[0].Price && pShowLongs && permitteddir != 'L'){
//						if(!pPermitSameDirectionEntries && Trades.Count>0){
//							if(Trades.Last().Value.EntryABar==CANCELLED_ID) lastdir = ' ';
//							else if(Trades.Last().Value.ExitABar > 0)   lastdir = ' ';
//							else if(Trades.Last().Value.EntryABar == 0) lastdir = 'L';//on a trend trade, do not jump in on "better"(lower) entry price, wait for a breakout of the further out entry price
//							else if(Trades.Last().Value.EntryABar > 0)  lastdir = Trades.Last().Value.Dir;
//						}
//if(ss)Print("2427   PermitAddtl: "+pPermitSameDirectionEntries.ToString()+"   lastdir: "+lastdir);
						//if(pPermitSameDirectionEntries || lastdir != 'L')
						{
							//lastdir = 'L';
							if(pBuySetupWAV!="SOUND OFF")
								PlayAlert(Nodes[1].ABar.ToString(), "Triangle trend BUY setup", AddSoundFolder(pBuySetupWAV), Brushes.Green);
							if(pEmailSetupSignal.Trim().Length>0)
								SendMail(pEmailSetupSignal.Trim(),"StructureBoss trend LONG setup identified "+Instruments[0].FullName, "");
							EP = EP + 2*TickSize;
							if(pSLBufferTicks>0) SL = SL - pSLBufferTicks * TickSize;
							RiskPts = Math.Abs(EP-SL);
//SL = EP - Instrument.MasterInstrument.RoundToTickSize(atr[0] * 1);
//Draw.Diamond(this,"slp"+CurrentBars[0].ToString(),false,0,SL,Brushes.Orange);
							var TD = new TradeData(pUseStdSLOnly, TickSize, pMinContracts, EP, SL, pRewardToRisk, Nodes[2].Price, DollarsRiskPerTrade[Times[0][0].DayOfWeek], tick_value_dollars, Nodes[2].ABar, Nodes[1].ABar, Nodes[0].ABar, Nodes[2].Price, Nodes[1].Price, Nodes[0].Price);
							if(!TD.Status.StartsWith("ERROR")) Trades[Nodes[1].ABar] = (TradeData)TD.Clone(); else return;
if(ss) Print("New trending LONG setup found   SL at "+TD.StopPrice+"  TP at: "+TD.TargetPrice);
							TradeKeys = Trades.Keys.ToList();
							Trades[Nodes[1].ABar].Disposition="Pending LONG entry at "+TD.EntryPrice.ToString();
if(pShowSLsquares) Draw.Square(this,Nodes[1].ABar.ToString()+" "+Trades[Nodes[1].ABar].Status, false, Times[0].GetValueAt(Nodes[1].ABar), SL,Brushes.Red);
//	Print(Trades[Nodes[1].ABar].Status);
						}
					}
				}
				#endregion
			}
			//while(Tags.Count> this.pMaxTriangles) Tags.RemoveAt(0);
			#endregion
		}
		//===================================================================================================
		private string LastAlertTag = string.Empty;
		private void PlayAlert(string tag, string msg, string wav, Brush br){
			if(pSilenceAllAlerts) return;
			if(LastAlertTag != tag) {
				if(State==State.Realtime && !System.IO.File.Exists(wav)) Log("Triangle alert: "+msg+" printed to Alerts window, but could not find wav: "+wav, LogLevel.Information);
				LastAlertTag = tag;
				Alert(tag, Priority.High, msg, wav, 1, br, ContrastingColor(br));
			}
		}
		//===================================================================================================
		#region ---- Parameters --
		static string  HLtemplates_folder = null;

		[Display(ResourceType = typeof(Custom.Resource), Name = "ZZ Value Type", GroupName = "NinjaScriptParameters", Order = 10)]
		public PivotPointBoss_DeviationType pDeviationType
		{ get; set; }

		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "ZZ Value", GroupName = "NinjaScriptParameters", Order = 20)]
		public double pDeviationValue
		{ get; set; }

		[Display(ResourceType = typeof(Custom.Resource), Name = "Use HighLow", GroupName = "NinjaScriptParameters", Order = 30)]
		public bool UseHighLow
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 35, Name = "Triangle type", GroupName = "NinjaScriptParameters", ResourceType = typeof(Custom.Resource))]
		public PivotPointBoss_Type pType
		{get;set;}

		[Display(Order = 40, Name = "Show longs?", GroupName = "NinjaScriptParameters", ResourceType = typeof(Custom.Resource))]
		public bool pShowLongs
		{get;set;}

		[Display(Order = 50, Name = "Show shorts?", GroupName = "NinjaScriptParameters", ResourceType = typeof(Custom.Resource))]
		public bool pShowShorts
		{get;set;}

		[Range(0,2359)]
		[Display(Order = 60, Name = "Start time", GroupName = "NinjaScriptParameters", Description ="Time to start entering new trades", ResourceType = typeof(Custom.Resource))]
		public int pStartTime
		{get;set;}

		[Range(0,2359)]
		[Display(Order = 70, Name = "Stop time", GroupName = "NinjaScriptParameters", Description ="Time to stop entering new trades", ResourceType = typeof(Custom.Resource))]
		public int pStopTime
		{get;set;}

		[Range(0,2359)]
		[Display(Order = 73, Name = "EOD time", GroupName = "NinjaScriptParameters", Description ="Time to exit all open positions", ResourceType = typeof(Custom.Resource))]
		public int pEODTime
		{get;set;}

		[Display(Order = 75, Name = "Use Std SL level ONLY", Description = "If the risk $ amount is too small, the SL distance won't be reduced, instead the trade will be rejected", GroupName = "NinjaScriptParameters", ResourceType = typeof(Custom.Resource))]
		public bool pUseStdSLOnly
		{get;set;}

		[Display(Order = 79, Name = "Engage BE Stop", Description = "When 2 bars exceed the entry price, move stop to BE+1 tick", GroupName = "NinjaScriptParameters", ResourceType = typeof(Custom.Resource))]
		public bool pEngageBEStop
		{get;set;}

		[Display(Order = 80, Name = "Engage TrailingStop", Description = "Trail x-ATR's behind price", GroupName = "NinjaScriptParameters", ResourceType = typeof(Custom.Resource))]
		public bool pEngageTrailingStop
		{get;set;}

		[Display(Order = 90, Name = "ATR mult TrailingStop", Description = "Once 2-bar is engaged, the ATR trailing will kick in", GroupName = "NinjaScriptParameters", ResourceType = typeof(Custom.Resource))]
		public double pTrailingStopATRMult
		{get;set;}

		[Display(Order = 95, Name = "SL Buffer (ticks)", Description = "# of ticks to add to the Initial SL distance", GroupName = "NinjaScriptParameters", ResourceType = typeof(Custom.Resource))]
		public double pSLBufferTicks
		{get;set;}

		[Display(Order = 100, Name = "Reward-to-risk", GroupName = "NinjaScriptParameters", ResourceType = typeof(Custom.Resource))]
		public double pRewardToRisk
		{get;set;}

		#endregion

		#region ---- Custom Visuals --
//		[Display(Order = 10, Name = "Show Triangles?", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
//		public bool pShowTriangles
//		{get;set;}

		[Display(Order = 10, Name = "X% for Summary text", GroupName = "Custom Visuals", Description="Set to '-1' to hide the Summary text", ResourceType = typeof(Custom.Resource))]
		public int pSummaryTxt_Xpct
		{get;set;}
		[Display(Order = 20, Name = "Y% for Summary text", GroupName = "Custom Visuals", Description="Set to '-1' to hide the Summary text", ResourceType = typeof(Custom.Resource))]
		public int pSummaryTxt_Ypct
		{get;set;}
		[Display(Order = 30, Name = "Summary text Bkg Opacity", GroupName = "Custom Visuals", Description="", ResourceType = typeof(Custom.Resource))]
		public float pSummaryTextBkgOpacity
		{get;set;}

		[Display(Order = 40, Name = "Entry Line thickness", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public float pEntryLineThickness
		{get;set;}

		[Display(Order = 50, Name = "SL Line thickness", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public float pSLLineThickness
		{get;set;}

		[Display(Order = 60, Name = "Target Line thickness", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public float pTargetLineThickness
		{get;set;}

		[Display(Order = 70, Name = "Show PnL Lines?", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pShowPnLLines
		{get;set;}

		[Display(Order = 80, Name = "Show SL History dots?", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pShowSLHistory
		{get;set;}

		[Display(Order = 90, Name = "Print PnL to OutputWindow?", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pPrintToOutputWindow
		{get;set;}

		#region -- drawn obj --
//		internal class LoadTriangleTemplates : StringConverter
//		{
//			#region LoadTriangleTemplates
//			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
//			{
//				//true means show a combobox
//				return true;
//			}

//			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
//			{
//				//true will limit to list. false will show the list, 
//				//but allow free-form entry
//				return false;
//			}

//			public override System.ComponentModel.TypeConverter.StandardValuesCollection
//				GetStandardValues(ITypeDescriptorContext context)
//			{
//				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Triangle"};
//				HLtemplates_folder = System.IO.Path.Combine(paths);
//				string search = "*.xml";
//				System.IO.DirectoryInfo dirCustom=null;
//				System.IO.FileInfo[] filCustom=null;
//				try{
//					dirCustom = new System.IO.DirectoryInfo(HLtemplates_folder);
//					filCustom = dirCustom.GetFiles(search);
//				}catch{}

//				var list = new List<string>();//new string[filCustom.Length+1];
//				list.Add("Default");
//				if(filCustom!=null){
//					foreach (System.IO.FileInfo fi in filCustom)
//					{
//						string name = fi.Name.Replace(".xml",string.Empty);
//						if(!list.Contains(name)){
//							list.Add(name);
//						}
//					}
//				}
//				return new StandardValuesCollection(list.ToArray());
//			}
//			#endregion
//		}
//		[RefreshProperties(RefreshProperties.All)]
//		[TypeConverter(typeof(LoadTriangleTemplates))]
//		[Display(Order = 30, Name = "Up triangle template name", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
//		public string pUpTriangleTemplate
//		{get; set;}

//		[RefreshProperties(RefreshProperties.All)]
//		[TypeConverter(typeof(LoadTriangleTemplates))]
//		[Display(Order = 40, Name = "Down triangle template name", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
//		public string pDownTriangleTemplate
//		{get;set;}

//		[Display(Order = 50, Name = "Max Triangles", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
//		public int pMaxTriangles
//		{get;set;}

//		[Display(Order = 60, Name = "Summary Text Location", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
//		public TextPosition pSummaryTextLoc
//		{get;set;}
		#endregion

		[Range(0,100)]
		[Display(Order = 100, Name = "Time boundary opacity", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public float pTimeLineOpacity
		{get;set;}


		[XmlIgnore]
		[Display(Order = 110, Name = "Up Triangles", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pUpTriangleBrush { get; set; }
			[Browsable(false)]
			public string pUpTriangleBrush_{	get { return Serialize.BrushToString(pUpTriangleBrush); } set { pUpTriangleBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 120, Name = "Down Triangles", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pDownTriangleBrush { get; set; }
			[Browsable(false)]
			public string pDownTriangleBrush_{	get { return Serialize.BrushToString(pDownTriangleBrush); } set { pDownTriangleBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 130, Name = "Historical Triangle Up", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pHistoricalTriangleUpBrush { get; set; }
			[Browsable(false)]
			public string pHistoricalTriangleUpBrush_{	get { return Serialize.BrushToString(pHistoricalTriangleUpBrush); } set { pHistoricalTriangleUpBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order = 140, Name = "Historical Triangle Down", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pHistoricalTriangleDownBrush { get; set; }
			[Browsable(false)]
			public string pHistoricalTriangleDownBrush_{	get { return Serialize.BrushToString(pHistoricalTriangleDownBrush); } set { pHistoricalTriangleDownBrush = Serialize.StringToBrush(value); }}

		[Range(0,100)]
		[Display(Order = 150, Name = "Triangles opacity", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public float pTrianglesOpacity
		{get;set;}

//		[Display(Order = 160, Name = "Summary Text size", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
//		public int SummaryFontSize
//		{get;set;}

		[Display(Order = 170, Name = "Summary Text font", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public NinjaTrader.Gui.Tools.SimpleFont pSummaryFont
		{get;set;}

		[Display(Order = 180, Name = "Line height", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public int pLineHeight
		{get;set;}

		[Display(Order = 190, Name = "Order label font", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public NinjaTrader.Gui.Tools.SimpleFont pOrderLabelFont
		{get;set;}

		[Display(Order = 200, Name = "Show PnL by DayOfWeek", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pShowPnLByDOW
		{get;set;}
		[Display(Order = 210, Name = "Show Drawdowns", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pShowDrawdowns
		{get;set;}
		[Display(Order = 220, Name = "Show Dispositions", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pShowDispositions
		{get;set;}

		[Display(Order = 230, Name = "Button Text", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public string pButtonText
		{get;set;}

		[XmlIgnore]
		[Display(Order = 240, Name = "Sunday plot", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pSundayPlot_Brush { get; set; }
			[Browsable(false)]
			public string pSundayPlot_BrushSerialize{	get { return Serialize.BrushToString(pSundayPlot_Brush); } set { pSundayPlot_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 250, Name = "Monday plot", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pMondayPlot_Brush { get; set; }
			[Browsable(false)]
			public string pMondayPlot_BrushSerialize{	get { return Serialize.BrushToString(pMondayPlot_Brush); } set { pMondayPlot_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 260, Name = "Tuesday plot", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pTuesdayPlot_Brush { get; set; }
			[Browsable(false)]
			public string pTuesdayPlot_BrushSerialize{	get { return Serialize.BrushToString(pTuesdayPlot_Brush); } set { pTuesdayPlot_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 270, Name = "Wednesday plot", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pWednesdayPlot_Brush { get; set; }
			[Browsable(false)]
			public string pWednesdayPlot_BrushSerialize{	get { return Serialize.BrushToString(pWednesdayPlot_Brush); } set { pWednesdayPlot_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 280, Name = "Thursday plot", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pThursdayPlot_Brush { get; set; }
			[Browsable(false)]
			public string pThursdayPlot_BrushSerialize{	get { return Serialize.BrushToString(pThursdayPlot_Brush); } set { pThursdayPlot_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 290, Name = "Friday plot", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pFridayPlot_Brush { get; set; }
			[Browsable(false)]
			public string pFridayPlot_BrushSerialize{	get { return Serialize.BrushToString(pFridayPlot_Brush); } set { pFridayPlot_Brush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 300, Name = "Saturday plot", GroupName = "Custom Visuals", ResourceType = typeof(Custom.Resource))]
		public Brush pSaturdayPlot_Brush { get; set; }
			[Browsable(false)]
			public string pSaturdayPlot_BrushSerialize{	get { return Serialize.BrushToString(pSaturdayPlot_Brush); } set { pSaturdayPlot_Brush = Serialize.StringToBrush(value); }}

		#endregion

		#region ---- Position Sizing --
//		[Display(Order = 10, Name = "Initial Balance $", GroupName = "Position Sizing", Description = "", ResourceType = typeof(Custom.Resource))]
//		public double pInitialBalanceDollars
//		{get;set;}

		[Display(Order = 20, Name = "Max $R/trade Sunday", GroupName = "Position Sizing", Description = "'-1' is OFF, '0' to use 1 contract per trade, '100' is $100 fixed risk", ResourceType = typeof(Custom.Resource))]
		public double pMaxRiskDollarsSunday
		{get;set;}
		[Display(Order = 21, Name = "Max $R/trade Monday", GroupName = "Position Sizing", Description = "'-1' is OFF, '0' to use 1 contract per trade, '100' is $100 fixed risk", ResourceType = typeof(Custom.Resource))]
		public double pMaxRiskDollarsMonday
		{get;set;}
		[Display(Order = 22, Name = "Max $R/trade Tuesday", GroupName = "Position Sizing", Description = "'-1' is OFF, '0' to use 1 contract per trade, '100' is $100 fixed risk", ResourceType = typeof(Custom.Resource))]
		public double pMaxRiskDollarsTuesday
		{get;set;}
		[Display(Order = 23, Name = "Max $R/trade Wednesday", GroupName = "Position Sizing", Description = "'-1' is OFF, '0' to use 1 contract per trade, '100' is $100 fixed risk", ResourceType = typeof(Custom.Resource))]
		public double pMaxRiskDollarsWednesday
		{get;set;}
		[Display(Order = 24, Name = "Max $R/trade Thursday", GroupName = "Position Sizing", Description = "'-1' is OFF, '0' to use 1 contract per trade, '100' is $100 fixed risk", ResourceType = typeof(Custom.Resource))]
		public double pMaxRiskDollarsThursday
		{get;set;}
		[Display(Order = 25, Name = "Max $R/trade Friday", GroupName = "Position Sizing", Description = "'-1' is OFF, '0' to use 1 contract per trade, '100' is $100 fixed risk", ResourceType = typeof(Custom.Resource))]
		public double pMaxRiskDollarsFriday
		{get;set;}
		[Display(Order = 26, Name = "Max $R/trade Saturday", GroupName = "Position Sizing", Description = "'-1' is OFF, '0' to use 1 contract per trade, '100' is $100 fixed risk", ResourceType = typeof(Custom.Resource))]
		public double pMaxRiskDollarsSaturday
		{get;set;}

		[Display(Order = 30, Name = "Which days to trade?", GroupName = "Position Sizing", Description = "All, or Su,M,Tu,W,Th,F,Sa - or 0,1,2,3,4,5,6", ResourceType = typeof(Custom.Resource))]
		public string pDaysOfWeekToTrade
		{get;set;}

		[Display(Order = 40, Name = "Min contracts", GroupName = "Position Sizing", Description = "", ResourceType = typeof(Custom.Resource))]
		public double pMinContracts
		{get;set;}

		[Display(Order = 50, Name = "Permit addtl trades", GroupName = "Position Sizing", Description = "Permit adding more trades in same direction", ResourceType = typeof(Custom.Resource))]
		public bool pPermitSameDirectionEntries
		{get;set;}
		#endregion

		#region ---- Audible --
		internal class LoadFileList : StringConverter
		{
			#region LoadFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles(search);
				}catch{}

				var list = new System.Collections.Generic.List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				list.Add("<inst>_BuyBreakout.wav");
				list.Add("<inst>_SellBreakout.wav");
				list.Add("<inst>_BuySetup.wav");
				list.Add("<inst>_SellSetup.wav");
				list.Add("<inst>_TrailingAdvanced.wav");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}

		[Display(Order=5, Name="Silence all alerts?", GroupName="Audible", Description = "")]
		public bool pSilenceAllAlerts
		{get;set;}
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		[Display(Order = 10, Name = "Buy Setup WAV", GroupName = "Audible", Description="WAV to play when a new signal prints", ResourceType = typeof(Custom.Resource))]
		public string pBuySetupWAV
		{ get; set; }
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		[Display(Order = 20, Name = "Sell Setup WAV", GroupName = "Audible", Description="WAV to play when a new signal prints", ResourceType = typeof(Custom.Resource))]
		public string pSellSetupWAV
		{ get; set; }

		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		[Display(Order = 30, Name = "Buy Fill WAV", GroupName = "Audible", Description="WAV to play when an entry level gets touched", ResourceType = typeof(Custom.Resource))]
		public string pBuyFillWAV
		{ get; set; }
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		[Display(Order = 40, Name = "Sell Fill WAV", GroupName = "Audible", Description="WAV to play when an entry level gets touched", ResourceType = typeof(Custom.Resource))]
		public string pSellFillWAV
		{ get; set; }

		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		[Display(Order = 50, Name = "Trailing Advance WAV", GroupName = "Audible", Description="WAV to play when a the trailing stop advances to a new price", ResourceType = typeof(Custom.Resource))]
		public string pTrailingStopWAV
		{get;set;}
		#endregion

		#region -- Email alerts --
		[Display(Order = 10, Name = "Setup Signal", GroupName = "Email", Description="Destination address for Setup signal - must have NT 'Share Service' active", ResourceType = typeof(Custom.Resource))]
		public string pEmailSetupSignal
		{get;set;}
		[Display(Order = 20, Name = "Fill Signal", GroupName = "Email", Description="Destination address for Fill signal - must have NT 'Share Service' active", ResourceType = typeof(Custom.Resource))]
		public string pEmailFillSignal
		{get;set;}
		[Display(Order = 30, Name = "TrailingStop moved Signal", GroupName = "Email", Description="Destination address for trailing stop advanced signal - must have NT 'Share Service' active", ResourceType = typeof(Custom.Resource))]
		public string pEmailTrailingStopSignal
		{get;set;}
		#endregion

		private string pLicensePassword = "<enter password here>";
#if DO_LICENSE_v1
		[XmlIgnore]
		[Display(Order=10, Name="License Password", GroupName="~ License ~", Description = "Contact us at structureboss@sbgtradingcorp.com")]
		public string LicensePassword
		{
			get { return pLicensePassword; }
			set { pLicensePassword = value; }
		}
#endif
		[Display(Order = 10, Name = "Comment 1", GroupName = "Comments", ResourceType = typeof(Custom.Resource))]
		public string pComment1 { get; set; }
		[Display(Order = 20, Name = "Comment 2", GroupName = "Comments", ResourceType = typeof(Custom.Resource))]
		public string pComment2 { get; set; }
		[Display(Order = 30, Name = "Comment 3", GroupName = "Comments", ResourceType = typeof(Custom.Resource))]
		public string pComment3 { get; set; }

		#region -- public series --
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> ARC_StructureBossHigh
		{
			get
			{
				Update();
				return zigZagHighSeries;
			}
		}

		/// <summary>
		/// Gets the ARC_StructureBoss low points.
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> ZigZagLow
		{
			get
			{
				Update();
				return zigZagLowSeries;
			}
		}
		#endregion
//============   DrawTextFixed  ==============================================================================================
		#region -- Draw methods --
		bool IsRealTime1 = false;
		bool IsRealTime2 = false;
		void DrawTextFixed(string tag, string msg, TextPosition txtpos){
			if(tag!="licerror") {if(!IsRealTime1 || !IsRealTime2) return;}
			if (ChartControl.Dispatcher.CheckAccess())
				Draw.TextFixed(this,tag, msg, txtpos);
			else
				ChartControl.Dispatcher.InvokeAsync((Action)(() => {
					TriggerCustomEvent(o2 =>{
						Draw.TextFixed(this,tag, msg, txtpos);
					},0,null);
				}));
		}
		void DrawTextFixed(string tag, string msg, TextPosition txtpos, Brush foregroundBrush, NinjaTrader.Gui.Tools.SimpleFont font, Brush outlineBrush, Brush fillBrush, int opacity){
			if(tag!="licerror") {if(!IsRealTime1 || !IsRealTime2) return;}
			if (ChartControl.Dispatcher.CheckAccess())
				Draw.TextFixed(this,tag, msg, txtpos, foregroundBrush, font, outlineBrush, fillBrush, opacity);
			else
				ChartControl.Dispatcher.InvokeAsync((Action)(() => {
					TriggerCustomEvent(o2 =>{
						Draw.TextFixed(this,tag, msg, txtpos, foregroundBrush, font, outlineBrush, fillBrush, opacity);
					},0,null);
				}));
//			Draw.TextFixed("posvalue", msg, TextPosition.Center, netDollars>0 ? Brushes.Lime:Brushes.Magenta, new SimpleFont("Arial",15), Brushes.Black, Brushes.Black, 50);
		}
		#endregion
		#region Miscellaneous
		private bool IsPriceGreater(double a, double b)
		{
			return a.ApproxCompare(b) > 0;
		}

		public override void OnCalculateMinMax()
		{
			MinValue = double.MaxValue;
			MaxValue = double.MinValue;
			
			if (BarsArray[0] == null || ChartBars == null || startIndex == int.MinValue)
				return;

			for (int seriesCount = 0; seriesCount < Values.Length; seriesCount++)
			{
				for (int idx = ChartBars.FromIndex - Displacement; idx <= ChartBars.ToIndex + Displacement; idx++)
				{
					if (idx < 0 || idx > Bars.Count - 1 - (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose ? 1 : 0))
						continue;
					
					if (zigZagHighZigZags.IsValidDataPointAt(idx))
						MaxValue = Math.Max(MaxValue, zigZagHighZigZags.GetValueAt(idx));
					
					if (zigZagLowZigZags.IsValidDataPointAt(idx))
						MinValue = Math.Min(MinValue, zigZagLowZigZags.GetValueAt(idx));
				}
			}
		}

		protected override Point[] OnGetSelectionPoints(ChartControl chartControl, ChartScale chartScale)
		{
			if (!IsSelected || Count == 0 || Plots[0].Brush.IsTransparent() || startIndex == int.MinValue)
				return new System.Windows.Point[0];

			List<System.Windows.Point> points = new List<System.Windows.Point>();

			int lastIndex	= Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose ? ChartBars.ToIndex - 1 : ChartBars.ToIndex - 2;

			for (int i = Math.Max(0, ChartBars.FromIndex - Displacement); i <= Math.Max(lastIndex, Math.Min(Bars.Count - (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose ? 2 : 1), lastIndex - Displacement)); i++)
			{
				int x = (chartControl.BarSpacingType == BarSpacingType.TimeBased || chartControl.BarSpacingType == BarSpacingType.EquidistantMulti && i + Displacement >= ChartBars.Count
					? chartControl.GetXByTime(ChartBars.GetTimeByBarIdx(chartControl, i + Displacement))
					: chartControl.GetXByBarIndex(ChartBars, i + Displacement));

				if (Value.IsValidDataPointAt(i))
					points.Add(new System.Windows.Point(x, chartScale.GetYByValue(Value.GetValueAt(i))));
			}
			return points.ToArray();
		}
		#endregion

		private void SetRectBkg(ref SharpDX.RectangleF r, float X, float Y, float Width, float Height){
			r.X = X-10f;
			r.Y = Y-3f;
			r.Width = Width+6f;
			r.Height = Height+3f;
		}
		private void SetRectText(ref SharpDX.RectangleF r, float X, float Y){
			r.X = X-5f;
			r.Y = Y;
		}
		private class TradeResult{
			public double Wins = 0;
			public double Losses = 0;
			public List<double> Ticks = new List<double>();
			public List<double> LTicks = new List<double>();
			public List<double> STicks = new List<double>();
		}
//		private int TimeToMinuteIndex(DateTime t){
//			double r = 1440.0 * ((double)t.TimeOfDay.Ticks / TimeSpan.TicksPerDay);
//			return (int)Math.Round(r,0);
//		}
//		private string MinuteIndexToFormattedTime(int t){
//			double h = t/1440.0 * 24;
//			double min = (h - Math.Truncate(h)) * 60.0;
//			h = Math.Truncate(h);
//			string ret = string.Format("{0}:{1}",h,min.ToString("00"));
////Print("MinuteIndexToFormattedTime:   in: "+t+"   return: "+ret);
//			return string.Format("{0}:{1}",h,min.ToString("00"));
//		}

		private SharpDX.RectangleF slineRect = new SharpDX.RectangleF(0,0,0,0);
		private NinjaTrader.Gui.Tools.SimpleFont AxisFont;
		private NinjaTrader.Gui.Tools.SimpleFont summaryFont;
//=========================================================================================================================================
		protected override void OnRender(Gui.Chart.ChartControl chartControl, Gui.Chart.ChartScale chartScale)
		{
			if(!ValidLicense) return;
			if (Bars == null || chartControl == null || startIndex == int.MinValue)
				return;
			SharpDX.Vector2 v1 = new SharpDX.Vector2(0, 0);
			SharpDX.Vector2 v2 = new SharpDX.Vector2(0, Convert.ToSingle(ChartPanel.H));
//			summaryFont = new NinjaTrader.Gui.Tools.SimpleFont("Arial", ){Bold = true};
//			summaryFont = (NinjaTrader.Gui.Tools.SimpleFont)pSummaryFont.Clone();
//			summaryFont.Bold = true;

			#region -- Paint start/stop of session (vertical lines) --
			if(InSessionABars!=null){
				LimeBrushDX.Opacity = pTimeLineOpacity/100.0f;
				MagentaBrushDX.Opacity = pTimeLineOpacity/100.0f;
				for(int i = ChartBars.FromIndex; i<ChartBars.ToIndex; i++){
					if(!InSessionABars.Contains(i-1) && InSessionABars.Contains(i)){
						v1.X = chartControl.GetXByBarIndex(ChartBars, i)-2;
						v2.X = v1.X;
						RenderTarget.DrawLine(v1, v2, LimeBrushDX, 3f);
						//Draw.VerticalLine(this,Times[0][0].ToString(),Times[0][1],Brushes.Green);
					}
					if(InSessionABars.Contains(i-1) && !InSessionABars.Contains(i)){
						v1.X = chartControl.GetXByBarIndex(ChartBars, i)+2;
						v2.X = v1.X;
						RenderTarget.DrawLine(v1, v2, MagentaBrushDX, 3f);
						//Draw.VerticalLine(this,Times[0][0].ToString(),Times[0][1],Brushes.Red);
					}
				}
				LimeBrushDX.Opacity = 1f;
				MagentaBrushDX.Opacity = 1f;
			}
			YellowBrushDX.Opacity = pTimeLineOpacity/100f;
			foreach(int i in ABarsAtStopTime.Where(ak=>ak >= ChartBars.FromIndex && ak<ChartBars.ToIndex).ToList()){
				v1.X = chartControl.GetXByBarIndex(ChartBars, i)-2;
				v2.X = v1.X;
				RenderTarget.DrawLine(v1, v2, YellowBrushDX, 3f);
			}
			YellowBrushDX.Opacity = 1f;
			#endregion
			var stextFormat = pOrderLabelFont.ToDirectWriteTextFormat();
			var stextLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, "", stextFormat, (float)(ChartPanel.X + ChartPanel.W),100f);
			{
				List<KeyValuePair<int,TradeData>> trades = Trades.Where(k=> //k.Value.ExitABar == 0 && 
						Math.Max(k.Value.EntryPrice,Math.Max(k.Value.TargetPrice,k.Value.StopPrice)) > chartScale.MinValue && 
						Math.Min(k.Value.EntryPrice,Math.Min(k.Value.TargetPrice,k.Value.StopPrice)) < chartScale.MaxValue).ToList<KeyValuePair<int, TradeData>>();//trades that have not exited
				var en = trades.GetEnumerator();
				var msg = "Setup LONG";
				while(en.MoveNext()){
					if(en.Current.Value.EntryABar == CANCELLED_ID) {
//Print("Cancelled trade found in OnRender, trade at " + Times[0].GetValueAt(en.Current.Key).ToString());
//						if(     en.Current.Value.Dir == 'L') FillTriangle(en.Current.Value.Nodes, PurpleBrushDX, 0.2f+pOpacity/100f, ref chartScale, ref chartControl);
//						else if(en.Current.Value.Dir == 'S') FillTriangle(en.Current.Value.Nodes, PurpleBrushDX, 0.2f+pOpacity/100f, ref chartScale, ref chartControl);
						continue;
					}
					if(en.Current.Value.EntryABar > 0 && pShowSLHistory){
//						Print("count: "+en.Current.Value.SLHistory.Count);
						foreach(var slkvp in en.Current.Value.SLHistory){
							v1.X = chartControl.GetXByBarIndex(ChartBars, slkvp.Key);
							v1.Y = chartScale.GetYByValue(slkvp.Value); 
							RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(v1, 2f, 3f), MagentaBrushDX);
						}
					}
					if(en.Current.Value.ExitABar > 0) {
						#region -- Draw PnL line on exited position --
//Print(Times[0].GetValueAt(en.Current.Key).ToString()+" is exited at "+en.Current.Value.ExitPrice);
						if(     en.Current.Value.Dir == 'L') FillTriangle(en.Current.Value.Nodes, HistoricalTriangleUpBrushDX, pOpacity/100f, ref chartScale, ref chartControl);
						else if(en.Current.Value.Dir == 'S') FillTriangle(en.Current.Value.Nodes, HistoricalTriangleDownBrushDX, pOpacity/100f, ref chartScale, ref chartControl);
						if(pShowPnLLines){
							if(en.Current.Value.ExitABar > ChartBars.FromIndex && en.Current.Value.EntryABar <= ChartBars.ToIndex){
								v1.X = chartControl.GetXByBarIndex(ChartBars, en.Current.Key);
								v1.Y = chartScale.GetYByValue(en.Current.Value.EntryPrice); 
								v2.X = chartControl.GetXByBarIndex(ChartBars, en.Current.Value.EntryABar);
								v2.Y = chartScale.GetYByValue(en.Current.Value.EntryPrice); 
								if(en.Current.Value.NetDist_tks>0)
									RenderTarget.DrawLine(v1, v2, Plots[1].BrushDX, Plots[1].Width, Plots[1].StrokeStyle);
								else
									RenderTarget.DrawLine(v1, v2, Plots[2].BrushDX, Plots[2].Width, Plots[2].StrokeStyle);
								v1.X = chartControl.GetXByBarIndex(ChartBars, en.Current.Value.ExitABar);
								v1.Y = chartScale.GetYByValue(en.Current.Value.ExitPrice); 
								if(en.Current.Value.NetDist_tks>0)
									RenderTarget.DrawLine(v1, v2, Plots[1].BrushDX, Plots[1].Width, Plots[1].StrokeStyle);
								else
									RenderTarget.DrawLine(v1, v2, Plots[2].BrushDX, Plots[2].Width, Plots[2].StrokeStyle);
							}
						}
						#endregion
						continue;
					}
					if(en.Current.Value.EntryABar >= 0) {
						if(     en.Current.Value.Dir == 'L') FillTriangle(en.Current.Value.Nodes, UpTriangleBrushDX, pOpacity/100f, ref chartScale, ref chartControl);
						else if(en.Current.Value.Dir == 'S') FillTriangle(en.Current.Value.Nodes, DownTriangleBrushDX, pOpacity/100f, ref chartScale, ref chartControl);
					}
					if(InSessionNow){
						bool ShowLines = false;
						if(en.Current.Value.Dir=='L' && pShowLongs || en.Current.Value.Dir=='S' && pShowShorts) ShowLines=true;
						if(en.Current.Value.EntryABar == 0 && ShowLines){
							#region -- Draw pending entry line --
							if(en.Current.Value.Dir=='L' && pShowLongs)
								msg = string.Format("Setup LONG {0}", en.Current.Value.Contracts);
							else if(pShowShorts)
								msg = string.Format("Setup SHORT {0}", en.Current.Value.Contracts);
							stextLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, stextFormat, (float)(ChartPanel.X + ChartPanel.W),100f);
							float x = chartControl.GetXByBarIndex(ChartBars, en.Current.Key);
							v1.X = Convert.ToSingle(ChartPanel.W) - stextLayout.Metrics.Width;
							v1.Y = chartScale.GetYByValue(en.Current.Value.EntryPrice) - stextLayout.Metrics.Height; 
							SetRectBkg(ref slineRect, v1.X, v1.Y, stextLayout.Metrics.Width, stextLayout.Metrics.Height);
							RenderTarget.FillRectangle(slineRect, en.Current.Value.Dir=='L' ? LimeBrushDX : MagentaBrushDX);
							SetRectText(ref slineRect, v1.X, v1.Y);
							RenderTarget.DrawText(msg, stextFormat, slineRect, BlackBrushDX);
							v1.Y = chartScale.GetYByValue(en.Current.Value.EntryPrice);
							v2.X = x;
							v2.Y = v1.Y;
							RenderTarget.DrawLine(v1, v2, en.Current.Value.Dir=='L' ? LimeBrushDX : MagentaBrushDX, pEntryLineThickness);
							#endregion
						}
						if(en.Current.Value.EntryABar >= 0) {
							float x = 0f;
							#region -- Draw "Long from" or "Short from" line --
							if(en.Current.Value.EntryABar > 0 && ContrastToBkgBrushDX!=null && ChartBkgBrushDX!=null){
								if(en.Current.Value.Dir=='L')
									msg = string.Format("LONG {0} from {1}",en.Current.Value.Contracts, Instrument.MasterInstrument.FormatPrice(en.Current.Value.EntryPrice));
								else
									msg = string.Format("SHORT {0} from {1}",en.Current.Value.Contracts, Instrument.MasterInstrument.FormatPrice(en.Current.Value.EntryPrice));
								stextLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, stextFormat, (float)(ChartPanel.X + ChartPanel.W),100f);
								x = chartControl.GetXByBarIndex(ChartBars, en.Current.Key);
								v1.X = x - stextLayout.Metrics.Width - 10f;//Convert.ToSingle(ChartPanel.W) - stextLayout.Metrics.Width;
								v1.Y = chartScale.GetYByValue(en.Current.Value.EntryPrice) - stextLayout.Metrics.Height; 
								SetRectBkg(ref slineRect, v1.X, v1.Y, stextLayout.Metrics.Width, stextLayout.Metrics.Height);
								RenderTarget.FillRectangle(slineRect, ContrastToBkgBrushDX);
								SetRectText(ref slineRect, v1.X, v1.Y);
								RenderTarget.DrawText(msg, stextFormat, slineRect, ChartBkgBrushDX);
								v1.Y = chartScale.GetYByValue(en.Current.Value.EntryPrice);
								v2.X = x;
								v2.Y = v1.Y;
								RenderTarget.DrawLine(v1, v2, ContrastToBkgBrushDX);
							}
							#endregion
							if(ShowLines){
								#region -- Draw target line --
								msg = string.Format("Target {0}",en.Current.Value.Contracts);
								stextLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, stextFormat, (float)(ChartPanel.X + ChartPanel.W),100f);
								x = chartControl.GetXByBarIndex(ChartBars, en.Current.Key);
								v1.X = x;
								v1.Y = chartScale.GetYByValue(en.Current.Value.TargetPrice)-1f; 
								v2.X = Convert.ToSingle(ChartPanel.W);
								v2.Y = v1.Y;
								if(en.Current.Value.EntryABar == 0){
									WhiteBrushDX.Opacity = 0.5f;
									v1.X = v1.X - stextLayout.Metrics.Width;
									SetRectBkg(ref slineRect, v1.X, v1.Y, stextLayout.Metrics.Width, stextLayout.Metrics.Height);
									RenderTarget.FillRectangle(slineRect, WhiteBrushDX);
									SetRectText(ref slineRect, v1.X, v1.Y);
									RenderTarget.DrawText(msg, stextFormat, slineRect, BlackBrushDX);
									v1.X = v1.X + stextLayout.Metrics.Width;
									RenderTarget.DrawLine(v1, v2, WhiteBrushDX, pTargetLineThickness);
									WhiteBrushDX.Opacity = 1f;
								}else{
									v2.X = Convert.ToSingle(ChartPanel.W) - stextLayout.Metrics.Width;
									SetRectBkg(ref slineRect, v2.X, v2.Y, stextLayout.Metrics.Width, stextLayout.Metrics.Height);
									RenderTarget.FillRectangle(slineRect, en.Current.Value.Dir=='L' ? MaroonBrushDX : DarkGreenBrushDX);
									SetRectText(ref slineRect, v2.X, v2.Y);
									RenderTarget.DrawText(msg, stextFormat, slineRect, BlackBrushDX);
									RenderTarget.DrawLine(v1, v2, en.Current.Value.Dir=='L' ? MaroonBrushDX : DarkGreenBrushDX, pTargetLineThickness);
								}
								#endregion
								#region -- Draw SL or Trailing SL line --
								if(en.Current.Value.IsBEEngaged)
									msg = string.Format("Trail SL {0}",en.Current.Value.Contracts);
								else{
									msg = string.Format("  SL\nR = {0}",(Math.Abs(en.Current.Value.EntryPrice-en.Current.Value.StopPrice)*en.Current.Value.Contracts * tick_value_dollars/TickSize).ToString("C0"));
								}
								stextLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, stextFormat, (float)(ChartPanel.X + ChartPanel.W),100f);
								x = chartControl.GetXByBarIndex(ChartBars, en.Current.Key);
								v1.X = x;
								v1.Y = chartScale.GetYByValue(en.Current.Value.StopPrice)+1f; 
								v2.X = Convert.ToSingle(ChartPanel.W);// - stextLayout.Metrics.Width;
								v2.Y = v1.Y;
								if(en.Current.Value.EntryABar == 0){
//									DimGrayBrushDX.Opacity = 0.2f;
									WhiteBrushDX.Opacity = 0.5f;
									v1.X = v1.X - stextLayout.Metrics.Width;
									SetRectBkg(ref slineRect, v1.X, v1.Y, stextLayout.Metrics.Width, stextLayout.Metrics.Height);
									RenderTarget.FillRectangle(slineRect, WhiteBrushDX);
									SetRectText(ref slineRect, v1.X, v1.Y);
									RenderTarget.DrawText(msg, stextFormat, slineRect, BlackBrushDX);
									v1.X = v1.X + stextLayout.Metrics.Width;
									RenderTarget.DrawLine(v1, v2, WhiteBrushDX, pSLLineThickness);
									WhiteBrushDX.Opacity = 1f;
//									DimGrayBrushDX.Opacity = 1f;
								}else{
									v2.X = Convert.ToSingle(ChartPanel.W) - stextLayout.Metrics.Width;
									SetRectBkg(ref slineRect, v2.X, v2.Y, stextLayout.Metrics.Width, stextLayout.Metrics.Height);
									RenderTarget.FillRectangle(slineRect, en.Current.Value.Dir=='L' ? MaroonBrushDX : DarkGreenBrushDX);
									SetRectText(ref slineRect, v2.X, v2.Y);
									RenderTarget.DrawText(msg, stextFormat, slineRect, BlackBrushDX);
									RenderTarget.DrawLine(v1, v2, en.Current.Value.Dir=='L' ? MaroonBrushDX : DarkGreenBrushDX, pSLLineThickness);
								}
								#endregion
							}
						}
					}
				}
			}

//			var v1 = new SharpDX.Vector2(Convert.ToSingle(ChartPanel.W)/2f - stextLayout.Metrics.Width/2f, 
//				Convert.ToSingle(ChartPanel.H)-stextLayout.Metrics.Height*2f);
//			var slineRect   = new SharpDX.RectangleF(v1.X, v1.Y, stextLayout.Metrics.Width, stextLayout.Metrics.Height+1f);

//			RenderTarget.FillRectangle(slineRect, MagentaBrushDX);

			#region -- OnRender zigzag --
			IsValidDataPointAt(Bars.Count - 1 - (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose ? 1 : 0)); // Make sure indicator is calculated until last (existing) bar
			int preDiff = 1;
			for (int i = ChartBars.FromIndex - 1; i >= 0; i--)
			{
				if (i - Displacement < startIndex || i - Displacement > Bars.Count - 1 - (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose ? 1 : 0))
					break;

				bool isHigh	= zigZagHighZigZags.IsValidDataPointAt(i - Displacement);
				bool isLow	= zigZagLowZigZags.IsValidDataPointAt(i - Displacement);

				if (isHigh || isLow)
					break;

				preDiff++;
			}

			preDiff -= (Displacement < 0 ? Displacement : 0 - Displacement);

			int postDiff = 0;
			for (int i = ChartBars.ToIndex; i <= zigZagHighZigZags.Count; i++)
			{
				if (i - Displacement < startIndex || i - Displacement > Bars.Count - 1 - (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose ? 1 : 0))
					break;

				bool isHigh	= zigZagHighZigZags.IsValidDataPointAt(i - Displacement);
				bool isLow	= zigZagLowZigZags.IsValidDataPointAt(i - Displacement);

				if (isHigh || isLow)
					break;

				postDiff++;
			}

			postDiff += (Displacement < 0 ? 0 - Displacement : Displacement);

			int		lastIdx		= -1;
			double	lastValue	= -1;
			SharpDX.Direct2D1.PathGeometry	g		= null;
			SharpDX.Direct2D1.GeometrySink	sink	= null;

			for (int idx = ChartBars.FromIndex - preDiff; idx <= ChartBars.ToIndex + postDiff; idx++)
			{
				if (idx < startIndex || idx > Bars.Count - (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose ? 2 : 1) || idx < Math.Max(BarsRequiredToPlot - Displacement, Displacement))
					continue;

				bool isHigh	= zigZagHighZigZags.IsValidDataPointAt(idx);
				bool isLow	= zigZagLowZigZags.IsValidDataPointAt(idx);

				if (!isHigh && !isLow)
					continue;
				
				double value = isHigh ? zigZagHighZigZags.GetValueAt(idx) : zigZagLowZigZags.GetValueAt(idx);
				
				if (lastIdx >= startIndex)
				{
					float x1	= (chartControl.BarSpacingType == BarSpacingType.TimeBased || chartControl.BarSpacingType == BarSpacingType.EquidistantMulti && idx + Displacement >= ChartBars.Count
						? chartControl.GetXByTime(ChartBars.GetTimeByBarIdx(chartControl, idx + Displacement))
						: chartControl.GetXByBarIndex(ChartBars, idx + Displacement));
					float y1	= chartScale.GetYByValue(value);

					if (sink == null)
					{
						float x0	= (chartControl.BarSpacingType == BarSpacingType.TimeBased || chartControl.BarSpacingType == BarSpacingType.EquidistantMulti && lastIdx + Displacement >= ChartBars.Count
						? chartControl.GetXByTime(ChartBars.GetTimeByBarIdx(chartControl, lastIdx + Displacement))
						: chartControl.GetXByBarIndex(ChartBars, lastIdx + Displacement));
						float y0	= chartScale.GetYByValue(lastValue);
						g			= new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						sink		= g.Open();
						sink.BeginFigure(new SharpDX.Vector2(x0, y0), SharpDX.Direct2D1.FigureBegin.Hollow);
					}
					sink.AddLine(new SharpDX.Vector2(x1, y1));
				}

				// Save as previous point
				lastIdx		= idx;
				lastValue	= value;
			}

			if (sink != null)
			{
				sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Open);
				sink.Close();
			}

			if (g != null)
			{
				var oldAntiAliasMode = RenderTarget.AntialiasMode;
				RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
				RenderTarget.DrawGeometry(g, Plots[0].BrushDX, Plots[0].Width, Plots[0].StrokeStyle);
				RenderTarget.AntialiasMode = oldAntiAliasMode;
				g.Dispose();
				RemoveDrawObject("NinjaScriptInfo");
			}
			else
				Draw.TextFixed(this, "NinjaScriptInfo", NinjaTrader.Custom.Resource.ZigZagDeviationValueError, TextPosition.BottomRight);
			#endregion

			var axisTextFormat = AxisFont.ToDirectWriteTextFormat();
			var axisLayout     = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, "X", axisTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
			float priorX = -10;
			string spotsummary = "";
			var bkgtype = ContrastingColorTxt(chartControl.Properties.ChartBackground);
			if(TimeSlicePnLChartToggle){
				#region -- TimeSlicePnLChartToggle --
int l = 1;
//try{
				var rr = new SharpDX.Direct2D1.RoundedRectangle();
				int w = Convert.ToInt32(ChartPanel.W * 0.9);
				int h = Convert.ToInt32(ChartPanel.H * 0.9);
				int x = (ChartPanel.W - w)/2;
				int y = (ChartPanel.H - h)/2;
				rr.Rect = new SharpDX.Rectangle(x,y,w,h);
				rr.RadiusX = 10f;
				rr.RadiusY = 10f;
				RenderTarget.FillRoundedRectangle(ref rr, DimGrayBrushDX);//background of entire PnL chart
				var TimeHistos = new SortedDictionary<TimeSpan,TradeResult>();
				int MinutesPerHisto = 60;
l=20;
				#region -- Calculate MinutesPerHisto --
				TimeSpan tdiff = TimeSpan.MinValue;
				int mt = 0;
				int ht = pStartTime/100;
				mt = pStartTime - ht*100;
				var ts = new TimeSpan(ht,mt,0);
				if(pStartTime != pStopTime){
					ht = pStopTime/100;
					mt = pStopTime - ht*100;
					var tx = new TimeSpan(ht,mt,0);
					tdiff = tx-ts;
					if(pStartTime > pStopTime){
						tdiff = ts-tx;
						var tsd = new TimeSpan(24,0,0);
						tdiff = tsd - tdiff;
					}
				}
l=22;
				MinutesPerHisto = Math.Max(5,5+(int)Math.Round(tdiff.TotalDays*1440.0/20,0));
				MinutesPerHisto = MinutesPerHisto/5;
				MinutesPerHisto = MinutesPerHisto * 5;//rounds up to the nearest 5-minute interval
				int NumOfHistos = (int)Math.Round(tdiff.TotalMinutes / MinutesPerHisto +0.5,0);
//				#region -- Determine smallest minute of the day, the earliest trade for the leftmost histo --
//				int smallest_minofday = int.MaxValue;
//				foreach(var tr in Trades){
//					smallest_minofday = Math.Min(smallest_minofday, TimeToMinuteIndex(Times[0].GetValueAt(tr.Value.EntryABar)));
//				}
//				#endregion
				//mt = (int)Math.Round(smallest_minofday / 5.0 + 0.5,0)*5;//round smallest minofday to a 5-minute value
				ts = ts.Add(new TimeSpan(0,MinutesPerHisto,0));
				for(int i = 0; i<NumOfHistos; i++){
					TimeHistos[ts] = new TradeResult();//the key will be absolute minute of the day, from 0 to 1440
					ts = ts.Add(new TimeSpan(0,MinutesPerHisto,0));
				}
				TimeSpan mm = TimeSpan.MinValue;
l=24;
				double wins = 0;
				double losses = 0;
				double pnlticks = 0;
				double long_wins = 0;
				double short_wins = 0;
				double long_losses = 0;
				double short_losses = 0;
				double long_pnlticks = 0;
				double short_pnlticks = 0;
				int days_with_trades = 0;
				SortedDictionary<DayOfWeek, int> TradesPerDOW = new SortedDictionary<DayOfWeek, int>();
				DateTime date = DateTime.MinValue;
				foreach(var tr in Trades.Where(s=>SelectedDayOfWeek==-1 || (int)s.Value.EnterAt.DayOfWeek == SelectedDayOfWeek).ToList()){
l=tr.Value.EntryABar;
					if(!Times[0].IsValidDataPointAt(tr.Value.EntryABar)) continue;
					var keys = TimeHistos.Keys.Where(k=>k >= Times[0].GetValueAt(tr.Value.EntryABar).TimeOfDay).ToList();
					if(keys==null) Print("keys was null:  minute of day: "+Times[0].GetValueAt(tr.Value.EntryABar).TimeOfDay.ToString());
					else if(keys.Count>0){ //Print("keys was empty:  minute of day: "+Times[0].GetValueAt(tr.Value.EntryABar).TimeOfDay.ToString());
						mm = keys.Min();
						if(tr.Value.NetDist_tks>0){
							TimeHistos[mm].Wins = TimeHistos[mm].Wins+1;
							wins++;
							if(tr.Value.Dir=='L') {
								long_wins++; 
								long_pnlticks += tr.Value.TksXContracts;
							}else{
								short_wins++;
								short_pnlticks += tr.Value.TksXContracts;
							}
						}else{
							TimeHistos[mm].Losses = TimeHistos[mm].Losses+1;
							losses++;
							if(tr.Value.Dir=='L'){
								long_losses++;
								long_pnlticks += tr.Value.TksXContracts;
							}else{
								short_losses++;
								short_pnlticks += tr.Value.TksXContracts;
							}
						}
						if(tr.Value.EnterAt.Date != date.Date){
							days_with_trades++;
							date = tr.Value.EnterAt.Date;
							if(!TradesPerDOW.ContainsKey(tr.Value.EnterAt.DayOfWeek)) TradesPerDOW[tr.Value.EnterAt.DayOfWeek] = 1;
							else TradesPerDOW[tr.Value.EnterAt.DayOfWeek] = TradesPerDOW[tr.Value.EnterAt.DayOfWeek] + 1;
						}

						pnlticks += tr.Value.TksXContracts;
						TimeHistos[mm].Ticks.Add(tr.Value.TksXContracts);
						if(tr.Value.Dir == 'L')
							TimeHistos[mm].LTicks.Add(tr.Value.TksXContracts);
						else
							TimeHistos[mm].STicks.Add(tr.Value.TksXContracts);
					}
				}
				#endregion
l=28;
				#region -- calc min and max equity of all PnL data--
				double pmax = double.MinValue;
				double pmin = double.MaxValue;
				foreach(var kvp in TimeHistos) {
					double sum = kvp.Value.Ticks.Sum();
					double Lsum = kvp.Value.LTicks.Sum();
					double Ssum = kvp.Value.STicks.Sum();
					pmax = Math.Max(pmax, Math.Max(sum, Math.Max(Lsum,Ssum)));
					pmin = Math.Min(pmin, Math.Min(sum, Math.Min(Lsum,Ssum)));
				}
				#endregion
				axisLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, Math.Max(-pmin,pmax).ToString(), axisTextFormat, (float)(ChartPanel.X + ChartPanel.W), Convert.ToSingle(chartControl.Properties.LabelFont.Size));

				float maxpnlDollars = Convert.ToSingle(pmax);
				float minpnlDollars = Convert.ToSingle(pmin);
				float pnlRangeDollars = maxpnlDollars - minpnlDollars;

l=30;
				int graphTopY = y + 10;
				int graphBotY = y + h - 10 - Convert.ToInt32(axisLayout.Metrics.Height);//leave room at bottom to paint plot legend
				int graphRangePx = graphBotY - graphTopY;
				int graphMinX = x + Convert.ToInt32(axisLayout.Metrics.Width*1.2)+10;
				int graphMaxX = x + w - 10;

				float PxPerDollar = graphRangePx / pnlRangeDollars;
				float PxPerTrade = Convert.ToSingle(graphMaxX-graphMinX) / TimeHistos.Count;
				float YofPnLZero = Math.Min(graphBotY, graphBotY - Math.Abs(minpnlDollars) * PxPerDollar);
				var v0 = new SharpDX.Vector2(graphMinX, graphTopY);
				v1 = new SharpDX.Vector2(graphMinX, graphBotY);
				RenderTarget.DrawLine(v0, v1, BlackBrushDX, 2f); //vertical axis on left

l=40;
				var vTickTop = new SharpDX.Vector2(graphMinX, YofPnLZero);
				var vTickBot = new SharpDX.Vector2(0,0);
				#region -- draw horizontal price levels on chart --
				var YAxisLevelDistance = Math.Max(1f,Convert.ToSingle(Math.Round(pnlRangeDollars/10f,0)));
				axisLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, pmax.ToString(), axisTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
				slineRect.Y = YofPnLZero;
				slineRect.Height = axisLayout.Metrics.Height;
				v0.X = graphMinX;
				v1.X = graphMaxX;
				float lvl = 0;
				while(lvl < maxpnlDollars){//paint levels above the zero level
					axisLayout  = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, lvl==0? "Zero":lvl.ToString(), axisTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
					slineRect.Y = YofPnLZero - Convert.ToSingle(lvl) * PxPerDollar;
					v0.Y = slineRect.Y;
					v1.Y = v0.Y;
					RenderTarget.DrawLine(v0, v1, lvl==0 ? YellowBrushDX:BlackBrushDX, lvl==0 ? 3f:1f); //horizontal price levels

					slineRect.X = graphMinX - axisLayout.Metrics.Width-2f;
					slineRect.Y = slineRect.Y - axisLayout.Metrics.Height/2f;
					slineRect.Width = axisLayout.Metrics.Width;
					if(lvl==0)
						RenderTarget.FillRectangle(slineRect, BlackBrushDX);
					RenderTarget.DrawText(lvl==0? "Zero":lvl.ToString(), axisTextFormat, slineRect, lvl==0? MagentaBrushDX : WhiteBrushDX);//paint level tick value
					lvl += YAxisLevelDistance;
				}
				lvl = -YAxisLevelDistance;
				while(lvl > minpnlDollars){//paint levels below the zero level
					axisLayout  = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, lvl.ToString(), axisTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
					slineRect.Y = YofPnLZero - Convert.ToSingle(lvl) * PxPerDollar;
					v0.Y = slineRect.Y;
					v1.Y = v0.Y;
					RenderTarget.DrawLine(v0, v1, BlackBrushDX); //horizontal price levels

					slineRect.X = graphMinX - axisLayout.Metrics.Width-2f;
					slineRect.Y = slineRect.Y - axisLayout.Metrics.Height/2f;
					slineRect.Width = axisLayout.Metrics.Width;
					RenderTarget.DrawText(lvl.ToString(), axisTextFormat, slineRect, WhiteBrushDX);//paint level tick value
					lvl -= YAxisLevelDistance;
				}
				#endregion
				vTickTop = new SharpDX.Vector2(0,graphBotY);
				vTickBot = new SharpDX.Vector2(0,graphBotY+6);
				v0.X = graphMaxX;
				v0.Y = graphBotY;
				v1.X = graphMinX;
				v1.Y = graphBotY;

				RenderTarget.DrawLine(v1, v0, BlackBrushDX, 2f); //horiz axis at bottom
				if(graphBotY != YofPnLZero)
					RenderTarget.DrawLine(new SharpDX.Vector2(graphMinX, YofPnLZero), new SharpDX.Vector2(graphMaxX, YofPnLZero), MagentaBrushDX); //zero level

				v0.X = graphMinX+5;
				v1.X = graphMinX+5;
				v1.Y = YofPnLZero;
				slineRect.Y = graphBotY+2f;
				LimeBrushDX.Opacity = 0.6f;
				MagentaBrushDX.Opacity = 0.6f;
				int hour = (int)Math.Truncate(pStartTime/100.0);
				int minute = pStartTime-hour*100;
				var startts = new TimeSpan(hour,minute,0);
				var sTextFormat =pSummaryFont.ToDirectWriteTextFormat();
				spotsummary = string.Empty;
				foreach(var kvp in TimeHistos){
					v0.Y = YofPnLZero - Convert.ToSingle(kvp.Value.Ticks.Sum()) * PxPerDollar;
					#region -- Draw histo --
					float tempf = v0.X + PxPerTrade;
					v0.X = v0.X + PxPerTrade/2f;
					v1.X = v0.X;
					if(MouseX > priorX && MouseX <= tempf){
						RenderTarget.DrawLine(v1, v0, v0.Y < YofPnLZero ? DarkGreenBrushDX : MaroonBrushDX, Math.Max(2f,PxPerTrade/4f)); //Histo
					}else{
						RenderTarget.DrawLine(v1, v0, v0.Y < YofPnLZero ? LimeBrushDX : MagentaBrushDX, Math.Max(2f,PxPerTrade/4f)); //Histo
					}
					#endregion
					if(this.pShowLongs && this.pShowShorts){
						v0.Y = YofPnLZero - Convert.ToSingle(kvp.Value.LTicks.Sum()) * PxPerDollar;
						#region -- Draw Long sum histo --
						v0.X = v0.X-2f;
						v1.X = v0.X;
						RenderTarget.DrawLine(v1, v0, CyanBrushDX, 3f); //Histo for LONG ticks
						#endregion
						v0.Y = YofPnLZero - Convert.ToSingle(kvp.Value.STicks.Sum()) * PxPerDollar;
						#region -- Draw Short sum histo --
						v0.X = v0.X + 4f;
						v1.X = v0.X;
						RenderTarget.DrawLine(v1, v0, OrangeBrushDX, 3f); //Histo for SHORT ticks
						#endregion
					}
					v0.X = tempf;
					v1.X = v0.X;
					#region -- Draw hash marks along X-axis --
					vTickTop.X = v0.X;
					vTickBot.X = v0.X;
					RenderTarget.DrawLine(vTickTop, vTickBot, WhiteBrushDX, 2f); //vertical hash mark on bottom axis of chart
					#endregion
					#region -- Draw timestamps on x-axis --
					var timestr = string.Format("{0}:{1}", kvp.Key.Hours, kvp.Key.Minutes.ToString("00"));
					axisLayout  = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, timestr, axisTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
					slineRect.Width = axisLayout.Metrics.Width+4f;
					slineRect.X = v0.X- axisLayout.Metrics.Width-2f;
					#region -- draw dot marker on current time --
					var now = DateTime.Now.TimeOfDay;
					if(now > startts && now < kvp.Key){
						startts = TimeSpan.MaxValue;
						tempf = slineRect.Width;
						RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(slineRect.X, YofPnLZero+6f), 5f,5f), BlackBrushDX);
						slineRect.Width = tempf;
					}
					#endregion
					RenderTarget.FillRectangle(slineRect, DimGrayBrushDX);
					RenderTarget.DrawText(timestr, axisTextFormat, slineRect, BlackBrushDX);//paint time of day
					#endregion
					#region -- Draw summary text on each histo bar, on mouse hover --
					if(MouseX > priorX && MouseX <= v0.X && MouseY > graphTopY && MouseY < graphBotY && (kvp.Value.Wins>0 || kvp.Value.Losses>0)){
l=90;
						var tks = kvp.Value.Ticks.Sum();
//						spotsummary = string.Format("{0}\n{1}/{2} = {3}\n{4}-tks\n{5}/trade",
//							timestr,
//							kvp.Value.Wins,
//							kvp.Value.Losses,
//							(kvp.Value.Wins/kvp.Value.Ticks.Count).ToString("0%"), 
//							ReduceToThousands(tks.ToString("0")),
//							(tks/kvp.Value.Ticks.Count()).ToString("0"));
						spotsummary = $"{timestr}\n{kvp.Value.Wins}/{kvp.Value.Losses} = {(kvp.Value.Wins/kvp.Value.Ticks.Count).ToString("0%")}\n{ReduceToThousands(tks.ToString("0"))}-tks\n{ReduceToThousands((tks/kvp.Value.Ticks.Count()).ToString("0"))}/trade";
						var sLayout  = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, spotsummary, sTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
						var txtrect = new SharpDX.RectangleF(MouseX+7, MouseY-5-sLayout.Metrics.Height, sLayout.Metrics.Width, sLayout.Metrics.Height);
						if(MouseX > graphMaxX/2) txtrect.X = MouseX - sLayout.Metrics.Width-7;
						RenderTarget.DrawText(spotsummary, sTextFormat, txtrect, BlackBrushDX);//paint win/loss pct
						sLayout.Dispose();
					}
					priorX = v0.X;
					#endregion
				}
				#region -- Print the days of the week that are included --
				var str = string.Format("All days ({0}-{1})", days_with_trades, days_with_trades>1 ? "days":"day");
				switch (SelectedDayOfWeek) {
					case 0: str = string.Format("Only Sundays ({0})",   TradesPerDOW.ContainsKey(DayOfWeek.Sunday)?    TradesPerDOW[DayOfWeek.Sunday]:0);   break;
					case 1: str = string.Format("Only Mondays ({0})",   TradesPerDOW.ContainsKey(DayOfWeek.Monday)?    TradesPerDOW[DayOfWeek.Monday]:0);   break;
					case 2: str = string.Format("Only Tuesdays ({0})",  TradesPerDOW.ContainsKey(DayOfWeek.Tuesday)?   TradesPerDOW[DayOfWeek.Tuesday]:0);  break;
					case 3: str = string.Format("Only Wednesdays ({0})",TradesPerDOW.ContainsKey(DayOfWeek.Wednesday)? TradesPerDOW[DayOfWeek.Wednesday]:0);break;
					case 4: str = string.Format("Only Thursdays ({0})", TradesPerDOW.ContainsKey(DayOfWeek.Thursday)?  TradesPerDOW[DayOfWeek.Thursday]:0); break;
					case 5: str = string.Format("Only Fridays ({0})",   TradesPerDOW.ContainsKey(DayOfWeek.Friday)?    TradesPerDOW[DayOfWeek.Friday]:0);   break;
					case 6: str = string.Format("Only Saturdays ({0})", TradesPerDOW.ContainsKey(DayOfWeek.Saturday)?  TradesPerDOW[DayOfWeek.Saturday]:0); break;
				}
//				str = string.Format("{0}\n\tw/l w%\nAll:\t{1}/{2} {3}\nLongs:\t{4}/{5} {6}\nShorts:\t{7}/{8} {9}\n\nPnL (ticks)\n{10} :All\n{11} :Longs\n{12} :Shorts",
//					str,wins,losses,(wins/(wins+losses)).ToString("0%"), long_wins,long_losses,(long_wins/(long_wins+long_losses)).ToString("0%"), 
//					short_wins,short_losses,(short_wins/(short_wins+short_losses)).ToString("0%"),
//					pnlticks.ToString("0"), long_pnlticks.ToString("0"), short_pnlticks.ToString("0"));
				str = $"{str}\n\tw/l w%\nAll:\t{wins}/{losses} {(wins/(wins+losses)).ToString("0%")}\nLongs:\t{long_wins}/{long_losses} {(long_wins/(long_wins+long_losses)).ToString("0%")}\nShorts:\t{short_wins}/{short_losses} {(short_wins/(short_wins+short_losses)).ToString("0%")}\n\nPnL (ticks)\n{ReduceToThousands(pnlticks.ToString("0"))} :All\n{ReduceToThousands(long_pnlticks.ToString("0"))} :Longs\n{ReduceToThousands(short_pnlticks.ToString("0"))} :Shorts";
				str = str.Replace("NaN","");
				RenderTarget.DrawText(str, sTextFormat, new SharpDX.RectangleF(graphMinX+10, graphTopY+10,400f,400f), BlackBrushDX);//paint day of week text
				sTextFormat.Dispose();
				#endregion

				LimeBrushDX.Opacity = 1f;
				MagentaBrushDX.Opacity = 1f;
l=120;
//}catch(Exception e){Print(l+":  "+e.ToString());}
				#endregion
			}
			else if(PnLChartToggle){
				#region -- TradeByTrade Equity chart --
//				RemoveDrawObject("pnl");
				var rr = new SharpDX.Direct2D1.RoundedRectangle();
				int w = Convert.ToInt32(ChartPanel.W * 0.9);
				int h = Convert.ToInt32(ChartPanel.H * 0.9);
				int x = (ChartPanel.W - w)/2;
				int y = (ChartPanel.H - h)/2;
				rr.Rect = new SharpDX.Rectangle(x,y,w,h);
				rr.RadiusX = 10f;
				rr.RadiusY = 10f;
				RenderTarget.FillRoundedRectangle(ref rr, DimGrayBrushDX);//background of entire PnL chart
				#region -- calc min and max equity of all PnL data--
				double pmax = PnL.Max();
				double pmin = Math.Min(0,PnL.Min());
				foreach(var dow in PnLByDOW.Keys){
					var range = PnLByDOW[dow].GetRange(2,PnLByDOW[dow].Count-2).ToList();//ignore the first 2 double values in the list, they are win and loss count
					pmax = Math.Max(pmax, range.Max());
					pmin = Math.Min(pmin, range.Min());
				}
//Print(kvp.Key.ToString()+"   "+sum);
				#endregion
				axisLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, Math.Max(-pmin,pmax).ToString(), axisTextFormat, (float)(ChartPanel.X + ChartPanel.W), Convert.ToSingle(chartControl.Properties.LabelFont.Size));

				float maxpnlDollars = Convert.ToSingle(pmax);
				float minpnlDollars = Convert.ToSingle(pmin);
				float pnlRangeDollars = maxpnlDollars - minpnlDollars;

				int graphTopY = y + 10;
				int graphBotY = y + h - 10 - Convert.ToInt32(axisLayout.Metrics.Height);//leave room at bottom to paint plot legend
				int graphRangePx = graphBotY - graphTopY;
				int graphMinX = x + Convert.ToInt32(axisLayout.Metrics.Width*1.2)+10;
				int graphMaxX = x + w - 10;

				float PxPerDollar = graphRangePx / pnlRangeDollars;
				float PxPerTrade = Convert.ToSingle(graphMaxX-graphMinX) / PnL.Count;

				float YofPnLZero = Math.Min(graphBotY, graphBotY - Math.Abs(minpnlDollars) * PxPerDollar);
				var v0 = new SharpDX.Vector2(graphMinX, graphTopY);
				v1 = new SharpDX.Vector2(graphMinX, graphBotY);
				RenderTarget.DrawLine(v0, v1, BlackBrushDX, 2f); //vertical axis on left

				var vTickTop = new SharpDX.Vector2(graphMinX, YofPnLZero);
				var vTickBot = new SharpDX.Vector2(0,0);
				#region -- draw horizontal price levels on chart --
				var YAxisLevelDistance = Convert.ToSingle(Math.Round(pnlRangeDollars/10f,0));
				axisLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, pmax.ToString(), axisTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
				slineRect.Y = YofPnLZero;
				slineRect.Height = axisLayout.Metrics.Height;
				v0.X = graphMinX;
				v1.X = graphMaxX;
				float lvl = 0;
				while(lvl < maxpnlDollars){//paint levels above the zero level
					axisLayout  = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, lvl==0? "Zero":lvl.ToString(), axisTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
					slineRect.Y = YofPnLZero - Convert.ToSingle(lvl) * PxPerDollar;
					v0.Y = slineRect.Y;
					v1.Y = v0.Y;
					RenderTarget.DrawLine(v0, v1, lvl==0 ? YellowBrushDX:BlackBrushDX, lvl==0 ? 3f:1f); //horizontal price levels

					slineRect.X = graphMinX - axisLayout.Metrics.Width-2f;
					slineRect.Y = slineRect.Y - axisLayout.Metrics.Height/2f;
					slineRect.Width = axisLayout.Metrics.Width;
					if(lvl==0)
						RenderTarget.FillRectangle(slineRect, BlackBrushDX);
					RenderTarget.DrawText(lvl==0? "Zero":lvl.ToString(), axisTextFormat, slineRect, lvl==0? MagentaBrushDX : WhiteBrushDX);//paint level tick value
					lvl += YAxisLevelDistance;
				}
				lvl = -YAxisLevelDistance;
				while(lvl > minpnlDollars){//paint levels below the zero level
					axisLayout  = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, lvl.ToString(), axisTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
					slineRect.Y = YofPnLZero - Convert.ToSingle(lvl) * PxPerDollar;
					v0.Y = slineRect.Y;
					v1.Y = v0.Y;
					RenderTarget.DrawLine(v0, v1, BlackBrushDX); //horizontal price levels

					slineRect.X = graphMinX - axisLayout.Metrics.Width-2f;
					slineRect.Y = slineRect.Y - axisLayout.Metrics.Height/2f;
					slineRect.Width = axisLayout.Metrics.Width;
					RenderTarget.DrawText(lvl.ToString(), axisTextFormat, slineRect, WhiteBrushDX);//paint level tick value
					lvl -= YAxisLevelDistance;
				}
				#endregion
				vTickTop = new SharpDX.Vector2(0,graphBotY);
				vTickBot = new SharpDX.Vector2(0,graphBotY+6);
				v0.X = graphMaxX;
				v0.Y = graphBotY;
				v1.X = graphMinX;
				v1.Y = graphBotY;
				RenderTarget.DrawLine(v1, v0, BlackBrushDX, 2f); //horiz axis at bottom
				if(graphBotY != YofPnLZero)
					RenderTarget.DrawLine(new SharpDX.Vector2(graphMinX, YofPnLZero), new SharpDX.Vector2(graphMaxX, YofPnLZero), MagentaBrushDX); //zero level
				#region -- paint chart legend --
				slineRect.X = graphMinX + 8f;
				slineRect.Y = graphBotY + 8f;
				int daysofweekCount = 0;
				foreach(var dow in PnLByDOW){//only those days with at least 1 trade will be here
					axisLayout  = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, dow.Key.ToString(), axisTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
					slineRect.Width = axisLayout.Metrics.Width+4f;
					if(DOW_PlotBrushesDX[dow.Key] != null){
						daysofweekCount++;
						RenderTarget.FillRectangle(slineRect, DOW_PlotBrushesDX[dow.Key]);
						slineRect.X = slineRect.X + 2f;
						RenderTarget.DrawText(dow.Key.ToString(), axisTextFormat, slineRect, 
							this.DOW_ContrastPlotBrushesTxt[dow.Key]=='K' ? BlackBrushDX : WhiteBrushDX);//paint day of week text
					}
					slineRect.X = slineRect.X + axisLayout.Metrics.Width + 8f;
				}
				#region -- paint the "All" legend key --
				if(daysofweekCount>1){
					axisLayout  = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, "All", axisTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
					slineRect.Width = axisLayout.Metrics.Width+4f;
					RenderTarget.FillRectangle(slineRect, WhiteBrushDX);
					slineRect.X = slineRect.X + 2f;
					RenderTarget.DrawText("All", axisTextFormat, slineRect, BlackBrushDX);//paint "All" legend key
				}
				#endregion
				#endregion --------------------------------------------------------------------------------------------------------
				v0.X = graphMinX+5;
				v1.X = graphMinX+5;
				var DOWvectors = new SortedDictionary<DayOfWeek, SharpDX.Vector2[]>();
				spotsummary = string.Empty;
				SharpDX.RectangleF txtrect = new SharpDX.RectangleF(-1f,-1f,1f,1f);
				foreach(var dow in PnLByDOW.Keys)
					DOWvectors[dow] = new SharpDX.Vector2[2] {new SharpDX.Vector2(v0.X,0), new SharpDX.Vector2(v0.X,0)};

				var dotV = new SharpDX.Vector2(0f,0f);
				var dotVDOW = new SharpDX.Vector2(0f,0f);
				var dotDOW = DayOfWeek.Sunday;
				priorX = v0.X-15;
				for(int n = 0; n<PnL.Count; n++){
					v0.Y = YofPnLZero - Convert.ToSingle(PnL[n]) * PxPerDollar;
					foreach(var dow in PnLByDOW.Keys){
						DOWvectors[dow][0].Y = YofPnLZero - Convert.ToSingle(PnLByDOW[dow][n+2]) * PxPerDollar;//+2 skips the win count (0-element) and loss count (1-element)
					}
					if(n>=0){
						#region -- Draw netPnL line --
						v0.X = v0.X + PxPerTrade;
						if(DOWvectors.Count>1 && n>0)
							RenderTarget.DrawLine(v1, v0, WhiteBrushDX, 3f); //PnL line
						#endregion
						#region -- Draw hash marks along X-axis
						vTickTop.X = v0.X;
						vTickBot.X = v0.X;
						RenderTarget.DrawLine(vTickTop, vTickBot, WhiteBrushDX, 2f); //vertical hash mark on bottom axis of chart
						#endregion
						foreach(var dow in DOWvectors.Keys){
							DOWvectors[dow][0].X = DOWvectors[dow][0].X + PxPerTrade;
							if(n>0)RenderTarget.DrawLine(DOWvectors[dow][1], DOWvectors[dow][0], (DOW_PlotBrushesDX.ContainsKey(dow) && DOW_PlotBrushesDX[dow]!=null ? DOW_PlotBrushesDX[dow] : MagentaBrushDX), 2); //PnL line for each day of week
						}
						#region -- Draw summary text on each trade, on mouse hover --
						if(MouseX > priorX && MouseX <= v0.X && MouseY > graphTopY && MouseY < graphBotY){
//							spotsummary = string.Format("{0}\n{1}\n{2}x {3}\n{4}{5}-tks\n{6}-total\n{7}",
//								Trades[TradeKeys[n]].EnterAt.ToString("MM/dd/y H:mm"),
//								Trades[TradeKeys[n]].EnterAt.DayOfWeek,
//								Trades[TradeKeys[n]].Contracts,
//								Trades[TradeKeys[n]].Dir=='L' ? "Long":"Short",
//								Trades[TradeKeys[n]].NetDist_tks>0 ? "+":string.Empty,
//								Trades[TradeKeys[n]].TksXContracts,
//								PnL[n].ToString(),
//								Trades[TradeKeys[n]].Disposition
//								);
							spotsummary = $"{Trades[TradeKeys[n]].EnterAt.ToString("MM/dd/y H:mm")}\n{Trades[TradeKeys[n]].EnterAt.DayOfWeek}\n{Trades[TradeKeys[n]].Contracts}x {(Trades[TradeKeys[n]].Dir=='L' ? "Long":"Short")}\n{(Trades[TradeKeys[n]].NetDist_tks>0 ? "+":string.Empty)}{ReduceToThousands(Trades[TradeKeys[n]].TksXContracts.ToString("0"))}-tks\n{ReduceToThousands(PnL[n].ToString())}-total\n{Trades[TradeKeys[n]].Disposition}";
							dotDOW = Trades[TradeKeys[n]].EnterAt.DayOfWeek;
							var sTextFormat = pSummaryFont.ToDirectWriteTextFormat();
							var sLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, spotsummary, sTextFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
//							txtrect = new SharpDX.RectangleF(MouseX+7, MouseY-5-sLayout.Metrics.Height, sLayout.Metrics.Width, sLayout.Metrics.Height);
							txtrect.X = graphMinX+10f;
							txtrect.Y = graphTopY+10f;
							txtrect.Width = sLayout.Metrics.Width;
							txtrect.Height = sLayout.Metrics.Height;
							dotV.X = v0.X;
							dotV.Y = v0.Y;
//							if(spotsummary!=string.Empty && txtrect.X>0 && sLayout!=null && BlackBrushDX!=null && BlackBrushDX.IsValid(RenderTarget) && sTextFormat!=null){//this makes sure the text prints over the PnL line
								RenderTarget.DrawText(spotsummary, sTextFormat, txtrect, BlackBrushDX);
//							}
							sTextFormat.Dispose();sTextFormat = null;
							sLayout.Dispose();sLayout = null;
						}
						priorX = v0.X;
						#endregion
					}
					v1.X = v0.X;
					v1.Y = v0.Y;
					foreach(var dow in DOWvectors.Keys){
						DOWvectors[dow][1].X = DOWvectors[dow][0].X;
						DOWvectors[dow][1].Y = DOWvectors[dow][0].Y;
						if(dow == dotDOW && dotVDOW.X==0){
							dotVDOW.X = DOWvectors[dow][0].X;
							dotVDOW.Y = DOWvectors[dow][0].Y;
						}
					}
				}
				if(dotV.X>0){
					RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(dotV, 5f, 5f), MagentaBrushDX);//dot on PnL line
					RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(dotVDOW, 5f, 5f), MagentaBrushDX);//dot on PnL line for that DOW
				}
				#endregion
			}else if(ShowSummaryTable && pSummaryFont.Size>4){
				DimGrayBrushDX.Opacity = pSummaryTextBkgOpacity/100f;
				BlackBrushDX.Opacity = pSummaryTextBkgOpacity/100f;
				#region -- Show Summary table --
				var summaryTxtFormat  = pSummaryFont.ToDirectWriteTextFormat();
				var summaryLayout     = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, 
											PnLText, summaryTxtFormat, (float)(ChartPanel.X + ChartPanel.W),12f);

				slineRect.X = ChartPanel.W * pSummaryTxt_Xpct/100.0f-5f;
				slineRect.Y = ChartPanel.H * pSummaryTxt_Ypct/100.0f;
				float LeftX = slineRect.X;
				float TopY = slineRect.Y;
				float PnLTextWidth = summaryLayout.Metrics.Width+20f;
				slineRect.Width = PnLTextWidth;
				slineRect.Height = summaryLayout.Metrics.Height+10f;
				RenderTarget.FillRectangle(slineRect, bkgtype=='B' ? BlackBrushDX:DimGrayBrushDX);

				slineRect.X = slineRect.X+5f;
				slineRect.Y = slineRect.Y+5f;
				float PnLTextLeftX = slineRect.X + 5f;
				RenderTarget.DrawText(PnLText, summaryTxtFormat, slineRect, LimeBrushDX);

				var lines = PnLByDOWText.Split(new char[]{'\n'});
				List<float> colX = CalculateColumns(lines, summaryTxtFormat, PnLTextWidth-5f);
				slineRect.Y = slineRect.Y + summaryLayout.Metrics.Height;
				summaryLayout     = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, 
									lines[0], summaryTxtFormat, (float)(ChartPanel.X + ChartPanel.W),12f);
				slineRect.Height = summaryLayout.Metrics.Height;//SummaryFontSize + 5f + pLineHeight;

				if(pShowPnLByDOW){
					foreach(var L in lines){
						float x0 = LeftX;
						slineRect.X = x0;
						slineRect.Width = PnLTextWidth;
						RenderTarget.FillRectangle(slineRect, bkgtype=='B' ? BlackBrushDX:DimGrayBrushDX);
						slineRect.X = PnLTextLeftX;
						var coltxt = L.Split(new char[]{'\t'}, StringSplitOptions.None);
						for(int i = 0; i<coltxt.Length; i++){
							RenderTarget.DrawText(coltxt[i], summaryTxtFormat, slineRect, LimeBrushDX);
							slineRect.X = x0 + colX[i];
							x0 = slineRect.X;
						}
						slineRect.Y = slineRect.Y + slineRect.Height;
					}
				}
//return;//BBB

				if(pShowDrawdowns){
					lines = DrawdownsText.Split(new char[]{'\n'});
					colX = CalculateColumns(lines, summaryTxtFormat, PnLTextWidth-5f);
//Print("Drawdowns: "+lines.Length+"  text: "+DrawdownsText);
//return;//BBB
					foreach(var L in lines){
						slineRect.X = LeftX;
						slineRect.Width = PnLTextWidth;
						RenderTarget.FillRectangle(slineRect, bkgtype=='B' ? BlackBrushDX:DimGrayBrushDX);
						slineRect.X = PnLTextLeftX;
						var coltxt = L.Split(new char[]{'\t'}, StringSplitOptions.None);
						float x0 = LeftX;
						for(int i = 0; i<coltxt.Length; i++){
							RenderTarget.DrawText(coltxt[i], summaryTxtFormat, slineRect, LimeBrushDX);
							slineRect.X = x0 + colX[i];
							x0 = slineRect.X;
						}
						slineRect.Y = slineRect.Y + slineRect.Height;
					}
//return;//BBB
				}
				if(pShowDispositions){
					lines = DispositionsText.Split(new char[]{'\n'});
//Print("Dispositions: "+lines.Length);
//return;//BBB
					colX = CalculateColumns(lines, summaryTxtFormat, PnLTextWidth-5f);
					foreach(var L in lines){
						slineRect.X = LeftX;
						slineRect.Width = PnLTextWidth;
						RenderTarget.FillRectangle(slineRect, bkgtype=='B' ? BlackBrushDX:DimGrayBrushDX);
						slineRect.X = PnLTextLeftX;
						var coltxt = L.Split(new char[]{'\t'}, StringSplitOptions.None);
						float x0 = LeftX;
						for(int i = 0; i<coltxt.Length; i++){
							RenderTarget.DrawText(coltxt[i], summaryTxtFormat, slineRect, LimeBrushDX);
							slineRect.X = x0 + colX[i];
							x0 = slineRect.X;
						}
						slineRect.Y = slineRect.Y + slineRect.Height;
					}
				}
bool pShowStatus = false;
				if(pShowStatus){
					StatusTextDir["1TimeOfDay"] = "We are in session, awaiting an entry setup";//we are outside of start/stop time, or We are past the EOD time
					StatusTextDir["2PendingOrder"] = "Long setup present, enter 5 contracts at 1000.00";//
					StatusTextDir["3FilledLong"] = "We're long, target is: and stop is: ";
					StatusTextDir["4TrailMoved"] = "Trailing stop moved to: ";
					lines = StatusText.Split(new char[]{'\n'});
//Print("Dispositions: "+lines.Length);
//return;//BBB
					colX = CalculateColumns(lines, summaryTxtFormat, PnLTextWidth-5f);
					foreach(var L in lines){
						slineRect.X     = LeftX;
						slineRect.Width = PnLTextWidth;
						RenderTarget.FillRectangle(slineRect, BlackBrushDX);
						slineRect.X     = PnLTextLeftX;
						var coltxt      = L.Split(new char[]{'\t'}, StringSplitOptions.None);
						float x0        = LeftX;
						for(int i = 0; i<coltxt.Length; i++){
							RenderTarget.DrawText(coltxt[i], summaryTxtFormat, slineRect, LimeBrushDX);
							slineRect.X = x0 + colX[i];
							x0 = slineRect.X;
						}
						slineRect.Y = slineRect.Y + slineRect.Height;
					}
				}
				slineRect.Height = slineRect.Y - TopY+5f;
				slineRect.Width = PnLTextWidth;
				slineRect.X = LeftX;
				slineRect.Y = TopY;
				//RenderTarget.DrawRectangle(slineRect, DimGrayBrushDX);
				BlackBrushDX.Opacity = 1f;
				DimGrayBrushDX.Opacity = 1f;
				#endregion
			}
			axisTextFormat.Dispose();
			axisLayout.Dispose();
		}
		//==================================================================================================================
		private List<float> CalculateColumns(string[] lines, SharpDX.DirectWrite.TextFormat TxtFormat, float maxWidth){
			#region -- create colX list --
			var colX = new List<float>();
			foreach(var L in lines){
				if(L.Contains("\t")) {
					var coltxt = L.Split(new char[]{'\t'}, StringSplitOptions.None);
					while(colX.Count< coltxt.Length) colX.Add(0f);
					float x1 = colX[0];
					for(int i = 0; i<coltxt.Length; i++){
						var Layout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, coltxt[i], TxtFormat, (float)(ChartPanel.W),12f);
						if(colX[i] < Layout.Metrics.Width) colX[i] = Layout.Metrics.Width;//save the size of the biggest item in this column
					}
				}
			}
			#endregion
			if(colX.Count==0){
				colX.Add(maxWidth);
				return colX;
			}
			#region -- add space to each column to fill up max allowed width --
			float sf = colX.Sum();
			while(sf < maxWidth){
				for(int i = 0; i< colX.Count; i++) colX[i] = colX[i] + 2f;//add extra space in columns to fill up the max allowed width
				sf = colX.Sum();
			}
			for(int i = 0; i< colX.Count; i++) colX[i] = colX[i] + 1f;//add extra space in columns
			colX[0] = colX[0] + 15f;
			#endregion
			return colX;
		}
		//==================================================================================================================
		#region -- ContrastingColor methods --
		//set the color to Black or White depending on background color
//		public Brush ContrastingColor(DayOfWeek dow)
//		{
//			SolidColorBrush background=null;
//			switch (dow) {
//				case DayOfWeek.Sunday:    background = (SolidColorBrush)pSundayPlot_Brush; break;
//				case DayOfWeek.Monday:    background = (SolidColorBrush)pMondayPlot_Brush; break;
//				case DayOfWeek.Tuesday:   background = (SolidColorBrush)pTuesdayPlot_Brush; break;
//				case DayOfWeek.Wednesday: background = (SolidColorBrush)pWednesdayPlot_Brush; break;
//				case DayOfWeek.Thursday:  background = (SolidColorBrush)pThursdayPlot_Brush; break;
//				case DayOfWeek.Friday:    background = (SolidColorBrush)pFridayPlot_Brush; break;
//				case DayOfWeek.Saturday:  background = (SolidColorBrush)pSaturdayPlot_Brush; break;
//			}
//		    // Counting the perceptive luminance - human eye favors green color... 
//		    double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
//		    if (a < 0.5) return Brushes.Black; // bright colors - black font
//		    else return Brushes.White; // dark colors - white font
//		}
		public Brush ContrastingColor(Brush background)
		{
			var clr = (SolidColorBrush)background;
		    // Counting the perceptive luminance - human eye favors green color... 
		    double a = 1 - (0.299 * clr.Color.R + 0.587 * clr.Color.G + 0.114 * clr.Color.B) / 255;
		    if (a < 0.5) return Brushes.Black; // bright colors - black font
		    else return Brushes.White; // dark colors - white font
		}
		public Brush ContrastingColor(SolidColorBrush background)
		{
		    // Counting the perceptive luminance - human eye favors green color... 
		    double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
		    if (a < 0.5) return Brushes.Black; // bright colors - black font
		    else return Brushes.White; // dark colors - white font
		}
		public char ContrastingColorTxt(Brush brush)
		{
			var background = (SolidColorBrush) brush;
		    // Counting the perceptive luminance - human eye favors green color... 
		    double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
		    if (a < 0.5) return 'K'; // bright colors - black font
		    else return 'W'; // dark colors - white font
		}
		#endregion
		//==================================================================================================================
        private void FillTriangle(Point[] points, SharpDX.Direct2D1.Brush dxbrush, float opacity, ref ChartScale cs, ref ChartControl cc)
        {
			var p0 = new Point(cc.GetXByBarIndex(ChartBars, Convert.ToInt32(points[0].X)), cs.GetYByValue(points[0].Y));
			var p1 = new Point(cc.GetXByBarIndex(ChartBars, Convert.ToInt32(points[1].X)), cs.GetYByValue(points[1].Y));
			var p2 = new Point(cc.GetXByBarIndex(ChartBars, Convert.ToInt32(points[2].X)), cs.GetYByValue(points[2].Y));
            SharpDX.Vector2[] vectors = new[] { p1.ToVector2(), p2.ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(p0.ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

			float op = dxbrush.Opacity;
			dxbrush.Opacity = opacity;
            RenderTarget.FillGeometry(geo1, dxbrush);
			dxbrush.Opacity = op;
            geo1.Dispose();
            sink1.Dispose();
        }
		
//============================================================
		private SharpDX.Direct2D1.Brush MagentaBrushDX, YellowBrushDX, BlackBrushDX, WhiteBrushDX, LimeBrushDX, DimGrayBrushDX, PurpleBrushDX, ContrastToBkgBrushDX, ChartBkgBrushDX, DarkGreenBrushDX, MaroonBrushDX, CyanBrushDX, OrangeBrushDX;
		private SharpDX.Direct2D1.Brush UpTriangleBrushDX, DownTriangleBrushDX, HistoricalTriangleUpBrushDX, HistoricalTriangleDownBrushDX;
		private Dictionary<DayOfWeek, SharpDX.Direct2D1.Brush> DOW_PlotBrushesDX = new Dictionary<DayOfWeek, SharpDX.Direct2D1.Brush>();
		private Dictionary<DayOfWeek, char> DOW_ContrastPlotBrushesTxt = new Dictionary<DayOfWeek, char>();
		public override void OnRenderTargetChanged()
		{
			if(UpTriangleBrushDX!=null && !UpTriangleBrushDX.IsDisposed) UpTriangleBrushDX.Dispose(); UpTriangleBrushDX = null;
			if(RenderTarget!=null){
				UpTriangleBrushDX = pUpTriangleBrush.ToDxBrush(RenderTarget); UpTriangleBrushDX.Opacity = pTrianglesOpacity/100f;
			}
			if(DownTriangleBrushDX!=null && !DownTriangleBrushDX.IsDisposed) DownTriangleBrushDX.Dispose(); DownTriangleBrushDX = null;
			if(RenderTarget!=null){
				DownTriangleBrushDX = pDownTriangleBrush.ToDxBrush(RenderTarget); DownTriangleBrushDX.Opacity = pTrianglesOpacity/100f;
			}
			if(HistoricalTriangleUpBrushDX!=null && !HistoricalTriangleUpBrushDX.IsDisposed) HistoricalTriangleUpBrushDX.Dispose(); HistoricalTriangleUpBrushDX = null;
			if(RenderTarget!=null){
				HistoricalTriangleUpBrushDX = pHistoricalTriangleUpBrush.ToDxBrush(RenderTarget); HistoricalTriangleUpBrushDX.Opacity = pTrianglesOpacity/100f;
			}
			if(HistoricalTriangleDownBrushDX!=null && !HistoricalTriangleDownBrushDX.IsDisposed) HistoricalTriangleDownBrushDX.Dispose(); HistoricalTriangleDownBrushDX = null;
			if(RenderTarget!=null){
				HistoricalTriangleDownBrushDX = pHistoricalTriangleDownBrush.ToDxBrush(RenderTarget); HistoricalTriangleDownBrushDX.Opacity = pTrianglesOpacity/100f;
			}

			#region -- OnRenderTargetChanged --
			if(MagentaBrushDX!=null && !MagentaBrushDX.IsDisposed) MagentaBrushDX.Dispose(); MagentaBrushDX = null;
			if(RenderTarget!=null)
				MagentaBrushDX = Brushes.Magenta.ToDxBrush(RenderTarget);
			if(YellowBrushDX!=null && !YellowBrushDX.IsDisposed) YellowBrushDX.Dispose(); YellowBrushDX = null;
			if(RenderTarget!=null)
				YellowBrushDX = Brushes.Yellow.ToDxBrush(RenderTarget);
			if(BlackBrushDX!=null   && !BlackBrushDX.IsDisposed)   BlackBrushDX.Dispose();   BlackBrushDX = null;
			if(RenderTarget!=null)
				BlackBrushDX = Brushes.Black.ToDxBrush(RenderTarget);
			if(WhiteBrushDX!=null   && !WhiteBrushDX.IsDisposed)   WhiteBrushDX.Dispose();   WhiteBrushDX = null;
			if(RenderTarget!=null)
				WhiteBrushDX = Brushes.White.ToDxBrush(RenderTarget);
			if(LimeBrushDX!=null   && !LimeBrushDX.IsDisposed)   LimeBrushDX.Dispose();   LimeBrushDX = null;
			if(RenderTarget!=null)
				LimeBrushDX = Brushes.Lime.ToDxBrush(RenderTarget);
			if(DimGrayBrushDX!=null   && !DimGrayBrushDX.IsDisposed)   DimGrayBrushDX.Dispose();   DimGrayBrushDX = null;
			if(RenderTarget!=null)
				DimGrayBrushDX = Brushes.DimGray.ToDxBrush(RenderTarget);
			if(PurpleBrushDX!=null   && !PurpleBrushDX.IsDisposed)   PurpleBrushDX.Dispose();   PurpleBrushDX = null;
			if(RenderTarget!=null)
				PurpleBrushDX = Brushes.Purple.ToDxBrush(RenderTarget);
			if(CyanBrushDX!=null   && !CyanBrushDX.IsDisposed)   CyanBrushDX.Dispose();   CyanBrushDX = null;
			if(RenderTarget!=null)
				CyanBrushDX = Brushes.Cyan.ToDxBrush(RenderTarget);
			if(OrangeBrushDX!=null   && !OrangeBrushDX.IsDisposed)   OrangeBrushDX.Dispose();   OrangeBrushDX = null;
			if(RenderTarget!=null)
				OrangeBrushDX = Brushes.Orange.ToDxBrush(RenderTarget);

			if(DarkGreenBrushDX!=null   && !DarkGreenBrushDX.IsDisposed)   DarkGreenBrushDX.Dispose();   DarkGreenBrushDX = null;
			if(RenderTarget!=null)
				DarkGreenBrushDX = Brushes.DarkGreen.ToDxBrush(RenderTarget);
			if(MaroonBrushDX!=null   && !MaroonBrushDX.IsDisposed)   MaroonBrushDX.Dispose();   MaroonBrushDX = null;
			if(RenderTarget!=null)
				MaroonBrushDX = Brushes.Maroon.ToDxBrush(RenderTarget);

			if(ChartControl!=null && ChartControl.Properties.ChartBackground!=null){
				if(ChartBkgBrushDX!=null && !ChartBkgBrushDX.IsDisposed) ChartBkgBrushDX.Dispose(); ChartBkgBrushDX=null;
				if(RenderTarget!=null){
					ChartBkgBrushDX = ChartControl.Properties.ChartBackground.ToDxBrush(RenderTarget);
				}
				if(ContrastToBkgBrushDX!=null && !ContrastToBkgBrushDX.IsDisposed) ContrastToBkgBrushDX.Dispose(); ContrastToBkgBrushDX = null;
				if(RenderTarget!=null){
					ContrastToBkgBrushDX = ContrastingColor(ChartControl.Properties.ChartBackground).ToDxBrush(RenderTarget);
				}
			}

			DayOfWeek dowid = DayOfWeek.Sunday;
			if(DOW_PlotBrushesDX.ContainsKey(dowid) && DOW_PlotBrushesDX[dowid]!=null   && !DOW_PlotBrushesDX[dowid].IsDisposed)   DOW_PlotBrushesDX[dowid].Dispose();   DOW_PlotBrushesDX[dowid] = null;
			if(RenderTarget!=null && DaysOfWeekToTradeNumber.Contains("0")){
				DOW_PlotBrushesDX[dowid] = pSundayPlot_Brush.ToDxBrush(RenderTarget);
				DOW_ContrastPlotBrushesTxt[dowid] = this.ContrastingColorTxt(pSundayPlot_Brush.Clone());
			}
			dowid = DayOfWeek.Monday;
			if(DOW_PlotBrushesDX.ContainsKey(dowid) && DOW_PlotBrushesDX[dowid]!=null   && !DOW_PlotBrushesDX[dowid].IsDisposed)   DOW_PlotBrushesDX[dowid].Dispose();   DOW_PlotBrushesDX[dowid] = null;
			if(RenderTarget!=null && DaysOfWeekToTradeNumber.Contains("1")){
				DOW_PlotBrushesDX[dowid] = pMondayPlot_Brush.ToDxBrush(RenderTarget);
				DOW_ContrastPlotBrushesTxt[dowid] = this.ContrastingColorTxt(pMondayPlot_Brush.Clone());
			}
			dowid = DayOfWeek.Tuesday;
			if(DOW_PlotBrushesDX.ContainsKey(dowid) && DOW_PlotBrushesDX[dowid]!=null   && !DOW_PlotBrushesDX[dowid].IsDisposed)   DOW_PlotBrushesDX[dowid].Dispose();   DOW_PlotBrushesDX[dowid] = null;
			if(RenderTarget!=null && DaysOfWeekToTradeNumber.Contains("2")){
				DOW_PlotBrushesDX[dowid] = pTuesdayPlot_Brush.ToDxBrush(RenderTarget);
				DOW_ContrastPlotBrushesTxt[dowid] = this.ContrastingColorTxt(pTuesdayPlot_Brush.Clone());
			}
			dowid = DayOfWeek.Wednesday;
			if(DOW_PlotBrushesDX.ContainsKey(dowid) && DOW_PlotBrushesDX[dowid]!=null   && !DOW_PlotBrushesDX[dowid].IsDisposed)   DOW_PlotBrushesDX[dowid].Dispose();   DOW_PlotBrushesDX[dowid] = null;
			if(RenderTarget!=null && DaysOfWeekToTradeNumber.Contains("3")){
				DOW_PlotBrushesDX[dowid] = pWednesdayPlot_Brush.ToDxBrush(RenderTarget);
				DOW_ContrastPlotBrushesTxt[dowid] = this.ContrastingColorTxt(pWednesdayPlot_Brush.Clone());
			}
			dowid = DayOfWeek.Thursday;
			if(DOW_PlotBrushesDX.ContainsKey(dowid) && DOW_PlotBrushesDX[dowid]!=null   && !DOW_PlotBrushesDX[dowid].IsDisposed)   DOW_PlotBrushesDX[dowid].Dispose();   DOW_PlotBrushesDX[dowid] = null;
			if(RenderTarget!=null && DaysOfWeekToTradeNumber.Contains("4")){
				DOW_PlotBrushesDX[dowid] = pThursdayPlot_Brush.ToDxBrush(RenderTarget);
				DOW_ContrastPlotBrushesTxt[dowid] = this.ContrastingColorTxt(pThursdayPlot_Brush.Clone());
			}
			dowid = DayOfWeek.Friday;
			if(DOW_PlotBrushesDX.ContainsKey(dowid) && DOW_PlotBrushesDX[dowid]!=null   && !DOW_PlotBrushesDX[dowid].IsDisposed)   DOW_PlotBrushesDX[dowid].Dispose();   DOW_PlotBrushesDX[dowid] = null;
			if(RenderTarget!=null && DaysOfWeekToTradeNumber.Contains("5")){
				DOW_PlotBrushesDX[dowid] = pFridayPlot_Brush.ToDxBrush(RenderTarget);
				DOW_ContrastPlotBrushesTxt[dowid] = this.ContrastingColorTxt(pFridayPlot_Brush.Clone());
			}
			dowid = DayOfWeek.Saturday;
			if(DOW_PlotBrushesDX.ContainsKey(dowid) && DOW_PlotBrushesDX[dowid]!=null   && !DOW_PlotBrushesDX[dowid].IsDisposed)   DOW_PlotBrushesDX[dowid].Dispose();   DOW_PlotBrushesDX[dowid] = null;
			if(RenderTarget!=null && DaysOfWeekToTradeNumber.Contains("6")){
				DOW_PlotBrushesDX[dowid] = pSaturdayPlot_Brush.ToDxBrush(RenderTarget);
				DOW_ContrastPlotBrushesTxt[dowid] = this.ContrastingColorTxt(pSaturdayPlot_Brush.Clone());
			}
			#endregion
		}
//============================================================
	}
}
#region -- public enums --
public enum PivotPointBoss_DeviationType
{
	Percent,
	Points
}
public enum PivotPointBoss_Type {Reversing,Trending}
#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_StructureBoss[] cacheARC_StructureBoss;
		public ARC.ARC_StructureBoss ARC_StructureBoss(double pDeviationValue, PivotPointBoss_Type pType)
		{
			return ARC_StructureBoss(Input, pDeviationValue, pType);
		}

		public ARC.ARC_StructureBoss ARC_StructureBoss(ISeries<double> input, double pDeviationValue, PivotPointBoss_Type pType)
		{
			if (cacheARC_StructureBoss != null)
				for (int idx = 0; idx < cacheARC_StructureBoss.Length; idx++)
					if (cacheARC_StructureBoss[idx] != null && cacheARC_StructureBoss[idx].pDeviationValue == pDeviationValue && cacheARC_StructureBoss[idx].pType == pType && cacheARC_StructureBoss[idx].EqualsInput(input))
						return cacheARC_StructureBoss[idx];
			return CacheIndicator<ARC.ARC_StructureBoss>(new ARC.ARC_StructureBoss(){ pDeviationValue = pDeviationValue, pType = pType }, input, ref cacheARC_StructureBoss);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_StructureBoss ARC_StructureBoss(double pDeviationValue, PivotPointBoss_Type pType)
		{
			return indicator.ARC_StructureBoss(Input, pDeviationValue, pType);
		}

		public Indicators.ARC.ARC_StructureBoss ARC_StructureBoss(ISeries<double> input , double pDeviationValue, PivotPointBoss_Type pType)
		{
			return indicator.ARC_StructureBoss(input, pDeviationValue, pType);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_StructureBoss ARC_StructureBoss(double pDeviationValue, PivotPointBoss_Type pType)
		{
			return indicator.ARC_StructureBoss(Input, pDeviationValue, pType);
		}

		public Indicators.ARC.ARC_StructureBoss ARC_StructureBoss(ISeries<double> input , double pDeviationValue, PivotPointBoss_Type pType)
		{
			return indicator.ARC_StructureBoss(input, pDeviationValue, pType);
		}
	}
}

#endregion
