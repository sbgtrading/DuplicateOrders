#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion

#region Author/Copyright
/*********************************************************************
************************* Golden Zone Trading ************************
**********************************************************************
* Author NT7 : RJay at http://www.innovative-trading-solutions-online.com/
* Author NT8 : Kriss { AzurITec }
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
v1.00   - 12.04.2016    + Conversion from NT7 as is
                        + Change in new session code compare to ninja7. Check with Sean on EST zone and NQ
						+ Slot 16003
----------------------------------------------------------------------
v1.01   - 05.09.2016    + Compatible Beta13 RC1
						+ Default settings updated
----------------------------------------------------------------------
v1.02   - 01.03.2017    + Added Compilation Licensing code
                        + Tested with 8.0.4.0
----------------------------------------------------------------------
######################################################################
~~~~~~~~~~~~~~~~~~~~~~~~~ BUGS/ LIMITATIONS ~~~~~~~~~~~~~~~~~~~~~~~~~~
----------------------------------------------------------------------
*/
#endregion

namespace NinjaTrader.NinjaScript.BarsTypes
{
	public class ARC_FullRange : BarsType
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "FullRange";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "21406", "25900", "819", "24787"};//819 is old mastery program
							//"24787" is HFTAlgo
		private string indicatorVersion = "v1.0";
		#region ARCLicense
		#region --  Registry class  --
		public class ModifyRegistry
		{
			public int NO_KEY_DEFINED = -1;
			public int ERROR_READING_KEY = -2;
			public string ErrorStatus = string.Empty;

			private bool showError = true;
			/// <summary>
			/// A property to show or hide error messages 
			/// (default = false)
			/// </summary>
			public bool ShowError
			{
				get { return showError; }
				set	{ showError = value; }
			}

			private string subKey = "Software\\NeuroStreet\\Settings";
			/// <summary>
			/// A property to set the SubKey value
			/// (default = "SOFTWARE\\" + Application.ProductName.ToUpper())
			/// </summary>
			public string SubKey
			{
				get { return subKey; }
				set	{ subKey = value; }
			}

			private Microsoft.Win32.RegistryKey baseRegistryKey = Microsoft.Win32.Registry.CurrentUser;
			/// <summary>
			/// A property to set the BaseRegistryKey value.
			/// (default = Registry.LocalMachine)
			/// </summary>
			public Microsoft.Win32.RegistryKey BaseRegistryKey
			{
				get { return baseRegistryKey; }
				set	{ baseRegistryKey = value; }
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To read a registry key.
			/// input: KeyName (string)
			/// output: value (string) 
			/// </summary>
			public int Read(string KeyName)
			{
				// Opening the registry key
				var rk = baseRegistryKey ;
				// Open a subKey as read-only
				var sk1 = rk.OpenSubKey(subKey);
				// If the RegistrySubKey doesn't exist -> (null)
				if ( sk1 == null )
				{
					return NO_KEY_DEFINED;
				}
				else
				{
					try 
					{
						// If the RegistryKey exists I get its value
						// or null is returned.
						return Convert.ToInt32(sk1.GetValue(KeyName));
					}
					catch (Exception e)
					{
						ErrorStatus = e.ToString();
						// AAAAAAAAAAARGH, an error!
//						if(parent!=null) ShowErrorMessage(e, "Reading registry " + KeyName, parent);
						return ERROR_READING_KEY;
					}
				}
			}	

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To write into a registry key.
			/// input: KeyName (string) , Value (object)
			/// output: true or false 
			/// </summary>
			public bool Write(string KeyName, object Value, NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					// I have to use CreateSubKey 
					// (create or open it if already exits), 
					// 'cause OpenSubKey open a subKey as read-only
					var sk1 = rk.CreateSubKey(subKey);
					// Save the value
					sk1.SetValue(KeyName, Value);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Writing registry " + KeyName, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To delete a registry key.
			/// input: KeyName (string)
			/// output: true or false 
			/// </summary>
			public bool DeleteKey(string KeyName, NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.CreateSubKey(subKey);
					// If the RegistrySubKey doesn't exists -> (true)
					if ( sk1 == null )
						return true;
					else
						sk1.DeleteValue(KeyName);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Deleting SubKey " + subKey, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To delete a sub key and any child.
			/// input: void
			/// output: true or false 
			/// </summary>
			public bool DeleteSubKeyTree(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists, I delete it
					if ( sk1 != null )
						rk.DeleteSubKeyTree(subKey);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Deleting SubKey " + subKey, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// Retrive the count of subkeys at the current key.
			/// input: void
			/// output: number of subkeys
			/// </summary>
			public int SubKeyCount(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists...
					if ( sk1 != null )
						return sk1.SubKeyCount;
					else
						return 0; 
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Retriving subkeys of " + subKey, parent);
					return 0;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// Retrive the count of values in the key.
			/// input: void
			/// output: number of keys
			/// </summary>
			public int ValueCount(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists...
					if ( sk1 != null )
						return sk1.ValueCount;
					else
						return 0; 
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Retriving keys of " + subKey, parent);
					return 0;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/
			
			private void ShowErrorMessage(Exception e, string Title, NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				if (showError)
					parent.Print(e.Message);
			}
		}
		#endregion ----------------------------------------
		ModifyRegistry Reg = new ModifyRegistry();
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(bool PingRegistry){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
				search = "nscid_*.txt";
				filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
				if(filCustom!=null){
					foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
						var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
						if(elements.Length>1)
							ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
					}
				}
			}
			if(ret_custid == -1 && PingRegistry){
				//the config file doesn't exist, create one based on what is recovered from the registry
				try{
if(IsDebug) Print(" ARCCID file is getting custid from registry because of file missing");
					ret_custid = Reg.Read("custid");
				}catch(Exception ex2){
if(IsDebug) Print("Registry read error: "+ex2.ToString());
					if(!LicErrorMessageHandler.IsDuplicate(ex2.ToString())) LogMsg("Please run your 'ARC_LicenseActivator v1' and supply your ARCAI Contact ID number", Cbi.LogLevel.Alert);
					return -1;
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			MachineId = NinjaTrader.Cbi.License.MachineId;
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				NewCustId = GetCustID(true);
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");
				NewCustId = GetCustID(true);
				#region -- Read config folder for ContactID --
//				string folder = ARCConfigDirectory;
//				string search = "arccid_*.txt";
//				var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
//				if(filCustom!=null){
//					foreach(System.IO.FileInfo fi in filCustom){
//						var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
//						if(elements.Length>1)
//							NewCustId = int.Parse(elements[1]);
//					}
//				}else{//the config file doesn't exist, create one based on what is recovered from the registry
//					try{
//if(IsDebug) Print(" ARCCID file is getting custid from registry because of file missing");
//						NewCustId = Reg.Read("custid", this);
//					}catch(Exception ex2){
//if(IsDebug) Print("Registry read error: "+ex2.ToString());
//						if(!LicErrorMessageHandler.IsDuplicate(ex2.ToString())) LogMsg("Please run your 'ARC_LicenseActivator v1' and supply your ARCAI Contact ID number", Cbi.LogLevel.Alert);
//						return false;
//					}
//					if(NewCustId>0){
//						System.IO.File.WriteAllText(
//							System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+NewCustId.ToString().Trim()+".txt"),
//							NewCustId.ToString()
//						);
//					}
//				}
				#endregion
//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
				bool IsConnectionIssue = UserId.CompareTo("253729")==0 || MachineId.CompareTo("0DE7B460EE7C494980DC065DDE946572")==0;//Chris Zolton
				if(IsConnectionIssue) return true;
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, NinjaTrader.Cbi.License.MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).Ticks.ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			bool IsJohnParaiso = NewCustId == 362496;
			if(IsJohnParaiso)
				Log(msg, Cbi.LogLevel.Warning);
			else{
				if(filCustom==null || filCustom.Length==0)
					Log(msg, alrt);
				else
					Log(msg, Cbi.LogLevel.Warning);
			}
		}

		#endregion

        private int RealCurrentBar;

		protected override void OnStateChange()
		{
            if (State == State.SetDefaults)
            {
                Description = @"";
                Name = "ARC_FullRange";
                BarsPeriod = new BarsPeriod { BarsPeriodType = (BarsPeriodType)16003, BarsPeriodTypeName = "ARC_FullRange", Value = 4 };
                BuiltFrom = BarsPeriodType.Tick;
                DaysToLoad = 5;
                IsIntraday = true;
            }
            else if (State == State.Configure)
            {
				IsDebug = System.IO.File.Exists(@"c:\222222222222.txt") && (NinjaTrader.Cbi.License.MachineId.CompareTo("1E53E271B82EC62C7C03A15C336229AE")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
				#region DoLicense call
#if DoLicense
				if(!IsDebug){
//					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
					if(!LicenseChecked){
						ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
						LicenseChecked = true;
					}
					IsVisible = true;
				}else
					ValidLicense = true;
#endif
				#endregion
                Name = "ARC_FullRange  " + BarsPeriod.Value.ToString() + " Tick" + (BarsPeriod.MarketDataType != MarketDataType.Last ? " - " + BarsPeriod.MarketDataType : string.Empty);
                
                Properties.Remove(Properties.Find("ReversalType", true));
                Properties.Remove(Properties.Find("BaseBarsPeriodType", true));
                Properties.Remove(Properties.Find("BaseBarsPeriodValue", true));
                Properties.Remove(Properties.Find("PointAndFigurePriceType", true));
                Properties.Remove(Properties.Find("Value2", true));

                SetPropertyName("Value", "Value");
            }
		}

        #region ##### generic #####
        public override int GetInitialLookBackDays(BarsPeriod barsPeriod, TradingHours tradingHours, int barsBack) { return 1; }
        public override void ApplyDefaultBasePeriodValue(BarsPeriod period) {  }
        public override void ApplyDefaultValue(BarsPeriod period)
        {
            period.BarsPeriodTypeName = "ARC_FullRange";
            period.Value = 10;
        }
        public override string ChartLabel(DateTime time) { return time.ToString("T", Core.Globals.GeneralOptions.CurrentCulture); }
        public override double GetPercentComplete(Bars bars, DateTime now) { return 0; }
        //public override bool IsRemoveLastBarSupported { get { return false; } }
        #endregion

        protected override void OnDataPoint(Bars bars, double open, double high, double low, double close, DateTime time, long volume, bool isBar, double bid, double ask)
        {
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				IsVisible = false;
				return;
			}
#endif
            if (SessionIterator == null) SessionIterator = new SessionIterator(bars);//Code Breaking Change - From Beta 9
            bool isNewSession = SessionIterator.IsNewSession(time, isBar);//Code Breaking Change - From Beta 9 
            if (isNewSession) SessionIterator.CalculateTradingDay(time, isBar);//Code Breaking Change - From Beta 9 
            
            if (bars.Count == 0 || bars.IsResetOnNewTradingDay && isNewSession) AddBar(bars, close, close, close, close, time, volume);//@Session Start
            else
            {
                DateTime barTime = bars.GetTime(bars.Count - 1);
                long barVolume = bars.GetVolume(bars.Count - 1);
                double barOpen = bars.GetOpen(bars.Count - 1);
                double barHigh = bars.GetHigh(bars.Count - 1);
                double barLow = bars.GetLow(bars.Count - 1);
                double barClose = bars.GetClose(bars.Count - 1);

                double tickSize = bars.Instrument.MasterInstrument.TickSize;
                double rangeValue = Math.Floor(10000000.0 * (double)bars.BarsPeriod.Value * tickSize) / 10000000.0;

                #region -- Bar Break Up --
                if (bars.Instrument.MasterInstrument.Compare(close, barLow + rangeValue) > 0)
                {
                    int NewBarCount = bars.Count - 2;
                    bool isFirstNewBar = true;
                    double newClose = barLow + rangeValue; // every bar closes either with high or low
                    
                    UpdateBar(bars, newClose, barLow, newClose, time, 0);
                                        
                    // if still gap, fill with phantom bars
                    double newBarOpen = newClose;
                    
                    while (bars.Instrument.MasterInstrument.Compare(close, newClose) > 0)
                    {
                        newClose = Math.Min(close, newBarOpen + rangeValue);
                        
                        AddBar(bars, newBarOpen, newClose, newBarOpen, newClose, time, isFirstNewBar ? volume : 0);

                        newBarOpen = newClose;
                        NewBarCount = bars.Count - 1;
                        isFirstNewBar = false;
                    }
                }
                #endregion

                #region -- Bar Break Dw --
                else if (bars.Instrument.MasterInstrument.Compare(barHigh - rangeValue, close) > 0)
                {
                    int NewBarCount = bars.Count - 2;
                    bool isFirstNewBar = true;
                    double newClose = barHigh - rangeValue; // every bar closes either with high or low
                    
                    UpdateBar(bars, barHigh, newClose, newClose, time, 0);

                    // if still gap, fill with phantom bars
                    
                    double newBarOpen = newClose;
                    while (bars.Instrument.MasterInstrument.Compare(newClose, close) > 0)
                    {
                        newClose = Math.Max(close, newBarOpen - rangeValue);
                        
                        AddBar(bars, newBarOpen, newBarOpen, newClose, newClose, time, isFirstNewBar ? volume : 0);

                        newBarOpen = newClose;
                        NewBarCount = bars.Count - 1;
                        isFirstNewBar = false;
                    }
                }
                #endregion

                else UpdateBar(bars, high, low, close, time, volume);
            }
            bars.LastPrice = close;
        }

	}
}















