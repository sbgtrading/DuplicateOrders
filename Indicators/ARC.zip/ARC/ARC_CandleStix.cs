#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion
using System.Windows.Controls;

//This namespace holds Indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region -- Category Order --
    [CategoryOrder("Bullish Patterns", 1)]
    [CategoryOrder("Bearish Patterns", 10)]
    [CategoryOrder("Filters", 20)]
    [CategoryOrder("Racing Stripes", 30)]
    [CategoryOrder("ChartMarker Signals", 40)]
    [CategoryOrder("Highlight Pattern Bars", 50)]
    [CategoryOrder("Audible Alerts", 55)]
    [CategoryOrder("Pattern Description Text", 60)]
    [CategoryOrder("Indicator Display", 70)]
    [CategoryOrder("Indicator Version", 80)]
	#endregion
    [TypeConverter("NinjaTrader.NinjaScript.Indicators.ARC.CandleStixConverter")]
	public class ARC_CandleStix : Indicator
	{
		#region -- Variables --
		private const int UP = 1;
		private const int DOWN = -1;

		private ARC_CandleStix_CandleStickPatternLogic	BullFinder, BearFinder;
//		private int 					numPatternsFound;
//		private Brush					downBrush				= Brushes.DimGray;
//		private TextPosition			textBoxPosition			= TextPosition.BottomRight;
//		private Brush					textBrush				= Brushes.DimGray;
//		private Brush					upBrush					= Brushes.DimGray;
		private SortedDictionary<ARC_CandleStix_Patterns, ARC_CandleStix_BullPatterns> UserSelectedBullishPatterns = new SortedDictionary<ARC_CandleStix_Patterns, ARC_CandleStix_BullPatterns>();
		private SortedDictionary<ARC_CandleStix_Patterns, ARC_CandleStix_BearPatterns> UserSelectedBearishPatterns = new SortedDictionary<ARC_CandleStix_Patterns, ARC_CandleStix_BearPatterns>();
//		private ARC_CandleStix_Patterns Pattern = ARC_CandleStix_Patterns.MorningStar;
		private Series<double> patternID;
//		private System.Windows.Media.Brush BullRacingStripe = null;
//		private System.Windows.Media.Brush BearRacingStripe = null;
		private SortedDictionary<int,ARC_CandleStix_BullPatterns> BullLocations = new SortedDictionary<int,ARC_CandleStix_BullPatterns>();
		private SortedDictionary<int,ARC_CandleStix_BearPatterns> BearLocations = new SortedDictionary<int,ARC_CandleStix_BearPatterns>();

		private SortedDictionary<int, ARC_CandleStix_BullPatterns> Bullenums = new SortedDictionary<int, ARC_CandleStix_BullPatterns>();
		private SortedDictionary<int, ARC_CandleStix_BearPatterns> Bearenums = new SortedDictionary<int, ARC_CandleStix_BearPatterns>();
		private SharpDX.Direct2D1.Brush BullRacingStripeDXBrush= null;
		private SharpDX.Direct2D1.Brush BearRacingStripeDXBrush= null;
		private SharpDX.Direct2D1.Brush WhiteDXBrush = null;
		private SharpDX.Direct2D1.Brush BlackDXBrush = null;
		private SharpDX.Direct2D1.Brush BullTextDXBrush = null;
		private SharpDX.Direct2D1.Brush BearTextDXBrush = null;
		private SharpDX.Direct2D1.Brush BullBarHighlightBrushDX = null;//pBullBarHighlightBrush
		private SharpDX.Direct2D1.Brush BearBarHighlightBrushDX = null;//pBearBarHighlightBrush

		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
        private Grid indytoolbar;
		private string toolbarname = "ARCCStxTB", uID;
		private List<int> BullSigBars = null;
		private List<int> BearSigBars = null;

		string msgText=null;
		int msgX = 0;
		int msgY = 0;
		#endregion
		private SortedDictionary<string,List<int>> VisibleSignals = new SortedDictionary<string,List<int>>();
		int Last_RMaB = -1;
		int Last_LMaB = -1;

		private string VERSION = "v1.0";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "CandleStix";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "13797", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId,LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion
		
		bool IsDebug = false;
		private int SoundAlertABar = 0;

		//==================================================================
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> PatternID		{get { return patternID; }}
		//==================================================================
//======== OnMouseMove ============================================================
        private void OnMouseMove(object sender, MouseEventArgs e)
        {
			if(!Keyboard.IsKeyDown(Key.LeftShift)) return;
			Point coords = e.GetPosition(ChartPanel);
			var Y = ChartingExtensions.ConvertToVerticalPixels(coords.Y, ChartControl.PresentationSource);
			var X = ChartingExtensions.ConvertToHorizontalPixels(coords.X, ChartControl.PresentationSource);
			int MouseABar = ChartBars.GetBarIdxByX(ChartControl, X);
			string msg = string.Empty;
			if     (BullLocations.ContainsKey(MouseABar)) msg = string.Format("Bull {0}", BullLocations[MouseABar].ToString());
			else if(BearLocations.ContainsKey(MouseABar)) msg = string.Format("Bear {0}", BearLocations[MouseABar].ToString());
			if(!string.IsNullOrEmpty(msg)) {
				msgText = msg;
				msgX = MouseABar;
				msgY = Y;
			}
		}
//======== OnStateChange ============================================================
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				#region SetDefaults
				Description			= "";
				Name				= "ARC_CandleStix";
				Calculate			= Calculate.OnBarClose;
				IsOverlay			= true;
				DrawOnPricePanel	= true;
				DisplayInDataBox	= false;
				IsAutoScale			= false;
				PaintPriceMarkers	= false;

				AddPlot(new Stroke(Brushes.Transparent,1), PlotStyle.Dot, "Pattern ID");
//				ShowAlerts			= true;
				TrendStrength		= 4;
				pRacingStripesDirections = ARC_CandleStix_Directions.Both;
				pBullishRacingStripeBrush = Brushes.Green;
				pBearishRacingStripeBrush = Brushes.Red;
				pBullishRacingStripeOpacity = 50;
				pBearishRacingStripeOpacity = 50;
				pBullPat_All = true;
				pShow_1barBulls = true;
				pShow_2barBulls = true;
				pShow_3barBulls = true;
				pBearPat_All = true;
				pShow_1barBears = true;
				pShow_2barBears = true;
				pShow_3barBears = true;
				pButtonText = "CandleStix";
				pMarkerTicks = 1;
				pDescriptionFont = new Gui.Tools.SimpleFont("Arial",12);

				pChartMarkerDirections = ARC_CandleStix_Directions.Both;
				pLongChartMarkerBrush = Brushes.Green;
				pShortChartMarkerBrush = Brushes.Red;

				pDescriptionsEnabled = true;
				pBullTextBrush = Brushes.Lime;
				pBearTextBrush = Brushes.Magenta;

				pHighlightPatternBars     = false;
				pBullBarHighlightBrush   = Brushes.Blue;
				pBullBarHighlightOpacity = 50;
				pBearBarHighlightBrush   = Brushes.Magenta;
				pBearBarHighlightOpacity = 50;
				#endregion
			}
			else if (State == State.Configure)
			{
				#region Configure
				Calculate	= Calculate.OnBarClose;
				Guid x = Guid.NewGuid();
				uID = x.ToString().Replace(" ",string.Empty).Replace("-",string.Empty);
//				foreach (var value in Enum.GetValues(typeof(ARC_CandleStix_BullPatterns)))
//					Bullenums[value] = (ARC_CandleStix_BullPatterns)value;
//				foreach (var value in Enum.GetValues(typeof(ARC_CandleStix_BearPatterns)))
//					Bearenums[value] = (ARC_CandleStix_BearPatterns)value;
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion
			}
			else if (State == State.DataLoaded){
				#region DataLoaded
				BullFinder = new ARC_CandleStix_CandleStickPatternLogic(this, TrendStrength);
				BearFinder = new ARC_CandleStix_CandleStickPatternLogic(this, TrendStrength);

				if(pBullPat_Hammer)				UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.Hammer,             ARC_CandleStix_BullPatterns.Hammer);
				if(pBullPat_InvertedHammer)		UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.InvertedHammer,     ARC_CandleStix_BullPatterns.InvertedHammer);
				if(pBullPat_Doji)				UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.Doji,               ARC_CandleStix_BullPatterns.Doji);
				if(pBullPat_Kicker)				UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.Kicker,             ARC_CandleStix_BullPatterns.Kicker);
				if(pBullPat_Engulfing)			UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.BullishEngulfing,   ARC_CandleStix_BullPatterns.Engulfing);
				if(pBullPat_Harami)				UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.BullishHarami,      ARC_CandleStix_BullPatterns.Harami);
				if(pBullPat_PiercingLine)		UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.PiercingLine,       ARC_CandleStix_BullPatterns.PiercingLine);
				if(pBullPat_MorningStar) 		UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.MorningStar,        ARC_CandleStix_BullPatterns.MorningStar);
				if(pBullPat_ThreeWhiteSoldiers)	UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.ThreeWhiteSoldiers, ARC_CandleStix_BullPatterns.ThreeWhiteSoldiers);
				if(pBullPat_ThreeLineStrike)	UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.RisingThreeMethods, ARC_CandleStix_BullPatterns.ThreeLineStrike);
				if(pBullPat_ThreeInside) 		UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.ThreeInside,        ARC_CandleStix_BullPatterns.ThreeInside);
				if(pBullPat_ThreeOutside) 		UserSelectedBullishPatterns.Add(ARC_CandleStix_Patterns.ThreeOutside,       ARC_CandleStix_BullPatterns.ThreeOutside);

				if(pBearPat_HangingMan)		 UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.HangingMan,          ARC_CandleStix_BearPatterns.HangingMan);
				if(pBearPat_ShootingStar)	 UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.ShootingStar,        ARC_CandleStix_BearPatterns.ShootingStar);
				if(pBearPat_Doji)			 UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.Doji,                ARC_CandleStix_BearPatterns.Doji);
				if(pBearPat_Kicker)			 UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.Kicker,              ARC_CandleStix_BearPatterns.Kicker);
				if(pBearPat_Engulfing)		 UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.BearishEngulfing,    ARC_CandleStix_BearPatterns.Engulfing);
				if(pBearPat_Harami)			 UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.BearishHarami,       ARC_CandleStix_BearPatterns.Harami);
				if(pBearPat_DarkCloudCover)	 UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.DarkCloudCover,      ARC_CandleStix_BearPatterns.DarkCloudCover);
				if(pBearPat_EveningStar) 	 UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.EveningStar,         ARC_CandleStix_BearPatterns.EveningStar);
				if(pBearPat_ThreeBlackCrows) UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.ThreeBlackCrows,     ARC_CandleStix_BearPatterns.ThreeBlackCrows);
				if(pBearPat_ThreeLineStrike) UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.FallingThreeMethods, ARC_CandleStix_BearPatterns.ThreeLineStrike);
				if(pBearPat_ThreeInside) 	 UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.ThreeInside,         ARC_CandleStix_BearPatterns.ThreeInside);
				if(pBearPat_ThreeOutside) 	 UserSelectedBearishPatterns.Add(ARC_CandleStix_Patterns.ThreeOutside,        ARC_CandleStix_BearPatterns.ThreeOutside);
				#endregion
				
				if(ChartPanel!=null) ChartPanel.MouseMove  += OnMouseMove;
				patternID = new Series<double>(this, MaximumBarsLookBack.Infinite);
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        ChartControl.AllowDrop = false;
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;

                        foreach (DependencyObject item in chartWindow.MainMenu) {
							if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;
						}

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Visible };

                            addToolBar();

                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            System.Windows.Automation.AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion
			}
			else if(State == State.Terminated)
			{
				#region Terminated
				if(ChartPanel!=null){
					ChartPanel.MouseMove -= OnMouseMove;
				}
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
				#endregion
			}
		}
//======== AddToolbar ============================================================
		private void DrawChartMarker(int abar, int DirOfSignal, string tag){
			#region DrawChartMarker
			tag = string.Format("CandleStix{0}_{1}",tag,abar);
			double ticks = pMarkerTicks*TickSize;
			if(pGlobalizeMarkers){
				if(DirOfSignal==UP){
					switch (pBuyChartMarkers){
						case ARC_CandleStix_ChartMarkers.Arrow   :  TriggerCustomEvent(o2 =>{	Draw.ArrowUp   (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, true, pLongMarker_Template);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Triangle:  TriggerCustomEvent(o2 =>{	Draw.TriangleUp(this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, true, pLongMarker_Template);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Dot     :  TriggerCustomEvent(o2 =>{	Draw.Dot       (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, true, pLongMarker_Template);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Square  :  TriggerCustomEvent(o2 =>{	Draw.Square    (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, true, pLongMarker_Template);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Diamond :  TriggerCustomEvent(o2 =>{	Draw.Diamond   (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, true, pLongMarker_Template);},0,null);break;
					}
				}
				else if(DirOfSignal==DOWN){
					switch (pSellChartMarkers){
						case ARC_CandleStix_ChartMarkers.Arrow   :  TriggerCustomEvent(o2 =>{	Draw.ArrowDown   (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, true, pShortMarker_Template);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Triangle:  TriggerCustomEvent(o2 =>{	Draw.TriangleDown(this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, true, pShortMarker_Template);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Dot     :  TriggerCustomEvent(o2 =>{	Draw.Dot         (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, true, pShortMarker_Template);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Square  :  TriggerCustomEvent(o2 =>{	Draw.Square      (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, true, pShortMarker_Template);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Diamond :  TriggerCustomEvent(o2 =>{	Draw.Diamond     (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, true, pShortMarker_Template);},0,null);break;
					}
				}
			}else{
//Draw.Dot(this,"zordersetting",false,-2,0,Brushes.Transparent);	RemoveDrawObject("zordersetting");},0,null);
				if(DirOfSignal==UP){
					switch (pBuyChartMarkers){
						case ARC_CandleStix_ChartMarkers.Arrow   :  TriggerCustomEvent(o2 =>{	Draw.ArrowUp   (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, pLongChartMarkerBrush);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Triangle:  TriggerCustomEvent(o2 =>{	Draw.TriangleUp(this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, pLongChartMarkerBrush);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Dot     :  TriggerCustomEvent(o2 =>{	Draw.Dot       (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, pLongChartMarkerBrush);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Square  :  TriggerCustomEvent(o2 =>{	Draw.Square    (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, pLongChartMarkerBrush);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Diamond :  TriggerCustomEvent(o2 =>{	Draw.Diamond   (this,tag,false,CurrentBars[0]-abar, Lows[0].GetValueAt(abar)-ticks, pLongChartMarkerBrush);},0,null);break;
					}
				}
				else if(DirOfSignal==DOWN){
					switch (pSellChartMarkers){
						case ARC_CandleStix_ChartMarkers.Arrow   :  TriggerCustomEvent(o2 =>{	Draw.ArrowDown   (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, pShortChartMarkerBrush);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Triangle:  TriggerCustomEvent(o2 =>{	Draw.TriangleDown(this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, pShortChartMarkerBrush);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Dot     :  TriggerCustomEvent(o2 =>{	Draw.Dot         (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, pShortChartMarkerBrush);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Square  :  TriggerCustomEvent(o2 =>{	Draw.Square      (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, pShortChartMarkerBrush);},0,null);break;
						case ARC_CandleStix_ChartMarkers.Diamond :  TriggerCustomEvent(o2 =>{	Draw.Diamond     (this,tag,false,CurrentBars[0]-abar, Highs[0].GetValueAt(abar)+ticks, pShortChartMarkerBrush);},0,null);break;
					}
				}
			}
			#endregion
		}
//==========================================================================================================
        #region -- TabSelectionChangedHandler() --
        private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        private Menu MenuControlContainer;
        private MenuItem MenuControl, miShowChartMarkers, miShowRacingStripes, miShowTextDescriptions, miShowBarHighlights;
		private MenuItem miShowBullPatterns, miShow1BarBullPatterns, miShow2BarBullPatterns, miShow3BarBullPatterns;
		private MenuItem miShowBearPatterns, miShow1BarBearPatterns, miShow2BarBearPatterns, miShow3BarBearPatterns;

		private void addToolBar(){
			#region -- addToolBar ------------------------------------------------------------------
			MenuControlContainer = new System.Windows.Controls.Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
            MenuControl = new MenuItem {Name="NSCanStx"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.White, Header = pButtonText, Foreground = Brushes.White, Background=Brushes.DarkGreen, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);
	//- - - - - - - - - - - - -
			#region -- miShowChartMarkers --
			miShowChartMarkers = new MenuItem {Header = "Chart Markers:  "+(pChartMarkerDirections.ToString()), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowChartMarkers.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Longs)       pChartMarkerDirections = ARC_CandleStix_Directions.Shorts;
				else if(pChartMarkerDirections == ARC_CandleStix_Directions.Shorts) pChartMarkerDirections = ARC_CandleStix_Directions.None;
				else if(pChartMarkerDirections == ARC_CandleStix_Directions.None)   pChartMarkerDirections = ARC_CandleStix_Directions.Both;
				else if(pChartMarkerDirections == ARC_CandleStix_Directions.Both)   pChartMarkerDirections = ARC_CandleStix_Directions.Longs;
				miShowChartMarkers.Header = "Chart Markers:  "+(pChartMarkerDirections.ToString());
				#region -- Delete markers where not requested --
				if(pChartMarkerDirections == ARC_CandleStix_Directions.None){
					List<string> del = new List<string>();
					foreach (dynamic obj in DrawObjects){
						if(obj.Tag.StartsWith("CandleStix"))	del.Add(obj.Tag);
					}
					foreach(string d in del)	RemoveDrawObject(d);
				}else if(pChartMarkerDirections == ARC_CandleStix_Directions.Longs){
					List<string> del = new List<string>();
					foreach (dynamic obj in DrawObjects){
						if(obj.Tag.StartsWith("CandleStixd"))	del.Add(obj.Tag);
					}
					foreach(string d in del)	RemoveDrawObject(d);
				}else if(pChartMarkerDirections == ARC_CandleStix_Directions.Shorts){
					List<string> del = new List<string>();
					foreach (dynamic obj in DrawObjects){
						if(obj.Tag.StartsWith("CandleStixu"))	del.Add(obj.Tag);
					}
					foreach(string d in del)	RemoveDrawObject(d);
				}
				#endregion
				#region -- Draw markers where requested --
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Longs || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					if(pShow_1barBulls){
						var pList = BullLocations.Where(k => (int)k.Value <=119).ToList();
						foreach(var p in pList){
							DrawChartMarker(p.Key, UP, "u");
						}
					}
					if(pShow_2barBulls){
						var pList = BullLocations.Where(k => (int)k.Value >=120 && (int)k.Value <=129).ToList();
						foreach(var p in pList){
							DrawChartMarker(p.Key, UP, "u");
						}
					}
					if(pShow_3barBulls){
						var pList = BullLocations.Where(k => (int)k.Value >=130 && (int)k.Value <=139).ToList();
						foreach(var p in pList){
							DrawChartMarker(p.Key, UP, "u");
						}
					}
				}
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Shorts || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					if(pShow_1barBears){
						var pList = BearLocations.Where(k => (int)k.Value <=219).ToList();
						foreach(var p in pList){
							DrawChartMarker(p.Key, DOWN, "d");
						}
					}
					if(pShow_2barBears){
						var pList = BearLocations.Where(k => (int)k.Value >=220 && (int)k.Value <=229).ToList();
						foreach(var p in pList){
							DrawChartMarker(p.Key, DOWN, "d");
						}
					}
					if(pShow_3barBears){
						var pList = BearLocations.Where(k => (int)k.Value >=230 && (int)k.Value <=239).ToList();
						foreach(var p in pList){
							DrawChartMarker(p.Key, DOWN, "d");
						}
					}
				}
				#endregion
				CalculateWhichSigsAreShowing();
				ForceRefresh();
			};
//			miShowChartMarkers.MouseWheel += delegate(object o, MouseWheelEventArgs e){
//			};
			MenuControl.Items.Add(miShowChartMarkers);
			#endregion
	//- - - - - - - - - - - - -
			#region -- miShowRacingStripes --
			miShowRacingStripes = new MenuItem {Header = "Racing Stripes:  "+(pRacingStripesDirections.ToString()), Name = "RS"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowRacingStripes.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(pRacingStripesDirections == ARC_CandleStix_Directions.Both)        pRacingStripesDirections = ARC_CandleStix_Directions.Longs;
				else if(pRacingStripesDirections == ARC_CandleStix_Directions.Longs)  pRacingStripesDirections = ARC_CandleStix_Directions.Shorts;
				else if(pRacingStripesDirections == ARC_CandleStix_Directions.Shorts) pRacingStripesDirections = ARC_CandleStix_Directions.None;
				else if(pRacingStripesDirections == ARC_CandleStix_Directions.None)   pRacingStripesDirections = ARC_CandleStix_Directions.Both;
				miShowRacingStripes.Header = "Racing Stripes:  "+(pRacingStripesDirections.ToString());
				CalculateWhichSigsAreShowing();
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			miShowRacingStripes.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				if(pRacingStripesDirections == ARC_CandleStix_Directions.Both)        pRacingStripesDirections = ARC_CandleStix_Directions.Longs;
				else if(pRacingStripesDirections == ARC_CandleStix_Directions.Longs)  pRacingStripesDirections = ARC_CandleStix_Directions.Shorts;
				else if(pRacingStripesDirections == ARC_CandleStix_Directions.Shorts) pRacingStripesDirections = ARC_CandleStix_Directions.None;
				else if(pRacingStripesDirections == ARC_CandleStix_Directions.None)   pRacingStripesDirections = ARC_CandleStix_Directions.Both;
				miShowRacingStripes.Header = "Racing Stripes:  "+(pRacingStripesDirections.ToString());
				CalculateWhichSigsAreShowing();
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			MenuControl.Items.Add(miShowRacingStripes);
			#endregion
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - -
			#region -- miShowBulls --
//			miShowBullPatterns = new MenuItem {Header = "Enabled Bulls:  "+(pShow_Bulls ? "ON" : "OFF"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
//			miShowBullPatterns.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
//				pShow_Bulls = !pShow_Bulls;
//				miShowBullPatterns.Header = "Enabled Bulls:  "+(pShow_Bulls ? "ON" : "OFF");
//				if(pShowChartMarkers){
//					var pList = BullLocations.Where(k => (int)k.Value <=119).ToList();
//					if(pShow_Bulls && pShow_1barBulls){
//						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
//					}
//					pList = BullLocations.Where(k => (int)k.Value >=120 && (int)k.Value <=129).ToList();
//					if(pShow_Bulls && pShow_2barBulls){
//						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
//					}
//					pList = BullLocations.Where(k => (int)k.Value >=130 && (int)k.Value <=139).ToList();
//					if(pShow_Bulls && pShow_3barBulls){
//						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
//					}
//					CalculateWhichSigsAreShowing();
//				}
//				ForceRefresh();
//			};
//			miShowBullPatterns.MouseWheel += delegate(object o, MouseWheelEventArgs e){
//				e.Handled = true;
//				pShow_Bulls = !pShow_Bulls;
//				miShowBullPatterns.Header = "Enabled Bulls:  "+(pShow_Bulls ? "ON" : "OFF");
//				if(pShowChartMarkers){
//					var pList = BullLocations.Where(k => (int)k.Value <=119).ToList();
//					if(pShow_Bulls && pShow_1barBulls){
//						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
//					}
//					pList = BullLocations.Where(k => (int)k.Value >=120 && (int)k.Value <=129).ToList();
//					if(pShow_Bulls && pShow_2barBulls){
//						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
//					}
//					pList = BullLocations.Where(k => (int)k.Value >=130 && (int)k.Value <=139).ToList();
//					if(pShow_Bulls && pShow_3barBulls){
//						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
//					}
//					CalculateWhichSigsAreShowing();
//				}
//				ForceRefresh();
//			};
//			MenuControl.Items.Add(miShowBullPatterns);
			#endregion
	//- - - - - - - - - - - - -
			#region -- miShow1BarBullPatterns --
			miShow1BarBullPatterns = new MenuItem {Header = "Show 1-bar Bulls:  "+(pShow_1barBulls ? "ON" : "OFF"), Name = "sbull1"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShow1BarBullPatterns.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShow_1barBulls = !pShow_1barBulls;
				miShow1BarBullPatterns.Header = "Show 1-bar Bulls:  "+(pShow_1barBulls ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Longs || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BullLocations.Where(k => (int)k.Value <=119).ToList();
					if(pShow_1barBulls){
						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			miShow1BarBullPatterns.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				pShow_1barBulls = !pShow_1barBulls;
				miShow1BarBullPatterns.Header = "Show 1-bar Bulls:  "+(pShow_1barBulls ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Longs || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BullLocations.Where(k => (int)k.Value <=119).ToList();
					if(pShow_1barBulls){
						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			MenuControl.Items.Add(miShow1BarBullPatterns);
			#endregion
	//- - - - - - - - - - - - -
			#region -- miShow2BarBullPatterns --
			miShow2BarBullPatterns = new MenuItem {Header = "Show 2-bar Bulls:  "+(pShow_2barBulls ? "ON" : "OFF"), Name = "sbull2"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShow2BarBullPatterns.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShow_2barBulls = !pShow_2barBulls;
				miShow2BarBullPatterns.Header = "Show 2-bar Bulls:  "+(pShow_2barBulls ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Longs || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BullLocations.Where(k => (int)k.Value >=120 && (int)k.Value <=129).ToList();
					if(pShow_2barBulls){
						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			miShow2BarBullPatterns.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				pShow_2barBulls = !pShow_2barBulls;
				miShow2BarBullPatterns.Header = "Show 2-bar Bulls:  "+(pShow_2barBulls ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Longs || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BullLocations.Where(k => (int)k.Value >=120 && (int)k.Value <=129).ToList();
					if(pShow_2barBulls){
						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			MenuControl.Items.Add(miShow2BarBullPatterns);
			#endregion
	//- - - - - - - - - - - - -
			#region -- miShow3BarBullPatterns --
			miShow3BarBullPatterns = new MenuItem {Header = "Show 3-bar Bulls:  "+(pShow_3barBulls ? "ON" : "OFF"), Name = "sbull3"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShow3BarBullPatterns.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShow_3barBulls = !pShow_3barBulls;
				miShow3BarBullPatterns.Header = "Show 3-bar Bulls:  "+(pShow_3barBulls ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Longs || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BullLocations.Where(k => (int)k.Value >=130 && (int)k.Value <=139).ToList();
					if(pShow_3barBulls){
						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			miShow3BarBullPatterns.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				pShow_3barBulls = !pShow_3barBulls;
				miShow3BarBullPatterns.Header = "Show 3-bar Bulls:  "+(pShow_3barBulls ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Longs || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BullLocations.Where(k => (int)k.Value >=130 && (int)k.Value <=139).ToList();
					if(pShow_3barBulls){
						foreach(var p in pList)	DrawChartMarker(p.Key, UP, "u");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixu_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			MenuControl.Items.Add(miShow3BarBullPatterns);
			#endregion
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - -
			#region -- miShowBears --
//			miShowBearPatterns = new MenuItem {Header = "Enabled Bears:  "+(pShow_Bears ? "ON" : "OFF"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
//			miShowBearPatterns.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
//				pShow_Bears = !pShow_Bears;
//				miShowBearPatterns.Header = "Enabled Bears:  "+(pShow_Bears ? "ON" : "OFF");
//				if(pShowChartMarkers){
//					var pList = BearLocations.Where(k => (int)k.Value <=219).ToList();
//					if(pShow_Bears && pShow_1barBears){
//						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
//					}
//					pList = BearLocations.Where(k => (int)k.Value >=220 && (int)k.Value <=229).ToList();
//					if(pShow_Bears && pShow_2barBears){
//						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
//					}
//					pList = BearLocations.Where(k => (int)k.Value >=230 && (int)k.Value <=239).ToList();
//					if(pShow_Bears && pShow_3barBears){
//						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
//					}
//					CalculateWhichSigsAreShowing();
//				}
//				ForceRefresh();
//			};
//			miShowBearPatterns.MouseWheel += delegate(object o, MouseWheelEventArgs e){
//				e.Handled = true;
//				pShow_Bears = !pShow_Bears;
//				miShowBearPatterns.Header = "Enabled Bears:  "+(pShow_Bears ? "ON" : "OFF");
//				if(pShowChartMarkers){
//					var pList = BearLocations.Where(k => (int)k.Value <=219).ToList();
//					if(pShow_Bears && pShow_1barBears){
//						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
//					}
//					pList = BearLocations.Where(k => (int)k.Value >=220 && (int)k.Value <=229).ToList();
//					if(pShow_Bears && pShow_2barBears){
//						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
//					}
//					pList = BearLocations.Where(k => (int)k.Value >=230 && (int)k.Value <=239).ToList();
//					if(pShow_Bears && pShow_3barBears){
//						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
//					}else{
//						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
//					}
//					CalculateWhichSigsAreShowing();
//				}
//				ForceRefresh();
//			};
//			MenuControl.Items.Add(miShowBearPatterns);
			#endregion
	//- - - - - - - - - - - - -
			#region -- miShow1BarBearPatterns --
			miShow1BarBearPatterns = new MenuItem {Header = "Show 1-bar Bears:  "+(pShow_1barBears ? "ON" : "OFF"), Name = "sbear1"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShow1BarBearPatterns.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShow_1barBears = !pShow_1barBears;
				miShow1BarBearPatterns.Header = "Show 1-bar Bears:  "+(pShow_1barBears ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Shorts || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BearLocations.Where(k => (int)k.Value <=219).ToList();
					if(pShow_1barBears){
						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			miShow1BarBearPatterns.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				pShow_1barBears = !pShow_1barBears;
				miShow1BarBearPatterns.Header = "Show 1-bar Bears:  "+(pShow_1barBears ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Shorts || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BearLocations.Where(k => (int)k.Value <=219).ToList();
					if(pShow_1barBears){
						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			MenuControl.Items.Add(miShow1BarBearPatterns);
			#endregion
	//- - - - - - - - - - - - -
			#region -- miShow2BarBearPatterns --
			miShow2BarBearPatterns = new MenuItem {Header = "Show 2-bar Bears:  "+(pShow_2barBears ? "ON" : "OFF"), Name = "sbear2"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShow2BarBearPatterns.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShow_2barBears = !pShow_2barBears;
				miShow2BarBearPatterns.Header = "Show 2-bar Bears:  "+(pShow_2barBears ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Shorts || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BearLocations.Where(k => (int)k.Value >=220 && (int)k.Value <=229).ToList();
					if(pShow_2barBears){
						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			miShow2BarBearPatterns.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				pShow_2barBears = !pShow_2barBears;
				miShow2BarBearPatterns.Header = "Show 2-bar Bears:  "+(pShow_2barBears ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Shorts || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BearLocations.Where(k => (int)k.Value >=220 && (int)k.Value <=229).ToList();
					if(pShow_2barBears){
						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			MenuControl.Items.Add(miShow2BarBearPatterns);
			#endregion
	//- - - - - - - - - - - - -
			#region -- miShow3BarBearPatterns --
			miShow3BarBearPatterns = new MenuItem {Header = "Show 3-bar Bears:  "+(pShow_3barBears ? "ON" : "OFF"), Name = "sbear3"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShow3BarBearPatterns.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pShow_3barBears = !pShow_3barBears;
				miShow3BarBearPatterns.Header = "Show 3-bar Bears:  "+(pShow_3barBears ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Shorts || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BearLocations.Where(k => (int)k.Value >=230 && (int)k.Value <=239).ToList();
					if(pShow_3barBears){
						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			miShow3BarBearPatterns.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				pShow_3barBears = !pShow_3barBears;
				miShow3BarBearPatterns.Header = "Show 3-bar Bears:  "+(pShow_3barBears ? "ON" : "OFF");
				if(pChartMarkerDirections == ARC_CandleStix_Directions.Shorts || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
					var pList = BearLocations.Where(k => (int)k.Value >=230 && (int)k.Value <=239).ToList();
					if(pShow_3barBears){
						foreach(var p in pList)	DrawChartMarker(p.Key, DOWN, "d");
					}else{
						foreach(var p in pList) RemoveDrawObject(string.Format("CandleStixd_{0}",p.Key));
					}
					CalculateWhichSigsAreShowing();
				}
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			MenuControl.Items.Add(miShow3BarBearPatterns);
			#endregion
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - -
			#region -- miShowBarHighlights --
			miShowBarHighlights = new MenuItem {Header = "Bar highlights:  "+(pHighlightPatternBars ? "ON" : "OFF"), Name = "sbhl"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowBarHighlights.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pHighlightPatternBars = !pHighlightPatternBars;
				miShowBarHighlights.Header = "Bar highlights:  "+(pHighlightPatternBars ? "ON" : "OFF");
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			miShowBarHighlights.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				pHighlightPatternBars = !pHighlightPatternBars;
				miShowBarHighlights.Header = "Bar highlights:  "+(pHighlightPatternBars ? "ON" : "OFF");
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			MenuControl.Items.Add(miShowBarHighlights);
			#endregion
	//- - - - - - - - - - - - -
			#region -- miShowTextDescriptions --
			miShowTextDescriptions = new MenuItem {Header = "Text Descriptions:  "+(pDescriptionsEnabled ? "ON" : "OFF"), Name = "sTD"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miShowTextDescriptions.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pDescriptionsEnabled = !pDescriptionsEnabled;
				miShowTextDescriptions.Header = "Text Descriptions:  "+(pDescriptionsEnabled ? "ON" : "OFF");
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			miShowTextDescriptions.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				pDescriptionsEnabled = !pDescriptionsEnabled;
				miShowTextDescriptions.Header = "Text Descriptions:  "+(pDescriptionsEnabled ? "ON" : "OFF");
				Last_RMaB = -1;//this will force a recalc of signal lists, in OnRender
				ForceRefresh();
			};
			MenuControl.Items.Add(miShowTextDescriptions);
			#endregion
			#endregion

			indytoolbar.Children.Add(MenuControlContainer);
		}
//======== OnBarUpdate ============================================================
		protected override void OnBarUpdate()
		{
			#region -- OnBarUpdate --
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			int new_sigs = 0;
			int p = 0;
			if(CurrentBars[0]<3) return;
			foreach(var Pattern in UserSelectedBullishPatterns){
				p = BullFinder.Evaluate(Pattern.Key);
				if(Pattern.Value == ARC_CandleStix_BullPatterns.Doji && !BullFinder.isInDownTrend) p = -1;
				if(Pattern.Value == ARC_CandleStix_BullPatterns.Kicker  && !BullFinder.isInUpTrend) p = -1;
				if(Pattern.Value == ARC_CandleStix_BullPatterns.ThreeInside  && !BullFinder.isInUpTrend) p = -1;
				if(Pattern.Value == ARC_CandleStix_BullPatterns.ThreeOutside && !BullFinder.isInUpTrend) p = -1;
				if(p >= 0){
					new_sigs++;
					BullLocations[CurrentBars[0]] = Pattern.Value;
					patternID[0] = (int)Pattern.Value;
					Value[0] = patternID[0];
					if(pChartMarkerDirections == ARC_CandleStix_Directions.Longs || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
						if(pShow_1barBulls && patternID[0] <= 119) {
							DrawChartMarker(CurrentBars[0], UP, "u");
							if(SoundAlertABar!=CurrentBar && !pWAV_1barBull.Contains("SOUND OFF")){
								if(pPrintToAlertsWindow)
									Alert(DateTime.Now.ToString(), pSoundAlertPriority, "1-bar bull", AddSoundFolder(pWAV_1barBull), 1, Brushes.Black, Brushes.Lime);
								else
									PlaySound(AddSoundFolder(pWAV_1barBull));
							}
							SoundAlertABar = CurrentBar;
						}
						if(pShow_2barBulls && IsBetweenInclusive(patternID[0], 120, 129)) {
							DrawChartMarker(CurrentBars[0], UP, "u");
							if(SoundAlertABar!=CurrentBar && !pWAV_2barBull.Contains("SOUND OFF")){
								if(pPrintToAlertsWindow)
									Alert(DateTime.Now.ToString(), pSoundAlertPriority, "2-bar bull", AddSoundFolder(pWAV_2barBull), 1, Brushes.Black, Brushes.Lime);
								else
									PlaySound(AddSoundFolder(pWAV_2barBull));
							}
							SoundAlertABar = CurrentBar;
						}
						if(pShow_3barBulls && IsBetweenInclusive(patternID[0], 130, 139)) {
							DrawChartMarker(CurrentBars[0], UP, "u");
							if(SoundAlertABar!=CurrentBar && !pWAV_3barBull.Contains("SOUND OFF")){
								if(pPrintToAlertsWindow)
									Alert(DateTime.Now.ToString(), pSoundAlertPriority, "3-bar bull", AddSoundFolder(pWAV_3barBull), 1, Brushes.Black, Brushes.Lime);
								else
									PlaySound(AddSoundFolder(pWAV_3barBull));
							}
							SoundAlertABar = CurrentBar;
						}
					}
				}
			}
			foreach(var Pattern in UserSelectedBearishPatterns){
				p = BearFinder.Evaluate(Pattern.Key);
				if(Pattern.Value == ARC_CandleStix_BearPatterns.Doji && !BearFinder.isInUpTrend) p = -1;
				if(Pattern.Value == ARC_CandleStix_BearPatterns.Kicker  && !BearFinder.isInDownTrend) p = -1;
				if(Pattern.Value == ARC_CandleStix_BearPatterns.ThreeInside  && !BearFinder.isInDownTrend) p = -1;
				if(Pattern.Value == ARC_CandleStix_BearPatterns.ThreeOutside && !BearFinder.isInDownTrend) p = -1;
				if(p >= 0){
					new_sigs++;
					BearLocations[CurrentBars[0]] = Pattern.Value;
					patternID[0] = (int)Pattern.Value;
					Value[0] = patternID[0];
					if(pChartMarkerDirections == ARC_CandleStix_Directions.Shorts || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
						if(pShow_1barBears && patternID[0] <= 219) {
							DrawChartMarker(CurrentBars[0], DOWN, "d");
							if(SoundAlertABar!=CurrentBar && !pWAV_1barBear.Contains("SOUND OFF")){
								if(pPrintToAlertsWindow)
									Alert(DateTime.Now.ToString(), pSoundAlertPriority, "1-bar bear", AddSoundFolder(pWAV_1barBear), 1, Brushes.Black, Brushes.Magenta);
								else
									PlaySound(AddSoundFolder(pWAV_1barBear));
							}
							SoundAlertABar = CurrentBar;
						}
						if(pShow_2barBears && IsBetweenInclusive(patternID[0], 220, 229)){
							DrawChartMarker(CurrentBars[0], DOWN, "d");
							if(SoundAlertABar!=CurrentBar && !pWAV_2barBear.Contains("SOUND OFF")){
								if(pPrintToAlertsWindow)
									Alert(DateTime.Now.ToString(), pSoundAlertPriority, "2-bar bear", AddSoundFolder(pWAV_2barBear), 1, Brushes.Black, Brushes.Magenta);
								else
									PlaySound(AddSoundFolder(pWAV_2barBear));
							}
							SoundAlertABar = CurrentBar;
						}
						if(pShow_3barBears && IsBetweenInclusive(patternID[0], 230, 239)){
							DrawChartMarker(CurrentBars[0], DOWN, "d");
							if(SoundAlertABar!=CurrentBar && !pWAV_3barBear.Contains("SOUND OFF")){
								if(pPrintToAlertsWindow)
									Alert(DateTime.Now.ToString(), pSoundAlertPriority, "3-bar bear", AddSoundFolder(pWAV_3barBear), 1, Brushes.Black, Brushes.Magenta);
								else
									PlaySound(AddSoundFolder(pWAV_3barBear));
							}
							SoundAlertABar = CurrentBar;
						}
					}
				}
			}
			if(new_sigs>0) CalculateWhichSigsAreShowing();

			if(IsFirstTickOfBar && patternID[1]<0){
				int count = 0;
				if(BullLocations.ContainsKey(CurrentBars[0]-1)) {
					BullLocations.Remove(CurrentBars[0]-1);
					count++;
				}
				if(BearLocations.ContainsKey(CurrentBars[0]-1)) {
					BearLocations.Remove(CurrentBars[0]-1);
					count++;
				}
				if(count==2) {
					RemoveDrawObject(string.Format("CandleStixu_{0}",CurrentBars[0]-1));
					RemoveDrawObject(string.Format("CandleStixd_{0}",CurrentBars[0]-1));
				}
			}
			if(!patternID.IsValidDataPoint(0) || patternID[0]<0){
				if(BullLocations.ContainsKey(CurrentBars[0])) BullLocations.Remove(CurrentBars[0]);
				if(BearLocations.ContainsKey(CurrentBars[0])) BearLocations.Remove(CurrentBars[0]);
			}
			#endregion
		}
//========Plot============================================================
	protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
		#region -- OnRender --
		if (!IsVisible) return;
		if(ChartControl==null) return;
		RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
		SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
		RenderTarget.AntialiasMode          = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

		int RMaB = Math.Min(Bars.Count-1, ChartBars.ToIndex);
		int LMaB = Math.Max(2, ChartBars.FromIndex);
		if(VisibleSignals.Count==0 || RMaB != Last_RMaB || LMaB != Last_LMaB){
			Last_LMaB = LMaB;
			Last_RMaB = RMaB;
			VisibleSignals["Bull 1bar"] = BullLocations.Where(k => k.Key >=LMaB && k.Key <=RMaB && (int)k.Value <=119 && BullSigBars.Contains(k.Key)).Select(k=>k.Key).ToList();
			VisibleSignals["Bull 2bar"] = BullLocations.Where(k => k.Key >=LMaB && k.Key <=RMaB && IsBetweenInclusive((int)k.Value, 120, 129) && BullSigBars.Contains(k.Key)).Select(k=>k.Key).ToList();
			VisibleSignals["Bull 3bar"] = BullLocations.Where(k => k.Key >=LMaB && k.Key <=RMaB && IsBetweenInclusive((int)k.Value, 130, 139) && BullSigBars.Contains(k.Key)).Select(k=>k.Key).ToList();
			VisibleSignals["Bear 1bar"] = BearLocations.Where(k => k.Key >=LMaB && k.Key <=RMaB && (int)k.Value <=219 && BearSigBars.Contains(k.Key)).Select(k=>k.Key).ToList();
			VisibleSignals["Bear 2bar"] = BearLocations.Where(k => k.Key >=LMaB && k.Key <=RMaB && IsBetweenInclusive((int)k.Value, 220, 229) && BearSigBars.Contains(k.Key)).Select(k=>k.Key).ToList();
			VisibleSignals["Bear 3bar"] = BearLocations.Where(k => k.Key >=LMaB && k.Key <=RMaB && IsBetweenInclusive((int)k.Value, 230, 239) && BearSigBars.Contains(k.Key)).Select(k=>k.Key).ToList();
		}
//if(Times[0].GetValueAt(x.Key).Hour==8 && Times[0].GetValueAt(x.Key).Minute==25) Print("Pattern: "+x.Value.ToString());

		var ShowRacingStripe = pRacingStripesDirections == ARC_CandleStix_Directions.Longs || pRacingStripesDirections == ARC_CandleStix_Directions.Both;
		if(pShow_1barBulls && (pHighlightPatternBars || ShowRacingStripe || pDescriptionsEnabled)){
			foreach(var p in VisibleSignals["Bull 1bar"]){
				if(pBullishRacingStripeOpacity>0 && ShowRacingStripe)
					drawRacingStripe(
						new double[]{chartScale.MinValue, chartScale.MaxValue, chartScale.MaxValue, chartScale.MinValue}, 
						new int[]{p,p,p,p}, BullRacingStripeDXBrush, chartControl, chartScale);
				if(this.pHighlightPatternBars){
					OutlineThisCandle(p, BullBarHighlightBrushDX, chartScale);
				}
				if(pDescriptionsEnabled){
//					msgText = string.Format("Bull {0}", BullLocations[p].ToString());
					msgText = BullLocations[p].ToString();
					msgX = ChartControl.GetXByBarIndex(ChartBars, p)-5;
					msgY = chartScale.GetYByValue(Lows[0].GetValueAt(p))+10;
					int w = Convert.ToInt32(getTextWidth(msgText, pDescriptionFont));
					drawString(msgText, msgX-w, msgY, pDescriptionFont, BullTextDXBrush, BlackDXBrush, SharpDX.DirectWrite.TextAlignment.Leading, w);
					msgText = string.Empty;
				}
			}
		}
		if(pShow_2barBulls && (pHighlightPatternBars || ShowRacingStripe || pDescriptionsEnabled)){
			foreach(var p in VisibleSignals["Bull 2bar"]){
				if(pBullishRacingStripeOpacity>0 && ShowRacingStripe) 
					drawRacingStripe(
						new double[]{chartScale.MinValue, chartScale.MaxValue, chartScale.MaxValue, chartScale.MinValue}, 
						new int[]{p,p,p,p}, BullRacingStripeDXBrush, chartControl, chartScale);
				if(this.pHighlightPatternBars){
					OutlineThisCandle(p, BullBarHighlightBrushDX, chartScale);
					OutlineThisCandle(p-1, BullBarHighlightBrushDX, chartScale);
				}
				if(pDescriptionsEnabled){
//					msgText = string.Format("Bull {0}", BullLocations[p].ToString());
					msgText = BullLocations[p].ToString();
					msgX = ChartControl.GetXByBarIndex(ChartBars, p)-5;
					msgY = chartScale.GetYByValue(GetLowestPrice(p, p-1))+10;
					int w = Convert.ToInt32(getTextWidth(msgText, pDescriptionFont));
					drawString(msgText, msgX-w, msgY, pDescriptionFont, BullTextDXBrush, BlackDXBrush, SharpDX.DirectWrite.TextAlignment.Leading, w);
					msgText = string.Empty;
				}
			}
		}
		if(pShow_3barBulls && (pHighlightPatternBars || ShowRacingStripe || pDescriptionsEnabled)){
			foreach(var p in VisibleSignals["Bull 3bar"]){
//if(Times[0].GetValueAt(p).Hour==8 && Times[0].GetValueAt(p).Minute==25) Print(p+"  marker: "+p.Value.ToString());
				if(pBullishRacingStripeOpacity>0 && ShowRacingStripe) 
					drawRacingStripe(
						new double[]{chartScale.MinValue, chartScale.MaxValue, chartScale.MaxValue, chartScale.MinValue}, 
						new int[]{p,p,p,p}, BullRacingStripeDXBrush, chartControl, chartScale);
				if(this.pHighlightPatternBars){
					OutlineThisCandle(p, BullBarHighlightBrushDX, chartScale);
					OutlineThisCandle(p-1, BullBarHighlightBrushDX, chartScale);
					OutlineThisCandle(p-2, BullBarHighlightBrushDX, chartScale);
				}
				if(pDescriptionsEnabled){
//					msgText = string.Format("Bull {0}", BullLocations[p].ToString());
					msgText = BullLocations[p].ToString();
					msgX = ChartControl.GetXByBarIndex(ChartBars, p)-5;
					msgY = chartScale.GetYByValue(GetLowestPrice(p, p-1, p-2))+10;
					int w = Convert.ToInt32(getTextWidth(msgText, pDescriptionFont));
					drawString(msgText, msgX-w, msgY, pDescriptionFont, BullTextDXBrush, BlackDXBrush, SharpDX.DirectWrite.TextAlignment.Leading, w);
					msgText = string.Empty;
				}
			}
		}

		ShowRacingStripe = pRacingStripesDirections == ARC_CandleStix_Directions.Shorts || pRacingStripesDirections == ARC_CandleStix_Directions.Both;
		if(pShow_1barBears && (pHighlightPatternBars || ShowRacingStripe || pDescriptionsEnabled)){
			foreach(var p in VisibleSignals["Bear 1bar"]){
				if(pBearishRacingStripeOpacity>0 && ShowRacingStripe) 
					drawRacingStripe(
						new double[]{chartScale.MinValue, chartScale.MaxValue, chartScale.MaxValue, chartScale.MinValue}, 
						new int[]{p,p,p,p}, BearRacingStripeDXBrush, chartControl, chartScale);
				if(this.pHighlightPatternBars){
					OutlineThisCandle(p, BearBarHighlightBrushDX, chartScale);
				}
				if(pDescriptionsEnabled){
//					msgText = string.Format("Bear {0}", BearLocations[p].ToString());
					msgText = BearLocations[p].ToString();
					msgX = ChartControl.GetXByBarIndex(ChartBars, p)-5;
					msgY = chartScale.GetYByValue(Highs[0].GetValueAt(p))-Convert.ToInt32(pDescriptionFont.Size)-5;
					int w = Convert.ToInt32(getTextWidth(msgText, pDescriptionFont));
					drawString(msgText, msgX-w, msgY, pDescriptionFont, BearTextDXBrush, BlackDXBrush, SharpDX.DirectWrite.TextAlignment.Leading, w);
					msgText = string.Empty;
				}
			}
		}
		if(pShow_2barBears && (pHighlightPatternBars || ShowRacingStripe || pDescriptionsEnabled)){
			foreach(var p in VisibleSignals["Bear 2bar"]){
				if(pBearishRacingStripeOpacity>0 && ShowRacingStripe) 
					drawRacingStripe(
						new double[]{chartScale.MinValue, chartScale.MaxValue, chartScale.MaxValue, chartScale.MinValue}, 
						new int[]{p,p,p,p}, BearRacingStripeDXBrush, chartControl, chartScale);
				if(this.pHighlightPatternBars){
					OutlineThisCandle(p, BearBarHighlightBrushDX, chartScale);
					OutlineThisCandle(p-1, BearBarHighlightBrushDX, chartScale);
				}
				if(pDescriptionsEnabled){
//					msgText = string.Format("Bear {0}", BearLocations[p].ToString());
					msgText = BearLocations[p].ToString();
					msgX = ChartControl.GetXByBarIndex(ChartBars, p)-5;
					msgY = chartScale.GetYByValue(GetHighestPrice(p, p-1))-Convert.ToInt32(pDescriptionFont.Size)-5;
					int w = Convert.ToInt32(getTextWidth(msgText, pDescriptionFont));
					drawString(msgText, msgX-w, msgY, pDescriptionFont, BearTextDXBrush, BlackDXBrush, SharpDX.DirectWrite.TextAlignment.Leading, w);
					msgText = string.Empty;
				}
			}
		}
		if(pShow_3barBears && (pHighlightPatternBars || ShowRacingStripe || pDescriptionsEnabled)){
			foreach(var p in VisibleSignals["Bear 3bar"]){
				if(pBearishRacingStripeOpacity>0 && ShowRacingStripe) 
					drawRacingStripe(
						new double[]{chartScale.MinValue, chartScale.MaxValue, chartScale.MaxValue, chartScale.MinValue}, 
						new int[]{p,p,p,p}, BearRacingStripeDXBrush, chartControl, chartScale);
				if(this.pHighlightPatternBars){
					OutlineThisCandle(p, BearBarHighlightBrushDX, chartScale);
					OutlineThisCandle(p-1, BearBarHighlightBrushDX, chartScale);
					OutlineThisCandle(p-2, BearBarHighlightBrushDX, chartScale);
				}
				if(pDescriptionsEnabled){
//					msgText = string.Format("Bear {0}", BearLocations[p].ToString());
					msgText = BearLocations[p].ToString();
					msgX = ChartControl.GetXByBarIndex(ChartBars, p)-5;
					msgY = chartScale.GetYByValue(GetHighestPrice(p, p-1, p-2))-Convert.ToInt32(pDescriptionFont.Size)-5;
					int w = Convert.ToInt32(getTextWidth(msgText, pDescriptionFont));
					drawString(msgText, msgX-w, msgY, pDescriptionFont, BearTextDXBrush, BlackDXBrush, SharpDX.DirectWrite.TextAlignment.Leading, w);
					msgText = string.Empty;
				}
			}
		}

		if(!pDescriptionsEnabled && !string.IsNullOrEmpty(msgText) && !IsInHitTest) {//if the user held-down the LeftShift key, then draw text description (see OnMouseMove method)
			msgX = ChartControl.GetXByBarIndex(ChartBars, msgX)-5;
			drawString(msgText, msgX, msgY, pDescriptionFont, WhiteDXBrush, BlackDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
			msgText = string.Empty;
		}

		RenderTarget.AntialiasMode = OSM;
		#endregion
	}
//=================================================================================================================
	#region -- Misc --
	//=================================================================================================================
	private void OutlineThisCandle(int abar, SharpDX.Direct2D1.Brush brushDX, ChartScale cs){
		int offset = 4;
		if(BullLocations.ContainsKey(abar) && BullLocations[abar] == ARC_CandleStix_BullPatterns.Doji) offset = 8;
		else if(BearLocations.ContainsKey(abar) && BearLocations[abar] == ARC_CandleStix_BearPatterns.Doji) offset = 8;
		var half = (int)(ChartControl.Properties.BarDistance / 2);
		var xL = ChartControl.GetXByBarIndex(ChartBars, abar) - half-1;
		var xR = ChartControl.GetXByBarIndex(ChartBars, abar) + half+1;
		var yT = cs.GetYByValue(Math.Max(Opens[0].GetValueAt(abar), Closes[0].GetValueAt(abar)))-offset;
		var yB = cs.GetYByValue(Math.Min(Opens[0].GetValueAt(abar), Closes[0].GetValueAt(abar)))+offset;
//		RenderTarget.DrawRectangle(new SharpDX.RectangleF(xL, yT, xR-xL, yB-yT), brushDX);
		RenderTarget.FillRectangle(new SharpDX.RectangleF(xL, yT, xR-xL, yB-yT), brushDX);
	}
	//=================================================================================================================
	private double GetHighestPrice(int abar0, int abar1){
		return Math.Max(Highs[0].GetValueAt(abar0), Highs[0].GetValueAt(abar1));
	}
	private double GetHighestPrice(int abar0, int abar1, int abar2){
		return Math.Max(Highs[0].GetValueAt(abar0), Math.Max(Highs[0].GetValueAt(abar1), Highs[0].GetValueAt(abar2)));
	}
	private double GetLowestPrice(int abar0, int abar1){
		return Math.Min(Lows[0].GetValueAt(abar0), Lows[0].GetValueAt(abar1));
	}
	private double GetLowestPrice(int abar0, int abar1, int abar2){
		return Math.Min(Lows[0].GetValueAt(abar0), Math.Min(Lows[0].GetValueAt(abar1), Lows[0].GetValueAt(abar2)));
	}
	//=================================================================================================================
	private bool IsBetweenInclusive(int inval, int LowerVal, int HigherVal){
		return inval>=LowerVal && inval<=HigherVal;
	}
	private bool IsBetweenInclusive(double inval, int LowerVal, int HigherVal){
		return inval>=LowerVal && inval<=HigherVal;
	}
	#endregion
//=================================================================================================================
	public override void OnRenderTargetChanged()
	{
		#region -- OnRenderTargetChanged --
		if( BullRacingStripeDXBrush!=null && !BullRacingStripeDXBrush.IsDisposed) {BullRacingStripeDXBrush.Dispose(); BullRacingStripeDXBrush = null;}
		if( BearRacingStripeDXBrush!=null && !BearRacingStripeDXBrush.IsDisposed) {BearRacingStripeDXBrush.Dispose(); BearRacingStripeDXBrush = null;}
		if( WhiteDXBrush!=null && !WhiteDXBrush.IsDisposed) {WhiteDXBrush.Dispose(); WhiteDXBrush=null;}
		if( BlackDXBrush!=null && !BlackDXBrush.IsDisposed) {BlackDXBrush.Dispose(); BlackDXBrush=null;}
		if( BullTextDXBrush!=null && !BullTextDXBrush.IsDisposed) {BullTextDXBrush.Dispose(); BullTextDXBrush=null;}
		if( BearTextDXBrush!=null && !BearTextDXBrush.IsDisposed) {BearTextDXBrush.Dispose(); BearTextDXBrush=null;}
		if( BullBarHighlightBrushDX!= null && !BullBarHighlightBrushDX.IsDisposed) {BullBarHighlightBrushDX.Dispose(); BullBarHighlightBrushDX=null;}//pBullBarHighlightBrush
		if( BearBarHighlightBrushDX!= null && !BearBarHighlightBrushDX.IsDisposed) {BearBarHighlightBrushDX.Dispose(); BearBarHighlightBrushDX=null;}//

		if(RenderTarget!=null){
			BullRacingStripeDXBrush = pBullishRacingStripeBrush.ToDxBrush(RenderTarget);
			BullRacingStripeDXBrush.Opacity = pBullishRacingStripeOpacity/100f;
		}
		if(RenderTarget!=null){
			BearRacingStripeDXBrush = pBearishRacingStripeBrush.ToDxBrush(RenderTarget);
			BearRacingStripeDXBrush.Opacity = pBearishRacingStripeOpacity/100f;
		}
		if(RenderTarget!=null)
			WhiteDXBrush = Brushes.White.ToDxBrush(RenderTarget);
		if(RenderTarget!=null)
			BlackDXBrush = Brushes.Black.ToDxBrush(RenderTarget);
		if(RenderTarget !=null)
			BullTextDXBrush = pBullTextBrush.ToDxBrush(RenderTarget);
		if(RenderTarget !=null)
			BearTextDXBrush = pBearTextBrush.ToDxBrush(RenderTarget);
		if(RenderTarget!=null){
			BullBarHighlightBrushDX = pBullBarHighlightBrush.ToDxBrush(RenderTarget);
			BullBarHighlightBrushDX.Opacity = pBullBarHighlightOpacity/100f;
		}
		if(RenderTarget!=null){
			BearBarHighlightBrushDX = pBearBarHighlightBrush.ToDxBrush(RenderTarget);
			BearBarHighlightBrushDX.Opacity = pBearBarHighlightOpacity/100f;
		}

		#endregion
	}
//=================================================================================================================
	private void CalculateWhichSigsAreShowing(){
		#region -- CalculateWhichSigsAreShowing --
		BullSigBars = new List<int>();
		BearSigBars = new List<int>();
		if(pRacingStripesDirections == ARC_CandleStix_Directions.Longs || pRacingStripesDirections == ARC_CandleStix_Directions.Both ||
			pChartMarkerDirections == ARC_CandleStix_Directions.Longs || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
			foreach(var x in BullLocations){
//Print(x.Value.ToString());
				if(pShow_1barBulls && (int)x.Value<=119) BullSigBars.Add(x.Key);
				if(pShow_2barBulls && IsBetweenInclusive((int)x.Value, 120, 129)) BullSigBars.Add(x.Key);
				if(pShow_3barBulls && IsBetweenInclusive((int)x.Value, 130, 139)) BullSigBars.Add(x.Key);
			}
		}
//Print("BullSigBars.Count: "+BullSigBars.Count);
		if(pRacingStripesDirections == ARC_CandleStix_Directions.Shorts || pRacingStripesDirections == ARC_CandleStix_Directions.Both ||
			pChartMarkerDirections == ARC_CandleStix_Directions.Shorts || pChartMarkerDirections == ARC_CandleStix_Directions.Both){
			foreach(var x in BearLocations){
				if(pShow_1barBears && (int)x.Value<=219) BearSigBars.Add(x.Key);
				if(pShow_2barBears && IsBetweenInclusive((int)x.Value, 220, 229)) BearSigBars.Add(x.Key);
				if(pShow_3barBears && IsBetweenInclusive((int)x.Value, 230, 239)) BearSigBars.Add(x.Key);
			}
		}
		#endregion
	}
//==========================================================================================================================================
	#region -- drawString --
		private float getTextWidth(string text, Gui.Tools.SimpleFont font)
		{
		    var textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        Convert.ToSingle(font.Size)
		        );
		    var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

		    float textwidth = textLayout.Metrics.Width;

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return textwidth;
		}
		private void drawString(string text, int x, int y, Gui.Tools.SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.Direct2D1.Brush fillDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, int width = 0)
		{
		    if (x < 0 || y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
		    var textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        Convert.ToSingle(font.Size)
		        ){
					TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap 
				};
			if(fillDXBrush != null){
				RenderTarget.FillRectangle(new SharpDX.RectangleF(x, y, width, Convert.ToSingle(font.Size)), fillDXBrush);
			}
			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0 ? getTextWidth(text, font) : width, float.MaxValue);
			RenderTarget.DrawTextLayout(new SharpDX.Vector2(x,y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

		    textLayout.Dispose();
		    textFormat.Dispose();
		}
		#endregion

	#region -- drawRegion --
		private void drawRegion(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
		{
			SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

			SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
			SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
			sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
			sink1.AddLines(vectors);
			sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink1.Close();

			RenderTarget.FillGeometry(geo1, dxbrush);
			geo1.Dispose();
			sink1.Dispose();
		}
		private void drawRacingStripe(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false, bool atMiddle = false)
		{
			if(dxbrush==null) return;
			var half = (int)(chartControl.Properties.BarDistance / 2);
			drawRegion(new Point[]{
				new Point(GetX0(xIndex[0],   chartControl, atMiddle)-half, drawOnPricePanel?0:chartScale.GetYByValue(yValues[0])),
				new Point(GetX0(xIndex[1],   chartControl, atMiddle)-half, drawOnPricePanel?0:chartScale.GetYByValue(yValues[1])),
				new Point(GetX0(xIndex[2]+1, chartControl, atMiddle)-half-1, drawOnPricePanel?0:chartScale.GetYByValue(yValues[2])),
				new Point(GetX0(xIndex[3]+1, chartControl, atMiddle)-half-1, drawOnPricePanel?0:chartScale.GetYByValue(yValues[3]))
				},
				dxbrush
			);
		}
		private int GetX0(int bars, ChartControl chartControl, bool atMiddle = false) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars) - (atMiddle ? (int)(chartControl.Properties.BarDistance / 2) : 0); }
		#endregion

		internal class LoadDrawingTemplates : StringConverter
		{
			#region LoadDrawingTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				var list = new List<string>();//new string[filCustom.Length+1];
				var types = new List<string>(){"Dot","ArrowUp","ArrowDown","Diamond","TriangleUp","TriangleDown","Square"};
				foreach(var type in types){
					string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool",type};
					try{
						dirCustom = new System.IO.DirectoryInfo(System.IO.Path.Combine(paths));
						filCustom = dirCustom.GetFiles( search);
					}catch{}

					if(list.Count==0) list.Add("Default");
					if(filCustom!=null){
						foreach (System.IO.FileInfo fi in filCustom)
						{
							string name = fi.Name.Replace(".xml",string.Empty);
							if(name=="Default") continue;
							name = type+"> "+name;
							if(!list.Contains(name)){
								list.Add(name);
							}
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
//====================================================================================================
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}

		#region -- Properties ------------------------------------
		internal class LoadFileList : StringConverter
		{
			#region LoadFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new System.Collections.Generic.List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}

		#region -- Bullish Patterns --
		[NinjaScriptProperty]
		[XmlIgnore]
		[RefreshProperties(RefreshProperties.All)] // Needed to refresh the property grid when the value changes
		[Display(Order = 5, Name = "Enable All", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_All
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[RefreshProperties(RefreshProperties.All)] // Needed to refresh the property grid when the value changes
		[Display(Order = 6, Name = "Disable All", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_None
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 10, Name = "Show Hammer", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_Hammer
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 20, Name = "Show InvertedHammer", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_InvertedHammer
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 30, Name = "Show Doji", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_Doji
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 40, Name = "Show Kicker", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_Kicker
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 50, Name = "Show Engulfing", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_Engulfing
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 60, Name = "Show Harami", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_Harami
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 70, Name = "Show PiercingLine", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_PiercingLine
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 80, Name = "Show MorningStar", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_MorningStar
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 90, Name = "Show ThreeWhiteSoldiers", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_ThreeWhiteSoldiers
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 100, Name = "Show ThreeLineStrike", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_ThreeLineStrike
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 110, Name = "Show ThreeOutside", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_ThreeOutside
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 120, Name = "Show ThreeInside", Description = "", GroupName = "Bullish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBullPat_ThreeInside
		{ get; set; }
		#endregion -----------------------------------

		#region -- Bearish Patterns --
		[NinjaScriptProperty]
		[XmlIgnore]
		[RefreshProperties(RefreshProperties.All)] // Needed to refresh the property grid when the value changes
		[Display(Order = 5, Name = "Enable All", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_All
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[RefreshProperties(RefreshProperties.All)] // Needed to refresh the property grid when the value changes
		[Display(Order = 6, Name = "Disable All", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_None
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 10, Name = "Show HangingMan", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_HangingMan
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 20, Name = "Show ShootingStar", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_ShootingStar
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 30, Name = "Show Doji", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_Doji
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 40, Name = "Show Kicker", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_Kicker
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 50, Name = "Show Engulfing", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_Engulfing
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 60, Name = "Show Harami", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_Harami
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 70, Name = "Show DarkCloudCover", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_DarkCloudCover
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 80, Name = "Show EveningStar", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_EveningStar
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 90, Name = "Show ThreeBlackCrows", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_ThreeBlackCrows
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 100, Name = "Show ThreeLineStrike", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_ThreeLineStrike
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 110, Name = "Show ThreeOutside", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_ThreeOutside
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 120, Name = "Show ThreeInside", Description = "", GroupName = "Bearish Patterns", ResourceType = typeof(Custom.Resource))]
		public bool pBearPat_ThreeInside
		{ get; set; }
		#endregion -----------------------------------

		#region -- Filters --
//		[Display(Order = 10, Name = "Enable bullish?", Description = "", GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
//		public bool pShow_Bulls {get;set;}

		[Display(Order = 20, Name = "Show 1-bar Bullish patterns?", Description = "", GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public bool pShow_1barBulls {get;set;}

		[Display(Order = 30, Name = "Show 2-bar Bullish patterns?", Description = "", GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public bool pShow_2barBulls {get;set;}

		[Display(Order = 40, Name = "Show 3-bar Bullish patterns?", Description = "", GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public bool pShow_3barBulls {get;set;}

//		[Display(Order = 50, Name = "Enable bearish?", Description = "", GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
//		public bool pShow_Bears {get;set;}

		[Display(Order = 60, Name = "Show 1-bar Bearish patterns?", Description = "", GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public bool pShow_1barBears {get;set;}

		[Display(Order = 70, Name = "Show 2-bar Bearish patterns?", Description = "", GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public bool pShow_2barBears {get;set;}

		[Display(Order = 80, Name = "Show 3-bar Bearish patterns?", Description = "", GroupName = "Filters", ResourceType = typeof(Custom.Resource))]
		public bool pShow_3barBears {get;set;}
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Trend Strength", Description = "Number of bars required to define a trend when a pattern requires a prevailing trend. \nA value of zero will disable trend requirement.",
		GroupName = "Filters", Order = 90)]
		public int TrendStrength { get; set; }

		#endregion

		#region -- Racing Stripes --
		[Display(Order = 5, Name = "RacingStripes", Description = "", GroupName = "Racing Stripes", ResourceType = typeof(Custom.Resource))]
		public ARC_CandleStix_Directions pRacingStripesDirections {get;set;}

		[Display(Order = 10, Name = "Bullish RacingStripe Opacity", Description = "0=transparent, 100=opaque", GroupName = "Racing Stripes", ResourceType = typeof(Custom.Resource))]
		public int pBullishRacingStripeOpacity
		{ get; set; }

		[XmlIgnore]
		[Display(Order = 20, Name = "Bullish RacingStripe", GroupName = "Racing Stripes")]
		public Brush pBullishRacingStripeBrush
		{ get; set; }
				[Browsable(false)]
				public string BullishRacingStripeBrushSerializable { get { return Serialize.BrushToString(pBullishRacingStripeBrush); } set { pBullishRacingStripeBrush = Serialize.StringToBrush(value); }        }

		[Display(Order = 30, Name = "Bearish RacingStripe Opacity", Description = "0=transparent, 100=opaque", GroupName = "Racing Stripes", ResourceType = typeof(Custom.Resource))]
		public int pBearishRacingStripeOpacity
		{ get; set; }

		[XmlIgnore]
		[Display(Order = 40, Name = "Bearish RacingStripe", GroupName = "Racing Stripes")]
		public Brush pBearishRacingStripeBrush
		{ get; set; }
				[Browsable(false)]
				public string BearishRacingStripeBrushSerializable { get { return Serialize.BrushToString(pBearishRacingStripeBrush); } set { pBearishRacingStripeBrush = Serialize.StringToBrush(value); }        }

		#endregion

		#region -- ChartMarker Signals --
		[Display(Name = "ChartMarkers", GroupName = "ChartMarker Signals", Description = "", Order = 5)]
		public ARC_CandleStix_Directions pChartMarkerDirections {get;set;}

		private bool pGlobalizeMarkers = false;
		[RefreshProperties(RefreshProperties.All)]
        [Display(Order = 10, Name = "Globalize Markers", GroupName = "ChartMarker Signals", Description = "Send marker long/short dots to all charts?")]
		public bool GlobalizeMarkers
		{
			get { return pGlobalizeMarkers; }
			set { pGlobalizeMarkers = value; }
		}

		[Display(Name = "Up ChartMarker Type", GroupName = "ChartMarker Signals", Description = "", Order = 20)]
		public ARC_CandleStix_ChartMarkers pBuyChartMarkers { get; set; }

		[XmlIgnore]
		[Display(Order = 30, Name = "Up Color", GroupName = "ChartMarker Signals", Description = "")]
		public Brush pLongChartMarkerBrush {get;set;}
			[Browsable(false)]
			public string pLongChartMarkerBrushSerialize	{get { return Serialize.BrushToString(pLongChartMarkerBrush); }set { pLongChartMarkerBrush = Serialize.StringToBrush(value); }}

		[Display(Order = 40, Name = "Down ChartMarker Type", GroupName = "ChartMarker Signals", Description = "")]
		public ARC_CandleStix_ChartMarkers pSellChartMarkers { get; set; }

		[XmlIgnore]
		[Display(Order = 50, Name = "Down Color", GroupName = "ChartMarker Signals", Description = "")]
		public Brush pShortChartMarkerBrush {get;set;}
			[Browsable(false)]
			public string pShortChartMarkerBrushSerialize	{get { return Serialize.BrushToString(pShortChartMarkerBrush); }set { pShortChartMarkerBrush = Serialize.StringToBrush(value); }}

		private string pLongMarker_Template = "Default";
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadDrawingTemplates))]
        [Display(Order = 30, Name = "Up Marker Template", GroupName = "ChartMarker Signals", Description = "Drawing template for globalized LONG signal")]
		public string LongMarker_Template
		{
			get { return pLongMarker_Template; }
			set { pLongMarker_Template = value; }
		}

		private string pShortMarker_Template = "Default";
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadDrawingTemplates))]
        [Display(Order = 50, Name = "Down Marker Template", GroupName = "ChartMarker Signals", Description = "Drawing template for globalized SHORT signal")]
		public string ShortMarker_Template
		{
			get { return pShortMarker_Template; }
			set { pShortMarker_Template = value; }
		}

		[Display(Order = 80, Name = "Separation Ticks", GroupName = "ChartMarker Signals", Description = "Distance between marker and price bar")]
		public int pMarkerTicks {get;set;}
		#endregion

		#region -- Highlight Pattern Bars -- 
		[Display(Name = "Enable", GroupName = "Highlight Pattern Bars", Description = "", Order = 10)]
		public bool pHighlightPatternBars {get;set;}

		[XmlIgnore]
		[Display(Name = "Bullish Color", GroupName = "Highlight Pattern Bars", Description = "", Order = 20)]
		public Brush pBullBarHighlightBrush {get;set;}
			[Browsable(false)]
			public string pBullBarHighlightBrushSerialize	{get { return Serialize.BrushToString(pBullBarHighlightBrush); }set { pBullBarHighlightBrush = Serialize.StringToBrush(value); }}

		[Display(Name = "Bullish Opacity", GroupName = "Highlight Pattern Bars", Description = "", Order = 30)]
		public int pBullBarHighlightOpacity {get;set;}

		[XmlIgnore]
		[Display(Name = "Bearish Color", GroupName = "Highlight Pattern Bars", Description = "", Order = 40)]
		public Brush pBearBarHighlightBrush {get;set;}
			[Browsable(false)]
			public string pBearBarHighlightBrushSerialize	{get { return Serialize.BrushToString(pBearBarHighlightBrush); }set { pBearBarHighlightBrush = Serialize.StringToBrush(value); }}

		[Display(Name = "Bearish Opacity", GroupName = "Highlight Pattern Bars", Description = "", Order = 50)]
		public int pBearBarHighlightOpacity {get;set;}

		#endregion

		#region -- Pattern Description Text --
		[Display(Name = "Display Descriptions?", GroupName = "Pattern Description Text", Description = "", Order = 10)]
		public bool pDescriptionsEnabled {get;set;}

		[Display(Name = "Text font", GroupName = "Pattern Description Text", Description = "", Order = 20)]
		public Gui.Tools.SimpleFont pDescriptionFont {get;set;}

		[XmlIgnore]
		[Display(Name = "Bullish Text Color", GroupName = "Pattern Description Text", Description = "", Order = 30)]
		public Brush pBullTextBrush {get;set;}
			[Browsable(false)]
			public string pBullTextBrushSerialize	{get { return Serialize.BrushToString(pBullTextBrush); }set { pBullTextBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Bearish Text Color", GroupName = "Pattern Description Text", Description = "", Order = 40)]
		public Brush pBearTextBrush {get;set;}
			[Browsable(false)]
			public string pBearTextBrushSerialize	{get { return Serialize.BrushToString(pBearTextBrush); }set { pBearTextBrush = Serialize.StringToBrush(value); }}
		//==================================================================================================================================================

//		[Display(Order = 2, Name = "Send Alerts", Description = "Set true to send alert message to Alerts window", GroupName = "NinjaScriptGeneral", ResourceType = typeof(Custom.Resource))]
//		public bool ShowAlerts { get; set; }

//		[Display(ResourceType = typeof(Custom.Resource), Name = "ShowPatternCount", Description = "Set true to display on chart the count of patterns found", GroupName = "NinjaScriptGeneral", Order = 3)]
//		public bool ShowPatternCount
//		{ get; set; }

//		[Display(ResourceType = typeof(Custom.Resource), Name = "TextFont", Description = "select font, style, size to display on chart", GroupName = "NinjaScriptGeneral", Order = 4)]
//		public Gui.Tools.SimpleFont TextFont
//		{ get; set; }
		#endregion

		#region -- Audible Alerts --
		private bool pPrintToAlertsWindow = false;
		private NinjaTrader.NinjaScript.Priority pSoundAlertPriority = NinjaTrader.NinjaScript.Priority.High;
		private string pWAV_1barBull = "SOUND OFF";
		private string pWAV_2barBull = "SOUND OFF";
		private string pWAV_3barBull = "SOUND OFF";
		private string pWAV_1barBear = "SOUND OFF";
		private string pWAV_2barBear = "SOUND OFF";
		private string pWAV_3barBear = "SOUND OFF";

		[Display(Name = "Print to Alerts window?", GroupName = "Audible Alerts", Description = "", Order = 10)]
		public bool PrintToAlertsWindow {
			get {return pPrintToAlertsWindow;}
			set{ pPrintToAlertsWindow = value;}
		}
		[Display(Name = "Alerts window Priority", GroupName = "Audible Alerts", Description = "If you print to the Alerts window, what priorty are the messages?", Order = 11)]
		public NinjaTrader.NinjaScript.Priority SoundAlertPriority{
			get {return pSoundAlertPriority;}
			set{ pSoundAlertPriority = value;}
		}

		[Description("Default WAV file to be played when 1-bar Bull signal appears")]
		[Display(Name = "WAV 1-bar Bull", GroupName = "Audible Alerts", Order = 20)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		public string WAV_1barBull
		{
			get { return pWAV_1barBull; }
			set { pWAV_1barBull = value; 
			}
		}
		[Description("Default WAV file to be played when 2-bar Bull signal appears")]
		[Display(Name = "WAV 2-bar Bull", GroupName = "Audible Alerts", Order = 21)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		public string WAV_2barBull
		{
			get { return pWAV_2barBull; }
			set { pWAV_2barBull = value; 
			}
		}
		[Description("Default WAV file to be played when 3-bar Bull signal appears")]
		[Display(Name = "WAV 3-bar Bull", GroupName = "Audible Alerts", Order = 22)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		public string WAV_3barBull
		{
			get { return pWAV_3barBull; }
			set { pWAV_3barBull = value; 
			}
		}

		[Description("Default WAV file to be played when 1-bar Bear signal appears")]
		[Display(Name = "WAV 1-bar Bear", GroupName = "Audible Alerts", Order = 30)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		public string WAV_1barBear
		{
			get { return pWAV_1barBear; }
			set { pWAV_1barBear = value; 
			}
		}
		[Description("Default WAV file to be played when 2-bar Bear signal appears")]
		[Display(Name = "WAV 2-bar Bear", GroupName = "Audible Alerts", Order = 31)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		public string WAV_2barBear
		{
			get { return pWAV_2barBear; }
			set { pWAV_2barBear = value; 
			}
		}
		[Description("Default WAV file to be played when 3-bar Bear signal appears")]
		[Display(Name = "WAV 3-bar Bear", GroupName = "Audible Alerts", Order = 32)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		public string WAV_3barBear
		{
			get { return pWAV_3barBear; }
			set { pWAV_3barBear = value; 
			}
		}

		#endregion

		[Display(Name = "Button Text", GroupName = "Indicator Display", Description = "", Order = 20)]
		public string pButtonText {get;set;}

		#endregion
	}

	//=================================================================================================================
	//=================================================================================================================
	public class ARC_CandleStix_CandleStickPatternLogic
	{
		#region -- Logic --
		public		bool				isInDownTrend;
		public		bool				isInUpTrend;
		private		MAX					max;
		private		MIN					min;
		private		NinjaScriptBase		ninjaScript;
		private		bool[]				prior = new bool[2];		// Check if there was any pattern in the last 2 bars. Ignore a match in case.
		private		Swing				swing;
		private		int					trendStrength;

	//=================================================================================================================
		public ARC_CandleStix_CandleStickPatternLogic(NinjaScriptBase ninjaScript, int trendStrength)
		{
			this.ninjaScript	= ninjaScript;
			this.trendStrength	= trendStrength;
		}
	//=================================================================================================================
		public int Evaluate(ARC_CandleStix_Patterns pattern)
		{
			if (ninjaScript.CurrentBar < trendStrength || ninjaScript.CurrentBar < 2)
				return -1;

			#region SetState
			if (max == null && trendStrength > 0 && (pattern == ARC_CandleStix_Patterns.HangingMan || pattern == ARC_CandleStix_Patterns.InvertedHammer))
			{
				max = new Indicators.MAX();
				max.Period = trendStrength;
				try 
				{
					max.SetState(State.Configure);
				}
				catch (Exception exp)
				{
					Cbi.Log.Process(typeof(Resource), "CbiUnableToCreateInstance2", new object[] { max.Name, exp.InnerException != null ? exp.InnerException.ToString() : exp.ToString() }, Cbi.LogLevel.Error, Cbi.LogCategories.Default);
					max.SetState(State.Finalized);
				}

				max.Parent = ninjaScript;
				max.SetInput(ninjaScript.High);

				lock (ninjaScript.NinjaScripts)
					ninjaScript.NinjaScripts.Add(max);

				try
				{
					max.SetState(ninjaScript.State);
				}
				catch (Exception exp)
				{
					Cbi.Log.Process(typeof(Resource), "CbiUnableToCreateInstance2", new object[] { max.Name, exp.InnerException != null ? exp.InnerException.ToString() : exp.ToString() }, Cbi.LogLevel.Error, Cbi.LogCategories.Default);
					max.SetState(State.Finalized);
					return -1;
				}
			}

			if (min == null && trendStrength > 0 && pattern == ARC_CandleStix_Patterns.Hammer)
			{
				min = new MIN();
				min.Period = trendStrength;
				try 
				{
					min.SetState(State.Configure);
				}
				catch (Exception exp)
				{
					Cbi.Log.Process(typeof(Resource), "CbiUnableToCreateInstance2", new object[] { min.Name, exp.InnerException != null ? exp.InnerException.ToString() : exp.ToString() }, Cbi.LogLevel.Error, Cbi.LogCategories.Default);
					min.SetState(State.Finalized);
				}

				min.Parent = ninjaScript;
				min.SetInput(ninjaScript.Low);

				lock (ninjaScript.NinjaScripts)
					ninjaScript.NinjaScripts.Add(min);

				try
				{
					min.SetState(ninjaScript.State);
				}
				catch (Exception exp)
				{
					Cbi.Log.Process(typeof(Resource), "CbiUnableToCreateInstance2", new object[] { min.Name, exp.InnerException != null ? exp.InnerException.ToString() : exp.ToString() }, Cbi.LogLevel.Error, Cbi.LogCategories.Default);
					min.SetState(State.Finalized);
					return -1;
				}
			}
			#endregion

			#region -- calculate Swing value -----------------
			if (pattern != ARC_CandleStix_Patterns.DownsideTasukiGap
					&& pattern != ARC_CandleStix_Patterns.EveningStar
					&& pattern != ARC_CandleStix_Patterns.FallingThreeMethods
					&& pattern != ARC_CandleStix_Patterns.MorningStar
					&& pattern != ARC_CandleStix_Patterns.RisingThreeMethods
					&& pattern != ARC_CandleStix_Patterns.ThreeInside
					&& pattern != ARC_CandleStix_Patterns.ThreeOutside
					&& pattern != ARC_CandleStix_Patterns.Kicker
					&& pattern != ARC_CandleStix_Patterns.StickSandwich
					&& pattern != ARC_CandleStix_Patterns.UpsideTasukiGap)
            {
                if (trendStrength == 0)
                {
                    isInDownTrend = true;
                    isInUpTrend = true;
                }
                else
                {
					#region init Swing indicator
                    if (swing == null)
                    {
                        swing = new Swing();
                        swing.Strength = trendStrength;
                        try
                        {
                            swing.SetState(State.Configure);
                        }
                        catch (Exception exp)
                        {
                            Cbi.Log.Process(typeof(Resource), "CbiUnableToCreateInstance2", new object[] { swing.Name, exp.InnerException != null ? exp.InnerException.ToString() : exp.ToString() }, Cbi.LogLevel.Error, Cbi.LogCategories.Default);
                            swing.SetState(State.Finalized);
                        }

                        swing.Parent = ninjaScript;
                        swing.SetInput(ninjaScript.Input);

                        lock (ninjaScript.NinjaScripts)
                            ninjaScript.NinjaScripts.Add(swing);

                        try
                        {
                            swing.SetState(ninjaScript.State);
                        }
                        catch (Exception exp)
                        {
                            Cbi.Log.Process(typeof(Resource), "CbiUnableToCreateInstance2", new object[] { swing.Name, exp.InnerException != null ? exp.InnerException.ToString() : exp.ToString() }, Cbi.LogLevel.Error, Cbi.LogCategories.Default);
                            swing.SetState(State.Finalized);
                            return -1;
                        }
                    }
					#endregion

                    // Calculate up trend line
                    int upTrendStartBarsAgo = 0;
                    int upTrendEndBarsAgo = 0;
                    int upTrendOccurence = 1;

                    while (ninjaScript.Low[upTrendEndBarsAgo] <= ninjaScript.Low[upTrendStartBarsAgo])
                    {
                        upTrendStartBarsAgo = swing.SwingLowBar(0, upTrendOccurence + 1, ninjaScript.CurrentBar);
                        upTrendEndBarsAgo = swing.SwingLowBar(0, upTrendOccurence, ninjaScript.CurrentBar);

                        if (upTrendStartBarsAgo < 0 || upTrendEndBarsAgo < 0)
                            break;

                        upTrendOccurence++;
                    }

                    // Calculate down trend line
                    int downTrendStartBarsAgo = 0;
                    int downTrendEndBarsAgo = 0;
                    int downTrendOccurence = 1;

                    while (ninjaScript.High[downTrendEndBarsAgo] >= ninjaScript.High[downTrendStartBarsAgo])
                    {

                        downTrendStartBarsAgo = swing.SwingHighBar(0, downTrendOccurence + 1, ninjaScript.CurrentBar);
                        downTrendEndBarsAgo = swing.SwingHighBar(0, downTrendOccurence, ninjaScript.CurrentBar);

                        if (downTrendStartBarsAgo < 0 || downTrendEndBarsAgo < 0)
                            break;

                        downTrendOccurence++;
                    }

                    if (upTrendStartBarsAgo > 0 && upTrendEndBarsAgo > 0 && upTrendStartBarsAgo < downTrendStartBarsAgo)
                    {
                        isInDownTrend = false;
                        isInUpTrend = true;
                    }
                    else if (downTrendStartBarsAgo > 0 && downTrendEndBarsAgo > 0 && upTrendStartBarsAgo > downTrendStartBarsAgo)
                    {
                        isInDownTrend = true;
                        isInUpTrend = false;
                    }
                    else
                    {
                        isInDownTrend = false;
                        isInUpTrend = false;
                    }
                }
            }
			#endregion

            int    found	= -1;
			NinjaScriptBase n		= ninjaScript;
			if (!prior[0] && !prior[1])				// no pattern found on the last 2 bars
				switch (pattern)
				{
					case ARC_CandleStix_Patterns.BearishBeltHold:	found = (isInUpTrend && n.Close[1] > n.Open[1] && n.Open[0] > n.Close[1] + 5 * n.TickSize && n.Open[0] == n.High[0] && n.Close[0] < n.Open[0]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.BearishEngulfing:	found = (isInUpTrend && n.Close[1] > n.Open[1] && n.Close[0] < n.Open[0] && n.Open[0] > n.Close[1] && n.Close[0] < n.Open[1]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.BearishHarami:		found = (isInUpTrend && n.Close[0] < n.Open[0] && n.Close[1] > n.Open[1] && n.Low[0] >= n.Open[1] && n.High[0] <= n.Close[1]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.BearishHaramiCross:	found = (isInUpTrend && (n.High[0] <= n.Close[1]) && (n.Low[0] >= n.Open[1]) && n.Open[0] <= n.Close[1] && n.Close[0] >= n.Open[1]
																	&& ((n.Close[0] >= n.Open[0] && n.Close[0] <= n.Open[0] + n.TickSize) || (n.Close[0] <= n.Open[0] && n.Close[0] >= n.Open[0] - n.TickSize))) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.BullishBeltHold:	found = (isInDownTrend && n.Close[1] < n.Open[1] && n.Open[0] < n.Close[1] - 5 * n.TickSize && n.Open[0] == n.Low[0] && n.Close[0] > n.Open[0]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.BullishEngulfing:	found = (isInDownTrend && n.Close[1] < n.Open[1] && n.Close[0] > n.Open[0] && n.Close[0] > n.Open[1] && n.Open[0] < n.Close[1]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.BullishHarami:		found = (isInDownTrend && n.Close[0] > n.Open[0] && n.Close[1] < n.Open[1] && n.Low[0] >= n.Close[1] && n.High[0] <= n.Open[1]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.BullishHaramiCross:	found = (isInDownTrend && (n.High[0] <= n.Open[1]) && (n.Low[0] >= n.Close[1]) && n.Open[0] >= n.Close[1] && n.Close[0] <= n.Open[1]
																	&& ((n.Close[0] >= n.Open[0] && n.Close[0] <= n.Open[0] + n.TickSize) || (n.Close[0] <= n.Open[0] && n.Close[0] >= n.Open[0] - n.TickSize))) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.DarkCloudCover:		found = (isInUpTrend && n.Open[0] > n.High[1] && n.Close[1] > n.Open[1] && n.Close[0] < n.Open[0] && n.Close[0] <= n.Close[1] - (n.Close[1] - n.Open[1]) / 2 && n.Close[0] >= n.Open[1]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.Doji:				found = (Math.Abs(n.Close[0] - n.Open[0]) <= (n.High[0] - n.Low[0]) * 0.07) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.DownsideTasukiGap:	found = (n.Close[2] < n.Open[2] && n.Close[1] < n.Open[1] && n.Close[0] > n.Open[0] && n.High[1] < n.Low[2]
																	&& n.Open[0] > n.Close[1] && n.Open[0] < n.Open[1] && n.Close[0] > n.Open[1] && n.Close[0] < n.Close[2]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.Kicker:
						if(n.Close[1] < n.Open[1] && n.Close[1] < n.Low[0]  && n.Open[0] >= (n.High[1]+n.Low[1])/2) {isInUpTrend = true;   isInDownTrend = false; found = (int)ARC_CandleStix_Patterns.Kicker;}
						if(n.Close[1] > n.Open[1] && n.Close[1] > n.High[0] && n.Open[0] <= (n.High[1]+n.Low[1])/2) {isInDownTrend = true; isInUpTrend = false;   found = (int)ARC_CandleStix_Patterns.Kicker;}
						break;

					case ARC_CandleStix_Patterns.ThreeInside:
						if(n.Close[2] < n.Open[2] && (n.High[1] < n.High[2] && n.Low[1] > n.Low[2]) && n.Close[0] > Math.Max(n.High[1],n.High[2])) {isInUpTrend = true;   isInDownTrend = false; found = (int)pattern;}
						if(n.Close[2] > n.Open[2] && (n.High[1] < n.High[2] && n.Low[1] > n.Low[2]) && n.Close[0] < Math.Min(n.Low[1],n.Low[2]))   {isInDownTrend = true; isInUpTrend = false;   found = (int)pattern;}
						break;

					case ARC_CandleStix_Patterns.ThreeOutside:				
						if(n.Close[2] < n.Open[2] && (n.High[1] > n.High[2] && n.Low[1] < n.Low[2]) && n.Close[0] > Math.Max(n.High[1],n.High[2])) {isInUpTrend = true;   isInDownTrend = false; found = (int)pattern;}
						if(n.Close[2] > n.Open[2] && (n.High[1] > n.High[2] && n.Low[1] < n.Low[2]) && n.Close[0] < Math.Min(n.Low[1],n.Low[2]))   {isInDownTrend = true; isInUpTrend = false;   found = (int)pattern;}
						break;

					case ARC_CandleStix_Patterns.EveningStar:		found = (n.Close[2] > n.Open[2] && n.Close[1] > n.Close[2] && n.Open[0] < (Math.Abs((n.Close[1] - n.Open[1]) / 2) + n.Open[1]) && n.Close[0] < n.Open[0]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.FallingThreeMethods:	found = (n.CurrentBar > 5 && n.Close[4] < n.Open[4] && n.Close[0] < n.Open[0] && n.Close[0] < n.Low[4] && n.High[3] < n.High[4] && n.Low[3] > n.Low[4]
																	&& n.High[2] < n.High[4] && n.Low[2] > n.Low[4] && n.High[1] < n.High[4] && n.Low[1] > n.Low[4]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.Hammer:				found = (isInDownTrend && (min == null ? true : min[0] == n.Low[0]) && n.Low[0] < n.Open[0] - 5 * n.TickSize 
																	&& Math.Abs(n.Open[0] - n.Close[0]) < (0.10 * (n.High[0] - n.Low[0])) && (n.High[0] - n.Close[0]) < (0.25 * (n.High[0] - n.Low[0]))) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.HangingMan:			found = (isInUpTrend && (max == null ? true : max[0] == n.High[0]) && n.Low[0] < n.Open[0] - 5 * n.TickSize 
																	&& Math.Abs(n.Open[0] - n.Close[0]) < (0.10 * (n.High[0] - n.Low[0])) && (n.High[0] - n.Close[0]) < (0.25 * (n.High[0] - n.Low[0]))) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.InvertedHammer:		found = (isInUpTrend && (max == null ? true : max[0] == n.High[0]) && n.High[0] > n.Open[0] + 5 * n.TickSize 
																	&& Math.Abs(n.Open[0] - n.Close[0]) < (0.10 * (n.High[0] - n.Low[0])) && (n.Close[0] - n.Low[0]) < (0.25 * (n.High[0] - n.Low[0]))) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.MorningStar:		found = (n.Close[2] < n.Open[2] && n.Close[1] < n.Close[2] && n.Open[0] > (Math.Abs((n.Close[1] - n.Open[1]) / 2) + n.Open[1]) && n.Close[0] > n.Open[0]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.PiercingLine:		found = (isInDownTrend && n.Open[0] < n.Low[1] && n.Close[1] < n.Open[1] && n.Close[0] > n.Open[0] && n.Close[0] >= n.Close[1] + (n.Open[1] - n.Close[1]) / 2 && n.Close[0] <= n.Open[1]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.RisingThreeMethods:	found = (n.CurrentBar > 5 && n.Close[4] > n.Open[4] && n.Close[0] > n.Open[0] && n.Close[0] > n.High[4] && n.High[3] < n.High[4] && n.Low[3] > n.Low[4]
																	&& n.High[2] < n.High[4] && n.Low[2] > n.Low[4] && n.High[1] < n.High[4] && n.Low[1] > n.Low[4]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.ShootingStar:		found = (isInUpTrend && n.High[0] > n.Open[0] && (n.High[0] - n.Open[0]) >= 2 * (n.Open[0] - n.Close[0]) && n.Close[0] < n.Open[0] && (n.Close[0] - n.Low[0]) <= 2 * n.TickSize) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.StickSandwich:		found = (n.Close[2] == n.Close[0] && n.Close[2] < n.Open[2] && n.Close[1] > n.Open[1] && n.Close[0] < n.Open[0]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.ThreeBlackCrows:	found = (isInUpTrend && n.Close[0] < n.Open[0] && n.Close[1] < n.Open[1] && n.Close[2] < n.Open[2] && n.Close[0] < n.Close[1] && n.Close[1] < n.Close[2]
																	&& n.Open[0] < n.Open[1] && n.Open[0] > n.Close[1] && n.Open[1] < n.Open[2] && n.Open[1] > n.Close[2]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.ThreeWhiteSoldiers:	found = (isInDownTrend && n.Close[0] > n.Open[0] && n.Close[1] > n.Open[1] && n.Close[2] > n.Open[2] && n.Close[0] > n.Close[1] && n.Close[1] > n.Close[2]
																	&& n.Open[0] < n.Close[1] && n.Open[0] > n.Open[1] && n.Open[1] < n.Close[2] && n.Open[1] > n.Open[2]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.UpsideGapTwoCrows:	found = (isInUpTrend && n.Close[2] > n.Open[2] && n.Close[1] < n.Open[1] && n.Close[0] < n.Open[0] && n.Low[1] > n.High[2]
																	&& n.Close[0] > n.High[2] && n.Close[0] < n.Close[1] && n.Open[0] > n.Open[1]) ? (int)pattern : -1; 
						break;
					case ARC_CandleStix_Patterns.UpsideTasukiGap:	found = (n.Close[2] > n.Open[2] && n.Close[1] > n.Open[1] && n.Close[0] < n. Open[0] && n.Low[1] > n.High[2]
																	&& n.Open[0] < n.Close[1] && n.Open[0] > n.Open[1] && n.Close[0] < n.Open[1] && n.Close[0] > n.Close[2]) ? (int)pattern : -1; 
						break;
				}
			prior[n.CurrentBars[0] % 2] = found >= 0;

			return found;
		}
		#endregion
	}
    public class CandleStixConverter : IndicatorBaseConverter // or StrategyBaseConverter
    {
		#region CandleStixConverter
        public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object component, Attribute[] attrs)
        {
            // we need the indicator instance which actually exists on the grid
            ARC_CandleStix indicator = component as ARC_CandleStix;

            // base.GetProperties ensures we have all the properties (and associated property grid editors)
            // NinjaTrader internal logic determines for a given indicator
            PropertyDescriptorCollection propertyDescriptorCollection = base.GetPropertiesSupported(context)
                                                                        ? base.GetProperties(context, component, attrs)
                                                                        : TypeDescriptor.GetProperties(component, attrs);

			if (indicator == null || propertyDescriptorCollection == null)
			    return propertyDescriptorCollection;

			// These values are will be shown/hidden (toggled) based on "ShowHideToggle" bool value
			List<PropertyDescriptor> toggles = new List<PropertyDescriptor>();
			if(indicator.GlobalizeMarkers){
				try{ toggles.Add(propertyDescriptorCollection["pLongChartMarkerBrush"]);} catch(Exception e){indicator.Print(e.ToString());}
				if(toggles[0] != null) propertyDescriptorCollection.Remove(toggles[0]);
				toggles.Clear();
				try{ toggles.Add(propertyDescriptorCollection["pShortChartMarkerBrush"]);} catch(Exception e){indicator.Print(e.ToString());}
				if(toggles[0] != null) propertyDescriptorCollection.Remove(toggles[0]);
			}else{
				try{ toggles.Add(propertyDescriptorCollection["LongMarker_Template"]);}  catch(Exception e){indicator.Print(e.ToString());}
				if(toggles[0] != null) propertyDescriptorCollection.Remove(toggles[0]);
				toggles.Clear();
				try{ toggles.Add(propertyDescriptorCollection["ShortMarker_Template"]);} catch(Exception e){indicator.Print(e.ToString());}
				if(toggles[0] != null) propertyDescriptorCollection.Remove(toggles[0]);
			}
			//PropertyDescriptor prop = null;
			List<string> props = new List<string>(){
				"pBullPat_Hammer", "pBullPat_InvertedHammer", "pBullPat_Doji", "pBullPat_Kicker", "pBullPat_Engulfing", 
				"pBullPat_Harami", "pBullPat_PiercingLine", "pBullPat_MorningStar", "pBullPat_ThreeWhiteSoldiers", "pBullPat_ThreeLineStrike", 
				"pBullPat_ThreeOutside", "pBullPat_ThreeInside"};

			Type pType = typeof(ARC_CandleStix);
			var propInfo = pType.GetProperty("pBullPat_All");
			if (indicator.pBullPat_All){
				foreach(var name in props){
					try{ 
						propInfo = pType.GetProperty(name);
						propInfo.SetValue(indicator, true);
					}
					catch(Exception e){indicator.Print(e.ToString());}
				}
				propInfo = pType.GetProperty("pBullPat_All");
				propInfo.SetValue(indicator, false);
			}
			if(indicator.pBullPat_None){
				foreach(var name in props){
					try{ 
						propInfo = pType.GetProperty(name);
						propInfo.SetValue(indicator, false);
					}
					catch(Exception e){indicator.Print(e.ToString());}
				}
				propInfo = pType.GetProperty("pBullPat_None");
				propInfo.SetValue(indicator, false);
			}
			
			props = new List<string>(){
				"pBearPat_HangingMan", "pBearPat_ShootingStar", "pBearPat_Doji", "pBearPat_Kicker", "pBearPat_Engulfing", 
				"pBearPat_Harami", "pBearPat_DarkCloudCover", "pBearPat_EveningStar", "pBearPat_ThreeBlackCrows", "pBearPat_ThreeLineStrike", 
				"pBearPat_ThreeOutside", "pBearPat_ThreeInside"};
			if (indicator.pBearPat_All){
				foreach(var name in props){
					try{ 
						propInfo = pType.GetProperty(name);
						propInfo.SetValue(indicator, true);
					}
					catch(Exception e){indicator.Print(e.ToString());}
				}
				propInfo = pType.GetProperty("pBearPat_All");
				propInfo.SetValue(indicator, false);
			}
			if(indicator.pBearPat_None){
				foreach(var name in props){
					try{ 
						propInfo = pType.GetProperty(name);
						propInfo.SetValue(indicator, false);
					}
					catch(Exception e){indicator.Print(e.ToString());}
				}
				propInfo = pType.GetProperty("pBearPat_None");
				propInfo.SetValue(indicator, false);
			}

			return propertyDescriptorCollection;
        }

        // Important: This must return true otherwise the type convetor will not be called
        public override bool GetPropertiesSupported(ITypeDescriptorContext context)
        { return true; }
		#endregion
    }
}

public enum ARC_CandleStix_ChartMarkers {Arrow, Triangle, Dot, Square, Diamond}
public enum ARC_CandleStix_Directions {Both, Longs, Shorts, None}

public enum ARC_CandleStix_Patterns
{
	BearishBeltHold			= 0,
	BearishEngulfing		= 1,
	BearishHarami			= 2,
	BearishHaramiCross		= 3,
	BullishBeltHold			= 4,
	BullishEngulfing		= 5,
	BullishHarami			= 6,
	BullishHaramiCross		= 7,
	DarkCloudCover			= 8,
	Doji					= 9,
	DownsideTasukiGap		= 10,
	EveningStar				= 11,
	FallingThreeMethods		= 12,
	Hammer					= 13,
	HangingMan				= 14,
	InvertedHammer			= 15,
	MorningStar				= 16,
	PiercingLine			= 17,
	RisingThreeMethods		= 18,
	ShootingStar			= 19,
	StickSandwich			= 20,
	ThreeBlackCrows			= 21,
	ThreeWhiteSoldiers		= 22,
	UpsideGapTwoCrows		= 23,
	UpsideTasukiGap			= 24,
	Kicker       = 25,
	ThreeInside  = 26,
	ThreeOutside = 27,
}
public enum ARC_CandleStix_BullPatterns
{
	Hammer				= 111,//1 = Bullish set, 1 = 1-bar pattern, 1 is the id for this pattern
	InvertedHammer		= 112,
	Doji				= 113,
	Kicker				= 121,
	Engulfing			= 122,
	Harami				= 123,
	PiercingLine		= 124,
	MorningStar			= 131,//1 = Bullish set, 3 = 3-bar pattern, 1 is the id for this pattern
	ThreeWhiteSoldiers	= 132,
	ThreeLineStrike     = 133,
	ThreeInside			= 134,
	ThreeOutside		= 135
}
public enum ARC_CandleStix_BearPatterns
{
	HangingMan			= 211,//2 = Bearish set, 1 = 1-bar pattern, 1 is the id for this pattern
	ShootingStar		= 212,
	Doji				= 213,
	Kicker				= 221,//2 = Bearish set, 2 = 2-bar pattern, 0 is the id for this pattern
	Engulfing			= 222,
	Harami				= 223,
	DarkCloudCover		= 224,
	EveningStar			= 231,
	ThreeBlackCrows		= 232,
	ThreeLineStrike     = 233,
	ThreeInside			= 234,
	ThreeOutside		= 235
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_CandleStix[] cacheARC_CandleStix;
		public ARC.ARC_CandleStix ARC_CandleStix(bool pBullPat_All, bool pBullPat_None, bool pBullPat_Hammer, bool pBullPat_InvertedHammer, bool pBullPat_Doji, bool pBullPat_Kicker, bool pBullPat_Engulfing, bool pBullPat_Harami, bool pBullPat_PiercingLine, bool pBullPat_MorningStar, bool pBullPat_ThreeWhiteSoldiers, bool pBullPat_ThreeLineStrike, bool pBullPat_ThreeOutside, bool pBullPat_ThreeInside, bool pBearPat_All, bool pBearPat_None, bool pBearPat_HangingMan, bool pBearPat_ShootingStar, bool pBearPat_Doji, bool pBearPat_Kicker, bool pBearPat_Engulfing, bool pBearPat_Harami, bool pBearPat_DarkCloudCover, bool pBearPat_EveningStar, bool pBearPat_ThreeBlackCrows, bool pBearPat_ThreeLineStrike, bool pBearPat_ThreeOutside, bool pBearPat_ThreeInside, int trendStrength)
		{
			return ARC_CandleStix(Input, pBullPat_All, pBullPat_None, pBullPat_Hammer, pBullPat_InvertedHammer, pBullPat_Doji, pBullPat_Kicker, pBullPat_Engulfing, pBullPat_Harami, pBullPat_PiercingLine, pBullPat_MorningStar, pBullPat_ThreeWhiteSoldiers, pBullPat_ThreeLineStrike, pBullPat_ThreeOutside, pBullPat_ThreeInside, pBearPat_All, pBearPat_None, pBearPat_HangingMan, pBearPat_ShootingStar, pBearPat_Doji, pBearPat_Kicker, pBearPat_Engulfing, pBearPat_Harami, pBearPat_DarkCloudCover, pBearPat_EveningStar, pBearPat_ThreeBlackCrows, pBearPat_ThreeLineStrike, pBearPat_ThreeOutside, pBearPat_ThreeInside, trendStrength);
		}

		public ARC.ARC_CandleStix ARC_CandleStix(ISeries<double> input, bool pBullPat_All, bool pBullPat_None, bool pBullPat_Hammer, bool pBullPat_InvertedHammer, bool pBullPat_Doji, bool pBullPat_Kicker, bool pBullPat_Engulfing, bool pBullPat_Harami, bool pBullPat_PiercingLine, bool pBullPat_MorningStar, bool pBullPat_ThreeWhiteSoldiers, bool pBullPat_ThreeLineStrike, bool pBullPat_ThreeOutside, bool pBullPat_ThreeInside, bool pBearPat_All, bool pBearPat_None, bool pBearPat_HangingMan, bool pBearPat_ShootingStar, bool pBearPat_Doji, bool pBearPat_Kicker, bool pBearPat_Engulfing, bool pBearPat_Harami, bool pBearPat_DarkCloudCover, bool pBearPat_EveningStar, bool pBearPat_ThreeBlackCrows, bool pBearPat_ThreeLineStrike, bool pBearPat_ThreeOutside, bool pBearPat_ThreeInside, int trendStrength)
		{
			if (cacheARC_CandleStix != null)
				for (int idx = 0; idx < cacheARC_CandleStix.Length; idx++)
					if (cacheARC_CandleStix[idx] != null && cacheARC_CandleStix[idx].pBullPat_All == pBullPat_All && cacheARC_CandleStix[idx].pBullPat_None == pBullPat_None && cacheARC_CandleStix[idx].pBullPat_Hammer == pBullPat_Hammer && cacheARC_CandleStix[idx].pBullPat_InvertedHammer == pBullPat_InvertedHammer && cacheARC_CandleStix[idx].pBullPat_Doji == pBullPat_Doji && cacheARC_CandleStix[idx].pBullPat_Kicker == pBullPat_Kicker && cacheARC_CandleStix[idx].pBullPat_Engulfing == pBullPat_Engulfing && cacheARC_CandleStix[idx].pBullPat_Harami == pBullPat_Harami && cacheARC_CandleStix[idx].pBullPat_PiercingLine == pBullPat_PiercingLine && cacheARC_CandleStix[idx].pBullPat_MorningStar == pBullPat_MorningStar && cacheARC_CandleStix[idx].pBullPat_ThreeWhiteSoldiers == pBullPat_ThreeWhiteSoldiers && cacheARC_CandleStix[idx].pBullPat_ThreeLineStrike == pBullPat_ThreeLineStrike && cacheARC_CandleStix[idx].pBullPat_ThreeOutside == pBullPat_ThreeOutside && cacheARC_CandleStix[idx].pBullPat_ThreeInside == pBullPat_ThreeInside && cacheARC_CandleStix[idx].pBearPat_All == pBearPat_All && cacheARC_CandleStix[idx].pBearPat_None == pBearPat_None && cacheARC_CandleStix[idx].pBearPat_HangingMan == pBearPat_HangingMan && cacheARC_CandleStix[idx].pBearPat_ShootingStar == pBearPat_ShootingStar && cacheARC_CandleStix[idx].pBearPat_Doji == pBearPat_Doji && cacheARC_CandleStix[idx].pBearPat_Kicker == pBearPat_Kicker && cacheARC_CandleStix[idx].pBearPat_Engulfing == pBearPat_Engulfing && cacheARC_CandleStix[idx].pBearPat_Harami == pBearPat_Harami && cacheARC_CandleStix[idx].pBearPat_DarkCloudCover == pBearPat_DarkCloudCover && cacheARC_CandleStix[idx].pBearPat_EveningStar == pBearPat_EveningStar && cacheARC_CandleStix[idx].pBearPat_ThreeBlackCrows == pBearPat_ThreeBlackCrows && cacheARC_CandleStix[idx].pBearPat_ThreeLineStrike == pBearPat_ThreeLineStrike && cacheARC_CandleStix[idx].pBearPat_ThreeOutside == pBearPat_ThreeOutside && cacheARC_CandleStix[idx].pBearPat_ThreeInside == pBearPat_ThreeInside && cacheARC_CandleStix[idx].TrendStrength == trendStrength && cacheARC_CandleStix[idx].EqualsInput(input))
						return cacheARC_CandleStix[idx];
			return CacheIndicator<ARC.ARC_CandleStix>(new ARC.ARC_CandleStix(){ pBullPat_All = pBullPat_All, pBullPat_None = pBullPat_None, pBullPat_Hammer = pBullPat_Hammer, pBullPat_InvertedHammer = pBullPat_InvertedHammer, pBullPat_Doji = pBullPat_Doji, pBullPat_Kicker = pBullPat_Kicker, pBullPat_Engulfing = pBullPat_Engulfing, pBullPat_Harami = pBullPat_Harami, pBullPat_PiercingLine = pBullPat_PiercingLine, pBullPat_MorningStar = pBullPat_MorningStar, pBullPat_ThreeWhiteSoldiers = pBullPat_ThreeWhiteSoldiers, pBullPat_ThreeLineStrike = pBullPat_ThreeLineStrike, pBullPat_ThreeOutside = pBullPat_ThreeOutside, pBullPat_ThreeInside = pBullPat_ThreeInside, pBearPat_All = pBearPat_All, pBearPat_None = pBearPat_None, pBearPat_HangingMan = pBearPat_HangingMan, pBearPat_ShootingStar = pBearPat_ShootingStar, pBearPat_Doji = pBearPat_Doji, pBearPat_Kicker = pBearPat_Kicker, pBearPat_Engulfing = pBearPat_Engulfing, pBearPat_Harami = pBearPat_Harami, pBearPat_DarkCloudCover = pBearPat_DarkCloudCover, pBearPat_EveningStar = pBearPat_EveningStar, pBearPat_ThreeBlackCrows = pBearPat_ThreeBlackCrows, pBearPat_ThreeLineStrike = pBearPat_ThreeLineStrike, pBearPat_ThreeOutside = pBearPat_ThreeOutside, pBearPat_ThreeInside = pBearPat_ThreeInside, TrendStrength = trendStrength }, input, ref cacheARC_CandleStix);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_CandleStix ARC_CandleStix(bool pBullPat_All, bool pBullPat_None, bool pBullPat_Hammer, bool pBullPat_InvertedHammer, bool pBullPat_Doji, bool pBullPat_Kicker, bool pBullPat_Engulfing, bool pBullPat_Harami, bool pBullPat_PiercingLine, bool pBullPat_MorningStar, bool pBullPat_ThreeWhiteSoldiers, bool pBullPat_ThreeLineStrike, bool pBullPat_ThreeOutside, bool pBullPat_ThreeInside, bool pBearPat_All, bool pBearPat_None, bool pBearPat_HangingMan, bool pBearPat_ShootingStar, bool pBearPat_Doji, bool pBearPat_Kicker, bool pBearPat_Engulfing, bool pBearPat_Harami, bool pBearPat_DarkCloudCover, bool pBearPat_EveningStar, bool pBearPat_ThreeBlackCrows, bool pBearPat_ThreeLineStrike, bool pBearPat_ThreeOutside, bool pBearPat_ThreeInside, int trendStrength)
		{
			return indicator.ARC_CandleStix(Input, pBullPat_All, pBullPat_None, pBullPat_Hammer, pBullPat_InvertedHammer, pBullPat_Doji, pBullPat_Kicker, pBullPat_Engulfing, pBullPat_Harami, pBullPat_PiercingLine, pBullPat_MorningStar, pBullPat_ThreeWhiteSoldiers, pBullPat_ThreeLineStrike, pBullPat_ThreeOutside, pBullPat_ThreeInside, pBearPat_All, pBearPat_None, pBearPat_HangingMan, pBearPat_ShootingStar, pBearPat_Doji, pBearPat_Kicker, pBearPat_Engulfing, pBearPat_Harami, pBearPat_DarkCloudCover, pBearPat_EveningStar, pBearPat_ThreeBlackCrows, pBearPat_ThreeLineStrike, pBearPat_ThreeOutside, pBearPat_ThreeInside, trendStrength);
		}

		public Indicators.ARC.ARC_CandleStix ARC_CandleStix(ISeries<double> input , bool pBullPat_All, bool pBullPat_None, bool pBullPat_Hammer, bool pBullPat_InvertedHammer, bool pBullPat_Doji, bool pBullPat_Kicker, bool pBullPat_Engulfing, bool pBullPat_Harami, bool pBullPat_PiercingLine, bool pBullPat_MorningStar, bool pBullPat_ThreeWhiteSoldiers, bool pBullPat_ThreeLineStrike, bool pBullPat_ThreeOutside, bool pBullPat_ThreeInside, bool pBearPat_All, bool pBearPat_None, bool pBearPat_HangingMan, bool pBearPat_ShootingStar, bool pBearPat_Doji, bool pBearPat_Kicker, bool pBearPat_Engulfing, bool pBearPat_Harami, bool pBearPat_DarkCloudCover, bool pBearPat_EveningStar, bool pBearPat_ThreeBlackCrows, bool pBearPat_ThreeLineStrike, bool pBearPat_ThreeOutside, bool pBearPat_ThreeInside, int trendStrength)
		{
			return indicator.ARC_CandleStix(input, pBullPat_All, pBullPat_None, pBullPat_Hammer, pBullPat_InvertedHammer, pBullPat_Doji, pBullPat_Kicker, pBullPat_Engulfing, pBullPat_Harami, pBullPat_PiercingLine, pBullPat_MorningStar, pBullPat_ThreeWhiteSoldiers, pBullPat_ThreeLineStrike, pBullPat_ThreeOutside, pBullPat_ThreeInside, pBearPat_All, pBearPat_None, pBearPat_HangingMan, pBearPat_ShootingStar, pBearPat_Doji, pBearPat_Kicker, pBearPat_Engulfing, pBearPat_Harami, pBearPat_DarkCloudCover, pBearPat_EveningStar, pBearPat_ThreeBlackCrows, pBearPat_ThreeLineStrike, pBearPat_ThreeOutside, pBearPat_ThreeInside, trendStrength);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_CandleStix ARC_CandleStix(bool pBullPat_All, bool pBullPat_None, bool pBullPat_Hammer, bool pBullPat_InvertedHammer, bool pBullPat_Doji, bool pBullPat_Kicker, bool pBullPat_Engulfing, bool pBullPat_Harami, bool pBullPat_PiercingLine, bool pBullPat_MorningStar, bool pBullPat_ThreeWhiteSoldiers, bool pBullPat_ThreeLineStrike, bool pBullPat_ThreeOutside, bool pBullPat_ThreeInside, bool pBearPat_All, bool pBearPat_None, bool pBearPat_HangingMan, bool pBearPat_ShootingStar, bool pBearPat_Doji, bool pBearPat_Kicker, bool pBearPat_Engulfing, bool pBearPat_Harami, bool pBearPat_DarkCloudCover, bool pBearPat_EveningStar, bool pBearPat_ThreeBlackCrows, bool pBearPat_ThreeLineStrike, bool pBearPat_ThreeOutside, bool pBearPat_ThreeInside, int trendStrength)
		{
			return indicator.ARC_CandleStix(Input, pBullPat_All, pBullPat_None, pBullPat_Hammer, pBullPat_InvertedHammer, pBullPat_Doji, pBullPat_Kicker, pBullPat_Engulfing, pBullPat_Harami, pBullPat_PiercingLine, pBullPat_MorningStar, pBullPat_ThreeWhiteSoldiers, pBullPat_ThreeLineStrike, pBullPat_ThreeOutside, pBullPat_ThreeInside, pBearPat_All, pBearPat_None, pBearPat_HangingMan, pBearPat_ShootingStar, pBearPat_Doji, pBearPat_Kicker, pBearPat_Engulfing, pBearPat_Harami, pBearPat_DarkCloudCover, pBearPat_EveningStar, pBearPat_ThreeBlackCrows, pBearPat_ThreeLineStrike, pBearPat_ThreeOutside, pBearPat_ThreeInside, trendStrength);
		}

		public Indicators.ARC.ARC_CandleStix ARC_CandleStix(ISeries<double> input , bool pBullPat_All, bool pBullPat_None, bool pBullPat_Hammer, bool pBullPat_InvertedHammer, bool pBullPat_Doji, bool pBullPat_Kicker, bool pBullPat_Engulfing, bool pBullPat_Harami, bool pBullPat_PiercingLine, bool pBullPat_MorningStar, bool pBullPat_ThreeWhiteSoldiers, bool pBullPat_ThreeLineStrike, bool pBullPat_ThreeOutside, bool pBullPat_ThreeInside, bool pBearPat_All, bool pBearPat_None, bool pBearPat_HangingMan, bool pBearPat_ShootingStar, bool pBearPat_Doji, bool pBearPat_Kicker, bool pBearPat_Engulfing, bool pBearPat_Harami, bool pBearPat_DarkCloudCover, bool pBearPat_EveningStar, bool pBearPat_ThreeBlackCrows, bool pBearPat_ThreeLineStrike, bool pBearPat_ThreeOutside, bool pBearPat_ThreeInside, int trendStrength)
		{
			return indicator.ARC_CandleStix(input, pBullPat_All, pBullPat_None, pBullPat_Hammer, pBullPat_InvertedHammer, pBullPat_Doji, pBullPat_Kicker, pBullPat_Engulfing, pBullPat_Harami, pBullPat_PiercingLine, pBullPat_MorningStar, pBullPat_ThreeWhiteSoldiers, pBullPat_ThreeLineStrike, pBullPat_ThreeOutside, pBullPat_ThreeInside, pBearPat_All, pBearPat_None, pBearPat_HangingMan, pBearPat_ShootingStar, pBearPat_Doji, pBearPat_Kicker, pBearPat_Engulfing, pBearPat_Harami, pBearPat_DarkCloudCover, pBearPat_EveningStar, pBearPat_ThreeBlackCrows, pBearPat_ThreeLineStrike, pBearPat_ThreeOutside, pBearPat_ThreeInside, trendStrength);
		}
	}
}

#endregion
