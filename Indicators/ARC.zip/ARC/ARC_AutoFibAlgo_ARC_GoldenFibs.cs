#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public class ARC_AutoFibAlgo_ARC_GoldenFibs : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				PrintTo = PrintTo.OutputTab2;
				Description = "Multi-timeframe fib levels";
				Name = "ARC_AutoFibAlgo_ARC_GoldenFibs";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				PaintPriceMarkers = false;
				DisplayInDataBox = false;
				IsAutoScale = false;
				ArePlotsConfigurable = false;
				ZOrder = 0;
				DrawOnPricePanel = true;
				ScaleJustification = ScaleJustification.Right;
				IsSuspendedWhileInactive = true;

				for (var i = 0; i < 20; i++)
					AddPlot(Brushes.Black, "Confluence" + i);

				for (var i = 0; i < 20; i++)
					AddPlot(new Stroke(Brushes.Black, DashStyleHelper.Dash, 1), PlotStyle.Line, "WeakConfluence" + i);

				BarPeriod = 5;
				LineDensity = ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Default;
				ConfluenceZone = ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth.Strong;
				Threshold = 100;
				LookBackMinute = 300;
				ResistanceColor = Brushes.Maroon;
				SupportColor = Brushes.Blue;
				StrongPlotStyle = PlotStyle.Line;
				WeakPlotStyle = PlotStyle.Line;
				StrongDashStyle = DashStyleHelper.Solid;
				WeakDashStyle = DashStyleHelper.Solid;
				LineWidthStrong = 2;
				LineWidthWeak = 2;
			}
			else if (State == State.Configure)
			{
				var bp = (BarsPeriod)BarsPeriod.Clone();
				bp.BarsPeriodType = BarsPeriodType.Minute;
				bp.Value = BarPeriod;
				var tradingHoursTuple = TradingHours.GetEthRth(Instrument.MasterInstrument);
				AddDataSeries(Instrument.FullName, bp, (int)(Bars.ToDate - Bars.FromDate).TotalMinutes + LookbackMinutes, tradingHoursTuple.Item1.Name, IsResetOnNewTradingDays[0]);

				for (var i = 0; i < 10; i++)
				{
					timeFrameFactor[i] = i == 0 ? 1 : Math.Sqrt(stepUpRatio) * timeFrameFactor[i - 1];

					upTrend[i] = true;
					existsSwingHigh[i] = false;
					existsSwingLow[i] = false;
					minimumDeviation[i] = double.MaxValue;
					for (var j = 0; j < 20; j++)
					{
						microHigh[i, j] = double.MaxValue;
						microLow[i, j] = double.MinValue;
					}

					currentHigh[i] = 0;
					currentLow[i] = 0;
					currentSwingHigh[i] = double.MaxValue;
					currentSwingLow[i] = double.MinValue;
					lastSwingHigh[i] = double.MaxValue;
					lastSwingLow[i] = double.MinValue;
					microSwingHigh0[i] = double.MaxValue;
					microSwingHigh1[i] = double.MaxValue;
					microSwingHigh2[i] = double.MaxValue;
					microSwingHigh3[i] = double.MaxValue;
					microSwingLow0[i] = double.MinValue;
					microSwingLow1[i] = double.MinValue;
					microSwingLow2[i] = double.MinValue;
					microSwingLow3[i] = double.MinValue;
					retUp0[i] = 0;
					retUp23[i] = 0;
					retUp38[i] = 0;
					retUp50[i] = 0;
					retUp62[i] = 0;
					retUp76[i] = 0;
					retUp100[i] = 0;
					retDown0[i] = 0;
					retDown23[i] = 0;
					retDown38[i] = 0;
					retDown50[i] = 0;
					retDown62[i] = 0;
					retDown76[i] = 0;
					retDown100[i] = 0;
					extUp0[i] = 0;
					extUp100[i] = 0;
					extUp127[i] = 0;
					extUp162[i] = 0;
					extUp200[i] = 0;
					extUp262[i] = 0;
					extUp300[i] = 0;
					extUp423[i] = 0;
					extDown0[i] = 0;
					extDown100[i] = 0;
					extDown127[i] = 0;
					extDown162[i] = 0;
					extDown200[i] = 0;
					extDown262[i] = 0;
					extDown300[i] = 0;
					extDown423[i] = 0;
					dirUp38[i] = 0;
					dirUp62[i] = 0;
					dirUp100[i] = 0;
					dirDown38[i] = 0;
					dirDown62[i] = 0;
					dirDown100[i] = 0;
					lastDirUp38[i] = 0;
					lastDirUp62[i] = 0;
					lastDirUp100[i] = 0;
					lastDirDown38[i] = 0;
					lastDirDown62[i] = 0;
					lastDirDown100[i] = 0;
					alt0Up[i] = 0;
					alt0Down[i] = 0;
					alt1Up[i] = 0;
					alt1Down[i] = 0;
					alt0Up62[i] = 0;
					alt0Up100[i] = 0;
					alt0Up162[i] = 0;
					alt1Up100[i] = 0;
					alt0Down62[i] = 0;
					alt0Down100[i] = 0;
					alt0Down162[i] = 0;
					alt1Down100[i] = 0;
					priorCurrentHigh[i] = 0;
					priorCurrentLow[i] = 0;
					priorMicroSwingHigh0[i] = double.MaxValue;
					priorMicroSwingHigh1[i] = double.MaxValue;
					priorMicroSwingHigh2[i] = double.MaxValue;
					priorMicroSwingHigh3[i] = double.MaxValue;
					priorMicroSwingLow0[i] = double.MinValue;
					priorMicroSwingLow1[i] = double.MinValue;
					priorMicroSwingLow2[i] = double.MinValue;
					priorMicroSwingLow3[i] = double.MinValue;
					priorCurrentSwingHigh[i] = 0;
					priorLastSwingHigh[i] = 0;
					priorCurrentSwingLow[i] = 0;
					priorLastSwingLow[i] = 0;
					priorRetUp0[i] = 0;
					priorRetUp23[i] = 0;
					priorRetUp38[i] = 0;
					priorRetUp50[i] = 0;
					priorRetUp62[i] = 0;
					priorRetUp76[i] = 0;
					priorRetUp100[i] = 0;
					priorRetDown0[i] = 0;
					priorRetDown23[i] = 0;
					priorRetDown38[i] = 0;
					priorRetDown50[i] = 0;
					priorRetDown62[i] = 0;
					priorRetDown76[i] = 0;
					priorRetDown100[i] = 0;
					priorExtUp0[i] = 0;
					priorExtUp100[i] = 0;
					priorExtUp127[i] = 0;
					priorExtUp162[i] = 0;
					priorExtUp200[i] = 0;
					priorExtUp262[i] = 0;
					priorExtUp300[i] = 0;
					priorExtUp423[i] = 0;
					priorExtDown0[i] = 0;
					priorExtDown100[i] = 0;
					priorExtDown127[i] = 0;
					priorExtDown162[i] = 0;
					priorExtDown200[i] = 0;
					priorExtDown262[i] = 0;
					priorExtDown300[i] = 0;
					priorExtDown423[i] = 0;
					priorDirUp38[i] = 0;
					priorDirUp62[i] = 0;
					priorDirUp100[i] = 0;
					priorDirDown38[i] = 0;
					priorDirDown62[i] = 0;
					priorDirDown100[i] = 0;
					priorLastDirUp38[i] = 0;
					priorLastDirUp62[i] = 0;
					priorLastDirUp100[i] = 0;
					priorLastDirDown38[i] = 0;
					priorLastDirDown62[i] = 0;
					priorLastDirDown100[i] = 0;
					priorAlt0Up62[i] = 0;
					priorAlt0Up100[i] = 0;
					priorAlt0Up162[i] = 0;
					priorAlt1Up100[i] = 0;
					priorAlt0Down62[i] = 0;
					priorAlt0Down100[i] = 0;
					priorAlt0Down162[i] = 0;
					priorAlt1Down100[i] = 0;
					countDown[i] = -1;
					currentSwingHighIndex[i] = -100;
					lastSwingHighIndex[i] = -100;
					currentSwingLowIndex[i] = -100;
					lastSwingLowIndex[i] = -100;
					weightMicroSwingHigh0[i] = 0;
					weightMicroSwingHigh1[i] = 0;
					weightMicroSwingHigh2[i] = 0;
					weightMicroSwingHigh3[i] = 0;
					weightMicroSwingLow0[i] = 0;
					weightMicroSwingLow1[i] = 0;
					weightMicroSwingLow2[i] = 0;
					weightMicroSwingLow3[i] = 0;
					weightCurrentSwingHigh[i] = 0;
					weightLastSwingHigh[i] = 0;
					weightCurrentSwingLow[i] = 0;
					weightLastSwingLow[i] = 0;
					weightRetUp23[i] = 0;
					weightRetUp38[i] = 0;
					weightRetUp50[i] = 0;
					weightRetUp62[i] = 0;
					weightRetUp76[i] = 0;
					weightRetDown23[i] = 0;
					weightRetDown38[i] = 0;
					weightRetDown50[i] = 0;
					weightRetDown62[i] = 0;
					weightRetDown76[i] = 0;
					weightExtUp127[i] = 0;
					weightExtUp162[i] = 0;
					weightExtUp200[i] = 0;
					weightExtUp262[i] = 0;
					weightExtUp300[i] = 0;
					weightExtUp423[i] = 0;
					weightExtDown127[i] = 0;
					weightExtDown162[i] = 0;
					weightExtDown200[i] = 0;
					weightExtDown262[i] = 0;
					weightExtDown300[i] = 0;
					weightExtDown423[i] = 0;
					weightDirUp38[i] = 0;
					weightDirUp62[i] = 0;
					weightDirUp100[i] = 0;
					weightDirDown38[i] = 0;
					weightDirDown62[i] = 0;
					weightDirDown100[i] = 0;
					weightLastDirUp38[i] = 0;
					weightLastDirUp62[i] = 0;
					weightLastDirUp100[i] = 0;
					weightLastDirDown38[i] = 0;
					weightLastDirDown62[i] = 0;
					weightLastDirDown100[i] = 0;
					weightAlt0Up62[i] = 0;
					weightAlt0Up100[i] = 0;
					weightAlt0Up162[i] = 0;
					weightAlt1Up100[i] = 0;
					weightAlt0Down62[i] = 0;
					weightAlt0Down100[i] = 0;
					weightAlt0Down162[i] = 0;
					weightAlt1Down100[i] = 0;
					cumWeightMicroSwingHigh0[i] = 0;
					cumWeightMicroSwingHigh1[i] = 0;
					cumWeightMicroSwingHigh2[i] = 0;
					cumWeightMicroSwingHigh3[i] = 0;
					cumWeightMicroSwingLow0[i] = 0;
					cumWeightMicroSwingLow1[i] = 0;
					cumWeightMicroSwingLow2[i] = 0;
					cumWeightMicroSwingLow3[i] = 0;
					cumWeightCurrentSwingHigh[i] = 0;
					cumWeightLastSwingHigh[i] = 0;
					cumWeightCurrentSwingLow[i] = 0;
					cumWeightLastSwingLow[i] = 0;
					cumWeightRetUp23[i] = 0;
					cumWeightRetUp38[i] = 0;
					cumWeightRetUp50[i] = 0;
					cumWeightRetUp62[i] = 0;
					cumWeightRetUp76[i] = 0;
					cumWeightRetDown23[i] = 0;
					cumWeightRetDown38[i] = 0;
					cumWeightRetDown50[i] = 0;
					cumWeightRetDown62[i] = 0;
					cumWeightRetDown76[i] = 0;
					cumWeightExtUp127[i] = 0;
					cumWeightExtUp162[i] = 0;
					cumWeightExtUp200[i] = 0;
					cumWeightExtUp262[i] = 0;
					cumWeightExtUp300[i] = 0;
					cumWeightExtUp423[i] = 0;
					cumWeightExtDown127[i] = 0;
					cumWeightExtDown162[i] = 0;
					cumWeightExtDown200[i] = 0;
					cumWeightExtDown262[i] = 0;
					cumWeightExtDown300[i] = 0;
					cumWeightExtDown423[i] = 0;
					cumWeightDirUp38[i] = 0;
					cumWeightDirUp62[i] = 0;
					cumWeightDirUp100[i] = 0;
					cumWeightDirDown38[i] = 0;
					cumWeightDirDown62[i] = 0;
					cumWeightDirDown100[i] = 0;
					cumWeightLastDirUp38[i] = 0;
					cumWeightLastDirUp62[i] = 0;
					cumWeightLastDirUp100[i] = 0;
					cumWeightLastDirDown38[i] = 0;
					cumWeightLastDirDown62[i] = 0;
					cumWeightLastDirDown100[i] = 0;
					cumWeightAlt0Up62[i] = 0;
					cumWeightAlt0Up100[i] = 0;
					cumWeightAlt0Up162[i] = 0;
					cumWeightAlt1Up100[i] = 0;
					cumWeightAlt0Down62[i] = 0;
					cumWeightAlt0Down100[i] = 0;
					cumWeightAlt0Down162[i] = 0;
					cumWeightAlt1Down100[i] = 0;
				}

				for (var i = 0; i < 20; i++)
				{
					strongFibs[i] = 0;
					weakFibs[i] = 0;
					priorStrongFibs[i] = 0;
					priorWeakFibs[i] = 0;
					oldStrongFibs[i] = 0;
					oldWeakFibs[i] = 0;
				}

				for (var i = 0; i < 40; i++)
				{
					newBOBHigh[i] = 0.0;
					oldBOBHigh[i] = 0.0;
					newBOBLow[i] = 0.0;
					oldBOBLow[i] = 0.0;
					newBOBClose[i] = 0.0;
					oldBOBClose[i] = 0.0;
					newState[i] = 1;
					oldState[i] = 1;
				}

				for (var i = 0; i < 540; i++)
				{
					fibLine[i] = 0;
					fibWeight[i] = 0;
					fibResistance[i] = 0;
					weakResistance[i] = 0;
					weightResistance[i] = 0;
					fibSupport[i] = 0;
					weakSupport[i] = 0;
					weightSupport[i] = 0;
				}

				zigZagFactor = Math.Max(8, 16.0 / Math.Pow(BarPeriod, 0.25));
				if (ConfluenceZone == ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth.Weak)
					zigZagFactor *= 1.2;

				switch (LineDensity)
				{
				case ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Small:
					zigZagFactor /= 1.4;
					break;
				case ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Smallest:
					zigZagFactor /= 1.96;
					break;
				case ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Increased:
					zigZagFactor *= 1.4;
					break;
				case ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Large:
					zigZagFactor *= 1.96;
					break;
				case ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Largest:
					zigZagFactor *= 2.74;
					break;
				}

				confluenceRange = (ConfluenceZone == ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth.Strong ? 0.2 : 0.1) * zigZagFactor;
			}
			else if (State == State.Historical)
			{
				for (var i = 0; i < 10; i++)
				{
					Plots[i].Brush = ResistanceColor;
					Plots[i].PlotStyle = StrongPlotStyle;
					Plots[i].DashStyleHelper = StrongDashStyle;
					Plots[i].Width = LineWidthStrong;
				}

				for (var i = 10; i < 20; i++)
				{
					Plots[i].Brush = SupportColor;
					Plots[i].PlotStyle = StrongPlotStyle;
					Plots[i].DashStyleHelper = StrongDashStyle;
					Plots[i].Width = LineWidthStrong;
				}

				for (var i = 20; i < 30; i++)
				{
					Plots[i].Brush = ResistanceColor;
					Plots[i].PlotStyle = WeakPlotStyle;
					Plots[i].DashStyleHelper = WeakDashStyle;
					Plots[i].Width = LineWidthWeak;
				}

				for (var i = 30; i < 40; i++)
				{
					Plots[i].Brush = SupportColor;
					Plots[i].PlotStyle = WeakPlotStyle;
					Plots[i].DashStyleHelper = WeakDashStyle;
					Plots[i].Width = LineWidthWeak;
				}
			}
		}

		protected override void OnBarUpdate()
		{
			if (!BarsType.CreateInstance(Bars.BarsPeriod.BarsPeriodType).IsIntraday)
				return;

			if (BarsInProgress == 1)
			{
				priorBarHigh = currentBarHigh;
				priorBarLow = currentBarLow;
				priorBarClose = currentBarClose;
				currentBarHigh = High[0];
				currentBarLow = Low[0];
				currentBarClose = Close[0];
				if (CurrentBar == 1)
				{
					for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
					{
						currentHigh[i] = priorBarHigh;
						currentLow[i] = priorBarLow;
					}

					currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
					avgTrueRange = currentBarTrueRange;
				}
				else if (CurrentBar > 1)
				{
					currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
					avgTrueRange = (avgTrueRange * CurrentBar + currentBarTrueRange) / (CurrentBar + 1);

					// Calculates Swing Highs and Lows, Retracements, Extensions, Alternates and Projections from currentBarHigh and currentBarLow
					if ((Time[0] - Time.GetValueAt(0)).TotalDays > 14)
						for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
							CalculateFibonacci(i);

					confluenceRangeWidth = confluenceRange * avgTrueRange;
					upperLimitResistance = MAX(High, 20)[0] + (displayFactor * avgTrueRange);
					lowerLimitResistance = Close[0];
					upperLimitSupport = Close[0];
					lowerLimitSupport = MIN(Low, 20)[0] - (displayFactor * avgTrueRange);
					upperLimitWeakResistance = MAX(High, 20)[0] + (displayFactor * avgTrueRange);
					lowerLimitWeakSupport = MIN(Low, 20)[0] - (displayFactor * avgTrueRange);
				}
			}

			if (BarsInProgress != 0 || CurrentBar < 2 || CurrentBars[1] <= LookbackMinutes)
				return;

			SetLinesAndWeights();
			SelectLines();
			SortLines();

			#region Display up to 10 Resistance and 10 Support Ranges
			for (var i = 0; i < 10; i++)
			{
				strongFibs[i] = Instrument.MasterInstrument.RoundToTickSize(fibSupport[9 - i]);
				strongFibs[10 + i] = Instrument.MasterInstrument.RoundToTickSize(fibResistance[i]);
				weakFibs[i] = Instrument.MasterInstrument.RoundToTickSize(weakSupport[9 - i]);
				weakFibs[10 + i] = Instrument.MasterInstrument.RoundToTickSize(weakResistance[i]);
			}

			for (var i = 0; i < 20; i++)
			{
				oldStrongFibs[i] = Instrument.MasterInstrument.RoundToTickSize(priorStrongFibs[i]);
				oldState[i] = newState[i];
				oldBOBHigh[i] = newBOBHigh[i];
				oldBOBLow[i] = newBOBLow[i];
				oldBOBClose[i] = newBOBClose[i];
				if (!showWeakerLines)
					continue;

				var j = i + 20;
				oldWeakFibs[i] = Instrument.MasterInstrument.RoundToTickSize(priorWeakFibs[i]);
				oldState[j] = newState[j];
				oldBOBHigh[j] = newBOBHigh[j];
				oldBOBLow[j] = newBOBLow[j];
				oldBOBClose[j] = newBOBClose[j];
			}

			for (var i = 0; i < 20; i++)
			{
				for (var j = 0; j < 20; j++)
				{
					if (strongFibs[j] == oldStrongFibs[i])
					{
						strongFibs[j] = Instrument.MasterInstrument.RoundToTickSize(strongFibs[i]);
						strongFibs[i] = Instrument.MasterInstrument.RoundToTickSize(oldStrongFibs[i]);
					}

					if (weakFibs[j] == oldWeakFibs[i])
					{
						weakFibs[j] = Instrument.MasterInstrument.RoundToTickSize(weakFibs[i]);
						weakFibs[i] = Instrument.MasterInstrument.RoundToTickSize(oldWeakFibs[i]);
					}
				}
			}

			for (var i = 0; i < 20; i++) 
				Confluences[i][0] = strongFibs[i];

			//newState und newBobClose determined via fib values
			lowestResistance = double.MaxValue;
			highestSupport = double.MinValue;

			for (var i = 0; i < 20; i++)
			{
				priorStrongFibs[i] = strongFibs[i];
				newState[i] = UpdateState(newState[i], oldState[i], oldStrongFibs[i], strongFibs[i], Highs[0][0], Lows[0][0], Closes[0][0]);

				if (newState[i] == 0)
				{
					PlotBrushes[i][0] = Brushes.Transparent;
				}
				else if (newState[i] == 1 || newState[i] == 2)
				{
					PlotBrushes[i][0] = ResistanceColor;
					lowestResistance = Math.Min(strongFibs[i], lowestResistance);
				}
				else if (newState[i] == 3 || newState[i] == 4)
				{
					PlotBrushes[i][0] = SupportColor;
					highestSupport = Math.Max(strongFibs[i], highestSupport);
				}
			}
			#endregion

			if (showWeakerLines)
			{
				for (var i = 0; i < 20; i++) 
					WeakConfluences[i][0] = weakFibs[i];

				for (var i = 20; i < 40; i++)
				{
					priorWeakFibs[i - 20] = weakFibs[i - 20];
					newState[i] = UpdateState(newState[i], oldState[i], oldWeakFibs[i - 20], weakFibs[i - 20], Highs[0][0], Lows[0][0], Closes[0][0]);

					if (newState[i] == 0)
						PlotBrushes[i][0] = Brushes.Transparent;
					else if (newState[i] == 1 || newState[i] == 2)
						PlotBrushes[i][0] = ResistanceColor;
					else if (newState[i] == 3 || newState[i] == 4) 
						PlotBrushes[i][0] = SupportColor;
				}
			}

			for (var i = 0; i < 40; i++)
			{
				if (allLevels.ContainsKey(Values[i][0]))
				{
					allLevels[Values[i][0]].rMABar = CurrentBar;
					allLevels[Values[i][0]].state = newState[i];
				}
				else
				{
					allLevels[Values[i][0]] = new LevelData(CurrentBar, newState[i]);
				}
			}
			
			var nearSupport = double.MinValue;
			var keys = new List<double>(allLevels.Keys);
			foreach (var k in keys)
			{
				if (allLevels[k].rMABar < CurrentBar) 
					allLevels[k].state = int.MinValue;

				if (allLevels[k].state != 3 && allLevels[k].state != 4)
					continue;

				if (k <= nearSupport)
					continue;
				
				nearSupport = k;
			}

			var nearResistance = double.MaxValue;
			for (var i = keys.Count - 1; i >= 0; i--)
			{
				if (allLevels[keys[i]].state != 1 && allLevels[keys[i]].state != 2)
					continue;

				if (keys[i] >= nearResistance)
					continue;
				
				nearResistance = keys[i];
			}

			foreach (var t in keys) 
				allLevels.Remove(t);
		}

		private static int UpdateState(int newState, int oldState, double oldFibs, double tmpFibValue, double h, double l, double c)
		{
			if (oldFibs != tmpFibValue)
				return 0;

			if (oldState == 0 && c < tmpFibValue)
				return 1;

			if (oldState == 0 && c >= tmpFibValue)
				return 3;

			if (oldState == 1 && l > tmpFibValue)
				return 3;

			if (oldState == 1)
				return 1;

			if (oldState == 3 && h < tmpFibValue)
				return 1;

			if (oldState == 3)
				return 3;

			return newState;
		}

		public void CalculateFibonacci(int i)
		{
			minimumDeviation[i] = zigZagFactor * Math.Pow(stepUpRatio, i) * avgTrueRange;
			timeFrameMultiplier = 1.5 * timeFrameFactor[i];
			highUpdate = upTrend[i] && priorBarHigh >= currentBarHigh && priorBarHigh > currentHigh[i];
			lowUpdate = !upTrend[i] && priorBarLow <= currentBarLow && priorBarLow < currentLow[i];
			addHigh = !upTrend[i] && priorBarHigh >= currentBarHigh && priorBarHigh > currentLow[i] + minimumDeviation[i];
			addLow = upTrend[i] && priorBarLow <= currentBarLow && priorBarLow < currentHigh[i] - minimumDeviation[i];
			normalizedRangeUp = 0;
			normalizedRangeDown = 0;

			countDown[i] = highUpdate || lowUpdate || addHigh || addLow ? 1 : countDown[i] - 1;

			if (countDown[i] == 0)
			{
				priorCurrentHigh[i] = currentHigh[i];
				priorCurrentLow[i] = currentLow[i];
				priorMicroSwingHigh0[i] = microSwingHigh0[i];
				priorMicroSwingHigh1[i] = microSwingHigh1[i];
				priorMicroSwingHigh2[i] = microSwingHigh2[i];
				priorMicroSwingHigh3[i] = microSwingHigh3[i];
				priorMicroSwingLow0[i] = microSwingLow0[i];
				priorMicroSwingLow1[i] = microSwingLow1[i];
				priorMicroSwingLow2[i] = microSwingLow2[i];
				priorMicroSwingLow3[i] = microSwingLow3[i];
				priorCurrentSwingHigh[i] = currentSwingHigh[i];
				priorLastSwingHigh[i] = lastSwingHigh[i];
				priorCurrentSwingLow[i] = currentSwingLow[i];
				priorLastSwingLow[i] = lastSwingLow[i];
				priorRetUp0[i] = retUp0[i];
				priorRetUp23[i] = retUp23[i];
				priorRetUp38[i] = retUp38[i];
				priorRetUp50[i] = retUp50[i];
				priorRetUp62[i] = retUp62[i];
				priorRetUp76[i] = retUp76[i];
				priorRetUp100[i] = retUp100[i];
				priorRetDown0[i] = retDown0[i];
				priorRetDown23[i] = retDown23[i];
				priorRetDown38[i] = retDown38[i];
				priorRetDown50[i] = retDown50[i];
				priorRetDown62[i] = retDown62[i];
				priorRetDown76[i] = retDown76[i];
				priorRetDown100[i] = retDown100[i];
				priorExtUp0[i] = extUp0[i];
				priorExtUp100[i] = extUp100[i];
				priorExtUp127[i] = extUp127[i];
				priorExtUp162[i] = extUp162[i];
				priorExtUp200[i] = extUp200[i];
				priorExtUp262[i] = extUp262[i];
				priorExtUp300[i] = extUp300[i];
				priorExtUp423[i] = extUp423[i];
				priorExtDown0[i] = extDown0[i];
				priorExtDown100[i] = extDown100[i];
				priorExtDown127[i] = extDown127[i];
				priorExtDown162[i] = extDown162[i];
				priorExtDown200[i] = extDown200[i];
				priorExtDown262[i] = extDown262[i];
				priorExtDown300[i] = extDown300[i];
				priorExtDown423[i] = extDown423[i];
				priorLastDirUp38[i] = lastDirUp38[i];
				priorLastDirUp62[i] = lastDirUp62[i];
				priorLastDirUp100[i] = lastDirUp100[i];
				priorLastDirDown38[i] = lastDirDown38[i];
				priorLastDirDown62[i] = lastDirDown62[i];
				priorLastDirDown100[i] = lastDirDown100[i];
				priorDirUp38[i] = dirUp38[i];
				priorDirUp62[i] = dirUp62[i];
				priorDirUp100[i] = dirUp100[i];
				priorDirDown38[i] = dirDown38[i];
				priorDirDown62[i] = dirDown62[i];
				priorDirDown100[i] = dirDown100[i];
				priorLastDirUp38[i] = lastDirUp38[i];
				priorLastDirUp62[i] = lastDirUp62[i];
				priorLastDirUp100[i] = lastDirUp100[i];
				priorLastDirDown38[i] = lastDirDown38[i];
				priorLastDirDown62[i] = lastDirDown62[i];
				priorLastDirDown100[i] = lastDirDown100[i];
				priorDirUp38[i] = dirUp38[i];
				priorDirUp62[i] = dirUp62[i];
				priorDirUp100[i] = dirUp100[i];
				priorDirDown38[i] = dirDown38[i];
				priorDirDown62[i] = dirDown62[i];
				priorDirDown100[i] = dirDown100[i];
				priorAlt0Up62[i] = alt0Up62[i];
				priorAlt0Up100[i] = alt0Up100[i];
				priorAlt0Up162[i] = alt0Up162[i];
				priorAlt1Up100[i] = alt1Up100[i];
				priorAlt0Down62[i] = alt0Down62[i];
				priorAlt0Down100[i] = alt0Down100[i];
				priorAlt0Down162[i] = alt0Down162[i];
				priorAlt1Down100[i] = alt1Down100[i];
				return;
			}

			if (countDown[i] != 1)
				return;

			#region Section to identify ZigZagHighs and ZigZagLows filling them into arrays
			priorCurrentHigh[i] = currentHigh[i];
			priorCurrentLow[i] = currentLow[i];
			priorMicroSwingHigh0[i] = microSwingHigh0[i];
			priorMicroSwingHigh1[i] = microSwingHigh1[i];
			priorMicroSwingHigh2[i] = microSwingHigh2[i];
			priorMicroSwingHigh3[i] = microSwingHigh3[i];
			priorMicroSwingLow0[i] = microSwingLow0[i];
			priorMicroSwingLow1[i] = microSwingLow1[i];
			priorMicroSwingLow2[i] = microSwingLow2[i];
			priorMicroSwingLow3[i] = microSwingLow3[i];

			if (addHigh) // when new high is added, currentLow is validated
			{
				upTrend[i] = true;
				microLow[i, 0] = currentLow[i];
				currentHigh[i] = priorBarHigh;
				if (microLow[i, 0] < microLow[i, 1]) // requires initialization
				{
					existsSwingLow[i] = true;
				}
			}
			else if (highUpdate)
			{
				currentHigh[i] = priorBarHigh;
			}
			else if (addLow) // when new low is added, currentHigh is validated and set to MicroHighArray, microLow[0] is left empty 
			{
				upTrend[i] = false;
				for (var j = 19; j > 0; j--)
				{
					microHigh[i, j] = microHigh[i, j - 1];
					microLow[i, j] = microLow[i, j - 1];
				}

				microHigh[i, 0] = currentHigh[i];
				microLow[i, 0] = double.MinValue; // not yet containing valid information, asymetric code
				currentLow[i] = priorBarLow;
				if (microHigh[i, 0] > microHigh[i, 1]) // requires initialization
				{
					existsSwingHigh[i] = true;
				}
			}
			else if (lowUpdate)
			{
				currentLow[i] = priorBarLow;
			}
			#endregion

			#region Section to calculate Swing Highs and Swing Lows
			priorCurrentSwingHigh[i] = currentSwingHigh[i];
			priorLastSwingHigh[i] = lastSwingHigh[i];
			priorCurrentSwingLow[i] = currentSwingLow[i];
			priorLastSwingLow[i] = lastSwingLow[i];

			if (addLow)
			{
				if (microHigh[i, 0] >= microHigh[i, 1] + double.Epsilon)
				{
					if (currentSwingHighIndex[i] >= 0)
					{
						lastSwingHigh[i] = currentSwingHigh[i];
						lastSwingHighIndex[i] = currentSwingHighIndex[i] + 1;
						if (lastSwingLowIndex[i] >= 0)
						{
							weightLastSwingHigh[i] = SpecificWeightLastSwing * (1.0 + (0.001 * i)) * Math.Sqrt((lastSwingHigh[i] - lastSwingLow[i]) / (zigZagFactor * avgTrueRange));
						}
						else
						{
							weightLastSwingHigh[i] = SpecificWeightLastSwing * (1.0 + (0.001 * i)) * timeFrameMultiplier;
						}
					}

					currentSwingHigh[i] = microHigh[i, 0];
					if (currentSwingLowIndex[i] >= 0)
					{
						weightCurrentSwingHigh[i] = SpecificWeightCurrentSwing * (1.0 + (0.001 * i)) * Math.Sqrt((currentSwingHigh[i] - currentSwingLow[i]) / (zigZagFactor * avgTrueRange));
					}
					else
					{
						weightCurrentSwingHigh[i] = SpecificWeightCurrentSwing * (1.0 + (0.001 * i)) * timeFrameMultiplier;
					}

					currentSwingHighIndex[i] = 0;
				}
				else
				{
					currentSwingHighIndex[i] += 1;
					lastSwingHighIndex[i] += 1;
				}

				currentSwingLowIndex[i] += 1;
				lastSwingLowIndex[i] += 1;
			}

			if (addHigh)
			{
				if (microLow[i, 0] <= microLow[i, 1] - double.Epsilon)
				{
					if (currentSwingLowIndex[i] >= 0)
					{
						lastSwingLow[i] = currentSwingLow[i];
						lastSwingLowIndex[i] = currentSwingLowIndex[i];
						if (lastSwingHighIndex[i] >= 0)
						{
							weightLastSwingLow[i] = SpecificWeightLastSwing * (1.0 + (0.001 * i)) * Math.Sqrt((lastSwingHigh[i] - lastSwingLow[i]) / (zigZagFactor * avgTrueRange));
						}
						else
						{
							weightLastSwingLow[i] = SpecificWeightLastSwing * (1.0 + (0.001 * i)) * timeFrameMultiplier;
						}
					}

					currentSwingLow[i] = microLow[i, 0];
					if (currentSwingHighIndex[i] >= 0)
					{
						weightCurrentSwingLow[i] = SpecificWeightCurrentSwing * (1.0 + (0.001 * i)) * Math.Sqrt((currentSwingHigh[i] - currentSwingLow[i]) / (zigZagFactor * avgTrueRange));
					}
					else
					{
						weightCurrentSwingLow[i] = SpecificWeightCurrentSwing * (1.0 + (0.001 * i)) * timeFrameMultiplier;
					}

					currentSwingLowIndex[i] = 0;
				}
			}
			#endregion

			#region Section to separate Swing Highs from MicroSwing Highs and Swing Lows from MicroSwing Lows
			highCount = 0;

			if (addLow)
			{
				if (currentSwingHighIndex[i] != highCount)
				{
					microSwingHigh0[i] = microHigh[i, highCount];
					highCount++;
				}
				else if (lastSwingHighIndex[i] != highCount + 1)
				{
					microSwingHigh0[i] = microHigh[i, highCount + 1];
					highCount += 2;
				}
				else
				{
					microSwingHigh0[i] = microHigh[i, highCount + 2];
					highCount += 3;
				}

				if (currentSwingHighIndex[i] != highCount && lastSwingHighIndex[i] != highCount)
				{
					microSwingHigh1[i] = microHigh[i, highCount];
					highCount++;
				}
				else if (lastSwingHighIndex[i] != highCount + 1)
				{
					microSwingHigh1[i] = microHigh[i, highCount + 1];
					highCount += 2;
				}
				else
				{
					microSwingHigh1[i] = microHigh[i, highCount + 2];
					highCount += 3;
				}

				if (currentSwingHighIndex[i] != highCount && lastSwingHighIndex[i] != highCount)
				{
					microSwingHigh2[i] = microHigh[i, highCount];
					highCount++;
				}
				else if (lastSwingHighIndex[i] != highCount + 1)
				{
					microSwingHigh2[i] = microHigh[i, highCount + 1];
					highCount += 2;
				}
				else
				{
					microSwingHigh2[i] = microHigh[i, highCount + 2];
					highCount += 3;
				}

				if (currentSwingHighIndex[i] != highCount && lastSwingHighIndex[i] != highCount)
				{
					microSwingHigh3[i] = microHigh[i, highCount];
					highCount++;
				}
				else if (lastSwingHighIndex[i] != highCount + 1)
				{
					microSwingHigh3[i] = microHigh[i, highCount + 1];
					highCount += 2;
				}
				else
				{
					microSwingHigh3[i] = microHigh[i, highCount + 2];
					highCount += 3;
				}

				weightMicroSwingHigh0[i] = SpecificWeightMicroSwing0 * (1.0 + (0.001 * i)) * timeFrameMultiplier;
				weightMicroSwingHigh1[i] = SpecificWeightMicroSwing1 * (1.0 + (0.001 * i)) * timeFrameMultiplier;
				weightMicroSwingHigh2[i] = SpecificWeightMicroSwing2 * (1.0 + (0.001 * i)) * timeFrameMultiplier;
				weightMicroSwingHigh3[i] = SpecificWeightMicroSwing3 * (1.0 + (0.001 * i)) * timeFrameMultiplier;
			}

			lowCount = 0;

			if (addHigh)
			{
				if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
				{
					microSwingLow0[i] = microLow[i, lowCount];
					lowCount++;
				}
				else if (lastSwingLowIndex[i] != lowCount + 1)
				{
					microSwingLow0[i] = microLow[i, lowCount + 1];
					lowCount += 2;
				}
				else
				{
					microSwingLow0[i] = microLow[i, lowCount + 2];
					lowCount += 3;
				}

				if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
				{
					microSwingLow1[i] = microLow[i, lowCount];
					lowCount++;
				}
				else if (lastSwingLowIndex[i] != lowCount + 1)
				{
					microSwingLow1[i] = microLow[i, lowCount + 1];
					lowCount += 2;
				}
				else
				{
					microSwingLow1[i] = microLow[i, lowCount + 2];
					lowCount += 3;
				}

				if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
				{
					microSwingLow2[i] = microLow[i, lowCount];
					lowCount++;
				}
				else if (lastSwingLowIndex[i] != lowCount + 1)
				{
					microSwingLow2[i] = microLow[i, lowCount + 1];
					lowCount += 2;
				}
				else
				{
					microSwingLow2[i] = microLow[i, lowCount + 2];
					lowCount += 3;
				}

				if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
				{
					microSwingLow3[i] = microLow[i, lowCount];
					lowCount++;
				}
				else if (lastSwingLowIndex[i] != lowCount + 1)
				{
					microSwingLow3[i] = microLow[i, lowCount + 1];
					lowCount += 2;
				}
				else
				{
					microSwingLow3[i] = microLow[i, lowCount + 2];
					lowCount += 3;
				}

				weightMicroSwingLow0[i] = SpecificWeightMicroSwing0 * (1.0 + (0.001 * i)) * timeFrameMultiplier;
				weightMicroSwingLow1[i] = SpecificWeightMicroSwing1 * (1.0 + (0.001 * i)) * timeFrameMultiplier;
				weightMicroSwingLow2[i] = SpecificWeightMicroSwing2 * (1.0 + (0.001 * i)) * timeFrameMultiplier;
				weightMicroSwingLow3[i] = SpecificWeightMicroSwing3 * (1.0 + (0.001 * i)) * timeFrameMultiplier;
			}
			#endregion

			#region Section to calculate Retracements from last Swing High and last Swing Low
			priorRetUp0[i] = retUp0[i];
			priorRetUp23[i] = retUp23[i];
			priorRetUp38[i] = retUp38[i];
			priorRetUp50[i] = retUp50[i];
			priorRetUp62[i] = retUp62[i];
			priorRetUp76[i] = retUp76[i];
			priorRetUp100[i] = retUp100[i];
			priorRetDown0[i] = retDown0[i];
			priorRetDown23[i] = retDown23[i];
			priorRetDown38[i] = retDown38[i];
			priorRetDown50[i] = retDown50[i];
			priorRetDown62[i] = retDown62[i];
			priorRetDown76[i] = retDown76[i];
			priorRetDown100[i] = retDown100[i];

			if (microHigh[i, 0] < double.MaxValue && (addLow || lowUpdate))
			{
				retUp0[i] = currentLow[i];
				retUp100[i] = microHigh[i, 0];
				retUp23[i] = retUp0[i] + (0.236 * (retUp100[i] - retUp0[i]));
				retUp38[i] = retUp0[i] + (0.382 * (retUp100[i] - retUp0[i]));
				retUp50[i] = retUp0[i] + (0.50 * (retUp100[i] - retUp0[i]));
				retUp62[i] = retUp0[i] + (0.618 * (retUp100[i] - retUp0[i]));
				retUp76[i] = retUp0[i] + (0.764 * (retUp100[i] - retUp0[i]));
				normalizedRangeUp = (1.0 + (0.001 * i)) * Math.Sqrt((retUp100[i] - retUp0[i]) / (zigZagFactor * avgTrueRange));
				weightRetUp23[i] = SpecificWeightRet23 * normalizedRangeUp;
				weightRetUp38[i] = SpecificWeightRet38 * normalizedRangeUp;
				weightRetUp50[i] = SpecificWeightRet50 * normalizedRangeUp;
				weightRetUp62[i] = SpecificWeightRet62 * normalizedRangeUp;
				weightRetUp76[i] = SpecificWeightRet76 * normalizedRangeUp;
			}

			if (microLow[i, 0] > double.MinValue && (addHigh || highUpdate))
			{
				retDown0[i] = currentHigh[i];
				retDown100[i] = microLow[i, 0];
				retDown23[i] = retDown0[i] + (0.236 * (retDown100[i] - retDown0[i]));
				retDown38[i] = retDown0[i] + (0.382 * (retDown100[i] - retDown0[i]));
				retDown50[i] = retDown0[i] + (0.50 * (retDown100[i] - retDown0[i]));
				retDown62[i] = retDown0[i] + (0.618 * (retDown100[i] - retDown0[i]));
				retDown76[i] = retDown0[i] + (0.764 * (retDown100[i] - retDown0[i]));
				normalizedRangeDown = (1.0 + (0.001 * i)) * Math.Sqrt((retDown0[i] - retDown100[i]) / (zigZagFactor * avgTrueRange));
				weightRetDown23[i] = SpecificWeightRet23 * normalizedRangeDown;
				weightRetDown38[i] = SpecificWeightRet38 * normalizedRangeDown;
				weightRetDown50[i] = SpecificWeightRet50 * normalizedRangeDown;
				weightRetDown62[i] = SpecificWeightRet62 * normalizedRangeDown;
				weightRetDown76[i] = SpecificWeightRet76 * normalizedRangeDown;
			}

			if (addHigh || highUpdate)
			{
				normalizedRangeUp = (1.0 + (0.001 * i)) * Math.Sqrt((retUp100[i] - retUp0[i]) / (zigZagFactor * avgTrueRange));
				if (currentBarClose > retUp38[i])
				{
					weightRetUp23[i] = DevalueRet * SpecificWeightRet23 * normalizedRangeUp;
				}

				if (currentBarClose > retUp50[i])
				{
					weightRetUp38[i] = DevalueRet * SpecificWeightRet38 * normalizedRangeUp;
				}

				if (currentBarClose > retUp62[i])
				{
					weightRetUp50[i] = DevalueRet * SpecificWeightRet50 * normalizedRangeUp;
				}

				if (currentBarClose > retUp76[i])
				{
					weightRetUp62[i] = DevalueRet * SpecificWeightRet62 * normalizedRangeUp;
				}

				if (currentBarClose > retUp100[i])
				{
					weightRetUp76[i] = DevalueRet * SpecificWeightRet76 * normalizedRangeUp;
				}
			}

			if (addLow || lowUpdate)
			{
				normalizedRangeDown = (1.0 + (0.001 * i)) * Math.Sqrt((retDown0[i] - retDown100[i]) / (zigZagFactor * avgTrueRange));
				if (currentBarClose < retDown38[i])
					weightRetDown23[i] = DevalueRet * SpecificWeightRet23 * normalizedRangeDown;

				if (currentBarClose < retDown50[i])
					weightRetDown38[i] = DevalueRet * SpecificWeightRet38 * normalizedRangeDown;

				if (currentBarClose < retDown62[i])
					weightRetDown50[i] = DevalueRet * SpecificWeightRet50 * normalizedRangeDown;

				if (currentBarClose < retDown76[i])
					weightRetDown62[i] = DevalueRet * SpecificWeightRet62 * normalizedRangeDown;

				if (currentBarClose < retDown100[i])
					weightRetDown76[i] = DevalueRet * SpecificWeightRet76 * normalizedRangeDown;
			}
			#endregion

			#region Section to calculate External Retracements from MicroHighs and MicroLows
			priorExtUp0[i] = extUp0[i];
			priorExtUp100[i] = extUp100[i];
			priorExtUp127[i] = extUp127[i];
			priorExtUp162[i] = extUp162[i];
			priorExtUp200[i] = extUp200[i];
			priorExtUp262[i] = extUp262[i];
			priorExtUp300[i] = extUp300[i];
			priorExtUp423[i] = extUp423[i];
			priorExtDown0[i] = extDown0[i];
			priorExtDown100[i] = extDown100[i];
			priorExtDown127[i] = extDown127[i];
			priorExtDown162[i] = extDown162[i];
			priorExtDown200[i] = extDown200[i];
			priorExtDown262[i] = extDown262[i];
			priorExtDown300[i] = extDown300[i];
			priorExtDown423[i] = extDown423[i];

			if (microHigh[i, 0] < double.MaxValue && (addLow || lowUpdate))
			{
				extUp0[i] = currentLow[i];
				extUp100[i] = microHigh[i, 0];
				extUp127[i] = extUp0[i] + (1.272 * (extUp100[i] - extUp0[i]));
				extUp162[i] = extUp0[i] + (1.618 * (extUp100[i] - extUp0[i]));
				extUp200[i] = extUp0[i] + (2.0 * (extUp100[i] - extUp0[i]));
				extUp262[i] = extUp0[i] + (2.618 * (extUp100[i] - extUp0[i]));
				extUp300[i] = extUp0[i] + (3.0 * (extUp100[i] - extUp0[i]));
				extUp423[i] = extUp0[i] + (4.236 * (extUp100[i] - extUp0[i]));
				normalizedRangeUp = (1.0 + (0.001 * i)) * Math.Sqrt((extUp100[i] - extUp0[i]) / (zigZagFactor * avgTrueRange));
				weightExtUp127[i] = SpecificWeightExt127 * normalizedRangeUp;
				weightExtUp162[i] = SpecificWeightExt162 * normalizedRangeUp;
				weightExtUp200[i] = SpecificWeightExt200 * normalizedRangeUp;
				weightExtUp262[i] = SpecificWeightExt262 * normalizedRangeUp;
				weightExtUp300[i] = SpecificWeightExt300 * normalizedRangeUp;
				weightExtUp423[i] = SpecificWeightExt423 * normalizedRangeUp;
			}

			if (microLow[i, 0] > double.MinValue && (addHigh || highUpdate))
			{
				extDown0[i] = currentHigh[i];
				extDown100[i] = microLow[i, 0];
				extDown127[i] = extDown0[i] + (1.272 * (extDown100[i] - extDown0[i]));
				extDown162[i] = extDown0[i] + (1.618 * (extDown100[i] - extDown0[i]));
				extDown200[i] = extDown0[i] + (2.0 * (extDown100[i] - extDown0[i]));
				extDown262[i] = extDown0[i] + (2.618 * (extDown100[i] - extDown0[i]));
				extDown300[i] = extDown0[i] + (3.0 * (extDown100[i] - extDown0[i]));
				extDown423[i] = extDown0[i] + (4.236 * (extDown100[i] - extDown0[i]));
				normalizedRangeDown = (1.0 + (0.001 * i)) * Math.Sqrt((extDown0[i] - extDown100[i]) / (zigZagFactor * avgTrueRange));
				weightExtDown127[i] = SpecificWeightExt127 * normalizedRangeDown;
				weightExtDown162[i] = SpecificWeightExt162 * normalizedRangeDown;
				weightExtDown200[i] = SpecificWeightExt200 * normalizedRangeDown;
				weightExtDown262[i] = SpecificWeightExt262 * normalizedRangeDown;
				weightExtDown300[i] = SpecificWeightExt300 * normalizedRangeDown;
				weightExtDown423[i] = SpecificWeightExt423 * normalizedRangeDown;
			}

			if (addHigh || highUpdate)
			{
				normalizedRangeUp = (1.0 + (0.001 * i)) * Math.Sqrt((extUp100[i] - extUp0[i]) / (zigZagFactor * avgTrueRange));
				if (currentBarClose > extUp162[i])
				{
					weightExtUp127[i] = DevalueExt * SpecificWeightExt127 * normalizedRangeUp;
				}

				if (currentBarClose > extUp200[i])
				{
					weightExtUp162[i] = DevalueExt * SpecificWeightExt162 * normalizedRangeUp;
				}

				if (currentBarClose > extUp262[i])
				{
					weightExtUp200[i] = DevalueExt * SpecificWeightExt200 * normalizedRangeUp;
				}

				if (currentBarClose > extUp300[i])
				{
					weightExtUp262[i] = DevalueExt * SpecificWeightExt262 * normalizedRangeUp;
				}

				if (currentBarClose > extUp423[i])
				{
					weightExtUp300[i] = DevalueExt * SpecificWeightExt300 * normalizedRangeUp;
				}

				if (currentBarClose > extUp0[i] + (5.0 * (extUp100[i] - extUp0[i])))
				{
					weightExtUp423[i] = DevalueExt * SpecificWeightExt423 * normalizedRangeUp;
				}
			}

			if (addLow || lowUpdate)
			{
				normalizedRangeDown = (1.0 + (0.001 * i)) * Math.Sqrt((extDown0[i] - extDown100[i]) / (zigZagFactor * avgTrueRange));
				if (currentBarClose < extDown162[i])
				{
					weightExtDown127[i] = DevalueExt * SpecificWeightExt127 * normalizedRangeDown;
				}

				if (currentBarClose < extDown200[i])
				{
					weightExtDown162[i] = DevalueExt * SpecificWeightExt162 * normalizedRangeDown;
				}

				if (currentBarClose < extDown262[i])
				{
					weightExtDown200[i] = DevalueExt * SpecificWeightExt200 * normalizedRangeDown;
				}

				if (currentBarClose < extDown300[i])
				{
					weightExtDown262[i] = DevalueExt * SpecificWeightExt262 * normalizedRangeDown;
				}

				if (currentBarClose < extDown423[i])
				{
					weightExtDown300[i] = DevalueExt * SpecificWeightExt300 * normalizedRangeDown;
				}

				if (currentBarClose < extDown0[i] + (5.0 * (extDown100[i] - extDown0[i])))
				{
					weightExtDown423[i] = DevalueExt * SpecificWeightExt423 * normalizedRangeDown;
				}
			}
			#endregion

			#region Section to calculate Direct Projections
			priorLastDirUp38[i] = lastDirUp38[i];
			priorLastDirUp62[i] = lastDirUp62[i];
			priorLastDirUp100[i] = lastDirUp100[i];
			priorLastDirDown38[i] = lastDirDown38[i];
			priorLastDirDown62[i] = lastDirDown62[i];
			priorLastDirDown100[i] = lastDirDown100[i];
			priorDirUp38[i] = dirUp38[i];
			priorDirUp62[i] = dirUp62[i];
			priorDirUp100[i] = dirUp100[i];
			priorDirDown38[i] = dirDown38[i];
			priorDirDown62[i] = dirDown62[i];
			priorDirDown100[i] = dirDown100[i];

			if (microHigh[i, 0] < double.MaxValue && microLow[i, 1] > double.MinValue && addLow)
			{
				lastDirUp38[i] = dirUp38[i];
				lastDirUp62[i] = dirUp62[i];
				lastDirUp100[i] = dirUp100[i];
				if (SpecificWeightDir38 > 0)
				{
					weightLastDirUp38[i] = weightDirUp38[i] * SpecificWeightLastDir38 / SpecificWeightDir38;
				}
				else
				{
					weightLastDirUp38[i] = 0;
				}

				if (SpecificWeightDir62 > 0)
				{
					weightLastDirUp62[i] = weightDirUp62[i] * SpecificWeightLastDir62 / SpecificWeightDir62;
				}
				else
				{
					weightLastDirUp62[i] = 0;
				}

				if (SpecificWeightDir100 > 0)
				{
					weightLastDirUp100[i] = weightDirUp100[i] * SpecificWeightLastDir100 / SpecificWeightDir100;
				}
				else
				{
					weightLastDirUp100[i] = 0;
				}

				dirUp38[i] = microHigh[i, 0] + (0.382 * (microHigh[i, 0] - microLow[i, 1]));
				dirUp62[i] = microHigh[i, 0] + (0.618 * (microHigh[i, 0] - microLow[i, 1]));
				dirUp100[i] = (2 * microHigh[i, 0]) - microLow[i, 1];

				normalizedRangeUp = (1.0 + (0.001 * i)) *
									Math.Sqrt((microHigh[i, 0] - microLow[i, 1]) / (zigZagFactor * avgTrueRange));
				weightDirUp38[i] = SpecificWeightDir38 * normalizedRangeUp;
				weightDirUp62[i] = SpecificWeightDir62 * normalizedRangeUp;
				weightDirUp100[i] = SpecificWeightDir100 * normalizedRangeUp;
			}

			if (microHigh[i, 0] < double.MaxValue && microLow[i, 0] > double.MinValue && addHigh)
			{
				lastDirDown38[i] = dirDown38[i];
				lastDirDown62[i] = dirDown62[i];
				lastDirDown100[i] = dirDown100[i];
				if (SpecificWeightDir38 > 0)
				{
					weightLastDirDown38[i] = weightDirDown38[i] * SpecificWeightLastDir38 / SpecificWeightDir38;
				}
				else
				{
					weightLastDirDown38[i] = 0;
				}

				if (SpecificWeightDir62 > 0)
				{
					weightLastDirDown62[i] = weightDirDown62[i] * SpecificWeightLastDir62 / SpecificWeightDir62;
				}
				else
				{
					weightLastDirDown62[i] = 0;
				}

				if (SpecificWeightDir100 > 0)
				{
					weightLastDirDown100[i] = weightDirDown100[i] * SpecificWeightLastDir100 / SpecificWeightDir100;
				}
				else
				{
					weightLastDirDown100[i] = 0;
				}

				dirDown38[i] = microLow[i, 0] + (0.382 * (microLow[i, 0] - microHigh[i, 0]));
				dirDown62[i] = microLow[i, 0] + (0.618 * (microLow[i, 0] - microHigh[i, 0]));
				dirDown100[i] = (2 * microLow[i, 0]) - microHigh[i, 0];
				normalizedRangeDown = (1.0 + (0.001 * i)) * Math.Sqrt((microHigh[i, 0] - microLow[i, 0]) / (zigZagFactor * avgTrueRange));
				weightDirDown38[i] = SpecificWeightDir38 * normalizedRangeDown;
				weightDirDown62[i] = SpecificWeightDir62 * normalizedRangeDown;
				weightDirDown100[i] = SpecificWeightDir100 * normalizedRangeDown;
			}

			if (addHigh || highUpdate)
			{
				if (microHigh[i, 1] < double.MaxValue && microLow[i, 2] > double.MinValue)
				{
					normalizedRangeUp = (1.0 + (0.001 * i)) * Math.Sqrt((microHigh[i, 1] - microLow[i, 2]) / (zigZagFactor * avgTrueRange));
					if (currentBarClose > lastDirUp62[i])
					{
						weightLastDirUp38[i] = DevalueDir * SpecificWeightLastDir38 * normalizedRangeUp;
					}

					if (currentBarClose > lastDirUp100[i])
					{
						weightLastDirUp62[i] = DevalueDir * SpecificWeightLastDir62 * normalizedRangeUp;
					}

					if (currentBarClose > (2 * lastDirUp100[i]) - lastDirUp62[i])
					{
						weightLastDirUp100[i] = DevalueDir * SpecificWeightLastDir100 * normalizedRangeUp;
					}
				}

				if (microHigh[i, 0] < double.MaxValue && microLow[i, 1] > double.MinValue)
				{
					normalizedRangeUp = (1.0 + (0.001 * i)) * Math.Sqrt((microHigh[i, 0] - microLow[i, 1]) / (zigZagFactor * avgTrueRange));
					if (currentBarClose > dirUp62[i])
					{
						weightDirUp38[i] = DevalueDir * SpecificWeightDir38 * normalizedRangeUp;
					}

					if (currentBarClose > dirUp100[i])
					{
						weightDirUp62[i] = DevalueDir * SpecificWeightDir62 * normalizedRangeUp;
					}

					if (currentBarClose > (2 * dirUp100[i]) - dirUp62[i])
					{
						weightDirUp100[i] = DevalueDir * SpecificWeightDir100 * normalizedRangeUp;
					}
				}
			}

			if (addLow || lowUpdate)
			{
				if (microHigh[i, 2] < double.MaxValue && microLow[i, 2] > double.MinValue)
				{
					normalizedRangeDown = (1.0 + (0.001 * i)) * Math.Sqrt((microHigh[i, 2] - microLow[i, 2]) / (zigZagFactor * avgTrueRange));
					if (currentBarClose < lastDirDown62[i])
					{
						weightLastDirDown38[i] = DevalueDir * SpecificWeightLastDir38 * normalizedRangeDown;
					}

					if (currentBarClose < lastDirDown100[i])
					{
						weightLastDirDown62[i] = DevalueDir * SpecificWeightLastDir62 * normalizedRangeDown;
					}

					if (currentBarClose < (2 * lastDirDown100[i]) - lastDirDown62[i])
					{
						weightLastDirDown100[i] = DevalueDir * SpecificWeightLastDir100 * normalizedRangeDown;
					}
				}

				if (microHigh[i, 1] < double.MaxValue && microLow[i, 1] > double.MinValue)
				{
					normalizedRangeDown = (1.0 + (0.001 * i)) * Math.Sqrt((microHigh[i, 1] - microLow[i, 1]) / (zigZagFactor * avgTrueRange));
					if (currentBarClose < dirDown62[i])
					{
						weightDirDown38[i] = DevalueDir * SpecificWeightDir38 * normalizedRangeDown;
					}

					if (currentBarClose < dirDown100[i])
					{
						weightDirDown62[i] = DevalueDir * SpecificWeightDir62 * normalizedRangeDown;
					}

					if (currentBarClose < (2 * dirDown100[i]) - dirDown62[i])
					{
						weightDirDown100[i] = DevalueDir * SpecificWeightDir100 * normalizedRangeDown;
					}
				}
			}
			#endregion

			#region Section to calculate Alternate Projections
			priorAlt0Up62[i] = alt0Up62[i];
			priorAlt0Up100[i] = alt0Up100[i];
			priorAlt0Up162[i] = alt0Up162[i];
			priorAlt1Up100[i] = alt1Up100[i];
			priorAlt0Down62[i] = alt0Down62[i];
			priorAlt0Down100[i] = alt0Down100[i];
			priorAlt0Down162[i] = alt0Down162[i];
			priorAlt1Down100[i] = alt1Down100[i];

			if (microHigh[i, 1] < double.MaxValue && microLow[i, 2] > double.MinValue && (addLow || lowUpdate))
			{
				alt0Up[i] = microHigh[i, 0] - microLow[i, 1];
				alt1Up[i] = microHigh[i, 1] - microLow[i, 2];
				alt0Up62[i] = currentLow[i] + (0.618 * alt0Up[i]);
				alt0Up100[i] = currentLow[i] + alt0Up[i];
				alt0Up162[i] = currentLow[i] + (1.618 * alt0Up[i]);
				alt1Up100[i] = currentLow[i] + alt1Up[i];
				normalizedRangeUp = (1.0 + (0.001 * i)) * Math.Sqrt(alt0Up[i] / (zigZagFactor * avgTrueRange));
				weightAlt0Up62[i] = SpecificWeightAlt62 * normalizedRangeUp;
				weightAlt0Up100[i] = SpecificWeightAlt100 * normalizedRangeUp;
				weightAlt0Up162[i] = SpecificWeightAlt162 * normalizedRangeUp;
				weightAlt1Up100[i] = SpecificWeightAlt100Prior * (1.0 + (0.001 * i)) * Math.Sqrt(alt1Up[i] / (zigZagFactor * avgTrueRange));
			}

			if (microHigh[i, 1] < double.MaxValue && microLow[i, 1] > double.MinValue && (addHigh || highUpdate))
			{
				alt0Down[i] = microHigh[i, 0] - microLow[i, 0];
				alt1Down[i] = microHigh[i, 1] - microLow[i, 1];
				alt0Down62[i] = currentHigh[i] - (0.618 * alt0Down[i]);
				alt0Down100[i] = currentHigh[i] - alt0Down[i];
				alt0Down162[i] = currentHigh[i] - (1.618 * alt0Down[i]);
				alt1Down100[i] = currentHigh[i] - alt1Down[i];
				normalizedRangeDown = (1.0 + (0.001 * i)) * Math.Sqrt(alt0Down[i] / (zigZagFactor * avgTrueRange));
				weightAlt0Down62[i] = SpecificWeightAlt62 * normalizedRangeDown;
				weightAlt0Down100[i] = SpecificWeightAlt100 * normalizedRangeDown;
				weightAlt0Down162[i] = SpecificWeightAlt162 * normalizedRangeDown;
				normalizedRangeDown = Math.Sqrt(alt1Down[i] / (zigZagFactor * avgTrueRange));
				weightAlt1Down100[i] = SpecificWeightAlt100Prior * (1.0 + (0.001 * i)) * Math.Sqrt(alt1Down[i] / (zigZagFactor * avgTrueRange));
			}

			if (addHigh || highUpdate)
			{
				normalizedRangeUp = (1.0 + (0.001 * i)) * Math.Sqrt(alt0Up[i] / (zigZagFactor * avgTrueRange));
				if (currentBarClose > alt0Up100[i])
				{
					weightAlt0Up62[i] = DevalueAlt * SpecificWeightAlt62 * normalizedRangeUp;
				}

				if (currentBarClose > alt0Up162[i])
				{
					weightAlt0Up100[i] = DevalueAlt * SpecificWeightAlt100 * normalizedRangeUp;
				}

				if (currentBarClose > alt0Up100[i] + alt0Up[i])
				{
					weightAlt0Up162[i] = DevalueAlt * SpecificWeightAlt162 * normalizedRangeUp;
				}

				if (currentBarClose > alt1Up100[i] + (0.62 * alt1Up[i]))
				{
					weightAlt1Up100[i] = DevalueAlt * SpecificWeightAlt100Prior * (1.0 + (0.001 * i)) * Math.Sqrt(alt1Up[i] / (zigZagFactor * avgTrueRange));
				}
			}

			if (addLow || lowUpdate)
			{
				normalizedRangeDown = (1.0 + (0.001 * i)) * Math.Sqrt(alt0Down[i] / (zigZagFactor * avgTrueRange));
				if (currentBarClose < alt0Down100[i])
				{
					weightAlt0Down62[i] = DevalueAlt * SpecificWeightAlt62 * normalizedRangeDown;
				}

				if (currentBarClose < alt0Down162[i])
				{
					weightAlt0Down100[i] = DevalueAlt * SpecificWeightAlt100 * normalizedRangeDown;
				}

				if (currentBarClose < alt0Down100[i] + alt0Down[i])
				{
					weightAlt0Down162[i] = DevalueAlt * SpecificWeightAlt162 * normalizedRangeDown;
				}

				if (currentBarClose < alt1Down100[i] + (0.62 * alt1Down[i]))
				{
					weightAlt1Down100[i] = DevalueAlt * SpecificWeightAlt100Prior * (1.0 + (0.001 * i)) * Math.Sqrt(alt1Down[i] / (zigZagFactor * avgTrueRange));
				}
			}
			#endregion
		}

		/// <summary>
		/// Writing all Fib Lines and Fib Weights to two separate Arrays that can be sorted
		/// </summary>
		public void SetLinesAndWeights()
		{
			countLine = 0;
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				#region Section to set Support and Resistance from previous Swing Highs and Swing Lows (max. 12 Values calculated and displayed)
				if (microSwingHigh0[i] < double.MaxValue)
				{
					fibLine[countLine] = microSwingHigh0[i];
					fibWeight[countLine] = weightMicroSwingHigh0[i];
					countLine++;
				}

				if (microSwingHigh1[i] < double.MaxValue)
				{
					fibLine[countLine] = microSwingHigh1[i];
					fibWeight[countLine] = weightMicroSwingHigh1[i];
					countLine++;
				}

				if (microSwingHigh2[i] < double.MaxValue)
				{
					fibLine[countLine] = microSwingHigh2[i];
					fibWeight[countLine] = weightMicroSwingHigh2[i];
					countLine++;
				}

				if (microSwingHigh3[i] < double.MaxValue)
				{
					fibLine[countLine] = microSwingHigh3[i];
					fibWeight[countLine] = weightMicroSwingHigh3[i];
					countLine++;
				}

				if (microSwingLow0[i] > double.MinValue)
				{
					fibLine[countLine] = microSwingLow0[i];
					fibWeight[countLine] = weightMicroSwingLow0[i];
					countLine++;
				}

				if (microSwingLow1[i] > double.MinValue)
				{
					fibLine[countLine] = microSwingLow1[i];
					fibWeight[countLine] = weightMicroSwingLow1[i];
					countLine++;
				}

				if (microSwingLow2[i] > double.MinValue)
				{
					fibLine[countLine] = microSwingLow2[i];
					fibWeight[countLine] = weightMicroSwingLow2[i];
					countLine++;
				}

				if (microSwingLow3[i] > double.MinValue)
				{
					fibLine[countLine] = microSwingLow3[i];
					fibWeight[countLine] = weightMicroSwingLow3[i];
					countLine++;
				}

				if (existsSwingHigh[i])
				{
					fibLine[countLine] = currentSwingHigh[i];
					fibWeight[countLine] = weightCurrentSwingHigh[i];
					countLine++;
					if (lastSwingHigh[i] < double.MaxValue)
					{
						fibLine[countLine] = lastSwingHigh[i];
						fibWeight[countLine] = weightLastSwingHigh[i];
						countLine++;
					}
				}

				if (existsSwingLow[i])
				{
					fibLine[countLine] = currentSwingLow[i];
					fibWeight[countLine] = weightCurrentSwingLow[i];
					countLine++;
					if (lastSwingLow[i] > double.MinValue)
					{
						fibLine[countLine] = lastSwingLow[i];
						fibWeight[countLine] = weightLastSwingLow[i];
						countLine++;
					}
				}
				#endregion

				#region Section to set Retracements from last Swing High and last Swing Low (max. 8 Values calculated and displayed)
				fibLine[countLine] = retUp23[i];
				fibWeight[countLine] = weightRetUp23[i];
				countLine++;

				fibLine[countLine] = retUp38[i];
				fibWeight[countLine] = weightRetUp38[i];
				countLine++;

				fibLine[countLine] = retUp50[i];
				fibWeight[countLine] = weightRetUp50[i];
				countLine++;

				fibLine[countLine] = retUp62[i];
				fibWeight[countLine] = weightRetUp62[i];
				countLine++;

				fibLine[countLine] = retUp76[i];
				fibWeight[countLine] = weightRetUp76[i];
				countLine++;

				fibLine[countLine] = retDown23[i];
				fibWeight[countLine] = weightRetDown23[i];
				countLine++;

				fibLine[countLine] = retDown38[i];
				fibWeight[countLine] = weightRetDown38[i];
				countLine++;

				fibLine[countLine] = retDown50[i];
				fibWeight[countLine] = weightRetDown50[i];
				countLine++;

				fibLine[countLine] = retDown62[i];
				fibWeight[countLine] = weightRetDown62[i];
				countLine++;

				fibLine[countLine] = retDown76[i];
				fibWeight[countLine] = weightRetDown76[i];
				countLine++;
				#endregion

				#region Section to set External Retracements from MicroHighs and MicroLows (max. 12 Values calculated and displayed)
				fibLine[countLine] = extUp127[i];
				fibWeight[countLine] = weightExtUp127[i];
				countLine++;

				fibLine[countLine] = extUp162[i];
				fibWeight[countLine] = weightExtUp162[i];
				countLine++;

				fibLine[countLine] = extUp200[i];
				fibWeight[countLine] = weightExtUp200[i];
				countLine++;

				fibLine[countLine] = extUp262[i];
				fibWeight[countLine] = weightExtUp262[i];
				countLine++;

				fibLine[countLine] = extUp300[i];
				fibWeight[countLine] = weightExtUp300[i];
				countLine++;

				fibLine[countLine] = extUp423[i];
				fibWeight[countLine] = weightExtUp423[i];
				countLine++;

				fibLine[countLine] = extDown127[i];
				fibWeight[countLine] = weightExtDown127[i];
				countLine++;

				fibLine[countLine] = extDown162[i];
				fibWeight[countLine] = weightExtDown162[i];
				countLine++;

				fibLine[countLine] = extDown200[i];
				fibWeight[countLine] = weightExtDown200[i];
				countLine++;

				fibLine[countLine] = extDown262[i];
				fibWeight[countLine] = weightExtDown262[i];
				countLine++;

				fibLine[countLine] = extDown300[i];
				fibWeight[countLine] = weightExtDown300[i];
				countLine++;

				fibLine[countLine] = extDown423[i];
				fibWeight[countLine] = weightExtDown423[i];
				countLine++;
				#endregion

				#region Section to calculate Direct Projections (max. 12 Values calculated and displayed)
				fibLine[countLine] = dirUp38[i];
				fibWeight[countLine] = weightDirUp38[i];
				countLine++;

				fibLine[countLine] = dirUp62[i];
				fibWeight[countLine] = weightDirUp62[i];
				countLine++;

				fibLine[countLine] = dirUp100[i];
				fibWeight[countLine] = weightDirUp100[i];
				countLine++;

				fibLine[countLine] = dirDown38[i];
				fibWeight[countLine] = weightDirDown38[i];
				countLine++;

				fibLine[countLine] = dirDown62[i];
				fibWeight[countLine] = weightDirDown62[i];
				countLine++;

				fibLine[countLine] = dirDown100[i];
				fibWeight[countLine] = weightDirDown100[i];
				countLine++;

				fibLine[countLine] = lastDirUp38[i];
				fibWeight[countLine] = weightLastDirUp38[i];
				countLine++;

				fibLine[countLine] = lastDirUp62[i];
				fibWeight[countLine] = weightLastDirUp62[i];
				countLine++;

				fibLine[countLine] = lastDirUp100[i];
				fibWeight[countLine] = weightLastDirUp100[i];
				countLine++;

				fibLine[countLine] = lastDirDown38[i];
				fibWeight[countLine] = weightLastDirDown38[i];
				countLine++;

				fibLine[countLine] = lastDirDown62[i];
				fibWeight[countLine] = weightLastDirDown62[i];
				countLine++;

				fibLine[countLine] = lastDirDown100[i];
				fibWeight[countLine] = weightLastDirDown100[i];
				countLine++;
				#endregion

				#region Section to calculate Alternate Projections (max. 8 Values calculated and displayed)
				if (alt0Up[i] > 1.272 * alt1Up[i])
				{
					fibLine[countLine] = alt0Up62[i];
					fibWeight[countLine] = weightAlt0Up62[i];
					countLine++;
				}

				fibLine[countLine] = alt0Up100[i];
				fibWeight[countLine] = weightAlt0Up100[i];
				countLine++;

				fibLine[countLine] = alt0Up162[i];
				fibWeight[countLine] = weightAlt0Up162[i];
				countLine++;

				fibLine[countLine] = alt1Up100[i];
				fibWeight[countLine] = weightAlt1Up100[i];
				countLine++;

				if (alt0Down[i] > 1.272 * alt1Down[i])
				{
					fibLine[countLine] = alt0Down62[i];
					fibWeight[countLine] = weightAlt0Down62[i];
					countLine++;
				}

				fibLine[countLine] = alt0Down100[i];
				fibWeight[countLine] = weightAlt0Down100[i];
				countLine++;

				fibLine[countLine] = alt0Down162[i];
				fibWeight[countLine] = weightAlt0Down162[i];
				countLine++;

				fibLine[countLine] = alt1Down100[i];
				fibWeight[countLine] = weightAlt1Down100[i];
				countLine++;
				#endregion
			}

			// Select all Resistance and Support Lines within the Display Range and Determine Compounded Weight of Each Line		
			initialWeight = 0;
			compoundedWeight = 0;
			highestWeight = 0;

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				#region swings
				var dummy = cumWeightMicroSwingHigh0[i];
				cumWeightMicroSwingHigh0[i] = 0;
				if (microSwingHigh0[i] >= lowerLimitSupport && microSwingHigh0[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingHigh0[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingHigh0[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingHigh0[i] == microSwingHigh0[i])
						{
							cumWeightMicroSwingHigh0[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightMicroSwingHigh0[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightMicroSwingHigh1[i];
				cumWeightMicroSwingHigh1[i] = 0;
				if (microSwingHigh1[i] >= lowerLimitSupport && microSwingHigh1[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingHigh1[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingHigh1[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingHigh1[i] == microSwingHigh1[i])
						{
							cumWeightMicroSwingHigh1[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightMicroSwingHigh1[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightMicroSwingHigh2[i];
				cumWeightMicroSwingHigh2[i] = 0;
				if (microSwingHigh2[i] >= lowerLimitSupport && microSwingHigh2[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingHigh2[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingHigh2[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingHigh2[i] == microSwingHigh2[i])
						{
							cumWeightMicroSwingHigh2[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightMicroSwingHigh2[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightMicroSwingHigh3[i];
				cumWeightMicroSwingHigh3[i] = 0;
				if (microSwingHigh3[i] >= lowerLimitSupport && microSwingHigh3[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingHigh3[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingHigh3[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingHigh3[i] == microSwingHigh3[i])
						{
							cumWeightMicroSwingHigh3[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightMicroSwingHigh3[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightMicroSwingLow0[i];
				cumWeightMicroSwingLow0[i] = 0;
				if (microSwingLow0[i] >= lowerLimitSupport && microSwingLow0[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingLow0[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingLow0[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingLow0[i] == microSwingLow0[i])
						{
							cumWeightMicroSwingLow0[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightMicroSwingLow0[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightMicroSwingLow1[i];
				cumWeightMicroSwingLow1[i] = 0;
				if (microSwingLow1[i] >= lowerLimitSupport && microSwingLow1[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingLow1[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingLow1[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingLow1[i] == microSwingLow1[i])
						{
							cumWeightMicroSwingLow1[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightMicroSwingLow1[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightMicroSwingLow2[i];
				cumWeightMicroSwingLow2[i] = 0;
				if (microSwingLow2[i] >= lowerLimitSupport && microSwingLow2[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingLow2[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingLow2[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingLow2[i] == microSwingLow2[i])
						{
							cumWeightMicroSwingLow2[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightMicroSwingLow2[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightMicroSwingLow3[i];
				cumWeightMicroSwingLow3[i] = 0;
				if (microSwingLow3[i] >= lowerLimitSupport && microSwingLow3[i] <= upperLimitResistance)
				{
					initialWeight = weightMicroSwingLow3[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(microSwingLow3[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorMicroSwingLow3[i] == microSwingLow3[i])
						{
							cumWeightMicroSwingLow3[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightMicroSwingLow3[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightCurrentSwingHigh[i];
				cumWeightCurrentSwingHigh[i] = 0;
				if (currentSwingHigh[i] >= lowerLimitSupport && currentSwingHigh[i] <= upperLimitResistance)
				{
					initialWeight = weightCurrentSwingHigh[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(currentSwingHigh[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorCurrentSwingHigh[i] == currentSwingHigh[i])
						{
							cumWeightCurrentSwingHigh[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightCurrentSwingHigh[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightLastSwingHigh[i];
				cumWeightLastSwingHigh[i] = 0;
				if (lastSwingHigh[i] >= lowerLimitSupport && lastSwingHigh[i] <= upperLimitResistance)
				{
					initialWeight = weightLastSwingHigh[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastSwingHigh[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastSwingHigh[i] == lastSwingHigh[i])
						{
							cumWeightLastSwingHigh[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightLastSwingHigh[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightCurrentSwingLow[i];
				cumWeightCurrentSwingLow[i] = 0;
				if (currentSwingLow[i] >= lowerLimitSupport && currentSwingLow[i] <= upperLimitResistance)
				{
					initialWeight = weightCurrentSwingLow[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(currentSwingLow[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorCurrentSwingLow[i] == currentSwingLow[i])
						{
							cumWeightCurrentSwingLow[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightCurrentSwingLow[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightLastSwingLow[i];
				cumWeightLastSwingLow[i] = 0;
				if (lastSwingLow[i] >= lowerLimitSupport && lastSwingLow[i] <= upperLimitResistance)
				{
					initialWeight = weightLastSwingLow[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastSwingLow[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastSwingLow[i] == lastSwingLow[i])
						{
							cumWeightLastSwingLow[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightLastSwingLow[i] = 0.5 * compoundedWeight;
						}
					}
				}
				#endregion

				#region Ret
				dummy = cumWeightRetUp23[i];
				cumWeightRetUp23[i] = 0;
				if (retUp23[i] >= lowerLimitSupport && retUp23[i] <= upperLimitResistance)
				{
					initialWeight = weightRetUp23[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retUp23[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetUp23[i] == retUp23[i])
						{
							cumWeightRetUp23[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightRetUp23[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightRetUp38[i];
				cumWeightRetUp38[i] = 0;
				if (retUp38[i] >= lowerLimitSupport && retUp38[i] <= upperLimitResistance)
				{
					initialWeight = weightRetUp38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retUp38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetUp38[i] == retUp38[i])
						{
							cumWeightRetUp38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightRetUp38[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightRetUp50[i];
				cumWeightRetUp50[i] = 0;
				if (retUp50[i] >= lowerLimitSupport && retUp50[i] <= upperLimitResistance)
				{
					initialWeight = weightRetUp50[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retUp50[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetUp50[i] == retUp50[i])
						{
							cumWeightRetUp50[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightRetUp50[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightRetUp62[i];
				cumWeightRetUp62[i] = 0;
				if (retUp62[i] >= lowerLimitSupport && retUp62[i] <= upperLimitResistance)
				{
					initialWeight = weightRetUp62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retUp62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetUp62[i] == retUp62[i])
						{
							cumWeightRetUp62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightRetUp62[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightRetUp76[i];
				cumWeightRetUp76[i] = 0;
				if (retUp76[i] >= lowerLimitSupport && retUp76[i] <= upperLimitResistance)
				{
					initialWeight = weightRetUp76[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retUp76[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetUp76[i] == retUp76[i])
						{
							cumWeightRetUp76[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightRetUp76[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightRetDown23[i];
				cumWeightRetDown23[i] = 0;
				if (retDown23[i] >= lowerLimitSupport && retDown23[i] <= upperLimitResistance)
				{
					initialWeight = weightRetDown23[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retDown23[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetDown23[i] == retDown23[i])
						{
							cumWeightRetDown23[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightRetDown23[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightRetDown38[i];
				cumWeightRetDown38[i] = 0;
				if (retDown38[i] >= lowerLimitSupport && retDown38[i] <= upperLimitResistance)
				{
					initialWeight = weightRetDown38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retDown38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetDown38[i] == retDown38[i])
						{
							cumWeightRetDown38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightRetDown38[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightRetDown50[i];
				cumWeightRetDown50[i] = 0;
				if (retDown50[i] >= lowerLimitSupport && retDown50[i] <= upperLimitResistance)
				{
					initialWeight = weightRetDown50[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retDown50[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetDown50[i] == retDown50[i])
						{
							cumWeightRetDown50[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightRetDown50[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightRetDown62[i];
				cumWeightRetDown62[i] = 0;
				if (retDown62[i] >= lowerLimitSupport && retDown62[i] <= upperLimitResistance)
				{
					initialWeight = weightRetDown62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retDown62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetDown62[i] == retDown62[i])
						{
							cumWeightRetDown62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightRetDown62[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightRetDown76[i];
				cumWeightRetDown76[i] = 0;
				if (retDown76[i] >= lowerLimitSupport && retDown76[i] <= upperLimitResistance)
				{
					initialWeight = weightRetDown76[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(retDown76[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorRetDown76[i] == retDown76[i])
						{
							cumWeightRetDown76[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightRetDown76[i] = 0.5 * compoundedWeight;
						}
					}
				}
				#endregion

				#region Ext
				dummy = cumWeightExtUp127[i];
				cumWeightExtUp127[i] = 0;
				if (extUp127[i] >= lowerLimitSupport && extUp127[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp127[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp127[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtUp127[i] == extUp127[i])
						{
							cumWeightExtUp127[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtUp127[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtUp162[i];
				cumWeightExtUp162[i] = 0;
				if (extUp162[i] >= lowerLimitSupport && extUp162[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp162[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp162[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight <= initialWeight)
					{
						if (priorExtUp162[i] == extUp162[i])
						{
							cumWeightExtUp162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtUp162[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtUp200[i];
				cumWeightExtUp200[i] = 0;
				if (extUp200[i] >= lowerLimitSupport && extUp200[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp200[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp200[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtUp200[i] == extUp200[i])
						{
							cumWeightExtUp200[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtUp200[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtUp262[i];
				cumWeightExtUp262[i] = 0;
				if (extUp262[i] >= lowerLimitSupport && extUp262[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp262[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp262[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtUp262[i] == extUp262[i])
						{
							cumWeightExtUp262[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtUp262[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtUp300[i];
				cumWeightExtUp300[i] = 0;
				if (extUp300[i] >= lowerLimitSupport && extUp300[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp300[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp300[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtUp300[i] == extUp300[i])
						{
							cumWeightExtUp300[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtUp300[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtUp423[i];
				cumWeightExtUp423[i] = 0;
				if (extUp423[i] >= lowerLimitSupport && extUp423[i] <= upperLimitResistance)
				{
					initialWeight = weightExtUp423[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extUp423[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtUp423[i] == extUp423[i])
						{
							cumWeightExtUp423[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtUp423[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtDown127[i];
				cumWeightExtDown127[i] = 0;
				if (extDown127[i] >= lowerLimitSupport && extDown127[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown127[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown127[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown127[i] == extDown127[i])
						{
							cumWeightExtDown127[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtDown127[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtDown162[i];
				cumWeightExtDown162[i] = 0;
				if (extDown162[i] >= lowerLimitSupport && extDown162[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown162[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown162[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown162[i] == extDown162[i])
						{
							cumWeightExtDown162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtDown162[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtDown200[i];
				cumWeightExtDown200[i] = 0;
				if (extDown200[i] >= lowerLimitSupport && extDown200[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown200[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown200[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown200[i] == extDown200[i])
						{
							cumWeightExtDown200[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtDown200[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtDown262[i];
				cumWeightExtDown262[i] = 0;
				if (extDown262[i] >= lowerLimitSupport && extDown262[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown262[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown262[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown262[i] == extDown262[i])
						{
							cumWeightExtDown262[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtDown262[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtDown300[i];
				cumWeightExtDown300[i] = 0;
				if (extDown300[i] >= lowerLimitSupport && extDown300[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown300[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown300[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown300[i] == extDown300[i])
						{
							cumWeightExtDown300[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtDown300[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightExtDown423[i];
				cumWeightExtDown423[i] = 0;
				if (extDown423[i] >= lowerLimitSupport && extDown423[i] <= upperLimitResistance)
				{
					initialWeight = weightExtDown423[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(extDown423[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorExtDown423[i] == extDown423[i])
						{
							cumWeightExtDown423[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightExtDown423[i] = 0.5 * compoundedWeight;
						}
					}
				}
				#endregion

				#region Dir and LastDir
				dummy = cumWeightDirUp38[i];
				cumWeightDirUp38[i] = 0;
				if (dirUp38[i] >= lowerLimitSupport && dirUp38[i] <= upperLimitResistance)
				{
					initialWeight = weightDirUp38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirUp38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirUp38[i] == dirUp38[i])
						{
							cumWeightDirUp38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightDirUp38[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightDirUp62[i];
				cumWeightDirUp62[i] = 0;
				if (dirUp62[i] >= lowerLimitSupport && dirUp62[i] <= upperLimitResistance)
				{
					initialWeight = weightDirUp62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirUp62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirUp62[i] == dirUp62[i])
						{
							cumWeightDirUp62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightDirUp62[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightDirUp100[i];
				cumWeightDirUp100[i] = 0;
				if (dirUp100[i] >= lowerLimitSupport && dirUp100[i] <= upperLimitResistance)
				{
					initialWeight = weightDirUp100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirUp100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirUp100[i] == dirUp100[i])
						{
							cumWeightDirUp100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightDirUp100[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightDirDown38[i];
				cumWeightDirDown38[i] = 0;
				if (dirDown38[i] >= lowerLimitSupport && dirDown38[i] <= upperLimitResistance)
				{
					initialWeight = weightDirDown38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirDown38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirDown38[i] == dirDown38[i])
						{
							cumWeightDirDown38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightDirDown38[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightDirDown62[i];
				cumWeightDirDown62[i] = 0;
				if (dirDown62[i] >= lowerLimitSupport && dirDown62[i] <= upperLimitResistance)
				{
					initialWeight = weightDirDown62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirDown62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirDown62[i] == dirDown62[i])
						{
							cumWeightDirDown62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightDirDown62[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightDirDown100[i];
				cumWeightDirDown100[i] = 0;
				if (dirDown100[i] >= lowerLimitSupport && dirDown100[i] <= upperLimitResistance)
				{
					initialWeight = weightDirDown100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(dirDown100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorDirDown100[i] == dirDown100[i])
						{
							cumWeightDirDown100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightDirDown100[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightLastDirUp38[i];
				cumWeightLastDirUp38[i] = 0;
				if (lastDirUp38[i] >= lowerLimitSupport && lastDirUp38[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirUp38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirUp38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirUp38[i] == lastDirUp38[i])
						{
							cumWeightLastDirUp38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightLastDirUp38[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightLastDirUp62[i];
				cumWeightLastDirUp62[i] = 0;
				if (lastDirUp62[i] >= lowerLimitSupport && lastDirUp62[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirUp62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirUp62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirUp62[i] == lastDirUp62[i])
						{
							cumWeightLastDirUp62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightLastDirUp62[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightLastDirUp100[i];
				cumWeightLastDirUp100[i] = 0;
				if (lastDirUp100[i] >= lowerLimitSupport && lastDirUp100[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirUp100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirUp100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirUp100[i] == lastDirUp100[i])
						{
							cumWeightLastDirUp100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightLastDirUp100[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightLastDirDown38[i];
				cumWeightLastDirDown38[i] = 0;
				if (lastDirDown38[i] >= lowerLimitSupport && lastDirDown38[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirDown38[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirDown38[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirDown38[i] == lastDirDown38[i])
						{
							cumWeightLastDirDown38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightLastDirDown38[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightLastDirDown62[i];
				cumWeightLastDirDown62[i] = 0;
				if (lastDirDown62[i] >= lowerLimitSupport && lastDirDown62[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirDown62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirDown62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirDown62[i] == lastDirDown62[i])
						{
							cumWeightLastDirDown62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightLastDirDown62[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightLastDirDown100[i];
				cumWeightLastDirDown100[i] = 0;
				if (lastDirDown100[i] >= lowerLimitSupport && lastDirDown100[i] <= upperLimitResistance)
				{
					initialWeight = weightLastDirDown100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(lastDirDown100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorLastDirDown100[i] == lastDirDown100[i])
						{
							cumWeightLastDirDown100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightLastDirDown100[i] = 0.5 * compoundedWeight;
						}
					}
				}
				#endregion

				#region Alt
				dummy = cumWeightAlt0Up62[i];
				cumWeightAlt0Up62[i] = 0;
				if (alt0Up62[i] >= lowerLimitSupport && alt0Up62[i] <= upperLimitResistance &&
					alt0Up[i] > 1.272 * alt1Up[i])
				{
					initialWeight = weightAlt0Up62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Up62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Up62[i] == alt0Up62[i])
						{
							cumWeightAlt0Up62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightAlt0Up62[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightAlt0Up100[i];
				cumWeightAlt0Up100[i] = 0;
				if (alt0Up100[i] >= lowerLimitSupport && alt0Up100[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt0Up100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Up100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Up100[i] == alt0Up100[i])
						{
							cumWeightAlt0Up100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightAlt0Up100[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightAlt0Up162[i];
				cumWeightAlt0Up162[i] = 0;
				if (alt0Up162[i] >= lowerLimitSupport && alt0Up162[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt0Up162[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Up162[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Up162[i] == alt0Up162[i])
						{
							cumWeightAlt0Up162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightAlt0Up162[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightAlt1Up100[i];
				cumWeightAlt1Up100[i] = 0;
				if (alt1Up100[i] >= lowerLimitSupport && alt1Up100[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt1Up100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt1Up100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt1Up100[i] == alt1Up100[i])
						{
							cumWeightAlt1Up100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightAlt1Up100[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightAlt0Down62[i];
				cumWeightAlt0Down62[i] = 0;
				if (alt0Down62[i] >= lowerLimitSupport && alt0Down62[i] <= upperLimitResistance &&
					alt0Down[i] > 1.272 * alt1Down[i])
				{
					initialWeight = weightAlt0Down62[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Down62[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Down62[i] == alt0Down62[i])
						{
							cumWeightAlt0Down62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightAlt0Down62[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightAlt0Down100[i];
				cumWeightAlt0Down100[i] = 0;
				if (alt0Down100[i] >= lowerLimitSupport && alt0Down100[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt0Down100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Down100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Down100[i] == alt0Down100[i])
						{
							cumWeightAlt0Down100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightAlt0Down100[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightAlt0Down162[i];
				cumWeightAlt0Down162[i] = 0;
				if (alt0Down162[i] >= lowerLimitSupport && alt0Down162[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt0Down162[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt0Down162[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt0Down162[i] == alt0Down162[i])
						{
							cumWeightAlt0Down162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightAlt0Down162[i] = 0.5 * compoundedWeight;
						}
					}
				}

				dummy = cumWeightAlt1Down100[i];
				cumWeightAlt1Down100[i] = 0;
				if (alt1Down100[i] >= lowerLimitSupport && alt1Down100[i] <= upperLimitResistance)
				{
					initialWeight = weightAlt1Down100[i];
					compoundedWeight = 0;
					highestWeight = initialWeight;
					for (var j = 0; j < countLine; j++)
					{
						if (Math.Abs(alt1Down100[i] - fibLine[j]) <= confluenceRangeWidth)
						{
							compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
							highestWeight = Math.Max(highestWeight, fibWeight[j]);
						}
					}

					if (highestWeight < initialWeight + 0.00001)
					{
						if (priorAlt1Down100[i] == alt1Down100[i])
						{
							cumWeightAlt1Down100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
						}
						else
						{
							cumWeightAlt1Down100[i] = 0.5 * compoundedWeight;
						}
					}
				}
				#endregion
			}
		}

		/// <summary>
		///     Prepare Lines for Display Range if Compounded Weight is Above Multiple of Threshold
		/// </summary>
		public void SelectLines()
		{
			countResistance = 0;
			for (var i = 0; i < 540; i++) 
				fibResistance[i] = 0;

			countSupport = 0;
			for (var i = 0; i < 540; i++) 
				fibSupport[i] = 0;

			countWeakResistance = 0;
			for (var i = 0; i < 540; i++) 
				weakResistance[i] = 0;

			countWeakSupport = 0;
			for (var i = 0; i < 540; i++) 
				weakSupport[i] = 0;

			#region swings
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightMicroSwingHigh0[i] > Threshold)
				{
					if (microSwingHigh0[i] > lowerLimitResistance)
					{
						if (cumWeightMicroSwingHigh0[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingHigh0[i];
							countResistance++;
						}
						else if (microSwingHigh0[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingHigh0[i];
							countWeakResistance++;
						}
					}
					else if (microSwingHigh0[i] <= upperLimitSupport)
					{
						if (cumWeightMicroSwingHigh0[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingHigh0[i];
							countSupport++;
						}
						else if (microSwingHigh0[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingHigh0[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightMicroSwingHigh1[i] > Threshold)
				{
					if (microSwingHigh1[i] > lowerLimitResistance)
					{
						if (cumWeightMicroSwingHigh1[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingHigh1[i];
							countResistance++;
						}
						else if (microSwingHigh1[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingHigh1[i];
							countWeakResistance++;
						}
					}
					else if (microSwingHigh1[i] <= upperLimitSupport)
					{
						if (cumWeightMicroSwingHigh1[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingHigh1[i];
							countSupport++;
						}
						else if (microSwingHigh1[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingHigh1[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightMicroSwingHigh2[i] > Threshold)
				{
					if (microSwingHigh2[i] > lowerLimitResistance)
					{
						if (cumWeightMicroSwingHigh2[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingHigh2[i];
							countResistance++;
						}
						else if (microSwingHigh2[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingHigh2[i];
							countWeakResistance++;
						}
					}
					else if (microSwingHigh2[i] <= upperLimitSupport)
					{
						if (cumWeightMicroSwingHigh2[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingHigh2[i];
							countSupport++;
						}
						else if (microSwingHigh2[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingHigh2[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightMicroSwingHigh3[i] > Threshold)
				{
					if (microSwingHigh3[i] > lowerLimitResistance)
					{
						if (cumWeightMicroSwingHigh3[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingHigh3[i];
							countResistance++;
						}
						else if (microSwingHigh3[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingHigh3[i];
							countWeakResistance++;
						}
					}
					else if (microSwingHigh3[i] <= upperLimitSupport)
					{
						if (cumWeightMicroSwingHigh3[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingHigh3[i];
							countSupport++;
						}
						else if (microSwingHigh3[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingHigh3[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightMicroSwingLow0[i] > Threshold)
				{
					if (microSwingLow0[i] > lowerLimitResistance)
					{
						if (cumWeightMicroSwingLow0[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingLow0[i];
							countResistance++;
						}
						else if (microSwingLow0[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingLow0[i];
							countWeakResistance++;
						}
					}
					else if (microSwingLow0[i] <= upperLimitSupport)
					{
						if (cumWeightMicroSwingLow0[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingLow0[i];
							countSupport++;
						}
						else if (microSwingLow0[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingLow0[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightMicroSwingLow1[i] > Threshold)
				{
					if (microSwingLow1[i] > lowerLimitResistance)
					{
						if (cumWeightMicroSwingLow1[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingLow1[i];
							countResistance++;
						}
						else if (microSwingLow1[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingLow1[i];
							countWeakResistance++;
						}
					}
					else if (microSwingLow1[i] <= upperLimitSupport)
					{
						if (cumWeightMicroSwingLow1[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingLow1[i];
							countSupport++;
						}
						else if (microSwingLow1[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingLow1[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightMicroSwingLow2[i] > Threshold)
				{
					if (microSwingLow2[i] > lowerLimitResistance)
					{
						if (cumWeightMicroSwingLow2[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingLow2[i];
							countResistance++;
						}
						else if (microSwingLow2[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingLow2[i];
							countWeakResistance++;
						}
					}
					else if (microSwingLow2[i] <= upperLimitSupport)
					{
						if (cumWeightMicroSwingLow2[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingLow2[i];
							countSupport++;
						}
						else if (microSwingLow2[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingLow2[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightMicroSwingLow3[i] > Threshold)
				{
					if (microSwingLow3[i] > lowerLimitResistance)
					{
						if (cumWeightMicroSwingLow3[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = microSwingLow3[i];
							countResistance++;
						}
						else if (microSwingLow3[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = microSwingLow3[i];
							countWeakResistance++;
						}
					}
					else if (microSwingLow3[i] <= upperLimitSupport)
					{
						if (cumWeightMicroSwingLow3[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = microSwingLow3[i];
							countSupport++;
						}
						else if (microSwingLow3[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = microSwingLow3[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightCurrentSwingHigh[i] > Threshold)
				{
					if (currentSwingHigh[i] > lowerLimitResistance)
					{
						if (cumWeightCurrentSwingHigh[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = currentSwingHigh[i];
							countResistance++;
						}
						else if (currentSwingHigh[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = currentSwingHigh[i];
							countWeakResistance++;
						}
					}
					else if (currentSwingHigh[i] <= upperLimitSupport)
					{
						if (cumWeightCurrentSwingHigh[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = currentSwingHigh[i];
							countSupport++;
						}
						else if (currentSwingHigh[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = currentSwingHigh[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightLastSwingHigh[i] > Threshold)
				{
					if (lastSwingHigh[i] > lowerLimitResistance)
					{
						if (cumWeightLastSwingHigh[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastSwingHigh[i];
							countResistance++;
						}
						else if (lastSwingHigh[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastSwingHigh[i];
							countWeakResistance++;
						}
					}
					else if (lastSwingHigh[i] <= upperLimitSupport)
					{
						if (cumWeightLastSwingHigh[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastSwingHigh[i];
							countSupport++;
						}
						else if (lastSwingHigh[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastSwingHigh[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightCurrentSwingLow[i] > Threshold)
				{
					if (currentSwingLow[i] > lowerLimitResistance)
					{
						if (cumWeightCurrentSwingLow[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = currentSwingLow[i];
							countResistance++;
						}
						else if (currentSwingLow[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = currentSwingLow[i];
							countWeakResistance++;
						}
					}
					else if (currentSwingLow[i] <= upperLimitSupport)
					{
						if (cumWeightCurrentSwingLow[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = currentSwingLow[i];
							countSupport++;
						}
						else if (currentSwingLow[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = currentSwingLow[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightLastSwingLow[i] > Threshold)
				{
					if (lastSwingLow[i] > lowerLimitResistance)
					{
						if (cumWeightLastSwingLow[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastSwingLow[i];
							countResistance++;
						}
						else if (lastSwingLow[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastSwingLow[i];
							countWeakResistance++;
						}
					}
					else if (lastSwingLow[i] <= upperLimitSupport)
					{
						if (cumWeightLastSwingLow[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastSwingLow[i];
							countSupport++;
						}
						else if (lastSwingLow[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastSwingLow[i];
							countWeakSupport++;
						}
					}
				}
			}
			#endregion

			#region Ret
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightRetUp23[i] > Threshold)
				{
					if (retUp23[i] > lowerLimitResistance)
					{
						if (cumWeightRetUp23[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retUp23[i];
							countResistance++;
						}
						else if (retUp23[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retUp23[i];
							countWeakResistance++;
						}
					}
					else if (retUp23[i] <= upperLimitSupport)
					{
						if (cumWeightRetUp23[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retUp23[i];
							countSupport++;
						}
						else if (retUp23[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retUp23[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightRetUp38[i] > Threshold)
				{
					if (retUp38[i] > lowerLimitResistance)
					{
						if (cumWeightRetUp38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retUp38[i];
							countResistance++;
						}
						else if (retUp38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retUp38[i];
							countWeakResistance++;
						}
					}
					else if (retUp38[i] <= upperLimitSupport)
					{
						if (cumWeightRetUp38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retUp38[i];
							countSupport++;
						}
						else if (retUp38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retUp38[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightRetUp50[i] > Threshold)
				{
					if (retUp50[i] > lowerLimitResistance)
					{
						if (cumWeightRetUp50[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retUp50[i];
							countResistance++;
						}
						else if (retUp50[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retUp50[i];
							countWeakResistance++;
						}
					}
					else if (retUp50[i] <= upperLimitSupport)
					{
						if (cumWeightRetUp50[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retUp50[i];
							countSupport++;
						}
						else if (retUp50[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retUp50[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightRetUp62[i] > Threshold)
				{
					if (retUp62[i] > lowerLimitResistance)
					{
						if (cumWeightRetUp62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retUp62[i];
							countResistance++;
						}
						else if (retUp62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retUp62[i];
							countWeakResistance++;
						}
					}
					else if (retUp62[i] <= upperLimitSupport)
					{
						if (cumWeightRetUp62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retUp62[i];
							countSupport++;
						}
						else if (retUp62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retUp62[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightRetUp76[i] > Threshold)
				{
					if (retUp76[i] > lowerLimitResistance)
					{
						if (cumWeightRetUp76[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retUp76[i];
							countResistance++;
						}
						else if (retUp76[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retUp76[i];
							countWeakResistance++;
						}
					}
					else if (retUp76[i] <= upperLimitSupport)
					{
						if (cumWeightRetUp76[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retUp76[i];
							countSupport++;
						}
						else if (retUp76[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retUp76[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightRetDown23[i] > Threshold)
				{
					if (retDown23[i] > lowerLimitResistance)
					{
						if (cumWeightRetDown23[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retDown23[i];
							countResistance++;
						}
						else if (retDown23[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retDown23[i];
							countWeakResistance++;
						}
					}
					else if (retDown23[i] <= upperLimitSupport)
					{
						if (cumWeightRetDown23[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retDown23[i];
							countSupport++;
						}
						else if (retDown23[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retDown23[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightRetDown38[i] > Threshold)
				{
					if (retDown38[i] > lowerLimitResistance)
					{
						if (cumWeightRetDown38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retDown38[i];
							countResistance++;
						}
						else if (retDown38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retDown38[i];
							countWeakResistance++;
						}
					}
					else if (retDown38[i] <= upperLimitSupport)
					{
						if (cumWeightRetDown38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retDown38[i];
							countSupport++;
						}
						else if (retDown38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retDown38[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightRetDown50[i] > Threshold)
				{
					if (retDown50[i] > lowerLimitResistance)
					{
						if (cumWeightRetDown50[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retDown50[i];
							countResistance++;
						}
						else if (retDown50[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retDown50[i];
							countWeakResistance++;
						}
					}
					else if (retDown50[i] <= upperLimitSupport)
					{
						if (cumWeightRetDown50[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retDown50[i];
							countSupport++;
						}
						else if (retDown50[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retDown50[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightRetDown62[i] > Threshold)
				{
					if (retDown62[i] > lowerLimitResistance)
					{
						if (cumWeightRetDown62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retDown62[i];
							countResistance++;
						}
						else if (retDown62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retDown62[i];
							countWeakResistance++;
						}
					}
					else if (retDown62[i] <= upperLimitSupport)
					{
						if (cumWeightRetDown62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retDown62[i];
							countSupport++;
						}
						else if (retDown62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retDown62[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightRetDown76[i] > Threshold)
				{
					if (retDown76[i] > lowerLimitResistance)
					{
						if (cumWeightRetDown76[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = retDown76[i];
							countResistance++;
						}
						else if (retDown76[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = retDown76[i];
							countWeakResistance++;
						}
					}
					else if (retDown76[i] <= upperLimitSupport)
					{
						if (cumWeightRetDown76[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = retDown76[i];
							countSupport++;
						}
						else if (retDown76[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = retDown76[i];
							countWeakSupport++;
						}
					}
				}
			}
			#endregion

			#region Ext
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtUp127[i] > Threshold)
				{
					if (extUp127[i] > lowerLimitResistance)
					{
						if (cumWeightExtUp127[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp127[i];
							countResistance++;
						}
						else if (extUp127[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp127[i];
							countWeakResistance++;
						}
					}
					else if (extUp127[i] <= upperLimitSupport)
					{
						if (cumWeightExtUp127[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp127[i];
							countSupport++;
						}
						else if (extUp127[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp127[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtUp162[i] > Threshold)
				{
					if (extUp162[i] > lowerLimitResistance)
					{
						if (cumWeightExtUp162[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp162[i];
							countResistance++;
						}
						else if (extUp162[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp162[i];
							countWeakResistance++;
						}
					}
					else if (extUp162[i] <= upperLimitSupport)
					{
						if (cumWeightExtUp162[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp162[i];
							countSupport++;
						}
						else if (extUp162[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp162[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtUp200[i] > Threshold)
				{
					if (extUp200[i] > lowerLimitResistance)
					{
						if (cumWeightExtUp200[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp200[i];
							countResistance++;
						}
						else if (extUp200[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp200[i];
							countWeakResistance++;
						}
					}
					else if (extUp200[i] <= upperLimitSupport)
					{
						if (cumWeightExtUp200[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp200[i];
							countSupport++;
						}
						else if (extUp200[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp200[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtUp262[i] > Threshold)
				{
					if (extUp262[i] > lowerLimitResistance)
					{
						if (cumWeightExtUp262[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp262[i];
							countResistance++;
						}
						else if (extUp262[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp262[i];
							countWeakResistance++;
						}
					}
					else if (extUp262[i] <= upperLimitSupport)
					{
						if (cumWeightExtUp262[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp262[i];
							countSupport++;
						}
						else if (extUp262[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp262[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtUp300[i] > Threshold)
				{
					if (extUp300[i] > lowerLimitResistance)
					{
						if (cumWeightExtUp300[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp300[i];
							countResistance++;
						}
						else if (extUp300[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp300[i];
							countWeakResistance++;
						}
					}
					else if (extUp300[i] <= upperLimitSupport)
					{
						if (cumWeightExtUp300[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp300[i];
							countSupport++;
						}
						else if (extUp300[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp300[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtUp423[i] > Threshold)
				{
					if (extUp423[i] > lowerLimitResistance)
					{
						if (cumWeightExtUp423[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extUp423[i];
							countResistance++;
						}
						else if (extUp423[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extUp423[i];
							countWeakResistance++;
						}
					}
					else if (extUp423[i] <= upperLimitSupport)
					{
						if (cumWeightExtUp423[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extUp423[i];
							countSupport++;
						}
						else if (extUp423[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extUp423[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtDown127[i] > Threshold)
				{
					if (extDown127[i] > lowerLimitResistance)
					{
						if (cumWeightExtDown127[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown127[i];
							countResistance++;
						}
						else if (extDown127[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown127[i];
							countWeakResistance++;
						}
					}
					else if (extDown127[i] <= upperLimitSupport)
					{
						if (cumWeightExtDown127[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown127[i];
							countSupport++;
						}
						else if (extDown127[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown127[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtDown162[i] > Threshold)
				{
					if (extDown162[i] > lowerLimitResistance)
					{
						if (cumWeightExtDown162[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown162[i];
							countResistance++;
						}
						else if (extDown162[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown162[i];
							countWeakResistance++;
						}
					}
					else if (extDown162[i] <= upperLimitSupport)
					{
						if (cumWeightExtDown162[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown162[i];
							countSupport++;
						}
						else if (extDown162[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown162[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtDown200[i] > Threshold)
				{
					if (extDown200[i] > lowerLimitResistance)
					{
						if (cumWeightExtDown200[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown200[i];
							countResistance++;
						}
						else if (extDown200[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown200[i];
							countWeakResistance++;
						}
					}
					else if (extDown200[i] <= upperLimitSupport)
					{
						if (cumWeightExtDown200[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown200[i];
							countSupport++;
						}
						else if (extDown200[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown200[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtDown262[i] > Threshold)
				{
					if (extDown262[i] > lowerLimitResistance)
					{
						if (cumWeightExtDown262[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown262[i];
							countResistance++;
						}
						else if (extDown262[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown262[i];
							countWeakResistance++;
						}
					}
					else if (extDown262[i] <= upperLimitSupport)
					{
						if (cumWeightExtDown262[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown262[i];
							countSupport++;
						}
						else if (extDown262[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown262[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtDown300[i] > Threshold)
				{
					if (extDown300[i] > lowerLimitResistance)
					{
						if (cumWeightExtDown300[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown300[i];
							countResistance++;
						}
						else if (extDown300[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown300[i];
							countWeakResistance++;
						}
					}
					else if (extDown300[i] <= upperLimitSupport)
					{
						if (cumWeightExtDown300[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown300[i];
							countSupport++;
						}
						else if (extDown300[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown300[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightExtDown423[i] > Threshold)
				{
					if (extDown423[i] > lowerLimitResistance)
					{
						if (cumWeightExtDown423[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = extDown423[i];
							countResistance++;
						}
						else if (extDown423[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = extDown423[i];
							countWeakResistance++;
						}
					}
					else if (extDown423[i] <= upperLimitSupport)
					{
						if (cumWeightExtDown423[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = extDown423[i];
							countSupport++;
						}
						else if (extDown423[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = extDown423[i];
							countWeakSupport++;
						}
					}
				}
			}
			#endregion

			#region Dir and LastDir
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightDirUp38[i] > Threshold)
				{
					if (dirUp38[i] > lowerLimitResistance)
					{
						if (cumWeightDirUp38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirUp38[i];
							countResistance++;
						}
						else if (dirUp38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirUp38[i];
							countWeakResistance++;
						}
					}
					else if (dirUp38[i] <= upperLimitSupport)
					{
						if (cumWeightDirUp38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirUp38[i];
							countSupport++;
						}
						else if (dirUp38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirUp38[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightDirUp62[i] > Threshold)
				{
					if (dirUp62[i] > lowerLimitResistance)
					{
						if (cumWeightDirUp62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirUp62[i];
							countResistance++;
						}
						else if (dirUp62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirUp62[i];
							countWeakResistance++;
						}
					}
					else if (dirUp62[i] <= upperLimitSupport)
					{
						if (cumWeightDirUp62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirUp62[i];
							countSupport++;
						}
						else if (dirUp62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirUp62[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightDirUp100[i] > Threshold)
				{
					if (dirUp100[i] > lowerLimitResistance)
					{
						if (cumWeightDirUp100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirUp100[i];
							countResistance++;
						}
						else if (dirUp100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirUp100[i];
							countWeakResistance++;
						}
					}
					else if (dirUp100[i] <= upperLimitSupport)
					{
						if (cumWeightDirUp100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirUp100[i];
							countSupport++;
						}
						else if (dirUp100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirUp100[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightDirDown38[i] > Threshold)
				{
					if (dirDown38[i] > lowerLimitResistance)
					{
						if (cumWeightDirDown38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirDown38[i];
							countResistance++;
						}
						else if (dirDown38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirDown38[i];
							countWeakResistance++;
						}
					}
					else if (dirDown38[i] <= upperLimitSupport)
					{
						if (cumWeightDirDown38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirDown38[i];
							countSupport++;
						}
						else if (dirDown38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirDown38[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightDirDown62[i] > Threshold)
				{
					if (dirDown62[i] > lowerLimitResistance)
					{
						if (cumWeightDirDown62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirDown62[i];
							countResistance++;
						}
						else if (dirDown62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirDown62[i];
							countWeakResistance++;
						}
					}
					else if (dirDown62[i] <= upperLimitSupport)
					{
						if (cumWeightDirDown62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirDown62[i];
							countSupport++;
						}
						else if (dirDown62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirDown62[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightDirDown100[i] > Threshold)
				{
					if (dirDown100[i] > lowerLimitResistance)
					{
						if (cumWeightDirDown100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = dirDown100[i];
							countResistance++;
						}
						else if (dirDown100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = dirDown100[i];
							countWeakResistance++;
						}
					}
					else if (dirDown100[i] <= upperLimitSupport)
					{
						if (cumWeightDirDown100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = dirDown100[i];
							countSupport++;
						}
						else if (dirDown100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = dirDown100[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightLastDirUp38[i] > Threshold)
				{
					if (lastDirUp38[i] > lowerLimitResistance)
					{
						if (cumWeightLastDirUp38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirUp38[i];
							countResistance++;
						}
						else if (lastDirUp38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirUp38[i];
							countWeakResistance++;
						}
					}
					else if (lastDirUp38[i] <= upperLimitSupport)
					{
						if (cumWeightLastDirUp38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirUp38[i];
							countSupport++;
						}
						else if (lastDirUp38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirUp38[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightLastDirUp62[i] > Threshold)
				{
					if (lastDirUp62[i] > lowerLimitResistance)
					{
						if (cumWeightLastDirUp62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirUp62[i];
							countResistance++;
						}
						else if (lastDirUp62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirUp62[i];
							countWeakResistance++;
						}
					}
					else if (lastDirUp62[i] <= upperLimitSupport)
					{
						if (cumWeightLastDirUp62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirUp62[i];
							countSupport++;
						}
						else if (lastDirUp62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirUp62[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightLastDirUp100[i] > Threshold)
				{
					if (lastDirUp100[i] > lowerLimitResistance)
					{
						if (cumWeightLastDirUp100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirUp100[i];
							countResistance++;
						}
						else if (lastDirUp100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirUp100[i];
							countWeakResistance++;
						}
					}
					else if (lastDirUp100[i] <= upperLimitSupport)
					{
						if (cumWeightLastDirUp100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirUp100[i];
							countSupport++;
						}
						else if (lastDirUp100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirUp100[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightLastDirDown38[i] > Threshold)
				{
					if (lastDirDown38[i] > lowerLimitResistance)
					{
						if (cumWeightLastDirDown38[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirDown38[i];
							countResistance++;
						}
						else if (lastDirDown38[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirDown38[i];
							countWeakResistance++;
						}
					}
					else if (lastDirDown38[i] <= upperLimitSupport)
					{
						if (cumWeightLastDirDown38[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirDown38[i];
							countSupport++;
						}
						else if (lastDirDown38[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirDown38[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightLastDirDown62[i] > Threshold)
				{
					if (lastDirDown62[i] > lowerLimitResistance)
					{
						if (cumWeightLastDirDown62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirDown62[i];
							countResistance++;
						}
						else if (lastDirDown62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirDown62[i];
							countWeakResistance++;
						}
					}
					else if (lastDirDown62[i] <= upperLimitSupport)
					{
						if (cumWeightLastDirDown62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirDown62[i];
							countSupport++;
						}
						else if (lastDirDown62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirDown62[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightLastDirDown100[i] > Threshold)
				{
					if (lastDirDown100[i] > lowerLimitResistance)
					{
						if (cumWeightLastDirDown100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = lastDirDown100[i];
							countResistance++;
						}
						else if (lastDirDown100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = lastDirDown100[i];
							countWeakResistance++;
						}
					}
					else if (lastDirDown100[i] <= upperLimitSupport)
					{
						if (cumWeightLastDirDown100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = lastDirDown100[i];
							countSupport++;
						}
						else if (lastDirDown100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = lastDirDown100[i];
							countWeakSupport++;
						}
					}
				}
			}
			#endregion

			#region Alt
			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightAlt0Up62[i] > Threshold)
				{
					if (alt0Up62[i] > lowerLimitResistance)
					{
						if (cumWeightAlt0Up62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Up62[i];
							countResistance++;
						}
						else if (alt0Up62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Up62[i];
							countWeakResistance++;
						}
					}
					else if (alt0Up62[i] <= upperLimitSupport)
					{
						if (cumWeightAlt0Up62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Up62[i];
							countSupport++;
						}
						else if (alt0Up62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Up62[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightAlt0Up100[i] > Threshold)
				{
					if (alt0Up100[i] > lowerLimitResistance)
					{
						if (cumWeightAlt0Up100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Up100[i];
							countResistance++;
						}
						else if (alt0Up100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Up100[i];
							countWeakResistance++;
						}
					}
					else if (alt0Up100[i] <= upperLimitSupport)
					{
						if (cumWeightAlt0Up100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Up100[i];
							countSupport++;
						}
						else if (alt0Up100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Up100[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightAlt0Up162[i] > Threshold)
				{
					if (alt0Up162[i] > lowerLimitResistance)
					{
						if (cumWeightAlt0Up162[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Up162[i];
							countResistance++;
						}
						else if (alt0Up162[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Up162[i];
							countWeakResistance++;
						}
					}
					else if (alt0Up162[i] <= upperLimitSupport)
					{
						if (cumWeightAlt0Up162[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Up162[i];
							countSupport++;
						}
						else if (alt0Up162[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Up162[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightAlt1Up100[i] > Threshold)
				{
					if (alt1Up100[i] > lowerLimitResistance)
					{
						if (cumWeightAlt1Up100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt1Up100[i];
							countResistance++;
						}
						else if (alt1Up100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt1Up100[i];
							countWeakResistance++;
						}
					}
					else if (alt1Up100[i] <= upperLimitSupport)
					{
						if (cumWeightAlt1Up100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt1Up100[i];
							countSupport++;
						}
						else if (alt1Up100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt1Up100[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightAlt0Down62[i] > Threshold)
				{
					if (alt0Down62[i] > lowerLimitResistance)
					{
						if (cumWeightAlt0Down62[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Down62[i];
							countResistance++;
						}
						else if (alt0Down62[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Down62[i];
							countWeakResistance++;
						}
					}
					else if (alt0Down62[i] <= upperLimitSupport)
					{
						if (cumWeightAlt0Down62[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Down62[i];
							countSupport++;
						}
						else if (alt0Down62[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Down62[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightAlt0Down100[i] > Threshold)
				{
					if (alt0Down100[i] > lowerLimitResistance)
					{
						if (cumWeightAlt0Down100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Down100[i];
							countResistance++;
						}
						else if (alt0Down100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Down100[i];
							countWeakResistance++;
						}
					}
					else if (alt0Down100[i] <= upperLimitSupport)
					{
						if (cumWeightAlt0Down100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Down100[i];
							countSupport++;
						}
						else if (alt0Down100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Down100[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightAlt0Down162[i] > Threshold)
				{
					if (alt0Down162[i] > lowerLimitResistance)
					{
						if (cumWeightAlt0Down162[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt0Down162[i];
							countResistance++;
						}
						else if (alt0Down162[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt0Down162[i];
							countWeakResistance++;
						}
					}
					else if (alt0Down162[i] <= upperLimitSupport)
					{
						if (cumWeightAlt0Down162[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt0Down162[i];
							countSupport++;
						}
						else if (alt0Down162[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt0Down162[i];
							countWeakSupport++;
						}
					}
				}
			}

			for (var i = lowestTimeFrame; i <= highestTimeFrame; i++)
			{
				if (cumWeightAlt1Down100[i] > Threshold)
				{
					if (alt1Down100[i] > lowerLimitResistance)
					{
						if (cumWeightAlt1Down100[i] > 1.5 * Threshold)
						{
							fibResistance[countResistance] = alt1Down100[i];
							countResistance++;
						}
						else if (alt1Down100[i] < upperLimitWeakResistance)
						{
							weakResistance[countWeakResistance] = alt1Down100[i];
							countWeakResistance++;
						}
					}
					else if (alt1Down100[i] <= upperLimitSupport)
					{
						if (cumWeightAlt1Down100[i] > 1.5 * Threshold)
						{
							fibSupport[countSupport] = alt1Down100[i];
							countSupport++;
						}
						else if (alt1Down100[i] > lowerLimitWeakSupport)
						{
							weakSupport[countWeakSupport] = alt1Down100[i];
							countWeakSupport++;
						}
					}
				}
			}
			#endregion
		}

		/// <summary>
		///     Sorting Arrays fibResistance, fib, fibLine and  fibWeight with BubbleSort to prepare for Analyzer
		/// </summary>
		public void SortLines()
		{
			for (var side = -1; side <= 1; side += 2)
			for (var strength = 0; strength < 2; strength += 2)
			{
				var goAhead = true;
				var m = side == -1 
					? (strength == 0 ? countWeakSupport : countSupport) 
					: (strength == 0 ? countWeakResistance : countResistance);
				var arr = side == -1 
					? (strength == 0 ? weakSupport : fibSupport)
					: (strength == 0 ? weakResistance : fibResistance);
				while (goAhead && m >= 1)
				{
					goAhead = false;
					for (var i = 1; i < m; i++)
					{
						if (arr[i - 1].ApproxCompare(arr[i]) == side)
						{
							var dummy = arr[i - 1];
							arr[i - 1] = arr[i];
							arr[i] = dummy;
							goAhead = true;
						}

						arr[i - 1] = Instrument.MasterInstrument.RoundToTickSize(arr[i - 1]);
					}

					m--;
				}
			}
		}

		#region Fields + Properties
		#region Arrays
		private readonly bool[] upTrend = new bool[10];
		private readonly bool[] existsSwingHigh = new bool[10];
		private readonly bool[] existsSwingLow = new bool[10];
		private readonly double[] minimumDeviation = new double[10];
		private readonly double[,] microHigh = new double[10, 20];
		private readonly double[,] microLow = new double[10, 20];
		private readonly double[] currentHigh = new double[10];
		private readonly double[] currentLow = new double[10];
		private readonly double[] priorCurrentHigh = new double[10];
		private readonly double[] priorCurrentLow = new double[10];
		private readonly double[] currentSwingHigh = new double[10];
		private readonly double[] currentSwingLow = new double[10];
		private readonly double[] lastSwingHigh = new double[10];
		private readonly double[] lastSwingLow = new double[10];
		private readonly double[] microSwingHigh0 = new double[10];
		private readonly double[] microSwingHigh1 = new double[10];
		private readonly double[] microSwingHigh2 = new double[10];
		private readonly double[] microSwingHigh3 = new double[10];
		private readonly double[] microSwingLow0 = new double[10];
		private readonly double[] microSwingLow1 = new double[10];
		private readonly double[] microSwingLow2 = new double[10];
		private readonly double[] microSwingLow3 = new double[10];
		private readonly double[] retUp0 = new double[10];
		private readonly double[] retUp23 = new double[10];
		private readonly double[] retUp38 = new double[10];
		private readonly double[] retUp50 = new double[10];
		private readonly double[] retUp62 = new double[10];
		private readonly double[] retUp76 = new double[10];
		private readonly double[] retUp100 = new double[10];
		private readonly double[] retDown0 = new double[10];
		private readonly double[] retDown23 = new double[10];
		private readonly double[] retDown38 = new double[10];
		private readonly double[] retDown50 = new double[10];
		private readonly double[] retDown62 = new double[10];
		private readonly double[] retDown76 = new double[10];
		private readonly double[] retDown100 = new double[10];
		private readonly double[] extUp0 = new double[10];
		private readonly double[] extUp100 = new double[10];
		private readonly double[] extUp127 = new double[10];
		private readonly double[] extUp162 = new double[10];
		private readonly double[] extUp200 = new double[10];
		private readonly double[] extUp262 = new double[10];
		private readonly double[] extUp300 = new double[10];
		private readonly double[] extUp423 = new double[10];
		private readonly double[] extDown0 = new double[10];
		private readonly double[] extDown100 = new double[10];
		private readonly double[] extDown127 = new double[10];
		private readonly double[] extDown162 = new double[10];
		private readonly double[] extDown200 = new double[10];
		private readonly double[] extDown262 = new double[10];
		private readonly double[] extDown300 = new double[10];
		private readonly double[] extDown423 = new double[10];
		private readonly double[] dirUp38 = new double[10];
		private readonly double[] dirUp62 = new double[10];
		private readonly double[] dirUp100 = new double[10];
		private readonly double[] dirDown38 = new double[10];
		private readonly double[] dirDown62 = new double[10];
		private readonly double[] dirDown100 = new double[10];
		private readonly double[] lastDirUp38 = new double[10];
		private readonly double[] lastDirUp62 = new double[10];
		private readonly double[] lastDirUp100 = new double[10];
		private readonly double[] lastDirDown38 = new double[10];
		private readonly double[] lastDirDown62 = new double[10];
		private readonly double[] lastDirDown100 = new double[10];
		private readonly double[] alt0Up = new double[10];
		private readonly double[] alt1Up = new double[10];
		private readonly double[] alt0Down = new double[10];
		private readonly double[] alt1Down = new double[10];
		private readonly double[] alt0Up62 = new double[10];
		private readonly double[] alt0Up100 = new double[10];
		private readonly double[] alt0Up162 = new double[10];
		private readonly double[] alt1Up100 = new double[10];
		private readonly double[] alt0Down62 = new double[10];
		private readonly double[] alt0Down100 = new double[10];
		private readonly double[] alt0Down162 = new double[10];
		private readonly double[] alt1Down100 = new double[10];
		private readonly double[] priorCurrentSwingHigh = new double[10];
		private readonly double[] priorLastSwingHigh = new double[10];
		private readonly double[] priorCurrentSwingLow = new double[10];
		private readonly double[] priorLastSwingLow = new double[10];
		private readonly double[] priorMicroSwingHigh0 = new double[10];
		private readonly double[] priorMicroSwingHigh1 = new double[10];
		private readonly double[] priorMicroSwingHigh2 = new double[10];
		private readonly double[] priorMicroSwingHigh3 = new double[10];
		private readonly double[] priorMicroSwingLow0 = new double[10];
		private readonly double[] priorMicroSwingLow1 = new double[10];
		private readonly double[] priorMicroSwingLow2 = new double[10];
		private readonly double[] priorMicroSwingLow3 = new double[10];
		private readonly double[] priorRetUp0 = new double[10];
		private readonly double[] priorRetUp23 = new double[10];
		private readonly double[] priorRetUp38 = new double[10];
		private readonly double[] priorRetUp50 = new double[10];
		private readonly double[] priorRetUp62 = new double[10];
		private readonly double[] priorRetUp76 = new double[10];
		private readonly double[] priorRetUp100 = new double[10];
		private readonly double[] priorRetDown0 = new double[10];
		private readonly double[] priorRetDown23 = new double[10];
		private readonly double[] priorRetDown38 = new double[10];
		private readonly double[] priorRetDown50 = new double[10];
		private readonly double[] priorRetDown62 = new double[10];
		private readonly double[] priorRetDown76 = new double[10];
		private readonly double[] priorRetDown100 = new double[10];
		private readonly double[] priorExtUp0 = new double[10];
		private readonly double[] priorExtUp100 = new double[10];
		private readonly double[] priorExtUp127 = new double[10];
		private readonly double[] priorExtUp162 = new double[10];
		private readonly double[] priorExtUp200 = new double[10];
		private readonly double[] priorExtUp262 = new double[10];
		private readonly double[] priorExtUp300 = new double[10];
		private readonly double[] priorExtUp423 = new double[10];
		private readonly double[] priorExtDown0 = new double[10];
		private readonly double[] priorExtDown100 = new double[10];
		private readonly double[] priorExtDown127 = new double[10];
		private readonly double[] priorExtDown162 = new double[10];
		private readonly double[] priorExtDown200 = new double[10];
		private readonly double[] priorExtDown262 = new double[10];
		private readonly double[] priorExtDown300 = new double[10];
		private readonly double[] priorExtDown423 = new double[10];
		private readonly double[] priorDirUp38 = new double[10];
		private readonly double[] priorDirUp62 = new double[10];
		private readonly double[] priorDirUp100 = new double[10];
		private readonly double[] priorDirDown38 = new double[10];
		private readonly double[] priorDirDown62 = new double[10];
		private readonly double[] priorDirDown100 = new double[10];
		private readonly double[] priorLastDirUp38 = new double[10];
		private readonly double[] priorLastDirUp62 = new double[10];
		private readonly double[] priorLastDirUp100 = new double[10];
		private readonly double[] priorLastDirDown38 = new double[10];
		private readonly double[] priorLastDirDown62 = new double[10];
		private readonly double[] priorLastDirDown100 = new double[10];
		private readonly double[] priorAlt0Up62 = new double[10];
		private readonly double[] priorAlt0Up100 = new double[10];
		private readonly double[] priorAlt0Up162 = new double[10];
		private readonly double[] priorAlt0Down62 = new double[10];
		private readonly double[] priorAlt0Down100 = new double[10];
		private readonly double[] priorAlt0Down162 = new double[10];
		private readonly double[] priorAlt1Up100 = new double[10];
		private readonly double[] priorAlt1Down100 = new double[10];
		private readonly int[] countDown = new int[10];
		private readonly int[] currentSwingHighIndex = new int[10];
		private readonly int[] lastSwingHighIndex = new int[10];
		private readonly int[] currentSwingLowIndex = new int[10];
		private readonly int[] lastSwingLowIndex = new int[10];
		#endregion

		private double avgTrueRange;
		private double timeFrameMultiplier;

		private int countResistance;
		private int countSupport;
		private int countWeakResistance;
		private int countWeakSupport;
		
		private double lowestResistance = double.MaxValue;
		private double highestSupport = double.MinValue;

		private bool highUpdate;
		private bool lowUpdate;
		private bool addHigh;
		private bool addLow;
		private double normalizedRangeUp;
		private double normalizedRangeDown;
		private int highCount;
		private int lowCount;

		private int countLine;
		private double initialWeight;
		private double compoundedWeight;
		private double highestWeight;

		#region zigzag
		private double currentBarHigh;
		private double currentBarLow;
		private double currentBarClose;
		private double currentBarTrueRange;
		private double priorBarHigh;
		private double priorBarLow;
		private double priorBarClose;
		private double zigZagFactor;
		private double confluenceRange;
		private readonly double displayFactor = 80.0;
		private readonly int lowestTimeFrame = 0;
		private readonly int highestTimeFrame = 9;
		private readonly double stepUpRatio = 1.5;
		#endregion

		#region Lines
		private readonly bool showWeakerLines = true;

		private double confluenceRangeWidth;
		private double upperLimitResistance = double.MaxValue;
		private double lowerLimitResistance;
		private double upperLimitSupport = double.MaxValue;
		private double lowerLimitSupport;
		private double upperLimitWeakResistance = double.MaxValue;
		private double lowerLimitWeakSupport;
		#endregion

		#region Specific Weights
		private const double SpecificWeightMicroSwing0 = 44.10;
		private const double SpecificWeightMicroSwing1 = 37.48;
		private const double SpecificWeightMicroSwing2 = 31.86;
		private const double SpecificWeightMicroSwing3 = 27.08;
		private const double SpecificWeightCurrentSwing = 46.42;
		private const double SpecificWeightLastSwing = 39.45;
		private const double SpecificWeightRet23 = 28.44;
		private const double SpecificWeightRet38 = 33.62;
		private const double SpecificWeightRet50 = 36.84;
		private const double SpecificWeightRet62 = 39.58;
		private const double SpecificWeightRet76 = 42.36;
		private const double SpecificWeightExt127 = 50.27;
		private const double SpecificWeightExt162 = 54.51;
		private const double SpecificWeightExt200 = 50.27;
		private const double SpecificWeightExt262 = 42.36;
		private const double SpecificWeightExt300 = 39.58;
		private const double SpecificWeightExt423 = 36.84;
		private const double SpecificWeightDir38 = 36.17;
		private const double SpecificWeightDir62 = 38.16;
		private const double SpecificWeightDir100 = 32.49;
		private const double SpecificWeightLastDir38 = 30.75;
		private const double SpecificWeightLastDir62 = 32.44;
		private const double SpecificWeightLastDir100 = 27.62;
		private const double SpecificWeightAlt62 = 23.75;
		private const double SpecificWeightAlt100 = 27.85;
		private const double SpecificWeightAlt162 = 32.71;
		private const double SpecificWeightAlt100Prior = 23.67;
		private const double DevalueRet = 0.8;
		private const double DevalueExt = 0.8;
		private const double DevalueDir = 0.6;
		private const double DevalueAlt = 0.6;
		#endregion

		#region Arrays
		private readonly double[] fibLine = new double[540];
		private readonly double[] fibWeight = new double[540];
		private readonly double[] fibResistance = new double[540];
		private readonly double[] weakResistance = new double[540];
		private readonly double[] weightResistance = new double[540];
		private readonly double[] fibSupport = new double[540];
		private readonly double[] weakSupport = new double[540];
		private readonly double[] weightSupport = new double[540];

		private readonly double[] timeFrameFactor = new double[10];
		private readonly double[] weightMicroSwingHigh0 = new double[10];
		private readonly double[] weightMicroSwingHigh1 = new double[10];
		private readonly double[] weightMicroSwingHigh2 = new double[10];
		private readonly double[] weightMicroSwingHigh3 = new double[10];
		private readonly double[] weightMicroSwingLow0 = new double[10];
		private readonly double[] weightMicroSwingLow1 = new double[10];
		private readonly double[] weightMicroSwingLow2 = new double[10];
		private readonly double[] weightMicroSwingLow3 = new double[10];
		private readonly double[] weightCurrentSwingHigh = new double[10];
		private readonly double[] weightLastSwingHigh = new double[10];
		private readonly double[] weightCurrentSwingLow = new double[10];
		private readonly double[] weightLastSwingLow = new double[10];
		private readonly double[] weightRetUp23 = new double[10];
		private readonly double[] weightRetUp38 = new double[10];
		private readonly double[] weightRetUp50 = new double[10];
		private readonly double[] weightRetUp62 = new double[10];
		private readonly double[] weightRetUp76 = new double[10];
		private readonly double[] weightRetDown23 = new double[10];
		private readonly double[] weightRetDown38 = new double[10];
		private readonly double[] weightRetDown50 = new double[10];
		private readonly double[] weightRetDown62 = new double[10];
		private readonly double[] weightRetDown76 = new double[10];
		private readonly double[] weightExtUp127 = new double[10];
		private readonly double[] weightExtUp162 = new double[10];
		private readonly double[] weightExtUp200 = new double[10];
		private readonly double[] weightExtUp262 = new double[10];
		private readonly double[] weightExtUp300 = new double[10];
		private readonly double[] weightExtUp423 = new double[10];
		private readonly double[] weightExtDown127 = new double[10];
		private readonly double[] weightExtDown162 = new double[10];
		private readonly double[] weightExtDown200 = new double[10];
		private readonly double[] weightExtDown262 = new double[10];
		private readonly double[] weightExtDown300 = new double[10];
		private readonly double[] weightExtDown423 = new double[10];
		private readonly double[] weightDirUp38 = new double[10];
		private readonly double[] weightDirUp62 = new double[10];
		private readonly double[] weightDirUp100 = new double[10];
		private readonly double[] weightDirDown38 = new double[10];
		private readonly double[] weightDirDown62 = new double[10];
		private readonly double[] weightDirDown100 = new double[10];
		private readonly double[] weightLastDirUp38 = new double[10];
		private readonly double[] weightLastDirUp62 = new double[10];
		private readonly double[] weightLastDirUp100 = new double[10];
		private readonly double[] weightLastDirDown38 = new double[10];
		private readonly double[] weightLastDirDown62 = new double[10];
		private readonly double[] weightLastDirDown100 = new double[10];
		private readonly double[] weightAlt0Up62 = new double[10];
		private readonly double[] weightAlt0Up100 = new double[10];
		private readonly double[] weightAlt0Up162 = new double[10];
		private readonly double[] weightAlt1Up100 = new double[10];
		private readonly double[] weightAlt0Down62 = new double[10];
		private readonly double[] weightAlt0Down100 = new double[10];
		private readonly double[] weightAlt0Down162 = new double[10];
		private readonly double[] weightAlt1Down100 = new double[10];

		private readonly double[] cumWeightMicroSwingHigh0 = new double[10];
		private readonly double[] cumWeightMicroSwingHigh1 = new double[10];
		private readonly double[] cumWeightMicroSwingHigh2 = new double[10];
		private readonly double[] cumWeightMicroSwingHigh3 = new double[10];
		private readonly double[] cumWeightMicroSwingLow0 = new double[10];
		private readonly double[] cumWeightMicroSwingLow1 = new double[10];
		private readonly double[] cumWeightMicroSwingLow2 = new double[10];
		private readonly double[] cumWeightMicroSwingLow3 = new double[10];
		private readonly double[] cumWeightCurrentSwingHigh = new double[10];
		private readonly double[] cumWeightLastSwingHigh = new double[10];
		private readonly double[] cumWeightCurrentSwingLow = new double[10];
		private readonly double[] cumWeightLastSwingLow = new double[10];
		private readonly double[] cumWeightRetUp23 = new double[10];
		private readonly double[] cumWeightRetUp38 = new double[10];
		private readonly double[] cumWeightRetUp50 = new double[10];
		private readonly double[] cumWeightRetUp62 = new double[10];
		private readonly double[] cumWeightRetUp76 = new double[10];
		private readonly double[] cumWeightRetDown23 = new double[10];
		private readonly double[] cumWeightRetDown38 = new double[10];
		private readonly double[] cumWeightRetDown50 = new double[10];
		private readonly double[] cumWeightRetDown62 = new double[10];
		private readonly double[] cumWeightRetDown76 = new double[10];
		private readonly double[] cumWeightExtUp127 = new double[10];
		private readonly double[] cumWeightExtUp162 = new double[10];
		private readonly double[] cumWeightExtUp200 = new double[10];
		private readonly double[] cumWeightExtUp262 = new double[10];
		private readonly double[] cumWeightExtUp300 = new double[10];
		private readonly double[] cumWeightExtUp423 = new double[10];
		private readonly double[] cumWeightExtDown127 = new double[10];
		private readonly double[] cumWeightExtDown162 = new double[10];
		private readonly double[] cumWeightExtDown200 = new double[10];
		private readonly double[] cumWeightExtDown262 = new double[10];
		private readonly double[] cumWeightExtDown300 = new double[10];
		private readonly double[] cumWeightExtDown423 = new double[10];
		private readonly double[] cumWeightDirUp38 = new double[10];
		private readonly double[] cumWeightDirUp62 = new double[10];
		private readonly double[] cumWeightDirUp100 = new double[10];
		private readonly double[] cumWeightDirDown38 = new double[10];
		private readonly double[] cumWeightDirDown62 = new double[10];
		private readonly double[] cumWeightDirDown100 = new double[10];
		private readonly double[] cumWeightLastDirUp38 = new double[10];
		private readonly double[] cumWeightLastDirUp62 = new double[10];
		private readonly double[] cumWeightLastDirUp100 = new double[10];
		private readonly double[] cumWeightLastDirDown38 = new double[10];
		private readonly double[] cumWeightLastDirDown62 = new double[10];
		private readonly double[] cumWeightLastDirDown100 = new double[10];
		private readonly double[] cumWeightAlt0Up62 = new double[10];
		private readonly double[] cumWeightAlt0Up100 = new double[10];
		private readonly double[] cumWeightAlt0Up162 = new double[10];
		private readonly double[] cumWeightAlt1Up100 = new double[10];
		private readonly double[] cumWeightAlt0Down62 = new double[10];
		private readonly double[] cumWeightAlt0Down100 = new double[10];
		private readonly double[] cumWeightAlt0Down162 = new double[10];
		private readonly double[] cumWeightAlt1Down100 = new double[10];

		private readonly double[] strongFibs = new double[20];
		private readonly double[] weakFibs = new double[20];
		private readonly double[] priorStrongFibs = new double[20];
		private readonly double[] priorWeakFibs = new double[20];
		private readonly double[] oldStrongFibs = new double[20];
		private readonly double[] oldWeakFibs = new double[20];
		private readonly double[] newBOBHigh = new double[40];
		private readonly double[] oldBOBHigh = new double[40];
		private readonly double[] newBOBLow = new double[40];
		private readonly double[] oldBOBLow = new double[40];
		private readonly double[] newBOBClose = new double[40];
		private readonly double[] oldBOBClose = new double[40];
		private readonly int[] newState = new int[40];
		private readonly int[] oldState = new int[40];
		#endregion

		private class LevelData
		{
			public int rMABar;
			public int state;

			public LevelData(int rmabar, int state)
			{
				rMABar = rmabar;
				this.state = state;
			}
		}

		private readonly SortedDictionary<double, LevelData> allLevels = new SortedDictionary<double, LevelData>();

		[Browsable(false)]
		[XmlIgnore]
		internal ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>> Confluences
		{
			get
			{
				return confluences ?? (confluences = new ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>>(() => Values.Take(20), i =>
				{
					if (i > 19)
						throw new IndexOutOfRangeException();

					return Values[i];
				}));
			}
		}
		private ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>> confluences;

		[Browsable(false)]
		[XmlIgnore]
		internal ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>> WeakConfluences
		{
			get
			{
				return weakConfluences ?? (weakConfluences = new ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>>(() => Values.Skip(20).Take(20), i =>
				{
					if (i > 19)
						throw new IndexOutOfRangeException();

					return Values[i + 20];
				}));
			}
		}
		private ARC_AutoFibAlgo_ReadOnlyMapProxy<Series<double>> weakConfluences;

		internal int LookbackMinutes
		{
			get { return 24 * 60 * LookBackMinute / BarPeriod; }
		}
		#endregion

		#region Parameters
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Bar period for minute bars", GroupName = "Parameters", Description = "Bar period for minute bars which are used to calculate the Fibonacci confluence lines", Order = 0)]
		public int BarPeriod { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Fibonacci swing timeframe", GroupName = "Parameters", Description = "Timeframes used to identify Fibonacci swings", Order = 1)]
		public ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution LineDensity { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Grid strength", GroupName = "Parameters", Description = "Width of the grid used for summing up Fibonacci lines", Order = 2)]
		public ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth ConfluenceZone { get; set; }

		[NinjaScriptProperty]
		[Range(0.0, double.MaxValue)]
		[Display(Name = "Threshold for confluence lines", GroupName = "Parameters", Description = "The treshhold set the minimumum statistical weight required for a confluence line. Confluence lines with a weight below the threshold value will not be shown.", Order = 3)]
		public double Threshold { get; set; }

		[NinjaScriptProperty]
		[Range(30, int.MaxValue)]
		[Display(Name = "Total lookback (days)", GroupName = "Parameters", Description = "Lookback period for data used for calculating Fibonacci lines", Order = 4)]
		public int LookBackMinute { get; set; }
		#endregion

		#region Plots
		[XmlIgnore]
		[Display(Name = "Resistance lines", GroupName = "Plots", Description = "Select color for all resistance lines", Order = 0)]
		public Brush ResistanceColor { get; set; }

		[Browsable(false)]
		public string ResistanceColorSerialize
		{
			get { return Serialize.BrushToString(ResistanceColor); }
			set { ResistanceColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Support lines", GroupName = "Plots", Description = "Select color for all support lines", Order = 1)]
		public Brush SupportColor { get; set; }

		[Browsable(false)]
		public string SupportColorSerialize
		{
			get { return Serialize.BrushToString(SupportColor); }
			set { SupportColor = Serialize.StringToBrush(value); }
		}

		[Range(1, int.MaxValue)]
		[Display(Name = "Line width major lines", GroupName = "Plots", Description = "Width for major lines.", Order = 2)]
		public int LineWidthStrong { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Line width minor lines", GroupName = "Plots", Description = "Width for minor lines.", Order = 3)]
		public int LineWidthWeak { get; set; }

		[Display(Name = "Plot style major lines", GroupName = "Plots", Description = "Plot style for major lines.", Order = 4)]
		public PlotStyle StrongPlotStyle { get; set; }

		[Display(Name = "Plot style minor lines", GroupName = "Plots", Description = "Plot style for minor lines.", Order = 5)]
		public PlotStyle WeakPlotStyle { get; set; }

		[Display(Name = "Dash style major lines", GroupName = "Plots", Description = "Dash style for major lines.", Order = 6)]
		public DashStyleHelper StrongDashStyle { get; set; }

		[Display(Name = "Dash style minor lines", GroupName = "Plots", Description = "Dash style for minor lines.", Order = 7)]
		public DashStyleHelper WeakDashStyle { get; set; }
		#endregion
	}
}

public enum ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution
{
	Smallest,
	Small,
	Default,
	Increased,
	Large,
	Largest
}

public enum ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth
{
	Strong,
	Weak
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_AutoFibAlgo_ARC_GoldenFibs[] cacheARC_AutoFibAlgo_ARC_GoldenFibs;
		public ARC.ARC_AutoFibAlgo_ARC_GoldenFibs ARC_AutoFibAlgo_ARC_GoldenFibs(int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			return ARC_AutoFibAlgo_ARC_GoldenFibs(Input, barPeriod, lineDensity, confluenceZone, threshold, lookBackMinute);
		}

		public ARC.ARC_AutoFibAlgo_ARC_GoldenFibs ARC_AutoFibAlgo_ARC_GoldenFibs(ISeries<double> input, int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			if (cacheARC_AutoFibAlgo_ARC_GoldenFibs != null)
				for (int idx = 0; idx < cacheARC_AutoFibAlgo_ARC_GoldenFibs.Length; idx++)
					if (cacheARC_AutoFibAlgo_ARC_GoldenFibs[idx] != null && cacheARC_AutoFibAlgo_ARC_GoldenFibs[idx].BarPeriod == barPeriod && cacheARC_AutoFibAlgo_ARC_GoldenFibs[idx].LineDensity == lineDensity && cacheARC_AutoFibAlgo_ARC_GoldenFibs[idx].ConfluenceZone == confluenceZone && cacheARC_AutoFibAlgo_ARC_GoldenFibs[idx].Threshold == threshold && cacheARC_AutoFibAlgo_ARC_GoldenFibs[idx].LookBackMinute == lookBackMinute && cacheARC_AutoFibAlgo_ARC_GoldenFibs[idx].EqualsInput(input))
						return cacheARC_AutoFibAlgo_ARC_GoldenFibs[idx];
			return CacheIndicator<ARC.ARC_AutoFibAlgo_ARC_GoldenFibs>(new ARC.ARC_AutoFibAlgo_ARC_GoldenFibs(){ BarPeriod = barPeriod, LineDensity = lineDensity, ConfluenceZone = confluenceZone, Threshold = threshold, LookBackMinute = lookBackMinute }, input, ref cacheARC_AutoFibAlgo_ARC_GoldenFibs);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_AutoFibAlgo_ARC_GoldenFibs ARC_AutoFibAlgo_ARC_GoldenFibs(int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			return indicator.ARC_AutoFibAlgo_ARC_GoldenFibs(Input, barPeriod, lineDensity, confluenceZone, threshold, lookBackMinute);
		}

		public Indicators.ARC.ARC_AutoFibAlgo_ARC_GoldenFibs ARC_AutoFibAlgo_ARC_GoldenFibs(ISeries<double> input , int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			return indicator.ARC_AutoFibAlgo_ARC_GoldenFibs(input, barPeriod, lineDensity, confluenceZone, threshold, lookBackMinute);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_AutoFibAlgo_ARC_GoldenFibs ARC_AutoFibAlgo_ARC_GoldenFibs(int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			return indicator.ARC_AutoFibAlgo_ARC_GoldenFibs(Input, barPeriod, lineDensity, confluenceZone, threshold, lookBackMinute);
		}

		public Indicators.ARC.ARC_AutoFibAlgo_ARC_GoldenFibs ARC_AutoFibAlgo_ARC_GoldenFibs(ISeries<double> input , int barPeriod, ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution lineDensity, ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth confluenceZone, double threshold, int lookBackMinute)
		{
			return indicator.ARC_AutoFibAlgo_ARC_GoldenFibs(input, barPeriod, lineDensity, confluenceZone, threshold, lookBackMinute);
		}
	}
}

#endregion
