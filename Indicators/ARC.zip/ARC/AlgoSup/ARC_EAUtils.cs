#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace ARC.AlgoSup.All
{
    #region NS EA Utils
    public static class NsEaUtils
    {
        #region Order Functions
        public static OrderAction GetOpposingOrderAction(this OrderAction action)
        {
            switch (action)
            {
                case OrderAction.Buy: return OrderAction.Sell;
                case OrderAction.SellShort: return OrderAction.BuyToCover;
                case OrderAction.Sell: return OrderAction.Buy;
                default: return OrderAction.SellShort; //this is buy to cover... there aren't any more cases in the enum but the switch case needs a default to return
            }
        }
        #endregion

        #region Get Number Of Decimal Places (for the tick size)
        public static int GetDecimalPlaces(this double number)
        {
            int i = 0;
            while (Math.Round(number, i) != number)
                i++;
            return i;
        }
        #endregion
    }
    #endregion

    #region Draw Sharp DX
    public static class DrawSharpDX
    {
        #region Line
        public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, float x1, float y1, float x2, float y2, Stroke stroke, Tuple<float, float> chartWidthNHeight)
        {
            if (RenderTarget == null || stroke == null || stroke.Brush == Brushes.Transparent || (x1 == x2 && y1 == y2) || !SharpDXUtils.IsLineInChart(x1, y1, x2, y2, chartWidthNHeight))
                return;

            DrawLine(RenderTarget, new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), stroke);
        }

        public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime time1, double price1, DateTime time2, double price2, Stroke stroke)
        {
            if (RenderTarget == null || chartControl == null || chartScale == null || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsLineInChart(time1, price1, time2, price2, chartControl, chartScale))
                return;

            float x1 = chartControl.GetXByTime(time1); float y1 = chartScale.GetYByValue(price1);
            float x2 = chartControl.GetXByTime(time2); float y2 = chartScale.GetYByValue(price2);

            DrawLine(RenderTarget, new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), stroke);
        }

        private static void DrawLine(SharpDX.Direct2D1.RenderTarget RenderTarget, SharpDX.Vector2 vector1, SharpDX.Vector2 vector2, Stroke stroke)
        {
            SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
            SharpDXUtils.WrapInAntiAlias(RenderTarget, () => { RenderTarget.DrawLine(vector1, vector2, brs, stroke.Width, stroke.StrokeStyle); });
            brs.Dispose();
        }
        #endregion

        #region Geometry
        public static void GeometryWithFill(SharpDX.Direct2D1.RenderTarget RenderTarget, List<Tuple<float, float>> Points, Stroke stroke, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight)
        {
            if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.AreAnyPointsInChart(Points, chartWidthNHeight))
                return;

            List<SharpDX.Vector2> points = new List<SharpDX.Vector2>();
            foreach (Tuple<float, float> point in Points)
                points.Add(new SharpDX.Vector2(point.Item1, point.Item2));

            DrawGeometry(RenderTarget, points, stroke, opacity, outline, background);
        }

        public static void GeometryWithFill(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, List<Tuple<DateTime, double>> Points, Stroke stroke, int opacity, bool outline, bool background)
        {
            if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.AreAnyPointsInChart(Points, chartControl, chartScale))
                return;

            List<SharpDX.Vector2> points = new List<SharpDX.Vector2>();
            foreach (Tuple<DateTime, double> point in Points)
                points.Add(new SharpDX.Vector2(chartControl.GetXByTime(point.Item1), chartScale.GetYByValue(point.Item2)));

            DrawGeometry(RenderTarget, points, stroke, opacity, outline, background);
        }

        private static void DrawGeometry(SharpDX.Direct2D1.RenderTarget RenderTarget, List<SharpDX.Vector2> Points, Stroke stroke, int opacity, bool outline, bool background)
        {
            SharpDX.Direct2D1.PathGeometry pathGeometry = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink geometrySink = pathGeometry.Open();

            for (int i = 0; i < Points.Count; i++)
            {
                if (i == 0)
                    geometrySink.BeginFigure(Points[i], SharpDX.Direct2D1.FigureBegin.Filled);
                else
                    geometrySink.AddLine(Points[i]);
            }
            geometrySink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            geometrySink.Close();
            SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
            if (outline)
                RenderTarget.DrawGeometry(pathGeometry, brs, stroke.Width, stroke.StrokeStyle);
            if (background)
            {
                brs.Opacity = opacity / 100f;
                SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                {
                    RenderTarget.FillGeometry(pathGeometry, brs);
                });
            }
            pathGeometry.Dispose(); brs.Dispose(); geometrySink.Dispose();
        }
        #endregion

        #region Box Text
        public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, DateTime time, double price, Stroke stroke, int opacity,
            Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null, bool rounded = false, float radius = 2,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
            SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
        {
            Size size = SharpDXUtils.MeasureString(text, TextFont);
            Tuple<float, float> chartWidthNHeight = SharpDXUtils.GetChartWidthNHeightPropper(chartControl, chartScale);
            float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);

            Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, rounded, radius, horizontalAlign, verticalAlign, backgroundBrush);
            Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
        }

        public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, float x, float y, Stroke stroke, int opacity,
            Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null, bool rounded = false, float radius = 2,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
            SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
        {
            Size size = SharpDXUtils.MeasureString(text, TextFont);
            Tuple<float, float> chartWidthNHeight = SharpDXUtils.GetChartWidthNHeightPropper(chartControl, chartScale);
            Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, rounded, radius, horizontalAlign, verticalAlign, backgroundBrush);
            Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
        }

        public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, Tuple<float, float> chartWidthNHeight, ChartScale chartScale, string text, float x, float y, Stroke stroke, int opacity,
            Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null, bool rounded = false, float radius = 2,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
            SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
        {
            Size size = SharpDXUtils.MeasureString(text, TextFont);
            Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, rounded, radius, horizontalAlign, verticalAlign, backgroundBrush);
            Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
        }

        public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Stroke stroke, int opacity, Brush textBrush, SimpleFont TextFont,
            bool outline, bool background, Tuple<float, float> chartWidthNHeight, Brush backgroundBrush = null, bool rounded = false, float radius = 2,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
            SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
        {
            Box(RenderTarget, x, y, width, height, stroke, opacity, outline, background, chartWidthNHeight, rounded, radius, horizontalAlign, verticalAlign, backgroundBrush);
            Text(RenderTarget, text, x, y, width, height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt); 
        }
        #endregion

        #region Box
        public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, DateTime topLeftTime, double topLeftPrice, DateTime bottomRightTime, double bottomRightPrice,
            int opacity, bool outline, bool background,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
        {
            if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
                return;

            float x1 = chartControl.GetXByTime(topLeftTime); float y1 = chartScale.GetYByValue(topLeftPrice);
            float x2 = chartControl.GetXByTime(bottomRightTime); float y2 = chartScale.GetYByValue(bottomRightPrice);
            float width = x2 - x1; float height = y2 - y1;

            if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                return;

            DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                opacity, outline, background, horizontalAlign, verticalAlign);
        }

        public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, Tuple<DateTime, double> topLeftPoint, Tuple<DateTime, double> bootomRightPoint,
            int opacity, bool outline, bool background,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
        {
            if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
                return;

            float x1 = chartControl.GetXByTime(topLeftPoint.Item1); float y1 = chartScale.GetYByValue(topLeftPoint.Item2);
            float x2 = chartControl.GetXByTime(bootomRightPoint.Item1); float y2 = chartScale.GetYByValue(bootomRightPoint.Item2);
            float width = x2 - x1; float height = y2 - y1;

            if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                return;

            DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                opacity, outline, background, horizontalAlign, verticalAlign);
        }

        public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, Tuple<float, float> topLeftPoint, Tuple<float, float> bootomRightPoint, int opacity,
            bool outline, bool background,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
        {
            if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent ||
                !SharpDXUtils.IsRectangleInChart(topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                return;

            DrawBox(RenderTarget, topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                opacity, outline, background, horizontalAlign, verticalAlign);
        }

        public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, Stroke stroke, Tuple<float, float> topLeftPoint, Tuple<float, float> bootomRightPoint, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
        {
            if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent ||
                !SharpDXUtils.IsRectangleInChart(topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, chartWidthNHeight))
                return;

            DrawBox(RenderTarget, topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                opacity, outline, background, horizontalAlign, verticalAlign);
        }

        public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight,
            bool rounded = false, float radius = 2,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
        {
            if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsRectangleInChart(x, y, width, height, chartWidthNHeight))
                return;
            if(rounded)
                DrawRoundedBox(RenderTarget, x, y, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush, opacity, outline, background, horizontalAlign, verticalAlign, radius);
            else
                DrawBox(RenderTarget, x, y, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush, opacity, outline, background, horizontalAlign, verticalAlign);
        }

        private static void DrawBox(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, Brush backgroundBrush, int opacity, bool outline, bool background,
            SharpDXUtils.HorizontalAlignment horizontalAlign, SharpDXUtils.VerticalAlignment verticalAlign)
        {
            if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Center)
                x -= width / 2;
            if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Right)
                x -= width;
            if (verticalAlign == SharpDXUtils.VerticalAlignment.Center)
                y -= height / 2;
            if (verticalAlign == SharpDXUtils.VerticalAlignment.Bottom)
                y -= height;
            SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
            if (outline)
            {
                SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                {
                    RenderTarget.DrawRectangle(rect, brs, stroke.Width, stroke.StrokeStyle);
                });
                brs.Dispose();
            }
            if (background)
            {
                SharpDX.Direct2D1.Brush brs = backgroundBrush.ToDxBrush(RenderTarget);
                brs.Opacity = (float)(opacity * 0.01f);
                SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                {
                    RenderTarget.FillRectangle(rect, brs);
                });
                brs.Dispose();
            }
        }
        private static void DrawRoundedBox(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, Brush backgroundBrush, int opacity, bool outline, bool background,
            SharpDXUtils.HorizontalAlignment horizontalAlign, SharpDXUtils.VerticalAlignment verticalAlign, float radius)
        {
            if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Center)
                x -= width / 2;
            if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Right)
                x -= width;
            if (verticalAlign == SharpDXUtils.VerticalAlignment.Center)
                y -= height / 2;
            if (verticalAlign == SharpDXUtils.VerticalAlignment.Bottom)
                y -= height;

            SharpDX.RectangleF rect = new SharpDX.RectangleF(x - radius, y - radius, width + radius * 2, height + radius * 2);
            SharpDX.Direct2D1.RoundedRectangle roundRect = new SharpDX.Direct2D1.RoundedRectangle() { Rect = rect, RadiusX = radius, RadiusY = radius };
            if (outline)
            {
                SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                {
                    RenderTarget.DrawRoundedRectangle(roundRect, brs, stroke.Width, stroke.StrokeStyle);
                });
                brs.Dispose();
            }
            if (background)
            {
                SharpDX.Direct2D1.Brush brs = backgroundBrush.ToDxBrush(RenderTarget);
                brs.Opacity = (float)(opacity * 0.01f);
                SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                {
                    RenderTarget.FillRoundedRectangle(roundRect, brs);
                });
                brs.Dispose();
            }
        }
        #endregion

        #region Text
        public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, DateTime time, double price, Brush textBrush, SimpleFont TextFont,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
            SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
        {
            if (RenderTarget == null || chartControl == null || chartScale == null || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
                return;

            float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);
            Size size = SharpDXUtils.MeasureString(text, TextFont);

            if (size.Width == 0 || size.Height == 0 || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                return;

            DrawText(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
        }

        public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, Brush textBrush, SimpleFont TextFont, Tuple<float, float> chartWidthNHeight,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
            SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
        {
            if (RenderTarget == null || string.IsNullOrEmpty(text) || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
                return;
            Size size = SharpDXUtils.MeasureString(text, TextFont);
            if (size.Width == 0 || size.Height == 0 || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, chartWidthNHeight))
                return;
            DrawText(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
        }

        public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Brush textBrush, SimpleFont TextFont, Tuple<float, float> chartWidthNHeight,
            SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
            SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
        {
            if (RenderTarget == null || string.IsNullOrEmpty(text) || width == 0 || height == 0 || textBrush == null || textBrush == Brushes.Transparent || TextFont == null ||
                !SharpDXUtils.IsRectangleInChart(x, y, width, height, chartWidthNHeight))
                return;
            DrawText(RenderTarget, text, x, y, width, height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
        }

        private static void DrawText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Brush textBrush, SimpleFont TextFont, SharpDXUtils.HorizontalAlignment horizontalAlign,
            SharpDXUtils.VerticalAlignment verticalAlign, SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment, SharpDX.DirectWrite.TextAlignment textAlignemnt)
        {
            if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Center)
                x -= width / 2;
            if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Right)
                x -= width;
            if (verticalAlign == SharpDXUtils.VerticalAlignment.Center)
                y -= height / 2;
            if (verticalAlign == SharpDXUtils.VerticalAlignment.Bottom)
                y -= height;
            SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
            SimpleFont fs = new SimpleFont(TextFont.Family.ToString(), TextFont.Size) { Bold = TextFont.Bold, Italic = TextFont.Italic };
            SharpDX.DirectWrite.TextFormat tff = fs.ToDirectWriteTextFormat();
            tff.ParagraphAlignment = paragraphAlignment;
            tff.TextAlignment = textAlignemnt;
            SharpDX.Direct2D1.Brush brs = textBrush.ToDxBrush(RenderTarget);
            SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
            {
                RenderTarget.DrawText(text, tff, rect, brs, SharpDX.Direct2D1.DrawTextOptions.Clip, SharpDX.Direct2D1.MeasuringMode.Natural);
            });
            tff.Dispose();
            brs.Dispose();
        }
        #endregion

        #region Draw Flag
        public static void DrawFlag(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, double price, Stroke stroke, int opacity, int opacityHovered,
            Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null, bool rounded = false, float radius = 2, double flagSize = 100, bool hovered = false)
        {
            Tuple<float, float> chartWidthHeight = SharpDXUtils.GetChartWidthNHeightPropper(chartControl, chartScale);
            float x1 = chartWidthHeight.Item1;
            float x2 = (float)Math.Max(x1 - flagSize, 50);
            x1 += 1000;
            float y = chartScale.GetYByValue(price);
            double h = SharpDXUtils.MeasureString(text, TextFont).Height;
            Line(RenderTarget, x2 + radius, y, x1, y, stroke, chartWidthHeight);
            if (hovered)
                Box(RenderTarget, x2, (float)(y - h / 2), x1 - x2, (float)h, stroke, opacityHovered, false, true, chartWidthHeight);
            BoxText(RenderTarget, chartWidthHeight, chartScale, text, x2, y, stroke, opacity, textBrush, TextFont, outline, background, backgroundBrush, rounded, radius, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center);
        }
        public static void DrawFlag(SharpDX.Direct2D1.RenderTarget RenderTarget, Tuple<float, float> chartWidthHeight, ChartScale chartScale, string text, double price, Stroke stroke, int opacity, int opacityHovered,
            Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null, bool rounded = false, float radius = 2, double flagSize = 100, bool hovered = false)
        {
            float x1 = chartWidthHeight.Item1;
            float x2 = (float)Math.Max(x1 - flagSize, 50);
            x1 += 1000;
            float y = chartScale.GetYByValue(price);
            double h = SharpDXUtils.MeasureString(text, TextFont).Height;
            Line(RenderTarget, x2 + radius, y, x1, y, stroke, chartWidthHeight);
            if (hovered)
                Box(RenderTarget, x2, (float)(y - h / 2), x1 - x2, (float)h, stroke, opacityHovered, false, true, chartWidthHeight);
            BoxText(RenderTarget, chartWidthHeight, chartScale, text, x2, y, stroke, opacity, textBrush, TextFont, outline, background, backgroundBrush, rounded, radius, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center);
        }
        #endregion
    }
    #endregion

    #region Sharp DX Utils
    public static class SharpDXUtils
    {
        #region Get Chart Width and Height
        public static Tuple<float, float> GetChartWidthNHeight(ChartControl chartControl, ChartScale chartScale)
        {
            return new Tuple<float, float>(chartControl.GetXByTime(chartControl.LastTimePainted), chartScale.GetYByValue(chartScale.MinValue));
        }
        public static Tuple<float, float> GetChartWidthNHeightPropper(ChartControl chartControl, ChartScale chartScale)
        {
            if(chartControl.ChartPanels.Count > chartScale.PanelIndex)
                return new Tuple<float, float>(chartControl.ChartPanels[chartScale.PanelIndex].W, chartControl.ChartPanels[chartScale.PanelIndex].H);
            return Tuple.Create(0f, 0f);
        }
        #endregion

        #region Check Co-ordinates in Flag
        public static bool CheckCoordinatesIn(ChartControl chartControl, ChartScale chartScale, double price, string text, SimpleFont TextFont, float x, float y, double flagLength)
        {
            Tuple<float, float> chartWidthHeight = SharpDXUtils.GetChartWidthNHeightPropper(chartControl, chartScale);
            float x1 = chartWidthHeight.Item1;
            float x2 = (float)Math.Max(x1 - flagLength, 50);
            double height = MeasureString(text, TextFont).Height;
            float yc = chartScale.GetYByValue(price);
            return x <= x1 && x >= x2 && y <= yc + height * 0.5 && y >= yc - height * 0.5;
        }
        public static bool CheckCoordinatesIn(Tuple<float, float> chartWidthHeight, ChartScale chartScale, double price, string text, SimpleFont TextFont, float x, float y, double flagLength)
        {
            float x1 = chartWidthHeight.Item1;
            float x2 = (float)Math.Max(x1 - flagLength, 50);
            double height = MeasureString(text, TextFont).Height;
            float yc = chartScale.GetYByValue(price);
            return x <= x1 && x >= x2 && y <= yc + height * 0.5 && y >= yc - height * 0.5;
        }
        #endregion

        #region Measure String
        public static Size MeasureString(string msg, SimpleFont TextFont)
        {
            if (TextFont == null || string.IsNullOrEmpty(msg))
                return new Size(0, 0);

            SimpleFont fs = new SimpleFont(TextFont.Family.ToString(), TextFont.Size) { Bold = TextFont.Bold, Italic = TextFont.Italic };
            using (SharpDX.DirectWrite.TextFormat tff = fs.ToDirectWriteTextFormat())
                using (SharpDX.DirectWrite.TextLayout layout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, tff, 999999, tff.FontSize))
                    return new Size(layout.Metrics.Width, layout.Metrics.Height);
        }
        #endregion

        #region Are Any Points iIn Chart
        public static bool AreAnyPointsInChart(List<Tuple<float, float>> points, Tuple<float, float> chartWidthNHeight)
        {
            foreach (Tuple<float, float> point in points)
                if (IsPointInChart(point.Item1, point.Item2, chartWidthNHeight))
                    return true;
            return false;
        }

        public static bool AreAnyPointsInChart(List<Tuple<DateTime, double>> points, ChartControl chartControl, ChartScale chartScale)
        {
            foreach (Tuple<DateTime, double> point in points)
                if (IsPointInChart(point.Item1, point.Item2, chartControl, chartScale))
                    return true;
            return false;
        }
        #endregion

        #region Is Line In Chart
        public static bool IsLineInChart(float x1, float y1, float x2, float y2, Tuple<float, float> chartWidthNHeight)
        {
            return IsPointInChart(x1, y1, chartWidthNHeight) || IsPointInChart(x2, y2, chartWidthNHeight);
        }

        public static bool IsLineInChart(DateTime x1, double y1, DateTime x2, double y2, ChartControl chartControl, ChartScale chartScale)
        {
            return IsPointInChart(x1, y1, chartControl, chartScale) || IsPointInChart(x2, y2, chartControl, chartScale);
        }
        #endregion

        #region Is Point In Chart
        public static bool IsPointInChart(float x, float y, Tuple<float, float> chartWidthNHeight)
        {
            return x >= -1 && x <= chartWidthNHeight.Item1 + 1 && y >= -1 && y <= chartWidthNHeight.Item2 + 1;
        }

        public static bool IsPointInChart(DateTime x, double y, ChartControl chartControl, ChartScale chartScale)
        {
            return x.CompareTo(chartControl.FirstTimePainted) >= 0 && x.CompareTo(chartControl.LastTimePainted) <= 0 && y >= chartScale.MinValue && y <= chartScale.MaxValue;
        }
        #endregion

        #region Is Rectangle In Chart
        public static bool IsRectangleInChart(SharpDX.RectangleF rectangle, Tuple<float, float> chartWidthNHeight)
        {
            return IsPointInChart(rectangle.X, rectangle.Y, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y, chartWidthNHeight) ||
                IsPointInChart(rectangle.X, rectangle.Y + rectangle.Height, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height, chartWidthNHeight);
        }

        public static bool IsRectangleInChart(float x, float y, float width, float height, Tuple<float, float> chartWidthNHeight)
        {
            SharpDX.RectangleF rectangle = new SharpDX.RectangleF(x, y, width, height);
            return IsPointInChart(rectangle.X, rectangle.Y, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y, chartWidthNHeight) ||
                IsPointInChart(rectangle.X, rectangle.Y + rectangle.Height, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height, chartWidthNHeight);
        }

        public static bool IsRectangleInChart(List<Tuple<DateTime, double>> points, ChartControl chartControl, ChartScale chartScale)
        {
            return AreAnyPointsInChart(points, chartControl, chartScale);
        }

        public static bool IsRectangleInChart(List<Tuple<float, float>> points, Tuple<float, float> chartWidthNHeight)
        {
            return AreAnyPointsInChart(points, chartWidthNHeight);
        }
        #endregion

        #region WrapInAntiAlias
        public static void WrapInAntiAlias(SharpDX.Direct2D1.RenderTarget RenderTarget, Action action)
        {
            SharpDX.Direct2D1.AntialiasMode prev = RenderTarget.AntialiasMode;
            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
            action();
            RenderTarget.AntialiasMode = prev;
        }
        #endregion

        #region Enums

        #region Horizontal Text Alignment
        public enum HorizontalAlignment
        {
            Center,
            Left,
            Right
        }
        #endregion

        #region Vertical Text Alignment
        public enum VerticalAlignment
        {
            Center,
            Top,
            Bottom
        }
        #endregion

        #endregion
    }
    #endregion

    #region Color Utils
    public static class ColorUtils
    {
        public static SolidColorBrush BrushFromArgb(int argb)
        {
            return new SolidColorBrush(System.Windows.Media.Color.FromArgb(
                (byte)(argb >> 24),
                (byte)(argb >> 16),
                (byte)(argb >> 8),
                (byte)(argb)));
        }

        public static SolidColorBrush BrushFromArgb(int alpha, Brush baseBrush)
        {
            var brush = (SolidColorBrush)baseBrush;

            return new SolidColorBrush(System.Windows.Media.Color.FromArgb(
                (byte)alpha,
                brush.Color.R,
                brush.Color.G,
                brush.Color.B));
        }

        public static System.Windows.Media.Color ColorFromIntArgb(int argb)
        {
            return System.Windows.Media.Color.FromArgb(
                                                        (byte)(argb >> 24),
                                                        (byte)(argb >> 16),
                                                        (byte)(argb >> 8),
                                                        (byte)(argb));
        }

        public static SolidColorBrush BrushFromArgb(int alpha, byte R, byte G, byte B)
        {
            return new SolidColorBrush(System.Windows.Media.Color.FromArgb(
                (byte)alpha,
                R,
                G,
                B));
        }

        private static Dictionary<string, BrushStorage> _dicBrushes = new Dictionary<string, BrushStorage>();
        public static string GetBrushName(this Brush brush)
        {
            if(_dicBrushes.Count == 0)
            {
                IEnumerable<string> sBrushes = typeof(Brushes).GetProperties().Select(x => x.Name);
                foreach (string s in sBrushes)
                {
                    SolidColorBrush scbBrush = (SolidColorBrush)typeof(Brushes).GetProperties().FirstOrDefault(x => x.Name == s).GetValue(null, null);
                    if(!_dicBrushes.ContainsKey(scbBrush.ToString()))
                        _dicBrushes.Add(scbBrush.ToString(), new BrushStorage() { Brush = scbBrush, Hash = scbBrush.ToString(), Name = s});
                }
            }
            if (_dicBrushes.ContainsKey(brush.ToString()))
                return _dicBrushes[brush.ToString()].Name;
            return string.Empty;
        }
    }
    public class BrushStorage
    {
        public Brush Brush { get; set; }
        public string Name { get; set; }
        public string Hash { get; set; }
    }
    #endregion
}
