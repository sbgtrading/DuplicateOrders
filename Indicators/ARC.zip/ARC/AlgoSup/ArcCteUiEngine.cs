#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using EasyTraderLean.Settings;
using ARC.AlgoSup.All;
using ARC.AlgoSupLean;
#endregion

namespace ARC.CTESup.UI
{
    #region Position Manager Account
    public class PositionManagerAccount : IDisposable
    {
        #region Floating Variables
        private List<NsPosition> _PositionsShort = new List<NsPosition>();
        private List<NsPosition> _PositionsLong = new List<NsPosition>();
        private EasyTraderSettings _Settings = new EasyTraderSettings();
        private IndicatorBase _Indicator = null;
        private Instrument _Instrument = null;
        private Position _Position = null;
        private State _State = State.Configure;
        #endregion

        #region Initialize
        public void Initialize(IndicatorBase indicator)
        {
            _Indicator = indicator;
            _Instrument = indicator.Instrument;
        }
        #endregion

        #region Update Settings
        public void UpdateSettings(EasyTraderSettings EasyTraderSettings)
        {
            _Settings.UpdateSettings(EasyTraderSettings);

            lock (_PositionsShort)
            {
                if (_PositionsShort.Count > 0)
                {
                    for (int i = 0; i < _PositionsShort.Count; i++)
                        _PositionsShort[i].UpdateSettings(EasyTraderSettings);
                }
            }
            lock (_PositionsLong)
            {
                if (_PositionsLong.Count > 0)
                {
                    for (int i = 0; i < _PositionsLong.Count; i++)
                        _PositionsLong[i].UpdateSettings(EasyTraderSettings);
                }
            }
        }
        #endregion

        #region Entry
        public void Enter(ETradeType TradeType, int quantity, double price = 0)
        {
            lock (_PositionsShort)
            {
                lock (_PositionsLong)
                {
                    if (TradeType == ETradeType.Long && _PositionsShort.Count == 0) 
                    {
                        NsPosition position = CreatePosition(TradeType);
                        position.Enter(_Indicator, quantity, price);
                        _PositionsLong.Add(position);
                    }
                    else if (TradeType == ETradeType.Short && _PositionsLong.Count == 0)
                    {
                        NsPosition position = CreatePosition(TradeType);
                        position.Enter(_Indicator, quantity, price);
                        _PositionsShort.Add(position);
                    }
                }
            }
        }

        public void Enter(PositionPlanner planner, bool isLong, bool isMarket = false)
        {
            NsPosition position = planner.Position.Clone() as NsPosition;
            if (isMarket)
                position.ResetEntryPriceForMarketEntry();

            if (isLong)
            {
                lock (_PositionsLong)
                {
                    //if (_PositionsLong.Count > 0 && _Settings.TargetStopSettings.MergeStops)
                    //    position.UpdateStop(_Indicator, _PositionsLong[0].WorkingTradeStopPrice);
                    position.Enter(_Indicator, position.Stop.Quantity);
                    _PositionsLong.Add(position);
                }
            }
            else
            {
                lock (_PositionsShort)
                {
                    //if (_PositionsShort.Count > 0 && _Settings.TargetStopSettings.MergeStops)
                    //    position.UpdateStop(_Indicator, _PositionsShort[0].WorkingTradeStopPrice);
                    position.Enter(_Indicator, position.Stop.Quantity);
                    _PositionsShort.Add(position);
                }
            }
        }

        public void AlgoEnter(ETradeType TradeType, int quantity, double price = 0)
        {
            lock (_PositionsShort)
            {
                lock (_PositionsLong)
                {
                    if (TradeType == ETradeType.Long && _PositionsShort.Count == 0)
                    {
                        NsPosition position = CreatePosition(TradeType);
                        position.Enter(_Indicator, quantity, price);
                        _PositionsLong.Add(position);
                    }
                    else if (TradeType == ETradeType.Short && _PositionsLong.Count == 0)
                    {
                        NsPosition position = CreatePosition(TradeType);
                        position.Enter(_Indicator, quantity, price);
                        _PositionsShort.Add(position);
                    }
                }
            }
        }
        #endregion

        #region Exit
        public void Exit(EExitType exitType)
        {
            if (_Indicator == null || _Indicator.Instrument == null)
                return;
            //Position _Position = _Account.GetPosition(_Indicator.Instrument.Id);

            //if (position != null && _PositionsLong.Count == 0 && _PositionsShort.Count == 0)
            //{
            //    Order order = _Account.CreateOrder(_Instrument, position.MarketPosition == MarketPosition.Long ? OrderAction.Sell : OrderAction.BuyToCover, OrderType.Market, OrderEntry.Manual, TimeInForce.Gtc,
            //        position.Quantity, 0, 0, "", "Exit Unprotected Position", DateTime.MaxValue, null);
            //    actions.Submit.Add(order);
            //}

            bool bHasExited = false;

            if (exitType.HasFlag(EExitType.Long) || exitType.HasFlag(EExitType.All))
            {
                lock (_PositionsLong)
                {
                    if ((_Position == null || _Position.MarketPosition == MarketPosition.Long) && _PositionsLong.Count > 0)
                    {
                        for (int i = 0; i < _PositionsLong.Count; i++)
                        {
                            if (_PositionsLong[i] != null)
                            {
                                _PositionsLong[i].Exit(_Instrument, exitType);
                                bHasExited = true;
                            }
                        }
                    }
                }
            }
            if (exitType.HasFlag(EExitType.Short) || exitType.HasFlag(EExitType.All))
            {
                lock (_PositionsShort)
                {
                    if ((_Position == null || _Position.MarketPosition == MarketPosition.Short) && _PositionsShort.Count > 0)
                    {
                        for (int i = 0; i < _PositionsShort.Count; i++)
                            if (_PositionsShort[i] != null)
                            {
                                _PositionsShort[i].Exit(_Instrument, exitType);
                                bHasExited = true;
                            }
                    }
                }
            }
            if(!bHasExited && exitType.HasFlag(EExitType.All))
            {
                ArcCteBackEnd.ExitTrade(_Settings.AccountSelectorSettings.SelectedAccount, _Instrument, exitType, string.Empty);
            }
        }

        private void AllEasyAlgos_ExitAll(Instrument instrument)
        {
            if (instrument == null || instrument.Id == _Instrument.Id)
                Exit(EExitType.All);
        }
        #endregion

        #region Exit Instrument
        public void ExitInstrument()
        {
            ARC.CTESup.ArcCteBackEnd.ExitInstrument(_Instrument);
        }
        #endregion

        #region Exit Instrument
        public void ExitEverything()
        {
            ARC.CTESup.ArcCteBackEnd.ExitEverything();
        }
        #endregion

        #region Interfaces
        public void SetState(State state)
        {
            _State = state;
            lock (_PositionsLong)
                if (_PositionsLong.Count > 0)
                    for (int i = 0; i < _PositionsLong.Count; i++)
                        _PositionsLong[i].SetState(_State);
            lock (_PositionsShort)
                if (_PositionsShort.Count > 0)
                    for (int i = 0; i < _PositionsShort.Count; i++)
                        _PositionsShort[i].SetState(_State);
        }

        public void Dispose()
        {
            _Indicator = null;
        }
        #endregion

        #region Internal Functions
        private NsPosition CreatePosition(ETradeType tradeType)
        {
            NsPosition position = new NsPosition(tradeType, _Settings);
            position.SetState(_State);
            return position;
        }
        #endregion
    }
    #endregion

    #region Single Position
    public class NsPosition : IDisposable, ICloneable
    {
        #region Floating Variables
        private double _dEntryPrice = 0;
        private NsOrder _oEntry = null;
        private NsOrder _oStop = null;
        private List<NsOrder> _lstTarget = null;
        private ETradeType _TradeType = ETradeType.Long;
        private ETradeState _TradeState = ETradeState.Nothing;
        private State _State;
        private ESettingsUpdate _SettingsUpdate = ESettingsUpdate.AlwaysUpdate;
        private EasyTraderSettings _Settings = new EasyTraderSettings();
        private string _sID = string.Empty;
        #endregion

        #region Contructors
        public NsPosition() { }
        public NsPosition(ETradeType tradeType, EasyTraderSettings settings = null, ESettingsUpdate settingsUpdate = ESettingsUpdate.AlwaysUpdate)
        {
            if (settings != null)
                _Settings.UpdateSettings(settings);
            _SettingsUpdate = settingsUpdate;
            _TradeType = tradeType;
            _oEntry = new NsOrder(String.Format("{0} {1}", "Entry", _TradeType == ETradeType.Long ? "Long" : "Short"), _TradeType == ETradeType.Long ? OrderAction.Buy : OrderAction.SellShort, 0);
            _oStop = new NsOrder(String.Format("{0} {1}", "Stop", _TradeType == ETradeType.Long ? "Long" : "Short"), _TradeType == ETradeType.Long ? OrderAction.Sell : OrderAction.BuyToCover, 0, OrderType.StopMarket);
            _lstTarget = new List<NsOrder>();

            //build target list for initialize
            _lstTarget.Add(new NsOrder(String.Format("{0} 1 {1}", "Target", _TradeType == ETradeType.Long ? "Long" : "Short"), _TradeType == ETradeType.Long ? OrderAction.Sell : OrderAction.BuyToCover, 0, OrderType.Limit));
            _lstTarget.Add(new NsOrder(String.Format("{0} 2 {1}", "Target", _TradeType == ETradeType.Long ? "Long" : "Short"), _TradeType == ETradeType.Long ? OrderAction.Sell : OrderAction.BuyToCover, 0, OrderType.Limit));
            _lstTarget.Add(new NsOrder(String.Format("{0} 3 {1}", "Target", _TradeType == ETradeType.Long ? "Long" : "Short"), _TradeType == ETradeType.Long ? OrderAction.Sell : OrderAction.BuyToCover, 0, OrderType.Limit));

            _TradeState = ETradeState.Nothing;
            _sID = DateTime.Now.ToString("yyyy/MM/dd-hh:mm:ss.ffff") + Guid.NewGuid().ToString();
        }
        #endregion

        #region Update Settings
        public void UpdateSettings(EasyTraderSettings settings)
        {
            if (_SettingsUpdate == ESettingsUpdate.NeverUpdate)
                return;

            if (_SettingsUpdate == ESettingsUpdate.UpdateTrailOnly)
                return;

            _Settings.TargetStopSettings.UpdateSettings(settings.TargetStopSettings.Clone() as TargetStopSettings);
            _Settings.EntryQuantitySettings.UpdateSettings(settings.EntryQuantitySettings.Clone() as EntryQuantitySettings);

            if (_lstTarget.Count == 3)
            {
                _lstTarget[0].Active = _Settings.TargetStopSettings.Target1.UseTarget;
                _lstTarget[1].Active = _Settings.TargetStopSettings.Target2.UseTarget;
                _lstTarget[2].Active = _Settings.TargetStopSettings.Target3.UseTarget;
                _lstTarget[0].Values.Quantity = _Settings.TargetStopSettings.Target1.Quantity;
                _lstTarget[1].Values.Quantity = _Settings.TargetStopSettings.Target2.Quantity;
                _lstTarget[2].Values.Quantity = _Settings.TargetStopSettings.Target3.Quantity;
            }

            if (_SettingsUpdate == ESettingsUpdate.UpdateTrailStopTargetQuantity)
                return;

            _Settings.UpdateSettings(settings);
        }
        #endregion

        #region Update Prices
        public void ResetEntryPriceForMarketEntry()
        {
            _dEntryPrice = 0;
        }
        public void UpdateEntryPrice(IndicatorBase indicator, double price = 0)
        {
            if (price > 0)
                _dEntryPrice = indicator.Instrument.MasterInstrument.RoundToTickSize(price);
            else
                _dEntryPrice = _TradeType == ETradeType.Long ? indicator.GetCurrentBid() : indicator.GetCurrentAsk();
            _oEntry.Values.Price = _dEntryPrice;
            CalculateStop(indicator);
            CalculateTarget(indicator);
            UpdateRiskReward();
        }
        public void UpdateStop(IndicatorBase indicator, double price)
        {
            _Settings.TargetStopSettings.StopValue = GetValue(indicator, price);
            CalculateStop(indicator);
            //if (_vmSettings.TargetStopSettings.UseRiskReward)
            CalculateTarget(indicator);
            UpdateRiskReward();
        }
        public void UpdateTarget1(IndicatorBase indicator, double price)
        {
            _Settings.TargetStopSettings.Target1.Target = GetValue(indicator, price);
            CalculateTarget(indicator);
            UpdateRiskReward();
        }
        public void UpdateTarget2(IndicatorBase indicator, double price)
        {
            _Settings.TargetStopSettings.Target2.Target = GetValue(indicator, price);
            CalculateTarget(indicator);
            UpdateRiskReward();
        }
        public void UpdateTarget3(IndicatorBase indicator, double price)
        {
            _Settings.TargetStopSettings.Target3.Target = GetValue(indicator, price);
            CalculateTarget(indicator);
            UpdateRiskReward();
        }
        public void UpdateRiskReward()
        {
            _Settings.TradePlannerSettingsPlan.Risk = Stop.USD;
            _Settings.TradePlannerSettingsPlan.RiskTicks = Stop.Ticks;
            _Settings.TradePlannerSettingsPlan.Reward = Target1.USD + Target2.USD + Target3.USD;
            _Settings.TradePlannerSettingsPlan.RewardTicks = Target1.Ticks + Target2.Ticks + Target3.Ticks;
            _Settings.TradePlannerSettingsPlan.Ratio = _Settings.TradePlannerSettingsPlan.Reward == 0 || _Settings.TradePlannerSettingsPlan.Risk == 0 ? 0 : _Settings.TradePlannerSettingsPlan.Reward / _Settings.TradePlannerSettingsPlan.Risk;
        }
        private double GetValue(IndicatorBase indicator, double price)
        {
            double dPrice = _dEntryPrice != 0 ? _dEntryPrice : indicator.GetCurrentBid();
            return indicator.Instrument.MasterInstrument.RoundToTickSize(Math.Abs(price - dPrice)) / indicator.TickSize;
        }
        public TargetStopSettings GetTargetStopSettings()
        {
            return _Settings.TargetStopSettings;
        }
        public TradePlannerSettings GetRiskReward()
        {
            return _Settings.TradePlannerSettingsPlan;
        }
        #endregion

        #region Enter
        public TradeSettings Enter(IndicatorBase indicator, int quantity, double price = 0, string OCO = "")
        {
            bool bIsMarket = price == 0 && _dEntryPrice == 0;

            UpdateEntryPrice(indicator, Math.Max(_dEntryPrice, price));

            if (_dEntryPrice == 0 && price != 0)
                _dEntryPrice = price;
            if (bIsMarket)
                _dEntryPrice = 0;

            double dPrice = indicator.Closes[_oEntry.BarsInProgress][0];

            if (_dEntryPrice > 0)
            {
                if (_State != State.Realtime)
                {
                    if (_dEntryPrice == dPrice)
                        _oEntry.OrderType = OrderType.Market;
                    else if (_dEntryPrice > dPrice)
                        _oEntry.OrderType = _TradeType == ETradeType.Long ? OrderType.StopMarket : OrderType.Limit;
                    else if (_dEntryPrice < dPrice)
                        _oEntry.OrderType = _TradeType == ETradeType.Long ? OrderType.Limit : OrderType.StopMarket;
                }
                else
                {
                    if (_dEntryPrice >= indicator.GetCurrentAsk(_oEntry.BarsInProgress))
                    {
                        dPrice = indicator.GetCurrentAsk(_oEntry.BarsInProgress);
                        _oEntry.OrderType = _TradeType == ETradeType.Long ? OrderType.StopMarket : OrderType.Limit;
                    }
                    else if (_dEntryPrice <= indicator.GetCurrentBid(_oEntry.BarsInProgress))
                    {
                        dPrice = indicator.GetCurrentBid(_oEntry.BarsInProgress);
                        _oEntry.OrderType = _TradeType == ETradeType.Long ? OrderType.Limit : OrderType.StopMarket;
                    }
                    else
                        _oEntry.OrderType = OrderType.Market;
                }
            }
            else
                _oEntry.OrderType = OrderType.Market;

            _oEntry.Values.Price = _dEntryPrice;

            TradeSettings trade = BuildTrade();

            ArcCteBackEnd.EnterTrade(_Settings.AccountSelectorSettings.SelectedAccount, indicator.Instrument, _TradeType, trade, dPrice, _sID);

            return trade;

            //if (_TradeState == ETradeState.Nothing && !_oEntry.IsOrderLive)
            //{
            //    //initialize stuff
            //    _TradeState = ETradeState.EntrySubmitted;
            //    if (!string.IsNullOrEmpty(OCO) && !string.IsNullOrWhiteSpace(OCO))
            //        _oEntry.Oco = OCO;
            //    if(_dEntryPrice == 0 && price != 0)
            //        _dEntryPrice = price;
            //    //check price for the entry to give the order type for the entry
            //    if (_dEntryPrice > 0)
            //    {
            //        if (_State != State.Realtime)
            //        {
            //            if (_dEntryPrice == indicator.Closes[_oEntry.BarsInProgress][0])
            //                _oEntry.OrderType = OrderType.Market;
            //            else if (_dEntryPrice > indicator.Closes[_oEntry.BarsInProgress][0])
            //                _oEntry.OrderType = _TradeType == ETradeType.Long ? OrderType.StopMarket : OrderType.Limit;
            //            else if (_dEntryPrice < indicator.Closes[_oEntry.BarsInProgress][0])
            //                _oEntry.OrderType = _TradeType == ETradeType.Long ? OrderType.Limit : OrderType.StopMarket;
            //        }
            //        else
            //        {
            //            if (_dEntryPrice >= indicator.GetCurrentAsk(_oEntry.BarsInProgress))
            //                _oEntry.OrderType = _TradeType == ETradeType.Long ? OrderType.StopMarket : OrderType.Limit;
            //            else if (_dEntryPrice <= indicator.GetCurrentBid(_oEntry.BarsInProgress))
            //                _oEntry.OrderType = _TradeType == ETradeType.Long ? OrderType.Limit : OrderType.StopMarket;
            //            else
            //                _oEntry.OrderType = OrderType.Market;
            //        }
            //    }
            //    else
            //        _oEntry.OrderType = OrderType.Market;

            //    _oEntry.Values.Price = _dEntryPrice;

            //    actions = _oEntry.Enter(indicator, account, quantity, actions);
            //}
            //return actions;
        }
        #endregion

        #region Exit
        public void Exit(Instrument instrument, EExitType exitType)
        {
            ArcCteBackEnd.ExitTrade(_Settings.AccountSelectorSettings.SelectedAccount, instrument, exitType, _sID);
            //if (_oStop != null)
            //    actions = _oStop.Exit(instrument, account, exitType, actions);
            //if (_lstTarget != null && _lstTarget.Count > 0)
            //    for (int i = 0; i < _lstTarget.Count; i++)
            //        actions = _lstTarget[i].Exit(instrument, account, exitType, actions);
            //if (_oEntry != null)
            //    actions = _oEntry.Exit(instrument, account, exitType, actions);
            ////Here we check to make sure that something has been submitted so we know to make sure to look in the order update to update the trade state as well, after the exit is complete
            //if (actions.HasSomethingInIt())
            //    _TradeState = ETradeState.ExitSubmitted;
            //else if (_TradeState != ETradeState.ExitSubmitted)
            //    _TradeState = ETradeState.Nothing;
            //return actions;
        }
        #endregion

        #region Build Trade
        private TradeSettings BuildTrade()
        {
            TradeSettings trade = new TradeSettings();

            trade.Entry = _oEntry.GetTradeDetails(_Settings.EntryQuantitySettings.Quantity);
            trade.Stop = _oStop.GetTradeDetails();
            if (_lstTarget.Count > 0)
            {
                for (int i = 0; i < _lstTarget.Count; i++)
                {
                    if (!_lstTarget[i].Active || _lstTarget[i].Values.Quantity == 0)
                        break;
                    trade.Targets.Add(_lstTarget[i].GetTradeDetails());
                }
            }

            return trade;
        }
        #endregion

        #region Stop & Target
        public void CalculateStop(IndicatorBase indicator)
        {
            if (indicator == null)
                return;
            if (_Settings.TargetStopSettings.StopValue > 0)
            {
                _oStop.Values.Price = _oEntry.Values.Price + (_TradeType == ETradeType.Long ? -1 : 1) * indicator.TickSize * _Settings.TargetStopSettings.StopValue;
                _oStop.Values.Quantity = _Settings.EntryQuantitySettings.Quantity;
                _oStop.Values.DistanceFromEntry = (int)_Settings.TargetStopSettings.StopValue;
                _oStop.Values.Ticks = _Settings.TargetStopSettings.StopValue * _oStop.Values.Quantity;
                _oStop.Values.USD = indicator.TickSize * indicator.Instrument.MasterInstrument.PointValue * _Settings.TargetStopSettings.StopValue * _oStop.Values.Quantity;
                UpdateRiskReward();
                return;
            }
            _oStop.Values.Reset();
        }

        #region Calculate Targets N Stops
        public void CalculateTargetsNStops(int iQuantity)
        {
            if (_Settings.TargetStopSettings.Target1.Quantity >= iQuantity)
            {
                _Settings.TargetStopSettings.Target1.Quantity = iQuantity;
                _Settings.TargetStopSettings.Target2.UseTarget = false;
                _Settings.TargetStopSettings.Target3.UseTarget = false;
            }
            else if (_Settings.TargetStopSettings.Target1.Quantity + _Settings.TargetStopSettings.Target2.Quantity >= iQuantity)
            {
                _Settings.TargetStopSettings.Target2.Quantity = iQuantity - _Settings.TargetStopSettings.Target1.Quantity;
                _Settings.TargetStopSettings.Target3.UseTarget = false;
            }
            else if (_Settings.TargetStopSettings.Target1.Quantity + _Settings.TargetStopSettings.Target2.Quantity + _Settings.TargetStopSettings.Target3.Quantity >= iQuantity)
            {
                _Settings.TargetStopSettings.Target3.Quantity = iQuantity - _Settings.TargetStopSettings.Target1.Quantity - _Settings.TargetStopSettings.Target2.Quantity;
            }
        }
        #endregion

        public void CalculateTarget(IndicatorBase indicator)
        {
            if (indicator == null)
                return;
            if (_lstTarget.Count > 0)
            {
                CalculateTargetsNStops(_Settings.EntryQuantitySettings.Quantity);
                double difference = Math.Abs(_oEntry.Values.Price - _oStop.Values.Price);
                int n = 0;
                for (int i = 0; i < _lstTarget.Count; i++)
                    _lstTarget[i].Values.Reset();
                //_lstTarget[n].Values.Reset();
                if (_lstTarget[n].Active)
                {
                    if (_Settings.TargetStopSettings.Target1.UseTarget && _Settings.TargetStopSettings.Target1.Target > 0 && _Settings.TargetStopSettings.Target1.Quantity > 0)
                    {
                        double multiple = (_Settings.TargetStopSettings.UseRiskReward ? indicator.Instrument.MasterInstrument.RoundToTickSize(difference * _Settings.TargetStopSettings.Target1.RiskRewardMultiplier) : indicator.TickSize * _Settings.TargetStopSettings.Target1.Target);
                        _lstTarget[n].Values.Price = _oEntry.Values.Price + (_TradeType == ETradeType.Long ? 1 : -1) * multiple;
                        _lstTarget[n].Values.Quantity = _Settings.TargetStopSettings.Target1.Quantity;
                        _lstTarget[n].Values.DistanceFromEntry = (int)(multiple / indicator.TickSize);
                        _lstTarget[n].Values.Ticks = (multiple * _lstTarget[n].Values.Quantity) / indicator.TickSize;
                        _lstTarget[n].Values.USD = indicator.Instrument.MasterInstrument.PointValue * multiple * _lstTarget[n].Values.Quantity;
                    }
                    n++;
                    //_lstTarget[n].Values.Reset();
                    if (_lstTarget[n].Active)
                    {
                        if (_Settings.TargetStopSettings.Target2.UseTarget && _Settings.TargetStopSettings.Target2.Target > 0 && _Settings.TargetStopSettings.Target2.Quantity > 0)
                        {
                            double multiple = _Settings.TargetStopSettings.UseRiskReward ? indicator.Instrument.MasterInstrument.RoundToTickSize(difference * _Settings.TargetStopSettings.Target2.RiskRewardMultiplier) : indicator.TickSize * _Settings.TargetStopSettings.Target2.Target;
                            _lstTarget[n].Values.Price = _oEntry.Values.Price + (_TradeType == ETradeType.Long ? 1 : -1) * multiple;
                            _lstTarget[n].Values.Quantity = _Settings.TargetStopSettings.Target2.Quantity;
                            _lstTarget[n].Values.DistanceFromEntry = (int)(multiple / indicator.TickSize);
                            _lstTarget[n].Values.Ticks = (multiple * _lstTarget[n].Values.Quantity) / indicator.TickSize;
                            _lstTarget[n].Values.USD = indicator.Instrument.MasterInstrument.PointValue * multiple * _lstTarget[n].Values.Quantity;
                        }
                        n++;
                        //_lstTarget[n].Values.Reset();
                        if (_lstTarget[n].Active)
                        {
                            if (_Settings.TargetStopSettings.Target3.UseTarget && _Settings.TargetStopSettings.Target3.Target > 0 && _Settings.TargetStopSettings.Target3.Quantity > 0)
                            {
                                double multiple = _Settings.TargetStopSettings.UseRiskReward ? indicator.Instrument.MasterInstrument.RoundToTickSize(difference * _Settings.TargetStopSettings.Target3.RiskRewardMultiplier) : indicator.TickSize * _Settings.TargetStopSettings.Target3.Target;
                                _lstTarget[n].Values.Price = _oEntry.Values.Price + (_TradeType == ETradeType.Long ? 1 : -1) * multiple;
                                _lstTarget[n].Values.Quantity = _Settings.TargetStopSettings.Target3.Quantity;
                                _lstTarget[n].Values.DistanceFromEntry = (int)(multiple / indicator.TickSize);
                                _lstTarget[n].Values.Ticks = (multiple * _lstTarget[n].Values.Quantity) / indicator.TickSize;
                                _lstTarget[n].Values.USD = indicator.Instrument.MasterInstrument.PointValue * multiple * _lstTarget[n].Values.Quantity;
                            }
                        }
                    }
                }
                UpdateRiskReward();
            }
        }
        #endregion

        #region Interface Stuff
        public void SetState(State state)
        {
            _State = state;
        }

        public void Clean()
        {
            _TradeState = ETradeState.Nothing;
            _oEntry.Clean();
            _oStop.Clean();
            for (int i = 0; i < _lstTarget.Count; i++)
                _lstTarget[i].Clean();
        }

        public void Dispose()
        {
            _TradeState = ETradeState.Nothing;
            _oEntry.Dispose(); _oEntry = null;
            _oStop.Dispose(); _oStop = null;
            if (_lstTarget.Count > 0)
                for (int i = 0; i < _lstTarget.Count; i++)
                    _lstTarget[i].Dispose();
            _lstTarget.Clear();
            _lstTarget = null;
        }

        public object Clone()
        {
            List<NsOrder> lstOrders = new List<NsOrder>();
            foreach (NsOrder order in _lstTarget)
                lstOrders.Add(order.Clone() as NsOrder);
            return new NsPosition()
            {
                _dEntryPrice = _dEntryPrice,
                _oEntry = _oEntry.Clone() as NsOrder,
                _oStop = _oStop.Clone() as NsOrder,
                _lstTarget = lstOrders,
                _Settings = _Settings,
                _State = _State,
                _TradeType = _TradeType,
                _SettingsUpdate = _SettingsUpdate,
                _sID = _sID
            };
        }
        #endregion

        #region Properties
        public ETradeState PositionState
        {
            get { return _TradeState; }
        }
        public bool OrderIdentified { get; set; }
        public ESettingsUpdate SettingsUpdate
        {
            get { return _SettingsUpdate; }
            set { _SettingsUpdate = value; }
        }
        //public double WorkingTradeStopPrice
        //{
        //    get
        //    {
        //        return _oStop != null && _oStop.Order != null ? _oStop.Order.StopPrice : 0;
        //    }
        //}

        public IndividualValue Entry { get { return _oEntry.Values; } }
        public IndividualValue Stop { get { return _oStop.Values; } }
        public IndividualValue Target1 { get { return _lstTarget.Count > 0 ? _lstTarget[0].Values : new IndividualValue(); } }
        public IndividualValue Target2 { get { return _lstTarget.Count > 1 ? _lstTarget[1].Values : new IndividualValue(); } }
        public IndividualValue Target3 { get { return _lstTarget.Count > 2 ? _lstTarget[2].Values : new IndividualValue(); } }

        public double EntryPrice { get { return _dEntryPrice; } }
        #endregion
    }
    #endregion

    #region Single Order
    public class NsOrder : IDisposable, ICloneable
    {
        #region Properties
        public bool Active { get; set; }
        public string Name { get; set; }
        public string Oco { get; set; }
        public int BarsInProgress { get; set; }
        public IndividualValue Values { get; set; }
        public bool PriceChange { get; set; }
        public bool QuantityChange { get; set; }
        public bool OrderIdentified { get; set; }
        public OrderAction Action { get; set; }
        public OrderType OrderType { get; set; }
        public bool IsOrderLive
        {
            get { return Active; }
        }
        #endregion

        #region Contructors
        public NsOrder(string name, OrderAction orderAction, int barsInProgress, OrderType orderType = OrderType.Market, bool active = true)
        {
            Action = orderAction;
            BarsInProgress = barsInProgress;
            Name = name;
            OrderType = orderType;
            Active = active;
            Oco = String.Empty;
            Values = new IndividualValue();
        }
        #endregion

        #region Get Trade Deatails
        public TradeDetails GetTradeDetails(int quantity = 0)
        {
            return new TradeDetails() { Price = Values.Price, Ticks = Values.DistanceFromEntry, Quantity = quantity == 0 ? Values.Quantity : quantity };
        }
        #endregion

        #region Cleaners
        public void Clean()
        {
            Oco = String.Empty;
        }

        public void Dispose()
        {
            Clean();
            Active = false;
        }
        #endregion

        #region Clone
        public object Clone()
        {
            return new NsOrder(Name, Action, BarsInProgress, OrderType, Active)
            {
                Values = Values.Clone() as IndividualValue
            };
        }
        #endregion
    }
    #endregion
}


