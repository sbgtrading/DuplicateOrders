#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using ARC.CTESup.UI;
using EasyTraderLean.Settings;
using NinjaTrader.NinjaScript.Indicators;
using ARC.AlgoSup.All;
#endregion

namespace ARC.AlgoSupLean
{
	#region Planner Base
	public class PlannerBase
	{
		#region Floating Variables
		internal ChartControl _ChartControl = null;
		internal ChartScale _ChartScale = null;
		internal EasyTraderSettings _Settings = null;
		internal ColorSettings _Colors = null;
        internal ARC.CTESup.ETradeType _TradeType = ARC.CTESup.ETradeType.Long;
        internal bool _bIsAnyGrabbed = false;
		internal Tuple<float, float> _tFFChartWidthNHeight = new Tuple<float, float>(0, 0);
		#endregion

		#region Constructor
		public PlannerBase(ARC.CTESup.ETradeType tradeType, EasyTraderSettings settings, ColorSettings colors)
		{
			_Settings = settings;
			_Colors = colors;
            _TradeType = tradeType;
            IsEnabled = false;
		}
		#endregion

		#region Update Settings
		public virtual void UpdateSettings(EasyTraderSettings settings, IndicatorBase indicator)
		{
			_Settings.UpdateSettings(settings.Clone() as EasyTraderSettings);
		}
        #endregion

        #region Update Entry Price
        public virtual void UpdateEntryPrice(EasyTraderSettings settings, IndicatorBase indicator, double entryPrice = 0)
        {
        }
		#endregion

		#region Update Chart Width N Height
		private void UpdateChartWidthNHeight()
		{
			if (_ChartControl == null || _ChartScale == null)
			{
                _tFFChartWidthNHeight = new Tuple<float, float>(0, 0);
                return;
			}
			_tFFChartWidthNHeight = SharpDXUtils.GetChartWidthNHeightPropper(_ChartControl, _ChartScale);
		}
		#endregion

		#region Check Chart Width and Height Set
		protected bool CheckWidthNHeightSet()
		{
			return _tFFChartWidthNHeight != new Tuple<float, float>(0, 0);
		}
		#endregion

		#region Draw
		public virtual void Draw(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Instrument instrument)
		{
            _ChartControl = chartControl;
            _ChartScale = chartScale;
            UpdateChartWidthNHeight();
        }
		#endregion

		#region Mouse Move
		public virtual bool MouseMove(float x, float y, IndicatorBase indicator)
		{
			return false;
		}
		#endregion

		#region Check Hover
		public virtual void CheckHover(float x, float y)
		{
			ReleaseGrab();
		}
		#endregion

		#region Mouse Down
		public virtual void MouseDown(bool down)
		{
		}
		#endregion

		#region Release Grab
		protected virtual void ReleaseGrab()
		{
		}
		#endregion

		#region Properties
		public virtual bool IsEnabled { get; set; }
		public bool IsAnyGrabbed { get { return _bIsAnyGrabbed; } }
		#endregion
	}
	#endregion

	#region Position Planner
	public class PositionPlanner : PlannerBase
	{
		#region Floating Variables
		private NsPosition _Position = null;
		#endregion

		#region Constructor
		public PositionPlanner(ARC.CTESup.ETradeType tradeType, EasyTraderSettings settings, ColorSettings colors) :
			base(tradeType ,settings, colors)
		{
			_Position = new NsPosition(_TradeType, _Settings, ARC.CTESup.ESettingsUpdate.UpdateTrailStopTargetQuantity);
		}
		#endregion

		#region Update Entry Price
		public override void UpdateEntryPrice(EasyTraderSettings settings, IndicatorBase indicator, double entryPrice = 0)
		{
            if (indicator == null || settings == null)
                return;
            if (!IsEnabled)
			{
				_Position.SettingsUpdate = ARC.CTESup.ESettingsUpdate.NeverUpdate;
				return;
			}
			_Position.SettingsUpdate = ARC.CTESup.ESettingsUpdate.UpdateTrailStopTargetQuantity;
			_Settings = settings;
			_Position.UpdateSettings(_Settings);
			_Position.UpdateEntryPrice(indicator);
			_ChartControl.InvalidateVisual();
		}
		#endregion

		#region Update Settings
		public override void UpdateSettings(EasyTraderSettings settings, IndicatorBase indicator)
		{
			if (indicator == null || settings == null)
				return;
			base.UpdateSettings(settings, indicator);
			_Position.UpdateSettings(_Settings);
			_Position.CalculateStop(indicator);
			_Position.CalculateTarget(indicator);
			InvokeAction(() => { _ChartControl.InvalidateVisual(); });
		}
        #endregion

        #region Invoke Action
        private void InvokeAction(Action p)
        {
			if (_ChartControl == null)
				return;
            if (_ChartControl.Dispatcher.CheckAccess())
            {
                p();
            }
            else
            {
                _ChartControl.Dispatcher.InvokeAsync(p);
            }
        }
        #endregion

        #region Draw
        public override void Draw(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Instrument instrument)
		{
			base.Draw(RenderTarget, chartControl, chartScale, instrument);
			if (!IsEnabled || !CheckWidthNHeightSet() || _ChartControl == null || _ChartScale == null || _Position == null || _Position.Entry.Price <= 0)
				return;
			float radius = 4;
			int iOpacityHovered = 10;
			int iOpacity = 75;
			DrawSharpDX.DrawFlag(RenderTarget, _tFFChartWidthNHeight, chartScale, String.Format("{2} [Qty = {0}] | {1}", _Position.Stop.Quantity, instrument.MasterInstrument.FormatPrice(_Position.Entry.Price), _Colors.ShortOrderNames ? "E" : "Entry"),
				_Position.Entry.Price, _Position.Entry.Hovered ? _Colors.Hovered : _Colors.Entry, iOpacity, iOpacityHovered, _Colors.Text, _Colors.Font, true, true, _Colors.FlagBackground, true, radius, _Colors.FlagLength, _Position.Entry.Hovered);
			if (_Position.Stop.Price > 0)
				DrawSharpDX.DrawFlag(RenderTarget, _tFFChartWidthNHeight, chartScale,
					String.Format("{3} [Qty = {0}] | {1:C2} | {2}", _Position.Stop.Quantity, _Position.Stop.USD, instrument.MasterInstrument.FormatPrice(_Position.Stop.Price), _Colors.ShortOrderNames ? "S" : "StopLoss"),
					_Position.Stop.Price, _Position.Stop.Hovered ? _Colors.Hovered : _Colors.Stop, iOpacity, iOpacityHovered, _Colors.Text, _Colors.Font, true, true, _Colors.FlagBackground, true, radius, _Colors.FlagLength, _Position.Stop.Hovered);
			if (_Position.Target1.Price > 0)
				DrawSharpDX.DrawFlag(RenderTarget, _tFFChartWidthNHeight, chartScale,
					String.Format("{3} [Qty = {0}] | {1:C2} | {2}", _Position.Target1.Quantity, _Position.Target1.USD, instrument.MasterInstrument.FormatPrice(_Position.Target1.Price), _Colors.ShortOrderNames ? "T1" : "Target 1"),
					_Position.Target1.Price, _Position.Target1.Hovered ? _Colors.Hovered : _Colors.Target, iOpacity, iOpacityHovered, _Colors.Text, _Colors.Font, true, true, _Colors.FlagBackground, true, radius, _Colors.FlagLength, _Position.Target1.Hovered);
			if (_Position.Target2.Price > 0)
				DrawSharpDX.DrawFlag(RenderTarget, _tFFChartWidthNHeight, chartScale,
					String.Format("{3} [Qty = {0}] | {1:C2} | {2}", _Position.Target2.Quantity, _Position.Target2.USD, instrument.MasterInstrument.FormatPrice(_Position.Target2.Price), _Colors.ShortOrderNames ? "T2" : "Target 2"),
					_Position.Target2.Price, _Position.Target2.Hovered ? _Colors.Hovered : _Colors.Target, iOpacity, iOpacityHovered, _Colors.Text, _Colors.Font, true, true, _Colors.FlagBackground, true, radius, _Colors.FlagLength, _Position.Target2.Hovered);
			if (_Position.Target3.Price > 0)
				DrawSharpDX.DrawFlag(RenderTarget, _tFFChartWidthNHeight, chartScale,
					String.Format("{3} [Qty = {0}] | {1:C2} | {2}", _Position.Target3.Quantity, _Position.Target3.USD, instrument.MasterInstrument.FormatPrice(_Position.Target3.Price), _Colors.ShortOrderNames ? "T3" : "Target 3"),
					_Position.Target3.Price, _Position.Target3.Hovered ? _Colors.Hovered : _Colors.Target, iOpacity, iOpacityHovered, _Colors.Text, _Colors.Font, true, true, _Colors.FlagBackground, true, radius, _Colors.FlagLength, _Position.Target3.Hovered);
		}
		#endregion

		#region Mouse Move
		public override bool MouseMove(float x, float y, IndicatorBase indicator)
		{
			if (indicator == null || !_bIsAnyGrabbed)
				return false;

			double dPrice = _ChartScale.GetValueByY(y);
			if (_Position.Entry.IsGrabbed)
				_Position.UpdateEntryPrice(indicator, dPrice);
			if (_Position.Stop.IsGrabbed)
				_Position.UpdateStop(indicator, dPrice);
			if (_Position.Target1.IsGrabbed)
				_Position.UpdateTarget1(indicator, dPrice);
			if (_Position.Target2.IsGrabbed)
				_Position.UpdateTarget2(indicator, dPrice);
			if (_Position.Target3.IsGrabbed)
				_Position.UpdateTarget3(indicator, dPrice);
			_Position.SettingsUpdate = ARC.CTESup.ESettingsUpdate.UpdateTrailStopTargetQuantity;
			_ChartControl.InvalidateVisual();
			return true;
		}
		#endregion

		#region Check Hover
		public override void CheckHover(float x, float y)
		{
			base.CheckHover(x, y);
			if (!CheckWidthNHeightSet() || _ChartControl == null)
				return;
            _Position.Entry.Hovered = SharpDXUtils.CheckCoordinatesIn(_tFFChartWidthNHeight, _ChartScale, _Position.Entry.Price, "X", _Colors.Font, x, y, _Colors.FlagLength);
			_Position.Stop.Hovered = SharpDXUtils.CheckCoordinatesIn(_tFFChartWidthNHeight, _ChartScale, _Position.Stop.Price, "X", _Colors.Font, x, y, _Colors.FlagLength);
			_Position.Target1.Hovered = SharpDXUtils.CheckCoordinatesIn(_tFFChartWidthNHeight, _ChartScale, _Position.Target1.Price, "X", _Colors.Font, x, y, _Colors.FlagLength);
			_Position.Target2.Hovered = SharpDXUtils.CheckCoordinatesIn(_tFFChartWidthNHeight, _ChartScale, _Position.Target2.Price, "X", _Colors.Font, x, y, _Colors.FlagLength);
			_Position.Target3.Hovered = SharpDXUtils.CheckCoordinatesIn(_tFFChartWidthNHeight, _ChartScale, _Position.Target3.Price, "X", _Colors.Font, x, y, _Colors.FlagLength);
			if (_Position.Entry.Hovered || _Position.Stop.Hovered || _Position.Target1.Hovered || _Position.Target2.Hovered || _Position.Target3.Hovered)
				_ChartControl.InvalidateVisual();
		}
		#endregion

		#region Mouse Down
		public override void MouseDown(bool down)
		{
			if(_ChartControl == null)
				return;

			if (down)
			{
				if (_bIsAnyGrabbed)
					return;
				if (_Position.Entry.Hovered)
				{
					_Position.Entry.IsGrabbed = true;
					_Position.Entry.Hovered = false;
				}
				else if (_Position.Stop.Hovered)
				{
					_Position.Stop.IsGrabbed = true;
					_Position.Stop.Hovered = false;
				}
				else if (_Position.Target1.Hovered)
				{
					_Position.Target1.IsGrabbed = true;
					_Position.Target1.Hovered = false;
				}
				else if (_Position.Target2.Hovered)
				{
					_Position.Target2.IsGrabbed = true;
					_Position.Target2.Hovered = false;
				}
				else if (_Position.Target3.Hovered)
				{
					_Position.Target3.IsGrabbed = true;
					_Position.Target3.Hovered = false;
				}

				_bIsAnyGrabbed = _Position.Entry.IsGrabbed || _Position.Stop.IsGrabbed || _Position.Target1.IsGrabbed || _Position.Target2.IsGrabbed || _Position.Target3.IsGrabbed;
			}
			else
			{
				if (_Position.Entry.Hovered)
					_Position.Entry.IsGrabbed = false;
				else if (_Position.Stop.Hovered)
					_Position.Stop.IsGrabbed = false;
				else if (_Position.Target1.Hovered)
					_Position.Target1.IsGrabbed = false;
				else if (_Position.Target2.Hovered)
					_Position.Target2.IsGrabbed = false;
				else if (_Position.Target3.Hovered)
					_Position.Target3.IsGrabbed = false;

				_bIsAnyGrabbed = false;
			}
			_ChartControl.InvalidateVisual();
		}
		#endregion

		#region Stop Updating
		public void StopUpdating()
		{
			_Position.SettingsUpdate = ARC.CTESup.ESettingsUpdate.UpdateTrailOnly;
		}
		#endregion

		#region Set State
		public void SetState(State state)
		{
			if (Position != null)
				Position.SetState(state);
		}
		#endregion

		#region Release Grab
		protected override void ReleaseGrab()
		{
			_Position.Entry.IsGrabbed = false;
			_Position.Stop.IsGrabbed = false;
			_Position.Target1.IsGrabbed = false;
			_Position.Target2.IsGrabbed = false;
			_Position.Target3.IsGrabbed = false;
		}
		#endregion

		#region Properties
		public NsPosition Position { get { return _Position; } }
		#endregion
	}
	#endregion

    #region Individual Value
    public class IndividualValue : ICloneable
	{
		public double Price { get; set; }
        public int DistanceFromEntry { get; set; }
        public double Ticks { get; set; }
        public double USD { get; set; }
		public int Quantity { get; set; }
		public bool Hovered { get; set; }
		public bool IsGrabbed { get; set; }
		public string Text { get; set; }

		public void Reset()
		{
			Price = 0;
			Ticks = 0;
			USD = 0;
			DistanceFromEntry = 0;
        }
		public void UpdatePrice(double price)
		{
			Price = price;
		}

		public bool Grab()
		{
			if (Hovered)
			{
				Hovered = false;
				IsGrabbed = true;
				return true;
            }
			return false;
		}

		public object Clone()
		{
			return new IndividualValue()
			{
				Price = Price,
				USD = USD,
				Ticks = Ticks,
				Quantity = Quantity,
				Hovered = false,
				IsGrabbed = false,
				Text = Text
			};
		}
	}
	#endregion

	#region Color Settings
	public class ColorSettings
	{
		public Stroke Entry { get; set; }
		public Stroke Stop { get; set; }
		public Stroke Target { get; set; }
		public Stroke Hovered { get; set; }
		public Brush Text { get; set; }
		public Brush FlagBackground { get; set; }
		public SimpleFont Font { get; set; }
		public double FlagLength { get; set; }
		public bool ShortOrderNames { get; set; }
	}
	#endregion
}
