#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC.AlgoSup
{
	public class ARC_DACumulativeDelta : Indicator
	{
		private long bUpCount, bDnCount;
		private int pDirection;
		private double pPrice;
		private long vTotal = 0;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name										= "ARC_DACumulativeDelta";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				AddPlot(new Stroke(Brushes.Green, 2), PlotStyle.Bar, "BuyVolume");
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Bar, "SellVolume");
				AddPlot(new Stroke(Brushes.DimGray, 2), PlotStyle.Hash, "CumulativeVolume");
				AddLine(Brushes.DarkGray, 0, "ZeroLine");
			}
			else if (State == State.Configure)
			{
				AddDataSeries(Data.BarsPeriodType.Tick, 1);
			}
		}

		protected override void OnBarUpdate()
		{
			if(CurrentBar <= 3 || CurrentBars[0] <= 3)
				return;
			
			#region RegTickData
			
			if(BarsInProgress == 1)
			{
				pDirection = Closes[1][0] > Closes[1][1] ? 1 : Closes[1][0] < Closes[1][1] ? -1 : pDirection;
				if (pDirection == 1)
				{											
					bUpCount += (long) Volume[0];
					pDirection = 1;
				}
				else if(pDirection == -1)
				{	
					bDnCount += (long) Volume[0];
					pDirection = -1;
				}

				vTotal += (long)Volume[0];
				pPrice = Closes[1][0];

				if (State != State.Historical)
				{
					BuyVolume[0] = bUpCount;
					SellVolume[0] = -bDnCount;
					CumulativeVolume[0] = bUpCount - bDnCount;
					if (Instrument.MasterInstrument.InstrumentType == InstrumentType.Forex)
                    {
						CumulativeVolume[0] /= 100000;
                    }
				}

				//Print(Volume[0] + ", " + bUpCount + ", " + bDnCount + ", " + CumulativeVolume[0] + ", " + pDirection);
			}

			#endregion

			if (BarsInProgress != 0)
				return;

			if (State == State.Historical)
			{
				BuyVolume[0] = bUpCount;
				SellVolume[0] = -bDnCount;
				CumulativeVolume[0] = bUpCount - bDnCount;
				if (Instrument.MasterInstrument.InstrumentType == InstrumentType.Forex)
				{
					CumulativeVolume[0] /= 100000;
				}
			}

			if (this.IsFirstTickOfBar)			
				bUpCount = bDnCount = vTotal = 0;			
		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BuyVolume
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SellVolume
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CumulativeVolume
		{
			get { return Values[2]; }
		}

		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.AlgoSup.ARC_DACumulativeDelta[] cacheARC_DACumulativeDelta;
		public ARC.AlgoSup.ARC_DACumulativeDelta ARC_DACumulativeDelta()
		{
			return ARC_DACumulativeDelta(Input);
		}

		public ARC.AlgoSup.ARC_DACumulativeDelta ARC_DACumulativeDelta(ISeries<double> input)
		{
			if (cacheARC_DACumulativeDelta != null)
				for (int idx = 0; idx < cacheARC_DACumulativeDelta.Length; idx++)
					if (cacheARC_DACumulativeDelta[idx] != null &&  cacheARC_DACumulativeDelta[idx].EqualsInput(input))
						return cacheARC_DACumulativeDelta[idx];
			return CacheIndicator<ARC.AlgoSup.ARC_DACumulativeDelta>(new ARC.AlgoSup.ARC_DACumulativeDelta(), input, ref cacheARC_DACumulativeDelta);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.AlgoSup.ARC_DACumulativeDelta ARC_DACumulativeDelta()
		{
			return indicator.ARC_DACumulativeDelta(Input);
		}

		public Indicators.ARC.AlgoSup.ARC_DACumulativeDelta ARC_DACumulativeDelta(ISeries<double> input )
		{
			return indicator.ARC_DACumulativeDelta(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.AlgoSup.ARC_DACumulativeDelta ARC_DACumulativeDelta()
		{
			return indicator.ARC_DACumulativeDelta(Input);
		}

		public Indicators.ARC.AlgoSup.ARC_DACumulativeDelta ARC_DACumulativeDelta(ISeries<double> input )
		{
			return indicator.ARC_DACumulativeDelta(input);
		}
	}
}

#endregion
