#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC.AlgoSup
{
	public class ARC_DATargStop : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name										= "ARC_DATargStop";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Dot, "Stop1");
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Dot, "Stop2");
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Dot, "Stop3");
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Dot, "Stop4");
				AddPlot(new Stroke(Brushes.Lime, 2), PlotStyle.Dot, "Target1");
				AddPlot(new Stroke(Brushes.Lime, 2), PlotStyle.Dot, "Target2");
				AddPlot(new Stroke(Brushes.Lime, 2), PlotStyle.Dot, "Target3");
				AddPlot(new Stroke(Brushes.Lime, 2), PlotStyle.Dot, "Target4");
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Stop1
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Stop2
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Stop3
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Stop4
		{
			get { return Values[3]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Target1
		{
			get { return Values[4]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Target2
		{
			get { return Values[5]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Target3
		{
			get { return Values[6]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Target4
		{
			get { return Values[7]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.AlgoSup.ARC_DATargStop[] cacheARC_DATargStop;
		public ARC.AlgoSup.ARC_DATargStop ARC_DATargStop()
		{
			return ARC_DATargStop(Input);
		}

		public ARC.AlgoSup.ARC_DATargStop ARC_DATargStop(ISeries<double> input)
		{
			if (cacheARC_DATargStop != null)
				for (int idx = 0; idx < cacheARC_DATargStop.Length; idx++)
					if (cacheARC_DATargStop[idx] != null &&  cacheARC_DATargStop[idx].EqualsInput(input))
						return cacheARC_DATargStop[idx];
			return CacheIndicator<ARC.AlgoSup.ARC_DATargStop>(new ARC.AlgoSup.ARC_DATargStop(), input, ref cacheARC_DATargStop);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.AlgoSup.ARC_DATargStop ARC_DATargStop()
		{
			return indicator.ARC_DATargStop(Input);
		}

		public Indicators.ARC.AlgoSup.ARC_DATargStop ARC_DATargStop(ISeries<double> input )
		{
			return indicator.ARC_DATargStop(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.AlgoSup.ARC_DATargStop ARC_DATargStop()
		{
			return indicator.ARC_DATargStop(Input);
		}

		public Indicators.ARC.AlgoSup.ARC_DATargStop ARC_DATargStop(ISeries<double> input )
		{
			return indicator.ARC_DATargStop(input);
		}
	}
}

#endregion
