#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.DirectWrite;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC.AlgoSup
{
	public class ARC_DAChartPnl : Indicator
	{
		public Brush			blackbrush	= Brushes.Black;
		public SimpleFont		font1	= new SimpleFont("Arial", 16);
		public Brush			graybrush	= Brushes.LightGray;
		private readonly Brush			greenbrush	= Brushes.Green;
		private readonly Stroke			pen			= new Stroke(Brushes.Black);
		private readonly Brush			redbrush	= Brushes.Red;
		private string pSecondsLabel;
		private string pMinutesLabel;
		private int pMinutesAdjuster;
		private string currentText;

		[Browsable(false)] public	double		OpenPl		{ get; set;}
		[Browsable(false)] public	bool		Paused		{ get; set;}
		[Browsable(false)] public	double		TodayPl		{ get; set;}
		[Browsable(false)] public	double		TrackedPl	{ get; set;}

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name										= "ARC_DAChartPnl";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Id					= 1;
				pSecondsLabel = "-sec";
				pMinutesLabel = "-min";
				pMinutesAdjuster = 0;
				AddPlot(Brushes.Green, "Daily Pnl Plot");
			}
			else if (State == State.Configure)
			{
				Plots[0].Width = 3;
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}

		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if(e.MarketDataType != MarketDataType.Ask && e.MarketDataType != MarketDataType.Bid)
            {
				return;
            }
			var ts = new TimeSpan(DateTime.Now.Ticks - e.Time.Ticks);
			var seconds = Math.Abs(ts.TotalSeconds) + pMinutesAdjuster * 60;
			double currentValue;
			if (seconds < 2)
			{
				currentValue = seconds;
				currentText = string.Format("{0}{1}", currentValue.ToString("0.00"), pSecondsLabel);
			}
			else if (seconds < 60)
			{
				currentValue = seconds;
				currentText = string.Format("{0}{1}", currentValue.ToString("0.0"), pSecondsLabel);
			}
			else
			{
				currentValue = Math.Round(seconds / 60, 1);
				currentText = string.Format("{0}{1}", currentValue, pMinutesLabel);
			}
			//Print(e.ToString() + "   ---   " + currentValue);
		}

		#region Graphics

		public override void OnRenderTargetChanged()
        {
            base.OnRenderTargetChanged();
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			if (chartControl == null)
				return;

			try
			{
				base.OnRender(chartControl, chartScale);
				if (RenderTarget == null)
				{
					return;
				}
				NT7Graphics graphics = new NT7Graphics(RenderTarget);
				var b = TrackedPl > 0 ? greenbrush : TrackedPl < 0 ? redbrush : blackbrush;

				RectangleF bounds = new RectangleF(ChartPanel.X, ChartPanel.Y, ChartPanel.W, ChartPanel.H);

				float textPosition = bounds.Y + 0.05f * bounds.Height;

				graphics.FillRectangle(graybrush, 5, textPosition, 310, 80);
				graphics.DrawRectangle(pen, 5, textPosition, 310, 80);

				textPosition += 2;
				graphics.DrawString("Tracked P&L :", font1, blackbrush, 10f, textPosition, 200f, Convert.ToSingle(font1.Size), SharpDX.DirectWrite.TextAlignment.Trailing);
				graphics.DrawString(TrackedPl.ToString("C"), font1, b, 215f, textPosition, SharpDX.DirectWrite.TextAlignment.Leading);

				textPosition += 20;
				b = TodayPl > 0 ? greenbrush : TodayPl < 0 ? redbrush : blackbrush;
				graphics.DrawString("Realized P&L:", font1, blackbrush, 10f, textPosition, 200f, Convert.ToSingle(font1.Size), SharpDX.DirectWrite.TextAlignment.Trailing);
				graphics.DrawString(TodayPl.ToString("C"), font1, b, 215f, textPosition, SharpDX.DirectWrite.TextAlignment.Leading);

				textPosition += 20;
				b = OpenPl > 0 ? greenbrush : OpenPl < 0 ? redbrush : blackbrush;
				graphics.DrawString("Unrealized P&L:", font1, blackbrush, 10f, textPosition, 200f, Convert.ToSingle(font1.Size), SharpDX.DirectWrite.TextAlignment.Trailing);
				graphics.DrawString(OpenPl.ToString("C"), font1, b, 215f, textPosition, SharpDX.DirectWrite.TextAlignment.Leading);

				textPosition += 20;
				graphics.DrawString("Data Lag:", font1, blackbrush, 10f, textPosition, 200f, Convert.ToSingle(font1.Size), SharpDX.DirectWrite.TextAlignment.Trailing);
				if(string.IsNullOrEmpty(currentText))
                {
					currentText = "0";
                }
				graphics.DrawString(currentText, font1, blackbrush, 215f, textPosition, SharpDX.DirectWrite.TextAlignment.Leading);

			}
			catch (Exception ex)
			{
				Log("Exception Happened in OnRender: " + ex.Message + "\n" + ex.StackTrace, Cbi.LogLevel.Error);
			}
		}

		#region RegNT7toNT8Class

		internal class NT7MeasureStringData
		{
			public float Height;
			public float Width;

			public NT7MeasureStringData()
			{

			}
		}

		internal class NT7Graphics
		{
			SharpDX.Direct2D1.RenderTarget rt;

			public NT7Graphics(SharpDX.Direct2D1.RenderTarget rt)
			{
				this.rt = rt;
			}

			public void DrawEllipse(Stroke s, RectangleF rect)
			{
				this.DrawEllipse(s, rect.X, rect.Y, rect.Width, rect.Height);
			}

			public void DrawEllipse(Stroke s, float x, float y, float w, float h)
			{
				float half = w / 2;
				float x0 = Convert.ToSingle(x + half - 1);
				float y0 = Convert.ToSingle(y + half - 1);
				SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
				SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f);
				var brush = s.Brush.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawEllipse(ellipse, brush, s.Width);
				brush.Dispose(); brush = null;
			}

			public void FillEllipse(Brush b, RectangleF rect)
			{
				this.FillEllipse(b, rect.X, rect.Y, rect.Width, rect.Height);
			}

			public void FillEllipse(Brush b, float x, float y, float w, float h)
			{
				float half = w / 2;
				float x0 = Convert.ToSingle(x + half - 1);
				float y0 = Convert.ToSingle(y + half - 1);
				SharpDX.Vector2 vectorForEllipse = new SharpDX.Vector2(x0, y0);
				SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(vectorForEllipse, w / 2.0f, h / 2.0f);
				var brush = b.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.FillEllipse(ellipse, brush);
				brush.Dispose(); brush = null;
			}

			public void DrawRectangle(Stroke s, RectangleF rect)
			{
				this.DrawRectangle(s, rect.X, rect.Y, rect.Width, rect.Height);
			}

			public void DrawRectangle(Stroke s, float x, float y, float w, float h)
			{
				SharpDX.RectangleF rectf = new SharpDX.RectangleF(x, y, w, h);
				var brush = s.Brush.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawRectangle(rectf, brush, s.Width);
				brush.Dispose(); brush = null;
			}

			public void FillRectangle(Brush b, RectangleF rect)
			{
				this.FillRectangle(b, rect.X, rect.Y, rect.Width, rect.Height);
			}

			public void FillRectangle(Brush b, float x, float y, float w, float h)
			{
				SharpDX.RectangleF rectf = new SharpDX.RectangleF(x, y, w, h);
				var brush = b.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.FillRectangle(rectf, brush);
				brush.Dispose(); brush = null;
			}

			public void DrawLine(Stroke s, float x1, float y1, float x2, float y2)
			{
				System.Windows.Point startPoint = new System.Windows.Point(x1, y1);
				System.Windows.Point endPoint = new System.Windows.Point(x2, y2);
				var brush = s.Brush.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawLine(startPoint.ToVector2(), endPoint.ToVector2(), brush, s.Width, s.StrokeStyle);
				brush.Dispose(); brush = null;
			}

			public void DrawString(String text, SimpleFont f, Brush b, RectangleF rect, SharpDX.DirectWrite.TextAlignment ta)
			{
				this.DrawString(text, f, b, rect.X, rect.Y, rect.Width, rect.Height, ta);
			}

			public void DrawString(String text, SimpleFont f, Brush b, RectangleF rect)
			{
				this.DrawString(text, f, b, rect.X, rect.Y);
			}

			public void DrawString(String text, SimpleFont f, Brush b, float x, float y)
			{
				this.DrawString(text, f, b, x, y, 400, Convert.ToSingle(f.Size), SharpDX.DirectWrite.TextAlignment.Leading);
			}

			public void DrawString(String text, SimpleFont f, Brush b, float x, float y, SharpDX.DirectWrite.TextAlignment ta)
			{
				this.DrawString(text, f, b, x, y, 400, Convert.ToSingle(f.Size), ta);
			}

			public void DrawString(String text, SimpleFont f, Brush b, float x, float y, float w, float h, SharpDX.DirectWrite.TextAlignment ta)
			{
				TextFormat textFormat =
					new TextFormat(
						Core.Globals.DirectWriteFactory,
						f.Family.ToString(),
						(f.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal),
						SharpDX.DirectWrite.FontStyle.Normal,
						SharpDX.DirectWrite.FontStretch.Normal,
						Convert.ToSingle(f.Size))
					{
						TextAlignment = ta,
						WordWrapping = WordWrapping.NoWrap
					};

				TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, w, h);//(float)f.Size);

				System.Windows.Point upperTextPoint = new System.Windows.Point(x, y);
				var brush = b.ToDxBrush(this.rt);
				if (brush == null) return;
				this.rt.DrawTextLayout(upperTextPoint.ToVector2(), textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
				brush.Dispose(); brush = null;
			}

			public NT7MeasureStringData MeasureString(String text, SimpleFont f)
			{
				NT7MeasureStringData sd = new NT7MeasureStringData();

				TextFormat textFormat = new TextFormat(Core.Globals.DirectWriteFactory, f.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal,
												SharpDX.DirectWrite.FontStyle.Normal, SharpDX.DirectWrite.FontStretch.Normal, Convert.ToSingle(f.Size))
				{ TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading, WordWrapping = WordWrapping.NoWrap };

				TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, 400, Convert.ToSingle(f.Size));


				sd.Height = Convert.ToSingle(textLayout.Metrics.Height);
				sd.Width = Convert.ToSingle(textLayout.Metrics.Width);

				return sd;
			}

			public void FillPolygon(Brush b, System.Windows.Point[] p)
			{
				SharpDX.Direct2D1.PathGeometry g = null;
				SharpDX.Direct2D1.GeometrySink sink = null;

				if (sink == null)
				{
					g = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					sink = g.Open();

				}

				sink.BeginFigure(new SharpDX.Vector2(Convert.ToSingle(p[0].X), Convert.ToSingle(p[0].Y)), SharpDX.Direct2D1.FigureBegin.Filled);
				for (int pidx = 1; pidx < p.Length; pidx++)
				{
					sink.AddLine(new SharpDX.Vector2(Convert.ToSingle(p[pidx].X), Convert.ToSingle(p[pidx].Y)));
				}
				sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
				sink.Close();

				if (g != null)
				{
					var brush = b.ToDxBrush(this.rt);
					if (brush == null) return;
					this.rt.FillGeometry(g, brush);
					brush.Dispose(); brush = null;

					g.Dispose();
					sink.Dispose();
					g = null;
					sink = null;
				}
			}

			public void DrawPolygon(Stroke s, System.Windows.Point[] p)
			{
				SharpDX.Direct2D1.PathGeometry g = null;
				SharpDX.Direct2D1.GeometrySink sink = null;

				if (sink == null)
				{
					g = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					sink = g.Open();

				}

				sink.BeginFigure(new SharpDX.Vector2(Convert.ToSingle(p[0].X), Convert.ToSingle(p[0].Y)), SharpDX.Direct2D1.FigureBegin.Filled);
				for (int pidx = 1; pidx < p.Length; pidx++)
				{
					sink.AddLine(new SharpDX.Vector2(Convert.ToSingle(p[pidx].X), Convert.ToSingle(p[pidx].Y)));
				}
				sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
				sink.Close();

				if (g != null)
				{
					var brush = s.Brush.ToDxBrush(this.rt);
					if (brush == null) return;
					this.rt.DrawGeometry(g, brush);
					brush.Dispose(); brush = null;

					g.Dispose();
					sink.Dispose();
					g = null;
					sink = null;
				}
			}
		}

		#endregion

		#endregion

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Id", Order=1, GroupName="Parameters")]
		public int Id
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Plot
		{
			get { return Values[0]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.AlgoSup.ARC_DAChartPnl[] cacheARCDAChartPnL;
		public ARC.AlgoSup.ARC_DAChartPnl ARC_DAChartPnl(int id)
		{
			return ARC_DAChartPnl(Input, id);
		}

		public ARC.AlgoSup.ARC_DAChartPnl ARC_DAChartPnl(ISeries<double> input, int id)
		{
			if (cacheARCDAChartPnL != null)
				for (int idx = 0; idx < cacheARCDAChartPnL.Length; idx++)
					if (cacheARCDAChartPnL[idx] != null && cacheARCDAChartPnL[idx].Id == id && cacheARCDAChartPnL[idx].EqualsInput(input))
						return cacheARCDAChartPnL[idx];
			return CacheIndicator<ARC.AlgoSup.ARC_DAChartPnl>(new ARC.AlgoSup.ARC_DAChartPnl(){ Id = id }, input, ref cacheARCDAChartPnL);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.AlgoSup.ARC_DAChartPnl ARC_DAChartPnl(int id)
		{
			return indicator.ARC_DAChartPnl(Input, id);
		}

		public Indicators.ARC.AlgoSup.ARC_DAChartPnl ARC_DAChartPnl(ISeries<double> input , int id)
		{
			return indicator.ARC_DAChartPnl(input, id);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.AlgoSup.ARC_DAChartPnl ARC_DAChartPnl(int id)
		{
			return indicator.ARC_DAChartPnl(Input, id);
		}

		public Indicators.ARC.AlgoSup.ARC_DAChartPnl ARC_DAChartPnl(ISeries<double> input , int id)
		{
			return indicator.ARC_DAChartPnl(input, id);
		}
	}
}

#endregion
