#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;

#endregion

namespace ARC.AlgoSup.All
{

	#region Timer Generator
	public class TimerGenerator
	{
		#region Variables
		public delegate void ProcessActionDelegate(MyAction action);
		public ProcessActionDelegate ProcessAction;

		private System.Timers.Timer timer;
		private int _iMilliseconds = 1;
		private MyAction OutputAction;
		private List<MyAction> Actions = new List<MyAction>();
		#endregion

		#region Constructor
		public TimerGenerator(int Milliseconds)
		{
			_iMilliseconds = Milliseconds;
		}
		#endregion

		#region Start It Up
		public void StartItUp()
		{
			if (!IsTimerAlive)
				startTimer(_iMilliseconds);
		}
		#endregion

		#region End It Now
		public void EndItNow()
		{
			stopTimer();
		}
        #endregion

        #region Add Action
        public void AddAction(MyAction action)
        {
            Actions.Add(action);
            if (!IsTimerAlive)
                startTimer(_iMilliseconds);
        }
        #endregion

        #region Start Timer
        private void startTimer(int intervalMilliseconds)
		{
			try
			{
				stopTimer();
				timer = new System.Timers.Timer();
				timer.Interval = intervalMilliseconds;
				timer.AutoReset = true;
				timer.Elapsed += new System.Timers.ElapsedEventHandler(TimerElapsed);
				timer.Start();
			}
			catch (Exception ex) { }
		}
		#endregion

		#region Stop Timer
		private void stopTimer()
		{
			try
			{
				if (timer != null)
				{
					timer.Elapsed -= TimerElapsed;
					timer.Stop();
					timer.Dispose();
					timer = null;
				}
			}
			catch (Exception ex) { }
		}
		#endregion

		#region Timer Elapsed
		private void TimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			if (Actions.Count > 0)
			{
				if (ProcessAction != null)
				{
					MyAction action = Actions[0];
					Actions.RemoveAt(0);
					ProcessAction(action);
				}
			}
		}
		#endregion

		#region Properties
		public bool IsTimerAlive
		{
			get { return timer != null && timer.Enabled; }
		}
		#endregion
	}
    #endregion

    #region Simple Timer
	/// <summary>
	/// this is a siple timer with an ellapsed event. Perfect for refreshing something every x time
	/// </summary>
    public class SimpleTimer
    {
        #region Variables
        public delegate void ElapsedDelegate();
        public ElapsedDelegate Elapsed;

        private System.Timers.Timer timer;
        private int _iMilliseconds = 1;
        #endregion

        #region Constructor
        public SimpleTimer(int Milliseconds)
        {
            _iMilliseconds = Milliseconds;
		}
		public SimpleTimer(TimeSpan time)
		{
			_iMilliseconds = (int)time.Ticks;
		}
		#endregion

		#region Start It Up
		public void StartItUp()
        {
            if (!IsTimerAlive) 
                startTimer(_iMilliseconds);
        }
		#endregion

		#region Restart
		public void Restart()
		{
            if (IsTimerAlive)
                stopTimer();
            startTimer(_iMilliseconds);
        }
        #endregion

        #region End It Now
        public void EndItNow()
        {
            stopTimer();
        }
        #endregion

        #region Start Timer
        private void startTimer(int intervalMilliseconds)
        {
            try
            {
                stopTimer();
                timer = new System.Timers.Timer();
                timer.Interval = intervalMilliseconds;
                timer.AutoReset = true;
                timer.Elapsed += new System.Timers.ElapsedEventHandler(TimerElapsed);
                timer.Start();
            }
            catch (Exception ex) { }
        }
        #endregion

        #region Stop Timer
        private void stopTimer()
        {
            try
            {
                if (timer != null)
                {
                    timer.Elapsed -= TimerElapsed;
                    timer.Stop();
                    timer.Dispose();
                    timer = null;
                }
            }
            catch (Exception ex) { }
        }
        #endregion

        #region Timer Elapsed
        private void TimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
			if(Elapsed != null)
				Elapsed();
        }
        #endregion

        #region Properties
        public bool IsTimerAlive
        {
            get { return timer != null && timer.Enabled; }
        }
        #endregion
    }
    #endregion

    #region My Action
    public class MyAction
	{
		public Action Action { get; set; }
		public string ActionName { get; set; }

		public MyAction() { }
		public MyAction(Action action, string actionName)
		{
			Action = action;
			ActionName = actionName;
		}
	}
	#endregion

	#region Action Processor
	public class ActionProcessor : IDisposable
    {
        #region Floating Variables
        private TimerGenerator _Timer;
        private State State = State.Configure;
        #endregion

        #region Constructor
        public ActionProcessor(int Milliseconds = 100)
        {
            _Timer = new TimerGenerator(Milliseconds);
            _Timer.ProcessAction += ProcessTimerAction;
        }
        #endregion

        #region Event Handlers

        #region Process Timer Action
        private void ProcessTimerAction(MyAction action)
        {
			action.Action();
        }
		#endregion

		#endregion

		#region Public Events

		#region Action Processor
		public void ProcessAction(Action action, string ActionName)
		{
			if (State != State.Realtime)
				action();
			else
			{
				_Timer.AddAction(new MyAction() { Action = action, ActionName = ActionName });
			}
		}
		public void ProcessAction(List<MyAction> actions)
		{
			if (actions != null && actions.Count > 0)
			{
				for (int i = 0; i < actions.Count; i++)
				{
					if (State != State.Realtime)
						actions[i].Action();
					else
						_Timer.AddAction(actions[i]);
				}
			}
		}
		#endregion

		#region Set State
		public void SetState(State state)
        {
            State = state;
        }
        #endregion

        #region Dispose
        public void Dispose()
        {
            if (_Timer != null)
            {
                _Timer.ProcessAction -= ProcessTimerAction;
                _Timer.EndItNow();
            }
        }
        #endregion

        #endregion
    }
    #endregion
}
