#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
//using System.Diagnostics.CodeAnalysis;
using System.Windows;
//using System.Reflection;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using System.Windows.Controls;
//using System.Windows.Input;
//using System.IO;
using SharpDX;
using System.Text;
using SharpDX.DirectWrite;
using System.Windows.Media.Imaging;
using System.Linq;
using NinjaTrader.NinjaScript.Indicators.ARC.Sup;
#endregion

public enum ARC_MarketMapper_Locations    {TopLeft,TopRight,Center,BottomLeft,BottomRight, None}
public enum ARC_MarketMapper_ChartMarkers {None, Arrow, Dot, Diamond, Square, Triangle, ArrowLine, Text}
public enum ARC_MarketMapper_CustomTimes  {None, Minute10, Minute15, Minute30, Hr1, Hr2, Hr4, Hr8, Hr12}

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[CategoryOrder("Visual Parameters",10)]
	[CategoryOrder("Sensitivity",30)]
	[CategoryOrder("Volume Arb Alert",40)]
	[CategoryOrder("Speed Arb Alert",50)]
	[CategoryOrder("ATR Arb Alert",60)]
	public class ARC_MarketMapper : Indicator 
	{
		private float WEEKLY_SCALE_MIN = 0;
		private float WEEKLY_SCALE_MAX = 200;
		private float DAILY_SCALE_MIN  = 0;
		private float DAILY_SCALE_MAX  = 200;
		private float CUSTOM_SCALE_MIN = 0;
		private float CUSTOM_SCALE_MAX = 200;
		private DateTime RecalcAt   = DateTime.Now;

		private bool IsDebug        = false;
		private bool ValidLicense   = false;
		private bool IsExpired      = true;

		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "MarketMapper";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "20034", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		#region RegThermometer
	    internal class ClassThermometerBar
	    {
	        public ClassThermometerBar(float iHeight, float iWidth)
	        {
	            m_width = iWidth;
	            m_height = iHeight;            
	        }

			#region RegInputs
			
	        // Corner Round
	        private float cornerRadius = 5;        
	        public float CornerRadius
	        {
	            set { cornerRadius = value; }
	            get { return cornerRadius; }
	        }

	        // Temperature Value1
	        private float val1 = 0;        
	        public float Value1
	        {
	            set { val1 = value; }
	            get { return val1; }
	        }
	        // Temperature Value2
	        private float val2 = 0;        
	        public float Value2
	        {
	            set { val2 = value;  }
	            get { return val2; }
	        }
	        // Temperature Value3
	        private float val3 = 0;        
	        public float Value3
	        {
	            set { val3 = value;  }
	            get { return val3; }
	        }

	        // Bar 1 Max Value
	        private float scale1_Max = 50;        
	        public float Scale1_Max
	        {
	            set { scale1_Max = value; }
	            get { return scale1_Max; }
	        }

	        // Bar 1 Min Value
	        private float scale1_Min = -20;        
	        public float Scale1_Min
	        {
	            set { scale1_Min = value; }
	            get { return scale1_Min; }
	        }

	        // Bar 2 Max Value
	        private float scale2_Max = 50;        
	        public float Scale2_Max
	        {
	            set { scale2_Max = value; }
	            get { return scale2_Max; }
	        }

	        // Bar 2 Min Value
	        private float scale2_Min = -20;        
	        public float Scale2_Min
	        {
	            set { scale2_Min = value; }
	            get { return scale2_Min; }
	        }

	        // Bar 3 Max Value
	        private float scale3_Max = 50;        
	        public float Scale3_Max
	        {
	            set { scale3_Max = value; }
	            get { return scale3_Max; }
	        }

	        // Bar 3 Min Value
	        private float scale3_Min = -20;        
	        public float Scale3_Min
	        {
	            set { scale3_Min = value; }
	            get { return scale3_Min; }
	        }

	        // Bar 1 Margin
	        private float bar_margin_TopBottom1 = 15;        
	        public float Bar_margin_TopBottom1
	        {
	            set { bar_margin_TopBottom1 = value; }
	            get { return bar_margin_TopBottom1; }
	        }
	        // Bar 2 Margin
	        private float bar_margin_TopBottom2 = 15;
	        public float Bar_margin_TopBottom2
	        {
	            set { bar_margin_TopBottom2 = value; }
	            get { return bar_margin_TopBottom2; }
	        }
	        // Bar 3 Margin
	        private float bar_margin_TopBottom3 = 15;
	        public float Bar_margin_TopBottom3
	        {
	            set { bar_margin_TopBottom3 = value; }
	            get { return bar_margin_TopBottom3; }
	        }

	        // Current Value Font
	        private SimpleFont tempFont = new SimpleFont("Times New Roman", 13);        
	        public SimpleFont TempFont
	        {
	            set { tempFont = value; }
	            get { return tempFont; }
	        }

	        
	        private Brush titleColor = Brushes.DarkSlateGray;        
	        public Brush TitleColor
	        {
	            set { titleColor = value; }
	            get { return titleColor; }
	        }

	        //Bar1 Big scale counts
	        private int bigScale1 = 5;        
	        public int BigScale1
	        {
	            set { bigScale1 = value; }
	            get { return bigScale1; }
	        }

	        //Bar2 Big scale counts
	        private int bigScale2 = 5;        
	        public int BigScale2
	        {
	            set { bigScale2 = value; }
	            get { return bigScale2; }
	        }

	        //Bar3 Big scale counts
	        private int bigScale3 = 5;        
	        public int BigScale3
	        {
	            set { bigScale3 = value; }
	            get { return bigScale3; }
	        }

	        private string titleBar1 = "Bar1";        
	        public string TitleBar1
	        {
	            set { titleBar1 = value; }
	            get { return titleBar1; }
	        }

	        private string titleBar2 = "Bar2";
	        public string TitleBar2
	        {
	            set { titleBar2 = value; }
	            get { return titleBar2; }
	        }

	        private string titleBar3 = "Bar3";
	        public string TitleBar3
	        {
	            set { titleBar3 = value; }
	            get { return titleBar3; }
	        }

	        private float titlePtXBar1 = 15;
	        public float TitlePtXBar1
	        {
	            set { titlePtXBar1 = value; }
	            get { return titlePtXBar1; }
	        }

	        private float titlePtXBar2 = 15;
	        public float TitlePtXBar2
	        {
	            set { titlePtXBar2 = value; }
	            get { return titlePtXBar2; }
	        }

	        private float titlePtXBar3 = 15;
	        public float TitlePtXBar3
	        {
	            set { titlePtXBar3 = value; }
	            get { return titlePtXBar3; }
	        }

	        private float titlePtYBar1 = 15;
	        public float TitlePtYBar1
	        {
	            set { titlePtYBar1 = value; }
	            get { return titlePtYBar1; }
	        }

	        private float titlePtYBar2 = 15;
	        public float TitlePtYBar2
	        {
	            set { titlePtYBar2 = value; }
	            get { return titlePtYBar2; }
	        }

	        private float titlePtYBar3 = 15;
	        public float TitlePtYBar3
	        {
	            set { titlePtYBar3 = value; }
	            get { return titlePtYBar3; }
	        }

	        private SimpleFont titleFontBar1 = new SimpleFont("Aril", 14);        
	        public SimpleFont TitleFontBar1
	        {
	            get { return titleFontBar1; }
	            set { titleFontBar1 = value; }
	        }

	        private SimpleFont titleFontBar2 = new SimpleFont("Aril", 14);        
	        public SimpleFont TitleFontBar2
	        {
	            get { return titleFontBar2; }
	            set { titleFontBar2 = value; }
	        }

	        private SimpleFont titleFontBar3 = new SimpleFont("Aril", 14);        
	        public SimpleFont TitleFontBar3
	        {
	            get { return titleFontBar3; }
	            set { titleFontBar3 = value; }
	        }

	        // bar small scale counts
	        private int smallScale = 5;        
	        public int SmallScale
	        {
	            set { smallScale = value; }
	            get { return smallScale; }
	        }

	        // scale Font
	        private SimpleFont drawFont = new SimpleFont("Aril", 9);        
	        public SimpleFont DrawFont
	        {
	            get { return drawFont; }
	            set { drawFont = value; }
	        }

	        // Font Color
	        private Brush drawColor = Brushes.White;        
	        public Brush DrawColor
	        {
	            set { drawColor = value; }
	            get { return drawColor; }
	        }

	        // Outline line color
	        private Brush dialOutLineColor = Brushes.Gray;        
	        public Brush DialOutLineColor
	        {
	            set { dialOutLineColor = value; }
	            get { return dialOutLineColor; }
	        }

	        // Main BackColor
	        private Brush dialBackColor = Brushes.Gray;        
	        public Brush DialBackColor
	        {
	            set { dialBackColor = value; }
	            get { return dialBackColor; }
	        }

	        // Big Scale Color
	        private Brush bigScaleColor = Brushes.Black;        
	        public Brush BigScaleColor
	        {
	            set { bigScaleColor = value; }
	            get { return bigScaleColor; }
	        }

	        // Small Scale Color
	        private Brush smallScaleColor = Brushes.Black;        
	        public Brush SmallScaleColor
	        {
	            set { smallScaleColor = value; }
	            get { return smallScaleColor; }
	        }

	        // Value bar backColor
	        private Brush mercuryBackColor = Brushes.LightGray;        
	        public Brush MercuryBackColor
	        {
	            set { mercuryBackColor = value; }
	            get { return mercuryBackColor; }
	        }

	        // Color really Value
	        private Brush mercuryColor = Brushes.Blue;        
	        public Brush MercuryColor
	        {
	            set { mercuryColor = value; }
	            get { return mercuryColor; }
	        }
			
			#endregion

	        #region RegFunctions
	        public void InitBaseVal_Bar1(float nScaleMin, float nScaleMax, int barTopBottomMargin, int nBigscale)
	        {
	            Bar_margin_TopBottom1 = barTopBottomMargin;
	            BigScale1 = nBigscale;
	            Scale1_Min = nScaleMin;
	            Scale1_Max = nScaleMax;
	        }

	        public void InitBaseVal_Bar2(float nScaleMin, float nScaleMax, int barTopBottomMargin, int nBigscale)
	        {
	            Bar_margin_TopBottom2 = barTopBottomMargin;
	            BigScale2 = nBigscale;
	            Scale2_Min = nScaleMin;
	            Scale2_Max = nScaleMax;
	        }

	        public void InitBaseVal_Bar3(float nScaleMin, float nScaleMax, int barTopBottomMargin, int nBigscale)
	        {
	            Bar_margin_TopBottom3 = barTopBottomMargin;
	            BigScale3 = nBigscale;
	            Scale3_Min = nScaleMin;
	            Scale3_Max = nScaleMax;
	        }

	        public void InitTitle_Bar1(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleBar1 = strTitle;
	            TitleFontBar1 = nFont;
	            TitlePtXBar1 = nX;            
	            TitlePtYBar1 = nY;            
	        }

	        public void InitTitle_Bar2(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleBar2 = strTitle;
	            TitleFontBar2 = nFont;
	            TitlePtXBar2 = nX;
	            TitlePtYBar2 = nY;
	        }

	        public void InitTitle_Bar3(string strTitle, SimpleFont nFont, float nX, float nY)
	        {
	            TitleBar3 = strTitle;
	            TitleFontBar3 = nFont;
	            TitlePtXBar3 = nX;
	            TitlePtYBar3 = nY;
	        }

		
			#endregion
					
	        private float X;
	        private float Y;
	        private float H1;
	        private float H2;
	        private float H3;
	        private float m_width;
	        private float m_height;
	        private Stroke p, s_p;
	        //private Brush b;        
	        
			
			private double DegreeToRadian(double angle)
			{
				return Math.PI * angle / 180.0;
			}
			
			private double RadianToDegree(double angle)
			{
				return angle * (180.0 / Math.PI);
			}			

	       
	    }		
		#endregion

        private const string productName = "ARC_MarketMapper";

		private const string VERSION = "v1.11 12.Apr.2022";
		//1.11 introduced the Infusionsoft licensing system (transitioning away from the fixed license key system)
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		private bool pEnableWeeklyPlot = true;
		[Display(Order = 10, Name = "Enable Weekly Plot", Description = "", GroupName = "Parameters")]       
		public bool EnableWeeklyPlot{
            get { return pEnableWeeklyPlot; }
            set { pEnableWeeklyPlot = value; }}

		private bool pEnableDailyPlot = true;
		[Display(Order = 20, Name = "Enable Daily Plot", Description = "", GroupName = "Parameters")]       
		public bool EnableDailyPlot{
            get { return pEnableDailyPlot; }
            set { pEnableDailyPlot = value; }}

		private bool pEnableCustomPlot = true;
		[Display(Order = 30, Name = "Enable Custom Plot", Description = "", GroupName = "Parameters")]       
		public bool EnableCustomPlot{
            get { return pEnableCustomPlot; }
            set { pEnableCustomPlot = value; }}

		#region - Visual Parameters -
		
		private SimpleFont iBarFont = new SimpleFont("Arial Black", 11){ Size = 11, Bold = true };

		private ARC_MarketMapper_Locations iGraphicLocation = ARC_MarketMapper_Locations.TopLeft;
        [Display(Order = 20, Name = "Location", Description = "", GroupName = "Visual Parameters")]       
		public ARC_MarketMapper_Locations GraphicLocation 
		{
            get { return iGraphicLocation; }
            set { iGraphicLocation = value; }
        }
		private int pGraphicSize = 8;
		[Display(Order = 30, Name = "Size", Description = "1 to 10", GroupName = "Visual Parameters")]       
		public int GraphicSize
		{
            get { return pGraphicSize; }
            set { pGraphicSize = Math.Max(1,Math.Min(10,value)); }
        }

		private bool pEnableGradientHisto = true;
		[Display(Order = 50, Name = "Enable Gradient histo?", Description = "Use a gradient (if your computer supports it)", GroupName = "Visual Parameters")]       
		public bool EnableGradientHisto
		{
            get { return pEnableGradientHisto; }
            set { pEnableGradientHisto = value; }
        }
		private Brush pSolidHistoColor = Brushes.Yellow;
		[XmlIgnore()]
		[Display(Order = 60, Name = "Solid Histo Color", Description = "", GroupName = "Visual Parameters")]       
		public Brush SolidHistoColor
		{
		    get { return pSolidHistoColor; }
		    set { pSolidHistoColor = value; }
		}
			[Browsable(false)]
			public string pSolidHistoColorSerialize	{get { return Serialize.BrushToString(pSolidHistoColor); }set { pSolidHistoColor = Serialize.StringToBrush(value); }}

		private string pScaleLines = "50,100,150,200";
		[Display(Order = 60, Name = "Vertical scale line values", Description = "", GroupName = "Visual Parameters")]       
		public string ScaleLines
		{
		    get { return pScaleLines; }
		    set {
				string result = "";
				var arr = value.Trim().ToArray();
				var list = new List<char>(){'0','1','2','3','4','5','6','7','8','9',',',' ','.'};
				foreach(var c in arr){
					if(list.Contains(c)) {
						if(result.Length==0) result = c.ToString();
						else result = string.Format("{0}{1}",result,c);
					}
				}
				pScaleLines = result; }
		}

		private bool pEnableWeeklyVLine = false;
		[Display(Order = 68, Name = "Enable Weekly VLine", Description = "", GroupName = "Visual Parameters")]       
		public bool EnableWeeklyVLine
		{
            get { return pEnableWeeklyVLine; }
            set { pEnableWeeklyVLine = value; }
        }
		private Brush pWeekTime_SeparatorBrush = Brushes.Yellow;
		[XmlIgnore()]
		[Display(Order = 70, Name = "Week separator vline", Description = "", GroupName = "Visual Parameters")]       
		public Brush WeekTime_SeparatorBrush
		{
		    get { return pWeekTime_SeparatorBrush; }
		    set { pWeekTime_SeparatorBrush = value; }
		}
			[Browsable(false)]
			public string pWeekTime_SeparatorBrushSerialize	{get { return Serialize.BrushToString(pWeekTime_SeparatorBrush); }set { pWeekTime_SeparatorBrush = Serialize.StringToBrush(value); }}

		private bool pEnableDailyVLine = false;
		[Display(Order = 78, Name = "Enable Daily VLine", Description = "", GroupName = "Visual Parameters")]       
		public bool EnableDailyVLine
		{
            get { return pEnableDailyVLine; }
            set { pEnableDailyVLine = value; }
        }
		private Brush pDayTime_SeparatorBrush = Brushes.Cyan;
		[XmlIgnore()]
		[Display(Order = 80, Name = "Day separator vline", Description = "", GroupName = "Visual Parameters")]       
		public Brush DayTime_SeparatorBrush
		{
		    get { return pDayTime_SeparatorBrush; }
		    set { pDayTime_SeparatorBrush = value; }
		}
			[Browsable(false)]
			public string pDayTime_SeparatorBrushSerialize	{get { return Serialize.BrushToString(pDayTime_SeparatorBrush); }set { pDayTime_SeparatorBrush = Serialize.StringToBrush(value); }}

		private bool pEnableCustomVLine = false;
		[Display(Order = 88, Name = "Enable Custom VLine", Description = "", GroupName = "Visual Parameters")]       
		public bool EnableCustomVLine
		{
            get { return pEnableCustomVLine; }
            set { pEnableCustomVLine = value; }
        }
		private Brush pCustomTime_SeparatorBrush = Brushes.LimeGreen;
		[XmlIgnore()]
		[Display(Order = 90, Name = "Custom separator vline", Description = "", GroupName = "Visual Parameters")]       
		public Brush CustomTime_SeparatorBrush
		{
		    get { return pCustomTime_SeparatorBrush; }
		    set { pCustomTime_SeparatorBrush = value; }
		}
			[Browsable(false)]
			public string pCustomTime_SeparatorBrushSerialize	{get { return Serialize.BrushToString(pCustomTime_SeparatorBrush); }set { pCustomTime_SeparatorBrush = Serialize.StringToBrush(value); }}

		#endregion

		#region RegGaugeVisualInputs

		private SimpleFont iTextFontGauge = new SimpleFont("Arial Black", 14){ Size = 14, Bold = true };

		private Brush iBackgroundColor = Brushes.Black;
		[XmlIgnore()]
        [Display(Name = "Background Color", Description = "", GroupName = "Visual Parameters")]       
		public Brush BackgroundColor
        {
            get { return iBackgroundColor; }
            set { iBackgroundColor = value; }
        }
				[Browsable(false)]
				public string BackgroundColorSerialize {get { return Serialize.BrushToString(iBackgroundColor); } set { iBackgroundColor = Serialize.StringToBrush(value); }}		
		private float iBackgroundOpacity = 90f;
		[XmlIgnore()]
        [Display(Name = "Background Opacity", Description = "", GroupName = "Visual Parameters")]       
		public float BackgroundOpacity
        {
            get { return iBackgroundOpacity; }
            set { iBackgroundOpacity = Math.Max(0f,Math.Min(100f,value)); }
        }
		private Brush iTextColor = Brushes.White;
		[XmlIgnore()]
        [Display(Name = "Text Color", Description = "", GroupName = "Visual Parameters")]       
		public Brush TextColor
        {
            get { return iTextColor; }
            set { iTextColor = value; }
        }
				[Browsable(false)]
				public string TextColorSerialize {get { return Serialize.BrushToString(iTextColor); }set { iTextColor = Serialize.StringToBrush(value); }}

		private string pButtonText = "MktMappr";
        [Display(Name = "Button text", Description = "", GroupName = "Visual Parameters")]       
		public string ButtonText
        {
            get { return pButtonText; }
            set { pButtonText = value; }
        }
		#endregion

		#region Alerts

//		private bool pEnableVolumeArbSignal = false;
//		[Display(Order = 10, Name = "Enable", Description = "", GroupName = "Volume Arb Alert")]       
//		public bool EnableVolumeArbSignal
//        {
//            get { return pEnableVolumeArbSignal; }
//            set { pEnableVolumeArbSignal = value; }
//        }

//		#region -- Value based thresholds --
//		private int iVArb_SpeedThreshold = 20; 
//		[Display(Order = 20, Name = "Speed Threshold <", Description = "Speed must be below this value to trigger alert", GroupName = "Volume Arb Alert")]       
//		public int VArb_SpeedThreshold
//		{
//		    get { return iVArb_SpeedThreshold; }
//		    set { iVArb_SpeedThreshold = value; }
//		}		
//		private int iVArb_ATRrangeThreshold = 20; 
//		[Display(Order = 30, Name = "ATR Threshold <", Description = "ATR must be below this value to trigger alert", GroupName = "Volume Arb Alert")]       
//		public int VArb_ATRrangeThreshold
//		{
//		    get { return iVArb_ATRrangeThreshold; }
//		    set { iVArb_ATRrangeThreshold = value; }
//		}
//		private int iVArb_VolumeThreshold = 150; 
//		[Display(Order = 40, Name = "Volume Threshold >", Description = "Volume must be ABOVE this value to trigger alert", GroupName = "Volume Arb Alert")]       
//		public int VArb_VolumeThreshold
//		{
//			get { return iVArb_VolumeThreshold; }
//			set { iVArb_VolumeThreshold = value; }
//		}
//		#endregion

//		#region -- Pct based thresholds --
//		private int iVArb_SpeedThresholdPct = 50;
//		[Display(Order = 50, Name = "Speed Threshold % <", Description = "Speed must be below this value to trigger alert", GroupName = "Volume Arb Alert")]       
//		public int VArb_SpeedThresholdPct
//		{
//		    get { return iVArb_SpeedThresholdPct; }
//		    set { iVArb_SpeedThresholdPct = value; }
//		}
//		private int iVArb_ATRrangeThresholdPct = 65;
//		[Display(Order = 60, Name = "ATR Threshold % <", Description = "ATR must be below this value to trigger alert", GroupName = "Volume Arb Alert")]       
//		public int VArb_ATRrangeThresholdPct
//		{
//		    get { return iVArb_ATRrangeThresholdPct; }
//		    set { iVArb_ATRrangeThresholdPct = value; }
//		}
//		private int iVArb_VolumeThresholdPct = 80;
//		[Display(Order = 70, Name = "Volume Threshold % >", Description = "Volume must be ABOVE this value to trigger alert", GroupName = "Volume Arb Alert")]       
//		public int VArb_VolumeThresholdPct
//		{
//		    get { return iVArb_VolumeThresholdPct; }
//		    set { iVArb_VolumeThresholdPct = value; }
//		}
//		#endregion

//		private string iVArb_SoundAlert = "SOUND OFF"; 
//		[TypeConverter(typeof(LoadSoundFileList))]
//		[Display(Order = 80, Name = "Sound File", Description = "", GroupName = "Volume Arb Alert")]
//		public string VArb_SoundAlert
//		{
//		    get { return iVArb_SoundAlert; }
//		    set { iVArb_SoundAlert = value; }
//		}		
//		private ARC_MarketMapper_ChartMarkers pVArb_ChartMarker = ARC_MarketMapper_ChartMarkers.None;
//		[Display(Order = 90, Name = "Chart Marker", Description = "Chart marker type", GroupName = "Volume Arb Alert")]       
//		public ARC_MarketMapper_ChartMarkers VArb_ChartMarker
//		{
//			get { return pVArb_ChartMarker; }
//			set { pVArb_ChartMarker = value; }
//		}
//		private Brush pVArb_MarkerColor = Brushes.Yellow;
//		[XmlIgnore()]
//		[Display(Order = 100, Name = "Marker Color", Description = "", GroupName = "Volume Arb Alert")]
//		public Brush VArb_MarkerColor
//		{
//		    get { return pVArb_MarkerColor; }
//		    set { pVArb_MarkerColor = value; }
//		}
//					[Browsable(false)]
//					public string pVArb_MarkerColorSerialize
//					{get { return Serialize.BrushToString(pVArb_MarkerColor); }set { pVArb_MarkerColor = Serialize.StringToBrush(value); }}

//		private Brush pVArb_RacingStripeColor = Brushes.Transparent;
//		[XmlIgnore()]
//		[Display(Order = 110, Name = "Racing Stripe Color", Description = "", GroupName = "Volume Arb Alert")]
//		public Brush VArb_RacingStripeColor
//		{
//		    get { return pVArb_RacingStripeColor; }
//		    set { pVArb_RacingStripeColor = value; }
//		}
//					[Browsable(false)]
//					public string pVArb_RacingStripeColorSerialize
//					{get { return Serialize.BrushToString(pVArb_RacingStripeColor); }set { pVArb_RacingStripeColor = Serialize.StringToBrush(value); }}
		#endregion
		

		private ARC_MarketMapper_CustomTimes pCustomTime = ARC_MarketMapper_CustomTimes.Minute30;
		[Display(Order = 10, Name = "Custom Timeframe", Description = "", GroupName = "Parameters")]
		public ARC_MarketMapper_CustomTimes CustomTime
		{
		    get { return pCustomTime; }
		    set { pCustomTime = value; }
		}

		private ClassThermometerBar CT = null;		

		private bool bGraphicsInitialized;

		private Brush backBrush;
		private Stroke backPen;

		private Series<double> sExtrnWeeklyRange, sExtrnDailyRange, sExtrnCustomRange;

		private int idTag;			
		private bool bCanAlertTrigger;
		private List<float> ScaleValues = new List<float>();


	#region Plots
	[Browsable(false)]
	[XmlIgnore]
	public Series<double> WTop{		get { return Values[0]; }}
	[Browsable(false)]
	[XmlIgnore]
	public Series<double> WBottom{		get { return Values[1]; }}

	[Browsable(false)]
	[XmlIgnore]
	public Series<double> DTop{		get { return Values[2]; }}
	[Browsable(false)]
	[XmlIgnore]
	public Series<double> DBottom{		get { return Values[3]; }}

	[Browsable(false)]
	[XmlIgnore]
	public Series<double> CTop{		get { return Values[4]; }}
	[Browsable(false)]
	[XmlIgnore]
	public Series<double> CBottom{		get { return Values[5]; }}

	#endregion

	#region -- OnStateChange --
	protected override void OnStateChange()
	{
		switch (State)
		{
			case State.SetDefaults:
				IsOverlay = true;
				this.Calculate = Calculate.OnPriceChange;
				this.Name = productName;//string.Format("{0} {1} ", productName, productVersion);
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Dot, "WeeklyTop");	
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Dot, "WeeklyBottom");	
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Dot, "DailyTop");	
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Dot, "DailyBottom");	
				AddPlot(new Stroke(Brushes.Blue, 1), PlotStyle.Hash, "CustomTop");	
				AddPlot(new Stroke(Brushes.Blue, 1), PlotStyle.Hash, "CustomBottom");	
				break;

			case State.Configure:
				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion

				this.idTag = 0;
				this.bGraphicsInitialized = false;

				AddDataSeries(BarsPeriodType.Minute, 5);
				break;

			case State.DataLoaded:
				#region -- Add Custom Toolbar --
				if (!isToolBarButtonAdded && ChartControl != null)
				{

					Dispatcher.BeginInvoke(new Action(() =>
					{
						ChartControl.AllowDrop = false;
						chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
						if (chartWindow == null) return;

						foreach (DependencyObject item in chartWindow.MainMenu) if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

						if (!isToolBarButtonAdded)
						{
							indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Hidden };

							addToolBar();

							chartWindow.MainMenu.Add(indytoolbar);
							chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

							foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
							System.Windows.Automation.AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
						}
					}));
				}
				#endregion

				this.backBrush	= this.iBackgroundColor.Clone();
				this.backBrush.Opacity = iBackgroundOpacity / 100f;
				this.backBrush.Freeze();
				this.backPen = new Stroke(this.iBackgroundColor);		
				sExtrnWeeklyRange = new Series<double>(this, MaximumBarsLookBack.Infinite);
				sExtrnDailyRange  = new Series<double>(this, MaximumBarsLookBack.Infinite);
				sExtrnCustomRange = new Series<double>(this, MaximumBarsLookBack.Infinite);

				var elem = pScaleLines.Split(new char[]{',',' '}, StringSplitOptions.RemoveEmptyEntries);
				var minscale = 0f;
				var maxscale = 0f;
				foreach(var e in elem){
					var f = float.Parse(e);
					minscale = Math.Min(minscale, f);
					maxscale = Math.Max(maxscale, f);
					ScaleValues.Add(f/100.0f);
				}
				WEEKLY_SCALE_MIN = minscale;
				DAILY_SCALE_MIN  = minscale;
				CUSTOM_SCALE_MIN = minscale;

				WEEKLY_SCALE_MAX = maxscale;
				DAILY_SCALE_MAX  = maxscale;
				CUSTOM_SCALE_MAX = maxscale;
				break;

			#region -- terminated --
			case State.Terminated:
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
				break;
				#endregion
		}
	}


	#endregion

	#region -- addToolBar --
		private MenuItem MenuControl;
		private string toolbarname = "ARC_MarketMapper_tbar", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;
		private Menu MenuControlContainer;

		private MenuItem miWeeklyPlotOnOff, miDailyPlotOnOff, miCustomPlotOnOff, miCustomTimeframe;
		private MenuItem miWeeklyVLineOnOff, miDailyVLineOnOff, miCustomVLineOnOff, miGraphicLocation, miGraphicSize;
		private Label lblWeeklyAvgRange, lblDailyAvgRange, lblCustomAvgRange;
		private Label lblWeekRange, lblDayRange, lblCustomRange;
		private MenuItem miRecalculate1;
		private void addToolBar()
		{
			int rHeight = 26;
			MenuControlContainer = new Menu { Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Center };
			MenuControl = new MenuItem { BorderThickness = new Thickness(2), BorderBrush = Brushes.Pink, Header = pButtonText, Foreground = Brushes.Pink, Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);
			MenuControl.GotFocus += delegate(object o, RoutedEventArgs e){
				var tks = Weekly_AvgRange/TickSize;
				lblWeeklyAvgRange.Content = tks.ToString("0 : ")+"Weekly Range (ticks)";
				tks = Daily_AvgRange/TickSize;
				lblDailyAvgRange.Content = tks.ToString("0 : ")+"Daily Range (ticks)";
				if(pCustomTime != ARC_MarketMapper_CustomTimes.None){
					tks = Custom_AvgRange/TickSize;
					lblCustomAvgRange.Content = tks.ToString("0 : ")+GetStringCustomRange(pCustomTime)+" Range (ticks)";
				}
				var r = CurrentWeekH-CurrentWeekL;
				tks = (r)/TickSize;
				lblWeekRange.Content = tks.ToString("0 : ")+"Week current";
				if(r > Weekly_AvgRange) lblWeekRange.Foreground = Brushes.Red;
				r = CurrentDayH-CurrentDayL;
				tks = (r)/TickSize;
				lblDayRange.Content = tks.ToString("0 : ")+"Day current";
				if(r > Daily_AvgRange) lblDayRange.Foreground = Brushes.Red;
				if(pCustomTime != ARC_MarketMapper_CustomTimes.None){
					r = CurrentCustomH-CurrentCustomL;
					tks = (r)/TickSize;
					lblCustomRange.Content = tks.ToString("0 : ")+GetStringCustomRange(pCustomTime)+" current";
					if(r > Custom_AvgRange) lblCustomRange.Foreground = Brushes.Red;
				}
			};
//==========================================================
			miGraphicLocation  = new MenuItem { Header = "Graphic Loc: "+iGraphicLocation.ToString(), Name = "miGraphicLocation",  Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false, StaysOpenOnClick = true };
			miGraphicLocation.Click += delegate (object o, RoutedEventArgs e){
				int type = (int)iGraphicLocation;
				type++;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_MarketMapper_Locations)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_MarketMapper_Locations), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				iGraphicLocation = (ARC_MarketMapper_Locations)type;
				miGraphicLocation.Header = "Graphic Loc: "+iGraphicLocation.ToString();
				ForceRefresh();
			};
			miGraphicLocation.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				int type = (int)iGraphicLocation;
				if(e.Delta>0)
					type++;
				else type--;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_MarketMapper_Locations)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_MarketMapper_Locations), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				iGraphicLocation = (ARC_MarketMapper_Locations)type;
				miGraphicLocation.Header = "Graphic Loc: "+iGraphicLocation.ToString();
				ForceRefresh();
			};
//==========================================================
			miGraphicSize  = new MenuItem { Header = "Graphic size: "+pGraphicSize.ToString(), Name = "pmiGraphicSize",  Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false, StaysOpenOnClick = true };
			miGraphicSize.Click += delegate (object o, RoutedEventArgs e){
				if(pGraphicSize <10) pGraphicSize++;
				else pGraphicSize = 1;
				miGraphicSize.Header = "Graphic size: "+pGraphicSize.ToString();
				ForceRefresh();
			};
			miGraphicSize.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				if(e.Delta>0){
					if(pGraphicSize <10) pGraphicSize++;
					else pGraphicSize = 1;
				}else{
					if(pGraphicSize > 1) pGraphicSize--;
					else pGraphicSize = 10;
				}
				miGraphicSize.Header = "Graphic size: "+pGraphicSize.ToString();
				ForceRefresh();
			};
//==========================================================
			miWeeklyPlotOnOff  = new MenuItem { Header = "Weekly plots "+(pEnableWeeklyPlot ? "ON":"OFF"), Name = "pEnableWeeklyPlotOnOff",  Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pEnableWeeklyPlot,  StaysOpenOnClick = true };
			miWeeklyPlotOnOff.Click += delegate (object o, RoutedEventArgs e){
				InformUserAboutRecalculation();
				pEnableWeeklyPlot = !pEnableWeeklyPlot;
				miWeeklyPlotOnOff.Header = "Weekly plots "+(pEnableWeeklyPlot ? "ON":"OFF");
			};
			miWeeklyPlotOnOff.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				pEnableWeeklyPlot = !pEnableWeeklyPlot;
				miWeeklyPlotOnOff.Header = "Weekly plots "+(pEnableWeeklyPlot ? "ON":"OFF");
			};
//==========================================================
			miWeeklyVLineOnOff  = new MenuItem { Header = "Weekly VLines "+(pEnableWeeklyVLine ? "ON":"OFF"), Name = "pEnableWeeklyVLineOnOff",  Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pEnableWeeklyVLine, IsEnabled=this.pWeekTime_SeparatorBrush!=Brushes.Transparent, StaysOpenOnClick = true };
			miWeeklyVLineOnOff.Click += delegate (object o, RoutedEventArgs e){
//				InformUserAboutRecalculation();
				pEnableWeeklyVLine = !pEnableWeeklyVLine;
				miWeeklyVLineOnOff.Header = "Weekly VLines "+(pEnableWeeklyVLine ? "ON":"OFF");
				ForceRefresh();
			};
			miWeeklyVLineOnOff.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
//				InformUserAboutRecalculation();
				pEnableWeeklyVLine = !pEnableWeeklyVLine;
				miWeeklyVLineOnOff.Header = "Weekly VLines "+(pEnableWeeklyVLine ? "ON":"OFF");
				ForceRefresh();
			};
//==========================================================
			miDailyPlotOnOff   = new MenuItem { Header = "Daily plots "+(pEnableDailyPlot   ? "ON":"OFF"), Name = "pEnableDailyPlotOnOff",   Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pEnableDailyPlot,   StaysOpenOnClick = true };
			miDailyPlotOnOff.Click += delegate (object o, RoutedEventArgs e){
				InformUserAboutRecalculation();
				pEnableDailyPlot = !pEnableDailyPlot;
				miDailyPlotOnOff.Header = "Daily plots "+(pEnableDailyPlot ? "ON":"OFF");
			};
			miDailyPlotOnOff.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				pEnableDailyPlot = !pEnableDailyPlot;
				miDailyPlotOnOff.Header = "Daily plots "+(pEnableDailyPlot ? "ON":"OFF");
			};
//==========================================================
			miDailyVLineOnOff  = new MenuItem { Header = "Daily VLines "+(pEnableDailyVLine ? "ON":"OFF"), Name = "pEnableDailyVLineOnOff",  Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pEnableDailyVLine, IsEnabled=this.pDayTime_SeparatorBrush!=Brushes.Transparent,  StaysOpenOnClick = true };
			miDailyVLineOnOff.Click += delegate (object o, RoutedEventArgs e){
//				InformUserAboutRecalculation();
				pEnableDailyVLine = !pEnableDailyVLine;
				miDailyVLineOnOff.Header = "Daily VLines "+(pEnableDailyVLine ? "ON":"OFF");
				ForceRefresh();
			};
			miDailyVLineOnOff.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
//				InformUserAboutRecalculation();
				pEnableDailyVLine = !pEnableDailyVLine;
				miDailyVLineOnOff.Header = "Daily VLines "+(pEnableDailyVLine ? "ON":"OFF");
				ForceRefresh();
			};
//==========================================================
			miCustomPlotOnOff  = new MenuItem { Header = "Custom plots "+(pEnableCustomPlot ? "ON":"OFF"), Name = "pEnableCustomPlotOnOff",  Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pEnableCustomPlot,  StaysOpenOnClick = true };
			miCustomPlotOnOff.Click += delegate (object o, RoutedEventArgs e){
				InformUserAboutRecalculation();
				pEnableCustomPlot = !pEnableCustomPlot;
				miCustomPlotOnOff.Header = "Custom plots "+(pEnableCustomPlot ? "ON":"OFF");
			};
			miCustomPlotOnOff.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				pEnableCustomPlot = !pEnableCustomPlot;
				miCustomPlotOnOff.Header = "Custom plots "+(pEnableCustomPlot ? "ON":"OFF");
			};
//==========================================================
			miCustomVLineOnOff  = new MenuItem { Header = "Custom VLines "+(pEnableCustomVLine ? "ON":"OFF"), Name = "pEnableCustomVLineOnOff",  Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pEnableCustomVLine, IsEnabled=this.pCustomTime_SeparatorBrush!=Brushes.Transparent,  StaysOpenOnClick = true };
			miCustomVLineOnOff.Click += delegate (object o, RoutedEventArgs e){
//				InformUserAboutRecalculation();
				pEnableCustomVLine = !pEnableCustomVLine;
				miCustomVLineOnOff.Header = "Custom VLines "+(pEnableCustomVLine ? "ON":"OFF");
				ForceRefresh();
			};
			miCustomVLineOnOff.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
//				InformUserAboutRecalculation();
				pEnableCustomVLine = !pEnableCustomVLine;
				miCustomVLineOnOff.Header = "Custom VLines "+(pEnableCustomVLine ? "ON":"OFF");
				ForceRefresh();
			};
//==========================================================
			miCustomTimeframe = new MenuItem { Header = "Custom Type:  "+GetStringCustomRange(pCustomTime), Name = "pCustomTime",  Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true,  StaysOpenOnClick = true };
			miCustomTimeframe.Click += delegate (object o, RoutedEventArgs e){
				InformUserAboutRecalculation();
				int type = (int)pCustomTime;
				type++;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_MarketMapper_CustomTimes)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_MarketMapper_CustomTimes), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				pCustomTime = (ARC_MarketMapper_CustomTimes)type;
				miCustomTimeframe.Header = "Custom Type:  "+GetStringCustomRange(pCustomTime);
			};
			miCustomTimeframe.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int type = (int)pCustomTime;
				if(e.Delta>0) type++; else type--;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_MarketMapper_CustomTimes)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_MarketMapper_CustomTimes), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				pCustomTime = (ARC_MarketMapper_CustomTimes)type;
				miCustomTimeframe.Header = "Custom Type:  "+GetStringCustomRange(pCustomTime);
			};
//==========================================================
			lblWeeklyAvgRange = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Weekly Avg (ticks)" };
			lblDailyAvgRange  = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Daily Avg (ticks)" };
			lblCustomAvgRange = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), 
					Content = (pCustomTime == ARC_MarketMapper_CustomTimes.None ? "" : GetStringCustomRange(pCustomTime)+" Avg (ticks)")};
			lblWeeklyAvgRange.FontWeight = FontWeights.Normal;
			lblDailyAvgRange.FontWeight = FontWeights.Normal;
			lblCustomAvgRange.FontWeight = FontWeights.Normal;

			lblWeekRange   = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Week current" };
			lblDayRange    = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Day current" };
			lblCustomRange = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), 
					Content = (pCustomTime == ARC_MarketMapper_CustomTimes.None ? "" : GetStringCustomRange(pCustomTime)+" current")};
			lblWeekRange.FontWeight = FontWeights.Normal;
			lblDayRange.FontWeight = FontWeights.Normal;
			lblCustomRange.FontWeight = FontWeights.Normal;

			#region -- Recalc Profiles --
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE signals", HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			#endregion

			MenuControl.Items.Add(miGraphicLocation);
			MenuControl.Items.Add(miGraphicSize);
					MenuControl.Items.Add(	new Separator());
			MenuControl.Items.Add(miWeeklyPlotOnOff);
			MenuControl.Items.Add(miWeeklyVLineOnOff);
					MenuControl.Items.Add(	new Separator());
			MenuControl.Items.Add(miDailyPlotOnOff);
			MenuControl.Items.Add(miDailyVLineOnOff);
					MenuControl.Items.Add(	new Separator());
			MenuControl.Items.Add(miCustomPlotOnOff);
			MenuControl.Items.Add(miCustomVLineOnOff);
			MenuControl.Items.Add(miCustomTimeframe);
					MenuControl.Items.Add(	new Separator());
			MenuControl.Items.Add(lblWeeklyAvgRange);
			MenuControl.Items.Add(lblDailyAvgRange);
			if(pCustomTime != ARC_MarketMapper_CustomTimes.None) MenuControl.Items.Add(lblCustomAvgRange);
					MenuControl.Items.Add(	new Separator());
			MenuControl.Items.Add(lblWeekRange);
			MenuControl.Items.Add(lblDayRange);
			if(pCustomTime != ARC_MarketMapper_CustomTimes.None) MenuControl.Items.Add(lblCustomRange);
					MenuControl.Items.Add(	new Separator());
			MenuControl.Items.Add(miRecalculate1);

			indytoolbar.Children.Add(MenuControlContainer);
		}
		private string GetStringCustomRange(ARC_MarketMapper_CustomTimes CustomTime){
			if(CustomTime == ARC_MarketMapper_CustomTimes.Minute10) return "10-minute";
			if(CustomTime == ARC_MarketMapper_CustomTimes.Minute15) return "15-minute";
			if(CustomTime == ARC_MarketMapper_CustomTimes.Minute30) return "30-minute";
			if(CustomTime == ARC_MarketMapper_CustomTimes.Hr1) return "Hourly";
			if(CustomTime == ARC_MarketMapper_CustomTimes.Hr2) return "2-Hour";
			if(CustomTime == ARC_MarketMapper_CustomTimes.Hr4) return "4-Hour";
			if(CustomTime == ARC_MarketMapper_CustomTimes.Hr8) return "8-Hour";
			if(CustomTime == ARC_MarketMapper_CustomTimes.Hr12) return "12-Hour";
			return "OFF";
		}

        #region private void menuTxtbox_KeyDown()
        private void menuTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtBoxSender = sender as TextBox;
			int max = 100;
			int min = 0;
			string startval = txtBoxSender.Text;
			try{
	            int keyVal = (int)e.Key;
	            int value = -1;
	            if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
					value = keyVal - (int)System.Windows.Input.Key.D0;
	            else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
					value = keyVal - (int)System.Windows.Input.Key.NumPad0;

	            bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);

//Print("IsNumberic: "+isNumeric.ToString());

				if (isNumeric || e.Key == System.Windows.Input.Key.Back)
    	        {
	                string newText    = value != -1 ? value.ToString() : "";
    	            int tbPosition    = txtBoxSender.SelectionStart;
        	        txtBoxSender.Text = txtBoxSender.SelectedText == "" ? txtBoxSender.Text.Insert(tbPosition, newText) : txtBoxSender.Text.Replace(txtBoxSender.SelectedText, newText);
            	    txtBoxSender.Select(tbPosition + 1, 0);
					int x = string.IsNullOrEmpty(txtBoxSender.Text.Trim()) ? min : Convert.ToInt32(txtBoxSender.Text);
					x = Math.Max(min, Math.Min(max,x));
					txtBoxSender.Text = x.ToString();
//Print("     text: "+txtBoxSender.Text);
				}
			}catch{
				txtBoxSender.Text = startval;
            }
        }
        #endregion
//=====================================================================================================
		private void InformUserAboutRecalculation(){
			miRecalculate1.Background = Brushes.Yellow;
			miRecalculate1.FontWeight = FontWeights.Bold;
			miRecalculate1.FontStyle  = FontStyles.Italic;
		}
		private void ResetRecalculationUI(){
			RecalcAt = DateTime.Now;
			miRecalculate1.FontWeight = FontWeights.Normal;
			miRecalculate1.FontStyle  = FontStyles.Normal;
			miRecalculate1.Background = null;
		}
//=====================================================================================================
		#region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Hidden;
		}
		#endregion

		#endregion

//===================================================================================================================================
		DayOfWeek LastDayOfWeek = DayOfWeek.Saturday;
		private class RangeData{
			public double H;
			public double L;
			public int StartABar;
			public RangeData(double h, double l, int startABar){H=h; L=l; StartABar = startABar;}
			public void Update(double pH, double pL){H = Math.Max(H,pH); L=Math.Min(L,pL);}
		}
		private List<RangeData> WeekData = new List<RangeData>();
		private List<RangeData> DayData = new List<RangeData>();
		private List<RangeData> CustomData = new List<RangeData>();
		double Weekly_AvgRange = 0;
		double Daily_AvgRange = 0;
		double Custom_AvgRange = 0;
		double Midline_Weekly = 0;
		double Midline_Daily = 0;
		double Midline_Custom = 0;
		int FirstBarOfWeek = 0;
		double CurrentDayH = 0;
		double CurrentDayL = 0;
		double wtop = 0;
		double wbot = 0;
		double dtop = 0;
		double dbot = 0;
		double ctop = 0;
		double cbot = 0;
		double CurrentWeekH = 0;
		double CurrentWeekL = 0;
		double CurrentCustomH = 0;
		double CurrentCustomL = 0;
//==============================================================================================
        protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
int line = 1355;
try{
			#region -- OnBarUpdate --
			if(CurrentBars[0] < 5)
				return;
//try{
			if(BarsInProgress==1){
				if(BarsArray[1].IsFirstBarOfSession){
line=1363;
					if((int)Times[1][0].DayOfWeek < (int)LastDayOfWeek) {
						FirstBarOfWeek = CurrentBars[1];
						if(WeekData.Count>0){
							Weekly_AvgRange = 0;
							foreach(var d in WeekData) Weekly_AvgRange += d.H-d.L;
							Weekly_AvgRange = Weekly_AvgRange / WeekData.Count;
						}

						WeekData.Insert(0, new RangeData(Highs[1][0], Lows[1][0], CurrentBars[0]));
						//if(pWeekTime_SeparatorBrush !=Brushes.Transparent && pEnableWeeklyVLine) Draw.VerticalLine(this,"WeekTime "+CurrentBar.ToString(),0, pWeekTime_SeparatorBrush);
						CurrentWeekH = Highs[1][0];
						CurrentWeekL = Lows[1][0];
					}
					LastDayOfWeek = Times[1][0].DayOfWeek;
line=1378;
					if(DayData.Count>0){
						Daily_AvgRange = 0;
						foreach(var d in DayData) Daily_AvgRange += d.H-d.L;
						Daily_AvgRange = Daily_AvgRange / DayData.Count;
					}
					DayData.Insert(0, new RangeData(Highs[1][0], Lows[1][0], CurrentBars[0]));
					//if(pDayTime_SeparatorBrush !=Brushes.Transparent && pEnableDailyVLine) Draw.VerticalLine(this,"DayTime "+CurrentBar.ToString(),0, pDayTime_SeparatorBrush);
					
line=1387;
					CurrentDayH = Highs[1][0];
					CurrentDayL = Lows[1][0];
				}else{
line=1391;
					CurrentDayH = Math.Max(CurrentDayH, Highs[1][0]);
					CurrentDayL = Math.Min(CurrentDayL, Lows[1][0]);
					if(DayData.Count>0) DayData[0].Update(CurrentDayH, CurrentDayL);
				}
				CurrentWeekH = Math.Max(CurrentWeekH, Highs[1][0]);
				CurrentWeekL = Math.Min(CurrentWeekL, Lows[1][0]);
				Midline_Weekly = (CurrentWeekH+CurrentWeekL)/2;
				if(Midline_Weekly!=0){
					wtop = Midline_Weekly + Weekly_AvgRange/2;
					wbot = Midline_Weekly - Weekly_AvgRange/2;
				}
				if(CurrentDayH!=0 && CurrentDayL!=0){
line=1404;
					Midline_Daily = (CurrentDayH + CurrentDayL) /2;
					dtop = Midline_Daily + Daily_AvgRange/2;
					dbot = Midline_Daily - Daily_AvgRange/2;
				}

line=1410;
				if(pCustomTime != ARC_MarketMapper_CustomTimes.None){
					int count = CustomData.Count;
					int t = -1;
					if(pCustomTime == ARC_MarketMapper_CustomTimes.Minute10){
						var ts = new TimeSpan(Times[1][0].Ticks - Times[1][1].Ticks);
						if(ts.TotalMinutes>10)
							t = 0;
						else
							t = Times[1][0].Minute % 10;
					}
					else if(pCustomTime == ARC_MarketMapper_CustomTimes.Minute15){
						var ts = new TimeSpan(Times[1][0].Ticks - Times[1][1].Ticks);
						if(ts.TotalMinutes>15)
							t = 0;
						else
							t = Times[1][0].Minute % 15;
					}
					else if(pCustomTime == ARC_MarketMapper_CustomTimes.Minute30){
						var ts = new TimeSpan(Times[1][0].Ticks - Times[1][1].Ticks);
						if(ts.TotalMinutes>30)
							t = 0;
						else
							t = Times[1][0].Minute % 30;
					}
					else if(pCustomTime == ARC_MarketMapper_CustomTimes.Hr1){
						var ts = new TimeSpan(Times[1][0].Ticks - Times[1][1].Ticks);
						if(ts.TotalMinutes>60)
							t = 0;
						else
							t = Times[1][0].Minute;
					}
					else if(pCustomTime == ARC_MarketMapper_CustomTimes.Hr2){
						var ts = new TimeSpan(Times[1][0].Ticks - Times[1][1].Ticks);
						if(ts.TotalMinutes>120)
							t = 0;
						else{
							if(Times[1][0].Minute != 0)
								t = -1;
							else
								t = Times[1][0].Hour % 2;
						}
					}
					else if(pCustomTime == ARC_MarketMapper_CustomTimes.Hr4){
						var ts = new TimeSpan(Times[1][0].Ticks - Times[1][1].Ticks);
						if(ts.TotalMinutes>240)
							t = 0;
						else{
							if(Times[1][0].Minute != 0)
								t = -1;
							else
								t = Times[1][0].Hour % 4;
						}
					}
					else if(pCustomTime == ARC_MarketMapper_CustomTimes.Hr8){
						var ts = new TimeSpan(Times[1][0].Ticks - Times[1][1].Ticks);
						if(ts.TotalMinutes>480)
							t = 0;
						else{
							if(Times[1][0].Minute != 0)
								t = -1;
							else
								t = Times[1][0].Hour % 8;
						}
					}
					else if(pCustomTime == ARC_MarketMapper_CustomTimes.Hr12){
						var ts = new TimeSpan(Times[1][0].Ticks - Times[1][1].Ticks);
						if(ts.TotalMinutes>720)
							t = 0;
						else{
							if(Times[1][0].Minute != 0)
								t = -1;
							else
								t = Times[1][0].Hour % 12;
						}
					}
					if(t==0){
						//if(pCustomTime_SeparatorBrush !=Brushes.Transparent && pEnableCustomVLine) Draw.VerticalLine(this,"CustomTime "+CurrentBar.ToString(),0, pCustomTime_SeparatorBrush);
						CustomData.Insert(0, new RangeData(Highs[1][0], Lows[1][0], CurrentBars[0]));
						CurrentCustomH = Highs[1][0];
						CurrentCustomL = Lows[1][0];
					}else{
						if(count>0) CustomData[0].Update(Highs[1][0], Lows[1][0]);
					}
					if(CustomData.Count>0 && CustomData.Count != count){
						Custom_AvgRange = 0;
						foreach(var d in CustomData) Custom_AvgRange += d.H-d.L;
						Custom_AvgRange = Custom_AvgRange / CustomData.Count;
					}
line=1499;
					CurrentCustomH = Math.Max(CurrentCustomH, Highs[1][0]);
					CurrentCustomL = Math.Min(CurrentCustomL, Lows[1][0]);
					Midline_Custom = (CurrentCustomH+CurrentCustomL)/2;
					ctop = Midline_Custom + Custom_AvgRange/2;
					cbot = Midline_Custom - Custom_AvgRange/2;
				}
			}else{
				if(pEnableWeeklyPlot && wtop!=wbot){
					if(wtop!=0){ WTop[0] = wtop; WBottom[0] = wbot;}
				}
				if(pEnableDailyPlot && dtop!=dbot){
					if(dtop!=0){ DTop[0] = dtop; DBottom[0] = dbot;}
				}
				if(pEnableCustomPlot && ctop!=cbot){
					if(ctop!=0){ CTop[0] = ctop; CBottom[0] = cbot;}
				}

				if(WeekData.Count>0) {
					WeekData[0].Update(Highs[1][0], Lows[1][0]);
					sExtrnWeeklyRange[0] = ComputePercent(Weekly_AvgRange, WeekData[0].H-WeekData[0].L);
				}
				if(DayData.Count>0){
					DayData[0].Update( Highs[1][0], Lows[1][0]);
					sExtrnDailyRange[0]  = ComputePercent(Daily_AvgRange,  DayData[0].H-DayData[0].L);
//Print("Day range today:  "+DayData[0].H+" - "+DayData[0].L+" = "+(DayData[0].H-DayData[0].L).ToString()+"  AvgRange: "+Daily_AvgRange.ToString());
				}
				if(CustomData.Count>0){
					sExtrnCustomRange[0] = ComputePercent(Custom_AvgRange, CustomData[0].H-CustomData[0].L);
				}
			}
}catch(Exception e){if(IsDebug) Print(line+":  "+e.ToString());}
			#endregion
        }
//==============================================================================================
		private void SetGraphic(int iOffset)
		{
			if(CT == null){
				return;
			}

			try
			{
				double WeeklyRange = sExtrnWeeklyRange.GetValueAt(iOffset);
				double DailyRange  = sExtrnDailyRange.GetValueAt(iOffset);
				double CustomRange = sExtrnCustomRange.GetValueAt(iOffset);

				// Protect against invalid seed values until the data is correct.
				if(
					!IsFinite(WeeklyRange)	
					|| !IsFinite(DailyRange)	
					|| !IsFinite(CustomRange)	
					)
					return;

				CT.Value1 = Convert.ToSingle(WeeklyRange);
				CT.Value2 = Convert.ToSingle(DailyRange);
				CT.Value3 = Convert.ToSingle(CustomRange);
			}
			catch(Exception e)
			{
				Print(e.Message);
				Log("ARC_MarketMapper - SetGraphic Exception = " + e.ToString(), NinjaTrader.Cbi.LogLevel.Error);
			}			
		}
		
        private bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value) && value < double.MaxValue;
        }

		#region RegAlerts
		
		private void SignalAlert(string wav)
		{
			if(!this.bCanAlertTrigger)
				return;
			
			if(wav != "SOUND OFF"){// && this.iEnableSoundAlert)
				this.PlaySound(AddSoundFolder(wav));				
				this.idTag++;
			}
		}
		//======================================================================================================
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
		#endregion

		#region RegNormalizing
		
		private float ComputePercent(double iForecast, double iCurrent)
		{
			if(iForecast == 0)
			{
				//Log("NS VSR - ComputePercent Exception = Div/0; Call " + iCall.ToString(), NinjaTrader.Cbi.LogLevel.Error);
				return 0;
			}
			
			if(iCurrent > iForecast)
				return Convert.ToSingle(100.0 * (iCurrent / iForecast));
						
			return Math.Min(100, Convert.ToSingle(100.0 * (1.0 - (Math.Abs(iForecast - iCurrent) / iForecast))));
		}
		
		#endregion

		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }

//====================================================================================================================================
		private SharpDX.Direct2D1.Brush backBrushDX = null;
		private SharpDX.Direct2D1.Brush txtBrushDX  = null;
		private SharpDX.Direct2D1.Brush SolidHistoBrushDX  = null;
		private SharpDX.Direct2D1.Brush gradientBrushDX    = null;
		private SharpDX.Direct2D1.Brush WeekTime_SeparatorBrushDX    = null;
		private SharpDX.Direct2D1.Brush DayTime_SeparatorBrushDX    = null;
		private SharpDX.Direct2D1.Brush CustomTime_SeparatorBrushDX    = null;
        public override void OnRenderTargetChanged()
        {
			//Dispose DX brushes
			if(backBrushDX!=null && !backBrushDX.IsDisposed) {backBrushDX.Dispose(); backBrushDX=null;}
			if(txtBrushDX!=null        && !txtBrushDX.IsDisposed)        {txtBrushDX.Dispose();         txtBrushDX=null;}
			if(SolidHistoBrushDX!=null && !SolidHistoBrushDX.IsDisposed) {SolidHistoBrushDX.Dispose();  SolidHistoBrushDX=null;}
			if(WeekTime_SeparatorBrushDX != null && !WeekTime_SeparatorBrushDX.IsDisposed) {WeekTime_SeparatorBrushDX.Dispose(); WeekTime_SeparatorBrushDX=null;}
			if(DayTime_SeparatorBrushDX != null  && !DayTime_SeparatorBrushDX.IsDisposed)  {DayTime_SeparatorBrushDX.Dispose(); DayTime_SeparatorBrushDX=null;}
			if(CustomTime_SeparatorBrushDX != null && !CustomTime_SeparatorBrushDX.IsDisposed) {CustomTime_SeparatorBrushDX.Dispose(); CustomTime_SeparatorBrushDX=null;}

			//create DX brushes
			if(RenderTarget!=null && backBrush!=null)        {backBrushDX        = backBrush.ToDxBrush(RenderTarget);}
			if(RenderTarget!=null && iTextColor!=null)       {txtBrushDX         = iTextColor.ToDxBrush(RenderTarget);}
			if(RenderTarget!=null && pSolidHistoColor!=null) {SolidHistoBrushDX  = this.pSolidHistoColor.ToDxBrush(RenderTarget);}
			if(RenderTarget!=null && pWeekTime_SeparatorBrush!=null)   {WeekTime_SeparatorBrushDX  = this.pWeekTime_SeparatorBrush.ToDxBrush(RenderTarget);}
			if(RenderTarget!=null && pDayTime_SeparatorBrush!=null)    {DayTime_SeparatorBrushDX   = this.pDayTime_SeparatorBrush.ToDxBrush(RenderTarget);}
			if(RenderTarget!=null && pCustomTime_SeparatorBrush!=null) {CustomTime_SeparatorBrushDX  = this.pCustomTime_SeparatorBrush.ToDxBrush(RenderTarget);}
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
#if DoLicense
			if (!ValidLicense) return;
#endif
			if (!IsVisible) return;
			if (chartControl==null) return;
			if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
			if(RenderTarget!=null && backBrush!=null && backBrushDX == null) {backBrushDX = backBrush.ToDxBrush(RenderTarget);}
			if(RenderTarget!=null && iTextColor!=null && txtBrushDX == null) {txtBrushDX  = iTextColor.ToDxBrush(RenderTarget);}
int line = 3489;
			base.OnRender(chartControl, chartScale);
try{

line=3500;
			var LMaB       = Math.Max(1,Math.Min(ChartBars.FromIndex, BarsArray[0].Count-1));
			var RMaB       = Math.Max(1,Math.Min(ChartBars.ToIndex, BarsArray[0].Count-1));
			var txtFormat  = iBarFont.ToDirectWriteTextFormat();
			var txtLayout  = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, "100.", txtFormat, (float)(ChartPanel.X + ChartPanel.W), Convert.ToSingle(iBarFont.Size));
			float txtwidth100 = txtLayout.Metrics.Width;
			float FontHeight  = txtLayout.Metrics.Height;
			float marginLRTB  = 5f;
			float HistoHeight = FontHeight;

			float ratio = pGraphicSize/10f;
			float w     = marginLRTB*2f + (675 * ratio) + txtwidth100;
			float h     = marginLRTB*2f + (FontHeight + HistoHeight + 1f)*3f;
			var bounds  = new RectangleF(0, 0, w, h);
			float originX = 0;
			float originY = 0;

//			if(MsgText!=null){
//				var ts = new TimeSpan(DateTime.Now.Ticks - RecalcAt.Ticks);
//				if(ts.TotalSeconds>5){
//					MsgText = null;
//					ForceRefresh();
//				}else{
//					txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, MsgText, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
//					if(txtBrushDX!=null) {
//						originX = bounds.Width*0.5f;
//						originY = bounds.Height*0.66f;
//						if(iGraphicLocation != ARC_MarketMapper_Locations.TopLeft && iGraphicLocation != ARC_MarketMapper_Locations.TopRight){
//							originX = 10f;
//							originY = bounds.Height*0.2f;
//						}
//						RenderTarget.DrawText(MsgText, txtFormat, new SharpDX.RectangleF(originX, originY, txtLayout.Metrics.Width, txtLayout.Metrics.Height), txtBrushDX);
//					}
//				}
//			}

			float x = ChartControl.GetXByBarIndex(chartControl.BarsArray[0], 0);
			float y0, y1;
			float barw = Math.Abs(x - ChartControl.GetXByBarIndex(chartControl.BarsArray[0], 1));
			float Halfbarw = Math.Max(2f,barw/2f);
			float Thirdbarw = Math.Max(2f,barw/3f);
			#region -- Draw period separators - Week, Day, Custom --
			if(pEnableCustomVLine && pCustomTime_SeparatorBrush != Brushes.Transparent){
				var abars = CustomData.Where(o=> o.StartABar > LMaB && o.StartABar <= RMaB).Select(o=> o.StartABar).ToList();
				foreach(var b in abars){
					x = Convert.ToSingle(ChartControl.GetXByBarIndex(chartControl.BarsArray[0], b))+Thirdbarw;
					y0 = chartScale.GetYByValue(CTop.GetValueAt(b+1));
					y1 = chartScale.GetYByValue(CBottom.GetValueAt(b+1));
					RenderTarget.FillRectangle(new SharpDX.RectangleF(x, y0, Thirdbarw, (Math.Abs(y0-y1))), CustomTime_SeparatorBrushDX);
				}
			}
			if(pEnableDailyVLine && pDayTime_SeparatorBrush != Brushes.Transparent){
				var abars = DayData.Where(o=> o.StartABar > LMaB && o.StartABar <= RMaB).Select(o=> o.StartABar).ToList();
				foreach(var b in abars){
					x = Convert.ToSingle(ChartControl.GetXByBarIndex(chartControl.BarsArray[0], b))+Thirdbarw;
					y0 = chartScale.GetYByValue(DTop.GetValueAt(b+1));
					y1 = chartScale.GetYByValue(DBottom.GetValueAt(b+1));
					RenderTarget.FillRectangle(new SharpDX.RectangleF(x, y0, Thirdbarw, (Math.Abs(y0-y1))), DayTime_SeparatorBrushDX);
				}
			}
			if(pEnableWeeklyVLine && pWeekTime_SeparatorBrush != Brushes.Transparent){
				var abars = WeekData.Where(o=> o.StartABar > LMaB && o.StartABar <= RMaB).Select(o=> o.StartABar).ToList();
				foreach(var b in abars){
					x = Convert.ToSingle(ChartControl.GetXByBarIndex(chartControl.BarsArray[0], b))+Thirdbarw;
					y0 = chartScale.GetYByValue(WTop.GetValueAt(b+1));
					y1 = chartScale.GetYByValue(WBottom.GetValueAt(b+1));
					RenderTarget.FillRectangle(new SharpDX.RectangleF(x, y0, Thirdbarw, (Math.Abs(y0-y1))), WeekTime_SeparatorBrushDX);
				}
			}
			#endregion

			var originalMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
			originX = 0;
			originY = 0;
			bool IsOnRight = false;
			if(iGraphicLocation == ARC_MarketMapper_Locations.TopLeft){
				originX = 10f;
				originY = 20f;
			}else if(iGraphicLocation == ARC_MarketMapper_Locations.TopRight){
				IsOnRight = true;
				originX = ChartPanel.W - (bounds.Width);
				originY = 10f;
			}else if(iGraphicLocation == ARC_MarketMapper_Locations.Center){
				originX = (ChartPanel.W - (bounds.Width))/2f;
				originY = (ChartPanel.H - bounds.Height)/2f;
			}else if(iGraphicLocation == ARC_MarketMapper_Locations.BottomLeft){
				originX = 10f;
				originY = ChartPanel.H - bounds.Height - FontHeight;
			}else if(iGraphicLocation == ARC_MarketMapper_Locations.BottomRight){
				IsOnRight = true;
				originX = ChartPanel.W - (bounds.Width);
				originY = ChartPanel.H - bounds.Height - FontHeight;
			}
			bounds.X = originX;
			bounds.Y = originY;
			if(iGraphicLocation != ARC_MarketMapper_Locations.None){
				if(backBrushDX!=null) RenderTarget.FillRectangle(bounds, backBrushDX);

			// Initial Draw and Setup
				if (!this.bGraphicsInitialized)
				{
					this.bGraphicsInitialized = true;
					this.DrawGraphics(new SharpDX.RectangleF(originX, bounds.Top + originY, (int)w, (int)h));
				}
				this.SetGraphic(Math.Max(0, Math.Min(CurrentBars[0] - 1, chartControl.LastSlotPainted)));

				x = bounds.X + marginLRTB;
				originX = x;
				float xHisto = x;//+ txtLayout.Metrics.Width*1.5f;
				float HistoMaxWidth = bounds.Width - marginLRTB*2f - txtwidth100;
				float y = bounds.Y + marginLRTB;
				float histoWidth = 0f;

		//draw 1st histo bar for "Weekly"
				#region -- 1st thermometer --
				txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, CT.TitleBar1, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
				if(txtBrushDX!=null) {
					RenderTarget.DrawText(CT.TitleBar1, txtFormat, new SharpDX.RectangleF(x, y, txtLayout.Metrics.Width, txtLayout.Metrics.Height), txtBrushDX);
					y = y + FontHeight;
				}
				var gradientRect0 = new RectangleF(xHisto, y+1f, HistoMaxWidth, HistoHeight-2f);
				#region -- Create gradientBrushDX --
				var lgb0 = new LinearGradientBrush();
				if(pEnableGradientHisto){
					lgb0.StartPoint = new System.Windows.Point(gradientRect0.TopLeft.X, gradientRect0.TopLeft.Y);
					lgb0.EndPoint = new System.Windows.Point(gradientRect0.BottomRight.X,gradientRect0.BottomRight.Y);

					var redGS = new GradientStop(Colors.Red, 0.75);
					lgb0.GradientStops.Add(redGS);

					var yellowGS = new GradientStop(Colors.Yellow, 0.5);
					lgb0.GradientStops.Add(yellowGS);

					var greenGS = new GradientStop(Colors.Green, 0.25);
					lgb0.GradientStops.Add(greenGS);
					gradientBrushDX = lgb0.ToDxBrush(RenderTarget);
					#endregion
					RenderTarget.FillRectangle(gradientRect0, gradientBrushDX);//draw gradient rectangle
				}else{
					RenderTarget.FillRectangle(gradientRect0, SolidHistoBrushDX);
				}

				string histoValText = string.Empty;
				double val = Math.Max(0, Math.Min(sExtrnWeeklyRange.GetValueAt(RMaB), WEEKLY_SCALE_MAX));
				histoWidth = HistoMaxWidth * Convert.ToSingle(val)/WEEKLY_SCALE_MAX;
				histoValText = (val).ToString("0");

				x = xHisto + histoWidth;
				if(backBrushDX!=null) RenderTarget.FillRectangle(new SharpDX.RectangleF(x, y, HistoMaxWidth-histoWidth, HistoHeight), backBrushDX);//blank-out the rightside of the gradient area, based on the size of the histo bar
				txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, histoValText, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
				if(txtBrushDX!=null) RenderTarget.DrawText(histoValText, txtFormat, new SharpDX.RectangleF(x + 5f, y, txtLayout.Metrics.Width*1.5f, txtLayout.Metrics.Height), txtBrushDX);
				#endregion

		//draw 2nd histo bar for "Daily"
				#region -- 2nd thermometer --
				x = originX;
				y = y + HistoHeight;
				txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, CT.TitleBar2, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
				if(txtBrushDX!=null) {
					RenderTarget.DrawText(CT.TitleBar2, txtFormat, new SharpDX.RectangleF(x,y, txtLayout.Metrics.Width, txtLayout.Metrics.Height), txtBrushDX);
					y = y + FontHeight;
				}

				gradientRect0.Y = y+1f;
				if(pEnableGradientHisto){
					gradientBrushDX.Dispose();
					lgb0.StartPoint = new System.Windows.Point(gradientRect0.TopLeft.X, gradientRect0.TopLeft.Y);
					lgb0.EndPoint   = new System.Windows.Point(gradientRect0.BottomRight.X,gradientRect0.BottomRight.Y);
					gradientBrushDX = lgb0.ToDxBrush(RenderTarget);
					RenderTarget.FillRectangle(gradientRect0, gradientBrushDX);//draw gradient rectangle
				}else{
					RenderTarget.FillRectangle(gradientRect0, SolidHistoBrushDX);
				}

				val = Math.Max(0, Math.Min(sExtrnDailyRange.GetValueAt(RMaB), DAILY_SCALE_MAX));
				histoWidth = HistoMaxWidth * Convert.ToSingle(val)/DAILY_SCALE_MAX;
				histoValText = (val).ToString("0");

				x = xHisto + histoWidth;
				if(backBrushDX!=null) RenderTarget.FillRectangle(new SharpDX.RectangleF(x, y, HistoMaxWidth-histoWidth, HistoHeight), backBrushDX);//blank-out the rightside of the gradient area, based on the size of the histo bar
				txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, histoValText, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
				if(txtBrushDX!=null) RenderTarget.DrawText(histoValText, txtFormat, new SharpDX.RectangleF(xHisto + histoWidth+5f, y, txtLayout.Metrics.Width*1.5f, txtLayout.Metrics.Height), txtBrushDX);
				#endregion

		//draw 3rd histo bar for "Custom"
				#region -- 3rd thermometer --
				x = originX;
				y = y + HistoHeight;
				txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, CT.TitleBar3, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
				if(txtBrushDX!=null){
					RenderTarget.DrawText(CT.TitleBar3, txtFormat, new SharpDX.RectangleF(x,y, txtLayout.Metrics.Width, txtLayout.Metrics.Height), txtBrushDX);
					y = y + FontHeight;
				}

				gradientRect0.Y = y+1f;
				if(pEnableGradientHisto){
					gradientBrushDX.Dispose();
					lgb0.StartPoint = new System.Windows.Point(gradientRect0.TopLeft.X, gradientRect0.TopLeft.Y);
					lgb0.EndPoint   = new System.Windows.Point(gradientRect0.BottomRight.X,gradientRect0.BottomRight.Y);
					gradientBrushDX = lgb0.ToDxBrush(RenderTarget);
					RenderTarget.FillRectangle(gradientRect0, gradientBrushDX);//draw gradient rectangle
				}else{
					RenderTarget.FillRectangle(gradientRect0, SolidHistoBrushDX);
				}

				val = Math.Max(0, Math.Min(sExtrnCustomRange.GetValueAt(RMaB), CUSTOM_SCALE_MAX));
				histoWidth = HistoMaxWidth * Convert.ToSingle(val)/CUSTOM_SCALE_MAX;
				histoValText = (val).ToString("0");

				x = xHisto + histoWidth;
				if(backBrushDX!=null) RenderTarget.FillRectangle(new SharpDX.RectangleF(x, y, HistoMaxWidth-histoWidth, HistoHeight), backBrushDX);//blank-out the rightside of the gradient area, based on the size of the histo bar
				txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, histoValText, txtFormat, (float)(ChartPanel.X + ChartPanel.W), FontHeight);
				if(txtBrushDX!=null) RenderTarget.DrawText(histoValText, txtFormat, new SharpDX.RectangleF(xHisto + histoWidth+5f, y, txtLayout.Metrics.Width*1.5f, txtLayout.Metrics.Height), txtBrushDX);
				#endregion

				SimpleFont font = (SimpleFont)iBarFont.Clone();
				font.Size = iBarFont.Size * 0.66f;
				var txtFormat2  = font.ToDirectWriteTextFormat();
				SharpDX.DirectWrite.TextLayout txtLayout2=null;
				foreach(var pct in ScaleValues){
					x = xHisto + (pct/(WEEKLY_SCALE_MAX/100f) * HistoMaxWidth);
					var v1 = new SharpDX.Vector2(x, bounds.Y+marginLRTB);
					var v2 = new SharpDX.Vector2(x, v1.Y + bounds.Height-marginLRTB*2f);
					RenderTarget.DrawLine(v1, v2, txtBrushDX);
					string pctStr = string.Format("{0}%", (pct*100f).ToString("0.0").Replace(".0",string.Empty));
					if(txtBrushDX!=null){
						txtLayout2 = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, pctStr, txtFormat2, (float)(ChartPanel.X + ChartPanel.W), Convert.ToSingle(font.Size)/2f);
						if(iGraphicLocation == ARC_MarketMapper_Locations.BottomLeft || iGraphicLocation == ARC_MarketMapper_Locations.BottomRight)
							RenderTarget.DrawText(pctStr, txtFormat2, new SharpDX.RectangleF(v1.X,v1.Y-txtLayout2.Metrics.Height, txtLayout2.Metrics.Width+10f, txtLayout2.Metrics.Height), txtBrushDX);
						else
							RenderTarget.DrawText(pctStr, txtFormat2, new SharpDX.RectangleF(v2.X,v2.Y+3f, txtLayout2.Metrics.Width+10f, txtLayout2.Metrics.Height), txtBrushDX);
					}
				}
				if(txtFormat!=null  && !txtFormat.IsDisposed)  txtFormat.Dispose();
				if(txtFormat2!=null && !txtFormat2.IsDisposed) txtFormat2.Dispose();
				if(txtLayout!=null  && !txtLayout.IsDisposed)  txtLayout.Dispose();
				if(txtLayout2!=null && !txtLayout2.IsDisposed) txtLayout2.Dispose();
line=3682;
			}
			RenderTarget.AntialiasMode = originalMode;
			if(gradientBrushDX!=null && !gradientBrushDX.IsDisposed) {gradientBrushDX.Dispose(); gradientBrushDX=null;}
} catch(Exception ex) {
	Log(line+":   Exception in OnRender: " + ex.Message + "\n" + ex.StackTrace, Cbi.LogLevel.Error);
}
		}

// ////////////////////////////////////////////////////////////////
		public void DrawGraphics(SharpDX.RectangleF iDrawBox)
		{
			int nBar_X = (int)iDrawBox.X;
			int nBar_Y = (int)iDrawBox.Y;
			int mBar_Width  = (int)iDrawBox.Width - (int)iDrawBox.Height;
			int mBar_Height = (int)iDrawBox.Height;

			SharpDX.RectangleF mBar_rect = new SharpDX.RectangleF(nBar_X, nBar_Y, mBar_Width / 3, mBar_Height);
			PlotBars(mBar_rect);		

//			int nCircle_Padding_Top = 10;
//			int nCircle_Padding_Right = 10;
//			int nCircle_Padding_Bottom = 10;
//			int nCircle_Padding_Left = 10;

//			int nCircle_X = mBar_Width;
//			int nCircle_Y = 0;
//			int mCircle_Width = (int)iDrawBox.Height;
//			int mCircle_Height = (int)iDrawBox.Height;

//			nCircle_X += nCircle_Padding_Left;
//			nCircle_Y += nCircle_Padding_Top;
//			mCircle_Width -= (nCircle_Padding_Right + nCircle_Padding_Left);
//			mCircle_Height -= (nCircle_Padding_Top + nCircle_Padding_Bottom);

//			SharpDX.RectangleF mCircle_rect = new SharpDX.RectangleF(nCircle_X, nCircle_Y, mCircle_Width, mCircle_Height);
//			PlotGauge(mCircle_rect);
		}

		private void PlotBars(SharpDX.RectangleF iBounds)
		{
			this.CT = new ClassThermometerBar(iBounds.Height, iBounds.Width);            

			this.CT.TitleColor = this.iTextColor;
			this.CT.DrawColor = this.iTextColor;

			this.CT.InitTitle_Bar1("Weekly", this.iBarFont, 12, 90);
			this.CT.InitBaseVal_Bar1(WEEKLY_SCALE_MIN, WEEKLY_SCALE_MAX, 20, 20);

			this.CT.InitTitle_Bar2("Daily", this.iBarFont, 12, 86);
			this.CT.InitBaseVal_Bar2(DAILY_SCALE_MIN, DAILY_SCALE_MAX, 20, 10);

			this.CT.InitTitle_Bar3("Custom", this.iBarFont, 12, 92);
			this.CT.InitBaseVal_Bar3(CUSTOM_SCALE_MIN, CUSTOM_SCALE_MAX, 20, 10);  			
		}		
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_MarketMapper[] cacheARC_MarketMapper;
		public ARC.ARC_MarketMapper ARC_MarketMapper()
		{
			return ARC_MarketMapper(Input);
		}

		public ARC.ARC_MarketMapper ARC_MarketMapper(ISeries<double> input)
		{
			if (cacheARC_MarketMapper != null)
				for (int idx = 0; idx < cacheARC_MarketMapper.Length; idx++)
					if (cacheARC_MarketMapper[idx] != null &&  cacheARC_MarketMapper[idx].EqualsInput(input))
						return cacheARC_MarketMapper[idx];
			return CacheIndicator<ARC.ARC_MarketMapper>(new ARC.ARC_MarketMapper(), input, ref cacheARC_MarketMapper);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_MarketMapper ARC_MarketMapper()
		{
			return indicator.ARC_MarketMapper(Input);
		}

		public Indicators.ARC.ARC_MarketMapper ARC_MarketMapper(ISeries<double> input )
		{
			return indicator.ARC_MarketMapper(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_MarketMapper ARC_MarketMapper()
		{
			return indicator.ARC_MarketMapper(Input);
		}

		public Indicators.ARC.ARC_MarketMapper ARC_MarketMapper(ISeries<double> input )
		{
			return indicator.ARC_MarketMapper(input);
		}
	}
}

#endregion
