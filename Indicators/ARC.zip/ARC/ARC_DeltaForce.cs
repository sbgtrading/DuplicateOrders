#define DoLicense
#define MODERATORS
//#define STOPWATCH_OUTPUT
//#define USE_WPF_COORDS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using System.Windows.Controls;
using System.Windows.Automation;
using System.Diagnostics;
using SharpDX.DirectWrite;
using NinjaTrader.Gui.NinjaScript;
using System.Reflection;
using System.Windows.Automation.Peers;
using System.Windows.Automation.Provider;
#endregion

/*
v1.0 - Ben Letto
----------------------------------------------------------------------
*/

//Search for #REMARQUE / #OVERLAY
namespace NinjaTrader.NinjaScript.Indicators.ARC
{

	public enum ARC_DeltaForce_SignalTimingTypes {OnTick, OnClose, NoAlerts}
	public enum ARC_DeltaForce_SLTP_CalcBasis {ATR, Ticks}
	public enum ARC_DeltaForce_TPLabelSide {Left, Right}

	#region -- Category Order --
	[CategoryOrder("Data", 0)]
	[CategoryOrder("Indicator Display", 10)]
	[CategoryOrder("MACDBB Parameters", 15)]
	[CategoryOrder("Bar Display", 20)]
	[CategoryOrder("Print Display", 30)]
	[CategoryOrder("Zones Display", 40)]
	[CategoryOrder("Bid/Ask Imbalances", 50)]
	[CategoryOrder("Block Trades", 60)]
	[CategoryOrder("Trapped Trader / Delta Divergence Signals", 70)]
	[CategoryOrder("Inventory Display", 80)]
	[CategoryOrder("Avg Stop Loss Calculators", 90)]
	[CategoryOrder("Volume Averages Set 1", 100)]
	[CategoryOrder("Volume Averages Set 2", 110)]
	[CategoryOrder("DSA Alert", 120)]
	#endregion
	public class ARC_DeltaForce : Indicator
	{
		private const int BUY = 1;
		private const int FLAT = 0;
		private const int SELL = -1;
		//-------------------------------- Variables -----------------------------
		private bool IsDebug = false;

		private float BARRIER_LINE_HEIGHT = 22f;
//		private double atr30_pts = 0;

		private const string VERSION = "v1.4 4.23.2020";
		//v1.1 - added BuyWAV and SellWAV and audible alerts, fixed DSA signal opacity range causing small right-shift in racing stripes
		//v1.2 - Changed buy/sell sig color to Transparent, fixed heatmap shifting right, added pArrowSeparation to move buy/sell signal away from price bars
		//v1.3 - Fixed AxisDXBrush issue - in certain circumstances, the AxisPen is null, seems to be when chart data is stagnant (not live or not refreshed recently)
		//v1.4 - OnRenderTargetChanged - added exclusion for AxisBrush when ChartControl==null

		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "DeltaForce";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "10647"};
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		private MACD BMACD;
		private MACD MACD1;
		private MACD MACD2;
		private MACD MACD3;
		private MACD MACD4;
		private StdDev SDBB, CND_SDBB;
		private Series<double> Histogram, ryVolAdjuster, Upper, Lower, BBDotLine;
		private Series<int> DSA_Signal, DFSignalHistory, MACD_Trend;
		private MACD CNCD;
		private Series<double> CumNetD;
		//private SortedDictionary<int,int> DSA_SignalDict = new SortedDictionary<int,int>();
		private int LastSignal = FLAT;
		private bool DidDotLineRetreatInsideBB = true;
//		Brush BuyStripeBrush, SellStripeBrush;
		SharpDX.Direct2D1.Brush BuyStripeDXBrush=null;
		SharpDX.Direct2D1.Brush SellStripeDXBrush=null;
		SharpDX.Direct2D1.Brush fillbrush=null;
		SharpDX.Direct2D1.Brush EntryDXBrush=null;
		SharpDX.Direct2D1.Brush EntryContrastDXBrush=null;
		SharpDX.Direct2D1.Brush LongSLDXBrush=null;
		SharpDX.Direct2D1.Brush LongT1DXBrush=null;
		SharpDX.Direct2D1.Brush LongT2DXBrush=null;
		SharpDX.Direct2D1.Brush LongSLContrastDXBrush=null;
		SharpDX.Direct2D1.Brush LongT1ContrastDXBrush=null;
		SharpDX.Direct2D1.Brush LongT2ContrastDXBrush=null;
		SharpDX.Direct2D1.Brush ShortSLDXBrush=null;
		SharpDX.Direct2D1.Brush ShortT1DXBrush=null;
		SharpDX.Direct2D1.Brush ShortT2DXBrush=null;
		SharpDX.Direct2D1.Brush ShortSLContrastDXBrush=null;
		SharpDX.Direct2D1.Brush ShortT1ContrastDXBrush=null;
		SharpDX.Direct2D1.Brush ShortT2ContrastDXBrush=null;
		SharpDX.Direct2D1.Brush Buy_DSA_DXBrush=null;
		SharpDX.Direct2D1.Brush Sell_DSA_DXBrush=null;
		SharpDX.Direct2D1.Brush HeatMap_MinimumLineDXBrush=null;

#if STOPWATCH_OUTPUT
		private SortedDictionary<string,TimeSpan> BenStopwatch = new SortedDictionary<string,TimeSpan>();
#endif
		private const int pFOREXD = 100000;
		private DateTime  dt;
		private bool      RunningFirstBar   = true;
		private int       ErrorCount         = 0;
		private int       LowBarWarningCount = 0;
		private int       line = 0;

        #region -- Variables --
//        private bool pOutlineZones = true;
//        private int pArrowHeight = 0;
//        private int pArrowBarWidth = 4;
//        private int pArrowTipAdjust = 2;
        private int pBoxSpace = 1;
		private int fbi = 0;
		private int lbi = 0;
        //-- others --
		private MouseManager MM;
		private int CBB = 0;
		private bool IsCurrentBar = false;
		private double PreviousVolume = 0;
		private int y1, y2, y3, y4, y5, y6, y7, y8, y9 = 0;
		private int x1, x2, x3, x4, x5, x6, x7, x8, x9 = 0;

        private bool ReadyToClose = false;
        private SortedDictionary<int, SortedDictionary<double, PrintLevelDetails>> BarDataCollection = new SortedDictionary<int, SortedDictionary<double, PrintLevelDetails>>();
        private int ThisCurrentBar = 0;
        private SortedDictionary<double, PrintLevelDetails> thisBarData = new SortedDictionary<double, PrintLevelDetails>();
        private bool Initialized = false;
        private int TickDirection = 0;
        private List<double> TickLevels = new List<double>();
        private long PLastVolume;

        private SortedList<int, BarTotal> BarDataTotals = new SortedList<int, BarTotal>();

        private int MouseBarIndex = 0;
        private SortedDictionary<double, PriceBox> PriceBoxes = new SortedDictionary<double, PriceBox>();//#REMARQUE : can be simple list not sorted
        private int AverageBoxHeight = 0;
        private int TotalBoxHeight = 0;
//        private int maxBarWidth = 1000;
        private int maxBarHeight = 1000;
        private int minBarHeight = 1;
        private SimpleFont GeneralFont = new SimpleFont("Arial", 12);
//        private int AdjustFontAmount = 0;
        private int diff = 0;
//        private int FinalDesiredMargin = 0;
        private int lastBarIndex = 0;
//        private int ClickedZoneBar = 0;
//        private double ClickedZoneTop = 0;
//        private double ClickedZoneBottom = 0;
//        private int XE = 0;
//        private Rect BidRect = new Rect(0, 0, 0, 0);
//        private Rect BidRectF = new Rect(0, 0, 0, 0);
//        private Rect BidRect5 = new Rect(0, 0, 0, 0);
//        private const int bsp = 0;
//        private const int bsp2 = 8;
//        private Pen ZoneH = new Pen(Brushes.Black, 3), ButtonPen = new Pen(Brushes.Black, 1);
        private Brush ButtonBrush = Brushes.LightGray;
        private Brush ButtonTextBrush = Brushes.Black;

//		private SimpleFont barprintFont = null;
        private SimpleFont ButtonFont = new SimpleFont("Arial", 12) { Bold = true };
        //-- Ladder --
        private bool FirstOnMarketDepthRun = false;
        private List<LadderRow> askRows = new List<LadderRow>();
        private List<LadderRow> bidRows = new List<LadderRow>();

        //--- curve
//        private double Price100P = 0;
//        private double Price0P = 0;
//        private int pOpacity1 = 100;
        private int pButtonSpace = 6;
//        private SortedDictionary<double, int> AllLevels = new SortedDictionary<double, int>();
//        private int CB = 0;
//        private double CH = 0;
//        private double CL = 0;
//        private bool ZoneSnapHover = false;
//        private bool ZoneSnapHover2 = false;

        //------ used for calculations --
//        private int PriceDigits = 0;
//        private string PriceString;
        private bool BarsAreMinute = false;

//        private VolumeProfileS AP;

        //---------- print -------------
//        private bool InButton1 = false;
//        private bool InButton2 = false;
//        List<int> PrintIndividualBars = new List<int>();
//        List<int> ProfileIndividualBars = new List<int>();
//        private int LastBlockWidth2 = 0;
//        private int MaxTextWidth2 = 0;
//        private double x1cp, x2cp, x4cp = 0;
//        private Rect ThisRect = new Rect(0, 0, 0, 0);
//        private Rect AskRect = new Rect(0, 0, 0, 0);

//        private bool OverrideFill1 = false;
//        private Rect BidSignalRect = new Rect(0, 0, 0, 0);
//        private Rect AskSignalRect = new Rect(0, 0, 0, 0);

        //-------- Manual Profile --------------
//		private const string MANUAL_PROFILE_TAG_SUFFIX = "_ManualProfile";
//        private string HoveredRectangleTag = string.Empty;
//        private int HoveredRectangleButton = 0;
//        private SortedList<string, VolumeProfileS> ManualProfiles = new SortedList<string, VolumeProfileS>();
//        private SortedList<string, int> ManualProfilesVE = new SortedList<string, int>();
//        private SortedList<string, int> ManualProfilesLE = new SortedList<string, int>();
//        private Rect BidRectF25 = new Rect(0, 0, 0, 0);
//        private List<string> AllRectangles = new List<string>();
//        private SortedList<string, int> ManualProfilesCB = new SortedList<string, int>();
        #endregion
		private bool IsForex = false;
		private double Opens00  = 0;
		private double Highs00  = 0;
		private double Lows00   = 0;
		private double Closes00 = 0;
		private double Highs01  = 0;
		private double Lows01   = 0;
		private double Highs10  = 0;
		private double Lows10   = 0;
		private double Closes10 = 0;
		private double SL_inPts=0;
		private double T1_inPts=0;
		private double T2_inPts=0;


		#region -- Variables Series --
		private Series<double> BodyHigh, BodyLow;
		private Series<double> Direction;
		private Series<double> BARCL;
		private Series<double> atr;
		#endregion

        private Series<double> NETDELTA;

        #region -- Toolbar --
        private string toolbarname = "DeltaForceToolBar", uID;
        private bool isToolBarButtonAdded = false;
        #endregion

		SolidColorBrush[] NetDHeatMap_Brushes = new SolidColorBrush[20];
		SharpDX.Direct2D1.Brush[] NetDHeatMap_DXBrushes = new SharpDX.Direct2D1.Brush[20];
		SharpDX.Direct2D1.Brush DSA_DXBrush = null;//brush used to color the DSA signal rectangle around the HeatMap histo bars, and the price bar

		#region -- SharpDX brushes --
//		SharpDX.Direct2D1.Brush iTextDXBrush5 = null;
//		SharpDX.Direct2D1.Brush iTextDXBrush6 = null;
//		SharpDX.Direct2D1.Brush iTextDXBrush7 = null;
		SharpDX.Direct2D1.Brush AxisDXBrush = null;
//		SharpDX.Direct2D1.Brush iBlocksDXBrush = null;
//		SharpDX.Direct2D1.Brush iBlocks2DXBrush = null;
//		SharpDX.Direct2D1.Brush ChartBackgroundDXBrush = null;

//		SharpDX.Direct2D1.Brush OverrideBrush = null; 
//		SharpDX.Direct2D1.Brush iIBBidDXBrush = null;
//		SharpDX.Direct2D1.Brush iIBBidDXBrush3 = null;
//		SharpDX.Direct2D1.Brush iIBAskDXBrush = null;
//		SharpDX.Direct2D1.Brush iIBAskDXBrush3 = null;
//

//        SharpDX.Direct2D1.Brush PenMDXBrush   = null;
//        SharpDX.Direct2D1.Brush BrushMDXBrush = null;
//        SharpDX.Direct2D1.Brush BrushTDXBrush = null;

//		SharpDX.Direct2D1.Brush ZoneHDXBrush = null;
//		int ZoneHLineWidth = 0;
//		SharpDX.Direct2D1.Brush ButtonDXBrush = null;
//		SharpDX.Direct2D1.Brush ButtonPenDXBrush = null;
//		SharpDX.Direct2D1.Brush ButtonTextDXBrush = null;
//		SharpDX.Direct2D1.Brush DXBrushes_Black = null;
//		SharpDX.Direct2D1.Brush DXBrushes_LightGreen = null;
//		SharpDX.Direct2D1.Brush DXBrushes_LightGray = null;
//		int RectangleLineWidth = 1;

//		SharpDX.Direct2D1.Brush DXBrushM2 = null;
//		SharpDX.Direct2D1.Brush PenM2DXBrush = null;

//		private SharpDX.Direct2D1.Brush iSupplyZDXBrushFresh, iSupplyZDXBrushTested, iSupplyZDXBrushBroken, iSupplyZOLDXBrushFresh, iSupplyZOLDXBrushTested, iSupplyZOLDXBrushBroken;
//		private SharpDX.Direct2D1.Brush iDemandZDXBrushFresh, iDemandZDXBrushTested, iDemandZDXBrushBroken, iDemandZOLDXBrushFresh, iDemandZOLDXBrushTested, iDemandZOLDXBrushBroken;
//		private SharpDX.Direct2D1.Brush iArrowUpDXBrush, iArrowDnDXBrush, iArrowUpODXBrush, iArrowDnODXBrush, iTM_DXBrush;
//		private SharpDX.Direct2D1.Brush iAskHistDXBrush1, iAskHistDXBrush2, iBidHistDXBrush1, iBidHistDXBrush2, iAskOutDXBrush1, iBidOutDXBrush1;
//		private SharpDX.Direct2D1.Brush TextBrush, iDPDXBrush, iDNDXBrush;
		private SharpDX.Direct2D1.Brush iDPDXBrush, iDNDXBrush;
//		private SharpDX.Direct2D1.Brush CurrentBrush = null;

		#endregion


		private class SmartMax{
			public int Period = 0;
			public SortedDictionary<int,long> Vals;//sequential list of the last Period-number of values
			public SortedDictionary<int,long> Avgs;//sequential list of averages for all bars
			public SortedDictionary<int,long> Maxs;//bar-by-bar history of Max values
			private long  MaxVal      = 0;
			private int   KeyOfMaxVal = -1;
			public bool   Initialized = false;
			public string Status      = string.Empty;
 
			#region Methods
			public SmartMax(int period){
				Period = period;
				Vals = new SortedDictionary<int,long>();
				Maxs = new SortedDictionary<int,long>();
				Avgs = new SortedDictionary<int,long>();
			}
			public long GetMax(){ 
				if(!Initialized) return int.MinValue;
				return MaxVal;
			}
			public long GetMax(int abar){ 
				if(Initialized && Maxs.ContainsKey(abar)) return Maxs[abar];
				return int.MinValue;
			}
			public long GetAverage(){ 
				if(!Initialized) return int.MinValue;
				if(Avgs.Count==0) return int.MinValue;
//				var k = Avgs.Keys.ToList().Last;
				return Avgs[Avgs.Keys.ToList().Max()];
			}
			public long GetAverage(int last_abar){ 
				if(!Initialized) return int.MinValue;
				if(Avgs.ContainsKey(last_abar)) return Avgs[last_abar];
				else return int.MinValue;
			}
			public long CalcAverage(){ 
				if(!Initialized) return int.MinValue;
				else if(Vals.Count>0){
try{
					var k = Vals.Keys.ToList();
					var avg = Convert.ToInt64(Vals.Values.Average());
					Avgs[k[k.Count-1]]= avg;
					return avg;
}catch(Exception e){Status="Line 963 "+e.ToString(); return int.MinValue;}
				}else return int.MinValue;
			}
			public long CalcAverage(int last_abar){ 
				if(!Initialized) return int.MinValue;
				else{
					if(Vals.Count>0) {
						var keys = Vals.Keys.ToList();
						double sum = 0;
						int i = 0;
//Status = keys.Count+"-keys";
						while(keys[i]<=last_abar){
							sum = sum + Vals[keys[i]];
//Status = string.Format("{0},  {1}",Status, Vals[keys[i]].ToString());
							i++;
						}
//Status = string.Format("{0}  sum:{1}",Status, sum);
						if(i>0) {
							var avg = Convert.ToInt64(sum/i);
							Avgs[last_abar] = avg;
							return avg;
						}else return 0;
					}else return 0;
				}
				return int.MinValue;
			}
			public void NoChange(int abar){
				Maxs[abar] = MaxVal;
				Avgs[abar] = GetAverage();
			}
			public void AddLong(long v, int abar){
				Status=string.Empty;
				try{
				if(!Initialized) {
					MaxVal = v;
					Vals[abar] = v;
					KeyOfMaxVal = abar;
					Initialized = true;
				}else{
					if(Vals.ContainsKey(abar)){
						Vals[abar] = v;
						if(v > MaxVal){
							MaxVal = v;
							KeyOfMaxVal = abar;
						}
					}else{
						Vals[abar] = v;
						if(Vals.Count > Period){
							var keys = Vals.Keys.ToList();
							if(keys[0]>keys[keys.Count-1]) keys.Reverse();//make sure the 0-element is the lowest
							while(keys.Count>0 && keys.Count > Period){
								if(keys[0]==KeyOfMaxVal) KeyOfMaxVal = int.MinValue;//search for max only when the Key of the prior max value has dropped off the period
								Vals.Remove(keys[0]);
								keys.RemoveAt(0);
							}
						}
						//if(KeyOfMaxVal==int.MinValue) Status = "-------------------   it's reset! -----  ";
						if(v > MaxVal){
							MaxVal = v;
							KeyOfMaxVal = abar;
						}else if(KeyOfMaxVal==int.MinValue){//search for max only when the Key of the prior max value has dropped off the period
							MaxVal = v;
							foreach(var kvp in Vals){
								if(kvp.Value >= MaxVal) {
									MaxVal = kvp.Value;
									KeyOfMaxVal = kvp.Key;
								}
							}
						}
						//if(Status.Length>0) Status = Status + "  it is now: "+KeyOfMaxVal.ToString();
						//Status = "Key is now: "+KeyOfMaxVal.ToString();
					}
				}
				Maxs[abar] = MaxVal;
				CalcAverage();
//Status = Status+"    Avg at "+abar+" is now: "+GetAverage().ToString();
				}catch(Exception e){Status = "line 1039: "+e.ToString();}
			}
			#endregion
 
		}
		private SmartMax NetD_MaxMgr = null;
		private SmartMax NetD_MinMgr = null;
		private SortedDictionary<int,int>   HeatMapBarToColor = new SortedDictionary<int,int>();//each price bar has a HeatMap color index value from 0 to 19 for the 20 different shades of green-to-red
		private SortedDictionary<int,float> VolumeAverage     = new SortedDictionary<int,float>();//vertical size of the heatmap rectangles are based on current volume as a multiple of recent average volume
//		private System.Collections.Generic.IEnumerable<KeyValuePair<int,SortedDictionary<double,PrintLevelDetails>>> BarData_VisibleBars = null;
//=================================================================================================
		private class AudibleAlerts{
			private SortedDictionary<string,string> Buys  = new SortedDictionary<string,String>();
			private SortedDictionary<string,string> Sells = new SortedDictionary<string,String>();
			private SortedDictionary<string,int>    AlertBars   = new SortedDictionary<string,int>();
			#region AudibleAlerts
			public AudibleAlerts(string[] BuyKeys, string[] BuyWAVs, string[] SellKeys, string[] SellWAVs){
				//if the BuyKeys length is shorter than BuyWAVs, then any BuyWAVs beyond the length of BuyKeys, will be ignored
				//if the SellKeys length is shorter than SellWAVs, then any SellWAVs beyond the length of SellKeys, will be ignored
				#region constructor
				string fname=string.Empty;
				for(var i = 0; i<BuyKeys.Length; i++){
					if(i < BuyWAVs.Length){
						if(BuyWAVs[i]=="SOUND OFF")
							Buys[BuyKeys[i]] = "SOUND OFF";
						else{
							fname = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", BuyWAVs[i].Trim());
							if(!fname.EndsWith(".wav")) fname = fname+".wav";
							if(System.IO.File.Exists(fname)){
								Buys[BuyKeys[i]] = fname;
								AlertBars[BuyKeys[i]] = 0;
							}
						}
					}
				}
				for(var i = 0; i<SellKeys.Length; i++){
					if(i < SellWAVs.Length){
						if(SellWAVs[i]=="SOUND OFF")
							Sells[SellKeys[i]] = "SOUND OFF";
						else{
							fname = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", SellWAVs[i].Trim());
							if(!fname.EndsWith(".wav")) fname = fname+".wav";
							if(System.IO.File.Exists(fname)){
								Sells[SellKeys[i]] = fname;
								AlertBars[SellKeys[i]] = 0;
							}
						}
					}
				}
				#endregion
			}
			public void Play(Indicator parent, int direction, string type, int signalbar){
				if(direction<0){//Sell signal
					if(!Sells.ContainsKey(type))
						parent.Alert(DateTime.Now.ToString(),Priority.Low, "DeltaForce SELL sound not found","",0,Brushes.DimGray,Brushes.White);
					else if(Sells[type] != "SOUND OFF" && AlertBars[type] != signalbar){
//parent.Print("PLaying DF SELL "+Sells[type]);
						parent.Alert(DateTime.Now.ToString(),Priority.Low, "DeltaForce SELL",Sells[type],0,Brushes.DimGray,Brushes.White);
//						parent.PlaySound(Sells[type]);
						AlertBars[type] = signalbar;
					}
				}
				else if(direction>0){//Buy signal
					if(!Buys.ContainsKey(type))
						parent.Alert(DateTime.Now.ToString(),Priority.Low, "DeltaForce BUY sound not found","",0,Brushes.DimGray,Brushes.White);
					else if(Buys[type] != "SOUND OFF" && AlertBars[type] != signalbar){
//parent.Print("PLaying DF BUY "+Buys[type]);
						parent.Alert(DateTime.Now.ToString(),Priority.Low, "DeltaForce BUY",Buys[type],0,Brushes.DimGray,Brushes.White);
//						parent.PlaySound(Buys[type]);
						AlertBars[type] = signalbar;
					}
				}
			}
			#endregion
		}
		private AudibleAlerts AudibleAlertMgr = null;
//=================================================================================================
        //------------------------------ Virtuals ---------------------------------
        public override string DisplayName { get { return "ARC_DeltaForce"; } }
		private byte ToByte(int i){return (byte)(Math.Max(0, Math.Min(255,i)));}

        private double gbTickSize = 0;
		private double RoundToTick(double p){
			double t = p/TickSize;
			if(t>int.MaxValue) return int.MaxValue*TickSize;
			else if(t<int.MinValue) return int.MinValue*TickSize;
			int i = Convert.ToInt32(t);
			return i*TickSize;
		}
//==============================================================================================
		private static string KeepOnlyTheseCharacters(string instr, string CharactersToKeep){
		string ret = string.Empty;
		char[] str = instr.ToCharArray(0,instr.Length);
		for(int i = 0; i<str.Length; i++) if(CharactersToKeep.Contains(str[i].ToString())) ret = string.Concat(ret,str[i].ToString());
		return ret;
	}
//=================================================================================================
        protected override void OnStateChange()
        {
	        #region --------- OnStateChange() ------------
			dt = DateTime.Now;
            #region State == State.SetDefaults
            if (State == State.SetDefaults)
            {
                Description = @"ARC_DeltaForce";
                Name = "ARC_DeltaForce";

                #region -- UI Settings --
                IsAutoScale = false;
                IsOverlay = true;
//                ArePlotsConfigurable = true;

                DisplayInDataBox = true;
                PaintPriceMarkers = true;
                MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
                ScaleJustification = ScaleJustification.Right;
                IsSuspendedWhileInactive = false;
                BarsRequiredToPlot = 1;

                Calculate = Calculate.OnEachTick;//force to on each tick
                #endregion

				AddPlot(new Stroke(Brushes.Transparent, 5f), PlotStyle.TriangleUp, "DF Buy");
				AddPlot(new Stroke(Brushes.Transparent, 5f), PlotStyle.TriangleDown, "DF Sell");
//				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA1CLH");
//				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA1VWAP");
//				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA1POC");
//				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA2CLL");
//				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA2CLH");
//				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA2VWAP");
//				AddPlot(new Stroke(Brushes.Orange), PlotStyle.Line, "VA2POC");

                #region -- Default Values --
				#region MACDBB Parameters
				BandPeriod = 10;
				Fast = 12;
				Slow = 26;
				StdDevNumber = 1.0;
				#endregion

				pRoundForexToWholePip = true;
                #region -- Category Bid/Ask Imbalances --
                //iTextColor6 = Brushes.Green;
                //iTextColor7 = Brushes.Red;
                //iIBAskColor = Brushes.Green;
                //iIBBidColor = Brushes.Red;
                //iIBFS = true;
//                iIpButtonSizeI = 2;
//                iOpacityUp2 = 75;
//                iOpacityDn2 = 75;
//                iImbalanceOffset = 2;
//                iVolumeQualifier = 0;
//                iRSSize = 4;
//                iBlocksO = 100;
//                iBlocksColor = Brushes.Black;
//                iBlocks2Color = Brushes.Yellow;
//                iShowImbalanceText = false;
//                iShowImbalanceA = false;
//                iShowImbalance = false;
//                iDotMode = "Outside";
                #endregion

				pSellWAV = "SOUND OFF";
				pBuyWAV = "SOUND OFF";

				
				#region -- Indicator Display --
				pButtonText = "DeltaForce";
				#endregion

                #region -- Zones Display --
//                iZonesEnabled = false;
//                iZonesTMEnabled = true;
//                iZonesTSEnabled = false;
//                iTickLevelWidth = 1;
//                iShowDemandZones = true;
//                iShowSupplyZones = true;
//                iShowFreshZones = true;
//                iShowTestedZones = true;
//                iShowBrokenZones = true;
//                iMinZWidth = 4;
//                iExtendZonesRight = true;
//                iSupplyZColorFresh = Brushes.Red;
//                iSupplyZColorTested = Brushes.LightPink;
//                iSupplyZColorBroken = Brushes.Fuchsia;
//                iDemandZColorFresh = Brushes.Green;
//                iDemandZColorTested = Brushes.LightGreen;
//                iDemandZColorBroken = Brushes.Cyan;
//                iSupplyZOLColorFresh = Brushes.Black;
//                iSupplyZOLColorTested = Brushes.Black;
//                iSupplyZOLColorBroken = Brushes.Black;
//                iDemandZOLColorFresh = Brushes.Black;
//                iDemandZOLColorTested = Brushes.Black;
//                iDemandZOLColorBroken = Brushes.Black;
//                iSupplyZOpacityFresh = 75;
//                iSupplyZOpacityTested = 75;
//                iSupplyZOpacityBroken = 40;
//                iDemandZOpacityFresh = 75;
//                iDemandZOpacityTested = 75;
//                iDemandZOpacityBroken = 40;
//                iTMColor = Brushes.White;
//                iTMOpacity = 100;
//                iTMWidth = 3;
                #endregion

                #region -- Print Display --
                iTextColor5 = Brushes.Black;
                iBarPrintFont = new SimpleFont("Arial", 12) { Bold = true };
//				barprintFont = (SimpleFont)iBarPrintFont.Clone();
//                iPrintEnabled = false;
                iDPColor = Brushes.DarkGreen;
                iDNColor = Brushes.DarkRed;
                iNetDeltaFont = new SimpleFont("Arial", 12) { Bold = true };
                pShowNetDeltaNumberOnBar = true;
				pShowNetDeltaHeatMap = true;
				pHeatMapHeightPeriod = 3;
				pHeatMapColorPeriod = 10;
//				iShowTotalVolumeInHeatMap = false;
//				iShowTotalVolumeAsPct = false;
				pHeatMap_PositiveColor = Brushes.DarkGreen;
				pHeatMap_NegativeColor = Brushes.DarkRed;
				pUseSkinnyHeatmapBars = false;
				pHeatMap_MinimumLineColor = Brushes.Black;
				pHeatMap_MinLineThickness = 1;

//                iCurrentBarEnabled = false;
//                iShowVolAtPrice = false;
				#endregion

				#region -- Bar Display --
				iMaxBarSpacePixels = 15;
				iMinBarSpacePixels = 2;
				iRightSideMarginMin = 100;
				iRightSidePaddingMin = 15;
				#endregion

                #region -- Block Trades --
//                iBlockSize = 20;
//                iIBAskColor3 = Brushes.Black;
//                iIBBidColor3 = Brushes.Black;
//                iOpacityUp3 = 100;
//                iOpacityDn3 = 100;
//                iShowBlocks = false;
//                iTriSize = 5;
//                iTriMode = "Inside";
                #endregion

                #region -- Avg Stop Loss Calculators --
//                iAvgStopLossOffset = 3;
                #endregion

                #region -- Inventory Display --
//                iInventoryEnabled = false;
//                iAskHistColor1 = Brushes.Red;
//                iAskHistColor2 = Brushes.Maroon;
//                iBidHistColor1 = Brushes.Green;
//                iBidHistColor2 = Brushes.Lime;
//                iAskOutColor1 = Brushes.Black;
//                iBidOutColor1 = Brushes.Black;
//                iDisplayTotal = true;
//                iTriMode2 = "Both";
//                iSwingOpacity2 = 80;
//                iSwingOpacity = 80;
//                iInvLength = 100;
//                imaxRows = 10;
//                ioutlineHistBars = false;
                #endregion

                #region -- Data --
                iPCalcM = "Tick";
				Bars_To_Process = -1;
                #endregion

                #region -- Trapped Trader / Delta Divergence Signals --
//                iTTEnabled = false;
//                iHighLowRangeFilter = true;
//                iArrowUpColor = Brushes.Lime;
//                iArrowUpOColor = Brushes.Black;
//                iArrowDnColor = Brushes.Red;
//                iArrowDnOColor = Brushes.Black;
//                iArrowShade = 100;
//                iSeparationVDS = 30;
//                iSeparation = 30;
//                iArrowWidth = 7;
//                iMinimumDecliningLevels = 3;
//                iLabelsEnabled = true;
//                iFontText2 = new SimpleFont("Arial", 12) { Bold = true };
//                iSignalNameP1 = @"TL";
//                iSignalNameN1 = @"TS";
//                iCCEnabled = false;
//                iDDEnabled = false;
//                iLookBack = 3;
//                iSignalsNameP1 = @"DL";
//                iSignalsNameN1 = @"DS";
//                iSignalsNameP1C = @"TDL";
//                iSignalsNameN1C = @"TDS";
                #endregion

				#region -- Delta Spread Analysis visuals --
				pShow_DSASignal        = true;
				pDSA_Sensitivity       = 8;
				pDSA_OpacityOnHeatMap  = 100;
				pDSA_OpacityOnPriceBar = 100;
				pSell_DSABrush         = Brushes.Red;
				pBuy_DSABrush          = Brushes.Lime;
				pDSA_HistoOutlineThickness = 4f;
				#endregion

				pAlgorithm = ARC_DeltaForce_Algorithm.NetDelta;
				pShowDeltaForceSignals = true;
				pShowLongs = true;
				pShowShorts = true;
				pShowRacingStripes = true;
				pSeparationTicks = 1;
				pPermitContinuingTrade = false;
				pMaxTrades = 2;
				pArrowSeparation = 4;
				pFilterOnHisto = false;
				pNormalizationPeriod = 20;

				#region TradingPlan defaults
				pBuyStripeBrush = Brushes.Green;
				pBuyStripeOpacity = 30;
				pSellStripeBrush = Brushes.Maroon;
				pSellStripeOpacity = 30;
				//EntryZoneSize_inATRs = 0.5;
				//EntryBasis = ARC_DeltaForce_TradeEntryBasis.AtATR;
				//PlanLevelsBasis = ARC_DeltaForce_Plan_LevelsBasis.AtEntryPrice;
				pATRperiod  = 13;
				pSLsize_inATRs  = 1.25;
				pSLsize_inTicks  = 10;
				pT1size_inATRs = 1.0;
				pT2size_inATRs = 1.5;
				pT1size_inTicks = 12;
				pT2size_inTicks = 18;
				EntryBrush    = Brushes.White;
				ShortSLBrush  = Brushes.Green;
				ShortT1Brush = Brushes.LightGreen;
				ShortT2Brush = Brushes.DarkGreen;
				LongSLBrush    = Brushes.Red;
				LongT1Brush   = Brushes.Orange;
				LongT2Brush   = Brushes.DarkOrange;
				EntryDashStyle = DashStyleHelper.Dash;
				SLDashStyle  = DashStyleHelper.Solid;
				T1DashStyle = DashStyleHelper.Solid;
				T2DashStyle = DashStyleHelper.Solid;
				EntryLineWidth = 2;
				SLLineWidth  = 2;
				T1LineWidth = 2;
				T2LineWidth = 2;
				pShowLongTradePlans  = true;
				pShowShortTradePlans = true;
				pShowEntry = true;
				pShowT2 = true;
				pShowT1 = true;
				pShowSL = true;
				pTradePlan_LineLength = 5;
				FontEL  = new SimpleFont("Arial", 10);
				FontSL  = new SimpleFont("Arial", 10);
				FontT1 = new SimpleFont("Arial", 10);
				FontT2 = new SimpleFont("Arial", 10);
				pTPLabelSide = ARC_DeltaForce_TPLabelSide.Right;
				ShortEntryLabel = "E";
				LongEntryLabel  = "E";
				ShortSLLabel    = "SL";
				LongSLLabel     = "SL";
				ShortT1Label   = "T1";
				LongT1Label    = "T1";
				ShortT2Label   = "T2";
				LongT2Label    = "T2";
				//IncludeTerminatedLevels  = false;
				//TerminatedLevelColor     = Brushes.Yellow;
				//TerminatedLevelLineWidth = 1;
				//TerminatedLevelDashStyle = DashStyleHelper.Solid;
				pVisualShiftDistance = 2;
				//DominantTradePlan = ARC_DeltaForce_DominantTradePlan.None;
				#endregion

                #endregion

            }
            #endregion

			#region State == State.Configure
			else if (State == State.Configure)
			{
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
#if DoLicense
				//Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				//RemoveDrawObject("lictext");
#endif
				//Print("IsForex: "+IsForex.ToString()+"    "+Instrument.MasterInstrument.InstrumentType.ToString());

//				bool IsMichaelBlack = (MachineId.CompareTo("53245F11FC9E8FEF74BB1CE2FAB84BF9")==0 ||
//					MachineId.CompareTo("90F01C0E88A1EC18E89A40A32C576F0B")==0 ||
//					MachineId.CompareTo("F7164C9EB78CC2CA9EFF04EBA1272777")==0) &&
//					UserId.CompareTo("MichaelBlack")==0;
//Print("Is this Michael Black?:   "+IsMichaelBlack.ToString());

				Color myRgbColor = new Color();
				var c = ((System.Windows.Media.SolidColorBrush)pHeatMap_PositiveColor).Color;
				byte R = c.R;
				byte G = c.G;
				byte B = c.B;

				bool midpointreached = false;
				double half = NetDHeatMap_Brushes.Length/2.0;
				int Rstep = Convert.ToInt32((255-R)/half-1);
				int Gstep = Convert.ToInt32((255-G)/half-1);
				int Bstep = Convert.ToInt32((255-B)/half-1);
				for(int brptr = 0; brptr<NetDHeatMap_Brushes.Length; brptr++){
					if(brptr < half){
						myRgbColor = Color.FromRgb(R, G, B);
						R = ToByte(R+Rstep);
						G = ToByte(G+Gstep);
						B = ToByte(B+Bstep);
					}else{
						if(!midpointreached) {
							midpointreached = true;
							R = 255;
							G = 255;
							B = 255;
							c = ((System.Windows.Media.SolidColorBrush)pHeatMap_NegativeColor).Color;
							Rstep = Convert.ToInt32((255-c.R)/half-1);
							Gstep = Convert.ToInt32((255-c.G)/half-1);
							Bstep = Convert.ToInt32((255-c.B)/half-1);
						}
						if(brptr == NetDHeatMap_Brushes.Length-1)
							myRgbColor = c;
						else{
							myRgbColor = Color.FromRgb(R, G, B);
							R = ToByte(R-Rstep);
							G = ToByte(G-Gstep);
							B = ToByte(B-Bstep);
						}
					}
					var scb = new SolidColorBrush(myRgbColor);
					NetDHeatMap_Brushes[brptr] = new SolidColorBrush(myRgbColor);
				}

                if (iPCalcM == "Tick") AddDataSeries(BarsPeriodType.Tick, 1);
                else AddDataSeries(BarsPeriodType.Minute, 1);

				Calculate = Calculate.OnEachTick;//force to on each tick
				IsAutoScale = false;//force setting

				MM = new MouseManager();
			}
            #endregion

            #region State == State.DataLoaded
            else if (State == State.DataLoaded)
            {
				BarsAreMinute = BarsArray[0].BarsPeriod.BarsPeriodType == BarsPeriodType.Minute;
				NetD_MaxMgr = new SmartMax(pHeatMapColorPeriod);
				NetD_MinMgr = new SmartMax(pHeatMapColorPeriod);
				gbTickSize = TickSize;//#BUG001 : bug fix
				IsForex = Instrument.MasterInstrument.InstrumentType == NinjaTrader.Cbi.InstrumentType.Forex;
				if(IsForex && pRoundForexToWholePip)
					gbTickSize = TickSize / 10;

				#region -- Init Exposed Series --
				NETDELTA = new Series<double>(this, MaximumBarsLookBack.Infinite);
				DFSignalHistory = new Series<int>(this, MaximumBarsLookBack.Infinite);
				#endregion

                #region -- Variables Series --
                CumNetD  = new Series<double>(this, MaximumBarsLookBack.Infinite);
				ryVolAdjuster = new Series<double>(this, MaximumBarsLookBack.Infinite);
				Histogram     = new Series<double>(this, MaximumBarsLookBack.Infinite);
				Upper         = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				BBDotLine	  = new Series<double>(this, MaximumBarsLookBack.Infinite);
				Lower         = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				atr           = new Series<double>(this, MaximumBarsLookBack.Infinite);
				MACD_Trend    = new Series<int>(this, MaximumBarsLookBack.Infinite);
				DSA_Signal    = new Series<int>(this, MaximumBarsLookBack.Infinite);
                BodyHigh      = new Series<double>(this, MaximumBarsLookBack.Infinite);
                BodyLow       = new Series<double>(this, MaximumBarsLookBack.Infinite);
                Direction     = new Series<double>(this, MaximumBarsLookBack.Infinite);
                #endregion

				AudibleAlertMgr = new AudibleAlerts(new string[]{"DFbuy"}, new string[]{pBuyWAV}, new string[]{"DFsell"}, new string[]{pSellWAV});
				BMACD = MACD(Input, Fast, Slow, BandPeriod);
				SDBB = StdDev(BMACD, BandPeriod);
				MACD1 = MACD(8, 20, 20);
				MACD2 = MACD(10, 20, 20);
				MACD3 = MACD(20, 60, 20);
				MACD4 = MACD(60, 240, 20);
				CNCD = MACD(CumNetD, Fast, Slow, BandPeriod);
//				SDCND = StdDev(CumNetD, BandPeriod);
				CND_SDBB = StdDev(CNCD, BandPeriod);

			}
            #endregion

            #region State == State.Historical
            else if (State == State.Historical)
            {
//				BuyStripeBrush = pBuyStripeBrush.Clone();
//				BuyStripeBrush.Opacity = this.pBuyStripeOpacity/100.0f;
//				BuyStripeBrush.Freeze();
//				SellStripeBrush = pSellStripeBrush.Clone();
//				SellStripeBrush.Opacity = this.pSellStripeOpacity/100.0f;
//				SellStripeBrush.Freeze();

                uID = KeepOnlyTheseCharacters(Instrument.FullName+DateTime.Now.Ticks.ToString(), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");//prevent multiple toolbar with same name
				SetZOrder(1001);
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        ChartControl.AllowDrop = false;
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;

                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

                            addToolBar();

                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

//                            ChartPanel.MouseMove += ChartPanel_MouseMove;
//                            ChartPanel.MouseDown += ChartPanel_MouseDown;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion
            }
            #endregion

            #region State == State.Realtime
            else if (State == State.Realtime)
            {
            }
			#endregion

            #region State == State.Transition
            else if (State == State.Transition)
            {
                //bench.Stop();
                //Print(String.Format("Loading Time : {0}ms on {1} bars => {2:n}ms/bar", bench.ElapsedMilliseconds, CurrentBars[0], bench.ElapsedMilliseconds / (double)CurrentBars[0]));
            }
            #endregion

            #region State == State.Terminated
            else if (State == State.Terminated)
            {
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
//                if (this.ChartControl != null)
//                {
//                    ChartPanel.MouseMove -= ChartPanel_MouseMove;
//                    ChartPanel.MouseDown -= ChartPanel_MouseDown;
//                }
            }
            #endregion
        #endregion
        }
//=================================================================================================
		private int CalculateHeatMapColorPtr(int abar0, int abar1, bool IsFromOnRender){
			#region -- CalculateHeatMapColorPtr --
			int midbrushIdx   = NetDHeatMap_Brushes.Length/2;
		    int hm_color_ptr = 0;
			for(int hmabar = Math.Max(0,abar0); hmabar<= abar1; hmabar++){
//				try
//              {
//line=1627;
//var tt = Times[0].GetValueAt(hmabar);
//var z = tt.Day==7 && tt.Hour==15 && tt.Minute==59 && tt.Second==59;
//if(z && abar0==abar1)Print("Inside OnBarUpdate");// else Print("Inside OnRender");
line=1631;
				    if(!HeatMapBarToColor.ContainsKey(hmabar))
                    {
line=1634;
					    long lowest_bid  = -NetD_MinMgr.GetAverage(hmabar-1);
					    long highest_ask =  NetD_MaxMgr.GetAverage(hmabar-1);
					    long L_spread = Math.Abs(highest_ask - lowest_bid);
					    long L_step   = (long)Math.Abs(Math.Ceiling((double)L_spread / NetDHeatMap_DXBrushes.Length));
line=1639;
					    double current_netd = NETDELTA.GetValueAt(hmabar);
						hm_color_ptr = 0;//0 is the full-green or Highest value
//if(z)Print("DF current_netd: "+current_netd+"  NETDELTA.valid: "+NETDELTA.IsValidDataPointAt(hmabar).ToString());
					    if(current_netd > 0){
						    while(hm_color_ptr < midbrushIdx){//L_step*2 to make sure we step past the lowest bid, for a bright-red bar if applicable
							    if(current_netd >= highest_ask) break;
							    hm_color_ptr++;
							    highest_ask = highest_ask - L_step;
						    }
//if(IsDebug && hmabar==ChartBars.ToIndex) Print(Times[0].GetValueAt(hmabar).ToString()+"  ptr: "+hm_color_ptr+"   "+current_netd+"   avg asks: "+highest_ask);
					    }else{
						    hm_color_ptr = NetDHeatMap_Brushes.Length-1;
						    while(hm_color_ptr > midbrushIdx){//L_step*2 to make sure we step past the lowest bid, for a bright-red bar if applicable
							    if(current_netd <= lowest_bid) break;
							    hm_color_ptr--;
							    lowest_bid = lowest_bid + L_step;
						    }
//if(IsDebug && hmabar==ChartBars.ToIndex) Print(Times[0].GetValueAt(hmabar).ToString()+"  ptr: "+hm_color_ptr+"   "+current_netd+"   avg bids: "+lowest_bid);
					    }
					    hm_color_ptr = Math.Max(0,Math.Min(NetDHeatMap_Brushes.Length-1, hm_color_ptr));
					    HeatMapBarToColor[hmabar] = Math.Max(0, Math.Min(hm_color_ptr, NetDHeatMap_Brushes.Length-1));//set the Index to the current color shade ptr
				    }
//				}
//                catch(Exception ex)
//                {
//                    Print(ex.Message);
//                }
line=1667;
				if(IsFromOnRender) return hm_color_ptr;
//Pit(string.Format("\n-------------------\ncb {0}:  {1}-bars ago",CurrentBars[0], (CurrentBars[0]-hmabar)));
//Pit(string.Format("ryAduster: {0}  hm_color_ptr {1}", ryVolAdjuster.GetValueAt(hmabar), hm_color_ptr));
				if(ryVolAdjuster.GetValueAt(hmabar)>1){//the volume on this bar is greater than the average volume
					int mid = NetDHeatMap_Brushes.Length/2;
					bool c1 = hm_color_ptr < (mid+1)-pDSA_Sensitivity;
					bool c2 = Closes[0].GetValueAt(hmabar) > Opens[0].GetValueAt(hmabar);
					if(c1 && c2){
						DSA_Signal[CurrentBars[0]-hmabar] = BUY;
					}
					c1 = hm_color_ptr > (mid-1)+pDSA_Sensitivity;
					c2 = Closes[0].GetValueAt(hmabar) < Opens[0].GetValueAt(hmabar);
					if(c1 && c2){
						DSA_Signal[CurrentBars[0]-hmabar] = SELL;
					}
				}
			}
			if(!HeatMapBarToColor.ContainsKey(abar1)) return midbrushIdx;
			return(HeatMapBarToColor[abar1]);
			#endregion
		}
//=================================================================================================
        protected override void OnBarUpdate()
        {
	        #region --------- OnBarUpdate() ------------
line=1692;
try{
            if (Instruments[0] == null || Instruments[1] == null || Instruments[0].FullName != Instruments[1].FullName) return;
			#region Stopwatch
#if STOPWATCH_OUTPUT
			if(!BenStopwatch.ContainsKey("FirstBarToCurrentBar")){
				if(RunningFirstBar){
					dt = DateTime.Now;
					RunningFirstBar=false;
				}
				if(CurrentBar>Bars.Count-4){
					BenStopwatch["FirstBarToCurrentBar"] = new TimeSpan(DateTime.Now.Ticks-dt.Ticks);
					Print("-------------------------------------------------");
					Print("Bar count: "+Bars.Count);
					Print(Bars.BarsPeriod.ToString());
					Print("Stopwatch results (seconds):");
					foreach(string strkey in BenStopwatch.Keys){
						Print(strkey+":   "+BenStopwatch[strkey].TotalSeconds.ToString("0.000"));
					}
					Print("");
					Print("done");
					Print("-------------------------------------------------");
				}
			}
#endif
			#endregion
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
line=1735;
			if(Bars_To_Process > 0){
				if(CurrentBars[0] < BarsArray[0].Count-Bars_To_Process) return;
				if(CurrentBars[1] < BarsArray[1].Count-Bars_To_Process) return;
			}
line=1740;
			#region Init
			try{
				Opens00  = RoundToWholePip(Opens[0][0]);
				Highs00  = RoundToWholePip(Highs[0][0]);
				Lows00   = RoundToWholePip(Lows[0][0]);
				Closes00 = RoundToWholePip(Closes[0][0]);
line=1747;
				if(CurrentBars[0]>0){
					Highs01  = RoundToWholePip(Highs[0][1]);
					Lows01   = RoundToWholePip(Lows[0][1]);
				}else{
					Highs01 = Highs00;
					Lows01  = Lows00;
				}
				Highs10  = RoundToWholePip(Highs[1][0]);
				Lows10   = RoundToWholePip(Lows[1][0]);
				Closes10 = RoundToWholePip(Closes[1][0]);
			}catch{
				Opens00  = Open[0];
				Highs00  = Open[0];
				Lows00   = Open[0];
				Closes00 = Open[0];
				Highs01  = Open[0];
				Lows01   = Open[0];
				Highs10  = Open[0];
				Lows10   = Open[0];
				Closes10 = Open[0];
			}

line=1770;
			//-- Memorize main series volume only in realtime --
            IsCurrentBar = CurrentBars[0] + 1 == BarsArray[0].Count;
            CBB = IsCurrentBar ? 1 : 0;
            if (iPCalcM == "Tick" && IsCurrentBar)
            {
                if (Volumes[0][0] == PreviousVolume) return;
                if (BarsInProgress == 1) PreviousVolume = Volumes[0][0];
            }
			#endregion

line=1781;
            if (BarsInProgress == 0 && CurrentBars[0] > 0)
            {
				atr[0] = ATR(this.pATRperiod)[0];

				if(pHeatMapHeightPeriod>1 && CurrentBars[0]>pHeatMapHeightPeriod){
					double sum = 0;
					for(int i=0; i<pHeatMapHeightPeriod && i<CurrentBars[0]; i++) sum = sum+Volumes[0][i];
					VolumeAverage[CurrentBars[0]] = Convert.ToSingle(sum/pHeatMapHeightPeriod / (IsForex ? pFOREXD : 1));
					double vol0 = IsForex ? Volumes[0][0] / pFOREXD: Volumes[0][0];
					double vavg = Volumes[0][1];
					if(IsForex){
						if(this.pHeatMapHeightPeriod>1) vavg = vavg / pFOREXD;
						else vavg = vavg / pFOREXD;
					}else{
						if(this.pHeatMapHeightPeriod>1 && VolumeAverage.ContainsKey(CurrentBars[0]-1)) vavg = VolumeAverage[CurrentBars[0]-1];
					}
					ryVolAdjuster[0] = vol0/vavg;
					//if(vol0 > vavg) DSA_Signal[0] = 1; else DSA_Signal[0] = 0;
				}
                BodyHigh[0]  = RTTS(Math.Max(Closes00, Opens00));
                BodyLow[0]   = RTTS(Math.Min(Closes00, Opens00));
                Direction[0] = Closes[0][0] > Opens[0][0] ? 1 : Closes[0][0] < Opens[0][0] ? -1 : Direction[1];
            }

            if (iPCalcM == "Tick")
            {
                #region -- update bar levels --
                if (BarsInProgress == 0)
                {
                    ReadyToClose = true;
                    if (IsFirstTickOfBar && BarDataCollection.ContainsKey(CurrentBars[0] - 1))
                    {
						int abar = CurrentBars[0]-1;
                        double StartPrice = Highs01;
                        do
                        {
                            if (!BarDataCollection[abar].ContainsKey(StartPrice))
                            {
                                BarDataCollection[abar][StartPrice] = new PrintLevelDetails();
                                BarDataCollection[abar][StartPrice].AskSize = 0;
                                BarDataCollection[abar][StartPrice].BidSize = 0;
                            }
                            StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                        }
                        while (StartPrice >= Lows01);
                    }
                }
                #endregion
				#region -- Tick --
line=1831;
                if (!BarsAreMinute && BarsInProgress == 1 && ReadyToClose)
                {
                    bool PriceDone = Closes[1][0] < Lows[0][CBB] || Closes[1][0] > Highs[0][CBB];
                    bool TimeDone = Times[1][0] > Times[0][CBB];

line=1837;
                    if (TimeDone || PriceDone)
                    {
                        ReadyToClose = false;
                        if (State == State.Historical)
                        {
line=1843;
                            ThisCurrentBar = CurrentBars[0];
                            var AI = ProcessFootSignals(thisBarData);
                            if (CurrentBars[0] > 1) BarDataCollection[ThisCurrentBar] = new SortedDictionary<double, PrintLevelDetails>(AI);

                            //-- add new level --
                            if (BarDataCollection.ContainsKey(ThisCurrentBar))
                            {
line=1851;
                                double StartPrice = Highs00;
                                do
                                {
                                    if (!BarDataCollection[ThisCurrentBar].ContainsKey(StartPrice))
                                    {
line=1857;
                                        BarDataCollection[ThisCurrentBar].Add(StartPrice, new PrintLevelDetails());
                                        BarDataCollection[ThisCurrentBar][StartPrice].AskSize = 0;
                                        BarDataCollection[ThisCurrentBar][StartPrice].BidSize = 0;
                                    }
                                    StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                                }
                                while (StartPrice >= Lows00);
line=1865;
                            }
                            if (!Initialized && !IsCurrentBar) thisBarData.Clear();
                        }
                    }
                }


line=1873;
                if (BarsInProgress == 0 && CurrentBars[0] > 0)
                {
                    if (BarsAreMinute)
                    {
                        if (State == State.Historical)
                        {
line=1880;
                            var AI = ProcessFootSignals(thisBarData);
                            if (CurrentBars[0] > 1) BarDataCollection[CurrentBars[0]] = new SortedDictionary<double, PrintLevelDetails>(AI);
                            if (!Initialized && !IsCurrentBar) thisBarData.Clear();
                        }

                        if (IsFirstTickOfBar && IsCurrentBar)
                        {
                            if (Initialized) thisBarData.Clear();
                            Initialized = true;
                        }

line=1892;
                        if (BarDataCollection.ContainsKey(CurrentBars[0]))
                        {
                            double StartPrice = Highs00;
                            do
                            {
                                if (!BarDataCollection[CurrentBars[0]].ContainsKey(StartPrice))
                                {
                                    BarDataCollection[CurrentBars[0]].Add(StartPrice, new PrintLevelDetails());
                                    BarDataCollection[CurrentBars[0]][StartPrice].AskSize = 0;
                                    BarDataCollection[CurrentBars[0]][StartPrice].BidSize = 0;
                                }
                                StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                            }
                            while (StartPrice >= Lows00);
                        }
                    }
                    else
                    {
line=1911;
                        if (State == State.Historical && CurrentBars[0] > 1 && !BarDataCollection.ContainsKey(CurrentBars[0]))
                        {
                            BarDataCollection[CurrentBars[0]] = new SortedDictionary<double, PrintLevelDetails>();
                            double StartPrice = Highs00;
                            do
                            {

                                BarDataCollection[CurrentBars[0]].Add(StartPrice, new PrintLevelDetails());
                                BarDataCollection[CurrentBars[0]][StartPrice].AskSize = 0;
                                BarDataCollection[CurrentBars[0]][StartPrice].BidSize = 0;
                                StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                            }
                            while (StartPrice >= Lows00);
                        }

                        if (IsFirstTickOfBar && IsCurrentBar)
                        {
                            ThisCurrentBar = CurrentBars[0];
                            if (Initialized) thisBarData.Clear();
                            Initialized = true;
                        }
                    }
                }

line=1954;
                if (BarsInProgress == 1)
                {
                    if (CurrentBars[1] < 1) return;
                    TickDirection = Closes[1][0] > Closes[1][1] ? 1 : Closes[1][0] < Closes[1][1] ? -1 : TickDirection;
                    long LastVolume = (long)Volumes[1][0];
					if (IsForex && LastVolume >= pFOREXD) LastVolume = LastVolume / pFOREXD;// FOREX divide by 100000
                    TickLevels.Clear();
                    if (iPCalcM == "Tick") TickLevels.Add(Closes10);
//bool zone = Times[1][0].Day==21 && Times[1][0].Hour==10 && Times[1][0].Minute==46;
					#region -- Process Print --
                    #region -- update ask --
                    if (TickDirection == 1)
                    {
						//Print(TickLevels.Count);
                        foreach (double lastPrice in TickLevels)
                        {
                            double LastPrice = RoundToWholePip(lastPrice);//##Modif by Kriss AzurITec## - BUGPP002 FIXED 07.04.2016
                            if (thisBarData.ContainsKey(LastPrice))
                            {
                                thisBarData[LastPrice].AskSize = thisBarData[LastPrice].AskSize + LastVolume;
                            }
                            else
                            {
                                thisBarData.Add(LastPrice, new PrintLevelDetails());
                                thisBarData[LastPrice].AskSize = LastVolume;
                            }
//							if(IsForex){
//	                            if (LastVolume/pFOREXD >= iBlockSize) thisBarData[LastPrice].AskBlocks.Add(LastVolume/pFOREXD);
//							}else 
//								if (LastVolume >= iBlockSize) thisBarData[LastPrice].AskBlocks.Add(LastVolume);
                        }
                    }
                    #endregion
                    #region -- update bid --
                    else if (TickDirection == -1)
                    {
line=1991;
                        foreach (double lastPrice in TickLevels)
                        {
                            double LastPrice = RoundToWholePip(lastPrice);//##Modif by Kriss AzurITec## - BUGPP002 FIXED 07.04.2016
                            if (thisBarData.ContainsKey(LastPrice))
                            {
                                thisBarData[LastPrice].BidSize = thisBarData[LastPrice].BidSize + LastVolume;
                            }
                            else
                            {
                                thisBarData.Add(LastPrice, new PrintLevelDetails());
                                thisBarData[LastPrice].BidSize = LastVolume;
                            }
//							if(IsForex){
//	                            if (LastVolume/pFOREXD >= iBlockSize) thisBarData[LastPrice].BidBlocks.Add(LastVolume/pFOREXD);
//							}else 
//								if (LastVolume >= iBlockSize) thisBarData[LastPrice].BidBlocks.Add(LastVolume);
                        }
                    }
                    #endregion
//					if (IsForex){
//						foreach(var kvp in thisBarData){
//							//thisBarData[kvp.Key].AskSize = thisBarData[kvp.Key].AskSize / pFOREXD;
//							thisBarData[kvp.Key].BidSize = thisBarData[kvp.Key].BidSize / pFOREXD;
//						}
//					}

line=2018;
                    if (IsCurrentBar)
                    {
                        double StartPrice = RoundToWholePip(Highs[0][CurrentBars[0] - ThisCurrentBar]);//##Modif by Kriss AzurITec## - BUGPP002 FIXED 02.04.2016
                        do
                        {
                            if (!thisBarData.ContainsKey(StartPrice))
                            {
                                thisBarData.Add(StartPrice, new PrintLevelDetails());
                                thisBarData[StartPrice].AskSize = 0;
                                thisBarData[StartPrice].BidSize = 0;
                            }
                            StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                        }
                        while (StartPrice >= RoundToWholePip(Lows[0][CurrentBars[0] - ThisCurrentBar]));

line=2034;
                        var AI = ProcessFootSignals(thisBarData);
                        if (BarsAreMinute) 
							BarDataCollection[CurrentBars[0]] = new SortedDictionary<double, PrintLevelDetails>(AI);
                        else 
							BarDataCollection[ThisCurrentBar] = new SortedDictionary<double, PrintLevelDetails>(AI);

                        StartPrice = Highs00;
                        if (BarDataCollection.ContainsKey(CurrentBars[0]))
                        {
line=2044;
                            do
                            {
                                if (!BarDataCollection[CurrentBars[0]].ContainsKey(StartPrice))
                                {
                                    BarDataCollection[CurrentBars[0]].Add(StartPrice, new PrintLevelDetails());
                                    BarDataCollection[CurrentBars[0]][StartPrice].AskSize = 0;
                                    BarDataCollection[CurrentBars[0]][StartPrice].BidSize = 0;
                                }
                                StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                            }
                            while (StartPrice >= Lows00);
                        }
                    }
                    #endregion
                }
				#endregion
            }
            else
			{
				#region -- non-tick based subdata --
line=2065;
                if (BarsInProgress == 0 && CurrentBars[0] > 0)
                {
                    if (IsFirstTickOfBar) BarDataCollection[CurrentBars[0]] = new SortedDictionary<double, PrintLevelDetails>(thisBarData);
                    thisBarData.Clear();
                }

                if (BarsInProgress == 1)
                {
line=2074;
                    if (CurrentBars[1] < 1) return;
                    TickDirection = Closes[1][0] > Closes[1][1] ? 1 : Closes[1][0] < Closes[1][1] ? -1 : TickDirection;

                    long LastVolume = (long)Volumes[1][0];
                    TickLevels.Clear();

                    if (IsCurrentBar)
                    {
                        TickLevels.Add(Closes10);
                        LastVolume = (long)Volumes[1][0] - PLastVolume;
                        if (LastVolume <= 0) LastVolume = (long)Volumes[1][0];
                        PLastVolume = (long)Volumes[1][0];
                    }
                    else
                    {
line=2090;
                        double StartPrice2 = Highs10;
                        do
                        {
                            TickLevels.Add(StartPrice2);
                            StartPrice2 = (StartPrice2 - gbTickSize);
                        }
                        while (StartPrice2 >= Lows10);
                        LastVolume = (int)(Volumes[1][0] / TickLevels.Count);
                    }

                    if (IsForex && LastVolume >= pFOREXD) LastVolume = LastVolume / pFOREXD;// FOREX divide by 100000

                    foreach (double LastPrice in TickLevels)
                    {
line=2105;
//                        if (compositeData.ContainsKey(LastPrice))
//                        {
//                            compositeData[LastPrice].AskSize = compositeData[LastPrice].AskSize + LastVolume;
//                        }
//                        else
//                        {
//                            compositeData.Add(LastPrice, new VolumeAtBA());
//                            compositeData[LastPrice].AskSize = LastVolume;
//                        }

                        if (thisBarData.ContainsKey(LastPrice))
                        {
                            thisBarData[LastPrice].AskSize = thisBarData[LastPrice].AskSize + LastVolume;
                        }
                        else
                        {
                            thisBarData.Add(LastPrice, new PrintLevelDetails());
                            thisBarData[LastPrice].AskSize = LastVolume;
                        }
                    }

                }
				#endregion
            }
			if(BarsInProgress==0 && CurrentBars[0]>3){
				if(this.IsFirstTickOfBar) DFSignalHistory[0] = FLAT;

				if(pAlgorithm == ARC_DeltaForce_Algorithm.NetDelta){
					CumNetD[1] = CumNetD[2] + NETDELTA[1];
					CumNetD[0] = CumNetD[1];
					if(BarsArray[0].IsFirstBarOfSession && pNormalizationPeriod<=0) {
						CumNetD[0] = NETDELTA[0];
						Histogram.Reset(1);
					}
line=1507;
					if(pNormalizationPeriod <= 0) {
						Histogram[0] = CumNetD[0];
					} else {
line=1511;
						double sum=0;
						for(int i = 0; i<Math.Min(CurrentBars[0],pNormalizationPeriod); i++) sum += CumNetD[i];
						Histogram[0] = CumNetD[0] - sum/this.pNormalizationPeriod;//CNCDma[0];
					}
line=1516;
					BBDotLine[0]   = CNCD.Default[0];
					double average = CNCD.Avg[0];
					double stdDevValue = CND_SDBB[0];
line=1522;
					Upper[0] = average + StdDevNumber * stdDevValue;
					Lower[0] = average - StdDevNumber * stdDevValue;
//if(BarsInProgress==0 && IsFirstTickOfBar && CurrentBars[0]<30) Print(Times[0][1].ToString()+"  DF NETDELTA: "+NETDELTA[1].ToString("0")+"   CumNetD: "+CumNetD[1].ToString("0"));
				}else if(pAlgorithm == ARC_DeltaForce_Algorithm.Price){
					BBDotLine[0] = BMACD[0];
					double average = BMACD.Avg[0];
					Upper[0] = average + StdDevNumber * SDBB[0];
					Lower[0] = average - StdDevNumber * SDBB[0];
		            Histogram[0] = MACD1.Diff[0] + MACD2.Diff[0] + MACD3.Diff[0] + MACD4.Diff[0];
				}
			}


line=2151;
            #region -- Reset and Create new BarDataCollection --
			if(Bars.Count<5 && LowBarWarningCount<3) {
line=2154;
				Log(string.Format("{0} {1}: has only {2}-bars on the chart",Instrument.MasterInstrument.Name,Bars.BarsPeriod.ToString(), Bars.Count), NinjaTrader.Cbi.LogLevel.Information);
				LowBarWarningCount++;
			}
            if (Bars.Count>5 && IsCurrentBar && BarsInProgress == 0 && IsFirstTickOfBar && !BarDataCollection.ContainsKey(CurrentBars[0] - 1))
            {
line=2160;
				int abar = CurrentBars[0]-1;
                BarDataCollection[abar] = new SortedDictionary<double, PrintLevelDetails>();
                double StartPrice = Highs01;
                do
                {
line=2166;
                    BarDataCollection[abar].Add(StartPrice, new PrintLevelDetails());
                    BarDataCollection[abar][StartPrice].AskSize = 0;
                    BarDataCollection[abar][StartPrice].BidSize = 0;
                    StartPrice = RoundToWholePip(StartPrice - gbTickSize);
                }
                while (StartPrice >= Lows01);
            }
            #endregion
line=2175;
			#region --- Calculate DeltaForce signals ---  
			if(BarsInProgress==0 && CurrentBars[0]>0){
				if(CurrentBars[0]>2){
					if(IsFirstTickOfBar)		    MACD_Trend[0] = MACD_Trend[1];
					if(BBDotLine[0] > BBDotLine[1]) MACD_Trend[0] = BUY;
					if(BBDotLine[0] < BBDotLine[1]) MACD_Trend[0] = SELL;
				}else
					MACD_Trend[0] = FLAT;
				if(BBDotLine[1] < Upper[1] && BBDotLine[1] > Lower[1]) DidDotLineRetreatInsideBB = true;
//if(Time[0].Day==14 && Time[0].Hour==10 && DidDotLineRetreatInsideBB) Draw.Dot(this,CurrentBars[0].ToString(), false, 1, Low[1], Brushes.Yellow);
line=2202;
//Pit(CurrentBars[0], "");Pit(CurrentBars[0], Times[0][0].ToString());
				#region -- Set HeatMap Color --
				int hm_color_ptr = CalculateHeatMapColorPtr(CurrentBars[0]-1, CurrentBars[0]-1, false);
				#endregion ----------------------------------------------------------
				int offset = 1;
				if(CurrentBars[0] < offset) return;
				int LastTrade = GetLastTrade();
				int TradeCount = GetTradeCount(BUY, pMaxTrades);
//Pit(Times[0][0].ToString());
				bool LongsPermitted = pShowDeltaForceSignals && DidDotLineRetreatInsideBB;
//Pit("2108  Trend: "+MACD_Trend[offset].ToString()+"  BBDotLine[0]: "+BBDotLine[offset].ToString("0.000")+"  Upper: "+Upper.ToString("0.000")+"  Lower: "+Lower.ToString("0.000"));
				if(MACD_Trend[offset] == SELL)                       LongsPermitted = false;
//Pit("2111  "+LongsPermitted.ToString());
				if(pFilterOnHisto && Histogram[offset]<=0)           LongsPermitted = false;
//Pit("2113  "+LongsPermitted.ToString());
				if(pPermitContinuingTrade && TradeCount>=pMaxTrades && LastTrade == BUY) LongsPermitted = false;
//Pit("2115  "+LongsPermitted.ToString());
				if(LastTrade == BUY && !pPermitContinuingTrade)      LongsPermitted = false;
//Pit("2117  "+LongsPermitted.ToString());
//Pit("2119  "+(DSA_Signal[offset]==BUY ? "DSA Buy" : (DSA_Signal[offset]==SELL ? "DSA Sell":"")));

line=2230;
				if(LongsPermitted && BBDotLine[offset]>Upper[offset] && DSA_Signal[offset]==BUY) {
					DFSignalHistory[offset]   = BUY;
					if(ChartControl!=null && pSignalsAsDrawObjects)
						Draw.ArrowUp(this,string.Format("DFBuy {0}",(CurrentBars[0]-offset)),false,offset,Lows[0][offset]-pSeparationTicks*TickSize*pArrowSeparation,Plots[0].Brush);
					else 
						DF_Buy[offset]            = Lows[0][offset]-pSeparationTicks*TickSize*pArrowSeparation;
					DidDotLineRetreatInsideBB = false;
					if(State==State.Realtime) AudibleAlertMgr.Play(this, BUY, "DFbuy", CurrentBars[0]-offset);
//Pit(string.Format("{0}  BUY {1}-bars ago  Histo: {2}",Times[0][0].ToString(), offset, Histogram[offset]));
				}

//Pit(CurrentBars[0]-offset, Times[0][offset].ToString()+"   SHORT   BBDotLine[0]: "+BBDotLine[offset].ToString("0.000"));
				TradeCount = GetTradeCount(SELL, pMaxTrades);
				bool ShortsPermitted = pShowDeltaForceSignals && DidDotLineRetreatInsideBB;
				if(MACD_Trend[offset] == BUY)                        ShortsPermitted = false;
//Pit(CurrentBars[0]-offset, string.Format("{0}  MACD_Trend", MACD_Trend[offset]));
				if(pFilterOnHisto && Histogram[offset]>=0)           ShortsPermitted = false;
//Pit(CurrentBars[0]-offset, string.Format("{0}  Histo", Histogram[offset]));
				if(pPermitContinuingTrade && TradeCount>=pMaxTrades && LastTrade == SELL) ShortsPermitted = false;
//Pit(CurrentBars[0]-offset, string.Format("{0}  Last trade", LastTrade));
				if(LastTrade == SELL && !pPermitContinuingTrade)     ShortsPermitted = false;
				if(ShortsPermitted && BBDotLine[offset]<Lower[offset] && DSA_Signal[offset]==SELL) {
	//Print(Times[0][0].ToString()+"  Histo: "+Histogram[1].ToString());
					DFSignalHistory[offset]   = SELL;
					if(ChartControl!=null && pSignalsAsDrawObjects)
						Draw.ArrowDown(this,string.Format("DFSell {0}",(CurrentBars[0]-offset)),false,offset,Highs[0][offset]+pSeparationTicks*TickSize*pArrowSeparation,Plots[1].Brush);
					else 
						DF_Sell[offset]           = Highs[0][offset]+pSeparationTicks*TickSize*pArrowSeparation;
					DidDotLineRetreatInsideBB = false;
					if(State==State.Realtime) AudibleAlertMgr.Play(this, SELL, "DFsell", CurrentBars[0]-offset);
//Pit(CurrentBars[0]-offset, string.Format("{0}  SELL {1}-bars ago",Times[0][0].ToString(), offset));
				}
			}
			#endregion
line=2256;
}catch(Exception obuerr){
	ErrorCount++;
	if(ErrorCount<5){
		Print(string.Format("  {0}: OnBarUpdate {1}",line,obuerr.ToString()));
		//Log(string.Format("  {0}: OnBarUpdate {1}",line,obuerr.ToString()), NinjaTrader.Cbi.LogLevel.Information);
	}
}
	        #endregion
        }
//=================================================================================================
		private void Pit(int abar, string x){
			if(Times[0].GetValueAt(abar).Hour==8 && Times[0].GetValueAt(abar).Day==16 && Times[0].GetValueAt(abar).Minute==30) Print(x);
		}
		private void Pit(string x){
			Print(x);
		}
//=================================================================================================
		private int GetLastTrade(){
			var macdBBsignal = FLAT;
			for(int rbar = 0; rbar<CurrentBars[0]; rbar++){
				if(macdBBsignal == FLAT){//initialize macdBBsignal to the most recent state of the trend, BMACD>Upper means it's a BUY trend, BMACD<Lower means it's a SELL trend
					if(BBDotLine[rbar] > Upper[rbar]) macdBBsignal = BUY;
					if(BBDotLine[rbar] < Lower[rbar]) macdBBsignal = SELL;
				}
				if(macdBBsignal == BUY && BBDotLine[rbar] < Lower[rbar]) return FLAT;//if the macd line crossed downward, from above the upper to below the lower, then the LastTrade is considered reset (FLAT)
				if(macdBBsignal == SELL && BBDotLine[rbar] > Upper[rbar]) return FLAT;//if the macd line crossed upward, from below the lower to above the upper, then the LastTrade is considered reset (FLAT)
				if(DFSignalHistory[rbar] != FLAT) return DFSignalHistory[rbar];
			}
			return FLAT;
		}
		private int GetTradeCount(int Direction, int MaxTrades){
			int abar = CurrentBars[0];
			int TradeCount = 0;
			while(abar>0 && TradeCount < MaxTrades){
				if(abar>DFSignalHistory.Count) break;
				if(Direction==BUY){
					if(DFSignalHistory.GetValueAt(abar) == BUY) TradeCount++;
					if(DFSignalHistory.GetValueAt(abar) == SELL) break;
				}else{
					if(DFSignalHistory.GetValueAt(abar) == SELL) TradeCount++;
					if(DFSignalHistory.GetValueAt(abar) == BUY) break;
				}
				abar--;
			}
			return TradeCount;
		}
//=================================================================================================
        #region --------- OnMarketDepth() ------------
        protected override void OnMarketDepth(MarketDepthEventArgs e)
        {
line=2300;
//Print("OMD");
            if (ChartControl == null) return;
			if(Bars_To_Process>0){
				if(CurrentBars[0] < BarsArray[0].Count-Bars_To_Process) return;
				if(CurrentBars[1] < BarsArray[1].Count-Bars_To_Process) return;
			}
//Print("iInventoryEnabled: "+iInventoryEnabled.ToString()+"  !FirstOnMarketDepthRun:" + (!FirstOnMarketDepthRun).ToString());
            if (!FirstOnMarketDepthRun)
            {
                askRows.Clear();
                bidRows.Clear();
                MarketDepthRow mdra;

                int imin = 0, imax = Math.Min(10, e.Instrument.MarketDepth.Asks.Count);
line=2315;
                for (int i = imin; i < imax; i++)
                {
                    try
                    {
                        mdra = e.Instrument.MarketDepth.Asks[i];
                        askRows.Add(new LadderRow(mdra.Price, mdra.Volume, e.MarketMaker));
                    }
                    catch (Exception e1) {Print(line+": "+e1.ToString());}//#BUG002 : due to multithreading, Asks.count can change during the loop and be less than imax, causing exception
                }

                imax = Math.Min(10, e.Instrument.MarketDepth.Bids.Count);
line=2327;
                for (int i = imin; i < imax; i++)
                {
                    try
                    {
                        mdra = e.Instrument.MarketDepth.Bids[i];
                        bidRows.Add(new LadderRow(mdra.Price, mdra.Volume, e.MarketMaker));
                    }
                    catch (Exception e2) {Print(line+": "+e2.ToString());}//#BUG002 : due to multithreading, Bids.count can change during the loop and be less than imax, causing exception
                }
//Print("askRows: "+askRows.Count+"  bidRows: "+bidRows.Count);
                if (!FirstOnMarketDepthRun)
                {
                    FirstOnMarketDepthRun = true;
                    ForceRefresh();
                }
            }
line=2344;
        }
        #endregion
//=================================================================================================
		public override void OnRenderTargetChanged()
		{
			#region -- OnRenderTargetChanged --
line=2149; // Print(line);
			#region -- Brush disposal --
//			if(iArrowUpDXBrush  !=null && !iArrowUpDXBrush.IsDisposed){  iArrowUpDXBrush.Dispose();  iArrowUpDXBrush  = null;}
//			if(iArrowDnDXBrush  !=null && !iArrowDnDXBrush.IsDisposed){  iArrowDnDXBrush.Dispose();  iArrowDnDXBrush  = null;}
//			if(iArrowUpODXBrush !=null && !iArrowUpODXBrush.IsDisposed){ iArrowUpODXBrush.Dispose(); iArrowUpODXBrush = null;}
//			if(iArrowDnODXBrush !=null && !iArrowDnODXBrush.IsDisposed){ iArrowDnODXBrush.Dispose(); iArrowDnODXBrush = null;}
//			if(iSupplyZDXBrushFresh!=null && !iSupplyZDXBrushFresh.IsDisposed) {	iSupplyZDXBrushFresh.Dispose(); iSupplyZDXBrushFresh = null;}
//			if(iSupplyZDXBrushTested!=null && !iSupplyZDXBrushTested.IsDisposed) {	iSupplyZDXBrushTested.Dispose(); iSupplyZDXBrushTested = null;}
//			if(iSupplyZDXBrushBroken!=null && !iSupplyZDXBrushBroken.IsDisposed) {	iSupplyZDXBrushBroken.Dispose(); iSupplyZDXBrushBroken = null;}
//			if(iSupplyZOLDXBrushFresh!=null && !iSupplyZOLDXBrushFresh.IsDisposed) {	iSupplyZOLDXBrushFresh.Dispose(); iSupplyZOLDXBrushFresh = null;}
//			if(iSupplyZOLDXBrushTested!=null && !iSupplyZOLDXBrushTested.IsDisposed) {	iSupplyZOLDXBrushTested.Dispose(); iSupplyZOLDXBrushTested = null;}
//			if(iSupplyZOLDXBrushBroken!=null && !iSupplyZOLDXBrushBroken.IsDisposed) {	iSupplyZOLDXBrushBroken.Dispose(); iSupplyZOLDXBrushBroken = null;}
//			if(iDemandZDXBrushFresh!=null && !iDemandZDXBrushFresh.IsDisposed) {	iDemandZDXBrushFresh.Dispose(); iDemandZDXBrushFresh = null;}
//			if(iDemandZDXBrushTested!=null && !iDemandZDXBrushTested.IsDisposed) {	iDemandZDXBrushTested.Dispose(); iDemandZDXBrushTested = null;}
//			if(iDemandZDXBrushBroken!=null && !iDemandZDXBrushBroken.IsDisposed) {	iDemandZDXBrushBroken.Dispose(); iDemandZDXBrushBroken = null;}
//			if(iDemandZOLDXBrushFresh!=null && !iDemandZOLDXBrushFresh.IsDisposed) {	iDemandZOLDXBrushFresh.Dispose(); iDemandZOLDXBrushFresh = null;}
//			if(iDemandZOLDXBrushTested!=null && !iDemandZOLDXBrushTested.IsDisposed) {	iDemandZOLDXBrushTested.Dispose(); iDemandZOLDXBrushTested = null;}
//			if(iDemandZOLDXBrushBroken!=null && !iDemandZOLDXBrushBroken.IsDisposed) {	iDemandZOLDXBrushBroken.Dispose(); iDemandZOLDXBrushBroken = null;}
//			if(iBidHistDXBrush1!=null && !iBidHistDXBrush1.IsDisposed) {	iBidHistDXBrush1.Dispose(); iBidHistDXBrush1 = null;}
//			if(iBidHistDXBrush2!=null && !iBidHistDXBrush2.IsDisposed) {	iBidHistDXBrush2.Dispose(); iBidHistDXBrush2 = null;}
//			if(iAskHistDXBrush1!=null && !iAskHistDXBrush1.IsDisposed) {	iAskHistDXBrush1.Dispose(); iAskHistDXBrush1 = null;}
//			if(iAskHistDXBrush2!=null && !iAskHistDXBrush2.IsDisposed) {	iAskHistDXBrush2.Dispose(); iAskHistDXBrush2 = null;}
//			if(iAskOutDXBrush1!=null && !iAskOutDXBrush1.IsDisposed) {	iAskOutDXBrush1.Dispose(); iAskOutDXBrush1 = null;}
//			if(iBidOutDXBrush1!=null && !iBidOutDXBrush1.IsDisposed) {	iBidOutDXBrush1.Dispose(); iBidOutDXBrush1 = null;}
//			if(iTextDXBrush5!=null && !iTextDXBrush5.IsDisposed) {	iTextDXBrush5.Dispose(); iTextDXBrush5 = null;}
//			if(iTextDXBrush6!=null && !iTextDXBrush6.IsDisposed) {	iTextDXBrush6.Dispose(); iTextDXBrush6 = null;}
//			if(iTextDXBrush7!=null && !iTextDXBrush7.IsDisposed) {	iTextDXBrush7.Dispose(); iTextDXBrush7 = null;}
//			if(TextBrush!=null && !TextBrush.IsDisposed) {	TextBrush.Dispose(); TextBrush = null;}
//			if(iTM_DXBrush!=null && !iTM_DXBrush.IsDisposed) {	iTM_DXBrush.Dispose(); iTM_DXBrush = null;}
			for(int brptr = 0; brptr<NetDHeatMap_DXBrushes.Length; brptr++){
//line=2179;  Print(line);
				if(NetDHeatMap_DXBrushes[brptr] != null && !NetDHeatMap_DXBrushes[brptr].IsDisposed){
//line=2181;  Print(line);
					NetDHeatMap_DXBrushes[brptr].Dispose();
					NetDHeatMap_DXBrushes[brptr] = null;
				}
			}
//			if(iBlocksDXBrush!=null && !iBlocksDXBrush.IsDisposed) {	iBlocksDXBrush.Dispose(); iBlocksDXBrush = null;}
//			if(iBlocks2DXBrush!=null && !iBlocks2DXBrush.IsDisposed) {	iBlocks2DXBrush.Dispose(); iBlocks2DXBrush = null;}
//			if(CurrentBrush!=null && !CurrentBrush.IsDisposed) {	CurrentBrush.Dispose(); CurrentBrush = null;}
//			if(iIBBidDXBrush3!=null && !iIBBidDXBrush3.IsDisposed) {	iIBBidDXBrush3.Dispose(); iIBBidDXBrush3 = null;}
//			if(iIBBidDXBrush!=null && !iIBBidDXBrush.IsDisposed) {	iIBBidDXBrush.Dispose(); iIBBidDXBrush = null;}
//			if(iIBAskDXBrush3!=null && !iIBAskDXBrush3.IsDisposed) {	iIBAskDXBrush3.Dispose(); iIBAskDXBrush3 = null;}
//			if(iIBAskDXBrush!=null && !iIBAskDXBrush.IsDisposed) {	iIBAskDXBrush.Dispose(); iIBAskDXBrush = null;}
//			if(OverrideBrush!=null && !OverrideBrush.IsDisposed) {	OverrideBrush.Dispose(); OverrideBrush = null;}
//line=2194;  Print(line);
			if(iDPDXBrush!=null && !iDPDXBrush.IsDisposed) {	iDPDXBrush.Dispose(); iDPDXBrush = null;}
//line=2196;  Print(line);
			if(iDNDXBrush!=null && !iDNDXBrush.IsDisposed) {	iDNDXBrush.Dispose();  iDNDXBrush = null;}
//			if( !=null && !.IsDisposed) {	.Dispose();  = null;}
//			if(ZoneHDXBrush!=null && !ZoneHDXBrush.IsDisposed) {	ZoneHDXBrush.Dispose(); ZoneHDXBrush = null;}
//			if(ButtonDXBrush!=null && !ButtonDXBrush.IsDisposed) {	ButtonDXBrush.Dispose(); ButtonDXBrush = null;}
//			if(ButtonPenDXBrush!=null && !ButtonPenDXBrush.IsDisposed) {	ButtonPenDXBrush.Dispose(); ButtonPenDXBrush = null;}
//			if(ButtonTextDXBrush!=null && !ButtonTextDXBrush.IsDisposed) {	ButtonTextDXBrush.Dispose(); ButtonTextDXBrush = null;}
//			if(DXBrushes_Black!=null && !DXBrushes_Black.IsDisposed) {	DXBrushes_Black.Dispose(); DXBrushes_Black = null;}
//			if(DXBrushes_LightGreen!=null && !DXBrushes_LightGreen.IsDisposed) {	DXBrushes_LightGreen.Dispose(); DXBrushes_LightGreen = null;}
//			if(DXBrushes_LightGray!=null && !DXBrushes_LightGray.IsDisposed) {	DXBrushes_LightGray.Dispose(); DXBrushes_LightGray = null;}
//			if(DXBrushM2!=null && !DXBrushM2.IsDisposed) {	DXBrushM2.Dispose(); DXBrushM2 = null;}
//			if(PenM2DXBrush!=null && !PenM2DXBrush.IsDisposed) {	PenM2DXBrush.Dispose(); PenM2DXBrush = null;}
//			if(ChartBackgroundDXBrush!=null && !ChartBackgroundDXBrush.IsDisposed) {	ChartBackgroundDXBrush.Dispose(); ChartBackgroundDXBrush = null;}
//line=2209;  Print(line);
			if(AxisDXBrush!=null && !AxisDXBrush.IsDisposed) {	AxisDXBrush.Dispose(); AxisDXBrush = null;}
			if(Buy_DSA_DXBrush!=null && !Buy_DSA_DXBrush.IsDisposed) {Buy_DSA_DXBrush.Dispose(); Buy_DSA_DXBrush=null;}
			if(Sell_DSA_DXBrush!=null && !Sell_DSA_DXBrush.IsDisposed) {Sell_DSA_DXBrush.Dispose(); Sell_DSA_DXBrush=null;}

			#endregion
//line=2213;  Print(line);
			#region Trade Plan DX Brush Disposal
			if(fillbrush!=null && !fillbrush.IsDisposed) fillbrush.Dispose(); fillbrush = null;

			if(EntryDXBrush!=null && !EntryDXBrush.IsDisposed) EntryDXBrush.Dispose(); EntryDXBrush = null;

			if(ShortSLDXBrush!=null && !ShortSLDXBrush.IsDisposed) ShortSLDXBrush.Dispose(); ShortSLDXBrush = null;
			if(ShortT1DXBrush!=null && !ShortT1DXBrush.IsDisposed) ShortT1DXBrush.Dispose(); ShortT1DXBrush = null;
			if(ShortT2DXBrush!=null && !ShortT2DXBrush.IsDisposed) ShortT2DXBrush.Dispose(); ShortT2DXBrush = null;

			if(LongSLDXBrush!=null && !LongSLDXBrush.IsDisposed) LongSLDXBrush.Dispose(); LongSLDXBrush = null;
			if(LongT1DXBrush!=null && !LongT1DXBrush.IsDisposed) LongT1DXBrush.Dispose(); LongT1DXBrush = null;
			if(LongT2DXBrush!=null && !LongT2DXBrush.IsDisposed) LongT2DXBrush.Dispose(); LongT2DXBrush = null;

//line=2227;  Print(line);
			if(EntryContrastDXBrush!=null && !EntryContrastDXBrush.IsDisposed) EntryContrastDXBrush.Dispose(); 	EntryContrastDXBrush = null;

			if(ShortSLContrastDXBrush!=null && !ShortSLContrastDXBrush.IsDisposed) ShortSLContrastDXBrush.Dispose();ShortSLContrastDXBrush = null;
			if(ShortT1ContrastDXBrush!=null && !ShortT1ContrastDXBrush.IsDisposed) ShortT1ContrastDXBrush.Dispose();ShortT1ContrastDXBrush = null;
			if(ShortT2ContrastDXBrush!=null && !ShortT2ContrastDXBrush.IsDisposed) ShortT2ContrastDXBrush.Dispose();ShortT2ContrastDXBrush = null;
			
			if(LongSLContrastDXBrush!=null && !LongSLContrastDXBrush.IsDisposed) LongSLContrastDXBrush.Dispose(); LongSLContrastDXBrush = null;
			if(LongT1ContrastDXBrush!=null && !LongT1ContrastDXBrush.IsDisposed) LongT1ContrastDXBrush.Dispose(); LongT1ContrastDXBrush = null;
			if(LongT2ContrastDXBrush!=null && !LongT2ContrastDXBrush.IsDisposed) LongT2ContrastDXBrush.Dispose(); LongT2ContrastDXBrush = null;
			#endregion
//			if(x!=null && !x.IsDisposed) x.Dispose(); x = null;
//line=2239;  Print(line);
			if(BuyStripeDXBrush!=null && !BuyStripeDXBrush.IsDisposed) {   BuyStripeDXBrush.Dispose(); BuyStripeDXBrush = null;}
			if(SellStripeDXBrush!=null && !SellStripeDXBrush.IsDisposed) { SellStripeDXBrush.Dispose(); SellStripeDXBrush = null;}
			if(HeatMap_MinimumLineDXBrush!=null && HeatMap_MinimumLineDXBrush.IsDisposed){ HeatMap_MinimumLineDXBrush.Dispose(); HeatMap_MinimumLineDXBrush=null;}

			if(RenderTarget!=null){
//line=2244;  Print(line);
				#region -- initialize brushes --
//				iSupplyZDXBrushFresh = iSupplyZColorFresh.ToDxBrush(RenderTarget);
//			    iSupplyZDXBrushFresh.Opacity = iSupplyZOpacityFresh / 100f;
//				iSupplyZDXBrushTested = iSupplyZColorTested.ToDxBrush(RenderTarget);
//			    iSupplyZDXBrushTested.Opacity = iSupplyZOpacityTested / 100f;
//				iSupplyZDXBrushBroken = iSupplyZColorBroken.ToDxBrush(RenderTarget);
//			    iSupplyZDXBrushBroken.Opacity = iSupplyZOpacityBroken / 100f;
//				iSupplyZOLDXBrushFresh = iSupplyZOLColorFresh.ToDxBrush(RenderTarget);
//				iSupplyZOLDXBrushTested = iSupplyZOLColorTested.ToDxBrush(RenderTarget);
//				iSupplyZOLDXBrushBroken = iSupplyZOLColorBroken.ToDxBrush(RenderTarget);

//				iDemandZDXBrushFresh = iDemandZColorFresh.ToDxBrush(RenderTarget);
//			    iDemandZDXBrushFresh.Opacity = iDemandZOpacityFresh / 100f;
//				iDemandZDXBrushTested = iDemandZColorTested.ToDxBrush(RenderTarget);
//			    iDemandZDXBrushTested.Opacity = iDemandZOpacityTested / 100f;
//				iDemandZDXBrushBroken = iDemandZColorBroken.ToDxBrush(RenderTarget);
//			    iDemandZDXBrushBroken.Opacity = iDemandZOpacityBroken / 100f;
//				iDemandZOLDXBrushFresh  = iDemandZOLColorFresh.ToDxBrush(RenderTarget);
//				iDemandZOLDXBrushTested = iDemandZOLColorTested.ToDxBrush(RenderTarget);
//				iDemandZOLDXBrushBroken = iDemandZOLColorBroken.ToDxBrush(RenderTarget);

				if(ChartControl == null || ChartControl.Properties==null || ChartControl.Properties.AxisPen.Brush==null)
					AxisDXBrush = Brushes.Plum.ToDxBrush(RenderTarget);
				else
					AxisDXBrush = ChartControl.Properties.AxisPen.Brush.ToDxBrush(RenderTarget);
//				ZoneHDXBrush = ZoneH.Brush.ToDxBrush(RenderTarget);
//				ButtonDXBrush = ButtonBrush.ToDxBrush(RenderTarget);
//				ButtonPenDXBrush = ButtonPen.Brush.ToDxBrush(RenderTarget);
//				ButtonTextDXBrush = ButtonTextBrush.ToDxBrush(RenderTarget);
//				DXBrushes_Black = Brushes.Black.ToDxBrush(RenderTarget);

//				DXBrushes_LightGreen = Brushes.LightGreen.ToDxBrush(RenderTarget);
//				DXBrushes_LightGray = Brushes.LightGray.ToDxBrush(RenderTarget);
//				int RectangleLineWidth = 1;

//				iBlocksDXBrush = iBlocksColor.ToDxBrush(RenderTarget); iBlocksDXBrush.Opacity=iBlocksO/100f;
//				iBlocks2DXBrush = iBlocks2Color.ToDxBrush(RenderTarget); iBlocks2DXBrush.Opacity=iBlocksO/100f;
//				ChartBackgroundDXBrush = ChartControl.Properties.ChartBackground.ToDxBrush(RenderTarget);

//				OverrideBrush = iBlocks2DXBrush;//iMPBarOpacity 
//				iIBBidDXBrush  = iIBBidColor.ToDxBrush(RenderTarget);
//				iIBBidDXBrush3 = iIBBidColor3.ToDxBrush(RenderTarget);  iIBBidDXBrush3.Opacity = iOpacityDn3/100f;
//				iIBAskDXBrush  = iIBAskColor.ToDxBrush(RenderTarget);
//				iIBAskDXBrush3 = iIBAskColor3.ToDxBrush(RenderTarget);  iIBAskDXBrush3.Opacity = iOpacityUp3/100f;
//				PenMDXBrush   = Brushes.Black.ToDxBrush(RenderTarget);
//				BrushMDXBrush = Brushes.Gray.ToDxBrush(RenderTarget);
//				BrushTDXBrush = Brushes.Gray.ToDxBrush(RenderTarget);

//				DXBrushM2 = Brushes.Gray.ToDxBrush(RenderTarget);
//				PenM2DXBrush = Brushes.Black.ToDxBrush(RenderTarget);
//				iTM_DXBrush = iTMColor.ToDxBrush(RenderTarget); iTM_DXBrush.Opacity = iTMOpacity/100f;
				for(int brptr = 0; brptr<NetDHeatMap_DXBrushes.Length; brptr++)
					NetDHeatMap_DXBrushes[brptr] = NetDHeatMap_Brushes[brptr].ToDxBrush(RenderTarget);

//				iAskHistDXBrush2 = iAskHistColor2.ToDxBrush(RenderTarget); iAskHistDXBrush2.Opacity=iSwingOpacity/100f;
//				iAskHistDXBrush1 = iAskHistColor1.ToDxBrush(RenderTarget); iAskHistDXBrush1.Opacity=iSwingOpacity/100f;

//				iBidHistDXBrush2 = iBidHistColor2.ToDxBrush(RenderTarget); iBidHistDXBrush2.Opacity=iSwingOpacity2/100f;
//				iBidHistDXBrush1 = iBidHistColor1.ToDxBrush(RenderTarget); iBidHistDXBrush1.Opacity=iSwingOpacity2/100f;

//				iAskOutDXBrush1 = iAskOutColor1.ToDxBrush(RenderTarget);
//				iBidOutDXBrush1 = iBidOutColor1.ToDxBrush(RenderTarget);

//				iTextDXBrush5 = iTextColor5.ToDxBrush(RenderTarget);
//				iTextDXBrush6 = iTextColor6.ToDxBrush(RenderTarget);
//				iTextDXBrush7 = iTextColor7.ToDxBrush(RenderTarget);
				
				iDPDXBrush = iDPColor.ToDxBrush(RenderTarget);
				iDNDXBrush = iDNColor.ToDxBrush(RenderTarget);
				BuyStripeDXBrush = this.pBuyStripeBrush.ToDxBrush(RenderTarget);
				BuyStripeDXBrush.Opacity = pBuyStripeOpacity/100.0f;
				SellStripeDXBrush = this.pSellStripeBrush.ToDxBrush(RenderTarget);
				SellStripeDXBrush.Opacity = pSellStripeOpacity/100.0f;
				
				Buy_DSA_DXBrush = pBuy_DSABrush.ToDxBrush(RenderTarget);
				Sell_DSA_DXBrush = pSell_DSABrush.ToDxBrush(RenderTarget);

				HeatMap_MinimumLineDXBrush = pHeatMap_MinimumLineColor.ToDxBrush(RenderTarget);
				#endregion

//line=2317;  Print(line);
				#region Trade Plan Create DX Brushes
				fillbrush = null;
				EntryDXBrush  = EntryBrush.ToDxBrush(RenderTarget);
				EntryContrastDXBrush = ContrastingColor((SolidColorBrush)EntryBrush).ToDxBrush(RenderTarget);
				EntryContrastDXBrush.Opacity  = 0.5f;

				#region Long trade plan brushes
				LongSLDXBrush  = LongSLBrush.ToDxBrush(RenderTarget);
				LongSLContrastDXBrush = ContrastingColor((SolidColorBrush)LongSLBrush).ToDxBrush(RenderTarget);
				LongSLContrastDXBrush.Opacity  = 0.5f;

				LongT1DXBrush = LongT1Brush.ToDxBrush(RenderTarget);
				LongT1ContrastDXBrush     = ContrastingColor((SolidColorBrush)LongT1Brush).ToDxBrush(RenderTarget);
				LongT1ContrastDXBrush.Opacity = 0.5f;

				LongT2DXBrush = LongT2Brush.ToDxBrush(RenderTarget);
				LongT2ContrastDXBrush     = ContrastingColor((SolidColorBrush)LongT2Brush).ToDxBrush(RenderTarget);
				LongT2ContrastDXBrush.Opacity = 0.5f;
				#endregion

				#region Short trade plan brushes
				ShortSLDXBrush  = ShortSLBrush.ToDxBrush(RenderTarget);
				ShortSLContrastDXBrush = ContrastingColor((SolidColorBrush)ShortSLBrush).ToDxBrush(RenderTarget);
				ShortSLContrastDXBrush.Opacity  = 0.5f;

				ShortT1DXBrush = ShortT1Brush.ToDxBrush(RenderTarget);
				ShortT1ContrastDXBrush     = ContrastingColor((SolidColorBrush)ShortT1Brush).ToDxBrush(RenderTarget);
				ShortT1ContrastDXBrush.Opacity = 0.5f;

				ShortT2DXBrush = ShortT2Brush.ToDxBrush(RenderTarget);
				ShortT2ContrastDXBrush     = ContrastingColor((SolidColorBrush)ShortT2Brush).ToDxBrush(RenderTarget);
				ShortT2ContrastDXBrush.Opacity = 0.5f;

				#endregion
				#endregion
			}
			#endregion
line=2355;  //Print(line);
		}
        //private Stopwatch benchOR = new Stopwatch();
        private bool IsDebugchOnRenderDone = false;
//=================================================================================================
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			if(!DSA_Sensitivity_Changed) base.OnRender(chartControl,chartScale);
	        #region --------- OnRender() ------------
line=2555;
			bool EXECUTE = false;
            try
            {
//				Print(chartControl.BarWidth.ToString("0.00"));
                RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
				bool IsMinuteBar = iPCalcM.CompareTo("Minute")==0;

//                gbChartScale = chartScale;

                //if (!IsDebugchOnRenderDone) benchOR.Start();

                #region -- conditions to return --
                if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot || ChartControl == null) return;
                if (Bars == null || BarsArray[0].Count == 0 || BarsArray[1].Count == 0)
                {
					string msg = string.Empty;
					if(BarsArray[0].Count==0) msg = "No bars on chart";
					if(BarsArray[1].Count==0) {
						if(msg.Length>0) msg = msg+Environment.NewLine+"No bars in background timeframe";
						else msg = "No bars in background timeframe";
					}
                    drawstring(string.Format("Data is missing...attempt to load more days of data, Repair DB, or restart NT{0}{1}",Environment.NewLine,msg), ChartPanel.X + 50, ChartPanel.Y + ChartPanel.H/2, new SimpleFont("Arial", 14), AxisDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
                    return;
                }
                if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
                #endregion
line=2582;
                SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
                RenderTarget.AntialiasMode          = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
//				int ZoneHLineWidth = Convert.ToInt32(ZoneH.Thickness);

				#region -- Preliminary Calculation --
                lastBarIndex = Math.Min(CurrentBars[0], ChartBars.ToIndex);//RIGHT BAR idx (slot)
                int firstBarIndex = Math.Max(BarsRequiredToPlot, ChartBars.FromIndex);// BarsRequiredToPlot;//FIRST LEFT BAR idx (slot)
                int RemainBars = ChartBars.ToIndex;

                //---------------
                if (lastBarIndex < 0 || firstBarIndex < 0 || CurrentBars[0] < 0) return;
                bool ISHardRight = lastBarIndex == CurrentBars[0];
                MouseBarIndex = CurrentBars[0] - (int)chartControl.GetSlotIndexByX(MM.X);
                if (Calculate != Calculate.OnBarClose) MouseBarIndex = MouseBarIndex - 1;

line=2598;
                #region -- Fill PriceBoxes List --
                double ActualTopPrice = chartScale.MaxValue;
                double ActualBottomPrice = chartScale.MinValue;
                double PercentExpand = 20, MinTicksExpand = 50;
                double TotalExpand = Math.Max(chartScale.MaxMinusMin * PercentExpand / 100, MinTicksExpand * gbTickSize);
                double TopPrice = ActualTopPrice + TotalExpand;
                double BottomPrice = ActualBottomPrice - TotalExpand;

line=2607;
                PriceBoxes.Clear();
                AverageBoxHeight = 0;
                TotalBoxHeight = 0;
                double currentPrice = BottomPrice;
                while (currentPrice <= TopPrice)
                {
                    int yCPrice = chartScale.GetYByValue(currentPrice);
                    int yCPm1   = chartScale.GetYByValue(currentPrice - gbTickSize);
                    int height  = Math.Max(minBarHeight, Math.Min(maxBarHeight, Math.Abs(yCPm1 - yCPrice) - pBoxSpace));
                    int halfHeight = height / 2;

                    if (!PriceBoxes.ContainsKey(currentPrice))
                    {
                        PriceBoxes[currentPrice] = new PriceBox();//##Modif by Kriss AzurITec## : BUGPP001 with CL [FIXED]. StartPrice always the same because never incremented due to NT BUG. See function RTTS for bug fix (line 12939). CRASHES HERE due to duplicate key
                        PriceBoxes[currentPrice].Top = yCPrice - halfHeight;
                        PriceBoxes[currentPrice].Bottom = yCPrice + halfHeight;
                        PriceBoxes[currentPrice].Height = height;
                    }
                    TotalBoxHeight = TotalBoxHeight + height;
                    currentPrice = RTTS(currentPrice + gbTickSize);//##Modif by Kriss AzurITec## : BUGPP001 with CL [FIXED]. No increment due to NT7 bug						
                }
line=2629;
                if (PriceBoxes.Count == 0) return;
                AverageBoxHeight = TotalBoxHeight / PriceBoxes.Count;
                #endregion

line=2634;
                #region -- Calculate Chart Variables (barwidth / bar margin right...) --
                int barWidth = chartControl.GetBarPaintWidth(ChartBars);
                int PixelsBetweenBars = (int)(ChartControl.Properties.BarDistance - chartControl.BarWidth);
                barWidth = Math.Max(barWidth, (int)(ChartControl.Properties.BarDistance - iMaxBarSpacePixels)) / 2;

                diff = barWidth - (int)(chartControl.BarWidth / 2);// chartControl.GetBarPaintWidth(ChartBars);
//                FinalDesiredMargin = iRightSideMarginMin + diff;// adjust the right side margin based on this number. add it.
				//Print("Bar Width: " + barWidth + ", diff: " + diff + ", FinalMargin: " + FinalDesiredMargin + ", System Bar Width: " + chartControl.GetBarPaintWidth(ChartBars));
				float systemBarWidth = chartControl.GetBarPaintWidth(ChartBars);
                #endregion

line=2646;
				#region -- automatically Calculate Fontsize --
				//reset GeneralFont to user settings
				GeneralFont.FamilySerialize = iBarPrintFont.FamilySerialize;
				GeneralFont.Size = iBarPrintFont.Size;
				GeneralFont.Bold = iBarPrintFont.Bold;

				//Calulate Font size for print inside bars
line=2654;
				if(firstBarIndex!=fbi || lastBarIndex!=lbi){
					#region -- original (error prone) Calculate barprintFont --
//					fbi = firstBarIndex;
//					lbi = lastBarIndex;
////					var BarData_VisibleBars = BarDataCollection.Where(p => p.Key >= firstBarIndex - 1 && p.Key <= lastBarIndex).ToList();
//					var BarData_VisibleBars = BarDataCollection.Where(p => p.Key >= firstBarIndex - 1 && p.Key <= lastBarIndex && (p.Value!=null && p.Value.Count>0)).ToDictionary(entry => entry.Key, entry => entry.Value);
//					long maxV = 99;
////return;
//					if(BarData_VisibleBars !=null){
//							maxV = IsMinuteBar ? 99 : Math.Max(
//															BarData_VisibleBars.Max(p => p.Value.Max(x => x.Value.AskSize)), 
//															BarData_VisibleBars.Max(p => p.Value.Max(x => x.Value.BidSize)));//get max bid/ask value
//					}
//					barprintFont.Size = this.iBarPrintFont.Size;
//					barprintFont.Size = CalculateOptimalFontSize(barWidth - 1, maxV.ToString(), barprintFont);
					#endregion -------------------
					#region -- Calculate barprintFont --
					fbi = firstBarIndex;
					lbi = lastBarIndex;
//					var BarData_VisibleBars = BarDataCollection.Where(p => p.Key >= firstBarIndex - 1 && p.Key <= lastBarIndex).ToList();
//					var BarData_VisibleBars = BarDataCollection.Where(p => p.Key >= firstBarIndex - 1 && p.Key <= lastBarIndex && (p.Value!=null && p.Value.Count>0)).ToDictionary(entry => entry.Key, entry => entry.Value);
					long maxV = 99;
line=2677;// //Print(line);
					if(!IsMinuteBar){
						long maxAsk = -1;
						long maxBid = -1;
						var keys = BarDataTotals.Keys.ToList();
						foreach(var p in keys) {
							//try{
line=2684;// //Print(line);
							if(p >= firstBarIndex - 1 && p <= lastBarIndex) {
								maxAsk = Math.Max(maxAsk, BarDataTotals[p].MaxAsk);
								maxBid = Math.Max(maxBid, BarDataTotals[p].MaxBid);
							}
							//}catch(Exception e2){Print("e2: "+e2.ToString());}
						}
line=2691;// //Print(line);
						if(maxAsk>=0 && maxBid>=0){
							maxV = Math.Max(maxAsk, maxBid);
//													Math.Max(
//															BarData_VisibleBars.Max(p => p.Value.Max(x => x.Value.AskSize)), 
//															BarData_VisibleBars.Max(p => p.Value.Max(x => x.Value.BidSize)));//get max bid/ask value
						}
					}
line=2699;// //Print(line);
//					barprintFont.Size = this.iBarPrintFont.Size;
//					barprintFont.Size = CalculateOptimalFontSize(barWidth - 1, maxV.ToString(), barprintFont);
					#endregion ----------------
				}
line=2704;
				//Calulate Font size for NetDelta
				var netDeltaFont = (SimpleFont)iNetDeltaFont.Clone();
				//var tmpBarDataTotals = BarDataTotals.ToList();
				//var tmpND = tmpBarDataTotals.Where(p => p.Key >= firstBarIndex - 1 && p.Key <= lastBarIndex);
				//long maxND = IsMinuteBar ? 99 : tmpND.Max(p => Math.Abs(p.Value.AskTotal + p.Value.BidTotal));//get max |netdelta| value
				//v1.12/ netDeltaFont.Size = CalculateOptimalFontSize(ChartControl.Properties.BarDistance, maxND.ToString(), netDeltaFont);
				bool drawNetDeltaText = true;//v1.12/ netDeltaFont.Size >= MINFONTSIZE + 2;

				//calculate vertical adjustment
line=2714;
//				AdjustFontAmount = 0;
				int adjustpoint = 5;// increase number to make it more sensitive, higher the number quicker the numbers get smaller
//				if (GeneralFont.Size - adjustpoint > AverageBoxHeight) AdjustFontAmount = (int)Math.Round((iBarPrintFont.Size - adjustpoint - AverageBoxHeight) / 2, 0);

				#endregion

				#endregion

line=2723;
				#region -- Draw NetDelta HeatMap --
				if(!IsInHitTest)
				{
					//float dsa_rect_linewidth = pDSA_HistoOutlineThickness;//Math.Max(ChartControl.Properties.BarDistance/4f, pDSA_HistoOutlineThickness);
					//int barpaintwidth = chartControl.GetBarPaintWidth(chartControl.BarsArray[0]);

					int   hm_color_ptr    = NetDHeatMap_Brushes.Length/2;
					float barDistance     = ChartControl.Properties.BarDistance;
					var   HalfBarDistance = barDistance/2f;
					CalculateHeatMapColorPtr(ChartBars.FromIndex, ChartBars.ToIndex, true);

//					float ry = ChartPanel.H - BARRIER_LINE_HEIGHT;
					float max_histo_height = ChartPanel.H/7f;
					float rx = 0f;
					SharpDX.RectangleF heatmapRect;
					for(int hmabar = ChartBars.FromIndex; hmabar<=ChartBars.ToIndex; hmabar++)
					{
line=2740;
						if(!HeatMapBarToColor.ContainsKey(hmabar)) continue;
						rx = ChartControl.GetXByBarIndex(ChartBars, hmabar);
						hm_color_ptr = HeatMapBarToColor[hmabar];
						try{
							float rheight = BARRIER_LINE_HEIGHT;
							float ryRect = ChartPanel.Y + ChartPanel.H - rheight;
							if(pUseSkinnyHeatmapBars)
                            {
								#region -- print a skinny version of the heatmap histo --
								if(pShowNetDeltaHeatMap) RenderTarget.FillRectangle(new SharpDX.RectangleF(rx-HalfBarDistance, ryRect, barDistance-1f, rheight), NetDHeatMap_DXBrushes[HeatMapBarToColor[hmabar]]);
								rheight = Math.Min(max_histo_height, Math.Max(rheight, rheight*Convert.ToSingle(ryVolAdjuster.GetValueAt(hmabar))));
								ryRect  = ChartPanel.Y + ChartPanel.H - rheight;
line=2765;
								heatmapRect = new SharpDX.RectangleF(rx-HalfBarDistance, ryRect, barDistance*0.2f, rheight);
								if(pShowNetDeltaHeatMap) RenderTarget.FillRectangle(heatmapRect, NetDHeatMap_DXBrushes[HeatMapBarToColor[hmabar]]);
								#endregion
							}
                            else
                            {
								#region -- print a regular width version of the heatmap histo --
								rheight = Math.Min(max_histo_height, Math.Max(rheight, rheight*Convert.ToSingle(ryVolAdjuster.GetValueAt(hmabar))));
								ryRect  = ChartPanel.Y + ChartPanel.H - rheight;
								heatmapRect = new SharpDX.RectangleF(rx-HalfBarDistance, ryRect, barDistance-1f, rheight);
								if(pShowNetDeltaHeatMap) RenderTarget.FillRectangle(heatmapRect, NetDHeatMap_DXBrushes[HeatMapBarToColor[hmabar]]);
								#endregion
							}
line=2778;
							if(pShow_DSASignal){
								#region -- Print DSA Signals on price bar and/or on HeatMap histo bar --
								if(rheight > BARRIER_LINE_HEIGHT){
line=2796;
									int mid = NetDHeatMap_Brushes.Length/2;
									bool IsSignalBar = false;
//Pit(hmabar, string.Format("onrender {0}  hm_color_ptr: {1} mid: {2}  DSASens: {3} ",Times[0].GetValueAt(hmabar),hm_color_ptr, mid, pDSA_Sensitivity));
									if(hm_color_ptr < (mid+1)-pDSA_Sensitivity && Closes[0].GetValueAt(hmabar) > Opens[0].GetValueAt(hmabar)){
										IsSignalBar = true;
										DSA_DXBrush = Buy_DSA_DXBrush;
//Pit(hmabar, "onrender    BUY");
									}
									if(hm_color_ptr > (mid-1)+pDSA_Sensitivity && Closes[0].GetValueAt(hmabar) < Opens[0].GetValueAt(hmabar)){
										IsSignalBar = true;
										DSA_DXBrush = Sell_DSA_DXBrush;
//Pit(hmabar, "onrender    SELL");
									}
									if(IsSignalBar){
line=2811;
										if(pShowNetDeltaHeatMap && pDSA_OpacityOnHeatMap>0){
											DSA_DXBrush.Opacity = pDSA_OpacityOnHeatMap/100.0f;
											heatmapRect.X       = heatmapRect.X + pDSA_HistoOutlineThickness/2f;
											heatmapRect.Y       = heatmapRect.Y + pDSA_HistoOutlineThickness/2f;
											heatmapRect.Width   = heatmapRect.Width - pDSA_HistoOutlineThickness;
											heatmapRect.Height  = heatmapRect.Height - pDSA_HistoOutlineThickness;
											RenderTarget.DrawRectangle(heatmapRect, DSA_DXBrush, pDSA_HistoOutlineThickness);
										}
										if(pDSA_OpacityOnPriceBar>0){
line=2821;
											DSA_DXBrush.Opacity = pDSA_OpacityOnPriceBar/100.0f;
											var ryO = chartScale.GetYByValue(Opens[0].GetValueAt(hmabar));
											var ryC = chartScale.GetYByValue(Closes[0].GetValueAt(hmabar));
											rheight = Math.Abs(ryO-ryC)+1f;
											RenderTarget.FillRectangle(new SharpDX.RectangleF(rx-systemBarWidth/2f, Math.Min(ryO,ryC)-1f, systemBarWidth, rheight), DSA_DXBrush);
										}
line=2842;
//										if(DSA_DXBrush!=null && !DSA_DXBrush.IsDisposed) DSA_DXBrush.Dispose(); DSA_DXBrush = null;
									}
								}
								#endregion -------------------------------
							}
							if(!DSA_Sensitivity_Changed && pShowRacingStripes){
								float chartHeightF = Convert.ToSingle(chartScale.Height*2);
								if(pShowLongs && this.pBuyStripeOpacity>0  && pBuyStripeBrush != Brushes.Transparent && DFSignalHistory.GetValueAt(hmabar)==BUY) 
									RenderTarget.FillRectangle(new SharpDX.RectangleF(rx-systemBarWidth/2f, 0, systemBarWidth, chartHeightF), BuyStripeDXBrush);
								if(pShowShorts && this.pSellStripeOpacity>0  && pSellStripeBrush != Brushes.Transparent && DFSignalHistory.GetValueAt(hmabar)==SELL) 
									RenderTarget.FillRectangle(new SharpDX.RectangleF(rx-systemBarWidth/2f, 0, systemBarWidth, chartHeightF), SellStripeDXBrush);
							}
							if(pShowLongTradePlans || pShowShortTradePlans){
								#region - show trade plans -
								var RMabar = Math.Min(CurrentBars[0],ChartBars.ToIndex);
								if(this.SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR) {
									SL_inPts = RoundToTick(this.pSLsize_inATRs * atr.GetValueAt(RMabar));
									T1_inPts = RoundToTick(this.pT1size_inATRs * atr.GetValueAt(RMabar));
									T2_inPts = RoundToTick(this.pT2size_inATRs * atr.GetValueAt(RMabar));
								}else{
									SL_inPts = RoundToTick(this.pSLsize_inTicks * TickSize);
									T1_inPts = RoundToTick(this.pT1size_inTicks * TickSize);
									T2_inPts = RoundToTick(this.pT2size_inTicks * TickSize);
								}
								int Dir = FLAT;
								double EntryPrice = 0;
								for(int ab = RMabar; ab>0; ab--){
									if     (DFSignalHistory.GetValueAt(ab) == SELL) {Dir=SELL; EntryPrice = Closes[0].GetValueAt(ab); break;}
									else if(DFSignalHistory.GetValueAt(ab) == BUY)  {Dir=BUY;  EntryPrice = Closes[0].GetValueAt(ab); break;}
								}

								rx = ChartControl.GetXByBarIndex(ChartBars, RMabar);
								float LineLengthPx = pTradePlan_LineLength*barDistance;
								float xLpx = rx + barDistance;
								float xRpx = xLpx + LineLengthPx;
//								if(pTPLabelSide == ARC_DeltaForce_TPLabelSide.Left) xRpx = rx+5f;

								#region - showing long trade plans -
								if(pShowLongTradePlans && Dir==BUY){
									var yP = chartScale.GetYByValue(EntryPrice);
									if(pShowEntry){
										if(pTPLabelSide == ARC_DeltaForce_TPLabelSide.Right){
											drawLine(xLpx, xRpx, yP, yP, this.EntryDXBrush, EntryLineWidth, EntryDashStyle);
											drawstring(LongEntryLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(EntryPrice)), xRpx+5f, yP, FontEL, EntryDXBrush, EntryContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
										}else{
											var xTextEnd = xLpx + 5f + drawstring(LongEntryLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(EntryPrice)), xLpx, yP, FontEL, EntryDXBrush, EntryContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
											float xLineEnd = xTextEnd + LineLengthPx;
											drawLine(xTextEnd, xLineEnd, yP, yP, this.EntryDXBrush, EntryLineWidth, EntryDashStyle);
										}
									}
									if(this.pShowSL){
										var price = EntryPrice - SL_inPts;
										yP = chartScale.GetYByValue(price);
										if(pTPLabelSide == ARC_DeltaForce_TPLabelSide.Right){
											drawLine(xLpx, xRpx, yP, yP, LongSLDXBrush, this.SLLineWidth, SLDashStyle);
											drawstring(LongSLLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xRpx+5f, yP, FontSL, LongSLDXBrush, LongSLContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
										}else{
											var xTextEnd = xLpx + 5f + drawstring(LongSLLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xLpx, yP, FontSL, LongSLDXBrush, LongSLContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
											float xLineEnd = xTextEnd + LineLengthPx;
											drawLine(xTextEnd, xLineEnd, yP, yP, this.LongSLDXBrush, SLLineWidth, SLDashStyle);
										}
									}
									if(this.pShowT1){
										var price = EntryPrice + T1_inPts;
										yP = chartScale.GetYByValue(price);
										if(pTPLabelSide == ARC_DeltaForce_TPLabelSide.Right){
											drawLine(xLpx, xRpx, yP, yP, LongT1DXBrush, this.T1LineWidth, T1DashStyle);
											drawstring(LongT1Label.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xRpx+5f, yP, FontT1, LongT1DXBrush, LongT1ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
										}else{
											var xTextEnd = xLpx + 5f + drawstring(LongT1Label.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xLpx, yP, FontT1, LongT1DXBrush, LongT1ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
											float xLineEnd = xTextEnd + LineLengthPx;
											drawLine(xTextEnd, xLineEnd, yP, yP, this.LongT1DXBrush, T1LineWidth, T1DashStyle);
										}
									}
									if(this.pShowT2){
										var price = EntryPrice + T2_inPts;
										yP = chartScale.GetYByValue(price);
										if(pTPLabelSide == ARC_DeltaForce_TPLabelSide.Right){
											drawLine(xLpx, xRpx, yP, yP, LongT2DXBrush, this.T2LineWidth, T2DashStyle);
											drawstring(LongT2Label.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xRpx+5f, yP, FontT2, LongT2DXBrush, LongT2ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
										}else{
											var xTextEnd = xLpx + 5f + drawstring(LongT2Label.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xLpx, yP, FontT2, LongT2DXBrush, LongT2ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
											float xLineEnd = xTextEnd + LineLengthPx;
											drawLine(xTextEnd, xLineEnd, yP, yP, this.LongT2DXBrush, T2LineWidth, T2DashStyle);
										}
									}
								}
								#endregion
								#region - showing short trade plans -
								else if(pShowShortTradePlans && Dir==SELL){
									var yP = chartScale.GetYByValue(EntryPrice);
									if(pShowEntry){
										if(pTPLabelSide == ARC_DeltaForce_TPLabelSide.Right){
											drawLine(xLpx, xRpx, yP, yP, this.EntryDXBrush, EntryLineWidth, EntryDashStyle);
											drawstring(ShortEntryLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(EntryPrice)), xRpx+5f, yP, FontEL, EntryDXBrush, EntryContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
										}else{
											var xTextEnd = xLpx + 5f + drawstring(ShortEntryLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(EntryPrice)), xLpx, yP, FontEL, EntryDXBrush, EntryContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
											float xLineEnd = xTextEnd + LineLengthPx;
											drawLine(xTextEnd, xLineEnd, yP, yP, this.EntryDXBrush, EntryLineWidth, EntryDashStyle);
										}
									}
									if(this.pShowSL){
										var price = EntryPrice + SL_inPts;
										yP = chartScale.GetYByValue(price);
										if(pTPLabelSide == ARC_DeltaForce_TPLabelSide.Right){
											drawLine(xLpx, xRpx, yP, yP, ShortSLDXBrush, this.SLLineWidth, SLDashStyle);
											drawstring(ShortSLLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xRpx+5f, yP, FontSL, ShortSLDXBrush, ShortSLContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
										}else{
											var xTextEnd = xLpx + 5f + drawstring(ShortSLLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xLpx, yP, FontSL, ShortSLDXBrush, ShortSLContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
											float xLineEnd = xTextEnd + LineLengthPx;
											drawLine(xTextEnd, xLineEnd, yP, yP, this.ShortSLDXBrush, SLLineWidth, SLDashStyle);
										}
									}
									if(this.pShowT1){
										var price = EntryPrice - T1_inPts;
										yP = chartScale.GetYByValue(price);
										if(pTPLabelSide == ARC_DeltaForce_TPLabelSide.Right){
											drawLine(xLpx, xRpx, yP, yP, ShortT1DXBrush, this.T1LineWidth, T1DashStyle);
											drawstring(ShortT1Label.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xRpx+5f, yP, FontT1, ShortT1DXBrush, ShortT1ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
										}else{
											var xTextEnd = xLpx + 5f + drawstring(ShortT1Label.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xLpx, yP, FontT1, ShortT1DXBrush, ShortT1ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
											float xLineEnd = xTextEnd + LineLengthPx;
											drawLine(xTextEnd, xLineEnd, yP, yP, this.ShortT1DXBrush, T1LineWidth, T1DashStyle);
										}
									}
									if(this.pShowT2){
										var price = EntryPrice - T2_inPts;
										yP = chartScale.GetYByValue(price);
										if(pTPLabelSide == ARC_DeltaForce_TPLabelSide.Right){
											drawLine(xLpx, xRpx, yP, yP, ShortT2DXBrush, this.T2LineWidth, T2DashStyle);
											drawstring(ShortT2Label.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xRpx+5f, yP, FontT2, ShortT2DXBrush, ShortT2ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
										}else{
											var xTextEnd = xLpx + 5f + drawstring(ShortT2Label.Replace("*",Instrument.MasterInstrument.FormatPrice(price)), xLpx, yP, FontT2, ShortT2DXBrush, ShortT2ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
											float xLineEnd = xTextEnd + LineLengthPx;
											drawLine(xTextEnd, xLineEnd, yP, yP, this.ShortT2DXBrush, T2LineWidth, T2DashStyle);
										}
									}
								}
								#endregion
								#endregion
							}
						}catch(Exception hme){Print(hme.ToString()+"  \n  "+line+"  No data: "+Bars.GetTime(hmabar).ToString());}
					}
line=2920;
					if(pHeatMap_MinLineThickness > 0 && pHeatMap_MinimumLineColor != Brushes.Transparent){
line=2923;
						drawLine(0, ChartPanel.W, ChartPanel.Y + ChartPanel.H-BARRIER_LINE_HEIGHT, ChartPanel.Y + ChartPanel.H-BARRIER_LINE_HEIGHT, HeatMap_MinimumLineDXBrush, pHeatMap_MinLineThickness);
//						RenderTarget.DrawLine(new SharpDX.Vector2(,), new SharpDX.Vector2(,), HeatMap_MinimumLineDXBrush, pHeatMap_MinLineThickness);
					}
				}

				#endregion
line=3283;

                #region -- DRAW BARS AND PRINT --
                if (!IsMinuteBar)
                {
line=3288;
                    int FirstBarDrawn = 99999999;
					VolumeProfileS TPRO = null;
					for(int abar = firstBarIndex; abar<=lastBarIndex; abar++)
					{
line=3297;
                        #region -- if outside of window => continue loop --
						double Highs0CB = RoundToWholePip(Highs[0].GetValueAt(abar));
						double Lows0CB = RoundToWholePip(Lows[0].GetValueAt(abar));

						if (Highs0CB < ActualBottomPrice || Lows0CB > ActualTopPrice) continue;
                        #endregion

                        //bool PrintThisBar = ((iPrintEnabled && !PrintIndividualBars.Contains(abar)) || (!iPrintEnabled && PrintIndividualBars.Contains(abar)) || (iCurrentBarEnabled && abar == CurrentBars[0]));

                        // composite at left adjustment
                        FirstBarDrawn = Math.Min(FirstBarDrawn, abar);

						TPRO = null;
line=3311;
						y1 = chartScale.GetYByValue(Highs0CB);
						y2 = chartScale.GetYByValue(BodyHigh.GetValueAt(abar));
						y3 = chartScale.GetYByValue(BodyLow.GetValueAt(abar)) + 1;
						y4 = chartScale.GetYByValue(Lows0CB) + 1;
						x1 = ChartControl.GetXByBarIndex(ChartBars, abar);

						if (y3 - y2 <= 0 || y4 - y1 <= 0) continue;

line=3320;
						Rect BodyRect = new Rect(x1 - barWidth, y2, barWidth * 2, y3 - y2);
						Rect CandleRect = new Rect(x1 - barWidth, y1 - 1, barWidth * 2, y4 - y1);

//						if(chartControl.BarWidth>1)
//							drawRegion(BodyRect, ChartBackgroundDXBrush);//Put a mask over the original chart bars

line=3327;
						if(!IsInHitTest && drawNetDeltaText && BarDataTotals.ContainsKey(abar)){
							double netdv = NETDELTA.GetValueAt(abar);
							string vstr1 = string.Empty;
							string vstr2 = string.Empty;
							double dist_mult = 1.1;
line=3479;
							#region -- NET DELTA --
							if (pShowNetDeltaNumberOnBar)
								vstr2 = netdv.ToString("0");
							if(vstr1.Length>0 && vstr2.Length>0){
								dist_mult = 2.5;
//								vstr1 = string.Format("{0}\n{1}", vstr1, vstr2);
								if (netdv >= 0){
									drawstring(vstr1, x1 - getTextWidth(vstr1, netDeltaFont) / 2, GetBoxPixel(Highs0CB, 'T') - netDeltaFont.Size*dist_mult, netDeltaFont, iDPDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
									drawstring(vstr2, x1 - getTextWidth(vstr1, netDeltaFont) / 2, GetBoxPixel(Highs0CB, 'T') - netDeltaFont.Size-5,         netDeltaFont, iDPDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
							    }else{
									drawstring(vstr1, x1 - getTextWidth(vstr1, netDeltaFont) / 2, GetBoxPixel(Lows0CB, 'B')+5,                   netDeltaFont, iDNDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
									drawstring(vstr2, x1 - getTextWidth(vstr1, netDeltaFont) / 2, GetBoxPixel(Lows0CB, 'B')+6+netDeltaFont.Size, netDeltaFont, iDNDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
								}
							}else{
								if(vstr2.Length>0) vstr1 = vstr2;
								if(vstr1.Length>0){
									if (netdv >= 0){
										drawstring(vstr1, x1 - getTextWidth(vstr1, netDeltaFont) / 2, GetBoxPixel(Highs0CB, 'T') - netDeltaFont.Size-5,         netDeltaFont, iDPDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
								    }else{
										drawstring(vstr1, x1 - getTextWidth(vstr1, netDeltaFont) / 2, GetBoxPixel(Lows0CB, 'B')+5,                   netDeltaFont, iDNDXBrush, SharpDX.DirectWrite.TextAlignment.Center);
									}
								}
							}
							#endregion
						}
line=3507;
                    }
				}
                #endregion

line=3588;

                #region -- Signals labels --
//                if (!IsMinuteBar)
//                {
//					for (int i = lastBarIndex; i > firstBarIndex; i--)
//                    {
//						string SignalOnBar = "";
//						int DirectionOfSignal = 0;
                        //double DDsignal = deltadivergenceDefault.IsValidDataPointAt(i) ? deltadivergenceDefault.GetValueAt(i) : 0;
                        //double TTsignal = trappedtraderDefault.IsValidDataPointAt(i) ? trappedtraderDefault.GetValueAt(i) : 0;
                        //double CSsignal = DDsignal == TTsignal ? DDsignal : 0;
						//if(!iCCEnabled) CSsignal = 0;

//                        int netdeltaside = 0;
//                        if ((pShowNetDeltaNumberOnBar/* || this.iShowTotalVolumeAsPct*/) && !IsInHitTest && drawNetDeltaText && BarDataTotals.ContainsKey(i))
//                        {
//                            double tot = NETDELTA.GetValueAt(i);
//                            netdeltaside = tot >= 0 ? 1 : -1;//v1.012 ##Modif by Kriss AzurITec## for auto offset
//                        }
//                    }
//                }
                #endregion

line=3782;

                // JQ 12.09.2017
                // Removed the following code as it's causing the PP to shift away from the SDV bar when the two bars
                // SDV + PP + VMD are added to the same chart and the SDV are set to be seen infront of the PP. 
                // Bug 12782, 12670
                //---start--
                //ChartControl.Properties.BarMarginRight = FinalDesiredMargin;
                //---end--
                RenderTarget.AntialiasMode = OSM;
line=3800;
            }
            catch (Exception e) { 
				RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased; 
				Print(line+", OnRender: "+e.ToString());
			}//#BUG003 : restore correct AntialiasMode
            //if (!IsDebugchOnRenderDone)
            //{
            //    benchOR.Stop();
            //    IsDebugchOnRenderDone = true;
            //    int nbbars = Math.Abs(lastBarIndex - firstBarIndex);
            //    Print(String.Format("OnRD Time (@load) : {0}ms on {1} bars => {2:n}ms/bar", benchOR.ElapsedMilliseconds, nbbars, benchOR.ElapsedMilliseconds / (double)nbbars));
            //    benchOR.Reset();
            //}
	        #endregion
		}//end of OnRender
//====================================================================================================
        private void drawLine(float x1, float x2, float y1, float y2, SharpDX.Direct2D1.Brush dxbrush, float width = 1, DashStyleHelper dashstyle = DashStyleHelper.Solid, int opacity = 100)
        {
            if(opacity!=100) dxbrush.Opacity = opacity / 100f;
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties  = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle           strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            RenderTarget.DrawLine(new SharpDX.Vector2(x1,y1), new SharpDX.Vector2(x2,y2), dxbrush, width, strokestyle);

            strokestyle.Dispose();
        }
        private float drawstring(string text, float x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush,  SharpDX.Direct2D1.Brush bkgBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxX = -9999f)
        {
			#region drawstring
			if (y < 0 || font.Size <= 0) return -1f;//don't draw if outside of window. if size==0 throw exception
			//SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();

			var textFormat = new SharpDX.DirectWrite.TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold   ? SharpDX.DirectWrite.FontWeight.Bold  : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
			)
				{ TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, ChartPanel.W/3, ChartPanel.H);

			if(x<0)    x = Math.Abs(x) - textLayout.Metrics.Width - 5;
			if(MaxX>0) x = Math.Min(x, MaxX - 3f - textLayout.Metrics.Width);
			x = Math.Max(5f,x);

			y = y - textLayout.Metrics.Height/2.0;
			if (bkgBrush!=null && bkgBrush.Opacity>0) {
				double xl = x - 3;
				double xr = x + textLayout.Metrics.Width + 3;
				double yt = y - 1;
				double yb = y+textLayout.Metrics.Height + 2;
				if(textAlignment==SharpDX.DirectWrite.TextAlignment.Trailing){
					xr = x + textLayout.Metrics.LayoutWidth +3;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				else if(textAlignment==SharpDX.DirectWrite.TextAlignment.Center){
					xr = x + textLayout.Metrics.LayoutWidth/2 + 3 + textLayout.Metrics.Width/2;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				var bkgBox = new System.Windows.Point[]
				{	new System.Windows.Point(xl, yt),
					new System.Windows.Point(xl, yb),
					new System.Windows.Point(xr, yb),
					new System.Windows.Point(xr, yt),
				};
				drawRegion(bkgBox, bkgBrush);
			}
			RenderTarget.DrawTextLayout(new SharpDX.Vector2(x,Convert.ToSingle(y)), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			float textWidth = textLayout.Metrics.Width;
			textLayout.Dispose();
			textFormat.Dispose();
			return textWidth;
			#endregion
		}
//====================================================================================================
		private Chart chartWindow;
        private Grid indytoolbar;

        private Menu MenuControlContainer;
        private MenuItem MenuControl, miAvgStopFirstTouch, miShow_DSASignal, miDSA_Sensitivity, miDSA_OpacityOnBar, miDSA_OpacityOnHeatMapHisto, miDSA_OutlineWidthOnHeatMapHisto;
		private MenuItem miShowHide_Longs, miShowHide_Shorts, miApplyHistoFilter, miShowHide_RacingStripes, miRecalculate1, miRecalculate2, miRecalculate3;
		private MenuItem miShowHide_LongTradePlan, miShowHide_ShortTradePlan, miPermitContinuingTrade, miShowNetDeltaHeatMap, miUseSkinnyHeatmapBars, miShowNetDeltaNumber;
		private MenuItem miShowEntry, miShowT2, miShowT1, miShowSL, miTPLabelSide, miSLTPCalcBasis, miAlgorithm;
        private TextBox nudMST1, nudMST2, nudCRV1, nudCRV2, nudPCS1, nudPCS2, nudPCS3, nudVA1, nudVA2;
        private ComboBox CompTypeCombo, VA1Combo, VA2Combo;
        private Button gCmdup;
        private Button gCmddw;
        private Label gLabel;
		private TextBox nudATRperiod, nudSLsize, nudT1size, nudT2size;
		private Label label_ATRPeriod, label_SLsize, label_T1size, label_T2size;

		private int SLdistanceTicks = 0;
		private int T1distanceTicks = 0;
		private int T2distanceTicks = 0;
		private bool DSA_Sensitivity_Changed = false;

        //------------------ Private Functions --------------------------------
        #region -- Toolbar Management Utilities --
		private void menuTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			#region menuTxtbox_KeyDown
			e.Handled = true;
			TextBox txtSender = sender as TextBox;
			int cursor_location = txtSender.SelectionStart;
			int keyVal = (int)e.Key;
			int new_number = -1;
			if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) {
				new_number = keyVal - (int)System.Windows.Input.Key.D0;
			}else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) {
				new_number = keyVal - (int)System.Windows.Input.Key.NumPad0;
			}

			bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.Decimal;
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.OemPeriod;

			if (isNumeric || e.Key == System.Windows.Input.Key.Back)
			{
				string newText = new_number != -1 ? new_number.ToString() : "";
				if(!txtSender.Text.Contains(".")){
					if(e.Key==System.Windows.Input.Key.Decimal) newText = ".";
					else if(e.Key==System.Windows.Input.Key.OemPeriod) newText = ".";
				}
				try{
					if(txtSender.SelectedText.Length==0)
						txtSender.Text = txtSender.Text.Insert(cursor_location, newText);
					else{
						txtSender.Text = txtSender.Text.Replace(txtSender.SelectedText, newText);
					}
				}catch(Exception t){Print("menuTxtbox_KeyDown: "+t.ToString());}
				cursor_location++;
			}

			string intxt = txtSender.Text;
			intxt = intxt.Replace("-",string.Empty).Trim();//no negative values allowed
			if (intxt.Length > 0)
			{
				if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR){
					if(txtSender.Name.Contains("ATR")) {
						pATRperiod = int.Parse(intxt);
						txtSender.Text = pATRperiod.ToString("0");
					}
					else if(txtSender.Name.Contains("SL")) {
						if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR){
							pSLsize_inATRs = double.Parse(intxt);
							txtSender.Text = pSLsize_inATRs.ToString("0.0");
						}else{
							pSLsize_inTicks = int.Parse(intxt);
							txtSender.Text = pSLsize_inTicks.ToString("0");
						}
					}
					else if(txtSender.Name.Contains("T1")) {
						if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR){
							pT1size_inATRs = double.Parse(intxt);
							txtSender.Text = pT1size_inATRs.ToString("0.0");
						}else{
							pT1size_inTicks = int.Parse(intxt);
							txtSender.Text = pT1size_inTicks.ToString("0");
						}
					}
					else if(txtSender.Name.Contains("T2")) {
						if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR){
							pT2size_inATRs = double.Parse(intxt);
							txtSender.Text = pT2size_inATRs.ToString("0.0");
						}else{
							pT2size_inTicks = int.Parse(intxt);
							txtSender.Text = pT2size_inTicks.ToString("0");
						}
					}
				}else{
					if(txtSender.Name.Contains("ATR")) txtSender.Text = pATRperiod.ToString("0");
					else if(txtSender.Name.Contains("SL")) txtSender.Text = pSLsize_inTicks.ToString("0");
					else if(txtSender.Name.Contains("T1")) txtSender.Text = pT1size_inTicks.ToString("0");
					else if(txtSender.Name.Contains("T2")) txtSender.Text = pT2size_inTicks.ToString("0");
				}
				txtSender.SelectionStart = Math.Min(txtSender.Text.Length,cursor_location);
            }            
			#endregion
		}
		private Grid createTradePlan_Grid(string id)
        {
			#region Grid maker
			const int rHeight = 26;

			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(100) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(50) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });

			if(id == "ATRperiod"){
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight/2) });
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight/2) });
				label_ATRPeriod = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "    ATR period: "};
				label_ATRPeriod.SetValue(Grid.ColumnProperty, 0);
				label_ATRPeriod.SetValue(Grid.RowProperty, 0);
				label_ATRPeriod.SetValue(Grid.RowSpanProperty, 2);
				nudATRperiod = new TextBox() { Name = "TradePlan_ATRPeriod" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
				nudATRperiod.Text        = pATRperiod.ToString();
				nudATRperiod.KeyDown    += menuTxtbox_KeyDown;
				nudATRperiod.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
//					Print("Intxt: "+
					//var intxt = val.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
					int num = pATRperiod + (e.Delta>0 ? 1 : -1);
					bool isInRange = num>=1 && num<=100;
					if(isInRange){
						pATRperiod   = num;
						nudATRperiod.Text = num.ToString("0");
						InformUserAboutRecalculation();
						ForceRefresh();
					}
				};
				nudATRperiod.SetValue(Grid.ColumnProperty, 1);
				nudATRperiod.SetValue(Grid.RowProperty, 0);
				nudATRperiod.SetValue(Grid.RowSpanProperty, 4);

//				Button cmdup1 = new Button() { Name = id+"cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
//				Button cmddw1 = new Button() { Name = id+"cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
//				cmdup1.Click += cmdupdw_Click;
//				cmdup1.SetValue(Grid.ColumnProperty, 2);
//				cmdup1.SetValue(Grid.RowProperty, 0);
//				cmddw1.Click += cmdupdw_Click;
//				cmddw1.SetValue(Grid.ColumnProperty, 2);
//				cmddw1.SetValue(Grid.RowProperty, 1);

				grid.Children.Add(label_ATRPeriod);
	            grid.Children.Add(nudATRperiod);
//	            grid.Children.Add(cmdup1);
//	            grid.Children.Add(cmddw1);
			}else if (id.StartsWith("SLsize")){
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
				label_SLsize = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "SL Size: " };
				label_SLsize.SetValue(Grid.ColumnProperty, 0);
				label_SLsize.SetValue(Grid.RowProperty, 0);
				label_SLsize.SetValue(Grid.RowSpanProperty, 2);
				nudSLsize = new TextBox() { Name = "TradePlan_SLsize" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
				if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR)
					nudSLsize.Text = pSLsize_inATRs.ToString("0.0");
				else
					nudSLsize.Text = pSLsize_inTicks.ToString("0");
				nudSLsize.KeyDown     += menuTxtbox_KeyDown;
				nudSLsize.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
					#region
					double num = 0;//Convert.ToDouble(val);
					if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR){
						num = pSLsize_inATRs + (e.Delta>0 ? 0.1 : -0.1);
					}else{
						num = pSLsize_inTicks + (e.Delta>0 ? 1 : -1);
					}

					bool isInRange = num>=0 && num<=100;
					if(isInRange){
						if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR){
							this.pSLsize_inATRs = num;
							nudSLsize.Text = num.ToString("0.0");
						}else{
							this.pSLsize_inTicks = Convert.ToInt32(num);
							nudSLsize.Text = num.ToString("0");
						}
			            ChartControl.InvalidateVisual();
					}
					#endregion
				};
				nudSLsize.SetValue(Grid.ColumnProperty, 1);
				nudSLsize.SetValue(Grid.RowProperty, 0);
				nudSLsize.SetValue(Grid.RowSpanProperty, 2);
				grid.Children.Add(label_SLsize);
	            grid.Children.Add(nudSLsize);
			}else if (id=="T1size"){
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
				label_T1size = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "          T1 Size: " };
				label_T1size.SetValue(Grid.ColumnProperty, 0);
				label_T1size.SetValue(Grid.RowProperty, 0);
				label_T1size.SetValue(Grid.RowSpanProperty, 2);

				nudT1size = new TextBox() { Name = "TradePlan_T1size" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
				if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR)
					nudT1size.Text = pT1size_inATRs.ToString("0.0");
				else
					nudT1size.Text = pT1size_inTicks.ToString("0");
				nudT1size.KeyDown     += menuTxtbox_KeyDown;
				nudT1size.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
					#region
					double num = 0;//Convert.ToDouble(val);
					if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR)
						num = pT1size_inATRs + (e.Delta>0 ? 0.1 : -0.1);
					else
						num = pT1size_inTicks + (e.Delta>0 ? 1 : -1);

					bool isInRange = num>=0 && num<=100;
					if(isInRange){
						if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR){
							this.pT1size_inATRs = num;
							nudT1size.Text = num.ToString("0.0");
						}else{
							this.pT1size_inTicks = Convert.ToInt32(num);
							nudT1size.Text = num.ToString("0");
						}
			            ChartControl.InvalidateVisual();
					}
					#endregion
				};
				nudT1size.SetValue(Grid.ColumnProperty, 1);
				nudT1size.SetValue(Grid.RowProperty, 0);
				nudT1size.SetValue(Grid.RowSpanProperty, 2);
				grid.Children.Add(label_T1size);
	            grid.Children.Add(nudT1size);
			}else if (id=="T2size"){
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
				label_T2size = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "          T2 Size: " };
				label_T2size.SetValue(Grid.ColumnProperty, 0);
				label_T2size.SetValue(Grid.RowProperty, 0);
				label_T2size.SetValue(Grid.RowSpanProperty, 2);

				nudT2size = new TextBox() { Name = "TradePlan_T2size" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
				if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR)
					nudT2size.Text = pT2size_inATRs.ToString("0.0");
				else
					nudT2size.Text = pT2size_inTicks.ToString("0");
				nudT2size.KeyDown     += menuTxtbox_KeyDown;
				nudT2size.MouseWheel += delegate(object sender, System.Windows.Input.MouseWheelEventArgs e){
					#region
					double num = 0;//Convert.ToDouble(val);
					if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR)
						num = pT2size_inATRs + (e.Delta>0 ? 0.1 : -0.1);
					else
						num = pT2size_inTicks + (e.Delta>0 ? 1 : -1);

					bool isInRange = num>=0 && num<=100;
					if(isInRange){
						if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR){
							this.pT2size_inATRs = num;
							nudT2size.Text = num.ToString("0.0");
						}else{
							this.pT2size_inTicks = Convert.ToInt32(num);
							nudT2size.Text = num.ToString("0");
						}
			            ChartControl.InvalidateVisual();
					}
					#endregion
				};
				nudT2size.SetValue(Grid.ColumnProperty, 1);
				nudT2size.SetValue(Grid.RowProperty, 0);
				nudT2size.SetValue(Grid.RowSpanProperty, 2);
				grid.Children.Add(label_T2size);
	            grid.Children.Add(nudT2size);
			}
			return grid;
			#endregion
		}
		private void SetLabelsAndTextBoxValues_ATRorTicks(){
			if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR){
				label_SLsize.Content = "   SL Size ATRs: ";
				label_T1size.Content = "   T1 Size ATRs: ";
				label_T2size.Content = "   T2 Size ATRs: ";
				nudSLsize.Text = pSLsize_inATRs.ToString("0.0");
				nudT1size.Text = pT1size_inATRs.ToString("0.0");
				nudT2size.Text = pT2size_inATRs.ToString("0.0");
			}else{
				label_SLsize.Content = "  SL Size Ticks: ";
				label_T1size.Content = "  T1 Size Ticks: ";
				label_T2size.Content = "  T2 Size Ticks: ";
				nudSLsize.Text = pSLsize_inTicks.ToString("0");
				nudT1size.Text = pT1size_inTicks.ToString("0");
				nudT2size.Text = pT2size_inTicks.ToString("0");
			}
		}
		private void InformUserAboutRecalculation(){
			miRecalculate1.Background = Brushes.Yellow;
			miRecalculate1.FontWeight = FontWeights.Bold;
			miRecalculate1.FontStyle = FontStyles.Italic;
			miRecalculate2.Background = Brushes.Yellow;
			miRecalculate2.FontWeight = FontWeights.Bold;
			miRecalculate2.FontStyle = FontStyles.Italic;
			miRecalculate3.Background = Brushes.Yellow;
			miRecalculate3.FontWeight = FontWeights.Bold;
			miRecalculate3.FontStyle = FontStyles.Italic;
		}
		private void ResetRecalculationUI(){
			DSA_Sensitivity_Changed = false;
			miRecalculate1.FontWeight = FontWeights.Normal;
			miRecalculate1.FontStyle = FontStyles.Normal;
			miRecalculate1.Background = null;
			miRecalculate2.FontWeight = FontWeights.Normal;
			miRecalculate2.FontStyle = FontStyles.Normal;
			miRecalculate2.Background = null;
			miRecalculate3.FontWeight = FontWeights.Normal;
			miRecalculate3.FontStyle = FontStyles.Normal;
			miRecalculate3.Background = null;
		}
//===========================================================================================
		#region -- addToolBar --
        private void addToolBar()
        {
			gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
			gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
			gLabel = new Label();//#RJBug001

			MenuControlContainer = new Menu { Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Center };
			MenuControl = new MenuItem {Name="NSDF"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Black, Header = pButtonText, Foreground = Brushes.Black, Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);

			#region -- DeltaForce Menu --
			MenuItem miDeltaForceSignals = new MenuItem { Header = "DeltaForce Signals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			miAlgorithm = new MenuItem { Header = "Algorithm:   " + pAlgorithm.ToString().ToUpper(), Name = "Algorithm", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
			#region
			miAlgorithm.Click += delegate(object o, RoutedEventArgs e){
				if(pAlgorithm == ARC_DeltaForce_Algorithm.Price) pAlgorithm = ARC_DeltaForce_Algorithm.NetDelta;
				else if(pAlgorithm == ARC_DeltaForce_Algorithm.NetDelta) pAlgorithm = ARC_DeltaForce_Algorithm.Price;
				miAlgorithm.Header = "Algorithm:   " + pAlgorithm.ToString().ToUpper();
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miAlgorithm.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				if(pAlgorithm == ARC_DeltaForce_Algorithm.Price) pAlgorithm = ARC_DeltaForce_Algorithm.NetDelta;
				else if(pAlgorithm == ARC_DeltaForce_Algorithm.NetDelta) pAlgorithm = ARC_DeltaForce_Algorithm.Price;
				miAlgorithm.Header = "Algorithm:   " + pAlgorithm.ToString().ToUpper();
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miDeltaForceSignals.Items.Add(miAlgorithm);
			#endregion
//========================================================================================================================
			miShowHide_Longs = new MenuItem { Header = pShowLongs ? "Hide Longs" : "Show Longs", Name = "ShowLongs"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miShowHide_Longs.Click += delegate (object o, RoutedEventArgs e){
				pShowLongs = !pShowLongs;
				miShowHide_Longs.Header = (pShowLongs ? "Hide Longs":"Show Longs");
				ForceRefresh();
			};
			miShowHide_Longs.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pShowLongs = !pShowLongs;
				miShowHide_Longs.Header = (pShowLongs ? "Hide Longs":"Show Longs");
				ForceRefresh();
			};
			miDeltaForceSignals.Items.Add(miShowHide_Longs);
			#endregion
//========================================================================================================================
			miShowHide_Shorts = new MenuItem { Header = pShowShorts ? "Hide Shorts" : "Show Shorts", Name = "ShowShorts"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miShowHide_Shorts.Click += delegate (object o, RoutedEventArgs e){
				pShowShorts = !pShowShorts;
				miShowHide_Shorts.Header = (pShowShorts ? "Hide Shorts":"Show Shorts");
				ForceRefresh();
			};
			miShowHide_Shorts.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pShowShorts = !pShowShorts;
				miShowHide_Shorts.Header = (pShowShorts ? "Hide Shorts":"Show Shorts");
				ForceRefresh();
			};
			miDeltaForceSignals.Items.Add(miShowHide_Shorts);
			#endregion
//========================================================================================================================
			miShowHide_RacingStripes = new MenuItem { Header = pShowRacingStripes ? "Hide Racing Stripes" : "Show Racing Stripes", Name = "ShowRacingStripes"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miShowHide_RacingStripes.Click += delegate (object o, RoutedEventArgs e){
				pShowRacingStripes = !pShowRacingStripes;
				miShowHide_RacingStripes.Header = (pShowRacingStripes ? "Hide Racing Stripes":"Show Racing Stripes");
				ForceRefresh();
			};
			miShowHide_RacingStripes.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pShowRacingStripes = !pShowRacingStripes;
				miShowHide_RacingStripes.Header = (pShowRacingStripes ? "Hide Racing Stripes":"Show Racing Stripes");
				ForceRefresh();
			};
			miDeltaForceSignals.Items.Add(miShowHide_RacingStripes);
			#endregion
//========================================================================================================================
			miPermitContinuingTrade = new MenuItem { Header = pPermitContinuingTrade ? "Continuing Trade ON" : "Continuing Trade OFF", Name = "ContinuingTrade"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miPermitContinuingTrade.Click += delegate (object o, RoutedEventArgs e){
				pPermitContinuingTrade = !pPermitContinuingTrade;
				miPermitContinuingTrade.Header = (pPermitContinuingTrade ? "Continuing Trade ON" : "Continuing Trade OFF");
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miPermitContinuingTrade.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pPermitContinuingTrade = !pPermitContinuingTrade;
				miPermitContinuingTrade.Header = (pPermitContinuingTrade ? "Continuing Trade ON" : "Continuing Trade OFF");
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miDeltaForceSignals.Items.Add(miPermitContinuingTrade);
			#endregion
//========================================================================================================================
			miApplyHistoFilter = new MenuItem { Header = pFilterOnHisto ? "Histo filter ON" : "Histo filter OFF", Name = "FilterOnHisto"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miApplyHistoFilter.Click += delegate (object o, RoutedEventArgs e){
				pFilterOnHisto = !pFilterOnHisto;
				miApplyHistoFilter.Header = (pFilterOnHisto ? "Histo filter ON" : "Histo filter OFF");
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miApplyHistoFilter.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pFilterOnHisto = !pFilterOnHisto;
				miApplyHistoFilter.Header = (pFilterOnHisto ? "Histo filter ON" : "Histo filter OFF");
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miDeltaForceSignals.Items.Add(miApplyHistoFilter);
			#endregion
//========================================================================================================================
			miDeltaForceSignals.Items.Add(new Separator());
//========================================================================================================================
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", Name = "recalc", Foreground = Brushes.Black, HorizontalAlignment = HorizontalAlignment.Center };
			#region
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			miDeltaForceSignals.Items.Add(miRecalculate1);
			#endregion
//========================================================================================================================
			var miDeltaForceTradePlans = new MenuItem { Header = "Trade Plans", Name="subm_TradePlans"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
//========================================================================================================================
			miShowHide_LongTradePlan = new MenuItem { Header  = pShowLongTradePlans  ? "Long Plans ON"  : "Long Plans OFF", Name = "ShowLTPlan"+uID,  Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miShowHide_LongTradePlan.Click += delegate (object o, RoutedEventArgs e){
				pShowLongTradePlans = !pShowLongTradePlans;
				miShowHide_LongTradePlan.Header = (pShowLongTradePlans ? "Long Plans ON" : "Long Plans OFF");
				ForceRefresh();
			};
			miShowHide_LongTradePlan.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pShowLongTradePlans = !pShowLongTradePlans;
				miShowHide_LongTradePlan.Header = (pShowLongTradePlans ? "Long Plans ON" : "Long Plans OFF");
				ForceRefresh();
			};
			miDeltaForceTradePlans.Items.Add(miShowHide_LongTradePlan);
			#endregion
//========================================================================================================================
			miShowHide_ShortTradePlan = new MenuItem { Header = pShowShortTradePlans ? "Short Plans ON" : "Short Plans OFF", Name = "ShowSTPlan"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miShowHide_ShortTradePlan.Click += delegate (object o, RoutedEventArgs e){
				pShowShortTradePlans = !pShowShortTradePlans;
				miShowHide_ShortTradePlan.Header = (pShowShortTradePlans ? "Short Plans ON" : "Short Plans OFF");
				ForceRefresh();
			};
			miShowHide_ShortTradePlan.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pShowShortTradePlans = !pShowShortTradePlans;
				miShowHide_ShortTradePlan.Header = (pShowShortTradePlans ? "Short Plans ON" : "Short Plans OFF");
				ForceRefresh();
			};
			miDeltaForceTradePlans.Items.Add(miShowHide_ShortTradePlan);
			#endregion
//========================================================================================================================
			miShowEntry = new MenuItem { Header = pShowEntry ? "Show Entry ON" : "Show Entry OFF", Name = "showEntry"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miShowEntry.Click += delegate (object o, RoutedEventArgs e){
				pShowEntry = !pShowEntry;
				miShowEntry.Header = (pShowEntry ? "Show Entry ON" : "Show Entry OFF");
				ForceRefresh();
			};
			miShowEntry.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pShowEntry = !pShowEntry;
				miShowEntry.Header = (pShowEntry ? "Show Entry ON" : "Show Entry OFF");
				ForceRefresh();
			};
			miDeltaForceTradePlans.Items.Add(miShowEntry);
			#endregion
//========================================================================================================================
			miShowT2 = new MenuItem { Header = pShowT2 ? "Show T2 ON" : "Show T2 OFF", Name = "showT2"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miShowT2.Click += delegate (object o, RoutedEventArgs e){
				pShowT2 = !pShowT2;
				miShowT2.Header = (pShowT2 ? "Show T2 ON" : "Show T2 OFF");
				ForceRefresh();
			};
			miShowT2.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pShowT2 = !pShowT2;
				miShowT2.Header = (pShowT2 ? "Show T2 ON" : "Show T2 OFF");
				ForceRefresh();
			};
			miDeltaForceTradePlans.Items.Add(miShowT2);
			#endregion
//========================================================================================================================
			miShowT1 = new MenuItem { Header = pShowT1 ? "Show T1 ON" : "Show T1 OFF", Name = "showT1"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miShowT1.Click += delegate (object o, RoutedEventArgs e){
				pShowT1 = !pShowT1;
				miShowT1.Header = (pShowT1 ? "Show T1 ON" : "Show T1 OFF");
				ForceRefresh();
			};
			miShowT1.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pShowT1 = !pShowT1;
				miShowT1.Header = (pShowT1 ? "Show T1 ON" : "Show T1 OFF");
				ForceRefresh();
			};
			miDeltaForceTradePlans.Items.Add(miShowT1);
			#endregion
//========================================================================================================================
			miShowSL = new MenuItem { Header = pShowSL ? "Show SL ON" : "Show SL OFF", Name = "showSL"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			#region
			miShowSL.Click += delegate (object o, RoutedEventArgs e){
				pShowSL = !pShowSL;
				miShowSL.Header = (pShowSL ? "Show SL ON" : "Show SL OFF");
				ForceRefresh();
			};
			miShowSL.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				pShowSL = !pShowSL;
				miShowSL.Header = (pShowSL ? "Show SL ON" : "Show SL OFF");
				ForceRefresh();
			};
			miDeltaForceTradePlans.Items.Add(miShowSL);
			#endregion
//========================================================================================================================
			miTPLabelSide = new MenuItem { Header = "Line Label side:   "+pTPLabelSide.ToString(), Name = "LineLabelSide"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miTPLabelSide.Click += delegate (object o, RoutedEventArgs e){
				#region
				if (pTPLabelSide == ARC_DeltaForce_TPLabelSide.Left) {
					this.pTPLabelSide = ARC_DeltaForce_TPLabelSide.Right;
					miTPLabelSide.Header = "Line Label side:   "+pTPLabelSide.ToString();
				} else {
					this.pTPLabelSide = ARC_DeltaForce_TPLabelSide.Left;
					miTPLabelSide.Header = "Line Label side:   "+pTPLabelSide.ToString();
				}
				ForceRefresh();
				#endregion
			};
			miTPLabelSide.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region
				if (pTPLabelSide == ARC_DeltaForce_TPLabelSide.Left) {
					this.pTPLabelSide = ARC_DeltaForce_TPLabelSide.Right;
					miSLTPCalcBasis.Header = "Line Label side:   "+pTPLabelSide.ToString();
				} else {
					this.pTPLabelSide = ARC_DeltaForce_TPLabelSide.Left;
					miTPLabelSide.Header = "Line Label side:   "+pTPLabelSide.ToString();
				}
				ForceRefresh();
				#endregion
			};
			miDeltaForceTradePlans.Items.Add(miTPLabelSide);
//========================================================================================================================
			miDeltaForceTradePlans.Items.Add(new Separator());

			miSLTPCalcBasis = new MenuItem { Header = "SL/Tgt based on:   "+SLTP_CalcBasis.ToString(), Name = "SLTP_CalcBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miSLTPCalcBasis.Click += delegate (object o, RoutedEventArgs e){
				#region
				if (miSLTPCalcBasis.Header.ToString().EndsWith("ATR")) {
					this.SLTP_CalcBasis = ARC_DeltaForce_SLTP_CalcBasis.Ticks;
					miSLTPCalcBasis.Header = miSLTPCalcBasis.Header.ToString().Replace("ATR","Ticks");
				} else {
					this.SLTP_CalcBasis = ARC_DeltaForce_SLTP_CalcBasis.ATR;
					miSLTPCalcBasis.Header = miSLTPCalcBasis.Header.ToString().Replace("Ticks","ATR");
				}
				SetLabelsAndTextBoxValues_ATRorTicks();
				ForceRefresh();
				#endregion
			};
			miSLTPCalcBasis.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				#region
				if (miSLTPCalcBasis.Header.ToString().EndsWith("ATR")) {
					this.SLTP_CalcBasis = ARC_DeltaForce_SLTP_CalcBasis.Ticks;
					miSLTPCalcBasis.Header = miSLTPCalcBasis.Header.ToString().Replace("ATR","Ticks");
				} else {
					this.SLTP_CalcBasis = ARC_DeltaForce_SLTP_CalcBasis.ATR;
					miSLTPCalcBasis.Header = miSLTPCalcBasis.Header.ToString().Replace("Ticks","ATR");
				}
				SetLabelsAndTextBoxValues_ATRorTicks();
				ForceRefresh();
				#endregion
			};
			miDeltaForceTradePlans.Items.Add(miSLTPCalcBasis);

			miDeltaForceTradePlans.Items.Add(createTradePlan_Grid("ATRperiod"));
			if(SLTP_CalcBasis == ARC_DeltaForce_SLTP_CalcBasis.ATR){
				miDeltaForceTradePlans.Items.Add(createTradePlan_Grid("SLsize"));
				miDeltaForceTradePlans.Items.Add(createTradePlan_Grid("T1size"));
				miDeltaForceTradePlans.Items.Add(createTradePlan_Grid("T2size"));
			}else{
				miDeltaForceTradePlans.Items.Add(createTradePlan_Grid("SLsize"));
				miDeltaForceTradePlans.Items.Add(createTradePlan_Grid("T1size"));
				miDeltaForceTradePlans.Items.Add(createTradePlan_Grid("T2size"));
			}
			SetLabelsAndTextBoxValues_ATRorTicks();
//========================================================================================================================
			miDeltaForceTradePlans.Items.Add(new Separator());
//========================================================================================================================
			miRecalculate2 = new MenuItem { Header = "RE-CALCULATE", Name = "recalc", Foreground = Brushes.Black, HorizontalAlignment = HorizontalAlignment.Center };
			#region
			miRecalculate2.Click += delegate (object o, RoutedEventArgs e){
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			miDeltaForceTradePlans.Items.Add(miRecalculate2);
			#endregion
//========================================================================================================================

			MenuControl.Items.Add(miDeltaForceSignals);
			MenuControl.Items.Add(miDeltaForceTradePlans);

//========================================================================================================================
			miShowNetDeltaHeatMap = new MenuItem { Header = pShowNetDeltaHeatMap ? "HeatMap ON" : "HeatMap OFF", Name = "pShowNetDeltaHeatMap"+uID, FontWeight = FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowNetDeltaHeatMap.Click += delegate(object o, RoutedEventArgs e){
				pShowNetDeltaHeatMap = !pShowNetDeltaHeatMap;
				miShowNetDeltaHeatMap.Header = pShowNetDeltaHeatMap ? "HeatMap ON" : "HeatMap OFF";
				ForceRefresh();
			};
			MenuControl.Items.Add(miShowNetDeltaHeatMap);

			miUseSkinnyHeatmapBars = new MenuItem { Header = pUseSkinnyHeatmapBars ? "Skinny Histo ON" : "Skinny Histo OFF", Name = "pUseSkinnyHeatmapBars"+uID, FontWeight = FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miUseSkinnyHeatmapBars.Click += delegate(object o, RoutedEventArgs e){
				pUseSkinnyHeatmapBars = !pUseSkinnyHeatmapBars;
				miUseSkinnyHeatmapBars.Header = pUseSkinnyHeatmapBars ? "Skinny Histo ON" : "Skinny Histo OFF";
				ForceRefresh();
			};
			MenuControl.Items.Add(miUseSkinnyHeatmapBars);

			miShowNetDeltaNumber = new MenuItem { Header = pShowNetDeltaNumberOnBar ? "Net Delta ON" : "Net Delta OFF", Name = "pShowNetDeltaNumberOnBar"+uID, FontWeight = FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowNetDeltaNumber.Click += delegate(object o, RoutedEventArgs e){
				pShowNetDeltaNumberOnBar = !pShowNetDeltaNumberOnBar;
				miShowNetDeltaNumber.Header = pShowNetDeltaNumberOnBar ? "Net Delta ON" : "Net Delta OFF";
				ForceRefresh();
			};
			MenuControl.Items.Add(miShowNetDeltaNumber);

//			miP = new MenuItem { Header = iShowTotalVolumeInHeatMap ? "Tot Vol ON" : "Tot Vol OFF", Name = "pShowTotVolumeInHeatMap", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miP.Click += DeltaForceMenu_Click;
//			miDeltaForceSignals.Items.Add(miP);

//			miP = new MenuItem { Header = iShowTotalVolumeAsPct ? "Tot Vol% ON" : "Tot Vol% OFF", Name = "pShowTotVolAsPct", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miP.Click += DeltaForceMenu_Click;
//			miDeltaForceSignals.Items.Add(miP);

//			miP = new MenuItem { Header = iShowImbalance ? "Bid/Ask Imbalances ON" : "Bid/Ask Imbalances OFF", Name = "pShowImbalance", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miP.Click += DeltaForceMenu_Click;
//			miDeltaForceSignals.Items.Add(miP);

//			miP = new MenuItem { Header = iShowImbalanceA ? "Bid/Ask Imbalances Dots ON" : "Bid/Ask Imbalances Dots OFF", Name = "pShowImbalanceA", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miP.Click += DeltaForceMenu_Click;
//			miDeltaForceSignals.Items.Add(miP);

//			miP = new MenuItem { Header = iShowImbalanceText ? "Bid/Ask Imbalances Text ON" : "Bid/Ask Imbalances Text OFF", Name = "pShowImbalanceText", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miP.Click += DeltaForceMenu_Click;
//			miDeltaForceSignals.Items.Add(miP);

//			miP = new MenuItem { Header = iShowBlocks ? "Block Trades ON" : "Block Trades OFF", Name = "pShowBlocks", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miP.Click += DeltaForceMenu_Click;
//			miDeltaForceSignals.Items.Add(miP);

//			miP = new MenuItem { Header = iTTEnabled ? "Trapped Trader ON" : "Trapped Trader OFF", Name = "pTTEnabled", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miP.Click += DeltaForceMenu_Click;
//			miDeltaForceSignals.Items.Add(miP);

//			miP = new MenuItem { Header = iDDEnabled ? "Delta Divergence ON" : "Delta Divergence OFF", Name = "pDDEnabled", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miP.Click += DeltaForceMenu_Click;
//			miDeltaForceSignals.Items.Add(miP);

//			miP = new MenuItem { Header = iCCEnabled ? "Combined Signal ON" : "Combined Signal OFF", Name = "pCCEnabled", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miP.Click += DeltaForceMenu_Click;
//			miDeltaForceSignals.Items.Add(miP);

			//------------------

			#endregion

			#region -- Inventory Menu --
//			MenuItem miInventory = new MenuItem { Header = "Inventory", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

//			MenuItem miInventory1 = new MenuItem { Header = iInventoryEnabled ? "Inventory ON" : "Inventory OFF", Name = "pInventoryEnabled", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miInventory1.Click += Inventory_Click;
//			miInventory.Items.Add(miInventory1);

//			//------------------

//			MenuControl.Items.Add(miInventory);
			#endregion

			#region -- Zones Menu --
//			MenuItem miZones = new MenuItem { Header = "Zones", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

//			MenuItem miZones1 = new MenuItem { Header = iZonesEnabled ? "Zones ON" : "Zones OFF", Name = "pZonesEnabled", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miZones1.Click += ZoneMenu_Click;
//			miZones.Items.Add(miZones1);

//			MenuItem miZones2 = new MenuItem { Header = iShowDemandZones ? "Demand Zones ON" : "Demand Zones OFF", Name = "pShowDemandZones", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miZones2.Click += ZoneMenu_Click;
//			miZones.Items.Add(miZones2);

//			MenuItem miZones3 = new MenuItem { Header = iShowSupplyZones ? "Supply Zones ON" : "Supply Zones OFF", Name = "pShowSupplyZones", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miZones3.Click += ZoneMenu_Click;
//			miZones.Items.Add(miZones3);

//			MenuItem miZones4 = new MenuItem { Header = iShowBrokenZones ? "Broken Zones ON" : "Broken Zones OFF", Name = "pShowBrokenZones", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miZones4.Click += ZoneMenu_Click;
//			miZones.Items.Add(miZones4);

//			MenuItem miZones5 = new MenuItem { Header = iShowFreshZones ? "Fresh Zones ON" : "Fresh Zones OFF", Name = "pShowFreshZones", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miZones5.Click += ZoneMenu_Click;
//			miZones.Items.Add(miZones5);

//			MenuItem miZones6 = new MenuItem { Header = iShowTestedZones ? "Tested Zones ON" : "Tested Zones OFF", Name = "pShowTestedZones", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miZones6.Click += ZoneMenu_Click;
//			miZones.Items.Add(miZones6);

//			MenuItem miZones7 = new MenuItem { Header = iZonesTSEnabled ? "Tested Shading ON" : "Tested Shading OFF", Name = "pZonesTSEnabled", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miZones7.Click += ZoneMenu_Click;
//			miZones.Items.Add(miZones7);

//			MenuItem miZones8 = new MenuItem { Header = iZonesTMEnabled ? "Tested Marker ON" : "Tested Marker OFF", Name = "pZonesTMEnabled", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miZones8.Click += ZoneMenu_Click;
//			miZones.Items.Add(miZones8);

//			MenuItem miZones9 = new MenuItem { Header = iExtendZonesRight ? "Extend Right ON" : "Extend Right OFF", Name = "pExtendZonesRight", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miZones9.Click += ZoneMenu_Click;
//			miZones.Items.Add(miZones9);

//			MenuItem miZones10 = new MenuItem { Header = "Restore All Zones", Name = "RestoreAllZones", Foreground = Brushes.Black, StaysOpenOnClick = true };
//			miZones10.Click += ZoneItem_Click;
//			miZones.Items.Add(miZones10);

			//------------------

//			if (iPCalcM != "Minute") MenuControl.Items.Add(miZones);
			#endregion

			#region -- Avg Stop Loss Calculators Menu --
//			MenuItem miAvgStopCalcs = new MenuItem { Header = "Avg Stop Loss Calculators", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
//			miAvgStopCalcs.Items.Add(miAvgStopFirstTouch = new MenuItem { Header = "First Touch: N/A", Name = "avgStopFirstTouch", Foreground = Brushes.Black });

//			//------------------

//			if (iPCalcM != "Minute") MenuControl.Items.Add(miAvgStopCalcs);
			#endregion

//----------------------------------------------------------------------------------------------
			#region -- menu Delta Spread Analysis --
			var miDeltaSpreadAnalysisMenu = new MenuItem { Header = "Delta Spread Analysis", Foreground = Brushes.Black, FontWeight = FontWeights.Normal  };
//----------------------------------------------------------------------------------------------
			miShow_DSASignal = new MenuItem { Header = (pShow_DSASignal ? "Hide on-bar signals":"Show on-bar signals"), Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
			miShow_DSASignal.Click += delegate (object o, RoutedEventArgs e){
				pShow_DSASignal = !pShow_DSASignal;
				miShow_DSASignal.Header = (pShow_DSASignal ? "Hide on-bar signals":"Show on-bar signals");
				ForceRefresh();
			};
			miShow_DSASignal.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				pShow_DSASignal = !pShow_DSASignal;
				miShow_DSASignal.Header = (pShow_DSASignal ? "Hide on-bar signals":"Show on-bar signals");
				ForceRefresh();
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miShow_DSASignal);
//----------------------------------------------------------------------------------------------
			var hdr = "Signal sensitivity: ";
			miDSA_Sensitivity = new MenuItem { Header = hdr+pDSA_Sensitivity.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true  };
			miDSA_Sensitivity.Click += delegate (object o, RoutedEventArgs e){
				if(pDSA_Sensitivity < 10) this.pDSA_Sensitivity++; else pDSA_Sensitivity = 1;
				miDSA_Sensitivity.Header = hdr+pDSA_Sensitivity.ToString();
				DSA_Sensitivity_Changed = true;
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miDSA_Sensitivity.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if(pDSA_Sensitivity < 10) this.pDSA_Sensitivity++;
				}else{
					if(pDSA_Sensitivity >1) this.pDSA_Sensitivity--;
				}
				miDSA_Sensitivity.Header = hdr+pDSA_Sensitivity.ToString();
				DSA_Sensitivity_Changed = true;
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miDSA_Sensitivity);
//----------------------------------------------------------------------------------------------
			var hdr1 = "Op. on price bar: ";
			miDSA_OpacityOnBar = new MenuItem { Header = hdr1+pDSA_OpacityOnPriceBar.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true  };
			miDSA_OpacityOnBar.Click += delegate (object o, RoutedEventArgs e){
				if(pDSA_OpacityOnPriceBar <= 90) this.pDSA_OpacityOnPriceBar+= 10; else pDSA_OpacityOnPriceBar = 0;
				miDSA_OpacityOnBar.Header = hdr1+pDSA_OpacityOnPriceBar.ToString();
				ForceRefresh();
			};
			miDSA_OpacityOnBar.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if(pDSA_OpacityOnPriceBar < 100) this.pDSA_OpacityOnPriceBar++;
				}else{
					if(pDSA_OpacityOnPriceBar > 0) this.pDSA_OpacityOnPriceBar--;
				}
				miDSA_OpacityOnBar.Header = hdr1+pDSA_OpacityOnPriceBar.ToString();
				ForceRefresh();
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miDSA_OpacityOnBar);
//----------------------------------------------------------------------------------------------
			var hdr2 = "Op. on heat map: ";
			miDSA_OpacityOnHeatMapHisto = new MenuItem { Header = hdr2+pDSA_OpacityOnHeatMap.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true  };
			miDSA_OpacityOnHeatMapHisto.Click += delegate (object o, RoutedEventArgs e){
				if(pDSA_OpacityOnHeatMap <= 90) this.pDSA_OpacityOnHeatMap+= 10; else pDSA_OpacityOnHeatMap = 0;
				miDSA_OpacityOnHeatMapHisto.Header = hdr2+pDSA_OpacityOnHeatMap.ToString();
				ForceRefresh();
			};
			miDSA_OpacityOnHeatMapHisto.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if(pDSA_OpacityOnHeatMap < 100) this.pDSA_OpacityOnHeatMap++;
				}else{
					if(pDSA_OpacityOnHeatMap > 0) this.pDSA_OpacityOnHeatMap--;
				}
				miDSA_OpacityOnHeatMapHisto.Header = hdr2+pDSA_OpacityOnHeatMap.ToString();
				ForceRefresh();
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miDSA_OpacityOnHeatMapHisto);
			
//----------------------------------------------------------------------------------------------
			var hdr3 = "Outline width Heat Map: ";
			miDSA_OutlineWidthOnHeatMapHisto = new MenuItem { Header = hdr3+pDSA_HistoOutlineThickness.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true  };
			miDSA_OutlineWidthOnHeatMapHisto.Click += delegate (object o, RoutedEventArgs e){
				if(pDSA_HistoOutlineThickness <= 10) this.pDSA_HistoOutlineThickness+= 10; else pDSA_HistoOutlineThickness = 0;
				miDSA_OutlineWidthOnHeatMapHisto.Header = hdr3+pDSA_HistoOutlineThickness.ToString();
				ForceRefresh();
			};
			miDSA_OutlineWidthOnHeatMapHisto.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta>0) {
					if(pDSA_HistoOutlineThickness < 9) this.pDSA_HistoOutlineThickness++;
				}else{
					if(pDSA_HistoOutlineThickness > 1) this.pDSA_HistoOutlineThickness--;
				}
				miDSA_OutlineWidthOnHeatMapHisto.Header = hdr3+pDSA_HistoOutlineThickness.ToString();
				ForceRefresh();
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miDSA_OutlineWidthOnHeatMapHisto);
//========================================================================================================================
			miDeltaSpreadAnalysisMenu.Items.Add(new Separator());
//========================================================================================================================
			miRecalculate3 = new MenuItem { Header = "RE-CALCULATE", Name = "recalc", Foreground = Brushes.Black, HorizontalAlignment = HorizontalAlignment.Center };
			#region
			miRecalculate3.Click += delegate (object o, RoutedEventArgs e){
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			miDeltaSpreadAnalysisMenu.Items.Add(miRecalculate3);
			#endregion

//----------------------------------------------------------------------------------------------
			#endregion
			MenuControl.Items.Add(miDeltaSpreadAnalysisMenu);

			indytoolbar.Children.Add(MenuControlContainer);
        }

        #endregion

        private void Combo_KeyDown(object sender, KeyEventArgs e) { e.Handled = true; }

        #region private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
//        private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
//        {
//            e.Handled = true;
//            TextBox txtSender = sender as TextBox;

//            int keyVal = (int)e.Key;
//            int value = -1;
//            if (keyVal >= (int)Key.D0 && keyVal <= (int)Key.D9) value = keyVal - (int)Key.D0;
//            else if (keyVal >= (int)Key.NumPad0 && keyVal <= (int)Key.NumPad9) value = keyVal - (int)Key.NumPad0;

//            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);

//            if (isNumeric || e.Key == Key.Back)
//            {
//                string newText = value != -1 ? value.ToString() : "";
//                int tbPosition = txtSender.SelectionStart;
//                txtSender.Text = txtSender.SelectedText == "" ? txtSender.Text.Insert(tbPosition, newText) : txtSender.Text.Replace(txtSender.SelectedText, newText);
//                txtSender.Select(tbPosition + 1, 0);
//            }
//        }
        #endregion

        #region private void NumericUpDownValueChanged(object TextChangedEventArgs, EventArgs e) 
        private void NumericUpDownValueChanged(object sender, TextChangedEventArgs e)
        {
            //update CP NUD values with Min/Max verif
            int nudPCS1i = Math.Min(23, Math.Max(0, IntParseFast(nudPCS1.Text)));
            nudPCS1.Text = nudPCS1i.ToString();
            int nudPCS2i = Math.Min(59, Math.Max(0, IntParseFast(nudPCS2.Text)));
            nudPCS2.Text = nudPCS2i.ToString();
            int nudPCS3i = Math.Min(1440, Math.Max(1, IntParseFast(nudPCS3.Text)));
            nudPCS3.Text = nudPCS3i.ToString();
        }
        #endregion

        #region private void cmdupdw_Click(object sender, RoutedEventArgs e)
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
            Button cmd = sender as Button;
            if (cmd.Name.Contains("CRV1cmdup")) nudCRV1.Text = (Math.Min(99999, IntParseFast(nudCRV1.Text) + 1)).ToString();
            else if (cmd.Name.Contains("CRV1cmddw")) nudCRV1.Text = (Math.Max(1, IntParseFast(nudCRV1.Text) - 1)).ToString();
            else if (cmd.Name.Contains("CRV2cmdup")) nudCRV2.Text = (Math.Min(99999, IntParseFast(nudCRV2.Text) + 1)).ToString();
            else if (cmd.Name.Contains("CRV2cmddw")) nudCRV2.Text = (Math.Max(1, IntParseFast(nudCRV2.Text) - 1)).ToString();

            else if (cmd.Name.Contains("MST1cmdup")) nudMST1.Text = (Math.Min(99999, IntParseFast(nudMST1.Text) + 1)).ToString();
            else if (cmd.Name.Contains("MST1cmddw")) nudMST1.Text = (Math.Max(0, IntParseFast(nudMST1.Text) - 1)).ToString();
            else if (cmd.Name.Contains("MST2cmdup")) nudMST2.Text = (Math.Min(99999, IntParseFast(nudMST2.Text) + 1)).ToString();
            else if (cmd.Name.Contains("MST2cmddw")) nudMST2.Text = (Math.Max(1, IntParseFast(nudMST2.Text) - 1)).ToString();

            else if (cmd.Name.Contains("VA1cmdup")) nudVA1.Text = (Math.Min(99999, IntParseFast(nudVA1.Text)) + 1).ToString();
            else if (cmd.Name.Contains("VA1cmddw")) nudVA1.Text = (Math.Max(1, IntParseFast(nudVA1.Text) - 1)).ToString();
            else if (cmd.Name.Contains("VA2cmdup")) nudVA2.Text = (Math.Min(99999, IntParseFast(nudVA2.Text)) + 1).ToString();
            else if (cmd.Name.Contains("VA2cmddw")) nudVA2.Text = (Math.Max(1, IntParseFast(nudVA2.Text) - 1)).ToString();
        }
        #endregion

        #region private void ZoneMenu_Click(object sender, EventArgs e)
//        private void ZoneMenu_Click(object sender, EventArgs e)
//        {
//            MenuItem item = sender as MenuItem;

//            #region -- pZonesEnabled --
//            if (item.Name == "pZonesEnabled")
//            {
//                if (item.Header.ToString().Contains("ON"))
//                {
//                    iZonesEnabled = false;
//                    item.Header = "Zones OFF";
//                }
//                else
//                {
//                    iZonesEnabled = true;
//                    item.Header = "Zones ON";
//                }
//            }
//            #endregion

//            #region -- pShowDemandZones --
//            else if (item.Name == "pShowDemandZones")
//            {
//                if (item.Header.ToString().Contains("ON"))
//                {
//                    iShowDemandZones = false;
//                    item.Header = "Demand Zones OFF";
//                }
//                else
//                {
//                    iShowDemandZones = true;
//                    item.Header = "Demand Zones ON";
//                }
//            }
//            #endregion

//            #region -- pShowSupplyZones --
//            else if (item.Name == "pShowSupplyZones")
//            {
//                if (item.Header.ToString().Contains("ON"))
//                {
//                    iShowSupplyZones = false;
//                    item.Header = "Supply Zones OFF";
//                }
//                else
//                {
//                    iShowSupplyZones = true;
//                    item.Header = "Supply Zones ON";
//                }
//            }
//            #endregion

//            #region -- pShowBrokenZones --
//            else if (item.Name == "pShowBrokenZones")
//            {
//                if (item.Header.ToString().Contains("ON"))
//                {
//                    iShowBrokenZones = false;
//                    item.Header = "Broken Zones OFF";
//                }
//                else
//                {
//                    iShowBrokenZones = true;
//                    item.Header = "Broken Zones ON";
//                }
//            }
//            #endregion

//            #region -- pShowFreshZones --
//            else if (item.Name == "pShowFreshZones")
//            {
//                if (item.Header.ToString().Contains("ON"))
//                {
//                    iShowFreshZones = false;
//                    item.Header = "Fresh Zones OFF";
//                }
//                else
//                {
//                    iShowFreshZones = true;
//                    item.Header = "Fresh Zones ON";
//                }
//            }
//            #endregion

//            #region -- pShowTestedZones --
//            else if (item.Name == "pShowTestedZones")
//            {
//                if (item.Header.ToString().Contains("ON"))
//                {
//                    iShowTestedZones = false;
//                    item.Header = "Tested Zones OFF";
//                }
//                else
//                {
//                    iShowTestedZones = true;
//                    item.Header = "Tested Zones ON";
//                }
//            }
//            #endregion

//            #region -- pZonesTSEnabled --
//            else if (item.Name == "pZonesTSEnabled")
//            {
//                if (item.Header.ToString().Contains("ON"))
//                {
//                    iZonesTSEnabled = false;
//                    item.Header = "Tested Shading OFF";
//                }
//                else
//                {
//                    iZonesTSEnabled = true;
//                    item.Header = "Tested Shading ON";
//                }
//            }
//            #endregion

//            #region -- pZonesTMEnabled --
//            else if (item.Name == "pZonesTMEnabled")
//            {
//                if (item.Header.ToString().Contains("ON"))
//                {
//                    iZonesTMEnabled = false;
//                    item.Header = "Tested Marker OFF";
//                }
//                else
//                {
//                    iZonesTMEnabled = true;
//                    item.Header = "Tested Marker ON";
//                }
//            }
//            #endregion

//            #region -- pExtendZonesRight --
//            else if (item.Name == "pExtendZonesRight")
//            {
//                if (item.Header.ToString().Contains("ON"))
//                {
//                    iExtendZonesRight = false;
//                    item.Header = "Extend Right OFF";
//                }
//                else
//                {
//                    iExtendZonesRight = true;
//                    item.Header = "Extend Right ON";
//                }
//            }

//            #endregion

//            ChartControl.InvalidateVisual();
//        }
        #endregion

        #region private void ZoneItem_Click(object sender, EventArgs e)
        private void ZoneItem_Click(object sender, EventArgs e)
        {
//            foreach (KeyValuePair<int, List<Zone>> DZ in SupplyZones)
//            {
//                foreach (Zone ZS in DZ.Value) ZS.IsHidden = false;
//            }
//            foreach (KeyValuePair<int, List<Zone>> DZ in DemandZones)
//            {
//                foreach (Zone ZS in DZ.Value) ZS.IsHidden = false;
//            }
//            ChartControl.InvalidateVisual();
        }
        #endregion

        #region private void Inventory_Click(object sender, EventArgs e)
//        private void Inventory_Click(object sender, EventArgs e)
//        {
//            MenuItem item = sender as MenuItem;

//            #region -- pInventoryEnabled --
//            if (item.Name == "pInventoryEnabled")
//            {
//                if (item.Header.ToString().Contains("ON"))
//                {
//                    iInventoryEnabled = false;
//                    item.Header = "Inventory OFF";
//                }
//                else
//                {
//                    iInventoryEnabled = true;
//                    item.Header = "Inventory ON";
//                }
//            }
//            #endregion

//            ChartControl.InvalidateVisual();
//        }
        #endregion

        #region -- Custom Grid to Build NUDControl (not WPF native) --
        private Grid createCRVMenu(string nudValue1, string nudValue2)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - CRV1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Defiance ATR % : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudCRV1 = new TextBox() { Name = string.Format("CRV1txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudCRV1.Text = nudValue1;
            nudCRV1.KeyDown += menuTxtbox_KeyDown;
            nudCRV1.TextChanged += NumericUpDownValueChanged;
            nudCRV1.SetValue(Grid.ColumnProperty, 1);
            nudCRV1.SetValue(Grid.RowProperty, 0);
            nudCRV1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("CRV1cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("CRV1cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);

            //line 2 - CRV2
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Break H/L ATR % : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudCRV2 = new TextBox() { Name = string.Format("CRV2txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudCRV2.Text = nudValue2;
            nudCRV2.KeyDown += menuTxtbox_KeyDown;
            nudCRV2.TextChanged += NumericUpDownValueChanged;
            nudCRV2.SetValue(Grid.ColumnProperty, 1);
            nudCRV2.SetValue(Grid.RowProperty, 2);
            nudCRV2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = string.Format("CRV2cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = string.Format("CRV2cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 2);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudCRV1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudCRV2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            return grid;
        }
        private Grid createMSTMenu(string nudValue1, string nudValue2)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - MST1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "% ATR : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            nudMST1 = new TextBox() { Name = string.Format("MST1txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST1.Text = nudValue1;
            nudMST1.KeyDown += menuTxtbox_KeyDown;
            nudMST1.TextChanged += NumericUpDownValueChanged;
            nudMST1.SetValue(Grid.ColumnProperty, 1);
            nudMST1.SetValue(Grid.RowProperty, 0);
            nudMST1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("MST1cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("MST1cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);

            //line 2 - MST2
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Strength : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudMST2 = new TextBox() { Name = string.Format("MST2txtbox{0}",uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST2.Text = nudValue2;
            nudMST2.KeyDown += menuTxtbox_KeyDown;
            nudMST2.TextChanged += NumericUpDownValueChanged;
            nudMST2.SetValue(Grid.ColumnProperty, 1);
            nudMST2.SetValue(Grid.RowProperty, 2);
            nudMST2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = string.Format("MST2cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = string.Format("MST2cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 2);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMST1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudMST2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            return grid;
        }
        private Grid createPCSettingsMenu(string PCtype, string nudValue1, string nudValue2, string nudValue3)
        {
            const int rHeight = 26;

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            #region -- line 1 - Combo --
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Type : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);

            CompTypeCombo = new ComboBox { Name = string.Format("CPS1combo{0}", uID), MinWidth = 75 + gCmdup.Width, Width = 75 + gCmdup.Width, MaxWidth = 75 + gCmdup.Width, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            CompTypeCombo.Items.Add(new ComboBoxItem { Content = "Day" });
            CompTypeCombo.Items.Add(new ComboBoxItem { Content = "Time" });
            CompTypeCombo.Text = PCtype;
            CompTypeCombo.KeyDown += Combo_KeyDown;
            CompTypeCombo.SetValue(Grid.ColumnProperty, 1);
            CompTypeCombo.SetValue(Grid.RowProperty, 0);
            CompTypeCombo.SetValue(Grid.ColumnSpanProperty, 2);
            #endregion

            #region -- line 2 - nud1 --
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Start (Hrs) : " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 1);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            nudPCS1 = new TextBox() { Name = string.Format("PCS1txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudPCS1.Text = nudValue1;
            nudPCS1.KeyDown += menuTxtbox_KeyDown;
            nudPCS1.TextChanged += NumericUpDownValueChanged;
            nudPCS1.SetValue(Grid.ColumnProperty, 1);
            nudPCS1.SetValue(Grid.RowProperty, 1);
            nudPCS1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = string.Format("CPS1cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = string.Format("CPS1cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 1);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 2);
            #endregion

            #region -- line 3 - nud2 --
            Label lbl3 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Start (M) : " };
            lbl3.SetValue(Grid.ColumnProperty, 0);
            lbl3.SetValue(Grid.RowProperty, 3);
            lbl3.SetValue(Grid.RowSpanProperty, 2);

            nudPCS2 = new TextBox() { Name = string.Format("PCS2txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudPCS2.Text = nudValue2;
            nudPCS2.KeyDown += menuTxtbox_KeyDown;
            nudPCS2.TextChanged += NumericUpDownValueChanged;
            nudPCS2.SetValue(Grid.ColumnProperty, 1);
            nudPCS2.SetValue(Grid.RowProperty, 3);
            nudPCS2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = string.Format("CPS2cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = string.Format("CPS2cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 3);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 4);
            #endregion

            #region -- line 4 - nud3 --
            Label lbl4 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Interval (M) : " };
            lbl4.SetValue(Grid.ColumnProperty, 0);
            lbl4.SetValue(Grid.RowProperty, 5);
            lbl4.SetValue(Grid.RowSpanProperty, 2);

            nudPCS3 = new TextBox() { Name = string.Format("PCS3txtbox{0}", uID), MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudPCS3.Text = nudValue3;
            nudPCS3.KeyDown += menuTxtbox_KeyDown;
            nudPCS3.TextChanged += NumericUpDownValueChanged;
            nudPCS3.SetValue(Grid.ColumnProperty, 1);
            nudPCS3.SetValue(Grid.RowProperty, 5);
            nudPCS3.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup3 = new Button() { Name = string.Format("CPS3cmdup{0}", uID), Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw3 = new Button() { Name = string.Format("CPS3cmddw{0}", uID), Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup3.Click += cmdupdw_Click;
            cmdup3.SetValue(Grid.ColumnProperty, 2);
            cmdup3.SetValue(Grid.RowProperty, 5);
            cmddw3.Click += cmdupdw_Click;
            cmddw3.SetValue(Grid.ColumnProperty, 2);
            cmddw3.SetValue(Grid.RowProperty, 6);
            #endregion

            //Add controls to grid
            grid.Children.Add(lbl1);
            grid.Children.Add(CompTypeCombo);

            grid.Children.Add(lbl2);
            grid.Children.Add(nudPCS1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            grid.Children.Add(lbl3);
            grid.Children.Add(nudPCS2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);

            grid.Children.Add(lbl4);
            grid.Children.Add(nudPCS3);
            grid.Children.Add(cmdup3);
            grid.Children.Add(cmddw3);

            return grid;
        }
        #endregion

        //---------- Events ------------------------------------------------
        #region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #endregion

        #region -- Low Level Drawing Functions - AzurITec --

        //Draw Rectangle. Rect as pixel coordinate
        private void drawRectangle(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush, int width, DashStyleHelper dashstyle = DashStyleHelper.Solid)
        {
            drawRectangle(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, dxbrush, dashstyle, width);
        }
        //Draw Rectangle. x and y as pixel coordinate, w and h in pixel too.
        private void drawRectangle(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
        {
            drawRectangle(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush, dashstyle, width);
        }
        //Draw Rectangle. points are in pixel coordinate.
//        private void drawRectangle(Point[] points, Brush couleur, DashStyleHelper dashstyle, int width)
//        {
//            drawLine(points[0].X, points[1].X, points[0].Y, points[1].Y, couleur, dashstyle, width);
//            drawLine(points[1].X, points[2].X, points[1].Y, points[2].Y, couleur, dashstyle, width);
//            drawLine(points[2].X, points[3].X, points[2].Y, points[3].Y, couleur, dashstyle, width);
//            drawLine(points[3].X, points[0].X, points[3].Y, points[0].Y, couleur, dashstyle, width);
//        }
        private void drawRectangle(Point[] points, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
        {
            drawLine(points[0].X, points[1].X, points[0].Y, points[1].Y, dxbrush, dashstyle, width);
            drawLine(points[1].X, points[2].X, points[1].Y, points[2].Y, dxbrush, dashstyle, width);
            drawLine(points[2].X, points[3].X, points[2].Y, points[3].Y, dxbrush, dashstyle, width);
            drawLine(points[3].X, points[0].X, points[3].Y, points[0].Y, dxbrush, dashstyle, width);
        }
        private void drawLine(double x1, double x2, double y1, double y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
        {
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            Point p0 = new Point(x1, y1);
            Point p1 = new Point(x2, y2);
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), dxbrush, width, strokestyle);

            strokestyle.Dispose();
        }
        //Draw Region between 4 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawRegion(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale)
        {
#if USE_WPF_COORDS
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl), chartScale.GetYByValueWpf(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl), chartScale.GetYByValueWpf(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl), chartScale.GetYByValueWpf(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl), chartScale.GetYByValueWpf(yValues[3]))
                },
                dxbrush
                );
#else
            drawRegion(new Point[]{
                    new Point(GetX0(xIndex[0], chartControl), chartScale.GetYByValue(yValues[0])),
                    new Point(GetX0(xIndex[1], chartControl), chartScale.GetYByValue(yValues[1])),
                    new Point(GetX0(xIndex[2], chartControl), chartScale.GetYByValue(yValues[2])),
                    new Point(GetX0(xIndex[3], chartControl), chartScale.GetYByValue(yValues[3]))
                },
                dxbrush
                );
#endif
        }

        //Draw Region between 4 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
//        private void drawRegion(double[] yValues, int[] xIndex, Brush color, int opacity, ChartControl chartControl, ChartScale chartScale)
//        {
//#if USE_WPF_COORDS
//            drawRegion(new Point[]{
//                    new Point(GetX0(xIndex[0], chartControl), chartScale.GetYByValueWpf(yValues[0])),
//                    new Point(GetX0(xIndex[1], chartControl), chartScale.GetYByValueWpf(yValues[1])),
//                    new Point(GetX0(xIndex[2], chartControl), chartScale.GetYByValueWpf(yValues[2])),
//                    new Point(GetX0(xIndex[3], chartControl), chartScale.GetYByValueWpf(yValues[3]))
//                },
//                color,
//                opacity
//                );
//#else
//            drawRegion(new Point[]{
//                    new Point(GetX0(xIndex[0], chartControl), chartScale.GetYByValue(yValues[0])),
//                    new Point(GetX0(xIndex[1], chartControl), chartScale.GetYByValue(yValues[1])),
//                    new Point(GetX0(xIndex[2], chartControl), chartScale.GetYByValue(yValues[2])),
//                    new Point(GetX0(xIndex[3], chartControl), chartScale.GetYByValue(yValues[3]))
//                },
//                color,
//                opacity
//                );
//#endif
//        }
		//Draw Region between 4 points. Coordinates are in pixel.
//        private void drawRegion(Point[] points, Brush color, int opacity = 100)
//        {
//            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
//            linebrush.Opacity = opacity / 100f;

//            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

//            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
//            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
//            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
//            sink1.AddLines(vectors);
//            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
//            sink1.Close();

//            RenderTarget.FillGeometry(geo1, linebrush);
//            geo1.Dispose();
//            sink1.Dispose();
//            linebrush.Dispose();
//        }
        private void drawRegion(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
        {
            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();
        }
//        //Draw Region. Rect in pixel coordinate.
//        private void drawRegion(Rect rectangle, Brush color, int opacity = 100)
//        {
//            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, color, opacity);
//        }
//        //Draw Region. x and y as pixel coordinate, w and h in pixel too.
//        private void drawRegion(double x, double y, double w, double h, Brush color, int opacity = 100)
//        {
//            drawRegion(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, color, opacity);
//        }
        //Draw Region. Rect in pixel coordinate.
        private void drawRegion(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush)
        {
            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, dxbrush);
        }
        private void drawRegion(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush, int MinHeight)
        {
            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, Math.Max(MinHeight,rectangle.Height), dxbrush);
        }
        //Draw Region. x and y as pixel coordinate, w and h in pixel too.
        private void drawRegion(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush)
        {
            drawRegion(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush);
        }

//        private void fillEllipse(Rect rectangle, Brush color, int opacity = 100)
//        {
//            Point center = new Point(rectangle.X + rectangle.Width / 2, rectangle.Y + rectangle.Height / 2);
//            float radiusX = (float)rectangle.Width / 2f;
//            float radiusY = (float)rectangle.Height / 2f;

//            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
//            linebrush.Opacity = opacity / 100f;

//            SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(center.ToVector2(), radiusX, radiusY);
//            RenderTarget.FillEllipse(ellipse, linebrush);

//            linebrush.Dispose();
//        }
        private void fillEllipse(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush)
        {
            Point center = new Point(rectangle.X + rectangle.Width / 2, rectangle.Y + rectangle.Height / 2);
            float radiusX = Convert.ToSingle(rectangle.Width) / 2f;
            float radiusY = Convert.ToSingle(rectangle.Height) / 2f;

            SharpDX.Direct2D1.Ellipse ellipse = new SharpDX.Direct2D1.Ellipse(center.ToVector2(), radiusX, radiusY);
            RenderTarget.FillEllipse(ellipse, dxbrush);
        }
        //Fill a Polygon from points given in x;y coordinates
//        private void fillPolygon(Point[] points, Brush color, int opacity = 100)
//        {
//            SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
//            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

//            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
//            linebrush.Opacity = opacity / 100f;

//            //SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };
//            SharpDX.Vector2[] vectors = new SharpDX.Vector2[points.Count() - 1];
//            for (int v = 1; v < points.Count(); v++) vectors[v - 1] = points[v].ToVector2();

//            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
//            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
//            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
//            sink1.AddLines(vectors);
//            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
//            sink1.Close();

//            RenderTarget.FillGeometry(geo1, linebrush);
//            geo1.Dispose();
//            sink1.Dispose();
//            linebrush.Dispose();

//            RenderTarget.AntialiasMode = oldAntialiasMode;
//        }
        private void fillPolygon(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
        {
            SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
            RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

            //SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };
            SharpDX.Vector2[] vectors = new SharpDX.Vector2[points.Count() - 1];
            for (int v = 1; v < points.Count(); v++) vectors[v - 1] = points[v].ToVector2();

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();

            RenderTarget.AntialiasMode = oldAntialiasMode;
        }
        //Fill a Polygon from points given in x;y coordinates
        private void drawPolygon(Point[] points, Brush color, int width, int opacity = 100, DashStyleHelper dashstyle = DashStyleHelper.Solid)
        {
            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            linebrush.Opacity = opacity / 100f;
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;
            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            SharpDX.Vector2[] vectors = new SharpDX.Vector2[points.Count() - 1];
            for (int v = 1; v < points.Count(); v++) vectors[v - 1] = points[v].ToVector2();

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.DrawGeometry(geo1, linebrush, width, strokestyle);
            geo1.Dispose();
            sink1.Dispose();
            linebrush.Dispose();
            strokestyle.Dispose();
        }
        private void drawPolygon(Point[] points, SharpDX.Direct2D1.Brush dxbrush, int width, DashStyleHelper dashstyle = DashStyleHelper.Solid)
        {
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;
            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            SharpDX.Vector2[] vectors = new SharpDX.Vector2[points.Count() - 1];
            for (int v = 1; v < points.Count(); v++) vectors[v - 1] = points[v].ToVector2();

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.DrawGeometry(geo1, dxbrush, width, strokestyle);
            geo1.Dispose();
            sink1.Dispose();
            strokestyle.Dispose();
        }
        //Draw a line between 2 points not in pixel coordinates. The x value is a relative the bar index. The y value is the numerical value (ie price / oscillator value)
        private void drawLine(double value1, double value2, int idxslot1, int idxslot2, Brush color, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale)
        {
            SharpDX.Direct2D1.Brush linebrush = color.ToDxBrush(RenderTarget);
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

#if USE_WPF_COORDS
            Point p0 = new Point(GetX0(idxslot1, chartControl), chartScale.GetYByValueWpf(value1));
            Point p1 = new Point(idxslot2 == 0 ? GetX0(Math.Min(CurrentBar, ChartBars.ToIndex), chartControl) : GetX0(idxslot2, chartControl), chartScale.GetYByValueWpf(value2));
#else
            Point p0 = new Point(GetX0(idxslot1, chartControl), chartScale.GetYByValue(value1));
            Point p1 = new Point(idxslot2 == 0 ? GetX0(Math.Min(CurrentBar, ChartBars.ToIndex), chartControl) : GetX0(idxslot2, chartControl), chartScale.GetYByValue(value2));
#endif
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), linebrush, width, strokestyle);

            linebrush.Dispose();
            strokestyle.Dispose();
        }
        private void drawLine(double value, int idxslot1, int idxslot2, Brush color, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale) { drawLine(value, value, idxslot1, idxslot2, color, dashstyle, width, chartControl, chartScale); }
        private void drawLine(double value1, double value2, int idxslot1, int idxslot2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale)
        {
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

#if USE_WPF_COORDS
            Point p0 = new Point(GetX0(idxslot1, chartControl), chartScale.GetYByValueWpf(value1));
            Point p1 = new Point(idxslot2 == 0 ? GetX0(Math.Min(CurrentBar, ChartBars.ToIndex), chartControl) : GetX0(idxslot2, chartControl), chartScale.GetYByValueWpf(value2));
#else
            Point p0 = new Point(GetX0(idxslot1, chartControl), chartScale.GetYByValue(value1));
            Point p1 = new Point(idxslot2 == 0 ? GetX0(Math.Min(CurrentBar, ChartBars.ToIndex), chartControl) : GetX0(idxslot2, chartControl), chartScale.GetYByValue(value2));
#endif
            RenderTarget.DrawLine(p0.ToVector2(), p1.ToVector2(), dxbrush, width, strokestyle);
            strokestyle.Dispose();
        }
        private void drawLine(double value, int idxslot1, int idxslot2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale) { drawLine(value, value, idxslot1, idxslot2, dxbrush, dashstyle, width, chartControl, chartScale); }
        private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            if (x < 0 || y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
            //SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            Point textpoint = new Point(x, y);
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                Convert.ToSingle(font.Size)
                )
            { TextAlignment = textAlignment, WordWrapping = WordWrapping.NoWrap };
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

            RenderTarget.DrawTextLayout(textpoint.ToVector2(), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
        }

        private double CalculateOptimalFontSize(double maxWidth, string text, SimpleFont font)
        {
            double fsize = font.Size;
            for (fsize = font.Size; fsize > 0; fsize--)
            {
                font.Size = fsize;
                float txtwidth = getTextWidth(text, font);
                if (txtwidth < maxWidth) break;
            }
            return fsize;
        }
        private float getTextWidth(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                Convert.ToSingle(font.Size)
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }
        private float[] getTextWidthHeight(string text, SimpleFont font)
        {
            TextFormat textFormat = new TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                Convert.ToSingle(font.Size)
                );
            TextLayout textLayout = new TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			var result = new float[2]{textLayout.Metrics.Width, textLayout.Metrics.Height};

            textLayout.Dispose();
            textFormat.Dispose();

            return result;
        }
        //private int GetX0(int bars, ChartControl chartControl) { return chartControl.GetXByBarIndex(ChartBars, bars); }//NEW VERSION NT8
        private int GetX0(int bars, ChartControl chartControl, bool atMiddle = false) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars) - (atMiddle ? (int)(chartControl.Properties.BarDistance / 2) : 0); }//NEW VERSION NT8        

        #endregion

        #region -- Misc Functions --
        //-- optimized code to parse string to int
        private int IntParseFast(string value)
        {
            int result = 0;
            for (int i = 0; i < value.Length; i++) result = 10 * result + (value[i] - 48);
            return result;
        }
        //recreate the profile's shape from the list of points (above or below or inside VA)
        private Point[] MakeShape(List<Point> points, int start)
        {
            Point[] newPoints = new Point[points.Count + 2];
            int i = 0;
            bool firstone = true;
            foreach (Point p in points)
            {
                if (firstone)
                {
                    firstone = false;
                    newPoints[i] = new Point(start, p.Y);
                    i++;
                }
                newPoints[i] = p;
                i++;
                if (i == points.Count + 1) newPoints[i] = new Point(start, p.Y);
            }
            return newPoints;
        }
        //set the color to Black or White depending on background color
        public Brush ContrastingColor(SolidColorBrush background)
        {
            // Counting the perceptive luminance - human eye favors green color... 
            double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
            if (a < 0.5) return Brushes.Black; // bright colors - black font
            else return Brushes.White; // dark colors - white font
        }
        //return coordinates of Box price depending on type
        private int GetBoxPixel(double price, char type)
        {
            price = RTTS(price);
            if (PriceBoxes.ContainsKey(price))
            {
                if (type == 'T') return PriceBoxes[price].Top;
                else if (type == 'B') return PriceBoxes[price].Bottom;
                else if (type == 'H') return PriceBoxes[price].Height;
            }
            return 0;
        }
        private int GetBoxPixel(double price, char type, bool GiveSpace)
        {
            price = RTTS(price);
			int space = 0;
			if(GiveSpace){
				if(this.pShowNetDeltaNumberOnBar) space = space +  (int)iNetDeltaFont.Size;
//				if(this.iShowTotalVolumeAsPct) space = space +  (int)iNetDeltaFont.Size;
				space = space + (int)iNetDeltaFont.Size;
				if (type == 'B') space = space + (int)iNetDeltaFont.Size;
				else if (type == 'T') space = space + (int)(iNetDeltaFont.Size/2);
			}
            if (PriceBoxes.ContainsKey(price))
            {
                if (type == 'T') return PriceBoxes[price].Top - space;
                else if (type == 'B') return PriceBoxes[price].Bottom + space;
                else if (type == 'H') return PriceBoxes[price].Height;
            }
            return 0;
        }

        private Point[] DrawTri(int x1, int y1, double val, int arrowSize, int dir)
        {
            arrowSize = arrowSize + 1;
            if (dir > 0) return (new Point[] { new Point(x1, y1 - arrowSize), new Point(x1, y1 + arrowSize), new Point(x1 + arrowSize, y1) });
            else return (new Point[] { new Point(x1, y1 - arrowSize), new Point(x1, y1 + arrowSize), new Point(x1 - arrowSize, y1) });
        }
//==========================================================================================================================
        private SortedDictionary<double, PrintLevelDetails> ProcessFootSignals(SortedDictionary<double, PrintLevelDetails> SL)
        {
line=6171;
            SortedDictionary<double, PrintLevelDetails> ThisI = new SortedDictionary<double, PrintLevelDetails>();
            var items = from pair in SL orderby pair.Key descending select pair;

            ThisI = SL;
            long bidt = 0;
            long askt = 0;
            bool ttt = true;
            long tttv = 0;
            long prevvol = 0;

            int TCB = BarsAreMinute ? CurrentBars[0] : ThisCurrentBar;

line=6184;
            BarDataTotals[TCB] = new BarTotal();
            BarDataTotals[TCB].MaxBid = 0;
            BarDataTotals[TCB].MaxAsk = 0;
            BarDataTotals[TCB].TrappedTraderN = 0;
            BarDataTotals[TCB].POC = 0;

            int barsAgoIndex = CurrentBars[0] - TCB;

line=6193;
            foreach (KeyValuePair<double, PrintLevelDetails> kvp2 in items)
            {
line=6196;
                if (kvp2.Key > Highs[0][barsAgoIndex] + 0.0000001 || kvp2.Key < Lows[0][barsAgoIndex] - 0.0000001) continue;
                if (ttt)
                {
line=6200;
                    if (kvp2.Value.AskSize > prevvol) tttv = tttv - 1;
                    else ttt = false;

                    prevvol = kvp2.Value.AskSize;
                }
line=6206;
                bidt = bidt + kvp2.Value.BidSize;
                askt = askt + kvp2.Value.AskSize;
	            BarDataTotals[TCB].MaxBid  = Math.Max(BarDataTotals[TCB].MaxBid, kvp2.Value.BidSize);
	            BarDataTotals[TCB].MaxAsk  = Math.Max(BarDataTotals[TCB].MaxAsk, kvp2.Value.AskSize);
            }

line=6224;

            BarDataTotals[TCB].AskTotal = askt;
            BarDataTotals[TCB].BidTotal = bidt;
            NETDELTA[0] = askt - bidt;
			if(NETDELTA[0]>0){
line=6263;
				NetD_MaxMgr.AddLong(Convert.ToInt64(NETDELTA[0]), CurrentBars[0]);
				NetD_MinMgr.NoChange(CurrentBars[0]);
			}else{ 
line=6269;
				NetD_MinMgr.AddLong(Convert.ToInt64(Math.Abs(NETDELTA[0])), CurrentBars[0]);
				NetD_MaxMgr.NoChange(CurrentBars[0]);
			}

			ttt = true;
            tttv = 0;
            prevvol = 0;

            // loop through lowest to highest price
line=6285;
            long CurrentVolumeAtPrice = 0;
            long CurrentMaximumVolume = 0;
            double CurrentPOCPrice = 0;

line=6292;
            bool IsFirst = true;
            int C = 0;

            foreach (KeyValuePair<double, PrintLevelDetails> kvp2 in SL)
            {
line=6298;
                if (kvp2.Key > Highs[0][barsAgoIndex] || kvp2.Key < Lows[0][barsAgoIndex]) continue;
                long thisbidsize = kvp2.Value.BidSize;
                long thisasksize = kvp2.Value.AskSize;
                ThisI[kvp2.Key].POC = false;
                ThisI[kvp2.Key].DIFF = Math.Abs(thisbidsize - thisasksize);
                ThisI[kvp2.Key].UFA = false;

                C++;
line=6307;
                bool IsLast = C == SL.Count && kvp2.Key == Highs00;

                if (kvp2.Key != Lows00) IsFirst = false;
                if (IsFirst || IsLast)
                {
                    IsFirst = false;
                    if (thisbidsize != 0 && thisasksize != 0) ThisI[kvp2.Key].UFA = true;
                }

line=6317;
                if (ttt)
                {
                    if (thisbidsize > prevvol) tttv = tttv + 1;
                    else ttt = false;
                    prevvol = thisbidsize;
                }

                double NextAsk = RTTS(kvp2.Key + gbTickSize);

line=6327;
                if (SL.ContainsKey(NextAsk))
                {
                    double AskS = Math.Max(SL[NextAsk].AskSize, 1);
                    double BidS = Math.Max(thisbidsize, 1);
                    double AskI = (AskS / BidS);
                    double BidI = (BidS / AskS);
                }

line=6354;
                CurrentVolumeAtPrice = thisasksize + thisbidsize;
                if (CurrentVolumeAtPrice > CurrentMaximumVolume)
                {
                    CurrentMaximumVolume = CurrentVolumeAtPrice;
                    CurrentPOCPrice = kvp2.Key;
                }
            }

line=6363;
            if (CurrentPOCPrice != 0) ThisI[CurrentPOCPrice].POC = true;

line=6496;
            return ThisI;
        }

		private double RoundToWholePip(double D){
			if(IsForex && pRoundForexToWholePip){
				int ticks = (int)Math.Round(D/gbTickSize);
				return ticks * gbTickSize;
			}else {
				int ticks = (int)Math.Round(D/TickSize);
				return ticks * TickSize;
			}
		}
        private double RTTS(double D)
        {
			if(IsForex && pRoundForexToWholePip){
				int ticks = (int)Math.Round(D/gbTickSize);
				return ticks * gbTickSize;
			}else {
				int ticks = (int)Math.Round(D/TickSize);
				return ticks * TickSize;
			}
			
//			int ticks = (int)Math.Round(D/gbTickSize);
//			return ticks * gbTickSize;
        }

        #endregion

        //-------------------- Nested Classes/Structs -------------------

        #region -------------------- Nested Classes/Structs -------------------

        #region --- internal struct ManualCurve
        internal struct ManualCurve
        {
            public double HighPrice;
            public double LowPrice;
            public int LeftBar;
            public int RightBar;
            public ManualCurve(double highPrice, double lowPrice, int leftBar, int rightBar)
            {
                HighPrice = highPrice;
                LowPrice = lowPrice;
                LeftBar = leftBar;
                RightBar = rightBar;
            }
        }
        #endregion

        #region --- internal class MouseManager --- #REMARQUE : NOT SURE IF IT NEEDS TO BE IMPLEMENTED ----
        internal class MouseManager
        {
            public int HoverIndex { get; set; }
            public bool Dragging { get; set; }
            public int X { get; set; }
            public int Y { get; set; }
            public int XStart { get; set; }
            public int YStart { get; set; }
            public int Index { get; set; }

            public MouseManager()
            {
                HoverIndex = -1;
                Dragging = false;
                X = 0;
                Y = 0;
                XStart = 0;
                YStart = 0;
                Index = 0;
            }

            public void Clear()
            {
                HoverIndex = -1;
                Dragging = false;
                X = 0;
                Y = 0;
                XStart = 0;
                YStart = 0;
                Index = 0;
            }
        }
        #endregion

        #region --- internal class PriceBox --- #REMARQUE : INTERET??? ---- AverageBoxHeight
        internal class PriceBox
        {
            public int Top { get; set; }
            public int Bottom { get; set; }
            public int Height { get; set; }
        }
        #endregion

        #region --- internal class VolumeAtBA
        internal class VolumeAtBA
        {
            public double BidSize { get; set; }
            public double AskSize { get; set; }

            public double getLevelVolume() { return BidSize + AskSize; }
        }
        #endregion

        #region --- internal class PrintLevelDetails
        internal class PrintLevelDetails
        {
            public long DIFF { get; set; }
            public bool POC { get; set; }
            public bool UFA { get; set; }

            public SortedDictionary<double, VolumeAtBA> AllVolume { get; set; }

            public long BidSize { get; set; }
            public long AskSize { get; set; }
            public long BidTotal { get; set; }
            public long AskTotal { get; set; }

            public double BidImbalance { get; set; }
            public double AskImbalance { get; set; }
            public List<long> BidBlocks { get; set; }
            public List<long> AskBlocks { get; set; }

            public PrintLevelDetails()
            {
                BidBlocks = new List<long>();
                AskBlocks = new List<long>();
                AllVolume = new SortedDictionary<double, VolumeAtBA>();
            }
        }
        #endregion

        #region --- internal class ProfileLevelDetails
        internal class ProfileLevelDetails
        {
            public long BidSize { get; set; }
            public long AskSize { get; set; }

            public double VAH { get; set; }
            public double VAL { get; set; }
            public double POC { get; set; }
        }
        #endregion

        #region --- internal class VolumeProfileS
        internal class VolumeProfileS
        {
            public SortedDictionary<double, VolumeAtBA> AllVolume { get; set; }

            public long BidSize { get; set; }
            public long AskSize { get; set; }
            public double VAH { get; set; }
            public double VAL { get; set; }
            public double VAH2 { get; set; }//#REMARQUE Quel INTERET??? Toujours at ProfileHigh
            public double VAL2 { get; set; }//#REMARQUE Quel INTERET??? toujours at ProfileLow
            public double POCPrice { get; set; }
            public double POCVolume { get; set; }
            public double VWAP { get; set; }

            public double ClusterTop { get; set; }
            public double ClusterBottom { get; set; }

            public double ProfileHigh { get; set; }
            public double ProfileLow { get; set; }
            public int ProfileStart { get; set; }
            public int ProfileEnd { get; set; }
            public int Rend { get; set; }

            public bool ExtendRight { get; set; }

            public VolumeProfileS() { AllVolume = new SortedDictionary<double, VolumeAtBA>(); }
        }
        #endregion

        #region --- internal class BarTotal
        internal class BarTotal
        {
            public long BidTotal { get; set; }
            public long AskTotal { get; set; }
			public long MaxBid { get; set;}
			public long MaxAsk { get; set;}
            public long TrappedTraderN { get; set; }
            public double POC { get; set; }
        }
        #endregion

        #region --- internal class Zone
        internal class Zone
        {
            public bool IsBroken { get; set; }
            public bool IsHidden { get; set; }
            public long TicksWidth { get; set; }
            public int EndBar { get; set; }
            public double TestedPrice { get; set; }
            public double BottomPrice { get; set; }
            public double TopPrice { get; set; }
        }
        #endregion

        #region --- internal class LadderRow
        internal class LadderRow
        {
            public string MarketMaker { get; set; }          // relevant for stocks only
            public double Price { get; set; }
            public long Volume { get; set; }

            public LadderRow(double myPrice, long myVolume, string myMarketMaker)
            {
                MarketMaker = myMarketMaker;
                Price = myPrice;
                Volume = myVolume;
            }
        }
        #endregion

        //----------------- Converter -------------------
        #region internal class ProfileHD : StringConverter
        internal class ProfileHD : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Left", "Right" });
            }
        }
        #endregion

        #region internal class CompositeType : StringConverter
        internal class CompositeType : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Day", "Time" });
            }
        }
        #endregion

        #region internal class VolumeAverageMode : StringConverter
        internal class VolumeAverageMode : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "EMA", "SMA" });
            }
        }
        #endregion

        #region internal class ProfileCalcMode : StringConverter
        internal class ProfileCalcMode : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Tick", "Minute" });
            }
        }
        #endregion

        #region internal class TotalMode : StringConverter
        internal class TotalMode : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Contracts", "Percent", "Both" });
            }
        }
        #endregion

        #region internal class SignalHD : StringConverter
        internal class SignalHD : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Inside", "Outside" });
            }
        }
        #endregion

        #region internal class ProfileDisplayMode : StringConverter
        internal class ProfileDisplayMode : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Histogram", "Shape" });
            }
        }
        #endregion

        #endregion

//===================================================================================================================
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }
//===================================================================================================================

        //---------------------- Properties ----------------------------
        #region -- Exposed Series --
        #region --- EXPOSED PROFILE ---
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> exNetDelta { get { return NETDELTA; } }
        [Browsable(false)]
        [XmlIgnore()]
        public Series<int> exDFSignal { get { return DFSignalHistory; } }
        #endregion

        #region -- Plots --
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> DF_Buy { get { return Values[0]; } }
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> DF_Sell { get { return Values[1]; } }
        #endregion

        #endregion

        #region -- public Properties --

        #region -- Print Display --
		[Display(Name = "HeatMap Visible", GroupName = "Print Display", Description = "", Order = 30)]
		public bool pShowNetDeltaHeatMap { get; set; }

		[XmlIgnore]
		[Display(Name = "HeatMap Positive", GroupName = "Print Display", Description = "Color of heatmap rectangle when current net delta exceeds the average positive net delta", Order = 40)]
		public Brush pHeatMap_PositiveColor { get; set; }
		[Browsable(false)]
		public string HeatMapPositiveColorSerialize
		{
		    get { return Serialize.BrushToString(pHeatMap_PositiveColor); }
		    set { pHeatMap_PositiveColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "HeatMap Negative", GroupName = "Print Display", Description = "Color of heatmap rectangle when current net delta exceeds the average positive net delta", Order = 50)]
		public Brush pHeatMap_NegativeColor { get; set; }
		[Browsable(false)]
		public string HeatMapNegativeColorSerialize
		{
		    get { return Serialize.BrushToString(pHeatMap_NegativeColor); }
		    set { pHeatMap_NegativeColor = Serialize.StringToBrush(value); }
		}

		[Range(0,100)]
		[Display(Name = "HeatMap Height Period", GroupName = "Print Display", Description = "Number of bars for total volume average - used in calculating the height of the HeatMap histogram", Order = 60)]
		public int pHeatMapHeightPeriod { get; set; }

		[Range(0,100)]
		[Display(Name = "HeatMap Color Period", GroupName = "Print Display", Description = "Number of bars for average net delta volume - used in calculating the color of the HeatMap histogram", Order = 70)]
		public int pHeatMapColorPeriod { get; set; }

		[Display(Name = "HeatMap Skinny Bars", GroupName = "Print Display", Description = "", Order = 85)]
		public bool pUseSkinnyHeatmapBars { get; set; }

//		[Display(Name = "HeatMap Volume Enabled", GroupName = "Print Display", Description = "Total volume prints at bottom of HeatMap histogram bars", Order = 80)]
//		public bool iShowTotalVolumeInHeatMap { get; set; }

		[XmlIgnore]
		[Display(Name = "HeatMap MinimumLine", GroupName = "Print Display", Description = "Color of heatmap minimum line", Order = 83)]
		public Brush pHeatMap_MinimumLineColor { get; set; }
		[Browsable(false)]
		public string pHeatMap_MinimumLineColorSerialize
		{
		    get { return Serialize.BrushToString(pHeatMap_MinimumLineColor); }
		    set { pHeatMap_MinimumLineColor = Serialize.StringToBrush(value); }
		}
        [Range(0, 1000)]
        [Display(Name = "HeatMap MinLine Thickness", GroupName = "Print Display", Description = "Thickness of the HeatMap minimum line (set to '0' to turn-off this line)", Order = 86)]
        public int pHeatMap_MinLineThickness { get; set; }


//		[Display(Name = "Show %Vol Enabled", GroupName = "Print Display", Description = "Show net delta as a percent of total bar volume", Order = 90)]
//		public bool iShowTotalVolumeAsPct { get; set; }

		[Display(Name = "Net Delta Enabled", GroupName = "Print Display", Description = "", Order = 100)]
		public bool pShowNetDeltaNumberOnBar { get; set; }

		[XmlIgnore]
		[Display(Name = "Net Delta Color Negative", GroupName = "Print Display", Description = "", Order = 110)]
		public Brush iDNColor { get; set; }
		[Browsable(false)]
		public string iDNColorSerialize
		{
		    get { return Serialize.BrushToString(iDNColor); }
		    set { iDNColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Net Delta Color Positive", GroupName = "Print Display", Description = "", Order = 120)]
		public Brush iDPColor { get; set; }
		[Browsable(false)]
		public string iDPColorSerialize
		{
		    get { return Serialize.BrushToString(iDPColor); }
		    set { iDPColor = Serialize.StringToBrush(value); }
		}

		[Display(Name = "Net Delta Font", GroupName = "Print Display", Description = "", Order = 130)]
		public SimpleFont iNetDeltaFont { get; set; }

		[XmlIgnore]
		[Display(Name = "Text Color", GroupName = "Print Display", Description = "", Order = 140)]
		public Brush iTextColor5 { get; set; }
				[Browsable(false)]
				public string iTextColor5Serialize{get { return Serialize.BrushToString(iTextColor5); }set { iTextColor5 = Serialize.StringToBrush(value); }}

        [Display(Name = "Text Font", GroupName = "Print Display", Description = "", Order = 150)]
        public SimpleFont iBarPrintFont { get; set; }

        #endregion

		#region -- Delta Spread Analysis signals --
		[Display(Order = 10, Name = "Enable DSA", GroupName = "DSA Alert", Description = "")]
		public bool pShow_DSASignal { get; set; }

		[Range(1,10)]
		[Display(Order = 20, Name = "DSA Sensitivity", GroupName = "DSA Alert", Description = "1 is most permissive, 10 is most restrictive")]
		public int pDSA_Sensitivity { get; set; }

		[XmlIgnore]
		[Display(Order = 30, Name = "BUY color", GroupName = "DSA Alert", Description = "Color of rectangles that give visual BUY signal")]
		public Brush pBuy_DSABrush { get; set; }
				[Browsable(false)]
				public string BuyDSABrush_Serialize{get { return Serialize.BrushToString(pBuy_DSABrush); }set { pBuy_DSABrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 40, Name = "SELL color", GroupName = "DSA Alert", Description = "Color of rectangles that give visual SELL signal")]
		public Brush pSell_DSABrush { get; set; }
				[Browsable(false)]
				public string SellDSABrush_Serialize{get { return Serialize.BrushToString(pSell_DSABrush); }set { pSell_DSABrush = Serialize.StringToBrush(value); }}

		[Range(0,100)]
		[Display(Order = 50, Name = "Op. HM outline", GroupName = "DSA Alert", Description = "Opacity of colored signal rectangle that prints around the HeatMap rectangle")]
		public float pDSA_OpacityOnHeatMap { get; set; }

		[Range(1,10)]
		[Display(Order = 60, Name = "Width HM outline", GroupName = "DSA Alert", Description = "Width of colored signal rectangle that prints around the HeatMap rectangle")]
		public float pDSA_HistoOutlineThickness {get;set;}

		[Range(0,100)]
		[Display(Order = 70, Name = "Op. PriceBar outline", GroupName = "DSA Alert", Description = "Opacity of colored signal rectangle that prints above and below the price bar")]
		public float pDSA_OpacityOnPriceBar { get; set; }

//		[Display(Order = 80, Name = "Overprint PriceBar?", GroupName = "DSA Alert", Description = "Overprint a rectangle on the price bar?  If not, then print 2 rectangles, one above the price bar, and one below it")]
//		public bool pDSA_OverprintPriceBar {get; set;}
		
		#endregion

        #region -- Bar Display --
        [Range(1, 1000)]
        [Display(Name = "Right Side Margin Minimum (Pixels)", GroupName = "Bar Display", Description = "", Order = 00)]
        public int iRightSideMarginMin { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Right Side Padding Minimum (Pixels)", GroupName = "Bar Display", Description = "", Order = 10)]
        public int iRightSidePaddingMin { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Bar Space Minimum (Pixels)", GroupName = "Bar Display", Description = "", Order = 20)]
        public int iMinBarSpacePixels { get; set; }

        [Range(1, 1000)]
        [Display(Name = "Bar Space Maximum (Pixels)", GroupName = "Bar Display", Description = "", Order = 30)]
        public int iMaxBarSpacePixels { get; set; }
        #endregion

        #region -- Data --
		[NinjaScriptProperty]
        [TypeConverter(typeof(ProfileCalcMode))]
        [Display(Name = "Mode", GroupName = "Data", Description = "Tick ??? used with tick charts on very small intervals (3-5 days max), Minute ??? used on larger lookbacks and larger interval charts, (profile only). ", Order = 5)]
        public string iPCalcM { get; set; }

		[NinjaScriptProperty]
        [Range(-1, 999999999999)]
        [Display(Name = "Bkg Bars To Process", GroupName = "Data", Description = "Number of ticks or minute bars to process.  Reduce this number to help speed-up Print execution (set to -1 to turn-off this limiter)", Order = 10)]
        public int Bars_To_Process { get; set; }
		
		[NinjaScriptProperty]
        [Display(Name = "Ignore last forex digit", GroupName = "Data", Description = "Round-off the rightmost digit in forex instruments", Order = 20)]
		public bool pRoundForexToWholePip { get; set; }

		[NinjaScriptProperty]
		[Range(0,int.MaxValue)]
		[Display(Name = "Normalization period", GroupName = "Data", Description = "Set to '0' to switch to raw (non-normalized) plot", Order = 30)]
		public int pNormalizationPeriod { get; set; }
        #endregion

		#region -- MACDBB Parameters --
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Period Bollinger Band", GroupName = "MACDBB Parameters", Description = "Band Period for Bollinger Band", Order = 0)]
        public int BandPeriod { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Lookback fast EMA", GroupName = "MACDBB Parameters", Description = "Period for fast EMA", Order = 10)]
        public int Fast { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Lookback slow EMA", GroupName = "MACDBB Parameters", Description = "Period for slow EMA", Order = 20)]
        public int Slow { get; set; }

        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Std. dev. multiplier", GroupName = "MACDBB Parameters", Description = "Number of standard deviations", Order = 30)]
        public double StdDevNumber { get; set; }
		#endregion
		//=================================================================
		#region DeltaForce
		[NinjaScriptProperty]
        [Display(Order = 0, Name = "Algorithm", GroupName = "DeltaForce Signals", Description = "")]
        public ARC_DeltaForce_Algorithm pAlgorithm { get; set; }

		[Display(Order = 10, Name = "Show signals?", GroupName = "DeltaForce Signals", Description = "")]
		public bool pShowDeltaForceSignals {get;set;}

		[Display(Order = 20, Name = "Show Longs?", GroupName = "DeltaForce Signals", Description = "")]
		public bool pShowLongs {get;set;}

		[Display(Order = 30, Name = "Show Shorts?", GroupName = "DeltaForce Signals", Description = "")]
		public bool pShowShorts {get;set;}

		[Display(Order = 32, Name = "Draw as chart object?", GroupName = "DeltaForce Signals", Description = "true = draw uparrow/downarrow chart objects, false = draw signals as a plot")]
		public bool pSignalsAsDrawObjects {get;set;}

		[Display(Order = 35, Name = "Arrow dist (ticks)", GroupName = "DeltaForce Signals", Description = "Distance (in ticks) between price bar and the DF_Buy and DF_Sell triangles")]
		public int pSeparationTicks {get;set;}
		
		[Display(Order = 40, Name = "Permit continuing trades?", GroupName = "DeltaForce Signals", Description = "")]
		public bool pPermitContinuingTrade {get;set;}

		[Display(Order = 45, Name = "Max continuing trades?", GroupName = "DeltaForce Signals", Description = "Max number of consequtive continuing trades")]
		public int pMaxTrades {get;set;}


		[Display(Order = 50, Name = "Filter on Histo?", GroupName = "DeltaForce Signals", Description = "")]
		public bool pFilterOnHisto {get;set;}

		[Display(Order = 60, Name = "Separation (ticks)", GroupName = "DeltaForce Signals", Description = "Distance (ticks) between price bar and buy/sell triangle")]
		public int pArrowSeparation {get;set;}

		[Display(Order = 70, Name = "Show Racing Stripes?", GroupName = "DeltaForce Signals", Description = "")]
		public bool pShowRacingStripes {get;set;}

		[XmlIgnore]
		[Display(Order = 80, Name = "Buy Stripe", GroupName = "DeltaForce Signals", Description = "Color of the background on a BUY signal")]
		public Brush pBuyStripeBrush { get; set; }
			    [Browsable(false)]
			    public string pBuyStripeBrushSerialize {get { return Serialize.BrushToString(pBuyStripeBrush);} set {pBuyStripeBrush = Serialize.StringToBrush(value); }}

		[Range(0,100)]
		[Display(Order =90, Name = "Buy Stripe Op.", GroupName = "DeltaForce Signals", Description = "Opacity of BUY background stripe")]
		public int pBuyStripeOpacity { get; set;}

		[XmlIgnore]
		[Display(Order = 100, Name = "Sell Stripe", GroupName = "DeltaForce Signals", Description = "Color of the background on a SELL signal")]
		public Brush pSellStripeBrush { get; set; }
			    [Browsable(false)]
			    public string pSellStripeBrushSerialize {get { return Serialize.BrushToString(pSellStripeBrush);} set {pSellStripeBrush = Serialize.StringToBrush(value); }}

		[Range(0,100)]
		[Display(Order = 110, Name = "Sell Stripe Op.", GroupName = "DeltaForce Signals", Description = "Opacity of SELL background stripe")]
		public int pSellStripeOpacity { get; set;}
		#endregion

		[Description("WAV file to play for DeltaForce BUY signals, 'SOUND OFF' to turn off the alert")]
        [Display(Order = 120, Name = "Buy Sound", GroupName = "DeltaForce Signals")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pBuyWAV		{ get; set; }

		[Description("WAV file to play for DeltaForce SELL signals, 'SOUND OFF' to turn off the alert")]
        [Display(Order = 130, Name = "Sell Sound", GroupName = "DeltaForce Signals")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pSellWAV		{ get; set; }

		#region TradingPlan
		[Range(1, 100)]
		[Display(Name = "ATR period", GroupName = "Trade Plan", Description = "", Order = 1)]
		public int pATRperiod  {get; set;}
		[Display(Name = "Show Longs", GroupName = "Trade Plan", Description = "Show trade plan for long trades", Order = 25)]
		public bool pShowLongTradePlans {get; set;}
		[Display(Name = "Show Shorts", GroupName = "Trade Plan", Description = "Show trade plan for short trades", Order = 30)]
		public bool pShowShortTradePlans {get; set;}

		[Range(0, 10000)]
		[Display(Name = "Line length", GroupName = "Trade Plan", Description = "Line length (in bars) for trade plan SL, T1 and T2 lines", Order = 50)]
		public int pTradePlan_LineLength {get;set;}
		[Display(Name = "Visual Shift distance", GroupName = "Trade Plan", Description = "Distance (in bars) of shifting the trade plans away from the current bar (neg value moves print to the left, pos values to the right)", Order = 75)]
		public int pVisualShiftDistance {get; set;}

		[Display(Name = "SL Calc Basis", GroupName = "Trade Plan", Description = "When calculating the SL distance, should it use the ATR multiple, or Tick distances?", Order = 80)]
		public ARC_DeltaForce_SLTP_CalcBasis SLTP_CalcBasis {get; set;}

		[Display(Name = "Show Entry line", GroupName = "Trade Plan", Description = "Show the Entry line", Order = 84)]
		public bool pShowEntry {get; set;}
		[Display(Name = "Show T2 line", GroupName = "Trade Plan", Description = "Show the T2 line", Order = 86)]
		public bool pShowT2 {get; set;}
		[Display(Name = "Show T1 line", GroupName = "Trade Plan", Description = "Show the T1 line", Order = 90)]
		public bool pShowT1 {get; set;}
		[Display(Name = "Show SL line", GroupName = "Trade Plan", Description = "Show the SL line", Order = 95)]
		public bool pShowSL {get; set;}
		[Display(Name = "Label Loc", GroupName = "Trade Plan", Description = "LEFT side or RIGHT side of the price lines", Order = 96)]
		public ARC_DeltaForce_TPLabelSide pTPLabelSide {get; set;}

//============================================================================================================
		[Display(Name = "Label for Longs", GroupName = "Trade Plan Entry", Description = "Enter a '*' for price insertion", Order = 15)]
		public string LongEntryLabel {get;set;}
		[Display(Name = "Label for Shorts", GroupName = "Trade Plan Entry", Description = "Enter a '*' for price insertion", Order = 20)]
		public string ShortEntryLabel {get;set;}

		[Display(Name = "Font", GroupName = "Trade Plan Entry", Description = "", Order = 45)]
        public SimpleFont FontEL { get; set; }
		[XmlIgnore]
		[Display(Name = "Entry color", GroupName = "Trade Plan Entry", Description = "Color of Entry lines", Order = 50)]
		public Brush EntryBrush  {get;set;}
		[Browsable(false)]
		public string EntryBrushSerialize {get { return Serialize.BrushToString(EntryBrush); }set { EntryBrush = Serialize.StringToBrush(value); }}
		[Display(Name = "Entry line style", GroupName = "Trade Plan Entry", Description = "Style of Entry lines", Order = 55)]
		public DashStyleHelper EntryDashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "Entry line width", GroupName = "Trade Plan Entry", Description = "", Order = 60)]
		public int EntryLineWidth {get;set;}
//============================================================================================================
		[Display(Name = "Font", GroupName = "Trade Plan StopLoss", Description = "", Order = 1)]
        public SimpleFont FontSL { get; set; }
		[Range(0.0, 1000)]
		[Display(Name = "SL size ATRs", GroupName = "Trade Plan StopLoss", Description = "Size of the stoploss as a multiple of the ATR", Order = 10)]
		public double pSLsize_inATRs {get;set;}
		[Range(0, 10000)]
		[Display(Name = "SL size Ticks", GroupName = "Trade Plan StopLoss", Description = "Size of the stoploss in Ticks", Order = 11)]
		public int pSLsize_inTicks {get;set;}
		[Display(Name = "SL label for Longs", GroupName = "Trade Plan StopLoss", Description = "Enter a '*' for price insertion", Order = 20)]
		public string LongSLLabel {get;set;}
		[Display(Name = "SL label for Shorts", GroupName = "Trade Plan StopLoss", Description = "Enter a '*' for price insertion", Order = 30)]
		public string ShortSLLabel {get;set;}
		[XmlIgnore]
		[Display(Name = "SL color for Longs", GroupName = "Trade Plan StopLoss", Description = "Color of SL lines", Order = 50)]
		public Brush LongSLBrush  {get;set;}
		[Browsable(false)]
		public string LSLBrushSerialize {get { return Serialize.BrushToString(LongSLBrush); }set { LongSLBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Name = "SL color for Shorts", GroupName = "Trade Plan StopLoss", Description = "Color of SL lines", Order = 51)]
		public Brush ShortSLBrush  {get;set;}
		[Browsable(false)]
		public string SSLBrushSerialize {get { return Serialize.BrushToString(ShortSLBrush); }set { ShortSLBrush = Serialize.StringToBrush(value); }}
		[Display(Name = "SL line style", GroupName = "Trade Plan StopLoss", Description = "Style of SL lines", Order = 65)]
		public DashStyleHelper SLDashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "SL line width", GroupName = "Trade Plan StopLoss", Description = "", Order = 80)]
		public int SLLineWidth {get;set;}
//============================================================================================================
        [Display(Name = "Font", GroupName = "Trade Plan Target1", Description = "", Order = 1)]
        public SimpleFont FontT1 { get; set; }
		[Range(0.0, 1000)]
		[Display(Name = "Target1 ATRs", GroupName = "Trade Plan Target1", Description = "Size of the first profit target as a multiple of ATR", Order = 10)]
		public double pT1size_inATRs  {get;set;}
		[Range(0.0, 10000)]
		[Display(Name = "Target1 Ticks", GroupName = "Trade Plan Target1", Description = "Size of the first profit target in ticks", Order = 12)]
		public double pT1size_inTicks  {get;set;}
		[Display(Name = "Target1 label for Longs", GroupName = "Trade Plan Target1", Description = "Enter a '*' for price insertion", Order = 20)]
		public string LongT1Label {get;set;}
		[Display(Name = "Target1 label for Shorts", GroupName = "Trade Plan Target1", Description = "Enter a '*' for price insertion", Order = 30)]
		public string ShortT1Label {get;set;}
		[XmlIgnore]
		[Display(Name = "Target1 color for Longs", GroupName = "Trade Plan Target1", Description = "Color of T1 lines", Order = 40)]
		public Brush LongT1Brush {get;set;}
		[Browsable(false)]
		public string LT1BrushSerialize {get { return Serialize.BrushToString(LongT1Brush); }set { LongT1Brush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Name = "Target1 color for Shorts", GroupName = "Trade Plan Target1", Description = "Color of T1 lines", Order = 50)]
		public Brush ShortT1Brush {get;set;}
		[Browsable(false)]
		public string ST1BrushSerialize {get { return Serialize.BrushToString(ShortT1Brush); }set { ShortT1Brush = Serialize.StringToBrush(value); }}
		[Display(Name = "Target1 line style", GroupName = "Trade Plan Target1", Description = "Style of T1 lines", Order = 60)]
		public DashStyleHelper T1DashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "Target1 line width", GroupName = "Trade Plan Target1", Description = "", Order = 70)]
		public int T1LineWidth {get;set;}
//============================================================================================================
		[Display(Name = "Font", GroupName = "Trade Plan Target2", Description = "", Order = 1)]
        public SimpleFont FontT2 { get; set; }
		[Range(0.0, 1000)]
		[Display(Name = "Target2 ATRs", GroupName = "Trade Plan Target2", Description = "Size of the second profit target as a multiple of ATR", Order = 10)]
		public double pT2size_inATRs  {get;set;}
		[Range(0.0, 10000)]
		[Display(Name = "Target2 Ticks", GroupName = "Trade Plan Target2", Description = "Size of the second profit target in ticks", Order = 12)]
		public double pT2size_inTicks  {get;set;}
		[Display(Name = "Target2 label for Longs", GroupName = "Trade Plan Target2", Description = "Enter a '*' for price insertion", Order = 20)]
		public string LongT2Label {get;set;}
		[Display(Name = "Target2 label for Shorts", GroupName = "Trade Plan Target2", Description = "Enter a '*' for price insertion", Order = 30)]
		public string ShortT2Label {get;set;}
		[XmlIgnore]
		[Display(Name = "Target2 color for Longs", GroupName = "Trade Plan Target2", Description = "Color of T2 lines", Order = 40)]
		public Brush LongT2Brush {get;set;}
		[Browsable(false)]
		public string LT2BrushSerialize {get { return Serialize.BrushToString(LongT2Brush); }set { LongT2Brush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Name = "Target2 color for Shorts", GroupName = "Trade Plan Target2", Description = "Color of T2 lines", Order = 50)]
		public Brush ShortT2Brush {get;set;}
		[Browsable(false)]
		public string ST2BrushSerialize {get { return Serialize.BrushToString(ShortT2Brush); }set { ShortT2Brush = Serialize.StringToBrush(value); }}
		[Display(Name = "Target2 line style", GroupName = "Trade Plan Target2", Description = "Style of T2 lines", Order = 60)]
		public DashStyleHelper T2DashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "Target2 line width", GroupName = "Trade Plan Target2", Description = "", Order = 70)]
		public int T2LineWidth {get;set;}
//============================================================================================================
		#endregion

        [Display(Name = "Button Text", GroupName = "Indicator Display", Description = "", Order = 20)]
		public string pButtonText {get;set;}

        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }


		#endregion
    }
}
public enum ARC_DeltaForce_Algorithm {Price, NetDelta}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_DeltaForce[] cacheARC_DeltaForce;
		public ARC.ARC_DeltaForce ARC_DeltaForce(string iPCalcM, int bars_To_Process, bool pRoundForexToWholePip, int pNormalizationPeriod, int bandPeriod, int fast, int slow, double stdDevNumber, ARC_DeltaForce_Algorithm pAlgorithm)
		{
			return ARC_DeltaForce(Input, iPCalcM, bars_To_Process, pRoundForexToWholePip, pNormalizationPeriod, bandPeriod, fast, slow, stdDevNumber, pAlgorithm);
		}

		public ARC.ARC_DeltaForce ARC_DeltaForce(ISeries<double> input, string iPCalcM, int bars_To_Process, bool pRoundForexToWholePip, int pNormalizationPeriod, int bandPeriod, int fast, int slow, double stdDevNumber, ARC_DeltaForce_Algorithm pAlgorithm)
		{
			if (cacheARC_DeltaForce != null)
				for (int idx = 0; idx < cacheARC_DeltaForce.Length; idx++)
					if (cacheARC_DeltaForce[idx] != null && cacheARC_DeltaForce[idx].iPCalcM == iPCalcM && cacheARC_DeltaForce[idx].Bars_To_Process == bars_To_Process && cacheARC_DeltaForce[idx].pRoundForexToWholePip == pRoundForexToWholePip && cacheARC_DeltaForce[idx].pNormalizationPeriod == pNormalizationPeriod && cacheARC_DeltaForce[idx].BandPeriod == bandPeriod && cacheARC_DeltaForce[idx].Fast == fast && cacheARC_DeltaForce[idx].Slow == slow && cacheARC_DeltaForce[idx].StdDevNumber == stdDevNumber && cacheARC_DeltaForce[idx].pAlgorithm == pAlgorithm && cacheARC_DeltaForce[idx].EqualsInput(input))
						return cacheARC_DeltaForce[idx];
			return CacheIndicator<ARC.ARC_DeltaForce>(new ARC.ARC_DeltaForce(){ iPCalcM = iPCalcM, Bars_To_Process = bars_To_Process, pRoundForexToWholePip = pRoundForexToWholePip, pNormalizationPeriod = pNormalizationPeriod, BandPeriod = bandPeriod, Fast = fast, Slow = slow, StdDevNumber = stdDevNumber, pAlgorithm = pAlgorithm }, input, ref cacheARC_DeltaForce);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_DeltaForce ARC_DeltaForce(string iPCalcM, int bars_To_Process, bool pRoundForexToWholePip, int pNormalizationPeriod, int bandPeriod, int fast, int slow, double stdDevNumber, ARC_DeltaForce_Algorithm pAlgorithm)
		{
			return indicator.ARC_DeltaForce(Input, iPCalcM, bars_To_Process, pRoundForexToWholePip, pNormalizationPeriod, bandPeriod, fast, slow, stdDevNumber, pAlgorithm);
		}

		public Indicators.ARC.ARC_DeltaForce ARC_DeltaForce(ISeries<double> input , string iPCalcM, int bars_To_Process, bool pRoundForexToWholePip, int pNormalizationPeriod, int bandPeriod, int fast, int slow, double stdDevNumber, ARC_DeltaForce_Algorithm pAlgorithm)
		{
			return indicator.ARC_DeltaForce(input, iPCalcM, bars_To_Process, pRoundForexToWholePip, pNormalizationPeriod, bandPeriod, fast, slow, stdDevNumber, pAlgorithm);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_DeltaForce ARC_DeltaForce(string iPCalcM, int bars_To_Process, bool pRoundForexToWholePip, int pNormalizationPeriod, int bandPeriod, int fast, int slow, double stdDevNumber, ARC_DeltaForce_Algorithm pAlgorithm)
		{
			return indicator.ARC_DeltaForce(Input, iPCalcM, bars_To_Process, pRoundForexToWholePip, pNormalizationPeriod, bandPeriod, fast, slow, stdDevNumber, pAlgorithm);
		}

		public Indicators.ARC.ARC_DeltaForce ARC_DeltaForce(ISeries<double> input , string iPCalcM, int bars_To_Process, bool pRoundForexToWholePip, int pNormalizationPeriod, int bandPeriod, int fast, int slow, double stdDevNumber, ARC_DeltaForce_Algorithm pAlgorithm)
		{
			return indicator.ARC_DeltaForce(input, iPCalcM, bars_To_Process, pRoundForexToWholePip, pNormalizationPeriod, bandPeriod, fast, slow, stdDevNumber, pAlgorithm);
		}
	}
}

#endregion
