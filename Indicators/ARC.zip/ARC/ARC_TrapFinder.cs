#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Controls;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
public enum ARC_TrapFinder_GapMeasurements {Ticks, ATR}

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    [CategoryOrder("Parameters", 10)]
    [CategoryOrder("Visuals", 20)]

	public class ARC_TrapFinder : Indicator
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "TrapFinder";

		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22890", "27405", "22344"};//27405 is Annual Membership
		private string indicatorVersion = "v1.0";
		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		const int SUPPORT = 1;
		const int RESISTANCE = -1;
		private ATR atr;
		private double PriorClose;
		private double traptop = 0;
		private double trapbot = 0;
//		bool Printed = false;
		private int AudibleABar = -1;
		SharpDX.Direct2D1.Brush BrokenFillBrushDX = null;
		SharpDX.Direct2D1.Brush TestedFillBrushDX = null;
		SharpDX.Direct2D1.Brush FreshFillBrushDX = null;
		
        private string toolbarname = "TrapFinderTB", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private System.Windows.Controls.Grid indytoolbar;
        private Menu MenuControlContainer;
        private MenuItem MenuControl;

		
		private class TrapData{
			public double Top;
			public double Bot;
			public int Type;
			public int TestedABar =-1;
			public int BrokenABar =-1;
			public TrapData(double top, double bot, int type){
				Top = top; Bot = bot; Type = type;
			}
		}
		SortedDictionary<int,TrapData> Traps = new SortedDictionary<int,TrapData>();
        #region private void addToolBar()
        private void addToolBar()
        {
//			uID = Instrument.FullName+" "+Bars.BarsPeriod.ToString()+" "+DateTime.Now.Ticks.ToString();//prevent multiple toolbar with same name
//			uID = uID.Replace(" ",string.Empty);
			uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
			Print("uID: "+uID);
//            gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
//            gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
//            gLabel = new Label();//#RJBug001

            MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
            MenuControl = new MenuItem { BorderThickness = new Thickness(2), BorderBrush = Brushes.Maroon, Foreground = Brushes.Maroon, Background = Brushes.White, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13, Header = pButtonText };
            MenuControlContainer.Items.Add(MenuControl);

            MenuItem miShowFreshTraps, miShowTestedTraps, miShowBrokenTraps, miEnableSounds;

			Separator separator = new Separator();

            miShowFreshTraps = new MenuItem { Header = "Show Fresh Traps " + (this.pShowFreshTraps ? "ON" : "OFF"), Name = "pShowFresh"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
            miShowFreshTraps.Click += delegate (object o, RoutedEventArgs e){
				pShowFreshTraps = !pShowFreshTraps;
				miShowFreshTraps.Header = "Show Fresh Traps " + (this.pShowFreshTraps ? "ON" : "OFF");
				ForceRefresh();
			};
            MenuControl.Items.Add(miShowFreshTraps);

            miShowTestedTraps = new MenuItem { Header = "Show Tested Traps " + (this.pShowTestedTraps ? "ON" : "OFF"), Name = "pShowTested"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
            miShowTestedTraps.Click += delegate (object o, RoutedEventArgs e){
				pShowTestedTraps = !pShowTestedTraps;
				miShowTestedTraps.Header = "Show Tested Traps " + (this.pShowTestedTraps ? "ON" : "OFF");
				ForceRefresh();
			};
            MenuControl.Items.Add(miShowTestedTraps);

            miShowBrokenTraps = new MenuItem { Header = "Show Broken Traps " + (this.pShowBrokenTraps ? "ON" : "OFF"), Name = "pShowBroken"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
            miShowBrokenTraps.Click += delegate (object o, RoutedEventArgs e){
				pShowBrokenTraps = !pShowBrokenTraps;
				miShowBrokenTraps.Header = "Show Broken Traps " + (this.pShowBrokenTraps ? "ON" : "OFF");
				ForceRefresh();
			};
            MenuControl.Items.Add(miShowBrokenTraps);

            MenuControl.Items.Add(separator);

			miEnableSounds = new MenuItem { Header = "Sound Alerts: " + (this.pEnableSoundAlerts ? "ON" : "OFF"), Name = "pShowBroken"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true, FontWeight=FontWeights.Normal };
            miEnableSounds.Click += delegate (object o, RoutedEventArgs e){
				pEnableSoundAlerts = !pEnableSoundAlerts;
				miEnableSounds.Header = "Sound Alerts: " + (this.pEnableSoundAlerts ? "ON" : "OFF");
				ForceRefresh();
			};
            MenuControl.Items.Add(miEnableSounds);

            //------------------


//            MenuItem buttonMST = new MenuItem { Header = "RE-CALCULATE RATIOS", Name = "patternsClick", HorizontalAlignment = HorizontalAlignment.Center, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = false };
//            buttonMST.Click += ReloadChart_Click;
//            MenuControl.Items.Add(buttonMST);

            indytoolbar.Children.Add(MenuControlContainer);
        }
        #endregion
        #region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion
		protected override void OnStateChange()
		{
			#region -- OnStateChange --
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "ARC_TrapFinder";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive = true;
				GapTicks			= 8;
				GapATRMultiple		= 0.5;
				ATRPeriod			= 14;
				pBrokenFillOpacity  = 50;
				pTestedFillOpacity  = 50;
				pFreshFillOpacity   = 50;
				GapMeasurement		= ARC_TrapFinder_GapMeasurements.ATR;
				pBrokenFillBrush = Brushes.DimGray;
				pTestedFillBrush = Brushes.Silver;
				pFreshFillBrush  = Brushes.Orange;
				pShowFreshTraps  = true;
				pShowTestedTraps = true;
				pShowBrokenTraps = true;
				pButtonText = "TrapFinder";
				SupZoneHitWAV = "none";
				ResZoneHitWAV = "none";
				pEnableSoundAlerts = false;

				AddPlot(new Stroke(Brushes.Orange, 1), PlotStyle.Hash, "TrapTop");
				AddPlot(new Stroke(Brushes.Orange, 1), PlotStyle.Hash, "TrapBottom");
			}
			else if (State == State.Configure)
			{
				IsDebug = System.IO.File.Exists(@"c:\222222222222.txt") && (NinjaTrader.Cbi.License.MachineId.CompareTo("1E53E271B82EC62C7C03A15C336229AE")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion
				atr = ATR(this.ATRPeriod);
			}
			else if (State == State.Historical){
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                        {
                            chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                            if (chartWindow == null) return;

                            foreach (DependencyObject item in chartWindow.MainMenu) if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                            if (!isToolBarButtonAdded)
                            {
                                indytoolbar = new Grid { Visibility = Visibility.Collapsed };

                                addToolBar();

                                chartWindow.MainMenu.Add(indytoolbar);
                                chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                                foreach (TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                                System.Windows.Automation.AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                            }
                        }));
                }
                #endregion
			}
            else if (State == State.Terminated)
            {
                if (chartWindow != null)
                {
                    if (indytoolbar != null)
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            chartWindow.MainMenu.Remove(indytoolbar);
                            indytoolbar = null;

                            chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
                            chartWindow = null;
                        }));
                    }
                }
            }
			#endregion
		}

		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(CurrentBar<5) return;
			double minpts = this.GapTicks*TickSize;
			if(this.GapMeasurement == ARC_TrapFinder_GapMeasurements.ATR){
				minpts = atr[0] * this.GapATRMultiple;
			}

			double diffpts = Low[0] - High[2];
			if(diffpts > 0 && diffpts > minpts)
			{
				traptop = Low[0];
				trapbot = High[2];
				Traps[CurrentBar-1] = new TrapData(Low[0], High[2], SUPPORT);
			}
			diffpts = Low[2] - High[0];
			if(diffpts > 0 && diffpts > minpts)
			{
				traptop = Low[2];
				trapbot = High[0];
				Traps[CurrentBar-1] = new TrapData(Low[2], High[0], RESISTANCE);
			}
			if(traptop != 0){
				TrapTop[0] = traptop;
				TrapBottom[0] = trapbot;
			}

			int ZoneHit = 0;
			double PriceHit = 0;
			if(Close[0] != PriorClose){
				var traps = Traps.Values.Where(k => k.TestedABar<0).ToList();
				foreach(TrapData val in traps){
					if(IsBetween(val.Top, val.Bot, High[0]) || IsBetween(val.Top, val.Bot, Low[0])){
						val.TestedABar = CurrentBar;
						if(pEnableSoundAlerts){
							ZoneHit = val.Type;
							if(IsBetween(val.Top, val.Bot, High[0]))     PriceHit = High[0];
							else if(IsBetween(val.Top, val.Bot, Low[0])) PriceHit = Low[0];
						}
					}
				}
				if(ZoneHit!=0 && State != State.Historical && CurrentBar!=AudibleABar){
					AudibleABar = CurrentBar;
					if(ZoneHit==RESISTANCE) Alert(AudibleABar.ToString(),Priority.High,"Res trap hit at "+PriceHit, AddSoundFolder(ResZoneHitWAV), 1, Brushes.Green,Brushes.White);
					else if(ZoneHit==SUPPORT) Alert(AudibleABar.ToString(),Priority.High,"Sup trap hit at "+PriceHit, AddSoundFolder(SupZoneHitWAV), 1, Brushes.Red,Brushes.White);
				}
				traps = Traps.Values.Where(k => k.BrokenABar<0).ToList();
				foreach(TrapData val in traps){
					if(val.Type == RESISTANCE   && High[0] >= val.Top) 
						val.BrokenABar = CurrentBar;
					else if(val.Type == SUPPORT && Low[0] <= val.Bot) 
						val.BrokenABar = CurrentBar;
				}
			}
			PriorClose = Close[0];
//			if(CurrentBar > Bars.Count-4 && !Printed){
//				Printed = true;
//				foreach(var kvp in Traps) 
//					if(kvp.Value.BrokenABar>0) Draw.Rectangle(this,kvp.Key.ToString(), Time.GetValueAt(kvp.Key), kvp.Value.Top, Time.GetValueAt(kvp.Value.BrokenABar), kvp.Value.Bot, Brushes.Pink);
//			}
		}
//======================================================================================================
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
//======================================================================================================
		public override void OnRenderTargetChanged()
		{
			#region -- OnRenderTargetChanged --
			if(FreshFillBrushDX!=null && !FreshFillBrushDX.IsDisposed) FreshFillBrushDX.Dispose(); FreshFillBrushDX=null;
			if(RenderTarget!=null) {
				FreshFillBrushDX = pFreshFillBrush.ToDxBrush(RenderTarget); FreshFillBrushDX.Opacity = pFreshFillOpacity/100f;
			}
			if(TestedFillBrushDX!=null && !TestedFillBrushDX.IsDisposed) TestedFillBrushDX.Dispose(); TestedFillBrushDX=null;
			if(RenderTarget!=null) {
				TestedFillBrushDX = pTestedFillBrush.ToDxBrush(RenderTarget); TestedFillBrushDX.Opacity = pTestedFillOpacity/100f;
			}
			if(BrokenFillBrushDX!=null && !BrokenFillBrushDX.IsDisposed) BrokenFillBrushDX.Dispose(); BrokenFillBrushDX=null;
			if(RenderTarget!=null) {
				BrokenFillBrushDX = pBrokenFillBrush.ToDxBrush(RenderTarget); BrokenFillBrushDX.Opacity = pBrokenFillOpacity/100f;
			}
			#endregion
		}
//======================================================================================================
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            #region -- conditions to return --
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (Bars == null || ChartControl == null) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
			if(IsInHitTest) return;
            #endregion

			int LMaB = ChartBars.FromIndex;
			int RMaB = ChartBars.ToIndex;
			if(pShowBrokenTraps){
				var traps = Traps.Where(k => k.Key< RMaB && k.Value.BrokenABar > LMaB).ToList();
				if(traps!=null){
					foreach(var kvp in traps){
						var xLeft  = chartControl.GetXByBarIndex(ChartBars, kvp.Key);
						var xRight = chartControl.GetXByBarIndex(ChartBars, kvp.Value.BrokenABar);
						var yTop = (float)chartScale.GetYByValue(kvp.Value.Top);
						var yBot = (float)chartScale.GetYByValue(kvp.Value.Bot);
						RenderTarget.FillRectangle(new SharpDX.RectangleF(xLeft, yTop, xRight-xLeft, yBot-yTop), BrokenFillBrushDX);
					}
				}
			}
			if(pShowTestedTraps){
				var traps = Traps.Where(k => k.Key< RMaB && k.Value.BrokenABar<0 && k.Value.TestedABar > LMaB).ToList();
				if(traps!=null){
					foreach(var kvp in traps){
						var xLeft  = chartControl.GetXByBarIndex(ChartBars, kvp.Key);
						var xRight = chartControl.GetXByBarIndex(ChartBars, kvp.Value.TestedABar);
						var yTop = (float)chartScale.GetYByValue(kvp.Value.Top);
						var yBot = (float)chartScale.GetYByValue(kvp.Value.Bot);
						RenderTarget.FillRectangle(new SharpDX.RectangleF(xLeft, yTop, xRight-xLeft, yBot-yTop), TestedFillBrushDX);
					}
				}
			}
			if(pShowFreshTraps){
				var traps = Traps.Where(k => k.Key< RMaB && k.Value.BrokenABar<0 && k.Value.TestedABar<0).ToList();
				if(traps!=null){
					foreach(var kvp in traps){
						var xLeft  = chartControl.GetXByBarIndex(ChartBars, kvp.Key);
						var xRight = chartControl.GetXByBarIndex(ChartBars, RMaB)+20;
						var yTop = (float)chartScale.GetYByValue(kvp.Value.Top);
						var yBot = (float)chartScale.GetYByValue(kvp.Value.Bot);
						RenderTarget.FillRectangle(new SharpDX.RectangleF(xLeft, yTop, xRight-xLeft, yBot-yTop), FreshFillBrushDX);
					}
				}
			}
		}

//========================================================================================================================
		private bool IsBetween(double H, double L, double price){
			return price < H && price > L;
		}
//========================================================================================================================
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("none");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }

		#region Properties
		[NinjaScriptProperty]
		[Display(Name="Measurement", Description="How to measure the gap", Order=10, GroupName="Parameters")]
		public ARC_TrapFinder_GapMeasurements GapMeasurement
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Gap Ticks", Description="Gap in ticks", Order=30, GroupName="Parameters")]
		public int GapTicks
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.01, double.MaxValue)]
		[Display(Name="Gap ATR Multiple", Description="Gap in ATR multiples", Order=50, GroupName="Parameters")]
		public double GapATRMultiple
		{ get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name="ATR Period", Description="Used when ATR is chosen for size type", Order=60, GroupName="Parameters")]
		public int ATRPeriod
		{ get; set; }



		[Display(Order = 10, Name="Show Fresh Traps", Description="", GroupName="Visuals")]
		public bool pShowFreshTraps {get;set;}

		[XmlIgnore]
		[Display(Order = 20, Name = "Fresh Trap brush", GroupName = "Visuals", Description = "Color of Fresh Traps")]
		public Brush pFreshFillBrush { get; set; }
				[Browsable(false)]
				public string pFreshFillBrushSerialize{ get { return Serialize.BrushToString(pFreshFillBrush); } set { pFreshFillBrush = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Order = 30, Name="Fresh Trap opacity", Description="Opacity of Fresh Trap rectangles", GroupName="Visuals")]
		public int pFreshFillOpacity
		{ get; set; }

		[Display(Order = 40, Name="Show Tested Traps", Description="", GroupName="Visuals")]
		public bool pShowTestedTraps {get;set;}

		[XmlIgnore]
		[Display(Order = 50, Name = "Tested Trap brush", GroupName = "Visuals", Description = "Color of Tested Traps")]
		public Brush pTestedFillBrush { get; set; }
				[Browsable(false)]
				public string pTestedFillBrushSerialize{ get { return Serialize.BrushToString(pTestedFillBrush); } set { pTestedFillBrush = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Order = 60, Name="Tested Trap opacity", Description="Opacity of Tested Trap rectangles", GroupName="Visuals")]
		public int pTestedFillOpacity
		{ get; set; }

		[Display(Order = 70, Name="Show Broken Traps", Description="", GroupName="Visuals")]
		public bool pShowBrokenTraps {get;set;}

		[XmlIgnore]
		[Display(Order = 80, Name = "Broken Trap brush", GroupName = "Visuals", Description = "Color of Broken Traps")]
		public Brush pBrokenFillBrush { get; set; }
				[Browsable(false)]
				public string pBrokenFillBrushSerialize{ get { return Serialize.BrushToString(pBrokenFillBrush); } set { pBrokenFillBrush = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Order = 90, Name="Broken Trap opacity", Description="Opacity of Broken Trap rectangles", GroupName="Visuals")]
		public int pBrokenFillOpacity
		{ get; set; }
		
        [Display(Name = "Button Text", GroupName = "Visuals", Description = "", Order = 100)]
		public string pButtonText {get;set;}

		[Display(Order = 10, Name = "Enable sounds", GroupName = "Alerts", ResourceType = typeof(Resource))]
		public bool pEnableSoundAlerts { get; set; }

		[Display(Order = 20, Name = "Support trap Hit WAV", GroupName = "Alerts", ResourceType = typeof(Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string SupZoneHitWAV { get; set; }

		[Display(Order = 30, Name = "Resistance trap Hit WAV", GroupName = "Alerts", ResourceType = typeof(Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string ResZoneHitWAV { get; set; }
		#endregion

		#region Plots
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> TrapTop
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> TrapBottom
		{
			get { return Values[1]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_TrapFinder[] cacheARC_TrapFinder;
		public ARC.ARC_TrapFinder ARC_TrapFinder(ARC_TrapFinder_GapMeasurements gapMeasurement, int gapTicks, double gapATRMultiple)
		{
			return ARC_TrapFinder(Input, gapMeasurement, gapTicks, gapATRMultiple);
		}

		public ARC.ARC_TrapFinder ARC_TrapFinder(ISeries<double> input, ARC_TrapFinder_GapMeasurements gapMeasurement, int gapTicks, double gapATRMultiple)
		{
			if (cacheARC_TrapFinder != null)
				for (int idx = 0; idx < cacheARC_TrapFinder.Length; idx++)
					if (cacheARC_TrapFinder[idx] != null && cacheARC_TrapFinder[idx].GapMeasurement == gapMeasurement && cacheARC_TrapFinder[idx].GapTicks == gapTicks && cacheARC_TrapFinder[idx].GapATRMultiple == gapATRMultiple && cacheARC_TrapFinder[idx].EqualsInput(input))
						return cacheARC_TrapFinder[idx];
			return CacheIndicator<ARC.ARC_TrapFinder>(new ARC.ARC_TrapFinder(){ GapMeasurement = gapMeasurement, GapTicks = gapTicks, GapATRMultiple = gapATRMultiple }, input, ref cacheARC_TrapFinder);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_TrapFinder ARC_TrapFinder(ARC_TrapFinder_GapMeasurements gapMeasurement, int gapTicks, double gapATRMultiple)
		{
			return indicator.ARC_TrapFinder(Input, gapMeasurement, gapTicks, gapATRMultiple);
		}

		public Indicators.ARC.ARC_TrapFinder ARC_TrapFinder(ISeries<double> input , ARC_TrapFinder_GapMeasurements gapMeasurement, int gapTicks, double gapATRMultiple)
		{
			return indicator.ARC_TrapFinder(input, gapMeasurement, gapTicks, gapATRMultiple);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_TrapFinder ARC_TrapFinder(ARC_TrapFinder_GapMeasurements gapMeasurement, int gapTicks, double gapATRMultiple)
		{
			return indicator.ARC_TrapFinder(Input, gapMeasurement, gapTicks, gapATRMultiple);
		}

		public Indicators.ARC.ARC_TrapFinder ARC_TrapFinder(ISeries<double> input , ARC_TrapFinder_GapMeasurements gapMeasurement, int gapTicks, double gapATRMultiple)
		{
			return indicator.ARC_TrapFinder(input, gapMeasurement, gapTicks, gapATRMultiple);
		}
	}
}

#endregion
