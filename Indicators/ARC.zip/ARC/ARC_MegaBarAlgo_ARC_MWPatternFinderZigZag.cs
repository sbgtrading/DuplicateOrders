using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using SharpDX.Direct2D1;

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public class ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag : ARC_MegaBarAlgo_ARCIndicatorBase
	{
		public override string ProductVersion => "v1.0.1 (4/19/2023)";
		public override bool ColicensedOnly => true;

		[Browsable(false)]
		[XmlIgnore]
		internal List<ARC_MegaBarAlgo_ZigZagPoint> SwingPoints
		{
			get
			{
				Update();
				return swingPoints;
			}
		}
		[SuppressMessage("ReSharper", "CollectionNeverUpdated.Local")]
		private readonly List<ARC_MegaBarAlgo_ZigZagPoint> swingPoints = new List<ARC_MegaBarAlgo_ZigZagPoint>();

		/// <summary>
		/// The farthest price reached in the trend direction (i.e. Highest high since trend start if trend is up)
		/// </summary>
		private double extremeInTrendDir;
		private readonly Dictionary<int, Indicator> swingExtreme = new Dictionary<int, Indicator>();
		private int trendDir;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && !this.ARC_MegaBarAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				IsOverlay = true;
				IncludeWicks = true;
				SwingStrength = 3;
			}
			else if (State == State.Configure)
			{
				swingPoints.Clear();
				extremeInTrendDir = 0;
				trendDir = 0;
			}
			else if (State == State.DataLoaded)
			{
				swingExtreme[-1] = MIN(Low, SwingStrength);
				swingExtreme[1] = MAX(High, SwingStrength);
			}
		}

		private ISeries<double> ZzHighSeries => IncludeWicks ? High : Close;
		private ISeries<double> ZzLowSeries => IncludeWicks ? Low : Close;

		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_MegaBarAlgo_IsLicensed())
				return;

			if (CurrentBar < 1)
				return;

			if (trendDir == 0)
			{
				if (ZzHighSeries[0] > ZzHighSeries[1])
				{
					trendDir = 1;
					swingPoints.Add(new ARC_MegaBarAlgo_ZigZagPoint(1, CurrentBar, ZzHighSeries[0]));
					extremeInTrendDir = ZzHighSeries[0];
				}
				else if (ZzLowSeries[0] < ZzLowSeries[1])
				{
					trendDir = -1;
					swingPoints.Add(new ARC_MegaBarAlgo_ZigZagPoint(-1, CurrentBar, ZzLowSeries[0]));
					extremeInTrendDir = ZzLowSeries[0];
				}

				return;
			}

			var barDir = (Low[0] - Close[0]).ApproxCompare(High[0] - Close[0]);
			if (barDir == 0)
				barDir = -1;

			// Create a bool array describing whether or not the next two pivots (opposite to current trend, then current trend again) are formed this bar
			var pivotsFormed = new[] { trendDir, -trendDir }
				.Select(td => (td == 1 ? ZzLowSeries : ZzHighSeries)[0].ApproxCompare(swingExtreme[-td][1]) == -td)
				.ToArray();
			pivotsFormed[1] &= pivotsFormed[0] && barDir == trendDir;

			// If we don't receive an opposing pivot, or we do but we estimate the in current trend dir extreme occurred first, update our pivot
			if (!pivotsFormed[1])
			{
				var newExtremeVal = trendDir == 1 ? ZzHighSeries[0] : ZzLowSeries[0];
				if (newExtremeVal.ApproxCompare(extremeInTrendDir) != -trendDir)
				{
					extremeInTrendDir = newExtremeVal;
					swingPoints.Last().Bar = CurrentBar;
					swingPoints.Last().Price = newExtremeVal;
				}
			}

			foreach (var pivotFormed in pivotsFormed)
			{
				// If we didn't receive another new pivot, stop here
				if (!pivotFormed)
					return;

				// Add our new pivot point
				trendDir *= -1;
				extremeInTrendDir = trendDir == 1 ? ZzHighSeries[0] : ZzLowSeries[0];
				swingPoints.Add(new ARC_MegaBarAlgo_ZigZagPoint(trendDir, CurrentBar, extremeInTrendDir));
			}
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (!this.ARC_MegaBarAlgo_IsLicensed())
				return;

			if (!IsVisible)
				return;

			var priorAaMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
			using (var brush = ZigZagStroke.Brush.ToDxBrush(RenderTarget))
				RenderTarget.ARC_MegaBarAlgo_DrawZigZag(this, chartScale, swingPoints, brush, ZigZagStroke.Width, lineStyle: ZigZagStroke.DashStyleHelper);
			RenderTarget.AntialiasMode = priorAaMode;
		}
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Order = 0, Name = "Swing Strength", GroupName = "Parameters", Description = "Number of bars used to identify a swing high or low")]
		public int SwingStrength { get; set; }
		
		[NinjaScriptProperty]
		[Display(Order = 1, Name = "Include Wicks", GroupName = "Parameters", Description = "Whether or not to use wicks (vs closes) for pivot points")]
		public bool IncludeWicks { get; set; }

		[Display(Name = "Zig Zag Stroke", GroupName = "Parameters", Order = 2)]
		public Stroke ZigZagStroke { get; set; } = new Stroke(Brushes.White, DashStyleHelper.Dash, 2);
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag[] cacheARC_MegaBarAlgo_ARC_MWPatternFinderZigZag;
		public ARC.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(int swingStrength, bool includeWicks)
		{
			return ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(Input, swingStrength, includeWicks);
		}

		public ARC.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(ISeries<double> input, int swingStrength, bool includeWicks)
		{
			if (cacheARC_MegaBarAlgo_ARC_MWPatternFinderZigZag != null)
				for (int idx = 0; idx < cacheARC_MegaBarAlgo_ARC_MWPatternFinderZigZag.Length; idx++)
					if (cacheARC_MegaBarAlgo_ARC_MWPatternFinderZigZag[idx] != null && cacheARC_MegaBarAlgo_ARC_MWPatternFinderZigZag[idx].SwingStrength == swingStrength && cacheARC_MegaBarAlgo_ARC_MWPatternFinderZigZag[idx].IncludeWicks == includeWicks && cacheARC_MegaBarAlgo_ARC_MWPatternFinderZigZag[idx].EqualsInput(input))
						return cacheARC_MegaBarAlgo_ARC_MWPatternFinderZigZag[idx];
			return CacheIndicator<ARC.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag>(new ARC.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(){ SwingStrength = swingStrength, IncludeWicks = includeWicks }, input, ref cacheARC_MegaBarAlgo_ARC_MWPatternFinderZigZag);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(int swingStrength, bool includeWicks)
		{
			return indicator.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(Input, swingStrength, includeWicks);
		}

		public Indicators.ARC.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(ISeries<double> input , int swingStrength, bool includeWicks)
		{
			return indicator.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(input, swingStrength, includeWicks);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(int swingStrength, bool includeWicks)
		{
			return indicator.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(Input, swingStrength, includeWicks);
		}

		public Indicators.ARC.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(ISeries<double> input , int swingStrength, bool includeWicks)
		{
			return indicator.ARC_MegaBarAlgo_ARC_MWPatternFinderZigZag(input, swingStrength, includeWicks);
		}
	}
}

#endregion
