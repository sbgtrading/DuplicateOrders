#define DoLicense
#define MODERATORS
#define ContextualTextBoxes_EnableDisable

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region Category Order
    [Gui.CategoryOrder("General Settings", 0)]
    [Gui.CategoryOrder("Pattern Size Settings", 1)]
    [Gui.CategoryOrder("Trade Plan", 2)]
    [Gui.CategoryOrder("ABC", 3)]
    [Gui.CategoryOrder("ABCD Flag", 4)]
    [Gui.CategoryOrder("WEDGE", 5)]
    [Gui.CategoryOrder("ASCENDING/ DESCENDING TRIANGLE", 6)]
    [Gui.CategoryOrder("SYMMETRIC TRIANGLE", 7)]
    [Gui.CategoryOrder("EXPANDING TRIANGLE", 8)]
    [Gui.CategoryOrder("RECTANGLE", 9)]
    [Gui.CategoryOrder("FLAG", 10)]
	[Gui.CategoryOrder("~ License ~", 1000)]
    [Gui.CategoryOrder("Indicator Version", 1100)]
    #endregion

    public class ARC_ACP : Indicator, ICustomTypeDescriptor 
	{
        #region Indicators, Series and Floating Variables

        private bool _bIsToolBarButtonAdded = false;
        //string
        private string _sToolbarName = "NSCPTToolBar", uID;
        private string _sThisName = "ARC_ACP";
        private string _sSoundName = "";
        //other
        private List<Depth> _lDepths = new List<Depth>();
        private GeneralSettings _GeneralSettings = null;
        private EntryStopsTargetsSettings _estSettings = null;

        #endregion

        #region Licensing Floating Variables
		private bool IsDebug        = false;
		private bool ValidLicense   = false;
		private bool IsExpired      = true;

		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "AutoChartPattern";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "19880", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId,LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

        #endregion

        #region Controls Variables
        private Menu _mnuControlContainer = null;
        private Grid _grdIndyToolbar;
        private Dictionary<string, MenuItem> _dicMenuItems = new Dictionary<string, MenuItem>();
        private Dictionary<string, TextBox> _dicTextBoxes = new Dictionary<string, TextBox>();
        private Dictionary<string, Button> _dicButtons = new Dictionary<string, Button>();
        #endregion

        #region On State Change
        protected override void OnStateChange()
        {
            #region Set Defaults
            if (State == State.SetDefaults) 
            {
                #region Default Crap
                Description = @"";
                Name = _sThisName;
                Calculate = Calculate.OnPriceChange;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = false;
                ZOrder = 0;
                #endregion

                #region Indicator Settings

                #region General Settings
                FillTransparency = 5;
                PatternNameColor = Brushes.White;
                Font = new SimpleFont("Arial", 14);
                ShowPattName = true;

                ShowLarge = false;
                largeSwingStrength = 32;
                largeSensitivity = 0.0;
                LargeBreakMultiple = 1;

                ShowMedium = true;
                mediumSwingStrength = 16;
                mediumSensitivity = 0.0;
                MediumBreakMultiple = 1;

                ShowSmall = false;
                smallSwingStrength = 3;
                smallSensitivity = 0.0;
                SmallBreakMultiple = 1;

                ShowFresh = true;
                ShowFilled = true;
                ShowCompleted = true;
                ShowInvalidated = false;

                ShowLong = true;
                ShowShort = true;
                ShowNeutral = false;

                UseSound = false;
                SoundAlert = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", "Alert1.wav");

                EntryType = "Close Of Bar";

                ShowInfoBox = true; //not in general

                ButtonText = "ACP"; //not in general STRING

                #endregion

                #region Trade Plan
                PatternBreakPercent = 50;
                TradePlan = "Pattern Defined";
                EntryLineColor = new Stroke(Brushes.DarkBlue, DashStyleHelper.Solid, 2);
                StopLineColor = new Stroke(Brushes.Red, DashStyleHelper.Solid, 2);
                TargetLineColor = new Stroke(Brushes.Lime, DashStyleHelper.Solid, 2);
                LabelColor = Brushes.Lime;
                Linelength = 10;
                StopTicks = 30;
                Target1Ticks = 30;
                Target2Ticks = 60;
                #endregion

                #region Patterns Properties

                #region ABC
                ShowABC = false;
                Fib1 = 38.2;
                Fib3 = 61.8;
                ABCStrokeBull = new Stroke(Brushes.Lime, DashStyleHelper.Solid, 3);
                ABCStrokeBear = new Stroke(Brushes.Red, DashStyleHelper.Solid, 3);
                StopABC = 5;
                Target1ABC = 1.0;
                Target2ABC = 1.9;
                #endregion

                #region ABCD Flag
                ShowABCD = true;
                Retracement1MinFibABCD = 61.8;
                Retracement1MaxFibABCD = 88.6;
                Retracement2MinFibABCD = 38.2;
                Retracement2MaxFibABCD = 100;
                ABCDStrokeBull = new Stroke(Brushes.Lime, DashStyleHelper.Solid, 3);
                ABCDStrokeBear = new Stroke(Brushes.Red, DashStyleHelper.Solid, 3);
                StopABCD = 5;
                Target1ABCD = 1.0;
                Target2ABCD = 1.9;
                #endregion

                #region Wedge
                ShowWedge = true;
                WedgeMinAngle = 5;
                WedgeMaxAngle = 20;
                WedgeNeutralStroke = new Stroke(Brushes.Yellow, DashStyleHelper.Solid, 3);
                WedgeBullishStroke = new Stroke(Brushes.Lime, DashStyleHelper.Solid, 3);
                WedgeBearishStroke = new Stroke(Brushes.Red, DashStyleHelper.Solid, 3);
                StopWedge = 5;
                Target1Wedge = 1.0;
                Target2Wedge = 1.9;
                #endregion

                #region Ascending/ Descending Triangle
                ShowAscDesc = true;
                AscDescTriangMinAngle = 5;
                AscDescTriangMaxAngle = 45;
                AscTriangStroke = new Stroke(Brushes.Lime, DashStyleHelper.Solid, 3);
                DescTriangStroke = new Stroke(Brushes.Red, DashStyleHelper.Solid, 3);
                StraightLineDev = 5;
                StopAscDescTriang = 5;
                Target1AscDescTriang = 1.0;
                Target2AscDescTriang = 1.9;
                #endregion

                #region Symmetric Triangle
                ShowSym = true;
                SymTriangMinAngle = 5;
                SymTriangMaxAngle = 30;
                SymNeutralTriangStroke = new Stroke(Brushes.Yellow, DashStyleHelper.Solid, 3);
                SymBullishTriangStroke = new Stroke(Brushes.Lime, DashStyleHelper.Solid, 3);
                SymBearishTriangStroke = new Stroke(Brushes.Red, DashStyleHelper.Solid, 3);
                DevSlope = 50;
                StopSymmTriang = 5;
                Target1SymmTriang = 1.0;
                Target2SymmTriang = 1.9;
                #endregion

                #region Expanding Triangle
                ShowExp = false;
                ExpTriangMinAngle = 5;
                ExpTriangMaxAngle = 30;
                ExpNeutralTriangStroke = new Stroke(Brushes.Yellow, DashStyleHelper.Solid, 3);
                ExpBullishTriangStroke = new Stroke(Brushes.Lime, DashStyleHelper.Solid, 3);
                ExpBearishTriangStroke = new Stroke(Brushes.Red, DashStyleHelper.Solid, 3);
                MaxBars = 100;
                StopExpTriang = 5;
                Target1ExpTriang = 1.0;
                Target2ExpTriang = 1.9;
                #endregion

                #region Rectangle
                ShowRect = true;
                Dev = 5; //slope dev
                RectNeutralStroke = new Stroke(Brushes.Yellow, DashStyleHelper.Solid, 3);
                RectBullishStroke = new Stroke(Brushes.Lime, DashStyleHelper.Solid, 3);
                RectBearishStroke = new Stroke(Brushes.Red, DashStyleHelper.Solid, 3);
                StopRect = 5;
                Target1Rect = 1.0;
                Target2Rect = 1.9;
                #endregion

                #region Flag
                ShowFlag = false;
                FlagMinAngle = 1;
                FlagMaxAngle = 180;
                FlagBullishStroke = new Stroke(Brushes.Lime, DashStyleHelper.Solid, 3);
                FlagBearishStroke = new Stroke(Brushes.Red, DashStyleHelper.Solid, 3);
                SlopesDev = 90; //100 for paralel line AICI CRED CA TREB SA MODIFICAM UN PIC CALCULUL
                StopFlag = 38.2;
                Target1Flag = 1.0;
                Target2Flag = 1.9;
                #endregion

                #endregion

                #endregion
            }
            #endregion

            #region Other States

            #region State Configure
            else if (State == State.Configure)
            {
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion
//LogMsg("Test",LogLevel.Alert);
            }
            #endregion
            #region State Historical
            else if (State == State.Historical)
            {
                AddToToolBar();
            }
            #endregion

            #region State Data Loaded
            else if (State == State.DataLoaded)
			{
				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);

                _lDepths.Add(new Depth(smallSwingStrength, smallSensitivity, eDepthType.Small, MIN(Low, smallSwingStrength), MAX(High, smallSwingStrength), TickSize, ATR(256)) { ShowDepth = ShowSmall });
                _lDepths.Add(new Depth(mediumSwingStrength, mediumSensitivity, eDepthType.Medium, MIN(Low, mediumSwingStrength), MAX(High, mediumSwingStrength), TickSize, ATR(256)) { ShowDepth = ShowMedium });
                _lDepths.Add(new Depth(largeSwingStrength, largeSensitivity, eDepthType.Large, MIN(Low, largeSwingStrength), MAX(High, largeSwingStrength), TickSize, ATR(256)) { ShowDepth = ShowLarge });

                //Adding Default Settings
                _GeneralSettings = new GeneralSettings() { Indicator = this, SmallDeviation = SmallBreakMultiple, MediumDeviation = MediumBreakMultiple, LargeDeviation = LargeBreakMultiple, ShowLong = ShowLong, 
                    ShowShort = ShowShort, ShowNeutral = ShowNeutral, ShowLarge = ShowLarge, ShowMedium = ShowMedium, ShowSmall = ShowSmall, ShowFresh = ShowFresh, ShowFilled  = ShowFilled,
                    ShowCompleted = ShowCompleted,
                    ShowInvalidated = ShowInvalidated, 
                    Transparency = FillTransparency, ShowPatternName = ShowPattName, UseSound = UseSound, SoundAlert = SoundAlert, FontFamily = Font, TextBrush = PatternNameColor, TradePlan = TradePlan,
                    PatternBreakPercent = 1 - (PatternBreakPercent * 0.01),
                    TradePlanTextBrush = LabelColor
                };

                EntryStopsTargetsSettings _estUserDefinedSettings = new EntryStopsTargetsSettings() { EntryStroke = EntryLineColor, StopStroke = StopLineColor, TargetStroke = TargetLineColor, 
                    LineLength = Linelength, StopMultiple = StopTicks * TickSize, Target1Multiple = Target1Ticks * TickSize, Target2Multiple = Target2Ticks * TickSize };
                EntryStopsTargetsSettings _estPatternDefinedSettings = _estUserDefinedSettings.Clone() as EntryStopsTargetsSettings;

                //adding the settings to the pack
                _estPatternDefinedSettings.NewStopsTargetsSettings(StopWedge * TickSize, Target1Wedge, Target2Wedge);
                PatternSettings wedge = new PatternSettings(){ Name = "Wedge", Show = ShowWedge, NeutralPatternColors = WedgeNeutralStroke, BullPatternColors = WedgeBullishStroke, BearPatternColors = WedgeBearishStroke,
                    MinAngle = WedgeMinAngle, MaxAngle = WedgeMaxAngle, UserDefined = _estUserDefinedSettings.Clone() as EntryStopsTargetsSettings, PatternDefined = _estPatternDefinedSettings.Clone() as EntryStopsTargetsSettings };
                _GeneralSettings.AddPattern(ePatterns.Wedge, wedge);

                _estPatternDefinedSettings.NewStopsTargetsSettings(StopAscDescTriang * TickSize, Target1AscDescTriang, Target2AscDescTriang);
                PatternSettings ascT = new PatternSettings() { Name = "Ascending\r\nTriangle", Show = ShowAscDesc, BullPatternColors = AscTriangStroke, MinAngle = AscDescTriangMinAngle, MaxAngle = AscDescTriangMaxAngle, 
                    SlopeDev = StraightLineDev, UserDefined = _estUserDefinedSettings.Clone() as EntryStopsTargetsSettings, PatternDefined = _estPatternDefinedSettings.Clone() as EntryStopsTargetsSettings };
                _GeneralSettings.AddPattern(ePatterns.AscendingTriangle, ascT);
                PatternSettings descT = new PatternSettings() { Name = "Descending\r\nTriangle", Show = ShowAscDesc, BearPatternColors = DescTriangStroke, MinAngle = AscDescTriangMinAngle, MaxAngle = AscDescTriangMaxAngle, 
                    SlopeDev = StraightLineDev, UserDefined = _estUserDefinedSettings.Clone() as EntryStopsTargetsSettings, PatternDefined = _estPatternDefinedSettings.Clone() as EntryStopsTargetsSettings };
                _GeneralSettings.AddPattern(ePatterns.DescendingTriangle, descT);

                _estPatternDefinedSettings.NewStopsTargetsSettings(StopSymmTriang * TickSize, Target1SymmTriang, Target2SymmTriang);
                PatternSettings symmT = new PatternSettings() { Name = "Symmetric\r\nTriangle", Show = ShowSym, NeutralPatternColors = SymNeutralTriangStroke, BullPatternColors = SymBullishTriangStroke, 
                    BearPatternColors = SymBearishTriangStroke, MinAngle = SymTriangMinAngle, MaxAngle = SymTriangMaxAngle, SlopeDev = DevSlope, UserDefined = _estUserDefinedSettings.Clone() as EntryStopsTargetsSettings, 
                    PatternDefined = _estPatternDefinedSettings.Clone() as EntryStopsTargetsSettings };
                _GeneralSettings.AddPattern(ePatterns.SymmetricTriangle, symmT); 

                _estPatternDefinedSettings.NewStopsTargetsSettings(StopExpTriang * TickSize, Target1ExpTriang, Target2ExpTriang);
                PatternSettings expT = new PatternSettings() { Name = "Expanding\r\nTriangle", Show = ShowExp, NeutralPatternColors = ExpNeutralTriangStroke, BullPatternColors = ExpBullishTriangStroke, 
                    BearPatternColors = ExpBearishTriangStroke, MinAngle = ExpTriangMinAngle, MaxAngle = ExpTriangMaxAngle, MaxBars = MaxBars, UserDefined = _estUserDefinedSettings.Clone() as EntryStopsTargetsSettings,
                    PatternDefined = _estPatternDefinedSettings.Clone() as EntryStopsTargetsSettings };
                _GeneralSettings.AddPattern(ePatterns.ExpandingTriangle, expT); 

                _estPatternDefinedSettings.NewStopsTargetsSettings(StopRect * TickSize, Target1Rect, Target2Rect);
                PatternSettings rect = new PatternSettings() { Name = "Rectangle", Show = ShowRect, NeutralPatternColors = RectNeutralStroke, BullPatternColors = RectBullishStroke, BearPatternColors = RectBearishStroke, 
                    SlopeDev = Dev, UserDefined = _estUserDefinedSettings.Clone() as EntryStopsTargetsSettings, PatternDefined = _estPatternDefinedSettings.Clone() as EntryStopsTargetsSettings };
                _GeneralSettings.AddPattern(ePatterns.Rectangle, rect);

                //_estPatternDefinedSettings.NewStopsTargetsSettings(StopFlag * 0.01, Target1Flag * 0.01, Target2Flag * 0.01);
                //PatternSettings flag = new PatternSettings() { Name = "Flag", Show = ShowFlag, BearPatternColors = FlagBearishStroke, BullPatternColors = FlagBullishStroke, MinAngle = FlagMinAngle, MaxAngle = FlagMaxAngle, 
                //    SlopeDev = SlopesDev, UserDefined = _estUserDefinedSettings.Clone() as EntryStopsTargetsSettings, PatternDefined = _estPatternDefinedSettings.Clone() as EntryStopsTargetsSettings };
                //_GeneralSettings.AddPattern(ePatterns.Flag, flag);

                _estPatternDefinedSettings.NewStopsTargetsSettings(StopABC * TickSize, Target1ABC, Target2ABC);
                PatternSettings ABC = new PatternSettings() { Name = "ABC", Show = ShowABC, Retracement1Min = Fib1, Retracement1Max = Fib3, BullPatternColors = ABCStrokeBull, BearPatternColors = ABCStrokeBear, 
                    UserDefined = _estUserDefinedSettings.Clone() as EntryStopsTargetsSettings, PatternDefined = _estPatternDefinedSettings.Clone() as EntryStopsTargetsSettings };
                _GeneralSettings.AddPattern(ePatterns.ABC, ABC);

                _estPatternDefinedSettings.NewStopsTargetsSettings(StopABCD * TickSize, Target1ABCD, Target2ABCD);
                PatternSettings ABCD = new PatternSettings()
                {
                    Name = "ABCD\r\nFlag",
                    Show = ShowABCD,
                    Retracement1Min = Retracement1MinFibABCD,
                    Retracement1Max = Retracement1MaxFibABCD,
                    Retracement2Min = Retracement2MinFibABCD,
                    Retracement2Max = Retracement2MaxFibABCD,
                    BullPatternColors = ABCDStrokeBull,
                    BearPatternColors = ABCDStrokeBear,
                    UserDefined = _estUserDefinedSettings.Clone() as EntryStopsTargetsSettings,
                    PatternDefined = _estPatternDefinedSettings.Clone() as EntryStopsTargetsSettings
                };
                _GeneralSettings.AddPattern(ePatterns.ABCD, ABCD);
            }
            #endregion

            #region State Terminated
            else if (State == State.Terminated)
            {
                RemoveFromToolBar();
            }
            #endregion

            #endregion
        }
        #endregion

		#region On Bar Update
        protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
            if (CurrentBar < 50 || _lDepths.Count == 0) return;
            for (int i = 0; i < _lDepths.Count; i++)
            {
                Depth p = _lDepths[i];
                int x = Calculate == Calculate.OnBarClose || (State != State.Realtime && !IsTickReplays[0].Value) ? 0 : 1;
                int result = p.Search(CurrentBar, Time[x], High[x], Low[x], Close[0], Close[1], Close[2], _GeneralSettings.GetDeviationForPatternBreaks(p.DepthType),
                    _GeneralSettings.PatternBreakPercent, EntryType == "Close Of Bar");
                switch (result)
                {
                    case 0: continue;
                    case 1:
                        bool IsTheSameAsPrevious4 = i != 0;
                        bool IsTheSameAsPrevious3 = IsTheSameAsPrevious4;
                        if (IsTheSameAsPrevious4 && _lDepths[i - 1].AllPoints.Count >= 4 && p.AllPoints.Count >= 5)
                        {
                            int prevC = _lDepths[i - 1].AllPoints.Count - 1;
                            int currC = p.AllPoints.Count - 1;
                            for (int j = 1; j < 5; j++)
                            {
                                if (prevC - j < 0 || currC - j < 0)
                                    break;
                                if (!_lDepths[i - 1].AllPoints[prevC - j].IsTheSame(p.AllPoints[currC - j]))
                                {
                                    if (j < 4)
                                        IsTheSameAsPrevious3 = false;
                                    IsTheSameAsPrevious4 = false;
                                }
                            }
                        }
                        if (IsTheSameAsPrevious4)
                            continue;

                        AscTriangle AscT = AscTriangle.FindPatternAsc(p.AllPoints, TickSize, CurrentBar, _GeneralSettings.GetSettingsFor(ePatterns.AscendingTriangle));
                        if (AscT != null)
                        {
                            if (p.AddPattern(AscT))
                                AscT.PlaySoundWhenPatternFound(_GeneralSettings);
                            continue;
                        }
                        DescTriangle DescT = DescTriangle.FindPatternDesc(p.AllPoints, TickSize, CurrentBar, _GeneralSettings.GetSettingsFor(ePatterns.DescendingTriangle));
                        if (DescT != null)
                        {
                            if (p.AddPattern(DescT))
                                DescT.PlaySoundWhenPatternFound(_GeneralSettings);
                            continue;
                        }
                        SymTriangle symTriangle = SymTriangle.FindPattern(p.AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.SymmetricTriangle));
                        if (symTriangle != null)
                        {
                            if (p.AddPattern(symTriangle))
                                symTriangle.PlaySoundWhenPatternFound(_GeneralSettings);
                            continue;
                        }
                        Wedge wedge = Wedge.FindPattern(p.AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.Wedge));
                        if (wedge != null)
                        {
                            if (p.AddPattern(wedge))
                                wedge.PlaySoundWhenPatternFound(_GeneralSettings);
                            continue;
                        }
                        ExpTriangle expTriangle = ExpTriangle.FindPattern(p.AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.ExpandingTriangle));
                        if (expTriangle != null)
                        {
                            if (p.AddPattern(expTriangle))
                                expTriangle.PlaySoundWhenPatternFound(_GeneralSettings);
                            continue;
                        }
                        Rectangle rect = Rectangle.FindPattern(p.AllPoints, TickSize, _GeneralSettings.GetSettingsFor(ePatterns.Rectangle));
                        if (rect != null)
                        {
                            if (p.AddPattern(rect))
                                rect.PlaySoundWhenPatternFound(_GeneralSettings);
                            continue;
                        }
                        ABCD abcd = ABCD.FindPattern(p.AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.ABCD));
                        if (abcd != null)
                        {
                            if (p.AddPattern(abcd))
                                abcd.PlaySoundWhenPatternFound(_GeneralSettings);
                            continue;
                        }
                        //Flag flag = Flag.FindPattern(p.AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.Flag));
                        //if (flag != null)
                        //{
                        //    if (p.AddPattern(flag))
                        //        flag.PlaySoundWhenPatternFound(_GeneralSettings);
                        //    continue;
                        //}

                        if (IsTheSameAsPrevious3)
                            continue;

                        ABC abc = ABC.FindPattern(p.AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.ABC));
                        if (abc != null)
                        {
                            //Time[0], High[0], Low[0], Close[0], Close[1]
                            abc.UpdatePatternAndLines(Time[0], Close[0], Close[1], High[0], Low[0], CurrentBar,
                                _GeneralSettings.GetDeviationForPatternBreaks(p.DepthType) * p.LastATR_Value, _GeneralSettings.PatternBreakPercent);
                            if (p.AddPattern(abc))
                                abc.PlaySoundWhenPatternFound(_GeneralSettings);
                            continue;
                        }
                        break;
                    case 2:
                        p.UpdatePattern(CurrentBar, _GeneralSettings);
                        break;
                }
            }
        }
        #endregion

        #region Objects

        #region State Functions

        #region Remove From ToolBar
        private void RemoveFromToolBar()
        {
            if (_grdIndyToolbar != null)
            {
                Action p = () =>
                {
                    Chart chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;

                    chartWindow.MainMenu.Remove(_grdIndyToolbar);
                    _grdIndyToolbar = null;

                    chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
                    chartWindow = null;

                    _bIsToolBarButtonAdded = false;
                };
                GeneralInvokeAction(p);
            }
        }
        #endregion

        #region Add To ToolBar
        private void AddToToolBar()
        {
            if (!_bIsToolBarButtonAdded && ChartControl != null)
            {
                Action p = () =>
                {
                    #region Initial SetUp
                    Chart chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                    if (chartWindow == null) return;

                    foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (ButtonText + uID)) _bIsToolBarButtonAdded = true;

                    _grdIndyToolbar = new Grid { Visibility = Visibility.Collapsed };

                    _mnuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
                    MenuItem MenuControl = new MenuItem { Name = "MenuControl", BorderThickness = new Thickness(2), BorderBrush = Brushes.Orange, Header = ButtonText, Foreground = Brushes.Orange, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
                    _dicMenuItems.Add(MenuControl.Name, MenuControl);
                    _mnuControlContainer.Items.Add(MenuControl);
                    #endregion

                    #region General
                    string headItem = "miGeneral";
                    AddMenuItem("General", headItem, Brushes.Black, null, MenuControl);
                    AddMenuItem("Show Large Swing " + (_GeneralSettings.ShowLarge ? "ON" : "OFF"), "btGeneral_ShowLarge" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Medium Swing " + (_GeneralSettings.ShowMedium ? "ON" : "OFF"), "btGeneral_ShowMedium" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Small Swing " + (_GeneralSettings.ShowSmall ? "ON" : "OFF"), "btGeneral_ShowSmall" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("- - -", "btGeneral_Lines0" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem], false);
                    AddMenuItem("Show Potential Patterns " + (_GeneralSettings.ShowFresh ? "ON" : "OFF"), "btGeneral_ShowPotential" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Confirmed Patterns " + (_GeneralSettings.ShowFilled ? "ON" : "OFF"), "btGeneral_ShowConfirmed" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Historical Patterns " + (_GeneralSettings.ShowCompleted ? "ON" : "OFF"), "btGeneral_ShowHistorical" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Invalidated Patterns " + (_GeneralSettings.ShowInvalidated ? "ON" : "OFF"), "btGeneral_ShowInvalidated" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("- - -", "btGeneral_Lines1", Brushes.Black, General_Click, _dicMenuItems[headItem], false);
                    AddMenuItem("Show Long Patterns " + (_GeneralSettings.ShowLong ? "ON" : "OFF"), "btGeneral_ShowLong" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Short Patterns " + (_GeneralSettings.ShowShort ? "ON" : "OFF"), "btGeneral_ShowShort" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Neutral Patterns " + (_GeneralSettings.ShowNeutral ? "ON" : "OFF"), "btGeneral_ShowNeutral" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    #endregion

                    #region Patterns
                    headItem = "miPatterns";
                    AddMenuItem("Patterns", headItem, Brushes.Black, null, MenuControl);
                    AddMenuItem("Show ABC " + (_GeneralSettings.GetSettingsFor(ePatterns.ABC).Show ? "ON" : "OFF"), "btPatterns_ShowABC" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show ABCD Flag " + (_GeneralSettings.GetSettingsFor(ePatterns.ABCD).Show ? "ON" : "OFF"), "btPatterns_ShowABCD" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Wedge " + (_GeneralSettings.GetSettingsFor(ePatterns.Wedge).Show ? "ON" : "OFF"), "btPatterns_ShowWedge" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Asc/Desc Triangle " + (_GeneralSettings.GetSettingsFor(ePatterns.AscendingTriangle).Show ? "ON" : "OFF"), "btPatterns_ShowAscDesc" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Symmetric Triangle " + (_GeneralSettings.GetSettingsFor(ePatterns.SymmetricTriangle).Show ? "ON" : "OFF"), "btPatterns_ShowSymmetric" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Expanding Triangle " + (_GeneralSettings.GetSettingsFor(ePatterns.ExpandingTriangle).Show ? "ON" : "OFF"), "btPatterns_ShowExpanding" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Rectangle " + (_GeneralSettings.GetSettingsFor(ePatterns.Rectangle).Show ? "ON" : "OFF"), "btPatterns_ShowRectangle" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    //AddMenuItem("Show Flag " + (_GeneralSettings.GetSettingsFor(ePatterns.Flag).Show ? "ON" : "OFF"), "btPatterns_ShowFlag", Brushes.Black, General_Click, _lstMenuItems[headItem]);
                    #endregion

                    #region Trading Plan
                    headItem = "miTradePlan";
                    AddMenuItem("Trade Plan", headItem, Brushes.Black, null, MenuControl);
                    AddMenuItem("Trade Plan:  " + TradePlan, "btTradePlan_General" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("- - -", "btTradePlan_PlaceHolder1" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem], false);
                    _dicMenuItems[headItem].Items.Add(createMSTMenu(StopTicks.ToString(), Target1Ticks.ToString(), Target2Ticks.ToString()));
                    //AddMenuItem("SL Ticks: " + StopTicks, "btTradePlan_SLticks", Brushes.Black, General_Click, _dicMenuItems[headItem], false);
                    //AddMenuItem("T1 Ticks: " + Target1Ticks, "btTradePlan_T1ticks", Brushes.Black, General_Click, _dicMenuItems[headItem], false);
                    //AddMenuItem("T2 Ticks: " + Target2Ticks, "btTradePlan_T2ticks", Brushes.Black, General_Click, _dicMenuItems[headItem], false);
                    AddMenuItem("- - -", "btTradePlan_PlaceHolder2" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem], false);
                    AddMenuItem("RE-CALCULATE TRADE PLAN", "btTradePlan_Recalculate_General" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem], true, false);
                    #endregion

                    #region Subscribe to Tab Control
                    _grdIndyToolbar.Children.Add(_mnuControlContainer);

                    chartWindow.MainMenu.Add(_grdIndyToolbar);
                    chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                    foreach (TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) _grdIndyToolbar.Visibility = Visibility.Visible;
                    AutomationProperties.SetAutomationId(_grdIndyToolbar, _sToolbarName + uID);
                    #endregion
                };
                GeneralInvokeAction(p);
            }
        }
        #endregion

        #endregion

        #region Control Functions

        #region Add Menu Item
        private void AddMenuItem(string Header, string Name, Brush TextBrush, RoutedEventHandler EventHandler, MenuItem Parent = null, bool Editable = true, bool StayOpenOnClick = true)
        {
            MenuItem item = new MenuItem { Header = Header, Name = Name, Foreground = TextBrush, StaysOpenOnClick = StayOpenOnClick, FontWeight = FontWeights.Normal };
            item.IsEnabled = Editable;
            if (EventHandler != null)
                item.Click += EventHandler;
            if (Parent != null)
                Parent.Items.Add(item);
            _dicMenuItems.Add(item.Name, item);
        }
        #endregion

        #region Create UpDown Menu
        //Function taken from NS VM Lean and needs to be updated to standards after christmas
        private Grid createMSTMenu(string nudValue1, string nudValue2, string nudValue3)
        {
            const int rHeight = 26;

            Button gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "+", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            Button gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "-", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            Label gLabel = new Label();//#RJBug001

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(55) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1 - Stop Loss
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "SL Ticks: " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            TextBox nudMST1 = new TextBox() { Name = "tbTradePlan_SLticks" + uID, MinWidth = 60, Width = 60, MaxWidth = 60, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST1.Text = nudValue1;
            nudMST1.KeyDown += menuTxtbox_KeyDown;
            nudMST1.TextChanged += NumericUpDownValueChanged;
            nudMST1.MouseWheel += delegate (object o, MouseWheelEventArgs e)
            {
                e.Handled = true;
                if (e.Delta > 0) StopTicks++;
                else StopTicks--;
                StopTicks = Math.Max(1, StopTicks);
                nudMST1.Text = StopTicks.ToString();
                InformUserAboutRecalculation();
                ForceRefresh();
            };
            nudMST1.SetValue(Grid.ColumnProperty, 1);
            nudMST1.SetValue(Grid.RowProperty, 0);
            nudMST1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = "btTradePlan_SLticks_Up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = "btTradePlan_SLticks_Dn" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += cmdupdw_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += cmdupdw_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);

            _dicTextBoxes.Add(nudMST1.Name, nudMST1);
            _dicButtons.Add(cmdup1.Name, cmdup1);
            _dicButtons.Add(cmddw1.Name, cmddw1);

            //line 2 - Target 3
            Label lbl2 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "T1 Ticks: " };
            lbl2.SetValue(Grid.ColumnProperty, 0);
            lbl2.SetValue(Grid.RowProperty, 2);
            lbl2.SetValue(Grid.RowSpanProperty, 2);

            TextBox nudMST2 = new TextBox() { Name = "tbTradePlan_T1ticks" + uID, MinWidth = 50, Width = 50, MaxWidth = 50, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST2.Text = nudValue2;
            nudMST2.KeyDown += menuTxtbox_KeyDown;
            nudMST2.TextChanged += NumericUpDownValueChanged;
            nudMST2.MouseWheel += delegate (object o, MouseWheelEventArgs e)
            {
                e.Handled = true;
                if (e.Delta > 0) Target1Ticks++;
                else Target1Ticks--;
                Target1Ticks = Math.Max(1, Target1Ticks);
                nudMST2.Text = Target1Ticks.ToString();
                InformUserAboutRecalculation();
                ForceRefresh();
            };
            nudMST2.SetValue(Grid.ColumnProperty, 1);
            nudMST2.SetValue(Grid.RowProperty, 2);
            nudMST2.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup2 = new Button() { Name = "btTradePlan_T1ticks_Up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw2 = new Button() { Name = "btTradePlan_T1ticks_Dn" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup2.Click += cmdupdw_Click;
            cmdup2.SetValue(Grid.ColumnProperty, 2);
            cmdup2.SetValue(Grid.RowProperty, 2);
            cmddw2.Click += cmdupdw_Click;
            cmddw2.SetValue(Grid.ColumnProperty, 2);
            cmddw2.SetValue(Grid.RowProperty, 3);

            _dicTextBoxes.Add(nudMST2.Name, nudMST2);
            _dicButtons.Add(cmdup2.Name, cmdup2);
            _dicButtons.Add(cmddw2.Name, cmddw2);

            //line 3 - Target 2
            Label lbl3 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "T2 Ticks: " };
            lbl3.SetValue(Grid.ColumnProperty, 0);
            lbl3.SetValue(Grid.RowProperty, 4);
            lbl3.SetValue(Grid.RowSpanProperty, 2);

            TextBox nudMST3 = new TextBox() { Name = "tbTradePlan_T2ticks" + uID, MinWidth = 50, Width = 50, MaxWidth = 50, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST3.Text = nudValue3;
            nudMST3.KeyDown += menuTxtbox_KeyDown;
            nudMST3.TextChanged += NumericUpDownValueChanged;
            nudMST3.MouseWheel += delegate (object o, MouseWheelEventArgs e)
            {
                e.Handled = true;
                if (e.Delta > 0) Target2Ticks++;
                else Target2Ticks--;
                Target2Ticks = Math.Max(1, Target2Ticks);
                nudMST3.Text = Target2Ticks.ToString();
                InformUserAboutRecalculation();
                ForceRefresh();
            };
            nudMST3.SetValue(Grid.ColumnProperty, 1);
            nudMST3.SetValue(Grid.RowProperty, 4);
            nudMST3.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup3 = new Button() { Name = "btTradePlan_T2ticks_Up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw3 = new Button() { Name = "btTradePlan_T2ticks_Dn" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup3.Click += cmdupdw_Click;
            cmdup3.SetValue(Grid.ColumnProperty, 2);
            cmdup3.SetValue(Grid.RowProperty, 4);
            cmddw3.Click += cmdupdw_Click;
            cmddw3.SetValue(Grid.ColumnProperty, 2);
            cmddw3.SetValue(Grid.RowProperty, 5);

            _dicTextBoxes.Add(nudMST3.Name, nudMST3);
            _dicButtons.Add(cmdup3.Name, cmdup3);
            _dicButtons.Add(cmddw3.Name, cmddw3);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMST1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);
            grid.Children.Add(lbl2);
            grid.Children.Add(nudMST2);
            grid.Children.Add(cmdup2);
            grid.Children.Add(cmddw2);
            grid.Children.Add(lbl3);
            grid.Children.Add(nudMST3);
            grid.Children.Add(cmdup3);
            grid.Children.Add(cmddw3);

            UpdateTextBoxEnable();

            return grid;
        }
        #endregion

        #region Update Text Box Enabled
        private void UpdateTextBoxEnable()
        {
            GeneralInvokeAction(() =>
            {
                bool IsEnabled = TradePlan == "User Defined";
                _dicTextBoxes[string.Format("tbTradePlan_SLticks{0}", uID)].IsEnabled = IsEnabled;
                _dicTextBoxes[string.Format("tbTradePlan_T1ticks{0}", uID)].IsEnabled = IsEnabled;
                _dicTextBoxes[string.Format("tbTradePlan_T2ticks{0}", uID)].IsEnabled = IsEnabled;
            });
        }
        #endregion

        #endregion

        #region Event Handlers

        #region General_Click
        private void General_Click(object sender, EventArgs e)
        {
            bool invalidateVisual = false;
            MenuItem item = sender as MenuItem;
            switch (item.Name.Substring(0, item.Name.Length - uID.Length))
            {
                case "btGeneral_ShowLarge": ShowLarge = !ShowLarge; _GeneralSettings.ShowLarge = ShowLarge; item.Header = "Show Large " + (_GeneralSettings.ShowLarge ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ShowSmall": ShowSmall = !ShowSmall; _GeneralSettings.ShowSmall = ShowSmall; item.Header = "Show Small " + (_GeneralSettings.ShowSmall ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ShowMedium": ShowMedium = !ShowMedium; _GeneralSettings.ShowMedium = ShowMedium; item.Header = "Show Medium " + (_GeneralSettings.ShowMedium ? "ON" : "OFF"); invalidateVisual = true; break;

                case "btGeneral_ShowPotential": ShowFresh = !ShowFresh; _GeneralSettings.ShowFresh = ShowFresh; item.Header = "Show Potential Patterns " + (_GeneralSettings.ShowFresh ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ShowConfirmed": ShowFilled = !ShowFilled; _GeneralSettings.ShowFilled = ShowFilled; item.Header = "Show Confirmed Patterns " + (_GeneralSettings.ShowFilled ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ShowHistorical": ShowCompleted = !ShowCompleted; _GeneralSettings.ShowCompleted = ShowCompleted; item.Header = "Show Historical Patterns " + (_GeneralSettings.ShowCompleted ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ShowInvalidated": ShowInvalidated = !ShowInvalidated; _GeneralSettings.ShowInvalidated = ShowInvalidated; item.Header = "Show Invalidated Patterns " + (_GeneralSettings.ShowInvalidated ? "ON" : "OFF"); invalidateVisual = true; break;

                case "btGeneral_ShowLong": ShowLong = !ShowLong; _GeneralSettings.ShowLong = ShowLong; item.Header = "Show Long Patterns " + (_GeneralSettings.ShowLong ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ShowShort": ShowShort = !ShowShort; _GeneralSettings.ShowShort = ShowShort; item.Header = "Show Short Patterns " + (_GeneralSettings.ShowShort ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ShowNeutral": ShowNeutral = !ShowNeutral; _GeneralSettings.ShowNeutral = ShowNeutral; item.Header = "Show Neutral Patterns " + (_GeneralSettings.ShowNeutral ? "ON" : "OFF"); invalidateVisual = true; break;

                case "btPatterns_ShowABC": ShowABC = !ShowABC; _GeneralSettings.SetPatternSettingsVisualOnOff(ePatterns.ABC, ShowABC); item.Header = "Show ABC " + (ShowABC ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btPatterns_ShowABCD": ShowABCD = !ShowABCD; _GeneralSettings.SetPatternSettingsVisualOnOff(ePatterns.ABCD, ShowABCD); item.Header = "Show ABCD Flag " + (ShowABCD ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btPatterns_ShowWedge": ShowWedge = !ShowWedge; _GeneralSettings.SetPatternSettingsVisualOnOff(ePatterns.Wedge, ShowWedge); item.Header = "Show Wedge " + (ShowWedge ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btPatterns_ShowAscDesc":
                    ShowAscDesc = !ShowAscDesc;
                    _GeneralSettings.SetPatternSettingsVisualOnOff(ePatterns.AscendingTriangle, ShowAscDesc);
                    _GeneralSettings.SetPatternSettingsVisualOnOff(ePatterns.DescendingTriangle, ShowAscDesc);
                    item.Header = "Show Asc/Desc Triangle " + (ShowAscDesc ? "ON" : "OFF");
                    invalidateVisual = true;
                    break;
                case "btPatterns_ShowSymmetric": ShowSym = !ShowSym; _GeneralSettings.SetPatternSettingsVisualOnOff(ePatterns.SymmetricTriangle, ShowSym); item.Header = "Show Symmetric Triangle " + (ShowSym ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btPatterns_ShowExpanding": ShowExp = !ShowExp; _GeneralSettings.SetPatternSettingsVisualOnOff(ePatterns.ExpandingTriangle, ShowExp); item.Header = "Show Expanding Triangle " + (ShowExp ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btPatterns_ShowRectangle": ShowRect = !ShowRect; _GeneralSettings.SetPatternSettingsVisualOnOff(ePatterns.Rectangle, ShowRect); item.Header = "Show Rectangle " + (ShowRect ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btPatterns_ShowFlag": ShowFlag = !ShowFlag; _GeneralSettings.SetPatternSettingsVisualOnOff(ePatterns.Flag, ShowFlag); item.Header = "Show Flag " + (ShowFlag ? "ON" : "OFF"); invalidateVisual = true; break;

                //logic for trading plan
                case "btTradePlan_General":
                    switch (TradePlan)
                    {
                        case "None": TradePlan = "User Defined"; break;
                        case "User Defined": TradePlan = "Pattern Defined"; break;
                        case "Pattern Defined": TradePlan = "None"; break;
                    }
                    UpdateTextBoxEnable();
                    item.Header = "Trade Plan " + TradePlan;
                    invalidateVisual = true;
                    _GeneralSettings.TradePlan = TradePlan;
                    break;
                case "btTradePlan_Recalculate_General":
                    System.Windows.Forms.SendKeys.SendWait("{F5}");
                    break;
            }
            if (invalidateVisual)
                CCInvokeAction(() =>
                {
                    ChartControl.InvalidateVisual();
                });
        }
        #endregion

        #region -- DoubleEditKeyPress -- 
        //Function taken from NS VM Lean and needs to be updated to standards after christmas
        private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtSender = sender as TextBox;

            int keyVal = (int)e.Key;
            int value = -1;
            if (keyVal >= (int)Key.D0 && keyVal <= (int)Key.D9) value = keyVal - (int)Key.D0;
            else if (keyVal >= (int)Key.NumPad0 && keyVal <= (int)Key.NumPad9) value = keyVal - (int)Key.NumPad0;

            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);

            if (isNumeric || e.Key == Key.Back || (e.Key == Key.Decimal && _dicTextBoxes.ContainsKey(txtSender.Name)))
            {
                string newText = value != -1 ? value.ToString() : e.Key == Key.Decimal ? System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator : "";
                int tbPosition = txtSender.SelectionStart;
                txtSender.Text = txtSender.SelectedText == "" ? txtSender.Text.Insert(tbPosition, newText) : txtSender.Text.Replace(txtSender.SelectedText, newText);
                txtSender.Select(tbPosition + 1, 0);
            }
        }
        #endregion

        #region -- DoubleEditTextChanged --
        private string currentTextEdit;
        //Function taken from NS VM Lean and needs to be updated to standards after christmas
        private void NumericUpDownValueChanged(object sender, EventArgs e)
        {
            TextBox txtSender = sender as TextBox;
            if (txtSender.Text.Length > 0)
            {
                float result;
                bool isNumeric = float.TryParse(txtSender.Text, out result);

                if (isNumeric) currentTextEdit = txtSender.Text;
                else
                {
                    txtSender.Text = currentTextEdit;
                    txtSender.Select(txtSender.Text.Length, 0);
                }
                if (_dicTextBoxes.ContainsKey(txtSender.Name))
                {
                    //switch (txtSender.Name)
                    {
                        if(txtSender.Name.StartsWith("tbTradePlan_SLticks")){
                            StopTicks = Convert.ToInt32(txtSender.Text);
						}else if(txtSender.Name.StartsWith("tbTradePlan_T1ticks")){
                            Target1Ticks = Convert.ToInt32(txtSender.Text);
                        }else if(txtSender.Name.StartsWith("tbTradePlan_T2ticks")){
                            Target2Ticks = Convert.ToInt32(txtSender.Text);
                        }
                    }
                    InformUserAboutRecalculation();
                }
            }
        }
        #endregion

        #region private void cmdupdw_Click(object sender, RoutedEventArgs e)
        //Function taken from NS VM Lean and needs to be updated to standards after christmas
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
            Button cmd = sender as Button;
            if (cmd != null && _dicButtons.ContainsKey(cmd.Name))
            {
                if (!_dicTextBoxes[string.Format("tbTradePlan_T1ticks{0}", uID)].IsEnabled)
                    return;
                string Name = cmd.Name;
                switch (Name.Substring(0, Name.Length - uID.Length))
                {
                    case "btTradePlan_SLticks_Up": _dicTextBoxes[Name].Text = (Math.Min(999999999, Convert.ToInt32(_dicTextBoxes[Name].Text) + 1)).ToString(); break;
                    case "btTradePlan_SLticks_Dn": _dicTextBoxes[Name].Text = (Math.Max(1, Convert.ToInt32(_dicTextBoxes[Name].Text) - 1)).ToString(); break;
                    case "btTradePlan_T1ticks_Up": _dicTextBoxes[Name].Text = (Math.Min(999999999, Convert.ToInt32(_dicTextBoxes[Name].Text) + 1)).ToString(); break;
                    case "btTradePlan_T1ticks_Dn": _dicTextBoxes[Name].Text = (Math.Max(1, Convert.ToInt32(_dicTextBoxes[Name].Text) - 1)).ToString(); break;
                    case "btTradePlan_T2ticks_Up": _dicTextBoxes[Name].Text = (Math.Min(999999999, Convert.ToInt32(_dicTextBoxes[Name].Text) + 1)).ToString(); break;
                    case "btTradePlan_T2ticks_Dn": _dicTextBoxes[Name].Text = (Math.Max(1, Convert.ToInt32(_dicTextBoxes[Name].Text) - 1)).ToString(); break;
                }
                InformUserAboutRecalculation();
            }
        }
        #endregion

        #region Tab Selection Changed Handler
        private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && _grdIndyToolbar != null)
                _grdIndyToolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #endregion

        #region Static Classes

        #region Calculations
        private static class Calc
        {
            #region Line Slope Calculation
            public static double Slope(double x1, double x2, double y1, double y2)
            {
                return (y2 - y1) / (x2 - x1);
            }
            public static float Slope(float x1, float x2, float y1, float y2)
            {
                return (y2 - y1) / (x2 - x1);
            }
            #endregion

            #region 2 Lines Angle Calculation
            public static double AngleDeg(double slope1, double slope2)
            {
                return Math.Atan((slope2 - slope1) / (1 + slope2 * slope1)) * (180 / Math.PI);
            }
            #endregion

            #region 1 sloping line and one vertical - Angle Calculation
            public static double AngleDeg(double slope)
            {
                return Math.Atan(slope) * (180 / Math.PI);
            }
            #endregion

            #region 3rd point of a line -  Calculation
            public static bool NextPoint(Point p1, Point p2, int CurrentBar, double close0, double close1, bool dir) 
            {
                double slope = Calc.Slope(p1.Bar, p2.Bar, p1.Price, p2.Price);
                double pricePoint3 = slope * (CurrentBar - p2.Bar) + p2.Price;
                if (dir ? close1 <= pricePoint3 && close0 > pricePoint3 : close1 >= pricePoint3 && close0 < pricePoint3)
                    return true;
                return false;
            }
            public static double NextPoint(Point p1, Point p2, int CurrentBar)
            {
                double slope = Calc.Slope(p1.Bar, p2.Bar, p1.Price, p2.Price);
                return slope * (CurrentBar - p2.Bar) + p2.Price;
            }
            public static float NextPoint(float p1x, float p1y, float p2x, float p2y, float p3x)
            {
                float slope = Slope(p1x, p2x, p1y, p2y);
                return slope * (p3x - p2x) + p2y;
            }
            public static float NextPoint(float p1x, float p1y, float slope, float p3x)
            {
                return slope * (p3x - p1x) + p1y;
            }
            public static double NextPoint(int p1x, double p1y, double slope, int p3x)
            {
                if (p1x == p3x)
                    return p1y;
                return slope * (p3x - p1x) + p1y;
            }
            #endregion

            #region Intersection of 2 points - X axis 
            public static float IntersectionXPoint(float xA, float yA, float xC, float yC, float slope1, float slope2)
            {
                return (slope1 * xC - slope2 * xA + yA - yC) / (slope1 - slope2);
            }
            #endregion

            public static Tuple<int, double> ThirdPoint(Tuple<int, double> A, Tuple<int, double> B, double slopeA, double slopeB)
            {
                int x = (int)(((slopeA * A.Item1) - A.Item2 - (slopeB * B.Item1) + B.Item2) / (slopeA - slopeB));
                double y = slopeA * (x - A.Item1) + A.Item2;
                return new Tuple<int, double>(x, y);
            }

            #region Intersection of 2 point - Y axis
            public static float IntersectionYPoint(float xA, float yA, float xB, float slope2)
            {
                return slope2 * (xB - xA) + yA;
            }
            #endregion

            #region Angle Comparison with Min & Max Value - Math Abs
            public static bool AngleAbsCompare(double minAngle, double maxAngle, double angle)
            {
                return Math.Abs(angle) < minAngle || Math.Abs(angle) > maxAngle;
            }
            #endregion

            public static bool PatternBroken(Tuple<int, double> A, Tuple<int, double> B, Tuple<int, double> C, int bar, bool checkMin, double minCheckValue, bool checkMax, double maxCheckValue)
            {
                return bar > B.Item1 || (checkMin && minCheckValue < Math.Min(A.Item2, C.Item2)) || (checkMax && maxCheckValue > Math.Max(A.Item2, C.Item2));
            }
        }
        #endregion

        #region Draw Sharp DX
        private static class DrawSharpDX
        {
            #region Line
            public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, float x1, float y1, float x2, float y2, Stroke stroke, Tuple<float, float> chartWidthNHeight)
            {
                if (RenderTarget == null || stroke == null || stroke.Brush == Brushes.Transparent || (x1 == x2 && y1 == y2) || !SharpDXUtils.IsLineInChart(x1, y1, x2, y2, chartWidthNHeight))
                    return;

                DrawLine(RenderTarget, new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), stroke);
            }

            public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime time1, double price1, DateTime time2, double price2, Stroke stroke)
            {
                if (RenderTarget == null || chartControl == null || chartScale == null || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsLineInChart(time1, price1, time2, price2, chartControl, chartScale))
                    return;

                float x1 = chartControl.GetXByTime(time1); float y1 = chartScale.GetYByValue(price1);
                float x2 = chartControl.GetXByTime(time2); float y2 = chartScale.GetYByValue(price2);

                DrawLine(RenderTarget, new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), stroke);
            }

            private static void DrawLine(SharpDX.Direct2D1.RenderTarget RenderTarget, SharpDX.Vector2 vector1, SharpDX.Vector2 vector2, Stroke stroke)
            {
                SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                SharpDXUtils.WrapInAntiAlias(RenderTarget, () => { RenderTarget.DrawLine(vector1, vector2, brs, stroke.Width, stroke.StrokeStyle); });
                brs.Dispose();
            }
            #endregion

            #region Geometry
            public static void GeometryWithFill(SharpDX.Direct2D1.RenderTarget RenderTarget, List<Tuple<float, float>> Points, Stroke stroke, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.AreAnyPointsInChart(Points, chartWidthNHeight))
                    return;

                List<SharpDX.Vector2> points = new List<SharpDX.Vector2>();
                foreach (Tuple<float, float> point in Points)
                    points.Add(new SharpDX.Vector2(point.Item1, point.Item2));

                DrawGeometry(RenderTarget, points, stroke, opacity, outline, background);
            }

            public static void GeometryWithFill(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, List<Tuple<DateTime, double>> Points, Stroke stroke, int opacity, bool outline, bool background)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.AreAnyPointsInChart(Points, chartControl, chartScale))
                    return;

                List<SharpDX.Vector2> points = new List<SharpDX.Vector2>();
                foreach (Tuple<DateTime, double> point in Points)
                    points.Add(new SharpDX.Vector2(chartControl.GetXByTime(point.Item1), chartScale.GetYByValue(point.Item2)));

                DrawGeometry(RenderTarget, points, stroke, opacity, outline, background);
            }

            private static void DrawGeometry(SharpDX.Direct2D1.RenderTarget RenderTarget, List<SharpDX.Vector2> Points, Stroke stroke, int opacity, bool outline, bool background)
            {
                SharpDX.Direct2D1.PathGeometry pathGeometry = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
                SharpDX.Direct2D1.GeometrySink geometrySink = pathGeometry.Open();

                for (int i = 0; i < Points.Count; i++)
                {
                    if (i == 0)
                        geometrySink.BeginFigure(Points[i], SharpDX.Direct2D1.FigureBegin.Filled);
                    else
                        geometrySink.AddLine(Points[i]);
                }
                geometrySink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
                geometrySink.Close();
                SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                if (outline)
                    RenderTarget.DrawGeometry(pathGeometry, brs, stroke.Width, stroke.StrokeStyle);
                if (background)
                {
                    brs.Opacity = opacity / 100f;
                    SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                    {
                        RenderTarget.FillGeometry(pathGeometry, brs);
                    });
                }
                pathGeometry.Dispose(); brs.Dispose(); geometrySink.Dispose();
            }
            #endregion

            #region Box Text
            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, DateTime time, double price, Stroke stroke, int opacity,
                Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Size size = SharpDXUtils.MeasureString(text, TextFont);
                Tuple<float, float> chartWidthNHeight = SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale);
                float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);

                Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, horizontalAlign, verticalAlign, backgroundBrush);
                Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, float x, float y, Stroke stroke, int opacity,
                Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Size size = SharpDXUtils.MeasureString(text, TextFont);
                Tuple<float, float> chartWidthNHeight = SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale);
                Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, horizontalAlign, verticalAlign, backgroundBrush);
                Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Stroke stroke, int opacity, Brush textBrush, SimpleFont TextFont,
                bool outline, bool background, Tuple<float, float> chartWidthNHeight, Brush backgroundBrush = null,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Box(RenderTarget, x, y, width, height, stroke, opacity, outline, background, chartWidthNHeight, horizontalAlign, verticalAlign, backgroundBrush);
                Text(RenderTarget, text, x, y, width, height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }
            #endregion

            #region Box
            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, DateTime topLeftTime, double topLeftPrice, DateTime bottomRightTime, double bottomRightPrice,
                int opacity, bool outline, bool background,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
                    return;

                float x1 = chartControl.GetXByTime(topLeftTime); float y1 = chartScale.GetYByValue(topLeftPrice);
                float x2 = chartControl.GetXByTime(bottomRightTime); float y2 = chartScale.GetYByValue(bottomRightPrice);
                float width = x2 - x1; float height = y2 - y1;

                if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background, horizontalAlign, verticalAlign);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, Tuple<DateTime, double> topLeftPoint, Tuple<DateTime, double> bootomRightPoint,
                int opacity, bool outline, bool background,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
                    return;

                float x1 = chartControl.GetXByTime(topLeftPoint.Item1); float y1 = chartScale.GetYByValue(topLeftPoint.Item2);
                float x2 = chartControl.GetXByTime(bootomRightPoint.Item1); float y2 = chartScale.GetYByValue(bootomRightPoint.Item2);
                float width = x2 - x1; float height = y2 - y1;

                if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background, horizontalAlign, verticalAlign);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, Tuple<float, float> topLeftPoint, Tuple<float, float> bootomRightPoint, int opacity,
                bool outline, bool background,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent ||
                    !SharpDXUtils.IsRectangleInChart(topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawBox(RenderTarget, topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background, horizontalAlign, verticalAlign);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, Stroke stroke, Tuple<float, float> topLeftPoint, Tuple<float, float> bootomRightPoint, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent ||
                    !SharpDXUtils.IsRectangleInChart(topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, chartWidthNHeight))
                    return;

                DrawBox(RenderTarget, topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background, horizontalAlign, verticalAlign);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsRectangleInChart(x, y, width, height, chartWidthNHeight))
                    return;

                DrawBox(RenderTarget, x, y, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush, opacity, outline, background, horizontalAlign, verticalAlign);
            }

            private static void DrawBox(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, Brush backgroundBrush, int opacity, bool outline, bool background,
                SharpDXUtils.HorizontalAlignment horizontalAlign, SharpDXUtils.VerticalAlignment verticalAlign)
            {
                if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Center)
                    x -= width / 2;
                if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Right)
                    x -= width;
                if (verticalAlign == SharpDXUtils.VerticalAlignment.Center)
                    y -= height / 2;
                if (verticalAlign == SharpDXUtils.VerticalAlignment.Bottom)
                    y -= height;
                SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
                if (outline)
                {
                    SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                    SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                    {
                        RenderTarget.DrawRectangle(rect, brs, stroke.Width, stroke.StrokeStyle);
                    });
                    brs.Dispose();
                }
                if (background)
                {
                    SharpDX.Direct2D1.Brush brs = backgroundBrush.ToDxBrush(RenderTarget);
                    brs.Opacity = (float)(opacity * 0.01f);
                    SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                    {
                        RenderTarget.FillRectangle(rect, brs);
                    });
                    brs.Dispose();
                }
            }
            #endregion

            #region Text
            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, DateTime time, double price, Brush textBrush, SimpleFont TextFont,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                if (RenderTarget == null || chartControl == null || chartScale == null || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
                    return;

                float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);
                Size size = SharpDXUtils.MeasureString(text, TextFont);

                if (size.Width == 0 || size.Height == 0 || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawText(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, Brush textBrush, SimpleFont TextFont, Tuple<float, float> chartWidthNHeight,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                if (RenderTarget == null || string.IsNullOrEmpty(text) || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
                    return;
                Size size = SharpDXUtils.MeasureString(text, TextFont);
                if (size.Width == 0 || size.Height == 0 || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, chartWidthNHeight))
                    return;
                DrawText(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Brush textBrush, SimpleFont TextFont, Tuple<float, float> chartWidthNHeight,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                if (RenderTarget == null || string.IsNullOrEmpty(text) || width == 0 || height == 0 || textBrush == null || textBrush == Brushes.Transparent || TextFont == null ||
                    !SharpDXUtils.IsRectangleInChart(x, y, width, height, chartWidthNHeight))
                    return;
                DrawText(RenderTarget, text, x, y, width, height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            private static void DrawText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Brush textBrush, SimpleFont TextFont, SharpDXUtils.HorizontalAlignment horizontalAlign, 
                SharpDXUtils.VerticalAlignment verticalAlign, SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment, SharpDX.DirectWrite.TextAlignment textAlignemnt)
            {
                if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Center)
                    x -= width / 2;
                if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Right)
                    x -= width;
                if (verticalAlign == SharpDXUtils.VerticalAlignment.Center)
                    y -= height / 2;
                if (verticalAlign == SharpDXUtils.VerticalAlignment.Bottom)
                    y -= height;
                SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
                SimpleFont fs = new SimpleFont(TextFont.Family.ToString(), TextFont.Size) { Bold = TextFont.Bold, Italic = TextFont.Italic };
                SharpDX.DirectWrite.TextFormat tff = fs.ToDirectWriteTextFormat();
                tff.ParagraphAlignment = paragraphAlignment;
                tff.TextAlignment = textAlignemnt;
                SharpDX.Direct2D1.Brush brs = textBrush.ToDxBrush(RenderTarget);
                SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                {
                    RenderTarget.DrawText(text, tff, rect, brs, SharpDX.Direct2D1.DrawTextOptions.Clip, SharpDX.Direct2D1.MeasuringMode.Natural);
                });
                tff.Dispose();
                brs.Dispose();
            }
            #endregion
        }
        #endregion

        #region Sharp DX Utils
        public static class SharpDXUtils
        {
            #region Get Chart Width and Height
            public static Tuple<float, float> GetChartWidthNHeight(ChartControl chartControl, ChartScale chartScale)
            {
                return new Tuple<float, float>(chartControl.GetXByTime(chartControl.LastTimePainted), chartScale.GetYByValue(chartScale.MinValue));
            }
            #endregion

            #region Measure String
            public static Size MeasureString(string msg, SimpleFont TextFont)
            {
                if (TextFont == null || string.IsNullOrEmpty(msg))
                    return new Size(0, 0);

                SimpleFont fs = new SimpleFont(TextFont.Family.ToString(), TextFont.Size) { Bold = TextFont.Bold, Italic = TextFont.Italic };
                SharpDX.DirectWrite.TextFormat tff = fs.ToDirectWriteTextFormat();
                SharpDX.DirectWrite.TextLayout layout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, tff, 999999, tff.FontSize);
                tff.Dispose();
                return new Size(layout.Metrics.Width, layout.Metrics.Height);
            }
            #endregion

            #region Are Any Points iIn Chart
            public static bool AreAnyPointsInChart(List<Tuple<float, float>> points, Tuple<float, float> chartWidthNHeight)
            {
                foreach (Tuple<float, float> point in points)
                    if (IsPointInChart(point.Item1, point.Item2, chartWidthNHeight))
                        return true;
                return false;
            }

            public static bool AreAnyPointsInChart(List<Tuple<DateTime, double>> points, ChartControl chartControl, ChartScale chartScale)
            {
                foreach (Tuple<DateTime, double> point in points)
                    if (IsPointInChart(point.Item1, point.Item2, chartControl, chartScale))
                        return true;
                return false;
            }
            #endregion

            #region Is Line In Chart
            public static bool IsLineInChart(float x1, float y1, float x2, float y2, Tuple<float, float> chartWidthNHeight)
            {
                return IsPointInChart(x1, y1, chartWidthNHeight) || IsPointInChart(x2, y2, chartWidthNHeight);
            }

            public static bool IsLineInChart(DateTime x1, double y1, DateTime x2, double y2, ChartControl chartControl, ChartScale chartScale)
            {
                return IsPointInChart(x1, y1, chartControl, chartScale) || IsPointInChart(x2, y2, chartControl, chartScale);
            }
            #endregion

            #region Is Point In Chart
            public static bool IsPointInChart(float x, float y, Tuple<float, float> chartWidthNHeight)
            {
                return x >= -1 && x <= chartWidthNHeight.Item1 + 1 && y >= -1 && y <= chartWidthNHeight.Item2 + 1;
            }

            public static bool IsPointInChart(DateTime x, double y, ChartControl chartControl, ChartScale chartScale)
            {
                return x.CompareTo(chartControl.FirstTimePainted) >= 0 && x.CompareTo(chartControl.LastTimePainted) <= 0 && y >= chartScale.MinValue && y <= chartScale.MaxValue;
            }
            #endregion

            #region Is Rectangle In Chart
            public static bool IsRectangleInChart(SharpDX.RectangleF rectangle, Tuple<float, float> chartWidthNHeight)
            {
                return IsPointInChart(rectangle.X, rectangle.Y, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y, chartWidthNHeight) ||
                    IsPointInChart(rectangle.X, rectangle.Y + rectangle.Height, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height, chartWidthNHeight);
            }

            public static bool IsRectangleInChart(float x, float y, float width, float height, Tuple<float, float> chartWidthNHeight)
            {
                SharpDX.RectangleF rectangle = new SharpDX.RectangleF(x, y, width, height);
                return IsPointInChart(rectangle.X, rectangle.Y, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y, chartWidthNHeight) ||
                    IsPointInChart(rectangle.X, rectangle.Y + rectangle.Height, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height, chartWidthNHeight);
            }

            public static bool IsRectangleInChart(List<Tuple<DateTime, double>> points, ChartControl chartControl, ChartScale chartScale)
            {
                return AreAnyPointsInChart(points, chartControl, chartScale);
            }

            public static bool IsRectangleInChart(List<Tuple<float, float>> points, Tuple<float, float> chartWidthNHeight)
            {
                return AreAnyPointsInChart(points, chartWidthNHeight);
            }
            #endregion

            #region WrapInAntiAlias
            public static void WrapInAntiAlias(SharpDX.Direct2D1.RenderTarget RenderTarget, Action action)
            {
                SharpDX.Direct2D1.AntialiasMode prev = RenderTarget.AntialiasMode;
                RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
                action();
                RenderTarget.AntialiasMode = prev;
            }
            #endregion

            #region Enums

            #region Horizontal Text Alignment
            public enum HorizontalAlignment
            {
                Center,
                Left,
                Right
            }
            #endregion

            #region Vertical Text Alignment
            public enum VerticalAlignment
            {
                Center,
                Top,
                Bottom
            }
            #endregion

            #endregion
        }
        #endregion

        #endregion

        #region Classes

        #region Lists - Depths, Points

        #region Point
        public class Point : ICloneable
        {
            #region Properties
            public double Price { get; set; }
            public int Bar { get; set; }
            public DateTime Time { get; set; } //TimeSpan
            public bool IsHigh { get; set; }
            #endregion

            #region Compare Points
            public bool IsTheSame(Point point)
            {
                return point.Price == Price && point.Bar == Bar && point.Time == Time && point.IsHigh == IsHigh;
            }
            public bool IsTheSameWithOne(List<Point> points)
            {
                foreach (Point p in points)
                    if (IsTheSame(p))
                        return true;
                return false;
            }
            #endregion

            #region Cloning
            //Cloning
            public object Clone()
            {
                return new Point() { Price = Price, Bar = Bar, Time = Time, IsHigh = IsHigh };
            }
            #endregion
        }
        #endregion

        #region Depth
        public class Depth
        {
            #region Floating Variables
            //int
            private int _iDepth;
            private int _iBarNumber = 0;
            //bool
            private bool _bUpTrend = true;
            //double
            private double _dSensitivity;
            private double currentHigh = 0;
            private double currentLow = 0;
            private double _dTickSize;
            //Other
            private List<Point> _lPointsForOneDepth = new List<Point>();
            private eDepthType _eDepthType;
            //Indicators
            private NinjaTrader.NinjaScript.Indicators.MIN _indiLowest;
            private NinjaTrader.NinjaScript.Indicators.MAX _indiHighest;
            private NinjaTrader.NinjaScript.Indicators.ATR _indiATR;
            #endregion

            #region Properties
            public bool ShowDepth { get; set; }
            public double LastATR_Value
            {
                get { return _indiATR[0]; }
            }
            public List<PatternBase> Patterns { get; set; }
            public List<Point> AllPoints
            {
                get { return _lPointsForOneDepth; }
            }
            public eDepthType DepthType
            {
                get { return _eDepthType; }
            }
            #endregion

            #region Constructor
            public Depth(int Depth, double Sensivity, eDepthType depthT, MIN min, MAX max, double tickSize, ATR atr) //constructor 
            {
                _iDepth = Depth; _eDepthType = depthT;
                _indiLowest = min;
                _indiHighest = max;
                _indiATR = atr;
                _dTickSize = tickSize;
                _dSensitivity = Sensivity;
                Patterns = new List<PatternBase>();
            }
            #endregion

            #region Public Functions
            public bool AddPattern(PatternBase pattern)
            {
                if (Patterns.Count == 0)
                {
                    Patterns.Add(pattern);
                    return true;
                }
                PatternBase lastPattern = Patterns[Patterns.Count - 1];
                if (lastPattern.GetType() == pattern.GetType() && (lastPattern.PatternStatePattern != ePatternState.Completed && lastPattern.PatternStatePattern != ePatternState.Invalidated))
                    return false;
                bool newPattern = false;
                foreach(Point p in pattern.Points)
                {
                    if (!p.IsTheSameWithOne(lastPattern.Points))
                    {
                        newPattern = true;
                        break;
                    }
                }
                if (newPattern)
                {
                    Patterns.Add(pattern);
                    return true;
                }
                return false;
            }

            public void UpdatePattern(int CurrentBar, GeneralSettings _GeneralSettings)
            {
                if (Patterns.Count == 0)
                    return;
                PatternBase lastPattern = Patterns[Patterns.Count - 1];
                if (lastPattern.PatternStatePattern != ePatternState.Fresh)
                    return;

                int totalPoints = _lPointsForOneDepth.Count - 1;
                if ((lastPattern.Points.Count != 4 || _lPointsForOneDepth[totalPoints-3].IsTheSame(lastPattern.Points[3])) && 
                    _lPointsForOneDepth[totalPoints - 2].IsTheSame(lastPattern.Points[2]) && _lPointsForOneDepth[totalPoints - 1].IsTheSame(lastPattern.Points[1]))
                {
                    PatternBase _Pattern = null;
                    if(lastPattern is AscTriangle)
                    {
                        _Pattern = AscTriangle.FindPatternAsc(AllPoints, _dTickSize, CurrentBar, _GeneralSettings.GetSettingsFor(ePatterns.AscendingTriangle));
                    }
                    else if (lastPattern is DescTriangle)
                    {
                        _Pattern = DescTriangle.FindPatternDesc(AllPoints, _dTickSize, CurrentBar, _GeneralSettings.GetSettingsFor(ePatterns.DescendingTriangle));
                    }
                    else if (lastPattern is SymTriangle)
                    {
                        _Pattern = SymTriangle.FindPattern(AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.SymmetricTriangle));
                    }
                    else if (lastPattern is Wedge)
                    {
                        _Pattern = Wedge.FindPattern(AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.Wedge));
                    }
                    else if (lastPattern is ExpTriangle)
                    {
                        _Pattern = ExpTriangle.FindPattern(AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.ExpandingTriangle));
                    }
                    else if (lastPattern is Rectangle)
                    {
                        _Pattern = Rectangle.FindPattern(AllPoints, _dTickSize, _GeneralSettings.GetSettingsFor(ePatterns.Rectangle));
                    }
                    else if (lastPattern is Flag)
                    {
                        _Pattern = Flag.FindPattern(AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.Flag));
                    }
                    else if (lastPattern is ABC)
                    {
                        _Pattern = ABC.FindPattern(AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.ABC));
                    }
                    else if (lastPattern is ABCD)
                    {
                        _Pattern = ABCD.FindPattern(AllPoints, _GeneralSettings.GetSettingsFor(ePatterns.ABCD));
                    }

                    if (_Pattern != null)
                        Patterns[Patterns.Count - 1] = _Pattern;
                    else
                        Patterns.RemoveAt(Patterns.Count - 1);
                }
            }

            public void DrawZigZag(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale)
            {
                if (AllPoints.Count > 0)
                {
                    for (int i = 1; i < AllPoints.Count; i++)
                    {
                        DrawSharpDX.Line(RenderTarget, chartControl, chartScale, AllPoints[i - 1].Time, AllPoints[i - 1].Price, AllPoints[i].Time, AllPoints[i].Price, new Stroke(Brushes.Lime));
                    }
                }
            }

            public int Search(int barNo, DateTime time, double high, double low, double close, double close1, double close2, double PatternBreakMultiple, double PatternBreakPercent, bool OnBarClose) //
            {
                bool _bSameBar = barNo == _iBarNumber;
                int x = 1;

                double _dCurrentClose = close;
                double _dPreviousClose = close1;

                if (OnBarClose)
                {
                    if (_bSameBar)
                        return 0;
                    else
                    {
                        _dCurrentClose = close1;
                        _dPreviousClose = close2;
                    }
                }

                _indiATR.Update();

                foreach (PatternBase pattern in Patterns)
                {
                    pattern.UpdatePatternAndLines(time, _dCurrentClose, _dPreviousClose, high, low, barNo, PatternBreakMultiple * _indiATR[x], PatternBreakPercent);
                }

                if (_bSameBar)
                    return 0;
                _iBarNumber = barNo;

                _indiLowest.Update();
                _indiHighest.Update();

                double _depth = _indiATR[x] * _dSensitivity;

                bool updateHigh = _bUpTrend && high > currentHigh;
                bool updateLow = !_bUpTrend && low < currentLow;
                bool addHigh = !_bUpTrend && !(low < currentLow) && high > Math.Max(_indiHighest[x+1], currentLow + _depth);
                bool addLow = _bUpTrend && !(high > currentHigh) && low < Math.Min(_indiLowest[x+1], currentHigh - _depth);

                if (addHigh)
                {
                    _bUpTrend = true;
                    currentHigh = _indiHighest[x];
                    _lPointsForOneDepth.Add(new Point() { Bar = barNo, Price = currentHigh, Time = time, IsHigh = true });
                    return 1;
                }
                else if (updateHigh)
                {
                    _bUpTrend = true;
                    currentHigh = high;
                    UpdateListPointValues(0, barNo, currentHigh, time);
                    return 2;
                }
                else if (addLow)
                {
                    _bUpTrend = false;
                    currentLow = _indiLowest[x];
                    _lPointsForOneDepth.Add(new Point() { Bar = barNo, Price = currentLow, Time = time, IsHigh = false });
                    return 1;
                }
                else if (updateLow)
                {
                    _bUpTrend = false;
                    currentLow = low;
                    UpdateListPointValues(0, barNo, currentLow, time);
                    return 2;
                }
                return 0;
            }
            #endregion

            #region Internal Functions
            private void UpdateListPointValues(int pointBack, int barNoUpd, double priceUpd, DateTime timeUpd)
            {
                int index = _lPointsForOneDepth.Count - 1 - pointBack;
                if (index > 0)
                {
                    _lPointsForOneDepth[index].Bar = barNoUpd;
                    _lPointsForOneDepth[index].Price = priceUpd;
                    _lPointsForOneDepth[index].Time = timeUpd;
                }
            }
            #endregion
        }
        #endregion

        #endregion

        #region Patterns

        #region Pattern Base
        public class PatternBase
        {
            #region Floating Variables
            protected List<Point> _lPoints = new List<Point>();
            protected DateTime _dtEndTime = DateTime.MaxValue;
            protected int _iDirection = 0;
            //internal bool _bShowPattern = true;
            protected Stroke _skPatternColor = new Stroke(Brushes.Red, DashStyleHelper.Solid, 2);
            protected int _iFillTransparency = 30;
            protected int _iDeviation = 0;
            protected ePatternState _eStatePatternDefined;
            protected ePatternState _eStateUserDefined;
            protected PatternSettings _PatternSettings = null;
            protected EntryStopsTargets _UserDefined = null;
            protected EntryStopsTargets _PatternDefined = null;
            #endregion

            #region Properties
            public ePatternType PatternType
            {
                get
                {
                    if (_iDirection == 1)
                        return ePatternType.Bull;
                    else if (_iDirection == -1)
                        return ePatternType.Bear;
                    return ePatternType.Neutral;
                }
            }
            public ePatternState PatternStateUser
            {
                get { return _eStateUserDefined; }
            }
            public ePatternState PatternStatePattern
            {
                get { return _eStatePatternDefined; }
            }
            public List<Point> Points
            {
                get { return _lPoints; }
            }
            #endregion

            #region Constructor
            public PatternBase(ePatternState PS, List<Point> points, PatternSettings settings)
            {
                _eStatePatternDefined = PS;
                _eStateUserDefined = PS;
                _lPoints = points;
                _PatternSettings = settings;
                _UserDefined = new EntryStopsTargets(settings.UserDefined);
                _PatternDefined = new EntryStopsTargets(settings.PatternDefined);
            }
            #endregion

            #region Public Functions
            public virtual void drawPattern(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime currentTime, int currentBar, GeneralSettings generalSettings)
            {
            }
            public virtual void UpdateSettings(PatternSettings patternSettings)
            {
                _PatternSettings = patternSettings;
            }
            public virtual void UpdatePatternAndLines(DateTime time, double close, double close1, double High, double Low, int bar, double PatternBreakMultiple, double PatternBreakPercent)
            {
                if (_eStatePatternDefined == ePatternState.Invalidated)
                    return;

                if (_eStatePatternDefined == ePatternState.Completed && _eStateUserDefined == ePatternState.Completed)
                    return;

                if (_UserDefined.CheckStopTarget(High, Low))
                    _eStateUserDefined = ePatternState.Completed;
                if (_PatternDefined.CheckStopTarget(High, Low))
                    _eStatePatternDefined = ePatternState.Completed;
            }
            public virtual void PlaySoundWhenPatternFound(GeneralSettings generalSettings)
            {
                if (!_PatternSettings.Show)
                    return;
                generalSettings.PlaySound();
            }
            #endregion

            #region Adjust Stroke To Pattern
            protected Stroke AdjustStrokeToPattern(Stroke stroke)
            {
                if (stroke != null)
                    if (_eStatePatternDefined == ePatternState.Fresh)
                        stroke.DashStyleHelper = DashStyleHelper.Dot;
                    else
                        stroke.DashStyleHelper = DashStyleHelper.Solid;
                return stroke;
            }
            #endregion

        }
        #endregion

        #region Wedge Pattern Class
        public class Wedge : PatternBase
        {
            #region Constructor
            public Wedge(ePatternState PS, List<Point> points, PatternSettings settings) :
                base(PS, points, settings)
            {
            }
            #endregion

            #region Find Pattern
            public static Wedge FindPattern(List<Point> p, PatternSettings settings)
            {
                if (p.Count < 5)
                    return null;

                int index = p.Count - 1;
                Point p1 = p[index];
                Point p2 = p[index - 1];
                Point p3 = p[index - 2];
                Point p4 = p[index - 3];

                bool checkPoint = (p1.Price > p2.Price) ? (p1.Price < p3.Price && p2.Price > p4.Price) : (p1.Price > p3.Price && p2.Price < p4.Price); //verifica punctele sa vada daca e un pattern in formare

                if (!checkPoint)
                    return null;

                double slopeUpLine = (p1.Price > p2.Price) ? Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price) : Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);
                double slopeDownLine = (p1.Price > p2.Price) ? Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price) : Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);
                double angle = Calc.AngleDeg(slopeUpLine, slopeDownLine);

                if (Calc.AngleAbsCompare(settings.MinAngle, settings.MaxAngle, angle))
                    return null;

                return new Wedge(ePatternState.Fresh, new List<Point>() { p1.Clone() as Point, p2.Clone() as Point, p3.Clone() as Point, p4.Clone() as Point }, settings);
            }
            #endregion

            #region Update Pattern
            public override void UpdatePatternAndLines(DateTime time, double close, double close1, double High, double Low, int bar, double PatternBreakMultiple, double PatternBreakPercent)
            {
                base.UpdatePatternAndLines(time, close, close1, High, Low, bar, PatternBreakMultiple, PatternBreakPercent);

                if (_eStatePatternDefined >= ePatternState.Filled)
                    return;

                Point p1 = _lPoints[3];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[1];
                Point p4 = _lPoints[0];

                double m1 = Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);
                double m2 = Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);

                int _iLeftPoint = Math.Min(p1.Bar, p2.Bar);

                Tuple<int, double> A = new Tuple<int, double>(_iLeftPoint, Calc.NextPoint(p1.Bar, p1.Price, m1, _iLeftPoint));
                Tuple<int, double> C = new Tuple<int, double>(_iLeftPoint, Calc.NextPoint(p2.Bar, p2.Price, m2, _iLeftPoint));
                Tuple<int, double> B = Calc.ThirdPoint(A, C, m1, m2);

                if(Calc.PatternBroken(A, B, C, bar, true, High, true, Low))
                {
                    _eStatePatternDefined = ePatternState.Invalidated;
                    _eStateUserDefined = ePatternState.Invalidated;
                    _dtEndTime = time;
                }

                if (bar < A.Item1 + Math.Abs(A.Item1 - B.Item1) * PatternBreakPercent)
                    return;

                double upLimitPrice = Calc.NextPoint(p1.Bar, p1.Price, m1, bar);
                double downLimitPrice = Calc.NextPoint(p2.Bar, p2.Price, m2, bar);
                double priceTop = (p1.Price > p2.Price ? upLimitPrice : downLimitPrice) + PatternBreakMultiple;
                double priceBottom = (p1.Price > p2.Price ? downLimitPrice : upLimitPrice) - PatternBreakMultiple;

                if (close > priceTop && close1 <= priceTop)
                {
                    _iDirection = 1;
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bull);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bull, Math.Abs(close - priceBottom));
                }
                else if (close < priceBottom && close1 >= priceBottom)
                {
                    _iDirection = -1;
                    _eStatePatternDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bear);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bear, Math.Abs(priceTop - close));
                }
            }
            #endregion

            #region Drawing Pattern
            public override void drawPattern(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime currentTime, int currentBar, GeneralSettings generalSettings)
            {
                PatternSettings settings = generalSettings.GetSettingsFor(ePatterns.Wedge);

                if (settings == null || !settings.Show)
                    return;

                List<Tuple<float, float>> patternPoints = new List<Tuple<float, float>>();

                Point p0 = _lPoints[0];
                Point p1 = _lPoints[1];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[3];

                float x0 = chartControl.GetXByTime(p0.Time); float y0 = chartScale.GetYByValue(p0.Price);
                float x1 = chartControl.GetXByTime(p1.Time); float y1 = chartScale.GetYByValue(p1.Price);
                float x2 = chartControl.GetXByTime(p2.Time); float y2 = chartScale.GetYByValue(p2.Price);
                float x3 = chartControl.GetXByTime(p3.Time); float y3 = chartScale.GetYByValue(p3.Price);

                float m1 = Calc.Slope(x0, x2, y0, y2);
                float m2 = Calc.Slope(x1, x3, y1, y3);

                //Adding Point A to List
                Tuple<float, float> A = new Tuple<float, float>(x3, y3);
                //Adding Point C to List
                Tuple<float, float> C = new Tuple<float, float>(x3, Calc.NextPoint(x2, y2, m1, x3));

                float xB = Calc.IntersectionXPoint(A.Item1, A.Item2, C.Item1, C.Item2, m1, m2);
                Tuple<float, float> B = new Tuple<float, float>(xB, Calc.IntersectionYPoint(A.Item1, A.Item2, xB, m2));

                patternPoints.Add(A);
                patternPoints.Add(B);
                patternPoints.Add(C);

                Stroke stroke = AdjustStrokeToPattern(_PatternSettings.GetStrokedByDirection(_iDirection));

                DrawSharpDX.GeometryWithFill(RenderTarget, patternPoints, stroke, generalSettings.Transparency, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale));

                if (generalSettings.ShowPatternName)
                {
                    float topLeftPoint = Math.Min(A.Item2, C.Item2);
                    string Name = _PatternSettings.Name + (_eStateUserDefined == ePatternState.Invalidated ? "\r\nINV" : "");
                    DrawSharpDX.BoxText(RenderTarget, chartControl, chartScale, Name, A.Item1 - 5, topLeftPoint, _PatternSettings.GetStrokedByDirection(_iDirection), generalSettings.Transparency,
                       generalSettings.TextBrush, generalSettings.FontFamily, false, true, null, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center);
                }
                if (generalSettings.TradePlan == "User Defined")
                    _UserDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
                else if (generalSettings.TradePlan == "Pattern Defined")
                    _PatternDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
            }
            #endregion
        }
        #endregion

        #region ABC Pattern Class
        public class ABC : PatternBase
        {
            #region Constructor
            public ABC(ePatternState PS, int dir, List<Point> points, PatternSettings settings)
                : base(PS, points, settings)
            {
                _iDirection = dir;
            }
            #endregion

            #region Find Pattern
            public static ABC FindPattern(List<Point> p, PatternSettings settings)
            {
                if (p.Count < 4)
                    return null;

                int index = p.Count - 1;
                Point p1 = p[index];
                Point p2 = p[index - 1];
                Point p3 = p[index - 2];

                double abRange = Math.Abs(p2.Price - p3.Price);
                double ValUP = p2.Price > p3.Price ? p2.Price - abRange * Math.Min(settings.Retracement1Max, settings.Retracement1Min) / 100 : p2.Price + abRange * Math.Min(settings.Retracement1Max, settings.Retracement1Min) / 100;
                double ValDOWN = p2.Price > p3.Price ? p2.Price - abRange * Math.Max(settings.Retracement1Max, settings.Retracement1Min) / 100 : p2.Price + abRange * Math.Max(settings.Retracement1Max, settings.Retracement1Min) / 100;

                bool checkPoint = (p2.Price > p3.Price) ? (p1.Price >= ValDOWN && p1.Price <= ValUP) : (p1.Price <= ValDOWN && p1.Price >= ValUP);

                if (!checkPoint)
                    return null;

                int dir = p2.Price > p3.Price ? 1 : -1;
                return new ABC(ePatternState.Fresh, dir, new List<Point>() { p1.Clone() as Point, p2.Clone() as Point, p3.Clone() as Point }, settings);
            }
            #endregion

            #region Update Pattern
            public override void UpdatePatternAndLines(DateTime time, double close, double close1, double High, double Low, int bar, double PatternBreakMultiple, double PatternBreakPercent)
            {
                base.UpdatePatternAndLines(time, close, close1, High, Low, bar, PatternBreakMultiple, PatternBreakPercent);

                if (_eStatePatternDefined >= ePatternState.Filled)
                    return;

                Point p1 = _lPoints[1];
                Point p2 = _lPoints[2];
                Point p0 = _lPoints[0];

                if(Math.Max(p1.Price, p2.Price) < close || Math.Min(p1.Price, p2.Price) > close)
                {
                    _eStatePatternDefined = ePatternState.Invalidated;
                    _eStateUserDefined = ePatternState.Invalidated;
                    _dtEndTime = time;
                }

                if (_iDirection == 1 && close >= p0.Price)
                {
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    //_dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bull);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bull, Math.Abs(close - Math.Min(p1.Price, p2.Price)));
                }
                else if (_iDirection == -1 && close <= p0.Price)
                {
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;  
                    //_dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bear);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bear, Math.Abs(close - Math.Max(p1.Price, p2.Price)));
                }
            }
            #endregion

            #region Drawing Pattern
            public override void drawPattern(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime currentTime, int currentBar, GeneralSettings generalSettings)
            {
                PatternSettings settings = generalSettings.GetSettingsFor(ePatterns.ABC);

                if (settings == null || !settings.Show)
                    return;

                List<Tuple<float, float>> patternPoints = new List<Tuple<float, float>>();

                Point p0 = _lPoints[0];
                Point p1 = _lPoints[1];
                Point p2 = _lPoints[2];

                float x0 = chartControl.GetXByTime(p0.Time); float y0 = chartScale.GetYByValue(p0.Price);
                float x1 = chartControl.GetXByTime(p1.Time); float y1 = chartScale.GetYByValue(p1.Price);
                float x2 = chartControl.GetXByTime(p2.Time); float y2 = chartScale.GetYByValue(p2.Price);

                //Adding Point A to List
                Tuple<float, float> A = new Tuple<float, float>(x2, y2);
                //Adding Point B to List
                Tuple<float, float> B = new Tuple<float, float>(x1, y1);
                //Adding Point C to List
                Tuple<float, float> C = new Tuple<float, float>(x0, y0);

                patternPoints.Add(A);
                patternPoints.Add(B);
                patternPoints.Add(C);

                Stroke stroke = AdjustStrokeToPattern(_PatternSettings.GetStrokedByDirection(_iDirection));

                DrawSharpDX.GeometryWithFill(RenderTarget, patternPoints, stroke, generalSettings.Transparency, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale));
                if (generalSettings.ShowPatternName)
                {
                    string Name = _PatternSettings.Name + (_eStateUserDefined == ePatternState.Invalidated ? "\r\nINV" : "");
                    DrawSharpDX.BoxText(RenderTarget, chartControl, chartScale, Name, A.Item1 - 5, A.Item2, _PatternSettings.GetStrokedByDirection(_iDirection), generalSettings.Transparency,
                        generalSettings.TextBrush, generalSettings.FontFamily, false, true, null, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center,
                        SharpDX.DirectWrite.ParagraphAlignment.Far, SharpDX.DirectWrite.TextAlignment.Trailing);
                }
                if (generalSettings.TradePlan == "User Defined")
                    _UserDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
                else if (generalSettings.TradePlan == "Pattern Defined")
                    _PatternDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
            }
            #endregion
        }
        #endregion

        #region Asc Triangle Pattern Class
        public class AscTriangle : PatternBase
        {
            #region Constructor
            public AscTriangle(ePatternState PS, int direction, List<Point> points, PatternSettings settings)
                : base(PS, points, settings)
            {
                _iDirection = direction;
            }
            #endregion

            #region Find ASC Pattern
            public static AscTriangle FindPatternAsc(List<Point> p, double tickSize, int currentBar, PatternSettings settings)
            {
                if (p.Count < 5)
                    return null;

                int index = p.Count - 1;
                Point p1 = p[index];
                Point p2 = p[index - 1];
                Point p3 = p[index - 2];
                Point p4 = p[index - 3];

                bool mainCond = p1.Price > p2.Price;
                double lastPointPrice = mainCond ? Calc.NextPoint(p1, p3, currentBar) : Calc.NextPoint(p2, p4, currentBar);
                double firstPointPrice = mainCond ? Calc.NextPoint(p1, p3, p4.Bar) : p4.Price;

                if (Math.Abs(lastPointPrice - (mainCond ? firstPointPrice : p4.Price)) > settings.SlopeDev * tickSize)
                    return null;

                bool cond1Asc = ((Math.Abs(lastPointPrice - firstPointPrice) <= settings.SlopeDev * tickSize) && (p2.Price > p4.Price));
                bool cond2Asc = ((Math.Abs(lastPointPrice - p4.Price) <= settings.SlopeDev * tickSize) && (p1.Price > p3.Price));

                bool checkPointAsc = mainCond ? cond1Asc : cond2Asc;

                if (!checkPointAsc)
                    return null;

                double slopeUpLine = mainCond ? Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price) : Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);
                double slopeDownLine = mainCond ? Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price) : Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);
                double angle = Calc.AngleDeg(slopeUpLine, slopeDownLine);

                if (Calc.AngleAbsCompare(settings.MinAngle, settings.MaxAngle, angle))
                    return null;

                return new AscTriangle(ePatternState.Fresh, 1, new List<Point>() { p1.Clone() as Point, p2.Clone() as Point, p3.Clone() as Point, p4.Clone() as Point }, settings);
            }
            #endregion

            #region Update Pattern
            public override void UpdatePatternAndLines(DateTime time, double close, double close1, double High, double Low, int bar, double PatternBreakMultiple, double PatternBreakPercent)
            {
                base.UpdatePatternAndLines(time, close, close1, High, Low, bar, PatternBreakMultiple, PatternBreakPercent);

                if (_eStatePatternDefined >= ePatternState.Filled)
                    return;

                Point p1 = _lPoints[3];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[1];
                Point p4 = _lPoints[0];

                double m1 = Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);
                double m2 = Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);

                int _iLeftPoint = Math.Min(p1.Bar, p2.Bar);

                Tuple<int, double> A = new Tuple<int, double>(_iLeftPoint, Calc.NextPoint(p1.Bar, p1.Price, m1, _iLeftPoint));
                Tuple<int, double> C = new Tuple<int, double>(_iLeftPoint, Calc.NextPoint(p2.Bar, p2.Price, m2, _iLeftPoint));
                Tuple<int, double> B = Calc.ThirdPoint(A, C, m1, m2);

                if (Calc.PatternBroken(A, B, C, bar, true, close, false, 0))
                {
                    _eStatePatternDefined = ePatternState.Invalidated;
                    _eStateUserDefined = ePatternState.Invalidated;
                    _dtEndTime = time;
                }

                double upLimitPrice = Calc.NextPoint(p1.Bar, p1.Price, m1, bar);
                double downLimitPrice = Calc.NextPoint(p2.Bar, p2.Price, m2, bar);
                double price = (p1.Price > p2.Price ? Math.Max(p1.Price, p3.Price) : Math.Max(p2.Price, p4.Price)) + PatternBreakMultiple;

                if (bar < A.Item1 + Math.Abs(A.Item1 - B.Item1) * PatternBreakPercent)
                {
                    if (close > price && close1 <= price)
                    {
                        _eStatePatternDefined = ePatternState.Invalidated;
                        _eStateUserDefined = ePatternState.Invalidated;
                        _dtEndTime = time;
                    }
                    return;
                }

                if (close > price && close1 <= price)
                {
                    _iDirection = 1;
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bull);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bull, Math.Abs(Math.Min(upLimitPrice, downLimitPrice) - close));
                }
                //else if (close < downLimitPrice - PatternBreakMultiple)
                //{
                //    _iDirection = -1;
                //    _eStatePatternDefined = ePatternState.Filled;
                //    _eStateUserDefined = ePatternState.Filled;
                //    _dtEndTime = time;
                //    _UserDefined.StartTrade(close, time, bar, ePatternType.Bear);
                //    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bear, Math.Abs(p4.Price - Calc.NextPoint(p1.Bar, p1.Price, m1, p4.Bar)));
                //}
                //else if (close < (p1.Price < p2.Price ? upLimitPrice : downLimitPrice) - PatternBreakMultiple)
                //{
                //    _eStatePatternDefined = ePatternState.Completed;
                //    _eStateUserDefined = ePatternState.Completed;
                //    _dtEndTime = time;
                //}
            }
            #endregion

            #region Drawing Pattern
            public override void drawPattern(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime currentTime, int currentBar, GeneralSettings generalSettings)
            {
                PatternSettings settings = generalSettings.GetSettingsFor(ePatterns.AscendingTriangle);

                if (settings == null || !settings.Show)
                    return;

                List<Tuple<float, float>> patternPoints = new List<Tuple<float, float>>();

                Point p0 = _lPoints[0];
                Point p1 = _lPoints[1];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[3];

                float x0 = chartControl.GetXByTime(p0.Time); float y0 = chartScale.GetYByValue(p0.Price);
                float x1 = chartControl.GetXByTime(p1.Time); float y1 = chartScale.GetYByValue(p1.Price);
                float x2 = chartControl.GetXByTime(p2.Time); float y2 = chartScale.GetYByValue(p2.Price);
                float x3 = chartControl.GetXByTime(p3.Time); float y3 = chartScale.GetYByValue(p3.Price);

                float m1 = Calc.Slope(x0, x2, y0, y2);
                float m2 = Calc.Slope(x1, x3, y1, y3);

                Tuple<float, float> A = new Tuple<float, float>(x3, Math.Min(y0, Math.Min(y1, Math.Min(y2, y3))));
                Tuple<float, float> B = new Tuple<float, float>(x3, y3 > y2 ? y3 : Calc.NextPoint(x2, y2, m1, x3));

                float pt1x = y3 > y2 ? x1 : x0; float pt1y = y3 > y2 ? y1 : y0;

                float xB = Calc.IntersectionXPoint(pt1x, pt1y, A.Item1, A.Item2, 0, y3 > y2 ? m2 : m1);
                Tuple<float, float> C = new Tuple<float, float>(xB, Math.Min(y0, Math.Min(y1, Math.Min(y2, y3))));

                patternPoints.Add(A);
                patternPoints.Add(B);
                patternPoints.Add(C);

                Stroke stroke = AdjustStrokeToPattern(_PatternSettings.GetStrokedByDirection(_iDirection));

                DrawSharpDX.GeometryWithFill(RenderTarget, patternPoints, stroke, generalSettings.Transparency, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale));
                if (generalSettings.ShowPatternName)
                {
                    float topLeftPoint = Math.Min(A.Item2, C.Item2);
                    string Name = _PatternSettings.Name + (_eStateUserDefined == ePatternState.Invalidated ? "\r\nINV" : "");
                    DrawSharpDX.BoxText(RenderTarget, chartControl, chartScale, Name, A.Item1 - 5, topLeftPoint, _PatternSettings.GetStrokedByDirection(_iDirection), generalSettings.Transparency,
                        generalSettings.TextBrush, generalSettings.FontFamily, false, true, null, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center,
                        SharpDX.DirectWrite.ParagraphAlignment.Far, SharpDX.DirectWrite.TextAlignment.Trailing);
                }
                if (generalSettings.TradePlan == "User Defined")
                    _UserDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
                else if (generalSettings.TradePlan == "Pattern Defined")
                    _PatternDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
            }

            #endregion
        }
        #endregion

        #region Desc Triangle Pattern Class
        public class DescTriangle : PatternBase
        {
            #region Constructor
            public DescTriangle(ePatternState PS, int direction, List<Point> points, PatternSettings settings)
                : base(PS, points, settings)
            {
                _iDirection = direction;
            }
            #endregion

            #region Find DESC Pattern
            public static DescTriangle FindPatternDesc(List<Point> p, double tickSize, int currentBar, PatternSettings settings)
            {
                if (p.Count < 5)
                    return null;

                int index = p.Count - 1;
                Point p1 = p[index];
                Point p2 = p[index - 1];
                Point p3 = p[index - 2];
                Point p4 = p[index - 3];

                bool mainCond = p1.Price > p2.Price;
                double lastPointPrice = mainCond ? Calc.NextPoint(p2, p4, currentBar) : Calc.NextPoint(p1, p3, currentBar);
                double firstPointPrice = mainCond ? p4.Price : Calc.NextPoint(p1, p3, p4.Bar);

                if (Math.Abs(lastPointPrice - (mainCond ? p4.Price : firstPointPrice)) > settings.SlopeDev * tickSize)
                    return null;

                bool cond1Desc = ((Math.Abs(lastPointPrice - firstPointPrice) <= settings.SlopeDev * tickSize) && (p1.Price < p3.Price));
                bool cond2Desc = ((Math.Abs(lastPointPrice - p4.Price) <= settings.SlopeDev * tickSize) && (p2.Price < p4.Price));

                bool checkPointDesc = mainCond ? cond1Desc : cond2Desc;

                if (!checkPointDesc)
                    return null;

                double slopeUpLine = (p1.Price > p2.Price) ? Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price) : Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);
                double slopeDownLine = (p1.Price > p2.Price) ? Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price) : Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);
                double angle = Calc.AngleDeg(slopeUpLine, slopeDownLine);

                if (Calc.AngleAbsCompare(settings.MinAngle, settings.MaxAngle, angle))
                    return null;

                return new DescTriangle(ePatternState.Fresh, -1, new List<Point>() { p1.Clone() as Point, p2.Clone() as Point, p3.Clone() as Point, p4.Clone() as Point }, settings);
            }
            #endregion

            #region Update Pattern
            public override void UpdatePatternAndLines(DateTime time, double close, double close1, double High, double Low, int bar, double PatternBreakMultiple, double PatternBreakPercent)
            {
                base.UpdatePatternAndLines(time, close, close1, High, Low, bar, PatternBreakMultiple, PatternBreakPercent);

                if (_eStatePatternDefined >= ePatternState.Filled)
                    return;

                Point p1 = _lPoints[3];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[1];
                Point p4 = _lPoints[0];

                double m1 = Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);
                double m2 = Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);

                int _iLeftPoint = Math.Min(p1.Bar, p2.Bar);

                Tuple<int, double> A = new Tuple<int, double>(_iLeftPoint, Calc.NextPoint(p1.Bar, p1.Price, m1, _iLeftPoint));
                Tuple<int, double> C = new Tuple<int, double>(_iLeftPoint, Calc.NextPoint(p2.Bar, p2.Price, m2, _iLeftPoint));
                Tuple<int, double> B = Calc.ThirdPoint(A, C, m1, m2);

                if (Calc.PatternBroken(A, B, C, bar, false, 0, true, close))
                {
                    _eStatePatternDefined = ePatternState.Invalidated;
                    _eStateUserDefined = ePatternState.Invalidated;
                    _dtEndTime = time;
                }

                double upLimitPrice = Calc.NextPoint(p1.Bar, p1.Price, m1, bar);
                double downLimitPrice = Calc.NextPoint(p2.Bar, p2.Price, m2, bar);
                double price = (p1.Price > p2.Price ? Math.Min(p2.Price, p4.Price) : Math.Min(p1.Price, p3.Price)) - PatternBreakMultiple;

                if (bar < A.Item1 + Math.Abs(A.Item1 - B.Item1) * PatternBreakPercent)
                {
                    if (close < price && close1 >= price)
                    {
                        _eStatePatternDefined = ePatternState.Invalidated;
                        _eStateUserDefined = ePatternState.Invalidated;
                        _dtEndTime = time;
                    }
                    return;
                }

                if (close < price && close1 >= price)
                {
                    _iDirection = -1;
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bear);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bear, Math.Abs(Math.Max(upLimitPrice, downLimitPrice) - close));
                }
                //else if (close > (p1.Price < p2.Price ? downLimitPrice : upLimitPrice) + PatternBreakMultiple)
                //{
                //    _eStatePatternDefined = ePatternState.Completed;
                //    _eStateUserDefined = ePatternState.Completed;
                //    _dtEndTime = time;
                //}
            }
            #endregion

            #region Drawing Pattern
            public override void drawPattern(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime currentTime, int currentBar, GeneralSettings generalSettings)
            {
                PatternSettings settings = generalSettings.GetSettingsFor(ePatterns.DescendingTriangle);

                if (settings == null || !settings.Show)
                    return;

                List<Tuple<float, float>> patternPoints = new List<Tuple<float, float>>();

                Point p0 = _lPoints[0];
                Point p1 = _lPoints[1];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[3];

                float x0 = chartControl.GetXByTime(p0.Time); float y0 = chartScale.GetYByValue(p0.Price);
                float x1 = chartControl.GetXByTime(p1.Time); float y1 = chartScale.GetYByValue(p1.Price);
                float x2 = chartControl.GetXByTime(p2.Time); float y2 = chartScale.GetYByValue(p2.Price);
                float x3 = chartControl.GetXByTime(p3.Time); float y3 = chartScale.GetYByValue(p3.Price);

                float m1 = Calc.Slope(x0, x2, y0, y2);
                float m2 = Calc.Slope(x1, x3, y1, y3);

                Tuple<float, float> A = new Tuple<float, float>(x3, Math.Max(y0, Math.Max(y1, Math.Max(y2, y3))));
                Tuple<float, float> B = new Tuple<float, float>(x3, y3 < y2 ? y3 : Calc.NextPoint(x2, y2, m1, x3));

                float pt1x = y3 < y2 ? x1 : x0; float pt1y = y3 < y2 ? y1 : y0;

                float xB = Calc.IntersectionXPoint(pt1x, pt1y, A.Item1, A.Item2, 0, y3 < y2 ? m2 : m1);
                Tuple<float, float> C = new Tuple<float, float>(xB, Math.Max(y0, Math.Max(y1, Math.Max(y2, y3))));

                patternPoints.Add(A);
                patternPoints.Add(B);
                patternPoints.Add(C);

                Stroke stroke = AdjustStrokeToPattern(_PatternSettings.GetStrokedByDirection(_iDirection));

                DrawSharpDX.GeometryWithFill(RenderTarget, patternPoints, stroke, generalSettings.Transparency, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale));
                if (generalSettings.ShowPatternName)
                {
                    float topLeftPoint = Math.Min(A.Item2, C.Item2);
                    string Name = _PatternSettings.Name + (_eStateUserDefined == ePatternState.Invalidated ? "\r\nINV" : "");
                    DrawSharpDX.BoxText(RenderTarget, chartControl, chartScale, Name, A.Item1 - 5, topLeftPoint, _PatternSettings.GetStrokedByDirection(_iDirection), generalSettings.Transparency,
                        generalSettings.TextBrush, generalSettings.FontFamily, false, true, null, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center,
                        SharpDX.DirectWrite.ParagraphAlignment.Far, SharpDX.DirectWrite.TextAlignment.Trailing);
                }
                if (generalSettings.TradePlan == "User Defined")
                    _UserDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
                else if (generalSettings.TradePlan == "Pattern Defined")
                    _PatternDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
            }
            #endregion
        }
        #endregion

        #region Symmetric Triangle Pattern Class
        public class SymTriangle : PatternBase
        {
            #region Constructor
            public SymTriangle(ePatternState PS, List<Point> points, PatternSettings settings)
                : base(PS, points, settings)
            {
            }
            #endregion

            #region Find Pattern
            public static SymTriangle FindPattern(List<Point> p, PatternSettings settings)
            {
                if (p.Count < 5)
                    return null;

                int index = p.Count - 1;
                Point p1 = p[index];
                Point p2 = p[index - 1];
                Point p3 = p[index - 2];
                Point p4 = p[index - 3];

                bool checkPoint = (p1.Price > p2.Price) ? (p1.Price < (p3.Price) && p2.Price > (p4.Price)) :
                                    (p1.Price > (p3.Price) && p2.Price < p4.Price);
                if (!checkPoint)
                    return null;

                double slopeUpLine = (p1.Price > p2.Price) ? Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price) : Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);
                double slopeDownLine = (p1.Price > p2.Price) ? Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price) : Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);

                if ((slopeUpLine > 0 && slopeDownLine > 0) || (slopeUpLine < 0 && slopeDownLine < 0) || slopeUpLine == 0 || slopeDownLine == 0)
                    return null;

                double maxAggresiveSlope = Math.Max(Math.Abs(slopeUpLine), Math.Abs(slopeDownLine));
                double minAggresiveSlope = Math.Min(Math.Abs(slopeUpLine), Math.Abs(slopeDownLine));

                if (minAggresiveSlope / maxAggresiveSlope > settings.SlopeDev / 100)
                    return null;

                double angle = Calc.AngleDeg(slopeUpLine, slopeDownLine);

                if (Calc.AngleAbsCompare(settings.MinAngle, settings.MaxAngle, angle))
                    return null;

                return new SymTriangle(ePatternState.Fresh, new List<Point>() { p1.Clone() as Point, p2.Clone() as Point, p3.Clone() as Point, p4.Clone() as Point }, settings);
            }
            #endregion

            #region Update Pattern
            public override void UpdatePatternAndLines(DateTime time, double close, double close1, double High, double Low, int bar, double PatternBreakMultiple, double PatternBreakPercent)
            {
                base.UpdatePatternAndLines(time, close, close1, High, Low, bar, PatternBreakMultiple, PatternBreakPercent);

                if (_eStatePatternDefined >= ePatternState.Filled)
                    return;

                Point p1 = _lPoints[3];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[1];
                Point p4 = _lPoints[0];

                double m1 = Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);
                double m2 = Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);

                int _iLeftPoint = Math.Min(p1.Bar, p2.Bar);

                Tuple<int, double> A = new Tuple<int, double>(_iLeftPoint, Calc.NextPoint(p1.Bar, p1.Price, m1, _iLeftPoint));
                Tuple<int, double> C = new Tuple<int, double>(_iLeftPoint, Calc.NextPoint(p2.Bar, p2.Price, m2, _iLeftPoint));
                Tuple<int, double> B = Calc.ThirdPoint(A, C, m1, m2);

                if (Calc.PatternBroken(A, B, C, bar, true, High, true, Low))
                {
                    _eStatePatternDefined = ePatternState.Invalidated;
                    _eStateUserDefined = ePatternState.Invalidated;
                    _dtEndTime = time;
                }

                //if(time == new DateTime(2022, 1, 5, 4, 3, 00))
                //{

                //}

                if (bar < A.Item1 + Math.Abs(A.Item1 - B.Item1) * PatternBreakPercent)
                    return;

                double upLimitPrice = Calc.NextPoint(p1.Bar, p1.Price, m1, bar);
                double downLimitPrice = Calc.NextPoint(p2.Bar, p2.Price, m2, bar);
                double priceTop = (p1.Price > p2.Price ? upLimitPrice : downLimitPrice) + PatternBreakMultiple;
                double priceBottom = (p1.Price > p2.Price ? downLimitPrice : upLimitPrice) - PatternBreakMultiple;

                if (close > priceTop && close1 <= priceTop)
                {
                    _iDirection = 1;
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bull);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bull, Math.Abs(priceBottom - close));
                }
                else if (close < priceBottom && close1 >= priceBottom)
                {
                    _iDirection = -1;
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bear);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bear, Math.Abs(priceTop - close));
                }
            }
            #endregion

            #region Drawing Pattern
            public override void drawPattern(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime currentTime, int currentBar, GeneralSettings generalSettings)
            {
                PatternSettings settings = generalSettings.GetSettingsFor(ePatterns.SymmetricTriangle);

                if (settings == null || !settings.Show)
                    return;

                List<Tuple<float, float>> patternPoints = new List<Tuple<float, float>>();

                Point p0 = _lPoints[0];
                Point p1 = _lPoints[1];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[3];

                float x0 = chartControl.GetXByTime(p0.Time); float y0 = chartScale.GetYByValue(p0.Price);
                float x1 = chartControl.GetXByTime(p1.Time); float y1 = chartScale.GetYByValue(p1.Price);
                float x2 = chartControl.GetXByTime(p2.Time); float y2 = chartScale.GetYByValue(p2.Price);
                float x3 = chartControl.GetXByTime(p3.Time); float y3 = chartScale.GetYByValue(p3.Price);

                float m1 = Calc.Slope(x0, x2, y0, y2);
                float m2 = Calc.Slope(x1, x3, y1, y3);

                //Adding Point A to List
                Tuple<float, float> A = new Tuple<float, float>(x3, y3);
                //Adding Point C to List
                Tuple<float, float> C = new Tuple<float, float>(x3, Calc.NextPoint(x2, y2, m1, x3));

                float xB = Calc.IntersectionXPoint(A.Item1, A.Item2, C.Item1, C.Item2, m1, m2);
                Tuple<float, float> B = new Tuple<float, float>(xB, Calc.IntersectionYPoint(A.Item1, A.Item2, xB, m2));

                patternPoints.Add(A);
                patternPoints.Add(B);
                patternPoints.Add(C);

                Stroke stroke = AdjustStrokeToPattern(_PatternSettings.GetStrokedByDirection(_iDirection));

                DrawSharpDX.GeometryWithFill(RenderTarget, patternPoints, stroke, generalSettings.Transparency, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale));
                if (generalSettings.ShowPatternName)
                {
                    float topLeftPoint = Math.Min(A.Item2, C.Item2);
                    string Name = _PatternSettings.Name + (_eStateUserDefined == ePatternState.Invalidated ? "\r\nINV" : "");
                    DrawSharpDX.BoxText(RenderTarget, chartControl, chartScale, Name, A.Item1 - 5, topLeftPoint, _PatternSettings.GetStrokedByDirection(_iDirection), generalSettings.Transparency,
                       generalSettings.TextBrush, generalSettings.FontFamily, false, true, null, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center,
                       SharpDX.DirectWrite.ParagraphAlignment.Far, SharpDX.DirectWrite.TextAlignment.Trailing);
                }
                if (generalSettings.TradePlan == "User Defined")
                    _UserDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
                else if (generalSettings.TradePlan == "Pattern Defined")
                    _PatternDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
            }
            #endregion
        }
        #endregion

        #region Expanding Triangle Pattern Class
        public class ExpTriangle : PatternBase
        {
            #region Constructor
            public ExpTriangle(ePatternState PS, List<Point> points, PatternSettings settings)
                : base(PS, points, settings)
            {
            }
            #endregion

            #region Find Pattern
            public static ExpTriangle FindPattern(List<Point> p, PatternSettings settings)
            {
                if (p.Count < 5)
                    return null;

                int index = p.Count - 1;
                Point p4 = p[index];
                Point p3 = p[index - 1];
                Point p2 = p[index - 2];
                Point p1 = p[index - 3];

                bool checkPoint = (p1.Price > p2.Price) ? (p1.Price < p3.Price && p2.Price > p4.Price)
                                    : (p1.Price > p3.Price && p2.Price < p4.Price);
                if (!checkPoint)
                    return null;
                double slopeUpLine = (p1.Price > p2.Price) ? Calc.Slope(p3.Bar, p1.Bar, p3.Price, p1.Price) : Calc.Slope(p4.Bar, p2.Bar, p4.Price, p2.Price);
                double slopeDownLine = (p1.Price > p2.Price) ? Calc.Slope(p4.Bar, p2.Bar, p4.Price, p2.Price) : Calc.Slope(p3.Bar, p1.Bar, p3.Price, p1.Price);
                double angle = Calc.AngleDeg(slopeUpLine, slopeDownLine);

                if (Calc.AngleAbsCompare(settings.MinAngle, settings.MaxAngle, angle))
                    return null;

                return new ExpTriangle(ePatternState.Fresh, new List<Point>() { p1.Clone() as Point, p2.Clone() as Point, p3.Clone() as Point, p4.Clone() as Point }, settings);

            }
            #endregion

            #region Update Pattern
            public override void UpdatePatternAndLines(DateTime time, double close, double close1, double High, double Low, int bar, double PatternBreakMultiple, double PatternBreakPercent)
            {
                base.UpdatePatternAndLines(time, close, close1, High, Low, bar, PatternBreakMultiple, PatternBreakPercent);

                if (_eStatePatternDefined >= ePatternState.Filled)
                    return;

                Point p1 = _lPoints[3];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[1];
                Point p4 = _lPoints[0];

                if (bar - p4.Bar > _PatternSettings.MaxBars)
                {
                    _eStatePatternDefined = ePatternState.Invalidated;
                    _eStateUserDefined = ePatternState.Invalidated;
                    _dtEndTime = time;
                    return;
                }

                double m1 = Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);
                double m2 = Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);

                Tuple<int, double> A = new Tuple<int, double>(bar, Calc.NextPoint(p1.Bar, p1.Price, m1, bar));
                Tuple<int, double> C = new Tuple<int, double>(bar, Calc.NextPoint(p2.Bar, p2.Price, m2, bar));

                double upLimitPrice = Calc.NextPoint(p1.Bar, p1.Price, m1, bar);
                double downLimitPrice = Calc.NextPoint(p2.Bar, p2.Price, m2, bar);

                if (close > (p1.Price > p2.Price ? upLimitPrice : downLimitPrice) + PatternBreakMultiple)
                {
                    _iDirection = 1;
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bull);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bull, Math.Abs(Math.Min(upLimitPrice, downLimitPrice) - close));
                }
                else if (close < (p1.Price > p2.Price ? downLimitPrice : upLimitPrice) - PatternBreakMultiple)
                {
                    _iDirection = -1;
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bear);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bear, Math.Abs(Math.Max(upLimitPrice, downLimitPrice) - close));
                }
            }
            #endregion

            #region Drawing Pattern
            public override void drawPattern(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime currentTime, int currentBar, GeneralSettings generalSettings)
            {
                PatternSettings settings = generalSettings.GetSettingsFor(ePatterns.ExpandingTriangle);

                if (settings == null || !settings.Show)
                    return;

                List<Tuple<float, float>> patternPoints = new List<Tuple<float, float>>();

                Point p0 = _lPoints[0];
                Point p1 = _lPoints[1];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[3];

                float x0 = chartControl.GetXByTime(p0.Time); float y0 = chartScale.GetYByValue(p0.Price);
                float x1 = chartControl.GetXByTime(p1.Time); float y1 = chartScale.GetYByValue(p1.Price);
                float x2 = chartControl.GetXByTime(p2.Time); float y2 = chartScale.GetYByValue(p2.Price);
                float x3 = chartControl.GetXByTime(p3.Time); float y3 = chartScale.GetYByValue(p3.Price);
                float x4 = chartControl.GetXByTime(_dtEndTime != DateTime.MaxValue ? _dtEndTime : currentTime);

                float m1 = Calc.Slope(x0, x2, y0, y2);
                float m2 = Calc.Slope(x1, x3, y1, y3);

                //Adding Point A to List
                Tuple<float, float> A = new Tuple<float, float>(x4, Calc.NextPoint(x3, y3, m2, x4));
                //Adding Point C to List
                Tuple<float, float> C = new Tuple<float, float>(x4, Calc.NextPoint(x2, y2, m1, x4));

                float xB = Calc.IntersectionXPoint(A.Item1, A.Item2, C.Item1, C.Item2, m1, m2);
                Tuple<float, float> B = new Tuple<float, float>(xB, Calc.IntersectionYPoint(A.Item1, A.Item2, xB, m2));

                patternPoints.Add(A);
                patternPoints.Add(B);
                patternPoints.Add(C);

                Stroke stroke = AdjustStrokeToPattern(_PatternSettings.GetStrokedByDirection(_iDirection));

                DrawSharpDX.GeometryWithFill(RenderTarget, patternPoints, stroke, generalSettings.Transparency, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale));
                if (generalSettings.ShowPatternName)
                {
                    float topLeftPoint = B.Item2;
                    string Name = _PatternSettings.Name + (_eStateUserDefined == ePatternState.Invalidated ? "\r\nINV" : "");
                    DrawSharpDX.BoxText(RenderTarget, chartControl, chartScale, Name, B.Item1 - 5, topLeftPoint, _PatternSettings.GetStrokedByDirection(_iDirection), generalSettings.Transparency,
                       generalSettings.TextBrush, generalSettings.FontFamily, false, true, null, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center, 
                       SharpDX.DirectWrite.ParagraphAlignment.Far, SharpDX.DirectWrite.TextAlignment.Trailing);
                }
                if (generalSettings.TradePlan == "User Defined")
                    _UserDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
                else if (generalSettings.TradePlan == "Pattern Defined")
                    _PatternDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
            }
            #endregion
        }
        #endregion

        #region Rectangle Pattern Class
        public class Rectangle : PatternBase
        {
            #region Constructor
            public Rectangle(ePatternState PS, List<Point> points, PatternSettings settings)
                : base(PS, points, settings)
            {
            }
            #endregion

            #region Find Pattern
            public static Rectangle FindPattern(List<Point> p, double tickSize, PatternSettings settings) // nu cred ca imi trebuie angles
            {
                if (p.Count < 5)
                    return null;

                int index = p.Count - 1;
                Point p1 = p[index];
                Point p2 = p[index - 1];
                Point p3 = p[index - 2];
                Point p4 = p[index - 3];

                bool checkPoint = Math.Abs(p1.Price - p3.Price) <= settings.SlopeDev * tickSize && Math.Abs(p2.Price - p4.Price) <= settings.SlopeDev * tickSize; //verifica punctele sa vada daca e un pattern in formare

                if (!checkPoint)
                    return null;

                return new Rectangle(ePatternState.Fresh, new List<Point>() { p1.Clone() as Point, p2.Clone() as Point, p3.Clone() as Point, p4.Clone() as Point }, settings);
            }
            #endregion

            #region Update Pattern
            public override void UpdatePatternAndLines(DateTime time, double close, double close1, double High, double Low, int bar, double PatternBreakMultiple, double PatternBreakPercent)
            {
                base.UpdatePatternAndLines(time, close, close1, High, Low, bar, PatternBreakMultiple, PatternBreakPercent);

                if (_eStatePatternDefined >= ePatternState.Filled)
                    return;

                Point p1 = _lPoints[3];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[1];
                Point p4 = _lPoints[0];

                double upLimitPrice = Math.Max(p1.Price, Math.Max(p2.Price, Math.Max(p3.Price, p4.Price)));
                double downLimitPrice = Math.Min(p1.Price, Math.Min(p2.Price, Math.Min(p3.Price, p4.Price)));

                if (close > upLimitPrice + PatternBreakMultiple && close1 <= upLimitPrice + PatternBreakMultiple)
                {
                    _iDirection = 1;
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bull);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bull, Math.Abs(close - downLimitPrice));
                }
                else if (close < downLimitPrice - PatternBreakMultiple && close1 >= downLimitPrice - PatternBreakMultiple)
                {
                    _iDirection = -1;
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bear);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bear, Math.Abs(close - upLimitPrice));
                }
            }
            #endregion

            #region Drawing Pattern
            public override void drawPattern(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime currentTime, int currentBar, GeneralSettings generalSettings)
            {
                PatternSettings settings = generalSettings.GetSettingsFor(ePatterns.Rectangle);

                if (settings == null || !settings.Show)
                    return;

                Point p0 = _lPoints[0];
                Point p1 = _lPoints[1];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[3];

                float y0 = chartScale.GetYByValue(p0.Price);
                float y1 = chartScale.GetYByValue(p1.Price);
                float y2 = chartScale.GetYByValue(p2.Price);
                float y3 = chartScale.GetYByValue(p3.Price);
                float x3 = chartControl.GetXByTime(p3.Time);
                float x4 = chartControl.GetXByTime(_dtEndTime != DateTime.MaxValue ? _dtEndTime : currentTime);

                //Adding Point A to List
                Tuple<float, float> A = new Tuple<float, float>(x3, Math.Min(y0, Math.Min(y1, Math.Min(y2, y3))));
                //Adding Point B to List
                Tuple<float, float> B = new Tuple<float, float>(x4, Math.Max(y0, Math.Max(y1, Math.Max(y2, y3))));

                Stroke stroke = AdjustStrokeToPattern(_PatternSettings.GetStrokedByDirection(_iDirection));

                DrawSharpDX.Box(RenderTarget, stroke, A, B, generalSettings.Transparency, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale));
                if (generalSettings.ShowPatternName)
                {
                    string Name = _PatternSettings.Name + (_eStateUserDefined == ePatternState.Invalidated ? "\r\nINV" : "");
                    DrawSharpDX.BoxText(RenderTarget, chartControl, chartScale, Name, A.Item1 - 5, A.Item2, _PatternSettings.GetStrokedByDirection(_iDirection), generalSettings.Transparency,
                       generalSettings.TextBrush, generalSettings.FontFamily, false, true, null, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center,
                       SharpDX.DirectWrite.ParagraphAlignment.Far, SharpDX.DirectWrite.TextAlignment.Trailing);
                }
                if (generalSettings.TradePlan == "User Defined")
                    _UserDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
                else if (generalSettings.TradePlan == "Pattern Defined")
                    _PatternDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
            }

            #endregion
        }
        #endregion

        #region Flag Pattern Class
        public class Flag : PatternBase
        {
            #region Constructor
            public Flag(ePatternState PS, int direction, List<Point> points, PatternSettings settings)
                : base(PS, points, settings)
            {
                _iDirection = direction;
            }
            #endregion

            #region Find Pattern
            public static Flag FindPattern(List<Point> p, PatternSettings settings)
            {
                if (p.Count < 5)
                    return null;

                int index = p.Count - 1;
                Point p1 = p[index];
                Point p2 = p[index - 1];
                Point p3 = p[index - 2];
                Point p4 = p[index - 3];

                bool checkPoint = (p1.Price > p2.Price) ? (p1.Price > p3.Price/* + deviation */&& p2.Price > p4.Price/* + deviation*/)
                                    : (p1.Price < p3.Price/* - deviation*/ && p2.Price < p4.Price/* - deviation*/);

                if (!checkPoint)
                    return null;

                double slopeUpLine = (p1.Price > p2.Price) ? Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price) : Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price); //nu cred ca ne mai trebuie, deci nu cred ca mai trebuie sa o calculam
                double slopeDownLine = (p1.Price > p2.Price) ? Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price) : Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);

                double maxAggresiveSlope = Math.Max(Math.Abs(slopeUpLine), Math.Abs(slopeDownLine));
                double minAggresiveSlope = Math.Min(Math.Abs(slopeUpLine), Math.Abs(slopeDownLine));

                if (minAggresiveSlope / maxAggresiveSlope < settings.SlopeDev / 100)
                    return null;

                double angle = Calc.AngleDeg(slopeDownLine);

                if (Calc.AngleAbsCompare(settings.MinAngle, settings.MaxAngle, angle))
                    return null;

                int dir = p1.Price > p3.Price ? -1 : 1;
                return new Flag(ePatternState.Fresh, dir, new List<Point>() { p1.Clone() as Point, p2.Clone() as Point, p3.Clone() as Point, p4.Clone() as Point }, settings);
            }
            #endregion

            #region Update Pattern
            public override void UpdatePatternAndLines(DateTime time, double close, double close1, double High, double Low, int bar, double PatternBreakMultiple, double PatternBreakPercent)
            {
                base.UpdatePatternAndLines(time, close, close1, High, Low, bar, PatternBreakMultiple, PatternBreakPercent);

                if (_eStatePatternDefined >= ePatternState.Filled)
                    return;

                Point p1 = _lPoints[3];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[1];
                Point p4 = _lPoints[0];

                double m1 = Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);
                double m2 = Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);

                Tuple<int, double> A = new Tuple<int, double>(bar, Calc.NextPoint(p1.Bar, p1.Price, m1, bar));
                Tuple<int, double> C = new Tuple<int, double>(bar, Calc.NextPoint(p2.Bar, p2.Price, m2, bar));

                double upLimitPrice = Calc.NextPoint(p1.Bar, p1.Price, m1, bar);
                double downLimitPrice = Calc.NextPoint(p2.Bar, p2.Price, m2, bar);

                if(_iDirection != -1)
                {
                    if (close > (p1.Price > p2.Price ? upLimitPrice : downLimitPrice) + PatternBreakMultiple)
                    {
                        _iDirection = 1;
                        _eStatePatternDefined = ePatternState.Filled;
                        _eStateUserDefined = ePatternState.Filled;
                        _dtEndTime = time;
                        _UserDefined.StartTrade(close, time, bar, ePatternType.Bull);
                        _PatternDefined.StartTrade(close, time, bar, ePatternType.Bull, Math.Abs(p4.Price - Calc.NextPoint(p1.Bar, p1.Price, m1, p4.Bar)));
                    }
                    else if (close < (p1.Price < p2.Price ? upLimitPrice : downLimitPrice) - PatternBreakMultiple)
                    {
                        _eStatePatternDefined = ePatternState.Completed;
                        _eStateUserDefined = ePatternState.Completed;
                        _dtEndTime = time;
                    }
                }
                else if (_iDirection != 1)
                {
                    if (close < (p1.Price > p2.Price ? downLimitPrice : upLimitPrice) - PatternBreakMultiple)
                    {
                        _iDirection = -1;
                        _eStatePatternDefined = ePatternState.Filled;
                        _eStateUserDefined = ePatternState.Filled;
                        _dtEndTime = time;
                        _UserDefined.StartTrade(close, time, bar, ePatternType.Bear);
                        _PatternDefined.StartTrade(close, time, bar, ePatternType.Bear, Math.Abs(p4.Price - Calc.NextPoint(p1.Bar, p1.Price, m1, p4.Bar)));
                    }
                    else if (close > (p1.Price < p2.Price ? downLimitPrice : upLimitPrice) + PatternBreakMultiple)
                    {
                        _eStatePatternDefined = ePatternState.Completed;
                        _eStateUserDefined = ePatternState.Completed;
                        _dtEndTime = time;
                    }

                }
            }
            #endregion

            #region Drawing Pattern
            public override void drawPattern(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime currentTime, int currentBar, GeneralSettings generalSettings)
            {
                PatternSettings settings = generalSettings.GetSettingsFor(ePatterns.Flag);

                if (settings == null || !settings.Show)
                    return;

                List<Tuple<float, float>> patternPoints = new List<Tuple<float, float>>();

                Point p0 = _lPoints[0];
                Point p1 = _lPoints[1];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[3];

                float x0 = chartControl.GetXByTime(p0.Time); float y0 = chartScale.GetYByValue(p0.Price);
                float x1 = chartControl.GetXByTime(p1.Time); float y1 = chartScale.GetYByValue(p1.Price);
                float x2 = chartControl.GetXByTime(p2.Time); float y2 = chartScale.GetYByValue(p2.Price);
                float x3 = chartControl.GetXByTime(p3.Time); float y3 = chartScale.GetYByValue(p3.Price);
                float x4 = chartControl.GetXByTime(_dtEndTime != DateTime.MaxValue ? _dtEndTime : currentTime);

                float m1 = Calc.Slope(x0, x2, y0, y2);
                float m2 = Calc.Slope(x1, x3, y1, y3);

                //Adding Point A to List
                Tuple<float, float> A = new Tuple<float, float>(x3, y3);
                //Adding Point D to List
                Tuple<float, float> C = new Tuple<float, float>(x4, Calc.NextPoint(x0, y0, m1, x4));
                //Adding Point B to List
                Tuple<float, float> B = new Tuple<float, float>(x3, Calc.NextPoint(x2, y2, m1, x3));
                //Adding Point C to List
                Tuple<float, float> D = new Tuple<float, float>(x4, Calc.NextPoint(x1, y1, m2, x4));

                patternPoints.Add(A);
                patternPoints.Add(B);
                patternPoints.Add(C);
                patternPoints.Add(D);

                Stroke stroke = AdjustStrokeToPattern(_PatternSettings.GetStrokedByDirection(_iDirection));

                DrawSharpDX.GeometryWithFill(RenderTarget, patternPoints, stroke, generalSettings.Transparency, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale));
                if (generalSettings.ShowPatternName)
                {
                    float topLeftPoint = Math.Min(A.Item2, B.Item2);
                    string Name = _PatternSettings.Name + (_eStateUserDefined == ePatternState.Invalidated ? "\r\nINV" : "");
                    DrawSharpDX.BoxText(RenderTarget, chartControl, chartScale, Name, A.Item1 - 5, topLeftPoint, _PatternSettings.GetStrokedByDirection(_iDirection), generalSettings.Transparency,
                       generalSettings.TextBrush, generalSettings.FontFamily, false, true, null, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center,
                       SharpDX.DirectWrite.ParagraphAlignment.Far, SharpDX.DirectWrite.TextAlignment.Trailing);
                }
                if (generalSettings.TradePlan == "User Defined")
                    _UserDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
                else if (generalSettings.TradePlan == "Pattern Defined")
                    _PatternDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
            }
            #endregion
        }
        #endregion

        #region ABCD Flag Pattern Class
        public class ABCD : PatternBase
        {
            #region Constructor
            public ABCD(ePatternState PS, int dir, List<Point> points, PatternSettings settings)
                : base(PS, points, settings)
            {
                _iDirection = dir;
            }
            #endregion

            #region Find Pattern
            public static ABCD FindPattern(List<Point> p, PatternSettings settings)
            {
                if (p.Count < 5)
                    return null;

                int index = p.Count - 1;
                Point p1 = p[index];
                Point p2 = p[index - 1];
                Point p3 = p[index - 2];
                Point p4 = p[index - 3];

                double abRange = Math.Abs(p3.Price - p4.Price);
                double ValUP = p3.Price > p4.Price ? p3.Price - abRange * Math.Min(settings.Retracement1Max, settings.Retracement1Min) / 100 : p3.Price + abRange * Math.Min(settings.Retracement1Max, settings.Retracement1Min) / 100;
                double ValDOWN = p3.Price > p4.Price ? p3.Price - abRange * Math.Max(settings.Retracement1Max, settings.Retracement1Min) / 100 : p3.Price + abRange * Math.Max(settings.Retracement1Max, settings.Retracement1Min) / 100;

                bool checkPoint = p3.Price > p4.Price ? (p2.Price >= ValDOWN && p2.Price <= ValUP) : (p2.Price <= ValDOWN && p2.Price >= ValUP);

                if (!checkPoint)
                    return null;

                double ValExtUP = p3.Price > p4.Price ? p2.Price + abRange * Math.Min(settings.Retracement2Min, settings.Retracement2Max) / 100 : p2.Price - abRange * Math.Min(settings.Retracement2Min, settings.Retracement2Max) / 100;
                double ValExtDown = p3.Price > p4.Price ? p2.Price + abRange * Math.Max(settings.Retracement2Min, settings.Retracement2Max) / 100 : p2.Price - abRange * Math.Max(settings.Retracement2Min, settings.Retracement2Max) / 100;

                bool checkExt = p3.Price < p4.Price ? (p1.Price >= ValExtDown && p1.Price <= ValExtUP) : (p1.Price <= ValExtDown && p1.Price >= ValExtUP);

                if (!checkExt)
                    return null;

                int dir = p3.Price < p4.Price ? 1 : -1;

                if (dir > 0 ? p3.Price < p[index - 4].Price : p3.Price > p[index - 4].Price)
                    return null;

                return new ABCD(ePatternState.Fresh, dir, new List<Point>() { p1.Clone() as Point, p2.Clone() as Point, p3.Clone() as Point, p4.Clone() as Point }, settings);
            }
            #endregion

            #region Update Pattern
            public override void UpdatePatternAndLines(DateTime time, double close, double close1, double High, double Low, int bar, double PatternBreakMultiple, double PatternBreakPercent)
            {
                base.UpdatePatternAndLines(time, close, close1, High, Low, bar, PatternBreakMultiple, PatternBreakPercent);

                if (_eStatePatternDefined >= ePatternState.Filled)
                    return;

                Point p1 = _lPoints[3];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[1];
                Point p4 = _lPoints[0];

                double m1 = Calc.Slope(p1.Bar, p3.Bar, p1.Price, p3.Price);
                double m2 = Calc.Slope(p2.Bar, p4.Bar, p2.Price, p4.Price);

                int _iLeftPoint = Math.Min(p1.Bar, p2.Bar);

                Tuple<int, double> A = new Tuple<int, double>(_iLeftPoint, Calc.NextPoint(p1.Bar, p1.Price, m1, _iLeftPoint));
                Tuple<int, double> C = new Tuple<int, double>(_iLeftPoint, Calc.NextPoint(p2.Bar, p2.Price, m2, _iLeftPoint));
                Tuple<int, double> B = Calc.ThirdPoint(A, C, m1, m2);

                if (Calc.PatternBroken(A, B, C, bar, _iDirection == 1, High, _iDirection == -1, Low))
                {
                    _eStatePatternDefined = ePatternState.Invalidated;
                    _eStateUserDefined = ePatternState.Invalidated;
                    _dtEndTime = time;
                }

                double upLimitPrice = Calc.NextPoint(p1.Bar, p1.Price, m1, bar);
                double downLimitPrice = Calc.NextPoint(p2.Bar, p2.Price, m2, bar);
                double priceTop = (p1.Price > p2.Price ? upLimitPrice : downLimitPrice) + PatternBreakMultiple;
                double priceBottom = (p1.Price > p2.Price ? downLimitPrice : upLimitPrice) - PatternBreakMultiple;

                if (_iDirection == 1 && close > priceTop)
                {
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bull);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bull, Math.Abs(close - priceBottom));
                }
                else if (_iDirection == -1 && close < priceBottom)
                {
                    _eStatePatternDefined = ePatternState.Filled;
                    _eStateUserDefined = ePatternState.Filled;
                    _dtEndTime = time;
                    _UserDefined.StartTrade(close, time, bar, ePatternType.Bear);
                    _PatternDefined.StartTrade(close, time, bar, ePatternType.Bear, Math.Abs(priceTop - close));
                }
            }
            #endregion

            #region Drawing Pattern
            public override void drawPattern(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime currentTime, int currentBar, GeneralSettings generalSettings)
            {
                PatternSettings settings = generalSettings.GetSettingsFor(ePatterns.ABCD);

                if (settings == null || !settings.Show)
                    return;

                List<Tuple<float, float>> patternPoints = new List<Tuple<float, float>>();

                Point p0 = _lPoints[0];
                Point p1 = _lPoints[1];
                Point p2 = _lPoints[2];
                Point p3 = _lPoints[3];

                float x0 = chartControl.GetXByTime(p0.Time); float y0 = chartScale.GetYByValue(p0.Price);
                float x1 = chartControl.GetXByTime(p1.Time); float y1 = chartScale.GetYByValue(p1.Price);
                float x2 = chartControl.GetXByTime(p2.Time); float y2 = chartScale.GetYByValue(p2.Price);
                float x3 = chartControl.GetXByTime(p3.Time); float y3 = chartScale.GetYByValue(p3.Price);
                float xr = chartControl.GetXByTime(_dtEndTime);

                float m1 = Calc.Slope(x0, x2, y0, y2);
                float m2 = Calc.Slope(x1, x3, y1, y3);

                //Adding Point A to List
                Tuple<float, float> A = new Tuple<float, float>(x3, y3);
                //Adding Point C to List
                Tuple<float, float> B = new Tuple<float, float>(x3, Calc.NextPoint(x2, y2, m1, x3));

                Tuple<float, float> D = new Tuple<float, float>(xr, Calc.IntersectionYPoint(A.Item1, A.Item2, xr, m2));

                Tuple<float, float> C = new Tuple<float, float>(xr, Calc.IntersectionYPoint(B.Item1, B.Item2, xr, m1));

                patternPoints.Add(A);
                patternPoints.Add(B);
                patternPoints.Add(C);
                patternPoints.Add(D);

                Stroke stroke = AdjustStrokeToPattern(_PatternSettings.GetStrokedByDirection(_iDirection));

                DrawSharpDX.GeometryWithFill(RenderTarget, patternPoints, stroke, generalSettings.Transparency, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale));

                if (generalSettings.ShowPatternName)
                {
                    string Name = _PatternSettings.Name + (_eStateUserDefined == ePatternState.Invalidated ? "\r\nINV" : "");
                    DrawSharpDX.BoxText(RenderTarget, chartControl, chartScale, Name, A.Item1 - 5, A.Item2, _PatternSettings.GetStrokedByDirection(_iDirection), generalSettings.Transparency,
                        generalSettings.TextBrush, generalSettings.FontFamily, false, true, null, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center,
                        SharpDX.DirectWrite.ParagraphAlignment.Far, SharpDX.DirectWrite.TextAlignment.Trailing);
                }
                if (generalSettings.TradePlan == "User Defined")
                    _UserDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
                else if (generalSettings.TradePlan == "Pattern Defined")
                    _PatternDefined.Draw(RenderTarget, chartControl, chartScale, currentTime, currentBar, generalSettings.FontFamily, generalSettings.TradePlanTextBrush);
            }
            #endregion
        }
        #endregion

        #endregion

        #region Entry, Stops & Targets

        #region Entry, Stops and Targets
        public class EntryStopsTargets
        {
            #region Floating Variables
            private bool _bFoundEndTime = false;
            private ePatternType _eDirection = ePatternType.Neutral;
            private Dictionary<eESTLineType, ESTLine> _dicLines = new Dictionary<eESTLineType, ESTLine>();
            private EntryStopsTargetsSettings _estSettings = null;
            #endregion

            #region Constructor
            public EntryStopsTargets(EntryStopsTargetsSettings Settings)
            {
                _estSettings = Settings.Clone() as EntryStopsTargetsSettings;
            }
            #endregion

            #region Public Functions
            public void StartTrade(double EntryPrice, DateTime EntryTime, int EntryBar, ePatternType Direction, double StopDistance = 0)
            {
                if (Direction == ePatternType.Neutral || EntryTime == DateTime.MinValue || EntryTime == DateTime.MaxValue || EntryPrice == 0)
                    return;
                _eDirection = Direction;
                _dicLines.Add(eESTLineType.Entry, new ESTLine() { Price = EntryPrice, EntryTime = EntryTime, EntryBar = EntryBar, EndTime = DateTime.MaxValue, Text = "Entry" });
                if (StopDistance != 0)
                    StopDistance += _estSettings.StopMultiple;
                if (_estSettings.StopMultiple != 0 || StopDistance != 0)
                {
                    double diff = StopDistance == 0 ? _estSettings.StopMultiple : StopDistance;
                    _dicLines.Add(eESTLineType.Stop, new ESTLine() { Price = EntryPrice + (_eDirection == ePatternType.Bull ? -1 : 1) * diff, EntryTime = EntryTime, EntryBar = EntryBar, EndTime = DateTime.MaxValue, Text = "Stop" });
                }
                if (_estSettings.Target1Multiple != 0)
                {
                    double diff = StopDistance == 0 ? _estSettings.Target1Multiple : _estSettings.Target1Multiple * StopDistance;
                    _dicLines.Add(eESTLineType.Target1, new ESTLine() { Price = EntryPrice + (_eDirection == ePatternType.Bull ? 1 : -1) * diff, EntryTime = EntryTime, EntryBar = EntryBar, EndTime = DateTime.MaxValue, Text = "Target 1" });
                }
                if (_estSettings.Target2Multiple != 0)
                {
                    double diff = StopDistance == 0 ? _estSettings.Target2Multiple : _estSettings.Target2Multiple * StopDistance;
                    _dicLines.Add(eESTLineType.Target2, new ESTLine() { Price = EntryPrice + (_eDirection == ePatternType.Bull ? 1 : -1) * diff, EntryTime = EntryTime, EntryBar = EntryBar, EndTime = DateTime.MaxValue, Text = "Target 2" });
                }
            }

            public void CheckEndBar(DateTime CurrentTime, int CurrentBar)
            {
                if (!_bFoundEndTime)
                    foreach (ESTLine line in _dicLines.Values)
                    {
                        line.CheckEndBar(CurrentTime, CurrentBar, _estSettings.LineLength);
                        if (line.EndTime != DateTime.MaxValue)
                            _bFoundEndTime = true;
                    }
            }

            public bool CheckStopTarget(double High, double Low)
            {
                bool dir = _eDirection == ePatternType.Bull;
                if (_dicLines.ContainsKey(eESTLineType.Stop) && _dicLines[eESTLineType.Stop].UpdateLine(!dir ? High : Low, !dir))
                    return true;
                if (_dicLines.ContainsKey(eESTLineType.Target1) && _dicLines[eESTLineType.Target1].UpdateLine(dir ? High : Low, dir))
                    return true;
                if (_dicLines.ContainsKey(eESTLineType.Target2) && _dicLines[eESTLineType.Target2].UpdateLine(dir ? High : Low, dir))
                    return true;
                return false;
            }

            public void Draw(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime CurrentTime, int CurrentBar, SimpleFont Font, Brush TextBrush)
            {
                List<eESTLineType> keys = _dicLines.Keys.ToList();
                for (int i = 0; i < keys.Count(); i++)
                    _dicLines[keys[i]].Draw(RenderTarget, chartControl, chartScale, _estSettings.GetStroke(keys[i]), TextBrush, _estSettings.LineLength, CurrentTime, CurrentBar, Font);
            }
            #endregion
        }
        #endregion

        #region EST Line
        private class ESTLine
        {
            #region Properties
            public double Price { get; set; }
            public DateTime EntryTime { get; set; }
            public int EntryBar { get; set; }
            public DateTime EndTime { get; set; }
            public int EndBar { get; set; }
            public string Text { get; set; }
            #endregion

            #region Public Properties
            public void Draw(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke LineStroke, Brush LabelColor, int LineLength, DateTime CurrentTime, int CurrentBar, SimpleFont Font)
            {
                DateTime endTime = chartControl.GetTimeBySlotIndex(EntryBar + LineLength);
                DrawSharpDX.Line(RenderTarget, chartControl, chartScale, EntryTime, Price, endTime == DateTime.MaxValue ? CurrentTime : endTime, Price, LineStroke);
                DrawSharpDX.Text(RenderTarget, chartControl, chartScale, Text, endTime == DateTime.MaxValue ? CurrentTime : endTime, Price, LabelColor, Font, SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment.Center);

            }

            public void CheckEndBar(DateTime CurrentTime, int CurrentBar, int LineLength)
            {
                if (EndTime == DateTime.MaxValue && CurrentBar - EntryBar > LineLength)
                    EndTime = CurrentTime;
            }

            public bool UpdateLine(double Value, bool Direction)
            {
                if (Price == double.MinValue || Price == double.MaxValue)
                    return false;
                return Direction ? Value > Price : Value < Price;
            }
            #endregion
        }
        #endregion

        #endregion

        #region Settings

        #region Pattern Settings
        public class PatternSettings
        {
            public bool Show { get; set; }
            public string Name { get; set; }
            public Stroke BullPatternColors { get; set; }
            public Stroke BearPatternColors { get; set; }
            public Stroke NeutralPatternColors { get; set; }
            public double MinAngle { get; set; }
            public double MaxAngle { get; set; }
            public double SlopeDev { get; set; }
            public double Retracement1Max { get; set; }
            public double Retracement1Min { get; set; }
            public double Retracement2Min { get; set; }
            public double Retracement2Max { get; set; }
            public int MaxBars { get; set; }
            public EntryStopsTargetsSettings UserDefined { get; set; }
            public EntryStopsTargetsSettings PatternDefined { get; set; }

            public Stroke GetStrokedByDirection(int direction)
            {
                if (direction > 0)
                    return BullPatternColors;
                else if (direction < 0)
                    return BearPatternColors;
                return NeutralPatternColors;
            }
        }
        #endregion

        #region General Settings
        public class GeneralSettings
        {
            #region Floating Variable
            private Dictionary<ePatterns, PatternSettings> _dicAllSettings = new Dictionary<ePatterns, PatternSettings>();
            #endregion

            #region Properties
            public Indicator Indicator { get; set; }
            public double SmallDeviation { get; set; }
            public double MediumDeviation { get; set; }
            public double LargeDeviation { get; set; }
            public int Transparency { get; set; }
            public bool ShowLong { get; set; }
            public bool ShowShort { get; set; }
            public bool ShowNeutral { get; set; }
            public bool ShowLarge { get; set; }
            public bool ShowMedium { get; set; }
            public bool ShowSmall { get; set; }
            public bool ShowFresh { get; set; }
            public bool ShowFilled { get; set; }
            public bool ShowCompleted { get; set; }
            public bool ShowInvalidated { get; set; }
            public bool ShowPatternName { get; set; }
            public bool UseSound { get; set; }
            public string SoundAlert { get; set; }
            public SimpleFont FontFamily { get; set; }
            public Brush TextBrush { get; set; }
            public Brush TradePlanTextBrush { get; set; }
            public string TradePlan { get; set; }
            public double PatternBreakPercent { get; set; }
            #endregion

            #region Public Functions
            public void AddPattern(ePatterns pattern, PatternSettings patternSettings)
            {
                if (_dicAllSettings.ContainsKey(pattern))
                    _dicAllSettings[pattern] = patternSettings;
                else
                    _dicAllSettings.Add(pattern, patternSettings);
            }

            public PatternSettings GetSettingsFor(ePatterns pattern)
            {
                if (_dicAllSettings.ContainsKey(pattern))
                    return _dicAllSettings[pattern];
                return null;
            }

            public void SetPatternSettingsVisualOnOff(ePatterns pattern, bool show)
            {
                if (_dicAllSettings.ContainsKey(pattern))
                    _dicAllSettings[pattern].Show = show;
            }

            public void SetPatternSettingsVisualOnOffInverse(ePatterns pattern)
            {
                if (_dicAllSettings.ContainsKey(pattern))
                    _dicAllSettings[pattern].Show = !_dicAllSettings[pattern].Show;
            }

            public double GetDeviationForPatternBreaks(eDepthType Depth)
            {
                switch (Depth)
                {
                    case eDepthType.Large: return LargeDeviation;
                    case eDepthType.Small: return SmallDeviation;
                    default: return MediumDeviation;
                }
            }

            public bool ShowThisDepth(eDepthType Depth)
            {
                switch (Depth)
                {
                    case eDepthType.Large: return ShowLarge;
                    case eDepthType.Small: return ShowSmall;
                    default: return ShowMedium;
                }
            }

            public bool ShowThisPatternType(ePatternType PatternType)
            {
                switch (PatternType)
                {
                    case ePatternType.Bull: return ShowLong;
                    case ePatternType.Bear: return ShowShort;
                    default: return ShowNeutral;
                }
            }

            public bool ShowThisPatternState(ePatternState PatternStateUser, ePatternState PatternStatePattern)
            {
                if(TradePlan == "User Defined")
                {
                    switch (PatternStateUser)
                    {
                        case ePatternState.Filled: return ShowFilled;
                        case ePatternState.Completed: return ShowCompleted;
                        case ePatternState.Invalidated: return ShowInvalidated;
                        default: return ShowFresh;
                    }
                }
                switch (PatternStatePattern)
                {
                    case ePatternState.Filled: return ShowFilled;
                    case ePatternState.Completed: return ShowCompleted;
                    case ePatternState.Invalidated: return ShowInvalidated;
                    default: return ShowFresh;
                }
            }

            public void PlaySound()
            {
                if (!UseSound || Indicator == null)
                    return;
                Indicator.PlaySound(SoundAlert);
            }
            #endregion
        }
        #endregion

        #region Entry Stop Target Settings
        public class EntryStopsTargetsSettings : ICloneable
        {
            #region Properties
            public Stroke EntryStroke { get; set; }
            public Stroke StopStroke { get; set; }
            public Stroke TargetStroke { get; set; }
            public int LineLength { get; set; }
            public double StopMultiple { get; set; }
            public double Target1Multiple { get; set; }
            public double Target2Multiple { get; set; }
            #endregion

            #region Public Functions
            public void NewStopsTargetsSettings(double Stop, double Target1, double Target2)
            {
                StopMultiple = Stop;
                Target1Multiple = Target1;
                Target2Multiple = Target2;
            }

            public Stroke GetStroke(eESTLineType type)
            {
                switch (type)
                {
                    case eESTLineType.Stop: return StopStroke;
                    case eESTLineType.Target1:
                    case eESTLineType.Target2: return TargetStroke;
                    default: return EntryStroke;
                }
            }
            #endregion

            #region Clone
            public object Clone()
            {
                return new EntryStopsTargetsSettings()
                {
                    EntryStroke = EntryStroke.Clone() as Stroke,
                    StopStroke = StopStroke.Clone() as Stroke,
                    TargetStroke = TargetStroke.Clone() as Stroke,
                    LineLength = LineLength,
                    StopMultiple = StopMultiple,
                    Target1Multiple = Target1Multiple,
                    Target2Multiple = Target2Multiple
                };
            }
            #endregion
        }
        #endregion

        #endregion

        #region Enums

        public enum ePatternState
        {
            Fresh, //just drawn
            Filled, //broken in one side - entry confirmed
            Completed, //SL or TGT hit
            Invalidated
        }
        public enum eDepthType
        {
            Small,
            Medium,
            Large
        }
        public enum ePatternType
        {
            Bull,
            Bear,
            Neutral
        }
        public enum ePatterns
        {
            ABC,
            ABCD,
            Wedge,
            AscendingTriangle,
            DescendingTriangle,
            SymmetricTriangle,
            ExpandingTriangle,
            Rectangle,
            Flag
        }
        public enum eESTLineType
        {
            Entry,
            Stop,
            Target1,
            Target2
        }

        #endregion

        #endregion

        #region Default NT Functions

        #region On Render
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
#if DoLicense
			if (!ValidLicense) return;
#endif
            base.OnRender(chartControl, chartScale);
            for (int i = 0; i < _lDepths.Count; i++)
            {
                Depth depth = _lDepths[i];
                if (!_GeneralSettings.ShowThisDepth(depth.DepthType))
                    continue;
                //depth.DrawZigZag(RenderTarget, chartControl, chartScale);
                for (int j = 0; j < depth.Patterns.Count; j++)
                {
                    PatternBase pattern = depth.Patterns[j];
                    if (!_GeneralSettings.ShowThisPatternType(pattern.PatternType) || !_GeneralSettings.ShowThisPatternState(pattern.PatternStateUser, pattern.PatternStatePattern))
                        continue;
                    pattern.drawPattern(RenderTarget, chartControl, chartScale, Bars.GetTime(CurrentBar), CurrentBar, _GeneralSettings);
                }
            }
        }
        #endregion

        #endregion

        #region Functions

        #region Inform User About Recalculation
        private void InformUserAboutRecalculation()
        {
            {
				string name = string.Format("btTradePlan_Recalculate_General{0}",uID);
                _dicMenuItems[name].Background = Brushes.Yellow;
                _dicMenuItems[name].FontWeight = FontWeights.Bold;
                _dicMenuItems[name].FontStyle  = FontStyles.Italic;
            }
        }
        #endregion

        #region Invoke Action
        private void CCInvokeAction(Action p)
        {
            if (ChartControl.Dispatcher.CheckAccess())
            {
                p();
            }
            else
            {
                ChartControl.Dispatcher.InvokeAsync(p);
            }
        }
        #endregion

        #region Invoke Action
        private void GeneralInvokeAction(Action p)
        {
            if (Dispatcher.CheckAccess())
            {
                p();
            }
            else
            {
                Dispatcher.InvokeAsync(p);
            }
        }
        #endregion

        #endregion

        #region Properties

        #region Override Display Name
        public override string DisplayName { get { return _sThisName; } }
        #endregion

        #region TPtype - Trade Plan (Values) Type
        internal class TPtype : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "None", "User Defined", "Pattern Defined" });
            }
        }
        #endregion

        #region ENTtype - Entry Type
        internal class ENTtype : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Close Of Bar", "On Tick Cross" });
            }
        }
        #endregion

        #endregion

        #endregion

        #region Properties

        #region Indicator Settings

        //large
        [NinjaScriptProperty]
        [Display(Name = "Show Large", Description = "", Order = 10, GroupName = "General Settings")]
        public bool ShowLarge { get; set; }

        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Large Swing Strength", Description = "", Order = 11, GroupName = "General Settings")]
        public int largeSwingStrength { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Large Swing Sensitivity", Description = "", Order = 12, GroupName = "General Settings")]
        public double largeSensitivity { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Large Pattern Break ATR Multiple", Description = "Description", Order = 13, GroupName = "General Settings")]
        public double LargeBreakMultiple { get; set; }

        //medium
        [NinjaScriptProperty]
        [Display(Name = "Show Medium", Description = "", Order = 20, GroupName = "General Settings")]
        public bool ShowMedium { get; set; }

        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Medium Swing Strength", Description = "", Order = 21, GroupName = "General Settings")]
        public int mediumSwingStrength { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Medium Swing Sensitivity", Description = "", Order = 22, GroupName = "General Settings")]
        public double mediumSensitivity { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Medium Pattern Break ATR Multiple", Description = "Description", Order = 23, GroupName = "General Settings")]
        public double MediumBreakMultiple { get; set; }

        //small
        [NinjaScriptProperty]
        [Display(Name = "Show Small", Description = "", Order = 30, GroupName = "General Settings")]
        public bool ShowSmall { get; set; }

        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Small Swing Strength", Description = "", Order = 31, GroupName = "General Settings")]
        public int smallSwingStrength { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Small Swing Sensitivity", Description = "", Order = 32, GroupName = "General Settings")]
        public double smallSensitivity { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Small Pattern Break ATR Multiple", Description = "Description", Order = 33, GroupName = "General Settings")]
        public double SmallBreakMultiple { get; set; }


        //long, short, neutral
        [NinjaScriptProperty]
        [Display(Name = "Show Long", Description = "", Order = 35, GroupName = "General Settings")]
        public bool ShowLong { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Short", Description = "", Order = 36, GroupName = "General Settings")]
        public bool ShowShort { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Neutral", Description = "", Order = 37, GroupName = "General Settings")]
        public bool ShowNeutral { get; set; }


        //Potential, Confirmed, Historical
        [NinjaScriptProperty]
        [Display(Name = "Show Potential Pattern", Description = "", Order = 38, GroupName = "General Settings")]
        public bool ShowFresh { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Confirmed Pattern", Description = "", Order = 39, GroupName = "General Settings")]
        public bool ShowFilled  { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Historical Pattern", Description = "", Order = 40, GroupName = "General Settings")]
        public bool ShowCompleted { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Invalidated Pattern", Description = "", Order = 45, GroupName = "General Settings")]
        public bool ShowInvalidated { get; set; }

        //sound alert
        [NinjaScriptProperty]
        [Display(Name = "Use Sound", Description = "", Order = 49, GroupName = "General Settings")]
        public bool UseSound { get; set; }

        [PropertyEditor("NinjaTrader.Gui.Tools.FilePathPicker", Filter = "WAV Files (*.wav)|*.wav")]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Alert Sound File", Description = "Sound File Name", Order = 50, GroupName = "General Settings")]
        public string SoundAlert { get; set; } 

        //info box
        [Browsable(false)]
        [NinjaScriptProperty]
        [Display(Name = "Show Info Box", Description = "", Order = 60, GroupName = "General Settings")]
        public bool ShowInfoBox { get; set; }

        //button text
        [NinjaScriptProperty]
        [Display(Name = "Button Text", Description = "", Order = 70, GroupName = "General Settings")]
        public string ButtonText  { get; set; }

        //Fill Transparency
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Fill Transparency", Description = "", Order = 80, GroupName = "General Settings")]
        public int FillTransparency { get; set; }

        //show pattern name
        [NinjaScriptProperty]
        [Display(Name = "Show Pattern Name", Description = "", Order = 90, GroupName = "General Settings")]
        public bool ShowPattName { get; set; }

        //pattern name color
        [XmlIgnore]
        [Display(Name = "Pattern Name Text Color", Description = "", Order = 100, GroupName = "General Settings")]
        public Brush PatternNameColor { get; set; }
        [Browsable(false)]
        public string patternNameColor_ { get { return Serialize.BrushToString(PatternNameColor); } set { PatternNameColor = Serialize.StringToBrush(value); } }

        //pattern name font
        [NinjaScriptProperty]
        [Display(Name = "Pattern Name Text Font", Description = "Choose your font style for the pattern name text", Order = 110, GroupName = "General Settings")]
        public SimpleFont Font { get; set; }

        //Pattern Entry Rules
        [NinjaScriptProperty]
        [Display(Name = "Entry Type", Description = "", Order = 200, GroupName = "General Settings")]
        [TypeConverter(typeof(ENTtype))]
        public string EntryType { get; set; }

        #endregion

        #region Trade Plan

        [Range(0, 100), NinjaScriptProperty]
        [Display(Name = "Pattern Break Percent", Description = "", Order = 0, GroupName = "Trade Plan")]
        public double PatternBreakPercent { get; set; }

        //TPtype

        [NinjaScriptProperty]
        [Display(Name = "Trade Plan", Description = "", Order = 10, GroupName = "Trade Plan")]
        [TypeConverter(typeof(TPtype))]
        public string TradePlan { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Entry Line Color", Description = "", Order = 20, GroupName = "Trade Plan")]
        public Stroke EntryLineColor { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Stop Line Color", Description = "", Order = 30, GroupName = "Trade Plan")]
        public Stroke StopLineColor { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Target Line Color", Description = "", Order = 40, GroupName = "Trade Plan")]
        public Stroke TargetLineColor { get; set; }

        [XmlIgnore]
        [NinjaScriptProperty]
        [Display(Name = "Label Color", Description = "", Order = 50, GroupName = "Trade Plan")]
        public Brush LabelColor { get; set; }
        [Browsable(false)]
        public string labelColor_ { get { return Serialize.BrushToString(LabelColor); } set { LabelColor = Serialize.StringToBrush(value); } }

        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Line Length", Description = "", Order = 60, GroupName = "Trade Plan")]
        public int Linelength { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Stop Ticks", Description = "", Order = 70, GroupName = "Trade Plan")]
        public int StopTicks { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 1 Ticks", Description = "", Order = 80, GroupName = "Trade Plan")]
        public int Target1Ticks { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 2 Ticks", Description = "", Order = 90, GroupName = "Trade Plan")]
        public int Target2Ticks { get; set; }

        #endregion

        #region ABC

        [NinjaScriptProperty]
        [Display(Name = "Show ABC Pattern?", Description = "", Order = 10, GroupName = "ABC")]
        public bool ShowABC { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Fib 1 Value", Description = "", Order = 20, GroupName = "ABC")]
        public double Fib1 { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Fib 2 Value", Description = "", Order = 40, GroupName = "ABC")]
        public double Fib3 { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bullish Pattern Plot Settings", Description = "", Order = 50, GroupName = "ABC")]
        public Stroke ABCStrokeBull { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bearish Pattern Plot Settings", Description = "", Order = 60, GroupName = "ABC")]
        public Stroke ABCStrokeBear { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Stop Ticks", Description = "", Order = 70, GroupName = "ABC")]
        public double StopABC { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 1 R-Multiple", Description = "", Order = 80, GroupName = "ABC")]
        public double Target1ABC { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 2 R-Multiple", Description = "", Order = 90, GroupName = "ABC")]
        public double Target2ABC { get; set; }


        #endregion

        #region ABCD Flag

        [NinjaScriptProperty]
        [Display(Name = "Show ABCD Flag Pattern?", Description = "", Order = 10, GroupName = "ABCD Flag")]
        public bool ShowABCD { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Retracement Min Fib Value", Description = "", Order = 20, GroupName = "ABCD Flag")]
        public double Retracement1MinFibABCD { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Retracement Max Fib Value", Description = "", Order = 25, GroupName = "ABCD Flag")]
        public double Retracement1MaxFibABCD { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "2nd Retracement Min Fib Value", Description = "", Order = 30, GroupName = "ABCD Flag")]
        public double Retracement2MinFibABCD { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "2nd Retracement Max Fib Value", Description = "", Order = 35, GroupName = "ABCD Flag")]
        public double Retracement2MaxFibABCD { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bullish Pattern Plot Settings", Description = "", Order = 50, GroupName = "ABCD Flag")]
        public Stroke ABCDStrokeBull { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bearish Pattern Plot Settings", Description = "", Order = 60, GroupName = "ABCD Flag")]
        public Stroke ABCDStrokeBear { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Stop Ticks", Description = "", Order = 70, GroupName = "ABCD Flag")]
        public double StopABCD { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 1 R-Multiple", Description = "", Order = 80, GroupName = "ABCD Flag")]
        public double Target1ABCD { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 2 R-Multiple", Description = "", Order = 90, GroupName = "ABCD Flag")]
        public double Target2ABCD { get; set; }


        #endregion

        #region WEDGE

        [NinjaScriptProperty]
        [Display(Name = "Show Wedge Pattern?", Description = "", Order = 5, GroupName = "WEDGE")]
        public bool ShowWedge { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Min Angle", Description = "", Order = 10, GroupName = "WEDGE")]
        public double WedgeMinAngle { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Max Angle", Description = "", Order = 20, GroupName = "WEDGE")]
        public double WedgeMaxAngle { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Neutral Pattern Plot Settings", Description = "", Order = 30, GroupName = "WEDGE")]
        public Stroke WedgeNeutralStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bullish Pattern Plot Settings", Description = "", Order = 40, GroupName = "WEDGE")]
        public Stroke WedgeBullishStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bearish Pattern Plot Settings", Description = "", Order = 50, GroupName = "WEDGE")]
        public Stroke WedgeBearishStroke { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Stop Ticks", Description = "", Order = 70, GroupName = "WEDGE")]
        public double StopWedge { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 1 R-Multiple", Description = "", Order = 80, GroupName = "WEDGE")]
        public double Target1Wedge { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 2 R-Multiple", Description = "", Order = 90, GroupName = "WEDGE")]
        public double Target2Wedge { get; set; }

        #endregion

        #region ASCENDING/ DESCENDING TRIANGLE

        [NinjaScriptProperty]
        [Display(Name = "Show Ascending/ Descending Pattern?", Description = "", Order = 5, GroupName = "ASCENDING/ DESCENDING TRIANGLE")]
        public bool ShowAscDesc { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Min Angle", Description = "", Order = 10, GroupName = "ASCENDING/ DESCENDING TRIANGLE")]
        public double AscDescTriangMinAngle { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Max Angle", Description = "", Order = 20, GroupName = "ASCENDING/ DESCENDING TRIANGLE")]
        public double AscDescTriangMaxAngle { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bullish Pattern Plot Settings", Description = "", Order = 30, GroupName = "ASCENDING/ DESCENDING TRIANGLE")]
        public Stroke AscTriangStroke { get; set; }
        [NinjaScriptProperty]
        [Display(Name = "Bearish Pattern Plot Settings", Description = "", Order = 35, GroupName = "ASCENDING/ DESCENDING TRIANGLE")]
        public Stroke DescTriangStroke { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = " Straight Line Deviation (Ticks)", Description = "", Order = 40, GroupName = "ASCENDING/ DESCENDING TRIANGLE")]
        public int StraightLineDev { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Stop Ticks", Description = "", Order = 70, GroupName = "ASCENDING/ DESCENDING TRIANGLE")]
        public double StopAscDescTriang { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 1 R-Multiple", Description = "", Order = 80, GroupName = "ASCENDING/ DESCENDING TRIANGLE")]
        public double Target1AscDescTriang { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 2 R-Multiple", Description = "", Order = 90, GroupName = "ASCENDING/ DESCENDING TRIANGLE")]
        public double Target2AscDescTriang { get; set; }

        #endregion

        #region Symmetric TRIANGLE

        [NinjaScriptProperty]
        [Display(Name = "Show Symmetric Triangle Pattern?", Description = "", Order = 5, GroupName = "SYMMETRIC TRIANGLE")]
        public bool ShowSym { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Min Angle", Description = "", Order = 10, GroupName = "SYMMETRIC TRIANGLE")]
        public double SymTriangMinAngle { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Max Angle", Description = "", Order = 20, GroupName = "SYMMETRIC TRIANGLE")]
        public double SymTriangMaxAngle { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Neutral Pattern Plot Settings", Description = "", Order = 30, GroupName = "SYMMETRIC TRIANGLE")]
        public Stroke SymNeutralTriangStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bullish Pattern Plot Settings", Description = "", Order = 32, GroupName = "SYMMETRIC TRIANGLE")]
        public Stroke SymBullishTriangStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bearish Pattern Plot Settings", Description = "", Order = 34, GroupName = "SYMMETRIC TRIANGLE")]
        public Stroke SymBearishTriangStroke { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Slope Deviation (%)", Description = "", Order = 40, GroupName = "SYMMETRIC TRIANGLE")]
        public int DevSlope { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Stop Ticks", Description = "", Order = 70, GroupName = "SYMMETRIC TRIANGLE")]
        public double StopSymmTriang { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 1 R-Multiple", Description = "", Order = 80, GroupName = "SYMMETRIC TRIANGLE")]
        public double Target1SymmTriang { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 2 R-Multiple", Description = "", Order = 90, GroupName = "SYMMETRIC TRIANGLE")]
        public double Target2SymmTriang { get; set; }

        #endregion

        #region RECTANGLE

        [NinjaScriptProperty]
        [Display(Name = "Show Rectangle Pattern?", Description = "", Order = 5, GroupName = "RECTANGLE")]
        public bool ShowRect { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Deviation (Ticks)", Description = "", Order = 10, GroupName = "RECTANGLE")]
        public int Dev { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Neutral Pattern Plot Settings", Description = "", Order = 30, GroupName = "RECTANGLE")]
        public Stroke RectNeutralStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bullish Pattern Plot Settings", Description = "", Order = 32, GroupName = "RECTANGLE")]
        public Stroke RectBullishStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bearish Pattern Plot Settings", Description = "", Order = 34, GroupName = "RECTANGLE")]
        public Stroke RectBearishStroke { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Stop Ticks", Description = "", Order = 70, GroupName = "RECTANGLE")]
        public double StopRect { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 1 R-Multiple", Description = "", Order = 80, GroupName = "RECTANGLE")]
        public double Target1Rect { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 2 R-Multiple", Description = "", Order = 90, GroupName = "RECTANGLE")]
        public double Target2Rect { get; set; }

        #endregion

        #region EXPANDING TRIANGLE

        [NinjaScriptProperty]
        [Display(Name = "Show Expanding Triangle Pattern?", Description = "", Order = 5, GroupName = "EXPANDING TRIANGLE")]
        public bool ShowExp { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Min Angle", Description = "", Order = 10, GroupName = "EXPANDING TRIANGLE")]
        public double ExpTriangMinAngle { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Max Angle", Description = "", Order = 20, GroupName = "EXPANDING TRIANGLE")]
        public double ExpTriangMaxAngle { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Neutral Pattern Plot Settings", Description = "", Order = 30, GroupName = "EXPANDING TRIANGLE")]
        public Stroke ExpNeutralTriangStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bullish Pattern Plot Settings", Description = "", Order = 40, GroupName = "EXPANDING TRIANGLE")]
        public Stroke ExpBullishTriangStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bearish Pattern Plot Settings", Description = "", Order = 50, GroupName = "EXPANDING TRIANGLE")]
        public Stroke ExpBearishTriangStroke { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Max. Bars", Description = "", Order = 60, GroupName = "EXPANDING TRIANGLE")]
        public int MaxBars { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Stop Ticks", Description = "", Order = 70, GroupName = "EXPANDING TRIANGLE")]
        public double StopExpTriang { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 1 R-Multiple", Description = "", Order = 80, GroupName = "EXPANDING TRIANGLE")]
        public double Target1ExpTriang { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 2 R-Multiple", Description = "", Order = 90, GroupName = "EXPANDING TRIANGLE")]
        public double Target2ExpTriang { get; set; }

        #endregion

        #region FLAG

        [NinjaScriptProperty]
        [Display(Name = "Show Flag Pattern?", Description = "", Order = 5, GroupName = "FLAG")]
        public bool ShowFlag { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Min Angle", Description = "", Order = 10, GroupName = "FLAG")]
        public double FlagMinAngle { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Pattern Max Angle", Description = "", Order = 20, GroupName = "FLAG")]
        public double FlagMaxAngle { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bullish Pattern Plot Settings", Description = "", Order = 30, GroupName = "FLAG")]
        public Stroke FlagBullishStroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bearish Pattern Plot Settings", Description = "", Order = 32, GroupName = "FLAG")]
        public Stroke FlagBearishStroke { get; set; }


        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Lines Slope Deviation (%)", Description = "", Order = 40, GroupName = "FLAG")]
        public double SlopesDev { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Stop Ticks", Description = "", Order = 70, GroupName = "FLAG")]
        public double StopFlag { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 1 R-Multiple", Description = "", Order = 80, GroupName = "FLAG")]
        public double Target1Flag { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Target 2 R-Multiple", Description = "", Order = 90, GroupName = "FLAG")]
        public double Target2Flag { get; set; }

        #endregion

        #region Indicator Version
        private const string VERSION = "v1.06 12.Apr.2022";
		//1.06 introduced the Infusionsoft licensing system (transitioning away from the fixed license key system)
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }
        #endregion
        #endregion

        #region Custom Property Manipulation
        private void ModifyProperties(PropertyDescriptorCollection col)
        {
            // add this to any property that wants to update the function
            //[RefreshProperties(RefreshProperties.All)]

            //flag remove
            col.Remove(col.Find("ShowFlag", true));
            col.Remove(col.Find("FlagMinAngle", true));
            col.Remove(col.Find("FlagMaxAngle", true));
            col.Remove(col.Find("FlagBullishStroke", true));
            col.Remove(col.Find("FlagBearishStroke", true));
            col.Remove(col.Find("SlopesDev", true));
            col.Remove(col.Find("StopFlag", true));
            col.Remove(col.Find("Target1Flag", true));
            col.Remove(col.Find("Target2Flag", true));

            //ABCD Remove
            //col.Remove(col.Find("ShowABCD", true));
            //col.Remove(col.Find("Retracement1MinFibABCD", true));
            //col.Remove(col.Find("Retracement1MaxFibABCD", true));
            //col.Remove(col.Find("Extention1MinFibABCD", true));
            //col.Remove(col.Find("Extention1MaxFibABCD", true));
            //col.Remove(col.Find("ABCDStrokeBull", true));
            //col.Remove(col.Find("ABCDStrokeBear", true));
            //col.Remove(col.Find("StopABCD", true));
            //col.Remove(col.Find("Target1ABCD", true));
            //col.Remove(col.Find("Target2ABCD", true));

            //if (smallSwingStrength >= smallMax)
            //    smallMax = smallSwingStrength + 1;
            //if (mediumSwingStrength >= mediumMax)
            //    mediumMax = mediumSwingStrength + 1;
            //if (largeSwingStrength >= largeMax)
            //    largeMax = largeSwingStrength + 1;
        }
        #endregion

        #region ICustomTypeDescriptor Members
        public PropertyDescriptorCollection GetProperties() { return TypeDescriptor.GetProperties(GetType()); }
		public object GetPropertyOwner(PropertyDescriptor pd) { return this; }
		public AttributeCollection GetAttributes() { return TypeDescriptor.GetAttributes(GetType()); }
		public string GetClassName() { return TypeDescriptor.GetClassName(GetType()); }
		public string GetComponentName() { return TypeDescriptor.GetComponentName(GetType()); }
		public TypeConverter GetConverter() { return TypeDescriptor.GetConverter(GetType()); }
		public EventDescriptor GetDefaultEvent() { return TypeDescriptor.GetDefaultEvent(GetType()); }
		public PropertyDescriptor GetDefaultProperty() { return TypeDescriptor.GetDefaultProperty(GetType()); }
		public object GetEditor(Type editorBaseType) { return TypeDescriptor.GetEditor(GetType(), editorBaseType); }
		public EventDescriptorCollection GetEvents(Attribute[] attributes) { return TypeDescriptor.GetEvents(GetType(), attributes); }
		public EventDescriptorCollection GetEvents() { return TypeDescriptor.GetEvents(GetType()); }
		public PropertyDescriptorCollection GetProperties(Attribute[] attributes)
		{
			PropertyDescriptorCollection orig = GetFilteredIndicatorProperties(TypeDescriptor.GetProperties(GetType(), attributes), this.IsOwnedByChart, this.IsCreatedByStrategy);
			PropertyDescriptor[] arr = new PropertyDescriptor[orig.Count];
			orig.CopyTo(arr, 0);
			PropertyDescriptorCollection col = new PropertyDescriptorCollection(arr);
			ModifyProperties(col);
			return col;
		}
		public static PropertyDescriptorCollection GetFilteredIndicatorProperties(PropertyDescriptorCollection origProperties, bool isOwnedByChart, bool isCreatedByStrategy)
		{
			List<PropertyDescriptor> allProps = new List<PropertyDescriptor>();
			foreach (PropertyDescriptor pd in origProperties) { allProps.Add(pd); }
			Type[] excludedTypes = new Type[] { typeof(System.Windows.Media.Brush), typeof(NinjaTrader.Gui.Stroke), typeof(System.Windows.Media.Color), typeof(System.Windows.Media.Pen) };
			Func<Type, bool> IsNotAVisualType = (Type propType) => {
				foreach (Type testType in excludedTypes) { if (testType.IsAssignableFrom(propType)) return false; }
				return true;
			};
			IEnumerable<string> baseIndProperties = from bp in typeof(IndicatorBase).GetProperties(BindingFlags.Instance | BindingFlags.Public) select bp.Name;
			IEnumerable<PropertyDescriptor> filteredProps = from p in allProps where p.IsBrowsable && (!isOwnedByChart && !isCreatedByStrategy ? (!baseIndProperties.Contains(p.Name) && p.Name != "Calculate" && p.Name != "Displacement" && IsNotAVisualType(p.PropertyType)) : true) select p;
			return new PropertyDescriptorCollection(filteredProps.ToArray());
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_ACP[] cacheARC_ACP;
		public ARC.ARC_ACP ARC_ACP(bool showLarge, int largeSwingStrength, double largeSensitivity, double largeBreakMultiple, bool showMedium, int mediumSwingStrength, double mediumSensitivity, double mediumBreakMultiple, bool showSmall, int smallSwingStrength, double smallSensitivity, double smallBreakMultiple, bool showLong, bool showShort, bool showNeutral, bool showFresh, bool showFilled, bool showCompleted, bool showInvalidated, bool useSound, bool showInfoBox, string buttonText, int fillTransparency, bool showPattName, SimpleFont font, string entryType, double patternBreakPercent, string tradePlan, Stroke entryLineColor, Stroke stopLineColor, Stroke targetLineColor, Brush labelColor, int linelength, int stopTicks, int target1Ticks, int target2Ticks, bool showABC, double fib1, double fib3, Stroke aBCStrokeBull, Stroke aBCStrokeBear, double stopABC, double target1ABC, double target2ABC, bool showABCD, double retracement1MinFibABCD, double retracement1MaxFibABCD, double retracement2MinFibABCD, double retracement2MaxFibABCD, Stroke aBCDStrokeBull, Stroke aBCDStrokeBear, double stopABCD, double target1ABCD, double target2ABCD, bool showWedge, double wedgeMinAngle, double wedgeMaxAngle, Stroke wedgeNeutralStroke, Stroke wedgeBullishStroke, Stroke wedgeBearishStroke, double stopWedge, double target1Wedge, double target2Wedge, bool showAscDesc, double ascDescTriangMinAngle, double ascDescTriangMaxAngle, Stroke ascTriangStroke, Stroke descTriangStroke, int straightLineDev, double stopAscDescTriang, double target1AscDescTriang, double target2AscDescTriang, bool showSym, double symTriangMinAngle, double symTriangMaxAngle, Stroke symNeutralTriangStroke, Stroke symBullishTriangStroke, Stroke symBearishTriangStroke, int devSlope, double stopSymmTriang, double target1SymmTriang, double target2SymmTriang, bool showRect, int dev, Stroke rectNeutralStroke, Stroke rectBullishStroke, Stroke rectBearishStroke, double stopRect, double target1Rect, double target2Rect, bool showExp, double expTriangMinAngle, double expTriangMaxAngle, Stroke expNeutralTriangStroke, Stroke expBullishTriangStroke, Stroke expBearishTriangStroke, int maxBars, double stopExpTriang, double target1ExpTriang, double target2ExpTriang, bool showFlag, double flagMinAngle, double flagMaxAngle, Stroke flagBullishStroke, Stroke flagBearishStroke, double slopesDev, double stopFlag, double target1Flag, double target2Flag)
		{
			return ARC_ACP(Input, showLarge, largeSwingStrength, largeSensitivity, largeBreakMultiple, showMedium, mediumSwingStrength, mediumSensitivity, mediumBreakMultiple, showSmall, smallSwingStrength, smallSensitivity, smallBreakMultiple, showLong, showShort, showNeutral, showFresh, showFilled, showCompleted, showInvalidated, useSound, showInfoBox, buttonText, fillTransparency, showPattName, font, entryType, patternBreakPercent, tradePlan, entryLineColor, stopLineColor, targetLineColor, labelColor, linelength, stopTicks, target1Ticks, target2Ticks, showABC, fib1, fib3, aBCStrokeBull, aBCStrokeBear, stopABC, target1ABC, target2ABC, showABCD, retracement1MinFibABCD, retracement1MaxFibABCD, retracement2MinFibABCD, retracement2MaxFibABCD, aBCDStrokeBull, aBCDStrokeBear, stopABCD, target1ABCD, target2ABCD, showWedge, wedgeMinAngle, wedgeMaxAngle, wedgeNeutralStroke, wedgeBullishStroke, wedgeBearishStroke, stopWedge, target1Wedge, target2Wedge, showAscDesc, ascDescTriangMinAngle, ascDescTriangMaxAngle, ascTriangStroke, descTriangStroke, straightLineDev, stopAscDescTriang, target1AscDescTriang, target2AscDescTriang, showSym, symTriangMinAngle, symTriangMaxAngle, symNeutralTriangStroke, symBullishTriangStroke, symBearishTriangStroke, devSlope, stopSymmTriang, target1SymmTriang, target2SymmTriang, showRect, dev, rectNeutralStroke, rectBullishStroke, rectBearishStroke, stopRect, target1Rect, target2Rect, showExp, expTriangMinAngle, expTriangMaxAngle, expNeutralTriangStroke, expBullishTriangStroke, expBearishTriangStroke, maxBars, stopExpTriang, target1ExpTriang, target2ExpTriang, showFlag, flagMinAngle, flagMaxAngle, flagBullishStroke, flagBearishStroke, slopesDev, stopFlag, target1Flag, target2Flag);
		}

		public ARC.ARC_ACP ARC_ACP(ISeries<double> input, bool showLarge, int largeSwingStrength, double largeSensitivity, double largeBreakMultiple, bool showMedium, int mediumSwingStrength, double mediumSensitivity, double mediumBreakMultiple, bool showSmall, int smallSwingStrength, double smallSensitivity, double smallBreakMultiple, bool showLong, bool showShort, bool showNeutral, bool showFresh, bool showFilled, bool showCompleted, bool showInvalidated, bool useSound, bool showInfoBox, string buttonText, int fillTransparency, bool showPattName, SimpleFont font, string entryType, double patternBreakPercent, string tradePlan, Stroke entryLineColor, Stroke stopLineColor, Stroke targetLineColor, Brush labelColor, int linelength, int stopTicks, int target1Ticks, int target2Ticks, bool showABC, double fib1, double fib3, Stroke aBCStrokeBull, Stroke aBCStrokeBear, double stopABC, double target1ABC, double target2ABC, bool showABCD, double retracement1MinFibABCD, double retracement1MaxFibABCD, double retracement2MinFibABCD, double retracement2MaxFibABCD, Stroke aBCDStrokeBull, Stroke aBCDStrokeBear, double stopABCD, double target1ABCD, double target2ABCD, bool showWedge, double wedgeMinAngle, double wedgeMaxAngle, Stroke wedgeNeutralStroke, Stroke wedgeBullishStroke, Stroke wedgeBearishStroke, double stopWedge, double target1Wedge, double target2Wedge, bool showAscDesc, double ascDescTriangMinAngle, double ascDescTriangMaxAngle, Stroke ascTriangStroke, Stroke descTriangStroke, int straightLineDev, double stopAscDescTriang, double target1AscDescTriang, double target2AscDescTriang, bool showSym, double symTriangMinAngle, double symTriangMaxAngle, Stroke symNeutralTriangStroke, Stroke symBullishTriangStroke, Stroke symBearishTriangStroke, int devSlope, double stopSymmTriang, double target1SymmTriang, double target2SymmTriang, bool showRect, int dev, Stroke rectNeutralStroke, Stroke rectBullishStroke, Stroke rectBearishStroke, double stopRect, double target1Rect, double target2Rect, bool showExp, double expTriangMinAngle, double expTriangMaxAngle, Stroke expNeutralTriangStroke, Stroke expBullishTriangStroke, Stroke expBearishTriangStroke, int maxBars, double stopExpTriang, double target1ExpTriang, double target2ExpTriang, bool showFlag, double flagMinAngle, double flagMaxAngle, Stroke flagBullishStroke, Stroke flagBearishStroke, double slopesDev, double stopFlag, double target1Flag, double target2Flag)
		{
			if (cacheARC_ACP != null)
				for (int idx = 0; idx < cacheARC_ACP.Length; idx++)
					if (cacheARC_ACP[idx] != null && cacheARC_ACP[idx].ShowLarge == showLarge && cacheARC_ACP[idx].largeSwingStrength == largeSwingStrength && cacheARC_ACP[idx].largeSensitivity == largeSensitivity && cacheARC_ACP[idx].LargeBreakMultiple == largeBreakMultiple && cacheARC_ACP[idx].ShowMedium == showMedium && cacheARC_ACP[idx].mediumSwingStrength == mediumSwingStrength && cacheARC_ACP[idx].mediumSensitivity == mediumSensitivity && cacheARC_ACP[idx].MediumBreakMultiple == mediumBreakMultiple && cacheARC_ACP[idx].ShowSmall == showSmall && cacheARC_ACP[idx].smallSwingStrength == smallSwingStrength && cacheARC_ACP[idx].smallSensitivity == smallSensitivity && cacheARC_ACP[idx].SmallBreakMultiple == smallBreakMultiple && cacheARC_ACP[idx].ShowLong == showLong && cacheARC_ACP[idx].ShowShort == showShort && cacheARC_ACP[idx].ShowNeutral == showNeutral && cacheARC_ACP[idx].ShowFresh == showFresh && cacheARC_ACP[idx].ShowFilled == showFilled && cacheARC_ACP[idx].ShowCompleted == showCompleted && cacheARC_ACP[idx].ShowInvalidated == showInvalidated && cacheARC_ACP[idx].UseSound == useSound && cacheARC_ACP[idx].ShowInfoBox == showInfoBox && cacheARC_ACP[idx].ButtonText == buttonText && cacheARC_ACP[idx].FillTransparency == fillTransparency && cacheARC_ACP[idx].ShowPattName == showPattName && cacheARC_ACP[idx].Font == font && cacheARC_ACP[idx].EntryType == entryType && cacheARC_ACP[idx].PatternBreakPercent == patternBreakPercent && cacheARC_ACP[idx].TradePlan == tradePlan && cacheARC_ACP[idx].EntryLineColor == entryLineColor && cacheARC_ACP[idx].StopLineColor == stopLineColor && cacheARC_ACP[idx].TargetLineColor == targetLineColor && cacheARC_ACP[idx].LabelColor == labelColor && cacheARC_ACP[idx].Linelength == linelength && cacheARC_ACP[idx].StopTicks == stopTicks && cacheARC_ACP[idx].Target1Ticks == target1Ticks && cacheARC_ACP[idx].Target2Ticks == target2Ticks && cacheARC_ACP[idx].ShowABC == showABC && cacheARC_ACP[idx].Fib1 == fib1 && cacheARC_ACP[idx].Fib3 == fib3 && cacheARC_ACP[idx].ABCStrokeBull == aBCStrokeBull && cacheARC_ACP[idx].ABCStrokeBear == aBCStrokeBear && cacheARC_ACP[idx].StopABC == stopABC && cacheARC_ACP[idx].Target1ABC == target1ABC && cacheARC_ACP[idx].Target2ABC == target2ABC && cacheARC_ACP[idx].ShowABCD == showABCD && cacheARC_ACP[idx].Retracement1MinFibABCD == retracement1MinFibABCD && cacheARC_ACP[idx].Retracement1MaxFibABCD == retracement1MaxFibABCD && cacheARC_ACP[idx].Retracement2MinFibABCD == retracement2MinFibABCD && cacheARC_ACP[idx].Retracement2MaxFibABCD == retracement2MaxFibABCD && cacheARC_ACP[idx].ABCDStrokeBull == aBCDStrokeBull && cacheARC_ACP[idx].ABCDStrokeBear == aBCDStrokeBear && cacheARC_ACP[idx].StopABCD == stopABCD && cacheARC_ACP[idx].Target1ABCD == target1ABCD && cacheARC_ACP[idx].Target2ABCD == target2ABCD && cacheARC_ACP[idx].ShowWedge == showWedge && cacheARC_ACP[idx].WedgeMinAngle == wedgeMinAngle && cacheARC_ACP[idx].WedgeMaxAngle == wedgeMaxAngle && cacheARC_ACP[idx].WedgeNeutralStroke == wedgeNeutralStroke && cacheARC_ACP[idx].WedgeBullishStroke == wedgeBullishStroke && cacheARC_ACP[idx].WedgeBearishStroke == wedgeBearishStroke && cacheARC_ACP[idx].StopWedge == stopWedge && cacheARC_ACP[idx].Target1Wedge == target1Wedge && cacheARC_ACP[idx].Target2Wedge == target2Wedge && cacheARC_ACP[idx].ShowAscDesc == showAscDesc && cacheARC_ACP[idx].AscDescTriangMinAngle == ascDescTriangMinAngle && cacheARC_ACP[idx].AscDescTriangMaxAngle == ascDescTriangMaxAngle && cacheARC_ACP[idx].AscTriangStroke == ascTriangStroke && cacheARC_ACP[idx].DescTriangStroke == descTriangStroke && cacheARC_ACP[idx].StraightLineDev == straightLineDev && cacheARC_ACP[idx].StopAscDescTriang == stopAscDescTriang && cacheARC_ACP[idx].Target1AscDescTriang == target1AscDescTriang && cacheARC_ACP[idx].Target2AscDescTriang == target2AscDescTriang && cacheARC_ACP[idx].ShowSym == showSym && cacheARC_ACP[idx].SymTriangMinAngle == symTriangMinAngle && cacheARC_ACP[idx].SymTriangMaxAngle == symTriangMaxAngle && cacheARC_ACP[idx].SymNeutralTriangStroke == symNeutralTriangStroke && cacheARC_ACP[idx].SymBullishTriangStroke == symBullishTriangStroke && cacheARC_ACP[idx].SymBearishTriangStroke == symBearishTriangStroke && cacheARC_ACP[idx].DevSlope == devSlope && cacheARC_ACP[idx].StopSymmTriang == stopSymmTriang && cacheARC_ACP[idx].Target1SymmTriang == target1SymmTriang && cacheARC_ACP[idx].Target2SymmTriang == target2SymmTriang && cacheARC_ACP[idx].ShowRect == showRect && cacheARC_ACP[idx].Dev == dev && cacheARC_ACP[idx].RectNeutralStroke == rectNeutralStroke && cacheARC_ACP[idx].RectBullishStroke == rectBullishStroke && cacheARC_ACP[idx].RectBearishStroke == rectBearishStroke && cacheARC_ACP[idx].StopRect == stopRect && cacheARC_ACP[idx].Target1Rect == target1Rect && cacheARC_ACP[idx].Target2Rect == target2Rect && cacheARC_ACP[idx].ShowExp == showExp && cacheARC_ACP[idx].ExpTriangMinAngle == expTriangMinAngle && cacheARC_ACP[idx].ExpTriangMaxAngle == expTriangMaxAngle && cacheARC_ACP[idx].ExpNeutralTriangStroke == expNeutralTriangStroke && cacheARC_ACP[idx].ExpBullishTriangStroke == expBullishTriangStroke && cacheARC_ACP[idx].ExpBearishTriangStroke == expBearishTriangStroke && cacheARC_ACP[idx].MaxBars == maxBars && cacheARC_ACP[idx].StopExpTriang == stopExpTriang && cacheARC_ACP[idx].Target1ExpTriang == target1ExpTriang && cacheARC_ACP[idx].Target2ExpTriang == target2ExpTriang && cacheARC_ACP[idx].ShowFlag == showFlag && cacheARC_ACP[idx].FlagMinAngle == flagMinAngle && cacheARC_ACP[idx].FlagMaxAngle == flagMaxAngle && cacheARC_ACP[idx].FlagBullishStroke == flagBullishStroke && cacheARC_ACP[idx].FlagBearishStroke == flagBearishStroke && cacheARC_ACP[idx].SlopesDev == slopesDev && cacheARC_ACP[idx].StopFlag == stopFlag && cacheARC_ACP[idx].Target1Flag == target1Flag && cacheARC_ACP[idx].Target2Flag == target2Flag && cacheARC_ACP[idx].EqualsInput(input))
						return cacheARC_ACP[idx];
			return CacheIndicator<ARC.ARC_ACP>(new ARC.ARC_ACP(){ ShowLarge = showLarge, largeSwingStrength = largeSwingStrength, largeSensitivity = largeSensitivity, LargeBreakMultiple = largeBreakMultiple, ShowMedium = showMedium, mediumSwingStrength = mediumSwingStrength, mediumSensitivity = mediumSensitivity, MediumBreakMultiple = mediumBreakMultiple, ShowSmall = showSmall, smallSwingStrength = smallSwingStrength, smallSensitivity = smallSensitivity, SmallBreakMultiple = smallBreakMultiple, ShowLong = showLong, ShowShort = showShort, ShowNeutral = showNeutral, ShowFresh = showFresh, ShowFilled = showFilled, ShowCompleted = showCompleted, ShowInvalidated = showInvalidated, UseSound = useSound, ShowInfoBox = showInfoBox, ButtonText = buttonText, FillTransparency = fillTransparency, ShowPattName = showPattName, Font = font, EntryType = entryType, PatternBreakPercent = patternBreakPercent, TradePlan = tradePlan, EntryLineColor = entryLineColor, StopLineColor = stopLineColor, TargetLineColor = targetLineColor, LabelColor = labelColor, Linelength = linelength, StopTicks = stopTicks, Target1Ticks = target1Ticks, Target2Ticks = target2Ticks, ShowABC = showABC, Fib1 = fib1, Fib3 = fib3, ABCStrokeBull = aBCStrokeBull, ABCStrokeBear = aBCStrokeBear, StopABC = stopABC, Target1ABC = target1ABC, Target2ABC = target2ABC, ShowABCD = showABCD, Retracement1MinFibABCD = retracement1MinFibABCD, Retracement1MaxFibABCD = retracement1MaxFibABCD, Retracement2MinFibABCD = retracement2MinFibABCD, Retracement2MaxFibABCD = retracement2MaxFibABCD, ABCDStrokeBull = aBCDStrokeBull, ABCDStrokeBear = aBCDStrokeBear, StopABCD = stopABCD, Target1ABCD = target1ABCD, Target2ABCD = target2ABCD, ShowWedge = showWedge, WedgeMinAngle = wedgeMinAngle, WedgeMaxAngle = wedgeMaxAngle, WedgeNeutralStroke = wedgeNeutralStroke, WedgeBullishStroke = wedgeBullishStroke, WedgeBearishStroke = wedgeBearishStroke, StopWedge = stopWedge, Target1Wedge = target1Wedge, Target2Wedge = target2Wedge, ShowAscDesc = showAscDesc, AscDescTriangMinAngle = ascDescTriangMinAngle, AscDescTriangMaxAngle = ascDescTriangMaxAngle, AscTriangStroke = ascTriangStroke, DescTriangStroke = descTriangStroke, StraightLineDev = straightLineDev, StopAscDescTriang = stopAscDescTriang, Target1AscDescTriang = target1AscDescTriang, Target2AscDescTriang = target2AscDescTriang, ShowSym = showSym, SymTriangMinAngle = symTriangMinAngle, SymTriangMaxAngle = symTriangMaxAngle, SymNeutralTriangStroke = symNeutralTriangStroke, SymBullishTriangStroke = symBullishTriangStroke, SymBearishTriangStroke = symBearishTriangStroke, DevSlope = devSlope, StopSymmTriang = stopSymmTriang, Target1SymmTriang = target1SymmTriang, Target2SymmTriang = target2SymmTriang, ShowRect = showRect, Dev = dev, RectNeutralStroke = rectNeutralStroke, RectBullishStroke = rectBullishStroke, RectBearishStroke = rectBearishStroke, StopRect = stopRect, Target1Rect = target1Rect, Target2Rect = target2Rect, ShowExp = showExp, ExpTriangMinAngle = expTriangMinAngle, ExpTriangMaxAngle = expTriangMaxAngle, ExpNeutralTriangStroke = expNeutralTriangStroke, ExpBullishTriangStroke = expBullishTriangStroke, ExpBearishTriangStroke = expBearishTriangStroke, MaxBars = maxBars, StopExpTriang = stopExpTriang, Target1ExpTriang = target1ExpTriang, Target2ExpTriang = target2ExpTriang, ShowFlag = showFlag, FlagMinAngle = flagMinAngle, FlagMaxAngle = flagMaxAngle, FlagBullishStroke = flagBullishStroke, FlagBearishStroke = flagBearishStroke, SlopesDev = slopesDev, StopFlag = stopFlag, Target1Flag = target1Flag, Target2Flag = target2Flag }, input, ref cacheARC_ACP);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_ACP ARC_ACP(bool showLarge, int largeSwingStrength, double largeSensitivity, double largeBreakMultiple, bool showMedium, int mediumSwingStrength, double mediumSensitivity, double mediumBreakMultiple, bool showSmall, int smallSwingStrength, double smallSensitivity, double smallBreakMultiple, bool showLong, bool showShort, bool showNeutral, bool showFresh, bool showFilled, bool showCompleted, bool showInvalidated, bool useSound, bool showInfoBox, string buttonText, int fillTransparency, bool showPattName, SimpleFont font, string entryType, double patternBreakPercent, string tradePlan, Stroke entryLineColor, Stroke stopLineColor, Stroke targetLineColor, Brush labelColor, int linelength, int stopTicks, int target1Ticks, int target2Ticks, bool showABC, double fib1, double fib3, Stroke aBCStrokeBull, Stroke aBCStrokeBear, double stopABC, double target1ABC, double target2ABC, bool showABCD, double retracement1MinFibABCD, double retracement1MaxFibABCD, double retracement2MinFibABCD, double retracement2MaxFibABCD, Stroke aBCDStrokeBull, Stroke aBCDStrokeBear, double stopABCD, double target1ABCD, double target2ABCD, bool showWedge, double wedgeMinAngle, double wedgeMaxAngle, Stroke wedgeNeutralStroke, Stroke wedgeBullishStroke, Stroke wedgeBearishStroke, double stopWedge, double target1Wedge, double target2Wedge, bool showAscDesc, double ascDescTriangMinAngle, double ascDescTriangMaxAngle, Stroke ascTriangStroke, Stroke descTriangStroke, int straightLineDev, double stopAscDescTriang, double target1AscDescTriang, double target2AscDescTriang, bool showSym, double symTriangMinAngle, double symTriangMaxAngle, Stroke symNeutralTriangStroke, Stroke symBullishTriangStroke, Stroke symBearishTriangStroke, int devSlope, double stopSymmTriang, double target1SymmTriang, double target2SymmTriang, bool showRect, int dev, Stroke rectNeutralStroke, Stroke rectBullishStroke, Stroke rectBearishStroke, double stopRect, double target1Rect, double target2Rect, bool showExp, double expTriangMinAngle, double expTriangMaxAngle, Stroke expNeutralTriangStroke, Stroke expBullishTriangStroke, Stroke expBearishTriangStroke, int maxBars, double stopExpTriang, double target1ExpTriang, double target2ExpTriang, bool showFlag, double flagMinAngle, double flagMaxAngle, Stroke flagBullishStroke, Stroke flagBearishStroke, double slopesDev, double stopFlag, double target1Flag, double target2Flag)
		{
			return indicator.ARC_ACP(Input, showLarge, largeSwingStrength, largeSensitivity, largeBreakMultiple, showMedium, mediumSwingStrength, mediumSensitivity, mediumBreakMultiple, showSmall, smallSwingStrength, smallSensitivity, smallBreakMultiple, showLong, showShort, showNeutral, showFresh, showFilled, showCompleted, showInvalidated, useSound, showInfoBox, buttonText, fillTransparency, showPattName, font, entryType, patternBreakPercent, tradePlan, entryLineColor, stopLineColor, targetLineColor, labelColor, linelength, stopTicks, target1Ticks, target2Ticks, showABC, fib1, fib3, aBCStrokeBull, aBCStrokeBear, stopABC, target1ABC, target2ABC, showABCD, retracement1MinFibABCD, retracement1MaxFibABCD, retracement2MinFibABCD, retracement2MaxFibABCD, aBCDStrokeBull, aBCDStrokeBear, stopABCD, target1ABCD, target2ABCD, showWedge, wedgeMinAngle, wedgeMaxAngle, wedgeNeutralStroke, wedgeBullishStroke, wedgeBearishStroke, stopWedge, target1Wedge, target2Wedge, showAscDesc, ascDescTriangMinAngle, ascDescTriangMaxAngle, ascTriangStroke, descTriangStroke, straightLineDev, stopAscDescTriang, target1AscDescTriang, target2AscDescTriang, showSym, symTriangMinAngle, symTriangMaxAngle, symNeutralTriangStroke, symBullishTriangStroke, symBearishTriangStroke, devSlope, stopSymmTriang, target1SymmTriang, target2SymmTriang, showRect, dev, rectNeutralStroke, rectBullishStroke, rectBearishStroke, stopRect, target1Rect, target2Rect, showExp, expTriangMinAngle, expTriangMaxAngle, expNeutralTriangStroke, expBullishTriangStroke, expBearishTriangStroke, maxBars, stopExpTriang, target1ExpTriang, target2ExpTriang, showFlag, flagMinAngle, flagMaxAngle, flagBullishStroke, flagBearishStroke, slopesDev, stopFlag, target1Flag, target2Flag);
		}

		public Indicators.ARC.ARC_ACP ARC_ACP(ISeries<double> input , bool showLarge, int largeSwingStrength, double largeSensitivity, double largeBreakMultiple, bool showMedium, int mediumSwingStrength, double mediumSensitivity, double mediumBreakMultiple, bool showSmall, int smallSwingStrength, double smallSensitivity, double smallBreakMultiple, bool showLong, bool showShort, bool showNeutral, bool showFresh, bool showFilled, bool showCompleted, bool showInvalidated, bool useSound, bool showInfoBox, string buttonText, int fillTransparency, bool showPattName, SimpleFont font, string entryType, double patternBreakPercent, string tradePlan, Stroke entryLineColor, Stroke stopLineColor, Stroke targetLineColor, Brush labelColor, int linelength, int stopTicks, int target1Ticks, int target2Ticks, bool showABC, double fib1, double fib3, Stroke aBCStrokeBull, Stroke aBCStrokeBear, double stopABC, double target1ABC, double target2ABC, bool showABCD, double retracement1MinFibABCD, double retracement1MaxFibABCD, double retracement2MinFibABCD, double retracement2MaxFibABCD, Stroke aBCDStrokeBull, Stroke aBCDStrokeBear, double stopABCD, double target1ABCD, double target2ABCD, bool showWedge, double wedgeMinAngle, double wedgeMaxAngle, Stroke wedgeNeutralStroke, Stroke wedgeBullishStroke, Stroke wedgeBearishStroke, double stopWedge, double target1Wedge, double target2Wedge, bool showAscDesc, double ascDescTriangMinAngle, double ascDescTriangMaxAngle, Stroke ascTriangStroke, Stroke descTriangStroke, int straightLineDev, double stopAscDescTriang, double target1AscDescTriang, double target2AscDescTriang, bool showSym, double symTriangMinAngle, double symTriangMaxAngle, Stroke symNeutralTriangStroke, Stroke symBullishTriangStroke, Stroke symBearishTriangStroke, int devSlope, double stopSymmTriang, double target1SymmTriang, double target2SymmTriang, bool showRect, int dev, Stroke rectNeutralStroke, Stroke rectBullishStroke, Stroke rectBearishStroke, double stopRect, double target1Rect, double target2Rect, bool showExp, double expTriangMinAngle, double expTriangMaxAngle, Stroke expNeutralTriangStroke, Stroke expBullishTriangStroke, Stroke expBearishTriangStroke, int maxBars, double stopExpTriang, double target1ExpTriang, double target2ExpTriang, bool showFlag, double flagMinAngle, double flagMaxAngle, Stroke flagBullishStroke, Stroke flagBearishStroke, double slopesDev, double stopFlag, double target1Flag, double target2Flag)
		{
			return indicator.ARC_ACP(input, showLarge, largeSwingStrength, largeSensitivity, largeBreakMultiple, showMedium, mediumSwingStrength, mediumSensitivity, mediumBreakMultiple, showSmall, smallSwingStrength, smallSensitivity, smallBreakMultiple, showLong, showShort, showNeutral, showFresh, showFilled, showCompleted, showInvalidated, useSound, showInfoBox, buttonText, fillTransparency, showPattName, font, entryType, patternBreakPercent, tradePlan, entryLineColor, stopLineColor, targetLineColor, labelColor, linelength, stopTicks, target1Ticks, target2Ticks, showABC, fib1, fib3, aBCStrokeBull, aBCStrokeBear, stopABC, target1ABC, target2ABC, showABCD, retracement1MinFibABCD, retracement1MaxFibABCD, retracement2MinFibABCD, retracement2MaxFibABCD, aBCDStrokeBull, aBCDStrokeBear, stopABCD, target1ABCD, target2ABCD, showWedge, wedgeMinAngle, wedgeMaxAngle, wedgeNeutralStroke, wedgeBullishStroke, wedgeBearishStroke, stopWedge, target1Wedge, target2Wedge, showAscDesc, ascDescTriangMinAngle, ascDescTriangMaxAngle, ascTriangStroke, descTriangStroke, straightLineDev, stopAscDescTriang, target1AscDescTriang, target2AscDescTriang, showSym, symTriangMinAngle, symTriangMaxAngle, symNeutralTriangStroke, symBullishTriangStroke, symBearishTriangStroke, devSlope, stopSymmTriang, target1SymmTriang, target2SymmTriang, showRect, dev, rectNeutralStroke, rectBullishStroke, rectBearishStroke, stopRect, target1Rect, target2Rect, showExp, expTriangMinAngle, expTriangMaxAngle, expNeutralTriangStroke, expBullishTriangStroke, expBearishTriangStroke, maxBars, stopExpTriang, target1ExpTriang, target2ExpTriang, showFlag, flagMinAngle, flagMaxAngle, flagBullishStroke, flagBearishStroke, slopesDev, stopFlag, target1Flag, target2Flag);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_ACP ARC_ACP(bool showLarge, int largeSwingStrength, double largeSensitivity, double largeBreakMultiple, bool showMedium, int mediumSwingStrength, double mediumSensitivity, double mediumBreakMultiple, bool showSmall, int smallSwingStrength, double smallSensitivity, double smallBreakMultiple, bool showLong, bool showShort, bool showNeutral, bool showFresh, bool showFilled, bool showCompleted, bool showInvalidated, bool useSound, bool showInfoBox, string buttonText, int fillTransparency, bool showPattName, SimpleFont font, string entryType, double patternBreakPercent, string tradePlan, Stroke entryLineColor, Stroke stopLineColor, Stroke targetLineColor, Brush labelColor, int linelength, int stopTicks, int target1Ticks, int target2Ticks, bool showABC, double fib1, double fib3, Stroke aBCStrokeBull, Stroke aBCStrokeBear, double stopABC, double target1ABC, double target2ABC, bool showABCD, double retracement1MinFibABCD, double retracement1MaxFibABCD, double retracement2MinFibABCD, double retracement2MaxFibABCD, Stroke aBCDStrokeBull, Stroke aBCDStrokeBear, double stopABCD, double target1ABCD, double target2ABCD, bool showWedge, double wedgeMinAngle, double wedgeMaxAngle, Stroke wedgeNeutralStroke, Stroke wedgeBullishStroke, Stroke wedgeBearishStroke, double stopWedge, double target1Wedge, double target2Wedge, bool showAscDesc, double ascDescTriangMinAngle, double ascDescTriangMaxAngle, Stroke ascTriangStroke, Stroke descTriangStroke, int straightLineDev, double stopAscDescTriang, double target1AscDescTriang, double target2AscDescTriang, bool showSym, double symTriangMinAngle, double symTriangMaxAngle, Stroke symNeutralTriangStroke, Stroke symBullishTriangStroke, Stroke symBearishTriangStroke, int devSlope, double stopSymmTriang, double target1SymmTriang, double target2SymmTriang, bool showRect, int dev, Stroke rectNeutralStroke, Stroke rectBullishStroke, Stroke rectBearishStroke, double stopRect, double target1Rect, double target2Rect, bool showExp, double expTriangMinAngle, double expTriangMaxAngle, Stroke expNeutralTriangStroke, Stroke expBullishTriangStroke, Stroke expBearishTriangStroke, int maxBars, double stopExpTriang, double target1ExpTriang, double target2ExpTriang, bool showFlag, double flagMinAngle, double flagMaxAngle, Stroke flagBullishStroke, Stroke flagBearishStroke, double slopesDev, double stopFlag, double target1Flag, double target2Flag)
		{
			return indicator.ARC_ACP(Input, showLarge, largeSwingStrength, largeSensitivity, largeBreakMultiple, showMedium, mediumSwingStrength, mediumSensitivity, mediumBreakMultiple, showSmall, smallSwingStrength, smallSensitivity, smallBreakMultiple, showLong, showShort, showNeutral, showFresh, showFilled, showCompleted, showInvalidated, useSound, showInfoBox, buttonText, fillTransparency, showPattName, font, entryType, patternBreakPercent, tradePlan, entryLineColor, stopLineColor, targetLineColor, labelColor, linelength, stopTicks, target1Ticks, target2Ticks, showABC, fib1, fib3, aBCStrokeBull, aBCStrokeBear, stopABC, target1ABC, target2ABC, showABCD, retracement1MinFibABCD, retracement1MaxFibABCD, retracement2MinFibABCD, retracement2MaxFibABCD, aBCDStrokeBull, aBCDStrokeBear, stopABCD, target1ABCD, target2ABCD, showWedge, wedgeMinAngle, wedgeMaxAngle, wedgeNeutralStroke, wedgeBullishStroke, wedgeBearishStroke, stopWedge, target1Wedge, target2Wedge, showAscDesc, ascDescTriangMinAngle, ascDescTriangMaxAngle, ascTriangStroke, descTriangStroke, straightLineDev, stopAscDescTriang, target1AscDescTriang, target2AscDescTriang, showSym, symTriangMinAngle, symTriangMaxAngle, symNeutralTriangStroke, symBullishTriangStroke, symBearishTriangStroke, devSlope, stopSymmTriang, target1SymmTriang, target2SymmTriang, showRect, dev, rectNeutralStroke, rectBullishStroke, rectBearishStroke, stopRect, target1Rect, target2Rect, showExp, expTriangMinAngle, expTriangMaxAngle, expNeutralTriangStroke, expBullishTriangStroke, expBearishTriangStroke, maxBars, stopExpTriang, target1ExpTriang, target2ExpTriang, showFlag, flagMinAngle, flagMaxAngle, flagBullishStroke, flagBearishStroke, slopesDev, stopFlag, target1Flag, target2Flag);
		}

		public Indicators.ARC.ARC_ACP ARC_ACP(ISeries<double> input , bool showLarge, int largeSwingStrength, double largeSensitivity, double largeBreakMultiple, bool showMedium, int mediumSwingStrength, double mediumSensitivity, double mediumBreakMultiple, bool showSmall, int smallSwingStrength, double smallSensitivity, double smallBreakMultiple, bool showLong, bool showShort, bool showNeutral, bool showFresh, bool showFilled, bool showCompleted, bool showInvalidated, bool useSound, bool showInfoBox, string buttonText, int fillTransparency, bool showPattName, SimpleFont font, string entryType, double patternBreakPercent, string tradePlan, Stroke entryLineColor, Stroke stopLineColor, Stroke targetLineColor, Brush labelColor, int linelength, int stopTicks, int target1Ticks, int target2Ticks, bool showABC, double fib1, double fib3, Stroke aBCStrokeBull, Stroke aBCStrokeBear, double stopABC, double target1ABC, double target2ABC, bool showABCD, double retracement1MinFibABCD, double retracement1MaxFibABCD, double retracement2MinFibABCD, double retracement2MaxFibABCD, Stroke aBCDStrokeBull, Stroke aBCDStrokeBear, double stopABCD, double target1ABCD, double target2ABCD, bool showWedge, double wedgeMinAngle, double wedgeMaxAngle, Stroke wedgeNeutralStroke, Stroke wedgeBullishStroke, Stroke wedgeBearishStroke, double stopWedge, double target1Wedge, double target2Wedge, bool showAscDesc, double ascDescTriangMinAngle, double ascDescTriangMaxAngle, Stroke ascTriangStroke, Stroke descTriangStroke, int straightLineDev, double stopAscDescTriang, double target1AscDescTriang, double target2AscDescTriang, bool showSym, double symTriangMinAngle, double symTriangMaxAngle, Stroke symNeutralTriangStroke, Stroke symBullishTriangStroke, Stroke symBearishTriangStroke, int devSlope, double stopSymmTriang, double target1SymmTriang, double target2SymmTriang, bool showRect, int dev, Stroke rectNeutralStroke, Stroke rectBullishStroke, Stroke rectBearishStroke, double stopRect, double target1Rect, double target2Rect, bool showExp, double expTriangMinAngle, double expTriangMaxAngle, Stroke expNeutralTriangStroke, Stroke expBullishTriangStroke, Stroke expBearishTriangStroke, int maxBars, double stopExpTriang, double target1ExpTriang, double target2ExpTriang, bool showFlag, double flagMinAngle, double flagMaxAngle, Stroke flagBullishStroke, Stroke flagBearishStroke, double slopesDev, double stopFlag, double target1Flag, double target2Flag)
		{
			return indicator.ARC_ACP(input, showLarge, largeSwingStrength, largeSensitivity, largeBreakMultiple, showMedium, mediumSwingStrength, mediumSensitivity, mediumBreakMultiple, showSmall, smallSwingStrength, smallSensitivity, smallBreakMultiple, showLong, showShort, showNeutral, showFresh, showFilled, showCompleted, showInvalidated, useSound, showInfoBox, buttonText, fillTransparency, showPattName, font, entryType, patternBreakPercent, tradePlan, entryLineColor, stopLineColor, targetLineColor, labelColor, linelength, stopTicks, target1Ticks, target2Ticks, showABC, fib1, fib3, aBCStrokeBull, aBCStrokeBear, stopABC, target1ABC, target2ABC, showABCD, retracement1MinFibABCD, retracement1MaxFibABCD, retracement2MinFibABCD, retracement2MaxFibABCD, aBCDStrokeBull, aBCDStrokeBear, stopABCD, target1ABCD, target2ABCD, showWedge, wedgeMinAngle, wedgeMaxAngle, wedgeNeutralStroke, wedgeBullishStroke, wedgeBearishStroke, stopWedge, target1Wedge, target2Wedge, showAscDesc, ascDescTriangMinAngle, ascDescTriangMaxAngle, ascTriangStroke, descTriangStroke, straightLineDev, stopAscDescTriang, target1AscDescTriang, target2AscDescTriang, showSym, symTriangMinAngle, symTriangMaxAngle, symNeutralTriangStroke, symBullishTriangStroke, symBearishTriangStroke, devSlope, stopSymmTriang, target1SymmTriang, target2SymmTriang, showRect, dev, rectNeutralStroke, rectBullishStroke, rectBearishStroke, stopRect, target1Rect, target2Rect, showExp, expTriangMinAngle, expTriangMaxAngle, expNeutralTriangStroke, expBullishTriangStroke, expBearishTriangStroke, maxBars, stopExpTriang, target1ExpTriang, target2ExpTriang, showFlag, flagMinAngle, flagMaxAngle, flagBullishStroke, flagBearishStroke, slopesDev, stopFlag, target1Flag, target2Flag);
		}
	}
}

#endregion
