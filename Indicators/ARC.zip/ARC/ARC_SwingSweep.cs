//
// Copyright (C) 2023, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    [CategoryOrder("Parameters", 10)]
    [CategoryOrder("Entry Lines", 20)]
    [CategoryOrder("General Visuals", 30)]
	public class ARC_SwingSweep : Indicator
	{
		private int			constant;
		private double		currentSwingHigh;
		private double		currentSwingLow;
		private ArrayList	lastHighCache;
		private double		lastSwingHighValue;
		private ArrayList	lastLowCache;
		private double		lastSwingLowValue;
		private int			saveCurrentBar;

		private Series<double> swingHighSeries;
		private Series<double> swingHighSwings;
		private Series<double> swingLowSeries;
		private Series<double> swingLowSwings;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionSwing;
				Name						= "ARC_SwingSweep";
				DisplayInDataBox			= false;
				PaintPriceMarkers			= false;
				IsSuspendedWhileInactive	= false;
				Calculate 					= Calculate.OnPriceChange;
				IsOverlay					= true;
				IsAutoScale = false;
				Strength					= 5;
				pShowSwingPlots = false;
				pShowSwingLines = true;
				pShowEntryLineText = false;
				pEntryLineLengthBars = 3;
				pFont = new NinjaTrader.Gui.Tools.SimpleFont("Arial",12);
				BuyLine_Stroke = new Stroke(Brushes.Green, 3);
				SellLine_Stroke = new Stroke(Brushes.Red, 3);


				AddPlot(new Stroke(Brushes.DarkBlue, 1), PlotStyle.Dot, NinjaTrader.Custom.Resource.SwingHigh);
				AddPlot(new Stroke(Brushes.Purple,	 1), PlotStyle.Dot, NinjaTrader.Custom.Resource.SwingLow);
			}

			else if (State == State.Configure)
			{
				currentSwingHigh	= 0;
				currentSwingLow		= 0;
				lastSwingHighValue	= 0;
				lastSwingLowValue	= 0;
				saveCurrentBar		= -1;
				constant			= (2 * Strength) + 1;
			}
			else if (State == State.DataLoaded)
			{
				lastHighCache	= new ArrayList();
				lastLowCache	= new ArrayList();

				swingHighSeries = new Series<double>(this);
				swingHighSwings = new Series<double>(this);
				swingLowSeries	= new Series<double>(this);
				swingLowSwings	= new Series<double>(this);
			}
		}

		private class LinesClass{
			public int StartABar = int.MinValue;
			public int EndABar = int.MaxValue;
			public int BreakABar = 0;
			public double Price = 0;
			public char Type = ' '; //'L'ong or 'S'hort
			public LinesClass(int currentbar, char type, double price){	StartABar = currentbar; Type = type; Price = price;			}
			public void Broken(int cb){
				BreakABar = cb;
				EndABar = cb;
			}
		}
		private double Round2Tick(double p){
			return Instrument.MasterInstrument.RoundToTickSize(p);
		}
		private SortedDictionary<int, LinesClass> ELines = new SortedDictionary<int, LinesClass>();
		private SortedDictionary<int, LinesClass> SwingLines = new SortedDictionary<int, LinesClass>();
		bool isSwingHigh = true;
		bool isSwingLow = true;
		protected override void OnBarUpdate()
		{
			#region -- Calc Swing --
			double high0	= Round2Tick(!(Input is PriceSeries || Input is Bars) ? Input[0] : High[0]);
			double low0		= Round2Tick(!(Input is PriceSeries || Input is Bars) ? Input[0] : Low[0]);
			double close0	= Round2Tick(!(Input is PriceSeries || Input is Bars) ? Input[0] : Close[0]);

			if (BarsArray[0].BarsType.IsRemoveLastBarSupported && CurrentBar < saveCurrentBar)
			{
				currentSwingHigh			= SwingHighPlot.IsValidDataPoint(0) ? SwingHighPlot[0] : 0;
				currentSwingLow				= SwingLowPlot.IsValidDataPoint(0) ? SwingLowPlot[0] : 0;
				lastSwingHighValue			= swingHighSeries[0];
				lastSwingLowValue			= swingLowSeries[0];
				swingHighSeries[Strength]	= 0;
				swingLowSeries[Strength]	= 0;

				lastHighCache.Clear();
				lastLowCache.Clear();
				for (int barsBack = Math.Min(CurrentBar, constant) - 1; barsBack >= 0; barsBack--)
				{
					lastHighCache.Add(Round2Tick(!(Input is PriceSeries || Input is Bars) ? Input[barsBack] : High[barsBack]));
					lastLowCache.Add(Round2Tick(!(Input is PriceSeries || Input is Bars) ? Input[barsBack] : Low[barsBack]));
				}
				saveCurrentBar = CurrentBar;
				return;
			}

			if (saveCurrentBar != CurrentBar)
			{
				swingHighSwings[0]	= 0;	// initializing important internal
				swingLowSwings[0]	= 0;	// initializing important internal

				swingHighSeries[0]	= 0;	// initializing important internal
				swingLowSeries[0]	= 0;	// initializing important internal

				lastHighCache.Add(high0);
				if (lastHighCache.Count > constant)
					lastHighCache.RemoveAt(0);
				lastLowCache.Add(low0);
				if (lastLowCache.Count > constant)
					lastLowCache.RemoveAt(0);

				if (lastHighCache.Count == constant)
				{
					isSwingHigh = true;
					double swingHighCandidateValue = (double) lastHighCache[Strength];
					for (int i=0; i < Strength; i++)
						if (((double) lastHighCache[i]).ApproxCompare(swingHighCandidateValue) >= 0)
							isSwingHigh = false;

					for (int i=Strength+1; i < lastHighCache.Count; i++)
						if (((double) lastHighCache[i]).ApproxCompare(swingHighCandidateValue) > 0)
							isSwingHigh = false;

					swingHighSwings[Strength] = isSwingHigh ? swingHighCandidateValue : 0.0;

					if (isSwingHigh){
						lastSwingHighValue = swingHighCandidateValue;
						currentSwingHigh = swingHighCandidateValue;
						for (int i=0; i <= Strength; i++)
							SwingHighPlot[i] = currentSwingHigh;
						SwingLines[CurrentBars[0]] = new LinesClass(CurrentBars[0]-Strength, 'S', Round2Tick(currentSwingHigh));
					}
					else if (high0 > currentSwingHigh || currentSwingHigh.ApproxCompare(0.0) == 0)
					{
						currentSwingHigh = 0.0;
						SwingHighPlot[0] = close0;
						SwingHighPlot.Reset();
					}
					else
						SwingHighPlot[0] = currentSwingHigh;

					if (isSwingHigh)
					{
						for (int i=0; i<=Strength; i++)
							swingHighSeries[i] = lastSwingHighValue;
					}
					else
					{
						swingHighSeries[0] = lastSwingHighValue;
					}
				}

				if (lastLowCache.Count == constant)
				{
					isSwingLow = true;
					double swingLowCandidateValue = (double) lastLowCache[Strength];
					for (int i=0; i < Strength; i++)
						if (((double) lastLowCache[i]).ApproxCompare(swingLowCandidateValue) <= 0)
							isSwingLow = false;

					for (int i=Strength+1; i < lastLowCache.Count; i++)
						if (((double) lastLowCache[i]).ApproxCompare(swingLowCandidateValue) < 0)
							isSwingLow = false;

					swingLowSwings[Strength] = isSwingLow ? swingLowCandidateValue : 0.0;

					if (isSwingLow){
						lastSwingLowValue = swingLowCandidateValue;
						currentSwingLow = swingLowCandidateValue;
						for (int i=0; i <= Strength; i++)
							SwingLowPlot[i] = currentSwingLow;
						SwingLines[CurrentBars[0]] = new LinesClass(CurrentBars[0]-Strength, 'L', Round2Tick(currentSwingLow));
					}
					else if (low0 < currentSwingLow || currentSwingLow.ApproxCompare(0.0) == 0)
					{
						currentSwingLow = double.MaxValue;
						SwingLowPlot[0] = close0;
						SwingLowPlot.Reset();
					}
					else
						SwingLowPlot[0] = currentSwingLow;

					if (isSwingLow)
					{
						for (int i=0; i<=Strength; i++)
							swingLowSeries[i] = lastSwingLowValue;
					}
					else
					{
						swingLowSeries[0] = lastSwingLowValue;
					}
				}

				saveCurrentBar = CurrentBar;
			}
			else if (CurrentBar >= constant - 1)
			{
				if (lastHighCache.Count == constant && high0.ApproxCompare((double) lastHighCache[lastHighCache.Count - 1]) > 0)
					lastHighCache[lastHighCache.Count - 1] = high0;
				if (lastLowCache.Count == constant && low0.ApproxCompare((double) lastLowCache[lastLowCache.Count - 1]) < 0)
					lastLowCache[lastLowCache.Count - 1] = low0;

				if (high0 > currentSwingHigh && swingHighSwings[Strength] > 0.0)
				{
					swingHighSwings[Strength] = 0.0;
					for (int i = 0; i <= Strength; i++)
					{
						SwingHighPlot[i] = close0;
						SwingHighPlot.Reset(i);
						currentSwingHigh = 0.0;
					}
				}
				else if (high0 > currentSwingHigh && currentSwingHigh.ApproxCompare(0.0) != 0)
				{
					SwingHighPlot[0] = close0;
					SwingHighPlot.Reset();
					currentSwingHigh = 0.0;
				}
				else if (high0 <= currentSwingHigh)
					SwingHighPlot[0] = currentSwingHigh;

				if (low0 < currentSwingLow && swingLowSwings[Strength] > 0.0)
				{
					swingLowSwings[Strength] = 0.0;
					for (int i = 0; i <= Strength; i++)
					{
						SwingLowPlot[i] = close0;
						SwingLowPlot.Reset(i);
						currentSwingLow = double.MaxValue;
					}
				}
				else if (low0 < currentSwingLow && currentSwingLow.ApproxCompare(double.MaxValue) != 0)
				{
					SwingLowPlot.Reset();
					currentSwingLow = double.MaxValue;
				}
				else if (low0 >= currentSwingLow)
					SwingLowPlot[0] = currentSwingLow;
			}
			#endregion
			if(CurrentBars[0]>2){
				//if(isSwingHigh) Draw.Square(this,CurrentBars[0].ToString(), false,0,Medians[0][0], Brushes.Cyan);
				var H = Round2Tick(Highs[0][0]);
				var L = Round2Tick(Lows[0][0]);
				var C = Round2Tick(Closes[0][0]);
//				if(SwingHighPlot.IsValidDataPoint(0) && SwingHighPlot.IsValidDataPoint(1) && SwingHighPlot[1] != SwingHighPlot[0]){
				if(SwingHighPlot.IsValidDataPoint(1)){
					if(H > SwingHighPlot[1])
						ELines[CurrentBars[0]] = new LinesClass(CurrentBars[0], 'S', Round2Tick(Lows[0][1]));
//					else if(isSwingHigh)
//						SwingLines[CurrentBars[0]] = new LinesClass(CurrentBars[0]-Strength, 'S', Round2Tick(lastSwingHighValue));
				}
//				if(SwingLowPlot.IsValidDataPoint(0) && SwingLowPlot.IsValidDataPoint(1) && SwingLowPlot[1] != SwingLowPlot[0]){
				if(SwingLowPlot.IsValidDataPoint(1)){
					if(L < SwingLowPlot[1])
						ELines[CurrentBars[0]] = new LinesClass(CurrentBars[0], 'L', Round2Tick(Highs[0][1]));
//					else if(isSwingLow)
//						SwingLines[CurrentBars[0]] = new LinesClass(CurrentBars[0]-Strength, 'L', Round2Tick(lastSwingLowValue));
				}
				var keys = SwingLines.Where(k=>k.Value.EndABar == int.MaxValue).Select(k=>k.Key).ToList();
				if(keys!=null){
					for(int i = 0; i<keys.Count; i++){
						var k = keys[i];//k is the id of the line
//						if(SwingLines[k].Type=='L' && SwingLines[k].Price == currentSwingLow) SwingLines[k].StartABar = CurrentBars[0];//advance startabar when the swing lows continue to print on that price level
//						if(SwingLines[k].Type=='S' && SwingLines[k].Price == currentSwingHigh) SwingLines[k].StartABar = CurrentBars[0];//advance startabar when the swing highs continue to print on that price level
						if(pSwingLineTerminationBasis == ARCSwingSweep_LineTerminationBiases.OnTouch){
							if(SwingLines[k].Type=='L' && L < SwingLines[k].Price){
								SwingLines[k].BreakABar = CurrentBars[0];
								SwingLines[k].EndABar = CurrentBars[0];
								ELines[CurrentBars[0]] = new LinesClass(CurrentBars[0], 'L', H);
							}
							else if(SwingLines[k].Type=='S' && H > SwingLines[k].Price){
								SwingLines[k].BreakABar = CurrentBars[0];
								SwingLines[k].EndABar = CurrentBars[0];
								ELines[CurrentBars[0]] = new LinesClass(CurrentBars[0], 'S', L);
							}
						}else{
							if(SwingLines[k].Type=='L' && Closes[0][0] > SwingLines[k].Price){
								SwingLines[k].BreakABar = CurrentBars[0];
								SwingLines[k].EndABar = CurrentBars[0];
								ELines[CurrentBars[0]] = new LinesClass(CurrentBars[0], 'L', H);
							}
							else if(SwingLines[k].Type=='S' && Closes[0][0] < SwingLines[k].Price){
								SwingLines[k].BreakABar = CurrentBars[0];
								SwingLines[k].EndABar = CurrentBars[0];
								ELines[CurrentBars[0]] = new LinesClass(CurrentBars[0], 'S', L);
							}
						}
					}
				}
				keys = ELines.Where(k=>k.Value.EndABar == int.MaxValue).Select(k=>k.Key).ToList();
				if(keys!=null){
					for(int i = 0; i<keys.Count; i++){
						var k = keys[i];//k is the StartABar of the line
						if(k==CurrentBars[0]) continue;
						if(ELines[k].StartABar + pEntryLineLengthBars < CurrentBars[0]){
							ELines[k].BreakABar = CurrentBars[0];
							ELines[k].EndABar = CurrentBars[0];
						}
						else if(ELines[k].Type=='L' && H > ELines[k].Price)      ELines[k].Broken(CurrentBars[0]);
						else if(ELines[k].Type=='S' && L < ELines[k].Price) ELines[k].Broken(CurrentBars[0]);
					}
				}
			}
		}
//==============================================================================================
		private SharpDX.Direct2D1.Brush BuyELBrushDX = null;
		private SharpDX.Direct2D1.Brush SellELBrushDX = null;
		public override void OnRenderTargetChanged()
		{
			if(BuyELBrushDX!=null   && !BuyELBrushDX.IsDisposed)    {BuyELBrushDX.Dispose();   BuyELBrushDX=null;}
			if(RenderTarget!=null) BuyELBrushDX = BuyLine_Stroke.Brush.ToDxBrush(RenderTarget);

			if(SellELBrushDX!=null   && !SellELBrushDX.IsDisposed)    {SellELBrushDX.Dispose();   SellELBrushDX=null;}
			if(RenderTarget!=null) SellELBrushDX = SellLine_Stroke.Brush.ToDxBrush(RenderTarget);
		}
		SharpDX.RectangleF labelRect;
		SharpDX.DirectWrite.TextLayout txtLayout = null;
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
			if(pShowSwingPlots)
				base.OnRender(chartControl, chartScale);
			int kv = 0;
			float y = 0;
			float xL = 0;
			float xR = 0;
			var txtFormat = pFont.ToDirectWriteTextFormat();
			var keys = ELines.Where(k=> k.Value.Price > chartScale.MinValue && k.Value.Price < chartScale.MaxValue && k.Value.EndABar > ChartBars.FromIndex && k.Value.StartABar < ChartBars.ToIndex).Select(k=>k.Key).ToList();
			if(keys!=null){
				for(int i = 0; i<keys.Count; i++){
					kv = keys[i];
					y = chartScale.GetYByValue(ELines[kv].Price);
					xL = ChartControl.GetXByBarIndex(ChartBars, ELines[kv].StartABar);
					xR = ChartControl.GetXByBarIndex(ChartBars, ELines[kv].EndABar==int.MaxValue ? CurrentBars[0]:ELines[kv].EndABar);
					if(ELines[kv].Type=='L'){
						RenderTarget.DrawLine(new SharpDX.Vector2(xL, y), new SharpDX.Vector2(xR, y), BuyELBrushDX, BuyLine_Stroke.Width);
						if(pShowEntryLineText && ELines[kv].EndABar==int.MaxValue){
							var msg = string.Format("Entry at {0}",Instrument.MasterInstrument.FormatPrice(ELines[kv].Price));
							txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, txtFormat, ChartPanel.X + ChartPanel.W, txtFormat.FontSize);
							labelRect = new SharpDX.RectangleF(xR+10f, y-txtLayout.Metrics.Height/2f, txtLayout.Metrics.Width, Convert.ToSingle(pFont.Size));
							RenderTarget.DrawText(msg, txtFormat, labelRect, BuyELBrushDX);
						}
					}else{
						RenderTarget.DrawLine(new SharpDX.Vector2(xL, y), new SharpDX.Vector2(xR, y), SellELBrushDX, SellLine_Stroke.Width);
						if(pShowEntryLineText && ELines[kv].EndABar==int.MaxValue){
							var msg = string.Format("Entry at {0}",Instrument.MasterInstrument.FormatPrice(ELines[kv].Price));
							txtLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, txtFormat, ChartPanel.X + ChartPanel.W, txtFormat.FontSize);
							labelRect = new SharpDX.RectangleF(xR+10f, y-txtLayout.Metrics.Height/2f, txtLayout.Metrics.Width, Convert.ToSingle(pFont.Size));
							RenderTarget.DrawText(msg, txtFormat, labelRect, SellELBrushDX);
						}
					}
				}
			}
			if(pShowSwingLines){
				keys = SwingLines.Where(k=> k.Value.Price > chartScale.MinValue && k.Value.Price < chartScale.MaxValue && k.Value.EndABar > ChartBars.FromIndex && k.Value.StartABar < ChartBars.ToIndex).Select(k=>k.Key).ToList();
//				keys = SwingLines.Where(k=> k.Value.EndABar > ChartBars.FromIndex && k.Value.StartABar < ChartBars.ToIndex).Select(k=>k.Key).ToList();
				if(keys!=null){
					for(int i = 0; i<keys.Count; i++){
						kv = keys[i];
						y = chartScale.GetYByValue(SwingLines[kv].Price);
						xL = ChartControl.GetXByBarIndex(ChartBars, SwingLines[kv].StartABar);
						xR = ChartControl.GetXByBarIndex(ChartBars, SwingLines[kv].EndABar==int.MaxValue ? CurrentBars[0]:SwingLines[kv].EndABar);
						RenderTarget.DrawLine(new SharpDX.Vector2(xL, y), new SharpDX.Vector2(xR, y), Plots[SwingLines[kv].Type=='L' ?1:0].BrushDX, Convert.ToSingle(Plots[SwingLines[kv].Type=='L' ?1:0].Pen.Thickness));
					}
				}
			}
		}
//==============================================================================================

		#region Functions
		/// <summary>
		/// Returns the number of bars ago a swing low occurred. Returns a value of -1 if a swing low is not found within the look back period.
		/// </summary>
		/// <param name="barsAgo"></param>
		/// <param name="instance"></param>
		/// <param name="lookBackPeriod"></param>
		/// <returns></returns>
		public int ARCSwingSweepLowBar(int barsAgo, int instance, int lookBackPeriod)
		{
			if (instance < 1)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.SwingSwingLowBarInstanceGreaterEqual, GetType().Name, instance));
			if (barsAgo < 0)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.SwingSwingLowBarBarsAgoGreaterEqual, GetType().Name, barsAgo));
			if (barsAgo >= Count)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.SwingSwingLowBarBarsAgoOutOfRange, GetType().Name, (Count - 1), barsAgo));

			Update();

			for (int idx=CurrentBar - barsAgo - Strength; idx >= CurrentBar - barsAgo - Strength - lookBackPeriod; idx--)
			{
				if (idx < 0)
					return -1;
				if (idx >= swingLowSwings.Count)
					continue;

				if (swingLowSwings.GetValueAt(idx).Equals(0.0))
					continue;

				if (instance == 1) // 1-based, < to be save
					return CurrentBar - idx;

				instance--;
			}

			return -1;
		}

		/// <summary>
		/// Returns the number of bars ago a swing high occurred. Returns a value of -1 if a swing high is not found within the look back period.
		/// </summary>
		/// <param name="barsAgo"></param>
		/// <param name="instance"></param>
		/// <param name="lookBackPeriod"></param>
		/// <returns></returns>
		public int ARCSwingSweepHighBar(int barsAgo, int instance, int lookBackPeriod)
		{
			if (instance < 1)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.SwingSwingHighBarInstanceGreaterEqual, GetType().Name, instance));
			if (barsAgo < 0)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.SwingSwingHighBarBarsAgoGreaterEqual, GetType().Name, barsAgo));
			if (barsAgo >= Count)
				throw new Exception(string.Format(NinjaTrader.Custom.Resource.SwingSwingHighBarBarsAgoOutOfRange, GetType().Name, (Count - 1), barsAgo));

			Update();

			for (int idx=CurrentBar - barsAgo - Strength; idx >= CurrentBar - barsAgo - Strength - lookBackPeriod; idx--)
			{
				if (idx < 0)
					return -1;
				if (idx >= swingHighSwings.Count)
					continue;

				if (swingHighSwings.GetValueAt(idx).Equals(0.0))
					continue;

				if (instance <= 1) // 1-based, < to be save
					return CurrentBar - idx;

				instance--;
			}

			return -1;
		}
		#endregion

		#region Properties
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Order = 10, Name = "Strength", GroupName = "Parameters", ResourceType = typeof(Custom.Resource))]
		public int Strength
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Order = 20, Name = "Swing Termination Basis", GroupName = "Parameters", ResourceType = typeof(Custom.Resource))]
		public ARCSwingSweep_LineTerminationBiases pSwingLineTerminationBasis
		{get;set;}

//		[NinjaScriptProperty]
//		[Display(Order = 5, Name = "Termination Basis", GroupName = "Entry Lines", ResourceType = typeof(Custom.Resource))]
//		public ARCSwingSweep_LineTerminationBiases pEntryLineTerminationBasis
//		{get;set;}

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Order = 10, Name = "Max age (in bars)", GroupName = "Entry Lines", Description="Entry levels will self-terminate after these number of bars have occurred", ResourceType = typeof(Custom.Resource))]
		public int pEntryLineLengthBars
		{ get; set; }

		[Display(Order = 20, Name = "Buy Brush", GroupName = "Entry Lines", ResourceType = typeof(Custom.Resource))]
		public Stroke BuyLine_Stroke { get; set; }

		[Display(Order = 30, Name = "Sell Brush", GroupName = "Entry Lines", ResourceType = typeof(Custom.Resource))]
		public Stroke SellLine_Stroke { get; set; }
		
		[Display(Order = 40, Name = "Entry font", GroupName = "Entry Lines", ResourceType = typeof(Custom.Resource))]
		public NinjaTrader.Gui.Tools.SimpleFont pFont
		{get;set;}

		[Display(Order = 10, Name = "Show Swing plots?", GroupName = "General Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pShowSwingPlots
		{get;set;}

		[Display(Order = 20, Name = "Show Swing lines?", GroupName = "General Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pShowSwingLines
		{get;set;}

		[Display(Order = 30, Name = "Show Entry text?", GroupName = "General Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pShowEntryLineText
		{get;set;}
		#endregion
		
		#region -- Plots --
		/// <summary>
		/// Gets the high swings.
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> SwingSweepHigh
		{
			get
			{
				Update();
				return swingHighSeries;
			}
		}

		private Series<double> SwingHighPlot
		{
			get
			{
				Update();
				return Values[0];
			}
		}

		/// <summary>
		/// Gets the low swings.
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> SwingSweepLow
		{
			get
			{
				Update();
				return swingLowSeries;
			}
		}

		private Series<double> SwingLowPlot
		{
			get
			{
				Update();
				return Values[1];
			}
		}
		#endregion
	}
}
public enum ARCSwingSweep_LineTerminationBiases {OnTouch, CloseAcross}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_SwingSweep[] cacheARC_SwingSweep;
		public ARC.ARC_SwingSweep ARC_SwingSweep(int strength, ARCSwingSweep_LineTerminationBiases pSwingLineTerminationBasis, int pEntryLineLengthBars)
		{
			return ARC_SwingSweep(Input, strength, pSwingLineTerminationBasis, pEntryLineLengthBars);
		}

		public ARC.ARC_SwingSweep ARC_SwingSweep(ISeries<double> input, int strength, ARCSwingSweep_LineTerminationBiases pSwingLineTerminationBasis, int pEntryLineLengthBars)
		{
			if (cacheARC_SwingSweep != null)
				for (int idx = 0; idx < cacheARC_SwingSweep.Length; idx++)
					if (cacheARC_SwingSweep[idx] != null && cacheARC_SwingSweep[idx].Strength == strength && cacheARC_SwingSweep[idx].pSwingLineTerminationBasis == pSwingLineTerminationBasis && cacheARC_SwingSweep[idx].pEntryLineLengthBars == pEntryLineLengthBars && cacheARC_SwingSweep[idx].EqualsInput(input))
						return cacheARC_SwingSweep[idx];
			return CacheIndicator<ARC.ARC_SwingSweep>(new ARC.ARC_SwingSweep(){ Strength = strength, pSwingLineTerminationBasis = pSwingLineTerminationBasis, pEntryLineLengthBars = pEntryLineLengthBars }, input, ref cacheARC_SwingSweep);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_SwingSweep ARC_SwingSweep(int strength, ARCSwingSweep_LineTerminationBiases pSwingLineTerminationBasis, int pEntryLineLengthBars)
		{
			return indicator.ARC_SwingSweep(Input, strength, pSwingLineTerminationBasis, pEntryLineLengthBars);
		}

		public Indicators.ARC.ARC_SwingSweep ARC_SwingSweep(ISeries<double> input , int strength, ARCSwingSweep_LineTerminationBiases pSwingLineTerminationBasis, int pEntryLineLengthBars)
		{
			return indicator.ARC_SwingSweep(input, strength, pSwingLineTerminationBasis, pEntryLineLengthBars);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_SwingSweep ARC_SwingSweep(int strength, ARCSwingSweep_LineTerminationBiases pSwingLineTerminationBasis, int pEntryLineLengthBars)
		{
			return indicator.ARC_SwingSweep(Input, strength, pSwingLineTerminationBasis, pEntryLineLengthBars);
		}

		public Indicators.ARC.ARC_SwingSweep ARC_SwingSweep(ISeries<double> input , int strength, ARCSwingSweep_LineTerminationBiases pSwingLineTerminationBasis, int pEntryLineLengthBars)
		{
			return indicator.ARC_SwingSweep(input, strength, pSwingLineTerminationBasis, pEntryLineLengthBars);
		}
	}
}

#endregion
