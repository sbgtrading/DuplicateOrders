#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region Category Order
    [Gui.CategoryOrder("General Settings", 0)]
    [Gui.CategoryOrder("Trend Line Settings", 1)]
    [Gui.CategoryOrder("Oscillator Settings", 2)]
    [Gui.CategoryOrder("HTF Settings", 3)]
    [Gui.CategoryOrder("Display Settings", 4)]
    [Gui.CategoryOrder("Indicator Version", 5)]
    #endregion

    public class ARCOscTLBreak : Indicator, ICustomTypeDescriptor
    {
		bool IsDebug = false;
		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "OscTLBreak";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "25410", "27405"};//27405 is Annual Membership

        #region Indicators, Series and Floating Variables
        private string _sThisName = "ARC_OscTLBreak";

        //Indicators
        private RSI _indRsi;
        //private CCI _indCci;
        //private ROC _indRoc;
        private MACD _indMacd;
        //private Stochastics _indStochastics;
        //private AroonOscillator _indArronOsc;
        private MFI _indMfi;
        //private NinjaTrader.NinjaScript.Indicators.NeuroStreet.NS_VMLean _indVmLean; // for indicator name you will insert the name that you'll find in the indicator code at the beggining of the code "public class indicatorName{"

        //Series
        //Floating Variables
        //int
        //double
        //bool
        private bool _bIsToolBarButtonAdded = false;
        //string
        private string _sToolbarName = "NSOSCTLToolBar", uID;
        //other
        private List<Depth> _lDepths = new List<Depth>();
        private PropertiesPack propertiesPack;

        //indis for VmLean Calculations
        private MACD _indMacdDefault;
        private MACD _indMacd1;
        private MACD _indMacd2;
        private MACD _indMacd3;
        private MACD _indMacd4;

        //MACD

        private StdDev _indStdDev;

        private int _iFastMacd1 = 8;
        private int _iSlowMacd1 = 20;
        private int _iSmoothMacd1 = 20;

        private int _iFastMacd2 = 10;
        private int _iSlowMacd2 = 20;
        private int _iSmoothMacd2 = 20;

        private int _iFastMacd3 = 20;
        private int _iSlowMacd3 = 60;
        private int _iSmoothMacd3 = 20;

        private int _iFastMacd4 = 60;
        private int _iSlowMacd4 = 240;
        private int _iSmoothMacd4 = 20;

        private ATR _indAtrVmLean; //avgTrueRange
        private int _iAtrPeriod = 256;
        private SMA _indSmaVmLean; //ExcursionSeries
        private int _iSmaPeriodVmLean = 65;

        private HtfPlotStorage CalculateOscillator;
        #endregion

        #region Controls Variables
        private Menu _mnuControlContainer = null;
        private Grid _grdIndyToolbar;
        private Dictionary<string, MenuItem> _dicMenuItems = new Dictionary<string, MenuItem>();
        private Dictionary<string, TextBox> _dicTextBoxes = new Dictionary<string, TextBox>();
        private Dictionary<string, Button> _dicButtons = new Dictionary<string, Button>();
        #endregion

        #region On State Change
        protected override void OnStateChange()
        {
            #region Set Defaults
            if (State == State.SetDefaults)
            {
                #region Default Crap
                Description = @"";
                Name = _sThisName;
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = false;
                DrawVerticalGridLines = false;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                //Disable this property if your indicator requires custom values that cumulate with each new market data event. 
                //See Help Guide for additional information.
                IsSuspendedWhileInactive = false;
                #endregion

                #region Indicator Settings

                #region HTF Settings
                useHtf = false;
                htft = "Minute";
                htfp = 1;
                pBXTSize = 8;
                pBXTOffset = 4;
                pBXTReverse = 14;

                #endregion

                #region ZigZag Settings
                ShowZigZag = true;
                ShowSmall = false;
                SmallSwingStrength = 5;
                SmallSensitivity = 0.0;
                ZigZagFiltering = true;

                ZigZagMidLineMacd = 0;
                ZigZagMidLineRsi = 50;
                ZigZagMidLineMfi = 50;
                ZigZagMidLineVmLean = 0;
                //SmallBreakMultiple = 1;
                ZigZagColor = new Stroke(Brushes.Black, DashStyleHelper.Solid, 2);

                #endregion

                #region Indicators Settings

                ChooseIndi = "RSI";
                UseMacdPlot = "MACD";
                UseRsiPlot = "RSI";
                UseVmLeanPlot = "Histogram";
                //UseStochasticsPlot = "D";

                //MACD
                FastMacd = 12;
                SlowMacd = 26;
                SmoothMacd = 8;
                ObMacd = 0.5;
                OsMacd = -0.5;
                MidLineMacd = 0;

                ////Stochastics
                //PeriodDStoch = 7;
                //PeriodKStoch = 14;
                //SmoothStoch = 3;
                //ObStochastic = 80;
                //OsStochastic = 20;
                //MidLineStochastic = 50;

                //RSI
                PeriodRSI = 7;
                SmoothRSI = 3;
                ObRsi = 70;
                OsRsi = 30;
                MidLineRsi = 50;


                ////CCI
                //PeriodCCI = 14;
                //ObCci = 100;
                //OsCci = -100;
                //MidLineCci = 0;


                ////Aroon
                //PeriodAroon = 14;
                //ObAroon = 50;
                //OsAroon = -50;
                //MidLineAroon = 0;

                ////ROC
                //PeriodROC = 14;
                //ObRoc = 0.5;
                //OsRoc = -0.5;
                //MidLineRoc = 0;


                //MFI
                PeriodMFI = 50;
                ObMfi = 80;
                OsMfi = 20;
                MidLineMfi = 50;

                //VmLean
                StdDevNumberVmLean = 1; //parameter
                FastMacdDefaulVmLeant = 12; //parameter
                SlowMacdDefaultVmLean = 26; //parameter
                BandPeriodVmLean = 10; //parameter
                ObVmLean = 2.5;
                OsVmLean = -2.5;
                MidLineVmLean = 0;


                #endregion

                #region Trend Line Settings
                SwingsBackNo = 1;
                //DT DB Settings
                //IncludeDtDb = true;
                //DtDbDeviation = 5;
                //Zero Line filter
                UseZeroLineFilter = true;
                //MidLine = 0;
                //OB&OS Levels
                LeftPointObOsFilter = true;
                RightPointNoObOsFilter = true;
                //UseObOsFilter = true;
                //ObOsPoints = "Both";
                //Overbought = 0;
                //Oversold = 0;
                //Buffer Zone
                MacdBufferSize = 0.3;
                //StochasticsBufferSize = 5;
                RsiBufferSize = 3;
                //CciBufferSize = 5;
                //AroonBufferSize = 5;
                //RocBufferSize = 0.02;
                MfiBufferSize = 3;
                VmLeanBufferSize = 1;
                //Break Point threshold
                UseThresholdFilter = true;

                //MACD
                MacdBreakPointThresholdUpMax = 1;
                MacdBreakPointThresholdUpMin = 0;
                MacdBreakPointThresholdDownMax = 0;
                MacdBreakPointThresholdDownMin = -1;
                ////Stochastics
                //StochasticsBreakPointThresholdUp = 70;
                //StochasticsBreakPointThresholdDown = 30;
                //Rsi
                RsiBreakPointThresholdUpMax = 70;
                RsiBreakPointThresholdUpMin = 40;
                RsiBreakPointThresholdDownMax = 60;
                RsiBreakPointThresholdDownMin = 30;
                ////CCI
                //CciBreakPointThresholdUp = 80;
                //CciBreakPointThresholdDown = -80;
                ////Aroon
                //AroonBreakPointThresholdUp = 30;
                //AroonBreakPointThresholdDown = -30;
                ////ROC
                //RocBreakPointThresholdUp = 0.2;
                //RocBreakPointThresholdDown = -0.2;
                //MFI
                MfiBreakPointThresholdUpMax = 70;
                MfiBreakPointThresholdUpMin = 40;
                MfiBreakPointThresholdDownMax = 60;
                MfiBreakPointThresholdDownMin = 30;
                //VmLean
                VmLeanBreakPointThresholdUpMax = 1;
                VmLeanBreakPointThresholdUpMin = 0;
                VmLeanBreakPointThresholdDownMax = 0;
                VmLeanBreakPointThresholdDownMin = -1;

                TouchesNo = 2;
                #endregion

                #region Display Defaults
                ShowLongDivergence = true;
                ShowShortDivergence = true;
                ViewOnlyLastDivergence = false;
                showTriangle = true; //triangles = arrows
                TriangleTickDeviation = 3;
                #endregion

                #region Display Settings
                RegularBearish = new Stroke(Brushes.Red, DashStyleHelper.Solid, 2);
                RegularBullish = new Stroke(Brushes.Blue, DashStyleHelper.Solid, 2);

                ButtonText = "Osc TLB";
                #endregion

                //Plots Color
                ObLinePlotColor = Brushes.Maroon;
                OsLinePlotColor = Brushes.DarkBlue;
                MidLinePlotColor = Brushes.Black;

                #endregion

                #region Plots
                AddPlot(new Stroke(Brushes.Yellow, DashStyleHelper.Solid, 2), PlotStyle.Line, "Oscillator");
                //MACD
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Solid, 1), 0.5, "MACD OB");
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Solid, 1), -0.5, "MACD OS");
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Dash, 1), 0, "MACD Midline");

                //RSI
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Solid, 1), 70, "RSI OB");
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Solid, 1), 30, "RSI OS");
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Dash, 1), 50, "RSI Midline");

                //MFI
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Solid, 1), 80, "MFI OB");
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Solid, 1), 20, "MFI OS");
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Dash, 1), 0, "MFI Midline");

                //VmLean
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Solid, 1), 2.5, "VmLean OB");
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Solid, 1), -2.5, "VmLean OS");
                AddLine(new Stroke(Brushes.Transparent, DashStyleHelper.Dash, 1), 0, "VmLean Midline");

                #endregion
            }
            #endregion

            #region Other States
            else if (State == State.Configure)
            {
				IsDebug = System.IO.File.Exists(@"c:\222222222222.txt");
				IsDebug = IsDebug && (NinjaTrader.Cbi.License.MachineId.CompareTo("1E53E271B82EC62C7C03A15C336229AE")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion

                if (useHtf)
                {
                    if (htft.Contains("Renko BXT"))
                    {
                        try
                        {
                            AddDataSeries(new BarsPeriod { BarsPeriodType = (BarsPeriodType)16005, Value = pBXTSize, Value2 = pBXTOffset, BaseBarsPeriodValue = pBXTReverse });//NS_RenkoBXT
                        }
                        catch (Exception e)
                        {
                            Print("Cannot add NS_RenkoBXT!");
                            try
                            {
                                AddDataSeries(new BarsPeriod { BarsPeriodType = (BarsPeriodType)19875, Value = pBXTSize, Value2 = pBXTOffset, BaseBarsPeriodValue = pBXTReverse });//ARC_RenkoBXT
                            }
                            catch (Exception ee)
                            {
                                {
                                    Print("Cannot add ARC_RenkoBXT!");
                                }
                            }
                        }
                    }
                    else if (htft.Contains("Renko"))
                    {
                        AddRenko(Instrument.FullName, htfp, MarketDataType.Last);
                    }
                    else
                        AddDataSeries(gbpt(htft), htfp);
                }
            }
            else if (State == State.DataLoaded)
            {
                CalculateOscillator = new HtfPlotStorage();

                _lDepths.Add(new Depth(SmallSwingStrength, SmallSensitivity, eDepthType.Small, MIN(Values[0], SmallSwingStrength), MAX(Values[0], SmallSwingStrength),
                    TickSize, ATR(BarsArray[useHtf ? 1 : 0], 256))
                { ShowDepth = ShowSmall });
                //Indicators
                _indMacd = MACD(BarsArray[useHtf ? 1 : 0], FastMacd, SlowMacd, SmoothMacd);
                //_indStochastics = Stochastics(BarsArray[useHtf ? 1 : 0], PeriodDStoch, PeriodKStoch, SmoothStoch);
                _indRsi = RSI(BarsArray[useHtf ? 1 : 0], PeriodRSI, SmoothRSI);
                //_indCci = CCI(BarsArray[useHtf ? 1 : 0], PeriodCCI);
                //_indArronOsc = AroonOscillator(BarsArray[useHtf ? 1 : 0], PeriodAroon);
                //_indRoc = ROC(BarsArray[useHtf ? 1 : 0], PeriodROC);
                _indMfi = MFI(BarsArray[useHtf ? 1 : 0], PeriodMFI);
                //_indVmLean = NS_VMLean(OptimizeSpeed, BandPeriod, Fast, Slow, StdDevNumber, SwingStrength, MultiplierMD, MultiplierDTB);
                propertiesPack = new PropertiesPack()
                {
                    ChooseIndi = ChooseIndi,
                    FastMacd = FastMacd,
                    MidLine = AssignVariables(ChooseIndi, 2),
                    Overbought = AssignVariables(ChooseIndi, 0),
                    Oversold = AssignVariables(ChooseIndi, 1),
                    Increment = AssignVariables(ChooseIndi, 7),
                    //add assignvariables function for increment and then add it to addtottoolbar
                    //PeriodAroon = PeriodAroon,
                    //PeriodCCI = PeriodCCI,
                    //PeriodDStoch = PeriodDStoch,
                    //PeriodKStoch = PeriodKStoch,
                    //PeriodROC = PeriodROC,
                    PeriodRSI = PeriodRSI,
                    RegularBearish = RegularBearish,
                    RegularBullish = RegularBullish,
                    ShowSmall = ShowSmall,
                    showTriangle = showTriangle,
                    SlowMacd = SlowMacd,
                    SmallSensitivity = SmallSensitivity,
                    SmallSwingStrength = SmallSwingStrength,
                    SmoothMacd = SmoothMacd,
                    SmoothRSI = SmoothRSI,
                    //SmoothStoch = SmoothStoch,
                    SwingsBackNo = SwingsBackNo,
                    TriangleTickDeviation = TriangleTickDeviation,
                    UseMacdPlot = UseMacdPlot,
                    LeftPointObOsFilter = LeftPointObOsFilter,
                    RightPointNoObOsFilter = RightPointNoObOsFilter,
                    UseRsiPlot = UseRsiPlot,
                    //UseStochasticsPlot = UseStochasticsPlot,
                    UseZeroLineFilter = UseZeroLineFilter,
                    ViewOnlyLastDivergence = ViewOnlyLastDivergence,
                    tickSize = TickSize,
                    PeriodMFI = PeriodMFI,
                    StdDevNumberVmLean = StdDevNumberVmLean,
                    BandPeriodVmLean = BandPeriodVmLean,
                    FastMacdDefaulVmLeant = FastMacdDefaulVmLeant,
                    SlowMacdDefaultVmLean = SlowMacdDefaultVmLean,
                    UseVmLeanPlot = UseVmLeanPlot,
                    ShowZigZag = ShowZigZag,
                    ZigZagColor = ZigZagColor,
                    ShowLongDivergence = ShowLongDivergence,
                    ShowShortDivergence = ShowShortDivergence,
                    BufferSize = AssignVariables(ChooseIndi, 3),
                    BreakPointThresholdUpMax = AssignVariables(ChooseIndi, 4),
                    BreakPointThresholdDownMax = AssignVariables(ChooseIndi, 5),
                    BreakPointThresholdUpMin = AssignVariables(ChooseIndi, 8),
                    BreakPointThresholdDownMin = AssignVariables(ChooseIndi, 9),
                    UseThresholdFilter = UseThresholdFilter,
                    TouchesNo = TouchesNo,
                    ZigZagFiltering = ZigZagFiltering,
                    MidLineZigZag = AssignVariables(ChooseIndi, 6)

                };
                
                Lines[0].Brush = (ChooseIndi == "MACD") ? ObLinePlotColor : Brushes.Transparent;
                Lines[1].Brush = (ChooseIndi == "MACD") ? OsLinePlotColor : Brushes.Transparent;
                Lines[2].Brush = (ChooseIndi == "MACD") ? MidLinePlotColor : Brushes.Transparent;

                Lines[3].Brush = (ChooseIndi == "RSI") ? ObLinePlotColor : Brushes.Transparent;
                Lines[4].Brush = (ChooseIndi == "RSI") ? OsLinePlotColor : Brushes.Transparent;
                Lines[5].Brush = (ChooseIndi == "RSI") ? MidLinePlotColor : Brushes.Transparent;

                Lines[6].Brush = (ChooseIndi == "MFI") ? ObLinePlotColor : Brushes.Transparent;
                Lines[7].Brush = (ChooseIndi == "MFI") ? OsLinePlotColor : Brushes.Transparent;
                Lines[8].Brush = (ChooseIndi == "MFI") ? MidLinePlotColor : Brushes.Transparent;

                Lines[9].Brush = (ChooseIndi == "VmLean") ? ObLinePlotColor : Brushes.Transparent;
                Lines[10].Brush = (ChooseIndi == "VmLean") ? OsLinePlotColor : Brushes.Transparent;
                Lines[11].Brush = (ChooseIndi == "VmLean") ? MidLinePlotColor : Brushes.Transparent;

                //indicators need for VmLean
                _indMacdDefault = MACD(BarsArray[useHtf ? 1 : 0], FastMacdDefaulVmLeant, SlowMacdDefaultVmLean, BandPeriodVmLean);//macd line and signal line
                _indStdDev = StdDev(_indMacdDefault.Default, BandPeriodVmLean);
                _indMacd1 = MACD(BarsArray[useHtf ? 1 : 0], _iFastMacd1, _iSlowMacd1, _iSmoothMacd1); //histogram
                _indMacd2 = MACD(BarsArray[useHtf ? 1 : 0], _iFastMacd2, _iSlowMacd2, _iSmoothMacd2); //histogram
                _indMacd3 = MACD(BarsArray[useHtf ? 1 : 0], _iFastMacd3, _iSlowMacd3, _iSmoothMacd3); //histogram
                _indMacd4 = MACD(BarsArray[useHtf ? 1 : 0], _iFastMacd4, _iSlowMacd4, _iSmoothMacd4); //histogram
                _indAtrVmLean = ATR(BarsArray[useHtf ? 1 : 0], _iAtrPeriod);
                _indSmaVmLean = SMA(_indAtrVmLean, _iSmaPeriodVmLean);
            }
            else if (State == State.Historical)
            {
                uID = Guid.NewGuid().ToString().Replace("-", string.Empty);
                AddToToolBar();
            }
            else if (State == State.Terminated)
            {
                RemoveFromToolBar();
            }
            #endregion
        }
        #endregion

        #region On Bar Update
        protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if (CurrentBar < 50 || _lDepths.Count == 0) return;

            int x = useHtf || Calculate == Calculate.OnBarClose || (State != State.Realtime && !IsTickReplays[0].Value) ? 0 : 1;
            int xCTF = Calculate == Calculate.OnBarClose || (State != State.Realtime && !IsTickReplays[0].Value) ? 0 : 1;
            if (BarsInProgress == (useHtf ? 1 : 0))
            {

                CalculateOscillator[IsFirstTickOfBar ? -1 : 0] = CalcIndicatorPlot(x);
                //zigzag calculation
                for (int i = 0; i < _lDepths.Count; i++)
                {
                    Depth p = _lDepths[i];
                    p.Search(this, CurrentBar, CurrentBars[0], Time[x], CalcIndicatorPlot(x), CalcIndicatorPlot(x+1), true, x, Time, propertiesPack, CalculateOscillator);
                }
            }
            if (BarsInProgress == 0)
            {
                OscillatorPlot[xCTF] = CalculateOscillator[0];
            }
        }
        #endregion

        #region Objects

        #region Calculate VmLean
        private double VmLeanCalculation(bool histogramBBLine, int index) //bool histogramBBLine = true if histogram is selected
        {
            #region Potential code - other VmLean Calculations
            //Calculations
            //MACD BB Calculatiosn
            //Average[0] = _indMacdDefault.Avg[0];//BMACD_AVG
            //Upper[0] = _indMacdDefault.Avg[0] + _dStdDevNumber * _indStdDev[0];//BMACD_AVG + StdDevNumber * SDBB
            //Lower[0] = _indMacdDefault.Avg[0] - _dStdDevNumber * _indStdDev[0];
            #endregion

            double res = 0;
            if (histogramBBLine)
                res = _indMacd1.Diff[index] + _indMacd2.Diff[index] + _indMacd3.Diff[index] + _indMacd4.Diff[index];
            else
                res = _indMacdDefault.Default[index];
            return res;
        }
        #endregion

        #region Button Regions

        #region State Functions

        #region Remove From ToolBar
        private void RemoveFromToolBar()
        {
            if (_grdIndyToolbar != null)
            {
                Action p = () =>
                {
                    Chart chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;

                    chartWindow.MainMenu.Remove(_grdIndyToolbar);
                    _grdIndyToolbar = null;

                    chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
                    chartWindow = null;

                    _bIsToolBarButtonAdded = false;
                };
                GeneralInvokeAction(p);
            }
        }
        #endregion

        #region Add To ToolBar
        private void AddToToolBar()
        {
            if (!_bIsToolBarButtonAdded && ChartControl != null)
            {
                Action p = () =>
                {
                    #region Initial SetUp
                    Chart chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                    if (chartWindow == null) return;

                    foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (ButtonText + uID)) _bIsToolBarButtonAdded = true;

                    _grdIndyToolbar = new Grid { Visibility = Visibility.Collapsed };

                    _mnuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
                    MenuItem MenuControl = new MenuItem { Name = "MenuControl", BorderThickness = new Thickness(2), BorderBrush = Brushes.Orange, Header = ButtonText, Foreground = Brushes.Orange, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
                    _dicMenuItems.Add(MenuControl.Name, MenuControl);
                    _mnuControlContainer.Items.Add(MenuControl);
                    #endregion

                    #region Divergence Options
                    string headItem = "miOSCTrendLineOptions";
                    AddMenuItem("Osc TLB Options", headItem, Brushes.Black, null, MenuControl);
                    //AddMenuItem("Include DT&DB " + (IncludeDtDb ? "ON" : "OFF"), "btGeneral_IncludeDtDb" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    //_dicMenuItems[headItem].Items.Add(createUpDownMenu(DtDbDeviation.ToString(), DtDbDeviation, "btDtDbDeviation", "DT&DB Deviation: "));

                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(AssignVariables(ChooseIndi, 3).ToString(), AssignVariables(ChooseIndi, 3), "btBufferSize", "Buffer Size: ", AssignVariables(ChooseIndi, 7), 0));

                    AddMenuItem("Use Threshold Filter " + (UseThresholdFilter ? "ON" : "OFF"), "btGeneral_UseThresholdFilter" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(AssignVariables(ChooseIndi, 4).ToString(), AssignVariables(ChooseIndi, 4), "btThresholdUpMax", "Long Threshold Break Point - Max: ", AssignVariables(ChooseIndi, 7), double.MinValue));
                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(AssignVariables(ChooseIndi, 8).ToString(), AssignVariables(ChooseIndi, 8), "btThresholdUpMin", "Long Threshold Break Point - Min: ", AssignVariables(ChooseIndi, 7), double.MinValue));
                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(AssignVariables(ChooseIndi, 5).ToString(), AssignVariables(ChooseIndi, 5), "btThresholdDownMax", "Short Threshold Break Point - Max: ", AssignVariables(ChooseIndi, 7), double.MinValue));
                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(AssignVariables(ChooseIndi, 9).ToString(), AssignVariables(ChooseIndi, 9), "btThresholdDownMin", "Short Threshold Break Point - Min: ", AssignVariables(ChooseIndi, 7), double.MinValue));


                    AddMenuItem("Use MidLine Filter " + (UseZeroLineFilter ? "ON" : "OFF"), "btGeneral_UseMidLineFilter" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(AssignVariables(ChooseIndi, 2).ToString(), AssignVariables(ChooseIndi, 2), "btMidLineLevel", "Mid Line Level: ", AssignVariables(ChooseIndi, 7), double.MinValue));

                    //AddMenuItem("Use OB/ OS Filter " + (UseObOsFilter ? "ON" : "OFF"), "btGeneral_UseObOsFilter" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Use OB/ OS Filter - Left Point " + (LeftPointObOsFilter ? "ON" : "OFF"), "btGeneral_LeftPointObOsFilter" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Use OB/ OS Filter - Right Point" + (RightPointNoObOsFilter ? "ON" : "OFF"), "btGeneral_RightPointNoObOsFilter" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);

                    //_dicMenuItems[headItem].Items.Add(createUpDownMenu(Overbought.ToString(), Overbought, "btObLevel", "OB Level: "));
                    //_dicMenuItems[headItem].Items.Add(createUpDownMenu(Oversold.ToString(), Oversold, "btOsLevel", "OS Level: "));

                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(AssignVariables(ChooseIndi, 0).ToString(), AssignVariables(ChooseIndi, 0), "btObLevel", "OB Level: ", AssignVariables(ChooseIndi, 7), double.MinValue));
                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(AssignVariables(ChooseIndi, 1).ToString(), AssignVariables(ChooseIndi, 1), "btOsLevel", "OS Level: ", AssignVariables(ChooseIndi, 7), double.MinValue));


                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(SwingsBackNo.ToString(), SwingsBackNo, "btMaxSwingsBack", "Max.Swings Back: ", 1, 1));

                    AddMenuItem("View Only Last Trend Line " + (ViewOnlyLastDivergence ? "ON" : "OFF"), "btGeneral_ViewOnlyLastDivergence" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Long Trend Line  " + (ShowLongDivergence ? "ON" : "OFF"), "btGeneral_ShowLongDivergence" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Short Trend Line  " + (ShowShortDivergence ? "ON" : "OFF"), "btGeneral_ShowShortDivergence" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Show Arrows " + (showTriangle ? "ON" : "OFF"), "btGeneral_ShowTriangles" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    #endregion

                    #region Swing Parameters
                    headItem = "miSwingsParameters";
                    AddMenuItem("Swing Trend Parameters", headItem, Brushes.Black, null, MenuControl);

                    AddMenuItem("ShowZigZag " + (ShowZigZag ? "ON" : "OFF"), "btSwingSettings_ShowZigZag" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(SmallSwingStrength.ToString(), SmallSwingStrength, "btSwingStrength", "Swing Strength: ", 1, 1));
                    //_dicMenuItems[headItem].Items.Add(createUpDownMenu(SmallSensitivity.ToString(), SmallSensitivity, "btSwingSensitivity", "Swing Sensitivity"));
                    AddMenuItem("ZigZag Filtering " + (ZigZagFiltering ? "ON" : "OFF"), "btSwingSettings_ZigZagFiltering" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    _dicMenuItems[headItem].Items.Add(createUpDownMenu(AssignVariables(ChooseIndi, 6).ToString(), AssignVariables(ChooseIndi, 6), "btZigZagMidLine", "ZigZag MidLine: ", AssignVariables(ChooseIndi, 7), double.MinValue));

                    #endregion

                    #region Oscillator Settings
                    //headItem = "miOscillatorSettings";
                    //AddMenuItem("Oscillator Settings", headItem, Brushes.Black, null, MenuControl);

                    //choose oscillator - dropdown menu  - NEEDS TO BE DONE
                    //AddMenuItem("- - -", "btGeneral_Lines0" + uID, Brushes.Black, General_Click, _dicMenuItems[headItem], false); - if we need it
                    #endregion

                    AddMenuItem("RE-CALCULATE Osc TLB", "btTradePlan_Recalculate_General" + uID, Brushes.Black, General_Click, MenuControl, true, false);

                    #region Subscribe to Tab Control
                    _grdIndyToolbar.Children.Add(_mnuControlContainer);

                    chartWindow.MainMenu.Add(_grdIndyToolbar);
                    chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                    foreach (TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) _grdIndyToolbar.Visibility = Visibility.Visible;
                    AutomationProperties.SetAutomationId(_grdIndyToolbar, _sToolbarName + uID);
                    #endregion
                };
                GeneralInvokeAction(p);
            }
        }
        #endregion

        #endregion

        #region Control Functions

        #region Add Menu Item
        private void AddMenuItem(string Header, string Name, Brush TextBrush, RoutedEventHandler EventHandler, MenuItem Parent = null, bool Editable = true, bool StayOpenOnClick = true)
        {
            MenuItem item = new MenuItem { Header = Header, Name = Name, Foreground = TextBrush, StaysOpenOnClick = StayOpenOnClick, FontWeight = FontWeights.Normal };
            item.IsEnabled = Editable;
            if (EventHandler != null)
                item.Click += EventHandler;
            if (Parent != null)
                Parent.Items.Add(item);
            _dicMenuItems.Add(item.Name, item);
        }
        #endregion

        #region Create UpDown Menu
        //Function taken from NS VM Lean and needs to be updated to standards after christmas
        private Grid createUpDownMenu(string nudValue1, double value, string id, string content, double increment, double minValue)
        {
            const int rHeight = 26;

            Button gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "+", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            Button gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "-", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            Label gLabel = new Label();//#RJBug001

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(55) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = content };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            TextBox nudMST1 = new TextBox() { Name = id + uID, MinWidth = 60, Width = 60, MaxWidth = 60, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST1.Text = nudValue1;
            nudMST1.KeyDown += menuTxtbox_KeyDown;
            nudMST1.TextChanged += NumericUpDownTextChanged;
            nudMST1.MouseWheel += delegate (object o, MouseWheelEventArgs e)
            {
                e.Handled = true;
                if (e.Delta >= 0) Math.Round(value += increment, 1);
                else Math.Round(value -= increment, 1);
                value = Math.Max(minValue, value);
                nudMST1.Text = value.ToString("#0.#");
                InformUserAboutRecalculation();
                ForceRefresh();
            };
            nudMST1.SetValue(Grid.ColumnProperty, 1);
            nudMST1.SetValue(Grid.RowProperty, 0);
            nudMST1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = "Up" + id + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = "Dn" + id + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += UpDownButton_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += UpDownButton_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);

            _dicTextBoxes.Add(nudMST1.Name, nudMST1);
            _dicButtons.Add(cmdup1.Name, cmdup1);
            _dicButtons.Add(cmddw1.Name, cmddw1);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMST1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            //UpdateTextBoxEnable(); - nu cred ca ne  mai trebuie

            return grid;
        }
        #endregion

        #endregion

        #region Event Handlers

        #region General_Click
        private void General_Click(object sender, EventArgs e)
        {
            bool invalidateVisual = false;
            MenuItem item = sender as MenuItem;
            switch (item.Name.Substring(0, item.Name.Length - uID.Length))
            {
                //case "btGeneral_IncludeDtDb":
                //    IncludeDtDb = !IncludeDtDb;
                //    propertiesPack.IncludeDtDb = IncludeDtDb;
                //    item.Header = "Include DT&DB " + (propertiesPack.IncludeDtDb ? "ON" : "OFF");
                //    invalidateVisual = true;
                //    InformUserAboutRecalculation();
                //    break;
                case "btGeneral_UseThresholdFilter":
                    UseThresholdFilter = !UseThresholdFilter;
                    propertiesPack.UseThresholdFilter = UseThresholdFilter;
                    item.Header = "Use Threshold Filter " + (propertiesPack.UseThresholdFilter ? "ON" : "OFF");
                    invalidateVisual = true;
                    InformUserAboutRecalculation();
                    break;
                case "btGeneral_UseMidLineFilter":
                    UseZeroLineFilter = !UseZeroLineFilter;
                    propertiesPack.UseZeroLineFilter = UseZeroLineFilter;
                    item.Header = "Use MidLine Filter " + (propertiesPack.UseZeroLineFilter ? "ON" : "OFF");
                    invalidateVisual = true;
                    InformUserAboutRecalculation();
                    break;
                //case "btGeneral_UseObOsFilter":
                //    UseObOsFilter = !UseObOsFilter;
                //    propertiesPack.UseObOsFilter = UseObOsFilter;
                //    item.Header = "Use OB/ OS Filter " + (propertiesPack.UseObOsFilter ? "ON" : "OFF");
                //    invalidateVisual = true;
                //    InformUserAboutRecalculation();
                //    break;
                case "btGeneral_LeftPointObOsFilter":
                    LeftPointObOsFilter = !LeftPointObOsFilter;
                    propertiesPack.LeftPointObOsFilter = LeftPointObOsFilter;
                    item.Header = "Use OB/ OS Filter - Left Point " + (propertiesPack.LeftPointObOsFilter ? "ON" : "OFF");
                    invalidateVisual = true;
                    InformUserAboutRecalculation();
                    break;
                case "btGeneral_RightPointNoObOsFilter":
                    RightPointNoObOsFilter = !RightPointNoObOsFilter;
                    propertiesPack.RightPointNoObOsFilter = RightPointNoObOsFilter;
                    item.Header = "Use OB/ OS Filter - Right Point " + (propertiesPack.RightPointNoObOsFilter ? "ON" : "OFF");
                    invalidateVisual = true;
                    InformUserAboutRecalculation();
                    break;
                case "btGeneral_ShowLongDivergence": ShowLongDivergence = !ShowLongDivergence; propertiesPack.ShowLongDivergence = ShowLongDivergence; item.Header = "Show Long Trend Line " + (propertiesPack.ShowLongDivergence ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ShowShortDivergence": ShowShortDivergence = !ShowShortDivergence; propertiesPack.ShowShortDivergence = ShowShortDivergence; item.Header = "Show Short Trend Line " + (propertiesPack.ShowShortDivergence ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ViewOnlyLastDivergence": ViewOnlyLastDivergence = !ViewOnlyLastDivergence; propertiesPack.ViewOnlyLastDivergence = ViewOnlyLastDivergence; item.Header = "View Only Last Trend Line " + (propertiesPack.ViewOnlyLastDivergence ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ShowTriangles": showTriangle = !showTriangle; propertiesPack.showTriangle = showTriangle; item.Header = "Show Arrows " + (propertiesPack.showTriangle ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btTradePlan_Recalculate_General":
                    System.Windows.Forms.SendKeys.SendWait("{F5}");
                    break;
                case "btSwingSettings_ShowZigZag":
                    ShowZigZag = !ShowZigZag;
                    propertiesPack.ShowZigZag = ShowZigZag;
                    item.Header = "ShowZigZag " + (propertiesPack.ShowZigZag ? "ON" : "OFF");
                    invalidateVisual = true;
                    InformUserAboutRecalculation();
                    break;
                case "btSwingSettings_ZigZagFiltering":
                    ZigZagFiltering = !ZigZagFiltering;
                    propertiesPack.ZigZagFiltering = ZigZagFiltering;
                    item.Header = "ZigZag Filtering " + (propertiesPack.ZigZagFiltering ? "ON" : "OFF");
                    invalidateVisual = true;
                    InformUserAboutRecalculation();
                    break;
            }
            if (invalidateVisual)
                CCInvokeAction(() =>
                {
                    for (int i = 0; i < _lDepths.Count; i++)
                    {
                        _lDepths[i].ShowHideDivergence(propertiesPack);
                    }
                    ChartControl.InvalidateVisual();
                });
        }
        #endregion

        #region -- DoubleEditKeyPress -- 
        //Function taken from NS VM Lean and needs to be updated to standards after christmas
        private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtSender = sender as TextBox;

            int keyVal = (int)e.Key;
            int value = -1;
            if (keyVal >= (int)Key.D0 && keyVal <= (int)Key.D9) value = keyVal - (int)Key.D0;
            else if (keyVal >= (int)Key.NumPad0 && keyVal <= (int)Key.NumPad9) value = keyVal - (int)Key.NumPad0;

            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);

            if (isNumeric || e.Key == Key.Back || (e.Key == Key.Decimal && _dicTextBoxes.ContainsKey(txtSender.Name)))
            {
                string newText = value != -1 ? value.ToString() : e.Key == Key.Decimal ? System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator : "";
                int tbPosition = txtSender.SelectionStart;
                txtSender.Text = txtSender.SelectedText == "" ? txtSender.Text.Insert(tbPosition, newText) : txtSender.Text.Replace(txtSender.SelectedText, newText);
                txtSender.Select(tbPosition + 1, 0);
            }
        }
        #endregion

        #region Numeric Up Down Text Changed
        private void NumericUpDownTextChanged(object sender, EventArgs e)
        {
            TextBox txtSender = sender as TextBox;
            if (txtSender.Text.Length > 0)
            {
                float result;
                bool isNumeric = float.TryParse(txtSender.Text, out result);

                if (!isNumeric)
                {
                    txtSender.Text = "1";
                    txtSender.Select(txtSender.Text.Length, 0);
                }
                if (_dicTextBoxes.ContainsKey(txtSender.Name))
                {
                    switch (txtSender.Name.Substring(0, txtSender.Name.Length - uID.Length))
                    {
                        //case "btDtDbDeviation": DtDbDeviation = Convert.ToInt32(txtSender.Text); break;
                        case "btBufferSize": ChangeVariablesValues(ChooseIndi, 5, Convert.ToDouble(txtSender.Text)); break;
                        case "btThresholdUpMax": ChangeVariablesValues(ChooseIndi, 3, Convert.ToDouble(txtSender.Text)); break;
                        case "btThresholdUpMin": ChangeVariablesValues(ChooseIndi, 7, Convert.ToDouble(txtSender.Text)); break;
                        case "btThresholdDownMax": ChangeVariablesValues(ChooseIndi, 4, Convert.ToDouble(txtSender.Text)); break;
                        case "btThresholdDownMin": ChangeVariablesValues(ChooseIndi, 8, Convert.ToDouble(txtSender.Text)); break;
                        case "btMidLineLevel": ChangeVariablesValues(ChooseIndi, 2, Convert.ToDouble(txtSender.Text)); break;
                        case "btObLevel": ChangeVariablesValues(ChooseIndi, 0, Convert.ToDouble(txtSender.Text)); break;
                        case "btOsLevel": ChangeVariablesValues(ChooseIndi, 1, Convert.ToDouble(txtSender.Text)); break;
                        case "btMaxSwingsBack": SwingsBackNo = Convert.ToInt32(txtSender.Text); break;
                        case "btSwingStrength": SmallSwingStrength = Convert.ToInt32(txtSender.Text); break;
                        case "btSwingSensitivity": SmallSensitivity = Convert.ToInt32(txtSender.Text); break;
                        case "btZigZagMidLine": ChangeVariablesValues(ChooseIndi, 6, Convert.ToDouble(txtSender.Text)); break;
                            //btZigZagMidLine
                    }
                    InformUserAboutRecalculation();
                }
            }
        }
        #endregion

        #region Combo Box Up Down Button Click
        private void UpDownButton_Click(object sender, RoutedEventArgs e)
        {
            Button cmd = sender as Button;
            if (cmd != null && _dicButtons.ContainsKey(cmd.Name))
            {
                string sTextBoxName = cmd.Name.Substring(2);
                int iMinValue = 0;
                if (sTextBoxName.StartsWith("btMaxSwingsBack") || sTextBoxName.StartsWith("btSwingStrength"))
                    iMinValue = 1;
                else if (sTextBoxName.StartsWith("btObLevel") || sTextBoxName.StartsWith("btOsLevel") || sTextBoxName.StartsWith("btThresholdUpMax") || sTextBoxName.StartsWith("btThresholdUpMin") || sTextBoxName.StartsWith("btThresholdDownMax") || sTextBoxName.StartsWith("btThresholdDownMin"))
                    iMinValue = -999999999;
                if (sTextBoxName.StartsWith("btBufferSize"))
                    iMinValue = 0;
                if (_dicTextBoxes.ContainsKey(sTextBoxName))
                {
                    if (cmd.Name.StartsWith("Up"))
                        _dicTextBoxes[sTextBoxName].Text = Math.Min(999999999, Convert.ToDouble(_dicTextBoxes[sTextBoxName].Text) + ((sTextBoxName.StartsWith("btMaxSwingsBack") || sTextBoxName.StartsWith("btSwingStrength")) ? 1 : propertiesPack.Increment)).ToString("#0.#");
                    else if (cmd.Name.StartsWith("Dn"))
                        _dicTextBoxes[sTextBoxName].Text = Math.Max(iMinValue, Convert.ToDouble(_dicTextBoxes[sTextBoxName].Text) - ((sTextBoxName.StartsWith("btMaxSwingsBack") || sTextBoxName.StartsWith("btSwingStrength")) ? 1 : propertiesPack.Increment)).ToString("#0.#");
                }
                InformUserAboutRecalculation();
            }
        }
        #endregion

        #region Tab Selection Changed Handler
        private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && _grdIndyToolbar != null)
                _grdIndyToolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #endregion

        #region Functions

        #region Inform User About Recalculation
        private void InformUserAboutRecalculation()
        {
            //            if (_dicMenuItems.ContainsKey("btTradePlan_Recalculate_General"))
            {
                string name = string.Format("btTradePlan_Recalculate_General{0}", uID);
                _dicMenuItems[name].Background = Brushes.Yellow;
                _dicMenuItems[name].FontWeight = FontWeights.Bold;
                _dicMenuItems[name].FontStyle = FontStyles.Italic;
            }
        }
        #endregion

        #region Invoke Action
        private void CCInvokeAction(Action p)
        {
            if (ChartControl.Dispatcher.CheckAccess())
            {
                p();
            }
            else
            {
                ChartControl.Dispatcher.InvokeAsync(p);
            }
        }
        #endregion

        #region Invoke Action
        private void GeneralInvokeAction(Action p)
        {
            if (Dispatcher.CheckAccess())
            {
                p();
            }
            else
            {
                Dispatcher.InvokeAsync(p);
            }
        }
        #endregion

        #endregion

        #endregion

        #region Classes

        #region HTF Plot Storage
        public class HtfPlotStorage
        {
            private List<double> _lstValues = new List<double>();

            public double MIN(int startIndex, int barsBack)
            {
                double dMin = double.MaxValue;
                int iCount = _lstValues.Count - 1;
                for (int i = startIndex; i < Math.Min(startIndex + barsBack, iCount); i++)
                {
                    dMin = Math.Min(_lstValues[iCount - i], dMin);
                }
                return dMin;
            }
            public double MAX(int startIndex, int barsBack)
            {
                double dMax = double.MinValue;
                int iCount = _lstValues.Count - 1;
                for (int i = startIndex; i < Math.Min(startIndex + barsBack, iCount); i++)
                {
                    dMax = Math.Max(_lstValues[iCount - i], dMax);
                }
                return dMax;
            }

            public double this[int index]
            {
                get
                {
                    if (_lstValues.Count - 1 - index < 0)
                        return 0;
                    return _lstValues[_lstValues.Count - 1 - index];
                }
                set
                {
                    if (index == -1)
                        _lstValues.Add(value);
                    else
                        _lstValues[_lstValues.Count - (index + 1)] = value;
                }
            }
        }
        #endregion

        #region Properties Pack
        public class PropertiesPack
        {
            #region ZigZag Properties

            public bool ShowSmall { get; set; }
            public int SmallSwingStrength { get; set; }
            public double SmallSensitivity { get; set; }
            public bool ShowZigZag { get; set; }
            public Stroke ZigZagColor { get; set; }
            public bool ZigZagFiltering { get; set; }
            public  double MidLineZigZag { get; set;  }
            public double Increment { get; set; }

            #endregion

            #region Indicator Settings
            public string ChooseIndi { get; set; }

            #region MACD
            public int FastMacd { get; set; }
            public int SlowMacd { get; set; }
            public int SmoothMacd { get; set; }
            #endregion

            #region Stochastics
            //public int PeriodDStoch { get; set; }

            //public int PeriodKStoch { get; set; }

            //public int SmoothStoch { get; set; }
            #endregion

            #region RSI
            public int PeriodRSI { get; set; }
            public int SmoothRSI { get; set; }
            #endregion

            #region CCI
            //public int PeriodCCI { get; set; }
            #endregion

            #region Aroon Oscillator
            //public int PeriodAroon { get; set; }
            #endregion

            #region ROC
            //public int PeriodROC { get; set; }
            #endregion

            #region MFI
            public int PeriodMFI { get; set; }
            #endregion

            #region VmLean
            public double StdDevNumberVmLean { get; set; }
            public int FastMacdDefaulVmLeant { get; set; }
            public int SlowMacdDefaultVmLean { get; set; }
            public int BandPeriodVmLean { get; set; }
            #endregion

            #region Plots
            public string UseMacdPlot { get; set; }
            public string UseRsiPlot { get; set; }
            //public string UseStochasticsPlot { get; set; }
            public string UseVmLeanPlot { get; set; }
            #endregion

            #endregion

            #region Trend Line Settings

            public double tickSize { get; set; }

            #region DT/ DB
            //public bool IncludeDtDb { get; set; }
            //public int DtDbDeviation { get; set; }
            #endregion

            #region Zero Filter
            public bool UseZeroLineFilter { get; set; }
            public double MidLine { get; set; }
            #endregion

            #region OB/OS Levels
            //public bool UseObOsFilter { get; set; }
            //public string ObOsPoints { get; set; }
            public bool LeftPointObOsFilter { get; set; }
            public bool RightPointNoObOsFilter { get; set; }
            public double Overbought { get; set; }
            public double Oversold { get; set; }
            public double BufferSize { get; set; }
            public bool UseThresholdFilter { get; set; }
            public double BreakPointThresholdUpMax { get; set; } //Long trades
            public double BreakPointThresholdUpMin { get; set; } //Long trades
            public double BreakPointThresholdDownMax { get; set; } // Short Trades
            public double BreakPointThresholdDownMin { get; set; } // Short Trades

            public int TouchesNo { get; set; }
            #endregion

            #region Peaks
            public int SwingsBackNo { get; set; } //peaks
            public bool ViewOnlyLastDivergence { get; set; }
            #endregion

            #region Display

            public Stroke RegularBearish { get; set; }
            public Stroke RegularBullish { get; set; }
            public double TriangleTickDeviation { get; set; }
            public bool showTriangle { get; set; }
            public bool ShowLongDivergence { get; set; }
            public bool ShowShortDivergence { get; set; }

            #endregion


            #endregion
        }
        #endregion

        #region Class Point
        public class Point : ICloneable
        {
            #region Properties
            public double Price { get; set; }
            public int Bar { get; set; }
            public DateTime Time { get; set; } //TimeSpan
            public bool IsHigh { get; set; }
            public int ConfirmationBar { get; set; } // the bar where the point is confirmed as a new point
            public Tuple<int, double> BarPrice
            {
                get { return new Tuple<int, double>(Bar, Price); }
            }
            #endregion

            #region Compare Points
            public bool IsTheSame(Point point)
            {
                return point.Price == Price && point.Bar == Bar && point.Time == Time && point.IsHigh == IsHigh;
            }
            public bool IsTheSameWithOne(List<Point> points)
            {
                foreach (Point p in points)
                    if (IsTheSame(p))
                        return true;
                return false;
            }
            #endregion

            #region Cloning
            public object Clone()
            {
                return new Point()
                {
                    Price = Price,
                    Bar = Bar,
                    Time = Time,
                    IsHigh = IsHigh,
                    ConfirmationBar = ConfirmationBar,
                };
            }
            #endregion

        }
        #endregion

        #region Class Depth
        public class Depth
        {
            #region Floating Variables
            //int
            private int _iDepth;
            private int _iBarNumber = 0;
            //bool
            private bool _bUpTrend = true;
            //double
            private double _dSensitivity;
            private double currentHigh = 0;
            private double currentLow = 0;
            private double _dTickSize;
            //Other
            private List<Point> _lPointsForOneDepth = new List<Point>();
            private List<Divergence> _lDivergences = new List<Divergence>();
            private eDepthType _eDepthType;
            //de sters urmatoarele 4 stroke-uri
            private Stroke _skRegularBearish = new Stroke(Brushes.Red, DashStyleHelper.Solid, 2);
            private Stroke _skRegularBullish = new Stroke(Brushes.Blue, DashStyleHelper.Solid, 2);
            private Stroke _skHiddenBearish = new Stroke(Brushes.Magenta, DashStyleHelper.Solid, 2);
            private Stroke _skHiddenBullish = new Stroke(Brushes.Aqua, DashStyleHelper.Solid, 2);

            //Indicators
            private NinjaTrader.NinjaScript.Indicators.MIN _indiLowest;
            private NinjaTrader.NinjaScript.Indicators.MAX _indiHighest;
            private NinjaTrader.NinjaScript.Indicators.ATR _indiATR;
            #endregion

            #region Properties
            public bool ShowDepth { get; set; }
            public double LastATR_Value
            {
                get { return _indiATR[0]; }
            }
            public List<Divergence> Divergences
            {
                get { return _lDivergences; }
            }
            public eDepthType DepthType
            {
                get { return _eDepthType; }
            }
            #endregion

            #region Constructor
            public Depth(int Depth, double Sensivity, eDepthType depthT, MIN min, MAX max, double tickSize, ATR atr) //constructor 
            {
                _iDepth = Depth; _eDepthType = depthT;
                _indiLowest = min;
                _indiHighest = max;
                _indiATR = atr;
                _dTickSize = tickSize;
                _dSensitivity = Sensivity;
                //Patterns = new List<PatternBase>();
            }
            #endregion

            #region Public Functions

            //showhide

            #region OB/ OS Checker
            //Left Point Ob/Os & Right Point inside Ob/Os
            private bool CheckObOsPoint(double point, bool dir, bool whichPoint, PropertiesPack properties)//whichPoint = true (LeftPoint) / false RightPoint
            {
                bool result = false;
                if (whichPoint)
                {
                    if (properties.LeftPointObOsFilter)
                    {
                        if (dir ? point > properties.Overbought : point < properties.Oversold) result = true;
                    }
                    else result = true;
                }
                else
                {
                    if (properties.RightPointNoObOsFilter)
                    {
                        if (point < properties.Overbought && point > properties.Oversold) result = true;
                    }
                    else result = true;
                }
                return result;
            }
            #endregion

            #region MidLine Checker
            private bool MidLineChecker(double point1, double point2, bool dir, PropertiesPack properties)//double midLine, , bool midLineFilter)
            {
                bool result = false;
                if (properties.UseZeroLineFilter)
                    result = dir ? (point1 > properties.MidLine && point2 > properties.MidLine) : (point1 < properties.MidLine && point2 < properties.MidLine);
                else
                    result = true;
                return result;
            }
            #endregion

            #region Find Divergence
            public void FindDivergence(Indicator indi, PropertiesPack properties)
            {
                if (_lPointsForOneDepth.Count < 3) return;

                int index = _lPointsForOneDepth.Count - 2;
                int increment = 0;
                bool searchForBullishTrendLine = _lPointsForOneDepth[index].IsHigh;
                for (int i = index - 2; i >= 0; i -= 2)
                {
                    //added for Adjusted line option
                    if (searchForBullishTrendLine && CheckObOsPoint(_lPointsForOneDepth[i].Price, true, true, properties) && CheckObOsPoint(_lPointsForOneDepth[index].Price, true, false, properties)
                        && MidLineChecker(_lPointsForOneDepth[i].Price, _lPointsForOneDepth[index].Price, true, properties))
                    {
                        if (_lPointsForOneDepth[index].Price < _lPointsForOneDepth[i].Price)
                        {
                            SetDivergence(indi, _lPointsForOneDepth[index], _lPointsForOneDepth[i], eDivergnceType.Regular, eSearchFor.High, properties, "Bullish Trend Line", properties.RegularBullish);
                        }
                    }
                    else if (!searchForBullishTrendLine && CheckObOsPoint(_lPointsForOneDepth[i].Price, false, true, properties) && CheckObOsPoint(_lPointsForOneDepth[index].Price, false, false, properties)
                        && MidLineChecker(_lPointsForOneDepth[i].Price, _lPointsForOneDepth[index].Price, false, properties))//regular and hidden BULLISH divergence
                    {
                        if (_lPointsForOneDepth[index].Price > _lPointsForOneDepth[i].Price)
                        {
                            SetDivergence(indi, _lPointsForOneDepth[index], _lPointsForOneDepth[i], eDivergnceType.Hidden, eSearchFor.Low, properties, "Bearish Trend Line", properties.RegularBearish);
                        }
                    }
                    increment++;
                    if (increment == properties.SwingsBackNo) break;
                }
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="indi"></param>
            /// <param name="point1">this is [index] value</param>
            /// <param name="point2">this is the [i] value</param>
            /// <param name="divergnceType"></param>
            private void SetDivergence(Indicator indi, Point point1, Point point2, eDivergnceType divergnceType, eSearchFor searchFor, PropertiesPack properties, string name, Stroke stroke)
            {
                //Drawing Triangle & Line on the chart
                //TriangleBase triangle;
                //if (searchFor == eSearchFor.Low)
                //    triangle = Draw.TriangleUp(indi, name + point2.Bar + point1 + "Triangle", true, point1.Time, point1.Price - properties.TriangleTickDeviation * properties.tickSize, stroke.Brush, true);
                //else
                //    triangle = Draw.TriangleDown(indi, name + point2.Bar + point1 + "Triangle", true, point1.Time, point1.Price + properties.TriangleTickDeviation * properties.tickSize, stroke.Brush, true);
                //NinjaTrader.NinjaScript.DrawingTools.Line line = Draw.Line(indi, name + point2.Bar + point1 + "Line", false,
                //    point2.Time, point2.Price, point1.Time, point1.Price, stroke.Brush, stroke.DashStyleHelper, Convert.ToInt32(stroke.Width), true);
                //Adding the Divergence
                _lDivergences.Add(new Divergence()
                {
                    Point1 = point2.Clone() as Point,
                    Point2 = point1.Clone() as Point,
                    DivergnceType = divergnceType,
                    SerchForHL = searchFor,
                    LineProperties = stroke,
                    PatternFinished = false
                    //Triangle = triangle,
                });
                ShowHideDivergence(properties);
            }
            #endregion

            #region ShowHideDivergence
            public void ShowHideDivergence(PropertiesPack propertiesPack)
            {
                if (_lDivergences.Count > 0)
                {
                    bool hiddenDiv = true;
                    bool regularDiv = true;
                    for (int i = _lDivergences.Count - 1; i >= 0; i--)
                    {
                        if (!(_lDivergences[i].SerchForHL == eSearchFor.Low ? propertiesPack.ShowShortDivergence : propertiesPack.ShowLongDivergence))
                        {
                            _lDivergences[i].Invisible(false);
                            continue;
                        }

                        if (_lDivergences[i].DivergnceType == eDivergnceType.Regular)
                        {
                            _lDivergences[i].Invisible((!propertiesPack.ViewOnlyLastDivergence || regularDiv));
                            regularDiv = false;
                        }

                        if (_lDivergences[i].DivergnceType == eDivergnceType.Hidden)
                        {
                            _lDivergences[i].Invisible((!propertiesPack.ViewOnlyLastDivergence || hiddenDiv));
                            hiddenDiv = false;
                        }

                        if (!propertiesPack.showTriangle)
                            _lDivergences[i].InvisibleTriangle(propertiesPack.showTriangle);
                    }
                }
            }
            #endregion

            #region Draw ZigZag
            public void DrawZigZag(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, ChartBars chartBars, PropertiesPack properties)
            {
                bool regularDivergence = false; //!properties.ShowRegularDiv;
                bool hiddenDivergence = false; //!properties.ShowHiddenDiv;

                if (_lPointsForOneDepth.Count > 0 && properties.ShowZigZag)
                {
                    for (int i = 1; i < _lPointsForOneDepth.Count; i++)
                    {
                        //DrawSharpDX.Line(RenderTarget, chartControl, chartScale, _lPointsForOneDepth[i - 1].Time, _lPointsForOneDepth[i - 1].Price, _lPointsForOneDepth[i].Time, _lPointsForOneDepth[i].Price, properties.ZigZagColor);
                        DrawSharpDX.Line(RenderTarget, chartControl, chartScale, chartBars, _lPointsForOneDepth[i - 1].Time, _lPointsForOneDepth[i - 1].Bar, _lPointsForOneDepth[i - 1].Price, _lPointsForOneDepth[i].Time, _lPointsForOneDepth[i].Bar, _lPointsForOneDepth[i].Price, properties.ZigZagColor);
                    }
                }

                if (_lDivergences.Count > 0)// && properties.ShowDivInIndiPanel)
                {
                    for (int i = _lDivergences.Count - 1; i >= 0; i--)
                    {
                        //if ((properties.ShowRegularDiv && _lDivergences[i].DivergnceType == eDivergnceType.Regular) || (properties.ShowHiddenDiv && _lDivergences[i].DivergnceType == eDivergnceType.Hidden))
                        {
                            if (_lDivergences[i].SerchForHL == eSearchFor.Low ? !properties.ShowShortDivergence : !properties.ShowLongDivergence)
                                continue;

                            if (!properties.ViewOnlyLastDivergence || !(_lDivergences[i].DivergnceType == eDivergnceType.Regular ? regularDivergence : hiddenDivergence))
                            {
                                if (_lDivergences[i].DivergnceType == eDivergnceType.Regular)
                                    regularDivergence = true;
                                if (_lDivergences[i].DivergnceType == eDivergnceType.Hidden)
                                    hiddenDivergence = true;

                                _lDivergences[i].DrawDivergence(RenderTarget, chartControl, chartScale, chartBars, properties);
                            }
                        }
                        if (properties.ViewOnlyLastDivergence && regularDivergence && hiddenDivergence)
                            break;
                    }
                }
            }
            #endregion

            #region Search Points
            public int Search(Indicator indi, int barNo, int ctfBarNo, DateTime time, double value, double value1, bool OnBarClose, int x/*, HtfPlotStorage OscillatorPlot*/, TimeSeries Time, PropertiesPack propertiesPack,
                HtfPlotStorage plotStorage)
            {
                bool _bSameBar = barNo == _iBarNumber;

                if (OnBarClose)
                {
                    if (_bSameBar)
                        return 0;
                }

                _indiATR.Update();

                if (_bSameBar)
                    return 0;
                _iBarNumber = barNo;

                //_indiLowest.Update();
                //_indiHighest.Update();

                bool bFoundNew = false;
                if(Divergences.Count > 0)
                {
                    for(int i = 0; i < Divergences.Count; i++)
                    {
                        if (!Divergences[i].PatternFinished)
                            if (Divergences[i].CheckBreak(indi, barNo, ctfBarNo, time, value, value1, propertiesPack))
                                bFoundNew = true;
                    }
                }

                if(bFoundNew)
                    ShowHideDivergence(propertiesPack);

                double _depth = _indiATR[x] * _dSensitivity;

                double max = plotStorage.MAX(x + 1, propertiesPack.SmallSwingStrength);
                double min = plotStorage.MIN(x + 1, propertiesPack.SmallSwingStrength);

                //bool zigZagFilterCheckerHigh = 
                //bool zigZagFilterCheckerLow =

                bool updateHigh = _bUpTrend && value > currentHigh && (propertiesPack.ZigZagFiltering ? value > propertiesPack.MidLineZigZag : true);
                bool updateLow = !_bUpTrend && value < currentLow && (propertiesPack.ZigZagFiltering ? value < propertiesPack.MidLineZigZag : true);
                //bool addHigh = !_bUpTrend && !(value < currentLow) && value > Math.Max(max, currentLow + _depth);
                //bool addLow = _bUpTrend && !(value > currentHigh) && value < Math.Min(min, currentHigh - _depth);
                bool addHigh = !_bUpTrend && !(value < currentLow) && value > Math.Max(max, currentLow + _depth) && (propertiesPack.ZigZagFiltering ? value > propertiesPack.MidLineZigZag : true);
                bool addLow = _bUpTrend && !(value > currentHigh) && value < Math.Min(min, currentHigh - _depth) && (propertiesPack.ZigZagFiltering ? value < propertiesPack.MidLineZigZag : true);

                if (addHigh)
                {
                    _bUpTrend = true;
                    //currentHigh = _indiHighest[x];
                    currentHigh = plotStorage.MAX(x, propertiesPack.SmallSwingStrength);
                    //CheckLastPointValidity(propertiesPack);
                    _lPointsForOneDepth.Add(new Point() { Bar = barNo - x, Price = currentHigh, Time = time, IsHigh = true });
                    FindDivergence(indi, propertiesPack);
                    return 1; // find div (apelare)
                }
                else if (updateHigh)
                {
                    _bUpTrend = true;
                    currentHigh = value;
                    UpdateListPointValues(0, barNo - x, currentHigh, time);
                    return 2;
                }
                else if (addLow)
                {
                    _bUpTrend = false;
                    //currentLow = _indiLowest[x];
                    currentLow = plotStorage.MIN(x, propertiesPack.SmallSwingStrength);
                    //CheckLastPointValidity(propertiesPack);
                    _lPointsForOneDepth.Add(new Point() { Bar = barNo - x, Price = currentLow, Time = time, IsHigh = false });
                    FindDivergence(indi, propertiesPack);
                    return 1;
                }
                else if (updateLow)
                {
                    _bUpTrend = false;
                    currentLow = value;
                    UpdateListPointValues(0, barNo - x, currentLow, time);
                    return 2;
                }
                //Print(_lPointsForOneDepth.Count);
                //NinjaTrader.Code.Output.Process(_lPointsForOneDepth.Count.ToString(), PrintTo.OutputTab1);

                return 0;
            }
            #endregion

            #endregion

            #region Internal Functions
            private void UpdateListPointValues(int pointBack, int barNoUpd, double priceUpd, DateTime timeUpd)
            {
                int index = _lPointsForOneDepth.Count - 1 - pointBack;
                if (index > 0)
                {
                    _lPointsForOneDepth[index].Bar = barNoUpd;
                    _lPointsForOneDepth[index].Price = priceUpd;
                    _lPointsForOneDepth[index].Time = timeUpd;
                }
            }

            //private void CheckLastPointValidity(PropertiesPack propertiesPack)
            //{
            //    if (_lPointsForOneDepth.Count > 0)
            //    {
            //        int i = _lPointsForOneDepth.Count - 1;
            //        _lPointsForOneDepth[i].IsOscillatorValidLeftPoint = IsPointValid(_lPointsForOneDepth[i].IsHigh, _lPointsForOneDepth[i].Price, true, propertiesPack);
            //        _lPointsForOneDepth[i].IsOscillatorValidRightPoint = IsPointValid(_lPointsForOneDepth[i].IsHigh, _lPointsForOneDepth[i].Price, false, propertiesPack);
            //    }
            //}

            //private bool IsPointValid(bool direction, double value, bool whichPoint, PropertiesPack propertiesPack) //whichPoint = true -> leftPoint/ false -> rightPoint
            //{
            //    if(whichPoint)
            //    {
            //        if (propertiesPack.LeftPointObOsFilter)
            //            return direction ? value > propertiesPack.Overbought : value < propertiesPack.Oversold;
            //    }
            //    else
            //    {
            //        if (propertiesPack.RightPointNoObOsFilter)
            //            return (value < propertiesPack.Overbought && value > propertiesPack.Oversold);

            //    }
            //    return true;
            //}
            #endregion
            // Print(_lPointsForOneDepth.);

        }

        #endregion

        #region Class Divergence 
        public class Divergence
        {
            #region Properties
            public Point Point1 { get; set; }
            public Point Point2 { get; set; }
            public Point StartBufferPoint = null;//{ get; set; }
            public Point EndPoint { get; set; }
            public double EndPrice { get; set; }
            public bool PatternFinished { get; set; }
            public eDivergnceType DivergnceType { get; set; }
            public eSearchFor SerchForHL { get; set; }
            public Stroke LineProperties { get; set; }
            //public TriangleBase Triangle { get; set; }
            public ArrowMarkerBase Arrow { get; set; }
            private int TouchesIncrement = 2;
            private bool _bIsValid = false; //this will check if the ZigZag was detached and out of the buffer zone, once the point 2 (and Line) was drawn
            #endregion

            #region Draw Divergence
            public void DrawDivergence(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, ChartBars chartBars, PropertiesPack properties)
            {
                double LeftPointPrice = Point1.Price;
                DateTime LeftPointTime = Point1.Time;
                int LeftPointBar = Point1.Bar;
                double RightPointPrice = Point2.Price;
                DateTime RightPointTime = Point2.Time;
                int RightPointBar = Point2.Bar;

                if (PatternFinished)
                {
                    RightPointPrice = EndPrice;
                    RightPointTime = EndPoint.Time;
                    RightPointBar = EndPoint.Bar;
                }
                else
                {
                    RightPointPrice = Calc.ThirdPointOnALine(Point1.BarPrice, Point2.BarPrice, chartBars.Bars.Count);
                    RightPointTime = chartBars.Bars.GetTime(chartBars.Bars.Count);
                    RightPointBar = chartBars.Bars.Count;
                }
                //List<Tuple<DateTime, double>> tuples = new List<Tuple<DateTime, double>>() {
                //    new Tuple<DateTime, double>(Point2.Time, Point2.Price + properties.BufferSize),
                //    new Tuple<DateTime, double>(Point2.Time, Point2.Price -  properties.BufferSize),
                //    new Tuple<DateTime, double>(RightPointTime, RightPointPrice - properties.BufferSize),
                //    new Tuple<DateTime, double>(RightPointTime, RightPointPrice + properties.BufferSize),
                if (StartBufferPoint != null)
                {
                    List<Tuple<DateTime, double>> tuples = new List<Tuple<DateTime, double>>() 
                    {
                        new Tuple<DateTime, double>(StartBufferPoint.Time, StartBufferPoint.Price + properties.BufferSize),
                        new Tuple<DateTime, double>(StartBufferPoint.Time, StartBufferPoint.Price -  properties.BufferSize),
                        new Tuple<DateTime, double>(RightPointTime, RightPointPrice - properties.BufferSize),
                        new Tuple<DateTime, double>(RightPointTime, RightPointPrice + properties.BufferSize),
                    };
                    DrawSharpDX.GeometryWithFill(RenderTarget, chartControl, chartScale, tuples, LineProperties, 30, false, true);
                }
                //DrawSharpDX.Line(RenderTarget, chartControl, chartScale, LeftPointTime, LeftPointPrice, RightPointTime, RightPointPrice, LineProperties, !PatternFinished);
                DrawSharpDX.Line(RenderTarget, chartControl, chartScale, chartBars, LeftPointTime, LeftPointBar, LeftPointPrice, RightPointTime, RightPointBar, RightPointPrice, LineProperties, !PatternFinished);

            }
            #endregion

            #region Drawing Tools Visibility
            public void Invisible(bool show)
            {
                //if (Line != null)
                //    Line.IsVisible = show;
                //if (Triangle != null)
                //    Triangle.IsVisible = show;
                if (Arrow != null)
                    Arrow.IsVisible = show;
            }

            //public void InvisibleLine(bool showLine)
            //{
            //    if (Line != null)
            //        Line.IsVisible = showLine;
            //}

            public void InvisibleTriangle(bool showTriangle)
            {
                //if (Triangle != null)
                //    Triangle.IsVisible = showTriangle;
                if (Arrow != null)
                    Arrow.IsVisible = showTriangle;

            }

            public bool CheckBreak(Indicator indi, int barNo, int ctfBarNo, DateTime time, double value, double value1, PropertiesPack propertiesPack)
            {
                double dPrice = Calc.ThirdPointOnALine(Point1.BarPrice, Point2.BarPrice, barNo);
                if(SerchForHL == eSearchFor.Low ? dPrice < (value - propertiesPack.BufferSize) : dPrice > (value + propertiesPack.BufferSize))
                {
                    _bIsValid = true;
                }
                if (SerchForHL == eSearchFor.High ? dPrice < (value - propertiesPack.BufferSize) : dPrice > (value + propertiesPack.BufferSize))
                {
                    EndPrice = dPrice;
                    EndPoint = new Point() { Time = time, Bar = ctfBarNo };
                    PatternFinished = true;

                    if(StartBufferPoint != null && _bIsValid)
                    {
                        string sName = String.Format("{0} Trend Line", SerchForHL == eSearchFor.High ? "Bullish" : "Bearish");

                        //TriangleBase triangle = null;
                        ArrowMarkerBase arrow = null;
                        if (SerchForHL == eSearchFor.High)
                        {
                            if ((propertiesPack.UseThresholdFilter && dPrice + propertiesPack.BufferSize < propertiesPack.BreakPointThresholdUpMax && dPrice - propertiesPack.BufferSize > propertiesPack.BreakPointThresholdUpMin) || !propertiesPack.UseThresholdFilter) // Short Trades
                                //triangle = Draw.TriangleUp(indi, sName + Point2.Bar + Point1 + "Triangle", true, EndTime, indi.BarsArray[0].GetLow(ctfBarNo) - propertiesPack.TriangleTickDeviation * propertiesPack.tickSize, LineProperties.Brush, true);
                                arrow = Draw.ArrowUp(indi, sName + Point2.Bar + Point1 + "ArrowUp", true, ctfBarNo - EndPoint.Bar, indi.BarsArray[0].GetLow(ctfBarNo) - propertiesPack.TriangleTickDeviation * propertiesPack.tickSize, LineProperties.Brush);
                        }
                        else
                        {
                            if ((propertiesPack.UseThresholdFilter && dPrice - propertiesPack.BufferSize > propertiesPack.BreakPointThresholdDownMin && dPrice + propertiesPack.BufferSize < propertiesPack.BreakPointThresholdDownMax) || !propertiesPack.UseThresholdFilter) //Long Trades
                                //triangle = Draw.TriangleDown(indi, sName + Point2.Bar + Point1 + "Triangle", true, EndTime, indi.BarsArray[0].GetHigh(ctfBarNo) + propertiesPack.TriangleTickDeviation * propertiesPack.tickSize, LineProperties.Brush, true);
                                arrow = Draw.ArrowDown(indi, sName + Point2.Bar + Point1 + "ArrowDown", true, ctfBarNo - EndPoint.Bar, indi.BarsArray[0].GetHigh(ctfBarNo) + propertiesPack.TriangleTickDeviation * propertiesPack.tickSize, LineProperties.Brush, true);
                        }
                        //Triangle = triangle;
                        Arrow = arrow;

                    }
                    return true;
                }
                else if(StartBufferPoint == null)
                {
                    double dPrice1 = Calc.ThirdPointOnALine(Point1.BarPrice, Point2.BarPrice, barNo - 1);
                    if ((dPrice1 > (value1 + propertiesPack.BufferSize) || dPrice1 < (value1 - propertiesPack.BufferSize)) && dPrice <= value + propertiesPack.BufferSize && dPrice >= value - propertiesPack.BufferSize)
                        TouchesIncrement++;
                    if (TouchesIncrement >= propertiesPack.TouchesNo)
                    {
                        TouchesIncrement = 2;
                        if(propertiesPack.TouchesNo == 2)
                            StartBufferPoint = Point2;
                        else
                            StartBufferPoint = new Point () { Price = dPrice, Time = time, Bar = barNo };
                    }
                    //if (TouchesIncrement == propertiesPack.TouchesNo+1)
                    //{
                    //    TouchesIncrement = 0;
                    //    EndPrice = dPrice;
                    //    EndTime = time;
                    //    PatternFinished = true;
                    //    return true;
                    //}
                }
                return false;
            }
            #endregion
        }
        #endregion

        #region Enums
        public enum eDepthType
        {
            Small,
            Medium,
            Large
        }
        public enum eDivergnceType
        {
            Regular,
            Hidden
        }
        public enum eSearchFor
        {
            High,
            Low
        }
        #endregion

        #endregion

        #region Static Classes

        #region Draw Sharp DX
        private static class DrawSharpDX
        {
            #region Line
            public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, float x1, float y1, float x2, float y2, Stroke stroke, Tuple<float, float> chartWidthNHeight)
            {
                if (RenderTarget == null || stroke == null || stroke.Brush == Brushes.Transparent || (x1 == x2 && y1 == y2) || !SharpDXUtils.IsLineInChart(x1, y1, x2, y2, chartWidthNHeight))
                    return;

                DrawLine(RenderTarget, new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), stroke);
            }

            public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime time1, double price1, DateTime time2, double price2, Stroke stroke, bool ExtendLineRight = false)
            {
                if (RenderTarget == null || chartControl == null || chartScale == null || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsLineInChart(time1, price1, time2, price2, chartControl, chartScale))
                    return;

                float x1 = chartControl.GetXByTime(time1); float y1 = chartScale.GetYByValue(price1);
                float x2 = chartControl.GetXByTime(time2); float y2 = chartScale.GetYByValue(price2);

                if (ExtendLineRight)
                {
                    float fSlope = Calc.Slope(x1, x2, y1, y2);
                    x2 += 10000;
                    y2 = y1 + (x2 - x1) * fSlope;
                }

                DrawLine(RenderTarget, new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), stroke);
            }

            public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, ChartBars chartBars, DateTime time1, int bar1, double price1, DateTime time2, int bar2, double price2, Stroke stroke, bool ExtendLineRight = false)
            {
                if (RenderTarget == null || chartControl == null || chartScale == null || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsLineInChart(time1, price1, time2, price2, chartControl, chartScale))
                    return;

                float x1 = chartControl.GetXByBarIndex(chartBars, bar1); float y1 = chartScale.GetYByValue(price1);
                float x2 = chartControl.GetXByBarIndex(chartBars, bar2); float y2 = chartScale.GetYByValue(price2);

                if (ExtendLineRight)
                {
                    float fSlope = Calc.Slope(x1, x2, y1, y2);
                    x2 += 10000;
                    y2 = y1 + (x2 - x1) * fSlope;
                }

                DrawLine(RenderTarget, new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), stroke);
            }

            private static void DrawLine(SharpDX.Direct2D1.RenderTarget RenderTarget, SharpDX.Vector2 vector1, SharpDX.Vector2 vector2, Stroke stroke)
            {
                SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                SharpDXUtils.WrapInAntiAlias(RenderTarget, () => { RenderTarget.DrawLine(vector1, vector2, brs, stroke.Width, stroke.StrokeStyle); });
                brs.Dispose();
            }
            #endregion

            #region Geometry
            public static void GeometryWithFill(SharpDX.Direct2D1.RenderTarget RenderTarget, List<Tuple<float, float>> Points, Stroke stroke, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.AreAnyPointsInChart(Points, chartWidthNHeight))
                    return;

                List<SharpDX.Vector2> points = new List<SharpDX.Vector2>();
                foreach (Tuple<float, float> point in Points)
                    points.Add(new SharpDX.Vector2(point.Item1, point.Item2));

                DrawGeometry(RenderTarget, points, stroke, opacity, outline, background);
            }

            public static void GeometryWithFill(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, List<Tuple<DateTime, double>> Points, Stroke stroke, int opacity, bool outline, bool background)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.AreAnyPointsInChart(Points, chartControl, chartScale))
                    return;

                List<SharpDX.Vector2> points = new List<SharpDX.Vector2>();
                foreach (Tuple<DateTime, double> point in Points)
                    points.Add(new SharpDX.Vector2(chartControl.GetXByTime(point.Item1), chartScale.GetYByValue(point.Item2)));

                DrawGeometry(RenderTarget, points, stroke, opacity, outline, background);
            }

            private static void DrawGeometry(SharpDX.Direct2D1.RenderTarget RenderTarget, List<SharpDX.Vector2> Points, Stroke stroke, int opacity, bool outline, bool background)
            {
                SharpDX.Direct2D1.PathGeometry pathGeometry = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
                SharpDX.Direct2D1.GeometrySink geometrySink = pathGeometry.Open();

                for (int i = 0; i < Points.Count; i++)
                {
                    if (i == 0)
                        geometrySink.BeginFigure(Points[i], SharpDX.Direct2D1.FigureBegin.Filled);
                    else
                        geometrySink.AddLine(Points[i]);
                }
                geometrySink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
                geometrySink.Close();
                SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                if (outline)
                    RenderTarget.DrawGeometry(pathGeometry, brs, stroke.Width, stroke.StrokeStyle);
                if (background)
                {
                    brs.Opacity = opacity / 100f;
                    SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                    {
                        RenderTarget.FillGeometry(pathGeometry, brs);
                    });
                }
                pathGeometry.Dispose(); brs.Dispose(); geometrySink.Dispose();
            }
            #endregion

            #region Box Text
            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, DateTime time, double price, Stroke stroke, int opacity,
                Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Size size = SharpDXUtils.MeasureString(text, TextFont);
                Tuple<float, float> chartWidthNHeight = SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale);
                float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);

                Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, horizontalAlign, verticalAlign, backgroundBrush);
                Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, float x, float y, Stroke stroke, int opacity,
                Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Size size = SharpDXUtils.MeasureString(text, TextFont);
                Tuple<float, float> chartWidthNHeight = SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale);
                Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, horizontalAlign, verticalAlign, backgroundBrush);
                Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Stroke stroke, int opacity, Brush textBrush, SimpleFont TextFont,
                bool outline, bool background, Tuple<float, float> chartWidthNHeight, Brush backgroundBrush = null,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Box(RenderTarget, x, y, width, height, stroke, opacity, outline, background, chartWidthNHeight, horizontalAlign, verticalAlign, backgroundBrush);
                Text(RenderTarget, text, x, y, width, height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }
            #endregion

            #region Box
            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, DateTime topLeftTime, double topLeftPrice, DateTime bottomRightTime, double bottomRightPrice,
                int opacity, bool outline, bool background,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
                    return;

                float x1 = chartControl.GetXByTime(topLeftTime); float y1 = chartScale.GetYByValue(topLeftPrice);
                float x2 = chartControl.GetXByTime(bottomRightTime); float y2 = chartScale.GetYByValue(bottomRightPrice);
                float width = x2 - x1; float height = y2 - y1;

                if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background, horizontalAlign, verticalAlign);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, Tuple<DateTime, double> topLeftPoint, Tuple<DateTime, double> bootomRightPoint,
                int opacity, bool outline, bool background,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
                    return;

                float x1 = chartControl.GetXByTime(topLeftPoint.Item1); float y1 = chartScale.GetYByValue(topLeftPoint.Item2);
                float x2 = chartControl.GetXByTime(bootomRightPoint.Item1); float y2 = chartScale.GetYByValue(bootomRightPoint.Item2);
                float width = x2 - x1; float height = y2 - y1;

                if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background, horizontalAlign, verticalAlign);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, Tuple<float, float> topLeftPoint, Tuple<float, float> bootomRightPoint, int opacity,
                bool outline, bool background,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent ||
                    !SharpDXUtils.IsRectangleInChart(topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawBox(RenderTarget, topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background, horizontalAlign, verticalAlign);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, Stroke stroke, Tuple<float, float> topLeftPoint, Tuple<float, float> bootomRightPoint, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent ||
                    !SharpDXUtils.IsRectangleInChart(topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, chartWidthNHeight))
                    return;

                DrawBox(RenderTarget, topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background, horizontalAlign, verticalAlign);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsRectangleInChart(x, y, width, height, chartWidthNHeight))
                    return;

                DrawBox(RenderTarget, x, y, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush, opacity, outline, background, horizontalAlign, verticalAlign);
            }

            private static void DrawBox(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, Brush backgroundBrush, int opacity, bool outline, bool background,
                SharpDXUtils.HorizontalAlignment horizontalAlign, SharpDXUtils.VerticalAlignment verticalAlign)
            {
                if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Center)
                    x -= width / 2;
                if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Right)
                    x -= width;
                if (verticalAlign == SharpDXUtils.VerticalAlignment.Center)
                    y -= height / 2;
                if (verticalAlign == SharpDXUtils.VerticalAlignment.Bottom)
                    y -= height;
                SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
                if (outline)
                {
                    SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                    SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                    {
                        RenderTarget.DrawRectangle(rect, brs, stroke.Width, stroke.StrokeStyle);
                    });
                    brs.Dispose();
                }
                if (background)
                {
                    SharpDX.Direct2D1.Brush brs = backgroundBrush.ToDxBrush(RenderTarget);
                    brs.Opacity = (float)(opacity * 0.01f);
                    SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                    {
                        RenderTarget.FillRectangle(rect, brs);
                    });
                    brs.Dispose();
                }
            }
            #endregion

            #region Text
            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, DateTime time, double price, Brush textBrush, SimpleFont TextFont,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                if (RenderTarget == null || chartControl == null || chartScale == null || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
                    return;

                float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);
                Size size = SharpDXUtils.MeasureString(text, TextFont);

                if (size.Width == 0 || size.Height == 0 || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawText(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, Brush textBrush, SimpleFont TextFont, Tuple<float, float> chartWidthNHeight,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                if (RenderTarget == null || string.IsNullOrEmpty(text) || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
                    return;
                Size size = SharpDXUtils.MeasureString(text, TextFont);
                if (size.Width == 0 || size.Height == 0 || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, chartWidthNHeight))
                    return;
                DrawText(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Brush textBrush, SimpleFont TextFont, Tuple<float, float> chartWidthNHeight,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                if (RenderTarget == null || string.IsNullOrEmpty(text) || width == 0 || height == 0 || textBrush == null || textBrush == Brushes.Transparent || TextFont == null ||
                    !SharpDXUtils.IsRectangleInChart(x, y, width, height, chartWidthNHeight))
                    return;
                DrawText(RenderTarget, text, x, y, width, height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            private static void DrawText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Brush textBrush, SimpleFont TextFont, SharpDXUtils.HorizontalAlignment horizontalAlign,
                SharpDXUtils.VerticalAlignment verticalAlign, SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment, SharpDX.DirectWrite.TextAlignment textAlignemnt)
            {
                if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Center)
                    x -= width / 2;
                if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Right)
                    x -= width;
                if (verticalAlign == SharpDXUtils.VerticalAlignment.Center)
                    y -= height / 2;
                if (verticalAlign == SharpDXUtils.VerticalAlignment.Bottom)
                    y -= height;
                SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
                SimpleFont fs = new SimpleFont(TextFont.Family.ToString(), TextFont.Size) { Bold = TextFont.Bold, Italic = TextFont.Italic };
                SharpDX.DirectWrite.TextFormat tff = fs.ToDirectWriteTextFormat();
                tff.ParagraphAlignment = paragraphAlignment;
                tff.TextAlignment = textAlignemnt;
                SharpDX.Direct2D1.Brush brs = textBrush.ToDxBrush(RenderTarget);
                SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
                {
                    RenderTarget.DrawText(text, tff, rect, brs, SharpDX.Direct2D1.DrawTextOptions.Clip, SharpDX.Direct2D1.MeasuringMode.Natural);
                });
                tff.Dispose();
                brs.Dispose();
            }
            #endregion
        }
        #endregion

        #region Sharp DX Utils
        public static class SharpDXUtils
        {
            #region Get Chart Width and Height
            public static Tuple<float, float> GetChartWidthNHeight(ChartControl chartControl, ChartScale chartScale)
            {
                return new Tuple<float, float>(chartControl.GetXByTime(chartControl.LastTimePainted), chartScale.GetYByValue(chartScale.MinValue));
            }
            #endregion

            #region Measure String
            public static Size MeasureString(string msg, SimpleFont TextFont)
            {
                if (TextFont == null || string.IsNullOrEmpty(msg))
                    return new Size(0, 0);

                SimpleFont fs = new SimpleFont(TextFont.Family.ToString(), TextFont.Size) { Bold = TextFont.Bold, Italic = TextFont.Italic };
                SharpDX.DirectWrite.TextFormat tff = fs.ToDirectWriteTextFormat();
                using (SharpDX.DirectWrite.TextLayout layout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, tff, 999999, tff.FontSize))
                {
                    tff.Dispose();
                    return new Size(layout.Metrics.Width, layout.Metrics.Height);
                }
            }
            #endregion

            #region Are Any Points iIn Chart
            public static bool AreAnyPointsInChart(List<Tuple<float, float>> points, Tuple<float, float> chartWidthNHeight)
            {
                foreach (Tuple<float, float> point in points)
                    if (IsPointInChart(point.Item1, point.Item2, chartWidthNHeight))
                        return true;
                return false;
            }

            public static bool AreAnyPointsInChart(List<Tuple<DateTime, double>> points, ChartControl chartControl, ChartScale chartScale)
            {
                foreach (Tuple<DateTime, double> point in points)
                    if (IsPointInChart(point.Item1, point.Item2, chartControl, chartScale))
                        return true;
                return false;
            }
            #endregion

            #region Is Line In Chart
            public static bool IsLineInChart(float x1, float y1, float x2, float y2, Tuple<float, float> chartWidthNHeight)
            {
                return IsPointInChart(x1, y1, chartWidthNHeight) || IsPointInChart(x2, y2, chartWidthNHeight);
            }

            public static bool IsLineInChart(DateTime x1, double y1, DateTime x2, double y2, ChartControl chartControl, ChartScale chartScale)
            {
                return IsPointInChart(x1, y1, chartControl, chartScale) || IsPointInChart(x2, y2, chartControl, chartScale);
            }
            #endregion

            #region Is Point In Chart
            public static bool IsPointInChart(float x, float y, Tuple<float, float> chartWidthNHeight)
            {
                return x >= -1 && x <= chartWidthNHeight.Item1 + 1 && y >= -1 && y <= chartWidthNHeight.Item2 + 1;
            }

            public static bool IsPointInChart(DateTime x, double y, ChartControl chartControl, ChartScale chartScale)
            {
                return x.CompareTo(chartControl.FirstTimePainted) >= 0 && x.CompareTo(chartControl.LastTimePainted) <= 0 && y >= chartScale.MinValue && y <= chartScale.MaxValue;
            }
            #endregion

            #region Is Rectangle In Chart
            public static bool IsRectangleInChart(SharpDX.RectangleF rectangle, Tuple<float, float> chartWidthNHeight)
            {
                return IsPointInChart(rectangle.X, rectangle.Y, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y, chartWidthNHeight) ||
                    IsPointInChart(rectangle.X, rectangle.Y + rectangle.Height, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height, chartWidthNHeight);
            }

            public static bool IsRectangleInChart(float x, float y, float width, float height, Tuple<float, float> chartWidthNHeight)
            {
                SharpDX.RectangleF rectangle = new SharpDX.RectangleF(x, y, width, height);
                return IsPointInChart(rectangle.X, rectangle.Y, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y, chartWidthNHeight) ||
                    IsPointInChart(rectangle.X, rectangle.Y + rectangle.Height, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height, chartWidthNHeight);
            }

            public static bool IsRectangleInChart(List<Tuple<DateTime, double>> points, ChartControl chartControl, ChartScale chartScale)
            {
                return AreAnyPointsInChart(points, chartControl, chartScale);
            }

            public static bool IsRectangleInChart(List<Tuple<float, float>> points, Tuple<float, float> chartWidthNHeight)
            {
                return AreAnyPointsInChart(points, chartWidthNHeight);
            }
            #endregion

            #region WrapInAntiAlias
            public static void WrapInAntiAlias(SharpDX.Direct2D1.RenderTarget RenderTarget, Action action)
            {
                SharpDX.Direct2D1.AntialiasMode prev = RenderTarget.AntialiasMode;
                RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
                action();
                RenderTarget.AntialiasMode = prev;
            }
            #endregion

            #region Enums

            #region Horizontal Text Alignment
            public enum HorizontalAlignment
            {
                Center,
                Left,
                Right
            }
            #endregion

            #region Vertical Text Alignment
            public enum VerticalAlignment
            {
                Center,
                Top,
                Bottom
            }
            #endregion

            #endregion
        }
        #endregion

        #region Calculations
        private static class Calc
        {
            #region Line Slope Calculation
            public static double Slope(double x1, double x2, double y1, double y2)
            {
                return (y2 - y1) / (x2 - x1);
            }
            public static float Slope(float x1, float x2, float y1, float y2)
            {
                return (y2 - y1) / (x2 - x1);
            }
            #endregion

            #region Third Point
            public static Tuple<int, double> ThirdPoint(Tuple<int, double> A, Tuple<int, double> B, double slopeA, double slopeB)
            {
                int x = (int)(((slopeA * A.Item1) - A.Item2 - (slopeB * B.Item1) + B.Item2) / (slopeA - slopeB));
                double y = slopeA * (x - A.Item1) + A.Item2;
                return new Tuple<int, double>(x, y);
            }
            public static double ThirdPointOnALine(Tuple<int, double> A, Tuple<int, double> B, int C)
            {
                double dLineSlope = Slope(A.Item1, B.Item1, A.Item2, B.Item2);
                double dResult = A.Item2 + (C - A.Item1) * dLineSlope;
                return dResult;
            }
            #endregion
        }
        #endregion

        #endregion

        #region Default NT Functions

        #region On Render
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            base.OnRender(chartControl, chartScale);
            foreach (Depth depth in _lDepths)
            {
                depth.DrawZigZag(RenderTarget, chartControl, chartScale, ChartBars, propertiesPack);
            }
        }
        #endregion

        #endregion

        #region On Bar Update

        #region HTF Objects

        #region Get Time Frame
        private BarsPeriodType gbpt(string bptt)
        {
            BarsPeriodType bpt = BarsPeriodType.Minute;
            switch (bptt)
            {
                case "Tick": bpt = BarsPeriodType.Tick; break;
                case "Volume": bpt = BarsPeriodType.Volume; break;
                case "Range": bpt = BarsPeriodType.Range; break;
                case "Second": bpt = BarsPeriodType.Second; break;
                case "Minute": bpt = BarsPeriodType.Minute; break;
                case "Day": bpt = BarsPeriodType.Day; break;
                case "Week": bpt = BarsPeriodType.Week; break;
                case "Month": bpt = BarsPeriodType.Month; break;
                case "Year": bpt = BarsPeriodType.Year; break;
                case "HeikenAshi": bpt = BarsPeriodType.HeikenAshi; break;
                case "Kagi": bpt = BarsPeriodType.Kagi; break;
                case "Renko": bpt = BarsPeriodType.Renko; break;
                case "PointAndFigure": bpt = BarsPeriodType.PointAndFigure; break;
                case "LineBreak": bpt = BarsPeriodType.LineBreak; break;
                case "Volumetric": bpt = BarsPeriodType.Volumetric; break;
                case "Renko BXT": bpt = (BarsPeriodType)33760; break;
            }
            return bpt;
        }
        #endregion

        #endregion

        #region Oscillator Plot Calculation
        public double CalcIndicatorPlot(int index)
        {
            switch (ChooseIndi)
            {
                //case "Aroon Oscillator": return _indArronOsc[index];
                //case "CCI": return _indCci[index];
                //case "ROC": return _indRoc[index];
                case "RSI":
                    switch (UseRsiPlot)
                    {
                        case "RSI": return _indRsi.Default[index];
                        case "Avg": return _indRsi.Avg[index];
                    }
                    break;
                //case "Stochastics":
                //    switch (UseStochasticsPlot)
                //    {
                //        case "D": return _indStochastics.D[index];
                //        case "K": return _indStochastics.K[index];
                //    }
                //    break;
                case "MACD":
                    switch (UseMacdPlot)
                    {
                        case "MACD": return _indMacd.Default[index];
                        case "Avg": return _indMacd.Avg[index];
                        case "Diff": return _indMacd.Diff[index];
                    }
                    break;
                case "MFI": return _indMfi[index]; break;
                case "VmLean":
                    switch (UseVmLeanPlot)
                    {
                        case "Histogram": return VmLeanCalculation(true, index);
                        case "BBs": return VmLeanCalculation(false, index);
                    }
                    break;
            }
            return 0;
        }
        #endregion

        #endregion

        #region Assign Ob, Os, MidLine - depending on the indicator
        private double AssignVariables(string ChooseIndi, int Variable)
        {
            switch (ChooseIndi)
            {
                //case "Aroon Oscillator":
                //    switch (Variable)
                //    {
                //        case 0: return ObAroon;
                //        case 1: return OsAroon;
                //        case 2: return MidLineAroon;
                //        case 3: return AroonBufferSize;
                //        case 4: return AroonBreakPointThresholdUp;
                //        case 5: return AroonBreakPointThresholdDown;
                //    }
                //    break;
                //case "CCI":
                //    switch (Variable)
                //    {
                //        case 0: return ObCci;
                //        case 1: return OsCci;
                //        case 2: return MidLineCci;
                //        case 3: return CciBufferSize;
                //        case 4: return CciBreakPointThresholdUp;
                //        case 5: return CciBreakPointThresholdDown;

                //    }
                //    break;
                //case "ROC":
                //    switch (Variable)
                //    {
                //        case 0: return ObRoc;
                //        case 1: return OsRoc;
                //        case 2: return MidLineRoc;
                //        case 3: return RocBufferSize;
                //        case 4: return RocBreakPointThresholdUp;
                //        case 5: return RocBreakPointThresholdDown;

                //    }
                    //break;
                case "RSI":
                    switch (Variable)
                    {
                        case 0: return ObRsi;
                        case 1: return OsRsi;
                        case 2: return MidLineRsi;
                        case 3: return RsiBufferSize;
                        case 4: return RsiBreakPointThresholdUpMax;
                        case 5: return RsiBreakPointThresholdDownMax;
                        case 6: return ZigZagMidLineRsi;
                        case 7: return 1;
                        case 8: return RsiBreakPointThresholdUpMin;
                        case 9: return RsiBreakPointThresholdDownMin;

                    }
                    break;
                //case "Stochastics":
                //    switch (Variable)
                //    {
                //        case 0: return ObStochastic;
                //        case 1: return OsStochastic;
                //        case 2: return MidLineStochastic;
                //        case 3: return StochasticsBufferSize;
                //        case 4: return StochasticsBreakPointThresholdUp;
                //        case 5: return StochasticsBreakPointThresholdDown;

                //    }
                    //break;
                case "MACD":
                    switch (Variable)
                    {
                        case 0: return ObMacd;
                        case 1: return OsMacd;
                        case 2: return MidLineMacd;
                        case 3: return MacdBufferSize;
                        case 4: return MacdBreakPointThresholdUpMax;
                        case 5: return MacdBreakPointThresholdDownMax;
                        case 6: return ZigZagMidLineMacd;
                        case 7: return 0.1;
                        case 8: return MacdBreakPointThresholdUpMin;
                        case 9: return MacdBreakPointThresholdDownMin;

                    }

                    break;
                case "MFI":
                    switch (Variable)
                    {
                        case 0: return ObMfi;
                        case 1: return OsMfi;
                        case 2: return MidLineMfi;
                        case 3: return MfiBufferSize;
                        case 4: return MfiBreakPointThresholdUpMax;
                        case 5: return MfiBreakPointThresholdDownMax;
                        case 6: return ZigZagMidLineMfi;
                        case 7: return 1;
                        case 8: return MfiBreakPointThresholdUpMin;
                        case 9: return MfiBreakPointThresholdDownMin;
                    }
                    break;
                case "VmLean":
                    switch (Variable)
                    {
                        case 0: return ObVmLean;
                        case 1: return OsVmLean;
                        case 2: return MidLineVmLean;
                        case 3: return VmLeanBufferSize;
                        case 4: return VmLeanBreakPointThresholdUpMax;
                        case 5: return VmLeanBreakPointThresholdDownMax;
                        case 6: return ZigZagMidLineVmLean;
                        case 7: return 0.1;
                        case 8: return VmLeanBreakPointThresholdUpMin;
                        case 9: return VmLeanBreakPointThresholdDownMin;
                    }
                    break;
            }
            return 0;
        }

        #endregion

        #region Assign Ob, Os, MidLine - depending on the indicator
        private double ChangeVariablesValues(string ChooseIndi, int Variable, double value)
        {
            switch (ChooseIndi)
            {
                //case "Aroon Oscillator":
                //    switch (Variable)
                //    {
                //        case 0: ObAroon = value; break;
                //        case 1: OsAroon = value; break;
                //        case 2: MidLineAroon = value; break;
                //        case 3: AroonBreakPointThresholdUp = value; break;
                //        case 4: AroonBreakPointThresholdDown = value; break;
                //        case 5: AroonBufferSize = value; break;
                //    }
                //    break;
                //case "CCI":
                //    switch (Variable)
                //    {
                //        case 0: ObCci = value; break;
                //        case 1: OsCci = value; break;
                //        case 2: MidLineCci = value; break;
                //        case 3: CciBreakPointThresholdUp = value; break;
                //        case 4: CciBreakPointThresholdDown = value; break;
                //        case 5: CciBufferSize = value; break;
                //    }
                //    break;
                //case "ROC":
                //    switch (Variable)
                //    {
                //        case 0: ObRoc = value; break;
                //        case 1: OsRoc = value; break;
                //        case 2: MidLineRoc = value; break;
                //        case 3: RocBreakPointThresholdUp = value; break;
                //        case 4: RocBreakPointThresholdDown = value; break;
                //        case 5: RocBufferSize = value; break;
                //    }
                //    break;
                case "RSI":
                    switch (Variable)
                    {
                        case 0: ObRsi = value; break;
                        case 1: OsRsi = value; break;
                        case 2: MidLineRsi = value; break;
                        case 3: RsiBreakPointThresholdUpMax = value; break;
                        case 4: RsiBreakPointThresholdDownMax = value; break;
                        case 5: RsiBufferSize = value; break;
                        case 6: ZigZagMidLineRsi = value; break;
                        case 7: RsiBreakPointThresholdUpMin = value; break;
                        case 8: RsiBreakPointThresholdDownMin = value; break;

                    }
                    break;
                //case "Stochastics":
                //    switch (Variable)
                //    {
                //        case 0: ObStochastic = value; break;
                //        case 1: OsStochastic = value; break;
                //        case 2: MidLineStochastic = value; break;
                //        case 3: StochasticsBreakPointThresholdUp  = value; break;
                //        case 4: StochasticsBreakPointThresholdDown = value; break;
                //        case 5: StochasticsBufferSize = value; break;
                //    }
                //    break;
                case "MACD":
                    switch (Variable)
                    {
                        case 0: ObMacd = value; break;
                        case 1: OsMacd = value; break;
                        case 2: MidLineMacd = value; break;
                        case 3: MacdBreakPointThresholdUpMax = value; break;
                        case 4: MacdBreakPointThresholdDownMax = value; break;
                        case 5: MacdBufferSize = value; break;
                        case 6: ZigZagMidLineMacd = value; break;
                        case 7: MacdBreakPointThresholdUpMin = value; break;
                        case 8: MacdBreakPointThresholdDownMin = value; break;

                    }

                    break;
                case "MFI":
                    switch (Variable)
                    {
                        case 0: ObMfi = value; break;
                        case 1: OsMfi = value; break;
                        case 2: MidLineMfi = value; break;
                        case 3: MfiBreakPointThresholdUpMax = value; break;
                        case 4: MfiBreakPointThresholdDownMax = value; break;
                        case 5: MfiBufferSize = value; break;
                        case 6: ZigZagMidLineMfi = value; break;
                        case 7: MfiBreakPointThresholdUpMin = value; break;
                        case 8: MfiBreakPointThresholdDownMin = value; break;

                    }
                    break;
                case "VmLean":
                    switch (Variable)
                    {
                        case 0: ObVmLean = value; break;
                        case 1: OsVmLean = value; break;
                        case 2: MidLineVmLean = value; break;
                        case 3: VmLeanBreakPointThresholdUpMax = value; break;
                        case 4: VmLeanBreakPointThresholdDownMax = value; break;
                        case 5: VmLeanBufferSize = value; break;
                        case 6: ZigZagMidLineVmLean = value; break;
                        case 7: VmLeanBreakPointThresholdUpMin = value; break;
                        case 8: VmLeanBreakPointThresholdDownMin = value; break;

                    }
                    break;
            }
            return 0;
        }

        #endregion

        #region Properties

        #region SIT - Swing Input Type
        internal class SIT : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "High/ Low", "Close", "Median", "Typical" });
            }
        }
        #endregion

        #region IT - Indicator Type
        internal class IT : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { /*"Aroon Oscillator", "CCI", "ROC", "Stochastics",*/ "RSI", "MACD", "MFI", "VmLean" });
            }
        }
        #endregion

        #region Indicator's Plot Type - string Converter for all indis plots
        //MACD
        internal class MacdPlot : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "MACD", "Avg", "Diff" });
            }
        }
        //Rsi
        internal class RsiPlot : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "RSI", "Avg" });
            }
        }
        ////Stochastics
        //internal class StochasticsPlot : StringConverter
        //{
        //    public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
        //    public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
        //    public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        //    {
        //        return new StandardValuesCollection(new String[] { "D", "K" });
        //    }
        //}
        internal class VmLeanPlot : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Histogram", "BBs" });
            }
        }
        #endregion

        #region TTT (Trading Timefranme Type)
        internal class TTT : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Tick", "Volume", "Range", "Second", "Minute", "Day", "Week", "Month", "Year", "HeikenAshi", "Kagi", "Renko", "PointAndFigure", "LineBreak", "Volumetric", "Renko BXT" });
            }
        }
        #endregion

        #endregion

        #region Override Display Name
        public override string DisplayName { get { return _sThisName; } }
        #endregion

        #endregion

        #region Properties

        #region Outputs

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> OscillatorPlot { get { return Values[0]; } }

        //[Browsable(false)]
        //[XmlIgnore]
        //public Series<double> ObLevel { get { return Values[1]; } }

        //[Browsable(false)]
        //[XmlIgnore]
        //public Series<double> OsLevel { get { return Values[2]; } }

        //[Browsable(false)]
        //[XmlIgnore]
        //public Series<double> Midline { get { return Values[3]; } }


        #endregion

        #region HTF Settings
        [NinjaScriptProperty]
        [Display(Name = "Use HTF", Description = "Use a higher timeframe for calcualtions?", Order = 0, GroupName = "HTF Settings")]
        [RefreshProperties(RefreshProperties.All)]
        public bool useHtf { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "HTF Period Type", Description = "Period type", Order = 10, GroupName = "HTF Settings")]
        [TypeConverter(typeof(TTT))]
        [RefreshProperties(RefreshProperties.All)]
        public string htft { get; set; }

        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "HTF Period", Description = "Period amount", Order = 20, GroupName = "HTF Settings")]
        public int htfp { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "BXT bar Size", GroupName = "HTF Settings", Description = "", Order = 40)]
        public int pBXTSize { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "BXT bar Offset", GroupName = "HTF Settings", Description = "", Order = 50)]
        public int pBXTOffset { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "BXT bar Reversal", GroupName = "HTF Settings", Description = "", Order = 60)]
        public int pBXTReverse { get; set; }

        #endregion

        #region ZigZag Properties

        //[NinjaScriptProperty]
        //[Display(Name = "Input Data for Swings", Description = "", Order = 10, GroupName = "General Settings")]
        //[TypeConverter(typeof(SIT))]
        //[RefreshProperties(RefreshProperties.All)]
        //public string SwingDataInput { get; set; }
        [Browsable(false)]
        [NinjaScriptProperty]
        [Display(Name = "Show Small", Description = "", Order = 30, GroupName = "General Settings")]
        public bool ShowSmall { get; set; } // browsable false

        [NinjaScriptProperty]
        [Display(Name = "Show ZigZag", Description = "", Order = 20, GroupName = "General Settings")]
        [RefreshProperties(RefreshProperties.All)]
        public bool ShowZigZag { get; set; }

        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Swing Strength", Description = "", Order = 31, GroupName = "General Settings")]
        public int SmallSwingStrength { get; set; }

        [Browsable(false)]
        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Swing Sensitivity", Description = "", Order = 32, GroupName = "General Settings")]
        public double SmallSensitivity { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ZigZag Line Properties", Description = "", Order = 40, GroupName = "General Settings")]
        public Stroke ZigZagColor { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ZigZag Filtering", Description = "", Order = 50, GroupName = "General Settings")]
        [RefreshProperties(RefreshProperties.All)]
        public bool ZigZagFiltering { get; set; }

        #region ZigZag MidLine

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Midline Level", Description = "", Order = 140, GroupName = "General Settings")]
        public double ZigZagMidLineMacd { get; set; }

        //[Range(0, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        //public double MidLineStochastic { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Midline Level", Description = "", Order = 140, GroupName = "General Settings")]
        public double ZigZagMidLineRsi { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        //public double MidLineCci { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        //public double MidLineAroon { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        //public double MidLineRoc { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Midline Level", Description = "", Order = 140, GroupName = "General Settings")]
        public double ZigZagMidLineMfi { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Midline Level", Description = "", Order = 140, GroupName = "General Settings")]
        public double ZigZagMidLineVmLean { get; set; }

        #endregion

        #endregion

        #region Indicator Settings

        [NinjaScriptProperty]
        [Display(Name = "Choose Oscillator", Description = "", Order = 10, GroupName = "Oscillator Settings")]
        [TypeConverter(typeof(IT))]
        [RefreshProperties(RefreshProperties.All)]
        public string ChooseIndi { get; set; }

        #region MACD
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Fast", Description = "", Order = 11, GroupName = "Oscillator Settings")]
        public int FastMacd { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Slow", Description = "", Order = 20, GroupName = "Oscillator Settings")]
        public int SlowMacd { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Smooth", Description = "", Order = 30, GroupName = "Oscillator Settings")]
        public int SmoothMacd { get; set; }


        #endregion

        #region Stochastics

        //[Range(0, int.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Period D", Description = "", Order = 40, GroupName = "Oscillator Settings")]
        //public int PeriodDStoch { get; set; }

        //[Range(0, int.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Period K", Description = "", Order = 50, GroupName = "Oscillator Settings")]
        //public int PeriodKStoch { get; set; }

        //[Range(0, int.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Smooth", Description = "", Order = 60, GroupName = "Oscillator Settings")]
        //public int SmoothStoch { get; set; }

        #endregion

        #region RSI

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Period", Description = "", Order = 70, GroupName = "Oscillator Settings")]
        public int PeriodRSI { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Smooth", Description = "", Order = 80, GroupName = "Oscillator Settings")]
        public int SmoothRSI { get; set; }

        #endregion

        #region CCI

        //[Range(0, int.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Period", Description = "", Order = 90, GroupName = "Oscillator Settings")]
        //public int PeriodCCI { get; set; }

        #endregion

        #region Aroon Oscillator
        //[Range(0, int.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Period", Description = "", Order = 100, GroupName = "Oscillator Settings")]
        //public int PeriodAroon { get; set; }
        #endregion

        #region ROC
        //[Range(0, int.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Period", Description = "", Order = 110, GroupName = "Oscillator Settings")]
        //public int PeriodROC { get; set; }
        #endregion

        #region MFI
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Period", Description = "", Order = 120, GroupName = "Oscillator Settings")]
        public int PeriodMFI { get; set; }
        #endregion

        #region VM Lean
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Period Bollinger Band", Description = "", Order = 130, GroupName = "Oscillator Settings")]
        public int BandPeriodVmLean { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Lookback Fast EMA", Description = "", Order = 140, GroupName = "Oscillator Settings")]
        public int FastMacdDefaulVmLeant { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Lookback Slow EMA", Description = "", Order = 150, GroupName = "Oscillator Settings")]
        public int SlowMacdDefaultVmLean { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Standard Deviation Multiplier", Description = "", Order = 151, GroupName = "Oscillator Settings")]
        public double StdDevNumberVmLean { get; set; }

        #endregion

        #region Plots
        [NinjaScriptProperty]
        [Display(Name = "Choose Plot", Description = "", Order = 120, GroupName = "Oscillator Settings")]
        [TypeConverter(typeof(MacdPlot))]
        public string UseMacdPlot { get; set; }


        [NinjaScriptProperty]
        [Display(Name = "Choose Plot", Description = "", Order = 130, GroupName = "Oscillator Settings")]
        [TypeConverter(typeof(RsiPlot))]
        public string UseRsiPlot { get; set; }

        //[NinjaScriptProperty]
        //[Display(Name = "Choose Plot", Description = "", Order = 140, GroupName = "Oscillator Settings")]
        //[TypeConverter(typeof(StochasticsPlot))]
        //public string UseStochasticsPlot { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Choose Plot", Description = "", Order = 150, GroupName = "Oscillator Settings")]
        [TypeConverter(typeof(VmLeanPlot))]
        public string UseVmLeanPlot { get; set; }

        #endregion

        #endregion

        #region Trend Line Settings

        #region Peaks & Touches

        //[NinjaScriptProperty]
        //[Display(Name = "Adjust Divergence Line", Description = "", Order = 0, GroupName = "Divergences Settings")]
        //public bool useAdjustedLine { get; set; }

        //Peaks
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Max. Swings Back", Description = "Description", Order = 10, GroupName = "Trend Line Settings")]
        public int SwingsBackNo { get; set; } //peaks

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "No. of Trend Line Touches", Description = "", Order = 20, GroupName = "Trend Line Settings")]
        public int TouchesNo { get; set; }

        #endregion

        #region Buffer Zones

        //MACD
        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Buffer Zone", Description = "", Order = 25, GroupName = "Trend Line Settings")]
        public double MacdBufferSize { get; set; }
        ////Stochastics
        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Buffer Zone", Description = "", Order = 25, GroupName = "Trend Line Settings")]
        //public double StochasticsBufferSize { get; set; }
        //RSI
        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Buffer Zone", Description = "", Order = 25, GroupName = "Trend Line Settings")]
        public double RsiBufferSize { get; set; }
        ////CCI
        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Buffer Zone", Description = "", Order = 25, GroupName = "Trend Line Settings")]
        //public double CciBufferSize { get; set; }
        ////Aroon
        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Buffer Zone", Description = "", Order = 25, GroupName = "Trend Line Settings")]
        //public double AroonBufferSize { get; set; }
        ////ROC
        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Buffer Zone", Description = "", Order = 25, GroupName = "Trend Line Settings")]
        //public double RocBufferSize { get; set; }
        //MFI
        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Buffer Zone", Description = "", Order = 25, GroupName = "Trend Line Settings")]
        public double MfiBufferSize { get; set; }
        //VmLean
        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Buffer Zone", Description = "", Order = 25, GroupName = "Trend Line Settings")]
        public double VmLeanBufferSize { get; set; }

        #endregion

        #region Zero Filter

        [NinjaScriptProperty]
        [Display(Name = "Use Mid Line Filter", Description = "", Order = 30, GroupName = "Trend Line Settings")]
        [RefreshProperties(RefreshProperties.All)]
        public bool UseZeroLineFilter { get; set; }

        #region MidLine

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        public double MidLineMacd { get; set; }

        //[Range(0, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        //public double MidLineStochastic { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        public double MidLineRsi { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        //public double MidLineCci { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        //public double MidLineAroon { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        //public double MidLineRoc { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        public double MidLineMfi { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Midline Level", Description = "", Order = 40, GroupName = "Trend Line Settings")]
        public double MidLineVmLean { get; set; }


        #endregion

        #endregion

        #region OB/OS Settings

        [NinjaScriptProperty]
        [Display(Name = "Use OB/ OS Filter - Left Point", Description = "", Order = 50, GroupName = "Trend Line Settings")]
        [RefreshProperties(RefreshProperties.All)]
        public bool LeftPointObOsFilter { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use OB/ OS Filter - Right Point", Description = "", Order = 60, GroupName = "Trend Line Settings")]
        [RefreshProperties(RefreshProperties.All)]
        public bool RightPointNoObOsFilter { get; set; }

        #region OB/OS Levels

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "OB Level", Description = "", Order = 70, GroupName = "Trend Line Settings")]
        public double ObMacd { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "OS Level", Description = "", Order = 80, GroupName = "Trend Line Settings")]
        public double OsMacd { get; set; }

        //[Range(0, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "OB Level", Description = "", Order = 70, GroupName = "Trend Line Settings")]
        //public double ObStochastic { get; set; }

        //[Range(0, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "OS Level", Description = "", Order = 80, GroupName = "Trend Line Settings")]
        //public double OsStochastic { get; set; }


        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "OB Level", Description = "", Order = 70, GroupName = "Trend Line Settings")]
        public double ObRsi { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "OS Level", Description = "", Order = 80, GroupName = "Trend Line Settings")]
        public double OsRsi { get; set; }


        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "OB Level", Description = "", Order = 70, GroupName = "Trend Line Settings")]
        //public double ObCci { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "OS Level", Description = "", Order = 80, GroupName = "Trend Line Settings")]
        //public double OsCci { get; set; }


        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "OB Level", Description = "", Order = 70, GroupName = "Trend Line Settings")]
        //public double ObAroon { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "OS Level", Description = "", Order = 80, GroupName = "Trend Line Settings")]
        //public double OsAroon { get; set; }


        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "OB Level", Description = "", Order = 70, GroupName = "Trend Line Settings")]
        //public double ObRoc { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "OS Level", Description = "", Order = 80, GroupName = "Trend Line Settings")]
        //public double OsRoc { get; set; }


        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "OB Level", Description = "", Order = 70, GroupName = "Trend Line Settings")]
        public double ObMfi { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "OS Level", Description = "", Order = 80, GroupName = "Trend Line Settings")]
        public double OsMfi { get; set; }


        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "OB Level", Description = "", Order = 70, GroupName = "Trend Line Settings")]
        public double ObVmLean { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "OS Level", Description = "", Order = 80, GroupName = "Trend Line Settings")]
        public double OsVmLean { get; set; }

        #endregion

        #endregion

        #region Threshold

        [NinjaScriptProperty]
        [Display(Name = "Use Threshold Filter", Description = "", Order = 90, GroupName = "Trend Line Settings")]
        [RefreshProperties(RefreshProperties.All)]
        public bool UseThresholdFilter { get; set; }

        //MACD
        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Long Threshold Break Point - Max", Description = "", Order = 100, GroupName = "Trend Line Settings")]
        public double MacdBreakPointThresholdUpMax { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Long Threshold Break Point - Min", Description = "", Order = 102, GroupName = "Trend Line Settings")]
        public double MacdBreakPointThresholdUpMin { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Short Threshold Break Point - Max", Description = "", Order = 104, GroupName = "Trend Line Settings")]
        public double MacdBreakPointThresholdDownMax { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Short Threshold Break Point - Min", Description = "", Order = 110, GroupName = "Trend Line Settings")]
        public double MacdBreakPointThresholdDownMin { get; set; }

        ////Stochastics
        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Threshold Break Point - Long", Description = "", Order = 100, GroupName = "Trend Line Settings")]
        //public double StochasticsBreakPointThresholdUp { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Threshold Break Point - Short", Description = "", Order = 110, GroupName = "Trend Line Settings")]
        //public double StochasticsBreakPointThresholdDown { get; set; }

        //RSI
        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Long Threshold Break Point - Max", Description = "", Order = 100, GroupName = "Trend Line Settings")]
        public double RsiBreakPointThresholdUpMax { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Long Threshold Break Point - Min", Description = "", Order = 102, GroupName = "Trend Line Settings")]
        public double RsiBreakPointThresholdUpMin { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Short Threshold Break Point - Max", Description = "", Order = 104, GroupName = "Trend Line Settings")]
        public double RsiBreakPointThresholdDownMax { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Short Threshold Break Point - Min", Description = "", Order = 110, GroupName = "Trend Line Settings")]
        public double RsiBreakPointThresholdDownMin { get; set; }

        ////CCI
        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Threshold Break Point - Long", Description = "", Order = 100, GroupName = "Trend Line Settings")]
        //public double CciBreakPointThresholdUp { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Threshold Break Point - Short", Description = "", Order = 110, GroupName = "Trend Line Settings")]
        //public double CciBreakPointThresholdDown { get; set; }

        ////Aroon
        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Threshold Break Point - Long", Description = "", Order = 100, GroupName = "Trend Line Settings")]
        //public double AroonBreakPointThresholdUp { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Threshold Break Point - Short", Description = "", Order = 110, GroupName = "Trend Line Settings")]
        //public double AroonBreakPointThresholdDown { get; set; }

        ////ROC
        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Threshold Break Point - Long", Description = "", Order = 100, GroupName = "Trend Line Settings")]
        //public double RocBreakPointThresholdUp { get; set; }

        //[Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        //[Display(Name = "Threshold Break Point - Short", Description = "", Order = 110, GroupName = "Trend Line Settings")]
        //public double RocBreakPointThresholdDown { get; set; }

        //MFI
        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Long Threshold Break Point - Max", Description = "", Order = 100, GroupName = "Trend Line Settings")]
        public double MfiBreakPointThresholdUpMax { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Long Threshold Break Point - Min", Description = "", Order = 102, GroupName = "Trend Line Settings")]
        public double MfiBreakPointThresholdUpMin { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Short Threshold Break Point - Max", Description = "", Order = 104, GroupName = "Trend Line Settings")]
        public double MfiBreakPointThresholdDownMax { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Short Threshold Break Point - Min", Description = "", Order = 110, GroupName = "Trend Line Settings")]
        public double MfiBreakPointThresholdDownMin { get; set; }

        //VmLean
        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Long Threshold Break Point - Max", Description = "", Order = 100, GroupName = "Trend Line Settings")]
        public double VmLeanBreakPointThresholdUpMax { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Long Threshold Break Point - Min", Description = "", Order = 102, GroupName = "Trend Line Settings")]
        public double VmLeanBreakPointThresholdUpMin { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Short Threshold Break Point - Max", Description = "", Order = 104, GroupName = "Trend Line Settings")]
        public double VmLeanBreakPointThresholdDownMax { get; set; }

        [Range(double.MinValue, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Short Threshold Break Point - Min", Description = "", Order = 110, GroupName = "Trend Line Settings")]
        public double VmLeanBreakPointThresholdDownMin { get; set; }

        #endregion

        #endregion

        #region Display Settings

        [NinjaScriptProperty]
        [Display(Name = "Show Long Trend Lines", Description = "", Order = 10, GroupName = "Display Settings")]
        [RefreshProperties(RefreshProperties.All)]
        public bool ShowLongDivergence { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bullish Trend Line", Description = "", Order = 20, GroupName = "Display Settings")]
        public Stroke RegularBullish { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Short Trend Lines", Description = "", Order = 30, GroupName = "Display Settings")]
        [RefreshProperties(RefreshProperties.All)]
        public bool ShowShortDivergence { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Bearish Trend Line", Description = "", Order = 40, GroupName = "Display Settings")]
        public Stroke RegularBearish { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Arrows", Description = "", Order = 50, GroupName = "Display Settings")]
        [RefreshProperties(RefreshProperties.All)]
        public bool showTriangle { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Arrows Tick Deviation", Description = "", Order = 60, GroupName = "Display Settings")]
        public double TriangleTickDeviation { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "View only last Trend Line", Description = "", Order = 70, GroupName = "Display Settings")]
        public bool ViewOnlyLastDivergence { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Button Text", Description = "", Order = 130, GroupName = "Display Settings")]
        public string ButtonText { get; set; }

        //Plot Line Color
        [XmlIgnore]
        [Display(Name = "Ob Line Color", Description = "", Order = 140, GroupName = "Display Settings")]
        public Brush ObLinePlotColor { get; set; }
        [Browsable(false)]
        public string ObLinePlotColor_ { get { return Serialize.BrushToString(ObLinePlotColor); } set { ObLinePlotColor = Serialize.StringToBrush(value); } }
        
        [XmlIgnore]
        [Display(Name = "Os Line Color", Description = "", Order = 150, GroupName = "Display Settings")]
        public Brush OsLinePlotColor { get; set; }
        [Browsable(false)]
        public string OsLinePlotColor_ { get { return Serialize.BrushToString(OsLinePlotColor); } set { OsLinePlotColor = Serialize.StringToBrush(value); } }
        
        [XmlIgnore]
        [Display(Name = "Midline Color", Description = "", Order = 160, GroupName = "Display Settings")]
        public Brush MidLinePlotColor { get; set; }
        [Browsable(false)]
        public string MidLinePlotColor_ { get { return Serialize.BrushToString(MidLinePlotColor); } set { MidLinePlotColor = Serialize.StringToBrush(value); } }

        #endregion

        #region Indicator Version
        private const string VERSION = "v1.05 07.12.2023";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }
        #endregion

        #endregion

        #region Custom Property Manipulation
        private void ModifyProperties(PropertyDescriptorCollection col)
        {
            #region Hide HTF Settings
            //hide all HTF settings
            col.Remove(col.Find("useHtf", true));
            col.Remove(col.Find("htft", true));
            col.Remove(col.Find("htfp", true));
            col.Remove(col.Find("pBXTSize", true));
            col.Remove(col.Find("pBXTOffset", true));
            col.Remove(col.Find("pBXTReverse", true));
            //
            #endregion

            if (htft.Contains("Renko BXT"))
            {
                col.Remove(col.Find("htfp", true));
            }
            else
            {
                col.Remove(col.Find("pBXTSize", true));
                col.Remove(col.Find("pBXTOffset", true));
                col.Remove(col.Find("pBXTReverse", true));
            }

            if (!showTriangle)
            {
                col.Remove(col.Find("TriangleTickDeviation", true));
            }
            if (!ShowLongDivergence)
            {
                col.Remove(col.Find("RegularBullish", true));
            }
            if (!ShowShortDivergence)
            {
                col.Remove(col.Find("RegularBearish", true));
            }
            if (!ShowZigZag)
            {
                col.Remove(col.Find("SmallSwingStrength", true));
                col.Remove(col.Find("SmallSensitivity", true));
                col.Remove(col.Find("ZigZagColor", true));
            }
            if (!ZigZagFiltering)
            {
                col.Remove(col.Find("ZigZagMidLineMacd", true));
                col.Remove(col.Find("ZigZagMidLineRsi", true));
                col.Remove(col.Find("ZigZagMidLineMfi", true));
                col.Remove(col.Find("ZigZagMidLineVmLean", true));
            }

            //if (ChooseIndi != "Aroon Oscillator")
            //{
            //    col.Remove(col.Find("PeriodAroon", true));
            //    col.Remove(col.Find("AroonBufferSize", true));
            //    col.Remove(col.Find("AroonBreakPointThresholdUp", true));
            //    col.Remove(col.Find("AroonBreakPointThresholdDown", true));
            //    col.Remove(col.Find("ObAroon", true));
            //    col.Remove(col.Find("OsAroon", true));
            //    col.Remove(col.Find("MidLineAroon", true));
            //}
            //if (ChooseIndi != "CCI")
            //{
            //    col.Remove(col.Find("PeriodCCI", true));
            //    col.Remove(col.Find("CciBufferSize", true));
            //    col.Remove(col.Find("CciBreakPointThresholdUp", true));
            //    col.Remove(col.Find("CciBreakPointThresholdDown", true));
            //    col.Remove(col.Find("ObCci", true));
            //    col.Remove(col.Find("OsCci", true));
            //    col.Remove(col.Find("MidLineCci", true));
            //}
            //if (ChooseIndi != "ROC")
            //{
            //    col.Remove(col.Find("PeriodROC", true));
            //    col.Remove(col.Find("RocBufferSize", true));
            //    col.Remove(col.Find("RocBreakPointThresholdUp", true));
            //    col.Remove(col.Find("RocBreakPointThresholdDown", true));
            //    col.Remove(col.Find("ObRoc", true));
            //    col.Remove(col.Find("OsRoc", true));
            //    col.Remove(col.Find("MidLineRoc", true));
            //}
            if (ChooseIndi != "RSI")
            {
                col.Remove(col.Find("PeriodRSI", true));
                col.Remove(col.Find("SmoothRSI", true));
                col.Remove(col.Find("RsiPlot", true));
                col.Remove(col.Find("UseRsiPlot", true));
                col.Remove(col.Find("RsiBufferSize", true));
                col.Remove(col.Find("RsiBreakPointThresholdUpMax", true));
                col.Remove(col.Find("RsiBreakPointThresholdUpMin", true));
                col.Remove(col.Find("RsiBreakPointThresholdDownMax", true));
                col.Remove(col.Find("RsiBreakPointThresholdDownMin", true));
                col.Remove(col.Find("ObRsi", true));
                col.Remove(col.Find("OsRsi", true));
                col.Remove(col.Find("MidLineRsi", true));
                col.Remove(col.Find("ZigZagMidLineRsi", true));
            }
            //if (ChooseIndi != "Stochastics")
            //{
            //    col.Remove(col.Find("PeriodDStoch", true));
            //    col.Remove(col.Find("PeriodKStoch", true));
            //    col.Remove(col.Find("SmoothStoch", true));
            //    col.Remove(col.Find("StochasticsPlot", true));
            //    col.Remove(col.Find("UseStochasticsPlot", true));
            //    col.Remove(col.Find("StochasticsBufferSize", true));
            //    col.Remove(col.Find("StochasticsBreakPointThresholdUp", true));
            //    col.Remove(col.Find("StochasticsBreakPointThresholdDown", true));
            //    col.Remove(col.Find("ObStochastic", true));
            //    col.Remove(col.Find("OsStochastic", true));
            //    col.Remove(col.Find("MidLineStochastic", true));
            //}
            if (ChooseIndi != "MACD")
            {
                col.Remove(col.Find("FastMacd", true));
                col.Remove(col.Find("SlowMacd", true));
                col.Remove(col.Find("SmoothMacd", true));
                col.Remove(col.Find("MacdPlot", true));
                col.Remove(col.Find("UseMacdPlot", true));
                col.Remove(col.Find("MacdBufferSize", true));
                col.Remove(col.Find("MacdBreakPointThresholdUpMax", true));
                col.Remove(col.Find("MacdBreakPointThresholdUpMin", true));
                col.Remove(col.Find("MacdBreakPointThresholdDownMax", true));
                col.Remove(col.Find("MacdBreakPointThresholdDownMin", true));
                col.Remove(col.Find("ObMacd", true));
                col.Remove(col.Find("OsMacd", true));
                col.Remove(col.Find("MidLineMacd", true));
                col.Remove(col.Find("ZigZagMidLineMacd", true));
            }
            if (ChooseIndi != "MFI")
            {
                col.Remove(col.Find("PeriodMFI", true));
                col.Remove(col.Find("MfiBufferSize", true));
                col.Remove(col.Find("MfiBreakPointThresholdUpMax", true));
                col.Remove(col.Find("MfiBreakPointThresholdUpMin", true));
                col.Remove(col.Find("MfiBreakPointThresholdDownMax", true));
                col.Remove(col.Find("MfiBreakPointThresholdDownMin", true));
                col.Remove(col.Find("ObMfi", true));
                col.Remove(col.Find("OsMfi", true));
                col.Remove(col.Find("MidLineMfi", true));
                col.Remove(col.Find("ZigZagMidLineMfi", true));
            }
            if (ChooseIndi != "VmLean")
            {
                col.Remove(col.Find("BandPeriodVmLean", true));
                col.Remove(col.Find("FastMacdDefaulVmLeant", true));
                col.Remove(col.Find("SlowMacdDefaultVmLean", true));
                col.Remove(col.Find("StdDevNumberVmLean", true));
                col.Remove(col.Find("UseVmLeanPlot", true));
                col.Remove(col.Find("VmLeanBufferSize", true));
                col.Remove(col.Find("VmLeanBreakPointThresholdUpMax", true));
                col.Remove(col.Find("VmLeanBreakPointThresholdUpMin", true));
                col.Remove(col.Find("VmLeanBreakPointThresholdDownMax", true));
                col.Remove(col.Find("VmLeanBreakPointThresholdDownMin", true));
                col.Remove(col.Find("ObVmLean", true));
                col.Remove(col.Find("OsVmLean", true));
                col.Remove(col.Find("MidLineVmLean", true));
                col.Remove(col.Find("ZigZagMidLineVmLean", true));
            }
            if (!UseZeroLineFilter)
            {
                //col.Remove(col.Find("MidLineAroon", true));
                //col.Remove(col.Find("MidLineCci", true));
                //col.Remove(col.Find("MidLineRoc", true));
                col.Remove(col.Find("MidLineRsi", true));
                //col.Remove(col.Find("MidLineStochastic", true));
                col.Remove(col.Find("MidLineMacd", true));
                col.Remove(col.Find("MidLineMfi", true));
                col.Remove(col.Find("MidLineVmLean", true));
                //col.Remove(col.Find("MidLine", true));
            }
            if (!UseThresholdFilter)
            {
                //col.Remove(col.Find("AroonBreakPointThresholdUp", true));
                //col.Remove(col.Find("AroonBreakPointThresholdDown", true));
                //col.Remove(col.Find("CciBreakPointThresholdUp", true));
                //col.Remove(col.Find("CciBreakPointThresholdDown", true));
                //col.Remove(col.Find("RocBreakPointThresholdUp", true));
                //col.Remove(col.Find("RocBreakPointThresholdDown", true));
                col.Remove(col.Find("RsiBreakPointThresholdUpMax", true));
                col.Remove(col.Find("RsiBreakPointThresholdUpMin", true));
                col.Remove(col.Find("RsiBreakPointThresholdDownMax", true));
                col.Remove(col.Find("RsiBreakPointThresholdDownMin", true));
                //col.Remove(col.Find("StochasticsBreakPointThresholdUp", true));
                //col.Remove(col.Find("StochasticsBreakPointThresholdDown", true));
                col.Remove(col.Find("MacdBreakPointThresholdUpMax", true));
                col.Remove(col.Find("MacdBreakPointThresholdUpMin", true));
                col.Remove(col.Find("MacdBreakPointThresholdDownMax", true));
                col.Remove(col.Find("MacdBreakPointThresholdDownMin", true));
                col.Remove(col.Find("MfiBreakPointThresholdUpMax", true));
                col.Remove(col.Find("MfiBreakPointThresholdUpMin", true));
                col.Remove(col.Find("MfiBreakPointThresholdDownMax", true));
                col.Remove(col.Find("MfiBreakPointThresholdDownMin", true));
                col.Remove(col.Find("VmLeanBreakPointThresholdUpMax", true));
                col.Remove(col.Find("VmLeanBreakPointThresholdUpMin", true));
                col.Remove(col.Find("VmLeanBreakPointThresholdDownMax", true));
                col.Remove(col.Find("VmLeanBreakPointThresholdDownMin", true));
            }
            if (!LeftPointObOsFilter && !RightPointNoObOsFilter)
            {
                //col.Remove(col.Find("ObAroon", true));
                //col.Remove(col.Find("OsAroon", true));
                //col.Remove(col.Find("ObCci", true));
                //col.Remove(col.Find("OsCci", true));
                //col.Remove(col.Find("ObRoc", true));
                //col.Remove(col.Find("OsRoc", true));
                col.Remove(col.Find("ObRsi", true));
                col.Remove(col.Find("OsRsi", true));
                //col.Remove(col.Find("ObStochastic", true));
                //col.Remove(col.Find("OsStochastic", true));
                col.Remove(col.Find("ObMacd", true));
                col.Remove(col.Find("OsMacd", true));
                col.Remove(col.Find("ObMfi", true));
                col.Remove(col.Find("OsMfi", true));
                col.Remove(col.Find("ObVmLean", true));
                col.Remove(col.Find("OsVmLean", true));
                //col.Remove(col.Find("Overbought", true));
                //col.Remove(col.Find("Oversold", true));
            }
            //if (!IncludeDtDb)
            //{
            //    col.Remove(col.Find("DtDbDeviation", true));
            //}
            //if (!ShowDivInPricePanel)
            //{
            //    col.Remove(col.Find("showTriangle", true));
            //    col.Remove(col.Find("TriangleTickDeviation", true));
            //}
            //if (!ShowRegularDiv)
            //{
            //    col.Remove(col.Find("RegularBearish", true));
            //    col.Remove(col.Find("RegularBullish", true));
            //}
            //if (!ShowHiddenDiv)
            //{
            //    col.Remove(col.Find("HiddenBearish", true));
            //    col.Remove(col.Find("HiddenBullish", true));
            //}
            if (!useHtf)
            {
                col.Remove(col.Find("htft", true));
                col.Remove(col.Find("htfp", true));
            }

        }
        #endregion

        #region ICustomTypeDescriptor Members
        public PropertyDescriptorCollection GetProperties() { return TypeDescriptor.GetProperties(GetType()); }
        public object GetPropertyOwner(PropertyDescriptor pd) { return this; }
        public AttributeCollection GetAttributes() { return TypeDescriptor.GetAttributes(GetType()); }
        public string GetClassName() { return TypeDescriptor.GetClassName(GetType()); }
        public string GetComponentName() { return TypeDescriptor.GetComponentName(GetType()); }
        public TypeConverter GetConverter() { return TypeDescriptor.GetConverter(GetType()); }
        public EventDescriptor GetDefaultEvent() { return TypeDescriptor.GetDefaultEvent(GetType()); }
        public PropertyDescriptor GetDefaultProperty() { return TypeDescriptor.GetDefaultProperty(GetType()); }
        public object GetEditor(Type editorBaseType) { return TypeDescriptor.GetEditor(GetType(), editorBaseType); }
        public EventDescriptorCollection GetEvents(Attribute[] attributes) { return TypeDescriptor.GetEvents(GetType(), attributes); }
        public EventDescriptorCollection GetEvents() { return TypeDescriptor.GetEvents(GetType()); }
        public PropertyDescriptorCollection GetProperties(Attribute[] attributes)
        {
            PropertyDescriptorCollection orig = GetFilteredIndicatorProperties(TypeDescriptor.GetProperties(GetType(), attributes), this.IsOwnedByChart, this.IsCreatedByStrategy);
            PropertyDescriptor[] arr = new PropertyDescriptor[orig.Count];
            orig.CopyTo(arr, 0);
            PropertyDescriptorCollection col = new PropertyDescriptorCollection(arr);
            ModifyProperties(col);
            return col;
        }
        public static PropertyDescriptorCollection GetFilteredIndicatorProperties(PropertyDescriptorCollection origProperties, bool isOwnedByChart, bool isCreatedByStrategy)
        {
            List<PropertyDescriptor> allProps = new List<PropertyDescriptor>();
            foreach (PropertyDescriptor pd in origProperties) { allProps.Add(pd); }
            Type[] excludedTypes = new Type[] { typeof(System.Windows.Media.Brush), typeof(NinjaTrader.Gui.Stroke), typeof(System.Windows.Media.Color), typeof(System.Windows.Media.Pen) };
            Func<Type, bool> IsNotAVisualType = (Type propType) => {
                foreach (Type testType in excludedTypes) { if (testType.IsAssignableFrom(propType)) return false; }
                return true;
            };
            IEnumerable<string> baseIndProperties = from bp in typeof(IndicatorBase).GetProperties(BindingFlags.Instance | BindingFlags.Public) select bp.Name;
            IEnumerable<PropertyDescriptor> filteredProps = from p in allProps where p.IsBrowsable && (!isOwnedByChart && !isCreatedByStrategy ? (!baseIndProperties.Contains(p.Name) && p.Name != "Calculate" && p.Name != "Displacement" && IsNotAVisualType(p.PropertyType)) : true) select p;
            return new PropertyDescriptorCollection(filteredProps.ToArray());
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARCOscTLBreak[] cacheARCOscTLBreak;
		public ARC.ARCOscTLBreak ARCOscTLBreak(bool useHtf, string htft, int htfp, int pBXTSize, int pBXTOffset, int pBXTReverse, bool showSmall, bool showZigZag, int smallSwingStrength, double smallSensitivity, Stroke zigZagColor, bool zigZagFiltering, double zigZagMidLineMacd, double zigZagMidLineRsi, double zigZagMidLineMfi, double zigZagMidLineVmLean, string chooseIndi, int fastMacd, int slowMacd, int smoothMacd, int periodRSI, int smoothRSI, int periodMFI, int bandPeriodVmLean, int fastMacdDefaulVmLeant, int slowMacdDefaultVmLean, double stdDevNumberVmLean, string useMacdPlot, string useRsiPlot, string useVmLeanPlot, int swingsBackNo, int touchesNo, double macdBufferSize, double rsiBufferSize, double mfiBufferSize, double vmLeanBufferSize, bool useZeroLineFilter, double midLineMacd, double midLineRsi, double midLineMfi, double midLineVmLean, bool leftPointObOsFilter, bool rightPointNoObOsFilter, double obMacd, double osMacd, double obRsi, double osRsi, double obMfi, double osMfi, double obVmLean, double osVmLean, bool useThresholdFilter, double macdBreakPointThresholdUpMax, double macdBreakPointThresholdUpMin, double macdBreakPointThresholdDownMax, double macdBreakPointThresholdDownMin, double rsiBreakPointThresholdUpMax, double rsiBreakPointThresholdUpMin, double rsiBreakPointThresholdDownMax, double rsiBreakPointThresholdDownMin, double mfiBreakPointThresholdUpMax, double mfiBreakPointThresholdUpMin, double mfiBreakPointThresholdDownMax, double mfiBreakPointThresholdDownMin, double vmLeanBreakPointThresholdUpMax, double vmLeanBreakPointThresholdUpMin, double vmLeanBreakPointThresholdDownMax, double vmLeanBreakPointThresholdDownMin, bool showLongDivergence, Stroke regularBullish, bool showShortDivergence, Stroke regularBearish, bool showTriangle, double triangleTickDeviation, bool viewOnlyLastDivergence, string buttonText)
		{
			return ARCOscTLBreak(Input, useHtf, htft, htfp, pBXTSize, pBXTOffset, pBXTReverse, showSmall, showZigZag, smallSwingStrength, smallSensitivity, zigZagColor, zigZagFiltering, zigZagMidLineMacd, zigZagMidLineRsi, zigZagMidLineMfi, zigZagMidLineVmLean, chooseIndi, fastMacd, slowMacd, smoothMacd, periodRSI, smoothRSI, periodMFI, bandPeriodVmLean, fastMacdDefaulVmLeant, slowMacdDefaultVmLean, stdDevNumberVmLean, useMacdPlot, useRsiPlot, useVmLeanPlot, swingsBackNo, touchesNo, macdBufferSize, rsiBufferSize, mfiBufferSize, vmLeanBufferSize, useZeroLineFilter, midLineMacd, midLineRsi, midLineMfi, midLineVmLean, leftPointObOsFilter, rightPointNoObOsFilter, obMacd, osMacd, obRsi, osRsi, obMfi, osMfi, obVmLean, osVmLean, useThresholdFilter, macdBreakPointThresholdUpMax, macdBreakPointThresholdUpMin, macdBreakPointThresholdDownMax, macdBreakPointThresholdDownMin, rsiBreakPointThresholdUpMax, rsiBreakPointThresholdUpMin, rsiBreakPointThresholdDownMax, rsiBreakPointThresholdDownMin, mfiBreakPointThresholdUpMax, mfiBreakPointThresholdUpMin, mfiBreakPointThresholdDownMax, mfiBreakPointThresholdDownMin, vmLeanBreakPointThresholdUpMax, vmLeanBreakPointThresholdUpMin, vmLeanBreakPointThresholdDownMax, vmLeanBreakPointThresholdDownMin, showLongDivergence, regularBullish, showShortDivergence, regularBearish, showTriangle, triangleTickDeviation, viewOnlyLastDivergence, buttonText);
		}

		public ARC.ARCOscTLBreak ARCOscTLBreak(ISeries<double> input, bool useHtf, string htft, int htfp, int pBXTSize, int pBXTOffset, int pBXTReverse, bool showSmall, bool showZigZag, int smallSwingStrength, double smallSensitivity, Stroke zigZagColor, bool zigZagFiltering, double zigZagMidLineMacd, double zigZagMidLineRsi, double zigZagMidLineMfi, double zigZagMidLineVmLean, string chooseIndi, int fastMacd, int slowMacd, int smoothMacd, int periodRSI, int smoothRSI, int periodMFI, int bandPeriodVmLean, int fastMacdDefaulVmLeant, int slowMacdDefaultVmLean, double stdDevNumberVmLean, string useMacdPlot, string useRsiPlot, string useVmLeanPlot, int swingsBackNo, int touchesNo, double macdBufferSize, double rsiBufferSize, double mfiBufferSize, double vmLeanBufferSize, bool useZeroLineFilter, double midLineMacd, double midLineRsi, double midLineMfi, double midLineVmLean, bool leftPointObOsFilter, bool rightPointNoObOsFilter, double obMacd, double osMacd, double obRsi, double osRsi, double obMfi, double osMfi, double obVmLean, double osVmLean, bool useThresholdFilter, double macdBreakPointThresholdUpMax, double macdBreakPointThresholdUpMin, double macdBreakPointThresholdDownMax, double macdBreakPointThresholdDownMin, double rsiBreakPointThresholdUpMax, double rsiBreakPointThresholdUpMin, double rsiBreakPointThresholdDownMax, double rsiBreakPointThresholdDownMin, double mfiBreakPointThresholdUpMax, double mfiBreakPointThresholdUpMin, double mfiBreakPointThresholdDownMax, double mfiBreakPointThresholdDownMin, double vmLeanBreakPointThresholdUpMax, double vmLeanBreakPointThresholdUpMin, double vmLeanBreakPointThresholdDownMax, double vmLeanBreakPointThresholdDownMin, bool showLongDivergence, Stroke regularBullish, bool showShortDivergence, Stroke regularBearish, bool showTriangle, double triangleTickDeviation, bool viewOnlyLastDivergence, string buttonText)
		{
			if (cacheARCOscTLBreak != null)
				for (int idx = 0; idx < cacheARCOscTLBreak.Length; idx++)
					if (cacheARCOscTLBreak[idx] != null && cacheARCOscTLBreak[idx].useHtf == useHtf && cacheARCOscTLBreak[idx].htft == htft && cacheARCOscTLBreak[idx].htfp == htfp && cacheARCOscTLBreak[idx].pBXTSize == pBXTSize && cacheARCOscTLBreak[idx].pBXTOffset == pBXTOffset && cacheARCOscTLBreak[idx].pBXTReverse == pBXTReverse && cacheARCOscTLBreak[idx].ShowSmall == showSmall && cacheARCOscTLBreak[idx].ShowZigZag == showZigZag && cacheARCOscTLBreak[idx].SmallSwingStrength == smallSwingStrength && cacheARCOscTLBreak[idx].SmallSensitivity == smallSensitivity && cacheARCOscTLBreak[idx].ZigZagColor == zigZagColor && cacheARCOscTLBreak[idx].ZigZagFiltering == zigZagFiltering && cacheARCOscTLBreak[idx].ZigZagMidLineMacd == zigZagMidLineMacd && cacheARCOscTLBreak[idx].ZigZagMidLineRsi == zigZagMidLineRsi && cacheARCOscTLBreak[idx].ZigZagMidLineMfi == zigZagMidLineMfi && cacheARCOscTLBreak[idx].ZigZagMidLineVmLean == zigZagMidLineVmLean && cacheARCOscTLBreak[idx].ChooseIndi == chooseIndi && cacheARCOscTLBreak[idx].FastMacd == fastMacd && cacheARCOscTLBreak[idx].SlowMacd == slowMacd && cacheARCOscTLBreak[idx].SmoothMacd == smoothMacd && cacheARCOscTLBreak[idx].PeriodRSI == periodRSI && cacheARCOscTLBreak[idx].SmoothRSI == smoothRSI && cacheARCOscTLBreak[idx].PeriodMFI == periodMFI && cacheARCOscTLBreak[idx].BandPeriodVmLean == bandPeriodVmLean && cacheARCOscTLBreak[idx].FastMacdDefaulVmLeant == fastMacdDefaulVmLeant && cacheARCOscTLBreak[idx].SlowMacdDefaultVmLean == slowMacdDefaultVmLean && cacheARCOscTLBreak[idx].StdDevNumberVmLean == stdDevNumberVmLean && cacheARCOscTLBreak[idx].UseMacdPlot == useMacdPlot && cacheARCOscTLBreak[idx].UseRsiPlot == useRsiPlot && cacheARCOscTLBreak[idx].UseVmLeanPlot == useVmLeanPlot && cacheARCOscTLBreak[idx].SwingsBackNo == swingsBackNo && cacheARCOscTLBreak[idx].TouchesNo == touchesNo && cacheARCOscTLBreak[idx].MacdBufferSize == macdBufferSize && cacheARCOscTLBreak[idx].RsiBufferSize == rsiBufferSize && cacheARCOscTLBreak[idx].MfiBufferSize == mfiBufferSize && cacheARCOscTLBreak[idx].VmLeanBufferSize == vmLeanBufferSize && cacheARCOscTLBreak[idx].UseZeroLineFilter == useZeroLineFilter && cacheARCOscTLBreak[idx].MidLineMacd == midLineMacd && cacheARCOscTLBreak[idx].MidLineRsi == midLineRsi && cacheARCOscTLBreak[idx].MidLineMfi == midLineMfi && cacheARCOscTLBreak[idx].MidLineVmLean == midLineVmLean && cacheARCOscTLBreak[idx].LeftPointObOsFilter == leftPointObOsFilter && cacheARCOscTLBreak[idx].RightPointNoObOsFilter == rightPointNoObOsFilter && cacheARCOscTLBreak[idx].ObMacd == obMacd && cacheARCOscTLBreak[idx].OsMacd == osMacd && cacheARCOscTLBreak[idx].ObRsi == obRsi && cacheARCOscTLBreak[idx].OsRsi == osRsi && cacheARCOscTLBreak[idx].ObMfi == obMfi && cacheARCOscTLBreak[idx].OsMfi == osMfi && cacheARCOscTLBreak[idx].ObVmLean == obVmLean && cacheARCOscTLBreak[idx].OsVmLean == osVmLean && cacheARCOscTLBreak[idx].UseThresholdFilter == useThresholdFilter && cacheARCOscTLBreak[idx].MacdBreakPointThresholdUpMax == macdBreakPointThresholdUpMax && cacheARCOscTLBreak[idx].MacdBreakPointThresholdUpMin == macdBreakPointThresholdUpMin && cacheARCOscTLBreak[idx].MacdBreakPointThresholdDownMax == macdBreakPointThresholdDownMax && cacheARCOscTLBreak[idx].MacdBreakPointThresholdDownMin == macdBreakPointThresholdDownMin && cacheARCOscTLBreak[idx].RsiBreakPointThresholdUpMax == rsiBreakPointThresholdUpMax && cacheARCOscTLBreak[idx].RsiBreakPointThresholdUpMin == rsiBreakPointThresholdUpMin && cacheARCOscTLBreak[idx].RsiBreakPointThresholdDownMax == rsiBreakPointThresholdDownMax && cacheARCOscTLBreak[idx].RsiBreakPointThresholdDownMin == rsiBreakPointThresholdDownMin && cacheARCOscTLBreak[idx].MfiBreakPointThresholdUpMax == mfiBreakPointThresholdUpMax && cacheARCOscTLBreak[idx].MfiBreakPointThresholdUpMin == mfiBreakPointThresholdUpMin && cacheARCOscTLBreak[idx].MfiBreakPointThresholdDownMax == mfiBreakPointThresholdDownMax && cacheARCOscTLBreak[idx].MfiBreakPointThresholdDownMin == mfiBreakPointThresholdDownMin && cacheARCOscTLBreak[idx].VmLeanBreakPointThresholdUpMax == vmLeanBreakPointThresholdUpMax && cacheARCOscTLBreak[idx].VmLeanBreakPointThresholdUpMin == vmLeanBreakPointThresholdUpMin && cacheARCOscTLBreak[idx].VmLeanBreakPointThresholdDownMax == vmLeanBreakPointThresholdDownMax && cacheARCOscTLBreak[idx].VmLeanBreakPointThresholdDownMin == vmLeanBreakPointThresholdDownMin && cacheARCOscTLBreak[idx].ShowLongDivergence == showLongDivergence && cacheARCOscTLBreak[idx].RegularBullish == regularBullish && cacheARCOscTLBreak[idx].ShowShortDivergence == showShortDivergence && cacheARCOscTLBreak[idx].RegularBearish == regularBearish && cacheARCOscTLBreak[idx].showTriangle == showTriangle && cacheARCOscTLBreak[idx].TriangleTickDeviation == triangleTickDeviation && cacheARCOscTLBreak[idx].ViewOnlyLastDivergence == viewOnlyLastDivergence && cacheARCOscTLBreak[idx].ButtonText == buttonText && cacheARCOscTLBreak[idx].EqualsInput(input))
						return cacheARCOscTLBreak[idx];
			return CacheIndicator<ARC.ARCOscTLBreak>(new ARC.ARCOscTLBreak(){ useHtf = useHtf, htft = htft, htfp = htfp, pBXTSize = pBXTSize, pBXTOffset = pBXTOffset, pBXTReverse = pBXTReverse, ShowSmall = showSmall, ShowZigZag = showZigZag, SmallSwingStrength = smallSwingStrength, SmallSensitivity = smallSensitivity, ZigZagColor = zigZagColor, ZigZagFiltering = zigZagFiltering, ZigZagMidLineMacd = zigZagMidLineMacd, ZigZagMidLineRsi = zigZagMidLineRsi, ZigZagMidLineMfi = zigZagMidLineMfi, ZigZagMidLineVmLean = zigZagMidLineVmLean, ChooseIndi = chooseIndi, FastMacd = fastMacd, SlowMacd = slowMacd, SmoothMacd = smoothMacd, PeriodRSI = periodRSI, SmoothRSI = smoothRSI, PeriodMFI = periodMFI, BandPeriodVmLean = bandPeriodVmLean, FastMacdDefaulVmLeant = fastMacdDefaulVmLeant, SlowMacdDefaultVmLean = slowMacdDefaultVmLean, StdDevNumberVmLean = stdDevNumberVmLean, UseMacdPlot = useMacdPlot, UseRsiPlot = useRsiPlot, UseVmLeanPlot = useVmLeanPlot, SwingsBackNo = swingsBackNo, TouchesNo = touchesNo, MacdBufferSize = macdBufferSize, RsiBufferSize = rsiBufferSize, MfiBufferSize = mfiBufferSize, VmLeanBufferSize = vmLeanBufferSize, UseZeroLineFilter = useZeroLineFilter, MidLineMacd = midLineMacd, MidLineRsi = midLineRsi, MidLineMfi = midLineMfi, MidLineVmLean = midLineVmLean, LeftPointObOsFilter = leftPointObOsFilter, RightPointNoObOsFilter = rightPointNoObOsFilter, ObMacd = obMacd, OsMacd = osMacd, ObRsi = obRsi, OsRsi = osRsi, ObMfi = obMfi, OsMfi = osMfi, ObVmLean = obVmLean, OsVmLean = osVmLean, UseThresholdFilter = useThresholdFilter, MacdBreakPointThresholdUpMax = macdBreakPointThresholdUpMax, MacdBreakPointThresholdUpMin = macdBreakPointThresholdUpMin, MacdBreakPointThresholdDownMax = macdBreakPointThresholdDownMax, MacdBreakPointThresholdDownMin = macdBreakPointThresholdDownMin, RsiBreakPointThresholdUpMax = rsiBreakPointThresholdUpMax, RsiBreakPointThresholdUpMin = rsiBreakPointThresholdUpMin, RsiBreakPointThresholdDownMax = rsiBreakPointThresholdDownMax, RsiBreakPointThresholdDownMin = rsiBreakPointThresholdDownMin, MfiBreakPointThresholdUpMax = mfiBreakPointThresholdUpMax, MfiBreakPointThresholdUpMin = mfiBreakPointThresholdUpMin, MfiBreakPointThresholdDownMax = mfiBreakPointThresholdDownMax, MfiBreakPointThresholdDownMin = mfiBreakPointThresholdDownMin, VmLeanBreakPointThresholdUpMax = vmLeanBreakPointThresholdUpMax, VmLeanBreakPointThresholdUpMin = vmLeanBreakPointThresholdUpMin, VmLeanBreakPointThresholdDownMax = vmLeanBreakPointThresholdDownMax, VmLeanBreakPointThresholdDownMin = vmLeanBreakPointThresholdDownMin, ShowLongDivergence = showLongDivergence, RegularBullish = regularBullish, ShowShortDivergence = showShortDivergence, RegularBearish = regularBearish, showTriangle = showTriangle, TriangleTickDeviation = triangleTickDeviation, ViewOnlyLastDivergence = viewOnlyLastDivergence, ButtonText = buttonText }, input, ref cacheARCOscTLBreak);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARCOscTLBreak ARCOscTLBreak(bool useHtf, string htft, int htfp, int pBXTSize, int pBXTOffset, int pBXTReverse, bool showSmall, bool showZigZag, int smallSwingStrength, double smallSensitivity, Stroke zigZagColor, bool zigZagFiltering, double zigZagMidLineMacd, double zigZagMidLineRsi, double zigZagMidLineMfi, double zigZagMidLineVmLean, string chooseIndi, int fastMacd, int slowMacd, int smoothMacd, int periodRSI, int smoothRSI, int periodMFI, int bandPeriodVmLean, int fastMacdDefaulVmLeant, int slowMacdDefaultVmLean, double stdDevNumberVmLean, string useMacdPlot, string useRsiPlot, string useVmLeanPlot, int swingsBackNo, int touchesNo, double macdBufferSize, double rsiBufferSize, double mfiBufferSize, double vmLeanBufferSize, bool useZeroLineFilter, double midLineMacd, double midLineRsi, double midLineMfi, double midLineVmLean, bool leftPointObOsFilter, bool rightPointNoObOsFilter, double obMacd, double osMacd, double obRsi, double osRsi, double obMfi, double osMfi, double obVmLean, double osVmLean, bool useThresholdFilter, double macdBreakPointThresholdUpMax, double macdBreakPointThresholdUpMin, double macdBreakPointThresholdDownMax, double macdBreakPointThresholdDownMin, double rsiBreakPointThresholdUpMax, double rsiBreakPointThresholdUpMin, double rsiBreakPointThresholdDownMax, double rsiBreakPointThresholdDownMin, double mfiBreakPointThresholdUpMax, double mfiBreakPointThresholdUpMin, double mfiBreakPointThresholdDownMax, double mfiBreakPointThresholdDownMin, double vmLeanBreakPointThresholdUpMax, double vmLeanBreakPointThresholdUpMin, double vmLeanBreakPointThresholdDownMax, double vmLeanBreakPointThresholdDownMin, bool showLongDivergence, Stroke regularBullish, bool showShortDivergence, Stroke regularBearish, bool showTriangle, double triangleTickDeviation, bool viewOnlyLastDivergence, string buttonText)
		{
			return indicator.ARCOscTLBreak(Input, useHtf, htft, htfp, pBXTSize, pBXTOffset, pBXTReverse, showSmall, showZigZag, smallSwingStrength, smallSensitivity, zigZagColor, zigZagFiltering, zigZagMidLineMacd, zigZagMidLineRsi, zigZagMidLineMfi, zigZagMidLineVmLean, chooseIndi, fastMacd, slowMacd, smoothMacd, periodRSI, smoothRSI, periodMFI, bandPeriodVmLean, fastMacdDefaulVmLeant, slowMacdDefaultVmLean, stdDevNumberVmLean, useMacdPlot, useRsiPlot, useVmLeanPlot, swingsBackNo, touchesNo, macdBufferSize, rsiBufferSize, mfiBufferSize, vmLeanBufferSize, useZeroLineFilter, midLineMacd, midLineRsi, midLineMfi, midLineVmLean, leftPointObOsFilter, rightPointNoObOsFilter, obMacd, osMacd, obRsi, osRsi, obMfi, osMfi, obVmLean, osVmLean, useThresholdFilter, macdBreakPointThresholdUpMax, macdBreakPointThresholdUpMin, macdBreakPointThresholdDownMax, macdBreakPointThresholdDownMin, rsiBreakPointThresholdUpMax, rsiBreakPointThresholdUpMin, rsiBreakPointThresholdDownMax, rsiBreakPointThresholdDownMin, mfiBreakPointThresholdUpMax, mfiBreakPointThresholdUpMin, mfiBreakPointThresholdDownMax, mfiBreakPointThresholdDownMin, vmLeanBreakPointThresholdUpMax, vmLeanBreakPointThresholdUpMin, vmLeanBreakPointThresholdDownMax, vmLeanBreakPointThresholdDownMin, showLongDivergence, regularBullish, showShortDivergence, regularBearish, showTriangle, triangleTickDeviation, viewOnlyLastDivergence, buttonText);
		}

		public Indicators.ARC.ARCOscTLBreak ARCOscTLBreak(ISeries<double> input , bool useHtf, string htft, int htfp, int pBXTSize, int pBXTOffset, int pBXTReverse, bool showSmall, bool showZigZag, int smallSwingStrength, double smallSensitivity, Stroke zigZagColor, bool zigZagFiltering, double zigZagMidLineMacd, double zigZagMidLineRsi, double zigZagMidLineMfi, double zigZagMidLineVmLean, string chooseIndi, int fastMacd, int slowMacd, int smoothMacd, int periodRSI, int smoothRSI, int periodMFI, int bandPeriodVmLean, int fastMacdDefaulVmLeant, int slowMacdDefaultVmLean, double stdDevNumberVmLean, string useMacdPlot, string useRsiPlot, string useVmLeanPlot, int swingsBackNo, int touchesNo, double macdBufferSize, double rsiBufferSize, double mfiBufferSize, double vmLeanBufferSize, bool useZeroLineFilter, double midLineMacd, double midLineRsi, double midLineMfi, double midLineVmLean, bool leftPointObOsFilter, bool rightPointNoObOsFilter, double obMacd, double osMacd, double obRsi, double osRsi, double obMfi, double osMfi, double obVmLean, double osVmLean, bool useThresholdFilter, double macdBreakPointThresholdUpMax, double macdBreakPointThresholdUpMin, double macdBreakPointThresholdDownMax, double macdBreakPointThresholdDownMin, double rsiBreakPointThresholdUpMax, double rsiBreakPointThresholdUpMin, double rsiBreakPointThresholdDownMax, double rsiBreakPointThresholdDownMin, double mfiBreakPointThresholdUpMax, double mfiBreakPointThresholdUpMin, double mfiBreakPointThresholdDownMax, double mfiBreakPointThresholdDownMin, double vmLeanBreakPointThresholdUpMax, double vmLeanBreakPointThresholdUpMin, double vmLeanBreakPointThresholdDownMax, double vmLeanBreakPointThresholdDownMin, bool showLongDivergence, Stroke regularBullish, bool showShortDivergence, Stroke regularBearish, bool showTriangle, double triangleTickDeviation, bool viewOnlyLastDivergence, string buttonText)
		{
			return indicator.ARCOscTLBreak(input, useHtf, htft, htfp, pBXTSize, pBXTOffset, pBXTReverse, showSmall, showZigZag, smallSwingStrength, smallSensitivity, zigZagColor, zigZagFiltering, zigZagMidLineMacd, zigZagMidLineRsi, zigZagMidLineMfi, zigZagMidLineVmLean, chooseIndi, fastMacd, slowMacd, smoothMacd, periodRSI, smoothRSI, periodMFI, bandPeriodVmLean, fastMacdDefaulVmLeant, slowMacdDefaultVmLean, stdDevNumberVmLean, useMacdPlot, useRsiPlot, useVmLeanPlot, swingsBackNo, touchesNo, macdBufferSize, rsiBufferSize, mfiBufferSize, vmLeanBufferSize, useZeroLineFilter, midLineMacd, midLineRsi, midLineMfi, midLineVmLean, leftPointObOsFilter, rightPointNoObOsFilter, obMacd, osMacd, obRsi, osRsi, obMfi, osMfi, obVmLean, osVmLean, useThresholdFilter, macdBreakPointThresholdUpMax, macdBreakPointThresholdUpMin, macdBreakPointThresholdDownMax, macdBreakPointThresholdDownMin, rsiBreakPointThresholdUpMax, rsiBreakPointThresholdUpMin, rsiBreakPointThresholdDownMax, rsiBreakPointThresholdDownMin, mfiBreakPointThresholdUpMax, mfiBreakPointThresholdUpMin, mfiBreakPointThresholdDownMax, mfiBreakPointThresholdDownMin, vmLeanBreakPointThresholdUpMax, vmLeanBreakPointThresholdUpMin, vmLeanBreakPointThresholdDownMax, vmLeanBreakPointThresholdDownMin, showLongDivergence, regularBullish, showShortDivergence, regularBearish, showTriangle, triangleTickDeviation, viewOnlyLastDivergence, buttonText);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARCOscTLBreak ARCOscTLBreak(bool useHtf, string htft, int htfp, int pBXTSize, int pBXTOffset, int pBXTReverse, bool showSmall, bool showZigZag, int smallSwingStrength, double smallSensitivity, Stroke zigZagColor, bool zigZagFiltering, double zigZagMidLineMacd, double zigZagMidLineRsi, double zigZagMidLineMfi, double zigZagMidLineVmLean, string chooseIndi, int fastMacd, int slowMacd, int smoothMacd, int periodRSI, int smoothRSI, int periodMFI, int bandPeriodVmLean, int fastMacdDefaulVmLeant, int slowMacdDefaultVmLean, double stdDevNumberVmLean, string useMacdPlot, string useRsiPlot, string useVmLeanPlot, int swingsBackNo, int touchesNo, double macdBufferSize, double rsiBufferSize, double mfiBufferSize, double vmLeanBufferSize, bool useZeroLineFilter, double midLineMacd, double midLineRsi, double midLineMfi, double midLineVmLean, bool leftPointObOsFilter, bool rightPointNoObOsFilter, double obMacd, double osMacd, double obRsi, double osRsi, double obMfi, double osMfi, double obVmLean, double osVmLean, bool useThresholdFilter, double macdBreakPointThresholdUpMax, double macdBreakPointThresholdUpMin, double macdBreakPointThresholdDownMax, double macdBreakPointThresholdDownMin, double rsiBreakPointThresholdUpMax, double rsiBreakPointThresholdUpMin, double rsiBreakPointThresholdDownMax, double rsiBreakPointThresholdDownMin, double mfiBreakPointThresholdUpMax, double mfiBreakPointThresholdUpMin, double mfiBreakPointThresholdDownMax, double mfiBreakPointThresholdDownMin, double vmLeanBreakPointThresholdUpMax, double vmLeanBreakPointThresholdUpMin, double vmLeanBreakPointThresholdDownMax, double vmLeanBreakPointThresholdDownMin, bool showLongDivergence, Stroke regularBullish, bool showShortDivergence, Stroke regularBearish, bool showTriangle, double triangleTickDeviation, bool viewOnlyLastDivergence, string buttonText)
		{
			return indicator.ARCOscTLBreak(Input, useHtf, htft, htfp, pBXTSize, pBXTOffset, pBXTReverse, showSmall, showZigZag, smallSwingStrength, smallSensitivity, zigZagColor, zigZagFiltering, zigZagMidLineMacd, zigZagMidLineRsi, zigZagMidLineMfi, zigZagMidLineVmLean, chooseIndi, fastMacd, slowMacd, smoothMacd, periodRSI, smoothRSI, periodMFI, bandPeriodVmLean, fastMacdDefaulVmLeant, slowMacdDefaultVmLean, stdDevNumberVmLean, useMacdPlot, useRsiPlot, useVmLeanPlot, swingsBackNo, touchesNo, macdBufferSize, rsiBufferSize, mfiBufferSize, vmLeanBufferSize, useZeroLineFilter, midLineMacd, midLineRsi, midLineMfi, midLineVmLean, leftPointObOsFilter, rightPointNoObOsFilter, obMacd, osMacd, obRsi, osRsi, obMfi, osMfi, obVmLean, osVmLean, useThresholdFilter, macdBreakPointThresholdUpMax, macdBreakPointThresholdUpMin, macdBreakPointThresholdDownMax, macdBreakPointThresholdDownMin, rsiBreakPointThresholdUpMax, rsiBreakPointThresholdUpMin, rsiBreakPointThresholdDownMax, rsiBreakPointThresholdDownMin, mfiBreakPointThresholdUpMax, mfiBreakPointThresholdUpMin, mfiBreakPointThresholdDownMax, mfiBreakPointThresholdDownMin, vmLeanBreakPointThresholdUpMax, vmLeanBreakPointThresholdUpMin, vmLeanBreakPointThresholdDownMax, vmLeanBreakPointThresholdDownMin, showLongDivergence, regularBullish, showShortDivergence, regularBearish, showTriangle, triangleTickDeviation, viewOnlyLastDivergence, buttonText);
		}

		public Indicators.ARC.ARCOscTLBreak ARCOscTLBreak(ISeries<double> input , bool useHtf, string htft, int htfp, int pBXTSize, int pBXTOffset, int pBXTReverse, bool showSmall, bool showZigZag, int smallSwingStrength, double smallSensitivity, Stroke zigZagColor, bool zigZagFiltering, double zigZagMidLineMacd, double zigZagMidLineRsi, double zigZagMidLineMfi, double zigZagMidLineVmLean, string chooseIndi, int fastMacd, int slowMacd, int smoothMacd, int periodRSI, int smoothRSI, int periodMFI, int bandPeriodVmLean, int fastMacdDefaulVmLeant, int slowMacdDefaultVmLean, double stdDevNumberVmLean, string useMacdPlot, string useRsiPlot, string useVmLeanPlot, int swingsBackNo, int touchesNo, double macdBufferSize, double rsiBufferSize, double mfiBufferSize, double vmLeanBufferSize, bool useZeroLineFilter, double midLineMacd, double midLineRsi, double midLineMfi, double midLineVmLean, bool leftPointObOsFilter, bool rightPointNoObOsFilter, double obMacd, double osMacd, double obRsi, double osRsi, double obMfi, double osMfi, double obVmLean, double osVmLean, bool useThresholdFilter, double macdBreakPointThresholdUpMax, double macdBreakPointThresholdUpMin, double macdBreakPointThresholdDownMax, double macdBreakPointThresholdDownMin, double rsiBreakPointThresholdUpMax, double rsiBreakPointThresholdUpMin, double rsiBreakPointThresholdDownMax, double rsiBreakPointThresholdDownMin, double mfiBreakPointThresholdUpMax, double mfiBreakPointThresholdUpMin, double mfiBreakPointThresholdDownMax, double mfiBreakPointThresholdDownMin, double vmLeanBreakPointThresholdUpMax, double vmLeanBreakPointThresholdUpMin, double vmLeanBreakPointThresholdDownMax, double vmLeanBreakPointThresholdDownMin, bool showLongDivergence, Stroke regularBullish, bool showShortDivergence, Stroke regularBearish, bool showTriangle, double triangleTickDeviation, bool viewOnlyLastDivergence, string buttonText)
		{
			return indicator.ARCOscTLBreak(input, useHtf, htft, htfp, pBXTSize, pBXTOffset, pBXTReverse, showSmall, showZigZag, smallSwingStrength, smallSensitivity, zigZagColor, zigZagFiltering, zigZagMidLineMacd, zigZagMidLineRsi, zigZagMidLineMfi, zigZagMidLineVmLean, chooseIndi, fastMacd, slowMacd, smoothMacd, periodRSI, smoothRSI, periodMFI, bandPeriodVmLean, fastMacdDefaulVmLeant, slowMacdDefaultVmLean, stdDevNumberVmLean, useMacdPlot, useRsiPlot, useVmLeanPlot, swingsBackNo, touchesNo, macdBufferSize, rsiBufferSize, mfiBufferSize, vmLeanBufferSize, useZeroLineFilter, midLineMacd, midLineRsi, midLineMfi, midLineVmLean, leftPointObOsFilter, rightPointNoObOsFilter, obMacd, osMacd, obRsi, osRsi, obMfi, osMfi, obVmLean, osVmLean, useThresholdFilter, macdBreakPointThresholdUpMax, macdBreakPointThresholdUpMin, macdBreakPointThresholdDownMax, macdBreakPointThresholdDownMin, rsiBreakPointThresholdUpMax, rsiBreakPointThresholdUpMin, rsiBreakPointThresholdDownMax, rsiBreakPointThresholdDownMin, mfiBreakPointThresholdUpMax, mfiBreakPointThresholdUpMin, mfiBreakPointThresholdDownMax, mfiBreakPointThresholdDownMin, vmLeanBreakPointThresholdUpMax, vmLeanBreakPointThresholdUpMin, vmLeanBreakPointThresholdDownMax, vmLeanBreakPointThresholdDownMin, showLongDivergence, regularBullish, showShortDivergence, regularBearish, showTriangle, triangleTickDeviation, viewOnlyLastDivergence, buttonText);
		}
	}
}

#endregion
