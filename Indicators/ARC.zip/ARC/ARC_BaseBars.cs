
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[CategoryOrder("Parameters", 5)]
	[CategoryOrder("Custom Visuals", 10)]
//	[CategoryOrder("Custom Visuals - Both Signals", 20)]

	public class ARC_BaseBars : Indicator
	{
		private double MaxBodyPct = 0;
		private Brush basingbrush;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name						= "ARC_Base Bars";
				IsOverlay   = true;
				this.ZOrder = 9999;
				IsSuspendedWhileInactive	= false;
				//pEnableInsideBars = true;
				pEnableBasingBars = true;
				pMaxBodyPct       = 50;
//				pBullishInsideBarBrush   = Brushes.Lime;
//				pBullishInsideBarOpacity = 50;
//				pBearishInsideBarBrush   = Brushes.Magenta;
//				pBearishInsideBarOpacity = 50;
				pBasingBarBrush   = Brushes.White;
				pBasingBarOpacity = 50;
//				pBullishComboBarBrush   = Brushes.Orange;
//				pBullishComboBarOpacity = 80;
//				pBearishComboBarBrush   = Brushes.OrangeRed;
//				pBearishComboBarOpacity = 80;
			}
			if(State == State.DataLoaded){
				MaxBodyPct  = pMaxBodyPct/100.0;
				basingbrush = pBasingBarBrush.Clone();
				basingbrush.Opacity = pBasingBarOpacity/100.0;
				basingbrush.Freeze();

//				bullishInsideBarBrush = pBullishInsideBarBrush.Clone();
//				bullishInsideBarBrush.Opacity = pBullishInsideBarOpacity/100.0;
//				bullishInsideBarBrush.Freeze();
//				bearishInsideBarBrush = pBearishInsideBarBrush.Clone();
//				bearishInsideBarBrush.Opacity = pBearishInsideBarOpacity/100.0;
//				bearishInsideBarBrush.Freeze();
			}
		}
//		SortedDictionary<int,char> BasingSignals = new SortedDictionary<int,char>();
//		SortedDictionary<int,char> InsideBarSignals = new SortedDictionary<int,char>();
		protected override void OnBarUpdate()
		{
			if(IsFirstTickOfBar && CurrentBars[0]>10){
				bool c1 = false;
				bool c2 = false;
//				if(Highs[0][1] < Highs[0][2] && Lows[0][1] > Lows[0][2]) c1 = true;
				double bodysize = Math.Abs(Opens[0][1]-Closes[0][1]);
				if(bodysize / Range()[1] < MaxBodyPct) c2 = true;
//				if(c1 && !c2 && pEnableInsideBars) {
//					//InsideBarSignals[CurrentBars[0]-1] = Opens[0][1] < Closes[0][1] ? 'U':'D';
//					if(Opens[0][1] < Closes[0][1])
//						BarBrushes[1] = bullishInsideBarBrush;
//					else
//						BarBrushes[1] = bearishInsideBarBrush;
//				}
				if(c2 && !c1 && pEnableBasingBars){ 
					//BasingSignals[CurrentBars[0]-1] = 'B';
					BarBrushes[1] = basingbrush;
				}
//				if(c1 && c2){ 
//					//BasingSignals[CurrentBars[0]-1] = 'B';
//					if(Opens[0][1] < Closes[0][1])
//						BarBrushes[1] = pBullishComboBarBrush;
//					else
//						BarBrushes[1] = pBearishComboBarBrush;
//				}
			}

		}
	#region -- custom graphics --
	/*
	private void OutlineThisCandle(int abar, SharpDX.Direct2D1.Brush brushDX, ChartScale cs, double TopPrice, double BottomPrice, int WidthAdj){
		int offset = 0;
		var half = (int)(ChartControl.Properties.BarDistance / 2);
		var xL = ChartControl.GetXByBarIndex(ChartBars, abar) - half-WidthAdj;
		var xR = ChartControl.GetXByBarIndex(ChartBars, abar) + half+WidthAdj;
		var yT = cs.GetYByValue(Math.Max(TopPrice, BottomPrice))-offset;
		var yB = cs.GetYByValue(Math.Min(TopPrice, BottomPrice))+offset;
		RenderTarget.FillRectangle(new SharpDX.RectangleF(xL, yT, xR-xL, yB-yT), brushDX);
	}
	private SharpDX.Direct2D1.Brush IBbrushUpDX, IBbrushDownDX, BasingBarBrushDX;
	public override void OnRenderTargetChanged()
	{
		if(IBbrushUpDX!=null)   IBbrushUpDX.Dispose(); IBbrushUpDX=null;
		if(RenderTarget !=null) {
			IBbrushUpDX         = pBullishInsideBarBrush.ToDxBrush(RenderTarget);
			IBbrushUpDX.Opacity = pBullishInsideBarOpacity / 100f;
		}
		if(IBbrushDownDX!=null)   IBbrushDownDX.Dispose(); IBbrushDownDX=null;
		if(RenderTarget !=null) {
			IBbrushDownDX         = pBearishInsideBarBrush.ToDxBrush(RenderTarget);
			IBbrushDownDX.Opacity = pBearishInsideBarOpacity/100f;
		}
		if(BasingBarBrushDX!=null)   BasingBarBrushDX.Dispose(); BasingBarBrushDX=null;
		if(RenderTarget !=null) {
			BasingBarBrushDX         = pBasingBarBrush.ToDxBrush(RenderTarget);
			BasingBarBrushDX.Opacity = pBasingBarOpacity/100f;
		}
	}
	protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
		#region -- OnRender --
		if (!IsVisible) return;
		if(ChartControl==null) return;
		RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
		SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
		RenderTarget.AntialiasMode          = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

		int RMaB = Math.Min(Bars.Count-1, ChartBars.ToIndex);
		int LMaB = Math.Max(2, ChartBars.FromIndex);
		if(pEnableInsideBars){
			var sig = InsideBarSignals.Where(k=>k.Key >= LMaB && k.Key <= RMaB).Select(k=>k).ToList();
			foreach(var s in sig){
				OutlineThisCandle(s.Key, s.Value=='U' ? IBbrushUpDX:IBbrushDownDX, chartScale, Highs[0].GetValueAt(s.Key), Lows[0].GetValueAt(s.Key),-2);
			}
		}
		if(pEnableBasingBars){
			var sig = BasingSignals.Where(k=>k.Key >= LMaB && k.Key <= RMaB).Select(k=>k).ToList();
			foreach(var s in sig){
				OutlineThisCandle(s.Key, BasingBarBrushDX, chartScale, Opens[0].GetValueAt(s.Key), Closes[0].GetValueAt(s.Key), 1);
			}
		}
		#endregion
	}
	*/
	#endregion

		#region Properties
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Enable InsideBars", GroupName = "NinjaScriptParameters", Order = 10, Description="")]
//		public bool pEnableInsideBars		{ get; set; }

		[Display(ResourceType = typeof(Custom.Resource), Name = "Enable Basing Bars", GroupName = "NinjaScriptParameters", Order = 20, Description="")]
		public bool pEnableBasingBars		{ get; set; }

		[Range(0, 100)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Max Body Pct", GroupName = "NinjaScriptParameters", Order = 30, Description="Max body height as a percentage of the Hi-Lo range of that bar")]
		public int pMaxBodyPct				{ get; set; }

//		[XmlIgnore]
//		[Display(Order = 10, Name = "Bullish InsideBar", GroupName = "Custom Visuals")]
//		public Brush pBullishInsideBarBrush
//		{ get; set; }
//				[Browsable(false)]
//				public string pBullishInsideBarBrushSerializable { get { return Serialize.BrushToString(pBullishInsideBarBrush); } set { pBullishInsideBarBrush = Serialize.StringToBrush(value); }        }
//		[Range(0, 100)]
//		[Display(Order = 20, Name = "Opacity", GroupName = "Custom Visuals", Description="", ResourceType = typeof(Custom.Resource))]
//		public int pBullishInsideBarOpacity				{ get; set; }

//		[XmlIgnore]
//		[Display(Order = 30, Name = "Bearish InsideBar", GroupName = "Custom Visuals")]
//		public Brush pBearishInsideBarBrush
//		{ get; set; }
//				[Browsable(false)]
//				public string pBearishInsideBarBrushSerializable { get { return Serialize.BrushToString(pBearishInsideBarBrush); } set { pBearishInsideBarBrush = Serialize.StringToBrush(value); }        }
//		[Range(0, 100)]
//		[Display(Order = 40, Name = "Opacity", GroupName = "Custom Visuals", Description="", ResourceType = typeof(Custom.Resource))]
//		public int pBearishInsideBarOpacity				{ get; set; }

		[XmlIgnore]
		[Display(Order = 50, Name = "Basing Bar", GroupName = "Custom Visuals")]
		public Brush pBasingBarBrush
		{ get; set; }
				[Browsable(false)]
				public string pBasingBarBrushSerializable { get { return Serialize.BrushToString(pBasingBarBrush); } set { pBasingBarBrush = Serialize.StringToBrush(value); }        }
		[Range(0, 100)]
		[Display(Order = 60, Name = "Opacity", GroupName = "Custom Visuals", Description="", ResourceType = typeof(Custom.Resource))]
		public int pBasingBarOpacity				{ get; set; }


//		[XmlIgnore]
//		[Display(Order = 10, Name = "Bullish ComboBar", GroupName = "Custom Visuals - Both Signals")]
//		public Brush pBullishComboBarBrush
//		{ get; set; }
//				[Browsable(false)]
//				public string pBullishComboBarBrushSerializable { get { return Serialize.BrushToString(pBullishComboBarBrush); } set { pBullishComboBarBrush = Serialize.StringToBrush(value); }        }
//		[Range(0, 100)]
//		[Display(Order = 20, Name = "Opacity", GroupName = "Custom Visuals - Both Signals", Description="", ResourceType = typeof(Custom.Resource))]
//		public int pBullishComboBarOpacity				{ get; set; }

//		[XmlIgnore]
//		[Display(Order = 30, Name = "Bearish ComboBar", GroupName = "Custom Visuals - Both Signals")]
//		public Brush pBearishComboBarBrush
//		{ get; set; }
//				[Browsable(false)]
//				public string pBearishComboBarBrushSerializable { get { return Serialize.BrushToString(pBearishComboBarBrush); } set { pBearishComboBarBrush = Serialize.StringToBrush(value); }        }
//		[Range(0, 100)]
//		[Display(Order = 40, Name = "Opacity", GroupName = "Custom Visuals - Both Signals", Description="", ResourceType = typeof(Custom.Resource))]
//		public int pBearishComboBarOpacity				{ get; set; }

		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_BaseBars[] cacheARC_BaseBars;
		public ARC.ARC_BaseBars ARC_BaseBars()
		{
			return ARC_BaseBars(Input);
		}

		public ARC.ARC_BaseBars ARC_BaseBars(ISeries<double> input)
		{
			if (cacheARC_BaseBars != null)
				for (int idx = 0; idx < cacheARC_BaseBars.Length; idx++)
					if (cacheARC_BaseBars[idx] != null &&  cacheARC_BaseBars[idx].EqualsInput(input))
						return cacheARC_BaseBars[idx];
			return CacheIndicator<ARC.ARC_BaseBars>(new ARC.ARC_BaseBars(), input, ref cacheARC_BaseBars);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_BaseBars ARC_BaseBars()
		{
			return indicator.ARC_BaseBars(Input);
		}

		public Indicators.ARC.ARC_BaseBars ARC_BaseBars(ISeries<double> input )
		{
			return indicator.ARC_BaseBars(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_BaseBars ARC_BaseBars()
		{
			return indicator.ARC_BaseBars(Input);
		}

		public Indicators.ARC.ARC_BaseBars ARC_BaseBars(ISeries<double> input )
		{
			return indicator.ARC_BaseBars(input);
		}
	}
}

#endregion
