#define DoLicense
#define MODERATORS
//#define ENABLE_CURRENTCURVE
//#define USE_WPF_COORDS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using System.Threading;
using System.Globalization;
using System.Linq;

using System.Windows.Automation;
using System.Windows.Controls;
//using System.Windows.Input;
using System.Windows;
#endregion

#region Author/Copyright
/*********************************************************************
****************************** NeuroStreet ***************************
**********************************************************************
* Author NT8 : Kriss { AzurITec } + Ben Letto {SBG Trading}
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##########################################################################################################################
--------------------------------------------------------------------------------------------------------------------------
v1.0    - Jun 12 2018  + Launch - StructureSwing code borrowed from GF_System_MTF, Curve drawing code from SDVolumeZones
--------------------------------------------------------------------------------------------------------------------------
v1.1    - Jul 13 2018  + Added "Show Midline" feature to 'StructureDetector Parameters'
					   + Fixed - was not printing all price/percent values on curve at 0 and 100
--------------------------------------------------------------------------------------------------------------------------
v1.2    - Jul 31 2018  + Bug fix to printing of midline
--------------------------------------------------------------------------------------------------------------------------
v1.3    - Sept 7 2018  + Added/enhanced support for MarketAnalyzer (PermissiveSignal, CurveState, StructureState)
                       + Removed "DisplayName"...it was preventing customization of MarketAnalyzer header info
--------------------------------------------------------------------------------------------------------------------------
v1.4    - Sept 13 2018 + Changed logic for current day DailyCurve.  See both code statements under "commented out for v1.4"
--------------------------------------------------------------------------------------------------------------------------
v1.5    - Oct 26 2018  + Added Aggressive Buy, Sell Permissive Signal types
--------------------------------------------------------------------------------------------------------------------------
v1.6    - Nov 20 2018  + Changed Structure Detector to a more comprehensive Sentiment triple box, for StructureBias, CurveState and Permission
--------------------------------------------------------------------------------------------------------------------------
v1.7    - March 1 2019 + Removed the public properties for "CurrentCurve".  The NinjaScript footer code ignores conditional compilation regions, thus making inaccurate NinjaScript footer code
--------------------------------------------------------------------------------------------------------------------------
v1.8    - Dec 10 2019  + Moved all Series<double> inits to the DataLoaded state, for compatibility with 8.0.20.0
--------------------------------------------------------------------------------------------------------------------------
		PermissiveSignal:
			CONSERVATIVE_UP   = 1
			CONSERVATIVE_DOWN = -1
			AGGRESSIVE_UP     = 2
			AGGRESSIVE_DOWN   = -2
		CurveState:
			Positive if above midline
			Negative if below midline
		StructureState:
			DOWN = -1
			NONE = 0
			UP = 1

*/
#endregion

#region -- Global Enums --
	public enum ARC_SwingPointConfluence_StrengthTypes {Count, Age, AvgPoints, GrossPoints}
	public enum ARC_SwingPointConfluence_HistoLoc {Left, Right}
	public enum ARC_SwingPointConfluence_ZoneDisplay {SupportOnly, ResistanceOnly, Both}
#endregion
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	#region -- Category Order --
	[CategoryOrder("Data Parameters",       10)]
	[CategoryOrder("SwingTrend Parameters", 20)]
	[CategoryOrder("Swing Visuals",       30)]
	[CategoryOrder("Dynamic Focus",       40)]
	[CategoryOrder("Zone Visuals",        50)]
	[CategoryOrder("Custom Visuals",      60)]
	[CategoryOrder("Indicator Version", 1000)]
	#endregion
    public class ARC_SwingPointConfluence : Indicator
    {
		private const int UP   = 1;
		private const int FLAT = 0;
		private const int DOWN = -1;

		private string OnStateChange_StatusMsg = string.Empty;
		private bool ValidLicense   = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "SwingPtConf";

		private string VERSION = "v1.0 24-Aug-23";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "25690", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsDebug = false;

		private int line = 0;
		private bool generalError = false;

		#region  ----- Variables for button interface ----- 
		private int pButtonSize = 15;
		private string toolbarname = "ARCSwPtConflTB", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;

		private Menu MenuControlContainer;
		private MenuItem MenuControl;

		private MenuItem miRecalculate1, miUseDynamicFocus, miStrengthBasis, miZonesToDisplay;
		private TextBox tb_SwingStrength, tb_StartDate, tb_EndDate, tb_BkgDataMinuteValue, tb_ZoneSizeTicks, tb_DynamicFocusATRmult, tb_MinimumStrengthPctile;

		#endregion

        private int diff = 0;
//		SortedDictionary<double, int> AllLevels = new SortedDictionary<double, int>();
        private DashStyleHelper pDashStyle = DashStyleHelper.Solid;

//        private SimpleFont ButtonFont = new SimpleFont("Arial", 12) { Bold = true };

		private int rHeight = 26;
		#region ----------  UI button pulldown  ----------
		#region ----- ChangeTextBoxValue -----
		private void ChangeTextValue(string Name, string Value, double Delta){
try{
			Value = Value.Replace("-",string.Empty).Trim();//no negative values allowed
			double incr = 0;
			if(!double.IsNaN(Delta)) {
				incr = Delta > 0 ? 1 : (Delta < 0 ? -1 : 0);
			}
			//Print("Name: "+Name);
			if (Value.Length > 0)
			{
				if (Name.StartsWith("tb_SwingStrength")) {
					Value = Value.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
					if(incr!=0){
						pSwingStrength = Math.Max(1,Math.Min(200,Convert.ToInt32(Value) + (int)incr));
						tb_SwingStrength.Text = pSwingStrength.ToString();
					}else{
						pSwingStrength = Math.Max(1,Math.Min(200,Convert.ToInt32(Value)));
						tb_SwingStrength.Text = Value;
					}
					this.InformUserAboutRecalculation();
				}
				else if (Name.StartsWith("tb_BkgDataMinuteValue")) {
					Value = Value.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
					if(incr!=0){
						pBkgDataMinuteValue = Math.Max(1,Math.Min(2000,Convert.ToInt32(Value) + (int)incr));
						tb_BkgDataMinuteValue.Text = pBkgDataMinuteValue.ToString();
					}else{
						pBkgDataMinuteValue = Math.Max(1,Math.Min(2000,Convert.ToInt32(Value)));
						tb_BkgDataMinuteValue.Text = Value;
					}
					this.InformUserAboutRecalculation();
				}
				else if (Name.StartsWith("tb_ZoneSizeTicks")) {
					Value = Value.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
					if(incr!=0){
						pZoneSizeTicks = Math.Max(1,Math.Min(2000,Convert.ToInt32(Value) + (int)incr));
						tb_ZoneSizeTicks.Text = pZoneSizeTicks.ToString();
					}else{
						pZoneSizeTicks = Math.Max(1,Math.Min(2000,Convert.ToInt32(Value)));
						tb_ZoneSizeTicks.Text = Value;
					}
					this.InformUserAboutRecalculation();
				}
				else if (Name.StartsWith("tb_MinimumStrengthPctile")) {
					if(incr!=0){
						pMinimumStrengthPctile = Math.Max(0,Math.Min(1,Convert.ToDouble(Value) + incr/20.0));
						tb_MinimumStrengthPctile.Text = pMinimumStrengthPctile.ToString();
					}else{
						pMinimumStrengthPctile = Math.Max(0,Math.Min(1,Convert.ToDouble(Value)));
						tb_MinimumStrengthPctile.Text = Value;
					}
					this.CalculateMinimumPlottingStrength(ref MinStrength);
					ForceRefresh();
//					this.InformUserAboutRecalculation();
				}
				else if (Name.StartsWith("tb_DynamicFocusATRmult")) {
					if(incr!=0){
						pDynamicFocusATRmult = Math.Max(0.1,Math.Min(100,Convert.ToDouble(Value) + incr/10.0));
						tb_DynamicFocusATRmult.Text = pDynamicFocusATRmult.ToString();
					}else{
						pDynamicFocusATRmult = Math.Max(0.1,Math.Min(100,Convert.ToDouble(Value)));
						tb_DynamicFocusATRmult.Text = Value;
					}
				}
			}
}catch(Exception e){Print(line+": "+e.ToString());}
		}
		#endregion
		#region  ----- createDoubleTextBox ----- 
        private Grid createDoubleTextBox(string name, string HeaderTxt, ref TextBox tb, string tb_Value)
        {
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });

			int row = 0;
			var lbl1 = new Label() { FontWeight=FontWeights.Normal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = HeaderTxt};
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 2);

			tb = new TextBox() { Name = name + uID, HorizontalContentAlignment=HorizontalAlignment.Center, VerticalContentAlignment=VerticalAlignment.Center, 
				MinWidth = 25, Width = 50, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0)};
			tb.Text = tb_Value;
			if(name.Contains("DynamicFocusATRmult")){
				#region ----- pDynamicFocusATRmult -----
				tb.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
					e.Handled = true;
					var original = pSwingStrength;
					if(e.Delta>0) pDynamicFocusATRmult = pDynamicFocusATRmult + 0.1; else pDynamicFocusATRmult = pDynamicFocusATRmult - 0.1;
					pDynamicFocusATRmult = Math.Max(0.1,Math.Min(100,pDynamicFocusATRmult));
					if(original != pDynamicFocusATRmult) InformUserAboutRecalculation();
					var temp = Convert.ToInt32(pDynamicFocusATRmult/0.1);
					pDynamicFocusATRmult = temp*0.1;
					tb_DynamicFocusATRmult.Text = pDynamicFocusATRmult.ToString();
					ForceRefresh();
					};
				#endregion
			}else if(name.Contains("MinimumStrengthPctile")){
				#region ----- pMinimumStrengthPctile -----
				tb.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
					e.Handled = true;
					var original = pMinimumStrengthPctile;
					var incr = 0.05;
					if(System.Windows.Input.Keyboard.IsKeyDown(System.Windows.Input.Key.LeftShift))incr = 0.01;
					if(e.Delta>0) pMinimumStrengthPctile = pMinimumStrengthPctile + incr; else pMinimumStrengthPctile = pMinimumStrengthPctile - incr;
					pMinimumStrengthPctile = Math.Max(0.0,Math.Min(1,pMinimumStrengthPctile));
					if(original != pMinimumStrengthPctile) InformUserAboutRecalculation();
					var temp = Convert.ToInt32(pMinimumStrengthPctile/incr);
					pMinimumStrengthPctile = temp * incr;
					tb_MinimumStrengthPctile.Text = pMinimumStrengthPctile.ToString();
					this.CalculateMinimumPlottingStrength(ref MinStrength);
					ForceRefresh();
					};
				#endregion
			}

			tb.KeyDown += numericTxtbox_KeyDown;
			tb.SetValue(Grid.ColumnProperty, 1);
			tb.SetValue(Grid.RowProperty, row);
			tb.SetValue(Grid.RowSpanProperty, 2);
			grid.Children.Add(lbl1);
            grid.Children.Add(tb);

            return grid;
        }
		#endregion
		#region  ----- createIntegerTextBox ----- 
        private Grid createIntegerTextBox(string name, string HeaderTxt, ref TextBox tb, string tb_Value)
        {
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });

			int row = 0;
			var lbl1 = new Label() { FontWeight=FontWeights.Normal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = HeaderTxt};
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 2);

			tb = new TextBox() { Name = name + uID, HorizontalContentAlignment=HorizontalAlignment.Center, VerticalContentAlignment=VerticalAlignment.Center, 
				MinWidth = 25, Width = 50, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0)};
			tb.Text = tb_Value;
			tb.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				var tbi = (TextBox)o;
				ChangeTextValue(tbi.Name, tbi.Text, e.Delta);
			};

			tb.KeyDown += numericTxtbox_KeyDown;
			tb.SetValue(Grid.ColumnProperty, 1);
			tb.SetValue(Grid.RowProperty, row);
			tb.SetValue(Grid.RowSpanProperty, 2);
			grid.Children.Add(lbl1);
            grid.Children.Add(tb);

            return grid;
        }
		#endregion
		#region -- createDateTextBox --
        private Grid createDateTextBox(string name, string HeaderTxt, ref TextBox tb, string tb_Value)
        {
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
//			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
//			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(30) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2), Focusable=false });

			int row = 0;
			var lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = HeaderTxt, FontWeight=FontWeights.Normal };
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, row);
			lbl1.SetValue(Grid.RowSpanProperty, 2);

			tb = new TextBox() { Name = name + uID, FontWeight=FontWeights.Normal, HorizontalContentAlignment=HorizontalAlignment.Center, VerticalContentAlignment=VerticalAlignment.Center, MinWidth = 25, Width = 75, MaxWidth = 105, Height = rHeight, Margin = new Thickness(5, 0, 0, 0)};
			tb.Text = tb_Value;
			tb.KeyDown += menuDateTxtbox_KeyDown;
			if(name.StartsWith("tb_Start")){
				tb.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
					e.Handled = true;
					var original = pBkgDataStartDT;
					if(e.Delta>0) pBkgDataStartDT = pBkgDataStartDT.AddDays(1); else pBkgDataStartDT = pBkgDataStartDT.AddDays(-1);
					if(original != pBkgDataStartDT){
						InformUserAboutRecalculation();
						tb_StartDate.Text = pBkgDataStartDT.ToShortDateString();
					}
					};
			}
			else if(name.StartsWith("tb_End")){
				tb.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
					e.Handled = true;
					var original = pBkgDataEndDT;
					if(e.Delta>0) pBkgDataEndDT = pBkgDataEndDT.AddDays(1); else pBkgDataEndDT = pBkgDataEndDT.AddDays(-1);
					if(original != pBkgDataEndDT){
						InformUserAboutRecalculation();
						tb_EndDate.Text = pBkgDataEndDT.ToShortDateString();
					}
					};
			}

			tb.SetValue(Grid.ColumnProperty, 1);
			tb.SetValue(Grid.RowProperty, row);
			tb.SetValue(Grid.RowSpanProperty, 2);
			grid.Children.Add(lbl1);
            grid.Children.Add(tb);

            return grid;
        }
		#endregion
		#region  ----- menuDateTxtbox_KeyDown ----- 
		private void menuDateTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			int DASH = -2;
			int SLASH = -3;
			e.Handled = true;
			TextBox txtSender = sender as TextBox;
			var OriginalText = txtSender.Text;
			int keyVal = (int)e.Key;

			int value = -1;
			if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
				value = keyVal - (int)System.Windows.Input.Key.D0;
			else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
				value = keyVal - (int)System.Windows.Input.Key.NumPad0;
			else if (keyVal == (int)System.Windows.Input.Key.Divide || keyVal == (int)System.Windows.Input.Key.OemQuestion) 
				value = SLASH;
			else if (keyVal == (int)System.Windows.Input.Key.Subtract || keyVal == (int)System.Windows.Input.Key.OemMinus)
				value = DASH;

			bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.Decimal;
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.OemPeriod;
			if (isNumeric || value==DASH || value==SLASH || e.Key == System.Windows.Input.Key.Back){
				string newText = string.Empty;
				if(value==DASH) newText = "-";
				else if(value==SLASH) newText = @"/";
				else if(value != -1) newText = value.ToString();

				int tbPosition = txtSender.SelectionStart;
				try{
					if(txtSender.SelectedText.Length==0)
						txtSender.Text = txtSender.Text.Insert(tbPosition, newText);
					else
						txtSender.Text.Replace(txtSender.SelectedText, newText);
				}catch(Exception t){ Print(t.ToString()); }
				txtSender.Select(tbPosition + 1, 0);
				DateTime dt;
				if(DateTime.TryParse(txtSender.Text, out dt)){
					if(txtSender.Name.Contains("tb_Start")) this.pBkgDataStartDT = dt;
					else if(txtSender.Name.Contains("tb_End")) this.pBkgDataEndDT = dt;
				}
			}
		}
		private void numericTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			e.Handled = true;
			TextBox txtSender = sender as TextBox;
			int keyVal = (int)e.Key;

			int value = -1;
			if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
				value = keyVal - (int)System.Windows.Input.Key.D0;
			else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
				value = keyVal - (int)System.Windows.Input.Key.NumPad0;

			bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.Decimal;
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.OemPeriod;
			if (isNumeric || e.Key == System.Windows.Input.Key.Back)
			{
				string newText = value != -1 ? value.ToString() : "";
				if(!txtSender.Text.Contains(".")){
					if(e.Key==System.Windows.Input.Key.Decimal) newText = ".";
					else if(e.Key==System.Windows.Input.Key.OemPeriod) newText = ".";
				}
				int tbPosition = txtSender.SelectionStart;
				try{
					if(txtSender.SelectedText.Length==0)
						txtSender.Text = txtSender.Text.Insert(tbPosition, newText);
					else
						txtSender.Text.Replace(txtSender.SelectedText, newText);
				}catch(Exception t){Print(t.ToString());}
				txtSender.Select(tbPosition + 1, 0);
			}
			ChangeTextValue(txtSender.Name, txtSender.Text, 0);
		}
		#endregion

//=====================================================================================================
		private void InformUserAboutRecalculation(){
			if(miRecalculate1!=null){
				miRecalculate1.Background = Brushes.Yellow;
				miRecalculate1.FontWeight = FontWeights.Bold;
				miRecalculate1.FontStyle  = FontStyles.Italic;
			}
		}
		private void ResetRecalculationUI(){
			if(miRecalculate1!=null){
				miRecalculate1.FontWeight = FontWeights.Normal;
				miRecalculate1.FontStyle  = FontStyles.Normal;
				miRecalculate1.Background = null;
			}
		}
		#region  ----- addToolBar ----- 
		private void addToolBar()
		{
			MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
			MenuControl          = new MenuItem { Name="ARC_SPC"+uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Cyan, Header = pButtonText, Foreground = Brushes.Cyan, Background = Brushes.Navy, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);

			MenuControl.Items.Add(createDateTextBox("tb_StartDate","Start date: ", ref tb_StartDate, this.pBkgDataStartDT.ToShortDateString()));
			MenuControl.Items.Add(createDateTextBox("tb_EndDate", "End date: ", ref tb_EndDate, this.pBkgDataEndDT.ToShortDateString()));
			MenuControl.Items.Add(createIntegerTextBox("tb_BkgDataMinuteValue", "Bkg timeframe (min): ", ref tb_BkgDataMinuteValue, this.pBkgDataMinuteValue.ToString()));
			MenuControl.Items.Add(createIntegerTextBox("tb_ZoneSizeTicks", "Zone Height (ticks): ", ref tb_ZoneSizeTicks, this.pZoneSizeTicks.ToString()));
			#region -- ZonesToDisplay --
			miZonesToDisplay = new MenuItem { Header = "Zones to display: "+this.pZonesToDisplay.ToString(), Name = "miZonesToDisplay"+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miZonesToDisplay.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(pZonesToDisplay == ARC_SwingPointConfluence_ZoneDisplay.Both) pZonesToDisplay = ARC_SwingPointConfluence_ZoneDisplay.ResistanceOnly;
				else if(pZonesToDisplay == ARC_SwingPointConfluence_ZoneDisplay.ResistanceOnly) pZonesToDisplay = ARC_SwingPointConfluence_ZoneDisplay.SupportOnly;
				else if(pZonesToDisplay == ARC_SwingPointConfluence_ZoneDisplay.SupportOnly) pZonesToDisplay = ARC_SwingPointConfluence_ZoneDisplay.Both;
				miZonesToDisplay.Header = "Zones to display: "+this.pZonesToDisplay.ToString();
				ForceRefresh();
			};
			miZonesToDisplay.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0){
					if(pZonesToDisplay == ARC_SwingPointConfluence_ZoneDisplay.Both) pZonesToDisplay = ARC_SwingPointConfluence_ZoneDisplay.ResistanceOnly;
					else if(pZonesToDisplay == ARC_SwingPointConfluence_ZoneDisplay.ResistanceOnly) pZonesToDisplay = ARC_SwingPointConfluence_ZoneDisplay.SupportOnly;
					else if(pZonesToDisplay == ARC_SwingPointConfluence_ZoneDisplay.SupportOnly) pZonesToDisplay = ARC_SwingPointConfluence_ZoneDisplay.Both;
				}else{
					if(pZonesToDisplay == ARC_SwingPointConfluence_ZoneDisplay.Both) pZonesToDisplay = ARC_SwingPointConfluence_ZoneDisplay.SupportOnly;
					else if(pZonesToDisplay == ARC_SwingPointConfluence_ZoneDisplay.ResistanceOnly) pZonesToDisplay = ARC_SwingPointConfluence_ZoneDisplay.Both;
					else if(pZonesToDisplay == ARC_SwingPointConfluence_ZoneDisplay.SupportOnly) pZonesToDisplay = ARC_SwingPointConfluence_ZoneDisplay.ResistanceOnly;
				}
				miZonesToDisplay.Header = "Zones to display: "+this.pZonesToDisplay.ToString();
				ForceRefresh();
			};
			#endregion
			MenuControl.Items.Add(miZonesToDisplay);

			MenuControl.Items.Add(new Separator());
			#region -- StrengthBasis --
			miStrengthBasis = new MenuItem { Header = "Strength Basis: "+this.pStrengthBasis.ToString(), Name = "miStrengthBasis"+uID, FontWeight=FontWeights.Normal, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miStrengthBasis.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.Age) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.AvgPoints;
				else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.AvgPoints) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.Count;
				else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.Count) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.GrossPoints;
				else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.GrossPoints) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.Age;
				miStrengthBasis.Header = "Strength Basis: "+this.pStrengthBasis.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miStrengthBasis.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0){
					if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.Age) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.AvgPoints;
					else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.AvgPoints) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.Count;
					else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.Count) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.GrossPoints;
					else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.GrossPoints) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.Age;
				}else{
					if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.Age) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.GrossPoints;
					else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.AvgPoints) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.Age;
					else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.Count) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.AvgPoints;
					else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.GrossPoints) pStrengthBasis = ARC_SwingPointConfluence_StrengthTypes.Count;
				}
				miStrengthBasis.Header = "Strength Basis: "+this.pStrengthBasis.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			#endregion
			MenuControl.Items.Add(miStrengthBasis);
			MenuControl.Items.Add(createDoubleTextBox("tb_MinimumStrengthPctile", "Minimum Strength Percentile: ", ref tb_MinimumStrengthPctile, pMinimumStrengthPctile.ToString()));

			MenuControl.Items.Add(new Separator());
			#region -- UseDynamicFocus --
			miUseDynamicFocus = new MenuItem { Header = pUseDynamicFocus ? "Dynamic Focus ON" : "Dynamic Focus OFF", Name = "miUseDynamicFocus"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			if(!pUseDynamicFocus) miUseDynamicFocus.FontWeight = FontWeights.Light;
			miUseDynamicFocus.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pUseDynamicFocus = !pUseDynamicFocus;
				miUseDynamicFocus.Header = pUseDynamicFocus ? "Dynamic Focus ON" : "Dynamic Focus OFF";
				if(!pUseDynamicFocus){
					miUseDynamicFocus.FontWeight = FontWeights.Light;
					DynamicFocusZones.Clear();
					CalculateMinimumPlottingStrength(ref MinStrength);
					tb_DynamicFocusATRmult.IsEnabled = false;
				}else{
					miUseDynamicFocus.FontWeight = FontWeights.Normal;
					CalculateMinimumPlottingStrength(ref MinStrength);
					tb_DynamicFocusATRmult.IsEnabled = true;
				}
//				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miUseDynamicFocus.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
				e.Handled = true;
				pUseDynamicFocus = !pUseDynamicFocus;
				miUseDynamicFocus.Header = pUseDynamicFocus ? "Dynamic Focus ON" : "Dynamic Focus OFF";
				if(!pUseDynamicFocus){
					miUseDynamicFocus.FontWeight = FontWeights.Light;
					DynamicFocusZones.Clear();
					CalculateMinimumPlottingStrength(ref MinStrength);
					tb_DynamicFocusATRmult.IsEnabled = false;
				}else{
					miUseDynamicFocus.FontWeight = FontWeights.Normal;
					CalculateMinimumPlottingStrength(ref MinStrength);
					tb_DynamicFocusATRmult.IsEnabled = true;
				}
				ForceRefresh();
			};
			#endregion
			MenuControl.Items.Add(miUseDynamicFocus);
			#region -- DynamicFocusATRmult --
			MenuControl.Items.Add(createDoubleTextBox("tb_DynamicFocusATRmult", "Dynamic Focus ATRmult: ", ref tb_DynamicFocusATRmult, this.pDynamicFocusATRmult.ToString()));
			tb_DynamicFocusATRmult.IsEnabled = pUseDynamicFocus;
			#endregion
			MenuControl.Items.Add(new Separator());

			#region -- RegMarketSwings submenu --
			var miMarketSwingsSubMenu = new MenuItem { Header = "Market Swings", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
				#region -- Show Swing Lines --
				var miMarketSwingLines = new MenuItem { Header = pShowSwingLines ? "Swing Lines ON" : "Swing Lines OFF", Name = "miMarketSwingLines"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
				if(!pShowSwingLines) miMarketSwingLines.FontWeight = FontWeights.Light;
				miMarketSwingLines.Click += delegate (object o, RoutedEventArgs e){
					e.Handled = true;
					this.pShowSwingLines = !pShowSwingLines;
					miMarketSwingLines.Header = pShowSwingLines ? "Swing Lines ON" : "Swing Lines OFF";
					if(!pShowSwingLines) miMarketSwingLines.FontWeight = FontWeights.Light; else miMarketSwingLines.FontWeight = FontWeights.Normal;
	//				InformUserAboutRecalculation();
					ForceRefresh();
				};
				miMarketSwingLines.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
					e.Handled = true;
					this.pShowSwingLines = !pShowSwingLines;
					miMarketSwingLines.Header = pShowSwingLines ? "Swing Lines ON" : "Swing Lines OFF";
					if(!pShowSwingLines) miMarketSwingLines.FontWeight = FontWeights.Light; else miMarketSwingLines.FontWeight = FontWeights.Normal;
				};
				#endregion
				miMarketSwingsSubMenu.Items.Add(miMarketSwingLines);

				#region -- Show Swing Labels --
				MenuItem miShowSwingLabels = new MenuItem { Header = pShowSwingLabels ? "Swing Labels ON" : "Swing Labels OFF", Name = "miShowSwingLabels"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
				if(!pShowSwingLabels) miShowSwingLabels.FontWeight = FontWeights.Light;
				miShowSwingLabels.Click += delegate (object o, RoutedEventArgs e){
					e.Handled = true;
					this.pShowSwingLabels = !pShowSwingLabels;
					miShowSwingLabels.Header = pShowSwingLabels ? "Swing Labels ON" : "Swing Labels OFF";
					if(!pShowSwingLabels) miShowSwingLabels.FontWeight = FontWeights.Light; else miShowSwingLabels.FontWeight = FontWeights.Normal;
	//				InformUserAboutRecalculation();
					ForceRefresh();
				};
				miShowSwingLabels.MouseWheel += delegate (object o, System.Windows.Input.MouseWheelEventArgs e){
					e.Handled = true;
					this.pShowSwingLabels = !pShowSwingLabels;
					miShowSwingLabels.Header = pShowSwingLabels ? "Swing Labels ON" : "Swing Labels OFF";
					if(!pShowSwingLabels) miShowSwingLabels.FontWeight = FontWeights.Light; else miShowSwingLabels.FontWeight = FontWeights.Normal;
				};
				#endregion
				miMarketSwingsSubMenu.Items.Add(miShowSwingLabels);
				miMarketSwingsSubMenu.Items.Add(new Separator());
				miMarketSwingsSubMenu.Items.Add(createIntegerTextBox("tb_SwingStrength", "Swing strength: ", ref tb_SwingStrength, this.pSwingStrength.ToString()));

				MenuControl.Items.Add(miMarketSwingsSubMenu);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Recalc --
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", Name = "btn_Recalc1"+uID, HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				this.pSwingStrength       = Math.Max(1,Math.Min(200,Convert.ToInt32(tb_SwingStrength.Text)));
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			MenuControl.Items.Add(miRecalculate1);
			#endregion
		//------------------

			indytoolbar.Children.Add(MenuControlContainer);
		}
		#endregion
		#endregion

		private SwingData SwingMgr = null;
		private class SwingData {
			public class bardata{
				public double O = 0;
				public double H = 0;
				public double L = 0;
				public double C = 0;
				public char Trend = ' ';
				public DateTime T;
				public bardata(double o, double h, double l, double c, DateTime t) {O=o; H=h; L=l; C=c; T=t;}
			}
			public class strengthdata{
				public int AgeInBars = 0;
				public double MFEpts = 0;
				public char Status = 'O';//'O' for open and available for updating, 'F' for finished
			}
			private const double UP   = 1;
			private const double DOWN = -1;
			#region  ----- SwingData class -----
			public SortedDictionary<int, double[]>	   AllPivots		= new SortedDictionary<int, double[]>();//one record for each pivot bar.  The first double is the trend +1 or -1, the 2nd double initial swing price, and if there's a final swing price on that bar, the 3rd double will hold that price.
			public SortedDictionary<int, strengthdata> PivotStrengths	= new SortedDictionary<int, strengthdata>();// max extended price of the swing move, age of that swing, in bars
			public SortedDictionary<int, bardata>	   OHLC				= new SortedDictionary<int, bardata>();
			//public SortedDictionary<int,byte>	Bias = new SortedDictionary<int,byte>();
			public int    pSwingStrength = 0;
			public int    CB    = 0;//this is the bar index of the background data
			public bool   isHLBased     = false;
			public double ExtentOfMove  = double.NaN;
			public string StatusMsg			= string.Empty;
			public double HighestSwingPrice = double.MinValue;
			public double LowestSwingPrice  = double.MaxValue;
			public double ZoneHeightPts = 0;
			public bool   CalculateOnBarClose = false;
			public bool	  IsRealTime = false;
			public bool z = false;

//			public SortedDictionary<int, char> Trend = new SortedDictionary<int,char>();
			#region  ----- properties ----- 
			private NinjaTrader.NinjaScript.IndicatorBase Parent;
			private bool updateHigh=false;
			private bool updateLow=false;
			private bool addHigh=false;
			private bool addLow=false;
			private int offset = 0;
			#endregion
			public SwingData(int swingStrength, bool is_hlBased, bool calcOnBarClose, NinjaTrader.NinjaScript.IndicatorBase parent){
				pSwingStrength = swingStrength;
				isHLBased     = is_hlBased; 
				CalculateOnBarClose = calcOnBarClose; 
				offset = calcOnBarClose ? 0 : 1;
				Parent = parent;
			}

			#region Methods
			private double MAX(ISeries<double> series, int lookback, int rbar_offset){
				double max = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) {
						if(i>=series.Count) return max;
						max = Math.Max(max, series[i]);
					}
				}catch{}
				return max;
			}
			private double MIN(ISeries<double> series, int lookback, int rbar_offset){
				double min = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) {
						if(i>=series.Count) return min;
						min = Math.Min(min, series[i]);
					}
				}catch{}
				return min;
			}
			private double MAX(SortedDictionary<int,bardata> data, int lookback, int abar){
int l = 1;
				double max = 0;
				try{
					max = data[abar].H;
					for(int i = abar-1; i>Math.Max(0,abar-lookback); i--) {
						if(i<=0) return max;
						if(data.ContainsKey(i)) max = Math.Max(max, data[i].H);
					}
				}catch{
//					var keys = data.Keys.Where(k=>k > abar-5050).ToList();
					Parent.Print("Err: "+l+"   abar: "+abar+"  data.Count: "+data.Count);
//					foreach(var xx in keys)Parent.Print("Key: "+xx+"   t: "+data[xx].T);
				}
				return max;
			}
			private double MIN(SortedDictionary<int,bardata> data, int lookback, int abar){
				double min = 0;
				try{
					min = data[abar].L;
					for(int i = abar-1; i>Math.Max(0,abar-lookback); i--) {
						if(i<=0) return min;
						if(data.ContainsKey(i)) min = Math.Min(min, data[i].L);
					}
				}catch{}
				return min;
			}
			public void AddToAllPivots(ref int line, int idx, char current_trend, char new_trend, bool pUseChartData, double price1, double price2=double.NaN){
				if(AllPivots.Count==0) {
					AllPivots[idx] = new double[]{UP, price1, price2};
					return;
				}
				bool IsOutsideBar = double.IsNaN(price2)==false;
				bool IsPriorBarOutside = double.IsNaN(AllPivots.Last().Value[2])==false;//if the prior bar was an outside bar
				double priorleadprice = IsPriorBarOutside ? AllPivots.Last().Value[2] : AllPivots.Last().Value[1];
				double newleadprice = IsOutsideBar ? price2 : price1;
				int LastIdx = AllPivots.Keys.Max();
//				int fudge = IsRealTime ? idx:idx+ (pUseChartData ? 1:0);
				int fudge = IsRealTime ? idx- (pUseChartData ? 1:0):idx;
				#region -- Add pivot logic --
if(z) Parent.Print("AddToAllPivots:   current_trend: "+current_trend+"  new_trend: "+new_trend);

//if(z) Parent.Print("a AddToAllPivots:   priorleadprice: "+priorleadprice+"  new leadprice: "+newleadprice);
				if(current_trend=='u' && new_trend=='u'){
// TREND CONTINUATION conditions
					if(!IsOutsideBar && newleadprice < priorleadprice) return;//outside bars are interior trend reversals, you must respect the lower low
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("b AddToAllPivots:   PriorBarOutside and current bar outside - adding new swing bar UP at "+price1+"  and : "+price2);
						AllPivots[fudge] = new double[]{UP, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("c AddToAllPivots:   not PriorBarOutside and current bar outside - adding new swing bar UP at "+price1+"  and : "+price2);
						AllPivots[fudge] = new double[]{UP, price1, price2};
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
if(z) Parent.Print("d AddToAllPivots:   not PriorBarOutside and not current bar outside - removing prior swing bar, adding new swing bar UP at "+price1+"  and : "+price2);
						var remove_idx = AllPivots.Keys.Max();
						AllPivots.Remove(remove_idx);//a trend continuation is taking place, the prior bar is no longer the max extent of the original trend...so remove it
//						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[fudge] = new double[]{UP, price1, price2};
					}else if(IsPriorBarOutside && !IsOutsideBar){
if(z) Parent.Print("e AddToAllPivots:   PriorBarOutside and not current bar outside - update prior swing bar leading price, adding new swing bar UP at "+price1+"  and : "+price2);
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[fudge] = new double[]{UP, price1, price2};
					}
					else{
if(z) Parent.Print("f AddToAllPivots:   else - update prior swing bar leading price, adding new swing bar UP at "+price1+"  and : "+price2);
						AllPivots[fudge] = new double[]{UP, price1, price2};
					}

				}else if(current_trend=='d' && new_trend=='d'){
// TREND CONTINUATION conditions
					if(!IsOutsideBar && newleadprice > priorleadprice) return;//outside bars are interior trend reversals, you must respect the higher high
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("b AddToAllPivots:   PriorBarOutside and current bar outside - adding new swing bar DOWN at "+price1+"  and : "+price2);
						AllPivots[fudge] = new double[]{DOWN, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("c AddToAllPivots:   not PriorBarOutside and current bar outside - adding new swing bar DOWN at "+price1+"  and : "+price2);
						AllPivots[fudge] = new double[]{DOWN, price1, price2};
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
if(z) Parent.Print("d AddToAllPivots:   not PriorBarOutside and not current bar outside - removing prior swing bar, adding new swing bar DOWN at "+price1+"  and : "+price2);
						var remove_idx = AllPivots.Keys.Max();
						AllPivots.Remove(remove_idx);//a trend continuation is taking place, the prior bar is no longer the max extent of the original trend...so remove it
//						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[fudge] = new double[]{DOWN, price1, price2};
					}
					else if(IsPriorBarOutside && !IsOutsideBar){
if(z) Parent.Print("e AddToAllPivots:   PriorBarOutside and not current bar outside - update prior swing bar leading price, adding new swing bar DOWN at "+price1+"  and : "+price2);
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher leading price is found
						AllPivots[fudge] = new double[]{DOWN, price1, price2};
					}
					else{
if(z) Parent.Print("f AddToAllPivots:   else - update prior swing bar leading price, adding new swing bar DOWN at "+price1+"  and : "+price2);
						AllPivots[fudge] = new double[]{DOWN, price1, price2};
					}
				}else if(current_trend=='d' && new_trend=='u'){//trend reversal occurred from down to up
// TREND REVERSAL conditions
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("ud w AddToAllPivots:   PriorBarOutside and current bar outside - blank out prior ending price, adding new swing bar UP at "+price1+"  and : "+price2);
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a lower low trend extending price is found on this new outside bar
						AllPivots[fudge] = new double[]{UP, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
						if(price1 <= priorleadprice){
if(z) Parent.Print("du x AddToAllPivots:   Not PriorBarOutside and current bar outside, yes new low made - adding new swing bar UP at "+price1+"  and : "+price2);
							var remove_idx = AllPivots.Keys.Max();
							AllPivots.Remove(remove_idx);
							AllPivots[fudge] = new double[]{UP, price1, price2};
						}else{
if(z) Parent.Print("du x AddToAllPivots:   Not PriorBarOutside and current bar outside, no new low made - ignoring low of current outside bar, adding new swing bar DOWN at "+price2);
							AllPivots[fudge] = new double[]{UP, price2, double.NaN};
						}
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
						AllPivots[fudge] = new double[]{UP, price1, price2};
					}else
						AllPivots[fudge] = new double[]{UP, price1, price2};

				}else if(current_trend=='u' && new_trend=='d'){//trend reversal occurred from up to down
// TREND REVERSAL conditions
					ExtentOfMove = newleadprice;
					if(IsPriorBarOutside && IsOutsideBar){
if(z) Parent.Print("ud w AddToAllPivots:   PriorBarOutside and current bar outside - blank out prior ending price, adding new swing bar DOWN at "+price1+"  and : "+price2);
						AllPivots.Last().Value[2] = double.NaN;//blank-out the prior leading price because a higher high trend extending price is found on this new outside bar
						AllPivots[fudge] = new double[]{DOWN, price1, price2};
					}
					else if(!IsPriorBarOutside && IsOutsideBar){
						if(price1 >= priorleadprice){
if(z) Parent.Print("ud x AddToAllPivots:   Not PriorBarOutside and current bar outside, yes new high made - adding new swing bar DOWN at "+price1+"  and : "+price2);
							var remove_idx = AllPivots.Keys.Max();
							AllPivots.Remove(remove_idx);//a trend reversal is taking place on an outside bar, the prior bar is no longer the max extent of the original trend...so remove it
							AllPivots[fudge] = new double[]{DOWN, price1, price2};
						}else{
if(z) Parent.Print("ud x AddToAllPivots:   Not PriorBarOutside and current bar outside, no new high made - ignoring high of current outside bar, adding new swing bar DOWN at "+price2);
							AllPivots[fudge] = new double[]{DOWN, price2, double.NaN};
						}
					}
					else if(!IsPriorBarOutside && !IsOutsideBar){
if(z) Parent.Print("ud y AddToAllPivots:   Not PriorBarOutside and Not current bar outside - adding new swing bar DOWN at "+price1+"  and : "+price2);
						AllPivots[fudge] = new double[]{DOWN, price1, price2};
					}else{
if(z) Parent.Print("ud z AddToAllPivots:   else - adding new swing bar DOWN at "+price1+"  and : "+price2);
						AllPivots[fudge] = new double[]{DOWN, price1, price2};
					}
if(z) Parent.Print("AddToAllPivots:   New low is put in...deleted the prior swing point, added a new point");
				}
				#endregion

				if(IsRealTime && AllPivots.Count>=4 && LastIdx != AllPivots.Keys.Max()){
					var keys = AllPivots.Keys.ToList();
					CalculatePivotStrengths(keys, keys.Count-4);
				}
			}
			#endregion

			private char current_trend = ' ';
			#region -- CalculateIt --
			public void CalculateIt(int cb, double o, double h, double l, double c, DateTime t, bool IsFirstTickOfBar, NinjaTrader.NinjaScript.Calculate Calculate, NinjaTrader.NinjaScript.State State, bool pUseChartData, ref int line){
line=1366;
				if(!IsRealTime)
					CB = cb;
//if(IsRealTime)Parent.Print("CB[bip]: "+CB);
				if(CB<=0) return;
				if(IsFirstTickOfBar){
//Parent.Print("FTOB adding h/l:  "+h+" / "+l+"  t: "+t.ToString());
					if(IsRealTime) CB++;
					if(isHLBased){
						OHLC[CB] = new bardata(o,h,l,c,t);//background data series, not chart data series
					}else{
						OHLC[CB] = new bardata(c,Math.Max(o,c),Math.Min(o,c),c,t);//background data series, not chart data series
					}
					if(!this.IsRealTime && OHLC.Count==1) return;
					if(!this.IsRealTime && OHLC.Count==2){
line=1373;
//foreach(var kvp in OHLC)Parent.Print("bar: "+bar+"  Key: "+kvp.Key+"  H: "+kvp.Value.H+"   t: "+kvp.Value.T.ToString());
						if(OHLC[CB].H > OHLC[CB-1].H)      {OHLC[CB].Trend ='u'; AllPivots.Add(CB, new double[3]{UP,   OHLC[CB].H, double.NaN}); ExtentOfMove = OHLC[CB].H;}
						else if(OHLC[CB].L < OHLC[CB-1].L) {OHLC[CB].Trend ='d'; AllPivots.Add(CB, new double[3]{DOWN, OHLC[CB].L,double.NaN});  ExtentOfMove = OHLC[CB].L;}
line=1376;
						return;
					}
				}else{
line=1379;
//Parent.Print("not first tick, CB: "+CB+" adding h/l:  "+h+" / "+l+"  t: "+t.ToString());
					if(isHLBased){
						OHLC[CB].H = Math.Max(h, OHLC[CB].H);
						OHLC[CB].L = Math.Min(l, OHLC[CB].L);
						OHLC[CB].C = c;
					}else{
						OHLC[CB].H = Math.Max(o,c);
						OHLC[CB].L = Math.Min(o,c);
						OHLC[CB].C = c;
					}
					OHLC[CB].T = t;
				}
line=1385;
//z = (t.Day>=8 && t.Month==8);
//if(z)Parent.Print("------------  Time: "+t.ToString());
				double H = MAX(OHLC, pSwingStrength, CB-1);
line=1387;
				double L = MIN(OHLC, pSwingStrength, CB-1);

line=1388;
//if(IsRealTime){
//	Parent.Print(CB+":  OHLC.Max: "+OHLC.Keys.Max());
//	var kidx = OHLC.Keys.Count-10;
//	var kys = OHLC.Keys.ToList();
//	for(int i = kidx; i<OHLC.Keys.Count; i++){
//		int xx = kys[i];
//		Parent.Print(xx+"  "+OHLC[xx].T);
//	}
//}
				if(OHLC[CB].H>H && OHLC[CB].L<L) OHLC[CB].Trend ='?';//this is an outside bar...meaning the trend reversal occurs on the same bar
				else if(OHLC[CB].H>H) {OHLC[CB].Trend ='u'; if(z)Parent.Print("Trend is UP");}
				else if(OHLC[CB].L<L) {OHLC[CB].Trend ='d'; if(z)Parent.Print("Trend is Down");}
				else				   {OHLC[CB].Trend = OHLC[CB-1].Trend;  if(z)Parent.Print("Trend is unchanged");}//inside bar, carry forward the existing trend
				current_trend = OHLC[CB-1].Trend;

line=1391;
				if(OHLC[CB].Trend == '?'){//this is an 'outside bar', a bar whose high is higher than the prior bar hi, and whose low is lower than the prior bar low
line=1392;
					if(OHLC[CB].C > OHLC[CB].O){//an upclosing outside bar
						OHLC[CB].Trend = 'u';//the trend is determined upward, based on the close > open
						if(current_trend == 'u'){//if the most recent trend was Up
							AddToAllPivots(ref line, CB, current_trend, 'u', pUseChartData, OHLC[CB].L, OHLC[CB].H);//in an uptrend, the outside bar reversal down is first, and the upward finish is second
							HighestSwingPrice = Math.Max(HighestSwingPrice,OHLC[CB].H);
						}else{//existing trend was down
							AddToAllPivots(ref line, CB, current_trend, 'u', pUseChartData, OHLC[CB].L, OHLC[CB].H);//in a downtrend, the down move continued, and the upward finish is second
							HighestSwingPrice = Math.Max(HighestSwingPrice, OHLC[CB].H);
						}
					}else{//a downclosing outside bar
line=1395;
						OHLC[CB].Trend = 'd';//the trend is determined downward, based on the close < open
						if(current_trend == 'd'){//if the most recent trend was Down
							AddToAllPivots(ref line, CB, current_trend, 'd', pUseChartData, OHLC[CB].H, OHLC[CB].L);//in a downtrend, the outside bar reversal up is first, and the downward finish is second
							LowestSwingPrice = Math.Min(LowestSwingPrice, OHLC[CB].L);
						}else{//existing trend was up
							AddToAllPivots(ref line, CB, current_trend, 'd', pUseChartData, OHLC[CB].H, OHLC[CB].L);//in an uptrend, the up move continued, and the downward finish is second
							LowestSwingPrice = Math.Min(LowestSwingPrice,OHLC[CB].L);
						}
					}
//}catch(Exception ee){parent.Print(line+":  "+ee.ToString());}
				}
				else if(OHLC[CB].Trend == 'u'){
					AddToAllPivots(ref line, CB, current_trend, 'u', pUseChartData, OHLC[CB].H);
					HighestSwingPrice = Math.Max(HighestSwingPrice, OHLC[CB].H);
				}
				else if(OHLC[CB].Trend == 'd'){
					AddToAllPivots(ref line, CB, current_trend, 'd', pUseChartData, OHLC[CB].L);
//Parent.Print("New trend Down from pivot of "+Parent.Times[0].GetValueAt(AllPivots.Last().Key).ToString());
					LowestSwingPrice = Math.Min(LowestSwingPrice,OHLC[CB].L);
				}
line=1405;
			}
			#endregion
			public void CreateZones(SortedDictionary<int, ZoneData> Zones, double NewSwingPrice, int zoneHeightTicks=-1){//, double TickSize){
				if(Zones.Count==0){
					if(zoneHeightTicks<0) return;
					ZoneHeightPts = Parent.TickSize * zoneHeightTicks;
					double p = LowestSwingPrice;
					while(p <= HighestSwingPrice){
						int k = Convert.ToInt32(p/Parent.TickSize);
						if(!Zones.ContainsKey(k)) Zones[k] = new ZoneData(p+ZoneHeightPts, p);
						p = p + ZoneHeightPts;
					}
					return;
				}else{
					double p = Parent.Instrument.MasterInstrument.RoundToTickSize(NewSwingPrice);
					var newkey = Convert.ToInt32(p/Parent.TickSize);
					int k = 0;
					int maxk = Zones.Keys.Max();
					int mink = Zones.Keys.Min();
					char AddType = newkey < mink ? 'L' : (newkey > maxk ? 'H' : ' ');
					if(AddType== ' ') return; //no new zone needed
					int zoneheight_ticks = Convert.ToInt32(ZoneHeightPts/Parent.TickSize);
					while(AddType!= ' ') {
						if(AddType == 'L'){//add new zones lower than current lowest zone
							k = mink - zoneheight_ticks;
							var pbot = k * Parent.TickSize;
							var ptop = pbot + ZoneHeightPts;
							Zones[k] = new ZoneData(ptop, pbot);
							mink = k;
							if(p > pbot) AddType = ' ';
						}
						else{//adding new zones higher than current highest zone
							k = maxk + zoneheight_ticks;
							var pbot = k * Parent.TickSize;
							var ptop = pbot + ZoneHeightPts;
							Zones[k] = new ZoneData(ptop, pbot);
							maxk = k;
							if(p < ptop) AddType = ' ';
						}
					}
				}
			}
			public void CreatePivotStrengthsDictAndPivotIDsList(SortedDictionary<int, ZoneData> Zones, ref int line){//, double TickSize){
				int zoneid = 0;
				double lvl = 0;
				var keys = AllPivots.Keys.ToList();
				if(keys.Count>2 && IsRealTime) keys = new List<int>{keys[keys.Count-2], keys.Last()};
				foreach(var k in keys){
line=1746;
					if(!PivotStrengths.ContainsKey(k) && k!=AllPivots.Keys.Last()) {
if(IsRealTime){
	Parent.Print("Adding PivotStrengths at "+k);
	var pk = PivotStrengths.Keys.ToList();
	while(pk.Count>5) pk.RemoveAt(0);
	foreach(var pkk in pk)Parent.Print("PivotStrength at "+OHLC[pkk].T.ToString());
}
						PivotStrengths[k] = new SwingData.strengthdata();
					}
line=1748;
					if(!double.IsNaN(AllPivots[k][2])) lvl = AllPivots[k][2]; else lvl = AllPivots[k][1];
line=1750;
					int idx = Convert.ToInt32(lvl/Parent.TickSize);
line=1752;
					zoneid = Zones.Where(kx=>kx.Value.HighPrice > lvl && kx.Value.LowPrice <= lvl).Select(kx=>kx.Key).FirstOrDefault();
					if(!Zones.ContainsKey(zoneid)){
line=1755;
						var dt = DateTime.MinValue;
						if(OHLC.ContainsKey(k)) dt = OHLC[k].T;
						Parent.Print("This swing level "+(dt!=DateTime.MinValue ? dt.ToString():"")+" "+lvl+" ("+zoneid+") was not in Zones data");
					}else{
line=1760;
						if(!Zones[zoneid].PivotIDs.Contains(k)) Zones[zoneid].PivotIDs.Add(k);//this adds this Pivot (abar) to the Zone, so we can get counts by means of the PivotIDs.Count value.
					}
//					if(PivotStrengths[kvp.Key].Status != 'F'){
//						if(AllPivots[kvp.Key][0]==UP){
//							for(int abar = kvp.Key+1; abar < OHLC.Count; abar++){
//								//AllPivots[1][
//							}
//						}
//					}
line=1770;
				}
			}
			public void CalculateStrengths_Count(SortedDictionary<int, ZoneData> zones){
				foreach(var kvp in zones){
					zones[kvp.Key].Strength = kvp.Value.PivotIDs.Count;
				}
			}
			public void CalculateStrengths_Age(SortedDictionary<int, ZoneData> zones){
				foreach(var kvp in zones){
					int sum = 0;
					foreach(var key in kvp.Value.PivotIDs){
						if(PivotStrengths.ContainsKey(key)){
							sum = sum + this.PivotStrengths[key].AgeInBars;
						}
						else Parent.Print(key+" key was not found in PivotStrengths.Count "+PivotStrengths.Count);
					}
					zones[kvp.Key].Strength = sum / (kvp.Value.PivotIDs.Count>0 ? kvp.Value.PivotIDs.Count:1);
				}
			}
			public void CalculateStrengths_AvgPoints(SortedDictionary<int, ZoneData> zones){
				foreach(var kvp in zones){
					double sum = 0;
					foreach(var key in kvp.Value.PivotIDs){
						if(PivotStrengths.ContainsKey(key))
							sum = sum + this.PivotStrengths[key].MFEpts;
						else Parent.Print(key+" key was not found in PivotStrengths.Count "+PivotStrengths.Count);
					}
					zones[kvp.Key].Strength = Parent.Instrument.MasterInstrument.RoundToTickSize(sum / (kvp.Value.PivotIDs.Count>0 ? kvp.Value.PivotIDs.Count:1));
				}
			}
			public void CalculateStrengths_GrossPoints(SortedDictionary<int, ZoneData> zones){
				foreach(var kvp in zones){
					double sum = 0;
					foreach(var key in kvp.Value.PivotIDs){
						if(PivotStrengths.ContainsKey(key))
							sum = sum + this.PivotStrengths[key].MFEpts;
						else Parent.Print(key+" key (CB "+Parent.CurrentBar+")was not found in PivotStrengths.Count "+PivotStrengths.Count);
					}
					zones[kvp.Key].Strength = Parent.Instrument.MasterInstrument.RoundToTickSize(sum);
				}
			}
			public void CalculatePivotStrengths(List<int> keys, int FirstKey){
				#region -- CalculatePivotStrengths --
				while(PivotStrengths.Count > FirstKey) PivotStrengths.Remove(PivotStrengths.Keys.Max());//erase the last few pivot strengths
				while(FirstKey < keys.Count-1){//recalc all pivot strengths except for the most recent, newly found pivot...it will not have a strength until after a new pivot has been found
					int Startabar = keys[FirstKey];
					int Stopabar  = keys[FirstKey+1];
					bool IsSingleSwingBar = double.IsNaN(AllPivots[Startabar][2]);
					double swingp = IsSingleSwingBar ? AllPivots[Startabar][1]: (AllPivots[Startabar][1]+AllPivots[Startabar][2])/2;
					double exprice = swingp;
					PivotStrengths[Startabar] = new strengthdata();
					PivotStrengths[Startabar].AgeInBars = Stopabar - Startabar;
					IsSingleSwingBar = double.IsNaN(AllPivots[Stopabar][2]);
					PivotStrengths[Startabar].MFEpts = Math.Abs(swingp - (IsSingleSwingBar ? AllPivots[Stopabar][1] : (AllPivots[Stopabar][1]+AllPivots[Stopabar][2])/2));
					FirstKey++;
				}
				#endregion
			}

			//================================================================================================
			public void UpdateSessionDate(DateTime t, double high, double low, SessionIterator sessionIterator0){
//				DateTime currentDate = SessionDate.Date;
//				if(sessionIterator0 == null)
//					SessionDate = t.Date;
//				else if(sessionIterator0.IsNewSession(t, true)) {
//					sessionIterator0.CalculateTradingDay(t, true);
//					SessionDate = sessionIterator0.ActualTradingDayExchange.Date;
//				}
			}
			#endregion
		}
        private double highestHigh  = 0;
        private double lowestLow    = double.MaxValue;
        private Bars swingBars      = null;
//		private bool preloadData    = false;
		private DateTime LaunchedAt = DateTime.MinValue;
		private SimpleFont textFont = new SimpleFont("Arial",12);
//        private int abar = 0;
		private DateTime lastBkgBarTime = DateTime.MinValue;
		private float weakZoneOpacity = 0f;
		private float strongZoneOpacity = 0f;
		private List<double> BarRanges = new List<double>();

		private class ZoneData{
			public double HighPrice   = 0;
			public double LowPrice    = 0;
			public double Strength    = 0;//0 is no strength
			public List<int> PivotIDs = new List<int>();
			public ZoneData(double high, double low){HighPrice=high; LowPrice=low;}
		}
		SortedDictionary<int, ZoneData> Zones = new SortedDictionary<int, ZoneData>();
		//private double currentHigh = 0, currentLow=0, priorDayHigh=0, priorDayLow=0;
//		private ATR atr;


//=======================================================================================================================
        protected override void OnStateChange()
        {
line = 1849;
			#region  ----- OnStateChange ----- 
try{
//			if(State!=null)Print(State.ToString()+"  OSC SwingPointConflu");
			OnStateChange_StatusMsg = string.Empty;
            #region ----- State == State.SetDefaults -----
            if (State == State.SetDefaults)
            {
ClearOutputWindow();
				Description             = @"";
				Name                    = "ARC_SwingPointConfluence";
				Calculate               = Calculate.OnPriceChange;
				IsOverlay               = true;
				PaintPriceMarkers       = false;
				DisplayInDataBox        = true;
				IsAutoScale             = false;
				ArePlotsConfigurable    = true;
				ZOrder                  = 0;
				DrawOnPricePanel        = true;
				ScaleJustification      = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive = false;

				IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
				IsDebug = IsDebug && (NinjaTrader.Cbi.License.MachineId.CompareTo("CB15E08BE30BC80628CFF6010471FA2A")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);

				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
				#region ----- Defaults -----
				pZoneSizeTicks    = 5;
				pMinimumStrengthPctile = 0.8;
				pStrongZoneOpacity   = 70;
				pWeakZoneOpacity   = 15;
				pMaxHistoSize      = 200f;
				pShowTextOnStrongZones = true;
				pShowTextOnWeakZones = false;
				pLabelTextBrush = Brushes.White;
				pHistoLoc = ARC_SwingPointConfluence_HistoLoc.Right;
				pSupportHistoBrush = Brushes.LightSkyBlue;
				pSupportZoneBrush  = Brushes.DarkBlue;
				pResistanceHistoBrush = Brushes.Red;
				pResistanceZoneBrush  = Brushes.Maroon;
				pDynamicFocusLineOpacity = 50;
				pExendedStrongZones = true;
				pZonesToDisplay = ARC_SwingPointConfluence_ZoneDisplay.Both;
				pUseDynamicFocus = false;
				pDynamicFocusATRmult = 5.5;
				pShowInputBarDataMsg = false;
				isHLBased       = true;
				pShowSwingLines = true;
				pStrengthBasis  = ARC_SwingPointConfluence_StrengthTypes.AvgPoints;
				UpLineColor     = Brushes.Lime;
				DownLineColor   = Brushes.Red;
				ZZLineThickness = 2;
				//pSwingLabelFontSize = 12;
				pZZlabelFont     = new SimpleFont("Arial",12);
				pShowSwingLabels = false;
				#endregion
				pUseChartData   = true;
				pBkgDataStartDT = DateTime.Now.AddDays(-14);
				pBkgDataEndDT   = new DateTime(DateTime.Now.Year+1, 1, 1);
				pBkgDataMinuteValue = 15;

				pButtonText = "SPC";

                #region -- Indicator Display --
                //iButtonSize = 13;
                //iButtonTextSize = 10;
                #endregion

            }
            #endregion

            #region ----- State == State.Configure ----- 
            if (State == State.Configure)
            {
				weakZoneOpacity = pWeakZoneOpacity/100f;
				strongZoneOpacity = pStrongZoneOpacity/100f;
				SetZOrder(int.MaxValue-1);
//				Calculate = Calculate.OnBarClose;
				AddDataSeries(BarsPeriodType.Minute,15);
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
#endif
			}
            #endregion
line = 1683;
            #region  ----- State == State.Historical ----- 
            if (State == State.Historical)
            {
//                sessionIterator0 = new SessionIterator(BarsArray[0]);
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;
                        
                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

                            addToolBar();
                            
                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion
            }
            #endregion

            #region  ----- State == State.DataLoaded ----- 
            if (State == State.DataLoaded)
            {
line = 1724;
				if(pUseChartData){// && pBkgDataStartDT > BarsArray[0].GetTime(0)){
					SwingMgr = new SwingData(pSwingStrength, isHLBased, Calculate==Calculate.OnBarClose, this);
//					preloadData = false;
                    #region -- Calculate --
					int abar = Math.Max(0,BarsArray[0].GetBar(pBkgDataStartDT));
					int finalabar = BarsArray[0].GetBar(pBkgDataEndDT);

                    while (abar < BarsArray[0].Count && abar <= Math.Min(BarsArray[0].Count-1,finalabar))
                    {
line=1586;
						double o = BarsArray[0].GetOpen(abar);
						double h = BarsArray[0].GetHigh(abar);
						double l = BarsArray[0].GetLow(abar);
						double c = BarsArray[0].GetClose(abar);
						DateTime t = BarsArray[0].GetTime(abar);
						SwingMgr.CalculateIt(abar, o,h,l,c,t, true, Calculate, State.Historical, pUseChartData, ref line); 
                        lastBkgBarTime = t;
                        abar++;
                    }
                    #endregion
					if(pShowInputBarDataMsg){
						var s = string.Format("{0}-bars of {1} chart data data\nfrom {2} to {3}", SwingMgr.OHLC.Count, BarsArray[0].BarsPeriod.ToString(), 
							(Times[0].GetValueAt(0) > pBkgDataStartDT ? Times[0].GetValueAt(0) : pBkgDataStartDT).ToString(), pBkgDataEndDT.ToString());
						Draw.TextFixed(this,"datainfo", s, TextPosition.Center);
						LaunchedAt = DateTime.Now;
					}

				}else{//if not usechartdata, or requested data start is before the first bar of the chart
//					preloadData = true;
                    #region -- Preload Swing Bars --
                    if (!generalError) swingBars = loadHistoricalBars(pBkgDataStartDT, (pBkgDataEndDT> DateTime.Now ? DateTime.Now : pBkgDataEndDT), BarsPeriodType.Minute, pBkgDataMinuteValue);//preload swing bars - sync code
                    if (swingBars == null || swingBars.Count <= 1)//if no historical data
                    {
						string errorSwingData = "Loading of minute data is incomplete. Please refresh chart via F5 or check minute data.";
                        Draw.TextFixed(this, "errortag", errorSwingData, TextPosition.Center, ChartControl.Properties.AxisPen.Brush, textFont, Brushes.Transparent, ChartControl.Properties.ChartBackground, 0);
                        generalError = true;
                    }
                    else
                    {
line=1569;
						SwingMgr = new SwingData(pSwingStrength, isHLBased, Calculate==Calculate.OnBarClose, this);
                        #region -- Calculate --
//SwingMgr.z=false;
						int abar = 0;
                        while (abar < swingBars.Count && swingBars.GetTime(abar).CompareTo(pBkgDataEndDT) <= 0)
                        {
line=1575;
							double o = swingBars.GetOpen(abar);
							double h = swingBars.GetHigh(abar);
							double l = swingBars.GetLow(abar);
							double c = swingBars.GetClose(abar);
							DateTime t = swingBars.GetTime(abar);
//if((t.Day==3||t.Day==4) && t.Month==8 && abar>2220) Print(abar+":  Adding OHLC at: "+t);
line=1617;
							SwingMgr.CalculateIt(abar, o,h,l,c,t, true, Calculate.OnBarClose, State.Historical, pUseChartData, ref line); 
	                        lastBkgBarTime = t;
//if(SwingMgr.AllPivots.Count>0)
//	Print("1582: "+h+": "+l+"  "+t.ToString()+"    "+SwingMgr.AllPivots.Last().Value[0]+"/"+SwingMgr.AllPivots.Last().Value[1]+"/"+SwingMgr.AllPivots.Last().Value[2]);
                            abar++;
                        }
                        #endregion
                    }
                    #endregion
					if(pShowInputBarDataMsg){
						var s = string.Format("{0}-bars of {1} swing data\nfrom {2} to {3}", SwingMgr.OHLC.Count, swingBars.BarsPeriod.ToString(), swingBars.GetTime(0).ToString(), pBkgDataEndDT.ToString());
						Draw.TextFixed(this,"datainfo", s, TextPosition.Center);
						LaunchedAt = DateTime.Now;
					}
//SwingMgr.z=false;
	            }
				if(SwingMgr.OHLC.Count>1){//clean up all the bar data that generated the pivots
					var keys = SwingMgr.AllPivots.Keys.ToList();
					int kx = keys.Count-2;
					if(kx<5) kx = 5;//keep OHLC data for only the last 5 pivots
//					int kx = Math.Max(0, Convert.ToInt32(keys.Count*0.9));
//					if(kx == keys.Count-1) kx = Math.Max(0,kx - 2);
					int lastabar = keys[kx];
					keys = SwingMgr.OHLC.Keys.ToList();
					foreach(var k in keys){
						if(!SwingMgr.AllPivots.ContainsKey(k) && k < lastabar) SwingMgr.OHLC.Remove(k);
					}
//					foreach(var k in SwingMgr.OHLC){
//						Print(k.Value.T.ToString());
//					}
				}
			}
            #endregion

            #region  ----- State == State.Realtime ----- 
            if (State == State.Realtime)
            {
line = 1787;
				Zones.Clear();
				SwingMgr.CreateZones(Zones, double.NaN, pZoneSizeTicks); 
//				foreach(var kvp in Zones){
//					Print(kvp.Key+":   top/bot:  "+kvp.Value.HighPrice+" / "+kvp.Value.LowPrice);
//				}
line = 1793;
				SwingMgr.CreatePivotStrengthsDictAndPivotIDsList(Zones, ref line);

//				Print("Pivot counts for each key");
//				foreach(var kvp in Zones){
//					Print(kvp.Key+":   top/bot:  "+kvp.Value.HighPrice+" / "+kvp.Value.LowPrice+"  counts: "+kvp.Value.Strength);
//				}

//				foreach(var kvp in SwingMgr.AllPivots){
//					var bb = SwingMgr.PivotStrengths.ContainsKey(kvp.Key);
//					Print(kvp.Key+":   Has PStr?:  "+bb.ToString()+(bb ? "   PivStr Pts: "+SwingMgr.PivotStrengths[kvp.Key].MFEpts : ""));
//				}
line = 1803;
				var keys = SwingMgr.AllPivots.Keys.ToList();
				if(keys!=null && keys.Count>0){
line = 1806;
					SwingMgr.CalculatePivotStrengths(keys, 0);
line = 1807;
					if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.Count)
						SwingMgr.CalculateStrengths_Count(Zones);//calculates the total number of pivots in each zone
					else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.Age)
						SwingMgr.CalculateStrengths_Age(Zones);//calculates the average age of each pivot in each zone
					else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.AvgPoints)
						SwingMgr.CalculateStrengths_AvgPoints(Zones);//calculates the average point move from each pivot in each zone
					else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.GrossPoints)
						SwingMgr.CalculateStrengths_GrossPoints(Zones);//calculates the total point move from each pivot in each zone
line = 1811;
					CalculateMinimumPlottingStrength(ref MinStrength);
				}
line = 1816;
				SwingMgr.IsRealTime = true;
            }
            #endregion

            #region  ----- State == State.Terminated ----- 
            if(State == State.Terminated)
            {
line=1709;
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
            }
            #endregion
}catch(Exception e){
	OnStateChange_StatusMsg = string.Format("{0}:  OnStateChange: \n{1}", line, e.ToString());
	Print(OnStateChange_StatusMsg);
//	Draw.TextFixed(this,"InitError","ARC_SwingPointConfluence "+e.ToString(), TextPosition.Center,Brushes.White,textFont,Brushes.Maroon,Brushes.Maroon,80);
}
            #endregion
        }
        //------------------------- Functions --------------------------------------        
        //This function does a bar request to preload historical minute bars. It is an asynchrone function but has been made synchrone.
        #region -- loadHistoricalBars --
        private Bars loadHistoricalBars(DateTime dtfrom, DateTime dtto, BarsPeriodType barsperiodtype, int barsperiod)
        {
//			TradingHours thrs = TradingHours.Get("Default 24 x 5");
            //---- Prepa Bars Request ----
            BarsRequest barsRequest = new BarsRequest(Bars.Instrument, dtfrom, dtto) { TradingHours = Bars.TradingHours, IsSplitAdjusted = false/*Bars.IsSplitAdjusted*/, IsDividendAdjusted = Bars.IsDividendAdjusted };
            barsRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = barsperiodtype, MarketDataType = Bars.BarsPeriod.MarketDataType, Value = barsperiod };

            //---- Request the bars ----
            bool doWait = true;
            Bars retour = null;
            barsRequest.Request(new Action<BarsRequest, NinjaTrader.Cbi.ErrorCode, string>((bars, errorCode, errorMessage) =>
            {
                if (errorCode != NinjaTrader.Cbi.ErrorCode.NoError) { retour = null; doWait = false; return; }
                else if (bars.Bars == null || bars.Bars.Count == 0) { doWait = false; return; }
                retour = bars.Bars;
                doWait = false;
                return;
            }));
            while (doWait) { Thread.Sleep(10); }//made synchrone cause need request to finish before continuing
            return retour;
        }
        #endregion
		//====================================================
		#region  ----- TabSelectionChangedHandler ----- 
		private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}
		#endregion

		double DynamicFocusPriceDistance = 0;
		List<int> DynamicFocusZones = new List<int>();
		int LastZoneId = 0;
		protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
try{
			if(BarsInProgress == 0){
				if(IsFirstTickOfBar) BarRanges.Add(Range()[0]);
				else BarRanges[BarRanges.Count-1] = Range()[0];
				while(BarRanges.Count>14) BarRanges.RemoveAt(0);
			}
			int bip = 1;
			if(pUseChartData) bip = 0;
			if(BarsInProgress == bip && BarsArray[bip].Count>2){
line=2201;
				var c1 = SwingMgr.OHLC.Count>0 && SwingMgr.OHLC.Last().Value.T.CompareTo(Times[bip][0])<0;
				var c2 = Times[bip][0].CompareTo(pBkgDataEndDT) < 0;
				if(c1 && c2){
line=2205;
					//Print("******************************   adding new bar from live market  ********************");
					int count = SwingMgr.AllPivots.Count;
//					if(pUseChartData){
//						SwingMgr.CalculateIt(CurrentBars[bip], Opens[bip][1], Highs[bip][1], Lows[bip][1], Closes[bip][1], Times[bip][1], IsFirstTickOfBar, Calculate, State, pUseChartData, ref line);
//					}else
					{
						SwingMgr.CalculateIt(CurrentBars[bip], Opens[bip][1], Highs[bip][1], Lows[bip][1], Closes[bip][1], Times[bip][1], IsFirstTickOfBar, Calculate, State, pUseChartData, ref line);
					}
					if(SwingMgr.IsRealTime && count != SwingMgr.AllPivots.Count){
						var keys = SwingMgr.AllPivots.Keys.Skip(Math.Max(0, SwingMgr.AllPivots.Keys.Count() - 2)).ToList();
						var type = SwingMgr.AllPivots[keys[0]][0];
						var p1 = SwingMgr.AllPivots[keys[0]][1];
						var p2 = SwingMgr.AllPivots[keys[0]][2];
						if(!double.IsNaN(p2)) p1 = (p1+p2)/2;//if this is a double pivot bar, use the average of the 2 pivot levels as the pivot level
						SwingMgr.CreateZones(Zones, p1); 
						SwingMgr.CreatePivotStrengthsDictAndPivotIDsList(Zones, ref line);
						if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.Count){
							SwingMgr.CalculateStrengths_Count(Zones);//calculates the total number of pivots in each zone
						}else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.Age){
							SwingMgr.PivotStrengths[keys[0]].AgeInBars = SwingMgr.CB-keys[0];
							SwingMgr.CalculateStrengths_Age(Zones);//calculates the average age of each pivot in each zone
						}else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.AvgPoints){
							SwingMgr.PivotStrengths[keys[0]].MFEpts = type>0 ? Math.Abs(p1 - Highs[bip][0]) : Math.Abs(p1 - Lows[bip][0]);
							SwingMgr.CalculateStrengths_AvgPoints(Zones);//calculates the average point move from each pivot in each zone
						}else if(pStrengthBasis == ARC_SwingPointConfluence_StrengthTypes.GrossPoints){
							SwingMgr.PivotStrengths[keys[0]].MFEpts = type>0 ? Math.Abs(p1 - Highs[bip][0]) : Math.Abs(p1 - Lows[bip][0]);
							SwingMgr.CalculateStrengths_GrossPoints(Zones);//calculates the total point move from each pivot in each zone
						}
line=2270;
						CalculateMinimumPlottingStrength(ref MinStrength);
					}
				}
			}
}catch(Exception eee){Print(line+":  "+eee.ToString());}
//if(!double.IsNaN(SwingMgr.ExtentOfMove)) Draw.Dot(this,CurrentBars[0].ToString(),false,0,SwingMgr.ExtentOfMove,Brushes.White);
//SwingMgr.UpdateSessionDate(Time[0], High[0], Low[0], null);
        }
//=======================================================================================================================
		private void CalculateMinimumPlottingStrength(ref double MinStrength){
//			var strengths = Zones.Select(k=>k.Value.Strength).Distinct().ToList();//conunts only distinct values in the percentile rank
			var strengths = Zones.Select(k=>k.Value.Strength).ToList();//this is the conventional calc for Percentile
			if(strengths!=null && strengths.Count>0){
				if(strengths.Count==1) MinStrength = strengths[0];
				else{
					strengths.Sort(); 
					MinStrength = 0;
					int v = Convert.ToInt32(strengths.Count * pMinimumStrengthPctile);
					if(strengths[0] < strengths.Last()){
						MinStrength = strengths[Math.Min(strengths.Count-1,v)];
					}else{
						MinStrength = strengths[strengths.Count-v];
					}
				}
			}
		}
//=======================================================================================================================
		private SharpDX.Direct2D1.Brush lineBrushUp, lineBrushDown, LabelTextBrushDX, YellowBrushDX;
		private SharpDX.Direct2D1.Brush ResistanceHistoBrushDX, SupportHistoBrushDX, ResistanceZoneBrushDX, SupportZoneBrushDX;
        public override void OnRenderTargetChanged()
        {
			#region -- ORTC --
			if(YellowBrushDX!=null   && !YellowBrushDX.IsDisposed)   {YellowBrushDX.Dispose();   YellowBrushDX=null;}
			if(RenderTarget!=null) {YellowBrushDX = Brushes.Yellow.ToDxBrush(RenderTarget); YellowBrushDX.Opacity = pDynamicFocusLineOpacity/100f;}

//			if(BlackBrushDX!=null   && !BlackBrushDX.IsDisposed)   {BlackBrushDX.Dispose();   BlackBrushDX=null;}
//			if(RenderTarget!=null) BlackBrushDX = Brushes.Black.ToDxBrush(RenderTarget);

//			if(WhiteBrushDX!=null   && !WhiteBrushDX.IsDisposed)   {WhiteBrushDX.Dispose();   WhiteBrushDX=null;}
//			if(RenderTarget!=null) WhiteBrushDX = Brushes.White.ToDxBrush(RenderTarget);

			if(LabelTextBrushDX!=null   && !LabelTextBrushDX.IsDisposed)   {LabelTextBrushDX.Dispose();   LabelTextBrushDX=null;}
			if(RenderTarget!=null) LabelTextBrushDX = pLabelTextBrush.ToDxBrush(RenderTarget);

			if(lineBrushUp!=null   && !lineBrushUp.IsDisposed)   {lineBrushUp.Dispose();   lineBrushUp=null;}
			if(lineBrushDown!=null && !lineBrushDown.IsDisposed) {lineBrushDown.Dispose(); lineBrushDown=null;}
			if(RenderTarget!=null) lineBrushUp = this.UpLineColor.ToDxBrush(RenderTarget);
			if(RenderTarget!=null) lineBrushDown = this.DownLineColor.ToDxBrush(RenderTarget);

			if(ResistanceZoneBrushDX!=null && !ResistanceZoneBrushDX.IsDisposed) {ResistanceZoneBrushDX.Dispose(); ResistanceZoneBrushDX=null;}
			if(SupportZoneBrushDX!=null && !SupportZoneBrushDX.IsDisposed) {SupportZoneBrushDX.Dispose(); SupportZoneBrushDX=null;}
			if(RenderTarget!=null) ResistanceZoneBrushDX = pResistanceZoneBrush.ToDxBrush(RenderTarget);
			if(RenderTarget!=null) SupportZoneBrushDX = pSupportZoneBrush.ToDxBrush(RenderTarget);

			if(ResistanceHistoBrushDX!=null && !ResistanceHistoBrushDX.IsDisposed) {ResistanceHistoBrushDX.Dispose(); ResistanceHistoBrushDX=null;}
			if(SupportHistoBrushDX!=null && !SupportHistoBrushDX.IsDisposed) {SupportHistoBrushDX.Dispose(); SupportHistoBrushDX=null;}
			if(RenderTarget!=null) ResistanceHistoBrushDX = pResistanceHistoBrush.ToDxBrush(RenderTarget);
			if(RenderTarget!=null) SupportHistoBrushDX = pSupportHistoBrush.ToDxBrush(RenderTarget);
			#endregion
		}

//=======================================================================================================================
		private float SetFontForStrength(float yB, float yT, ref SimpleFont font, ref SharpDX.DirectWrite.TextFormat textFormat){
			var fontHeight = yB-yT-1f;
			if(fontHeight>6){
				font = new SimpleFont("Arial", fontHeight);
				textFormat = new SharpDX.DirectWrite.TextFormat(
					Core.Globals.DirectWriteFactory,
					font.FamilySerialize,
					font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
					font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
					SharpDX.DirectWrite.FontStretch.Normal,
					(float)font.Size) {	TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
			}else font = null;
			return fontHeight;
		}
//=======================================================================================================================
		bool init = true;
		double MinStrength = 0;
		SharpDX.DirectWrite.TextLayout textLayout = null;
//		SharpDX.Direct2D1.Factory factory = null;
		SharpDX.DirectWrite.TextFormat textFormat = null;
		SimpleFont font = null;
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale){
			if(pShowInputBarDataMsg){
				var ts = new TimeSpan(DateTime.Now.Ticks - LaunchedAt.Ticks);
				if(ts.TotalSeconds>10) {RemoveDrawObject("datainfo"); LaunchedAt = DateTime.MaxValue;}
			}
try{
            #region -- conditions to return --
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (Bars == null || ChartControl == null) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
			if (IsInHitTest) return;
            #endregion
		    RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

			if(pUseDynamicFocus){
				#region -- DynamicFocus --
line=2091;
				if(CurrentBars[0] > BarsArray[0].Count-3){
line=2096;
					DynamicFocusPriceDistance = BarRanges.Average() * this.pDynamicFocusATRmult;
					var close = Closes[0].GetValueAt(CurrentBars[0]);
					var tprice = close + DynamicFocusPriceDistance;
					var bprice = close - DynamicFocusPriceDistance;
					if(pDynamicFocusLineOpacity>0){
						var yy1 = chartScale.GetYByValue(tprice);
						RenderTarget.DrawLine(new SharpDX.Vector2(0f, yy1), new SharpDX.Vector2(ChartPanel.W, yy1), YellowBrushDX, 2f);
						yy1 = chartScale.GetYByValue(bprice);
						RenderTarget.DrawLine(new SharpDX.Vector2(0f, yy1), new SharpDX.Vector2(ChartPanel.W, yy1), YellowBrushDX, 2f);
					}
//Print(Times[0].GetValueAt(CurrentBars[0]).ToString()+"   LastZoneId: "+LastZoneId+"   top: "+tprice+"   bot: "+bprice+"      clos: "+close);
					if(LastZoneId==0 || close > Zones[LastZoneId].HighPrice || close < Zones[LastZoneId].LowPrice){
						DynamicFocusZones = Zones.Where(k=>k.Value.HighPrice<=tprice && k.Value.LowPrice>=bprice).Select(k=>k.Key).ToList();
//Print("DynamicFocusZones.Count: "+DynamicFocusZones.Count);
						if(DynamicFocusZones!=null && DynamicFocusZones.Count>0){
							var strengths = Zones.Where(k=>DynamicFocusZones.Contains(k.Key)).Select(k=>k.Value.Strength).ToList();//this is the conventional calc for Percentile
							if(strengths!=null && strengths.Count>0){
								if(strengths.Count==1) MinStrength = strengths[0];
								else{
									strengths.Sort(); 
line=2112;
									MinStrength = 0;
									int v = Convert.ToInt32(strengths.Count * pMinimumStrengthPctile);
line=2115;
									if(strengths[0] < strengths.Last()){
line=2117;
			//foreach(var dd in strengths) Print(dd);
			//Print("v: "+v+"   strengths.Count: "+strengths.Count);
										MinStrength = strengths[Math.Min(strengths.Count-1,v)];
			//Print("strengths["+v+"]: "+MinStrength);
									}else{
//line=2123;Print("strengths.Count: "+strengths.Count+"  v: "+v);
										MinStrength = strengths[strengths.Count-v];
									}
								}
							}
line=2126;
							LastZoneId = Zones.Where(k=>k.Value.HighPrice >= close && k.Value.LowPrice <= close).FirstOrDefault().Key;
						}
					}
				}
				#endregion
			}
line=2130;
			#region -- Draw Strength histo and zones --
			List<KeyValuePair<int,ZoneData>> zones = Zones.Where(k=>k.Value.Strength>0 && k.Value.HighPrice > chartScale.MinValue && k.Value.LowPrice < chartScale.MaxValue).ToList();
			float fontHeight = -1f;
			if(zones!=null && zones.Count>0){
line=2132;
				if(pShowTextOnStrongZones || pShowTextOnStrongZones){
					textLayout = null;
//					factory = new SharpDX.Direct2D1.Factory();
				}
				fontHeight = SetFontForStrength(chartScale.GetYByValue(0), chartScale.GetYByValue(pZoneSizeTicks*TickSize), ref font, ref textFormat);
line=2137;
				double maxstrength = zones.Max(k=>k.Value.Strength);
				float maxX = pMaxHistoSize;
				float strengthPerPixel = Convert.ToSingle(maxX/maxstrength);
				float xR = 0f;
				float yT = 0f;
				float yB = 0f;
				if(pHistoLoc == ARC_SwingPointConfluence_HistoLoc.Left){
					#region -- Left-side of chart histogram --
//try{
					foreach(var kvp in zones){
						var IsOutsideOfDynamicArea = DynamicFocusZones.Count >0 && !DynamicFocusZones.Contains(kvp.Key);

	//Print("Strength: "+kvp.Value.Strength + "   "+kvp.Value.HighPrice+"    xR: "+xR+"   yT: "+yT+"   yB: "+yB);
						if(strongZoneOpacity > 0f && kvp.Value.Strength >= MinStrength){
							xR = Convert.ToSingle(kvp.Value.Strength) * strengthPerPixel;
							yT = chartScale.GetYByValue(kvp.Value.HighPrice);
							yB = chartScale.GetYByValue(kvp.Value.LowPrice);
	//Print(kvp.Value.HighPrice+"    xR: "+xR+"   yT: "+yT+"   yB: "+yB);
							bool WasThisLevelPrinted = false;
							if(Closes[0].GetValueAt(CurrentBars[0]) < kvp.Value.LowPrice){
								if(pZonesToDisplay != ARC_SwingPointConfluence_ZoneDisplay.SupportOnly){
									ResistanceHistoBrushDX.Opacity = IsOutsideOfDynamicArea ? weakZoneOpacity : strongZoneOpacity;
									RenderTarget.FillRectangle(new SharpDX.RectangleF(0, yT, xR, Math.Max(1f,yB-yT)), ResistanceHistoBrushDX);
									WasThisLevelPrinted=true;
									if(pExendedStrongZones && !IsOutsideOfDynamicArea){
										ResistanceZoneBrushDX.Opacity = IsOutsideOfDynamicArea ? weakZoneOpacity : strongZoneOpacity;
										RenderTarget.FillRectangle(new SharpDX.RectangleF(xR+2f, yT, ChartPanel.W, Math.Max(1f,yB-yT)), ResistanceZoneBrushDX);
									}
								}
							}
							else if(pZonesToDisplay != ARC_SwingPointConfluence_ZoneDisplay.ResistanceOnly){
								SupportHistoBrushDX.Opacity = IsOutsideOfDynamicArea ? weakZoneOpacity : strongZoneOpacity;
								RenderTarget.FillRectangle(new SharpDX.RectangleF(0, yT, xR, Math.Max(1f,yB-yT)), SupportHistoBrushDX);
								WasThisLevelPrinted=true;
								if(pExendedStrongZones && !IsOutsideOfDynamicArea){
									SupportZoneBrushDX.Opacity = IsOutsideOfDynamicArea ? weakZoneOpacity : strongZoneOpacity;
									RenderTarget.FillRectangle(new SharpDX.RectangleF(xR+2f, yT, ChartPanel.W, Math.Max(1f,yB-yT)), SupportZoneBrushDX);
								}
							}
							if(pShowTextOnStrongZones && font!=null && WasThisLevelPrinted && !IsOutsideOfDynamicArea){
								textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, kvp.Value.Strength.ToString(), textFormat, fontHeight, float.MaxValue);
								var rect = new SharpDX.RectangleF(2f, yT-2f, textLayout.Metrics.Width+10f, fontHeight+3f);
//								RenderTarget.FillRectangle(rect, BlackBrushDX);
								RenderTarget.DrawTextLayout(new SharpDX.Vector2(rect.X+1f, rect.Y+1f), textLayout, LabelTextBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
							}
						}else if(pWeakZoneOpacity>0 && kvp.Value.Strength>0){
							xR = Convert.ToSingle(kvp.Value.Strength) * strengthPerPixel;
							yT = chartScale.GetYByValue(kvp.Value.HighPrice);
							yB = chartScale.GetYByValue(kvp.Value.LowPrice);
	//Print(kvp.Value.HighPrice+"    xR: "+xR+"   yT: "+yT+"   yB: "+yB);
							bool WasThisLevelPrinted = false;
							if(Closes[0].GetValueAt(CurrentBars[0]) < kvp.Value.LowPrice){
								if(pZonesToDisplay != ARC_SwingPointConfluence_ZoneDisplay.SupportOnly){
									ResistanceHistoBrushDX.Opacity = weakZoneOpacity;
									RenderTarget.FillRectangle(new SharpDX.RectangleF(0, yT, xR, Math.Max(1f,yB-yT)), ResistanceHistoBrushDX);
									WasThisLevelPrinted=true;
									if(pExendedWeakZones && !IsOutsideOfDynamicArea){
										ResistanceZoneBrushDX.Opacity = weakZoneOpacity;
										RenderTarget.FillRectangle(new SharpDX.RectangleF(xR+2f, yT, ChartPanel.W, Math.Max(1f,yB-yT)), ResistanceZoneBrushDX);
									}
								}
							}else if(pZonesToDisplay != ARC_SwingPointConfluence_ZoneDisplay.ResistanceOnly){
								SupportHistoBrushDX.Opacity = weakZoneOpacity;
								RenderTarget.FillRectangle(new SharpDX.RectangleF(0, yT, xR, Math.Max(1f,yB-yT)), SupportHistoBrushDX);
								WasThisLevelPrinted=true;
								if(pExendedWeakZones && !IsOutsideOfDynamicArea){
									SupportZoneBrushDX.Opacity = weakZoneOpacity;
									RenderTarget.FillRectangle(new SharpDX.RectangleF(xR+2f, yT, ChartPanel.W, Math.Max(1f,yB-yT)), SupportZoneBrushDX);
								}
							}
							if(pShowTextOnWeakZones && font!=null && WasThisLevelPrinted && !IsOutsideOfDynamicArea){
								textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, kvp.Value.Strength.ToString(), textFormat, fontHeight, float.MaxValue);
								var rect = new SharpDX.RectangleF(2f, yT-2f, textLayout.Metrics.Width+10f, fontHeight+3f);
//								RenderTarget.FillRectangle(rect, BlackBrushDX);
								RenderTarget.DrawTextLayout(new SharpDX.Vector2(rect.X+1f, rect.Y+1f), textLayout, LabelTextBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
							}
						}
					}
//}catch(Exception eee){Print(line+":  "+eee.ToString());}
					#endregion
				}else{
					#region -- Right-side of chart Histogram --
					foreach(var kvp in zones){
	//Print("Strength: "+kvp.Value.Strength + "   "+kvp.Value.HighPrice+"    xR: "+xR+"   yT: "+yT+"   yB: "+yB);
						var IsOutsideOfDynamicArea = DynamicFocusZones.Count >0 && !DynamicFocusZones.Contains(kvp.Key);
						if(strongZoneOpacity>0f && kvp.Value.Strength >= MinStrength){
							xR = Convert.ToSingle(kvp.Value.Strength) * strengthPerPixel;
							yT = chartScale.GetYByValue(kvp.Value.HighPrice);
							yB = chartScale.GetYByValue(kvp.Value.LowPrice);
							bool WasThisLevelPrinted = false;
	//Print(kvp.Value.HighPrice+"    xR: "+xR+"   yT: "+yT+"   yB: "+yB);
							if(Closes[0].GetValueAt(CurrentBars[0]) < kvp.Value.LowPrice){
								if(pZonesToDisplay != ARC_SwingPointConfluence_ZoneDisplay.SupportOnly){
									ResistanceHistoBrushDX.Opacity = IsOutsideOfDynamicArea ? weakZoneOpacity : strongZoneOpacity;
									RenderTarget.FillRectangle(new SharpDX.RectangleF(ChartPanel.W, yT, -xR, Math.Max(1f,yB-yT)), ResistanceHistoBrushDX);
									WasThisLevelPrinted=true;
									if(pExendedStrongZones && !IsOutsideOfDynamicArea){
										ResistanceZoneBrushDX.Opacity = IsOutsideOfDynamicArea ? weakZoneOpacity : strongZoneOpacity;
										RenderTarget.FillRectangle(new SharpDX.RectangleF(ChartPanel.W-xR-2f, yT, -ChartPanel.W, Math.Max(1f,yB-yT)), ResistanceZoneBrushDX);
									}
								}
							}
							else if(pZonesToDisplay != ARC_SwingPointConfluence_ZoneDisplay.ResistanceOnly){
								SupportHistoBrushDX.Opacity = IsOutsideOfDynamicArea ? weakZoneOpacity : strongZoneOpacity;
								RenderTarget.FillRectangle(new SharpDX.RectangleF(ChartPanel.W, yT, -xR, Math.Max(1f,yB-yT)), SupportHistoBrushDX);
								WasThisLevelPrinted=true;
								if(pExendedStrongZones && !IsOutsideOfDynamicArea){
									SupportZoneBrushDX.Opacity = IsOutsideOfDynamicArea ? weakZoneOpacity : strongZoneOpacity;
									RenderTarget.FillRectangle(new SharpDX.RectangleF(ChartPanel.W-xR-2f, yT, -ChartPanel.W, Math.Max(1f,yB-yT)), SupportZoneBrushDX);
								}
							}
							if(pShowTextOnStrongZones && font!=null && WasThisLevelPrinted && !IsOutsideOfDynamicArea){
								textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, kvp.Value.Strength.ToString(), textFormat, fontHeight, float.MaxValue);
//								var rect = new SharpDX.RectangleF(ChartPanel.W-2f, yT-2f, textLayout.Metrics.Width+1f, fontHeight+3f);
								var rect = new SharpDX.RectangleF(ChartPanel.W-textLayout.Metrics.Width-2f, yT-2f, textLayout.Metrics.Width+1f, fontHeight+3f);
//								RenderTarget.FillRectangle(rect, BlackBrushDX);
								RenderTarget.DrawTextLayout(new SharpDX.Vector2(rect.X+1f, rect.Y+1f), textLayout, LabelTextBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
							}
						}else if(pWeakZoneOpacity>0 && kvp.Value.Strength>0){
							xR = Convert.ToSingle(kvp.Value.Strength) * strengthPerPixel;
							yT = chartScale.GetYByValue(kvp.Value.HighPrice);
							yB = chartScale.GetYByValue(kvp.Value.LowPrice);
							bool WasThisLevelPrinted = false;
	//Print(kvp.Value.HighPrice+"    xR: "+xR+"   yT: "+yT+"   yB: "+yB);
							if(Closes[0].GetValueAt(CurrentBars[0]) < kvp.Value.LowPrice){
								if(pZonesToDisplay != ARC_SwingPointConfluence_ZoneDisplay.SupportOnly){
									ResistanceHistoBrushDX.Opacity = weakZoneOpacity;
									RenderTarget.FillRectangle(new SharpDX.RectangleF(ChartPanel.W, yT, -xR, Math.Max(1f,yB-yT)), ResistanceHistoBrushDX);
									WasThisLevelPrinted=true;
									if(pExendedWeakZones && !IsOutsideOfDynamicArea){
										ResistanceZoneBrushDX.Opacity = weakZoneOpacity;
										RenderTarget.FillRectangle(new SharpDX.RectangleF(ChartPanel.W-xR-2f, yT, -ChartPanel.W, Math.Max(1f,yB-yT)), ResistanceZoneBrushDX);
									}
								}
							}else if(pZonesToDisplay != ARC_SwingPointConfluence_ZoneDisplay.ResistanceOnly){
								SupportHistoBrushDX.Opacity = weakZoneOpacity;
								RenderTarget.FillRectangle(new SharpDX.RectangleF(ChartPanel.W, yT, -xR, Math.Max(1f,yB-yT)), SupportHistoBrushDX);
								WasThisLevelPrinted=true;
								if(pExendedWeakZones && !IsOutsideOfDynamicArea){
									SupportZoneBrushDX.Opacity = weakZoneOpacity;
									RenderTarget.FillRectangle(new SharpDX.RectangleF(ChartPanel.W-xR-2f, yT, -ChartPanel.W, Math.Max(1f,yB-yT)), SupportZoneBrushDX);
								}
							}
							if(pShowTextOnWeakZones && font!=null && WasThisLevelPrinted && !IsOutsideOfDynamicArea){
								textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, kvp.Value.Strength.ToString(), textFormat, fontHeight, float.MaxValue);
//								var rect = new SharpDX.RectangleF(ChartPanel.W-2f, yT-2f, textLayout.Metrics.Width+1f, fontHeight+3f);
								var rect = new SharpDX.RectangleF(ChartPanel.W-textLayout.Metrics.Width-2f, yT-2f, textLayout.Metrics.Width+1f, fontHeight+3f);
//								RenderTarget.FillRectangle(rect, BlackBrushDX);
								RenderTarget.DrawTextLayout(new SharpDX.Vector2(rect.X+1f, rect.Y+1f), textLayout, LabelTextBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
							}
						}
					}
					#endregion
				}
line=2301;
				if(textLayout!=null) textLayout.Dispose();
				if(textFormat!=null) textFormat.Dispose();
			}
			#endregion

			#region -- draw swing lines and labels --            
			if (pShowSwingLines)
			{
				int rmab = BarsArray[0].GetBar(Times[0].GetValueAt(Math.Min(BarsArray[0].Count-1,ChartBars.ToIndex)));
				if(rmab==BarsArray[0].Count-1 && Calculate == Calculate.OnBarClose) rmab = rmab-1;

				int x1 = 0;
				int y1 = 0;
				int x2 = 0;
				int y2 = 0;
				if (rmab >= 2 && SwingMgr.AllPivots.Count>0){
					var SwingLabelBrush = ' ';//fillbrush;
					var keys = new System.Collections.Generic.List<int>(SwingMgr.AllPivots.Keys);
				    int j = keys.Count-1;
					double swingprice2 = Closes[0].GetValueAt(1);
					double swingprice1 = Closes[0].GetValueAt(1);
					double swingpriceOB = 0;  //swing price of an outside bar
					float vTextOffset = 0;
					int swingABar1 = 1;
try{
line=2548;
//Print("swingBars[0]: "+swingBars.GetTime(0).ToString()+"  ["+j+"]: "+swingBars.GetTime(keys[j]).ToString());
				    while (j > 0) { 
						j = j - 1;
						var t = SwingMgr.OHLC[keys[j]].T;//swingBars.GetTime(keys[j]);
						swingABar1 = BarsArray[0].GetBar(t);
//Print(j+":  "+SwingMgr.OHLC[keys[j]].T.ToString()+"  Finding leftmost line,  searching bar: "+swingABar1+" < "+(ChartBars.FromIndex-1));
						if(swingABar1 < ChartBars.FromIndex-1) {
							swingpriceOB = SwingMgr.AllPivots[keys[j]][2];
							if(!double.IsNaN(swingprice2))
								swingprice1 = swingpriceOB;//swingprice2 contains the last swing price of an outside bar
							else
								swingprice1 = SwingMgr.AllPivots[keys[j]][1];//that bar is a normal (non-outsidebar), therefore the last swing price of that swing bar is in element [1]
							break;
						}
					}//j is now the index of the first swing point prior to the left-most bar on the chart
line=2564;
					var lineBrush = 'u';
					string zzId0 = "";
					int swingABar0 = keys[j];
					double priorH = SwingMgr.AllPivots[swingABar0][1];
					double priorL = SwingMgr.AllPivots[swingABar0][1];
					if(!double.IsNaN(SwingMgr.AllPivots[swingABar0][2])){
						priorL = SwingMgr.AllPivots[swingABar0][2];
						if(priorH < priorL){
							double temp = priorH;
							priorH = priorL;
							priorL = temp;
						}
					}
line=2578;
					double OB_High = 0;//high price of an outside bar
					double OB_Low = 0;//low price of an outside bar
					int swingABar0OnChart = 0;
					int swingABar1OnChart = 0;
					int min_displayable_x = 0;
					swingABar1 = -1;
					
//Print("   ");
					int fudge = 0;//SwingMgr.IsRealTime? 0:1;
                    for (int i = j; i<keys.Count && i < (pUseChartData ? BarsArray[0].Count : swingBars.Count); i++)
                    {
line=2589;
						swingABar0 = keys[i]+fudge;
						if(pUseChartData || swingBars==null){
line=2592;
							x1 = ChartControl.GetXByBarIndex(ChartBars, swingABar0);
line=2594;
							min_displayable_x = ChartControl.GetXByBarIndex(ChartBars, 1)+2;//removes some erroneous zigzag lines and labels
							x2 = ChartControl.GetXByBarIndex(ChartBars, swingABar1);
line=2597;
//try{Print("swBar0: "+Times[0].GetValueAt(swingABar0)+"    swBar1: "+Times[0].GetValueAt(swingABar1));}catch(Exception dde){Print(swingABar0+" / "+swingABar1);}
						}else if(swingABar0>0 && swingABar1>0){
line=2600;
							min_displayable_x = ChartControl.GetXByBarIndex(ChartBars, 1)+2;//removes some erroneous zigzag lines and labels
							var t = SwingMgr.OHLC[swingABar0].T;// swingBars.GetTime(swingABar0);
line=2603;
							swingABar0OnChart = BarsArray[0].GetBar(t);
							x1 = ChartControl.GetXByBarIndex(ChartBars, swingABar0OnChart);
							t = SwingMgr.OHLC[swingABar1].T;//swingBars.GetTime(swingABar1);
line=2607;
							swingABar1OnChart = BarsArray[0].GetBar(t);
							x2 = ChartControl.GetXByBarIndex(ChartBars, swingABar1OnChart);
						}

line=2612;
						double swingprice = SwingMgr.AllPivots[swingABar0-fudge][1];
						swingpriceOB = SwingMgr.AllPivots[swingABar0-fudge][2];//Outside Bar swing price at the close of the bar
						bool IsOutsideBar = !double.IsNaN(swingpriceOB);
						if(x1>min_displayable_x || x2>min_displayable_x){
							if(IsOutsideBar){
								OB_High = Math.Max(swingprice, swingpriceOB);
								OB_Low = Math.Min(swingprice, swingpriceOB);
								y1 = chartScale.GetYByValue(swingprice);
								y2 = chartScale.GetYByValue(swingprice1);
								drawLine(x1, x2, y1, y2, (swingprice1 < swingprice ? lineBrushUp : lineBrushDown), DashStyleHelper.Solid, ZZLineThickness);
								y1 = chartScale.GetYByValue(swingpriceOB);
								y2 = chartScale.GetYByValue(swingprice);
								drawLine(x1, x1, y1, y2, (swingpriceOB > swingprice ? lineBrushUp : lineBrushDown), DashStyleHelper.Solid, ZZLineThickness);
								swingprice = swingpriceOB;
							}else{
								if(swingprice1 > swingprice){//a down swing
									lineBrush = 'd';
								}else{
									lineBrush = 'u';
								}

								y1 = chartScale.GetYByValue(swingprice);
								y2 = chartScale.GetYByValue(swingprice1);
//try{Print(Times[0].GetValueAt(swingABar0)+" @ "+swingprice+"    to "+Times[0].GetValueAt(swingABar1)+" @ "+swingprice1);}catch(Exception dde){Print(swingABar0+" / "+swingABar1);}

line=2638;
								if(swingABar1>0) drawLine(x1, x2, y1, y2, (lineBrush=='u' ? lineBrushUp : lineBrushDown), DashStyleHelper.Solid, ZZLineThickness);
								swingprice1 = swingprice;
							}
						}

						if (pShowSwingLabels){
line=2639;
							#region Show SwingLabels
//try{
							float[] SZ  = getTextHeightAndWidth(zzId0, pZZlabelFont);
							double xx = x1 - SZ[1] / 2;
							if(xx>min_displayable_x){
line=2645;
								if(!IsOutsideBar){
							    	if (lineBrush == 'u'){
										SwingLabelBrush = 'u';
										vTextOffset = -SZ[0] -3f;
										if(swingprice > priorH) zzId0 = "HH";
										else if(swingprice < priorH) zzId0 = "LH";
										else zzId0 = "DT";
										priorH = swingprice;
									} else {
										SwingLabelBrush = 'd';
										vTextOffset = 3f;
										if(swingprice < priorL) zzId0 = "LL";
										else if(swingprice > priorL) zzId0 = "HL";
										else zzId0 = "DB";
										priorL = swingprice;
									}
	//Print("SZ[0]: "+SZ[0]+"  SZ[1]: "+SZ[1]);
									drawString(zzId0, xx, y1 + vTextOffset, pZZlabelFont, (SwingLabelBrush=='u' ? lineBrushUp : lineBrushDown), SharpDX.DirectWrite.TextAlignment.Center);                                            
								}else{//need to draw 2 labels on an outside bar
line=2665;
									SwingLabelBrush = 'u';
									zzId0 = "HH";
									if(OB_High == priorH) zzId0 = "DT";
									else if(OB_High < priorH) zzId0 = "LH";
									priorH = OB_High;
									vTextOffset = -SZ[0] -3f;
								    drawString(zzId0, xx, Math.Min(y1,y2) + vTextOffset, pZZlabelFont, (SwingLabelBrush=='u' ? lineBrushUp : lineBrushDown), SharpDX.DirectWrite.TextAlignment.Center);                                            

									SwingLabelBrush = 'd';
									vTextOffset = 3f;
									zzId0 = "LL";
									if(OB_Low == priorL) zzId0 = "DB";
									else if(OB_Low > priorL) zzId0 = "HL";
									priorL = OB_Low;
								    drawString(zzId0, x1 - SZ[1] / 2, Math.Max(y1,y2) + vTextOffset, pZZlabelFont, (SwingLabelBrush=='u' ? lineBrushUp : lineBrushDown), SharpDX.DirectWrite.TextAlignment.Center);                                            
								}
							}
//}catch(Exception onr){Print("OnRender: "+onr.ToString());}
							#endregion
						}
						if(swingABar0OnChart > rmab) break;
						swingprice2 = swingprice1;
						swingprice1 = swingprice;
						swingABar1  = swingABar0;
					}
}catch(Exception eee){Print(line+"  Error: "+eee.ToString());}
				}
line=2691;
			}
			#endregion
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
		}catch(Exception ore){Print(line+"  "+ore.ToString());}
		}

		#region - supporting code -
		//set the color to Black or White depending on background color
		public Brush ContrastingColor(SolidColorBrush background)
		{
		    // Counting the perceptive luminance - human eye favors green color... 
		    double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
		    if (a < 0.5) return Brushes.Black; // bright colors - black font
		    else return Brushes.White; // dark colors - white font
		}

		private float[] getTextHeightAndWidth(string text, SimpleFont font){
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			float[] result = new float[2]{(float)font.Size, textLayout.Metrics.Width};

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return result;
		}
		private float getTextWidth(string text, SimpleFont font)
		{
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        );
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

		    float textwidth = textLayout.Metrics.Width;

		    textLayout.Dispose();
		    textFormat.Dispose();

		    return textwidth;
		}
//		private float getTextHeight(string text, SimpleFont font)
//		{
//		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
//		        Core.Globals.DirectWriteFactory,
//		        font.FamilySerialize,
//		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
//		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
//		        SharpDX.DirectWrite.FontStretch.Normal,
//		        (float)font.Size
//		        );
//		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

//		    float textheight = textLayout.Metrics.Height;

//		    textLayout.Dispose();
//		    textFormat.Dispose();

//		    return textheight;
//		}
//		#region drawstring
		//Draw a text at {x;y} coordinates in pixel.
		private void drawString(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxTextWidth = -9999f)
		{
		    SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
		    SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
		        Core.Globals.DirectWriteFactory,
		        font.FamilySerialize,
		        font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
		        font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
		        SharpDX.DirectWrite.FontStretch.Normal,
		        (float)font.Size
		        ) { TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
		    SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, MaxTextWidth <= 0f ? getTextWidth(text, font) : MaxTextWidth, float.MaxValue);

		    RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

		    textLayout.Dispose();
		    textFormat.Dispose();
		}
//		private void drawstring(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.Direct2D1.Brush bkgBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxTextWidth = -9999f, float MaxX = -9999f)
//		{
//			#region drawstring
//			if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
//			SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();

//			var textFormat = new SharpDX.DirectWrite.TextFormat(
//				Core.Globals.DirectWriteFactory,
//				font.FamilySerialize,
//				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
//				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
//				SharpDX.DirectWrite.FontStretch.Normal,
//				(float)font.Size
//			)
//				{ TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
//			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, (MaxTextWidth>0 ? MaxTextWidth : ChartPanel.W/3), ChartPanel.H);
//			if(x<0) x = Math.Abs(x) - textLayout.Metrics.Width - 5;

//			if(MaxX>0)
//				x = Math.Min(x, MaxX - 3f - textLayout.Metrics.Width);

//			y = y - textLayout.Metrics.Height/2.0;
//			if (bkgBrush!=null && bkgBrush.Opacity>0) {
//				double xl = x - 3;
//				double xr = x + textLayout.Metrics.Width + 3;
//				double yt = y - 1;
//				double yb = y+textLayout.Metrics.Height + 2;
//				if(textAlignment==SharpDX.DirectWrite.TextAlignment.Trailing){
//					xr = x + textLayout.Metrics.LayoutWidth +3;
//					xl = xr - textLayout.Metrics.Width - 6;
//				}
//				else if(textAlignment==SharpDX.DirectWrite.TextAlignment.Center){
//					xr = x + textLayout.Metrics.LayoutWidth/2 + 3 + textLayout.Metrics.Width/2;
//					xl = xr - textLayout.Metrics.Width - 6;
//				}
//				var bkgBox = new System.Windows.Point[]
//				{	new System.Windows.Point(xl, yt),
//					new System.Windows.Point(xl, yb),
//					new System.Windows.Point(xr, yb),
//					new System.Windows.Point(xr, yt),
//				};
//				drawRegion(bkgBox, bkgBrush);
//			}
//			RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

//			textLayout.Dispose();
//			textFormat.Dispose();
//			#endregion
//		}
//		#endregion

		private void drawLine(double x1, double x2, double y1, double y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle = DashStyleHelper.Solid, int width = 1, int opacity = 100)
		{
		    dxbrush.Opacity = opacity / 100f;
		    SharpDX.Direct2D1.DashStyle _dashstyle;
		    if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

		    SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
		    SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

		    RenderTarget.DrawLine(new SharpDX.Vector2((float)x1,(float)y1), new SharpDX.Vector2((float)x2,(float)y2), dxbrush, width, strokestyle);

		    strokestyle.Dispose();
		}
		
//        //Draw Region. Rect in pixel coordinate.
//        private void drawRegion(Rect rectangle, SharpDX.Direct2D1.Brush color)//, int opacity = 100)
//        {
//            drawRegion(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, color);
//        }
//        //Draw Region. x and y as pixel coordinate, w and h in pixel too.
//        private void drawRegion(double x, double y, double w, double h, SharpDX.Direct2D1.Brush color)
//        {
//            drawRegion(
//				new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, 
//				color);
//        }
//		private void drawRegion(System.Windows.Point[] points, SharpDX.Direct2D1.Brush dxbrush)
//		{
//		    SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

//		    SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
//		    SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
//		    sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
//		    sink1.AddLines(vectors);
//		    sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
//		    sink1.Close();

//		    RenderTarget.FillGeometry(geo1, dxbrush);
//		    geo1.Dispose();
//		    sink1.Dispose();
//		}

//		//Draw a line between 2 points. 'x1' and 'x2' are pixel locations, the y value is the numerical value (ie price / oscillator value)
//		private void drawLine(double val1, double val2, float x1, float x2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = true)
//		{
//			if(double.IsNaN(val1) || double.IsNaN(val2)) {Print("Val is NaN"); return;}
//			//SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
//			SharpDX.Direct2D1.DashStyle _dashstyle;
//			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

//			SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
//			SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

//			SharpDX.Vector2 v1 = new SharpDX.Vector2(x1, drawOnPricePanel ? chartScale.GetYByValue(val1) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val1));
//			SharpDX.Vector2 v2 = new SharpDX.Vector2(x2, drawOnPricePanel ? chartScale.GetYByValue(val2) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val2));
////Print("\nv1: "+v1.X+", "+v1.Y+"   "+val1);
////Print("v2: "+v2.X+", "+v2.Y+"   "+val2);
//			RenderTarget.DrawLine(v1, v2, dxbrush, width, strokestyle);

//			strokestyle.Dispose();
//		}
//		private void drawRectangle(Rect rectangle, SharpDX.Direct2D1.Brush dxbrush, int width, DashStyleHelper dashstyle = DashStyleHelper.Solid)
//		{
//			drawRectangle(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height, dxbrush, dashstyle, width);
//		}
//		//Draw Rectangle. x and y as pixel coordinate, w and h in pixel too.
//		private void drawRectangle(double x, double y, double w, double h, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
//		{
//			drawRectangle(new Point[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) }, dxbrush, dashstyle, width);
//		}
//		private void drawRectangle(Point[] points, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width)
//		{
//			drawLine(points[0].X, points[1].X, points[0].Y, points[1].Y, dxbrush, dashstyle, width);
//			drawLine(points[1].X, points[2].X, points[1].Y, points[2].Y, dxbrush, dashstyle, width);
//			drawLine(points[2].X, points[3].X, points[2].Y, points[3].Y, dxbrush, dashstyle, width);
//			drawLine(points[3].X, points[0].X, points[3].Y, points[0].Y, dxbrush, dashstyle, width);
//		}
		#endregion

		#region -- Parameters --
		[Display(Name = "Use Chart Data?", GroupName = "Data Parameters", Description = "Use chart data instead of custom bkg data", Order = 5)]
		public bool pUseChartData {get;set;}

		[Display(Name = "Custom Start DT", GroupName = "Data Parameters", Description = "", Order = 15)]
		public DateTime pBkgDataStartDT {get;set;}

		[Display(Name = "Custom End DT", GroupName = "Data Parameters", Description = "", Order = 16)]
		public DateTime pBkgDataEndDT {get;set;}
		
		[Display(Name = "Bkg Data MinutesPerBar", GroupName = "Data Parameters", Description = "", Order = 30)]
		public int pBkgDataMinuteValue {get;set;}

		#region -- Dynamic Focus --
		[Display(Name = "Use Dynamic Focus?", GroupName = "Dynamic Focus", Description = "Use current price area to focus your zone strength calculation", Order = 10)]
		public bool pUseDynamicFocus {get;set;}
		[Range(0.1,100)]
		[Display(Name = "ATR mult", GroupName = "Dynamic Focus", Description = "", Order = 20)]
		public double pDynamicFocusATRmult {get;set;}

		[Range(0,100)]
		[Display(Name = "Top/Bot line opacity", GroupName = "Dynamic Focus", Description = "", Order = 30)]
		public int pDynamicFocusLineOpacity {get;set;}
		#endregion

		#region -- Zone Visuals --
		[Range(1,int.MaxValue)]
		[Display(Name = "Zone Height (ticks)", GroupName = "Zone Visuals", Description = "", Order = 10)]
		public int pZoneSizeTicks {get;set;}

		[Display(Name = "Strength basis", GroupName = "Zone Visuals", Description = "", Order = 20)]
		public ARC_SwingPointConfluence_StrengthTypes pStrengthBasis {get;set;}

		[Range(0,1)]
		[Display(Name = "Minimum Strength Percentile", GroupName = "Zone Visuals", Description = "", Order = 30)]
		public double pMinimumStrengthPctile {get;set;}

		[Range(0,float.MaxValue)]
		[Display(Name = "Max histo size (pixels)", GroupName = "Zone Visuals", Description = "", Order = 40)]
		public float pMaxHistoSize {get;set;}

		[Display(Name = "Histo locaction", GroupName = "Zone Visuals", Description = "", Order = 50)]
		public ARC_SwingPointConfluence_HistoLoc pHistoLoc {get;set;}

		[XmlIgnore]
		[Display(Name = "Resistance Histo fill", GroupName = "Zone Visuals", Description = "", Order = 60)]
		public Brush pResistanceHistoBrush {get;set;}
					[Browsable(false)]
					public string pResistanceHistoBrushSerialize{
							get { return Serialize.BrushToString(pResistanceHistoBrush); }
							set { pResistanceHistoBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Support Histo fill", GroupName = "Zone Visuals", Description = "", Order = 61)]
		public Brush pSupportHistoBrush {get;set;}
					[Browsable(false)]
					public string pSupportHistoBrushSerialize{
							get { return Serialize.BrushToString(pSupportHistoBrush); }
							set { pSupportHistoBrush = Serialize.StringToBrush(value); }}

		[Range(0,100)]
		[Display(Name = "Opacity for strong zones", GroupName = "Zone Visuals", Description = "", Order = 70)]
		public int pStrongZoneOpacity {get;set;}

		[Range(0,100)]
		[Display(Name = "Opacity for weak zones", GroupName = "Zone Visuals", Description = "", Order = 71)]
		public int pWeakZoneOpacity {get;set;}

		[Display(Name = "Zones to display", GroupName = "Zone Visuals", Description = "", Order = 80)]
		public ARC_SwingPointConfluence_ZoneDisplay pZonesToDisplay {get;set;}

		[Display(Name = "Extend Strong zones?", GroupName = "Zone Visuals", Description = "", Order = 90)]
		public bool pExendedStrongZones {get;set;}

		[Display(Name = "Extend Weak zones?", GroupName = "Zone Visuals", Description = "", Order = 100)]
		public bool pExendedWeakZones {get;set;}

		[XmlIgnore]
		[Display(Name = "Resistance Zone fill", GroupName = "Zone Visuals", Description = "", Order = 110)]
		public Brush pResistanceZoneBrush {get;set;}
					[Browsable(false)]
					public string pResistanceZoneBrushSerialize{
							get { return Serialize.BrushToString(pResistanceZoneBrush); }
							set { pResistanceZoneBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Support Zone fill", GroupName = "Zone Visuals", Description = "", Order = 111)]
		public Brush pSupportZoneBrush {get;set;}
					[Browsable(false)]
					public string pSupportZoneBrushSerialize{
							get { return Serialize.BrushToString(pSupportZoneBrush); }
							set { pSupportZoneBrush = Serialize.StringToBrush(value); }}

		[Display(Name = "Labels on Strong zones?", GroupName = "Zone Visuals", Description = "", Order = 120)]
		public bool pShowTextOnStrongZones {get;set;}
		[Display(Name = "Labels on Weak zones?", GroupName = "Zone Visuals", Description = "", Order = 130)]
		public bool pShowTextOnWeakZones {get;set;}

		[XmlIgnore]
		[Display(Name = "Label Text color", GroupName = "Zone Visuals", Description = "", Order = 140)]
		public Brush pLabelTextBrush { get; set; }
					[Browsable(false)]
					public string pLabelTextBrush_{
							get { return Serialize.BrushToString(pLabelTextBrush); }
							set { pLabelTextBrush = Serialize.StringToBrush(value); }}
		#endregion

		#region -- Swing Parameters --
		[Display(Name = "Use Highs/Lows", GroupName = "SwingTrend Parameters", Description = "Use High/Lows or Input", Order = 5)]
		public bool isHLBased { get; set; }

		private int pSwingStrength = 5;
		[Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 10)]
		public int SwingStrength {get{return pSwingStrength;} set{ pSwingStrength = Math.Max(1,value);}}

		#endregion

		#region Custom Visuals
		[Display(Name = "Show Lines", GroupName = "Swing Visuals", Description = "Show structure trend lines", Order = 5)]
		public bool pShowSwingLines {get;set;}

		[XmlIgnore]
		[Display(Name = "Up-trend line color", GroupName = "Swing Visuals", Description = "Line color for up-trending structure", Order = 10)]
		public Brush UpLineColor { get; set; }
					[Browsable(false)]
					public string UpLineColorSerialize{
							get { return Serialize.BrushToString(UpLineColor); }
							set { UpLineColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Down-trend line color", GroupName = "Swing Visuals", Description = "Line color for down-trending structure", Order = 20)]
		public Brush DownLineColor { get; set; }
					[Browsable(false)]
					public string DownLineColorSerialize{
							get { return Serialize.BrushToString(DownLineColor); }
							set { DownLineColor = Serialize.StringToBrush(value); }}
		[Range(1, 10)]
		[Display(Name = "Line Thickness", GroupName = "Swing Visuals", Description = "Thickness of structure lines", Order = 30)]
		public int ZZLineThickness {get;set;}

		[Display(Name = "Show Swing Labels", GroupName = "Swing Visuals", Description = "Show zigzag labels (e.g. 'HH' or 'LH', etc)", Order = 40)]
		public bool pShowSwingLabels{get;set;}

		[Display(Name = "Font size", GroupName = "Swing Visuals", Description = "Font for structure labels", Order = 50)]
        public SimpleFont pZZlabelFont { get; set; }
		#endregion

        [Display(Name = "Button Text", GroupName = "Custom Visuals", Description = "", Order = 60)]
		public string pButtonText {get;set;}
        [Display(Name = "Show Input data msg?", GroupName = "Custom Visuals", Description = "", Order = 70)]
		public bool pShowInputBarDataMsg {get;set;}

		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_SwingPointConfluence[] cacheARC_SwingPointConfluence;
		public ARC.ARC_SwingPointConfluence ARC_SwingPointConfluence()
		{
			return ARC_SwingPointConfluence(Input);
		}

		public ARC.ARC_SwingPointConfluence ARC_SwingPointConfluence(ISeries<double> input)
		{
			if (cacheARC_SwingPointConfluence != null)
				for (int idx = 0; idx < cacheARC_SwingPointConfluence.Length; idx++)
					if (cacheARC_SwingPointConfluence[idx] != null &&  cacheARC_SwingPointConfluence[idx].EqualsInput(input))
						return cacheARC_SwingPointConfluence[idx];
			return CacheIndicator<ARC.ARC_SwingPointConfluence>(new ARC.ARC_SwingPointConfluence(), input, ref cacheARC_SwingPointConfluence);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_SwingPointConfluence ARC_SwingPointConfluence()
		{
			return indicator.ARC_SwingPointConfluence(Input);
		}

		public Indicators.ARC.ARC_SwingPointConfluence ARC_SwingPointConfluence(ISeries<double> input )
		{
			return indicator.ARC_SwingPointConfluence(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_SwingPointConfluence ARC_SwingPointConfluence()
		{
			return indicator.ARC_SwingPointConfluence(Input);
		}

		public Indicators.ARC.ARC_SwingPointConfluence ARC_SwingPointConfluence(ISeries<double> input )
		{
			return indicator.ARC_SwingPointConfluence(input);
		}
	}
}

#endregion
