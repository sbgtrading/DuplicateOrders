#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region Category Order
    [Gui.CategoryOrder("Zone Settings", 1)]
    [Gui.CategoryOrder("Absorption Zone Settings", 2)]
    [Gui.CategoryOrder("Block Zone Settings", 3)]
    [Gui.CategoryOrder("Tape Display", 4)]
    [Gui.CategoryOrder("General", 5)]
    [Gui.CategoryOrder("Indicator Version", 6)]
    #endregion

    public class ARC_MMTT : Indicator
    {
		private bool IsDebug        = false;
		private bool ValidLicense   = false;
		private bool IsExpired      = true;

		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "MarketMakerTapeTrader";

		private const string VERSION = "v1.16 13.Jun.2022";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }
		//v1.16 added pShowBuyAbsorptionZones, pShowSellAbsorptionZones, pShowTape, BidBlockStroke and AskBlockStroke

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "19964", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
				bool IsConnectionIssue = UserId.CompareTo("253729")==0 || MachineId.CompareTo("0DE7B460EE7C494980DC065DDE946572")==0;//Chris Zolton
				if(IsConnectionIssue) return true;
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

        #region Floating Variables
        private string _sThisName = "ARC_MMTT";

        //int
        //double
        //float
        //bool
        private bool _bIsToolBarButtonAdded = false;
        private bool _bTapePaused = false;
        //string
        private string _sToolbarName = "NSMMTTToolBar", uID;
        //Other
        private static float _fStartFromCornerX = 10;
        private static float _fStartFromCornerY = 25;
        //Clases
        private TickManager _TickManager = null;
        //private SecondManager _SecondManager = null;
        private ZoneManager _ZoneManager = null;
        private AccelerationColorSettings _AccelerationSettings = null;
        private List<DrawLineProperties> _lTapeLive = new List<DrawLineProperties>();
        private List<DrawLineProperties> _lTapePaused = new List<DrawLineProperties>();
        private Dictionary<int, FullBar> bars = new Dictionary<int, FullBar>();
        #endregion

        #region Controls Variables
        private Menu _mnuControlContainer = null;
        private Grid _grdIndyToolbar;
        private Dictionary<string, MenuItem> _lstMenuItems = new Dictionary<string, MenuItem>();
        #endregion

        #region On State Change
        protected override void OnStateChange()
        {
            #region Set Defaults
            if (State == State.SetDefaults) 
            {
                #region Default Crap
                Description = @"";
                Name = _sThisName;
                Calculate = Calculate.OnEachTick;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = false;
                DrawVerticalGridLines = false;
                PaintPriceMarkers     = true;
                ScaleJustification    = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                //Disable this property if your indicator requires custom values that cumulate with each new market data event. 
                //See Help Guide for additional information.
                IsSuspendedWhileInactive = false;
                ZOrder = int.MaxValue;
                #endregion

                #region Settings
                //Zone Settings
                ShowZones = true;
                pShowBuyAbsorptionZones = true;
                pShowSellAbsorptionZones = true;
                ExtendAbsorptionZones = true;
                AbsorptionContractsMinimum = 40;
                //AbsorptionThreshold = 2.5;
                AbsorptionStrokeBid = new Stroke(Brushes.Maroon, 2);
                AbsorptionStrokeAsk = new Stroke(Brushes.Navy, 2);
                ShowBlockZones = true;
                BlockThreshold = 0.5;
				BlockAtBidStroke = new Stroke(Brushes.Red,2);
				BlockAtAskStroke = new Stroke(Brushes.Lime,2);
                MaxBarsBack = 10;
                BlockContracts = 20;
                //Tape Display
				pShowTape = true;
                ShowTapeBackground = true;
                TapeBackgroundStroke = new Stroke(Brushes.Black, 2);
                TextFont = new SimpleFont("Century Gothic", 11) { Bold = true };
                TextBrush = Brushes.White;
                UpColor = Brushes.Lime;
                DnColor = Brushes.Red;
                AcellerationStep1 = Brushes.DarkBlue;
                AcellerationStep2 = Brushes.Blue;
                AcellerationStep3 = Brushes.DodgerBlue;
                AcellerationStep4 = Brushes.Aqua;
                AcellerationStep5 = Brushes.Cyan;
                //General
                ButtonText = "MMTT";
                //MaxDrawZones = 2000;
                #endregion
            }
            #endregion

            #region Other States
            else if (State == State.Configure)
            {
				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion
			}
            else if(State == State.Historical)
            {
                AddToToolBar();
            }
            else if(State == State.DataLoaded)
            {
                InitializeVariables();
            }
            else if (State == State.Terminated)
            {
                RemoveFromToolBar();
            }
            #endregion
        }
        #endregion

        #region On Bar Update - Empty
        protected override void OnBarUpdate() 
        {
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(bars.Count > 0)
            {
                for(int i = CurrentBar; i >= 1; i--)
                {
                    if(bars.ContainsKey(i))
                        bars[i].UpdateBars(Close[0], Time[0], ExtendAbsorptionZones);
                }
            }
        }
        #endregion

        #region Objects

        #region State Functions

        #region Add To ToolBar
        private void AddToToolBar()
        {
            if (!_bIsToolBarButtonAdded && ChartControl != null)
            {
                Action p = () =>
                {
                    #region Initial SetUp
                    Chart chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                    if (chartWindow == null) return;

                    foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (_sToolbarName + uID)) _bIsToolBarButtonAdded = true;

                    _grdIndyToolbar = new Grid { Visibility = Visibility.Collapsed };

                    _mnuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
                    MenuItem MenuControl = new MenuItem { Name = "MenuControl", BorderThickness = new Thickness(2), BorderBrush = Brushes.Orange, Header = ButtonText, Foreground = Brushes.Orange, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
                    _lstMenuItems.Add(MenuControl.Name, MenuControl);
                    _mnuControlContainer.Items.Add(MenuControl);
                    #endregion

                    #region General
                    string headItem = "miGeneral";
                    AddMenuItem("General", headItem, Brushes.Black, null, MenuControl);
                    AddMenuItem("Show Zones " + (ShowZones ? "ON" : "OFF"), "btGeneral_ShowZones", Brushes.Black, General_Click, _lstMenuItems[headItem]);
                    AddMenuItem("Show Tape " + (pShowTape ? "ON" : "OFF"), "btGeneral_ShowTape", Brushes.Black, General_Click, _lstMenuItems[headItem]);
                    AddMenuItem("Tape " + (_bTapePaused ? "Paused" : "Running"), "btGeneral_PauseTape", Brushes.Black, General_Click, _lstMenuItems[headItem]);
                    #endregion

                    #region Absorption
                    headItem = "miAbsorption";
                    AddMenuItem("Absorption", headItem, Brushes.Black, null, MenuControl);
                    AddMenuItem("Show BUY Zones " + (pShowBuyAbsorptionZones ? "ON" : "OFF"), "btAbsorption_ShowBuy", Brushes.Black, General_Click, _lstMenuItems[headItem]);
                    AddMenuItem("Show SELL Zones " + (pShowSellAbsorptionZones ? "ON" : "OFF"), "btAbsorption_ShowSell", Brushes.Black, General_Click, _lstMenuItems[headItem]);
//                case "btAbsorption_ShowBuy":  pShowBuyAbsorptionZones = !pShowBuyAbsorptionZones; item.Header = "Show BUY Zones " + (pShowBuyAbsorptionZones ? "ON" : "OFF"); invalidateVisual = true; break;
//                case "btAbsorption_ShowSell": pShowSellAbsorptionZones = !pShowSellAbsorptionZones; item.Header = "Show SELL Zones " + (pShowSellAbsorptionZones ? "ON" : "OFF"); invalidateVisual = true; break;

                    AddMenuItem(" Avg Bid size", "btAbsorption_Contracts_Bid", Brushes.Black, General_Click, _lstMenuItems[headItem], false);
                    AddMenuItem(" Avg Ask size", "btAbsorption_Contracts_Ask", Brushes.Black, General_Click, _lstMenuItems[headItem], false);
                    AddMenuItem("- - -", "btAbsorption_Lines", Brushes.Black, General_Click, _lstMenuItems[headItem], false);
                    AddMenuItem(MaxBarsBack + " Lookback bars", "btAbsorption_Bars", Brushes.Black, General_Click, _lstMenuItems[headItem], false);
                    //AddMenuItem(AbsorptionThreshold + " Multiplier", "btAbsorption_Multiplier", Brushes.Black, General_Click, _lstMenuItems[headItem], false);
                    #endregion

                    #region Block
                    headItem = "miBlock";
                    AddMenuItem("Block", headItem, Brushes.Black, null, MenuControl);
                    AddMenuItem("Show Zones " + (ShowBlockZones ? "ON" : "OFF"), "btBlock_Show", Brushes.Black, General_Click, _lstMenuItems[headItem]);
                    AddMenuItem(": Average Block", "btBlock_Contracts", Brushes.Black, General_Click, _lstMenuItems[headItem], false);
                    AddMenuItem("- - -", "btBlock_Lines", Brushes.Black, General_Click, _lstMenuItems[headItem], false);
                    AddMenuItem(MaxBarsBack + ": Lookback bars", "btBlock_BarsBack", Brushes.Black, General_Click, _lstMenuItems[headItem], false);
                    AddMenuItem(BlockThreshold + "%: percentile", "btBlock_Multiplier", Brushes.Black, General_Click, _lstMenuItems[headItem], false);
                    #endregion

                    #region Subscribe to Tab Control
                    _grdIndyToolbar.Children.Add(_mnuControlContainer);

                    chartWindow.MainMenu.Add(_grdIndyToolbar);
                    chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                    foreach (TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) _grdIndyToolbar.Visibility = Visibility.Visible;
                    AutomationProperties.SetAutomationId(_grdIndyToolbar, _sToolbarName + uID);
                    #endregion
                };
                GeneralInvokeAction(p);
            }
        }
        #endregion

        #region Remove From ToolBar
        private void RemoveFromToolBar()
        {
            if (_grdIndyToolbar != null)
            {
                Action p = () =>
                {
                    Chart chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;

                    chartWindow.MainMenu.Remove(_grdIndyToolbar);
                    _grdIndyToolbar = null;

                    chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
                    chartWindow = null;

                    _bIsToolBarButtonAdded = false;
                };
                GeneralInvokeAction(p);
            }
        }
        #endregion

        #region Initialize Variables
        private void InitializeVariables()
        {
            _AccelerationSettings = new AccelerationColorSettings()
            {
                TimeBrush1 = AcellerationStep1,
                TimeBrush2 = AcellerationStep2,
                TimeBrush3 = AcellerationStep3,
                TimeBrush4 = AcellerationStep4,
                TimeBrush5 = AcellerationStep5
            };
            ThresholdSettings tSettings = new ThresholdSettings()
            {
                //AbsorptionThresholdMultiplier = AbsorptionThreshold,
                AbsorptionColor = AbsorptionStrokeBid,
                BlockThresholdMultiplier = BlockThreshold,
                BidBlockColor = BlockAtBidStroke,
                AskBlockColor = BlockAtAskStroke,
            };
            _TickManager = new TickManager();
            _TickManager.ThresholdSettings = tSettings;
            _TickManager.MaximumBars = MaxBarsBack;
            _ZoneManager = new ZoneManager(TickSize);
            _ZoneManager.ThresholdSettings = tSettings;
            _ZoneManager.TextBrush = TextBrush;
        }
        #endregion

        #endregion

        #region Control Functions

        #region Add Menu Item
        private void AddMenuItem(string Header, string Name, Brush TextBrush, RoutedEventHandler EventHandler, MenuItem Parent = null, bool Editable = true)
        {
            MenuItem item = new MenuItem { Header = Header, Name = Name+uID, Foreground = TextBrush, StaysOpenOnClick = true, FontWeight = FontWeights.Normal };
            item.IsEnabled = Editable;
            if (EventHandler != null)
                item.Click += EventHandler;
            if (Parent != null)
                Parent.Items.Add(item);
            _lstMenuItems.Add(Name, item);
        }
        #endregion

        #region Update Button Text
        private void UpdateButtonText(double AverageBid, double AverageAsk, double BlockNumber)
        {
            Action p = () =>
            {
                if (_lstMenuItems.ContainsKey("btAbsorption_Contracts_Bid"))
                    _lstMenuItems["btAbsorption_Contracts_Bid"].Header = AverageBid + " Avg Bid size";
                if (_lstMenuItems.ContainsKey("btAbsorption_Contracts_Ask"))
                    _lstMenuItems["btAbsorption_Contracts_Ask"].Header = AverageAsk + " Avg Ask size";
                if (_lstMenuItems.ContainsKey("btBlock_Contracts"))
                    _lstMenuItems["btBlock_Contracts"].Header = BlockNumber + ": Average Block";
            };
            GeneralInvokeAction(p);
        }
        #endregion

        #endregion

        #region Event Handlers

        #region General_Click
        private void General_Click(object sender, EventArgs e)
        {
            //Print(sender.ToString());

            bool invalidateVisual = false;
            MenuItem item = sender as MenuItem;
            switch (item.Name.Replace(uID,string.Empty))
            {
                case "btGeneral_ShowZones": ShowZones = !ShowZones; item.Header = "Show Zones " + (ShowZones ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_ShowTape": pShowTape = !pShowTape; item.Header = "Show Tape " + (pShowTape ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btGeneral_PauseTape": _bTapePaused = !_bTapePaused; item.Header = "Tape " + (_bTapePaused ? "Paused" : "Running"); invalidateVisual = true; break;
                case "btAbsorption_ShowBuy":  pShowBuyAbsorptionZones = !pShowBuyAbsorptionZones; item.Header = "Show BUY Zones " + (pShowBuyAbsorptionZones ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btAbsorption_ShowSell": pShowSellAbsorptionZones = !pShowSellAbsorptionZones; item.Header = "Show SELL Zones " + (pShowSellAbsorptionZones ? "ON" : "OFF"); invalidateVisual = true; break;
                case "btBlock_Show": ShowBlockZones = !ShowBlockZones; item.Header = "Show Zones " + (ShowBlockZones ? "ON" : "OFF"); invalidateVisual = true; break;
            }
            if (invalidateVisual)
                CCInvokeAction(() =>
                {
                    ChartControl.InvalidateVisual();
                });
        }
        #endregion

        #region Tab Selection Changed Handler
        private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && _grdIndyToolbar != null)
                _grdIndyToolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #endregion

        #region Classes

        #region Normal Classes

        #region Tick Manager
        private class TickManager
        {
            private int _iCurrentBar = 0;
            private double _lContractsTopPercent = 0;
            private bool _bNewSecond = true;
            private bool _bActivateZone = true;
            private TickItem _LastTick = null;
            private List<TickItem> _lTickItems = new List<TickItem>();

            public int MaximumBars { get; set; }
            public double ContractsTopPercent { get { return _lContractsTopPercent; } }
            public bool NewSecond { get { return _bNewSecond; } }
            public ThresholdSettings ThresholdSettings { get; set; }

            public TickItem AddTick(MarketDataEventArgs MarketDataUpdate, int CurrentBar, int ContractsThreshold)
            {
                int tick = 1;
                _bNewSecond = true;
                if (_LastTick != null)
                {
                    if (MarketDataUpdate.Price != _LastTick.Price)
                        tick = MarketDataUpdate.Price > _LastTick.Price ? 1 : -1;
                    else
                        tick = _LastTick.Tick > 0 ? 2 : -2;
                    if (MarketDataUpdate.Time.TimeOfDay.Seconds == _LastTick.Time.TimeOfDay.Seconds && MarketDataUpdate.Time.TimeOfDay.Minutes == _LastTick.Time.TimeOfDay.Minutes && MarketDataUpdate.Time.TimeOfDay.Hours == _LastTick.Time.TimeOfDay.Hours)
                        _bNewSecond = false;
                }

                _LastTick = new TickItem()
                {
                    Contracts = MarketDataUpdate.Volume,
                    Price = MarketDataUpdate.Price,
                    Time = MarketDataUpdate.Time,
                    Tick = tick,
                    BarNumber = CurrentBar,
                    DetectionType = ThresholdSettings.CheckThresholds(MarketDataUpdate.Volume, ContractsThreshold, eTapeDetection.Block)
                };
                _lTickItems.Add(_LastTick.Clone() as TickItem);

                if(CurrentBar != _iCurrentBar && _lTickItems.Count > 0)
                {
                    //remove the oldest bars and calculate average tick and top x percent
                    int size = _lTickItems.Count - 1;
                    int topPercentSize = (int)Math.Floor(size * ThresholdSettings.BlockThresholdMultiplier * 0.01);
                    List<long> contracts = new List<long>();
                    bool sorted = false;
                    for(int i = size; i >= 0; i--)
                    {
                        if(_lTickItems[i].BarNumber >= _iCurrentBar - MaximumBars)
                        {
                            if(contracts.Count < topPercentSize)
                            {
                                contracts.Add(_lTickItems[i].Contracts);
                            }
                            else if(contracts.Count > 0)
                            {
                                if (!sorted)
                                {
                                    contracts.Sort();
                                    sorted = true;
                                }
                                if (contracts[0] < _lTickItems[i].Contracts)
                                {
                                    contracts[0] = _lTickItems[i].Contracts;
                                    sorted = false;
                                }
                            }
                        }
                        else
                        {
                            _bActivateZone = true;
                            _lTickItems.RemoveAt(i);
                        }
                    }
                    if (contracts.Count > 0)
                    {
                        contracts.Sort();
                        _lContractsTopPercent = contracts.Average();
                    }
                }
                _iCurrentBar = CurrentBar;
                return _LastTick;
            }

            public void AddDetectionType(eTapeDetection Detection)
            {
                _LastTick.DetectionType = Detection;
                _lTickItems[_lTickItems.Count - 1].DetectionType = Detection;
            }

            public DrawLineProperties GetTickProperties(MarketDataEventArgs MarketDataUpdate, Tuple<string, Stroke> DetectionPack, Brush UpColor, Brush DnColor, AccelerationColorSettings AccelerationColors)
            {
                bool showTradeBox = _lTickItems.Count < 2 || _lTickItems[_lTickItems.Count - 1].DetectionType != _lTickItems[_lTickItems.Count - 2].DetectionType;
                DrawLineProperties colors =
                    new DrawLineProperties()
                    {
                        Time = _LastTick.Time,
                        AccelerationColors = AccelerationColors,
                        Columns = new List<TextBoxDrawingProperties>()
                        {
                            new TextBoxDrawingProperties(new Stroke(Brushes.Transparent), 50, Brushes.White){ Text = _LastTick.Time.ToString("hh:mm:ss") },
                            new TextBoxDrawingProperties
                            (
                                new Stroke(_LastTick.Tick == 1 ? UpColor : _LastTick.Tick == -1 ? DnColor : Brushes.Transparent),
                                100,
                                _LastTick.Tick > 1 ? UpColor : _LastTick.Tick < -1 ? DnColor : Brushes.Black
                            )
                            {
                                Text = MarketDataUpdate.Instrument.MasterInstrument.FormatPrice(_LastTick.Price)
                            },
                            new TextBoxDrawingProperties(new Stroke(Brushes.White), 0, _LastTick.Tick > 0 ? UpColor : DnColor, 20){ Text = _LastTick.Tick == 1 ? "+" : _LastTick.Tick == -1 ? "-" : " " },
                            new TextBoxDrawingProperties(new Stroke(Brushes.White), 0, _LastTick.Tick == 1 ? UpColor : _LastTick.Tick == -1 ? DnColor : Brushes.White){ Text = _LastTick.Contracts.ToString() },
                            new TextBoxDrawingProperties(DetectionPack.Item2, 100, Brushes.Black)
                            { 
                                Text = showTradeBox ? DetectionPack.Item1 : ""
                            }
                        }
                    };
                return colors;
            }

            public string DrawLastTick()
            {
                return _lTickItems.Count > 0 ? _lTickItems[_lTickItems.Count - 1].ToString() : "No ticks are stored";
            }
        }
        #endregion

        #region Tick Item
        private class TickItem : ICloneable
        {
            public int Tick { get; set; }
            public int BarNumber { get; set; }
            public long Contracts { get; set; }
            public double Price { get; set; }
            public DateTime Time { get; set; }
            public eTapeDetection DetectionType { get; set; }

            public override string ToString()
            {
                return "Time: " + Time + "; Price: " + Price + "; Tick: " + (Tick == 1 ? "+" : Tick == -1 ? "-" : " ") + "; Volume: " + Contracts + "; DetectionType: " + DetectionType + ";";
            }

            public object Clone()
            {
                return new TickItem() { Time = Time, Price = Price, Tick = Tick, BarNumber = BarNumber, Contracts = Contracts, DetectionType = DetectionType/*, DrawingProperties = DrawingProperties.Clone() as DrawLineProperties*/ };
            }
        }
        #endregion

        #region Draw Line Properties
        private class DrawLineProperties : ICloneable
        {
            private float _fY = 0;
            private float _fHeight = 0;
            private bool _bDrawLine = true;

            public int ValueFromNewSecond { get; set; }
            public DateTime Time { get; set; }
            public AccelerationColorSettings AccelerationColors { get; set; }
            public List<TextBoxDrawingProperties> Columns { get; set; }

            public bool DrawRow(SharpDX.Direct2D1.RenderTarget RenderTarget, float ChartHeight, float ChartWidth, int NumberInList, SimpleFont TextFont)
            {
                if (!_bDrawLine)
                {
                    return false;
                }
                if (_fHeight == 0)
                {
                    Size size = SharpDXUtils.MeasureString("!1Q", TextFont);
                    _fHeight = (float)size.Height;
                }
                _fY = _fStartFromCornerY + NumberInList * _fHeight;
                if (_fY > ChartHeight + _fStartFromCornerY)
                {
                    _bDrawLine = false;
                    return false;
                }
                float x = _fStartFromCornerX;
                for(int i = 0; i < Columns.Count; i++)
                {
                    x += Columns[i].Update(x, TextFont, i == 0 ? AccelerationColors.GetStroked(ValueFromNewSecond) : null) + 2;
                    Columns[i].DrawBox(RenderTarget, _fY, i == Columns.Count - 1 ? 0 : _fHeight, TextFont, new Tuple<float, float>((float)ChartWidth, (float)ChartHeight));
                }
                return true;
            }

            public float CalculateBoxWidth(SimpleFont TextFont)
            {
                if(Columns.Count > 0)
                {
                    float x = _fStartFromCornerX + 1;
                    for (int i = 0; i < Columns.Count - 2; i++)
                    {
                        x += Columns[i].Update(x, TextFont, null) + 2;
                    }
                    x += (float)SharpDXUtils.MeasureString("123 ", TextFont).Width + 2;
                    x += (float)SharpDXUtils.MeasureString("BLK ", TextFont).Width + 2;
                    x += _fStartFromCornerX + 1;
                    return x;
                }
                return 0;
            }

            public object Clone()
            {
                List<TextBoxDrawingProperties> columns = new List<TextBoxDrawingProperties>();
                foreach (TextBoxDrawingProperties p in Columns)
                    columns.Add(p.Clone() as TextBoxDrawingProperties);

                return new DrawLineProperties()
                {
                    Columns = columns,
                    _fHeight = _fHeight,
                    AccelerationColors = AccelerationColors.Clone() as AccelerationColorSettings
                };
            }

        }
        #endregion

        #region Text Box Drawing Properties
        private class TextBoxDrawingProperties : ICloneable
        {
            public int BackgroundOpacity { get; set; }
            private float _fX = 0;
            private float _fWidth = 0;
            public string Text { get; set; }
            public Brush TextBrush { get; set; }
            public Stroke BackgroundStroke { get; set; }

            public TextBoxDrawingProperties(Stroke Stroke, int Opacity, Brush TextBrush, float FixedWidth = 0)
            {
                BackgroundStroke = Stroke; BackgroundOpacity = Opacity; this.TextBrush = TextBrush; _fWidth = FixedWidth;
            }

            public float Update(float PrevX, SimpleFont TextFont, Stroke OverrideBackgroundStroke = null)
            {
                if (OverrideBackgroundStroke != null)
                    BackgroundStroke = OverrideBackgroundStroke;
                if (_fWidth == 0)
                {
                    Size size = SharpDXUtils.MeasureString(Text, TextFont);
                    _fWidth = (float)size.Width + 10;
                }
                if (_fX != PrevX)
                    _fX = PrevX;
                return _fWidth;
            }

            public void DrawBox(SharpDX.Direct2D1.RenderTarget RenderTarget, float Y, float Height, SimpleFont TextFont, Tuple<float, float> ChartWidthNHeight)
            {
                if(Height == 0)
                    Height = (float)SharpDXUtils.MeasureString(Text, TextFont).Height;
                DrawSharpDX.BoxText(RenderTarget, Text, _fX, Y, _fWidth, Height, BackgroundStroke, BackgroundOpacity, TextBrush, TextFont, false, true, ChartWidthNHeight);
            }

            public object Clone()
            {
                return new TextBoxDrawingProperties(BackgroundStroke.Clone() as Stroke, BackgroundOpacity, TextBrush)
                {
                    _fX = _fX,
                    _fWidth = _fWidth,
                    Text = Text
                };
            }
        }
        #endregion

        #region Zone Manager
        private class ZoneManager
        {
            private List<Zone> _lstZones = new List<Zone>();
            private double _dTickSize = 0;

            public ZoneManager(double TickSize)
            {
                _dTickSize = TickSize;
            }

            public Brush TextBrush { get; set; }
            public ThresholdSettings ThresholdSettings { get; set; }

            public Tuple<string, Stroke> ProcessTick(TickItem Tick, int BarNumber)
            {
                if (Tick == null)
                    return new Tuple<string, Stroke> ("", null);
                if (Tick.DetectionType == eTapeDetection.Block)
                {
					bool IsBid = Tick.Tick < 0;
                    _lstZones.Add(new Zone()
                    {
                        Time = Tick.Time,
                        BarNumber = BarNumber,
                        Contracts = Tick.Contracts,
                        Bid = IsBid,
                        Price = Tick.Price,
                        Detection = Tick.DetectionType,
                        ZoneStroke = new Stroke(ThresholdSettings.ReturnDetectionColor(IsBid, Tick.DetectionType)),
                        TextBrush = TextBrush
                    });
                    return new Tuple<string, Stroke>("BLK\r\n"+Tick.Contracts, _lstZones[_lstZones.Count-1].ZoneStroke);
                }
                return new Tuple<string, Stroke>("", null);
            }

            //private void AddZone(Zone zone)
            //{
            //    _lstZones.Add(zone.Clone() as Zone);
            //    if (_lstZones.Count >= _iMaxDrawZones)
            //        _lstZones.RemoveAt(0);
            //}

            public void DrawZones(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl ChartControl, ChartScale ChartScale, bool ShowBlockZones, ChartBars bars)
            {
                if(_lstZones.Count > 0 && ShowBlockZones)
                {
                    for(int i = _lstZones.Count - 1; i >= 0; i--)
                    {
                        if (_lstZones[i].Detection == eTapeDetection.Block)
                            _lstZones[i].Draw(RenderTarget, ChartControl, ChartScale, bars); 
                    }
                }
                //foreach (Zone zone in _lstZones)
                //{
                //    if(zone.Detection == eTapeDetection.Absorption ? ShowAbsorptionZones : ShowBlockZones)
                //        zone.Draw(RenderTarget, ChartControl, ChartScale);
                //}
            }
        }
        #endregion

        #region Zone
        private class Zone : ICloneable
        {
            public long Contracts { get; set; }
            public double Price { get; set; }
            //public double PriceLow { get; set; }
            public DateTime Time { get; set; }
            public int BarNumber { get; set; }
            public bool Bid { get; set; }
            public Brush TextBrush { get; set; }
            public Stroke ZoneStroke { get; set; }
            public eTapeDetection Detection { get; set; }

            public void Draw(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl ChartControl, ChartScale ChartScale, ChartBars bars) //still need to add opacity 
            {
                Tuple<float, float> chart = SharpDXUtils.GetChartWidthNHeight(ChartControl, ChartScale);
                float x1 = ChartControl.GetXByBarIndex(bars, BarNumber) + (Bid ? -1f : 1f)*(float)(ChartControl.BarWidth);
                float yt = ChartScale.GetYByValue(Price);
                if (!SharpDXUtils.IsPointInChart(x1, yt, chart))
                    return;
                float xDiff = 10;
                DrawSharpDX.GeometryWithFill(RenderTarget,
                    new List<Tuple<float, float>>()
                    {
                        new Tuple<float, float>(x1, yt),
                        new Tuple<float, float>(x1 + (Bid ? -1f : 1f)*(float)(xDiff*0.5), yt - (float)(xDiff*0.5)),
                        new Tuple<float, float>(x1 + (Bid ? -1f : 1f)*(float)(xDiff), yt),
                        new Tuple<float, float>(x1 + (Bid ? -1f : 1f)*(float)(xDiff* 0.5), yt + (float)(xDiff*0.5))
                    }, ZoneStroke, 30, true, true, chart);
                //DrawSharpDX.Box(RenderTarget, x1 + xDiff / 4, yt, xDiff/2, yb - yt, ZoneStroke, 30, true, true, SharpDXUtils.GetChartWidthNHeight(ChartControl, ChartScale));
            }

            public object Clone()
            {
                return new Zone() { Contracts = Contracts, Bid = Bid, Detection = Detection, Price = Price, TextBrush = TextBrush, Time = Time, BarNumber = BarNumber, ZoneStroke = ZoneStroke };
            }
        }
        #endregion

        #region Threshold Settings
        private class ThresholdSettings
        {
            //this class will store the 4 types of traders and their thresholds and calculate them
            //public double AbsorptionThresholdMultiplier { get; set; }
            public double BlockThresholdMultiplier { get; set; }
            public Stroke AbsorptionColor { get; set; }
            public Stroke BidBlockColor { get; set; }
            public Stroke AskBlockColor { get; set; }

            public eTapeDetection CheckThresholds(double Contracts, double CheckAgainst, eTapeDetection CheckWhat)
            {
                if (CheckWhat == eTapeDetection.Block && Contracts > CheckAgainst)
                    return eTapeDetection.Block;
                //if (CheckWhat == eTapeDetection.Absorption && Contracts > AbsorptionThresholdMultiplier * CheckAgainst)
                //    return eTapeDetection.Absorption;
                return eTapeDetection.None;
            }

            public Tuple<string, Stroke> ReturnDetectionText(bool IsBid, eTapeDetection Detection, double Contracts)
            {
                switch (Detection)
                {
                    case eTapeDetection.Absorption: return new Tuple<string, Stroke>("ABS\r\n " + Contracts, AbsorptionColor);
                    case eTapeDetection.Block: return new Tuple<string, Stroke>("BLK\r\n " + Contracts, IsBid ? BidBlockColor:AskBlockColor);
                    default: return new Tuple<string, Stroke>("", null);
                }
            }
            public Stroke ReturnDetectionColor(bool IsBid, eTapeDetection Detection)
            {
                switch (Detection)
                {
                    case eTapeDetection.Absorption: return AbsorptionColor;
                    case eTapeDetection.Block: return IsBid ? BidBlockColor : AskBlockColor;
                    default: return null;
                }
            }
        }
        #endregion

        #region Acceleration Color Settings
        private class AccelerationColorSettings : ICloneable
        {
            private Brush _brTimeBrush1 = Brushes.DarkBlue;
            private Brush _brTimeBrush2 = Brushes.DodgerBlue;
            private Brush _brTimeBrush3 = Brushes.Blue;
            private Brush _brTimeBrush4 = Brushes.Aqua;
            private Brush _brTimeBrush5 = Brushes.Cyan;

            public Brush TimeBrush1 { set { _brTimeBrush1 = value; } }
            public Brush TimeBrush2 { set { _brTimeBrush2 = value; } }
            public Brush TimeBrush3 { set { _brTimeBrush3 = value; } }
            public Brush TimeBrush4 { set { _brTimeBrush4 = value; } }
            public Brush TimeBrush5 { set { _brTimeBrush5 = value; } }

            public Stroke GetStroked(int ValueFromNewSecond)
            {
                switch (ValueFromNewSecond)
                {
                    case 0: return new Stroke(Brushes.Transparent);
                    case 1: return new Stroke(_brTimeBrush1);
                    case 2: return new Stroke(_brTimeBrush2);
                    case 3: return new Stroke(_brTimeBrush3);
                    case 4: return new Stroke(_brTimeBrush4);
                    default: return new Stroke(_brTimeBrush5);
                }
            }

            public object Clone()
            {
                return new AccelerationColorSettings() { TimeBrush1 = _brTimeBrush1, TimeBrush2 = _brTimeBrush2, TimeBrush3 = _brTimeBrush3, TimeBrush4 = _brTimeBrush4, TimeBrush5 = _brTimeBrush5 };
            }
        }
        #endregion

        #region FullBar
        private class FullBar
        {
            public DateTime barTime { get; set; }
            public int barNo { get; set; }
            public Dictionary<double, Price> prices { get; set; }
            public double LastValueAsk { get; set; }
            public int LastPricesAsk { get; set; }
            public double LastValueBid { get; set; }
            public int LastPricesBid { get; set; }
            public double TotalAsk { get { return _dTotalAsk; } }
            public double TotalBid { get { return _dTotalBid; } }

            private long totalBid = 0;
            private long totalAsk = 0;
            private long _lMostVolume = 0;
            //Floating Variables
            private double lastUpdatedPrice = 0;
            private double _dOpen = 0;
            private double _dClose = 0;
            private double _dHigh = 0;
            private double _dLow = 0;
            private double _dTotalAsk = 0;
            private double _dTotalBid = 0;
            private double _dMostVolumePrice = 0;
            private bool _bHasAbsoptionZones = false;

            public long ProcessOnMarketData(MarketDataEventArgs data, bool setVol, int MinVolumeBlock)
            {
                //building the bar
                if (_dOpen == 0)
                    _dOpen = data.Price;
                _dClose = data.Price;
                if (_dLow == 0 || data.Price < _dLow)
                    _dLow = data.Price;
                if (_dHigh == 0 || data.Price > _dHigh)
                    _dHigh = data.Price;

                //adding to the bid and ask
                if (data.Price >= data.Ask || data.Price <= data.Bid)
                {
                    if (data.Price >= data.Ask)
                        totalAsk += data.Volume;
                    else
                        totalBid += data.Volume;

                    if (lastUpdatedPrice == 0)
                        lastUpdatedPrice = data.Price;

                    if (!prices.ContainsKey(data.Price))
                    {
                        Price price = new Price() { price = data.Price, Broken = false, BrokenTimeAsk = DateTime.MaxValue, BrokenTimeBid = DateTime.MaxValue };
                        prices.Add(data.Price, price);
                    }
                    long result = prices[data.Price].addVolume(setVol ? data.Volume : 0, data.Price >= data.Ask, data.Time, MinVolumeBlock);
                    lastUpdatedPrice = data.Price;
                    return result;
                }
                return 0;
            }

            public void CalculateAverageBidAsk()
            {
                foreach(Price price in prices.Values)
                {
                    _dTotalAsk += price.full.ask;
                    _dTotalBid += price.full.bid;
                    if (price.full.askItalic || price.full.bidItalic)
                        _bHasAbsoptionZones = true;
                }
            }

            public void Draw(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, DateTime Time, Stroke StrokeBid, Stroke StrokeAsk, bool pShowBuyAbsorptionZones, bool pShowSellAbsorptionZones)
            {
                if (!_bHasAbsoptionZones || renderTarget == null)
                    return;
                List<double> _lstPriceList = prices.Keys.ToList();
                _lstPriceList.Sort();
                double firstPriceAsk = 0;
                double lastPriceAsk = 0;
                DateTime lastEndTimeAsk = DateTime.MaxValue;
                double firstPriceBid = 0;
                double lastPriceBid = 0;
                DateTime lastEndTimeBid = DateTime.MaxValue;
                for (int i = 0; i < _lstPriceList.Count; i++)
                {
                    Price price = prices[_lstPriceList[i]];
					if(pShowBuyAbsorptionZones){
	                    if (price.full.askItalic)
	                    {
	                        if (firstPriceAsk == 0)
	                        {
	                            firstPriceAsk = price.price;
	                            lastEndTimeAsk = price.BrokenTimeAsk;
	                        }
	                        if (lastEndTimeAsk.CompareTo(price.BrokenTimeAsk) != 0)
	                        {
	                            bool _bStillLive = lastEndTimeAsk.CompareTo(DateTime.MaxValue) == 0;
	                            DrawSharpDX.Box(renderTarget, chartControl, chartScale, StrokeAsk, barTime, firstPriceAsk, _bStillLive ? Time : lastEndTimeAsk,
	                                lastPriceAsk, 30, true, true);
	                            firstPriceAsk = price.price;
	                            lastEndTimeAsk = price.BrokenTimeAsk;
	                        }
	                        lastPriceAsk = price.price;
	                    }
	                    else
	                    {
	                        if (firstPriceAsk != 0 && lastPriceAsk != 0)
	                        {
	                            bool _bStillLive = lastEndTimeAsk.CompareTo(DateTime.MaxValue) == 0;
	                            DrawSharpDX.Box(renderTarget, chartControl, chartScale, StrokeAsk, barTime, firstPriceAsk, _bStillLive ? Time : lastEndTimeAsk,
	                                lastPriceAsk, 30, true, true);
	                        }
	                        firstPriceAsk = 0;
	                        lastPriceAsk = 0;
	                        lastEndTimeAsk = DateTime.MaxValue;
	                    }
					}
					if(pShowSellAbsorptionZones){
	                    if (price.full.bidItalic)
	                    {
	                        if (firstPriceBid == 0)
	                        {
	                            firstPriceBid = price.price;
	                            lastEndTimeBid = price.BrokenTimeBid;
	                        }
	                        if (lastEndTimeBid.CompareTo(price.BrokenTimeBid) != 0)
	                        {
	                            bool _bStillLive = lastEndTimeBid.CompareTo(DateTime.MaxValue) == 0;
	                            DrawSharpDX.Box(renderTarget, chartControl, chartScale, StrokeBid, barTime, firstPriceBid, _bStillLive ? Time : lastEndTimeBid,
	                                lastPriceBid, 30, true, true);
	                            firstPriceBid = price.price;
	                            lastEndTimeBid = price.BrokenTimeBid;
	                        }
	                        lastPriceBid = price.price;
	                    }
	                    else
	                    {
	                        if (firstPriceBid != 0 && lastPriceBid != 0)
	                        {
	                            bool _bStillLive = lastEndTimeBid.CompareTo(DateTime.MaxValue) == 0;
	                            DrawSharpDX.Box(renderTarget, chartControl, chartScale, StrokeBid, barTime, firstPriceBid, _bStillLive ? Time : lastEndTimeBid,
	                                lastPriceBid, 30, true, true);
	                        }
	                        firstPriceBid = 0;
	                        lastPriceBid = 0;
	                        lastEndTimeBid = DateTime.MaxValue;
	                    }
					}
                }
            }
            public void UpdateBars(double Close, DateTime Time, bool Extend)
            {
                if (!_bHasAbsoptionZones)
                    return;
                foreach (Price price in prices.Values)
                {
                    if (price.full.askItalic)
                    {
                        bool _bStillLive = price.BrokenTimeAsk.CompareTo(DateTime.MaxValue) == 0;
                        if (_bStillLive && (Close < price.price || (!Extend && barTime.CompareTo(Time) != 0)))
                            price.BrokenTimeAsk = Time;
                    }
                    if (price.full.bidItalic)
                    {
                        bool _bStillLive = price.BrokenTimeBid.CompareTo(DateTime.MaxValue) == 0;
                        if (_bStillLive && (Close > price.price || (!Extend && barTime.CompareTo(Time) != 0)))
                            price.BrokenTimeBid = Time;
                    }
                }
            }

            public override string ToString()
            {
                return barTime.ToString();
            }
        }
        #endregion

        #region Price
        private class Price : ICloneable // tine minte pretul si vol full si partial aferent la fiecare pret
        {
            public double price { get; set; }
            public Contracts full { get; set; }
            public bool askImbalance { get; set; }
            public bool bidImbalance { get; set; }
            public bool Broken { get; set; }
            public DateTime BrokenTimeAsk { get; set; }
            public DateTime BrokenTimeBid { get; set; }

            public long diference
            {
                get
                {
                    return full.diference;
                }
            }
            public long volume
            {
                get
                {
                    return full.volume;
                }
            }

            public long addVolume(long vol, bool ask, DateTime tickTime, int MinVolumeBlock)
            {
                if (full == null)
                    full = new Contracts() { ask = 0, bid = 0, fullStroke = new Stroke(Brushes.White, 2), leftStroke = null, rightStroke = null };
                full.ask += ask ? vol : 0;
                full.bid += !ask ? vol : 0;
                full.fullStroke = null;
                if (full.ask > MinVolumeBlock)
                {
                    if (ask)
                    {
                        full.askItalic = true;
                        return full.ask;
                    }
                }
                else if (full.bid > MinVolumeBlock)
                {
                    {
                        full.bidItalic = true;
                        return -full.bid;
                    }
                }
                return 0;
            }

            public Stroke GetStroked(double Open, double Close, Stroke BodyStroke, bool GetRight)
            {
                Stroke stroke = GetRight ? full.rightStroke : full.leftStroke;

                return stroke != null ? stroke : (full.fullStroke != null ? full.fullStroke : (price >= Math.Min(Open, Close) && price <= Math.Max(Open, Close) ? BodyStroke : null));
            }

            public object Clone()
            {
                return new Price()
                {
                    price = price,
                    full = full.Clone() as Contracts,
                    askImbalance = askImbalance,
                    bidImbalance = bidImbalance
                };
            }
        }
        #endregion

        #region Contracts
        private class Contracts : ICloneable
        {
            public long bid { get; set; }
            public long ask { get; set; }
            public bool bidItalic { get; set; }
            public bool askItalic { get; set; }
            public Stroke leftStroke { get; set; }
            public Stroke rightStroke { get; set; }
            public Stroke fullStroke { get; set; }
            public long diference
            {
                get
                {
                    return ask - bid;
                }
            }
            public long volume
            {
                get
                {
                    return ask + bid;
                }
            }
            public double ratio
            {
                get
                {
                    return bid == 0 || ask == 0 ? 0 : Math.Round(ask > bid ? (double)ask / bid : -bid / (double)ask, 2);
                }
            }

            public object Clone()
            {
                return new Contracts() { ask = ask, bid = bid, leftStroke = leftStroke, rightStroke = rightStroke, fullStroke = fullStroke, askItalic = askItalic, bidItalic = bidItalic };
            }
        }
        #endregion

        #endregion

        #region Static

        #region Draw Sharp DX
        private static class DrawSharpDX
        {
            #region Line
            public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, float X1, float Y1, float X2, float Y2, Stroke Stroke, Tuple<float, float> ChartWidthNHeight)
            {
                if (RenderTarget == null || Stroke == null || Stroke.Brush == Brushes.Transparent || (X1 == X2 && Y1 == Y2) || !SharpDXUtils.IsLineInChart(X1, Y1, X2, Y2, ChartWidthNHeight))
                    return;

                DrawLine(RenderTarget, new SharpDX.Vector2(X1, Y1), new SharpDX.Vector2(X2, Y2), Stroke);
            }

            public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime time1, double price1, DateTime time2, double price2, Stroke stroke)
            {
                if (RenderTarget == null || chartControl == null || chartScale == null || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsLineInChart(time1, price1, time2, price2, chartControl, chartScale))
                    return;

                float x1 = chartControl.GetXByTime(time1); float y1 = chartScale.GetYByValue(price1);
                float x2 = chartControl.GetXByTime(time2); float y2 = chartScale.GetYByValue(price2);

                DrawLine(RenderTarget, new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), stroke);
            }

            private static void DrawLine(SharpDX.Direct2D1.RenderTarget RenderTarget, SharpDX.Vector2 vector1, SharpDX.Vector2 vector2, Stroke stroke)
            {
                SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                RenderTarget.DrawLine(vector1, vector2, brs, stroke.Width, stroke.StrokeStyle);
                brs.Dispose();
            }
            #endregion

            #region Geometry
            public static void GeometryWithFill(SharpDX.Direct2D1.RenderTarget RenderTarget, List<Tuple<float, float>> Points, Stroke stroke, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.AreAnyPointsInChart(Points, chartWidthNHeight))
                    return;

                List<SharpDX.Vector2> points = new List<SharpDX.Vector2>();
                foreach (Tuple<float, float> point in Points)
                    points.Add(new SharpDX.Vector2(point.Item1, point.Item2));

                DrawGeometry(RenderTarget, points, stroke, opacity, outline, background);
            }

            public static void GeometryWithFill(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, List<Tuple<DateTime, double>> Points, Stroke stroke, int opacity, bool outline, bool background)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.AreAnyPointsInChart(Points, chartControl, chartScale))
                    return;

                List<SharpDX.Vector2> points = new List<SharpDX.Vector2>();
                foreach (Tuple<DateTime, double> point in Points)
                    points.Add(new SharpDX.Vector2(chartControl.GetXByTime(point.Item1), chartScale.GetYByValue(point.Item2)));

                DrawGeometry(RenderTarget, points, stroke, opacity, outline, background);
            }

            private static void DrawGeometry(SharpDX.Direct2D1.RenderTarget RenderTarget, List<SharpDX.Vector2> Points, Stroke stroke, int opacity, bool outline, bool background)
            {
                SharpDX.Direct2D1.PathGeometry pathGeometry = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
                SharpDX.Direct2D1.GeometrySink geometrySink = pathGeometry.Open();

                for (int i = 0; i < Points.Count; i++)
                {
                    if (i == 0)
                        geometrySink.BeginFigure(Points[i], SharpDX.Direct2D1.FigureBegin.Filled);
                    else
                        geometrySink.AddLine(Points[i]);
                }
                geometrySink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
                geometrySink.Close();
                SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                if (outline)
                    RenderTarget.DrawGeometry(pathGeometry, brs, stroke.Width);
                if (background)
                {
                    brs.Opacity = opacity / 100f;
                    RenderTarget.FillGeometry(pathGeometry, brs);
                }
                pathGeometry.Dispose(); brs.Dispose(); geometrySink.Dispose();
            }
            #endregion

            #region Box Text
            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, DateTime time, double price, Stroke stroke, int opacity,
                Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Size size = SharpDXUtils.MeasureString(text, TextFont);
                Tuple<float, float> chartWidthNHeight = SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale);
                float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);

                Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, backgroundBrush);
                Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, paragraphAlignment, textAlignemnt);
            }

            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, float x, float y, Stroke stroke, int opacity,
                Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Size size = SharpDXUtils.MeasureString(text, TextFont);
                Tuple<float, float> chartWidthNHeight = SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale);
                Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, backgroundBrush);
                Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, paragraphAlignment, textAlignemnt);
            }

            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Stroke stroke, int opacity, Brush textBrush, SimpleFont TextFont,
                bool outline, bool background, Tuple<float, float> chartWidthNHeight, Brush backgroundBrush = null,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Box(RenderTarget, x, y, width, height, stroke, opacity, outline, background, chartWidthNHeight, backgroundBrush);
                Text(RenderTarget, text, x, y, width, height, textBrush, TextFont, chartWidthNHeight, paragraphAlignment, textAlignemnt);
            }
            #endregion

            #region Box
            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, DateTime topLeftTime, double topLeftPrice, DateTime bottomRightTime, double bottomRightPrice,
                int opacity, bool outline, bool background, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
                    return;

                float x1 = chartControl.GetXByTime(topLeftTime); float y1 = chartScale.GetYByValue(topLeftPrice);
                float x2 = chartControl.GetXByTime(bottomRightTime); float y2 = chartScale.GetYByValue(bottomRightPrice);
                float width = x2 - x1; float height = y2 - y1;

                if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, Tuple<DateTime, double> topLeftPoint, Tuple<DateTime, double> bootomRightPoint,
                int opacity, bool outline, bool background, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
                    return;

                float x1 = chartControl.GetXByTime(topLeftPoint.Item1); float y1 = chartScale.GetYByValue(topLeftPoint.Item2);
                float x2 = chartControl.GetXByTime(bootomRightPoint.Item1); float y2 = chartScale.GetYByValue(bootomRightPoint.Item2);
                float width = x2 - x1; float height = y2 - y1;

                if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, Tuple<float, float> topLeftPoint, Tuple<float, float> bootomRightPoint, int opacity,
                bool outline, bool background, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent ||
                    !SharpDXUtils.IsRectangleInChart(topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawBox(RenderTarget, topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, Stroke stroke, Tuple<float, float> topLeftPoint, Tuple<float, float> bootomRightPoint, int opacity, bool outline, bool background,
                Tuple<float, float> chartWidthNHeight, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent ||
                    !SharpDXUtils.IsRectangleInChart(topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, chartWidthNHeight))
                    return;

                DrawBox(RenderTarget, topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
                    opacity, outline, background);
            }

            public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight, Brush backgroundBrush = null)
            {
                if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsRectangleInChart(x, y, width, height, chartWidthNHeight))
                    return;

                DrawBox(RenderTarget, x, y, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush, opacity, outline, background);
            }

            private static void DrawBox(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, Brush backgroundBrush, int opacity, bool outline, bool background)
            {
                SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
                if (outline)
                {
                    SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                    RenderTarget.DrawRectangle(rect, brs, stroke.Width, stroke.StrokeStyle);
                    brs.Dispose();
                }
                if (background)
                {
                    SharpDX.Direct2D1.Brush brs = backgroundBrush.ToDxBrush(RenderTarget);
                    brs.Opacity = (float)(opacity * 0.01f);
                    RenderTarget.FillRectangle(rect, brs);
                    brs.Dispose();
                }
            }
            #endregion

            #region Text
            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, DateTime time, double price, Brush textBrush, SimpleFont TextFont,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                if (RenderTarget == null || chartControl == null || chartScale == null || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
                    return;

                float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);
                Size size = SharpDXUtils.MeasureString(text, TextFont);

                if (size.Width == 0 || size.Height == 0 || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawText(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, paragraphAlignment, textAlignemnt);
            }

            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, Brush textBrush, SimpleFont TextFont, Tuple<float, float> chartWidthNHeight,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                if (RenderTarget == null || string.IsNullOrEmpty(text) || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
                    return;
                Size size = SharpDXUtils.MeasureString(text, TextFont);
                if (size.Width == 0 || size.Height == 0 || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, chartWidthNHeight))
                    return;
                DrawText(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, paragraphAlignment, textAlignemnt);
            }

            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Brush textBrush, SimpleFont TextFont, Tuple<float, float> chartWidthNHeight,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                if (RenderTarget == null || string.IsNullOrEmpty(text) || width == 0 || height == 0 || textBrush == null || textBrush == Brushes.Transparent || TextFont == null ||
                    !SharpDXUtils.IsRectangleInChart(x, y, width, height, chartWidthNHeight))
                    return;
                DrawText(RenderTarget, text, x, y, width, height, textBrush, TextFont, paragraphAlignment, textAlignemnt);
            }

            private static void DrawText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Brush textBrush, SimpleFont TextFont,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment, SharpDX.DirectWrite.TextAlignment textAlignemnt)
            {
                SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
                SimpleFont fs = new SimpleFont(TextFont.Family.ToString(), TextFont.Size) { Bold = TextFont.Bold, Italic = TextFont.Italic };
                SharpDX.DirectWrite.TextFormat tff = fs.ToDirectWriteTextFormat();
                tff.ParagraphAlignment = paragraphAlignment;
                tff.TextAlignment = textAlignemnt;
                SharpDX.Direct2D1.Brush brs = textBrush.ToDxBrush(RenderTarget);
                RenderTarget.DrawText(text, tff, rect, brs, SharpDX.Direct2D1.DrawTextOptions.Clip, SharpDX.Direct2D1.MeasuringMode.Natural);
                tff.Dispose();
                brs.Dispose();
            }
            #endregion
        }
        #endregion

        #region Sharp DX Utils
        public static class SharpDXUtils
        {
            #region Get Chart Width and Height
            public static Tuple<float, float> GetChartWidthNHeight(ChartControl chartControl, ChartScale chartScale)
            {
                return new Tuple<float, float>(chartControl.GetXByTime(chartControl.LastTimePainted), chartScale.GetYByValue(chartScale.MinValue));
            }
            #endregion

            #region Measure String
            public static Size MeasureString(string msg, SimpleFont TextFont)
            {
                if (TextFont == null || string.IsNullOrEmpty(msg))
                    return new Size(0, 0);

                SimpleFont fs = new SimpleFont(TextFont.Family.ToString(), TextFont.Size) { Bold = TextFont.Bold, Italic = TextFont.Italic };
                using (SharpDX.DirectWrite.TextFormat tff = fs.ToDirectWriteTextFormat())
                using (SharpDX.DirectWrite.TextLayout layout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, tff, 999999, tff.FontSize))
                    return new Size(layout.Metrics.Width, layout.Metrics.Height);
            }
            #endregion

            #region Are Any Points iIn Chart
            public static bool AreAnyPointsInChart(List<Tuple<float, float>> points, Tuple<float, float> chartWidthNHeight)
            {
                foreach (Tuple<float, float> point in points)
                    if (IsPointInChart(point.Item1, point.Item2, chartWidthNHeight))
                        return true;
                return false;
            }

            public static bool AreAnyPointsInChart(List<Tuple<DateTime, double>> points, ChartControl chartControl, ChartScale chartScale)
            {
                foreach (Tuple<DateTime, double> point in points)
                    if (IsPointInChart(point.Item1, point.Item2, chartControl, chartScale))
                        return true;
                return false;
            }
            #endregion

            #region Is Line In Chart
            public static bool IsLineInChart(float x1, float y1, float x2, float y2, Tuple<float, float> chartWidthNHeight)
            {
                return IsPointInChart(x1, y1, chartWidthNHeight) || IsPointInChart(x2, y2, chartWidthNHeight);
            }

            public static bool IsLineInChart(DateTime x1, double y1, DateTime x2, double y2, ChartControl chartControl, ChartScale chartScale)
            {
                return IsPointInChart(x1, y1, chartControl, chartScale) || IsPointInChart(x2, y2, chartControl, chartScale);
            }
            #endregion

            #region Is Point In Chart
            public static bool IsPointInChart(float x, float y, Tuple<float, float> chartWidthNHeight)
            {
                return x >= -1 && x <= chartWidthNHeight.Item1 + 1 && y >= -1 && y <= chartWidthNHeight.Item2 + 1;
            }
            public static bool IsPointInChart(SharpDX.Vector2 point, Tuple<float, float> chartWidthNHeight)
            {
                return point.X >= -1 && point.X <= chartWidthNHeight.Item1 + 1 && point.Y >= -1 && point.Y <= chartWidthNHeight.Item2 + 1;
            }

            public static bool IsPointInChart(DateTime x, double y, ChartControl chartControl, ChartScale chartScale)
            {
                return x.CompareTo(chartControl.FirstTimePainted) >= 0 && x.CompareTo(chartControl.LastTimePainted) <= 0 && y >= chartScale.MinValue && y <= chartScale.MaxValue;
            }
            #endregion

            #region Is Rectangle In Chart
            public static bool IsRectangleInChart(SharpDX.RectangleF rectangle, Tuple<float, float> chartWidthNHeight)
            {
                return IsPointInChart(rectangle.X, rectangle.Y, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y, chartWidthNHeight) ||
                    IsPointInChart(rectangle.X, rectangle.Y + rectangle.Height, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height, chartWidthNHeight);
            }

            public static bool IsRectangleInChart(float x, float y, float width, float height, Tuple<float, float> chartWidthNHeight)
            {
                SharpDX.RectangleF rectangle = new SharpDX.RectangleF(x, y, width, height);
                return IsPointInChart(rectangle.TopLeft, chartWidthNHeight) || IsPointInChart(rectangle.TopRight, chartWidthNHeight) ||
                    IsPointInChart(rectangle.BottomLeft, chartWidthNHeight) || IsPointInChart(rectangle.BottomRight, chartWidthNHeight) ||
                    (x <= chartWidthNHeight.Item1 && x + width >= chartWidthNHeight.Item1) || (y <= chartWidthNHeight.Item2 && y + height >= chartWidthNHeight.Item2);
            }

            public static bool IsRectangleInChart(List<Tuple<DateTime, double>> points, ChartControl chartControl, ChartScale chartScale)
            {
                return AreAnyPointsInChart(points, chartControl, chartScale);
            }

            public static bool IsRectangleInChart(List<Tuple<float, float>> points, Tuple<float, float> chartWidthNHeight)
            {
                return AreAnyPointsInChart(points, chartWidthNHeight);
            }
            #endregion
        }
        #endregion

        #endregion

        #endregion

        #region Enums

        #region Tape Detection
        private enum eTapeDetection
        {
            None = 0,
            Absorption = 1,
            Block = 2,
        }
        #endregion

        #endregion

        #region Default NT Functions

        #region On Market Data
        protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
        {
            if (marketDataUpdate.MarketDataType != MarketDataType.Last || CurrentBar <= 0)
                return;

            if (!bars.ContainsKey(CurrentBar))
            {
                double _dLastValueBid = 0;
                double _dLastValueAsk = 0;
                int _iLastPricesBid = 0;
                int _iLastPricesAsk = 0;
                int b = CurrentBar - 1;
                if (bars.ContainsKey(b))
                {
                    bars[b].CalculateAverageBidAsk();
                    _iLastPricesBid = bars[b].LastPricesBid;
                    _iLastPricesAsk = bars[b].LastPricesAsk;
                    _dLastValueBid = bars[b].LastValueBid * _iLastPricesBid + bars[b].TotalBid;
                    _dLastValueAsk = bars[b].LastValueAsk * _iLastPricesAsk + bars[b].TotalAsk;
                    _iLastPricesBid += bars[b].prices.Count;
                    _iLastPricesAsk += bars[b].prices.Count;
                    if (bars.ContainsKey(CurrentBar - MaxBarsBack))
                    {
                        _dLastValueBid -= bars[CurrentBar - MaxBarsBack].TotalBid;
                        _dLastValueAsk -= bars[CurrentBar - MaxBarsBack].TotalAsk;
                        _iLastPricesAsk -= bars[CurrentBar - MaxBarsBack].prices.Count;
                        _iLastPricesBid -= bars[CurrentBar - MaxBarsBack].prices.Count;
                    }
                    _dLastValueBid = _dLastValueBid / (_iLastPricesBid != 0 ? _iLastPricesBid : 1);
                    _dLastValueAsk = _dLastValueAsk / (_iLastPricesAsk != 0 ? _iLastPricesAsk : 1);
                }
                FullBar bar = new FullBar()
                {
                    barTime = Time[0],
                    barNo = CurrentBar,
                    prices = new Dictionary<double, Price>(),
                    LastValueAsk = _dLastValueAsk,
                    LastValueBid = _dLastValueBid,
                    LastPricesAsk = _iLastPricesAsk,
                    LastPricesBid = _iLastPricesBid
                };
                bars.Add(CurrentBar, bar);
            }
            Tuple<string, Stroke> text = new Tuple<string, Stroke>("", null);
            eTapeDetection detection = eTapeDetection.None;
            if (bars.ContainsKey(CurrentBar))
            {
                long result = bars[CurrentBar].ProcessOnMarketData(marketDataUpdate, true, AbsorptionContractsMinimum);
                if (result != 0)
                {
                    text = new Tuple<string, Stroke>("ABS\r\n" + Math.Abs(result), result < 0 ? AbsorptionStrokeBid : AbsorptionStrokeAsk);
                    detection = eTapeDetection.Absorption;
                }
            }

            TickItem tick = _TickManager.AddTick(marketDataUpdate, CurrentBar, BlockContracts);

            if(text.Item2 == null)
                text = _ZoneManager.ProcessTick(tick, CurrentBar);

            if(detection != eTapeDetection.None)
                _TickManager.AddDetectionType(detection);
            DrawLineProperties lineProp = _TickManager.GetTickProperties(marketDataUpdate, text, UpColor, DnColor, _AccelerationSettings);

            //Adding to the proper tape and ballancing them out
            if (_bTapePaused)
                _lTapePaused.Add(lineProp);
            else 
            {
                if(_lTapePaused.Count > 0)
                {
                    foreach (DrawLineProperties dp in _lTapePaused)
                        _lTapeLive.Add(dp);
                    _lTapePaused.Clear();
                }
                _lTapeLive.Add(lineProp);
            }

            if (Count - 1 == CurrentBar && bars.ContainsKey(CurrentBar))
                UpdateButtonText(Math.Ceiling(bars[CurrentBar].LastValueBid), Math.Ceiling(bars[CurrentBar].LastValueAsk), Math.Ceiling(_TickManager.ContractsTopPercent));

            if (_bTapePaused)
                CCInvokeAction(() =>
                {
                    ChartControl.InvalidateVisual();
                });
        }
        #endregion

        #region On Render
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
#if DoLicense
			if (!ValidLicense) return;
#endif
            //base.OnRender(chartControl, chartScale);
            if(ShowZones)
                _ZoneManager.DrawZones(RenderTarget, chartControl, chartScale, ShowBlockZones, ChartBars);
            if (ShowZones && (pShowBuyAbsorptionZones || pShowSellAbsorptionZones) && bars.Count > 0)
            {
                DateTime _dtCurrentTime = Bars.GetTime(CurrentBar);
                for (int i = Math.Min(CurrentBar, chartControl.LastSlotPainted); i >= 0/*Math.Max(1, chartControl.LastSlotPainted - chartControl.SlotsPainted)*/; i--)
                {
                    if(bars.ContainsKey(i))
                        bars[i].Draw(RenderTarget, chartControl, chartScale, _dtCurrentTime, AbsorptionStrokeBid, AbsorptionStrokeAsk, pShowBuyAbsorptionZones, pShowSellAbsorptionZones);
                }
            }
            if(pShowTape) DrawTicks(SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale));
        }
        #endregion

        #endregion

        #region Functions

        #region Draw Ticks
        public void DrawTicks(Tuple<float, float> ChartWdthNHeight)
        {
            if (_lTapeLive.Count > 0)
            {
                int valueFromNewSecond = 0;
                int size = _lTapeLive.Count - 1;
                if (ShowTapeBackground)
                {
                    float Width = _lTapeLive[size].CalculateBoxWidth(TextFont);
                    DrawSharpDX.Box(RenderTarget, TapeBackgroundStroke, new Tuple<float, float>(-1, -1), new Tuple<float, float>(Width, ChartWdthNHeight.Item2 + 2), 100, true, true, ChartWdthNHeight);
                }
                for (int i = size; i >= 0; i--)
                {
                    if (i == size || _lTapeLive[i + 1].Time.Second != _lTapeLive[i].Time.Second)
                        valueFromNewSecond = 0;
                    else
                        valueFromNewSecond++;
                    _lTapeLive[i].ValueFromNewSecond = valueFromNewSecond;
                    if (!_lTapeLive[i].DrawRow(this.RenderTarget, ChartWdthNHeight.Item2, ChartWdthNHeight.Item1, size - i, TextFont))
                        _lTapeLive.RemoveAt(i);
                }
            }
        }
        #endregion

        #region Invoke Action
        private void CCInvokeAction(Action p)
        {
            if (ChartControl.Dispatcher.CheckAccess())
            {
                p();
            }
            else
            {
                ChartControl.Dispatcher.InvokeAsync(p);
            }
        }
        #endregion

        #region Invoke Action
        private void GeneralInvokeAction(Action p)
        {
            if (Dispatcher.CheckAccess())
            {
                p();
            }
            else
            {
                ChartControl.Dispatcher.InvokeAsync(p);
            }
        }
        #endregion

        #endregion

        #region Override Display Name
        //public override string DisplayName { get { return _sThisName; } }
        #endregion

        #endregion

        #region Properties

        #region Zone Settings
        
        [Display(Name = "Show Zones", Description = "Master Zones Settins", Order = 10, GroupName = "Zone Settings")]
        public bool ShowZones { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Bars Back", Description = "The number of bars back for zone calculations", Order = 80, GroupName = "Zone Settings")]
        public int MaxBarsBack { get; set; }

        #region Absorption Zone Settings
        
        [Display(Name = "Show Buy Absorption Zones", Description = "Absorption Zones", Order = 10, GroupName = "Absorption Zone Settings")]
        public bool pShowBuyAbsorptionZones { get; set; }

		[Display(Name = "Show Sell Absorption Zones", Description = "Absorption Zones", Order = 15, GroupName = "Absorption Zone Settings")]
        public bool pShowSellAbsorptionZones { get; set; }
        
        [Display(Name = "Extend Absorption Zones", Description = "Absorption Zones", Order = 20, GroupName = "Absorption Zone Settings")]
        public bool ExtendAbsorptionZones { get; set; }

        [Range(0, int.MaxValue)]
        [Display(Name = "Absorption Minimum Contracts", Description = "Absorption Minimum Contracts", Order = 30, GroupName = "Absorption Zone Settings")]
        public int AbsorptionContractsMinimum { get; set; }

        //[Range(0.0001, double.MaxValue)]
        //[Display(Name = "Absorption Multiplier", Description = "Absorption Zones Multiplier", Order = 40, GroupName = "Absorption Zone Settings")]
        //public double AbsorptionThreshold { get; set; }
        
        [Display(Name = "Absorption Zone Bid Winner", Description = "Absorption Zone Bid Winner", Order = 42, GroupName = "Absorption Zone Settings")]
        public Stroke AbsorptionStrokeBid { get; set; }

        
        [Display(Name = "Absorption Zone Ask Winner", Description = "Absorption Zone Ask Winner", Order = 45, GroupName = "Absorption Zone Settings")]
        public Stroke AbsorptionStrokeAsk { get; set; }
        #endregion

        #region Block Zone Settings
        
        [Display(Name = "Show Block Zones", Description = "Block Zones", Order = 50, GroupName = "Block Zone Settings")]
        public bool ShowBlockZones { get; set; }

        [Range(0.0001, double.MaxValue)]
        [Display(Name = "Block Percentile (Percent)", Description = "", Order = 60, GroupName = "Block Zone Settings")]
        public double BlockThreshold { get; set; }

        [Display(Name = "Bid Block color", Description = "Choose the color of blocks at the Bid price", Order = 80, GroupName = "Block Zone Settings")]
        public Stroke BlockAtBidStroke { get; set; }

		[Display(Name = "Ask Block color", Description = "Choose the color of blocks at the Ask price", Order = 90, GroupName = "Block Zone Settings")]
        public Stroke BlockAtAskStroke { get; set; }

		[Range(1, int.MaxValue)]
        [Display(Name = "Block Minimum Contracts", Description = "", Order = 100, GroupName = "Block Zone Settings")]
        public int BlockContracts { get; set; }
        #endregion

        #endregion

        #region Tape Display
        
        [Display(Name = "Show Tape", Description = "Show or hide the tape printout", Order = 0, GroupName = "Tape Display")]
		public bool pShowTape {get;set;}

		[Display(Name = "Show Tape Background", Description = "Show a background Box over the tape to be able to see the text more clearly", Order = 1, GroupName = "Tape Display")]
        public bool ShowTapeBackground { get; set; }

        
        [Display(Name = "Tape Background Color", Description = "Tape Background Color", Order = 5, GroupName = "Tape Display")]
        public Stroke TapeBackgroundStroke { get; set; }

        
        [Display(Name = "Text Font", Description = "Choose your font style for the propting text displayed in the tape", Order = 10, GroupName = "Tape Display")]
        public SimpleFont TextFont { get; set; }

        [XmlIgnore]
        [Display(Name = "Text Color", Description = "Choose the color with which to paint the text", Order = 20, GroupName = "Tape Display")]
        public Brush TextBrush { get; set; }
			        [Browsable(false)]
			        public string _TextBrush { get { return Serialize.BrushToString(TextBrush); } set { TextBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Up Tick Color", Description = "Choose the color with which to paint the up tick", Order = 30, GroupName = "Tape Display")]
        public Brush UpColor { get; set; }
			        [Browsable(false)]
			        public string _UpColor { get { return Serialize.BrushToString(UpColor); } set { UpColor = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Down Tick Color", Description = "Choose the color with which to paint the down tick", Order = 40, GroupName = "Tape Display")]
        public Brush DnColor { get; set; }
			        [Browsable(false)]
			        public string _DnColor { get { return Serialize.BrushToString(DnColor); } set { DnColor = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Acceleration 1st Step Color", Description = "Choose the color with which to paint the leg of the time acceleration", Order = 50, GroupName = "Tape Display")]
        public Brush AcellerationStep1 { get; set; }
			        [Browsable(false)]
			        public string _AcellerationStep1 { get { return Serialize.BrushToString(AcellerationStep1); } set { AcellerationStep1 = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Acceleration 2nd Step Color", Description = "Choose the color with which to paint the leg of the time acceleration", Order = 60, GroupName = "Tape Display")]
        public Brush AcellerationStep2 { get; set; }
			        [Browsable(false)]
			        public string _AcellerationStep2 { get { return Serialize.BrushToString(AcellerationStep2); } set { AcellerationStep2 = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Acceleration 3rd Step Color", Description = "Choose the color with which to paint the leg of the time acceleration", Order = 70, GroupName = "Tape Display")]
        public Brush AcellerationStep3 { get; set; }
			        [Browsable(false)]
			        public string _AcellerationStep3 { get { return Serialize.BrushToString(AcellerationStep3); } set { AcellerationStep3 = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Acceleration 4th Step Color", Description = "Choose the color with which to paint the leg of the time acceleration", Order = 80, GroupName = "Tape Display")]
        public Brush AcellerationStep4 { get; set; }
			        [Browsable(false)]
			        public string _AcellerationStep4 { get { return Serialize.BrushToString(AcellerationStep4); } set { AcellerationStep4 = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Acceleration 5th Step Color", Description = "Choose the color with which to paint the leg of the time acceleration", Order = 90, GroupName = "Tape Display")]
        public Brush AcellerationStep5 { get; set; }
			        [Browsable(false)]
			        public string _AcellerationStep5 { get { return Serialize.BrushToString(AcellerationStep5); } set { AcellerationStep5 = Serialize.StringToBrush(value); } }
        #endregion

        #region General Display
        
        [Display(Name = "Button Text", Description = "", Order = 10, GroupName = "General Display")]
        public string ButtonText { get; set; }

        //[Range(1, int.MaxValue)]
        //[Display(Name = "Max Draw Zones", Description = "", Order = 20, GroupName = "General Display")]
        //public int MaxDrawZones { get; set; }
        #endregion

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_MMTT[] cacheARC_MMTT;
		public ARC.ARC_MMTT ARC_MMTT()
		{
			return ARC_MMTT(Input);
		}

		public ARC.ARC_MMTT ARC_MMTT(ISeries<double> input)
		{
			if (cacheARC_MMTT != null)
				for (int idx = 0; idx < cacheARC_MMTT.Length; idx++)
					if (cacheARC_MMTT[idx] != null &&  cacheARC_MMTT[idx].EqualsInput(input))
						return cacheARC_MMTT[idx];
			return CacheIndicator<ARC.ARC_MMTT>(new ARC.ARC_MMTT(), input, ref cacheARC_MMTT);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_MMTT ARC_MMTT()
		{
			return indicator.ARC_MMTT(Input);
		}

		public Indicators.ARC.ARC_MMTT ARC_MMTT(ISeries<double> input )
		{
			return indicator.ARC_MMTT(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_MMTT ARC_MMTT()
		{
			return indicator.ARC_MMTT(Input);
		}

		public Indicators.ARC.ARC_MMTT ARC_MMTT(ISeries<double> input )
		{
			return indicator.ARC_MMTT(input);
		}
	}
}

#endregion
