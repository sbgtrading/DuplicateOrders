#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System.Collections.Generic;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	internal class ARC_VABOAlgo_PeriodicVolumeProfileTracker<TParent> where TParent : NinjaScriptBase, ARC_VABOAlgo_ISupportsPeriodicVolumeProfile
	{
		public int ZoneStartPrimaryBar => _profileStartBars.FirstOrDefault();

		private int[] _profileStartBars = new [] { 0, 0 };
		private readonly Dictionary<double, double> _volPerPrice = new Dictionary<double, double>();
		private readonly TParent _parent;
		private readonly Action _drawVerticalLine;
		private readonly int _minuteBip;
		private readonly int _tickBip;
		public ARC_VABOAlgo_PeriodicVolumeProfileTracker(TParent parent, int minuteBip, int tickBip, Action drawVerticalLine)
		{
			_parent = parent;
			_drawVerticalLine = drawVerticalLine;
			_minuteBip = minuteBip;
			_tickBip = tickBip;
		}

		private void ResyncVolumeZone()
		{
			if (_volPerPrice.Count == 0)
				return;

			var totalVolume = _volPerPrice.Sum(kvp => kvp.Value);

			var volKvpsInOrder = _volPerPrice
				.ToArray()
				.OrderByDescending(kvp => kvp.Key)
				.ToArray();
			
			// Get the POC
			var pocIdx = volKvpsInOrder
				.Select((kvp, i) => (kvp, i))
				.OrderByDescending(t => t.Item1.Value)
				.Select(t => t.Item2)
				.First();

			var cumulativeVolume = volKvpsInOrder[pocIdx].Value;
			var highIdx = pocIdx;
			var lowIdx = pocIdx;
			var side = -1;
			while (cumulativeVolume < totalVolume * _parent.ValueAreaPercent / 100)
			{
				var extendedSide = highIdx - pocIdx <= pocIdx - lowIdx ? 1 : -1;
				if (extendedSide == -1 ? lowIdx == 0 : highIdx == volKvpsInOrder.Length - 1)
					extendedSide *= -1;

				if (extendedSide == 1)
				{
					highIdx++;
					cumulativeVolume += volKvpsInOrder[highIdx].Value;
				}
				else
				{
					lowIdx--;
					cumulativeVolume += volKvpsInOrder[lowIdx].Value;
				}
			}

			for (var i = 0; i <= (_parent.FreezeVAPlots ? 0 : _parent.CurrentBars[0] - _profileStartBars[0]); i++)
			{
				_parent.VAH[0] = volKvpsInOrder[lowIdx].Key;
				_parent.POC[0] = volKvpsInOrder[pocIdx].Key;
				_parent.VAL[0] = volKvpsInOrder[highIdx].Key;
			}
		}

		private int GetMinuteBarIdx(DateTime time, int barSizeMinutes)
		{
			return (int) Math.Floor(time.TimeOfDay.TotalMinutes / barSizeMinutes);
		}

		public void OnBarUpdate()
		{
			if (_parent.CurrentBars.Any(cb => cb <= 0))
				return;

			if (_parent.BarsInProgress == _minuteBip && _parent.Time[0].Minute % _parent.RecalculationFrequencyMinutes == 0)
			{
				ResyncVolumeZone();
				return;
			}

			if (_parent.BarsInProgress != _tickBip)
				return;

			if (GetMinuteBarIdx(_parent.Time[0], _parent.MinutesPerVolumeProfile) == GetMinuteBarIdx(_parent.Time[1], _parent.MinutesPerVolumeProfile))
			{
				if (!_volPerPrice.ContainsKey(_parent.Close[0]))
					_volPerPrice[_parent.Close[0]] = 0;
				_volPerPrice[_parent.Close[0]] += _parent.Volume[0];
				return;
			}
			
			_drawVerticalLine();
			ResyncVolumeZone();
			_volPerPrice.Clear();
			_profileStartBars = _parent.CurrentBars.ToArray();
			foreach (var series in new [] { _parent.VAL, _parent.POC, _parent.VAH })
				series[0] = _parent.Close[0];
		}
	}

	public interface ARC_VABOAlgo_ISupportsPeriodicVolumeProfile
	{
		public Series<double> VAH { get; }
		public Series<double> POC { get; }
		public Series<double> VAL { get; }
		public int MinutesPerVolumeProfile { get; set; }
		public int RecalculationFrequencyMinutes { get; set; }
		public int ValueAreaPercent { get; set; }
		public bool FreezeVAPlots { get; set; }
	}

	[Browsable(true)]
	public class ARC_VABOAlgo_ARC_PeriodicVolumeProfile : ARC_VABOAlgo_ARCIndicatorBase, ARC_VABOAlgo_ISupportsPeriodicVolumeProfile
	{
		public override string ProductVersion => "v1.0.1 (5/3/2024)";
		public override bool ColicensedOnly => true;

		[Browsable(false), XmlIgnore]
		public Series<double> VAH
		{
			get
			{
				Update();
				return Values[0];
			}
		}

		[Browsable(false), XmlIgnore]
		public Series<double> POC
		{
			get
			{
				Update();
				return Values[1];
			}
		}

		[Browsable(false), XmlIgnore]
		public Series<double> VAL
		{
			get
			{
				Update();
				return Values[2];
			}
		}

		[Browsable(false), XmlIgnore]
		public int ZoneStartPrimaryBar
		{
			get
			{
				Update();
				return profileTracker.ZoneStartPrimaryBar;
			}
		}

		private ARC_VABOAlgo_PeriodicVolumeProfileTracker<ARC_VABOAlgo_ARC_PeriodicVolumeProfile> profileTracker;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && !this.ARC_VABOAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				Name = "Periodic Volume Profile";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				IsSuspendedWhileInactive = false;

				MinutesPerVolumeProfile = 30;
				RecalculationFrequencyMinutes = 1;
				ValueAreaPercent = 70;
				FreezeVAPlots = false;
			}
			else if (State == State.Configure)
			{
				AddPlot(ValueAreaHighStroke, PlotStyle.Hash, "VAH");
				AddPlot(PointOfControlStroke, PlotStyle.Hash, "POC");
				AddPlot(ValueAreaLowStroke, PlotStyle.Hash, "VAL");

				profileTracker = new ARC_VABOAlgo_PeriodicVolumeProfileTracker<ARC_VABOAlgo_ARC_PeriodicVolumeProfile>(this, this.ARC_VABOAlgo_EnsureDataSeriesAdded(AddDataSeries, BarsPeriodType.Minute, 1), this.ARC_VABOAlgo_EnsureDataSeriesAdded(AddDataSeries, BarsPeriodType.Tick, 1), () => DrawingTools.Draw.VerticalLine(this, $"Tag{Guid.NewGuid()}", 0, SessionBreakStroke.Brush, SessionBreakStroke.DashStyleHelper, (int) SessionBreakStroke.Width));
			}
		}

		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_VABOAlgo_IsLicensed())
				return;

			profileTracker.OnBarUpdate();
		}

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Minutes Per Volume Profile", GroupName = "Parameters", Order = 0)]
		public int MinutesPerVolumeProfile { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Recalculation Frequency (Minutes)", GroupName = "Parameters", Order = 1)]
		public int RecalculationFrequencyMinutes { get; set; }
		
		[NinjaScriptProperty, Range(0, 100)]
		[Display(Name = "Value Area (%)", GroupName = "Parameters", Order = 2)]
		public int ValueAreaPercent { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Freeze VA Plots", GroupName = "Parameters", Order = 3)]
		public bool FreezeVAPlots { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Volume Profile Break", GroupName = "Visuals", Order = 0)]
		public Stroke SessionBreakStroke { get; set; } = new Stroke(Brushes.Yellow, DashStyleHelper.Solid, 2);

		[NinjaScriptProperty]
		[Display(Name = "VAH Stroke", GroupName = "Visuals", Order = 1)]
		public Stroke ValueAreaHighStroke { get; set; } = new Stroke(Brushes.Red, DashStyleHelper.Solid, 2);
		
		[NinjaScriptProperty]
		[Display(Name = "POC Stroke", GroupName = "Visuals", Order = 2)]
		public Stroke PointOfControlStroke { get; set; } = new Stroke(Brushes.Yellow, DashStyleHelper.Solid, 2);

		[NinjaScriptProperty]
		[Display(Name = "VAL Stroke", GroupName = "Visuals", Order = 3)]
		public Stroke ValueAreaLowStroke { get; set; } = new Stroke(Brushes.Blue, DashStyleHelper.Solid, 2);
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_VABOAlgo_ARC_PeriodicVolumeProfile[] cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile;
		public ARC.ARC_VABOAlgo_ARC_PeriodicVolumeProfile ARC_VABOAlgo_ARC_PeriodicVolumeProfile(int minutesPerVolumeProfile, int recalculationFrequencyMinutes, int valueAreaPercent, bool freezeVAPlots, Stroke sessionBreakStroke, Stroke valueAreaHighStroke, Stroke pointOfControlStroke, Stroke valueAreaLowStroke)
		{
			return ARC_VABOAlgo_ARC_PeriodicVolumeProfile(Input, minutesPerVolumeProfile, recalculationFrequencyMinutes, valueAreaPercent, freezeVAPlots, sessionBreakStroke, valueAreaHighStroke, pointOfControlStroke, valueAreaLowStroke);
		}

		public ARC.ARC_VABOAlgo_ARC_PeriodicVolumeProfile ARC_VABOAlgo_ARC_PeriodicVolumeProfile(ISeries<double> input, int minutesPerVolumeProfile, int recalculationFrequencyMinutes, int valueAreaPercent, bool freezeVAPlots, Stroke sessionBreakStroke, Stroke valueAreaHighStroke, Stroke pointOfControlStroke, Stroke valueAreaLowStroke)
		{
			if (cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile != null)
				for (int idx = 0; idx < cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile.Length; idx++)
					if (cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx] != null && cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx].MinutesPerVolumeProfile == minutesPerVolumeProfile && cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx].RecalculationFrequencyMinutes == recalculationFrequencyMinutes && cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx].ValueAreaPercent == valueAreaPercent && cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx].FreezeVAPlots == freezeVAPlots && cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx].SessionBreakStroke == sessionBreakStroke && cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx].ValueAreaHighStroke == valueAreaHighStroke && cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx].PointOfControlStroke == pointOfControlStroke && cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx].ValueAreaLowStroke == valueAreaLowStroke && cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx].EqualsInput(input))
						return cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile[idx];
			return CacheIndicator<ARC.ARC_VABOAlgo_ARC_PeriodicVolumeProfile>(new ARC.ARC_VABOAlgo_ARC_PeriodicVolumeProfile(){ MinutesPerVolumeProfile = minutesPerVolumeProfile, RecalculationFrequencyMinutes = recalculationFrequencyMinutes, ValueAreaPercent = valueAreaPercent, FreezeVAPlots = freezeVAPlots, SessionBreakStroke = sessionBreakStroke, ValueAreaHighStroke = valueAreaHighStroke, PointOfControlStroke = pointOfControlStroke, ValueAreaLowStroke = valueAreaLowStroke }, input, ref cacheARC_VABOAlgo_ARC_PeriodicVolumeProfile);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_VABOAlgo_ARC_PeriodicVolumeProfile ARC_VABOAlgo_ARC_PeriodicVolumeProfile(int minutesPerVolumeProfile, int recalculationFrequencyMinutes, int valueAreaPercent, bool freezeVAPlots, Stroke sessionBreakStroke, Stroke valueAreaHighStroke, Stroke pointOfControlStroke, Stroke valueAreaLowStroke)
		{
			return indicator.ARC_VABOAlgo_ARC_PeriodicVolumeProfile(Input, minutesPerVolumeProfile, recalculationFrequencyMinutes, valueAreaPercent, freezeVAPlots, sessionBreakStroke, valueAreaHighStroke, pointOfControlStroke, valueAreaLowStroke);
		}

		public Indicators.ARC.ARC_VABOAlgo_ARC_PeriodicVolumeProfile ARC_VABOAlgo_ARC_PeriodicVolumeProfile(ISeries<double> input , int minutesPerVolumeProfile, int recalculationFrequencyMinutes, int valueAreaPercent, bool freezeVAPlots, Stroke sessionBreakStroke, Stroke valueAreaHighStroke, Stroke pointOfControlStroke, Stroke valueAreaLowStroke)
		{
			return indicator.ARC_VABOAlgo_ARC_PeriodicVolumeProfile(input, minutesPerVolumeProfile, recalculationFrequencyMinutes, valueAreaPercent, freezeVAPlots, sessionBreakStroke, valueAreaHighStroke, pointOfControlStroke, valueAreaLowStroke);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_VABOAlgo_ARC_PeriodicVolumeProfile ARC_VABOAlgo_ARC_PeriodicVolumeProfile(int minutesPerVolumeProfile, int recalculationFrequencyMinutes, int valueAreaPercent, bool freezeVAPlots, Stroke sessionBreakStroke, Stroke valueAreaHighStroke, Stroke pointOfControlStroke, Stroke valueAreaLowStroke)
		{
			return indicator.ARC_VABOAlgo_ARC_PeriodicVolumeProfile(Input, minutesPerVolumeProfile, recalculationFrequencyMinutes, valueAreaPercent, freezeVAPlots, sessionBreakStroke, valueAreaHighStroke, pointOfControlStroke, valueAreaLowStroke);
		}

		public Indicators.ARC.ARC_VABOAlgo_ARC_PeriodicVolumeProfile ARC_VABOAlgo_ARC_PeriodicVolumeProfile(ISeries<double> input , int minutesPerVolumeProfile, int recalculationFrequencyMinutes, int valueAreaPercent, bool freezeVAPlots, Stroke sessionBreakStroke, Stroke valueAreaHighStroke, Stroke pointOfControlStroke, Stroke valueAreaLowStroke)
		{
			return indicator.ARC_VABOAlgo_ARC_PeriodicVolumeProfile(input, minutesPerVolumeProfile, recalculationFrequencyMinutes, valueAreaPercent, freezeVAPlots, sessionBreakStroke, valueAreaHighStroke, pointOfControlStroke, valueAreaLowStroke);
		}
	}
}

#endregion
