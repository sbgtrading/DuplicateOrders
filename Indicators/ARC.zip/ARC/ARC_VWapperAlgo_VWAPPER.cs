#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;

#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[Browsable(true)]
	[CategoryOrder("Parameters", 1)]
	[CategoryOrder("Zone1", 10)]
	[CategoryOrder("Zone2", 20)]
	[CategoryOrder("Zone3", 30)]
	[CategoryOrder("Indicator Version", 40)]
	public class ARC_VWapperAlgo_VWAPPER : ARC_VWapperAlgo_ARCIndicatorBase
	{
		public override string ProductVersion { get { return "v1.0 (3/1/2023)"; } }
		public override bool ColicensedOnly { get { return true; } }

		bool IsDebug = false;
		double iCumVolume = 0;
		double iCumTypicalVolume = 0;
		double iCumVolume1 = 0;
		double iCumTypicalVolume1 = 0;
		int StartABar = -1;
		int RegionStartABar = 0;
		private Series<int> Dir;
		private string tag = "";
		//		SMA sma             = null;
		//		ATR atr             = null;
		private int FirstDayOfNewSession = -1;
		double StepInPts = 0;
		double OneBandUnit = 0;

		bool Z1Printable = true;
		bool Z2Printable = true;
		bool Z3Printable = true;
		private Series<double> zoneID;
		private SortedDictionary<int, double> VWAPsAtNewSession = new SortedDictionary<int, double>();

		private SortedDictionary<DateTime, double[]> HistoricalVwap = new SortedDictionary<DateTime, double[]>();//[0] is vwap, [1] is x (deviation from vwap), [2] is CumVol, [3] is CumTypicalVol
		private bool NeedBackgroundData = true;
		#region -- loadHistoricalBars --
		private Bars loadHistoricalBars(ARC_VWapperAlgo_DayWeekMonth TF)
		{
			//---- Prepa Bars Request ----
			DateTime now = DateTime.Now;
			var dtfrom = now.AddDays(TF == ARC_VWapperAlgo_DayWeekMonth.Day ? -4 : (TF == ARC_VWapperAlgo_DayWeekMonth.Week ? -8 : -30));
			if (TF == ARC_VWapperAlgo_DayWeekMonth.Month) dtfrom = new DateTime(now.Year, now.Month, 1).AddDays(-3);
			if (dtfrom > BarsArray[0].GetTime(0))
			{
				NeedBackgroundData = false;
				return null;
			}
			BarsRequest barsRequest = new BarsRequest(Bars.Instrument, dtfrom, now) { TradingHours = Bars.TradingHours, IsSplitAdjusted = false/*Bars.IsSplitAdjusted*/, IsDividendAdjusted = Bars.IsDividendAdjusted };
			int val = 5;
			if (BarsArray[0].BarsPeriod.BarsPeriodType == BarsPeriodType.Minute) val = BarsArray[0].BarsPeriod.Value;

			if (TF == ARC_VWapperAlgo_DayWeekMonth.Day)
			{
				barsRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, MarketDataType = Bars.BarsPeriod.MarketDataType, Value = val };
			}
			else if (TF == ARC_VWapperAlgo_DayWeekMonth.Week)
			{
				barsRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, MarketDataType = Bars.BarsPeriod.MarketDataType, Value = val };
			}
			else if (TF == ARC_VWapperAlgo_DayWeekMonth.Month)
			{
				barsRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, MarketDataType = Bars.BarsPeriod.MarketDataType, Value = val };
			}

			//---- Request the bars ----
			bool doWait = true;
			Bars retour = null;
			barsRequest.Request(new Action<BarsRequest, ErrorCode, string>((bars, errorCode, errorMessage) =>
			{
				if (errorCode != ErrorCode.NoError) { retour = null; doWait = false; return; }
				else if (bars.Bars == null || bars.Bars.Count == 0) { doWait = false; return; }
				retour = bars.Bars;
				doWait = false;
				return;
			}));
			while (doWait) { System.Threading.Thread.Sleep(10); }//made synchrone cause need request to finish before continuing
			return retour;
		}
		#endregion
		private bool SevereError = false;
		private Bars extraBars = null;
		private Series<double> RawVWAP;

		protected override void OnStateChange()
		{
			base.OnStateChange();
			#region -- OnStateChange --
			if (State == State.SetDefaults)
			{
				Calculate = Calculate.OnPriceChange;
				IsOverlay = true;
				DisplayInDataBox = true;
				DrawOnPricePanel = true;
				DrawHorizontalGridLines = true;
				DrawVerticalGridLines = true;
				PaintPriceMarkers = true;
				IsAutoScale = false;
				ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive = true;
				pUseNTSessionTime = true;
				pCustomSessionStartTime = 1800;
				pBandPeriod = 30;
				pBandMult1 = 1.0;
				pBandMult2 = 2.0;
				pBandMult3 = 3.0;
				Zone1Color = Brushes.Green;
				Zone2Color = Brushes.Red;
				Zone3Color = Brushes.Blue;
				pStepSize = 4;
				pVisualSessionBreak = true;
				Zone1OpacityBkg = 10;
				Zone2OpacityBkg = 10;
				Zone3OpacityBkg = 10;
				pDayWeekMonth = ARC_VWapperAlgo_DayWeekMonth.Day;

				AddPlot(Brushes.Cyan, "PlotVWAP");
				AddPlot(Brushes.Maroon, "Upper");
				AddPlot(Brushes.DarkGreen, "Lower");
				AddPlot(Brushes.Yellow, "Upper2");
				AddPlot(Brushes.Yellow, "Lower2");
				AddPlot(Brushes.Blue, "Upper3");
				AddPlot(Brushes.Blue, "Lower3");
			}
			else if (State == State.Configure)
			{
				zoneID = new Series<double>(this);
				RawVWAP = new Series<double>(this);
				Dir = new Series<int>(this);
				if (Calculate == Calculate.OnEachTick) Calculate = Calculate.OnPriceChange;
			}
			else if (State == State.DataLoaded)
			{
				StepInPts = pStepSize * TickSize;
				if (IsDebug) ClearOutputWindow();
				Z1Printable = Zone1OpacityBkg > 0 && Zone1Color.ToString() != Brushes.Transparent.ToString();
				Z2Printable = Zone2OpacityBkg > 0 && Zone2Color.ToString() != Brushes.Transparent.ToString();
				Z3Printable = Zone3OpacityBkg > 0 && Zone3Color.ToString() != Brushes.Transparent.ToString();
				var errorData = "Loading of background data is incomplete.\nAre you connected to your datafeed?  Try reloading historical data.";
				extraBars = loadHistoricalBars(this.pDayWeekMonth);//preload bars - sync code
				if (NeedBackgroundData && (extraBars == null || extraBars.Count <= 1))//if no historical data
				{
					Draw.TextFixed(this, "errortag", errorData, TextPosition.Center, Brushes.Red, new NinjaTrader.Gui.Tools.SimpleFont("Arial", 14), Brushes.White, Brushes.White, 100);
					SevereError = true;
				}
				else if (extraBars != null && extraBars.Count > 0)
				{
					int start_abar = 0;
					int sT = pCustomSessionStartTime * 100;
					for (int abar = 1; abar < extraBars.Count - 1; abar++)
					{
						var dt0 = extraBars.GetTime(abar);
						var dt1 = extraBars.GetTime(abar - 1);

						var t0 = ToTime(dt0);
						var t1 = ToTime(dt1);
						//						if(t1 > t0) t1 = t1-240000;
						bool NewSession = false;
						if (pDayWeekMonth == ARC_VWapperAlgo_DayWeekMonth.Week)
						{
							if (dt0.DayOfWeek < dt1.DayOfWeek || dt0.DayOfWeek == DayOfWeek.Sunday)
							{
								NewSession = true;
							}
						}
						else if (pDayWeekMonth == ARC_VWapperAlgo_DayWeekMonth.Month)
						{
							if (dt0.Month != dt1.Month)
							{
								NewSession = true;
							}
						}
						else if (dt0.Day != FirstDayOfNewSession)
						{//daily
							if (pUseNTSessionTime)
							{
								if (extraBars.IsFirstBarOfSession) NewSession = true;
							}
							else
							{
								if (t1 < t0)
								{//normally, the prior bar is of lower ToTime value than the current bar...except for when t0 is at or after midnight
									if (t1 <= sT && t0 > sT)
									{
										//	Print("1  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
										FirstDayOfNewSession = dt0.Day;
										NewSession = true;
									}
									else if (t0 < t1 && t0 < sT)
									{
										//	Print("2  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
										FirstDayOfNewSession = dt0.Day;
										NewSession = true;
									}
								}
								else if (t1 != t0)
								{//example, if the prior bar is 2359 and the current bar is 0000.  If the two bars have a different time (sometimes Range bars have the same timestamp...these can be skipped
									if (sT > t1)
									{
										//	Print("3  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
										FirstDayOfNewSession = dt0.Day;
										NewSession = true;
									}
								}
							}
						}

						if (NewSession)
						{
							start_abar = abar;
							iCumVolume = extraBars.GetVolume(abar);
							iCumTypicalVolume = extraBars.GetVolume(abar) * ((extraBars.GetHigh(abar) + extraBars.GetLow(abar) + extraBars.GetClose(abar)) / 3);
						}
						else
						{
							iCumVolume = iCumVolume + extraBars.GetVolume(abar);
							iCumTypicalVolume = iCumTypicalVolume + (extraBars.GetVolume(abar) * ((extraBars.GetHigh(abar) + extraBars.GetLow(abar) + extraBars.GetClose(abar)) / 3));
						}
						double vw = (iCumTypicalVolume / iCumVolume);
						if (!HistoricalVwap.ContainsKey(dt0)) HistoricalVwap[dt0] = new double[4] { 0, 0, 0, 0 };
						HistoricalVwap[dt0][0] = vw;
						HistoricalVwap[dt0][2] = iCumVolume;
						HistoricalVwap[dt0][3] = iCumTypicalVolume;
						double diff = 0;
						double sumSq = 0;
						for (int i = abar; i > start_abar; i--)
						{
							var tx = extraBars.GetTime(i);
							if (HistoricalVwap.ContainsKey(tx)) vw = HistoricalVwap[tx][0];
							diff = extraBars.GetClose(i) - vw;
							sumSq = sumSq + diff * diff;
						}
						HistoricalVwap[dt0][1] = Math.Sqrt(sumSq / Math.Max(1, abar - start_abar));
					}
				}
			}
			#endregion
		}
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (!this.ARC_VWapperAlgo_IsLicensed())
				return;

			int priorABar = 0;
			float x0 = 0;
			float x1 = 0;
			float y0 = 0;
			float y1 = 0;
			foreach (var kvp in VWAPsAtNewSession)
			{
				if (kvp.Key < ChartBars.FromIndex || kvp.Key > ChartBars.ToIndex) continue;
				x0 = chartControl.GetXByBarIndex(ChartBars, kvp.Key - 1);
				x1 = chartControl.GetXByBarIndex(ChartBars, kvp.Key);
				y1 = chartScale.GetYByValue(kvp.Value);
				if (kvp.Key - 1 == priorABar) //therefore kvp.Key is the first bar of the new session
					y0 = y1;
				else//then kvp.Key is the last bar of the prior session, connect the VWAP line from the bar prior to it
					y0 = chartScale.GetYByValue(PlotVWAP.GetValueAt(kvp.Key - 1));
				if (Plots[0].PlotStyle == PlotStyle.Line)
				{
					RenderTarget.DrawLine(new SharpDX.Vector2(x0, y0), new SharpDX.Vector2(x1, y1), Plots[0].BrushDX, Plots[0].Width, Plots[0].StrokeStyle);
				}
				else if (Plots[0].PlotStyle == PlotStyle.Hash)
				{
					float w = Convert.ToSingle(chartControl.BarWidth);
					RenderTarget.DrawLine(new SharpDX.Vector2(x1 - w, y1), new SharpDX.Vector2(x1 + w, y1), Plots[0].BrushDX, Plots[0].Width, Plots[0].StrokeStyle);
				}
				else if (Plots[0].PlotStyle == PlotStyle.Cross)
				{
					float w = (x1 - x0) / 2f;
					RenderTarget.DrawLine(new SharpDX.Vector2(x1 - w, y1), new SharpDX.Vector2(x1 + w, y1), Plots[0].BrushDX, Plots[0].Width);
					RenderTarget.DrawLine(new SharpDX.Vector2(x1, y1 - w), new SharpDX.Vector2(x1, y1 + w), Plots[0].BrushDX, Plots[0].Width);
				}
				else if (Plots[0].PlotStyle == PlotStyle.Square)
					RenderTarget.DrawLine(new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x0, y1), Plots[0].BrushDX, Plots[0].Width);
				else// if(Plots[0].PlotStyle == PlotStyle.Dot)
					RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x1, y1), Plots[0].Width, Plots[0].Width), Plots[0].BrushDX);
				priorABar = kvp.Key;
			}
			base.OnRender(chartControl, chartScale);
		}
		//==============================================================================================================================
		protected override void OnBarUpdate()
		{
			base.OnBarUpdate();
			if (!this.ARC_VWapperAlgo_IsLicensed())
				return;

			if (SevereError) return;
			if (CurrentBars[0] < 3) return;
			var dt0 = Times[0][0];
			var dt1 = Times[0][1];
			var t0 = ToTime(dt0);
			var t1 = ToTime(dt1);
			//			if(t1 > t0) t1 = t1-240000;
			bool NewSession = false;
			if (pDayWeekMonth == ARC_VWapperAlgo_DayWeekMonth.Week)
			{
				if (dt0.DayOfWeek < dt1.DayOfWeek || dt0.DayOfWeek == DayOfWeek.Sunday)
				{
					NewSession = true;
				}
			}
			else if (pDayWeekMonth == ARC_VWapperAlgo_DayWeekMonth.Month)
			{
				if (dt0.Month != dt1.Month)
				{
					NewSession = true;
				}
			}
			else if (dt0.Day != FirstDayOfNewSession)
			{//daily, and the two bars have a different time (sometimes Range bars have the same timestamp...these can be skipped
				int sT = pCustomSessionStartTime * 100;
				if (pUseNTSessionTime)
				{
					if (BarsArray[0].IsFirstBarOfSession) NewSession = true;
				}
				else
				{
					if (t1 < t0)
					{//normally, the prior bar is of lower ToTime value than the current bar...except for when t0 is at or after midnight
						if (t1 <= sT && t0 > sT)
						{
							//	Print("1  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
							FirstDayOfNewSession = dt0.Day;
							NewSession = true;
						}
						else if (t0 < t1 && t0 < sT)
						{
							//	Print("2  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
							FirstDayOfNewSession = dt0.Day;
							NewSession = true;
						}
					}
					else if (t1 != t0)
					{//example, if the prior bar is 2359 and the current bar is 0000.  If the two bars have a different time (sometimes Range bars have the same timestamp...these can be skipped
						if (sT > t1)
						{
							//	Print("3  New session: t1: "+t1+"   sT: "+sT+"   t0: "+t0);
							FirstDayOfNewSession = dt0.Day;
							NewSession = true;
						}
					}
				}
			}
			if (NewSession && IsFirstTickOfBar)
			{
				VWAPsAtNewSession[CurrentBars[0] - 1] = PlotVWAP[1];
				if (CurrentBars[0] > 0 && pVisualSessionBreak)
				{
					for (int i = 0; i < Values.Length; i++)
					{
						Values[i].Reset(1);//Sean requested that the lines do not slope to the reset point
					}
				}
				HistoricalVwap.Clear();//since the new session occurred on chart bars (not on backloaded bars), we can clear those historical vwap calculations and run with bar data from now on
				StartABar = CurrentBars[0];
				iCumVolume1 = 0;
				iCumTypicalVolume1 = 0;
			}
			else
			{
				if (IsFirstTickOfBar)
				{
					if (HistoricalVwap.Count > 0 && HistoricalVwap.ContainsKey(Times[0][0]))
					{//historical vwap data was calculated on backloaded bars...if it still exists, we calculate vwap on that HistoricalVwap data
						iCumVolume1 = HistoricalVwap[Times[0][0]][2];
						iCumTypicalVolume1 = HistoricalVwap[Times[0][0]][3];
					}
					else
					{
						iCumVolume1 = iCumVolume;
						iCumTypicalVolume1 = iCumTypicalVolume;
					}
				}
			}
			var inzone = Times[0][0].Day == 4 && Times[0][0].Month == 11 && Times[0][0].Hour >= 21;

			var keys = HistoricalVwap.Keys.Where(k => k <= Times[0][0]);//.ToList();
			if (keys != null && keys.Count() > 0)
			{
				PlotVWAP[0] = HistoricalVwap[keys.Max()][0];
				OneBandUnit = HistoricalVwap[keys.Max()][1];
				if (inzone) Print("1122  keys: " + keys.Count() + "  keys.Max(): " + keys.Max().ToString() + "  PlotVWAP[0]: " + PlotVWAP[0].ToString() + "  OneBandUnit: " + OneBandUnit);
			}
			else
			{
				iCumVolume = iCumVolume1 + Volumes[0][0];
				iCumTypicalVolume = iCumTypicalVolume1 + (Volumes[0][0] * ((Highs[0][0] + Lows[0][0] + Closes[0][0]) / 3));
				RawVWAP[0] = (iCumTypicalVolume / iCumVolume);
				if (RawVWAP[0] > PlotVWAP[1] + StepInPts) PlotVWAP[0] = RawVWAP[0];
				else if (RawVWAP[0] < PlotVWAP[1] - StepInPts) PlotVWAP[0] = RawVWAP[0];
				else PlotVWAP[0] = PlotVWAP[1];

				if (StartABar == -1)
					StartABar = CurrentBars[0];
				else if (StartABar == CurrentBars[0])
					VWAPsAtNewSession[StartABar] = PlotVWAP[0];

				if (inzone) Print(" 1136: " + Times[0][0].ToString() + "  StartABar: " + StartABar + "  PlotVWAP[0]: " + PlotVWAP[0].ToString());
				if (PlotVWAP[0] != PlotVWAP[1])
				{
					double diff = 0;
					//					if(OneBandUnit==double.MinValue)
					//					{
					double sumSq = 0;
					for (int i = CurrentBars[0]; i > StartABar; i--)
					{
						diff = Closes[0].GetValueAt(i) - RawVWAP.GetValueAt(i);
						sumSq = sumSq + diff * diff;
					}
					OneBandUnit = Math.Sqrt(sumSq / Math.Max(1, CurrentBars[0] - StartABar));
					if (inzone) Print(" 1147: " + Times[0][0].ToString() + "  NEW OneBandUnit: " + OneBandUnit.ToString());
					//					}
					PlotUpper[0] = PlotVWAP[0] + OneBandUnit * pBandMult1;
					PlotLower[0] = PlotVWAP[0] - OneBandUnit * pBandMult1;
					PlotUpper2[0] = PlotVWAP[0] + OneBandUnit * pBandMult2;
					PlotLower2[0] = PlotVWAP[0] - OneBandUnit * pBandMult2;
					PlotUpper3[0] = PlotVWAP[0] + OneBandUnit * pBandMult3;
					PlotLower3[0] = PlotVWAP[0] - OneBandUnit * pBandMult3;
				}
				else if (NewSession)
				{
					OneBandUnit = 0;
					PlotUpper[0] = PlotVWAP[0];
					PlotLower[0] = PlotVWAP[0];
					PlotUpper2[0] = PlotVWAP[0];
					PlotLower2[0] = PlotVWAP[0];
					PlotUpper3[0] = PlotVWAP[0];
					PlotLower3[0] = PlotVWAP[0];
				}
				else
				{
					PlotUpper[0] = PlotUpper[1];
					PlotLower[0] = PlotLower[1];
					PlotUpper2[0] = PlotUpper2[1];
					PlotLower2[0] = PlotLower2[1];
					PlotUpper3[0] = PlotUpper3[1];
					PlotLower3[0] = PlotLower3[1];
				}
			}
			if (Closes[0][0] > PlotUpper3[0]) zoneID[0] = 4;
			else if (Closes[0][0] > PlotUpper2[0]) zoneID[0] = 3;
			else if (Closes[0][0] > PlotUpper[0]) zoneID[0] = 2;
			else if (Closes[0][0] > PlotVWAP[0]) zoneID[0] = 1;
			else if (Closes[0][0] > PlotLower[0]) zoneID[0] = -1;
			else if (Closes[0][0] > PlotLower2[0]) zoneID[0] = -2;
			else if (Closes[0][0] > PlotLower3[0]) zoneID[0] = -3;
			else zoneID[0] = -4;

			if (pBandMult1 > 0 && Z1Printable)
			{
				Draw.Region(this, "1", CurrentBars[0], 0, PlotUpper, PlotVWAP, Brushes.Transparent, Zone1Color, Zone1OpacityBkg);
				Draw.Region(this, "2", CurrentBars[0], 0, PlotLower, PlotVWAP, Brushes.Transparent, Zone1Color, Zone1OpacityBkg);
			}
			if (pBandMult2 > 0 && Z2Printable)
			{
				Draw.Region(this, "3", CurrentBars[0], 0, PlotUpper2, PlotUpper, Brushes.Transparent, Zone2Color, Zone2OpacityBkg);
				Draw.Region(this, "4", CurrentBars[0], 0, PlotLower2, PlotLower, Brushes.Transparent, Zone2Color, Zone2OpacityBkg);
			}
			if (pBandMult3 > 0 && Z3Printable)
			{
				Draw.Region(this, "5", CurrentBars[0], 0, PlotUpper3, PlotUpper2, Brushes.Transparent, Zone3Color, Zone3OpacityBkg);
				Draw.Region(this, "6", CurrentBars[0], 0, PlotLower3, PlotLower2, Brushes.Transparent, Zone3Color, Zone3OpacityBkg);
			}
		}

		//==========================================================================================================================
		#region -- Properties -------------------------------------------------

		#region -- Zone settings --
		[XmlIgnore]
		[Display(Name = "Bkg color", GroupName = "Zone1", Description = "Background color for up-trending condition", Order = 10)]
		public Brush Zone1Color { get; set; }
		[Browsable(false)]
		public string Zone1ColorSerialize
		{
			get { return Serialize.BrushToString(Zone1Color); }
			set { Zone1Color = Serialize.StringToBrush(value); }
		}
		[Range(0, 100)]
		[Display(Name = "Opacity", GroupName = "Zone1", Description = "Opacity, 0=transparent, 100=opaque", Order = 20)]
		public int Zone1OpacityBkg { get; set; }

		[Range(0.0, double.MaxValue), NinjaScriptProperty]
		[Display(Name = "Deviation mult", GroupName = "Zone1", Order = 30)]
		public double pBandMult1
		{ get; set; }



		[XmlIgnore]
		[Display(Name = "Bkg color", GroupName = "Zone2", Description = "Background color", Order = 30)]
		public Brush Zone2Color { get; set; }
		[Browsable(false)]
		public string Zone2ColorSerialize
		{
			get { return Serialize.BrushToString(Zone2Color); }
			set { Zone2Color = Serialize.StringToBrush(value); }
		}
		[Range(0, 100)]
		[Display(Name = "Opacity", GroupName = "Zone2", Description = "Opacity, 0=transparent, 100=opaque", Order = 40)]
		public int Zone2OpacityBkg { get; set; }

		[Range(0.0, double.MaxValue), NinjaScriptProperty]
		[Display(Name = "Deviation mult", GroupName = "Zone2", Order = 50)]
		public double pBandMult2
		{ get; set; }


		[XmlIgnore]
		[Display(Name = "Bkg color", GroupName = "Zone3", Description = "Background color", Order = 60)]
		public Brush Zone3Color { get; set; }
		[Browsable(false)]
		public string Zone3ColorSerialize
		{
			get { return Serialize.BrushToString(Zone3Color); }
			set { Zone3Color = Serialize.StringToBrush(value); }
		}
		[Range(0, 100)]
		[Display(Name = "Opacity", GroupName = "Zone3", Description = "Opacity of the down-trend background color", Order = 70)]
		public int Zone3OpacityBkg { get; set; }

		[Range(0.0, double.MaxValue), NinjaScriptProperty]
		[Display(Name = "Deviation mult", GroupName = "Zone3", Order = 80)]
		public double pBandMult3
		{ get; set; }
		#endregion

		#region -- Parameters --
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Step Size", GroupName = "NinjaScriptParameters", Order = 0)]
		public int pStepSize { get; set; }
		[Display(Name = "Day/Week/Month", GroupName = "NinjaScriptParameters", Order = 5)]
		public ARC_VWapperAlgo_DayWeekMonth pDayWeekMonth { get; set; }

		[RefreshProperties(RefreshProperties.All)] // Needed to refresh the property grid when the value changes
		[Display(Name = "Use NT SessionStart", GroupName = "NinjaScriptParameters", Order = 10, Description = "If true, then use the NinjaTrader Session Start for this instrument.  If false, then use the 'Custom Session Start' parameter")]
		public bool pUseNTSessionTime { get; set; }

		[Range(1, 2359), NinjaScriptProperty]
		[Display(Name = "Custom Session Start", GroupName = "NinjaScriptParameters", Order = 20, Description = "If 'Use NT SessionStart' is true, this parameter is ignored")]
		public int pCustomSessionStartTime { get; set; }

		private bool pVisualSessionBreak = true;
		//		[Display(Name = "Visual Session Break", GroupName = "Session", Order = 30, Description="This changes the visual appearance of the lines at the session break")]
		//		public bool pVisualSessionBreak		{ get; set; }

		private int pBandPeriod = 20;
		//		[Range(1, int.MaxValue), NinjaScriptProperty]
		//		[Display(Name = "Band Period", GroupName = "NinjaScriptParameters", Order = 20)]
		//		public int pBandPeriod
		//		{ get; set; }

		#endregion

		#endregion ------------------------------------------------------------

		#region Plots
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotVWAP
		{
			get { return Values[0]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotUpper
		{
			get { return Values[1]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotLower
		{
			get { return Values[2]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotUpper2
		{
			get { return Values[3]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotLower2
		{
			get { return Values[4]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotUpper3
		{
			get { return Values[5]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotLower3
		{
			get { return Values[6]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ZoneID
		{
			get
			{
				Update();
				return zoneID;
			}
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_VWapperAlgo_VWAPPER[] cacheARC_VWapperAlgo_VWAPPER;
		public ARC.ARC_VWapperAlgo_VWAPPER ARC_VWapperAlgo_VWAPPER(double pBandMult1, double pBandMult2, double pBandMult3, int pStepSize, int pCustomSessionStartTime)
		{
			return ARC_VWapperAlgo_VWAPPER(Input, pBandMult1, pBandMult2, pBandMult3, pStepSize, pCustomSessionStartTime);
		}

		public ARC.ARC_VWapperAlgo_VWAPPER ARC_VWapperAlgo_VWAPPER(ISeries<double> input, double pBandMult1, double pBandMult2, double pBandMult3, int pStepSize, int pCustomSessionStartTime)
		{
			if (cacheARC_VWapperAlgo_VWAPPER != null)
				for (int idx = 0; idx < cacheARC_VWapperAlgo_VWAPPER.Length; idx++)
					if (cacheARC_VWapperAlgo_VWAPPER[idx] != null && cacheARC_VWapperAlgo_VWAPPER[idx].pBandMult1 == pBandMult1 && cacheARC_VWapperAlgo_VWAPPER[idx].pBandMult2 == pBandMult2 && cacheARC_VWapperAlgo_VWAPPER[idx].pBandMult3 == pBandMult3 && cacheARC_VWapperAlgo_VWAPPER[idx].pStepSize == pStepSize && cacheARC_VWapperAlgo_VWAPPER[idx].pCustomSessionStartTime == pCustomSessionStartTime && cacheARC_VWapperAlgo_VWAPPER[idx].EqualsInput(input))
						return cacheARC_VWapperAlgo_VWAPPER[idx];
			return CacheIndicator<ARC.ARC_VWapperAlgo_VWAPPER>(new ARC.ARC_VWapperAlgo_VWAPPER(){ pBandMult1 = pBandMult1, pBandMult2 = pBandMult2, pBandMult3 = pBandMult3, pStepSize = pStepSize, pCustomSessionStartTime = pCustomSessionStartTime }, input, ref cacheARC_VWapperAlgo_VWAPPER);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_VWapperAlgo_VWAPPER ARC_VWapperAlgo_VWAPPER(double pBandMult1, double pBandMult2, double pBandMult3, int pStepSize, int pCustomSessionStartTime)
		{
			return indicator.ARC_VWapperAlgo_VWAPPER(Input, pBandMult1, pBandMult2, pBandMult3, pStepSize, pCustomSessionStartTime);
		}

		public Indicators.ARC.ARC_VWapperAlgo_VWAPPER ARC_VWapperAlgo_VWAPPER(ISeries<double> input , double pBandMult1, double pBandMult2, double pBandMult3, int pStepSize, int pCustomSessionStartTime)
		{
			return indicator.ARC_VWapperAlgo_VWAPPER(input, pBandMult1, pBandMult2, pBandMult3, pStepSize, pCustomSessionStartTime);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_VWapperAlgo_VWAPPER ARC_VWapperAlgo_VWAPPER(double pBandMult1, double pBandMult2, double pBandMult3, int pStepSize, int pCustomSessionStartTime)
		{
			return indicator.ARC_VWapperAlgo_VWAPPER(Input, pBandMult1, pBandMult2, pBandMult3, pStepSize, pCustomSessionStartTime);
		}

		public Indicators.ARC.ARC_VWapperAlgo_VWAPPER ARC_VWapperAlgo_VWAPPER(ISeries<double> input , double pBandMult1, double pBandMult2, double pBandMult3, int pStepSize, int pCustomSessionStartTime)
		{
			return indicator.ARC_VWapperAlgo_VWAPPER(input, pBandMult1, pBandMult2, pBandMult3, pStepSize, pCustomSessionStartTime);
		}
	}
}

#endregion
