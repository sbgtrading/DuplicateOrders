#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public enum ARC_Trend_MTF_BkgDataTypes {NotUsed, Week, Day, Minutes240, Minutes60, Minutes30, Minutes15, Minutes5}
	public class ARC_Trend_MTF : Indicator
	{
		Brush upbrush, downbrush;
		List<int> TrendStatus = new List<int>();
		List<ARC_Trend_MTF_BkgDataTypes> BkgDatas = new List<ARC_Trend_MTF_BkgDataTypes>();
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"When bkg timeframe trend is congruent with chart candle trend";
				Name										= "ARC_Trend - 2 timeframes";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= false;
				pBkgData1 = ARC_Trend_MTF_BkgDataTypes.Day;
				pBkgData2 = ARC_Trend_MTF_BkgDataTypes.Minutes30;
				pBkgData3 = ARC_Trend_MTF_BkgDataTypes.NotUsed;
				pBkgData4 = ARC_Trend_MTF_BkgDataTypes.NotUsed;
				pBkgData5 = ARC_Trend_MTF_BkgDataTypes.NotUsed;
				pBkgData6 = ARC_Trend_MTF_BkgDataTypes.NotUsed;
				pBkgData7 = ARC_Trend_MTF_BkgDataTypes.NotUsed;
				pUpStripeOpacity = 30;
				pDownStripeOpacity = 30;
			}
			else if (State == State.Configure)
			{
				if(pBkgData1 != ARC_Trend_MTF_BkgDataTypes.NotUsed) {BkgDatas.Add(pBkgData1); TrendStatus.Add(0);}
				if(pBkgData2 != ARC_Trend_MTF_BkgDataTypes.NotUsed) {BkgDatas.Add(pBkgData2); TrendStatus.Add(0);}
				if(pBkgData3 != ARC_Trend_MTF_BkgDataTypes.NotUsed) {BkgDatas.Add(pBkgData3); TrendStatus.Add(0);}
				if(pBkgData4 != ARC_Trend_MTF_BkgDataTypes.NotUsed) {BkgDatas.Add(pBkgData4); TrendStatus.Add(0);}
				if(pBkgData5 != ARC_Trend_MTF_BkgDataTypes.NotUsed) {BkgDatas.Add(pBkgData5); TrendStatus.Add(0);}
				if(pBkgData6 != ARC_Trend_MTF_BkgDataTypes.NotUsed) {BkgDatas.Add(pBkgData6); TrendStatus.Add(0);}
				if(pBkgData7 != ARC_Trend_MTF_BkgDataTypes.NotUsed) {BkgDatas.Add(pBkgData7); TrendStatus.Add(0);}

				for(int i = 0; i< BkgDatas.Count; i++){
					if(BkgDatas[i] == ARC_Trend_MTF_BkgDataTypes.Week)
						AddDataSeries(Data.BarsPeriodType.Week, 1);
					else if(BkgDatas[i] == ARC_Trend_MTF_BkgDataTypes.Day)
						AddDataSeries(Data.BarsPeriodType.Day, 1);
					else if(BkgDatas[i] == ARC_Trend_MTF_BkgDataTypes.Minutes240)
						AddDataSeries(Data.BarsPeriodType.Minute, 240);
					else if(BkgDatas[i] == ARC_Trend_MTF_BkgDataTypes.Minutes60)
						AddDataSeries(Data.BarsPeriodType.Minute, 60);
					else if(BkgDatas[i] == ARC_Trend_MTF_BkgDataTypes.Minutes30)
						AddDataSeries(Data.BarsPeriodType.Minute, 30);
					else if(BkgDatas[i] == ARC_Trend_MTF_BkgDataTypes.Minutes15)
						AddDataSeries(Data.BarsPeriodType.Minute, 15);
					else if(BkgDatas[i] == ARC_Trend_MTF_BkgDataTypes.Minutes5)
						AddDataSeries(Data.BarsPeriodType.Minute, 5);
				}

				upbrush = pUpTrendBrush.Clone();
				upbrush.Opacity = pUpStripeOpacity/100.0;
				upbrush.Freeze();
				downbrush = pDownTrendBrush.Clone();
				downbrush.Opacity = pDownStripeOpacity/100.0;
				downbrush.Freeze();
			}
		}

		protected override void OnBarUpdate()
		{
			int BIP = BarsInProgress;
			if(CurrentBars[BIP]<2) return;

			if(BIP>0 && Closes[BIP][0] > Highs[BIP][1]){
				TrendStatus[BIP-1] = 1;
			}
			else if(BIP>0 && Closes[BIP][0] < Lows[BIP][1]){
				TrendStatus[BIP-1] = -1;
			}
			if(BIP==0){
				var countUp = TrendStatus.Count(k=>k==1);
				var countDown = TrendStatus.Count(k=>k==-1);
				if(countUp == TrendStatus.Count) BackBrushes[0] = upbrush;
				else if(countDown == TrendStatus.Count) BackBrushes[0] = downbrush;
				else BackBrushes[0] = null;
			}
		}

		#region Properties
		[Display(Order=10, Name="Bkg Data TF1", GroupName="Parameters", Description="")]
		public ARC_Trend_MTF_BkgDataTypes pBkgData1
		{get;set;}

		[Display(Order=11, Name="Bkg Data TF2", GroupName="Parameters", Description="")]
		public ARC_Trend_MTF_BkgDataTypes pBkgData2
		{get;set;}

		[Display(Order=12, Name="Bkg Data TF3", GroupName="Parameters", Description="")]
		public ARC_Trend_MTF_BkgDataTypes pBkgData3
		{get;set;}

		[Display(Order=13, Name="Bkg Data TF4", GroupName="Parameters", Description="")]
		public ARC_Trend_MTF_BkgDataTypes pBkgData4
		{get;set;}

		[Display(Order=14, Name="Bkg Data TF5", GroupName="Parameters", Description="")]
		public ARC_Trend_MTF_BkgDataTypes pBkgData5
		{get;set;}

		[Display(Order=15, Name="Bkg Data TF6", GroupName="Parameters", Description="")]
		public ARC_Trend_MTF_BkgDataTypes pBkgData6
		{get;set;}

		[Display(Order=16, Name="Bkg Data TF7", GroupName="Parameters", Description="")]
		public ARC_Trend_MTF_BkgDataTypes pBkgData7
		{get;set;}

		private Brush pUpTrendBrush = Brushes.Lime;
		[XmlIgnore()]
		[Display(Order = 20, ResourceType = typeof(Custom.Resource), Name = "Up trend stripe",  GroupName = "Parameters")]
		public Brush UpTrendBrush{	get { return pUpTrendBrush; }	set { pUpTrendBrush = value; }		}
					[Browsable(false)]
					public string UpTrendBrushSerialize	{	get { return Serialize.BrushToString(pUpTrendBrush); } set { pUpTrendBrush = Serialize.StringToBrush(value); }			}
		[Range(0,100)]
		[Display(Order=21, Name="Up stripe Opacity", GroupName="Parameters", Description="")]
		public int pUpStripeOpacity
		{get;set;}


		private Brush pDownTrendBrush = Brushes.Magenta;
		[XmlIgnore()]
		[Display(Order = 30, ResourceType = typeof(Custom.Resource), Name = "Down trend stripe",  GroupName = "Parameters")]
		public Brush DownTrendBrush{	get { return pDownTrendBrush; }	set { pDownTrendBrush = value; }		}
					[Browsable(false)]
					public string DownTrendBrushSerialize	{	get { return Serialize.BrushToString(pDownTrendBrush); } set { pDownTrendBrush = Serialize.StringToBrush(value); }					}
		[Range(0,100)]
		[Display(Order=31, Name="Down stripe Opacity", GroupName="Parameters", Description="")]
		public int pDownStripeOpacity
		{get;set;}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_Trend_MTF[] cacheARC_Trend_MTF;
		public ARC.ARC_Trend_MTF ARC_Trend_MTF()
		{
			return ARC_Trend_MTF(Input);
		}

		public ARC.ARC_Trend_MTF ARC_Trend_MTF(ISeries<double> input)
		{
			if (cacheARC_Trend_MTF != null)
				for (int idx = 0; idx < cacheARC_Trend_MTF.Length; idx++)
					if (cacheARC_Trend_MTF[idx] != null &&  cacheARC_Trend_MTF[idx].EqualsInput(input))
						return cacheARC_Trend_MTF[idx];
			return CacheIndicator<ARC.ARC_Trend_MTF>(new ARC.ARC_Trend_MTF(), input, ref cacheARC_Trend_MTF);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_Trend_MTF ARC_Trend_MTF()
		{
			return indicator.ARC_Trend_MTF(Input);
		}

		public Indicators.ARC.ARC_Trend_MTF ARC_Trend_MTF(ISeries<double> input )
		{
			return indicator.ARC_Trend_MTF(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_Trend_MTF ARC_Trend_MTF()
		{
			return indicator.ARC_Trend_MTF(Input);
		}

		public Indicators.ARC.ARC_Trend_MTF ARC_Trend_MTF(ISeries<double> input )
		{
			return indicator.ARC_Trend_MTF(input);
		}
	}
}

#endregion
