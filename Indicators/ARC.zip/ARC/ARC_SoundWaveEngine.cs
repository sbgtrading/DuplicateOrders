#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
public enum ARC_SoundWaveEngine_QtyBasis {TicksCount, Volume}
public enum ARC_SoundWaveEngine_HistoBasis {UpMinusDown, SumTotal}
public enum ARC_SoundWaveEngine_SmoothingType {Simple, Weighted, Exponential}
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	[CategoryOrder("Parameters",       10)]
	[CategoryOrder("Custom Visuals",    60)]
	[CategoryOrder("Indicator Version", 1000)]
	public class ARC_SoundWaveEngine : Indicator
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "SoundWave";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "26845", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
				if(UserId.CompareTo("416913")==0) return true;// James Hyland  osmovalve@yahoo.com
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

//		private string VERSION = "v0.16 26-Oct-23";
		private string VERSION = "v1.0 26-Oct-23";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; }}

		private const int UP = 1;
		private const int DOWN = -1;
		private Series<double> PositiveHistos;
		private DateTime LaunchTime = DateTime.MaxValue;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "ARC_SoundWaveEngine";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= false;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= false;
				pHistoCalcBasis = ARC_SoundWaveEngine_HistoBasis.SumTotal;
				pSecondsLookback		  = 3;
				pThresholdSmoothingPeriod = 200;
				pSensitivityFactor = 50;
				pFullStripes  = true;
				pNBarLookback = 0;
				pShowTapeFlipStatus = true;
				pBkgStripeOpacity = 40;
				pBkgStripeBuyBrush  = Brushes.Lime;
				pBkgStripeSellBrush = Brushes.Magenta;
				pFlipTheTape = false;
				AddPlot(new Stroke(Brushes.Orange, 2),  PlotStyle.Bar, "Threshold");
				Plots[0].AutoWidth = true;
				AddPlot(new Stroke(Brushes.MediumBlue, 2),    PlotStyle.Bar, "UpFlow");
				Plots[1].AutoWidth = true;
				AddPlot(new Stroke(Brushes.DarkRed, 2), PlotStyle.Bar, "DownFlow");
				Plots[2].AutoWidth = true;
				AddPlot(new Stroke(Brushes.Transparent, 1), PlotStyle.Dot, "Flow");
				AddLine(Brushes.DarkGray,	0,		NinjaTrader.Custom.Resource.NinjaScriptIndicatorZeroLine);
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Tick, 1);
				BuyBkgBrush = pBkgStripeBuyBrush.Clone();
				BuyBkgBrush.Opacity = pBkgStripeOpacity/100f;
				BuyBkgBrush.Freeze();
				SellBkgBrush = pBkgStripeSellBrush.Clone();
				SellBkgBrush.Opacity = pBkgStripeOpacity/100f;
				SellBkgBrush.Freeze();
				ThresholdMult = (5.0-1.0) * pSensitivityFactor/100.0 + 1.0;
				IsDebug = System.IO.File.Exists(@"c:\222222222222.txt");
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion
			}
			else if(State==State.DataLoaded){
				PositiveHistos = new Series<double>(BarsArray[0]);
				ema = EMA(PositiveHistos, pThresholdSmoothingPeriod);
				wma = WMA(PositiveHistos, pThresholdSmoothingPeriod);
				sma = SMA(PositiveHistos, pThresholdSmoothingPeriod);
//				Print1(Instrument.FullName+":  "+BarsArray[0].LastBarTime.ToString()+"  "+BarsArray[1].LastBarTime.ToString());
				LaunchTime = BarsArray[1].LastBarTime.AddSeconds(-pSecondsLookback*1.2);
				int b = Math.Max(0,BarsArray[0].Count-2-pThresholdSmoothingPeriod);
//Print1("b: "+b+"   BarsArray[0].Count: "+BarsArray[0].Count);
				var t = BarsArray[0].GetTime(b);
//Print1("T1: "+LaunchTime.ToString()+"  T2: "+t.ToString());
				if(LaunchTime > t) LaunchTime = t;
			}
			else if(State==State.Historical){
				if(ChartControl==null) PrintTo = PrintTo.OutputTab1;
				else PrintTo = PrintTo.OutputTab2;
			}
		}
		Brush BuyBkgBrush;
		Brush SellBkgBrush;
		char dir = ' ';
		double priorPrice = 0;
		int c = 0;
		string lastprint = "";
		private void Print1(string s){
			if(c<20000 && lastprint.CompareTo(s)!=0) Print ("SWE: "+s);
			lastprint=s;
			//c++;
		}
		private class Data{
			public DateTime T = DateTime.MinValue;
			public int CBar0 = 0;
			public double Volu = 0;
			public Data(DateTime t, int cb, double volu){T = t; CBar0 = cb; Volu = volu;}
		}
		List<Data> Volup = new List<Data>();
		List<Data> Voldn = new List<Data>();
		SortedDictionary<int, double> UpCountAtThisBar = new SortedDictionary<int,double>();
		SortedDictionary<int, double> DownCountAtThisBar = new SortedDictionary<int,double>();
		List<double> Velo = new List<double>();
		TimeSpan ts;
		string tstr0 = "";
		string tstr1 = "";
		int cb0 = -1;
		EMA ema = null;
		WMA wma = null;
		SMA sma = null;
		int LaunchABar = -1; bool zone = false;
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
int line=1;
try{
//if(BarsInProgress == 0 && State==State.Realtime && LaunchABar == -1) LaunchABar = CurrentBars[0]+15;
//if(LaunchABar > 0 && IsDebug) {
//	zone = CurrentBars[0]>LaunchABar && CurrentBars[0] - LaunchABar < 10;
//	if(BarsInProgress==1) Print1("\n"+Times[1][0].ToString().Replace(" PM","."+Times[1][0].Millisecond.ToString())+ "   CB-LaunchABar: "+(CurrentBars[0]-LaunchABar).ToString());
//}
			if(ChartControl==null && LaunchTime.Ticks > Times[1][0].Ticks) return;//improve load times for SoundWave, reduce calculation on unimportant data not used in calculation of the graphic.
			if(cb0==-1) cb0 = CurrentBars[0];
			if(BarsInProgress == 1){
				//if(State==State.Historical)
				{
					if(Closes[1][0] > priorPrice) dir = 'U';
					if(Closes[1][0] < priorPrice) dir = 'D';
					priorPrice = Closes[1][0];
					var dt = Times[1][0].AddSeconds(-pSecondsLookback);
					cb0 = BarsArray[0].GetBar(Times[1][0]);
line=10;
//tstr0 = "N/A";try{tstr0=Times[0][0].ToString();}catch{};
//tstr1 = "N/A";try{tstr1=Times[1][0].ToString();}catch{};
					if(dir=='U'){
						Volup.Add(new Data(Times[1][0], cb0, Volumes[1][0]));
					}
					else if(dir=='D'){
						Voldn.Add(new Data(Times[1][0], cb0, Volumes[1][0]));
					}
					#region -- Remove out of date ticks --
					while(Volup.Count>0){
						ts = new TimeSpan(Times[1][0].Ticks - Volup[0].T.Ticks);
						if(ts.TotalSeconds > pSecondsLookback) {
//if(State==State.Realtime && IsDebug) Print1(string.Format("{0}  removing tick: {1}.{2}    count {3}", (ChartControl==null ? "b":"s"), Volup[0].T.Second, Volup[0].T.Millisecond, Volup.Count));
if(zone) Print1("  removing vup at "+Volup[0].T.ToString().Replace(" PM","."+Times[1][0].Millisecond.ToString()));
							Volup.RemoveAt(0);
						}
						else break;
					}
					while(Voldn.Count>0){
						ts = new TimeSpan(Times[1][0].Ticks - Voldn[0].T.Ticks);
						if(ts.TotalSeconds > pSecondsLookback){
if(zone) Print1("  removing vdn at "+Voldn[0].T.ToString().Replace(" PM","."+Times[1][0].Millisecond.ToString()));
							Voldn.RemoveAt(0);
						}
						else break;
					}
					#endregion
				}
//var t= Times[1][0];
//bool z = t.Day==21 && t.Month==9 && t.Hour==13 && t.Minute==24;
//if(z)Print1(t.ToString()+"   "+Closes[1][0]+" up tks: "+Volup.Count+"   dn: "+Voldn.Count);
				return;
			}
line=952;
//Print1("Each VolUp and VolDn element:   "+zone.ToString());
//if(zone) {
//	foreach(var kk in Volup) Print1("   Volup.T "+kk.T.ToString().Replace(" PM","."+Times[1][0].Millisecond.ToString())+"  vol: "+kk.Volu);
//	foreach(var kk in Voldn) Print1("   Voldn.T "+kk.T.ToString().Replace(" PM","."+Times[1][0].Millisecond.ToString())+"  vol: "+kk.Volu);
//}
			double vup = Volup.Count;
			double vdn = Voldn.Count;
			if(pFlipTheTape){
//Print1(Times[0][0].ToString()+"  Flipped!   up: "+vdn+"   dn: "+vup);
				double temp = vdn;
				vdn = vup;
				vup = temp;
			}
			double diff = vup-vdn;
//if(zone) Print1("  vup - vdn : "+vup+" - "+vdn+"  = "+diff);
//			if(pQtyBasis == ARC_SoundWaveEngine_QtyBasis.TicksCount){
//line=297;
//				vup = Volup.Count;
//				vdn = Voldn.Count;
//				diff = vup-vdn;
//			}else if(pQtyBasis == ARC_SoundWaveEngine_QtyBasis.Volume){
//				var L = Volup.Select(k=>k.Volu).ToList();
//				if(L!=null && L.Count>0){
//					vup = L.Sum();
////Print1("vup count: "+L.Count+"  sum: "+vup);
//				}
//				L = Voldn.Select(k=>k.Volu).ToList();
//				if(L!=null && L.Count>0){
//					vdn = L.Sum();
////Print1("vdn count: "+L.Count+"  sum: "+vdn);
//				}
//				diff = vup-vdn;
////Print1(Times[0][0].ToString()+"   diff: "+diff+"    "+vup+" - "+vdn);
//			}
//			if(pHistoCalcBasis == ARC_SoundWaveEngine_HistoBasis.UpMinusDown){
//				if(diff>0){
//					UpFlow[0] = diff;
//					DnFlow.Reset(0);
//					UpCountAtThisBar[cb0] = diff;
//					Flow[0] = UpFlow[0];
//				}else{
//					DnFlow[0] = (pAllHistosPositive ? Math.Abs(diff):diff);
//					UpFlow.Reset(0);
//					DownCountAtThisBar[cb0] = diff;
//					Flow[0] = DnFlow[0];
//				}
//			}else
			if(pHistoCalcBasis == ARC_SoundWaveEngine_HistoBasis.SumTotal){
line=329;
				if(pFlipTheTape){
					if(pShowTapeFlipStatus && ChartControl!=null) Draw.TextFixed(this,"flipstatus", "Tape: Flipped", TextPosition.TopLeft, ChartControl.Properties.ChartText, ChartControl.Properties.LabelFont, ChartControl.Properties.ChartBackground, ChartControl.Properties.ChartBackground,100);
					if(diff>=0){
line=333;
						UpFlow[0] = vup+vdn;
						Flow[0]   = UpFlow[0];
						DnFlow[0]=0;
					}else{
line=338;
						DnFlow[0] = (pAllHistosPositive ? vup+vdn : -(vup+vdn));
						Flow[0]   = -Math.Abs(DnFlow[0]);
						UpFlow[0]=0;
					}
				}else{
					if(pShowTapeFlipStatus && ChartControl!=null) Draw.TextFixed(this,"flipstatus", "Tape: Normal", TextPosition.TopLeft, ChartControl.Properties.ChartText, ChartControl.Properties.LabelFont, ChartControl.Properties.ChartBackground, ChartControl.Properties.ChartBackground,100);
					if(diff>0){
line=333;
						UpFlow[0] = vup+vdn;
						Flow[0]   = UpFlow[0];
						DnFlow[0]=0;
					}else{
line=338;
						DnFlow[0] = (pAllHistosPositive ? vup+vdn : -(vup+vdn));
						Flow[0]   = -Math.Abs(DnFlow[0]);
						UpFlow[0]=0;
					}
				}
			}
line=344;
			PositiveHistos[0] = Math.Abs(Flow[0]);
			double thresh = 0;
			if(CurrentBars[0]>1){
line=349;
//				if(pHistoCalcBasis == ARC_SoundWaveEngine_HistoBasis.UpMinusDown){
//					Threshold[0] = Threshold[1];
//					while(UpCountAtThisBar.Count   > pThresholdSmoothingPeriod) UpCountAtThisBar.Remove(  UpCountAtThisBar.First().Key);
//					while(DownCountAtThisBar.Count > pThresholdSmoothingPeriod) DownCountAtThisBar.Remove(DownCountAtThisBar.First().Key);
//					if(UpCountAtThisBar.Count>0){
//						thresh  = UpCountAtThisBar.Values.Average();
//						Threshold[0] = thresh*ThresholdMult;
//					}
//					if(DownCountAtThisBar.Count>0){
//						thresh = Math.Abs(DownCountAtThisBar.Values.Average());
//						if(pAllHistosPositive)
//							Threshold[0] =  thresh*ThresholdMult;
//						else
//							Threshold[0] = -thresh*ThresholdMult;
//					}
//				}
			}
			if(pHistoCalcBasis == ARC_SoundWaveEngine_HistoBasis.SumTotal){
				var abar = BarsArray[0].GetBar(Times[1][0].AddSeconds(-pSecondsLookback));
line=369;
				while(UpCountAtThisBar.Count>0   && UpCountAtThisBar.First().Key < abar)   UpCountAtThisBar.Remove(  UpCountAtThisBar.First().Key);
				while(DownCountAtThisBar.Count>0 && DownCountAtThisBar.First().Key < abar) DownCountAtThisBar.Remove(DownCountAtThisBar.First().Key);
line=371;
				if(pSmoothingType == ARC_SoundWaveEngine_SmoothingType.Simple){
					double sum = 0;
					abar = CurrentBars[0];
					int count = 0;
					while(CurrentBars[0] - abar < pThresholdSmoothingPeriod){
						if(abar <3) break;
						count++;
						sum = sum + (Flow.IsValidDataPointAt(abar) ? Math.Abs(Flow.GetValueAt(abar)):0);
//if(zone) Print1("  "+count+":   sum = "+sum+"   Flow["+abar+"]:  "+Flow.GetValueAt(abar));
						abar--;
					}
					thresh = sum / pThresholdSmoothingPeriod;
//					thresh = sma[0];
				}else if(pSmoothingType == ARC_SoundWaveEngine_SmoothingType.Exponential){
					thresh = CurrentBars[0]>10? ema[0] : 0;
				}else if(pSmoothingType == ARC_SoundWaveEngine_SmoothingType.Weighted){
					thresh = CurrentBars[0]>10? wma[0] : 0;
				}
				Threshold[0] = thresh*ThresholdMult;
//if(zone) Print1("  thresh:  "+Threshold[0]);
//				if(pAllHistosPositive) {
//					AvgLower[0] = Threshold[0];
//				}else{
//					AvgLower[0] = -Threshold[0];
//				}
line=393;
//var t = Times[1][0];
//bool z = t.Day==6 && t.Hour==16 && t.Minute==3;
//if(z)Print1(t.ToShortTimeString()+" sum: "+(s1+s2)+"  s1: "+s1+"  s2: "+s2+"   thresh: "+thresh+"   abar "+(cb0-abar));
			}
//			if(CurrentBars[0]>2 && pShowVelocityPlot){
//				var v0 = UpFlow.IsValidDataPoint(0) ? UpFlow[0] : DnFlow[0];
//				var v1 = UpFlow.IsValidDataPoint(1) ? UpFlow[1] : DnFlow[1];
//				Velocity[0] = (v0 - v1) * ThresholdMult;
//				if(IsFirstTickOfBar){
//					var v2 = UpFlow.IsValidDataPoint(2) ? UpFlow[2] : DnFlow[2];
////					Velo.Insert(0, v1 - v2);
//					Velocity[1] = (v1 - v2) * ThresholdMult;
//				}
//			}
//			if(pNBarLookback>0 && CurrentBars[0] > pNBarLookback+1){
//				double tH = 0;
//				double tL = 0;
//				if(pAllHistosPositive) {
//					for(int i = 1; i<=pNBarLookback; i++){
//						if(UpFlow.IsValidDataPoint(i)) tH = Math.Max(tH, UpFlow[i]);
//						if(DnFlow.IsValidDataPoint(i)) tL = Math.Max(tL, Math.Abs(DnFlow[i]));
//					}
//				}else{
//					for(int i = 1; i<=pNBarLookback; i++){
//						if(UpFlow.IsValidDataPoint(i)) tH = Math.Max(tH, UpFlow[i]);
//						if(DnFlow.IsValidDataPoint(i)) tL = Math.Min(tL, DnFlow[i]);
//					}
//				}
//				Threshold[0] = tH * ThresholdMult;
//				AvgLower[0] = tL * ThresholdMult;
//			}
line=500;

//			if(UpFlow[0] > Threshold[0]) PlotBrushes[0][0] = Brushes.DeepPink;
			if(CurrentBars!=null && CurrentBars[0]>0){
line=510;
				if(ChartControl!=null){
					if(pAllHistosPositive) {
						#region -- update prior bar for accuracy --
						if(IsFirstTickOfBar && CurrentBars[0]>3){//update prior bar background brush to eliminate rare situation where net delta is nearly 0
							if(pFullStripes){
								if(UpFlow[1] > Threshold[2]) {
//Print1(Times[0][1].ToShortTimeString()+"."+Times[0][1].Second+"         UpFlow[1]: "+UpFlow[1].ToString()+"  DnFlow[1]: "+DnFlow[1].ToString()+"  Threshold[2]: "+Threshold[2].ToString()+"  BUY");
									BackBrushesAll[1] = BuyBkgBrush;
								}
								else if(DnFlow[1] > Threshold[2]){
//Print1(Times[0][1].ToShortTimeString()+"."+Times[0][1].Second+"         UpFlow[1]: "+UpFlow[1].ToString()+"  DnFlow[1]: "+DnFlow[1].ToString()+"  Threshold[2]: "+Threshold[2].ToString()+"  SELLLL");
									BackBrushesAll[1] = SellBkgBrush;
								}
								else{
//Print1(Times[0][1].ToShortTimeString()+"."+Times[0][1].Second+"         UpFlow[1]: "+UpFlow[1].ToString()+"  DnFlow[1]: "+DnFlow[1].ToString()+"  Threshold[2]: "+Threshold[2].ToString()+"  NULL");
									BackBrushesAll[1] = null;
								}
							}else{
								if(UpFlow[1] > Threshold[2]) BackBrushes[1] = BuyBkgBrush;
								else if(DnFlow[1] > Threshold[2]) BackBrushes[1] = SellBkgBrush;
								else BackBrushes[1] = null;
							}
						}
						#endregion
						if(pFullStripes){
line=520;
							if(UpFlow[0] > Threshold[1]) BackBrushesAll[0] = BuyBkgBrush;
							else if(DnFlow[0] > Threshold[1]) BackBrushesAll[0] = SellBkgBrush;
							else BackBrushesAll[0] = null;
						}else{
line=530;
							if(UpFlow[0] > Threshold[1]) BackBrushes[0] = BuyBkgBrush;
							else if(DnFlow[0] > Threshold[1]) BackBrushes[0] = SellBkgBrush;
							else BackBrushes[0] = null;
						}
//					}else{
//						if(pFullStripes){
//							if(UpFlow[0] > Threshold[1]) BackBrushesAll[0] = BuyBkgBrush;
//							else if(DnFlow[0] < AvgLower[1]) BackBrushesAll[0] = SellBkgBrush;
//							else BackBrushesAll[0] = null;
//						}else{
//							if(UpFlow[0] > Threshold[1]) BackBrushes[0] = BuyBkgBrush;
//							else if(DnFlow[0] < AvgLower[1]) BackBrushes[0] = SellBkgBrush;
//							else BackBrushes[0] = null;
//						}
					}
				}
			}
//			if(DnFlow[0] < AvgLower[0]) PlotBrushes[1][0] = Brushes.DeepPink;
}catch(Exception e){Print1("Line "+line+":   "+e.ToString());}
		}

		#region --- Properties ---
		private ARC_SoundWaveEngine_HistoBasis pHistoCalcBasis;
		private ARC_SoundWaveEngine_QtyBasis pQtyBasis;
//		[Display(Order=10, Name="Flow calc basis", GroupName = "Parameters", Description="Ticks count, or SumTotal")]
//		public ARC_SoundWaveEngine_HistoBasis pHistoCalcBasis
//		{get;set;}

//		[Display(Order=20, Name="Qty Basis", GroupName = "Parameters", Description="")]
//		public ARC_SoundWaveEngine_QtyBasis pQtyBasis
//		{get;set;}

		[NinjaScriptProperty]
		[Range(1, double.MaxValue)]
		[Display(Order=30, Name="Seconds Lookback", GroupName="Parameters")]
		public double pSecondsLookback
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Order=40, Name="Thresh smoothing period (bars)", GroupName="Parameters")]
		public int pThresholdSmoothingPeriod
		{ get; set; }

		private double ThresholdMult = 1;
		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Order=50, Name="Sensitivity Factor", Description="0 = numerous signals, 100 = few signals", GroupName="Parameters")]
		public double pSensitivityFactor
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order=60, Name="Smoothing type", Description="", GroupName="Parameters")]
		public ARC_SoundWaveEngine_SmoothingType pSmoothingType
		{get;set;}

		[NinjaScriptProperty]
		[Display(Order=65, Name="Flip the tape", Description="Reverse the direction of signals?", GroupName="Parameters")]
		public bool pFlipTheTape
		{get;set;}

		private int pNBarLookback = 0;
//		[NinjaScriptProperty]
//		[Display(Order=70, Name="N-bar lookback histos", GroupName="Parameters")]
//		public int pNBarLookback
//		{get;set;}

//		[Display(Order=60, Name="Show velocity plot?", GroupName="Parameters")]
//		public bool pShowVelocityPlot
//		{ get;set; }


		[Display(Order=10, Name="Full-sized racing stripes?", Description="", GroupName="Custom Visuals")]
		public bool pFullStripes
		{ get; set; }

		[Display(Order=20, Name="Bkg Stripe Opacity", Description="0=transparent, 100=full color", GroupName="Custom Visuals")]
		public double pBkgStripeOpacity
		{ get; set; }

		[XmlIgnore]
		[Display(Order=30, Name="Buy stripe", Description="", GroupName="Custom Visuals")]
		public Brush pBkgStripeBuyBrush{ get; set; }
					[Browsable(false)]
					public string pBkgStripeBuyBrush_{
							get { return Serialize.BrushToString(pBkgStripeBuyBrush); }
							set { pBkgStripeBuyBrush = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order=40, Name="Sell stripe", Description="", GroupName="Custom Visuals")]
		public Brush pBkgStripeSellBrush{ get; set; }
					[Browsable(false)]
					public string pBkgStripeSellBrush_{
							get { return Serialize.BrushToString(pBkgStripeSellBrush); }
							set { pBkgStripeSellBrush = Serialize.StringToBrush(value); }}

		[Display(Order = 50, Name = "Show Tape Flip Status?", GroupName = "Custom Visuals", Description = "")]
		public bool pShowTapeFlipStatus {get;set;}

		private bool pAllHistosPositive = true;
//		[Display(Order=10, Name="Make all histos positive?", GroupName="SumTotal Parameters")]
//		public bool pAllHistosPositive
//		{ get; set; }
		
//		[NinjaScriptProperty]
//		[Display(Order=30, Name="Use Net diff?", Description="...if false, use raw tick counts", GroupName="Parameters")]
//		public bool pUseNetDiff
//		{ get; set; }

		#endregion

		#region -- Plots --
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Threshold
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> UpFlow
		{
			get { return Values[1]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> DnFlow
		{
			get { return Values[2]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Flow
		{
			get { return Values[3]; }
		}

//		[Browsable(false)]
//		[XmlIgnore]
//		public Series<double> AvgLower
//		{
//			get { return Values[3]; }
//		}


//		[Browsable(false)]
//		[XmlIgnore]
//		public Series<double> Flow
//		{
//			get { return Values[5]; }
//		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_SoundWaveEngine[] cacheARC_SoundWaveEngine;
		public ARC.ARC_SoundWaveEngine ARC_SoundWaveEngine(double pSecondsLookback, int pThresholdSmoothingPeriod, double pSensitivityFactor, ARC_SoundWaveEngine_SmoothingType pSmoothingType, bool pFlipTheTape)
		{
			return ARC_SoundWaveEngine(Input, pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor, pSmoothingType, pFlipTheTape);
		}

		public ARC.ARC_SoundWaveEngine ARC_SoundWaveEngine(ISeries<double> input, double pSecondsLookback, int pThresholdSmoothingPeriod, double pSensitivityFactor, ARC_SoundWaveEngine_SmoothingType pSmoothingType, bool pFlipTheTape)
		{
			if (cacheARC_SoundWaveEngine != null)
				for (int idx = 0; idx < cacheARC_SoundWaveEngine.Length; idx++)
					if (cacheARC_SoundWaveEngine[idx] != null && cacheARC_SoundWaveEngine[idx].pSecondsLookback == pSecondsLookback && cacheARC_SoundWaveEngine[idx].pThresholdSmoothingPeriod == pThresholdSmoothingPeriod && cacheARC_SoundWaveEngine[idx].pSensitivityFactor == pSensitivityFactor && cacheARC_SoundWaveEngine[idx].pSmoothingType == pSmoothingType && cacheARC_SoundWaveEngine[idx].pFlipTheTape == pFlipTheTape && cacheARC_SoundWaveEngine[idx].EqualsInput(input))
						return cacheARC_SoundWaveEngine[idx];
			return CacheIndicator<ARC.ARC_SoundWaveEngine>(new ARC.ARC_SoundWaveEngine(){ pSecondsLookback = pSecondsLookback, pThresholdSmoothingPeriod = pThresholdSmoothingPeriod, pSensitivityFactor = pSensitivityFactor, pSmoothingType = pSmoothingType, pFlipTheTape = pFlipTheTape }, input, ref cacheARC_SoundWaveEngine);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_SoundWaveEngine ARC_SoundWaveEngine(double pSecondsLookback, int pThresholdSmoothingPeriod, double pSensitivityFactor, ARC_SoundWaveEngine_SmoothingType pSmoothingType, bool pFlipTheTape)
		{
			return indicator.ARC_SoundWaveEngine(Input, pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor, pSmoothingType, pFlipTheTape);
		}

		public Indicators.ARC.ARC_SoundWaveEngine ARC_SoundWaveEngine(ISeries<double> input , double pSecondsLookback, int pThresholdSmoothingPeriod, double pSensitivityFactor, ARC_SoundWaveEngine_SmoothingType pSmoothingType, bool pFlipTheTape)
		{
			return indicator.ARC_SoundWaveEngine(input, pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor, pSmoothingType, pFlipTheTape);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_SoundWaveEngine ARC_SoundWaveEngine(double pSecondsLookback, int pThresholdSmoothingPeriod, double pSensitivityFactor, ARC_SoundWaveEngine_SmoothingType pSmoothingType, bool pFlipTheTape)
		{
			return indicator.ARC_SoundWaveEngine(Input, pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor, pSmoothingType, pFlipTheTape);
		}

		public Indicators.ARC.ARC_SoundWaveEngine ARC_SoundWaveEngine(ISeries<double> input , double pSecondsLookback, int pThresholdSmoothingPeriod, double pSensitivityFactor, ARC_SoundWaveEngine_SmoothingType pSmoothingType, bool pFlipTheTape)
		{
			return indicator.ARC_SoundWaveEngine(input, pSecondsLookback, pThresholdSmoothingPeriod, pSensitivityFactor, pSmoothingType, pFlipTheTape);
		}
	}
}

#endregion
