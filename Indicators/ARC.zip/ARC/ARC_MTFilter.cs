#define DoLicense
#define MODERATORS
//#define ARC_RENKOBXT_INSTALLED //if not defined, then it will look for NS_RenkoBXT bars

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using SharpDX.DirectWrite;
//using NeuroStreet.VMLean;
using System.Windows.Controls;
using System.Windows.Automation;
#endregion

#region -- Author / Infos version --
#endregion

//TAGS : ##MODIF HERE## / ##DEFAULT VALUE TO CHECK## / ##HARD CODED## / ##??##

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region -- Category Order --
    [CategoryOrder("Parameters", 1)]
    [CategoryOrder("Indicator Version", 1111)]
    #endregion
    public class ARC_MTFilter : Indicator
    {
		private bool IsDebug        = false;
		private bool ValidLicense   = false;
		private bool IsExpired      = true;

		private bool LicenseChecked = false;
		private string UserId    = string.Empty;//MTFilter v1.1 14.Jun.2022,     20034,21042,21140,21350,21686,21868, 
		private string MachineId = string.Empty;
		string ModuleName = "MTFilter";

		List<string> Expected_ISTagSet = new List<string>(){"22344", "20146","25900", "27405"};//27405 is Annual Membership    PropTraderProgram 21868
		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion


        private const string VERSION = "v1.1 14.Jun.2022";
		//1.15 introduced the Infusionsoft licensing system (transitioning away from the fixed license key system)
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

        #region ---- Variables ---- 

        #region -- Structure BIAS + Swings --
        private List<int> sequence = new List<int>(3);//#STRBIAS
        private int SRType, preSRType;//#STRBIAS  
		private Series<double> structureBiasState;
		private Series<double> swingHighsState;
		private Series<double> swingLowsState;
        #endregion

		private EMA EmaFast;
		private EMA EmaSlow;
		private SMA SmaFast;
		private SMA SmaSlow;
        private MACD BMACD;
        private MACD MACD1;
        private MACD MACD2;
        private MACD MACD3;
        private MACD MACD4;
        private StdDev SDBB;

        #region -- zigzag indicator -- 
        private int lastHighIdx = 0;
        private int lastLowIdx = 0;
        private int priorSwingHighIdx = 0;
        private int priorSwingLowIdx = 0;
        private int highCount = 0;
        private int lowCount = 0;
        private int preLastHighIdx = 0;
        private int preLastLowIdx = 0;
        private double zigzagDeviation = 0.0;
        private double currentHigh = 0.0;
        private double currentLow = 0.0;
        private double swingMax = 0.0;
        private double swingMin = 0.0;
        private double preCurrentHigh = 0.0;
        private double preCurrentLow = 0.0;
        private bool addHigh = false;
        private bool updateHigh = false;
        private bool addLow = false;
        private bool updateLow = false;
        private bool drawHigherHighLabel = false;
        private bool drawLowerHighLabel = false;
        private bool drawDoubleTopLabel = false;
        private bool drawLowerLowLabel = false;
        private bool drawHigherLowLabel = false;
        private bool drawDoubleBottomLabel = false;
        private bool intraBarAddHigh = false;
        private bool intraBarUpdateHigh = false;
        private bool intraBarAddLow = false;
        private bool intraBarUpdateLow = false;

        private ATR avgTrueRange;
        private Series<int> pre_swingHighType;
        private Series<int> pre_swingLowType;
        private Series<int> swingHighType;
        private Series<int> swingLowType;
//        private Series<int> acceleration1;
//        private Series<int> acceleration2;
        private Series<bool> upTrend;
        #endregion

		private Series<double> BBMACD, Upper, Lower, Histogram;
		private int DATA_ID = 0;
		private int FilterRequirements = 0;
		private Brush UpTrendTinted = null;
		private Brush DownTrendTinted = null;
        #endregion

        //public override string DisplayName { get { return "ARC_MT Filter"; } }

        protected override void OnStateChange()
        {
            #region State == State.SetDefaults  
            if (State == State.SetDefaults)
            {
				Description = @"";
				Name = "ARC_MT Filter";
				ArePlotsConfigurable = false;
				DrawOnPricePanel     = false;
				AreLinesConfigurable = false;
				DrawOnPricePanel  = false;
				PaintPriceMarkers = false;
				ZOrder = -1;
				MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				ScaleJustification = ScaleJustification.Right;
				IsSuspendedWhileInactive = false;
				Calculate = Calculate.OnEachTick;
				IsOverlay = false;
				DisplayInDataBox = true;

				pBarBasis = ARC_MTFilter_BarBasis.Chart;
				pMinuteBarPeriod = 10;
				pRangeBarSize = 14;
				pRenkoBarSize = 14;
				pBXTSize = 8;
				pBXTOffset = 4;
				pBXTReverse = 14;

				pRequireHisto_PosNeg       = true;
				pRequireBBHisto_Confluence = false;
				pRequireBB_AboveUpperBelowLower = false;
//				pRequireBB_AboveLowerBelowUpper = false;
				pRequireBB_AboveBelowMidline    = false;
				pRequireMA_FastAboveBelowSlow   = false;
				pRequireClosePrice_AboveBelowFastMA  = false;
				pRequireFullBar_AboveBelowFastMA  = false;
				pRequireBB_AboveBelowZeroline = false;
				pRequireClosePrice_AboveBelowSlowMA  = true;
				pRequireFullBar_AboveBelowSlowMA  = false;
				pRequireSwingStructure = false;

				pExtendRacingStripes = false;
				pUpTrendOpacity      = 90;
				pDownTrendOpacity    = 90;
                BandPeriod  = 10;
                pFast       = 12;
                pSlow       = 26;
                pFastMA     = 100;
                pSlowMA     = 200;
				pFastMAType = ARC_MTFilter_MAType.EMA;
				pSlowMAType = ARC_MTFilter_MAType.EMA;

				StdDevNumber = 1.0;

//                #region SwingTrend Parameters 
                pSwingStrength = 3;
//                MultiplierMD = 0.0;
//                MultiplierDTB = 0.0;
//                #endregion

			}
			#endregion

			#region State == State.Configure  
			else if (State == State.Configure)
			{
                AddDataSeries(BarsPeriodType.Minute, pMinuteBarPeriod);
                AddDataSeries(BarsPeriodType.Range, pRangeBarSize);
                AddRenko(Instrument.FullName, pRenkoBarSize, MarketDataType.Last);
				DATA_ID = 0;
				if(     pBarBasis == ARC_MTFilter_BarBasis.Minute)   DATA_ID = 1;
				else if(pBarBasis == ARC_MTFilter_BarBasis.Range)    DATA_ID = 2;
				else if(pBarBasis == ARC_MTFilter_BarBasis.Renko)    DATA_ID = 3;
				try{
					AddDataSeries(new BarsPeriod { BarsPeriodType = (BarsPeriodType) 16005, Value = pBXTSize, Value2 = pBXTOffset, BaseBarsPeriodValue=pBXTReverse });//NS_RenkoBXT
					if(pBarBasis == ARC_MTFilter_BarBasis.RenkoBXT) DATA_ID = 4;
				}catch(Exception e){
					Print("Cannot add NS_RenkoBXT!");
					try{
						AddDataSeries(new BarsPeriod { BarsPeriodType = (BarsPeriodType) 19875, Value = pBXTSize, Value2 = pBXTOffset, BaseBarsPeriodValue=pBXTReverse });//ARC_RenkoBXT
						if(pBarBasis == ARC_MTFilter_BarBasis.RenkoBXT) DATA_ID = 4;
					}catch(Exception ee){{
						Print("Cannot add ARC_RenkoBXT!");}
						DATA_ID = 0;
					}
				}
				//uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion
            }
            #endregion

			#region -- DataLoaded --
			else if(State == State.DataLoaded){
				UpTrendTinted = pUpTrendBrush.Clone();
				UpTrendTinted.Opacity = pUpTrendOpacity/100f;
				UpTrendTinted.Freeze();
				DownTrendTinted = pDownTrendBrush.Clone();
				DownTrendTinted.Opacity = pDownTrendOpacity/100f;
				DownTrendTinted.Freeze();

				#region INIT Series  
				//swingInput        = new Series<double>(this);
				pre_swingHighType = new Series<int>(BarsArray[0]);
				pre_swingLowType  = new Series<int>(BarsArray[0]);
				swingHighType     = new Series<int>(BarsArray[0]);
				swingLowType      = new Series<int>(BarsArray[0]);
//				acceleration1     = new Series<int>(this);
//				acceleration2     = new Series<int>(this);
				upTrend           = new Series<bool>(BarsArray[0]);
				if(pRequireHisto_PosNeg) 			FilterRequirements++;
				if(pRequireBBHisto_Confluence)	    FilterRequirements++;
				if(pRequireBB_AboveUpperBelowLower) FilterRequirements++;
				if(pRequireBB_AboveBelowMidline)	FilterRequirements++;
				if(pRequireBB_AboveBelowZeroline)	FilterRequirements++;
				if(pRequireMA_FastAboveBelowSlow)	FilterRequirements++;
				if(pRequireClosePrice_AboveBelowFastMA)	FilterRequirements++;
				if(pRequireClosePrice_AboveBelowSlowMA)	FilterRequirements++;
				if(pRequireFullBar_AboveBelowFastMA)	FilterRequirements++;
				if(pRequireFullBar_AboveBelowSlowMA)	FilterRequirements++;
				if(pRequireSwingStructure)				FilterRequirements++;

				EmaFast = EMA(Closes[DATA_ID], pFastMA);
				EmaSlow = EMA(Closes[DATA_ID], pSlowMA);
				SmaFast = SMA(Closes[DATA_ID], pFastMA);
				SmaSlow = SMA(Closes[DATA_ID], pSlowMA);
				BBMACD    = new Series<double>(BarsArray[DATA_ID]);
				Upper     = new Series<double>(BarsArray[DATA_ID]);
				Lower     = new Series<double>(BarsArray[DATA_ID]);
				Histogram = new Series<double>(BarsArray[DATA_ID]);

				structureBiasState = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);//#STRBIAS
				swingHighsState    = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);//#STRBIAS
				swingLowsState     = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);//#STRBIAS
				#endregion

				#region INIT external Series  
				BMACD = MACD(Closes[DATA_ID], pFast, pSlow, BandPeriod);
				SDBB  = StdDev(BMACD, BandPeriod);
				MACD1 = MACD(BarsArray[DATA_ID], 8, 20, 20);
				MACD2 = MACD(BarsArray[DATA_ID], 10, 20, 20);
				MACD3 = MACD(BarsArray[DATA_ID], 20, 60, 20);
				MACD4 = MACD(BarsArray[DATA_ID], 60, 240, 20);
				avgTrueRange = ATR(256);
				#endregion
			}
			#endregion

            #region State == State.Terminated
            else if (State == State.Terminated)
            {
            }
            #endregion
        }
		double maFast = 0;
		double maSlow = 0;
		double macdValue = 0;
		double average = 0;
		double stdDevValue = 0;
		double histogram = 0;
		double bbmacd = 0;
		double upper = 0;
		double lower = 0;
		char StructureState = ' ';
//===============================================================================================================
        protected override void OnBarUpdate()
        {
int line=1411;
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
try{
line=1421;
			if(BarsInProgress == DATA_ID){
	            #region --- Calculate signal ---  
				try{
		            macdValue = BMACD[0];
				}catch(Exception e1){Print("e1: "+e1.ToString());}
line=1422;
				try{
		            average =   BMACD.Avg[0];
				}catch(Exception e2){Print("e2: "+e2.ToString());}
line=1423;
				try{
	    	        stdDevValue = SDBB[0];
				}catch(Exception e3){Print("e3: "+e3.ToString());}

				if(pFastMAType == ARC_MTFilter_MAType.EMA)
					maFast = EmaFast[0];
				else if(pFastMAType == ARC_MTFilter_MAType.SMA)
					maFast = SmaFast[0];
				if(pSlowMAType == ARC_MTFilter_MAType.EMA)
					maSlow = EmaSlow[0];
				else if(pSlowMAType == ARC_MTFilter_MAType.SMA)
					maSlow = SmaSlow[0];
				BBMACD[0]  = macdValue;
				upper = average + StdDevNumber * stdDevValue;
				Upper[0]  = upper;
				lower     = average - StdDevNumber * stdDevValue;
				Lower[0]  = lower;
            	histogram = MACD1.Diff[0] + MACD2.Diff[0] + MACD3.Diff[0] + MACD4.Diff[0];
				Histogram[0] = histogram;
//Print(Times[DATA_ID][0].ToString()+"   Histo: "+histogram);
	            #endregion
			}
            #region -- Summarize all filter components --  
line=1429;
            if (CurrentBars[0] > 0 && BarsInProgress == 0)
            {

				int FilterCount = 0;//positive means upward trend, negative means downward trend
				if(pRequireHisto_PosNeg){
	                if (histogram > 0)
						FilterCount++;
	                else if (histogram < 0)
						FilterCount--;
				}
				if(pRequireBBHisto_Confluence){
	                if (histogram > 0 && macdValue > 0)
						FilterCount++;
	                else if (histogram < 0 && macdValue < 0)
						FilterCount--;
				}
				if(pRequireClosePrice_AboveBelowSlowMA){
	                if (Closes[DATA_ID][0] > maSlow)
						FilterCount++;
	                else if (Closes[DATA_ID][0] < maSlow)
						FilterCount--;
				}
				if(pRequireFullBar_AboveBelowSlowMA){
	                if (Lows[DATA_ID][0] > maSlow)
						FilterCount++;
	                else if (Highs[DATA_ID][0] < maSlow)
						FilterCount--;
				}
				if(pRequireClosePrice_AboveBelowFastMA){
	                if (Closes[DATA_ID][0] > maFast)
						FilterCount++;
	                else if (Closes[DATA_ID][0] < maFast)
						FilterCount--;
				}
				if(pRequireFullBar_AboveBelowFastMA){
	                if (Lows[DATA_ID][0] > maFast)
						FilterCount++;
	                else if (Highs[DATA_ID][0] < maFast)
						FilterCount--;
				}
				if(pRequireMA_FastAboveBelowSlow){
	                if (maFast > maSlow)
						FilterCount++;
	                else if (maFast < maSlow)
						FilterCount--;
				}
				if(pRequireBB_AboveUpperBelowLower){
	                if (macdValue > upper)
						FilterCount++;
	                else if (macdValue < lower)
						FilterCount--;
				}
				bool c1 = true;
//				if(pRequireBB_AboveLowerBelowUpper){
//	                if (macdValue > upper || macdValue < lower)
//						c1 = false;
//				}
				if(pRequireBB_AboveBelowMidline){
					double midline = (upper+lower)/2;
	                if (macdValue > midline)
						FilterCount++;
	                else if (macdValue < midline)
						FilterCount--;
				}
				if(pRequireBB_AboveBelowZeroline){
	                if (macdValue > 0)
						FilterCount++;
	                else if (macdValue < 0)
						FilterCount--;
				}
				if(pRequireSwingStructure){
	                if (structureBiasState[1] > 0)
						FilterCount++;
	                else if (structureBiasState[1] < 0)
						FilterCount--;
				}


				if(pExtendRacingStripes){
					if(c1 &&  FilterCount == FilterRequirements && pUpTrendOpacity>0)   BackBrushesAll[0] = UpTrendTinted;
					if(c1 && -FilterCount == FilterRequirements && pDownTrendOpacity>0) BackBrushesAll[0] = DownTrendTinted;
				}else{
					if(c1 &&  FilterCount == FilterRequirements && pUpTrendOpacity>0)   BackBrushes[0] = UpTrendTinted;
					if(c1 && -FilterCount == FilterRequirements && pDownTrendOpacity>0) BackBrushes[0] = DownTrendTinted;
				}
            }
            #endregion

line=1502;
            #region --- Calculate and Draw ZigZag + Intrabar Structure BIAS ---
			if(BarsInProgress == 0){
				bool useHL = true;//ThisInputType == NS_VMLean_InputType.High_Low;

            #region -- Init zigzag states --    
            if (CurrentBars[0] < 2)
            {
line=1552;
                upTrend[0] = true;
line=1553;
                pre_swingHighType[0] = 0;
line=1554;
                pre_swingLowType[0] = 0;
line=1555;
                swingHighType[0] = 0;
line=1556;
                swingLowType[0] = 0;
            }
            #endregion

            #region else if (Calculate == Calculate.OnBarClose)
            else if (Calculate == Calculate.OnBarClose)
            {
line=1564;
                zigzagDeviation = MultiplierMD * avgTrueRange[0];
                swingMax = MAX(useHL ? High : Input, pSwingStrength)[1];
                swingMin = MIN(useHL ? Low : Input, pSwingStrength)[1];

                pre_swingHighType[0] = 0;
                pre_swingLowType[0] = 0;
                swingHighType[0] = 0;
                swingLowType[0] = 0;

                updateHigh = upTrend[1] && (useHL ? Highs[0][0] : Closes[0][0]) > currentHigh;
                updateLow = !upTrend[1] && (useHL ? Lows[0][0] : Closes[0][0]) < currentLow;
                addHigh = !upTrend[1] && !((useHL ? Lows[0][0] : Closes[0][0]) < currentLow) && (useHL ? Highs[0][0] : Closes[0][0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                addLow = upTrend[1] && !((useHL ? Highs[0][0] : Closes[0][0]) > currentHigh) && (useHL ? Lows[0][0] : Closes[0][0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

                upTrend[0] = upTrend[1];

line=1583;
                #region -- New High --
                if (addHigh)
                {
                    upTrend[0] = true;
                    int lookback = CurrentBars[0] - lastLowIdx;
                    swingLowType[lookback] = pre_swingLowType[lookback];
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBars[0] - lastLowIdx; i++)
                    {
                        if ((useHL ? Highs[0][i] : Closes[0][i]) > newHigh)
                        {
                            newHigh = (useHL ? Highs[0][i] : Closes[0][i]);
                            j = i;
                        }
                    }
line=1600;
                    currentHigh = newHigh;
                    priorSwingHighIdx = lastHighIdx;
                    lastHighIdx = CurrentBars[0] - j;
                }
                #endregion

                #region -- uptrend --
                else if (updateHigh)
                {
line=1610;
                    upTrend[0] = true;
                    pre_swingHighType[CurrentBars[0] - lastHighIdx] = 0;
                    currentHigh = (useHL ? Highs[0][0] : Closes[0][0]);
                    lastHighIdx = CurrentBars[0];
                }
                #endregion

                #region -- New Low --
                else if (addLow)
                {
line=1624;
                    upTrend[0] = false;
                    int lookback = CurrentBars[0] - lastHighIdx;
                    swingHighType[lookback] = pre_swingHighType[lookback];
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBars[0] - lastHighIdx; i++)
                    {
                        if ((useHL ? Lows[0][i] : Closes[0][i]) < newLow)
                        {
                            newLow = (useHL ? Lows[0][i] : Closes[0][i]);
                            j = i;
                        }
                    }
line=1638;
                    currentLow = newLow;
                    priorSwingLowIdx = lastLowIdx;
                    lastLowIdx = CurrentBars[0] - j;
                }
                #endregion

                #region -- dwtrend --
                else if (updateLow)
                {
line=1648;
                    upTrend[0] = false;
                    pre_swingLowType[CurrentBars[0] - lastLowIdx] = 0;
                    currentLow = (useHL ? Lows[0][0] : Closes[0][0]);
                    lastLowIdx = CurrentBars[0];
                }
                #endregion

                #region re-init drawing states at each new bar before calculous
                drawHigherHighLabel = false;
                drawLowerHighLabel = false;
                drawDoubleTopLabel = false;
                drawLowerLowLabel = false;
                drawHigherLowLabel = false;
                drawDoubleBottomLabel = false;
                
                #endregion

                #region -- UP || HH --
                if (addHigh || updateHigh)
                {
line=1687;
                    int priorHighCount = CurrentBars[0] - priorSwingHighIdx;
                    int priorLowCount = CurrentBars[0] - priorSwingLowIdx;
                    highCount = CurrentBars[0] - lastHighIdx;
                    lowCount = CurrentBars[0] - lastLowIdx;

                    double marginUp = (useHL ? Highs[0][priorHighCount] : Closes[0][priorHighCount]) + MultiplierDTB * avgTrueRange[highCount];
                    double marginDown = (useHL ? Highs[0][priorHighCount] : Closes[0][priorHighCount]) - MultiplierDTB * avgTrueRange[highCount];

line=1718;
                    #region -- Set NEW drawing states --
                    if (currentHigh > marginUp) drawHigherHighLabel = true;
                    else if (currentHigh < marginDown) drawLowerHighLabel = true;
                    else drawDoubleTopLabel = true;

line=1734;
                    if (currentHigh > marginUp)
                        pre_swingHighType[highCount] = 3;
                    else if (currentHigh < marginDown)
                        pre_swingHighType[highCount] = 1;
                    else
                        pre_swingHighType[highCount] = 2;
                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (addLow || updateLow)
                {
line=1750;
                    int priorLowCount = CurrentBars[0] - priorSwingLowIdx;
                    int priorHighCount = CurrentBars[0] - priorSwingHighIdx;
                    lowCount = CurrentBars[0] - lastLowIdx;
                    highCount = CurrentBars[0] - lastHighIdx;

                    double marginDown = (useHL ? Lows[0][priorLowCount] : Closes[0][priorLowCount]) - MultiplierDTB * avgTrueRange[lowCount];
                    double marginUp = (useHL ? Lows[0][priorLowCount] : Closes[0][priorLowCount]) + MultiplierDTB * avgTrueRange[lowCount];

line=1759;

                    #region -- Set NEW drawing states --
line=1793;
                    if (currentLow < marginDown) drawLowerLowLabel = true;
                    else if (currentLow > marginUp) drawHigherLowLabel = true;
                    else drawDoubleBottomLabel = true;
                    
                    if (currentLow < marginDown)
                        pre_swingLowType[lowCount] = -3;
                    else if (currentLow > marginUp)
                        pre_swingLowType[lowCount] = -1;
                    else
                        pre_swingLowType[lowCount] = -2;
                    #endregion
                }
                #endregion

            }
            #endregion

            #region else if (IsFirstTickOfBar)
            else if (IsFirstTickOfBar)
            {
line=1829;
                zigzagDeviation = MultiplierMD * avgTrueRange[1];
line=1829;
                swingMax = MAX(useHL ? Highs[0] : Closes[0], pSwingStrength)[2];
                swingMin = MIN(useHL ? Lows[0] : Closes[0], pSwingStrength)[2];

                pre_swingHighType[0] = 0;
                pre_swingLowType[0] = 0;
                swingHighType[0] = 0;
                swingLowType[0] = 0;

                updateHigh = upTrend[1] && (useHL ? Highs[0][1] : Closes[0][1]) > currentHigh;
                updateLow = !upTrend[1] && (useHL ? Lows[0][1] : Closes[0][1]) < currentLow;
                addHigh = !upTrend[1] && !((useHL ? Lows[0][1] : Closes[0][1]) < currentLow) && (useHL ? Highs[0][1] : Closes[0][1]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                addLow = upTrend[1] && !((useHL ? Highs[0][1] : Closes[0][1]) > currentHigh) && (useHL ? Lows[0][1] : Closes[0][1]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

                upTrend[0] = upTrend[1];

line=1847;
                #region -- New High --
                if (addHigh)
                {
                    upTrend[0] = true;
                    int lookback = CurrentBars[0] - lastLowIdx;
                    swingLowType[lookback] = pre_swingLowType[lookback];
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 1; i < CurrentBars[0] - lastLowIdx; i++)
                    {
                        if ((useHL ? Highs[0][i] : Closes[0][i]) > newHigh)
                        {
                            newHigh = (useHL ? Highs[0][i] : Closes[0][i]);
                            j = i;
                        }
                    }
                    currentHigh = newHigh;
                    priorSwingHighIdx = lastHighIdx;
                    lastHighIdx = CurrentBars[0] - j;
                }
                #endregion

                #region -- UPtrend --
                else if (updateHigh)
                {
line=1873;
                    upTrend[0] = true;
                    pre_swingHighType[CurrentBars[0] - lastHighIdx] = 0;
                    currentHigh = (useHL ? Highs[0][1] : Closes[0][1]);
                    lastHighIdx = CurrentBars[0] - 1;
                }
                #endregion

                #region -- New Low --
                else if (addLow)
                {
line=1890;
                    upTrend[0] = false;
                    int lookback = CurrentBars[0] - lastHighIdx;
                    swingHighType[lookback] = pre_swingHighType[lookback];
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 1; i < CurrentBars[0] - lastHighIdx; i++)
                    {
                        if ((useHL ? Lows[0][i] : Closes[0][i]) < newLow)
                        {
                            newLow = (useHL ? Lows[0][i] : Closes[0][i]);
                            j = i;
                        }
                    }
                    currentLow = newLow;
                    priorSwingLowIdx = lastLowIdx;
                    lastLowIdx = CurrentBars[0] - j;
                }
                #endregion

                #region -- DWtrend --
                else if (updateLow)
                {
line=1913;
                    upTrend[0] = false;
                    pre_swingLowType[CurrentBars[0] - lastLowIdx] = 0;
                    currentLow = useHL ? Lows[0][1] : Closes[0][1];
                    lastLowIdx = CurrentBars[0] - 1;
                }
                #endregion

                #region re-init drawing states at each new bar before calculous
                drawHigherHighLabel = false;
                drawLowerHighLabel = false;
                drawDoubleTopLabel = false;
                drawLowerLowLabel = false;
                drawHigherLowLabel = false;
                drawDoubleBottomLabel = false;
                #endregion

                #region -- UP || HH --
                if (addHigh || updateHigh)
                {
line=1955;
                    int priorHighCount = CurrentBars[0] - priorSwingHighIdx;
                    highCount = CurrentBars[0] - lastHighIdx;
                    lowCount = CurrentBars[0] - lastLowIdx;

                    double marginUp = (useHL ? Highs[0][priorHighCount] : Closes[0][priorHighCount]) + MultiplierDTB * avgTrueRange[highCount];
                    double marginDown = (useHL ? Highs[0][priorHighCount] : Closes[0][priorHighCount]) - MultiplierDTB * avgTrueRange[highCount];

                    #region -- Set NEW drawing states --
line=1974;
                    if (currentHigh > marginUp) drawHigherHighLabel = true;
                    else if (currentHigh < marginDown) drawLowerHighLabel = true;
                    else drawDoubleTopLabel = true;

					if (currentHigh > marginUp)
                        pre_swingHighType[highCount] = 3;
                    else if (currentHigh < marginDown)
                        pre_swingHighType[highCount] = 1;
                    else
                        pre_swingHighType[highCount] = 2;
                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (addLow || updateLow)
                {
line=1994;
                    int priorLowCount = CurrentBars[0] - priorSwingLowIdx;
                    lowCount = CurrentBars[0] - lastLowIdx;
                    highCount = CurrentBars[0] - lastHighIdx;

                    double marginDown = (useHL ? Lows[0][priorLowCount] : Closes[0][priorLowCount]) - MultiplierDTB * avgTrueRange[lowCount];
                    double marginUp = (useHL ? Lows[0][priorLowCount] : Closes[0][priorLowCount]) + MultiplierDTB * avgTrueRange[lowCount];

                    #region -- Set NEW drawing states --
line=2013;
                    if (currentLow < marginDown) drawLowerLowLabel = true;
                    else if (currentLow > marginUp) drawHigherLowLabel = true;
                    else drawDoubleBottomLabel = true;

					if (currentLow < marginDown)
                        pre_swingLowType[lowCount] = -3;
                    else if (currentLow > marginUp)
                        pre_swingLowType[lowCount] = -1;
                    else
                        pre_swingLowType[lowCount] = -2;
                    #endregion
                }
                #endregion
            }
            #endregion
line=2032;
            #region if (Calculate != Calculate.OnBarClose)
            if (Calculate != Calculate.OnBarClose)
            {
                intraBarUpdateHigh = upTrend[0] && (useHL ? Highs[0][0] : Closes[0][0]) > currentHigh;
                intraBarUpdateLow = !upTrend[0] && (useHL ? Lows[0][0] : Closes[0][0]) < currentLow;
                intraBarAddHigh = !upTrend[0] && !((useHL ? Lows[0][0] : Closes[0][0]) < currentLow) && (useHL ? Highs[0][0] : Closes[0][0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                intraBarAddLow = upTrend[0] && !((useHL ? Highs[0][0] : Closes[0][0]) > currentHigh) && (useHL ? Lows[0][0] : Closes[0][0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

line=2043;
                #region -- new HH --
                if (intraBarAddHigh)
                {
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBars[0] - lastLowIdx; i++)
                    {
                        if ((useHL ? Highs[0][i] : Closes[0][i]) > newHigh)
                        {
                            newHigh = (useHL ? Highs[0][i] : Closes[0][i]);
                            j = i;
                        }
                    }
                    preCurrentHigh = newHigh;
                    preLastHighIdx = CurrentBars[0] - j;
                }
                #endregion

                #region -- uptrend --
                else if (intraBarUpdateHigh)
                {
line=2065;
                    preCurrentHigh = (useHL ? Highs[0][0] : Closes[0][0]);
                    preLastHighIdx = CurrentBars[0];
                }
                #endregion

line=2071;
                #region -- new LL --
                if (intraBarAddLow)
                {
line=2075;
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBars[0] - lastHighIdx; i++)
                    {
                        if ((useHL ? Lows[0][i] : Closes[0][i]) < newLow)
                        {
                            newLow = useHL ? Lows[0][i] : Closes[0][i];
                            j = i;
                        }
                    }
                    preCurrentLow = newLow;
                    preLastLowIdx = CurrentBars[0] - j;
                }
                #endregion

                #region -- dwtrend --
                else if (intraBarUpdateLow)
                {
line=2094;
                    preCurrentLow = (useHL ? Lows[0][0] : Closes[0][0]);
                    preLastLowIdx = CurrentBars[0];
                }
                #endregion

                #region -- UP || HH --
                if (intraBarAddHigh || intraBarUpdateHigh)
                {
line=2103;
                    int prePriorHighCount = intraBarAddHigh ? CurrentBars[0] - lastHighIdx : CurrentBars[0] - priorSwingHighIdx;
                    int preHighCount = CurrentBars[0] - preLastHighIdx;
                    int prePriorLowCount = CurrentBars[0] - priorSwingLowIdx;
                    int preLowCount = CurrentBars[0] - lastLowIdx;

line=2128;
                    #region ---- StructureBias RealTime ---
                    double marginUp, marginDown;
                    if (useHL)
                    {
                        marginUp = Highs[0][prePriorHighCount] + MultiplierDTB * avgTrueRange[preHighCount];
                        marginDown = Highs[0][prePriorHighCount] - MultiplierDTB * avgTrueRange[preHighCount];
                    }
                    else
                    {
                        marginUp = Closes[0][prePriorHighCount] + MultiplierDTB * avgTrueRange[preHighCount];
                        marginDown = Closes[0][prePriorHighCount] - MultiplierDTB * avgTrueRange[preHighCount];
                    }

                    if (preCurrentHigh > marginUp) preSRType = 3;//#STRBIAS
                    else if (preCurrentHigh < marginDown) preSRType = Math.Max(preSRType, 2);//#STRBIAS
                    else preSRType = Math.Max(preSRType, 1);//#STRBIAS
                    #endregion
                }
                #endregion

                #region -- DW || LL --
                else if (intraBarAddLow || intraBarUpdateLow)
                {
line=2152;
                    int prePriorLowCount = intraBarAddLow ? CurrentBars[0] - lastLowIdx : CurrentBars[0] - priorSwingLowIdx;
                    int preLowCount = CurrentBars[0] - preLastLowIdx;
                    int prePriorHighCount = CurrentBars[0] - priorSwingHighIdx;
                    int preHighCount = CurrentBars[0] - lastHighIdx;

line=2177;
                    #region ---- StructureBias RealTime ---
                    double marginUp, marginDown;
                    if (useHL)
                    {
                        marginDown = Lows[0][prePriorLowCount] - MultiplierDTB * avgTrueRange[preLowCount];
                        marginUp = Lows[0][prePriorLowCount] + MultiplierDTB * avgTrueRange[preLowCount];
                    }
                    else
                    {
                        marginDown = Closes[0][prePriorLowCount] - MultiplierDTB * avgTrueRange[preLowCount];
                        marginUp = Closes[0][prePriorLowCount] + MultiplierDTB * avgTrueRange[preLowCount];
                    }
                    if (preCurrentLow < marginDown) preSRType = -3;//#STRBIAS
                    else if (preCurrentLow > marginUp) preSRType = Math.Min(preSRType, -2);//#STRBIAS
                    else preSRType = Math.Min(preSRType, -1);//#STRBIAS
                    #endregion
                }
                #endregion

                //Is it possible ??
                else
                {
line=2200;
                    preSRType = 0;//#STRBIAS
                }

                #region ---- StructureBias RealTime ---
                if (CurrentBars[0] < 2) 
					structureBiasState[0] = 0;
                else
                {
line=2218;
                    if (preSRType == 0) structureBiasState[0] = structureBiasState[1];

                    #region -- Oscillation State --
                    else if (structureBiasState[1] == 0)
                    {
                        //Oscillation State
                        //Need HH/!LL/HH to go to Up Trend
                        //{NEW} !LL/High/!LL/HH to go to Up Trend
                        //Need LL/!HH/LL to go to Dw Trend
                        //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
                        if (sequence.Count < 2) structureBiasState[0] = 0;
                        else if (sequence.Count < 3)
                        {
line=2232;
                            if (sequence[0] == 3 && sequence[1] != -3 && preSRType == 3) structureBiasState[0] = 1;
                            else if (sequence[0] == -3 && sequence[1] != 3 && preSRType == -3) structureBiasState[0] = -1;
                            else structureBiasState[0] = 0;
                        }
                        else
                        {
line=2239;
                            if (sequence[1] == 3 && sequence[2] != -3 && preSRType == 3) structureBiasState[0] = 1;
                            else if (sequence[1] == -3 && sequence[2] != 3 && preSRType == -3) structureBiasState[0] = -1;
                            //{NEW} HL/LH/HL/HH to go to Up Trend
                            else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && preSRType == 3) structureBiasState[0] = 1;
                            //{NEW} LH/HL/LH/LL to go to Up Trend
                            else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && preSRType == -3) structureBiasState[0] = -1;
                            else structureBiasState[0] = 0;
                        }
                    }
                    #endregion

                    #region -- UpTrend State --
                    else if (structureBiasState[1] > 0)
                    {
line=2254;
                        //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
                        if (preSRType == -3) structureBiasState[0] = 0;
                        else structureBiasState[0] = 1;
                    }
                    #endregion

                    #region -- DwTrend State --
                    else if (structureBiasState[1] < 0)
                    {
line=2264;
                        //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
                        if (preSRType == 3) structureBiasState[0] = 0;
                        else structureBiasState[0] = -1;
                    }
                    #endregion

                    else structureBiasState[0] = structureBiasState[1];
                }
                #endregion
            }
            #endregion
			}
line=2284;
            #endregion

            #region --- init before having enough bars --- 
            if (CurrentBars[0] < BarsRequiredToPlot + 55 && BarsInProgress == 0)
            {
line=2385;
                structureBiasState[0] = 0;//#STRBIAS
                SRType = 0;//#STRBIAS
                swingHighsState[0] = 0;//#STRBIAS
                swingLowsState[0] = 0;//#STRBIAS
                return;
            }
            #endregion

line = 2341;
			if(BarsInProgress == 0 && CurrentBars[0]>2){
	            #region -- Structure BIAS --
	            SRType = drawHigherHighLabel ? 3 : drawLowerHighLabel ? 2 : drawDoubleTopLabel ? 1 : drawDoubleBottomLabel ? -1 : drawHigherLowLabel ? -2 : drawLowerLowLabel ? -3 : 0;
	            swingHighsState[0] = drawHigherHighLabel ? 3    : drawLowerHighLabel ? 2  : drawDoubleTopLabel ? 1 : 0;//#SWINGS for BH
    	        swingLowsState[0]  = drawDoubleBottomLabel ? -1 : drawHigherLowLabel ? -2 : drawLowerLowLabel ? -3 : 0;//#SWINGS for BH	

line = 2346;
	            #region -- Oscillation State --
	            int decay = 0;
	            if (Calculate!= Calculate.OnBarClose && State!=State.Historical) decay = 1;
	            if (SRType != 0 && structureBiasState[decay + 1] == 0)
	            {
line = 2347;
	                #region -- update sequence ---
	                //--- Same Trend --
	                if (upTrend[1] == upTrend[0])
	                {
	                    if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }

	                //--- Changing Trend ---
	                else if (Calculate == Calculate.OnBarClose && upTrend[1] != upTrend[0])
	                {
line = 2348;
	                    if (sequence.Count < 4) sequence.Add(SRType);
	                    else
	                    {
	                        sequence[0] = sequence[1];
	                        sequence[1] = sequence[2];
	                        sequence[2] = sequence[3];
	                        sequence[3] = SRType;
	                    }
	                }
	                #region -- eachtick --
	                else if (Calculate != Calculate.OnBarClose && upTrend[1] != upTrend[0])
	                {
line = 2349;
	                    if (IsFirstTickOfBar)
	                    {
	                        if (sequence.Count < 4) sequence.Add(SRType);
	                        else
	                        {
	                            sequence[0] = sequence[1];
	                            sequence[1] = sequence[2];
	                            sequence[2] = sequence[3];
	                            sequence[3] = SRType;
	                        }
	                    }
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                #endregion
	                #endregion

line = 2350;
					//Oscillation State
					//Need HH/!LL/HH to go to Up Trend
					//{NEW} !LL/High/!LL/HH to go to Up Trend
					//Need LL/!HH/LL to go to Dw Trend
					//{NEW} !HH/Low/!HH/LL to go to Dw Trend				
					if (sequence.Count < 3) structureBiasState[decay] = 0;
	                else if (sequence.Count < 4)
	                {
line = 2351;
						if (sequence[0] == 3 && sequence[1] != -3 && sequence[2] == 3) structureBiasState[decay] = 1;
						else if (sequence[0] == -3 && sequence[1] != 3 && sequence[2] == -3) structureBiasState[decay] = -1;
						else structureBiasState[decay] = 0;
	                }
	                else
	                {
line = 2352;
						if (sequence[1] == 3 && sequence[2] != -3 && sequence[3] == 3) structureBiasState[decay] = 1;
						else if (sequence[1] == -3 && sequence[2] != 3 && sequence[3] == -3) structureBiasState[decay] = -1;
						//{NEW} HL/LH/HL/HH to go to Up Trend
						else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && sequence[3] == 3) structureBiasState[decay] = 1;
						//{NEW} LH/HL/LH/LL to go to Up Trend
						else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && sequence[3] == -3) structureBiasState[decay] = -1;
						else structureBiasState[decay] = 0;
	                }
	            }
	            #endregion

	            #region -- UpTrend State --
	            else if (SRType != 0 && structureBiasState[decay + 1] > 0)
	            {
line = 2353;
	                if (IsFirstTickOfBar) sequence.Clear();
	                //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
	                if (SRType == -3)
	                {
	                    structureBiasState[decay] = 0;
	                    if (IsFirstTickOfBar) sequence.Add(SRType);
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                else structureBiasState[decay] = 1;
	            }
	            #endregion

	            #region -- DwTrend State --
	            else if (SRType != 0 && structureBiasState[decay + 1] < 0)
	            {
line = 2354;
	                if (IsFirstTickOfBar) sequence.Clear();
	                //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
	                if (SRType == 3)
	                {
	                    structureBiasState[decay] = 0;
	                    if (IsFirstTickOfBar) sequence.Add(SRType);
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                else structureBiasState[decay] = -1;
	            }
	            #endregion
				if(SRType == 3) StructureState = 'L';
				else if(SRType == -3) StructureState = 'S';

				if(StructureState == 'L') structureBiasState[decay] = 1;
				else if(StructureState == 'S') structureBiasState[decay] = -1;
	            else {
line = 2355;
					structureBiasState[decay] = structureBiasState[decay + 1];
//Print(line+":   structBiasState[decay]: "+structureBiasState[decay]);
				}
line = 2356;
	            #endregion
//				if(structureBiasState[decay] > 0) BackBrushes[0]=Brushes.Lime;
//				if(structureBiasState[decay] < 0) BackBrushes[0]=Brushes.Magenta;
			}
}catch(Exception e){Print(line+": "+e.ToString());}
        }
//===================================================================================================================

        #region -- Properties ------------------------------------------------------------
		#region -- Timeframe --
		//[NinjaScriptProperty]
		[Display(Name = "Bar basis", GroupName = "Timeframe", Description = "", Order = 5)]
		public ARC_MTFilter_BarBasis pBarBasis {get;set;}

		//[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Minute bar period", GroupName = "Timeframe", Description = "", Order = 10)]
		public int pMinuteBarPeriod {get;set;}

		//[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Range bar period", GroupName = "Timeframe", Description = "", Order = 20)]
		public int pRangeBarSize {get;set;}

		//[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Renko bar period", GroupName = "Timeframe", Description = "", Order = 30)]
		public int pRenkoBarSize {get;set;}

		//[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "BXT bar Size", GroupName = "Timeframe", Description = "", Order = 40)]
		public int pBXTSize {get;set;}

		//[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "BXT bar Offset", GroupName = "Timeframe", Description = "", Order = 50)]
		public int pBXTOffset {get;set;}

		//[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "BXT bar Reversal", GroupName = "Timeframe", Description = "", Order = 60)]
		public int pBXTReverse {get;set;}
		#endregion

		#region GroupName = "Parameters"
        //[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Period Bollinger Band", GroupName = "Parameters", Description = "Band Period for Bollinger Band", Order = 10)]
        public int BandPeriod { get; set; }

        //[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Fast EMA", GroupName = "Parameters", Description = "Period for fast EMA", Order = 20)]
        public int pFast { get; set; }

        //[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Slow EMA", GroupName = "Parameters", Description = "Period for slow EMA", Order = 30)]
        public int pSlow { get; set; }

        //[NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Std. dev. multiplier", GroupName = "Parameters", Description = "Number of standard deviations for MACD cloud", Order = 40)]
        public double StdDevNumber { get; set; }

        //[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Swing Strength", GroupName = "Parameters", Description = "Period for slow EMA", Order = 50)]
        public int pSwingStrength { get; set; }
        //[NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Deviation multiplier", GroupName = "Parameters", Description = "Multiplier used to calculate minimum deviation as an ATR multiple", Order = 60)]
        public double MultiplierMD { get; set; }

        //[NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Sensitivity double tops/bottoms", GroupName = "Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 70)]
        public double MultiplierDTB { get; set; }

		#endregion

		#region -- Requirements --
		//[NinjaScriptProperty]
		[Display(Name = "Histo above / below zero", GroupName = "Requirements", Description = "", Order = 10)]
		public bool pRequireHisto_PosNeg {get;set;}
		//[NinjaScriptProperty]
		[Display(Name = "BB+Histo confluence", GroupName = "Requirements", Description = "", Order = 20)]
		public bool pRequireBBHisto_Confluence {get;set;}
		//[NinjaScriptProperty]
		[Display(Name = "BB above upper / below lower", GroupName = "Requirements", Description = "", Order = 30)]
		public bool pRequireBB_AboveUpperBelowLower {get;set;}
//		//[NinjaScriptProperty]
//		[Display(Name = "BB above lower / below upper", GroupName = "Requirements", Description = "", Order = 35)]
//		public bool pRequireBB_AboveLowerBelowUpper {get;set;}
		//[NinjaScriptProperty]
		[Display(Name = "BB above/below midline", GroupName = "Requirements", Description = "", Order = 40)]
		public bool pRequireBB_AboveBelowMidline {get;set;}
		//[NinjaScriptProperty]
		[Display(Name = "BB above/below zeroline", GroupName = "Requirements", Description = "", Order = 50)]
		public bool pRequireBB_AboveBelowZeroline {get;set;}
		//[NinjaScriptProperty]
		[Display(Name = "Fast MA above/below Slow MA", GroupName = "Requirements", Description = "", Order = 60)]
		public bool pRequireMA_FastAboveBelowSlow {get;set;}
		//[NinjaScriptProperty]
		[Display(Name = "Close Price above/below Fast MA", GroupName = "Requirements", Description = "", Order = 70)]
		public bool pRequireClosePrice_AboveBelowFastMA {get;set;}
		//[NinjaScriptProperty]
		[Display(Name = "Close Price above/below Slow MA", GroupName = "Requirements", Description = "", Order = 80)]
		public bool pRequireClosePrice_AboveBelowSlowMA {get;set;}
		//[NinjaScriptProperty]
		[Display(Name = "Full price bar above/below Fast MA", GroupName = "Requirements", Description = "", Order = 90)]
		public bool pRequireFullBar_AboveBelowFastMA {get;set;}
		//[NinjaScriptProperty]
		[Display(Name = "Full price bar above/below Slow MA", GroupName = "Requirements", Description = "", Order = 100)]
		public bool pRequireFullBar_AboveBelowSlowMA {get;set;}
		//[NinjaScriptProperty]
		[Display(Name = "Swing structure", GroupName = "Requirements", Description = "", Order = 110)]
		public bool pRequireSwingStructure {get;set;}

        //[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Fast MA period", GroupName = "Requirements", Description = "Period for fast EMA", Order = 120)]
        public int pFastMA { get; set; }

		//[NinjaScriptProperty]
		[Display(Name = "Fast MA Type", GroupName = "Requirements", Description = "", Order = 130)]
		public ARC_MTFilter_MAType pFastMAType  {get;set;}

        //[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Slow MA period", GroupName = "Requirements", Description = "Period for slow EMA", Order = 140)]
        public int pSlowMA { get; set; }

		//[NinjaScriptProperty]
		[Display(Name = "Slow MA Type", GroupName = "Requirements", Description = "", Order = 150)]
		public ARC_MTFilter_MAType pSlowMAType  {get;set;}
		#endregion

		#region -- Visual Parameters --
		private Brush pUpTrendBrush = Brushes.Green;
		[XmlIgnore()]
		[Display(Order = 10, Name = "Uptrend", Description = "", GroupName = "Visual Parameters")]       
		public Brush UpTrendBrush{
		    get { return pUpTrendBrush; }
		    set { pUpTrendBrush = value; }
		}
					[Browsable(false)]
					public string pUpTrendBrushSerialize{
						get { return Serialize.BrushToString(pUpTrendBrush); }
						set { pUpTrendBrush = Serialize.StringToBrush(value); }
					}
        [Range(0, 100)]
        [Display(Name = "Uptrend Opacity", GroupName = "Visual Parameters", Description = "", Order = 20)]
		public int pUpTrendOpacity {get;set;}

		private Brush pDownTrendBrush = Brushes.Red;
		[XmlIgnore()]
		[Display(Order = 30, Name = "Downtrend", Description = "", GroupName = "Visual Parameters")]       
		public Brush DownTrendBrush{
		    get { return pDownTrendBrush; }
		    set { pDownTrendBrush = value; }
		}
					[Browsable(false)]
					public string pDownTrendBrushSerialize{
						get { return Serialize.BrushToString(pDownTrendBrush); }
						set { pDownTrendBrush = Serialize.StringToBrush(value); }
					}
        [Range(0, 100)]
        [Display(Name = "Downtrend Opacity", GroupName = "Visual Parameters", Description = "", Order = 40)]
		public int pDownTrendOpacity {get;set;}

        [Display(Name = "Extend stripes vertically", GroupName = "Visual Parameters", Description = "", Order = 50)]
		public bool pExtendRacingStripes {get;set;}
        #endregion

		#region GroupName = "SwingTrend Parameters"
//        //[NinjaScriptProperty]
//        [Range(1, int.MaxValue)]
//        [Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 0)]
//        public int pSwingStrength { get; set; }

//        //[NinjaScriptProperty]
//        [Range(0, double.MaxValue)]
//        [Display(Name = "Deviation multiplier", GroupName = "SwingTrend Parameters", Description = "Multiplier used to calculate minimum deviation as an ATR multiple", Order = 1)]
//        public double MultiplierMD { get; set; }

//        //[NinjaScriptProperty]
//        [Range(0, double.MaxValue)]
//        [Display(Name = "Sensitivity double tops/bottoms", GroupName = "SwingTrend Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 2)]
//        public double MultiplierDTB { get; set; }
        #endregion

        //--end--
        #endregion
    }
}
public enum ARC_MTFilter_BarBasis {Chart, Minute, Range, Renko, RenkoBXT }
public enum ARC_MTFilter_MAType {SMA, EMA}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_MTFilter[] cacheARC_MTFilter;
		public ARC.ARC_MTFilter ARC_MTFilter()
		{
			return ARC_MTFilter(Input);
		}

		public ARC.ARC_MTFilter ARC_MTFilter(ISeries<double> input)
		{
			if (cacheARC_MTFilter != null)
				for (int idx = 0; idx < cacheARC_MTFilter.Length; idx++)
					if (cacheARC_MTFilter[idx] != null &&  cacheARC_MTFilter[idx].EqualsInput(input))
						return cacheARC_MTFilter[idx];
			return CacheIndicator<ARC.ARC_MTFilter>(new ARC.ARC_MTFilter(), input, ref cacheARC_MTFilter);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_MTFilter ARC_MTFilter()
		{
			return indicator.ARC_MTFilter(Input);
		}

		public Indicators.ARC.ARC_MTFilter ARC_MTFilter(ISeries<double> input )
		{
			return indicator.ARC_MTFilter(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_MTFilter ARC_MTFilter()
		{
			return indicator.ARC_MTFilter(Input);
		}

		public Indicators.ARC.ARC_MTFilter ARC_MTFilter(ISeries<double> input )
		{
			return indicator.ARC_MTFilter(input);
		}
	}
}

#endregion
