#define DoLicense
#define MODERATORS

//#define SPEECHENABLED
// 
// Copyright (C) 2011, SBG Trading Corp.   www.affordableindicators.com
// Use this indicator/strategy at your own risk.  No warranty expressed or implied.
// Trading financial instruments is risky and can result in substantial loss.
// The owner of this indicator/strategy holds harmless SBG Trading Corp. from any 
// and all trading losses incurred while using this indicator/strategy.
//
//
#region Using declarations
using System;
using System.Collections.Generic;
//using System.Diagnostics;
//using System.Drawing;
//using System.Drawing.Drawing2D;
using System.ComponentModel;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#if SPEECHENABLED
using SpeechLib;
using System.Reflection;
using System.Threading;
#endif
#endregion
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using NinjaTrader.Gui;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using SharpDX.DirectWrite;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Windows.Media;
using System.Linq;
//using System.Speech.Synthesis;
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    [CategoryOrder("Parameters", 10)]
    [CategoryOrder("Alert", 20)]
    [CategoryOrder("Visuals", 30)]
#if SPEECHENABLED
	public delegate void SpeechDelegate_ARC_LineAlert(string str);
	[Description("Speak a phrase, play alert WAV and/or draw a chart marker when a manually drawn trendline is hit")]
#else
	[Description("Play alert WAV and/or draw a chart marker when a manually drawn trendline is hit")]
#endif
//		[Gui.Design.DisplayName("Flux Alert on trendline hit")]
//		public class ARC_LineAlert : Indicator
	public class ARC_LineAlert : Indicator
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "LineAlert";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "21742", "27405"};//27405 is Annual Membership
		private string indicatorVersion = "v1.0";
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		private class TheLine {
			public string Tag="";
			public string Type = "Ray";
			public int StartBar=0;
			public int EndBar=1;
			public double StartPrice=0;
			public double EndPrice=0;
			public double CurrentUpperAlertPrice = 0;
			public double CurrentLinePrice = 0;
			public double CurrentLowerAlertPrice = 0;
			public Color ColorOfLine = Colors.Transparent;
			public TheLine(string tag, string drawType, int startbar, int endbar, double startprice, double endprice, System.Windows.Media.Color colorofline) {this.Tag=tag;this.Type=drawType;this.StartBar=startbar;this.EndBar=endbar;this.StartPrice=startprice;this.EndPrice=endprice; this.ColorOfLine=colorofline;}
		}
		#region Variables
			// Wizard generated variables
			private bool RunInit = true;
			private int EmailBar = -1;
			private double priorprice = 0, price = 0;
			private string TagOfCrossedLine = null;
			private int CrossDirection = 0;
			private string NewMsg = null;
			private Dictionary<string,double> Lines = new Dictionary<string,double>();
			private string[] Msgs = new String[3]{string.Empty,string.Empty,string.Empty};
			//private Pen ThePen;
//			private StringFormat	stringFormat	= new StringFormat();
			private DateTime TimeOfText = DateTime.MaxValue;
			private double NearestAbove = double.MaxValue;
			private double NearestBelow = double.MaxValue;
			private string NearestAboveTag = null;
			private string NearestBelowTag = null;
			private float lineval1=0, lineval2=0, lineval2zupper=0, lineval2zlower=0;
			private string AlertMsg = "";
			private bool SpeechEnabled = false;

			private string FS = null;
		#endregion
		private int CrossingsThisBar = 0;
		private string NearestUpperWAV = string.Empty;
		private string NearestLowerWAV = string.Empty;
		private List<TheLine> TheCO = new List<TheLine>();
		private Series<double> input;
		private int PopupBar = -1;
		private string Id = @"N/A";
		private List<string> TagsOfLinesHit = new List<string>();
		private DateTime MsgPrintTime = DateTime.MinValue;
		private double ZoneSizePts = 0;
		private SortedDictionary<string,int> AlertsPerLine = new SortedDictionary<string,int>();
		private Brush tempbrush;
		private SharpDX.Direct2D1.Brush NearLineDXBrush    =null;
		private SharpDX.Direct2D1.Brush DistantLineDXBrush =null;
		private SharpDX.Direct2D1.Brush LineDXBrush        =null;
		private SharpDX.Direct2D1.Brush GoldenrodDXBrush =null;

#if SPEECHENABLED
		static Assembly SpeechLib = null;
#endif
		/// <summary>
		/// This method is used to configure the indicator and is called once before any bar data is loaded.
		/// </summary>
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				bool IsBen = System.IO.File.Exists("c:\\222222222222.txt");
				IsBen = IsBen && (NinjaTrader.Cbi.License.MachineId.CompareTo("CB15E08BE30BC80628CFF6010471FA2A")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
				Calculate   = Calculate.OnPriceChange;
				IsChartOnly = true;
				IsOverlay   = true;
				IsAutoScale = false;
				Name = "ARC_LineAlert";
			}

			if (State == State.Configure) {
				IsDebug = System.IO.File.Exists(@"c:\222222222222.txt") && (NinjaTrader.Cbi.License.MachineId.CompareTo("1E53E271B82EC62C7C03A15C336229AE")==0 || NinjaTrader.Cbi.License.MachineId.CompareTo("766C8CD2AD83CA787BCA6A2A76B2303B")==0);
				#region DoLicense call
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
				#endregion
#if SPEECHENABLED
				string dll = System.IO.Path.Combine(System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","custom"),"interop.speechlib.dll");   //"c:\users\ben\Documents\NinjaTrader 8\"
				if(System.IO.File.Exists(dll)) {
					SpeechEnabled = true;
					SpeechLib = Assembly.LoadFile(dll);
				}
#endif
				NearestUpperWAV = this.DefaultSoundFileName;
				NearestLowerWAV = this.DefaultSoundFileName;
				if(Instrument!=null && Bars!=null) Id = MakeString(new Object[]{Instrument.FullName.ToString()," (",Bars.BarsPeriod.ToString(),")"});
				tempbrush = pLineBrush.Clone();
				tempbrush.Opacity = 100.0;
				tempbrush.Freeze();
			}
			if (State == State.DataLoaded){
				input = new Series<double>(this);//inside State.DataLoaded
				ZoneSizePts = pZoneSizeTicks*TickSize;
			}
		}
//===============================================================================================
 		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(pDataSource == DataSource_ARC_LineAlert.Price)		input[0] = (Close[0]); 
			else if(pDataSource == DataSource_ARC_LineAlert.Volume)	input[0] = (Volume[0]);
			else input[0] = Input[0];

			if(IsFirstTickOfBar) {
				CrossingsThisBar = 0;
				TagsOfLinesHit.Clear();
			}
			if(Calculate == Calculate.OnBarClose) priorprice=input[1];
			else priorprice = price;
			price = input[0];
			if(price != priorprice && State != State.Historical) {
				ARC_LineAlert_Engine(ref NearestUpperWAV, ref NearestLowerWAV);
			}

			if(TimeOfText != DateTime.MaxValue) {
				TimeSpan ts = new TimeSpan(Math.Abs(TimeOfText.Ticks-NinjaTrader.Core.Globals.Now.Ticks));
				if(ts.TotalSeconds>5) RemoveDrawObject("infomsg");
				else Draw.TextFixed(this, "infomsg",AlertMsg,TextPosition.Center);
			}
		}

//====================================================================================================
		#region SayItPlayIt methods
		private void PlayIt(string EncodedTag) {
			string[] elements = EncodedTag.Split(new char[]{':'}, StringSplitOptions.None);
			if(elements.Length>0) {
				string wavname = elements[elements.Length-1].ToLower().Trim();
				if(wavname.Length>0){
					if(!wavname.Contains(".wav")) wavname = wavname + ".wav";
					if(pPrintToAlertsWindow)
						Alert(CurrentBar.ToString(),pAlertPriority,NewMsg,AddSoundFolder(wavname),1,Brushes.Blue,Brushes.White);  
					else
						PlaySound(AddSoundFolder(wavname));
				}
				TimeOfText = NinjaTrader.Core.Globals.Now;
				AlertMsg = MakeString(new Object[]{"WAV file ",wavname," played"});
			}
		}
#if SPEECHENABLED
		private static void SayItThread (string WhatToSay) {
			if(WhatToSay.Length>0) {
				SpVoice voice = new SpVoice();
				// Tells the program to speak everything in the textbox using Default settings
				voice.Speak(WhatToSay, SpeechVoiceSpeakFlags.SVSFDefault);
			}
		}
		private void SayIt (string EncodedTag, double Price) {
			if(!SpeechEnabled) {
				TimeOfText  = NinjaTrader.Core.Globals.Now;
				AlertMsg = "Speech not available\nPut Interop.SpeechLib.DLL into 'bin\\Custom' folder and restart the platform";
				return;
			}
			string[] elements = EncodedTag.Split(new char[]{':'}, StringSplitOptions.None);
			if(elements.Length>0) {
				SpeechDelegate_ARC_LineAlert speechThread = new SpeechDelegate_ARC_LineAlert(SayItThread);
				string SayThis = elements[elements.Length-1].ToUpper();
				if(SayThis.Contains("[SAYPRICE]")) {
					string pricestr1 = Instrument.MasterInstrument.FormatPrice(Price);
					string spokenprice = string.Empty + pricestr1[0];
					int i = 0;
					while(i<pricestr1.Length) {
						spokenprice = MakeString(new Object[]{spokenprice," ",pricestr1[i++]});
						spokenprice = spokenprice.Replace(".","point");
					}
					SayThis = SayThis.Replace("[SAYPRICE]", spokenprice);
				}
				speechThread.BeginInvoke(SayThis, null, null);
				TimeOfText  = NinjaTrader.Core.Globals.Now;
				AlertMsg = MakeString(new Object[]{"'",SayThis,"' was spoken"});
			}
		}
#else
		private void SayIt (string EncodedTag) {}
		private void SayIt (string EncodedTag, double Price) {}
#endif
		#endregion
//====================================================================================================
		private void ARC_LineAlert_Engine(ref string NearestUpperWAV, ref string NearestLowerWAV){

//try{
			double CrossedAt = double.MinValue;
			TheCO.Clear();
			double p1 = 0;
			double p2 = 0;
			DateTime t1 = DateTime.MinValue;
			DateTime t2 = DateTime.MinValue;
			int b1 = 0;
			int b2 = 0;
			var objs = DrawObjects.Where(k=> k.ToString().Contains(".HorizontalLine")).ToList();//Only horizontal lines are valid for ARC_LineAlert
			foreach (dynamic CO in objs)
			{
				bool IsHLine = CO.ToString().Contains(".HorizontalLine");
				bool IsLine = CO.ToString().Contains(".ExtendedLine") || CO.ToString().Contains(".Line");
				bool IsRay = CO.ToString().Contains(".Ray");
				if(IsHLine || IsLine || IsRay) {
					if(pTrendlineTag.Length>0 && !CO.Tag.ToLower().Contains(pTrendlineTag.ToLower())) continue;
				}
				if(IsRay) {
					p1 = CO.StartAnchor.Price;
					t1 = CO.StartAnchor.Time;
					b1 = Bars.GetBar(t1);
					p2 = CO.EndAnchor.Price;
					t2 = CO.EndAnchor.Time;
					b2 = Bars.GetBar(t2);
					double slope = (p2 - p1)/Math.Abs(b1-b2);
					bool permit1 = slope>0  && (pFilterDirection == TrendDirection_ARC_LineAlert.Up || pFilterDirection == TrendDirection_ARC_LineAlert.UpAndHorizontal);
					bool permit2 = slope<0  && (pFilterDirection == TrendDirection_ARC_LineAlert.Down || pFilterDirection == TrendDirection_ARC_LineAlert.DownAndHorizontal);
					bool permit3 = slope==0 && (pFilterDirection == TrendDirection_ARC_LineAlert.UpAndHorizontal || pFilterDirection == TrendDirection_ARC_LineAlert.DownAndHorizontal || pFilterDirection == TrendDirection_ARC_LineAlert.Horizontal);
					if(permit1 || permit2 || permit3 || pFilterDirection == TrendDirection_ARC_LineAlert.All)
						TheCO.Add(new TheLine(CO.Tag, CO.Name, b1, b2, p1, p2, Colors.Red));
				}
				if(IsHLine) {
					p1 = CO.StartAnchor.Price;
					t1 = CO.StartAnchor.Time;
					b1 = Bars.GetBar(t1);
					bool permit1 = pFilterDirection == TrendDirection_ARC_LineAlert.Horizontal || pFilterDirection == TrendDirection_ARC_LineAlert.UpAndHorizontal || pFilterDirection == TrendDirection_ARC_LineAlert.DownAndHorizontal;
					if(permit1 || pFilterDirection == TrendDirection_ARC_LineAlert.All)
						TheCO.Add(new TheLine(CO.Tag, CO.Name, CurrentBar-1, CurrentBar-2, p1, p1, Colors.Red));
				}
				if(IsLine) {
					p1 = CO.StartAnchor.Price;
					t1 = CO.StartAnchor.Time;
					b1 = Bars.GetBar(t1);

					p2 = CO.EndAnchor.Price;
					t2 = CO.EndAnchor.Time;
					b2 = Bars.GetBar(t2);

					double slope = (p2 - p1)/Math.Abs(b1-b2);
					bool permit1 = slope>0 && (pFilterDirection == TrendDirection_ARC_LineAlert.Up || pFilterDirection == TrendDirection_ARC_LineAlert.UpAndHorizontal);
					bool permit2 = slope<0 && (pFilterDirection == TrendDirection_ARC_LineAlert.Down || pFilterDirection == TrendDirection_ARC_LineAlert.DownAndHorizontal);
					bool permit3 = slope==0 && (pFilterDirection == TrendDirection_ARC_LineAlert.UpAndHorizontal || pFilterDirection == TrendDirection_ARC_LineAlert.DownAndHorizontal || pFilterDirection == TrendDirection_ARC_LineAlert.Horizontal);
					bool permit4 = true;
					if(CO.ToString().EndsWith(".Line")) permit4 = Math.Max(b1,b2)>=CurrentBar;
					if(permit4 && (permit1 || permit2 || permit3 || pFilterDirection == TrendDirection_ARC_LineAlert.All)){
						TheCO.Add(new TheLine(CO.Tag, CO.ToString(), b1, b2, p1, p2, Colors.Red));
					}
				}
			}
//			if(pFilterDirection == TrendDirection_ARC_LineAlert.Horizontal || pFilterDirection == TrendDirection_ARC_LineAlert.UpAndHorizontal || pFilterDirection == TrendDirection_ARC_LineAlert.DownAndHorizontal || pFilterDirection == TrendDirection_ARC_LineAlert.All) {
//				if(this.pAlertLevel1>-9999) TheCO.Add(new TheLine("AlertLevel1", "Line", 0, 1, this.pAlertLevel1, this.pAlertLevel1, Colors.Transparent));
//				if(this.pAlertLevel2>-9999) TheCO.Add(new TheLine("AlertLevel2", "Line", 0, 1, this.pAlertLevel2, this.pAlertLevel2, Colors.Transparent));
//				if(this.pAlertLevel3>-9999) TheCO.Add(new TheLine("AlertLevel3", "Line", 0, 1, this.pAlertLevel3, this.pAlertLevel3, Colors.Transparent));
//			}

			NearestAbove = double.MaxValue;
			NearestBelow = double.MaxValue;
			NearestAboveTag = null;
			NearestBelowTag = null;
			string LineDesc = string.Empty;

			foreach(TheLine CO in TheCO) 
			{
//try{
//Print(MakeString(new Object[]{CO.NinjaTrader.NinjaScript.DrawingTools.ToString()," found on ",CO.GetType(),", with a tag of: ",CO.Tag}));
				if (CO.Type.Contains("Ray"))            CO.CurrentLinePrice = CalculateDistance(input[0], CO.StartBar, CO.EndBar, CO.StartPrice, CO.EndPrice, ref NearestAbove, ref NearestBelow, "Ray ", CO.Tag, ref NearestAboveTag, ref NearestBelowTag);
				if (CO.Type.Contains("HorizontalLine")) CO.CurrentLinePrice = CalculateDistance(input[0], CO.StartBar, CO.StartBar-1, CO.StartPrice, CO.StartPrice, ref NearestAbove, ref NearestBelow, "HLine ", CO.Tag, ref NearestAboveTag, ref NearestBelowTag);
				if (CO.Type.Contains("ExtendedLine"))   CO.CurrentLinePrice = CalculateDistance(input[0], CO.StartBar, CO.EndBar, CO.StartPrice, CO.EndPrice, ref NearestAbove, ref NearestBelow, "Line ", CO.Tag, ref NearestAboveTag, ref NearestBelowTag);
				if (CO.Type.Contains("Line"))           CO.CurrentLinePrice = CalculateDistance(input[0], CO.StartBar, CO.EndBar, CO.StartPrice, CO.EndPrice, ref NearestAbove, ref NearestBelow, "Line ", CO.Tag, ref NearestAboveTag, ref NearestBelowTag);
				CO.CurrentUpperAlertPrice = CO.CurrentLinePrice + ZoneSizePts;
				CO.CurrentLowerAlertPrice = CO.CurrentLinePrice - ZoneSizePts;
//}catch(Exception err){Print(Name+":  Engine2: "+err.ToString());}
			}
			TagOfCrossedLine = string.Empty;
			foreach (TheLine L in TheCO) {
				if(priorprice <= L.CurrentLowerAlertPrice && price > L.CurrentLowerAlertPrice){// && !TagsOfLinesHit.Contains(L.Tag)) {
//					TagsOfLinesHit.Add(L.Tag);
					TagOfCrossedLine = L.Tag;
					if(!AlertsPerLine.ContainsKey(TagOfCrossedLine)) AlertsPerLine[TagOfCrossedLine] = 0;
					CrossDirection = 1;
					if(L.Tag.StartsWith("AlertLevel"))
						LineDesc = L.Tag;
					else {
						if(L.StartPrice < L.EndPrice)
							LineDesc = "Up Trendline";
						else if(L.StartPrice > L.EndPrice)
							LineDesc = "Down Trendline";
						else
							LineDesc = L.Type.ToString();//L.Tag;
					}
					CrossedAt = L.CurrentLowerAlertPrice;
	//Print(NinjaTrader.Core.Globals.Now.ToString()+" above Crossed UP, prior tick: "+priorprice+" line="+lineprice+"  price="+currentprice);
				}
				if(/*pDataSource == DataSource_ARC_LineAlert.Price &&*/ priorprice>=L.CurrentUpperAlertPrice && price<L.CurrentUpperAlertPrice){// && !TagsOfLinesHit.Contains(L.Tag)) {
					TagOfCrossedLine = L.Tag;
					if(!AlertsPerLine.ContainsKey(TagOfCrossedLine)) AlertsPerLine[TagOfCrossedLine] = 0;
					CrossDirection = -1;
					if(L.Tag.StartsWith("AlertLevel"))
						LineDesc = L.Tag;
					else {
						if(L.StartPrice < L.EndPrice)
							LineDesc = "Up Trendline";
						else if(L.StartPrice > L.EndPrice)
							LineDesc = "Down Trendline";
						else
							LineDesc = L.Type.ToString();//L.Tag;
					}
					CrossedAt = L.CurrentUpperAlertPrice;
	//Print(NinjaTrader.Core.Globals.Now.ToString()+" above Crossed DOWN, prior tick: "+priorprice+" line="+lineprice+"  price="+currentprice);
				}
			}
			bool ValidSignal = false;
			if(TheCO.Count>0 && LineDesc.Length>0 && CrossingNow(price, priorprice, NearestAbove, NearestBelow, NearestAboveTag, NearestBelowTag, ref CrossedAt)) {
				NewMsg = MakeString(new Object[]{Id," has hit '",LineDesc,"' at ",Instrument.MasterInstrument.FormatPrice(CrossedAt)});
				CrossingsThisBar++;
				AlertsPerLine[TagOfCrossedLine] = AlertsPerLine[TagOfCrossedLine] + 1;
				bool c1 = AlertsPerLine[TagOfCrossedLine]<=this.pMaxAlertsPerLine;
				if((int)pSignalType >=9 && (int)pSignalType <=13 && CrossingsThisBar <= pMaxAlertsPerBar && State != State.Historical) {
					if(c1){
						PopupBar = CurrentBar;
						Log(string.Concat(NinjaTrader.Core.Globals.Now.ToString(),"  ",NewMsg),LogLevel.Alert);
					}
				}
				else if(CrossingsThisBar <= pMaxAlertsPerBar) { 
					if(c1 && (int)pSignalType>=4) {
						if(TagOfCrossedLine.ToLower().Contains("say"))       SayIt(TagOfCrossedLine, price);
						else if(TagOfCrossedLine.ToLower().Contains("play")) PlayIt(TagOfCrossedLine);
						else if(pSoundFileName.Length>0){
							if(pPrintToAlertsWindow)
								Alert(NinjaTrader.Core.Globals.Now.ToString(), pAlertPriority, Bars.BarsPeriod.ToString()+": Line hit at "+Instrument.MasterInstrument.FormatPrice(CrossedAt),AddSoundFolder(pSoundFileName),1,Brushes.Blue,Brushes.White);  
							else
								PlaySound(AddSoundFolder(AddSoundFolder(pSoundFileName)));
						}
					}
				}
				if(c1 && (int)pSignalType !=4 && (int)pSignalType !=9){
					DrawSymbol((int)pSignalType);
				}

				if(c1 && EmailBar+pEmailFrequency < CurrentBar && pSendEmails && NewMsg!=null) {
					SendMail(pEmailAddress, MakeString(new Object[]{"ARC_LineAlert on ",Id," at ",Instrument.MasterInstrument.FormatPrice(CrossedAt)}),NewMsg);
					EmailBar = CurrentBar;
					TimeOfText = NinjaTrader.Core.Globals.Now;
					AlertMsg = MakeString(new Object[]{"Email message sent to ",pEmailAddress});
				}
			}
			if(NewMsg != null) {
				if(pTextMsgPosition != TextPosition_ARC_LineAlert_local.None) {
					MsgPrintTime = DateTime.Now;
					//Print(NewMsg);

//					Msgs[2] = Msgs[1];
//					Msgs[1] = Msgs[0];
//					Msgs[0] = NewMsg+Environment.NewLine;
//					NewMsg = null;

//					if(pTextMsgPosition == TextPosition_ARC_LineAlert_local.TopRight)
//						Draw.TextFixed(this, "MsgList",MakeString(new Object[]{Msgs[0],Msgs[1],Msgs[2]}), TextPosition.TopRight);
//					else if(pTextMsgPosition == TextPosition_ARC_LineAlert_local.TopLeft)
//						Draw.TextFixed(this, "MsgList",MakeString(new Object[]{Environment.NewLine,Msgs[0],Msgs[1],Msgs[2]}), TextPosition.TopLeft);
//					else if(pTextMsgPosition == TextPosition_ARC_LineAlert_local.BottomRight)
//						Draw.TextFixed(this, "MsgList",MakeString(new Object[]{Msgs[0],Msgs[1],Msgs[2]}), TextPosition.BottomRight);
//					else if(pTextMsgPosition == TextPosition_ARC_LineAlert_local.BottomLeft)
//						Draw.TextFixed(this, "MsgList",MakeString(new Object[]{Msgs[0],Msgs[1],Msgs[2],Environment.NewLine,"\t"}), TextPosition.BottomLeft);
//					else if(pTextMsgPosition == TextPosition_ARC_LineAlert_local.Center)
//						Draw.TextFixed(this, "MsgList",MakeString(new Object[]{Msgs[0],Msgs[1],Msgs[2]}), TextPosition.Center);

					if(pTextMsgPosition == TextPosition_ARC_LineAlert_local.TopRight)
						Draw.TextFixed(this, "MsgList", NewMsg, TextPosition.TopRight);
					else if(pTextMsgPosition == TextPosition_ARC_LineAlert_local.TopLeft)
						Draw.TextFixed(this, "MsgList", NewMsg, TextPosition.TopLeft);
					else if(pTextMsgPosition == TextPosition_ARC_LineAlert_local.BottomRight)
						Draw.TextFixed(this, "MsgList", NewMsg, TextPosition.BottomRight);
					else if(pTextMsgPosition == TextPosition_ARC_LineAlert_local.BottomLeft)
						Draw.TextFixed(this, "MsgList", NewMsg, TextPosition.BottomLeft);
					else if(pTextMsgPosition == TextPosition_ARC_LineAlert_local.Center)
						Draw.TextFixed(this, "MsgList", NewMsg, TextPosition.Center);
					NewMsg = null;
				}
			}


			//for(int k = 0; k<Lines.Count; k++) Draw.Dot(this, k+"dot",false,0,Lines[k],Color.Yellow);
			string[] elements;
			try{
				elements = NearestAboveTag.ToLower().Split(new char[]{':'}, StringSplitOptions.None);
				if(elements.Length>1 && NearestAboveTag.Contains("playit")) NearestUpperWAV = elements[elements.Length-1];
				else NearestUpperWAV = this.pSoundFileName;
				if(NearestUpperWAV.StartsWith(".wav")) NearestUpperWAV = string.Empty;
			}catch{}
//Print("NearestBelowTag: "+NearestBelowTag);
			try{
				elements = NearestBelowTag.ToLower().Split(new char[]{':'}, StringSplitOptions.None);
				if(elements.Length>1 && NearestBelowTag.Contains("playit")) NearestLowerWAV = elements[elements.Length-1];
				else NearestLowerWAV = this.pSoundFileName;
				if(NearestLowerWAV.StartsWith(".wav")) NearestLowerWAV = string.Empty;
			}catch{}

//}catch(Exception err1){Print(Name+":  Engine1: "+err1.ToString());}
		}

//====================================================================================================
		private double CalculateDistance(double close, int startabs, int endabs, double startprice, double endprice, ref double NearestAbove, ref double NearestBelow, string LineType, string Tag, ref string NearestAboveTag, ref string NearestBelowTag){
			if(startprice<=0) return 0;
			if(endabs<startabs) {
				int temp = endabs;
				endabs = startabs;
				startabs = temp;
				double tempp = endprice;
				endprice = startprice;
				startprice = tempp;
			}
			double slope = (endprice - startprice) / (endabs-startabs);
//			double linepricenow = (CurrentBar - endabs) * slope + endprice;
			double linepricenow = (CurrentBar - startabs) * slope + startprice;
			Lines[Tag] = linepricenow;
//Print("Lines["+Tag+"] = "+linepricenow.ToString());
			if(linepricenow > close) {
				double distance = linepricenow - close;
				if(distance < NearestAbove) {
					NearestAbove = distance;
					NearestAboveTag = Tag;
//Print("   NearestAbove "+Tag+"  "+distance);
				}
			}
			if(linepricenow < close) {
				double distance = close - linepricenow;
				if(distance < NearestBelow) {
					NearestBelow = distance;
					NearestBelowTag = Tag;
//Print("   NearestBelow "+Tag+"  "+distance);
				}
//Draw.TextFixed(this, "nearestbelow","Nearest line ("+LineType+":"+Tag+") below price: "+linepricenow.ToString()+"  distance: "+NearestBelow.ToString(),TextPosition.TopLeft);
			}
			return linepricenow;
		}
//====================================================================================================
		private bool CrossingNow (double currentprice, double priorprice, double NearestAbove, double NearestBelow, string NearestAboveTag, string NearestBelowTag, ref double CrossedAt) {
			TagOfCrossedLine = string.Empty;
			
			//Dictionary<string,double> TempLines = Lines;
			foreach (KeyValuePair<string,double> kv in /*Temp*/Lines) {
				double lineprice = kv.Value-ZoneSizePts;
				if(priorprice>lineprice) lineprice = kv.Value+ZoneSizePts;

				if(priorprice<=lineprice && currentprice>lineprice) {
					CrossDirection = 1;
					TagOfCrossedLine = kv.Key;
					CrossedAt = lineprice;
	//Print(NinjaTrader.Core.Globals.Now.ToString()+" above Crossed UP, prior tick: "+priorprice+" line="+lineprice+"  price="+currentprice);
					return true;
				}
				if(pDataSource == DataSource_ARC_LineAlert.Price && priorprice>=lineprice && currentprice<lineprice) {
					CrossDirection = -1;
					TagOfCrossedLine = kv.Key;
					CrossedAt = lineprice;
	//Print(NinjaTrader.Core.Globals.Now.ToString()+" above Crossed DOWN, prior tick: "+priorprice+" line="+lineprice+"  price="+currentprice);
					return true;
				}

//				if(pDataSource == DataSource_ARC_LineAlert.Price && priorprice>=lineprice && currentprice<lineprice) {
//					CrossDirection = -1;
//					TagOfCrossedLine = kv.Key;
//					CrossedAt = lineprice;
//	//Print(NinjaTrader.Core.Globals.Now.ToString()+" below Crossed DOWN, prior tick: "+priorprice+" line="+lineprice+"  price="+currentprice);
//					return true;
//				}
//				if(priorprice<=lineprice && currentprice>lineprice) {
//					CrossDirection = 1;
//					TagOfCrossedLine = kv.Key;
//					CrossedAt = lineprice;
//	//Print(NinjaTrader.Core.Globals.Now.ToString()+" below Crossed UP, prior tick: "+priorprice+" line="+lineprice+"  price="+currentprice);
//					return true;
//				}
			}
			return false;
		}
//====================================================================================================
		private void DrawSymbol(int AlertType) {
			if(State==State.Historical) return;
//Print("CrossDirection: "+CrossDirection+"   pDownCrossArrowDirection: "+pDownCrossArrowDirection.ToString()+"  UpCrossArrow: "+pUpCrossArrowDirection.ToString());
			string id = MakeString(new Object[]{"LineAlert",CurrentBar});
			if(CrossDirection == 1) { //Upward crossing, put symbol on Low price
				if(AlertType == 0 || AlertType == 5 || AlertType == 10)
					Draw.Diamond(this, id, false, 0, Low[0]-TickSize, pUpBrush);
				else if(AlertType == 3 || AlertType == 8 || AlertType == 13)
					Draw.Dot(this, id, false, 0, Low[0]-TickSize, pUpBrush);
				else if(AlertType == 1 || AlertType == 6 || AlertType == 11) {
					if(pUpCrossArrowDirection == ARC_LineAlert_ArrowDirection.Up)
						Draw.TriangleUp(this, id, false, 0, Low[0]-TickSize, pUpBrush);
					else
						Draw.TriangleDown(this, id, false, 0, High[0]+TickSize, pDownBrush);
				}
				else if(AlertType == 2 || AlertType == 7 || AlertType == 12) {
					if(pUpCrossArrowDirection == ARC_LineAlert_ArrowDirection.Up)
						Draw.ArrowUp(this, id, false, 0, Low[0]-TickSize, pUpBrush);
					else
						Draw.ArrowDown(this, id, false, 0, High[0]+TickSize, pDownBrush);
				}
			}
			else if(CrossDirection == -1) { //Downward crossing, put symbol on Low price
				if(AlertType == 0 || AlertType == 5 || AlertType == 10)
					Draw.Diamond(this, id, false, 0, High[0]+TickSize, pDownBrush);
				else if(AlertType == 3 || AlertType == 8 || AlertType == 13)
					Draw.Dot(this, id, false, 0, High[0]+TickSize, pDownBrush);
				else if(AlertType == 1 || AlertType == 6 || AlertType == 11) {
					if(pDownCrossArrowDirection == ARC_LineAlert_ArrowDirection.Up)
						Draw.TriangleUp(this, id, false, 0, Low[0]-TickSize, pUpBrush);
					else
						Draw.TriangleDown(this, id, false, 0, High[0]+TickSize, pDownBrush);
				}
				else if(AlertType == 2 || AlertType == 7 || AlertType == 12){
					if(pDownCrossArrowDirection == ARC_LineAlert_ArrowDirection.Up)
						Draw.ArrowUp(this, id, false, 0, Low[0]-TickSize, pUpBrush);
					else
						Draw.ArrowDown(this, id, false, 0, High[0]+TickSize, pDownBrush);
				}
			}
		}
//====================================================================================================
	private static string MakeString(object[] s){
		System.Text.StringBuilder stb = new System.Text.StringBuilder(null);
		for(int i = 0; i<s.Length; i++) {
			stb = stb.Append(s[i].ToString());
		}
		return stb.ToString();
	}
//====================================================================================================
//		public override string ToString()
//		{
//			string tags = string.Empty;
//			if(this.pTrendlineTag.Length>0) tags = " on '"+this.pTrendlineTag+"' tagged lines";
//			if(pDataSource == DataSource_ARC_LineAlert.Volume)
//				return "ARC_LineAlert - Volume alerts"+tags;
//			else if(pDataSource == DataSource_ARC_LineAlert.Price)
//				return "ARC_LineAlert - Price alerts"+tags;
//			else return "ARC_LineAlert - Indicator alerts"+tags;
//		}
//====================================================================================================
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
//====================================================================================================

		#region Properties
		internal class LoadFileList : StringConverter
		{
			#region LoadFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new System.Collections.Generic.List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}

		private TrendDirection_ARC_LineAlert pFilterDirection = TrendDirection_ARC_LineAlert.All;
//		[Description("Engage only Upward or Downward sloping trendlines?  'Horizontal' for flat, non-sloped trendlines, and 'All' means you engage upward and downward and horizontal trendlines")]
//		[Category("Parameters")]
//		public TrendDirection_ARC_LineAlert FilterDirection
//		{
//			get { return pFilterDirection; }
//			set { pFilterDirection = value; }
//		}

		private DataSource_ARC_LineAlert pDataSource = DataSource_ARC_LineAlert.Price;
//		[Description("")]
//		[Category("Parameters")]
//		public DataSource_ARC_LineAlert DataSource
//		{
//			get { return pDataSource; }
//			set { pDataSource = value; }
//		}
		private NinjaTrader.NinjaScript.Priority pAlertPriority = NinjaTrader.NinjaScript.Priority.High;
//		[Description("Set the priority for these alerts...the Alerts window sorts information based on this setting")]
//		[Category("Parameters")]
//		public NinjaTrader.NinjaScript.Priority AlertPriority
//		{
//			get { return pAlertPriority; }
//			set { pAlertPriority = value; }
//		}

		private string pTrendlineTag = "Horiz";
		[Description("Enter a specific tag name or id (case insensitive)...and the indicator will pay attention ONLY to horizontal lines that contain the this tag/id in their 'Tag' field.  If you leave this parameter blank, then all trendlines will be recognized")]
		[Category("Parameters")]
		public string TrendlineTag
		{
			get { return pTrendlineTag; }
			set { 	string result = value;
					if(string.IsNullOrEmpty(result.Trim())){pTrendlineTag=string.Empty;}
					else{
						result = result.Trim();
						char[] ch = result.ToCharArray();
						result = string.Empty;
						foreach(char c in ch) {
							if((c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9')){
								result = string.Concat(result,c);
							}
						}
						pTrendlineTag = result;
					}
				}
		}

//		private double pAlertLevel1 = 0;
//		[Description("Optional hardcoded alert level, enter '-9999' to disengage this alert")]
//		[Category("Parameters")]
//		public double AlertLevel1
//		{
//			get { return pAlertLevel1; }
//			set { pAlertLevel1 = value; }
//		}

//		private double pAlertLevel2 = 0;
//		[Description("Optional hardcoded alert level, enter '-9999' to disengage this alert")]
//		[Category("Parameters")]
//		public double AlertLevel2
//		{
//			get { return pAlertLevel2; }
//			set { pAlertLevel2 = value; }
//		}

//		private double pAlertLevel3 = 0;
//		[Description("Optional hardcoded alert level, enter '-9999' to disengage this alert")]
//		[Category("Parameters")]
//		public double AlertLevel3
//		{
//			get { return pAlertLevel3; }
//			set { pAlertLevel3 = value; }
//		}

		#region Alerts		
		private ARC_LineAlert_AlertType pSignalType = ARC_LineAlert_AlertType.SoundOnly;
		[Display(Name = "Signal type", GroupName = "Alert", Order = 10)]
		public ARC_LineAlert_AlertType SignalType
		{
			get { return pSignalType; }
			set { pSignalType = value; }
		}

		private string pSoundFileName = "SOUND OFF";
		[Description("Default WAV file to be played when line gets hit")]
		[Display(Name = "WAV file", GroupName = "Alert", Order = 20)]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadFileList))]
		public string DefaultSoundFileName
		{
			get { return pSoundFileName; }
			set { pSoundFileName = value; 
//				string wavname = pSoundFileName.ToLower();
//				if(!wavname.Contains(".wav")) pSoundFileName = pSoundFileName.Trim() + ".wav";
			}
		}


		private double pZoneSizeTicks = 0;
		[Description("Zone size, number of points above and below the levels that will enable the trigger of the alert")]
		[Display(Name = "Zone Size (ticks)", GroupName = "Alert", Order = 30)]
		public double ZoneSizeTicks
		{
			get { return pZoneSizeTicks; }
			set { pZoneSizeTicks = Math.Max(0,value);
			}
		}

		private int pMaxAlertsPerBar = 1;
		[Description("Maximum times an alert can be played on the same bar, if CalculateOnBarClose=true then MaxAlertsPerBar will be fixed at 1")]
		[Display(Name = "Max alerts per bar", GroupName = "Alert", Order = 40)]
		public int MaxAlertsPerBar
		{
			get { return pMaxAlertsPerBar; }
			set { pMaxAlertsPerBar = Math.Max(0,value); }
		}

		private int pMaxAlertsPerLine = 1;
		[Description("Maximum times an alert can be played on any particular trendline")]
		[Display(Name = "Max alerts per Line", GroupName = "Alert", Order = 45)]
		public int MaxAlertsPerLine
		{
			get { return pMaxAlertsPerLine; }
			set { pMaxAlertsPerLine = Math.Max(0,value); }
		}

		private int pEmailFrequency = 0;
		[Description("What's the minimum number of bars between consecutive email sends.  0 = once on each bar, 1 = skip a bar, 2 = skip 2 bars, etc")]
		[Display(Name = "Min. email frequency", GroupName = "Alert", Order = 50)]
		public int EmailFrequency
		{
			get { return pEmailFrequency; }
			set { pEmailFrequency = value; }
		}

		private bool pSendEmails = false;
		[Description("Send an email on each arrow signal?  Make sure your NT platform is configured for SMTP sends")]
		[Display(Name = "Enable Email?", GroupName = "Alert", Order = 48)]
		public bool EmailEnabled
		{
			get { return pSendEmails; }
			set { pSendEmails = value; }
		}

		private string pEmailAddress = "";
		[Description("Enter a valid destination email address to receive an email on signals")]
		[Display(Name = "Email address", GroupName = "Alert", Order = 49)]
		public string EmailAddress
		{
			get { return pEmailAddress; }
			set { pEmailAddress = value; }
		}

		private bool pPrintToAlertsWindow = true;
		[Description("Print alert message to Alerts window?")]
		[Display(Name = "Print to Alerts Window", GroupName = "Alert", Order = 100)]
		public bool PrintToAlertsWindow
		{
			get { return pPrintToAlertsWindow; }
			set { pPrintToAlertsWindow = value; }
		}

		#endregion

		#region -- Visuals --
		private ARC_LineAlert_ArrowDirection pUpCrossArrowDirection = ARC_LineAlert_ArrowDirection.Down;
		private ARC_LineAlert_ArrowDirection pDownCrossArrowDirection = ARC_LineAlert_ArrowDirection.Up;
		[Description("")]
		[Display(Name = "Arrow Dir on Upward cross", GroupName = "Visuals", Order = 10)]
		public ARC_LineAlert_ArrowDirection UpCrossArrowDirection
		{
			get { return pUpCrossArrowDirection; }
			set { pUpCrossArrowDirection = value; }
		}
		[Description("")]
		[Display(Name = "Arrow Dir on Downward cross", GroupName = "Visuals", Order = 20)]
		public ARC_LineAlert_ArrowDirection DownCrossArrowDirection
		{
			get { return pDownCrossArrowDirection; }
			set { pDownCrossArrowDirection = value; }
		}
		private Brush pLineBrush = Brushes.Red;
		[XmlIgnore()]
		[Description("Color of alert line for levels near to current price")]
		[Display(Order=30, ResourceType = typeof(Custom.Resource), Name = "Line color",  GroupName = "Visuals")]
		public Brush LineC{	get { return pLineBrush; }	set { pLineBrush = value; }		}
		[Browsable(false)]
		public string LineBrushSerialize
		{	get { return Serialize.BrushToString(pLineBrush); } set { pLineBrush = Serialize.StringToBrush(value); }
		}
		
		private Brush pUpBrush = Brushes.Green;
		[XmlIgnore()]
		[Description("Color of the selected chart marker when price crosses upward thru an alert level")]
		[Display(Order=40, ResourceType = typeof(Custom.Resource), Name = "Marker Up color",  GroupName = "Visuals")]
		public Brush UC{	get { return pUpBrush; }	set { pUpBrush = value; }		}
		[Browsable(false)]
		public string UClSerialize
		{	get { return Serialize.BrushToString(pUpBrush); } set { pUpBrush = Serialize.StringToBrush(value); }
		}
		
		private Brush pDownBrush = Brushes.Red;
		[XmlIgnore()]
		[Description("Color of the selected chart marker when price crosses downward thru an alert level")]
		[Display(Order=50, ResourceType = typeof(Custom.Resource), Name = "Marker Down color",  GroupName = "Visuals")]
		public Brush DC{	get { return pDownBrush; }	set { pDownBrush = value; }		}
		[Browsable(false)]
		public string DClSerialize
		{	get { return Serialize.BrushToString(pDownBrush); } set { pDownBrush = Serialize.StringToBrush(value); }
		}

		private string pLineLabel = "[price]";
		[Description("What label to put on each level?  [price] is an optional placeholder for the current level price, [wav] is an optional placeholder for the wav file name, '*' (asterisk) whenever you want a new-line inserted")]
		[Display(Order=40, ResourceType = typeof(Custom.Resource), Name = "Label text",  GroupName = "Visuals")]
		public string LineLabel
		{
			get { return pLineLabel; }
			set { pLineLabel = value;}
		}
		private float pFontSize = 16;
		[Display(Order=60, ResourceType = typeof(Custom.Resource), Name = "Font size",  GroupName = "Visuals")]
		public float FontSize
		{
			get { return pFontSize; }
			set { pFontSize = Math.Max(6,value); }
		}

		private bool pShowAlertLevels = false;
		[Description("Show price levels of only the nearest lines?")]
		[Display(Order=70, ResourceType = typeof(Custom.Resource), Name = "Show Levels",  GroupName = "Visuals")]
		public bool ShowAlertLevels
		{
			get { return pShowAlertLevels; }
			set { pShowAlertLevels = value; }
		}

		private bool pShowAll = true;
//		[Description("Show all current price alert levels, even the ones off the chart?")]
//		[Display(Order=70, ResourceType = typeof(Custom.Resource), Name = "Show All Levels",  GroupName = "Visuals")]
//		public bool ShowAll
//		{
//			get { return pShowAll; }
//			set { pShowAll = value; }
//		}

		private TextPosition_ARC_LineAlert_local pTextMsgPosition = TextPosition_ARC_LineAlert_local.None;
		[Description("On screen Location of 'line hit' notifications")]
		[Display(Order=80, ResourceType = typeof(Custom.Resource), Name = "Txt Msg Location",  GroupName = "Visuals")]
		public TextPosition_ARC_LineAlert_local TextMsgPosition
		{
			get { return pTextMsgPosition; }
			set { pTextMsgPosition = value; }
		}

		private int pLineLengthPixels = 70;
		[Description("Length of alert lines in pixels")]
		[Display(Order=90, ResourceType = typeof(Custom.Resource), Name = "Line length (px)",  GroupName = "Visuals")]
		public int LineLengthPixels
		{
			get { return pLineLengthPixels; }
			set { pLineLengthPixels = Math.Max(1,value); }
		}

		#endregion

		#endregion

//====================================================================================================
		private string GetDescription(int AlertType, string SoundFileName) {
			if(AlertType == 4) return SoundFileName;
			else if(AlertType == 0) return "Diamond";
			else if(AlertType == 5) return MakeString(new Object[]{SoundFileName, " & Diamond"});
			else if(AlertType == 1) return "Triangle";
			else if(AlertType == 6) return MakeString(new Object[]{SoundFileName, " & Triangle"});
			else if(AlertType == 2) return "Arrow";
			else if(AlertType == 7) return MakeString(new Object[]{SoundFileName, " & Arrow"});
			else if(AlertType == 3) return "Dot";
			else if(AlertType == 8) return MakeString(new Object[]{SoundFileName, " & Dot"});
			else if(AlertType == 9) return "Popup";
			else if(AlertType == 10) return "Popup & Diamond";
			else if(AlertType == 11) return "Popup & Triangle";
			else if(AlertType == 12) return "Popup & Arrow";
			else if(AlertType == 13) return "Popup & Dot";
			return "Error - unknown type";
		}
//====================================================================================================
	public override void OnRenderTargetChanged()
	{
		if(NearLineDXBrush  !=null && !NearLineDXBrush.IsDisposed)  NearLineDXBrush.Dispose();  NearLineDXBrush  = null;
		if(DistantLineDXBrush  !=null && !DistantLineDXBrush.IsDisposed)  DistantLineDXBrush.Dispose();  DistantLineDXBrush  = null;
//		if(LineDXBrush  !=null && !LineDXBrush.IsDisposed)  LineDXBrush.Dispose();  LineDXBrush  = null;
		if(GoldenrodDXBrush!=null && !GoldenrodDXBrush.IsDisposed) GoldenrodDXBrush.Dispose(); GoldenrodDXBrush = null;

		if(RenderTarget!=null)
			NearLineDXBrush = pLineBrush.ToDxBrush(RenderTarget);
		if(RenderTarget!=null)
			DistantLineDXBrush = pLineBrush.ToDxBrush(RenderTarget);
		if(RenderTarget!=null)
			GoldenrodDXBrush = Brushes.Goldenrod.ToDxBrush(RenderTarget);
	}
//====================================================================================================
	protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
		if (!IsVisible) return;
		if(ChartControl==null) return;
		double minPrice = chartScale.MinValue; double maxPrice = chartScale.MaxValue;
		//base.OnRender(chartControl, chartScale);
		//Point PanelUpperLeftPoint	= new Point(ChartPanel.X, ChartPanel.Y);
		//Point PanelLowerRightPoint	= new Point(ChartPanel.X + ChartPanel.W, ChartPanel.Y + ChartPanel.H);
		//int firstBarPainted = ChartBars.FromIndex;
		//int lastBarPainted = ChartBars.ToIndex;

		var ts = new TimeSpan(DateTime.Now.Ticks - MsgPrintTime.Ticks);
		if(ts.TotalSeconds > 15) RemoveDrawObject("MsgList");

		int line = 978;
		TextFormat textFormat		= new TextFormat(Core.Globals.DirectWriteFactory, "Arial", SharpDX.DirectWrite.FontWeight.Normal,
											SharpDX.DirectWrite.FontStyle.Normal, SharpDX.DirectWrite.FontStretch.Normal, pFontSize) 
											{ TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading, WordWrapping = WordWrapping.NoWrap };

		TextLayout textLayout		= null;
		LineDXBrush = NearLineDXBrush;

		int LeftmostPixelOfLines = ChartPanel.W-pLineLengthPixels;//chartControl.GetXByBarIndex(BarSelected);//-ChartControl.BarSpace*5;
		float endpoint = ChartPanel.X+ChartPanel.W;
		bool skip = false;


		if(!pShowAll) {//show only the alert levels nearest to the current price
			if(NearestAbove != double.MaxValue) {
	//Print("Nearest above: "+NearestAbove);
				double p = input[0]+NearestAbove;
				if(p > maxPrice) {
					p = maxPrice;
					LineDXBrush = DistantLineDXBrush;
				}
				if(!skip) {
					lineval1 = chartScale.GetYByValue(p);
					RenderTarget.DrawLine(new SharpDX.Vector2(LeftmostPixelOfLines, lineval1), new SharpDX.Vector2(endpoint, lineval1), LineDXBrush);
					lineval2zupper = chartScale.GetYByValue(p+ZoneSizePts);
					lineval2zlower = chartScale.GetYByValue(p-ZoneSizePts);
					RenderTarget.DrawLine(new SharpDX.Vector2(LeftmostPixelOfLines, lineval2zupper), new SharpDX.Vector2(LeftmostPixelOfLines, lineval2zlower),LineDXBrush);
					string desc = string.Empty;
					if(AlertsPerLine.ContainsKey(NearestAboveTag) && AlertsPerLine[NearestAboveTag] >= pMaxAlertsPerLine){
						desc = "Expired";
						LineDXBrush = GoldenrodDXBrush;
					}else if(pLineLabel.Length>0) {
						desc = pLineLabel.Replace("[price]",Instrument.MasterInstrument.FormatPrice(input[0]+NearestAbove)).Replace("[wav]",(int)pSignalType>=4?NearestUpperWAV:string.Empty).Replace("*",Environment.NewLine);
					}
					if(LineDXBrush!=null){
						textLayout = new TextLayout(Core.Globals.DirectWriteFactory, desc, textFormat, ChartPanel.W, pFontSize);
						float x = endpoint - textLayout.Metrics.Width - 5;
						float y = lineval1 - textLayout.Metrics.Height - 2;
						if(price != maxPrice) y = lineval1;
						RenderTarget.DrawTextLayout(new SharpDX.Vector2(x,y), textLayout, LineDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					}
				}
			}

			LineDXBrush = NearLineDXBrush;
			skip = false;
			if(NearestBelow != double.MaxValue) {
//Print("Nearest below: "+NearestBelow);
				double p = input[0]-NearestBelow;
				if(p < minPrice) {
					p = minPrice;
					LineDXBrush = DistantLineDXBrush;
				}
				if(!skip) {
					lineval2 = chartScale.GetYByValue(p);//(float)GetYPos(p, bounds, minPrice, maxPrice));
					RenderTarget.DrawLine(new SharpDX.Vector2(LeftmostPixelOfLines, lineval2), new SharpDX.Vector2(endpoint, lineval2), LineDXBrush);
					lineval2zupper = chartScale.GetYByValue(p+ZoneSizePts);//(float)GetYPos(p+ZoneSizePts, bounds, minPrice, maxPrice));
					lineval2zlower = chartScale.GetYByValue(p-ZoneSizePts);//(float)GetYPos(p-ZoneSizePts, bounds, minPrice, maxPrice));
					RenderTarget.DrawLine(new SharpDX.Vector2(LeftmostPixelOfLines, lineval2zupper), new SharpDX.Vector2(LeftmostPixelOfLines, lineval2zlower),LineDXBrush);
					string desc = string.Empty;
					if(AlertsPerLine.ContainsKey(NearestBelowTag) && AlertsPerLine[NearestBelowTag] >= pMaxAlertsPerLine){
						desc = "Expired";
						LineDXBrush = GoldenrodDXBrush;
					}else if(pLineLabel.Length>0) {
						desc = pLineLabel.Replace("[price]",Instrument.MasterInstrument.FormatPrice(input[0]-NearestBelow)).Replace("[wav]",(int)pSignalType>=4?NearestLowerWAV:string.Empty).Replace("*",Environment.NewLine);
					}
					if(LineDXBrush!=null){
						textLayout = new TextLayout(Core.Globals.DirectWriteFactory, desc, textFormat, ChartPanel.W, pFontSize);
						float x = endpoint - textLayout.Metrics.Width - 5;
						float y = lineval2 - textLayout.Metrics.Height - 2;
						if(price != minPrice) y = lineval2;
						RenderTarget.DrawTextLayout(new SharpDX.Vector2(x,y), textLayout, LineDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					}
				}
			}
		} else if(pShowAll) {
			foreach(TheLine L in TheCO) {
				lineval2 = chartScale.GetYByValue(L.CurrentLinePrice);//(float)GetYPos(L.CurrentLinePrice, bounds, minPrice, maxPrice));
				RenderTarget.DrawLine(new SharpDX.Vector2(LeftmostPixelOfLines, lineval2), new SharpDX.Vector2(endpoint, lineval2), LineDXBrush);
				lineval2zupper = chartScale.GetYByValue(L.CurrentUpperAlertPrice);//(float)GetYPos(L.CurrentUpperAlertPrice, bounds, minPrice, maxPrice));
				lineval2zlower = chartScale.GetYByValue(L.CurrentLowerAlertPrice);//(float)GetYPos(L.CurrentLowerAlertPrice, bounds, minPrice, maxPrice));
				RenderTarget.DrawLine(new SharpDX.Vector2(LeftmostPixelOfLines, lineval2zupper), new SharpDX.Vector2(LeftmostPixelOfLines, lineval2zlower), LineDXBrush);
				string desc = string.Empty;
				if(AlertsPerLine.ContainsKey(L.Tag) && AlertsPerLine[L.Tag] >= pMaxAlertsPerLine){
					desc = "Expired";
					LineDXBrush = GoldenrodDXBrush;
				}else if(pLineLabel.Length>0) {
					desc = pLineLabel.ToLower().Replace("[price]",Instrument.MasterInstrument.FormatPrice(L.CurrentLinePrice));
				}
				if(LineDXBrush!=null){
					if(pSoundFileName!=".wav") desc = desc.Replace("[wav]",(int)pSignalType>=4?pSoundFileName:string.Empty);
					else desc = desc.Replace("[wav]",string.Empty);
					if(desc.Contains("*")) desc = desc.Replace("*",Environment.NewLine);
					textLayout = new TextLayout(Core.Globals.DirectWriteFactory, desc, textFormat, ChartPanel.W, pFontSize);
					float x = endpoint - textLayout.Metrics.Width - 5;
					float y = lineval2 - textLayout.Metrics.Height - 2;
					if(price != minPrice) y = lineval2;
					RenderTarget.DrawTextLayout(new SharpDX.Vector2(x,y), textLayout, LineDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
				}
			}
		}

//}catch(Exception err){Print(line+" "+Name+" PlotError: "+err.ToString());}
		if(textLayout!=null){
			textLayout.Dispose();
			textLayout = null;
		}
		if(textFormat!=null){
			textFormat.Dispose();
			textFormat = null;
		}
	}

		//========================================================================================================
    //    protected override void OnTermination()
  //      {
//			if (this.ChartControl != null) {
//				this.ChartControl.ChartPanel.MouseUp -= MouseUpEvent;
	//		}
      //  }
    }
}


	public enum ARC_LineAlert_ArrowDirection {Up, Down}
	public enum ARC_LineAlert_AlertType {
		Diamond=0,
		Triangle=1,
		Arrow=2,
		Dot=3,
		SoundOnly=4,
		SoundAndDiamond=5,
		SoundAndTriangle=6,
		SoundAndArrow=7,
		SoundAndDot=8,
		PopupOnly=9,
		PopupAndDiamond=10,
		PopupAndTriangle =11,
		PopupAndArrow =12,
		PopupAndDot =13
	}
	public enum DataSource_ARC_LineAlert{
		Volume,Price,Input
	}
	public enum TrendDirection_ARC_LineAlert{
		Up, Down, Horizontal, UpAndHorizontal, DownAndHorizontal, All
	}
	public enum TextPosition_ARC_LineAlert_local {
		TopRight,
		BottomRight,
		TopLeft,
		BottomLeft,
		Center,
		None
	}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_LineAlert[] cacheARC_LineAlert;
		public ARC.ARC_LineAlert ARC_LineAlert()
		{
			return ARC_LineAlert(Input);
		}

		public ARC.ARC_LineAlert ARC_LineAlert(ISeries<double> input)
		{
			if (cacheARC_LineAlert != null)
				for (int idx = 0; idx < cacheARC_LineAlert.Length; idx++)
					if (cacheARC_LineAlert[idx] != null &&  cacheARC_LineAlert[idx].EqualsInput(input))
						return cacheARC_LineAlert[idx];
			return CacheIndicator<ARC.ARC_LineAlert>(new ARC.ARC_LineAlert(), input, ref cacheARC_LineAlert);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_LineAlert ARC_LineAlert()
		{
			return indicator.ARC_LineAlert(Input);
		}

		public Indicators.ARC.ARC_LineAlert ARC_LineAlert(ISeries<double> input )
		{
			return indicator.ARC_LineAlert(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_LineAlert ARC_LineAlert()
		{
			return indicator.ARC_LineAlert(Input);
		}

		public Indicators.ARC.ARC_LineAlert ARC_LineAlert(ISeries<double> input )
		{
			return indicator.ARC_LineAlert(input);
		}
	}
}

#endregion
