//
// Copyright (C) 2021, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
	public class ARC_MFI : Indicator
	{
		private	Series<double>		negative;
		private	Series<double>		positive;
		private	SUM					sumNegative;
		private SUM					sumPositive;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionMFI;
				Name						= "ARC_MFI";
				IsSuspendedWhileInactive	= false;
				Period						= 100;
				DrawOnPricePanel			= false;

				AddPlot(Brushes.DarkCyan,		NinjaTrader.Custom.Resource.NinjaScriptIndicatorNameMFI);
				AddLine(Brushes.SlateBlue,	20,	NinjaTrader.Custom.Resource.NinjaScriptIndicatorLower);
				AddLine(Brushes.White,	50,	NinjaTrader.Custom.Resource.NinjaScriptIndicatorMiddle);
				AddLine(Brushes.Goldenrod,	80,	NinjaTrader.Custom.Resource.NinjaScriptIndicatorUpper);
			}
			else if (State == State.DataLoaded)
			{
				negative		= new Series<double>(this);
				positive		= new Series<double>(this);
				sumNegative		= SUM(negative, Period);
				sumPositive		= SUM(positive, Period);
			}
			else if (State == State.Historical)
			{
				if (Calculate == Calculate.OnPriceChange)
				{
					Draw.TextFixed(this, "NinjaScriptInfo", string.Format(NinjaTrader.Custom.Resource.NinjaScriptOnPriceChangeError, Name), TextPosition.BottomRight);
					Log(string.Format(NinjaTrader.Custom.Resource.NinjaScriptOnPriceChangeError, Name), LogLevel.Error);
				}
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar == 0)
				Value[0] = 50;
			else
			{
				double typical0		= Typical[0];
				double typical1		= Typical[1];
				double volume0		= Instrument.MasterInstrument.InstrumentType == InstrumentType.CryptoCurrency ? Core.Globals.ToCryptocurrencyVolume((long)Volume[0]) : Volume[0];
				negative[0]			= typical0 < typical1 ? typical0 * volume0 : 0;
				positive[0]			= typical0 > typical1 ? typical0 * volume0 : 0;

				double sumNegative0	= sumNegative[0];
				Value[0]			= sumNegative0 == 0 ? 50 : 100.0 - (100.0 / (1 + sumPositive[0] / sumNegative0));
			}
		}

		#region Properties
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "NinjaScriptParameters", Order = 0)]
		public int Period
		{ get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_MFI[] cacheARC_MFI;
		public ARC.ARC_MFI ARC_MFI(int period)
		{
			return ARC_MFI(Input, period);
		}

		public ARC.ARC_MFI ARC_MFI(ISeries<double> input, int period)
		{
			if (cacheARC_MFI != null)
				for (int idx = 0; idx < cacheARC_MFI.Length; idx++)
					if (cacheARC_MFI[idx] != null && cacheARC_MFI[idx].Period == period && cacheARC_MFI[idx].EqualsInput(input))
						return cacheARC_MFI[idx];
			return CacheIndicator<ARC.ARC_MFI>(new ARC.ARC_MFI(){ Period = period }, input, ref cacheARC_MFI);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_MFI ARC_MFI(int period)
		{
			return indicator.ARC_MFI(Input, period);
		}

		public Indicators.ARC.ARC_MFI ARC_MFI(ISeries<double> input , int period)
		{
			return indicator.ARC_MFI(input, period);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_MFI ARC_MFI(int period)
		{
			return indicator.ARC_MFI(Input, period);
		}

		public Indicators.ARC.ARC_MFI ARC_MFI(ISeries<double> input , int period)
		{
			return indicator.ARC_MFI(input, period);
		}
	}
}

#endregion
