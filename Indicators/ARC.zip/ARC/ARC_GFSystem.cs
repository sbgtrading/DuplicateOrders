#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
//using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.Tools;
using System.Threading;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;

using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows;

#endregion

#region Author/Copyright
/*********************************************************************
************************* Golden Zone Trading ************************
**********************************************************************
* Author NT8 : Kriss { AzurITec } + Ben Letto {SBG Trading}
**********************************************************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~ info version ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
######################################################################
----------------------------------------------------------------------
v1.2    - 05.3.2018    + Added TradePlan (Near and Far)
                        + Tested with 8.0.13.1
----------------------------------------------------------------------
v1.3    - 09.8.2018    + Added PlanLevelsBasis
					   + Added SL/Tgt calc basis (ATR and Ticks)
					   + Added Show SL, Show T1, Show T2
                       + Tested with 8.0.15.1
----------------------------------------------------------------------
*/
#endregion

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region -- Global Enums --
    public enum ARC_GFSystem_FiblineResolutionA { Smallest, Small, Default, Increased, Large, Largest }
    public enum ARC_GFSystem_ConfluenceWidthA { Strong, Weak }
	public enum ARC_GFSystem_TradeEntryBasis{ AtFibPrice, AtMidPrice, AtATR}
	public enum ARC_GFSystem_TradePlanLocation {Left,Right}
	public enum ARC_GFSystem_DominantTradePlan {Long,Short,None}
	public enum ARC_GFSystem_SLTP_CalcBasis {ATR, Ticks}
	public enum ARC_GFSystem_Plan_LevelsBasis {AtFib, AtEntryPrice}
    #endregion

    public class ARC_GFSystem : Indicator
    {
		private const int UP = 1;
		private const int FLAT = 0;
		private const int DOWN = -1;
		#region TradePlan class definition
		private class TradePlan {
			public double EntryPrice;
			public double SLPrice;
			public double T1Price;
			public double T2Price;
			public double EntryZoneHighPrice;
			public double EntryZoneLowPrice;
			public TradePlan(char Type, double fibLevel, ARC_GFSystem_Plan_LevelsBasis planlevelsbasis, ARC_GFSystem_TradeEntryBasis entrybasis, double atr, double EntryZoneMult, double SL_inPts, double T1_inPts, double T2_inPts, double TickSize){
				int ticks = (int)Math.Round(atr * EntryZoneMult / TickSize);
				if(ticks%2==1) ticks = ticks+1;
				if(Type=='S'){//'S' for supportive
					EntryZoneLowPrice = fibLevel;
					EntryZoneHighPrice = (EntryZoneLowPrice + ticks * TickSize);
				}else{
					EntryZoneHighPrice = fibLevel;
					EntryZoneLowPrice = (EntryZoneHighPrice - ticks * TickSize);
				}
				if(entrybasis == ARC_GFSystem_TradeEntryBasis.AtFibPrice) 
					EntryPrice = fibLevel;
				else if(entrybasis == ARC_GFSystem_TradeEntryBasis.AtMidPrice) {
					EntryPrice = (EntryZoneHighPrice+EntryZoneLowPrice)/2.0;
//					EntryPrice = Math.Round(EntryPrice/TickSize,0) * TickSize;
				} else if(entrybasis == ARC_GFSystem_TradeEntryBasis.AtATR) {
					if(Type=='R') {//it's a resistance, SHORT entry plan
						EntryPrice = EntryZoneLowPrice;
					}
					else {//it's a support, LONG entry plan
						EntryPrice = EntryZoneHighPrice;
					}
				}else{//AtNearestEdge
					if(Type=='S') {//it's a supportive, LONG entry plan
						EntryPrice = EntryZoneHighPrice;
					}
					else {//it's a resistance, SHORT entry plan
						EntryPrice = EntryZoneLowPrice;
					}
				}
				double keyprice = fibLevel;
				if(planlevelsbasis == ARC_GFSystem_Plan_LevelsBasis.AtEntryPrice) keyprice = EntryPrice;
				if(Type=='R'){//it's a resistance, SHORT entry plan
					SLPrice = keyprice + SL_inPts;
					if(T1_inPts>0) T1Price = keyprice - T1_inPts; else T1Price = double.NaN;
					if(T2_inPts>0) T2Price = keyprice - T2_inPts; else T2Price = double.NaN;
				}else{//it's a supportive, LONG entry plan
					SLPrice = keyprice - SL_inPts;
					if(T1_inPts>0) T1Price = keyprice + T1_inPts; else T1Price = double.NaN;
					if(T2_inPts>0) T2Price = keyprice + T2_inPts; else T2Price = double.NaN;
				}
			}
		}
		private TradePlan[] SupTPlan = new TradePlan[2]{null,null};
		private TradePlan[] ResTPlan = new TradePlan[2]{null,null};
		private double AvgSL = double.MinValue;
		private double AvgT1 = double.MinValue;
		private double AvgT2 = double.MinValue;
		#endregion

		private string OnStateChange_ErrorMsg = string.Empty;
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "GFSystem";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		System.Collections.Generic.List<string> Expected_ISTagSet = new System.Collections.Generic.List<string>(){"22344", "25900", "4396", "847", "819", "27405"};//27405 is Annual Membership and 819 is old mastery program
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion

		bool IsDebug = false;

		//2.1 - added ButtonText parameter...letting user select the text on the UI button
		//2.2 - Moved Series<double> inits to DataLoaded state, for NT8.0.20.0 compatibility
		//2.3 - Changed DisplayName to clean up the NT IndicatorDialog
		private string VERSION = "v2.3 Apr.29.20";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

        #region -- Variables --

        #region -- Arrays --
        private bool[] upTrend = new bool[10];
        private bool[] existsSwingHigh = new bool[10];
        private bool[] existsSwingLow = new bool[10];
        private double[] minimumDeviation = new double[10];
        private double[,] microHigh = new double[10, 20];
        private double[,] microLow = new double[10, 20];
        private double[] currentHigh = new double[10];
        private double[] currentLow = new double[10];
        private double[] priorCurrentHigh = new double[10];
        private double[] priorCurrentLow = new double[10];
        private double[] currentSwingHigh = new double[10];
        private double[] currentSwingLow = new double[10];
        private double[] lastSwingHigh = new double[10];
        private double[] lastSwingLow = new double[10];
        private double[] microSwingHigh0 = new double[10];
        private double[] microSwingHigh1 = new double[10];
        private double[] microSwingHigh2 = new double[10];
        private double[] microSwingHigh3 = new double[10];
        private double[] microSwingLow0 = new double[10];
        private double[] microSwingLow1 = new double[10];
        private double[] microSwingLow2 = new double[10];
        private double[] microSwingLow3 = new double[10];
        private double[] retUp0 = new double[10];
        private double[] retUp23 = new double[10];
        private double[] retUp38 = new double[10];
        private double[] retUp50 = new double[10];
        private double[] retUp62 = new double[10];
        private double[] retUp76 = new double[10];
        private double[] retUp100 = new double[10];
        private double[] retDown0 = new double[10];
        private double[] retDown23 = new double[10];
        private double[] retDown38 = new double[10];
        private double[] retDown50 = new double[10];
        private double[] retDown62 = new double[10];
        private double[] retDown76 = new double[10];
        private double[] retDown100 = new double[10];
        private double[] extUp0 = new double[10];
        private double[] extUp100 = new double[10];
        private double[] extUp127 = new double[10];
        private double[] extUp162 = new double[10];
        private double[] extUp200 = new double[10];
        private double[] extUp262 = new double[10];
        private double[] extUp300 = new double[10];
        private double[] extUp423 = new double[10];
        private double[] extDown0 = new double[10];
        private double[] extDown100 = new double[10];
        private double[] extDown127 = new double[10];
        private double[] extDown162 = new double[10];
        private double[] extDown200 = new double[10];
        private double[] extDown262 = new double[10];
        private double[] extDown300 = new double[10];
        private double[] extDown423 = new double[10];
        private double[] dirUp38 = new double[10];
        private double[] dirUp62 = new double[10];
        private double[] dirUp100 = new double[10];
        private double[] dirDown38 = new double[10];
        private double[] dirDown62 = new double[10];
        private double[] dirDown100 = new double[10];
        private double[] lastDirUp38 = new double[10];
        private double[] lastDirUp62 = new double[10];
        private double[] lastDirUp100 = new double[10];
        private double[] lastDirDown38 = new double[10];
        private double[] lastDirDown62 = new double[10];
        private double[] lastDirDown100 = new double[10];
        private double[] alt0Up = new double[10];
        private double[] alt1Up = new double[10];
        private double[] alt0Down = new double[10];
        private double[] alt1Down = new double[10];
        private double[] alt0Up62 = new double[10];
        private double[] alt0Up100 = new double[10];
        private double[] alt0Up162 = new double[10];
        private double[] alt1Up100 = new double[10];
        private double[] alt0Down62 = new double[10];
        private double[] alt0Down100 = new double[10];
        private double[] alt0Down162 = new double[10];
        private double[] alt1Down100 = new double[10];
        private double[] priorCurrentSwingHigh = new double[10];
        private double[] priorLastSwingHigh = new double[10];
        private double[] priorCurrentSwingLow = new double[10];
        private double[] priorLastSwingLow = new double[10];
        private double[] priorMicroSwingHigh0 = new double[10];
        private double[] priorMicroSwingHigh1 = new double[10];
        private double[] priorMicroSwingHigh2 = new double[10];
        private double[] priorMicroSwingHigh3 = new double[10];
        private double[] priorMicroSwingLow0 = new double[10];
        private double[] priorMicroSwingLow1 = new double[10];
        private double[] priorMicroSwingLow2 = new double[10];
        private double[] priorMicroSwingLow3 = new double[10];
        private double[] priorRetUp0 = new double[10];
        private double[] priorRetUp23 = new double[10];
        private double[] priorRetUp38 = new double[10];
        private double[] priorRetUp50 = new double[10];
        private double[] priorRetUp62 = new double[10];
        private double[] priorRetUp76 = new double[10];
        private double[] priorRetUp100 = new double[10];
        private double[] priorRetDown0 = new double[10];
        private double[] priorRetDown23 = new double[10];
        private double[] priorRetDown38 = new double[10];
        private double[] priorRetDown50 = new double[10];
        private double[] priorRetDown62 = new double[10];
        private double[] priorRetDown76 = new double[10];
        private double[] priorRetDown100 = new double[10];
        private double[] priorExtUp0 = new double[10];
        private double[] priorExtUp100 = new double[10];
        private double[] priorExtUp127 = new double[10];
        private double[] priorExtUp162 = new double[10];
        private double[] priorExtUp200 = new double[10];
        private double[] priorExtUp262 = new double[10];
        private double[] priorExtUp300 = new double[10];
        private double[] priorExtUp423 = new double[10];
        private double[] priorExtDown0 = new double[10];
        private double[] priorExtDown100 = new double[10];
        private double[] priorExtDown127 = new double[10];
        private double[] priorExtDown162 = new double[10];
        private double[] priorExtDown200 = new double[10];
        private double[] priorExtDown262 = new double[10];
        private double[] priorExtDown300 = new double[10];
        private double[] priorExtDown423 = new double[10];
        private double[] priorDirUp38 = new double[10];
        private double[] priorDirUp62 = new double[10];
        private double[] priorDirUp100 = new double[10];
        private double[] priorDirDown38 = new double[10];
        private double[] priorDirDown62 = new double[10];
        private double[] priorDirDown100 = new double[10];
        private double[] priorLastDirUp38 = new double[10];
        private double[] priorLastDirUp62 = new double[10];
        private double[] priorLastDirUp100 = new double[10];
        private double[] priorLastDirDown38 = new double[10];
        private double[] priorLastDirDown62 = new double[10];
        private double[] priorLastDirDown100 = new double[10];
        private double[] priorAlt0Up62 = new double[10];
        private double[] priorAlt0Up100 = new double[10];
        private double[] priorAlt0Up162 = new double[10];
        private double[] priorAlt0Down62 = new double[10];
        private double[] priorAlt0Down100 = new double[10];
        private double[] priorAlt0Down162 = new double[10];
        private double[] priorAlt1Up100 = new double[10];
        private double[] priorAlt1Down100 = new double[10];
        private int[] countDown = new int[10];
        private int[] currentSwingHighIndex = new int[10];
        private int[] lastSwingHighIndex = new int[10];
        private int[] currentSwingLowIndex = new int[10];
        private int[] lastSwingLowIndex = new int[10];
        #endregion

        private bool generalError           = false;
        private bool init                   = true;
        private bool initATR                = true;
        private Brush textBrush             = Brushes.Red;
        private SimpleFont textFont         = new SimpleFont("Arial", 12);
        private SimpleFont textFont2         = new SimpleFont("Arial", 10);
        private string errorData            = "Loading of minute data is incomplete. Please refresh chart via F5 or check minute data.";
        private string preloadedData        = "";
        private DateTime firstSessionBegin  = new DateTime(0);
        private bool isIntraday             = true;
        private bool preloadMinuteData      = false;
        private bool isMinuteDataLoaded     = false;
        private bool isMinuteBarsCalled     = false;
        private bool existsHistMinuteData   = false;
        private bool isTrainingComplete     = false;
        private bool drawPreloadInfo        = false;
        private Bars minuteBars             = null;
        private DateTime lastMinuteBarTime  = new DateTime(0);
        private int minuteBarIndex          = 0;

        private double avgTrueRangeLog      = 0;
        private double avgTrueRange         = 0;
        private double timeFrameMultiplier  = 0;
        private double dummy                = 0;
        private bool goAhead                = false;
        private int k                       = 0;
        private int m                       = 0;
        private int n                       = 0;

        private int countResistance         = 0;
        private int countSupport            = 0;
        private int countWeakResistance     = 0;
        private int countWeakSupport        = 0;

        private int tmpOldState             = 0;
        private double tmpFibValue          = 0.0;
		private double lowestResistance     = double.MaxValue;
        private double highestSupport       = double.MinValue;

        private bool highUpdate;
        private bool lowUpdate;
        private bool addHigh;
        private bool addLow;
        private double normalizedRangeUp;
        private double normalizedRangeDown;
        private int highCount;
        private int lowCount;

        private int countLine;
        private double initialWeight;
        private double compoundedWeight;
        private double highestWeight;
		
		private Series<double> ResNear;
		private Series<double> ResFar;
		private Series<double> SupNear;
		private Series<double> SupFar;
		private Series<double> atr;
		private Series<double> SupFar_SL;
		private Series<double> SupFar_T1;
		private Series<double> SupFar_T2;
		private Series<double> SupFar_En;
		private Series<double> SupFar_AH;
		private Series<double> SupFar_AL;
		private Series<double> SupNear_SL;
		private Series<double> SupNear_T1;
		private Series<double> SupNear_T2;
		private Series<double> SupNear_En;
		private Series<double> SupNear_AH;
		private Series<double> SupNear_AL;
		private Series<double> ResFar_SL;
		private Series<double> ResFar_T1;
		private Series<double> ResFar_T2;
		private Series<double> ResFar_En;
		private Series<double> ResFar_AH;
		private Series<double> ResFar_AL;
		private Series<double> ResNear_SL;
		private Series<double> ResNear_T1;
		private Series<double> ResNear_T2;
		private Series<double> ResNear_En;
		private Series<double> ResNear_AH;
		private Series<double> ResNear_AL;

        #region -- zigzag --
        private double currentBarHigh       = 0;
        private double currentBarLow        = 0;
        private double currentBarClose      = 0;
        private double currentBarTrueRange  = 0;
        private double priorBarHigh         = 0;
        private double priorBarLow          = 0;
        private double priorBarClose        = 0;
        private double zigZagFactor         = 0;
        private double displayFactor        = 80.0;
        private double confluenceRange      = 0;
        private int currentBars1            = 0;
        private int priorCurrentBars1       = 0;
        private int lowestTimeFrame         = 0;
        private int highestTimeFrame        = 9;
        private double stepUpRatio          = 1.5;
        #endregion

        #region -- Lines --
        private bool SHOW_WEAKER_LINES          = true;

        private double confluenceRangeWidth     = 0;
        private double upperLimitResistance     = double.MaxValue;
        private double lowerLimitResistance     = 0;
        private double upperLimitSupport        = double.MaxValue;
        private double lowerLimitSupport        = 0;
        private double upperLimitWeakResistance = double.MaxValue;
        private double lowerLimitWeakSupport    = 0;
        #endregion       
        
        #region -- Specific Weights --
        private double specificWeightMicroSwing0 = 44.10;
        private double specificWeightMicroSwing1 = 37.48;
        private double specificWeightMicroSwing2 = 31.86;
        private double specificWeightMicroSwing3 = 27.08;
        private double specificWeightCurrentSwing = 46.42;
        private double specificWeightLastSwing = 39.45;
        private double specificWeightRet23 = 28.44;
        private double specificWeightRet38 = 33.62;
        private double specificWeightRet50 = 36.84;
        private double specificWeightRet62 = 39.58;
        private double specificWeightRet76 = 42.36;
        private double specificWeightExt127 = 50.27;
        private double specificWeightExt162 = 54.51;
        private double specificWeightExt200 = 50.27;
        private double specificWeightExt262 = 42.36;
        private double specificWeightExt300 = 39.58;
        private double specificWeightExt423 = 36.84;
        private double specificWeightDir38 = 36.17;
        private double specificWeightDir62 = 38.16;
        private double specificWeightDir100 = 32.49;
        private double specificWeightLastDir38 = 30.75;
        private double specificWeightLastDir62 = 32.44;
        private double specificWeightLastDir100 = 27.62;
        private double specificWeightAlt62 = 23.75;
        private double specificWeightAlt100 = 27.85;
        private double specificWeightAlt162 = 32.71;
        private double specificWeightAlt100Prior = 23.67;
        private double devalueRet = 0.8;
        private double devalueExt = 0.8;
        private double devalueDir = 0.6;
        private double devalueAlt = 0.6;
        #endregion

        #region -- Arrays --
        private double[] fibLine                = new double[540];
        private double[] fibWeight              = new double[540];
        private double[] fibResistance          = new double[540];
        private double[] weakResistance         = new double[540];
        private double[] weightResistance       = new double[540];
        private double[] fibSupport             = new double[540];
        private double[] weakSupport            = new double[540];
        private double[] weightSupport          = new double[540];

        private double[] timeFrameFactor        = new double[10];
        private double[] weightMicroSwingHigh0  = new double[10];
        private double[] weightMicroSwingHigh1  = new double[10];
        private double[] weightMicroSwingHigh2  = new double[10];
        private double[] weightMicroSwingHigh3  = new double[10];
        private double[] weightMicroSwingLow0   = new double[10];
        private double[] weightMicroSwingLow1   = new double[10];
        private double[] weightMicroSwingLow2   = new double[10];
        private double[] weightMicroSwingLow3   = new double[10];
        private double[] weightCurrentSwingHigh = new double[10];
        private double[] weightLastSwingHigh    = new double[10];
        private double[] weightCurrentSwingLow  = new double[10];
        private double[] weightLastSwingLow     = new double[10];
        private double[] weightRetUp23          = new double[10];
        private double[] weightRetUp38          = new double[10];
        private double[] weightRetUp50          = new double[10];
        private double[] weightRetUp62          = new double[10];
        private double[] weightRetUp76          = new double[10];
        private double[] weightRetDown23        = new double[10];
        private double[] weightRetDown38        = new double[10];
        private double[] weightRetDown50        = new double[10];
        private double[] weightRetDown62        = new double[10];
        private double[] weightRetDown76        = new double[10];
        private double[] weightExtUp127         = new double[10];
        private double[] weightExtUp162         = new double[10];
        private double[] weightExtUp200         = new double[10];
        private double[] weightExtUp262         = new double[10];
        private double[] weightExtUp300         = new double[10];
        private double[] weightExtUp423         = new double[10];
        private double[] weightExtDown127       = new double[10];
        private double[] weightExtDown162       = new double[10];
        private double[] weightExtDown200       = new double[10];
        private double[] weightExtDown262       = new double[10];
        private double[] weightExtDown300       = new double[10];
        private double[] weightExtDown423       = new double[10];
        private double[] weightDirUp38          = new double[10];
        private double[] weightDirUp62          = new double[10];
        private double[] weightDirUp100         = new double[10];
        private double[] weightDirDown38        = new double[10];
        private double[] weightDirDown62        = new double[10];
        private double[] weightDirDown100       = new double[10];
        private double[] weightLastDirUp38      = new double[10];
        private double[] weightLastDirUp62      = new double[10];
        private double[] weightLastDirUp100     = new double[10];
        private double[] weightLastDirDown38    = new double[10];
        private double[] weightLastDirDown62    = new double[10];
        private double[] weightLastDirDown100   = new double[10];
        private double[] weightAlt0Up62         = new double[10];
        private double[] weightAlt0Up100        = new double[10];
        private double[] weightAlt0Up162        = new double[10];
        private double[] weightAlt1Up100        = new double[10];
        private double[] weightAlt0Down62       = new double[10];
        private double[] weightAlt0Down100      = new double[10];
        private double[] weightAlt0Down162      = new double[10];
        private double[] weightAlt1Down100      = new double[10];

        private double[] cumulatedWeightMicroSwingHigh0     = new double[10];
        private double[] cumulatedWeightMicroSwingHigh1     = new double[10];
        private double[] cumulatedWeightMicroSwingHigh2     = new double[10];
        private double[] cumulatedWeightMicroSwingHigh3     = new double[10];
        private double[] cumulatedWeightMicroSwingLow0      = new double[10];
        private double[] cumulatedWeightMicroSwingLow1      = new double[10];
        private double[] cumulatedWeightMicroSwingLow2      = new double[10];
        private double[] cumulatedWeightMicroSwingLow3      = new double[10];
        private double[] cumulatedWeightCurrentSwingHigh    = new double[10];
        private double[] cumulatedWeightLastSwingHigh       = new double[10];
        private double[] cumulatedWeightCurrentSwingLow     = new double[10];
        private double[] cumulatedWeightLastSwingLow        = new double[10];
        private double[] cumulatedWeightRetUp23             = new double[10];
        private double[] cumulatedWeightRetUp38             = new double[10];
        private double[] cumulatedWeightRetUp50             = new double[10];
        private double[] cumulatedWeightRetUp62             = new double[10];
        private double[] cumulatedWeightRetUp76             = new double[10];
        private double[] cumulatedWeightRetDown23           = new double[10];
        private double[] cumulatedWeightRetDown38           = new double[10];
        private double[] cumulatedWeightRetDown50           = new double[10];
        private double[] cumulatedWeightRetDown62           = new double[10];
        private double[] cumulatedWeightRetDown76           = new double[10];
        private double[] cumulatedWeightExtUp127            = new double[10];
        private double[] cumulatedWeightExtUp162            = new double[10];
        private double[] cumulatedWeightExtUp200            = new double[10];
        private double[] cumulatedWeightExtUp262            = new double[10];
        private double[] cumulatedWeightExtUp300            = new double[10];
        private double[] cumulatedWeightExtUp423            = new double[10];
        private double[] cumulatedWeightExtDown127          = new double[10];
        private double[] cumulatedWeightExtDown162          = new double[10];
        private double[] cumulatedWeightExtDown200          = new double[10];
        private double[] cumulatedWeightExtDown262          = new double[10];
        private double[] cumulatedWeightExtDown300          = new double[10];
        private double[] cumulatedWeightExtDown423          = new double[10];
        private double[] cumulatedWeightDirUp38             = new double[10];
        private double[] cumulatedWeightDirUp62             = new double[10];
        private double[] cumulatedWeightDirUp100            = new double[10];
        private double[] cumulatedWeightDirDown38           = new double[10];
        private double[] cumulatedWeightDirDown62           = new double[10];
        private double[] cumulatedWeightDirDown100          = new double[10];
        private double[] cumulatedWeightLastDirUp38         = new double[10];
        private double[] cumulatedWeightLastDirUp62         = new double[10];
        private double[] cumulatedWeightLastDirUp100        = new double[10];
        private double[] cumulatedWeightLastDirDown38       = new double[10];
        private double[] cumulatedWeightLastDirDown62       = new double[10];
        private double[] cumulatedWeightLastDirDown100      = new double[10];
        private double[] cumulatedWeightAlt0Up62            = new double[10];
        private double[] cumulatedWeightAlt0Up100           = new double[10];
        private double[] cumulatedWeightAlt0Up162           = new double[10];
        private double[] cumulatedWeightAlt1Up100           = new double[10];
        private double[] cumulatedWeightAlt0Down62          = new double[10];
        private double[] cumulatedWeightAlt0Down100         = new double[10];
        private double[] cumulatedWeightAlt0Down162         = new double[10];
        private double[] cumulatedWeightAlt1Down100         = new double[10];

        private double[] strongFibs         = new double[20];
        private double[] weakFibs           = new double[20];
        private double[] priorStrongFibs    = new double[20];
        private double[] priorWeakFibs      = new double[20];
        private double[] oldStrongFibs      = new double[20];
        private double[] oldWeakFibs        = new double[20];
        private double[] newBOBHigh         = new double[40];
        private double[] oldBOBHigh         = new double[40];
        private double[] newBOBLow          = new double[40];
        private double[] oldBOBLow          = new double[40];
        private double[] newBOBClose        = new double[40];
        private double[] oldBOBClose        = new double[40];
        private int[] newState              = new int[40];
        private int[] oldState              = new int[40];
        #endregion
		
        #endregion
		System.Collections.Generic.List<int> SL_List = new System.Collections.Generic.List<int>();
		System.Collections.Generic.List<int> T1_List = new System.Collections.Generic.List<int>();
		System.Collections.Generic.List<int> T2_List = new System.Collections.Generic.List<int>();

		private const int SUP_ID = 1;
		private const int RES_ID = -1;
		private string ObjTagPrefix = string.Empty;
		static string  HLtemplates_folder = null;
		private SortedDictionary<string, bool> IsGlobalized = new SortedDictionary<string,bool>();
		#region -- Global_RaysData --------------------------------------------------
		private class Global_RaysData{
			public int LMAbar = 0;
			public int Type = -1;//if Support = 1, if Resistance -1
			public DateTime DT;
			public double Price;
			public string TemplateName;
			public bool IsDrawn = false;
			public DateTime EndDT = DateTime.MaxValue;
			public Global_RaysData(DateTime dt, int leftABar, int res_or_sup, double price, string templatename){
				DT=dt; Price=price; LMAbar = leftABar; Type = res_or_sup; TemplateName=templatename.Replace(" Ray Template",string.Empty); IsDrawn=false; EndDT = DateTime.MaxValue;
			}
		}
		#endregion
		private SortedDictionary<string,Global_RaysData> GlobalRays = new SortedDictionary<string,Global_RaysData>();

		private int line=0;
        #region -- variables for benchmark --
        private DateTime benchStart = new DateTime(0);
        private DateTime benchStop  = new DateTime(0);
        private bool getBench       = false;
        #endregion
		
		#region Variables for button interface
		private int pButtonSize = 15;
		private string toolbarname = "NSGoldenFibsSystemToolBar", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;

		private Menu MenuControlContainer;
		private MenuItem MenuControl, btn_RecalcTradePlans, btn_RecalcMktStructure;
        private Button      ClearGlobals_Button;
		private Button		EnableGlobals_Button;

//		private ComboBox comboEntryBasis, comboProfile;
		private MenuItem miDominantTP, miEntryBasis, miPlanLevelsBasis, miShowLongTP, miShowShortTP, miShowNearTP, miShowFarTP;
		private MenuItem miGlobalize_FarSell, miGlobalize_FarBuy, miGlobalize_NearBuy, miGlobalize_NearSell, miGlobalize_All;
		private MenuItem miShowT2, miShowT1, miShowSL;
		private MenuItem miCurSL, miAvgSL, miAvgT1, miAvgT2;
		private Label label_SLsize, label_T1size, label_T2size;
		private int GlobalObjCount = 0;

		private TextBox nudSwingStrength, nudATRperiod, nudEntryZoneMult, nudSLsize, nudT1size, nudT2size;

		private Button gCmdup;
		private Button gCmddw;
		private Label gLabel;
		#endregion
		private bool ParameterChanged = false;
		private SimpleFont ZZlabelFont;
		private int SLdistanceTicks = 0;
		private int T1distanceTicks = 0;
		private int T2distanceTicks = 0;

        private Grid createTradePlan_Grid(string id, string val)
        {
			#region Grid maker
			const int rHeight = 26;

			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(100) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(50) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });

			if(id == "ATRperiod"){
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight/2) });
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight/2) });
				var label = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "    ATR period: "};
				label.SetValue(Grid.ColumnProperty, 0);
				label.SetValue(Grid.RowProperty, 0);
				label.SetValue(Grid.RowSpanProperty, 2);
				nudATRperiod = new TextBox() { Name = "TradePlan_ATRPeriod" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
				nudATRperiod.Text         = val;
				nudATRperiod.KeyDown     += menuTxtbox_KeyDown;
				nudATRperiod.MouseWheel += MouseWheelEvent;
				nudATRperiod.SetValue(Grid.ColumnProperty, 1);
				nudATRperiod.SetValue(Grid.RowProperty, 0);
				nudATRperiod.SetValue(Grid.RowSpanProperty, 4);

				Button cmdup1 = new Button() { Name = id+"cmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
				Button cmddw1 = new Button() { Name = id+"cmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
				cmdup1.Click += cmdupdw_Click;
				cmdup1.SetValue(Grid.ColumnProperty, 2);
				cmdup1.SetValue(Grid.RowProperty, 0);
				cmddw1.Click += cmdupdw_Click;
				cmddw1.SetValue(Grid.ColumnProperty, 2);
				cmddw1.SetValue(Grid.RowProperty, 1);

				grid.Children.Add(label);
	            grid.Children.Add(nudATRperiod);
	            grid.Children.Add(cmdup1);
	            grid.Children.Add(cmddw1);
			}else if (id=="EntryZoneSize"){
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
				var label = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "EntryZone Size ATRs: " };
				label.SetValue(Grid.ColumnProperty, 0);
				label.SetValue(Grid.RowProperty, 0);
				label.SetValue(Grid.RowSpanProperty, 2);

				nudEntryZoneMult = new TextBox() { Name = "TradePlan_EntryZoneSize" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
				nudEntryZoneMult.Text         = val;
				nudEntryZoneMult.KeyDown    += menuTxtbox_KeyDown;
				nudEntryZoneMult.MouseWheel += MouseWheelEvent;
				nudEntryZoneMult.SetValue(Grid.ColumnProperty, 1);
				nudEntryZoneMult.SetValue(Grid.RowProperty, 0);
				nudEntryZoneMult.SetValue(Grid.RowSpanProperty, 2);
				grid.Children.Add(label);
	            grid.Children.Add(nudEntryZoneMult);
			}else if (id.StartsWith("SLsize")){
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
				label_SLsize = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "SL Size: " };
				label_SLsize.SetValue(Grid.ColumnProperty, 0);
				label_SLsize.SetValue(Grid.RowProperty, 0);
				label_SLsize.SetValue(Grid.RowSpanProperty, 2);
				nudSLsize = new TextBox() { Name = "TradePlan_SLsize" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
				nudSLsize.Text         = val;
				nudSLsize.KeyDown     += menuTxtbox_KeyDown;
				nudSLsize.MouseWheel += MouseWheelEvent;
				nudSLsize.SetValue(Grid.ColumnProperty, 1);
				nudSLsize.SetValue(Grid.RowProperty, 0);
				nudSLsize.SetValue(Grid.RowSpanProperty, 2);
				grid.Children.Add(label_SLsize);
	            grid.Children.Add(nudSLsize);
			}else if (id=="T1size"){
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
				label_T1size = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "          T1 Size: " };
				label_T1size.SetValue(Grid.ColumnProperty, 0);
				label_T1size.SetValue(Grid.RowProperty, 0);
				label_T1size.SetValue(Grid.RowSpanProperty, 2);

				nudT1size = new TextBox() { Name = "TradePlan_T1size" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
				nudT1size.Text         = val;
				nudT1size.KeyDown     += menuTxtbox_KeyDown;
				nudT1size.MouseWheel += MouseWheelEvent;
				nudT1size.SetValue(Grid.ColumnProperty, 1);
				nudT1size.SetValue(Grid.RowProperty, 0);
				nudT1size.SetValue(Grid.RowSpanProperty, 2);
				grid.Children.Add(label_T1size);
	            grid.Children.Add(nudT1size);
			}else if (id=="T2size"){
				grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });
				label_T2size = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "          T2 Size: " };
				label_T2size.SetValue(Grid.ColumnProperty, 0);
				label_T2size.SetValue(Grid.RowProperty, 0);
				label_T2size.SetValue(Grid.RowSpanProperty, 2);

				nudT2size = new TextBox() { Name = "TradePlan_T2size" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
				nudT2size.Text         = val;
				nudT2size.KeyDown     += menuTxtbox_KeyDown;
				nudT2size.MouseWheel += MouseWheelEvent;
				nudT2size.SetValue(Grid.ColumnProperty, 1);
				nudT2size.SetValue(Grid.RowProperty, 0);
				nudT2size.SetValue(Grid.RowSpanProperty, 2);
				grid.Children.Add(label_T2size);
	            grid.Children.Add(nudT2size);
			}
			return grid;
			#endregion
		}
		private void SetLabelsAndTextBoxValues_ATRorTicks(){
			if(SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.ATR){
				label_SLsize.Content = "   SL Size ATRs: ";
				label_T1size.Content = "   T1 Size ATRs: ";
				label_T2size.Content = "   T2 Size ATRs: ";
				nudSLsize.Text = SLsize_inATRs.ToString("0.0");
				nudT1size.Text = T1size_inATRs.ToString("0.0");
				nudT2size.Text = T2size_inATRs.ToString("0.0");
			}else{
				label_SLsize.Content = "  SL Size Ticks: ";
				label_T1size.Content = "  T1 Size Ticks: ";
				label_T2size.Content = "  T2 Size Ticks: ";
				nudSLsize.Text = SLsize_inTicks.ToString("0");
				nudT1size.Text = T1size_inTicks.ToString("0");
				nudT2size.Text = T2size_inTicks.ToString("0");
			}
		}
        private Grid createMktStructure_Menu(string nudValue)
        {
			#region Grid maker
			const int rHeight = 26;

			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
//			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
//			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

			//line 1 - MST1
			var label = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Swing Strength: " };
			label.SetValue(Grid.ColumnProperty, 0);
			label.SetValue(Grid.RowProperty, 0);
			label.SetValue(Grid.RowSpanProperty, 2);

			nudSwingStrength = new TextBox() { Name = "MktStructure_SwingStrength" + uID, MinWidth = 75, Width = 75, MaxWidth = 75, Height = rHeight, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
			nudSwingStrength.Text = nudValue;
			nudSwingStrength.KeyDown += menuTxtbox_KeyDown;
			nudSwingStrength.MouseWheel += MouseWheelEvent;
			nudSwingStrength.SetValue(Grid.ColumnProperty, 1);
			nudSwingStrength.SetValue(Grid.RowProperty, 0);
			nudSwingStrength.SetValue(Grid.RowSpanProperty, 2);

			Button cmdup1 = new Button() { Name = "SwingStrengthcmdup" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
			Button cmddw1 = new Button() { Name = "SwingStrengthcmddw" + uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
			cmdup1.Click += cmdupdw_Click;
			cmdup1.SetValue(Grid.ColumnProperty, 2);
			cmdup1.SetValue(Grid.RowProperty, 0);
			cmddw1.Click += cmdupdw_Click;
			cmddw1.SetValue(Grid.ColumnProperty, 2);
			cmddw1.SetValue(Grid.RowProperty, 1);

			grid.Children.Add(label);
            grid.Children.Add(nudSwingStrength);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            return grid;
			#endregion
        }
        private void cmdupdw_Click(object sender, RoutedEventArgs e)
        {
	        #region cmdupdw_Click
			Button cmd = sender as Button;
			if (cmd.Name.Contains("SwingStrength")){
				if(cmd.Name.Contains("up")) nudSwingStrength.Text = Math.Min(200, Convert.ToInt32(nudSwingStrength.Text) + 1).ToString();
				else nudSwingStrength.Text = Math.Max(1, Convert.ToInt32(nudSwingStrength.Text) - 1).ToString();
			}
			else if (cmd.Name.Contains("ATRperiod")){
				if(cmd.Name.Contains("up")) nudATRperiod.Text = Math.Min(100, Convert.ToInt32(nudATRperiod.Text) + 1).ToString();
				else nudATRperiod.Text = Math.Max(1, Convert.ToInt32(nudATRperiod.Text) - 1).ToString();
			}
	        #endregion
        }

		private void PlaySoundAlert2(string wav = "alert2.wav"){
			PlaySound( System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", wav));
		}
		private void menuTxtbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			#region menuTxtbox_KeyDown
			e.Handled = true;
			TextBox txtSender = sender as TextBox;
			int cursor_location = txtSender.SelectionStart;
			int keyVal = (int)e.Key;
			int new_number = -1;
			if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) {
				new_number = keyVal - (int)System.Windows.Input.Key.D0;
			}else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) {
				new_number = keyVal - (int)System.Windows.Input.Key.NumPad0;
			}

			bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.Decimal;
			isNumeric = isNumeric || e.Key==System.Windows.Input.Key.OemPeriod;

			if (isNumeric || e.Key == System.Windows.Input.Key.Back)
			{
				string newText = new_number != -1 ? new_number.ToString() : "";
				if(!txtSender.Text.Contains(".")){
					if(e.Key==System.Windows.Input.Key.Decimal) newText = ".";
					else if(e.Key==System.Windows.Input.Key.OemPeriod) newText = ".";
				}
				try{
					if(txtSender.SelectedText.Length==0)
						txtSender.Text = txtSender.Text.Insert(cursor_location, newText);
					else{
						txtSender.Text = txtSender.Text.Replace(txtSender.SelectedText, newText);
					}
				}catch(Exception t){Print("menuTxtbox_KeyDown: "+t.ToString());}
				cursor_location++;
			}

			string intxt = txtSender.Text;
			intxt = intxt.Replace("-",string.Empty);//no negative values allowed
			intxt = intxt.Trim();
			if (intxt.Length > 0)
			{
				txtSender.Text = this.ChangeTextValue(txtSender.Name, intxt, 0);
				txtSender.SelectionStart = Math.Min(txtSender.Text.Length,cursor_location);
            }            
			#endregion
		}

        private void MouseWheelEvent(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
			#region ----- MouseWheelEvent -----
			TextBox txtSender = sender as TextBox;
			string intxt = txtSender.Text;

			if(txtSender.Name.Contains("MktStructure_SwingStrength")){
				txtSender.Text = ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 1 : -1);
			}
			else if(txtSender.Name.StartsWith("TradePlan_ATRPeriod")){
				txtSender.Text = ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 1 : -1);
			}
			else if(txtSender.Name.StartsWith("TradePlan_SLsize")){
				if(SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.ATR)
					txtSender.Text = ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 0.1 : -0.1);
				else
					txtSender.Text = ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 1 : -1);
			}
			else if(txtSender.Name.StartsWith("TradePlan_T1size")){
				if(SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.ATR)
					txtSender.Text = ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 0.1 : -0.1);
				else
					txtSender.Text = ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 1 : -1);
			}
			else if(txtSender.Name.StartsWith("TradePlan_T2size")){
				if(SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.ATR)
					txtSender.Text = ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 0.1 : -0.1);
				else
					txtSender.Text = ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 1 : -1);
			}
			else{
				txtSender.Text = ChangeTextValue(txtSender.Name, txtSender.Text, e.Delta>0 ? 0.1 : -0.1);
			}
			#endregion
        }

		private void InformUserAboutRecalculation(){
			btn_RecalcTradePlans.Background = Brushes.Yellow;
			btn_RecalcMktStructure.Background = Brushes.Yellow;
			miCurSL.Header = "Click here to calculate";
			miAvgSL.Header = "";
			miAvgT1.Header = "";
			miAvgT2.Header = "";
		}
        private void tradeplanMasterMenuItem_Click(object sender, EventArgs e)
        {
	        #region tradeplanMasterMenuItem_Click
            MenuItem item = sender as MenuItem;
			if(item==null) return;
            #region -- dominantTradePlan --
            if (item.Name.StartsWith("dominantTradePlan"))
            {
                if (item.Header.ToString().EndsWith("LONG")) {
                    this.DominantTradePlan = ARC_GFSystem_DominantTradePlan.Short;
                    item.Header = item.Header.ToString().Replace("LONG","SHORT");
                } else if (item.Header.ToString().EndsWith("SHORT")) {
                    this.DominantTradePlan = ARC_GFSystem_DominantTradePlan.None;
                    item.Header = item.Header.ToString().Replace("SHORT","NONE");
                } else {
                    this.DominantTradePlan = ARC_GFSystem_DominantTradePlan.Long;
                    item.Header = item.Header.ToString().Replace("NONE","LONG");
                }
            }
            #endregion
            #region -- entryBasis --
            else if (item.Name.StartsWith("entryBasis"))
            {
				if (item.Header.ToString().EndsWith("AtATR")) {
                    this.EntryBasis = ARC_GFSystem_TradeEntryBasis.AtFibPrice;
                    item.Header = item.Header.ToString().Replace("AtATR","AtFibPrice");
                } else if (item.Header.ToString().EndsWith("AtFibPrice")) {
                    this.EntryBasis = ARC_GFSystem_TradeEntryBasis.AtMidPrice;
                    item.Header = item.Header.ToString().Replace("AtFibPrice","AtMidPrice");
                } else {
                    this.EntryBasis = ARC_GFSystem_TradeEntryBasis.AtATR;
                    item.Header = item.Header.ToString().Replace("AtMidPrice","AtATR");
                }
				InformUserAboutRecalculation();
            }
            #endregion
            #region -- PlanLevelsBasis --
            else if (item.Name.StartsWith("PlanLevelsBasis"))
            {
				if (item.Header.ToString().EndsWith("AtEntryPrice")) {
                    this.PlanLevelsBasis = ARC_GFSystem_Plan_LevelsBasis.AtFib;
                    item.Header = item.Header.ToString().Replace("AtEntryPrice","AtFib");
                } else {
                    this.PlanLevelsBasis = ARC_GFSystem_Plan_LevelsBasis.AtEntryPrice;
                    item.Header = item.Header.ToString().Replace("AtFib","AtEntryPrice");
                }
				InformUserAboutRecalculation();
            }
            #endregion
//miEntryBasis = new MenuItem { Header = "Entry Basis "+ this.EntryBasis.ToString(), Name = "entryBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };

            #region -- showLongTradePlans --
            else if (item.Name.StartsWith("showLongTradePlans"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.ShowLongTradePlans = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
                } else {
                    this.ShowLongTradePlans = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
                }
            }
            #endregion
            #region -- showShortTradePlans --
            else if (item.Name.StartsWith("showShortTradePlans"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.ShowShortTradePlans = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
                } else {
                    this.ShowShortTradePlans = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
                }
            }
            #endregion
            #region -- showNearTradePlans --
            else if (item.Name.StartsWith("showNearTradePlans"))
            {
                if (item.Header.ToString().EndsWith("ON")) {
                    this.ShowNearTradePlan = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
                } else {
                    this.ShowNearTradePlan = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
                }
            }
            #endregion
			#region -- showFarTradePlans --
			if (item.Name.StartsWith("showFarTradePlans"))
			{
				if (item.Header.ToString().EndsWith("ON")) {
					this.ShowFarTradePlan = false;
					item.Header = item.Header.ToString().Replace("ON","OFF");
				} else {
					this.ShowFarTradePlan = true;
					item.Header = item.Header.ToString().Replace("OFF","ON");
				}
			}
			#endregion
			#region -- Show T1 line, T2 line and SL line --
			if (item.Name.StartsWith("showT1"))
			{
				if (item.Header.ToString().EndsWith("ON")) {
					this.ShowT1 = false;
					item.Header = item.Header.ToString().Replace("ON","OFF");
				} else {
					this.ShowT1 = true;
					item.Header = item.Header.ToString().Replace("OFF","ON");
				}
			}
			else if (item.Name.StartsWith("showT2"))
			{
				if (item.Header.ToString().EndsWith("ON")) {
					this.ShowT2 = false;
					item.Header = item.Header.ToString().Replace("ON","OFF");
				} else {
					this.ShowT2 = true;
					item.Header = item.Header.ToString().Replace("OFF","ON");
				}
			}
			else if (item.Name.StartsWith("showSL"))
			{
				if (item.Header.ToString().EndsWith("ON")) {
					this.ShowSL = false;
					item.Header = item.Header.ToString().Replace("ON","OFF");
				} else {
					this.ShowSL = true;
					item.Header = item.Header.ToString().Replace("OFF","ON");
				}
			}
			else if (item.Name.StartsWith("SLTP_CalcBasis"))
			{
				if (item.Header.ToString().EndsWith("ATR")) {
					this.SLTP_CalcBasis = ARC_GFSystem_SLTP_CalcBasis.Ticks;
					item.Header = item.Header.ToString().Replace("ATR","Ticks");
				} else {
					this.SLTP_CalcBasis = ARC_GFSystem_SLTP_CalcBasis.ATR;
					item.Header = item.Header.ToString().Replace("Ticks","ATR");
				}
				SetLabelsAndTextBoxValues_ATRorTicks();
				InformUserAboutRecalculation();
				SLCalcBasis_SetVisibilityOfInputs();
			}
			#endregion

			#region -- Hit the RecalcTradePlans button --
			if (item.Name.StartsWith("RecalcTradePlansClick"))
			{
				this.ATRperiod            = (int)Math.Max(1.00,Math.Min(100,Convert.ToInt32(nudATRperiod.Text)));
				this.EntryZoneSize_inATRs = Math.Max(0.01,Math.Min(3,  Convert.ToDouble(nudEntryZoneMult.Text)));
				if(SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.ATR){
					this.SLsize_inATRs       = Math.Max(0.0, Math.Min(100,Convert.ToDouble(nudSLsize.Text)));
					this.T1size_inATRs       = Math.Max(0.0, Math.Min(100,Convert.ToDouble(nudT1size.Text)));
					this.T2size_inATRs       = Math.Max(0.0, Math.Min(100,Convert.ToDouble(nudT2size.Text)));
				}else{
					this.SLsize_inTicks      = Convert.ToInt32(Math.Max(0.0, Math.Min(10000,Convert.ToDouble(nudSLsize.Text))));
					this.T1size_inTicks      = Convert.ToInt32(Math.Max(0.0, Math.Min(10000,Convert.ToDouble(nudT1size.Text))));
					this.T2size_inTicks      = Convert.ToInt32(Math.Max(0.0, Math.Min(10000,Convert.ToDouble(nudT2size.Text))));
				}
				System.Windows.Forms.SendKeys.SendWait("{F5}");
				btn_RecalcTradePlans.Background = null;
				btn_RecalcMktStructure.Background = null;
				return;
			}
			#endregion
			else{
				ParameterChanged = true;
			    ChartControl.InvalidateVisual();
			}
			#endregion
        }

        private void structureMenuItem_Click(object sender, EventArgs e)
        {
	        #region structureMenuItem_Click
			MenuItem item = sender as MenuItem;
//Print("Item.Name; "+item.Name+"   header: "+item.Header.ToString());
			#region -- RecalcMarketStructureClick --
			if (item.Name.Contains("RecalcMarketStructureClick"))
			{
				this.SwingStrength = Convert.ToInt32(nudSwingStrength.Text);
				InformUserAboutRecalculation();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
				return;
			}
			#endregion
			#region -- Calculate CurSL, AvgSL, AvgT1 and AvgT2 --
			else if (item.Name.Contains("CurSL_") && miCurSL.Header.ToString().StartsWith("Click here to calculate"))
			{
				miCurSL.Header = "Cur SL: N/A";
				System.Windows.Forms.SendKeys.SendWait("{F5}");
				return;
			}
			#endregion
            #region -- showMarketStructureClick --
            else if (item.Name.Contains( "showStructureLinesClick"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.ShowStructureLines = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
                }
                else
                {
                    this.ShowStructureLines = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
                }
            }
            #endregion
            #region -- showStructureBkgClick --
            else if (item.Name.Contains("showStructureBkgClick"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.ShowStructureBackground = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
                }
                else
                {
                    this.ShowStructureBackground = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
                }
				btn_RecalcTradePlans.Background = Brushes.Yellow;
				btn_RecalcMktStructure.Background = Brushes.Yellow;
            }
            #endregion
            #region -- showStructureLabelsClick --
            else if (item.Name.Contains( "showStructureLabelsClick"))
            {
                if (item.Header.ToString().EndsWith("ON"))
                {
                    this.ShowStructureLabels = false;
                    item.Header = item.Header.ToString().Replace("ON","OFF");
                }
                else
                {
                    this.ShowStructureLabels = true;
                    item.Header = item.Header.ToString().Replace("OFF","ON");
                }
            }
            #endregion
            ChartControl.InvalidateVisual();
	        #endregion
        }

		private string ChangeTextValue(string SenderName, string intxt, double change_amount){
	        #region ChangeTextValue
			if (SenderName.Contains("MktStructure_SwingStrength")) {
				intxt = intxt.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
				SwingStrength = Math.Max(1,Convert.ToInt32(intxt) + Convert.ToInt32(change_amount));
				InformUserAboutRecalculation();
				return SwingStrength.ToString();
			}
			else if (SenderName.StartsWith("TradePlan_ATRPeriod")) {
				intxt = intxt.Replace(".",string.Empty);//inbound text is an integer, decimal is stripped out
				int num = Convert.ToInt32(intxt) + Convert.ToInt32(change_amount);
				bool isInRange = num>=1 && num<=100;
				if(isInRange){
					this.ATRperiod   = num;
					ParameterChanged = true;
					InformUserAboutRecalculation();
		            ChartControl.InvalidateVisual();
					return ATRperiod.ToString();
				}
			}
			else if (SenderName.StartsWith("TradePlan_EntryZoneSize")) {
				double num = Convert.ToDouble(intxt) + change_amount;
				bool isInRange = num>=0.0 && num<=3;
				if(isInRange){
					EntryZoneSize_inATRs = num;
					ParameterChanged     = true;
					InformUserAboutRecalculation();
		            ChartControl.InvalidateVisual();
					string res = EntryZoneSize_inATRs.ToString();
					if(!res.Contains(".")) return res+".0";
					return res;
				}
			}
			else if (SenderName.StartsWith("TradePlan_SLsize")) {
				if(SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.ATR){
					double num = Convert.ToDouble(intxt) + change_amount;
					bool isInRange = num>=0.0 && num<=100;
					if(isInRange){
						this.SLsize_inATRs = num;
						ParameterChanged   = true;
						InformUserAboutRecalculation();
			            ChartControl.InvalidateVisual();
						string res = SLsize_inATRs.ToString();
						if(!res.Contains(".")) return res+".0";
						return res;
					}
				}else{
					double num = Convert.ToInt32(intxt) + change_amount;
					bool isInRange = num>=0.0 && num<=10000;
					if(isInRange){
						this.SLsize_inTicks = Convert.ToInt32(num);
						ParameterChanged   = true;
						InformUserAboutRecalculation();
			            ChartControl.InvalidateVisual();
						return SLsize_inTicks.ToString();
					}
				}
			}
			else if (SenderName.StartsWith("TradePlan_T1size")){
				if(SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.ATR){
					double num = Convert.ToDouble(intxt) + change_amount;
					bool isInRange = num>=0.0 && num<=100;
					if(isInRange){
						this.T1size_inATRs = num;
						ParameterChanged    = true;
						InformUserAboutRecalculation();
			            ChartControl.InvalidateVisual();
						string res = T1size_inATRs.ToString();
						if(!res.Contains(".")) return res+".0";
						return res;
					}
				}else{
					double num = Convert.ToInt32(intxt) + change_amount;
					bool isInRange = num>=0.0 && num<=10000;
					if(isInRange){
						this.T1size_inTicks = Convert.ToInt32(num);
						ParameterChanged   = true;
						InformUserAboutRecalculation();
			            ChartControl.InvalidateVisual();
						return T1size_inTicks.ToString();
					}
				}
			}
			else if (SenderName.StartsWith("TradePlan_T2size")){
				if(SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.ATR){
					double num = Convert.ToDouble(intxt) + change_amount;
					bool isInRange = num>=0.0 && num<=100;
					if(isInRange){
						this.T2size_inATRs = num;
						ParameterChanged    = true;
						InformUserAboutRecalculation();
			            ChartControl.InvalidateVisual();
						string res = T2size_inATRs.ToString();
						if(!res.Contains(".")) return res+".0";
						return res;
					}
				}else{
					double num = Convert.ToInt32(intxt) + change_amount;
					bool isInRange = num>=0.0 && num<=10000;
					if(isInRange){
						this.T2size_inTicks = Convert.ToInt32(num);
						ParameterChanged   = true;
						InformUserAboutRecalculation();
			            ChartControl.InvalidateVisual();
						return T2size_inTicks.ToString();
					}
				}
			}
			return intxt;
			#endregion
		}
//=====================================================================================================
		private int CalculateCountOfGlobalObjects(){
			var Tag1 = string.Format("@{0} {1}", "FS", ObjTagPrefix);
			var Tag2 = string.Format("@{0} {1}", "FB", ObjTagPrefix);
			var Tag3 = string.Format("@{0} {1}", "NS", ObjTagPrefix);
			var Tag4 = string.Format("@{0} {1}", "NB", ObjTagPrefix);
			var objects = DrawObjects.Where(ob=> ob.Tag.StartsWith(Tag1) || ob.Tag.StartsWith(Tag2) || ob.Tag.StartsWith(Tag3) || ob.Tag.StartsWith(Tag4));
			if(objects==null) return 0;
			return objects.Count();
		}

		#region addGFSToolBar
		//==============================================================
		private void addGFSToolBar()
		{
			gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
			gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "??", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
			gLabel = new Label();//#RJBug001

			MenuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
			MenuControl          = new MenuItem {Name="GFS"+uID,  BorderThickness = new Thickness(2), BorderBrush = Brushes.White, Header = pButtonText, Foreground = Brushes.White, Background = Brushes.Blue, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControl.GotFocus += delegate(object o, RoutedEventArgs e){
				GlobalObjCount = CalculateCountOfGlobalObjects();
				if(GlobalObjCount>0){
					ClearGlobals_Button.Background = Brushes.DarkGreen;
					ClearGlobals_Button.Content    = "Clear Globals";
					ClearGlobals_Button.Visibility = Visibility.Visible;
				}else
					ClearGlobals_Button.Visibility = Visibility.Collapsed;
			};
			MenuControlContainer.Items.Add(MenuControl);

			#region -- Reg TradePlanMaster --
			MenuItem miTPMaster = new MenuItem { Header = "TradePlan Master", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			miDominantTP = new MenuItem { Header = "Dominant Trade Plan: "+ this.DominantTradePlan.ToString().ToUpper(), Name = "dominantTradePlan"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miDominantTP.Click += tradeplanMasterMenuItem_Click;
			miTPMaster.Items.Add(miDominantTP);

			miEntryBasis = new MenuItem { Header = "Entry Basis: "+ this.EntryBasis.ToString(), Name = "entryBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miEntryBasis.Click += tradeplanMasterMenuItem_Click;
			miTPMaster.Items.Add(miEntryBasis);

			miPlanLevelsBasis = new MenuItem { Header = "Plan Level Basis: "+ this.PlanLevelsBasis.ToString(), Name = "PlanLevelsBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miPlanLevelsBasis.Click += tradeplanMasterMenuItem_Click;
			miTPMaster.Items.Add(miPlanLevelsBasis);

			miTPMaster.Items.Add(new Separator());

			miShowLongTP = new MenuItem { Header = this.ShowLongTradePlans ? "Long TradePlans ON" : "Long TradePlans OFF", Name = "showLongTradePlans"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowLongTP.Click += tradeplanMasterMenuItem_Click;
			miTPMaster.Items.Add(miShowLongTP);

			miShowShortTP = new MenuItem { Header = ShowShortTradePlans ? "Short TradePlans ON" : "Short TradePlans OFF", Name = "showShortTradePlans"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowShortTP.Click += tradeplanMasterMenuItem_Click;
			miTPMaster.Items.Add(miShowShortTP);

			miShowNearTP = new MenuItem { Header = ShowNearTradePlan ? "Near TradePlans ON" : "Near TradePlans OFF", Name = "showNearTradePlans"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowNearTP.Click += tradeplanMasterMenuItem_Click;
			miTPMaster.Items.Add(miShowNearTP);

			miShowFarTP = new MenuItem { Header = ShowFarTradePlan ? "Far TradePlans ON" : "Far TradePlans OFF", Name = "showFarTradePlans"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowFarTP.Click += tradeplanMasterMenuItem_Click;
			miTPMaster.Items.Add(miShowFarTP);
			miTPMaster.Items.Add(new Separator());

			miShowT2 = new MenuItem { Header = ShowT2 ? "Show T2 ON" : "Show T2 OFF", Name = "showT2"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowT2.Click += tradeplanMasterMenuItem_Click;
			miTPMaster.Items.Add(miShowT2);

			miShowT1 = new MenuItem { Header = ShowT1 ? "Show T1 ON" : "Show T1 OFF", Name = "showT1"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowT1.Click += tradeplanMasterMenuItem_Click;
			miTPMaster.Items.Add(miShowT1);

			miShowSL = new MenuItem { Header = ShowSL ? "Show SL ON" : "Show SL OFF", Name = "showSL"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowSL.Click += tradeplanMasterMenuItem_Click;
			miTPMaster.Items.Add(miShowSL);

			miTPMaster.Items.Add(new Separator());

			var mi = new MenuItem { Header = "SL/Tgt based on:   "+SLTP_CalcBasis.ToString(), Name = "SLTP_CalcBasis"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			mi.Click += tradeplanMasterMenuItem_Click;
//			mi.Background = Brushes.Silver;
			miTPMaster.Items.Add(mi);

			miTPMaster.Items.Add(createTradePlan_Grid("ATRperiod", ATRperiod.ToString()));
			miTPMaster.Items.Add(createTradePlan_Grid("EntryZoneSize", EntryZoneSize_inATRs.ToString()));
			miTPMaster.Items.Add(createTradePlan_Grid("SLsize", SLsize_inATRs.ToString()));
			miTPMaster.Items.Add(createTradePlan_Grid("T1size", T1size_inATRs.ToString()));
			miTPMaster.Items.Add(createTradePlan_Grid("T2size", T2size_inATRs.ToString()));
			SetLabelsAndTextBoxValues_ATRorTicks();

			miTPMaster.Items.Add(new Separator());

			btn_RecalcTradePlans = new MenuItem { Header = "RE-CALCULATE TRADE PLANS", Name = "RecalcTradePlansClick", HorizontalAlignment = HorizontalAlignment.Center };
			btn_RecalcTradePlans.Click += tradeplanMasterMenuItem_Click;
			btn_RecalcTradePlans.Background = null;
			miTPMaster.Items.Add(btn_RecalcTradePlans);

			MenuControl.Items.Add(miTPMaster);
			#endregion

			#region -- RegMarketStructure --
			MenuItem miMarketStructure = new MenuItem { Header = "Market Structure", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

			MenuItem miMarketStructureLines = new MenuItem { Header = ShowStructureLines ? "Structure Lines ON" : "Structure Lines OFF", Name = "showStructureLinesClick"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miMarketStructureLines.Click += structureMenuItem_Click;
			miMarketStructure.Items.Add(miMarketStructureLines);

			MenuItem miShowStructureLabels = new MenuItem { Header = ShowStructureLabels ? "Structure Labels ON" : "Structure Labels OFF", Name = "showStructureLabelsClick"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miShowStructureLabels.Click += structureMenuItem_Click;
			miMarketStructure.Items.Add(miShowStructureLabels);

			MenuItem miMarketStructureBkg = new MenuItem { Header = ShowStructureBackground ? "Structure Background ON" : "Structure Background OFF", Name = "showStructureBkgClick"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
			miMarketStructureBkg.Click += structureMenuItem_Click;
			miMarketStructure.Items.Add(miMarketStructureBkg);

			miMarketStructure.Items.Add(createMktStructure_Menu(this.SwingStrength.ToString()));
			miMarketStructure.Items.Add(new Separator());

			btn_RecalcMktStructure = new MenuItem { Header = "RE-CALCULATE STRUCTURE", Name = "RecalcMarketStructureClick"+uID, HorizontalAlignment = HorizontalAlignment.Center };
			btn_RecalcMktStructure.Click += structureMenuItem_Click;
			miMarketStructure.Items.Add(btn_RecalcMktStructure);
			//------------------

			MenuControl.Items.Add(miMarketStructure);
			#endregion

			#region -- Reg AvgTickCalculators --
			var miAvgTickCalcs = new MenuItem { Header = "Avg Tick Calculators",Name = "AvgTickCalculatorsLabel"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			miCurSL = new MenuItem { Header = "Cur SL: ", Name = "CurSL_"+uID, Foreground = Brushes.Black };
			miCurSL.Click += structureMenuItem_Click;
			miAvgTickCalcs.Items.Add(miCurSL);
			miAvgTickCalcs.Items.Add(miAvgSL = new MenuItem { Header = "Avg SL: ", Name = "AvgSL_"+uID, Foreground = Brushes.Black });
			miAvgTickCalcs.Items.Add(miAvgT1 = new MenuItem { Header = "Avg T1: ", Name = "AvgT1_"+uID, Foreground = Brushes.Black });
			miAvgTickCalcs.Items.Add(miAvgT2 = new MenuItem { Header = "Avg T2: ", Name = "AvgT2_"+uID, Foreground = Brushes.Black });

			MenuControl.Items.Add(miAvgTickCalcs);
			#endregion

	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			var miGlobal_SubMenu = new MenuItem { Header = "Global Visuals", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
	//- - - - - - - - - - - - - 
			#region -- Globalize Far Sell level --
			miGlobalize_FarSell = new MenuItem {Header = "Globalize Far Sell", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["FS"] = false;
			miGlobalize_FarSell.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				var tag = "FS";
				IsGlobalized[tag] = !IsGlobalized[tag];
				if(!IsGlobalized[tag]){
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
				} else {
//					if(!ShowFarTradePlan) {
//						ShowFarTradePlan = true;
//					}
//					if(ShowFarTradePlan && ShowShortTradePlans)
					{
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content   = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, RES_ID, ResFar.GetValueAt(CurrentBars[0]), this.pFarSell_RayTemplate); 
						GlobalRays[tag].IsDrawn = true;
						ImmediatelyDraw_Ray(tag, GlobalRays);
						GlobalObjCount = CalculateCountOfGlobalObjects();
					}
				}
//				miShowFarTP.Header = ShowFarTradePlan ? "Far TradePlans ON" : "Far TradePlans OFF",
				ForceRefresh();
			};
			miGlobal_SubMenu.Items.Add(miGlobalize_FarSell);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Globalize Near Sell level --
			miGlobalize_NearSell = new MenuItem {Header = "Globalize Near Sell", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["NS"] = false;
			miGlobalize_NearSell.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				var tag = "NS";
				IsGlobalized[tag] = !IsGlobalized[tag];
				if(!IsGlobalized[tag]){
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
				} else {
//					if(!ShowNearTradePlan) {
//						ShowNearTradePlan = true;
//					}
//					if(ShowNearTradePlan && ShowShortTradePlans)
					{
line=1853;
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content   = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, RES_ID, ResNear.GetValueAt(CurrentBars[0]), this.pNearSell_RayTemplate); 
						GlobalRays[tag].IsDrawn = true;
						ImmediatelyDraw_Ray(tag, GlobalRays);
						GlobalObjCount = CalculateCountOfGlobalObjects();
					}
				}
//				miShowNearTP.Header = ShowNearTradePlan ? "Near TradePlans ON" : "Near TradePlans OFF",
				ForceRefresh();
			};
			miGlobal_SubMenu.Items.Add(miGlobalize_NearSell);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Globalize Near Buy level --
			miGlobalize_NearBuy = new MenuItem {Header = "Globalize Near Buy", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["NB"] = false;
			miGlobalize_NearBuy.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				var tag = "NB";
				IsGlobalized[tag] = !IsGlobalized[tag];
				if(!IsGlobalized[tag]){
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
				} else {
//					if(!ShowNarTradePlan) {
//						ShowNarTradePlan = true;
//					}
//					if(ShowNearTradePlan && ShowBuyTradePlans)
					{
line=1889;
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content   = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, SUP_ID, SupNear.GetValueAt(CurrentBars[0]), this.pNearBuy_RayTemplate); 
						GlobalRays[tag].IsDrawn = true;
						ImmediatelyDraw_Ray(tag, GlobalRays);
						GlobalObjCount = CalculateCountOfGlobalObjects();
					}
				}
//				miShowFarTP.Header = ShowFarTradePlan ? "Far TradePlans ON" : "Far TradePlans OFF",
				ForceRefresh();
			};
			miGlobal_SubMenu.Items.Add(miGlobalize_NearBuy);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Globalize Far Buy level --
			miGlobalize_FarBuy = new MenuItem {Header = "Globalize Far Buy", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["FB"] = false;
			miGlobalize_FarBuy.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				var tag = "FB";
				IsGlobalized[tag] = !IsGlobalized[tag];
				if(!IsGlobalized[tag]){
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
				} else {
//					if(!ShowFarTradePlan) {
//						ShowFarTradePlan = true;
//					}
//					if(ShowFarTradePlan && ShowLongTradePlans)
					{
line=1925;
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content   = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, SUP_ID, SupFar.GetValueAt(CurrentBars[0]), this.pFarBuy_RayTemplate); 
						GlobalRays[tag].IsDrawn = true;
						ImmediatelyDraw_Ray(tag, GlobalRays);
						GlobalObjCount = CalculateCountOfGlobalObjects();
					}
				}
//				miShowFarTP.Header = ShowFarTradePlan ? "Far TradePlans ON" : "Far TradePlans OFF",
				ForceRefresh();
			};
			miGlobal_SubMenu.Items.Add(miGlobalize_FarBuy);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Globalize all levels --
			miGlobalize_All = new MenuItem {Header = "Globalize All", Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			IsGlobalized["All"] = false;
			miGlobalize_All.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				var tag = "All";
				IsGlobalized[tag] = !IsGlobalized[tag];
				if(!IsGlobalized[tag]){
					tag = "FS";
					IsGlobalized[tag] = false;
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
					tag = "NS";
					IsGlobalized[tag] = false;
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
					tag = "NB";
					IsGlobalized[tag] = false;
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
					tag = "FB";
					IsGlobalized[tag] = false;
					RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
					if(GlobalRays.ContainsKey(tag)) GlobalRays[tag].IsDrawn = false;
				} else {
//					if(!ShowFarTradePlan) {
//						ShowFarTradePlan = true;
//					}
//					if(ShowFarTradePlan && ShowLongTradePlans)
					{
line=1975;
						#region -- enable globals --
						pGlobalObjects_Enabled = true;
						EnableGlobals_Button.Content   = "Globals ON";
						ClearGlobals_Button.Background = Brushes.DarkGreen;
						ClearGlobals_Button.Content    = "Clear Globals";
						ClearGlobals_Button.Visibility = Visibility.Visible;
						#endregion --
						tag = "FS";
						GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, RES_ID, ResFar.GetValueAt(CurrentBars[0]), this.pFarSell_RayTemplate); 
						GlobalRays[tag].IsDrawn = true;
						tag = "NS";
						GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, RES_ID, ResNear.GetValueAt(CurrentBars[0]), this.pNearSell_RayTemplate); 
						GlobalRays[tag].IsDrawn = true;
						tag = "NB";
						GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, SUP_ID, SupNear.GetValueAt(CurrentBars[0]), this.pNearBuy_RayTemplate); 
						GlobalRays[tag].IsDrawn = true;
						tag = "FB";
						GlobalRays[tag] = new Global_RaysData(Times[0].GetValueAt(CurrentBars[0]-1), CurrentBars[0]-1, SUP_ID, SupFar.GetValueAt(CurrentBars[0]), this.pFarBuy_RayTemplate); 
						GlobalRays[tag].IsDrawn = true;
						ImmediatelyDraw_Rays(GlobalRays);
						GlobalObjCount = CalculateCountOfGlobalObjects();
					}
				}
//				miShowFarTP.Header = ShowFarTradePlan ? "Far TradePlans ON" : "Far TradePlans OFF",
				ForceRefresh();
			};
			miGlobal_SubMenu.Items.Add(miGlobalize_All);
			#endregion
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(miGlobal_SubMenu);
	//- - - - - - - - - - - - - 
			#region -- Enable Globals --
			EnableGlobals_Button = new System.Windows.Controls.Button { Content = (pGlobalObjects_Enabled ? "Globals ON":"Globals OFF"), Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
			EnableGlobals_Button.Click += delegate (object o, RoutedEventArgs e){
				//e.Handled = true;
				pGlobalObjects_Enabled = !pGlobalObjects_Enabled;
				EnableGlobals_Button.Content = (pGlobalObjects_Enabled ? "Globals ON" : "Globals OFF");
                ForceRefresh();
			};
			MenuControl.Items.Add(EnableGlobals_Button);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Clear Globals --
			ClearGlobals_Button = new System.Windows.Controls.Button { Content = "", Foreground=Brushes.White, Background=Brushes.DimGray};//content is blank until we have rays or rectangles drawn on the chart
			ClearGlobals_Button.Visibility = Visibility.Collapsed;
			ClearGlobals_Button.Click += delegate(object o, RoutedEventArgs e){
				var Tag1 = string.Format("@{0} {1}", "FS", ObjTagPrefix);
				var Tag2 = string.Format("@{0} {1}", "FB", ObjTagPrefix);
				var Tag3 = string.Format("@{0} {1}", "NS", ObjTagPrefix);
				var Tag4 = string.Format("@{0} {1}", "NB", ObjTagPrefix);
				var objects = DrawObjects.ToList();
				foreach (dynamic dob in objects)
				{
					var type = dob.ToString();
					if (type.EndsWith(".Ray")){
						if(dob.Tag.StartsWith(Tag1))		RemoveDrawObject(dob.Tag);
						else if(dob.Tag.StartsWith(Tag2))	RemoveDrawObject(dob.Tag);
						else if(dob.Tag.StartsWith(Tag3))	RemoveDrawObject(dob.Tag);
						else if(dob.Tag.StartsWith(Tag4))	RemoveDrawObject(dob.Tag);
					}
				}
				//e.Handled=true;
				ClearGlobals_Button.Content = "";
				ClearGlobals_Button.Visibility = Visibility.Collapsed;
				ClearGlobals_Button.Background = Brushes.DimGray;
				GlobalObjCount = 0;
			};
			MenuControl.Items.Add(ClearGlobals_Button);
			#endregion
	//- - - - - - - - - - - - - 

			indytoolbar.Children.Add(MenuControlContainer);
		}
		//==============================================================
		private void SLCalcBasis_SetVisibilityOfInputs(){
			return;
//			if(SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.ATR){
//				nudSLMult.Visibility = Visibility.Visible;
//				nudSLsize.Visibility = Visibility.Hidden;
//				label_SLATR.Visibility = Visibility.Visible;
//				label_SLsize.Visibility = Visibility.Hidden;
//			}else{
//				nudSLMult.Visibility = Visibility.Hidden;
//				nudSLsize.Visibility = Visibility.Visible;
//				label_SLsize.Visibility = Visibility.Visible;
//				label_SLATR.Visibility = Visibility.Hidden;
//			}
		}
		//==============================================================
		#endregion

		private StructureBias StructureBiasMgr = null;
		private class StructureBias{
			#region StructureBias class
			public int    SwingStrength = 0;
			public bool   isHLBased         = false;
			public double MultiplierMD  = 0;
			public double MultiplierDTB = 0;
			public Series<int> Bias;
			public Brush UpTrendColorTinted   = null;
			public Brush DownTrendColorTinted = null;
			public string ErrorMsg = string.Empty;
			public System.Collections.Generic.SortedDictionary<int,double> AllPivots = new System.Collections.Generic.SortedDictionary<int,double>();

			#region internals
			private int  SRType = 0;
			private int  preSRType = 0;
	        private bool vdrawHigherHighLabel   = false;
	        private bool vdrawLowerHighLabel    = false;
	        private bool vdrawDoubleTopLabel    = false;
	        private bool vdrawLowerLowLabel     = false;
	        private bool vdrawHigherLowLabel    = false;
	        private bool vdrawDoubleBottomLabel = false;
			private ISeries<double> High;
			private ISeries<double> Low;
			private Series<bool>   vupTrend;
			private Series<double> vpre_swingHighType;
			private Series<double> vpre_swingLowType;
			private Series<double> vswingHighType;
			private Series<double> vswingLowType;
			private Series<double> vavgTrueRange;
			private Series<double> vswingInput;
			private Series<double> pre_swingHighType;
			private Series<double> pre_swingLowType;
			private Series<double> swingHighType;
			private Series<double> swingLowType;
			private int lastLowIdx;
			private int lastHighIdx;
			public Series<bool> upTrend;
			private double vswingMax;
			private double vswingMin;
			private double vzigzagDeviation;
			private bool vupdateHigh;
			private bool vupdateLow;
			private bool vaddHigh;
			private bool vaddLow;
			private bool updateLow;
			private bool updateHigh;
			private double vcurrentHigh;
			private double vcurrentLow;
			private int vlastLowIdx;
			private int vlastHighIdx;
			private int vpriorSwingHighIdx;
			private int vpriorSwingLowIdx;
			private int vhighCount;
			private int vlowCount;
			private int vpreLastHighIdx;
			private int vpreLastLowIdx;
			private int priorSwingHighIdx;
			private int priorSwingLowIdx;
			private double currentHigh;
			private double currentLow;
			private double vmarginUp;
			private double vmarginDown;
			private double vpreCurrentHigh;
			private double vpreCurrentLow;
			private double swingMax;
			private double swingMin;
			private bool vintraBarUpdateHigh;
			private bool vintraBarUpdateLow;
			private bool vintraBarAddHigh;
			private bool vintraBarAddLow;
			private bool addHigh;
			private bool addLow;
	        public System.Collections.Generic.List<int> sequence = new System.Collections.Generic.List<int>(3);
			#endregion

			public StructureBias(NinjaScriptBase Chart_Bars, ISeries<double> high, ISeries<double> low, int swingStrength, bool use_HL, double multiplierMD, double multiplierDTB, Brush trendUpColor, int opacityUp, Brush trendDownColor, int opacityDown){
				#region constructor
				High = high;
				Low  = low;
				vupTrend           = new Series<bool>  (Chart_Bars,MaximumBarsLookBack.Infinite);
				vpre_swingHighType = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vpre_swingLowType  = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vswingHighType     = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vswingLowType      = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vavgTrueRange      = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				vswingInput        = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				Bias               = new Series<int>   (Chart_Bars,MaximumBarsLookBack.Infinite);
				upTrend            = new Series<bool>  (Chart_Bars,MaximumBarsLookBack.Infinite);
				pre_swingHighType  = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				pre_swingLowType   = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				swingHighType      = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				swingLowType       = new Series<double>(Chart_Bars,MaximumBarsLookBack.Infinite);
				SwingStrength = swingStrength;
				isHLBased         = use_HL;
				MultiplierMD  = multiplierMD;
				MultiplierDTB = multiplierDTB;
				UpTrendColorTinted         = trendUpColor.Clone();
				UpTrendColorTinted.Opacity = opacityUp / 100f;
				UpTrendColorTinted.Freeze();
				DownTrendColorTinted         = trendDownColor.Clone();
				DownTrendColorTinted.Opacity = opacityDown / 100f;
				DownTrendColorTinted.Freeze();
				#endregion
			}
			private double MAX(ISeries<double> series, int lookback, int rbar_offset){
				double max = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) max = Math.Max(max, series[i]);
				}catch{}
				return max;
			}
			private double MIN(ISeries<double> series, int lookback, int rbar_offset){
				double min = series[rbar_offset];
				try{
					for(int i = rbar_offset+1; i<lookback+rbar_offset; i++) min = Math.Min(min, series[i]);
				}catch{}
				return min;
			}
			public void AddToAllPivots(int idx, double price){
				if(AllPivots.Count>0){
					int ptr = AllPivots.Count-1;
					var keys = new System.Collections.Generic.List<int>(AllPivots.Keys);
					if(price<0){
						if(AllPivots[keys[ptr]]<0) AllPivots.Remove(keys[ptr]);
					}
					else if(price>0){
						if(AllPivots[keys[ptr]]>0) AllPivots.Remove(keys[ptr]);
					}
				}
				AllPivots[idx] = price;
			}
			public void CalculateIt(int CurrentBar, ISeries<double>Input, bool IsFirstTickOfBar, NinjaTrader.NinjaScript.Calculate Calculate, NinjaTrader.NinjaScript.State State, double atr256){
				ErrorMsg = string.Empty;
int line=2201;
				try{
	            #region --- Calculate ZigZag ---                
	            swingMax = MAX(isHLBased ? High : Input, SwingStrength, 1);
	            swingMin = MIN(isHLBased ? Low : Input, SwingStrength, 1);

	            pre_swingHighType[0] = 0;
	            pre_swingLowType[0] = 0;
	            swingHighType[0] = 0;
	            swingLowType[0] = 0;

	            updateHigh = upTrend[1] && (isHLBased ? High[0] : Input[0]) > currentHigh;
	            updateLow = !upTrend[1] && (isHLBased ? Low[0] : Input[0]) < currentLow;
	            addHigh = !upTrend[1] && !((isHLBased ? Low[0] : Input[0]) < currentLow) && (isHLBased ? High[0] : Input[0]) > Math.Max(swingMax, currentLow);
	            addLow = upTrend[1] && !((isHLBased ? High[0] : Input[0]) > currentHigh) && (isHLBased ? Low[0] : Input[0]) < Math.Min(swingMin, currentHigh);

	            upTrend[0] = upTrend[1];
	            #endregion
line=2219;
	            #region -- New High --
	            if (addHigh)
	            {
	                //-- update zigzag H/L --
	                upTrend[0] = true;
	                int lookback = CurrentBar - lastLowIdx;
	                swingLowType[lookback] = pre_swingLowType[lookback];
					AddToAllPivots(lastLowIdx, -Low[lookback]);
	                double newHigh = double.MinValue;
	                int j = 0;
	                for (int i = 0; i < CurrentBar - lastLowIdx; i++)
	                {
	                    if ((isHLBased ? High[i] : Input[i]) > newHigh)
	                    {
	                        newHigh = (isHLBased ? High[i] : Input[i]);
	                        j = i;
	                    }
	                }
	                currentHigh = newHigh;
	                priorSwingHighIdx = lastHighIdx;
	                lastHighIdx = CurrentBar - j;
	            }
	            #endregion
	            #region -- uptrend --
	            else if (updateHigh)
	            {
line=2246;
	                upTrend[0] = true;
	                pre_swingHighType[CurrentBar - lastHighIdx] = 0;
	                currentHigh = (isHLBased ? High[0] : Input[0]);
	                lastHighIdx = CurrentBar;
	            }
	            #endregion
	            #region -- New Low --
	            else if (addLow)
	            {
line=2256;
	                upTrend[0] = false;
	                int lookback = CurrentBar - lastHighIdx;
	                swingHighType[lookback] = pre_swingHighType[lookback];
					AddToAllPivots(lastHighIdx, High[lookback]);
	                double newLow = double.MaxValue;
	                int j = 0;
	                for (int i = 0; i < CurrentBar - lastHighIdx; i++)
	                {
	                    if ((isHLBased ? Low[i] : Input[i]) < newLow)
	                    {
	                        newLow = (isHLBased ? Low[i] : Input[i]);
	                        j = i;
	                    }
	                }
	                currentLow = newLow;
	                priorSwingLowIdx = lastLowIdx;
	                lastLowIdx = CurrentBar - j;
	            }
	            #endregion

	            #region -- dwtrend --
	            else if (updateLow)
	            {
line=2280;
	                upTrend[0] = false;
	                pre_swingLowType[CurrentBar - lastLowIdx] = 0;
	                currentLow = (isHLBased ? Low[0] : Input[0]);
	                lastLowIdx = CurrentBar;
	            }
	            #endregion

	            #region -- Init zigzag states --

				vavgTrueRange[0] = atr256;

line=2292;
	            if (CurrentBar < 2)
	            {
	                vupTrend[0] = true;
	                vpre_swingHighType[0] = 0;
	                vpre_swingLowType[0] = 0;
	                vswingHighType[0] = 0;
	                vswingLowType[0] = 0;
	            }
	            #endregion

	            #region OnBarClose
	            else if (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose)
	            {
line=2306;
	                vzigzagDeviation = MultiplierMD * vavgTrueRange[0];
	                vswingMax        = MAX(isHLBased ? High : Input, SwingStrength, 1);
	                vswingMin        = MIN(isHLBased ? Low : Input, SwingStrength, 1);

	                vpre_swingHighType[0] = 0;
	                vpre_swingLowType[0]  = 0;
	                vswingHighType[0]     = 0;
	                vswingLowType[0]      = 0;

	                vupdateHigh = vupTrend[1]  && (isHLBased ? High[0] :   vswingInput[0]) > vcurrentHigh;
	                vupdateLow  = !vupTrend[1] && (isHLBased ? Low[0] :    vswingInput[0]) < vcurrentLow;
	                vaddHigh    = !vupTrend[1] && !((isHLBased ? Low[0] :  vswingInput[0]) < vcurrentLow) && (isHLBased ? High[0] : vswingInput[0]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
	                vaddLow     = vupTrend[1]  && !((isHLBased ? High[0] : vswingInput[0]) > vcurrentHigh) && (isHLBased ? Low[0] : vswingInput[0]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

	                vupTrend[0] = vupTrend[1];

line=2323;
	                #region -- New High --
	                if (vaddHigh)
	                {
	                    vupTrend[0] = true;
	                    int lookback = CurrentBar - vlastLowIdx;
	                    vswingLowType[lookback] = vpre_swingLowType[lookback];
						AddToAllPivots(vlastLowIdx, -Low[lookback]);
	                    double vnewHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastLowIdx; i++)
	                    {
	                        if ((isHLBased ? High[i] : vswingInput[i]) > vnewHigh)
	                        {
	                            vnewHigh = (isHLBased ? High[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }

	                    vcurrentHigh = vnewHigh;
	                    vpriorSwingHighIdx = vlastHighIdx;
	                    vlastHighIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- uptrend --
	                else if (vupdateHigh)
	                {
line=2351;
	                    vupTrend[0] = true;
	                    vpre_swingHighType[CurrentBar - vlastHighIdx] = 0;
	                    vcurrentHigh = (isHLBased ? High[0] : vswingInput[0]);
	                    vlastHighIdx = CurrentBar;
	                }
	                #endregion

	                #region -- New Low --
	                else if (vaddLow)
	                {
line=2362;
	                    vupTrend[0] = false;
	                    int lookback = CurrentBar - vlastHighIdx;
	                    vswingHighType[lookback] = vpre_swingHighType[lookback];
						AddToAllPivots(vlastHighIdx, High[lookback]);
	                    double vnewLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastHighIdx; i++)
	                    {
	                        if ((isHLBased ? Low[i] : vswingInput[i]) < vnewLow)
	                        {
	                            vnewLow = (isHLBased ? Low[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vcurrentLow = vnewLow;
	                    vpriorSwingLowIdx = vlastLowIdx;
	                    vlastLowIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- dwtrend --
	                else if (vupdateLow)
	                {
line=2386;
	                    vupTrend[0] = false;
	                    vpre_swingLowType[CurrentBar - vlastLowIdx] = 0;
	                    vcurrentLow = (isHLBased ? Low[0] : vswingInput[0]);
	                    vlastLowIdx = CurrentBar;
	                }
	                #endregion

	                #region re-init drawing states at each new bar before calculous

line=2396;
	                vdrawHigherHighLabel = false;
	                vdrawLowerHighLabel = false;
	                vdrawDoubleTopLabel = false;
	                vdrawLowerLowLabel = false;
	                vdrawHigherLowLabel = false;
	                vdrawDoubleBottomLabel = false;
	                
	                #endregion

	                #region -- UP || HH --
	                if (vaddHigh || vupdateHigh)
	                {
line=2409;
	                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;

	                    double vmarginUp = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) + MultiplierDTB * vavgTrueRange[vhighCount];
	                    double vmarginDown = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) - MultiplierDTB * vavgTrueRange[vhighCount];

	                    #endregion
	                    // end new code

	                    #region -- Set NEW drawing states --

	                    if (vcurrentHigh > vmarginUp) vdrawHigherHighLabel = true;
	                    else if (vcurrentHigh < vmarginDown) vdrawLowerHighLabel = true;
	                    else vdrawDoubleTopLabel = true;

	                    if (vcurrentHigh > vmarginUp)
	                        vpre_swingHighType[vhighCount] = 3;
	                    else if (vcurrentHigh < vmarginDown)
	                        vpre_swingHighType[vhighCount] = 1;
	                    else
	                        vpre_swingHighType[vhighCount] = 2;
	                    #endregion
	                }

	                #region -- DW || LL --
	                else if (vaddLow || vupdateLow)
	                {
line=2439;
	                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;

						double vmarginDown = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) - MultiplierDTB * vavgTrueRange[vlowCount];
	                    double vmarginUp = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) + MultiplierDTB * vavgTrueRange[vlowCount];

	                    #region -- Calculate acceleration on BBMACD and Histo --
	                    #endregion

	                    #region -- Set NEW drawing states --

	                    if (vcurrentLow < vmarginDown) vdrawLowerLowLabel = true;
	                    else if (vcurrentLow > vmarginUp) vdrawHigherLowLabel = true;
	                    else vdrawDoubleBottomLabel = true;
	                    
	                    if (vcurrentLow < vmarginDown)
	                        vpre_swingLowType[vlowCount] = -3;
	                    else if (vcurrentLow > vmarginUp)
	                        vpre_swingLowType[vlowCount] = -1;
	                    else
	                        vpre_swingLowType[vlowCount] = -2;
	                    #endregion
	                }
	                #endregion
	            }
                #endregion

	            #region else if (IsFirstTickOfBar)
	            else if (IsFirstTickOfBar)
	            {
line=2472;
	                vzigzagDeviation = MultiplierMD * vavgTrueRange[1];
	                vswingMax = MAX(isHLBased ? High : Input, SwingStrength, 2);
	                vswingMin = MIN(isHLBased ? Low : Input, SwingStrength, 2);

	                vpre_swingHighType[0] = 0;
	                vpre_swingLowType[0] = 0;
	                vswingHighType[0] = 0;
	                vswingLowType[0] = 0;

	                vupdateHigh = vupTrend[1] && (isHLBased ? High[1] : vswingInput[1]) > vcurrentHigh;
	                vupdateLow = !vupTrend[1] && (isHLBased ? Low[1] : vswingInput[1]) < vcurrentLow;
	                vaddHigh = !vupTrend[1] && !((isHLBased ? Low[1] : vswingInput[1]) < vcurrentLow) && (isHLBased ? High[1] : vswingInput[1]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
	                vaddLow = vupTrend[1] && !((isHLBased ? High[1] : vswingInput[1]) > vcurrentHigh) && (isHLBased ? Low[1] : vswingInput[1]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

	                vupTrend[0] = vupTrend[1];

	                #region -- New High --
	                if (vaddHigh)
	                {
line=2492;
	                    vupTrend[0] = true;
	                    int lookback = CurrentBar - vlastLowIdx;
	                    vswingLowType[lookback] = vpre_swingLowType[lookback];
						AddToAllPivots(vlastLowIdx, -Low[lookback]);
	                    double vnewHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 1; i < CurrentBar - vlastLowIdx; i++)
	                    {
	                        if ((isHLBased ? High[i] : vswingInput[i]) > vnewHigh)
	                        {
	                            vnewHigh = (isHLBased ? High[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vcurrentHigh = vnewHigh;
	                    vpriorSwingHighIdx = vlastHighIdx;
	                    vlastHighIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- UPtrend --
	                else if (vupdateHigh)
	                {
line=2516;
	                    vupTrend[0] = true;
	                    vpre_swingHighType[CurrentBar - vlastHighIdx] = 0;
	                    vcurrentHigh = (isHLBased ? High[1] : vswingInput[1]);
	                    vlastHighIdx = CurrentBar - 1;
	                }
	                #endregion

	                #region -- New Low --
	                else if (vaddLow)
	                {
line=2527;
	                    vupTrend[0] = false;
	                    int lookback = CurrentBar - vlastHighIdx;
	                    vswingHighType[lookback] = vpre_swingHighType[lookback];
						AddToAllPivots(vlastHighIdx, High[lookback]);
	                    double vnewLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 1; i < CurrentBar - vlastHighIdx; i++)
	                    {
	                        if ((isHLBased ? Low[i] : vswingInput[i]) < vnewLow)
	                        {
	                            vnewLow = (isHLBased ? Low[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vcurrentLow = vnewLow;
	                    vpriorSwingLowIdx = vlastLowIdx;
	                    vlastLowIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- DWtrend --
	                else if (updateLow)
	                {
line=2551;
	                    vupTrend[0] = false;
	                    vpre_swingLowType[CurrentBar - vlastLowIdx] = 0;
	                    vcurrentLow = isHLBased ? Low[1] : vswingInput[1];
	                    vlastLowIdx = CurrentBar - 1;
	                }
	                #endregion

	                #region re-init drawing states at each new bar before calculous

	                vdrawHigherHighLabel = false;
	                vdrawLowerHighLabel = false;
	                vdrawDoubleTopLabel = false;
	                vdrawLowerLowLabel = false;
	                vdrawHigherLowLabel = false;
	                vdrawDoubleBottomLabel = false;

	                #endregion

line=2570;
	                #region -- UP || HH --
	                if (vaddHigh || vupdateHigh)
	                {
	                    int vpriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;

	                    double vmarginUp = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) + MultiplierDTB * vavgTrueRange[vhighCount];
	                    double vmarginDown = (isHLBased ? High[vpriorHighCount] : vswingInput[vpriorHighCount]) - MultiplierDTB * vavgTrueRange[vhighCount];

	                    #region -- Set NEW drawing states --

	                    if (vcurrentHigh > vmarginUp) vdrawHigherHighLabel = true;
	                    else if (vcurrentHigh < vmarginDown) vdrawLowerHighLabel = true;
	                    else vdrawDoubleTopLabel = true;
	                    
	                    if (vcurrentHigh > vmarginUp)
	                        vpre_swingHighType[vhighCount] = 3;
	                    else if (currentHigh < vmarginDown)
	                        vpre_swingHighType[vhighCount] = 1;
	                    else
	                        vpre_swingHighType[vhighCount] = 2;
	                    #endregion
	                }
	                #endregion

	                #region -- DW || LL --
	                else if (vaddLow || vupdateLow)
	                {
line=2600;
	                    int vpriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    vlowCount = CurrentBar - vlastLowIdx;
	                    vhighCount = CurrentBar - vlastHighIdx;

	                    double vmarginDown = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) - MultiplierDTB * vavgTrueRange[vlowCount];
	                    double vmarginUp = (isHLBased ? Low[vpriorLowCount] : vswingInput[vpriorLowCount]) + MultiplierDTB * vavgTrueRange[vlowCount];

	                    #region -- Set NEW drawing states --

	                    if (vcurrentLow < vmarginDown) vdrawLowerLowLabel = true;
	                    else if (vcurrentLow > vmarginUp) vdrawHigherLowLabel = true;
	                    else vdrawDoubleBottomLabel = true;
	                    
	                    if (vcurrentLow < vmarginDown)
	                        vpre_swingLowType[vlowCount] = -3;
	                    else if (vcurrentLow > vmarginUp)
	                        vpre_swingLowType[vlowCount] = -1;
	                    else
	                        vpre_swingLowType[vlowCount] = -2;
	                    #endregion
	                }
	                #endregion
	            }
	            #endregion
line=2625;
	            #region -- OnPriceChange or OnEachTick --
	            if (Calculate != NinjaTrader.NinjaScript.Calculate.OnBarClose)
	            {
line=2629;
	                vintraBarUpdateHigh = vupTrend[0] && (isHLBased ? High[0] : vswingInput[0]) > vcurrentHigh;
	                vintraBarUpdateLow = !vupTrend[0] && (isHLBased ? Low[0] : vswingInput[0]) < vcurrentLow;
	                vintraBarAddHigh = !vupTrend[0] && !((isHLBased ? Low[0] : vswingInput[0]) < vcurrentLow) && (isHLBased ? High[0] : vswingInput[0]) > Math.Max(vswingMax, vcurrentLow + vzigzagDeviation);
	                vintraBarAddLow = vupTrend[0] && !((isHLBased ? High[0] : vswingInput[0]) > vcurrentHigh) && (isHLBased ? Low[0] : vswingInput[0]) < Math.Min(vswingMin, vcurrentHigh - vzigzagDeviation);

	                #region -- new HH --
	                if (vintraBarAddHigh)
	                {
line=2638;
	                    double vnewHigh = double.MinValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastLowIdx; i++)
	                    {
	                        if ((isHLBased ? High[i] : vswingInput[i]) > vnewHigh)
	                        {
	                            vnewHigh = (isHLBased ? High[i] : vswingInput[i]);
	                            j = i;
	                        }
	                    }
	                    vpreCurrentHigh = vnewHigh;
	                    vpreLastHighIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- uptrend --
	                else if (vintraBarUpdateHigh)
	                {
line=2657;
	                    vpreCurrentHigh = (isHLBased ? High[0] : vswingInput[0]);
	                    vpreLastHighIdx = CurrentBar;
	                }
	                #endregion

	                #region -- new LL --
	                if (vintraBarAddLow)
	                {
line=2666;
	                    double vnewLow = double.MaxValue;
	                    int j = 0;
	                    for (int i = 0; i < CurrentBar - vlastHighIdx; i++)
	                    {
	                        if ((isHLBased ? Low[i] : vswingInput[i]) < vnewLow)
	                        {
	                            vnewLow = isHLBased ? Low[i] : vswingInput[i];
	                            j = i;
	                        }
	                    }
	                    vpreCurrentLow = vnewLow;
	                    vpreLastLowIdx = CurrentBar - j;
	                }
	                #endregion

	                #region -- dwtrend --
	                else if (vintraBarUpdateLow)
	                {
line=2685;
	                    vpreCurrentLow = (isHLBased ? Low[0] : vswingInput[0]);
	                    vpreLastLowIdx = CurrentBar;
	                }
	                #endregion

	                #region -- UP || HH --
	                if (vintraBarAddHigh || vintraBarUpdateHigh)
	                {
line=2694;
	                    int vprePriorHighCount = vintraBarAddHigh ? CurrentBar - vlastHighIdx : CurrentBar - vpriorSwingHighIdx;
	                    int vpreHighCount = CurrentBar - vpreLastHighIdx;
	                    int vprePriorLowCount = CurrentBar - vpriorSwingLowIdx;
	                    int vpreLowCount = CurrentBar - vlastLowIdx;

	                    #region ---- StructureBias RealTime ---
	                    double vmarginUp, vmarginDown;
	                    if (isHLBased)//ThisInputType == gztVMDivInputType.High_Low)
	                    {
	                        vmarginUp = High[vprePriorHighCount] + MultiplierDTB * vavgTrueRange[vpreHighCount];
	                        vmarginDown = High[vprePriorHighCount] - MultiplierDTB * vavgTrueRange[vpreHighCount];
	                    }
	                    else
	                    {
	                        vmarginUp = vswingInput[vprePriorHighCount] + MultiplierDTB * vavgTrueRange[vpreHighCount];
	                        vmarginDown = vswingInput[vprePriorHighCount] - MultiplierDTB * vavgTrueRange[vpreHighCount];
	                    }

	                    if (vpreCurrentHigh > vmarginUp) preSRType = 3;//#STRBIAS
	                    else if (vpreCurrentHigh < vmarginDown) preSRType = Math.Max(preSRType, 2);//#STRBIAS
	                    else preSRType = Math.Max(preSRType, 1);//#STRBIAS
	                    #endregion
	                }
	                #endregion

	                #region -- DW || LL --
	                else if (vintraBarAddLow || vintraBarUpdateLow)
	                {
line=2723;
	                    int vprePriorLowCount = vintraBarAddLow ? CurrentBar - vlastLowIdx : CurrentBar - vpriorSwingLowIdx;
	                    int vpreLowCount = CurrentBar - vpreLastLowIdx;
	                    int vprePriorHighCount = CurrentBar - vpriorSwingHighIdx;
	                    int vpreHighCount = CurrentBar - vlastHighIdx;

	                    #region ---- StructureBias RealTime ---
	                    double vmarginUp, vmarginDown;
	                    if (isHLBased)//ThisInputType == gztVMDivInputType.High_Low)
	                    {
	                        vmarginDown = Low[vprePriorLowCount] - MultiplierDTB * vavgTrueRange[vpreLowCount];
	                        vmarginUp = Low[vprePriorLowCount] + MultiplierDTB * vavgTrueRange[vpreLowCount];
	                    }
	                    else
	                    {
	                        vmarginDown = vswingInput[vprePriorLowCount] - MultiplierDTB * vavgTrueRange[vpreLowCount];
	                        vmarginUp = vswingInput[vprePriorLowCount] + MultiplierDTB * vavgTrueRange[vpreLowCount];
	                    }
	                    if (vpreCurrentLow < vmarginDown) preSRType = -3;//#STRBIAS
	                    else if (vpreCurrentLow > vmarginUp) preSRType = Math.Min(preSRType, -2);//#STRBIAS
	                    else preSRType = Math.Min(preSRType, -1);//#STRBIAS
	                    #endregion
	                }
	                #endregion
	                //Is it possible ??
	                else
	                {
	                    preSRType = 0;//#STRBIAS
	                }

	                #region ---- StructureBias RealTime ---
	                if (CurrentBar < 2) Bias[0] = FLAT;
	                else
	                {
line=2757;
	                    if (preSRType == 0) Bias[0] = Bias[1];

	                    #region -- Oscillation State --
	                    else if (Bias[1] == FLAT)
	                    {
	                        //Oscillation State
	                        //Need HH/!LL/HH to go to Up Trend
	                        //{NEW} !LL/High/!LL/HH to go to Up Trend
	                        //Need LL/!HH/LL to go to Dw Trend
	                        //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
	                        if (sequence.Count < 2) Bias[0] = FLAT;
	                        else if (sequence.Count < 3)
	                        {
	                            if (sequence[0] == 3 && sequence[1] != -3 && preSRType == 3) Bias[0] = UP;
	                            else if (sequence[0] == -3 && sequence[1] != 3 && preSRType == -3) Bias[0] = DOWN;
	                            else Bias[0] = FLAT;
	                        }
	                        else
	                        {
	                            if (sequence[1] == 3 && sequence[2] != -3 && preSRType == 3) Bias[0] = UP;
	                            else if (sequence[1] == -3 && sequence[2] != 3 && preSRType == -3) Bias[0] = DOWN;
	                            //{NEW} HL/LH/HL/HH to go to Up Trend
	                            else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && preSRType == 3) Bias[0] = UP;
	                            //{NEW} LH/HL/LH/LL to go to Up Trend
	                            else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && preSRType == -3) Bias[0] = DOWN;
	                            else Bias[0] = FLAT;
	                        }
	                    }
	                    #endregion

	                    #region -- UpTrend State --
	                    else if (Bias[1] > FLAT)
	                    {
line=2791;
	                        //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
	                        if (preSRType == -3) Bias[0] = FLAT;
	                        else Bias[0] = UP;
	                    }
	                    #endregion

	                    #region -- DwTrend State --
	                    else if (Bias[1] < FLAT)
	                    {
line=2801;
	                        //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
	                        if (preSRType == 3) Bias[0] = FLAT;
	                        else Bias[0] = DOWN;
	                    }
	                    #endregion

	                    else Bias[0] = Bias[1];
	                }
	                #endregion
	            }
	            #endregion
line=2813;
	            #region -- Structure BIAS --
	            SRType = vdrawHigherHighLabel ? 3 : vdrawLowerHighLabel ? 2 : vdrawDoubleTopLabel ? 1 : vdrawDoubleBottomLabel ? -1 : vdrawHigherLowLabel ? -2 : vdrawLowerLowLabel ? -3 : 0;

				#region -- Oscillation State --
	            int decay = 0;
	            if (Calculate!= NinjaTrader.NinjaScript.Calculate.OnBarClose && State != NinjaTrader.NinjaScript.State.Historical) decay = 1;
	            if (SRType != 0 && Bias[decay + 1] == FLAT)
	            {
line=2822;
	                #region -- update sequence ---
	                //--- Same Trend --
	                if (vupTrend[1] == vupTrend[0])
	                {
	                    if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
//ErrorMsg = "Sequence updated to SameTrend...SRType "+SRType+"   count:"+sequence.Count;
	                }

	                //--- Changing Trend ---
	                else if (Calculate == NinjaTrader.NinjaScript.Calculate.OnBarClose && upTrend[1] != upTrend[0])
	                {
line=2835;
	                    if (sequence.Count < 4) 
							sequence.Add(SRType);
	                    else
	                    {
	                        sequence[0] = sequence[1];
	                        sequence[1] = sequence[2];
	                        sequence[2] = sequence[3];
	                        sequence[3] = SRType;
	                    }
//ErrorMsg = "Sequence updated to ChangingTrend...SRType "+SRType+"   count:"+sequence.Count;
	                }
	                #region -- eachtick --
	                else if (Calculate != NinjaTrader.NinjaScript.Calculate.OnBarClose && vupTrend[1] != vupTrend[0])
	                {
line=2850;
	                    if (IsFirstTickOfBar)
	                    {
	                        if (sequence.Count < 4) sequence.Add(SRType);
	                        else
	                        {
	                            sequence[0] = sequence[1];
	                            sequence[1] = sequence[2];
	                            sequence[2] = sequence[3];
	                            sequence[3] = SRType;
	                        }
	                    }
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                #endregion
	                #endregion
line=2867;

	                //Oscillation State
	                //Need HH/!LL/HH to go to Up Trend
	                //{NEW} !LL/High/!LL/HH to go to Up Trend
	                //Need LL/!HH/LL to go to Dw Trend
	                //{NEW} !HH/Low/!HH/LL to go to Dw Trend				
	                if (sequence.Count < 3) Bias[decay] = FLAT;
	                else if (sequence.Count < 4)
	                {
line=2877;
	                    if (sequence[0] == 3 && sequence[1] != -3 && sequence[2] == 3) Bias[decay] = UP;
	                    else if (sequence[0] == -3 && sequence[1] != 3 && sequence[2] == -3) Bias[decay] = DOWN;
	                    else Bias[decay] = FLAT;
	                }
	                else
	                {
line=2884;
	                    if (sequence[1] == 3 && sequence[2] != -3 && sequence[3] == 3) Bias[decay] = UP;
	                    else if (sequence[1] == -3 && sequence[2] != 3 && sequence[3] == -3) Bias[decay] = DOWN;
	                    //{NEW} HL/LH/HL/HH to go to Up Trend
	                    else if (sequence[0] != -3 && sequence[1] > 0 && sequence[2] != -3 && sequence[3] == 3) Bias[decay] = UP;
	                    //{NEW} LH/HL/LH/LL to go to Up Trend
	                    else if (sequence[0] != 3 && sequence[1] < 0 && sequence[2] != 3 && sequence[3] == -3) Bias[decay] = DOWN;
	                    else Bias[decay] = FLAT;
	                }
	            }
	            #endregion

	            #region -- UpTrend State --
	            else if (SRType != 0 && Bias[decay + 1] > FLAT)
	            {
line=2899;
	                if (IsFirstTickOfBar) sequence.Clear();
	                //Look at Lows only. If LL go to OSC / else {HL or DB} stay UpTrend
	                if (SRType == -3)
	                {
	                    Bias[decay] = FLAT;
	                    if (IsFirstTickOfBar) sequence.Add(SRType);
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                else Bias[decay] = UP;
	            }
	            #endregion

	            #region -- DwTrend State --
	            else if (SRType != 0 && Bias[decay + 1] < FLAT)
	            {
line=2916;
	                if (IsFirstTickOfBar) sequence.Clear();
	                //Look at Highs only. If HH go to OSC / else {LH or DT} stay DwTrend
	                if (SRType == 3)
	                {
	                    Bias[decay] = FLAT;
	                    if (IsFirstTickOfBar) sequence.Add(SRType);
	                    else if (sequence.Count == 0) sequence.Add(SRType);
	                    else sequence[sequence.Count - 1] = SRType;
	                }
	                else Bias[decay] = DOWN;
	            }
	            #endregion

	            else Bias[decay] = Bias[decay + 1];
	            #endregion
line=2932;
				}catch(Exception e){ErrorMsg = "---------------"+line.ToString()+":  StructureBiasMgr\n\n"+e.ToString() + "---------------";}
			}
			#endregion
		}
		private class LevelData{
			public int LMAbar = 0;
			public int RMAbar = 0;
			public int State = 0;
			public LevelData(int lmabar, int rmabar, int state){	LMAbar = lmabar; RMAbar = rmabar; State=state;	}
		}
		private System.Collections.Generic.SortedDictionary<double,LevelData> AllLevels = new System.Collections.Generic.SortedDictionary<double, LevelData>();
		private System.Collections.Generic.List<double> TerminatedLevels = new System.Collections.Generic.List<double>();

		public override string DisplayName { get { return "ARC_GFSystem"; } }

        protected override void OnStateChange()
        {
line = 2415;
try{
			OnStateChange_ErrorMsg = string.Empty;
            #region State == State.SetDefaults
            if (State == State.SetDefaults)
            {
				PrintTo = PrintTo.OutputTab2;
                Description             = @"Multi-timeframe fib levels with trade plans";
                Name                    = "ARC_GoldenFibsSystem_MTF";
                Calculate               = Calculate.OnBarClose;
                IsOverlay               = true;
                PaintPriceMarkers       = false;
                DisplayInDataBox        = false;
                IsAutoScale             = false;
                ArePlotsConfigurable    = false;
                ZOrder                  = 0;
                DrawOnPricePanel        = true;
                ScaleJustification      = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = true;
				pButtonText = "GF System";

line = 2434;
                for (int i = 0; i < 20; i++) AddPlot(Brushes.Black, String.Format("Confluence{0}", i));
                for (int i = 0; i < 20; i++) AddPlot(new Stroke(Brushes.Black, DashStyleHelper.Dash, 1), PlotStyle.Line, String.Format("WeakConfluence{0}", i));

				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
line = 2439;

                #region -- default parameters --
                BarPeriod               = 5;
                LineDensity             = ARC_GFSystem_FiblineResolutionA.Default;
                ConfluenceZone          = ARC_GFSystem_ConfluenceWidthA.Strong;
                Threshold               = 100;
                LookBackMinute          = 300;
                ShowMinuteDataPeriod    = false;
                ResistanceColor         = Brushes.Maroon;
                SupportColor            = Brushes.Blue;
                StrongPlotStyle         = PlotStyle.Line;
                WeakPlotStyle           = PlotStyle.Line;
                StrongDashStyle         = DashStyleHelper.Solid;
                WeakDashStyle           = DashStyleHelper.Solid;
                LineWidthStrong         = 2;
                LineWidthWeak           = 2;
                #endregion
line = 2457;

				#region TradingPlan defaults
				EntryZoneSize_inATRs = 0.5;
				EntryBasis = ARC_GFSystem_TradeEntryBasis.AtATR;
				PlanLevelsBasis = ARC_GFSystem_Plan_LevelsBasis.AtEntryPrice;
				ATRperiod  = 13;
				SLsize_inATRs  = 1.25;
				SLsize_inTicks  = 10;
				T1size_inATRs = 1.0;
				T2size_inATRs = 1.5;
				T1size_inTicks = 12;
				T2size_inTicks = 18;
				EntryBrush    = Brushes.White;
				ShortSLBrush  = Brushes.Green;
				ShortT1Brush = Brushes.LightGreen;
				ShortT2Brush = Brushes.DarkGreen;
				LongSLBrush    = Brushes.Red;
				LongT1Brush   = Brushes.Orange;
				LongT2Brush   = Brushes.DarkOrange;
				EntryDashStyle = DashStyleHelper.Dash;
				SLDashStyle  = DashStyleHelper.Solid;
				T1DashStyle = DashStyleHelper.Solid;
				T2DashStyle = DashStyleHelper.Solid;
				EntryLineWidth = 2;
				SLLineWidth  = 2;
				T1LineWidth = 2;
				T2LineWidth = 2;
				ShowLongTradePlans  = true;
				ShowShortTradePlans = true;
				ShowNearTradePlan   = true;
				ShowFarTradePlan    = true;
				ShowEntryZones      = true;
				ShowT2 = true;
				ShowT1 = true;
				ShowSL = true;
				NearTradePlan_LineLength = 5;
				FarTradePlan_LineLength  = 5;
				BuyFarTradePlan_Location   = ARC_GFSystem_TradePlanLocation.Right;
				BuyNearTradePlan_Location  = ARC_GFSystem_TradePlanLocation.Right;
				SellNearTradePlan_Location = ARC_GFSystem_TradePlanLocation.Right;
				SellFarTradePlan_Location  = ARC_GFSystem_TradePlanLocation.Right;
				BuyEntryZoneColor          = Brushes.Green;
				BuyEntryZoneColorOpacity   = 50;
				SellEntryZoneColor         = Brushes.Red;
				SellEntryZoneColorOpacity  = 50;
				FontEL  = new SimpleFont("Arial", 10);
				FontSL  = new SimpleFont("Arial", 10);
				FontT1 = new SimpleFont("Arial", 10);
				FontT2 = new SimpleFont("Arial", 10);
				ShortEntryLabel = "E";
				LongEntryLabel  = "E";
				ShortSLLabel    = "SL";
				LongSLLabel     = "SL";
				ShortT1Label   = "T1";
				LongT1Label    = "T1";
				ShortT2Label   = "T2";
				LongT2Label    = "T2";
				IncludeTerminatedLevels  = false;
				TerminatedLevelColor     = Brushes.Yellow;
				TerminatedLevelLineWidth = 1;
				TerminatedLevelDashStyle = DashStyleHelper.Solid;
				VisualShiftDistance = 2;
				DominantTradePlan = ARC_GFSystem_DominantTradePlan.None;
				#endregion

line = 2516;
				#region SwingTrend Defaults
				SwingStrength = 3;
                isHLBased = true;
				ShowStructureLines = true;
				UpTrendColor = Brushes.Green;
				OpacityUpTrendBkg = 20;
				DownTrendColor = Brushes.Maroon;
				OpacityDownTrendBkg = 20;
				UpLineColor   = Brushes.DarkGreen;
				DownLineColor = Brushes.Red;
				LineThickness = 2;
                ZZlabelFont = new SimpleFont("Arial", 12);
				ShowStructureLabels = false;
				#endregion

				pFarSell_RayTemplate  = "Default";
				pNearSell_RayTemplate = "Default";
				pNearBuy_RayTemplate  = "Default";
				pFarBuy_RayTemplate   = "Default";
            }
            #endregion

line = 2534;
            #region State == State.Configure
            if (State == State.Configure)
            {
line=3086;
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
#endif
                if(getBench) benchStart = DateTime.Now;

line = 2551;
                AddDataSeries(BarsPeriodType.Minute, BarPeriod);

line = 2554;
                if (IsAutoScale) IsAutoScale = false;
            }
            #endregion

line = 2861;
            #region State == State.Historical
            if (State == State.Historical)
            {
line=3437;
                #region -- end of initialization with User Parameters --
                for (int i = 0; i < 10; i++)
                {
                    Plots[i].Brush = ResistanceColor;
                    Plots[i].PlotStyle = StrongPlotStyle;
                    Plots[i].DashStyleHelper = StrongDashStyle;
                    Plots[i].Width = LineWidthStrong;
                }
                for (int i = 10; i < 20; i++)
                {
                    Plots[i].Brush = SupportColor;
                    Plots[i].PlotStyle = StrongPlotStyle;
                    Plots[i].DashStyleHelper = StrongDashStyle;
                    Plots[i].Width = LineWidthStrong;
                }
                for (int i = 20; i < 30; i++)
                {
                    Plots[i].Brush = ResistanceColor;
                    Plots[i].PlotStyle = WeakPlotStyle;
                    Plots[i].DashStyleHelper = WeakDashStyle;
                    Plots[i].Width = LineWidthWeak;
                }
                for (int i = 30; i < 40; i++)
                {
                    Plots[i].Brush = SupportColor;
                    Plots[i].PlotStyle = WeakPlotStyle;
                    Plots[i].DashStyleHelper = WeakDashStyle;
                    Plots[i].Width = LineWidthWeak;
                }
                #endregion
				ObjTagPrefix = string.Format("{0}#{1}{2}", Instrument.MasterInstrument.Name, DateTime.Now.Second,DateTime.Now.Millisecond);

line=3470;
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;
                        
                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

                            addGFSToolBar();
                            
                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

//                            ChartPanel.KeyUp += ChartPanel_KeyUp;
//                            ChartPanel.MouseUp += ChartPanel_MouseUp;
//                            ChartPanel.MouseMove += ChartPanel_MouseMove;
//                            ChartPanel.MouseDown += ChartPanel_MouseDown;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion

            }
            #endregion

line = 2930;
            #region State == State.DataLoaded
            if (State == State.DataLoaded)
            {
				StructureBiasMgr = new StructureBias(this, Highs[0], Lows[0], SwingStrength, isHLBased, MultiplierMD, MultiplierDTB, UpTrendColor, OpacityUpTrendBkg, DownTrendColor, OpacityDownTrendBkg);

                #region -- Init Arrays --
                for (int i = 0; i < 10; i++)
                {
                    timeFrameFactor[i] = i == 0 ? 1 : Math.Sqrt(stepUpRatio) * timeFrameFactor[i - 1];

                    upTrend[i] = true;
                    existsSwingHigh[i] = false;
                    existsSwingLow[i] = false;
                    minimumDeviation[i] = double.MaxValue;
                    for (int j = 0; j < 20; j++)
                    {
                        microHigh[i, j] = double.MaxValue;
                        microLow[i, j] = double.MinValue;
                    }
                    currentHigh[i] = 0;
                    currentLow[i] = 0;
                    currentSwingHigh[i] = double.MaxValue;
                    currentSwingLow[i] = double.MinValue;
                    lastSwingHigh[i] = double.MaxValue;
                    lastSwingLow[i] = double.MinValue;
                    microSwingHigh0[i] = double.MaxValue;
                    microSwingHigh1[i] = double.MaxValue;
                    microSwingHigh2[i] = double.MaxValue;
                    microSwingHigh3[i] = double.MaxValue;
                    microSwingLow0[i] = double.MinValue;
                    microSwingLow1[i] = double.MinValue;
                    microSwingLow2[i] = double.MinValue;
                    microSwingLow3[i] = double.MinValue;
                    retUp0[i] = 0;
                    retUp23[i] = 0;
                    retUp38[i] = 0;
                    retUp50[i] = 0;
                    retUp62[i] = 0;
                    retUp76[i] = 0;
                    retUp100[i] = 0;
                    retDown0[i] = 0;
                    retDown23[i] = 0;
                    retDown38[i] = 0;
                    retDown50[i] = 0;
                    retDown62[i] = 0;
                    retDown76[i] = 0;
                    retDown100[i] = 0;
                    extUp0[i] = 0;
                    extUp100[i] = 0;
                    extUp127[i] = 0;
                    extUp162[i] = 0;
                    extUp200[i] = 0;
                    extUp262[i] = 0;
                    extUp300[i] = 0;
                    extUp423[i] = 0;
                    extDown0[i] = 0;
                    extDown100[i] = 0;
                    extDown127[i] = 0;
                    extDown162[i] = 0;
                    extDown200[i] = 0;
                    extDown262[i] = 0;
                    extDown300[i] = 0;
                    extDown423[i] = 0;
                    dirUp38[i] = 0;
                    dirUp62[i] = 0;
                    dirUp100[i] = 0;
                    dirDown38[i] = 0;
                    dirDown62[i] = 0;
                    dirDown100[i] = 0;
                    lastDirUp38[i] = 0;
                    lastDirUp62[i] = 0;
                    lastDirUp100[i] = 0;
                    lastDirDown38[i] = 0;
                    lastDirDown62[i] = 0;
                    lastDirDown100[i] = 0;
                    alt0Up[i] = 0;
                    alt0Down[i] = 0;
                    alt1Up[i] = 0;
                    alt1Down[i] = 0;
                    alt0Up62[i] = 0;
                    alt0Up100[i] = 0;
                    alt0Up162[i] = 0;
                    alt1Up100[i] = 0;
                    alt0Down62[i] = 0;
                    alt0Down100[i] = 0;
                    alt0Down162[i] = 0;
                    alt1Down100[i] = 0;
                    priorCurrentHigh[i] = 0;
                    priorCurrentLow[i] = 0;
                    priorMicroSwingHigh0[i] = double.MaxValue;
                    priorMicroSwingHigh1[i] = double.MaxValue;
                    priorMicroSwingHigh2[i] = double.MaxValue;
                    priorMicroSwingHigh3[i] = double.MaxValue;
                    priorMicroSwingLow0[i] = double.MinValue;
                    priorMicroSwingLow1[i] = double.MinValue;
                    priorMicroSwingLow2[i] = double.MinValue;
                    priorMicroSwingLow3[i] = double.MinValue;
                    priorCurrentSwingHigh[i] = 0;
                    priorLastSwingHigh[i] = 0;
                    priorCurrentSwingLow[i] = 0;
                    priorLastSwingLow[i] = 0;
                    priorRetUp0[i] = 0;
                    priorRetUp23[i] = 0;
                    priorRetUp38[i] = 0;
                    priorRetUp50[i] = 0;
                    priorRetUp62[i] = 0;
                    priorRetUp76[i] = 0;
                    priorRetUp100[i] = 0;
                    priorRetDown0[i] = 0;
                    priorRetDown23[i] = 0;
                    priorRetDown38[i] = 0;
                    priorRetDown50[i] = 0;
                    priorRetDown62[i] = 0;
                    priorRetDown76[i] = 0;
                    priorRetDown100[i] = 0;
                    priorExtUp0[i] = 0;
                    priorExtUp100[i] = 0;
                    priorExtUp127[i] = 0;
                    priorExtUp162[i] = 0;
                    priorExtUp200[i] = 0;
                    priorExtUp262[i] = 0;
                    priorExtUp300[i] = 0;
                    priorExtUp423[i] = 0;
                    priorExtDown0[i] = 0;
                    priorExtDown100[i] = 0;
                    priorExtDown127[i] = 0;
                    priorExtDown162[i] = 0;
                    priorExtDown200[i] = 0;
                    priorExtDown262[i] = 0;
                    priorExtDown300[i] = 0;
                    priorExtDown423[i] = 0;
                    priorDirUp38[i] = 0;
                    priorDirUp62[i] = 0;
                    priorDirUp100[i] = 0;
                    priorDirDown38[i] = 0;
                    priorDirDown62[i] = 0;
                    priorDirDown100[i] = 0;
                    priorLastDirUp38[i] = 0;
                    priorLastDirUp62[i] = 0;
                    priorLastDirUp100[i] = 0;
                    priorLastDirDown38[i] = 0;
                    priorLastDirDown62[i] = 0;
                    priorLastDirDown100[i] = 0;
                    priorAlt0Up62[i] = 0;
                    priorAlt0Up100[i] = 0;
                    priorAlt0Up162[i] = 0;
                    priorAlt1Up100[i] = 0;
                    priorAlt0Down62[i] = 0;
                    priorAlt0Down100[i] = 0;
                    priorAlt0Down162[i] = 0;
                    priorAlt1Down100[i] = 0;
                    countDown[i] = -1;
                    currentSwingHighIndex[i] = -100;
                    lastSwingHighIndex[i] = -100;
                    currentSwingLowIndex[i] = -100;
                    lastSwingLowIndex[i] = -100;
                    weightMicroSwingHigh0[i] = 0;
                    weightMicroSwingHigh1[i] = 0;
                    weightMicroSwingHigh2[i] = 0;
                    weightMicroSwingHigh3[i] = 0;
                    weightMicroSwingLow0[i] = 0;
                    weightMicroSwingLow1[i] = 0;
                    weightMicroSwingLow2[i] = 0;
                    weightMicroSwingLow3[i] = 0;
                    weightCurrentSwingHigh[i] = 0;
                    weightLastSwingHigh[i] = 0;
                    weightCurrentSwingLow[i] = 0;
                    weightLastSwingLow[i] = 0;
                    weightRetUp23[i] = 0;
                    weightRetUp38[i] = 0;
                    weightRetUp50[i] = 0;
                    weightRetUp62[i] = 0;
                    weightRetUp76[i] = 0;
                    weightRetDown23[i] = 0;
                    weightRetDown38[i] = 0;
                    weightRetDown50[i] = 0;
                    weightRetDown62[i] = 0;
                    weightRetDown76[i] = 0;
                    weightExtUp127[i] = 0;
                    weightExtUp162[i] = 0;
                    weightExtUp200[i] = 0;
                    weightExtUp262[i] = 0;
                    weightExtUp300[i] = 0;
                    weightExtUp423[i] = 0;
                    weightExtDown127[i] = 0;
                    weightExtDown162[i] = 0;
                    weightExtDown200[i] = 0;
                    weightExtDown262[i] = 0;
                    weightExtDown300[i] = 0;
                    weightExtDown423[i] = 0;
                    weightDirUp38[i] = 0;
                    weightDirUp62[i] = 0;
                    weightDirUp100[i] = 0;
                    weightDirDown38[i] = 0;
                    weightDirDown62[i] = 0;
                    weightDirDown100[i] = 0;
                    weightLastDirUp38[i] = 0;
                    weightLastDirUp62[i] = 0;
                    weightLastDirUp100[i] = 0;
                    weightLastDirDown38[i] = 0;
                    weightLastDirDown62[i] = 0;
                    weightLastDirDown100[i] = 0;
                    weightAlt0Up62[i] = 0;
                    weightAlt0Up100[i] = 0;
                    weightAlt0Up162[i] = 0;
                    weightAlt1Up100[i] = 0;
                    weightAlt0Down62[i] = 0;
                    weightAlt0Down100[i] = 0;
                    weightAlt0Down162[i] = 0;
                    weightAlt1Down100[i] = 0;
                    cumulatedWeightMicroSwingHigh0[i] = 0;
                    cumulatedWeightMicroSwingHigh1[i] = 0;
                    cumulatedWeightMicroSwingHigh2[i] = 0;
                    cumulatedWeightMicroSwingHigh3[i] = 0;
                    cumulatedWeightMicroSwingLow0[i] = 0;
                    cumulatedWeightMicroSwingLow1[i] = 0;
                    cumulatedWeightMicroSwingLow2[i] = 0;
                    cumulatedWeightMicroSwingLow3[i] = 0;
                    cumulatedWeightCurrentSwingHigh[i] = 0;
                    cumulatedWeightLastSwingHigh[i] = 0;
                    cumulatedWeightCurrentSwingLow[i] = 0;
                    cumulatedWeightLastSwingLow[i] = 0;
                    cumulatedWeightRetUp23[i] = 0;
                    cumulatedWeightRetUp38[i] = 0;
                    cumulatedWeightRetUp50[i] = 0;
                    cumulatedWeightRetUp62[i] = 0;
                    cumulatedWeightRetUp76[i] = 0;
                    cumulatedWeightRetDown23[i] = 0;
                    cumulatedWeightRetDown38[i] = 0;
                    cumulatedWeightRetDown50[i] = 0;
                    cumulatedWeightRetDown62[i] = 0;
                    cumulatedWeightRetDown76[i] = 0;
                    cumulatedWeightExtUp127[i] = 0;
                    cumulatedWeightExtUp162[i] = 0;
                    cumulatedWeightExtUp200[i] = 0;
                    cumulatedWeightExtUp262[i] = 0;
                    cumulatedWeightExtUp300[i] = 0;
                    cumulatedWeightExtUp423[i] = 0;
                    cumulatedWeightExtDown127[i] = 0;
                    cumulatedWeightExtDown162[i] = 0;
                    cumulatedWeightExtDown200[i] = 0;
                    cumulatedWeightExtDown262[i] = 0;
                    cumulatedWeightExtDown300[i] = 0;
                    cumulatedWeightExtDown423[i] = 0;
                    cumulatedWeightDirUp38[i] = 0;
                    cumulatedWeightDirUp62[i] = 0;
                    cumulatedWeightDirUp100[i] = 0;
                    cumulatedWeightDirDown38[i] = 0;
                    cumulatedWeightDirDown62[i] = 0;
                    cumulatedWeightDirDown100[i] = 0;
                    cumulatedWeightLastDirUp38[i] = 0;
                    cumulatedWeightLastDirUp62[i] = 0;
                    cumulatedWeightLastDirUp100[i] = 0;
                    cumulatedWeightLastDirDown38[i] = 0;
                    cumulatedWeightLastDirDown62[i] = 0;
                    cumulatedWeightLastDirDown100[i] = 0;
                    cumulatedWeightAlt0Up62[i] = 0;
                    cumulatedWeightAlt0Up100[i] = 0;
                    cumulatedWeightAlt0Up162[i] = 0;
                    cumulatedWeightAlt1Up100[i] = 0;
                    cumulatedWeightAlt0Down62[i] = 0;
                    cumulatedWeightAlt0Down100[i] = 0;
                    cumulatedWeightAlt0Down162[i] = 0;
                    cumulatedWeightAlt1Down100[i] = 0;
                }
                for (int i = 0; i < 20; i++)
                {
                    strongFibs[i] = 0;
                    weakFibs[i] = 0;
                    priorStrongFibs[i] = 0;
                    priorWeakFibs[i] = 0;
                    oldStrongFibs[i] = 0;
                    oldWeakFibs[i] = 0;
                }
                for (int i = 0; i < 40; i++)
                {
                    newBOBHigh[i] = 0.0;
                    oldBOBHigh[i] = 0.0;
                    newBOBLow[i] = 0.0;
                    oldBOBLow[i] = 0.0;
                    newBOBClose[i] = 0.0;
                    oldBOBClose[i] = 0.0;
                    newState[i] = 1;
                    oldState[i] = 1;
                }
                for (int i = 0; i < 540; i++)
                {
                    fibLine[i] = 0;
                    fibWeight[i] = 0;
                    fibResistance[i] = 0;
                    weakResistance[i] = 0;
                    weightResistance[i] = 0;
                    fibSupport[i] = 0;
                    weakSupport[i] = 0;
                    weightSupport[i] = 0;
                }
                #endregion
				ResNear = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResNear_SL = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResNear_T1 = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResNear_T2 = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResNear_En = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResNear_AH = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResNear_AL = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResFar = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResFar_SL = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResFar_T1 = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResFar_T2 = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResFar_En = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResFar_AH = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				ResFar_AL = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupNear = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupNear_SL = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupNear_T1 = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupNear_T2 = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupNear_En = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupNear_AH = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupNear_AL = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupFar = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupFar_SL = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupFar_T1 = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupFar_T2 = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupFar_En = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupFar_AH = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				SupFar_AL = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
				atr = new Series<double>(BarsArray[0],MaximumBarsLookBack.Infinite);
line=3507;
                #region -- calculate zigZagFactor and confluenceRange --
                zigZagFactor = Math.Max(8, 16.0 / Math.Pow(BarPeriod, 0.25));
                if (ConfluenceZone == ARC_GFSystem_ConfluenceWidthA.Weak)
                    zigZagFactor = 1.2 * zigZagFactor;
                if (LineDensity == ARC_GFSystem_FiblineResolutionA.Small)
                    zigZagFactor = zigZagFactor / 1.4;
                else if (LineDensity == ARC_GFSystem_FiblineResolutionA.Smallest)
                    zigZagFactor = zigZagFactor / (1.96);
                else if (LineDensity == ARC_GFSystem_FiblineResolutionA.Increased)
                    zigZagFactor = 1.4 * zigZagFactor;
                else if (LineDensity == ARC_GFSystem_FiblineResolutionA.Large)
                    zigZagFactor = 1.96 * zigZagFactor;
                else if (LineDensity == ARC_GFSystem_FiblineResolutionA.Largest)
                    zigZagFactor = 2.74 * zigZagFactor;
                if (ConfluenceZone == ARC_GFSystem_ConfluenceWidthA.Strong)
                    confluenceRange = 0.2 * zigZagFactor;
                else
                    confluenceRange = 0.1 * zigZagFactor;
                #endregion

line = 2955;
                #region -- preloading code if needed --
                
line=3531;
				DateTime firstBarTime = DateTime.MinValue;
				DateTime minuteBarsStartDate = DateTime.MinValue;
				try{firstBarTime = BarsArray[1].GetTime(0);}catch{firstBarTime = BarsArray[0].GetTime(0);}
				try{minuteBarsStartDate = BarsArray[1].LastBarTime.AddDays(-LookBackMinute).Date;}
					catch{minuteBarsStartDate = BarsArray[0].LastBarTime.AddDays(-LookBackMinute).Date;}

line=3538;
                if (minuteBarsStartDate.CompareTo(firstBarTime.Date) < 0) preloadMinuteData = true;
                else preloadMinuteData = false;//no need preload because aleady 300days on the chart

                if (preloadMinuteData)
                {
line=3544;
                    minuteBars = loadHistoricalBars(Bars.ToDate.AddDays(-LookBackMinute).Date, Bars.ToDate);//preload bars - sync code
                    if (minuteBars == null || minuteBars.Count <= 1)//if no historical data
                    {
                        textBrush = ChartControl.Properties.AxisPen.Brush;
                        Draw.TextFixed(this, "errortag", errorData, TextPosition.Center, textBrush, textFont, Brushes.Transparent, Brushes.Transparent, 0);
                        generalError = true;
                    }
                    else
                    {
line=3554;
                        string minuteBarsStart = "";
                        CultureInfo minuteBarsCulture = new CultureInfo("en-us");

                        #region -- Calculate ATR and Fibs after 14 days --
                        while (minuteBars.GetTime(minuteBarIndex).CompareTo(firstBarTime) < 0)
                        {
                            priorBarHigh = minuteBars.GetHigh(minuteBarIndex);
                            priorBarLow = minuteBars.GetLow(minuteBarIndex);
                            priorBarClose = minuteBars.GetClose(minuteBarIndex);
                            currentBarHigh = minuteBars.GetHigh(minuteBarIndex + 1);
                            currentBarLow = minuteBars.GetLow(minuteBarIndex + 1);
                            currentBarClose = minuteBars.GetClose(minuteBarIndex + 1);

line=3568;
                            if (minuteBarIndex == 0)
                            {
                                minuteBarsStart = minuteBars.GetTime(minuteBarIndex).Date.ToString("d MMM yyyy", minuteBarsCulture);
                                firstSessionBegin = minuteBars.GetTime(minuteBarIndex).Date;
                            }
                            else if (minuteBarIndex == 1)
                            {
                                for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
                                {
                                    currentHigh[i] = currentBarHigh;
                                    currentLow[i] = currentBarLow;
                                }
                                currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                                avgTrueRange = currentBarTrueRange;
                            }
                            else
                            {
                                currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                                avgTrueRange = avgTrueRange * (minuteBarIndex - 1) / minuteBarIndex + currentBarTrueRange / minuteBarIndex;
                                if (minuteBars.GetTime(minuteBarIndex).CompareTo(firstSessionBegin.AddDays(14)) > 0)
                                {
                                    for (int i = lowestTimeFrame; i <= highestTimeFrame; i++) CalculateFibonacci(i);
                                    isTrainingComplete = true;
                                }
                            }
                            minuteBarIndex++;
                        }
                        #endregion
                        lastMinuteBarTime = minuteBars.GetTime(minuteBarIndex - 1);
line=3598;

                        if (ShowMinuteDataPeriod)
                        {
                            string minuteBarsEnd = minuteBars.GetTime(minuteBarIndex).Date.ToString("d MMM yyyy", minuteBarsCulture);
                            preloadedData = "ARC_GoldenFibsSystem v 2.0: Minute data preloaded from " + minuteBarsStart + " to " + minuteBarsEnd + " with " + minuteBars.Count + " bars";
                            textBrush = ChartControl.Properties.AxisPen.Brush;
                            drawPreloadInfo = true;
                        }
                    }
                }
                else if (ShowMinuteDataPeriod)
                {
line=3611;
                    preloadedData = "ARC_GoldenFibsSystem v 2.0: No minute data preloaded";
                    textBrush = ChartControl.Properties.AxisPen.Brush;
                    drawPreloadInfo = true;
                }
                #endregion

line=3618;
            }
            #endregion

line = 3049;
            #region State == State.Realtime
            if (State == State.Realtime)
            {
line = 3053;
                if (getBench)
                {
                    benchStop = DateTime.Now;
                    getBench = false;//only one print                    
                    Print("Loading time : " + benchStop.Subtract(benchStart).TotalMilliseconds);
                }
            }
            #endregion
			
            #region State == State.Terminated
            if(State == State.Terminated)
            {
line=3639;
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
						indytoolbar = null;
						try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							try{	chartWindow.MainMenu.Remove(indytoolbar);}catch{}
							indytoolbar = null;
							try{	chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;}catch{}
							chartWindow = null;
						}));
					}
				}

//                if (this.ChartControl != null)
//                {
//                    ChartPanel.KeyUp -= ChartPanel_KeyUp;
//                    ChartPanel.MouseUp -= ChartPanel_MouseUp;
//                    ChartPanel.MouseMove -= ChartPanel_MouseMove;
//                    ChartPanel.MouseDown -= ChartPanel_MouseDown;
//                }
            }
            #endregion

}catch(Exception e){
	OnStateChange_ErrorMsg = string.Format("{0}:  OnStateChange: \n{1}", line, e.ToString());
	Print(OnStateChange_ErrorMsg);
	Draw.TextFixed(this,"InitError","ARC_GoldenFibsSystem_MTF\n\nError during initialization...are you connected to your active datafeed?\n\nSee OutputWindow for more details", TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Maroon,Brushes.Maroon,80);
}
        }
		#region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}
		#endregion
		private double RoundToTick(double p){
			double t = p/TickSize;
			if(t>int.MaxValue) return int.MaxValue*TickSize;
			else if(t<int.MinValue) return int.MinValue*TickSize;
			int i = Convert.ToInt32(t);
			return i*TickSize;
		}
//=================================================================================================================================

		protected override void OnBarUpdate()
        {
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
line=3708;
try{
            if (!Data.BarsType.CreateInstance(Bars.BarsPeriod.BarsPeriodType).IsIntraday) return;
            if (generalError) return;

line=3713;
            if (BarsInProgress == 1)
            {
line=3716;
                #region -- preload needed --
                if (preloadMinuteData)
                {
                    #region -- Calculate on bar close --
                    if (Calculate == Calculate.OnBarClose)
                    {
                        if (Times[1][0].CompareTo(lastMinuteBarTime) <= 0) return;
                        currentBars1 = CurrentBars[1];
                        priorBarHigh = currentBarHigh;
                        priorBarLow = currentBarLow;
                        priorBarClose = currentBarClose;
                        currentBarHigh = Highs[1][0];
                        currentBarLow = Lows[1][0];
                        currentBarClose = Closes[1][0];
                        currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                        avgTrueRange = avgTrueRange * (minuteBarIndex - 1) / minuteBarIndex + currentBarTrueRange / minuteBarIndex;
                        minuteBarIndex = minuteBarIndex + 1;
                        //==============================================================================================================================
                        // Calculates Swing Highs and Lows, Retracements, Extensions, Alternates and Projections from currentBarHigh and currentBarLow
                        //==============================================================================================================================
                        if (Times[1][0].CompareTo(firstSessionBegin.AddDays(14)) > 0)
                        {
                            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++) CalculateFibonacci(i);
                            isTrainingComplete = true;
                        }
                        confluenceRangeWidth = confluenceRange * avgTrueRange;
                        upperLimitResistance = MAX(Highs[1], 20)[0] + displayFactor * avgTrueRange;
                        lowerLimitResistance = Closes[1][0];
                        upperLimitSupport = Closes[1][0];
                        lowerLimitSupport = MIN(Lows[1], 20)[0] - displayFactor * avgTrueRange;
                        upperLimitWeakResistance = MAX(Highs[1], 20)[0] + displayFactor * avgTrueRange;
                        lowerLimitWeakSupport = MIN(Lows[1], 20)[0] - displayFactor * avgTrueRange;
                    }
                    #endregion

                    #region -- Calculate on eachtick or change --
                    else if (CurrentBars[1] == 0) currentBars1 = CurrentBars[1];
                    else if (IsFirstTickOfBar)
                    {
                        if (Times[1][1].CompareTo(lastMinuteBarTime) <= 0) return;
                        currentBars1 = CurrentBars[1];
                        priorBarHigh = currentBarHigh;
                        priorBarLow = currentBarLow;
                        priorBarClose = currentBarClose;
                        currentBarHigh = Highs[1][1];
                        currentBarLow = Lows[1][1];
                        currentBarClose = Closes[1][1];
                        currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                        avgTrueRange = avgTrueRange * (minuteBarIndex - 1) / minuteBarIndex + currentBarTrueRange / minuteBarIndex;
                        minuteBarIndex = minuteBarIndex + 1;
                        //==============================================================================================================================
                        // Calculates Swing Highs and Lows, Retracements, Extensions, Alternates and Projections from currentBarHigh and currentBarLow
                        //==============================================================================================================================
                        if (Times[1][1].CompareTo(firstSessionBegin.AddDays(14)) > 0)
                        {
                            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++) CalculateFibonacci(i);
                            isTrainingComplete = true;
                        }
                        confluenceRangeWidth = confluenceRange * avgTrueRange;
                        upperLimitResistance = MAX(Highs[1], 20)[1] + displayFactor * avgTrueRange;
                        lowerLimitResistance = Closes[1][1];
                        upperLimitSupport = Closes[1][1];
                        lowerLimitSupport = MIN(Lows[1], 20)[1] - displayFactor * avgTrueRange;
                        upperLimitWeakResistance = MAX(Highs[1], 20)[1] + displayFactor * avgTrueRange;
                        lowerLimitWeakSupport = MIN(Lows[1], 20)[1] - displayFactor * avgTrueRange;
                    }
                    #endregion
                }
                #endregion

                #region -- no preload needed --
                else if (Times[1][0].CompareTo(firstSessionBegin) > 0)//no calculous if more than 300 days
                {
line=3790;
                    #region -- Calculate on bar close --
                    if (Calculate == Calculate.OnBarClose)
                    {
                        priorBarHigh = currentBarHigh;
                        priorBarLow = currentBarLow;
                        priorBarClose = currentBarClose;
                        currentBarHigh = Highs[1][0];
                        currentBarLow = Lows[1][0];
                        currentBarClose = Closes[1][0];
                        if (minuteBarIndex == 1)
                        {
                            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
                            {
                                currentHigh[i] = priorBarHigh;
                                currentLow[i] = priorBarLow;
                            }
                            currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                            avgTrueRange = currentBarTrueRange;
                        }
                        else if (minuteBarIndex > 1)
                        {
                            currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                            avgTrueRange = avgTrueRange * (minuteBarIndex - 1) / minuteBarIndex + currentBarTrueRange / minuteBarIndex;
                            //==============================================================================================================================
                            // Calculates Swing Highs and Lows, Retracements, Extensions, Alternates and Projections from currentBarHigh and currentBarLow
                            //==============================================================================================================================
                            if (Times[1][0].CompareTo(firstSessionBegin.AddDays(14)) > 0)
                            {
                                for (int i = lowestTimeFrame; i <= highestTimeFrame; i++) CalculateFibonacci(i);
                                isTrainingComplete = true;
                            }
                            confluenceRangeWidth = confluenceRange * avgTrueRange;
                            upperLimitResistance = MAX(Highs[1], 20)[0] + displayFactor * avgTrueRange;
                            lowerLimitResistance = Closes[1][0];
                            upperLimitSupport = Closes[1][0];
                            lowerLimitSupport = MIN(Lows[1], 20)[0] - displayFactor * avgTrueRange;
                            upperLimitWeakResistance = MAX(Highs[1], 20)[0] + displayFactor * avgTrueRange;
                            lowerLimitWeakSupport = MIN(Lows[1], 20)[0] - displayFactor * avgTrueRange;
                        }
                        minuteBarIndex = minuteBarIndex + 1;
                    }
                    #endregion

                    #region -- Calculate on eachtick or change --
                    else if (CurrentBars[1] == 0)
                    {
line=3837;
                        currentBarHigh = Highs[1][0];
                        currentBarLow = Lows[1][0];
                        currentBarClose = Closes[1][0];
                    }
                    else if (CurrentBars[1] > 0 && IsFirstTickOfBar)
                    {
line=3844;
                        priorBarHigh = currentBarHigh;
                        priorBarLow = currentBarLow;
                        priorBarClose = currentBarClose;
                        currentBarHigh = Highs[1][1];
                        currentBarLow = Lows[1][1];
                        currentBarClose = Closes[1][1];
                        if (minuteBarIndex == 1)
                        {
line=3853;
                            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
                            {
                                currentHigh[i] = priorBarHigh;
                                currentLow[i] = priorBarLow;
                            }
                            currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                            avgTrueRange = currentBarTrueRange;
                        }
                        else if (minuteBarIndex > 1)
                        {
line=3864;
                            currentBarTrueRange = Math.Max(priorBarClose, currentBarHigh) - Math.Min(priorBarClose, currentBarLow);
                            avgTrueRange = avgTrueRange * (minuteBarIndex - 1) / minuteBarIndex + currentBarTrueRange / minuteBarIndex;
                            //==============================================================================================================================
                            // Calculates Swing Highs and Lows, Retracements, Extensions, Alternates and Projections from currentBarHigh and currentBarLow
                            //==============================================================================================================================
                            if (Times[1][1].CompareTo(firstSessionBegin.AddDays(14)) > 0)
                            {
                                for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
                                    CalculateFibonacci(i);
                                isTrainingComplete = true;
                            }
line=3876;
                            confluenceRangeWidth = confluenceRange * avgTrueRange;
                            upperLimitResistance = MAX(Highs[1], 20)[1] + displayFactor * avgTrueRange;
                            lowerLimitResistance = Closes[1][1];
                            upperLimitSupport = Closes[1][1];
                            lowerLimitSupport = MIN(Lows[1], 20)[1] - displayFactor * avgTrueRange;
                            upperLimitWeakResistance = MAX(Highs[1], 20)[1] + displayFactor * avgTrueRange;
                            lowerLimitWeakSupport = MIN(Lows[1], 20)[1] - displayFactor * avgTrueRange;
                        }
                        minuteBarIndex = minuteBarIndex + 1;
                    }
                    #endregion
                }
                #endregion
            }

line=3892;
            if (BarsInProgress == 0)
            {
                if (drawPreloadInfo)
                {
                    Draw.TextFixed(this, "data check", preloadedData, TextPosition.BottomRight, textBrush, textFont2, Brushes.Transparent, Brushes.Transparent, 1);
                    drawPreloadInfo = false;
                }
                if (CurrentBars[0] < 2) return;

                if (isTrainingComplete && (IsFirstTickOfBar || currentBars1 > priorCurrentBars1))
                {
line=3904;
                    priorCurrentBars1 = currentBars1;

                    //==============================================================================================================================
                    // Sets all lines and weights within the display range
                    // Note : this is the hot path. It takes on average 1ms to run for each bar. On a 5 days 1Min barchart = 37000 bars, it takes 3.7s to run.
                    //==============================================================================================================================
                    SetLinesAndWeights();

line=3913;
                    //==============================================================================================================================
                    // Selects strong and weak lines above defined theshold for weight and checks whether weaker lines are in the smaller display range
                    //==============================================================================================================================
                    SelectLines();

line=3919;
                    //==============================================================================================================================
                    // Sorting Arrays fibLine, fibWeight, fibLine and  fibWeight with BubbleSort to prepare for Analyzer
                    // Note : the sorting method has been written to be faster than the Array.Sort c# method.
                    //==============================================================================================================================
                    SortLines();

                    //==============================================================================================================================
line=3927;
					#region Display up to 10 Resistance and 10 Support Ranges
					for (int i = 0; i < 10; i++)
					{
					    strongFibs[i]      = Instrument.MasterInstrument.RoundToTickSize(fibSupport[9 - i]);
					    strongFibs[10 + i] = Instrument.MasterInstrument.RoundToTickSize(fibResistance[i]);
					    weakFibs[i]        = Instrument.MasterInstrument.RoundToTickSize(weakSupport[9 - i]);
					    weakFibs[10 + i]   = Instrument.MasterInstrument.RoundToTickSize(weakResistance[i]);
					}

					if (IsFirstTickOfBar)
					{
						for (int i = 0; i < 20; i++)
						{
							oldStrongFibs[i] = Instrument.MasterInstrument.RoundToTickSize(priorStrongFibs[i]);
							oldState[i]      = newState[i];
							oldBOBHigh[i]    = newBOBHigh[i];
							oldBOBLow[i]     = newBOBLow[i];
							oldBOBClose[i]   = newBOBClose[i];
							if (SHOW_WEAKER_LINES)
							{
								int j = i + 20;
								oldWeakFibs[i] = Instrument.MasterInstrument.RoundToTickSize(priorWeakFibs[i]);
								oldState[j]    = newState[j];
								oldBOBHigh[j]  = newBOBHigh[j];
								oldBOBLow[j]   = newBOBLow[j];
								oldBOBClose[j] = newBOBClose[j];
							}
						}
					}

					for (int i = 0; i < 20; i++)
					{
					    for (int j = 0; j < 20; j++)
					    {
					        if (strongFibs[j] == oldStrongFibs[i])
					        {
					            strongFibs[j] = Instrument.MasterInstrument.RoundToTickSize(strongFibs[i]);
					            strongFibs[i] = Instrument.MasterInstrument.RoundToTickSize(oldStrongFibs[i]);
					        }
					        if (weakFibs[j] == oldWeakFibs[i])
					        {
					            weakFibs[j] = Instrument.MasterInstrument.RoundToTickSize(weakFibs[i]);
					            weakFibs[i] = Instrument.MasterInstrument.RoundToTickSize(oldWeakFibs[i]);
					        }
					    }
					}

					#region -- SET Confluences to strongFibs --
					Confluence0[0]  = strongFibs[0];
					Confluence1[0]  = strongFibs[1];
					Confluence2[0]  = strongFibs[2];
					Confluence3[0]  = strongFibs[3];
					Confluence4[0]  = strongFibs[4];
					Confluence5[0]  = strongFibs[5];
					Confluence6[0]  = strongFibs[6];
					Confluence7[0]  = strongFibs[7];
					Confluence8[0]  = strongFibs[8];
					Confluence9[0]  = strongFibs[9];
					Confluence10[0] = strongFibs[10];
					Confluence11[0] = strongFibs[11];
					Confluence12[0] = strongFibs[12];
					Confluence13[0] = strongFibs[13];
					Confluence14[0] = strongFibs[14];
					Confluence15[0] = strongFibs[15];
					Confluence16[0] = strongFibs[16];
					Confluence17[0] = strongFibs[17];
					Confluence18[0] = strongFibs[18];
					Confluence19[0] = strongFibs[19];
					#endregion

					//newState und newBobClose determined via fib values
					lowestResistance = double.MaxValue;
					highestSupport = double.MinValue;
//bool inzone = Time[0].Day==11 && Time[0].Month==6 && Time[0].Hour==10;

					for (int i = 0; i < 20; i++)
					{
						tmpFibValue        = strongFibs[i];
						priorStrongFibs[i] = tmpFibValue;
						tmpOldState = oldState[i];
						newState[i] = UpdateState(newState[i], oldState[i], oldStrongFibs[i], tmpFibValue, Highs[0][0], Lows[0][0], Closes[0][0]);

						if (newState[i] == 0)
						    PlotBrushes[i][0] = Brushes.Transparent;
						else if (newState[i] == 1 || newState[i] == 2){
						    PlotBrushes[i][0] = ResistanceColor;
						    lowestResistance = Math.Min(tmpFibValue, lowestResistance);
						}
						else if (newState[i] == 3 || newState[i] == 4){
						    PlotBrushes[i][0] = SupportColor;
						    highestSupport = Math.Max(tmpFibValue, highestSupport);
						}
					}
					#endregion
line=4022;
                    #region if (SHOW_WEAKER_LINES)
                    if (SHOW_WEAKER_LINES)
                    {
                        #region -- SET WeakConfluences to weakFibs --
                        WeakConfluence0[0] = weakFibs[0];
                        WeakConfluence1[0] = weakFibs[1];
                        WeakConfluence2[0] = weakFibs[2];
                        WeakConfluence3[0] = weakFibs[3];
                        WeakConfluence4[0] = weakFibs[4];
                        WeakConfluence5[0] = weakFibs[5];
                        WeakConfluence6[0] = weakFibs[6];
                        WeakConfluence7[0] = weakFibs[7];
                        WeakConfluence8[0] = weakFibs[8];
                        WeakConfluence9[0] = weakFibs[9];
                        WeakConfluence10[0] = weakFibs[10];
                        WeakConfluence11[0] = weakFibs[11];
                        WeakConfluence12[0] = weakFibs[12];
                        WeakConfluence13[0] = weakFibs[13];
                        WeakConfluence14[0] = weakFibs[14];
                        WeakConfluence15[0] = weakFibs[15];
                        WeakConfluence16[0] = weakFibs[16];
                        WeakConfluence17[0] = weakFibs[17];
                        WeakConfluence18[0] = weakFibs[18];
                        WeakConfluence19[0] = weakFibs[19];
                        #endregion

                        for (int i = 20; i < 40; i++)
                        {
                            tmpFibValue = weakFibs[i - 20];
                            priorWeakFibs[i - 20] = tmpFibValue;
                            tmpOldState = oldState[i];
							newState[i] = UpdateState(newState[i], oldState[i], oldWeakFibs[i-20], tmpFibValue, Highs[0][0], Lows[0][0], Closes[0][0]);

                            if (newState[i] == 0)
                                PlotBrushes[i][0] = Brushes.Transparent;
                            else if (newState[i] == 1 || newState[i] == 2)
                            {
                                PlotBrushes[i][0] = ResistanceColor;
//                                lowestResistance = Math.Min(tmpFibValue, lowestResistance);
                            }
                            else if (newState[i] == 3 || newState[i] == 4)
                            {
                                PlotBrushes[i][0] = SupportColor;
//                                highestSupport = Math.Max(tmpFibValue, highestSupport);
                            }
                        }
                    }
                    #endregion
					//if(IncludeTerminatedLevels)
line=4072;
					for (int i = 0; i < 40; i++){
						if(AllLevels.ContainsKey(Values[i][0])) {
							AllLevels[Values[i][0]].RMAbar = CurrentBar;
							AllLevels[Values[i][0]].State  = newState[i];
//if(inzone && Values[i][0]==65.79) Print(Time[0].ToString()+"  3562  State: "+newState[i]+"   "+Bars.GetTime(CurrentBar).ToString());
						}else{
							AllLevels[Values[i][0]] = new LevelData(CurrentBar, CurrentBar, newState[i]);
//if(inzone && Values[i][0]==65.79) Print(Time[0].ToString()+"  3565  State: "+newState[i]+"   "+Bars.GetTime(CurrentBar).ToString());
						}
					}
line=4083;
					TerminatedLevels.Clear();
					double near_support    = double.MinValue;
					double far_support     = double.MinValue;
					var keys = new System.Collections.Generic.List<double>(AllLevels.Keys);
line=4088;
					for(int i = 0; i<keys.Count; i++){
						if(AllLevels[keys[i]].RMAbar < CurrentBar){
line=4091;
							TerminatedLevels.Add(keys[i]);
							if(IncludeTerminatedLevels) 
								AllLevels[keys[i]].State = UpdateState(AllLevels[keys[i]].State, keys[i], Highs[0][0], Lows[0][0], Closes[0][0]);
							else 
								AllLevels[keys[i]].State = int.MinValue;//slated for removal
//if(inzone)Print(Time[0].ToString()+"  AllLevels["+keys[i].ToString()+"].State: "+AllLevels[keys[i]].State);
						}
						if (AllLevels[keys[i]].State == 3 || AllLevels[keys[i]].State == 4){
							if(keys[i] > near_support){
								far_support  = near_support;
							    near_support = keys[i];
							}
						}
					}
line=4106;
					double near_resistance = double.MaxValue;
					double far_resistance  = double.MaxValue;
					for(int i = keys.Count-1; i>=0; i--){
						if (AllLevels[keys[i]].State == 1 || AllLevels[keys[i]].State == 2){
							if(keys[i] < near_resistance){
								far_resistance = near_resistance;
							    near_resistance = keys[i];
							}
						}
					}
//Print("AllLevels.Count: "+AllLevels.Count);
//int ii = 0;
//foreach(var LK in AllLevels.Keys){
//	ii++;
//	Draw.Text(this, ii.ToString(), string.Format("State: {0}",AllLevels[LK].State), 10, LK);
//}
line=4117;
					if(!IncludeTerminatedLevels){
						#region remove terminated levels
						for(int i = 0; i<keys.Count; i++)
							AllLevels.Remove(keys[i]);
						keys = new System.Collections.Generic.List<double>(AllLevels.Keys);
						#endregion
					}
					
line=4126;
					double priorSupNear = SupNear[1];
					double priorResNear = ResNear[1];
					SupNear[0] = Instrument.MasterInstrument.RoundToTickSize(near_support);
					SupFar[0]  = Instrument.MasterInstrument.RoundToTickSize(far_support);
					ResNear[0] = Instrument.MasterInstrument.RoundToTickSize(near_resistance);
					ResFar[0]  = Instrument.MasterInstrument.RoundToTickSize(far_resistance);

					#region --- Update globalized rays if necessary ---
					var tag = "FS";
					if(GlobalRays.ContainsKey(tag)){
						GlobalRays[tag].LMAbar = CurrentBars[0]-1;
						GlobalRays[tag].DT = Times[0].GetValueAt(CurrentBars[0]-1);
						if(ResFar[0] != GlobalRays[tag].Price){
							GlobalRays[tag].Price = ResFar[0];
							if(GlobalRays[tag].IsDrawn){
								RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
								ImmediatelyDraw_Ray(tag, GlobalRays);
							}
						}
					}
					tag = "NS";
					if(GlobalRays.ContainsKey(tag)){
						GlobalRays[tag].LMAbar = CurrentBars[0]-1;
						GlobalRays[tag].DT = Times[0].GetValueAt(CurrentBars[0]-1);
						if(ResNear[0] != GlobalRays[tag].Price){
							GlobalRays[tag].Price = ResNear[0];
							if(GlobalRays[tag].IsDrawn){
								RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
								ImmediatelyDraw_Ray(tag, GlobalRays);
						}
						}
					}
					tag = "NB";
					if(GlobalRays.ContainsKey(tag)){
						GlobalRays[tag].LMAbar = CurrentBars[0]-1;
						GlobalRays[tag].DT = Times[0].GetValueAt(CurrentBars[0]-1);
						if(SupNear[0] != GlobalRays[tag].Price){
							GlobalRays[tag].Price = SupNear[0];
							if(GlobalRays[tag].IsDrawn){
								RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
								ImmediatelyDraw_Ray(tag, GlobalRays);
							}
						}
					}
					tag = "FB";
					if(GlobalRays.ContainsKey(tag)){
						GlobalRays[tag].LMAbar = CurrentBars[0]-1;
						GlobalRays[tag].DT = Times[0].GetValueAt(CurrentBars[0]-1);
						if(SupFar[0] != GlobalRays[tag].Price){
							GlobalRays[tag].Price = SupFar[0];
							if(GlobalRays[tag].IsDrawn){
								RemoveDrawObject(string.Format("@{0} {1}", tag, ObjTagPrefix));
								ImmediatelyDraw_Ray(tag, GlobalRays);
							}
						}
					}
					#endregion
line=4184;
					atr[0] = ATR(this.ATRperiod)[0];
					double SL_inPts = RoundToTick(this.SLsize_inATRs * atr[0]);
					if(this.SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.Ticks) SL_inPts = this.SLsize_inTicks * TickSize;
					double T1_inPts = RoundToTick(this.T1size_inATRs * atr[0]);
					if(this.SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.Ticks) T1_inPts = this.T1size_inTicks * TickSize;
					double T2_inPts = RoundToTick(this.T2size_inATRs * atr[0]);
					if(this.SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.Ticks) T2_inPts = this.T2size_inTicks * TickSize;

					var plan = new TradePlan('S', SupFar.GetValueAt(CurrentBar), PlanLevelsBasis, EntryBasis, atr.GetValueAt(CurrentBar-1), EntryZoneSize_inATRs, SL_inPts, T1_inPts, T2_inPts, TickSize);
					SupFar_SL[0] = plan.SLPrice;
					SupFar_T1[0] = plan.T1Price;
					SupFar_T2[0] = plan.T2Price;
					SupFar_En[0] = plan.EntryPrice;
					SupFar_AH[0] = plan.EntryZoneHighPrice;
					SupFar_AL[0] = plan.EntryZoneLowPrice;

					if(PlanLevelsBasis == ARC_GFSystem_Plan_LevelsBasis.AtFib){
						double ddd = 0;
						if(!double.IsNaN(plan.SLPrice)){
							ddd = Math.Abs((plan.EntryPrice - plan.SLPrice)/TickSize);
							if(ddd>10000) SLdistanceTicks=10000;
							else if(ddd<0) SLdistanceTicks=0;
							else if(double.IsNaN(ddd)) SLdistanceTicks = 0;
							else if(double.IsInfinity(ddd)) SLdistanceTicks = 10000;
							else
								SLdistanceTicks = Convert.ToInt32(ddd);
						}else SLdistanceTicks = -1;

						if(!double.IsNaN(plan.T1Price)){
							ddd = Math.Abs((plan.EntryPrice - plan.T1Price)/TickSize);
							if(ddd>10000) T1distanceTicks=10000;
							else if(ddd<0) T1distanceTicks=0;
							else if(double.IsNaN(ddd)) T1distanceTicks = 0;
							else if(double.IsInfinity(ddd)) T1distanceTicks = 10000;
							else
								T1distanceTicks = Convert.ToInt32(ddd);
						}else T1distanceTicks = -1;

						if(!double.IsNaN(plan.T2Price)){
							ddd = Math.Abs((plan.EntryPrice - plan.T2Price)/TickSize);
							if(ddd>10000) T2distanceTicks=10000;
							else if(ddd<0) T2distanceTicks=0;
							else if(double.IsNaN(ddd)) T2distanceTicks = 0;
							else if(double.IsInfinity(ddd)) T2distanceTicks = 10000;
							else
								T2distanceTicks = Convert.ToInt32(ddd);
						}else T2distanceTicks = -1;
					}else{
						SLdistanceTicks = (int)(SL_inPts / TickSize);
						T1distanceTicks = (int)(T1_inPts / TickSize);
						T2distanceTicks = (int)(T2_inPts / TickSize);
					}
					plan = new TradePlan('S', SupNear.GetValueAt(CurrentBar), PlanLevelsBasis, EntryBasis, atr.GetValueAt(CurrentBar-1), EntryZoneSize_inATRs, SL_inPts, T1_inPts, T2_inPts, TickSize);
					SupNear_SL[0] = plan.SLPrice;
					SupNear_T1[0] = plan.T1Price;
					SupNear_T2[0] = plan.T2Price;
					SupNear_En[0] = plan.EntryPrice;
					SupNear_AH[0] = plan.EntryZoneHighPrice;
					SupNear_AL[0] = plan.EntryZoneLowPrice;
					plan = new TradePlan('R', ResNear.GetValueAt(CurrentBar), PlanLevelsBasis, EntryBasis, atr.GetValueAt(CurrentBar-1), EntryZoneSize_inATRs, SL_inPts, T1_inPts, T2_inPts, TickSize);
					ResNear_SL[0] = plan.SLPrice;
					ResNear_T1[0] = plan.T1Price;
					ResNear_T2[0] = plan.T2Price;
					ResNear_En[0] = plan.EntryPrice;
					ResNear_AH[0] = plan.EntryZoneHighPrice;
					ResNear_AL[0] = plan.EntryZoneLowPrice;
					plan = new TradePlan('R', ResFar.GetValueAt(CurrentBar), PlanLevelsBasis, EntryBasis, atr.GetValueAt(CurrentBar-1), EntryZoneSize_inATRs, SL_inPts, T1_inPts, T2_inPts, TickSize);
					ResFar_SL[0] = plan.SLPrice;
					ResFar_T1[0] = plan.T1Price;
					ResFar_T2[0] = plan.T2Price;
					ResFar_En[0] = plan.EntryPrice;
					ResFar_AH[0] = plan.EntryZoneHighPrice;
					ResFar_AL[0] = plan.EntryZoneLowPrice;

					#region Update Cur SL, Avg SL, T1, T2 in interface menus
					if(IsFirstTickOfBar && (priorSupNear!=near_support || priorResNear != near_resistance)){
						if(SL_inPts < 10000 && SL_inPts > 0) {//filter out any erroneously large tick values, or small tick values
							if(SLdistanceTicks>=0) SL_List.Add(SLdistanceTicks);
							if(T1distanceTicks>=0) T1_List.Add(T1distanceTicks);
							if(T2distanceTicks>=0) T2_List.Add(T2distanceTicks);
						}
					}
line=4267;
					if(CurrentBar > BarsArray[0].Count-6 && AvgSL == double.MinValue){
						AvgSL = SL_List.Average();
						AvgT1 = T1_List.Average();
						AvgT2 = T2_List.Average();
						try{
							Dispatcher.BeginInvoke(new Action(() =>
							{
								try
								{
									if (this.miAvgSL != null)
									{
										miCurSL.Header = string.Format("Cur SL: {0}", SLdistanceTicks.ToString("0"));
										miAvgSL.Header = string.Format("Avg SL: {0}", AvgSL.ToString("0.0"));
										miAvgT1.Header = string.Format("Avg T1: {0}", AvgT1.ToString("0.0"));
										miAvgT2.Header = string.Format("Avg T2: {0}", AvgT2.ToString("0.0"));
									}
								}
								catch (Exception){};
							}));
						}catch(Exception d){Print(line+":  "+d.ToString());}
					}
					#endregion

line=4291;
					StructureBiasMgr.CalculateIt(CurrentBar, Input, IsFirstTickOfBar, Calculate, State, ATR(256)[0]);
//bool inzone = Time[0].Day==4 && Time[0].Month==6 && Time[0].Hour==21;
//if(inzone){
//	if(StructureBiasMgr.ErrorMsg.Length>0) Print(StructureBiasMgr.ErrorMsg);
//	Print(Time[0].ToString()+"   --------------");
//	foreach(var ss in StructureBiasMgr.sequence) Print(ss);
//}
					if(ShowStructureBackground){
line=4300;
						if(this.OpacityUpTrendBkg>0 && UpTrendColor != Brushes.Transparent && StructureBiasMgr.Bias[0] == UP){
							BackBrushes[0] = StructureBiasMgr.UpTrendColorTinted;
						}
						if(this.OpacityDownTrendBkg>0 && DownTrendColor != Brushes.Transparent && StructureBiasMgr.Bias[0] == DOWN){
							BackBrushes[0] = StructureBiasMgr.DownTrendColorTinted;
						}
					}
                }
            }
line=4310;
}catch(Exception obue){Print(line+":  "+obue.ToString());}
        }
//=======================================================================================================================
		#region UpdateState
		private int UpdateState(int newState, int oldState, double oldFibs, double tmpFibValue, double H, double L, double C){
			if (oldFibs != tmpFibValue)
			    return 0;
			else if (oldState == 0 && C < tmpFibValue)
			    return 1;
			else if (oldState == 0 && C >= tmpFibValue)
			    return 3;
			else if (oldState == 1 && L > tmpFibValue)
			    return 3;
			else if (oldState == 1)
			    return 1;
			else if (oldState == 3 && H < tmpFibValue)
			    return 1;
			else if (oldState == 3)
			    return 3;
			return newState;
		}
//=======================================================================================================================
		private int UpdateState(int State, double tmpFibValue, double H, double L, double C){
			return UpdateState(State, State, tmpFibValue, tmpFibValue, H, L, C);
		}
		#endregion
//=============================================================================================================
//		public override void OnRenderTargetChanged()
//		{
//			#region -- Brush disposal --
//			if(tpoVA_BrushDX!=null      && !tpoVA_BrushDX.IsDisposed)      tpoVA_BrushDX.Dispose();      tpoVA_BrushDX      = null;
//			if(RenderTarget!=null){
//				float divisor = 100f;
//				#region -- Brush init --
//				vpVA_BrushDX              = vpVABrush.ToDxBrush(RenderTarget);
//			}
//		}
//=======================================================================================================================
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{

            #region -- conditions to return --
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (Bars == null || ChartControl == null) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
			if (IsInHitTest) return;
            #endregion
line=4358;
			#region Create DX Brushes
			SharpDX.Direct2D1.Brush fillbrush = null;
			var EntryDXBrush  = EntryBrush.ToDxBrush(RenderTarget);
			var EntryContrastDXBrush = ContrastingColor((SolidColorBrush)EntryBrush).ToDxBrush(RenderTarget);
			EntryContrastDXBrush.Opacity  = 0.5f;

			#region Long trade plan brushes
			var LongSLDXBrush  = LongSLBrush.ToDxBrush(RenderTarget);
			var LongSLContrastDXBrush = ContrastingColor((SolidColorBrush)LongSLBrush).ToDxBrush(RenderTarget);
			LongSLContrastDXBrush.Opacity  = 0.5f;

			var LongT1DXBrush = LongT1Brush.ToDxBrush(RenderTarget);
			var LongT1ContrastDXBrush     = ContrastingColor((SolidColorBrush)LongT1Brush).ToDxBrush(RenderTarget);
			LongT1ContrastDXBrush.Opacity = 0.5f;

			var LongT2DXBrush = LongT2Brush.ToDxBrush(RenderTarget);
			var LongT2ContrastDXBrush     = ContrastingColor((SolidColorBrush)LongT2Brush).ToDxBrush(RenderTarget);
			LongT2ContrastDXBrush.Opacity = 0.5f;
			#endregion

			#region Short trade plan brushes
			var ShortSLDXBrush  = ShortSLBrush.ToDxBrush(RenderTarget);
			var ShortSLContrastDXBrush = ContrastingColor((SolidColorBrush)ShortSLBrush).ToDxBrush(RenderTarget);
			ShortSLContrastDXBrush.Opacity  = 0.5f;

			var ShortT1DXBrush = ShortT1Brush.ToDxBrush(RenderTarget);
			var ShortT1ContrastDXBrush     = ContrastingColor((SolidColorBrush)ShortT1Brush).ToDxBrush(RenderTarget);
			ShortT1ContrastDXBrush.Opacity = 0.5f;

			var ShortT2DXBrush = ShortT2Brush.ToDxBrush(RenderTarget);
			var ShortT2ContrastDXBrush     = ContrastingColor((SolidColorBrush)ShortT2Brush).ToDxBrush(RenderTarget);
			ShortT2ContrastDXBrush.Opacity = 0.5f;
			#endregion
			#endregion

			int rmab = BarsArray[0].GetBar(Times[0].GetValueAt(Math.Min(BarsArray[0].Count-1,ChartBars.ToIndex)));
			if(Calculate == Calculate.OnBarClose) rmab = rmab-1;

			#region -- draw structure --            
			if (ShowStructureLines)
			{
			    RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

				if (rmab >= 2)
				{
//				    double ThisSize = 0;

					var StructureLabelBrush = EntryDXBrush;

					var keys = new System.Collections.Generic.List<int>(StructureBiasMgr.AllPivots.Keys);
				    int j = keys.Count-1;
					double swingprice2 = Closes[0].GetValueAt(1);
					double swingprice1 = Closes[0].GetValueAt(1);
					float vTextOffset = 0;
					int swingABar1 = 1;
				    while (j > 0) { 
						j = j - 1;
						if(keys[j] < ChartBars.FromIndex) {
							swingABar1 = keys[j];
							swingprice1 = Math.Abs(StructureBiasMgr.AllPivots[swingABar1]);
							break;
						}
					}//j is now the first swing point prior to the first bar on the chart

                    try
                    {
						var lineBrushUp   = this.UpLineColor.ToDxBrush(RenderTarget);
						var lineBrushDown = this.DownLineColor.ToDxBrush(RenderTarget);
						var lineBrush = lineBrushUp;
						string zzId0 = "";
                        for (int i = j; keys[i] <= rmab; i++)
                        {
							bool IsLowSwing = false;
							int swingabar = keys[i];
							double swingprice = StructureBiasMgr.AllPivots[swingabar];
							if(swingprice < 0) {
								swingprice = Math.Abs(swingprice);
								lineBrush = lineBrushDown;
								if(swingprice<swingprice2) zzId0 = "LL";
								else if(swingprice>swingprice2) zzId0 = "HL";
								else zzId0 = "DB";
								IsLowSwing = true;
							}else{
								lineBrush = lineBrushUp;
								if(swingprice<swingprice2) zzId0 = "LH";
								else if(swingprice>swingprice2) zzId0 = "HH";
								else zzId0 = "DT";
							}

							int x1 = ChartControl.GetXByBarIndex(ChartBars, swingabar);
							int x2 = ChartControl.GetXByBarIndex(ChartBars, swingABar1);

							int y1 = chartScale.GetYByValue(swingprice);
							int y2 = chartScale.GetYByValue(swingprice1);

							drawLine(x1, x2, y1, y2, lineBrush,DashStyleHelper.Solid, LineThickness);
							if (ShowStructureLabels)
							{
try{
							    float[] SZ  = getTextHeightAndWidth(zzId0, ZZlabelFont);
							    if (!IsLowSwing){
									StructureLabelBrush = lineBrushUp;
									vTextOffset = -SZ[0] -3f;
								} else if (IsLowSwing) {
									StructureLabelBrush = lineBrushDown;
									vTextOffset = 3f;
								}
//Print("SZ[0]: "+SZ[0]+"  SZ[1]: "+SZ[1]);
							    drawString(zzId0, x1 - SZ[1] / 2, y1 + vTextOffset, ZZlabelFont, StructureLabelBrush, SharpDX.DirectWrite.TextAlignment.Center);                                            
}catch(Exception onr){Print("OnRender: "+onr.ToString());}
							}
							swingprice2 = swingprice1;
							swingprice1 = swingprice;
							swingABar1  = swingabar;

						}
						if(lineBrushUp!=null && !lineBrushUp.IsDisposed)     lineBrushUp.Dispose();   lineBrushUp=null;
						if(lineBrushDown!=null && !lineBrushDown.IsDisposed) lineBrushDown.Dispose(); lineBrushDown=null;
			        }
			        catch{ }
				}
				RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
			}
            #endregion

			try{
			base.OnRender(chartControl, chartScale);
			#region Calculate TradePlan levels
//			Print("rmab: "+rmab+"    BarsArray[0].Count: "+BarsArray[0].Count);
//			if(BarsInProgress==0)
			{
line=4494;
				double atrvalue = atr.GetValueAt(rmab);
				double SL_inPts = this.SLsize_inATRs * atrvalue;
				if(this.SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.Ticks) SL_inPts = this.SLsize_inTicks * TickSize;
				double T1_inPts = this.T1size_inATRs * atrvalue;
				if(this.SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.Ticks) T1_inPts = this.T1size_inTicks * TickSize;
				double T2_inPts = this.T2size_inATRs * atrvalue;
				if(this.SLTP_CalcBasis == ARC_GFSystem_SLTP_CalcBasis.Ticks) T2_inPts = this.T2size_inTicks * TickSize;

				if(this.ShowLongTradePlans){
					if(this.ShowNearTradePlan && SupNear.IsValidDataPointAt(rmab)){
						if(ParameterChanged || SupTPlan[0]==null || SupTPlan[0].EntryPrice != SupNear.GetValueAt(rmab)){
							SupTPlan[0] = new TradePlan('S', SupNear.GetValueAt(rmab), PlanLevelsBasis, EntryBasis, atr.GetValueAt(rmab), EntryZoneSize_inATRs, SL_inPts, T1_inPts, T2_inPts, TickSize);
//							SupTPlan[0].EntryPrice = Instrument.MasterInstrument.RoundToTickSize(SupTPlan[0].EntryPrice);
//							SupTPlan[0].SLPrice = Instrument.MasterInstrument.RoundToTickSize(SupTPlan[0].SLPrice);
//							if(!double.IsNaN(SupTPlan[0].T1Price)) SupTPlan[0].T1Price = Instrument.MasterInstrument.RoundToTickSize(SupTPlan[0].T1Price);
//							if(!double.IsNaN(SupTPlan[0].T2Price)) SupTPlan[0].T2Price = Instrument.MasterInstrument.RoundToTickSize(SupTPlan[0].T2Price);
							ParameterChanged = false;
						}
					}
					if(this.ShowFarTradePlan && SupFar.IsValidDataPointAt(rmab)){
						if(ParameterChanged || SupTPlan[1]==null || SupTPlan[1].EntryPrice != SupFar.GetValueAt(rmab)){
							SupTPlan[1] = new TradePlan('S', SupFar.GetValueAt(rmab), PlanLevelsBasis, EntryBasis, atr.GetValueAt(rmab), EntryZoneSize_inATRs, SL_inPts, T1_inPts, T2_inPts, TickSize);
//							SupTPlan[1].EntryPrice = Instrument.MasterInstrument.RoundToTickSize(SupTPlan[1].EntryPrice);
//							SupTPlan[1].SLPrice = Instrument.MasterInstrument.RoundToTickSize(SupTPlan[1].SLPrice);
//							if(!double.IsNaN(SupTPlan[1].T1Price)) SupTPlan[1].T1Price = Instrument.MasterInstrument.RoundToTickSize(SupTPlan[1].T1Price);
//							if(!double.IsNaN(SupTPlan[1].T2Price)) SupTPlan[1].T2Price = Instrument.MasterInstrument.RoundToTickSize(SupTPlan[1].T2Price);
							ParameterChanged = false;
						}
					}
				}
				if(this.ShowShortTradePlans){
line=4526;
					if(this.ShowNearTradePlan && ResNear.IsValidDataPointAt(rmab)){
						if(ParameterChanged || ResTPlan[0]==null || ResTPlan[0].EntryPrice != ResNear.GetValueAt(rmab)){
							ResTPlan[0] = new TradePlan('R', ResNear.GetValueAt(rmab), PlanLevelsBasis, EntryBasis, atr.GetValueAt(rmab), EntryZoneSize_inATRs, SL_inPts, T1_inPts, T2_inPts, TickSize);
//							ResTPlan[0].EntryPrice = Instrument.MasterInstrument.RoundToTickSize(ResTPlan[0].EntryPrice);
//							ResTPlan[0].SLPrice = Instrument.MasterInstrument.RoundToTickSize(ResTPlan[0].SLPrice);
//							if(!double.IsNaN(ResTPlan[0].T1Price)) ResTPlan[0].T1Price = Instrument.MasterInstrument.RoundToTickSize(ResTPlan[0].T1Price);
//							if(!double.IsNaN(ResTPlan[0].T2Price)) ResTPlan[0].T2Price = Instrument.MasterInstrument.RoundToTickSize(ResTPlan[0].T2Price);
							ParameterChanged = false;
						}
					}
					if(this.ShowFarTradePlan && ResFar.IsValidDataPointAt(rmab)){
						if(ParameterChanged || ResTPlan[1]==null || ResTPlan[1].EntryPrice != ResFar.GetValueAt(rmab)){
							ResTPlan[1] = new TradePlan('R', ResFar.GetValueAt(rmab), PlanLevelsBasis, EntryBasis, atr.GetValueAt(rmab), EntryZoneSize_inATRs, SL_inPts, T1_inPts, T2_inPts, TickSize);
//							ResTPlan[1].EntryPrice = Instrument.MasterInstrument.RoundToTickSize(ResTPlan[1].EntryPrice);
//							ResTPlan[1].SLPrice = Instrument.MasterInstrument.RoundToTickSize(ResTPlan[1].SLPrice);
//							if(!double.IsNaN(ResTPlan[1].T1Price)) ResTPlan[1].T1Price = Instrument.MasterInstrument.RoundToTickSize(ResTPlan[1].T1Price);
//							if(!double.IsNaN(ResTPlan[1].T2Price)) ResTPlan[1].T2Price = Instrument.MasterInstrument.RoundToTickSize(ResTPlan[1].T2Price);
							ParameterChanged = false;
						}
					}
				}
			}
			#endregion
line=4550;
			#region Draw Trade Plan Levels
			float x_rmab = chartControl.GetXByBarIndex(ChartBars, rmab);
			TradePlan ptr = null;
			SharpDX.RectangleF	EntryZoneRect;
line=4555;
			if(IncludeTerminatedLevels){
				#region Draw teriminated level lines
				var TerminatedDXBrush = TerminatedLevelColor.ToDxBrush(RenderTarget);
				foreach(double key in TerminatedLevels){
					if(AllLevels[key].LMAbar <= rmab){
						float x1 = chartControl.GetXByBarIndex(ChartBars, AllLevels[key].RMAbar);
						drawLine(key, key, x_rmab, x1, TerminatedDXBrush, TerminatedLevelDashStyle, TerminatedLevelLineWidth, chartControl, chartScale);
					}
				}
				if(TerminatedDXBrush!=null && !TerminatedDXBrush.IsDisposed) TerminatedDXBrush.Dispose(); 
				TerminatedDXBrush = null;
				#endregion
			}

			int structure_bias = StructureBiasMgr.Bias.GetValueAt(rmab);
			float MarginPushDistance = 0f;
			ARC_GFSystem_TradePlanLocation BNear = BuyNearTradePlan_Location;
			ARC_GFSystem_TradePlanLocation SNear = SellNearTradePlan_Location;
			ARC_GFSystem_TradePlanLocation BFar  = BuyFarTradePlan_Location;
			ARC_GFSystem_TradePlanLocation SFar  = SellFarTradePlan_Location;
			if(DominantTradePlan == ARC_GFSystem_DominantTradePlan.Long){
				BNear = ARC_GFSystem_TradePlanLocation.Left;
				BFar  = ARC_GFSystem_TradePlanLocation.Left;
				SNear = ARC_GFSystem_TradePlanLocation.Right;
				SFar  = ARC_GFSystem_TradePlanLocation.Right;
			} else if(DominantTradePlan == ARC_GFSystem_DominantTradePlan.Short){
				SNear = ARC_GFSystem_TradePlanLocation.Left;
				SFar  = ARC_GFSystem_TradePlanLocation.Left;
				BNear = ARC_GFSystem_TradePlanLocation.Right;
				BFar  = ARC_GFSystem_TradePlanLocation.Right;
			}

			if(BNear == ARC_GFSystem_TradePlanLocation.Left) MarginPushDistance = Math.Max(MarginPushDistance, this.NearTradePlan_LineLength);
			if(SNear == ARC_GFSystem_TradePlanLocation.Left) MarginPushDistance = Math.Max(MarginPushDistance, this.NearTradePlan_LineLength);
			if(BFar  == ARC_GFSystem_TradePlanLocation.Left) MarginPushDistance = Math.Max(MarginPushDistance, this.FarTradePlan_LineLength);
			if(SFar  == ARC_GFSystem_TradePlanLocation.Left) MarginPushDistance = Math.Max(MarginPushDistance, this.FarTradePlan_LineLength);
//			if(PrintPlansInRightMargin)
				x_rmab = x_rmab + (VisualShiftDistance + MarginPushDistance) * ChartControl.Properties.BarDistance + (Calculate==Calculate.OnBarClose ? 1.5f : 0.5f) * ChartControl.Properties.BarDistance;
//			else
//				x_rmab = x_rmab + MarginPushDistance * ChartControl.Properties.BarDistance + (Calculate==Calculate.OnBarClose ? 2f * ChartControl.Properties.BarDistance : 0);
			for(int i = 0; i<4; i++){
				double SLp = double.MinValue;
				double T1p = double.MinValue;
				double T2p = double.MinValue;
				double Enp = double.MinValue;
				double AHp = double.MinValue;
				double ALp = double.MinValue;
				try{
				ptr=null;
				if(ShowLongTradePlans){
					if(i==0 && ShowNearTradePlan){
						ptr = SupTPlan[0];
						SLp = SupNear_SL.GetValueAt(rmab);
						T1p = SupNear_T1.GetValueAt(rmab);
						T2p = SupNear_T2.GetValueAt(rmab);
						Enp = SupNear_En.GetValueAt(rmab);
						AHp = SupNear_AH.GetValueAt(rmab);
						ALp = SupNear_AL.GetValueAt(rmab);
					}
					else if(i==1 && ShowFarTradePlan) {
						ptr = SupTPlan[1];
						SLp = SupFar_SL.GetValueAt(rmab);
						T1p = SupFar_T1.GetValueAt(rmab);
						T2p = SupFar_T2.GetValueAt(rmab);
						Enp = SupFar_En.GetValueAt(rmab);
						AHp = SupFar_AH.GetValueAt(rmab);
						ALp = SupFar_AL.GetValueAt(rmab);
					}
				}
				if(ShowShortTradePlans){
					if(i==2 && ShowNearTradePlan) {
						ptr = ResTPlan[0];
						SLp = ResNear_SL.GetValueAt(rmab);
						T1p = ResNear_T1.GetValueAt(rmab);
						T2p = ResNear_T2.GetValueAt(rmab);
						Enp = ResNear_En.GetValueAt(rmab);
						AHp = ResNear_AH.GetValueAt(rmab);
						ALp = ResNear_AL.GetValueAt(rmab);
					}
					else if(i==3 && ShowFarTradePlan){
						ptr = ResTPlan[1];
						SLp = ResFar_SL.GetValueAt(rmab);
						T1p = ResFar_T1.GetValueAt(rmab);
						T2p = ResFar_T2.GetValueAt(rmab);
						Enp = ResFar_En.GetValueAt(rmab);
						AHp = ResFar_AH.GetValueAt(rmab);
						ALp = ResFar_AL.GetValueAt(rmab);
					}
				}
//				if(ShowStructureLines){
//					if(structure_bias == UP && (i==2 || i==3)) continue;//skip the Resistance (sell) Trade Plans
//					else if(structure_bias == DOWN && (i==0 || i==1)) continue;//Skip the Support (buy) Trade Plans
//					else if(structure_bias == FLAT) continue;
//				}
				if(ptr != null && !double.IsNaN(ptr.EntryPrice))
				{
					float x = x_rmab;
					float yTop = chartScale.GetYByValue(AHp);
					float yBot = chartScale.GetYByValue(ALp);
					float line_length = (i==0 || i==2 ? NearTradePlan_LineLength : FarTradePlan_LineLength) * ChartControl.Properties.BarDistance;
					bool LeftSideFlip = false;
					if(i==0 && BNear      == ARC_GFSystem_TradePlanLocation.Left)
						LeftSideFlip = true;
					else if(i==2 && SNear == ARC_GFSystem_TradePlanLocation.Left)
						LeftSideFlip = true;
					else if(i==1 && BFar  == ARC_GFSystem_TradePlanLocation.Left)
						LeftSideFlip = true;
					else if(i==3 && SFar  == ARC_GFSystem_TradePlanLocation.Left)
						LeftSideFlip = true;
					if(LeftSideFlip)
						x = x - line_length + 3f;
					else
						x = x - 3f;

					Brush SLBrush  = ShortSLBrush;
					Brush T1Brush = ShortT1Brush;
					Brush T2Brush = ShortT2Brush;
					SharpDX.Direct2D1.Brush SLDXBrush  = ShortSLDXBrush;
					SharpDX.Direct2D1.Brush T1DXBrush = ShortT1DXBrush;
					SharpDX.Direct2D1.Brush T2DXBrush = ShortT2DXBrush;
					SharpDX.Direct2D1.Brush SLContrastDXBrush = ShortSLContrastDXBrush;
					SharpDX.Direct2D1.Brush T1ContrastDXBrush = ShortT1ContrastDXBrush;
					SharpDX.Direct2D1.Brush T2ContrastDXBrush = ShortT2ContrastDXBrush;
					string EntryLabel = ShortEntryLabel;
					string SLLabel    = ShortSLLabel;
					string T1Label   = ShortT1Label;
					string T2Label   = ShortT2Label;
					if(Enp > SLp) {
						EntryLabel = LongEntryLabel;
						SLLabel    = LongSLLabel;
						T1Label    = LongT1Label;
						T2Label    = LongT2Label;
						SLBrush    = LongSLBrush;
						T1Brush    = LongT1Brush;
						T2Brush    = LongT2Brush;
						SLDXBrush  = LongSLDXBrush;
						T1DXBrush = LongT1DXBrush;
						T2DXBrush = LongT2DXBrush;
						SLContrastDXBrush  = LongSLContrastDXBrush;
						T1ContrastDXBrush = LongT1ContrastDXBrush;
						T2ContrastDXBrush = LongT2ContrastDXBrush;
					}

					if(ShowEntryZones){
						fillbrush = (i<2? BuyEntryZoneColor.ToDxBrush(RenderTarget) : SellEntryZoneColor.ToDxBrush(RenderTarget));
						EntryZoneRect	=	new SharpDX.RectangleF(x, yTop, line_length, yBot-yTop);
						RenderTarget.DrawRectangle(EntryZoneRect, fillbrush);
						fillbrush.Opacity = (i<2 ? BuyEntryZoneColorOpacity : SellEntryZoneColorOpacity) / 100f;
						RenderTarget.FillRectangle(EntryZoneRect, fillbrush);
					}
					if(EntryLineWidth>0 && EntryBrush != Brushes.Transparent){
						if(LeftSideFlip)
							drawstring(EntryLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(Enp)), -x, chartScale.GetYByValue(Enp), FontEL, EntryDXBrush, EntryContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
						else
							drawstring(EntryLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(Enp)), x+line_length+5, chartScale.GetYByValue(Enp), FontEL, EntryDXBrush, EntryContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
					}
//RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2((float)chartControl.PanelWidth,100),50,50),fillbrush);
					if(SLLineWidth>0 && SLBrush!=Brushes.Transparent && ShowSL){
						drawLine(SLp, SLp, x, x + line_length, SLDXBrush, SLDashStyle, SLLineWidth, chartControl, chartScale);
						if(LeftSideFlip)
							drawstring(SLLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(SLp)), -x, chartScale.GetYByValue(SLp), FontSL, SLDXBrush, SLContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
						else
							drawstring(SLLabel.Replace("*",Instrument.MasterInstrument.FormatPrice(SLp)), x+line_length+5, chartScale.GetYByValue(SLp), FontSL, SLDXBrush, SLContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
					}
					if(T1LineWidth>0 && T1Brush!=Brushes.Transparent && ShowT1){
						drawLine(T1p, T1p, x, x + line_length, T1DXBrush, T1DashStyle, T1LineWidth, chartControl, chartScale);
						if(LeftSideFlip)
							drawstring(T1Label.Replace("*",Instrument.MasterInstrument.FormatPrice(T1p)), -x, chartScale.GetYByValue(T1p), FontT1, T1DXBrush, T1ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
						else
							drawstring(T1Label.Replace("*",Instrument.MasterInstrument.FormatPrice(T1p)), x+line_length+5, chartScale.GetYByValue(T1p), FontT1, T1DXBrush, T1ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
					}
					if(T2LineWidth>0 && T2Brush!=Brushes.Transparent && ShowT2){
						drawLine(T2p, T2p, x, x + line_length, T2DXBrush, T2DashStyle, T2LineWidth, chartControl, chartScale);
						if(LeftSideFlip)
							drawstring(T2Label.Replace("*",Instrument.MasterInstrument.FormatPrice(T2p)), -x, chartScale.GetYByValue(T2p), FontT2, T2DXBrush, T2ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
						else
							drawstring(T2Label.Replace("*",Instrument.MasterInstrument.FormatPrice(T2p)), x+line_length+5, chartScale.GetYByValue(T2p), FontT2, T2DXBrush, T2ContrastDXBrush, SharpDX.DirectWrite.TextAlignment.Leading);
					}
				}
				}catch(Exception eee){Print(i+":   "+eee.ToString());}
			}
			#endregion
			}catch(Exception perr){Print(line+":  "+perr.ToString());}

			#region DX Brush Disposal
			if(fillbrush!=null && !fillbrush.IsDisposed) fillbrush.Dispose(); 
			fillbrush = null;

			if(EntryDXBrush!=null && !EntryDXBrush.IsDisposed) EntryDXBrush.Dispose(); 
			EntryDXBrush = null;

			if(ShortSLDXBrush!=null && !ShortSLDXBrush.IsDisposed) ShortSLDXBrush.Dispose(); 
			ShortSLDXBrush = null;
			if(ShortT1DXBrush!=null && !ShortT1DXBrush.IsDisposed) ShortT1DXBrush.Dispose(); 
			ShortT1DXBrush = null;
			if(ShortT2DXBrush!=null && !ShortT2DXBrush.IsDisposed) ShortT2DXBrush.Dispose(); 
			ShortT2DXBrush = null;

			if(LongSLDXBrush!=null && !LongSLDXBrush.IsDisposed) LongSLDXBrush.Dispose(); 
			LongSLDXBrush = null;
			if(LongT1DXBrush!=null && !LongT1DXBrush.IsDisposed) LongT1DXBrush.Dispose(); 
			LongT1DXBrush = null;
			if(LongT2DXBrush!=null && !LongT2DXBrush.IsDisposed) LongT2DXBrush.Dispose(); 
			LongT2DXBrush = null;

			if(EntryContrastDXBrush!=null && !EntryContrastDXBrush.IsDisposed) EntryContrastDXBrush.Dispose(); 
			EntryContrastDXBrush = null;

			if(ShortSLContrastDXBrush!=null && !ShortSLContrastDXBrush.IsDisposed) ShortSLContrastDXBrush.Dispose(); 
			ShortSLContrastDXBrush = null;
			if(ShortT1ContrastDXBrush!=null && !ShortT1ContrastDXBrush.IsDisposed) ShortT1ContrastDXBrush.Dispose(); 
			ShortT1ContrastDXBrush = null;
			if(ShortT2ContrastDXBrush!=null && !ShortT2ContrastDXBrush.IsDisposed) ShortT2ContrastDXBrush.Dispose(); 
			ShortT2ContrastDXBrush = null;
			
			if(LongSLContrastDXBrush!=null && !LongSLContrastDXBrush.IsDisposed) LongSLContrastDXBrush.Dispose(); 
			LongSLContrastDXBrush = null;
			if(LongT1ContrastDXBrush!=null && !LongT1ContrastDXBrush.IsDisposed) LongT1ContrastDXBrush.Dispose(); 
			LongT1ContrastDXBrush = null;
			if(LongT2ContrastDXBrush!=null && !LongT2ContrastDXBrush.IsDisposed) LongT2ContrastDXBrush.Dispose(); 
			LongT2ContrastDXBrush = null;
			#endregion
		}
//=============================================================================================================
		private void ImmediatelyDraw_Ray(string tag, SortedDictionary<string, Global_RaysData> dict){
			#region -- Draw Global Rays ------------------------------
			if(tag!=null && tag.Length>0){
				TriggerCustomEvent(o1 =>{Draw.Ray(this, string.Format("@{0} {1}",tag,ObjTagPrefix), dict[tag].DT, dict[tag].Price, Times[0].GetValueAt(CurrentBars[0]), dict[tag].Price, true, dict[tag].TemplateName);},0,null);
			}
			#endregion ----------------------------
		}
//=============================================================================================================
		private void ImmediatelyDraw_Rays(SortedDictionary<string, Global_RaysData> dict){
			#region -- Draw Global Rays ------------------------------
			foreach(var tag in dict.Keys){
				if(tag!=null && tag.Length>0){
					TriggerCustomEvent(o1 =>{Draw.Ray(this, string.Format("@{0} {1}",tag,ObjTagPrefix), dict[tag].DT, dict[tag].Price, Times[0].GetValueAt(CurrentBars[0]), dict[tag].Price, true, dict[tag].TemplateName);},0,null);
				}
			}
			#endregion ----------------------------
		}
//=============================================================================================================

		#region supporting code
        private float[] getTextHeightAndWidth(string text, SimpleFont font){
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

			float[] result = new float[2]{(float)font.Size, textLayout.Metrics.Width};

            textLayout.Dispose();
            textFormat.Dispose();

            return result;
		}
        private float getTextWidth(string text, SimpleFont font)
        {
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textwidth = textLayout.Metrics.Width;

            textLayout.Dispose();
            textFormat.Dispose();

            return textwidth;
        }
        private float getTextHeight(string text, SimpleFont font)
        {
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                );
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, float.MaxValue, float.MaxValue);

            float textheight = textLayout.Metrics.Height;

            textLayout.Dispose();
            textFormat.Dispose();

            return textheight;
        }
        private void drawstring(string text, float x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush,  SharpDX.Direct2D1.Brush bkgBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float MaxX = -9999f)
        {
			#region drawstring
			if (y < 0 || font.Size <= 0) return;//don't draw if outside of window. if size==0 throw exception
			//SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();

			var textFormat = new SharpDX.DirectWrite.TextFormat(
				Core.Globals.DirectWriteFactory,
				font.FamilySerialize,
				font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
				font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
				SharpDX.DirectWrite.FontStretch.Normal,
				(float)font.Size
			)
				{ TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, ChartPanel.W/3, ChartPanel.H);
			if(x<0) x = Math.Abs(x) - textLayout.Metrics.Width - 5;

			if(MaxX>0)
				x = Math.Min(x, MaxX - 3f - textLayout.Metrics.Width);

			y = y - textLayout.Metrics.Height/2.0;
			if (bkgBrush!=null && bkgBrush.Opacity>0) {
				double xl = x - 3;
				double xr = x + textLayout.Metrics.Width + 3;
				double yt = y - 1;
				double yb = y+textLayout.Metrics.Height + 2;
				if(textAlignment==SharpDX.DirectWrite.TextAlignment.Trailing){
					xr = x + textLayout.Metrics.LayoutWidth +3;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				else if(textAlignment==SharpDX.DirectWrite.TextAlignment.Center){
					xr = x + textLayout.Metrics.LayoutWidth/2 + 3 + textLayout.Metrics.Width/2;
					xl = xr - textLayout.Metrics.Width - 6;
				}
				var bkgBox = new System.Windows.Point[]
				{	new System.Windows.Point(xl, yt),
					new System.Windows.Point(xl, yb),
					new System.Windows.Point(xr, yb),
					new System.Windows.Point(xr, yt),
				};
				drawRegion(bkgBox, bkgBrush);
			}
			RenderTarget.DrawTextLayout(new SharpDX.Vector2(x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

			textLayout.Dispose();
			textFormat.Dispose();
			#endregion
		}
        //Draw a text at {x;y} coordinates in pixel.
        private void drawString(string text, double x, double y, SimpleFont font, SharpDX.Direct2D1.Brush textDXBrush, SharpDX.DirectWrite.TextAlignment textAlignment, float width = 0f)
        {
            SharpDX.Direct2D1.Factory factory = new SharpDX.Direct2D1.Factory();
            SharpDX.DirectWrite.TextFormat textFormat = new SharpDX.DirectWrite.TextFormat(
                Core.Globals.DirectWriteFactory,
                font.FamilySerialize,
                font.Bold ? SharpDX.DirectWrite.FontWeight.Bold : SharpDX.DirectWrite.FontWeight.Normal,
                font.Italic ? SharpDX.DirectWrite.FontStyle.Italic : SharpDX.DirectWrite.FontStyle.Normal,
                SharpDX.DirectWrite.FontStretch.Normal,
                (float)font.Size
                ) { TextAlignment = textAlignment, WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap };
            SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, text, textFormat, width == 0f ? getTextWidth(text, font) : width, float.MaxValue);

            RenderTarget.DrawTextLayout(new SharpDX.Vector2((float)x,(float)y), textLayout, textDXBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);

            textLayout.Dispose();
            textFormat.Dispose();
        }

        private void drawLine(float x1, float x2, float y1, float y2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle = DashStyleHelper.Solid, int width = 1, int opacity = 100)
        {
            dxbrush.Opacity = opacity / 100f;
            SharpDX.Direct2D1.DashStyle _dashstyle;
            if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

            SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
            SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

            RenderTarget.DrawLine(new SharpDX.Vector2(x1,y1), new SharpDX.Vector2(x2,y2), dxbrush, width, strokestyle);

            strokestyle.Dispose();
        }
        private void drawRegion(System.Windows.Point[] points, SharpDX.Direct2D1.Brush dxbrush)
        {
            SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

            SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
            SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
            sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
            sink1.AddLines(vectors);
            sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
            sink1.Close();

            RenderTarget.FillGeometry(geo1, dxbrush);
            geo1.Dispose();
            sink1.Dispose();
        }

        //set the color to Black or White depending on background color
        public Brush ContrastingColor(SolidColorBrush background)
        {
            // Counting the perceptive luminance - human eye favors green color... 
            double a = 1 - (0.299 * background.Color.R + 0.587 * background.Color.G + 0.114 * background.Color.B) / 255;
            if (a < 0.5) return Brushes.Black; // bright colors - black font
            else return Brushes.White; // dark colors - white font
        }

        //Draw a line between 2 points. 'x1' and 'x2' are pixel locations, the y value is the numerical value (ie price / oscillator value)
		private void drawLine(double val1, double val2, float x1, float x2, SharpDX.Direct2D1.Brush dxbrush, DashStyleHelper dashstyle, int width, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = true)
		{
			if(double.IsNaN(val1) || double.IsNaN(val2)) {Print("Val is NaN"); return;}
			//SharpDX.Direct2D1.Brush linebrush = couleur.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.DashStyle _dashstyle;
			if (!Enum.TryParse(dashstyle.ToString(), true, out _dashstyle)) _dashstyle = SharpDX.Direct2D1.DashStyle.Dash;

			SharpDX.Direct2D1.StrokeStyleProperties properties = new SharpDX.Direct2D1.StrokeStyleProperties() { DashStyle = _dashstyle };
			SharpDX.Direct2D1.StrokeStyle strokestyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, properties);

			SharpDX.Vector2 v1 = new SharpDX.Vector2(x1, drawOnPricePanel ? chartScale.GetYByValue(val1) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val1));
			SharpDX.Vector2 v2 = new SharpDX.Vector2(x2, drawOnPricePanel ? chartScale.GetYByValue(val2) : ChartPanel.Y + (float)chartScale.GetYByValueWpf(val2));
//Print("\nv1: "+v1.X+", "+v1.Y+"   "+val1);
//Print("v2: "+v2.X+", "+v2.Y+"   "+val2);
			RenderTarget.DrawLine(v1, v2, dxbrush, width, strokestyle);

			strokestyle.Dispose();
		}
		#endregion
		//This function does a bar request to preload historical minute bars. It is an asynchrone function but has been made synchrone.
		#region -- loadHistoricalBars --
		private Bars loadHistoricalBars(DateTime dtfrom, DateTime dtto)
		{
			//---- Prepa Bars Request ----
			BarsRequest barsRequest = new BarsRequest(Bars.Instrument, dtfrom, dtto) { TradingHours = Bars.TradingHours, IsSplitAdjusted = false/*Bars.IsSplitAdjusted*/, IsDividendAdjusted = Bars.IsDividendAdjusted };
			barsRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, MarketDataType = Bars.BarsPeriod.MarketDataType, Value = BarPeriod };

			//---- Request the bars ----
			bool doWait = true;
			Bars retour = null;
			barsRequest.Request(new Action<BarsRequest, NinjaTrader.Cbi.ErrorCode, string>((bars, errorCode, errorMessage) =>
			{
				if (errorCode != NinjaTrader.Cbi.ErrorCode.NoError) { retour = null; doWait = false; return; }
				else if (bars.Bars == null || bars.Bars.Count == 0) { doWait = false; return; }
				retour = bars.Bars;
				doWait = false;
				return;
			}));
			while (doWait) { Thread.Sleep(10); }//made synchrone cause need request to finish before continuing
			return retour;
		}
		#endregion

		#region -- CalculateFibonacci --
		public void CalculateFibonacci(int i)
		{
			minimumDeviation[i] = zigZagFactor * Math.Pow(stepUpRatio, i) * avgTrueRange;
			timeFrameMultiplier = 1.5 * timeFrameFactor[i];
			highUpdate = upTrend[i] && priorBarHigh >= currentBarHigh && priorBarHigh > currentHigh[i];
			lowUpdate = !upTrend[i] && priorBarLow <= currentBarLow && priorBarLow < currentLow[i];
			addHigh = !upTrend[i] && priorBarHigh >= currentBarHigh && priorBarHigh > currentLow[i] + minimumDeviation[i];
			addLow = upTrend[i] && priorBarLow <= currentBarLow && priorBarLow < currentHigh[i] - minimumDeviation[i];
			normalizedRangeUp = 0;
			normalizedRangeDown = 0;

            // Condition required to speed up the indicator
            //==========================================================================================================================
            // printing of lines is delayed by one bar to avoid vertical lines on the chart

            countDown[i] = highUpdate || lowUpdate || addHigh || addLow?1:countDown[i] - 1;

            #region -- countDown[i] == 0 --
            if (countDown[i] == 0)
            {
                priorCurrentHigh[i] = currentHigh[i];
                priorCurrentLow[i] = currentLow[i];
                priorMicroSwingHigh0[i] = microSwingHigh0[i];
                priorMicroSwingHigh1[i] = microSwingHigh1[i];
                priorMicroSwingHigh2[i] = microSwingHigh2[i];
                priorMicroSwingHigh3[i] = microSwingHigh3[i];
                priorMicroSwingLow0[i] = microSwingLow0[i];
                priorMicroSwingLow1[i] = microSwingLow1[i];
                priorMicroSwingLow2[i] = microSwingLow2[i];
                priorMicroSwingLow3[i] = microSwingLow3[i];
                priorCurrentSwingHigh[i] = currentSwingHigh[i];
                priorLastSwingHigh[i] = lastSwingHigh[i];
                priorCurrentSwingLow[i] = currentSwingLow[i];
                priorLastSwingLow[i] = lastSwingLow[i];
                priorRetUp0[i] = retUp0[i];
                priorRetUp23[i] = retUp23[i];
                priorRetUp38[i] = retUp38[i];
                priorRetUp50[i] = retUp50[i];
                priorRetUp62[i] = retUp62[i];
                priorRetUp76[i] = retUp76[i];
                priorRetUp100[i] = retUp100[i];
                priorRetDown0[i] = retDown0[i];
                priorRetDown23[i] = retDown23[i];
                priorRetDown38[i] = retDown38[i];
                priorRetDown50[i] = retDown50[i];
                priorRetDown62[i] = retDown62[i];
                priorRetDown76[i] = retDown76[i];
                priorRetDown100[i] = retDown100[i];
                priorExtUp0[i] = extUp0[i];
                priorExtUp100[i] = extUp100[i];
                priorExtUp127[i] = extUp127[i];
                priorExtUp162[i] = extUp162[i];
                priorExtUp200[i] = extUp200[i];
                priorExtUp262[i] = extUp262[i];
                priorExtUp300[i] = extUp300[i];
                priorExtUp423[i] = extUp423[i];
                priorExtDown0[i] = extDown0[i];
                priorExtDown100[i] = extDown100[i];
                priorExtDown127[i] = extDown127[i];
                priorExtDown162[i] = extDown162[i];
                priorExtDown200[i] = extDown200[i];
                priorExtDown262[i] = extDown262[i];
                priorExtDown300[i] = extDown300[i];
                priorExtDown423[i] = extDown423[i];
                priorLastDirUp38[i] = lastDirUp38[i];
                priorLastDirUp62[i] = lastDirUp62[i];
                priorLastDirUp100[i] = lastDirUp100[i];
                priorLastDirDown38[i] = lastDirDown38[i];
                priorLastDirDown62[i] = lastDirDown62[i];
                priorLastDirDown100[i] = lastDirDown100[i];
                priorDirUp38[i] = dirUp38[i];
                priorDirUp62[i] = dirUp62[i];
                priorDirUp100[i] = dirUp100[i];
                priorDirDown38[i] = dirDown38[i];
                priorDirDown62[i] = dirDown62[i];
                priorDirDown100[i] = dirDown100[i];
                priorLastDirUp38[i] = lastDirUp38[i];
                priorLastDirUp62[i] = lastDirUp62[i];
                priorLastDirUp100[i] = lastDirUp100[i];
                priorLastDirDown38[i] = lastDirDown38[i];
                priorLastDirDown62[i] = lastDirDown62[i];
                priorLastDirDown100[i] = lastDirDown100[i];
                priorDirUp38[i] = dirUp38[i];
                priorDirUp62[i] = dirUp62[i];
                priorDirUp100[i] = dirUp100[i];
                priorDirDown38[i] = dirDown38[i];
                priorDirDown62[i] = dirDown62[i];
                priorDirDown100[i] = dirDown100[i];
                priorAlt0Up62[i] = alt0Up62[i];
                priorAlt0Up100[i] = alt0Up100[i];
                priorAlt0Up162[i] = alt0Up162[i];
                priorAlt1Up100[i] = alt1Up100[i];
                priorAlt0Down62[i] = alt0Down62[i];
                priorAlt0Down100[i] = alt0Down100[i];
                priorAlt0Down162[i] = alt0Down162[i];
                priorAlt1Down100[i] = alt1Down100[i];
            }
            #endregion

            if (countDown[i] == 1)
            {
                #region -- Section to identify ZigZagHighs and ZigZagLows filling them into arrays --
                priorCurrentHigh[i] = currentHigh[i];
                priorCurrentLow[i] = currentLow[i];
                priorMicroSwingHigh0[i] = microSwingHigh0[i];
                priorMicroSwingHigh1[i] = microSwingHigh1[i];
                priorMicroSwingHigh2[i] = microSwingHigh2[i];
                priorMicroSwingHigh3[i] = microSwingHigh3[i];
                priorMicroSwingLow0[i] = microSwingLow0[i];
                priorMicroSwingLow1[i] = microSwingLow1[i];
                priorMicroSwingLow2[i] = microSwingLow2[i];
                priorMicroSwingLow3[i] = microSwingLow3[i];

                if (addHigh) // when new high is added, currentLow is validated
                {
                    upTrend[i] = true;
                    microLow[i, 0] = currentLow[i];
                    currentHigh[i] = priorBarHigh;
                    if (microLow[i, 0] < microLow[i, 1]) // requires initialization
                        existsSwingLow[i] = true;
                }
                else if (highUpdate)
                {
                    currentHigh[i] = priorBarHigh;
                }
                else if (addLow)  // when new low is added, currentHigh is validated and set to MicroHighArray, microLow[0] is left empty 
                {
                    upTrend[i] = false;
                    for (int j = 19; j > 0; j--)
                    {
                        microHigh[i, j] = microHigh[i, j - 1];
                        microLow[i, j] = microLow[i, j - 1];
                    }
                    microHigh[i, 0] = currentHigh[i];
                    microLow[i, 0] = double.MinValue; // not yet containing valid information, assymetric code
                    currentLow[i] = priorBarLow;
                    if (microHigh[i, 0] > microHigh[i, 1]) // requires initialization
                        existsSwingHigh[i] = true;
                }
                else if (lowUpdate)
                {
                    currentLow[i] = priorBarLow;
                }
                #endregion

                //=========================================================================================================================
                #region -- Section to calculate Swing Highs and Swing Lows --
                priorCurrentSwingHigh[i] = currentSwingHigh[i];
                priorLastSwingHigh[i] = lastSwingHigh[i];
                priorCurrentSwingLow[i] = currentSwingLow[i];
                priorLastSwingLow[i] = lastSwingLow[i];

                if (addLow)
                {
                    if (microHigh[i, 0] >= microHigh[i, 1] + double.Epsilon)
                    {
                        if (currentSwingHighIndex[i] >= 0)
                        {
                            lastSwingHigh[i] = currentSwingHigh[i];
                            lastSwingHighIndex[i] = currentSwingHighIndex[i] + 1;
                            if (lastSwingLowIndex[i] >= 0)
                                weightLastSwingHigh[i] = specificWeightLastSwing * (1.0 + 0.001 * i) * Math.Sqrt((lastSwingHigh[i] - lastSwingLow[i]) / (zigZagFactor * avgTrueRange));
                            else
                                weightLastSwingHigh[i] = specificWeightLastSwing * (1.0 + 0.001 * i) * timeFrameMultiplier;
                        }
                        currentSwingHigh[i] = microHigh[i, 0];
                        if (currentSwingLowIndex[i] >= 0)
                            weightCurrentSwingHigh[i] = specificWeightCurrentSwing * (1.0 + 0.001 * i) * Math.Sqrt((currentSwingHigh[i] - currentSwingLow[i]) / (zigZagFactor * avgTrueRange));
                        else
                            weightCurrentSwingHigh[i] = specificWeightCurrentSwing * (1.0 + 0.001 * i) * timeFrameMultiplier;
                        currentSwingHighIndex[i] = 0;
                    }
                    else
                    {
                        currentSwingHighIndex[i] = currentSwingHighIndex[i] + 1;
                        lastSwingHighIndex[i] = lastSwingHighIndex[i] + 1;
                    }
                    currentSwingLowIndex[i] = currentSwingLowIndex[i] + 1;
                    lastSwingLowIndex[i] = lastSwingLowIndex[i] + 1;
                }
                if (addHigh)
                {
                    if (microLow[i, 0] <= microLow[i, 1] - double.Epsilon)
                    {
                        if (currentSwingLowIndex[i] >= 0)
                        {
                            lastSwingLow[i] = currentSwingLow[i];
                            lastSwingLowIndex[i] = currentSwingLowIndex[i];
                            if (lastSwingHighIndex[i] >= 0)
                                weightLastSwingLow[i] = specificWeightLastSwing * (1.0 + 0.001 * i) * Math.Sqrt((lastSwingHigh[i] - lastSwingLow[i]) / (zigZagFactor * avgTrueRange));
                            else
                                weightLastSwingLow[i] = specificWeightLastSwing * (1.0 + 0.001 * i) * timeFrameMultiplier;
                        }
                        currentSwingLow[i] = microLow[i, 0];
                        if (currentSwingHighIndex[i] >= 0)
                            weightCurrentSwingLow[i] = specificWeightCurrentSwing * (1.0 + 0.001 * i) * Math.Sqrt((currentSwingHigh[i] - currentSwingLow[i]) / (zigZagFactor * avgTrueRange));
                        else
                            weightCurrentSwingLow[i] = specificWeightCurrentSwing * (1.0 + 0.001 * i) * timeFrameMultiplier;
                        currentSwingLowIndex[i] = 0;
                    }
                }
                #endregion 

                //=========================================================================================================================
                #region -- Section to separate Swing Highs from MicroSwing Highs and Swing Lows from MicroSwing Lows --

                highCount = 0;

                if (addLow)
                {
                    if (currentSwingHighIndex[i] != highCount)
                    {
                        microSwingHigh0[i] = microHigh[i, highCount];
                        highCount = highCount + 1; ;
                    }
                    else if (lastSwingHighIndex[i] != highCount + 1)
                    {
                        microSwingHigh0[i] = microHigh[i, highCount + 1];
                        highCount = highCount + 2;
                    }
                    else
                    {
                        microSwingHigh0[i] = microHigh[i, highCount + 2];
                        highCount = highCount + 3;
                    }

                    if (currentSwingHighIndex[i] != highCount && lastSwingHighIndex[i] != highCount)
                    {
                        microSwingHigh1[i] = microHigh[i, highCount];
                        highCount = highCount + 1; ;
                    }
                    else if (lastSwingHighIndex[i] != highCount + 1)
                    {
                        microSwingHigh1[i] = microHigh[i, highCount + 1];
                        highCount = highCount + 2;
                    }
                    else
                    {
                        microSwingHigh1[i] = microHigh[i, highCount + 2];
                        highCount = highCount + 3;
                    }

                    if (currentSwingHighIndex[i] != highCount && lastSwingHighIndex[i] != highCount)
                    {
                        microSwingHigh2[i] = microHigh[i, highCount];
                        highCount = highCount + 1; ;
                    }
                    else if (lastSwingHighIndex[i] != highCount + 1)
                    {
                        microSwingHigh2[i] = microHigh[i, highCount + 1];
                        highCount = highCount + 2;
                    }
                    else
                    {
                        microSwingHigh2[i] = microHigh[i, highCount + 2];
                        highCount = highCount + 3;
                    }

                    if (currentSwingHighIndex[i] != highCount && lastSwingHighIndex[i] != highCount)
                    {
                        microSwingHigh3[i] = microHigh[i, highCount];
                        highCount = highCount + 1; ;
                    }
                    else if (lastSwingHighIndex[i] != highCount + 1)
                    {
                        microSwingHigh3[i] = microHigh[i, highCount + 1];
                        highCount = highCount + 2;
                    }
                    else
                    {
                        microSwingHigh3[i] = microHigh[i, highCount + 2];
                        highCount = highCount + 3;
                    }
                    weightMicroSwingHigh0[i] = specificWeightMicroSwing0 * (1.0 + 0.001 * i) * timeFrameMultiplier;
                    weightMicroSwingHigh1[i] = specificWeightMicroSwing1 * (1.0 + 0.001 * i) * timeFrameMultiplier;
                    weightMicroSwingHigh2[i] = specificWeightMicroSwing2 * (1.0 + 0.001 * i) * timeFrameMultiplier;
                    weightMicroSwingHigh3[i] = specificWeightMicroSwing3 * (1.0 + 0.001 * i) * timeFrameMultiplier;
                }

                lowCount = 0;

                if (addHigh)
                {
                    if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
                    {
                        microSwingLow0[i] = microLow[i, lowCount];
                        lowCount = lowCount + 1; ;
                    }
                    else if (lastSwingLowIndex[i] != lowCount + 1)
                    {
                        microSwingLow0[i] = microLow[i, lowCount + 1];
                        lowCount = lowCount + 2;
                    }
                    else
                    {
                        microSwingLow0[i] = microLow[i, lowCount + 2];
                        lowCount = lowCount + 3;
                    }

                    if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
                    {
                        microSwingLow1[i] = microLow[i, lowCount];
                        lowCount = lowCount + 1; ;
                    }
                    else if (lastSwingLowIndex[i] != lowCount + 1)
                    {
                        microSwingLow1[i] = microLow[i, lowCount + 1];
                        lowCount = lowCount + 2;
                    }
                    else
                    {
                        microSwingLow1[i] = microLow[i, lowCount + 2];
                        lowCount = lowCount + 3;
                    }

                    if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
                    {
                        microSwingLow2[i] = microLow[i, lowCount];
                        lowCount = lowCount + 1; ;
                    }
                    else if (lastSwingLowIndex[i] != lowCount + 1)
                    {
                        microSwingLow2[i] = microLow[i, lowCount + 1];
                        lowCount = lowCount + 2;
                    }
                    else
                    {
                        microSwingLow2[i] = microLow[i, lowCount + 2];
                        lowCount = lowCount + 3;
                    }

                    if (currentSwingLowIndex[i] != lowCount && lastSwingLowIndex[i] != lowCount)
                    {
                        microSwingLow3[i] = microLow[i, lowCount];
                        lowCount = lowCount + 1; ;
                    }
                    else if (lastSwingLowIndex[i] != lowCount + 1)
                    {
                        microSwingLow3[i] = microLow[i, lowCount + 1];
                        lowCount = lowCount + 2;
                    }
                    else
                    {
                        microSwingLow3[i] = microLow[i, lowCount + 2];
                        lowCount = lowCount + 3;
                    }
                    weightMicroSwingLow0[i] = specificWeightMicroSwing0 * (1.0 + 0.001 * i) * timeFrameMultiplier;
                    weightMicroSwingLow1[i] = specificWeightMicroSwing1 * (1.0 + 0.001 * i) * timeFrameMultiplier;
                    weightMicroSwingLow2[i] = specificWeightMicroSwing2 * (1.0 + 0.001 * i) * timeFrameMultiplier;
                    weightMicroSwingLow3[i] = specificWeightMicroSwing3 * (1.0 + 0.001 * i) * timeFrameMultiplier;
                }
                #endregion

                //=========================================================================================================================
                #region -- Section to calculate Retracements from last Swing High and last Swing Low --

                priorRetUp0[i] = retUp0[i];
                priorRetUp23[i] = retUp23[i];
                priorRetUp38[i] = retUp38[i];
                priorRetUp50[i] = retUp50[i];
                priorRetUp62[i] = retUp62[i];
                priorRetUp76[i] = retUp76[i];
                priorRetUp100[i] = retUp100[i];
                priorRetDown0[i] = retDown0[i];
                priorRetDown23[i] = retDown23[i];
                priorRetDown38[i] = retDown38[i];
                priorRetDown50[i] = retDown50[i];
                priorRetDown62[i] = retDown62[i];
                priorRetDown76[i] = retDown76[i];
                priorRetDown100[i] = retDown100[i];

                if (microHigh[i, 0] < double.MaxValue && (addLow || lowUpdate))
                {
                    retUp0[i] = currentLow[i];
                    retUp100[i] = microHigh[i, 0];
                    retUp23[i] = retUp0[i] + 0.236 * (retUp100[i] - retUp0[i]);
                    retUp38[i] = retUp0[i] + 0.382 * (retUp100[i] - retUp0[i]);
                    retUp50[i] = retUp0[i] + 0.50 * (retUp100[i] - retUp0[i]);
                    retUp62[i] = retUp0[i] + 0.618 * (retUp100[i] - retUp0[i]);
                    retUp76[i] = retUp0[i] + 0.764 * (retUp100[i] - retUp0[i]);
                    normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((retUp100[i] - retUp0[i]) / (zigZagFactor * avgTrueRange));
                    weightRetUp23[i] = specificWeightRet23 * normalizedRangeUp;
                    weightRetUp38[i] = specificWeightRet38 * normalizedRangeUp;
                    weightRetUp50[i] = specificWeightRet50 * normalizedRangeUp;
                    weightRetUp62[i] = specificWeightRet62 * normalizedRangeUp;
                    weightRetUp76[i] = specificWeightRet76 * normalizedRangeUp;
                }

                if (microLow[i, 0] > double.MinValue && (addHigh || highUpdate))
                {
                    retDown0[i] = currentHigh[i];
                    retDown100[i] = microLow[i, 0];
                    retDown23[i] = retDown0[i] + 0.236 * (retDown100[i] - retDown0[i]);
                    retDown38[i] = retDown0[i] + 0.382 * (retDown100[i] - retDown0[i]);
                    retDown50[i] = retDown0[i] + 0.50 * (retDown100[i] - retDown0[i]);
                    retDown62[i] = retDown0[i] + 0.618 * (retDown100[i] - retDown0[i]);
                    retDown76[i] = retDown0[i] + 0.764 * (retDown100[i] - retDown0[i]);
                    normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((retDown0[i] - retDown100[i]) / (zigZagFactor * avgTrueRange));
                    weightRetDown23[i] = specificWeightRet23 * normalizedRangeDown;
                    weightRetDown38[i] = specificWeightRet38 * normalizedRangeDown;
                    weightRetDown50[i] = specificWeightRet50 * normalizedRangeDown;
                    weightRetDown62[i] = specificWeightRet62 * normalizedRangeDown;
                    weightRetDown76[i] = specificWeightRet76 * normalizedRangeDown;
                }

                if (addHigh || highUpdate)
                {
                    normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((retUp100[i] - retUp0[i]) / (zigZagFactor * avgTrueRange));
                    if (currentBarClose > retUp38[i])
                        weightRetUp23[i] = devalueRet * specificWeightRet23 * normalizedRangeUp;
                    if (currentBarClose > retUp50[i])
                        weightRetUp38[i] = devalueRet * specificWeightRet38 * normalizedRangeUp;
                    if (currentBarClose > retUp62[i])
                        weightRetUp50[i] = devalueRet * specificWeightRet50 * normalizedRangeUp;
                    if (currentBarClose > retUp76[i])
                        weightRetUp62[i] = devalueRet * specificWeightRet62 * normalizedRangeUp;
                    if (currentBarClose > retUp100[i])
                        weightRetUp76[i] = devalueRet * specificWeightRet76 * normalizedRangeUp;
                }

                if (addLow || lowUpdate)
                {
                    normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((retDown0[i] - retDown100[i]) / (zigZagFactor * avgTrueRange));
                    if (currentBarClose < retDown38[i])
                        weightRetDown23[i] = devalueRet * specificWeightRet23 * normalizedRangeDown;
                    if (currentBarClose < retDown50[i])
                        weightRetDown38[i] = devalueRet * specificWeightRet38 * normalizedRangeDown;
                    if (currentBarClose < retDown62[i])
                        weightRetDown50[i] = devalueRet * specificWeightRet50 * normalizedRangeDown;
                    if (currentBarClose < retDown76[i])
                        weightRetDown62[i] = devalueRet * specificWeightRet62 * normalizedRangeDown;
                    if (currentBarClose < retDown100[i])
                        weightRetDown76[i] = devalueRet * specificWeightRet76 * normalizedRangeDown;
                }
                #endregion 

                //================================================================================================================================
                #region -- Section to calculate External Retracements from MicroHighs and MicroLows --

                priorExtUp0[i] = extUp0[i];
                priorExtUp100[i] = extUp100[i];
                priorExtUp127[i] = extUp127[i];
                priorExtUp162[i] = extUp162[i];
                priorExtUp200[i] = extUp200[i];
                priorExtUp262[i] = extUp262[i];
                priorExtUp300[i] = extUp300[i];
                priorExtUp423[i] = extUp423[i];
                priorExtDown0[i] = extDown0[i];
                priorExtDown100[i] = extDown100[i];
                priorExtDown127[i] = extDown127[i];
                priorExtDown162[i] = extDown162[i];
                priorExtDown200[i] = extDown200[i];
                priorExtDown262[i] = extDown262[i];
                priorExtDown300[i] = extDown300[i];
                priorExtDown423[i] = extDown423[i];

                if (microHigh[i, 0] < double.MaxValue && (addLow || lowUpdate))
                {
                    extUp0[i] = currentLow[i];
                    extUp100[i] = microHigh[i, 0];
                    extUp127[i] = extUp0[i] + 1.272 * (extUp100[i] - extUp0[i]);
                    extUp162[i] = extUp0[i] + 1.618 * (extUp100[i] - extUp0[i]);
                    extUp200[i] = extUp0[i] + 2.0 * (extUp100[i] - extUp0[i]);
                    extUp262[i] = extUp0[i] + 2.618 * (extUp100[i] - extUp0[i]);
                    extUp300[i] = extUp0[i] + 3.0 * (extUp100[i] - extUp0[i]);
                    extUp423[i] = extUp0[i] + 4.236 * (extUp100[i] - extUp0[i]);
                    normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((extUp100[i] - extUp0[i]) / (zigZagFactor * avgTrueRange));
                    weightExtUp127[i] = specificWeightExt127 * normalizedRangeUp;
                    weightExtUp162[i] = specificWeightExt162 * normalizedRangeUp;
                    weightExtUp200[i] = specificWeightExt200 * normalizedRangeUp;
                    weightExtUp262[i] = specificWeightExt262 * normalizedRangeUp;
                    weightExtUp300[i] = specificWeightExt300 * normalizedRangeUp;
                    weightExtUp423[i] = specificWeightExt423 * normalizedRangeUp;
                }

                if (microLow[i, 0] > double.MinValue && (addHigh || highUpdate))
                {
                    extDown0[i] = currentHigh[i];
                    extDown100[i] = microLow[i, 0];
                    extDown127[i] = extDown0[i] + 1.272 * (extDown100[i] - extDown0[i]);
                    extDown162[i] = extDown0[i] + 1.618 * (extDown100[i] - extDown0[i]);
                    extDown200[i] = extDown0[i] + 2.0 * (extDown100[i] - extDown0[i]);
                    extDown262[i] = extDown0[i] + 2.618 * (extDown100[i] - extDown0[i]);
                    extDown300[i] = extDown0[i] + 3.0 * (extDown100[i] - extDown0[i]);
                    extDown423[i] = extDown0[i] + 4.236 * (extDown100[i] - extDown0[i]);
                    normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((extDown0[i] - extDown100[i]) / (zigZagFactor * avgTrueRange));
                    weightExtDown127[i] = specificWeightExt127 * normalizedRangeDown;
                    weightExtDown162[i] = specificWeightExt162 * normalizedRangeDown;
                    weightExtDown200[i] = specificWeightExt200 * normalizedRangeDown;
                    weightExtDown262[i] = specificWeightExt262 * normalizedRangeDown;
                    weightExtDown300[i] = specificWeightExt300 * normalizedRangeDown;
                    weightExtDown423[i] = specificWeightExt423 * normalizedRangeDown;
                }

                if (addHigh || highUpdate)
                {
                    normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((extUp100[i] - extUp0[i]) / (zigZagFactor * avgTrueRange));
                    if (currentBarClose > extUp162[i])
                        weightExtUp127[i] = devalueExt * specificWeightExt127 * normalizedRangeUp;
                    if (currentBarClose > extUp200[i])
                        weightExtUp162[i] = devalueExt * specificWeightExt162 * normalizedRangeUp;
                    if (currentBarClose > extUp262[i])
                        weightExtUp200[i] = devalueExt * specificWeightExt200 * normalizedRangeUp;
                    if (currentBarClose > extUp300[i])
                        weightExtUp262[i] = devalueExt * specificWeightExt262 * normalizedRangeUp;
                    if (currentBarClose > extUp423[i])
                        weightExtUp300[i] = devalueExt * specificWeightExt300 * normalizedRangeUp;
                    if (currentBarClose > extUp0[i] + 5.0 * (extUp100[i] - extUp0[i]))
                        weightExtUp423[i] = devalueExt * specificWeightExt423 * normalizedRangeUp;
                }

                if (addLow || lowUpdate)
                {
                    normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((extDown0[i] - extDown100[i]) / (zigZagFactor * avgTrueRange));
                    if (currentBarClose < extDown162[i])
                        weightExtDown127[i] = devalueExt * specificWeightExt127 * normalizedRangeDown;
                    if (currentBarClose < extDown200[i])
                        weightExtDown162[i] = devalueExt * specificWeightExt162 * normalizedRangeDown;
                    if (currentBarClose < extDown262[i])
                        weightExtDown200[i] = devalueExt * specificWeightExt200 * normalizedRangeDown;
                    if (currentBarClose < extDown300[i])
                        weightExtDown262[i] = devalueExt * specificWeightExt262 * normalizedRangeDown;
                    if (currentBarClose < extDown423[i])
                        weightExtDown300[i] = devalueExt * specificWeightExt300 * normalizedRangeDown;
                    if (currentBarClose < extDown0[i] + 5.0 * (extDown100[i] - extDown0[i]))
                        weightExtDown423[i] = devalueExt * specificWeightExt423 * normalizedRangeDown;
                }
                #endregion

                //=====================================================================================================================
                #region -- Section to calculate Direct Projections --

                priorLastDirUp38[i] = lastDirUp38[i];
                priorLastDirUp62[i] = lastDirUp62[i];
                priorLastDirUp100[i] = lastDirUp100[i];
                priorLastDirDown38[i] = lastDirDown38[i];
                priorLastDirDown62[i] = lastDirDown62[i];
                priorLastDirDown100[i] = lastDirDown100[i];
                priorDirUp38[i] = dirUp38[i];
                priorDirUp62[i] = dirUp62[i];
                priorDirUp100[i] = dirUp100[i];
                priorDirDown38[i] = dirDown38[i];
                priorDirDown62[i] = dirDown62[i];
                priorDirDown100[i] = dirDown100[i];

                if (microHigh[i, 0] < double.MaxValue && microLow[i, 1] > double.MinValue && addLow)
                {
                    lastDirUp38[i] = dirUp38[i];
                    lastDirUp62[i] = dirUp62[i];
                    lastDirUp100[i] = dirUp100[i];
                    if (specificWeightDir38 > 0)
                        weightLastDirUp38[i] = weightDirUp38[i] * specificWeightLastDir38 / specificWeightDir38;
                    else
                        weightLastDirUp38[i] = 0;
                    if (specificWeightDir62 > 0)
                        weightLastDirUp62[i] = weightDirUp62[i] * specificWeightLastDir62 / specificWeightDir62;
                    else
                        weightLastDirUp62[i] = 0;
                    if (specificWeightDir100 > 0)
                        weightLastDirUp100[i] = weightDirUp100[i] * specificWeightLastDir100 / specificWeightDir100;
                    else
                        weightLastDirUp100[i] = 0;

                    dirUp38[i] = microHigh[i, 0] + 0.382 * (microHigh[i, 0] - microLow[i, 1]);
                    dirUp62[i] = microHigh[i, 0] + 0.618 * (microHigh[i, 0] - microLow[i, 1]);
                    dirUp100[i] = 2 * microHigh[i, 0] - microLow[i, 1];

                    normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 0] - microLow[i, 1]) / (zigZagFactor * avgTrueRange));
                    weightDirUp38[i] = specificWeightDir38 * normalizedRangeUp;
                    weightDirUp62[i] = specificWeightDir62 * normalizedRangeUp;
                    weightDirUp100[i] = specificWeightDir100 * normalizedRangeUp;
                }

                if (microHigh[i, 0] < double.MaxValue && microLow[i, 0] > double.MinValue && addHigh)
                {
                    lastDirDown38[i] = dirDown38[i];
                    lastDirDown62[i] = dirDown62[i];
                    lastDirDown100[i] = dirDown100[i];
                    if (specificWeightDir38 > 0)
                        weightLastDirDown38[i] = weightDirDown38[i] * specificWeightLastDir38 / specificWeightDir38;
                    else
                        weightLastDirDown38[i] = 0;
                    if (specificWeightDir62 > 0)
                        weightLastDirDown62[i] = weightDirDown62[i] * specificWeightLastDir62 / specificWeightDir62;
                    else
                        weightLastDirDown62[i] = 0;
                    if (specificWeightDir100 > 0)
                        weightLastDirDown100[i] = weightDirDown100[i] * specificWeightLastDir100 / specificWeightDir100;
                    else
                        weightLastDirDown100[i] = 0;

                    dirDown38[i] = microLow[i, 0] + 0.382 * (microLow[i, 0] - microHigh[i, 0]);
                    dirDown62[i] = microLow[i, 0] + 0.618 * (microLow[i, 0] - microHigh[i, 0]);
                    dirDown100[i] = 2 * microLow[i, 0] - microHigh[i, 0];
                    normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 0] - microLow[i, 0]) / (zigZagFactor * avgTrueRange));
                    weightDirDown38[i] = specificWeightDir38 * normalizedRangeDown;
                    weightDirDown62[i] = specificWeightDir62 * normalizedRangeDown;
                    weightDirDown100[i] = specificWeightDir100 * normalizedRangeDown;
                }

                if (addHigh || highUpdate)
                {
                    if (microHigh[i, 1] < double.MaxValue && microLow[i, 2] > double.MinValue)
                    {
                        normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 1] - microLow[i, 2]) / (zigZagFactor * avgTrueRange));
                        if (currentBarClose > lastDirUp62[i])
                            weightLastDirUp38[i] = devalueDir * specificWeightLastDir38 * normalizedRangeUp;
                        if (currentBarClose > lastDirUp100[i])
                            weightLastDirUp62[i] = devalueDir * specificWeightLastDir62 * normalizedRangeUp;
                        if (currentBarClose > 2 * lastDirUp100[i] - lastDirUp62[i])
                            weightLastDirUp100[i] = devalueDir * specificWeightLastDir100 * normalizedRangeUp;
                    }
                    if (microHigh[i, 0] < double.MaxValue && microLow[i, 1] > double.MinValue)
                    {
                        normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 0] - microLow[i, 1]) / (zigZagFactor * avgTrueRange));
                        if (currentBarClose > dirUp62[i])
                            weightDirUp38[i] = devalueDir * specificWeightDir38 * normalizedRangeUp;
                        if (currentBarClose > dirUp100[i])
                            weightDirUp62[i] = devalueDir * specificWeightDir62 * normalizedRangeUp;
                        if (currentBarClose > 2 * dirUp100[i] - dirUp62[i])
                            weightDirUp100[i] = devalueDir * specificWeightDir100 * normalizedRangeUp;
                    }
                }

                if (addLow || lowUpdate)
                {
                    if (microHigh[i, 2] < double.MaxValue && microLow[i, 2] > double.MinValue)
                    {
                        normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 2] - microLow[i, 2]) / (zigZagFactor * avgTrueRange));
                        if (currentBarClose < lastDirDown62[i])
                            weightLastDirDown38[i] = devalueDir * specificWeightLastDir38 * normalizedRangeDown;
                        if (currentBarClose < lastDirDown100[i])
                            weightLastDirDown62[i] = devalueDir * specificWeightLastDir62 * normalizedRangeDown;
                        if (currentBarClose < 2 * lastDirDown100[i] - lastDirDown62[i])
                            weightLastDirDown100[i] = devalueDir * specificWeightLastDir100 * normalizedRangeDown;
                    }
                    if (microHigh[i, 1] < double.MaxValue && microLow[i, 1] > double.MinValue)
                    {
                        normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt((microHigh[i, 1] - microLow[i, 1]) / (zigZagFactor * avgTrueRange));
                        if (currentBarClose < dirDown62[i])
                            weightDirDown38[i] = devalueDir * specificWeightDir38 * normalizedRangeDown;
                        if (currentBarClose < dirDown100[i])
                            weightDirDown62[i] = devalueDir * specificWeightDir62 * normalizedRangeDown;
                        if (currentBarClose < 2 * dirDown100[i] - dirDown62[i])
                            weightDirDown100[i] = devalueDir * specificWeightDir100 * normalizedRangeDown;
                    }
                }
                #endregion

                //=====================================================================================================================
                #region -- Section to calculate Alternate Projections --

                priorAlt0Up62[i] = alt0Up62[i];
                priorAlt0Up100[i] = alt0Up100[i];
                priorAlt0Up162[i] = alt0Up162[i];
                priorAlt1Up100[i] = alt1Up100[i];
                priorAlt0Down62[i] = alt0Down62[i];
                priorAlt0Down100[i] = alt0Down100[i];
                priorAlt0Down162[i] = alt0Down162[i];
                priorAlt1Down100[i] = alt1Down100[i];

                if (microHigh[i, 1] < double.MaxValue && microLow[i, 2] > double.MinValue && (addLow || lowUpdate))
                {
                    alt0Up[i] = microHigh[i, 0] - microLow[i, 1];
                    alt1Up[i] = microHigh[i, 1] - microLow[i, 2];
                    alt0Up62[i] = currentLow[i] + 0.618 * alt0Up[i];
                    alt0Up100[i] = currentLow[i] + alt0Up[i];
                    alt0Up162[i] = currentLow[i] + 1.618 * alt0Up[i];
                    alt1Up100[i] = currentLow[i] + alt1Up[i];
                    normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt(alt0Up[i] / (zigZagFactor * avgTrueRange));
                    weightAlt0Up62[i] = specificWeightAlt62 * normalizedRangeUp;
                    weightAlt0Up100[i] = specificWeightAlt100 * normalizedRangeUp;
                    weightAlt0Up162[i] = specificWeightAlt162 * normalizedRangeUp;
                    weightAlt1Up100[i] = specificWeightAlt100Prior * (1.0 + 0.001 * i) * Math.Sqrt(alt1Up[i] / (zigZagFactor * avgTrueRange));
                }

                if (microHigh[i, 1] < double.MaxValue && microLow[i, 1] > double.MinValue && (addHigh || highUpdate))
                {
                    alt0Down[i] = microHigh[i, 0] - microLow[i, 0];
                    alt1Down[i] = microHigh[i, 1] - microLow[i, 1];
                    alt0Down62[i] = currentHigh[i] - 0.618 * alt0Down[i];
                    alt0Down100[i] = currentHigh[i] - alt0Down[i];
                    alt0Down162[i] = currentHigh[i] - 1.618 * alt0Down[i];
                    alt1Down100[i] = currentHigh[i] - alt1Down[i];
                    normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt(alt0Down[i] / (zigZagFactor * avgTrueRange));
                    weightAlt0Down62[i] = specificWeightAlt62 * normalizedRangeDown;
                    weightAlt0Down100[i] = specificWeightAlt100 * normalizedRangeDown;
                    weightAlt0Down162[i] = specificWeightAlt162 * normalizedRangeDown;
                    normalizedRangeDown = Math.Sqrt(alt1Down[i] / (zigZagFactor * avgTrueRange));
                    weightAlt1Down100[i] = specificWeightAlt100Prior * (1.0 + 0.001 * i) * Math.Sqrt(alt1Down[i] / (zigZagFactor * avgTrueRange));
                }

                if (addHigh || highUpdate)
                {
                    normalizedRangeUp = (1.0 + 0.001 * i) * Math.Sqrt(alt0Up[i] / (zigZagFactor * avgTrueRange));
                    if (currentBarClose > alt0Up100[i])
                        weightAlt0Up62[i] = devalueAlt * specificWeightAlt62 * normalizedRangeUp;
                    if (currentBarClose > alt0Up162[i])
                        weightAlt0Up100[i] = devalueAlt * specificWeightAlt100 * normalizedRangeUp;
                    if (currentBarClose > alt0Up100[i] + alt0Up[i])
                        weightAlt0Up162[i] = devalueAlt * specificWeightAlt162 * normalizedRangeUp;
                    if (currentBarClose > alt1Up100[i] + 0.62 * alt1Up[i])
                        weightAlt1Up100[i] = devalueAlt * specificWeightAlt100Prior * (1.0 + 0.001 * i) * Math.Sqrt(alt1Up[i] / (zigZagFactor * avgTrueRange));
                }

                if (addLow || lowUpdate)
                {
                    normalizedRangeDown = (1.0 + 0.001 * i) * Math.Sqrt(alt0Down[i] / (zigZagFactor * avgTrueRange));
                    if (currentBarClose < alt0Down100[i])
                        weightAlt0Down62[i] = devalueAlt * specificWeightAlt62 * normalizedRangeDown;
                    if (currentBarClose < alt0Down162[i])
                        weightAlt0Down100[i] = devalueAlt * specificWeightAlt100 * normalizedRangeDown;
                    if (currentBarClose < alt0Down100[i] + alt0Down[i])
                        weightAlt0Down162[i] = devalueAlt * specificWeightAlt162 * normalizedRangeDown;
                    if (currentBarClose < alt1Down100[i] + 0.62 * alt1Down[i])
                        weightAlt1Down100[i] = devalueAlt * specificWeightAlt100Prior * (1.0 + 0.001 * i) * Math.Sqrt(alt1Down[i] / (zigZagFactor * avgTrueRange));
                }
                #endregion 
            }
        }
        #endregion

        //=========================================================================================================================
        // Writing all Fib Lines and Fib Weights to two separate Arrays that can be sorted
        //=========================================================================================================================            
        #region -- SetLinesAndWeights --
        public void SetLinesAndWeights()
        {
            countLine = 0;

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                //=========================================================================================================================
                #region -- Section to set Support and Resistance from previous Swing Highs and Swing Lows (max. 12 Values calculated and displayed) --

                if (microSwingHigh0[i] < double.MaxValue)
                {
                    fibLine[countLine] = microSwingHigh0[i];
                    fibWeight[countLine] = weightMicroSwingHigh0[i];
                    countLine = countLine + 1;
                }
                if (microSwingHigh1[i] < double.MaxValue)
                {
                    fibLine[countLine] = microSwingHigh1[i];
                    fibWeight[countLine] = weightMicroSwingHigh1[i];
                    countLine = countLine + 1;
                }
                if (microSwingHigh2[i] < double.MaxValue)
                {
                    fibLine[countLine] = microSwingHigh2[i];
                    fibWeight[countLine] = weightMicroSwingHigh2[i];
                    countLine = countLine + 1;
                }
                if (microSwingHigh3[i] < double.MaxValue)
                {
                    fibLine[countLine] = microSwingHigh3[i];
                    fibWeight[countLine] = weightMicroSwingHigh3[i];
                    countLine = countLine + 1;
                }
                if (microSwingLow0[i] > double.MinValue)
                {
                    fibLine[countLine] = microSwingLow0[i];
                    fibWeight[countLine] = weightMicroSwingLow0[i];
                    countLine = countLine + 1;
                }
                if (microSwingLow1[i] > double.MinValue)
                {
                    fibLine[countLine] = microSwingLow1[i];
                    fibWeight[countLine] = weightMicroSwingLow1[i];
                    countLine = countLine + 1;
                }
                if (microSwingLow2[i] > double.MinValue)
                {
                    fibLine[countLine] = microSwingLow2[i];
                    fibWeight[countLine] = weightMicroSwingLow2[i];
                    countLine = countLine + 1;
                }
                if (microSwingLow3[i] > double.MinValue)
                {
                    fibLine[countLine] = microSwingLow3[i];
                    fibWeight[countLine] = weightMicroSwingLow3[i];
                    countLine = countLine + 1;
                }
                if (existsSwingHigh[i])
                {
                    fibLine[countLine] = currentSwingHigh[i];
                    fibWeight[countLine] = weightCurrentSwingHigh[i];
                    countLine = countLine + 1;
                    if (lastSwingHigh[i] < double.MaxValue)
                    {
                        fibLine[countLine] = lastSwingHigh[i];
                        fibWeight[countLine] = weightLastSwingHigh[i];
                        countLine = countLine + 1;
                    }
                }
                if (existsSwingLow[i])
                {
                    fibLine[countLine] = currentSwingLow[i];
                    fibWeight[countLine] = weightCurrentSwingLow[i];
                    countLine = countLine + 1;
                    if (lastSwingLow[i] > double.MinValue)
                    {
                        fibLine[countLine] = lastSwingLow[i];
                        fibWeight[countLine] = weightLastSwingLow[i];
                        countLine = countLine + 1;
                    }
                }
                #endregion 

                //=========================================================================================================================
                #region -- Section to set Retracements from last Swing High and last Swing Low (max. 8 Values calculated and displayed) --

                fibLine[countLine] = retUp23[i];
                fibWeight[countLine] = weightRetUp23[i];
                countLine = countLine + 1;

                fibLine[countLine] = retUp38[i];
                fibWeight[countLine] = weightRetUp38[i];
                countLine = countLine + 1;

                fibLine[countLine] = retUp50[i];
                fibWeight[countLine] = weightRetUp50[i];
                countLine = countLine + 1;

                fibLine[countLine] = retUp62[i];
                fibWeight[countLine] = weightRetUp62[i];
                countLine = countLine + 1;

                fibLine[countLine] = retUp76[i];
                fibWeight[countLine] = weightRetUp76[i];
                countLine = countLine + 1;

                fibLine[countLine] = retDown23[i];
                fibWeight[countLine] = weightRetDown23[i];
                countLine = countLine + 1;

                fibLine[countLine] = retDown38[i];
                fibWeight[countLine] = weightRetDown38[i];
                countLine = countLine + 1;

                fibLine[countLine] = retDown50[i];
                fibWeight[countLine] = weightRetDown50[i];
                countLine = countLine + 1;

                fibLine[countLine] = retDown62[i];
                fibWeight[countLine] = weightRetDown62[i];
                countLine = countLine + 1;

                fibLine[countLine] = retDown76[i];
                fibWeight[countLine] = weightRetDown76[i];
                countLine = countLine + 1;
                #endregion

                //===========================================================================================================================
                #region -- Section to set External Retracements from MicroHighs and MicroLows (max. 12 Values calculated and displayed) --

                fibLine[countLine] = extUp127[i];
                fibWeight[countLine] = weightExtUp127[i];
                countLine = countLine + 1;

                fibLine[countLine] = extUp162[i];
                fibWeight[countLine] = weightExtUp162[i];
                countLine = countLine + 1;

                fibLine[countLine] = extUp200[i];
                fibWeight[countLine] = weightExtUp200[i];
                countLine = countLine + 1;

                fibLine[countLine] = extUp262[i];
                fibWeight[countLine] = weightExtUp262[i];
                countLine = countLine + 1;

                fibLine[countLine] = extUp300[i];
                fibWeight[countLine] = weightExtUp300[i];
                countLine = countLine + 1;

                fibLine[countLine] = extUp423[i];
                fibWeight[countLine] = weightExtUp423[i];
                countLine = countLine + 1;

                fibLine[countLine] = extDown127[i];
                fibWeight[countLine] = weightExtDown127[i];
                countLine = countLine + 1;

                fibLine[countLine] = extDown162[i];
                fibWeight[countLine] = weightExtDown162[i];
                countLine = countLine + 1;

                fibLine[countLine] = extDown200[i];
                fibWeight[countLine] = weightExtDown200[i];
                countLine = countLine + 1;

                fibLine[countLine] = extDown262[i];
                fibWeight[countLine] = weightExtDown262[i];
                countLine = countLine + 1;

                fibLine[countLine] = extDown300[i];
                fibWeight[countLine] = weightExtDown300[i];
                countLine = countLine + 1;

                fibLine[countLine] = extDown423[i];
                fibWeight[countLine] = weightExtDown423[i];
                countLine = countLine + 1;
                #endregion

                //==============================================================================================================================
                #region -- Section to calculate Direct Projections (max. 12 Values calculated and displayed) --

                fibLine[countLine] = dirUp38[i];
                fibWeight[countLine] = weightDirUp38[i];
                countLine = countLine + 1;

                fibLine[countLine] = dirUp62[i];
                fibWeight[countLine] = weightDirUp62[i];
                countLine = countLine + 1;

                fibLine[countLine] = dirUp100[i];
                fibWeight[countLine] = weightDirUp100[i];
                countLine = countLine + 1;

                fibLine[countLine] = dirDown38[i];
                fibWeight[countLine] = weightDirDown38[i];
                countLine = countLine + 1;

                fibLine[countLine] = dirDown62[i];
                fibWeight[countLine] = weightDirDown62[i];
                countLine = countLine + 1;

                fibLine[countLine] = dirDown100[i];
                fibWeight[countLine] = weightDirDown100[i];
                countLine = countLine + 1;

                fibLine[countLine] = lastDirUp38[i];
                fibWeight[countLine] = weightLastDirUp38[i];
                countLine = countLine + 1;

                fibLine[countLine] = lastDirUp62[i];
                fibWeight[countLine] = weightLastDirUp62[i];
                countLine = countLine + 1;

                fibLine[countLine] = lastDirUp100[i];
                fibWeight[countLine] = weightLastDirUp100[i];
                countLine = countLine + 1;

                fibLine[countLine] = lastDirDown38[i];
                fibWeight[countLine] = weightLastDirDown38[i];
                countLine = countLine + 1;

                fibLine[countLine] = lastDirDown62[i];
                fibWeight[countLine] = weightLastDirDown62[i];
                countLine = countLine + 1;

                fibLine[countLine] = lastDirDown100[i];
                fibWeight[countLine] = weightLastDirDown100[i];
                countLine = countLine + 1;
                #endregion

                //==============================================================================================================================
                #region -- Section to calculate Alternate Projections (max. 8 Values calculated and displayed) --

                if (alt0Up[i] > 1.272 * alt1Up[i])
                {
                    fibLine[countLine] = alt0Up62[i];
                    fibWeight[countLine] = weightAlt0Up62[i];
                    countLine = countLine + 1;
                }
                fibLine[countLine] = alt0Up100[i];
                fibWeight[countLine] = weightAlt0Up100[i];
                countLine = countLine + 1;

                fibLine[countLine] = alt0Up162[i];
                fibWeight[countLine] = weightAlt0Up162[i];
                countLine = countLine + 1;

                fibLine[countLine] = alt1Up100[i];
                fibWeight[countLine] = weightAlt1Up100[i];
                countLine = countLine + 1;

                if (alt0Down[i] > 1.272 * alt1Down[i])
                {
                    fibLine[countLine] = alt0Down62[i];
                    fibWeight[countLine] = weightAlt0Down62[i];
                    countLine = countLine + 1;
                }

                fibLine[countLine] = alt0Down100[i];
                fibWeight[countLine] = weightAlt0Down100[i];
                countLine = countLine + 1;

                fibLine[countLine] = alt0Down162[i];
                fibWeight[countLine] = weightAlt0Down162[i];
                countLine = countLine + 1;

                fibLine[countLine] = alt1Down100[i];
                fibWeight[countLine] = weightAlt1Down100[i];
                countLine = countLine + 1;
                #endregion
            }

            //==============================================================================================================================
            // Select all Resistance and Support Lines within the Display Range and Determine Compounded Weight of Each Line
            //==============================================================================================================================			
            initialWeight = 0;
            compoundedWeight = 0;
            highestWeight = 0;

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {

                #region -- swings --
                dummy = cumulatedWeightMicroSwingHigh0[i];
                cumulatedWeightMicroSwingHigh0[i] = 0;
                if (microSwingHigh0[i] >= lowerLimitSupport && microSwingHigh0[i] <= upperLimitResistance)
                {
                    initialWeight = weightMicroSwingHigh0[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(microSwingHigh0[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorMicroSwingHigh0[i] == microSwingHigh0[i])
                            cumulatedWeightMicroSwingHigh0[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightMicroSwingHigh0[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightMicroSwingHigh1[i];
                cumulatedWeightMicroSwingHigh1[i] = 0;
                if (microSwingHigh1[i] >= lowerLimitSupport && microSwingHigh1[i] <= upperLimitResistance)
                {
                    initialWeight = weightMicroSwingHigh1[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(microSwingHigh1[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorMicroSwingHigh1[i] == microSwingHigh1[i])
                            cumulatedWeightMicroSwingHigh1[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightMicroSwingHigh1[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightMicroSwingHigh2[i];
                cumulatedWeightMicroSwingHigh2[i] = 0;
                if (microSwingHigh2[i] >= lowerLimitSupport && microSwingHigh2[i] <= upperLimitResistance)
                {
                    initialWeight = weightMicroSwingHigh2[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(microSwingHigh2[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorMicroSwingHigh2[i] == microSwingHigh2[i])
                            cumulatedWeightMicroSwingHigh2[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightMicroSwingHigh2[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightMicroSwingHigh3[i];
                cumulatedWeightMicroSwingHigh3[i] = 0;
                if (microSwingHigh3[i] >= lowerLimitSupport && microSwingHigh3[i] <= upperLimitResistance)
                {
                    initialWeight = weightMicroSwingHigh3[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(microSwingHigh3[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorMicroSwingHigh3[i] == microSwingHigh3[i])
                            cumulatedWeightMicroSwingHigh3[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightMicroSwingHigh3[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightMicroSwingLow0[i];
                cumulatedWeightMicroSwingLow0[i] = 0;
                if (microSwingLow0[i] >= lowerLimitSupport && microSwingLow0[i] <= upperLimitResistance)
                {
                    initialWeight = weightMicroSwingLow0[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(microSwingLow0[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorMicroSwingLow0[i] == microSwingLow0[i])
                            cumulatedWeightMicroSwingLow0[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightMicroSwingLow0[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightMicroSwingLow1[i];
                cumulatedWeightMicroSwingLow1[i] = 0;
                if (microSwingLow1[i] >= lowerLimitSupport && microSwingLow1[i] <= upperLimitResistance)
                {
                    initialWeight = weightMicroSwingLow1[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(microSwingLow1[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorMicroSwingLow1[i] == microSwingLow1[i])
                            cumulatedWeightMicroSwingLow1[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightMicroSwingLow1[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightMicroSwingLow2[i];
                cumulatedWeightMicroSwingLow2[i] = 0;
                if (microSwingLow2[i] >= lowerLimitSupport && microSwingLow2[i] <= upperLimitResistance)
                {
                    initialWeight = weightMicroSwingLow2[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(microSwingLow2[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorMicroSwingLow2[i] == microSwingLow2[i])
                            cumulatedWeightMicroSwingLow2[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightMicroSwingLow2[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightMicroSwingLow3[i];
                cumulatedWeightMicroSwingLow3[i] = 0;
                if (microSwingLow3[i] >= lowerLimitSupport && microSwingLow3[i] <= upperLimitResistance)
                {
                    initialWeight = weightMicroSwingLow3[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(microSwingLow3[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorMicroSwingLow3[i] == microSwingLow3[i])
                            cumulatedWeightMicroSwingLow3[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightMicroSwingLow3[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightCurrentSwingHigh[i];
                cumulatedWeightCurrentSwingHigh[i] = 0;
                if (currentSwingHigh[i] >= lowerLimitSupport && currentSwingHigh[i] <= upperLimitResistance)
                {
                    initialWeight = weightCurrentSwingHigh[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(currentSwingHigh[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorCurrentSwingHigh[i] == currentSwingHigh[i])
                            cumulatedWeightCurrentSwingHigh[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightCurrentSwingHigh[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightLastSwingHigh[i];
                cumulatedWeightLastSwingHigh[i] = 0;
                if (lastSwingHigh[i] >= lowerLimitSupport && lastSwingHigh[i] <= upperLimitResistance)
                {
                    initialWeight = weightLastSwingHigh[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(lastSwingHigh[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorLastSwingHigh[i] == lastSwingHigh[i])
                            cumulatedWeightLastSwingHigh[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightLastSwingHigh[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightCurrentSwingLow[i];
                cumulatedWeightCurrentSwingLow[i] = 0;
                if (currentSwingLow[i] >= lowerLimitSupport && currentSwingLow[i] <= upperLimitResistance)
                {
                    initialWeight = weightCurrentSwingLow[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(currentSwingLow[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorCurrentSwingLow[i] == currentSwingLow[i])
                            cumulatedWeightCurrentSwingLow[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightCurrentSwingLow[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightLastSwingLow[i];
                cumulatedWeightLastSwingLow[i] = 0;
                if (lastSwingLow[i] >= lowerLimitSupport && lastSwingLow[i] <= upperLimitResistance)
                {
                    initialWeight = weightLastSwingLow[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(lastSwingLow[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorLastSwingLow[i] == lastSwingLow[i])
                            cumulatedWeightLastSwingLow[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightLastSwingLow[i] = 0.5 * compoundedWeight;
                    }
                }
                #endregion

                #region -- Ret --
                dummy = cumulatedWeightRetUp23[i];
                cumulatedWeightRetUp23[i] = 0;
                if (retUp23[i] >= lowerLimitSupport && retUp23[i] <= upperLimitResistance)
                {
                    initialWeight = weightRetUp23[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(retUp23[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorRetUp23[i] == retUp23[i])
                            cumulatedWeightRetUp23[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightRetUp23[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightRetUp38[i];
                cumulatedWeightRetUp38[i] = 0;
                if (retUp38[i] >= lowerLimitSupport && retUp38[i] <= upperLimitResistance)
                {
                    initialWeight = weightRetUp38[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(retUp38[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorRetUp38[i] == retUp38[i])
                            cumulatedWeightRetUp38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightRetUp38[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightRetUp50[i];
                cumulatedWeightRetUp50[i] = 0;
                if (retUp50[i] >= lowerLimitSupport && retUp50[i] <= upperLimitResistance)
                {
                    initialWeight = weightRetUp50[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(retUp50[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorRetUp50[i] == retUp50[i])
                            cumulatedWeightRetUp50[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightRetUp50[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightRetUp62[i];
                cumulatedWeightRetUp62[i] = 0;
                if (retUp62[i] >= lowerLimitSupport && retUp62[i] <= upperLimitResistance)
                {
                    initialWeight = weightRetUp62[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(retUp62[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorRetUp62[i] == retUp62[i])
                            cumulatedWeightRetUp62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightRetUp62[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightRetUp76[i];
                cumulatedWeightRetUp76[i] = 0;
                if (retUp76[i] >= lowerLimitSupport && retUp76[i] <= upperLimitResistance)
                {
                    initialWeight = weightRetUp76[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(retUp76[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorRetUp76[i] == retUp76[i])
                            cumulatedWeightRetUp76[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightRetUp76[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightRetDown23[i];
                cumulatedWeightRetDown23[i] = 0;
                if (retDown23[i] >= lowerLimitSupport && retDown23[i] <= upperLimitResistance)
                {
                    initialWeight = weightRetDown23[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(retDown23[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorRetDown23[i] == retDown23[i])
                            cumulatedWeightRetDown23[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightRetDown23[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightRetDown38[i];
                cumulatedWeightRetDown38[i] = 0;
                if (retDown38[i] >= lowerLimitSupport && retDown38[i] <= upperLimitResistance)
                {
                    initialWeight = weightRetDown38[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(retDown38[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorRetDown38[i] == retDown38[i])
                            cumulatedWeightRetDown38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightRetDown38[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightRetDown50[i];
                cumulatedWeightRetDown50[i] = 0;
                if (retDown50[i] >= lowerLimitSupport && retDown50[i] <= upperLimitResistance)
                {
                    initialWeight = weightRetDown50[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(retDown50[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorRetDown50[i] == retDown50[i])
                            cumulatedWeightRetDown50[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightRetDown50[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightRetDown62[i];
                cumulatedWeightRetDown62[i] = 0;
                if (retDown62[i] >= lowerLimitSupport && retDown62[i] <= upperLimitResistance)
                {
                    initialWeight = weightRetDown62[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(retDown62[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorRetDown62[i] == retDown62[i])
                            cumulatedWeightRetDown62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightRetDown62[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightRetDown76[i];
                cumulatedWeightRetDown76[i] = 0;
                if (retDown76[i] >= lowerLimitSupport && retDown76[i] <= upperLimitResistance)
                {
                    initialWeight = weightRetDown76[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(retDown76[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorRetDown76[i] == retDown76[i])
                            cumulatedWeightRetDown76[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightRetDown76[i] = 0.5 * compoundedWeight;
                    }
                }
                #endregion

                #region -- Ext --
                dummy = cumulatedWeightExtUp127[i];
                cumulatedWeightExtUp127[i] = 0;
                if (extUp127[i] >= lowerLimitSupport && extUp127[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtUp127[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extUp127[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtUp127[i] == extUp127[i])
                            cumulatedWeightExtUp127[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtUp127[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtUp162[i];
                cumulatedWeightExtUp162[i] = 0;
                if (extUp162[i] >= lowerLimitSupport && extUp162[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtUp162[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extUp162[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight <= initialWeight)
                    {
                        if (priorExtUp162[i] == extUp162[i])
                            cumulatedWeightExtUp162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtUp162[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtUp200[i];
                cumulatedWeightExtUp200[i] = 0;
                if (extUp200[i] >= lowerLimitSupport && extUp200[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtUp200[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extUp200[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtUp200[i] == extUp200[i])
                            cumulatedWeightExtUp200[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtUp200[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtUp262[i];
                cumulatedWeightExtUp262[i] = 0;
                if (extUp262[i] >= lowerLimitSupport && extUp262[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtUp262[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extUp262[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtUp262[i] == extUp262[i])
                            cumulatedWeightExtUp262[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtUp262[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtUp300[i];
                cumulatedWeightExtUp300[i] = 0;
                if (extUp300[i] >= lowerLimitSupport && extUp300[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtUp300[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extUp300[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtUp300[i] == extUp300[i])
                            cumulatedWeightExtUp300[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtUp300[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtUp423[i];
                cumulatedWeightExtUp423[i] = 0;
                if (extUp423[i] >= lowerLimitSupport && extUp423[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtUp423[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extUp423[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtUp423[i] == extUp423[i])
                            cumulatedWeightExtUp423[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtUp423[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtDown127[i];
                cumulatedWeightExtDown127[i] = 0;
                if (extDown127[i] >= lowerLimitSupport && extDown127[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtDown127[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extDown127[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtDown127[i] == extDown127[i])
                            cumulatedWeightExtDown127[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtDown127[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtDown162[i];
                cumulatedWeightExtDown162[i] = 0;
                if (extDown162[i] >= lowerLimitSupport && extDown162[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtDown162[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extDown162[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtDown162[i] == extDown162[i])
                            cumulatedWeightExtDown162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtDown162[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtDown200[i];
                cumulatedWeightExtDown200[i] = 0;
                if (extDown200[i] >= lowerLimitSupport && extDown200[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtDown200[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extDown200[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtDown200[i] == extDown200[i])
                            cumulatedWeightExtDown200[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtDown200[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtDown262[i];
                cumulatedWeightExtDown262[i] = 0;
                if (extDown262[i] >= lowerLimitSupport && extDown262[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtDown262[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extDown262[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtDown262[i] == extDown262[i])
                            cumulatedWeightExtDown262[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtDown262[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtDown300[i];
                cumulatedWeightExtDown300[i] = 0;
                if (extDown300[i] >= lowerLimitSupport && extDown300[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtDown300[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extDown300[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtDown300[i] == extDown300[i])
                            cumulatedWeightExtDown300[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtDown300[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightExtDown423[i];
                cumulatedWeightExtDown423[i] = 0;
                if (extDown423[i] >= lowerLimitSupport && extDown423[i] <= upperLimitResistance)
                {
                    initialWeight = weightExtDown423[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(extDown423[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorExtDown423[i] == extDown423[i])
                            cumulatedWeightExtDown423[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightExtDown423[i] = 0.5 * compoundedWeight;
                    }
                }
                #endregion

                #region -- Dir and LastDir --
                dummy = cumulatedWeightDirUp38[i];
                cumulatedWeightDirUp38[i] = 0;
                if (dirUp38[i] >= lowerLimitSupport && dirUp38[i] <= upperLimitResistance)
                {
                    initialWeight = weightDirUp38[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(dirUp38[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorDirUp38[i] == dirUp38[i])
                            cumulatedWeightDirUp38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightDirUp38[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightDirUp62[i];
                cumulatedWeightDirUp62[i] = 0;
                if (dirUp62[i] >= lowerLimitSupport && dirUp62[i] <= upperLimitResistance)
                {
                    initialWeight = weightDirUp62[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(dirUp62[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorDirUp62[i] == dirUp62[i])
                            cumulatedWeightDirUp62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightDirUp62[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightDirUp100[i];
                cumulatedWeightDirUp100[i] = 0;
                if (dirUp100[i] >= lowerLimitSupport && dirUp100[i] <= upperLimitResistance)
                {
                    initialWeight = weightDirUp100[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(dirUp100[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorDirUp100[i] == dirUp100[i])
                            cumulatedWeightDirUp100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightDirUp100[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightDirDown38[i];
                cumulatedWeightDirDown38[i] = 0;
                if (dirDown38[i] >= lowerLimitSupport && dirDown38[i] <= upperLimitResistance)
                {
                    initialWeight = weightDirDown38[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(dirDown38[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorDirDown38[i] == dirDown38[i])
                            cumulatedWeightDirDown38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightDirDown38[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightDirDown62[i];
                cumulatedWeightDirDown62[i] = 0;
                if (dirDown62[i] >= lowerLimitSupport && dirDown62[i] <= upperLimitResistance)
                {
                    initialWeight = weightDirDown62[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(dirDown62[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorDirDown62[i] == dirDown62[i])
                            cumulatedWeightDirDown62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightDirDown62[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightDirDown100[i];
                cumulatedWeightDirDown100[i] = 0;
                if (dirDown100[i] >= lowerLimitSupport && dirDown100[i] <= upperLimitResistance)
                {
                    initialWeight = weightDirDown100[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(dirDown100[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorDirDown100[i] == dirDown100[i])
                            cumulatedWeightDirDown100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightDirDown100[i] = 0.5 * compoundedWeight;
                    }
                }

                dummy = cumulatedWeightLastDirUp38[i];
                cumulatedWeightLastDirUp38[i] = 0;
                if (lastDirUp38[i] >= lowerLimitSupport && lastDirUp38[i] <= upperLimitResistance)
                {
                    initialWeight = weightLastDirUp38[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(lastDirUp38[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorLastDirUp38[i] == lastDirUp38[i])
                            cumulatedWeightLastDirUp38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightLastDirUp38[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightLastDirUp62[i];
                cumulatedWeightLastDirUp62[i] = 0;
                if (lastDirUp62[i] >= lowerLimitSupport && lastDirUp62[i] <= upperLimitResistance)
                {
                    initialWeight = weightLastDirUp62[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(lastDirUp62[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorLastDirUp62[i] == lastDirUp62[i])
                            cumulatedWeightLastDirUp62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightLastDirUp62[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightLastDirUp100[i];
                cumulatedWeightLastDirUp100[i] = 0;
                if (lastDirUp100[i] >= lowerLimitSupport && lastDirUp100[i] <= upperLimitResistance)
                {
                    initialWeight = weightLastDirUp100[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(lastDirUp100[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorLastDirUp100[i] == lastDirUp100[i])
                            cumulatedWeightLastDirUp100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightLastDirUp100[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightLastDirDown38[i];
                cumulatedWeightLastDirDown38[i] = 0;
                if (lastDirDown38[i] >= lowerLimitSupport && lastDirDown38[i] <= upperLimitResistance)
                {
                    initialWeight = weightLastDirDown38[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(lastDirDown38[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorLastDirDown38[i] == lastDirDown38[i])
                            cumulatedWeightLastDirDown38[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightLastDirDown38[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightLastDirDown62[i];
                cumulatedWeightLastDirDown62[i] = 0;
                if (lastDirDown62[i] >= lowerLimitSupport && lastDirDown62[i] <= upperLimitResistance)
                {
                    initialWeight = weightLastDirDown62[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(lastDirDown62[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorLastDirDown62[i] == lastDirDown62[i])
                            cumulatedWeightLastDirDown62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightLastDirDown62[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightLastDirDown100[i];
                cumulatedWeightLastDirDown100[i] = 0;
                if (lastDirDown100[i] >= lowerLimitSupport && lastDirDown100[i] <= upperLimitResistance)
                {
                    initialWeight = weightLastDirDown100[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(lastDirDown100[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorLastDirDown100[i] == lastDirDown100[i])
                            cumulatedWeightLastDirDown100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightLastDirDown100[i] = 0.5 * compoundedWeight;
                    }
                }
                #endregion

                #region -- Alt --
                dummy = cumulatedWeightAlt0Up62[i];
                cumulatedWeightAlt0Up62[i] = 0;
                if (alt0Up62[i] >= lowerLimitSupport && alt0Up62[i] <= upperLimitResistance && alt0Up[i] > 1.272 * alt1Up[i])
                {
                    initialWeight = weightAlt0Up62[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(alt0Up62[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorAlt0Up62[i] == alt0Up62[i])
                            cumulatedWeightAlt0Up62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightAlt0Up62[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightAlt0Up100[i];
                cumulatedWeightAlt0Up100[i] = 0;
                if (alt0Up100[i] >= lowerLimitSupport && alt0Up100[i] <= upperLimitResistance)
                {
                    initialWeight = weightAlt0Up100[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(alt0Up100[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorAlt0Up100[i] == alt0Up100[i])
                            cumulatedWeightAlt0Up100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightAlt0Up100[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightAlt0Up162[i];
                cumulatedWeightAlt0Up162[i] = 0;
                if (alt0Up162[i] >= lowerLimitSupport && alt0Up162[i] <= upperLimitResistance)
                {
                    initialWeight = weightAlt0Up162[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(alt0Up162[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorAlt0Up162[i] == alt0Up162[i])
                            cumulatedWeightAlt0Up162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightAlt0Up162[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightAlt1Up100[i];
                cumulatedWeightAlt1Up100[i] = 0;
                if (alt1Up100[i] >= lowerLimitSupport && alt1Up100[i] <= upperLimitResistance)
                {
                    initialWeight = weightAlt1Up100[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(alt1Up100[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorAlt1Up100[i] == alt1Up100[i])
                            cumulatedWeightAlt1Up100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightAlt1Up100[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightAlt0Down62[i];
                cumulatedWeightAlt0Down62[i] = 0;
                if (alt0Down62[i] >= lowerLimitSupport && alt0Down62[i] <= upperLimitResistance && alt0Down[i] > 1.272 * alt1Down[i])
                {
                    initialWeight = weightAlt0Down62[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(alt0Down62[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorAlt0Down62[i] == alt0Down62[i])
                            cumulatedWeightAlt0Down62[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightAlt0Down62[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightAlt0Down100[i];
                cumulatedWeightAlt0Down100[i] = 0;
                if (alt0Down100[i] >= lowerLimitSupport && alt0Down100[i] <= upperLimitResistance)
                {
                    initialWeight = weightAlt0Down100[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(alt0Down100[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorAlt0Down100[i] == alt0Down100[i])
                            cumulatedWeightAlt0Down100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightAlt0Down100[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightAlt0Down162[i];
                cumulatedWeightAlt0Down162[i] = 0;
                if (alt0Down162[i] >= lowerLimitSupport && alt0Down162[i] <= upperLimitResistance)
                {
                    initialWeight = weightAlt0Down162[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(alt0Down162[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorAlt0Down162[i] == alt0Down162[i])
                            cumulatedWeightAlt0Down162[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightAlt0Down162[i] = 0.5 * compoundedWeight;
                    }
                }
                dummy = cumulatedWeightAlt1Down100[i];
                cumulatedWeightAlt1Down100[i] = 0;
                if (alt1Down100[i] >= lowerLimitSupport && alt1Down100[i] <= upperLimitResistance)
                {
                    initialWeight = weightAlt1Down100[i];
                    compoundedWeight = 0;
                    highestWeight = initialWeight;
                    for (int j = 0; j < countLine; j++)
                    {
                        if (Math.Abs(alt1Down100[i] - fibLine[j]) <= confluenceRangeWidth)
                        {
                            compoundedWeight = compoundedWeight + fibWeight[j] + initialWeight;
                            highestWeight = Math.Max(highestWeight, fibWeight[j]);
                        }
                    }
                    if (highestWeight < initialWeight + 0.00001)
                    {
                        if (priorAlt1Down100[i] == alt1Down100[i])
                            cumulatedWeightAlt1Down100[i] = Math.Max(0.95 * dummy, 0.5 * compoundedWeight);
                        else
                            cumulatedWeightAlt1Down100[i] = 0.5 * compoundedWeight;
                    }
                }
                #endregion

            }
        }
        #endregion

        //==============================================================================================================================
        // Prepare Lines for Display Range if Compounded Weight is Above Multiple of Threshold
        //==============================================================================================================================	
        #region -- SelectLines --
        public void SelectLines()
        {
            countResistance = 0;
            for (int i = 0; i < 540; i++) fibResistance[i] = 0;
            countSupport = 0;
            for (int i = 0; i < 540; i++) fibSupport[i] = 0;
            countWeakResistance = 0;
            for (int i = 0; i < 540; i++) weakResistance[i] = 0;
            countWeakSupport = 0;
            for (int i = 0; i < 540; i++) weakSupport[i] = 0;

            #region -- swings --
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightMicroSwingHigh0[i] > Threshold)
                    if (microSwingHigh0[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightMicroSwingHigh0[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = microSwingHigh0[i];
                            countResistance = countResistance + 1;
                        }
                        else if (microSwingHigh0[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = microSwingHigh0[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (microSwingHigh0[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightMicroSwingHigh0[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = microSwingHigh0[i];
                            countSupport = countSupport + 1;
                        }
                        else if (microSwingHigh0[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = microSwingHigh0[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightMicroSwingHigh1[i] > Threshold)
                    if (microSwingHigh1[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightMicroSwingHigh1[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = microSwingHigh1[i];
                            countResistance = countResistance + 1;
                        }
                        else if (microSwingHigh1[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = microSwingHigh1[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (microSwingHigh1[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightMicroSwingHigh1[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = microSwingHigh1[i];
                            countSupport = countSupport + 1;
                        }
                        else if (microSwingHigh1[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = microSwingHigh1[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightMicroSwingHigh2[i] > Threshold)
                    if (microSwingHigh2[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightMicroSwingHigh2[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = microSwingHigh2[i];
                            countResistance = countResistance + 1;
                        }
                        else if (microSwingHigh2[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = microSwingHigh2[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (microSwingHigh2[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightMicroSwingHigh2[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = microSwingHigh2[i];
                            countSupport = countSupport + 1;
                        }
                        else if (microSwingHigh2[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = microSwingHigh2[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightMicroSwingHigh3[i] > Threshold)
                    if (microSwingHigh3[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightMicroSwingHigh3[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = microSwingHigh3[i];
                            countResistance = countResistance + 1;
                        }
                        else if (microSwingHigh3[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = microSwingHigh3[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (microSwingHigh3[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightMicroSwingHigh3[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = microSwingHigh3[i];
                            countSupport = countSupport + 1;
                        }
                        else if (microSwingHigh3[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = microSwingHigh3[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightMicroSwingLow0[i] > Threshold)
                    if (microSwingLow0[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightMicroSwingLow0[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = microSwingLow0[i];
                            countResistance = countResistance + 1;
                        }
                        else if (microSwingLow0[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = microSwingLow0[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (microSwingLow0[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightMicroSwingLow0[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = microSwingLow0[i];
                            countSupport = countSupport + 1;
                        }
                        else if (microSwingLow0[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = microSwingLow0[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightMicroSwingLow1[i] > Threshold)
                    if (microSwingLow1[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightMicroSwingLow1[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = microSwingLow1[i];
                            countResistance = countResistance + 1;
                        }
                        else if (microSwingLow1[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = microSwingLow1[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (microSwingLow1[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightMicroSwingLow1[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = microSwingLow1[i];
                            countSupport = countSupport + 1;
                        }
                        else if (microSwingLow1[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = microSwingLow1[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightMicroSwingLow2[i] > Threshold)
                    if (microSwingLow2[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightMicroSwingLow2[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = microSwingLow2[i];
                            countResistance = countResistance + 1;
                        }
                        else if (microSwingLow2[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = microSwingLow2[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (microSwingLow2[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightMicroSwingLow2[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = microSwingLow2[i];
                            countSupport = countSupport + 1;
                        }
                        else if (microSwingLow2[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = microSwingLow2[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightMicroSwingLow3[i] > Threshold)
                    if (microSwingLow3[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightMicroSwingLow3[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = microSwingLow3[i];
                            countResistance = countResistance + 1;
                        }
                        else if (microSwingLow3[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = microSwingLow3[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (microSwingLow3[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightMicroSwingLow3[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = microSwingLow3[i];
                            countSupport = countSupport + 1;
                        }
                        else if (microSwingLow3[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = microSwingLow3[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightCurrentSwingHigh[i] > Threshold)
                    if (currentSwingHigh[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightCurrentSwingHigh[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = currentSwingHigh[i];
                            countResistance = countResistance + 1;
                        }
                        else if (currentSwingHigh[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = currentSwingHigh[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (currentSwingHigh[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightCurrentSwingHigh[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = currentSwingHigh[i];
                            countSupport = countSupport + 1;
                        }
                        else if (currentSwingHigh[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = currentSwingHigh[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightLastSwingHigh[i] > Threshold)
                    if (lastSwingHigh[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightLastSwingHigh[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = lastSwingHigh[i];
                            countResistance = countResistance + 1;
                        }
                        else if (lastSwingHigh[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = lastSwingHigh[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (lastSwingHigh[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightLastSwingHigh[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = lastSwingHigh[i];
                            countSupport = countSupport + 1;
                        }
                        else if (lastSwingHigh[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = lastSwingHigh[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightCurrentSwingLow[i] > Threshold)
                    if (currentSwingLow[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightCurrentSwingLow[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = currentSwingLow[i];
                            countResistance = countResistance + 1;
                        }
                        else if (currentSwingLow[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = currentSwingLow[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (currentSwingLow[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightCurrentSwingLow[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = currentSwingLow[i];
                            countSupport = countSupport + 1;
                        }
                        else if (currentSwingLow[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = currentSwingLow[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightLastSwingLow[i] > Threshold)
                    if (lastSwingLow[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightLastSwingLow[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = lastSwingLow[i];
                            countResistance = countResistance + 1;
                        }
                        else if (lastSwingLow[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = lastSwingLow[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (lastSwingLow[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightLastSwingLow[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = lastSwingLow[i];
                            countSupport = countSupport + 1;
                        }
                        else if (lastSwingLow[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = lastSwingLow[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }
            #endregion

            #region -- Ret --
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightRetUp23[i] > Threshold)
                    if (retUp23[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightRetUp23[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = retUp23[i];
                            countResistance = countResistance + 1;
                        }
                        else if (retUp23[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = retUp23[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (retUp23[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightRetUp23[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = retUp23[i];
                            countSupport = countSupport + 1;
                        }
                        else if (retUp23[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = retUp23[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightRetUp38[i] > Threshold)
                    if (retUp38[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightRetUp38[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = retUp38[i];
                            countResistance = countResistance + 1;
                        }
                        else if (retUp38[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = retUp38[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (retUp38[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightRetUp38[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = retUp38[i];
                            countSupport = countSupport + 1;
                        }
                        else if (retUp38[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = retUp38[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightRetUp50[i] > Threshold)
                    if (retUp50[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightRetUp50[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = retUp50[i];
                            countResistance = countResistance + 1;
                        }
                        else if (retUp50[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = retUp50[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (retUp50[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightRetUp50[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = retUp50[i];
                            countSupport = countSupport + 1;
                        }
                        else if (retUp50[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = retUp50[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightRetUp62[i] > Threshold)
                    if (retUp62[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightRetUp62[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = retUp62[i];
                            countResistance = countResistance + 1;
                        }
                        else if (retUp62[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = retUp62[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (retUp62[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightRetUp62[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = retUp62[i];
                            countSupport = countSupport + 1;
                        }
                        else if (retUp62[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = retUp62[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightRetUp76[i] > Threshold)
                    if (retUp76[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightRetUp76[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = retUp76[i];
                            countResistance = countResistance + 1;
                        }
                        else if (retUp76[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = retUp76[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (retUp76[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightRetUp76[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = retUp76[i];
                            countSupport = countSupport + 1;
                        }
                        else if (retUp76[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = retUp76[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightRetDown23[i] > Threshold)
                    if (retDown23[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightRetDown23[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = retDown23[i];
                            countResistance = countResistance + 1;
                        }
                        else if (retDown23[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = retDown23[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (retDown23[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightRetDown23[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = retDown23[i];
                            countSupport = countSupport + 1;
                        }
                        else if (retDown23[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = retDown23[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightRetDown38[i] > Threshold)
                    if (retDown38[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightRetDown38[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = retDown38[i];
                            countResistance = countResistance + 1;
                        }
                        else if (retDown38[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = retDown38[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (retDown38[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightRetDown38[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = retDown38[i];
                            countSupport = countSupport + 1;
                        }
                        else if (retDown38[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = retDown38[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightRetDown50[i] > Threshold)
                    if (retDown50[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightRetDown50[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = retDown50[i];
                            countResistance = countResistance + 1;
                        }
                        else if (retDown50[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = retDown50[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (retDown50[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightRetDown50[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = retDown50[i];
                            countSupport = countSupport + 1;
                        }
                        else if (retDown50[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = retDown50[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightRetDown62[i] > Threshold)
                    if (retDown62[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightRetDown62[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = retDown62[i];
                            countResistance = countResistance + 1;
                        }
                        else if (retDown62[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = retDown62[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (retDown62[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightRetDown62[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = retDown62[i];
                            countSupport = countSupport + 1;
                        }
                        else if (retDown62[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = retDown62[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightRetDown76[i] > Threshold)
                    if (retDown76[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightRetDown76[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = retDown76[i];
                            countResistance = countResistance + 1;
                        }
                        else if (retDown76[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = retDown76[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (retDown76[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightRetDown76[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = retDown76[i];
                            countSupport = countSupport + 1;
                        }
                        else if (retDown76[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = retDown76[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }
            #endregion

            #region -- Ext --
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtUp127[i] > Threshold)
                    if (extUp127[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtUp127[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extUp127[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extUp127[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extUp127[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extUp127[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtUp127[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extUp127[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extUp127[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extUp127[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtUp162[i] > Threshold)
                    if (extUp162[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtUp162[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extUp162[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extUp162[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extUp162[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extUp162[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtUp162[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extUp162[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extUp162[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extUp162[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtUp200[i] > Threshold)
                    if (extUp200[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtUp200[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extUp200[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extUp200[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extUp200[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extUp200[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtUp200[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extUp200[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extUp200[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extUp200[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtUp262[i] > Threshold)
                    if (extUp262[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtUp262[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extUp262[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extUp262[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extUp262[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extUp262[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtUp262[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extUp262[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extUp262[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extUp262[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtUp300[i] > Threshold)
                    if (extUp300[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtUp300[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extUp300[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extUp300[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extUp300[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extUp300[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtUp300[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extUp300[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extUp300[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extUp300[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtUp423[i] > Threshold)
                    if (extUp423[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtUp423[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extUp423[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extUp423[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extUp423[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extUp423[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtUp423[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extUp423[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extUp423[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extUp423[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtDown127[i] > Threshold)
                    if (extDown127[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtDown127[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extDown127[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extDown127[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extDown127[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extDown127[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtDown127[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extDown127[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extDown127[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extDown127[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtDown162[i] > Threshold)
                    if (extDown162[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtDown162[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extDown162[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extDown162[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extDown162[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extDown162[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtDown162[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extDown162[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extDown162[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extDown162[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtDown200[i] > Threshold)
                    if (extDown200[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtDown200[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extDown200[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extDown200[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extDown200[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extDown200[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtDown200[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extDown200[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extDown200[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extDown200[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtDown262[i] > Threshold)
                    if (extDown262[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtDown262[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extDown262[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extDown262[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extDown262[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extDown262[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtDown262[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extDown262[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extDown262[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extDown262[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtDown300[i] > Threshold)
                    if (extDown300[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtDown300[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extDown300[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extDown300[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extDown300[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extDown300[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtDown300[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extDown300[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extDown300[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extDown300[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightExtDown423[i] > Threshold)
                    if (extDown423[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightExtDown423[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = extDown423[i];
                            countResistance = countResistance + 1;
                        }
                        else if (extDown423[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = extDown423[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (extDown423[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightExtDown423[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = extDown423[i];
                            countSupport = countSupport + 1;
                        }
                        else if (extDown423[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = extDown423[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }
            #endregion

            #region -- Dir and LastDir --
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightDirUp38[i] > Threshold)
                    if (dirUp38[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightDirUp38[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = dirUp38[i];
                            countResistance = countResistance + 1;
                        }
                        else if (dirUp38[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = dirUp38[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (dirUp38[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightDirUp38[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = dirUp38[i];
                            countSupport = countSupport + 1;
                        }
                        else if (dirUp38[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = dirUp38[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightDirUp62[i] > Threshold)
                    if (dirUp62[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightDirUp62[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = dirUp62[i];
                            countResistance = countResistance + 1;
                        }
                        else if (dirUp62[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = dirUp62[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (dirUp62[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightDirUp62[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = dirUp62[i];
                            countSupport = countSupport + 1;
                        }
                        else if (dirUp62[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = dirUp62[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightDirUp100[i] > Threshold)
                    if (dirUp100[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightDirUp100[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = dirUp100[i];
                            countResistance = countResistance + 1;
                        }
                        else if (dirUp100[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = dirUp100[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (dirUp100[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightDirUp100[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = dirUp100[i];
                            countSupport = countSupport + 1;
                        }
                        else if (dirUp100[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = dirUp100[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightDirDown38[i] > Threshold)
                    if (dirDown38[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightDirDown38[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = dirDown38[i];
                            countResistance = countResistance + 1;
                        }
                        else if (dirDown38[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = dirDown38[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (dirDown38[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightDirDown38[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = dirDown38[i];
                            countSupport = countSupport + 1;
                        }
                        else if (dirDown38[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = dirDown38[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightDirDown62[i] > Threshold)
                    if (dirDown62[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightDirDown62[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = dirDown62[i];
                            countResistance = countResistance + 1;
                        }
                        else if (dirDown62[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = dirDown62[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (dirDown62[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightDirDown62[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = dirDown62[i];
                            countSupport = countSupport + 1;
                        }
                        else if (dirDown62[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = dirDown62[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightDirDown100[i] > Threshold)
                    if (dirDown100[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightDirDown100[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = dirDown100[i];
                            countResistance = countResistance + 1;
                        }
                        else if (dirDown100[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = dirDown100[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (dirDown100[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightDirDown100[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = dirDown100[i];
                            countSupport = countSupport + 1;
                        }
                        else if (dirDown100[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = dirDown100[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightLastDirUp38[i] > Threshold)
                    if (lastDirUp38[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightLastDirUp38[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = lastDirUp38[i];
                            countResistance = countResistance + 1;
                        }
                        else if (lastDirUp38[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = lastDirUp38[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (lastDirUp38[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightLastDirUp38[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = lastDirUp38[i];
                            countSupport = countSupport + 1;
                        }
                        else if (lastDirUp38[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = lastDirUp38[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightLastDirUp62[i] > Threshold)
                    if (lastDirUp62[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightLastDirUp62[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = lastDirUp62[i];
                            countResistance = countResistance + 1;
                        }
                        else if (lastDirUp62[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = lastDirUp62[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (lastDirUp62[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightLastDirUp62[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = lastDirUp62[i];
                            countSupport = countSupport + 1;
                        }
                        else if (lastDirUp62[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = lastDirUp62[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightLastDirUp100[i] > Threshold)
                    if (lastDirUp100[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightLastDirUp100[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = lastDirUp100[i];
                            countResistance = countResistance + 1;
                        }
                        else if (lastDirUp100[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = lastDirUp100[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (lastDirUp100[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightLastDirUp100[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = lastDirUp100[i];
                            countSupport = countSupport + 1;
                        }
                        else if (lastDirUp100[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = lastDirUp100[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightLastDirDown38[i] > Threshold)
                    if (lastDirDown38[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightLastDirDown38[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = lastDirDown38[i];
                            countResistance = countResistance + 1;
                        }
                        else if (lastDirDown38[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = lastDirDown38[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (lastDirDown38[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightLastDirDown38[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = lastDirDown38[i];
                            countSupport = countSupport + 1;
                        }
                        else if (lastDirDown38[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = lastDirDown38[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightLastDirDown62[i] > Threshold)
                    if (lastDirDown62[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightLastDirDown62[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = lastDirDown62[i];
                            countResistance = countResistance + 1;
                        }
                        else if (lastDirDown62[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = lastDirDown62[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (lastDirDown62[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightLastDirDown62[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = lastDirDown62[i];
                            countSupport = countSupport + 1;
                        }
                        else if (lastDirDown62[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = lastDirDown62[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightLastDirDown100[i] > Threshold)
                    if (lastDirDown100[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightLastDirDown100[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = lastDirDown100[i];
                            countResistance = countResistance + 1;
                        }
                        else if (lastDirDown100[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = lastDirDown100[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (lastDirDown100[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightLastDirDown100[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = lastDirDown100[i];
                            countSupport = countSupport + 1;
                        }
                        else if (lastDirDown100[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = lastDirDown100[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }
            #endregion

            #region -- Alt --
            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightAlt0Up62[i] > Threshold)
                    if (alt0Up62[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightAlt0Up62[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = alt0Up62[i];
                            countResistance = countResistance + 1;
                        }
                        else if (alt0Up62[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = alt0Up62[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (alt0Up62[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightAlt0Up62[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = alt0Up62[i];
                            countSupport = countSupport + 1;
                        }
                        else if (alt0Up62[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = alt0Up62[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightAlt0Up100[i] > Threshold)
                    if (alt0Up100[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightAlt0Up100[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = alt0Up100[i];
                            countResistance = countResistance + 1;
                        }
                        else if (alt0Up100[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = alt0Up100[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (alt0Up100[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightAlt0Up100[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = alt0Up100[i];
                            countSupport = countSupport + 1;
                        }
                        else if (alt0Up100[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = alt0Up100[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightAlt0Up162[i] > Threshold)
                    if (alt0Up162[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightAlt0Up162[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = alt0Up162[i];
                            countResistance = countResistance + 1;
                        }
                        else if (alt0Up162[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = alt0Up162[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (alt0Up162[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightAlt0Up162[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = alt0Up162[i];
                            countSupport = countSupport + 1;
                        }
                        else if (alt0Up162[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = alt0Up162[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightAlt1Up100[i] > Threshold)
                    if (alt1Up100[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightAlt1Up100[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = alt1Up100[i];
                            countResistance = countResistance + 1;
                        }
                        else if (alt1Up100[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = alt1Up100[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (alt1Up100[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightAlt1Up100[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = alt1Up100[i];
                            countSupport = countSupport + 1;
                        }
                        else if (alt1Up100[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = alt1Up100[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightAlt0Down62[i] > Threshold)
                    if (alt0Down62[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightAlt0Down62[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = alt0Down62[i];
                            countResistance = countResistance + 1;
                        }
                        else if (alt0Down62[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = alt0Down62[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (alt0Down62[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightAlt0Down62[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = alt0Down62[i];
                            countSupport = countSupport + 1;
                        }
                        else if (alt0Down62[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = alt0Down62[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightAlt0Down100[i] > Threshold)
                    if (alt0Down100[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightAlt0Down100[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = alt0Down100[i];
                            countResistance = countResistance + 1;
                        }
                        else if (alt0Down100[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = alt0Down100[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (alt0Down100[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightAlt0Down100[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = alt0Down100[i];
                            countSupport = countSupport + 1;
                        }
                        else if (alt0Down100[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = alt0Down100[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightAlt0Down162[i] > Threshold)
                    if (alt0Down162[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightAlt0Down162[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = alt0Down162[i];
                            countResistance = countResistance + 1;
                        }
                        else if (alt0Down162[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = alt0Down162[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (alt0Down162[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightAlt0Down162[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = alt0Down162[i];
                            countSupport = countSupport + 1;
                        }
                        else if (alt0Down162[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = alt0Down162[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }

            for (int i = lowestTimeFrame; i <= highestTimeFrame; i++)
            {
                if (cumulatedWeightAlt1Down100[i] > Threshold)
                    if (alt1Down100[i] > lowerLimitResistance)
                    {
                        if (cumulatedWeightAlt1Down100[i] > 1.5 * Threshold)
                        {
                            fibResistance[countResistance] = alt1Down100[i];
                            countResistance = countResistance + 1;
                        }
                        else if (alt1Down100[i] < upperLimitWeakResistance)
                        {
                            weakResistance[countWeakResistance] = alt1Down100[i];
                            countWeakResistance = countWeakResistance + 1;
                        }
                    }
                    else if (alt1Down100[i] <= upperLimitSupport)
                    {
                        if (cumulatedWeightAlt1Down100[i] > 1.5 * Threshold)
                        {
                            fibSupport[countSupport] = alt1Down100[i];
                            countSupport = countSupport + 1;
                        }
                        else if (alt1Down100[i] > lowerLimitWeakSupport)
                        {
                            weakSupport[countWeakSupport] = alt1Down100[i];
                            countWeakSupport = countWeakSupport + 1;
                        }
                    }
            }
            #endregion
        }
        #endregion

        //==============================================================================================================================
        // Sorting Arrays fibResistance, fib, fibLine and  fibWeight with BubbleSort to prepare for Analyzer
        //==============================================================================================================================
        #region -- SortLines --
        public void SortLines()
        {
            #region -- Resistance Array is sorted in ascending order
            goAhead = true;
            m = countResistance;
            while (goAhead && m >= 1)
            {
                goAhead = false;
                for (int i = 1; i < m; i++)
                {
                    if (fibResistance[i - 1] > fibResistance[i])
                    {
                        dummy = fibResistance[i - 1];
                        fibResistance[i - 1] = fibResistance[i];
                        fibResistance[i] = dummy;
                        goAhead = true;
                    }
					fibResistance[i-1] = Instrument.MasterInstrument.RoundToTickSize(fibResistance[i-1]);
                }
                m = m - 1;
            }
            #endregion

            #region -- Support Array is sorted in descending order
            goAhead = true;
            n = countSupport;
            while (goAhead && n >= 1)
            {
                goAhead = false;
                for (int i = 1; i < n; i++)
                {
                    if (fibSupport[i - 1] < fibSupport[i])
                    {
                        dummy = fibSupport[i - 1];
                        fibSupport[i - 1] = fibSupport[i];
                        fibSupport[i] = dummy;
                        goAhead = true;
                    }
					fibSupport[i-1] = Instrument.MasterInstrument.RoundToTickSize(fibSupport[i-1]);
                }
                n = n - 1;
            }
            #endregion

            #region -- Weak Resistance Array is sorted in ascending order
            goAhead = true;
            m = countWeakResistance;
            while (goAhead && m >= 1)
            {
                goAhead = false;
                for (int i = 1; i < m; i++)
                {
                    if (weakResistance[i - 1] > weakResistance[i])
                    {
                        dummy = weakResistance[i - 1];
                        weakResistance[i - 1] = weakResistance[i];
                        weakResistance[i] = dummy;
                        goAhead = true;
                    }
					weakResistance[i-1] = Instrument.MasterInstrument.RoundToTickSize(weakResistance[i-1]);
                }
                m = m - 1;
            }
            #endregion

            #region -- Support Array is sorted in descending order
            goAhead = true;
            n = countWeakSupport;
            while (goAhead && n >= 1)
            {
                goAhead = false;
                for (int i = 1; i < n; i++)
                {
                    if (weakSupport[i - 1] < weakSupport[i])
                    {
                        dummy = weakSupport[i - 1];
                        weakSupport[i - 1] = weakSupport[i];
                        weakSupport[i] = dummy;
                        goAhead = true;
                    }
					weakSupport[i-1] = Instrument.MasterInstrument.RoundToTickSize(weakSupport[i-1]);
                }
                n = n - 1;
            }
            #endregion
        }
        #endregion

		internal class LoadRayTemplates : StringConverter
		{
			#region LoadRayTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool","Ray"};
				HLtemplates_folder = System.IO.Path.Combine(paths);
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(HLtemplates_folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("Default");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						string name = fi.Name.Replace(".xml",string.Empty);
						if(!list.Contains(name)){
							list.Add(name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
        #region --- Properties ---

        #region -- Confluences --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence0 { get { return Values[0]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence1 { get { return Values[1]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence2 { get { return Values[2]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence3 { get { return Values[3]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence4 { get { return Values[4]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence5 { get { return Values[5]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence6 { get { return Values[6]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence7 { get { return Values[7]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence8 { get { return Values[8]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence9 { get { return Values[9]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence10 { get { return Values[10]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence11 { get { return Values[11]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence12 { get { return Values[12]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence13 { get { return Values[13]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence14 { get { return Values[14]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence15 { get { return Values[15]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence16 { get { return Values[16]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence17 { get { return Values[17]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence18 { get { return Values[18]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> Confluence19 { get { return Values[19]; } }
        #endregion

        #region -- WeakConfluences --
        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence0 { get { return Values[20]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence1 { get { return Values[21]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence2 { get { return Values[22]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence3 { get { return Values[23]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence4 { get { return Values[24]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence5 { get { return Values[25]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence6 { get { return Values[26]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence7 { get { return Values[27]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence8 { get { return Values[28]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence9 { get { return Values[29]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence10 { get { return Values[30]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence11 { get { return Values[31]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence12 { get { return Values[32]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence13 { get { return Values[33]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence14 { get { return Values[34]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence15 { get { return Values[35]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence16 { get { return Values[36]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence17 { get { return Values[37]; } }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> WeakConfluence18 { get { return Values[38]; } }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> WeakConfluence19 { get { return Values[39]; } }
		#endregion
		#endregion

		#region -- Parameters --
		[Description("Enable gobalization of key Trade Plan fib levels")]
		[Display(Order = 10, Name = "Globals Enabled",  GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		public bool pGlobalObjects_Enabled {get;set;}

		[Display(Order = 20, Name = "Far Sell Ray Template", GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pFarSell_RayTemplate { get; set; }

		[Display(Order = 30, Name = "Near Sell Ray Template", GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pNearSell_RayTemplate { get; set; }

		[Display(Order = 40, Name = "Near Buy Ray Template", GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pNearBuy_RayTemplate { get; set; }

		[Display(Order = 50, Name = "Far Buy Ray Template", GroupName = "Global Visuals", ResourceType = typeof(Custom.Resource))]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadRayTemplates))]
		public string pFarBuy_RayTemplate { get; set; }

		#region TradingPlan
		[Range(1, 100)]
		[Display(Name = "ATR period", GroupName = "Trade Plan", Description = "", Order = 1)]
		public int ATRperiod  {get; set;}
		[Display(Name = "Dominant Trade Plan", GroupName = "Trade Plan", Description = "", Order = 3)]
		public ARC_GFSystem_DominantTradePlan DominantTradePlan  {get; set;}
		[Display(Name = "Plan levels basis", GroupName = "Trade Plan", Description = "What level is used as the key level?  Stops and Targets will be measured from this level", Order = 5)]
		public ARC_GFSystem_Plan_LevelsBasis PlanLevelsBasis {get; set;}
		[Display(Name = "Sell Far Trade Plan loc", GroupName = "Trade Plan", Description = "", Order = 8)]
		public ARC_GFSystem_TradePlanLocation SellFarTradePlan_Location  {get; set;}
		[Display(Name = "Sell Near Trade Plan loc", GroupName = "Trade Plan", Description = "", Order = 10)]
		public ARC_GFSystem_TradePlanLocation SellNearTradePlan_Location  {get; set;}
		[Display(Name = "Buy Near Trade Plan loc", GroupName = "Trade Plan", Description = "", Order = 15)]
		public ARC_GFSystem_TradePlanLocation BuyNearTradePlan_Location  {get; set;}
		[Display(Name = "Buy Far Trade Plan loc", GroupName = "Trade Plan", Description = "", Order = 20)]
		public ARC_GFSystem_TradePlanLocation BuyFarTradePlan_Location  {get; set;}
		[Display(Name = "Show Longs", GroupName = "Trade Plan", Description = "Show trade plan for long trades", Order = 25)]
		public bool ShowLongTradePlans {get; set;}
		[Display(Name = "Show Shorts", GroupName = "Trade Plan", Description = "Show trade plan for short trades", Order = 30)]
		public bool ShowShortTradePlans {get; set;}
		[Display(Name = "Show Near Trade Plans", GroupName = "Trade Plan", Description = "Show the trade plan for the nearest fib line", Order = 35)]
		public bool ShowNearTradePlan {get; set;}
		[Display(Name = "Show Far Trade Plans", GroupName = "Trade Plan", Description = "Show the trade plan for the far fib line", Order = 40)]
		public bool ShowFarTradePlan {get; set;}

//		[Display(Name = "Print at CurrentBar?", GroupName = "Trade Plan", Description = "", Order = 42)]
//		public bool PrintPlansInRightMargin = false;
		[Range(0, 10000)]
		[Display(Name = "Near line length", GroupName = "Trade Plan", Description = "Line length (in bars) for near trade plan SL, T1 and T2 lines", Order = 45)]
		public int NearTradePlan_LineLength {get; set;}
		[Range(0, 10000)]
		[Display(Name = "Far line length", GroupName = "Trade Plan", Description = "Line length (in bars) for near trade plan SL, T1 and T2 lines", Order = 50)]
		public int FarTradePlan_LineLength {get;set;}
		[Display(Name = "Include terminated levels", GroupName = "Trade Plan", Description = "Include all historical levels, not just the current ones", Order = 55)]
		public bool IncludeTerminatedLevels{get; set;}
		[XmlIgnore]
		[Display(Name = "Terminated color", GroupName = "Trade Plan", Description = "Color of terminated lines carried forward", Order = 60)]
		public Brush TerminatedLevelColor {get; set;}
		[Browsable(false)]
		public string TerminatedLevelColorSerialize {get { return Serialize.BrushToString(TerminatedLevelColor); }set { TerminatedLevelColor = Serialize.StringToBrush(value); }}
		[Display(Name = "Terminated line width", GroupName = "Trade Plan", Description = "Thickness of terminated line carried forward", Order = 65)]
		public int TerminatedLevelLineWidth {get; set;}
		[Display(Name = "Terminated line style", GroupName = "Trade Plan", Description = "Style of terminated lines", Order = 70)]
		public DashStyleHelper TerminatedLevelDashStyle {get;set;}
		[Display(Name = "Visual Shift distance", GroupName = "Trade Plan", Description = "Distance (in bars) of shifting the trade plans away from the current bar (neg value moves print to the left, pos values to the right)", Order = 75)]
		public int VisualShiftDistance {get; set;}

		[Display(Name = "SL Calc Basis", GroupName = "Trade Plan", Description = "When calculating the SL distance, should it use the ATR multiple, or Tick distances?", Order = 80)]
		public ARC_GFSystem_SLTP_CalcBasis SLTP_CalcBasis {get; set;}

//		private bool ShowT2 = true;
//		private bool ShowT1 = true;
//		private bool ShowSL = true;
		[Display(Name = "Show T2 line", GroupName = "Trade Plan", Description = "Show the T2 line", Order = 86)]
		public bool ShowT2 {get; set;}
		[Display(Name = "Show T1 line", GroupName = "Trade Plan", Description = "Show the T1 line", Order = 90)]
		public bool ShowT1 {get; set;}
		[Display(Name = "Show SL line", GroupName = "Trade Plan", Description = "Show the SL line", Order = 95)]
		public bool ShowSL {get; set;}

//============================================================================================================
		[Range(0.01, 10)]
		[Display(Name = "EntryZone Height", GroupName = "Trade Plan Entry", Description = "Size of Entry Area rectangle, in multiples of the ATR", Order = 0)]
		public double EntryZoneSize_inATRs { get; set; }

		[Display(Name = "Entry Basis", GroupName = "Trade Plan Entry", Description = "", Order = 5)]
		public ARC_GFSystem_TradeEntryBasis EntryBasis {get;set;}

		[Display(Name = "Show Entry Areas", GroupName = "Trade Plan Entry", Description = "", Order = 10)]
		public bool ShowEntryZones {get;set;}

		[Display(Name = "Label for Longs", GroupName = "Trade Plan Entry", Description = "Enter a '*' for price insertion", Order = 15)]
		public string LongEntryLabel {get;set;}
		[Display(Name = "Label for Shorts", GroupName = "Trade Plan Entry", Description = "Enter a '*' for price insertion", Order = 20)]
		public string ShortEntryLabel {get;set;}
		[XmlIgnore]
		[Display(Name = "Buy EntryZone Fill", GroupName = "Trade Plan Entry", Description = "", Order = 25)]
		public Brush BuyEntryZoneColor{get;set;}
		[Browsable(false)]
		public string BuyEntryZoneColorSerialize {get { return Serialize.BrushToString(BuyEntryZoneColor); }set { BuyEntryZoneColor = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Name = "Buy EntryZone Fill Opacity", GroupName = "Trade Plan Entry", Description = "0=transparent, 100=fully opaque", Order = 30)]
		public int BuyEntryZoneColorOpacity {get;set;}

		[XmlIgnore]
		[Display(Name = "Sell EntryZone Fill", GroupName = "Trade Plan Entry", Description = "", Order = 35)]
		public Brush SellEntryZoneColor{get;set;}
		[Browsable(false)]
		public string SellEntryZoneColorSerialize {get { return Serialize.BrushToString(SellEntryZoneColor); }set { SellEntryZoneColor = Serialize.StringToBrush(value); }}
		[Range(0, 100)]
		[Display(Name = "Sell EntryZone Fill Opacity", GroupName = "Trade Plan Entry", Description = "0=transparent, 100=fully opaque", Order = 40)]
		public int SellEntryZoneColorOpacity {get;set;}

		[Display(Name = "Font", GroupName = "Trade Plan Entry", Description = "", Order = 45)]
        public SimpleFont FontEL { get; set; }
		[XmlIgnore]
		[Display(Name = "Entry color", GroupName = "Trade Plan Entry", Description = "Color of Entry lines", Order = 50)]
		public Brush EntryBrush  {get;set;}
		[Browsable(false)]
		public string EntryBrushSerialize {get { return Serialize.BrushToString(EntryBrush); }set { EntryBrush = Serialize.StringToBrush(value); }}
		[Display(Name = "Entry line style", GroupName = "Trade Plan Entry", Description = "Style of Entry lines", Order = 55)]
		public DashStyleHelper EntryDashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "Entry line width", GroupName = "Trade Plan Entry", Description = "", Order = 60)]
		public int EntryLineWidth {get;set;}
//============================================================================================================
		[Display(Name = "Font", GroupName = "Trade Plan StopLoss", Description = "", Order = 1)]
        public SimpleFont FontSL { get; set; }
		[Range(0.0, 1000)]
		[Display(Name = "SL size ATRs", GroupName = "Trade Plan StopLoss", Description = "Size of the stoploss as a multiple of the ATR", Order = 10)]
		public double SLsize_inATRs {get;set;}
		[Range(0, 10000)]
		[Display(Name = "SL size Ticks", GroupName = "Trade Plan StopLoss", Description = "Size of the stoploss in Ticks", Order = 11)]
		public int SLsize_inTicks {get;set;}
		[Display(Name = "SL label for Longs", GroupName = "Trade Plan StopLoss", Description = "Enter a '*' for price insertion", Order = 20)]
		public string LongSLLabel {get;set;}
		[Display(Name = "SL label for Shorts", GroupName = "Trade Plan StopLoss", Description = "Enter a '*' for price insertion", Order = 30)]
		public string ShortSLLabel {get;set;}
		[XmlIgnore]
		[Display(Name = "SL color for Longs", GroupName = "Trade Plan StopLoss", Description = "Color of SL lines", Order = 50)]
		public Brush LongSLBrush  {get;set;}
		[Browsable(false)]
		public string LSLBrushSerialize {get { return Serialize.BrushToString(LongSLBrush); }set { LongSLBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Name = "SL color for Shorts", GroupName = "Trade Plan StopLoss", Description = "Color of SL lines", Order = 51)]
		public Brush ShortSLBrush  {get;set;}
		[Browsable(false)]
		public string SSLBrushSerialize {get { return Serialize.BrushToString(ShortSLBrush); }set { ShortSLBrush = Serialize.StringToBrush(value); }}
		[Display(Name = "SL line style", GroupName = "Trade Plan StopLoss", Description = "Style of SL lines", Order = 65)]
		public DashStyleHelper SLDashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "SL line width", GroupName = "Trade Plan StopLoss", Description = "", Order = 80)]
		public int SLLineWidth {get;set;}
//============================================================================================================
        [Display(Name = "Font", GroupName = "Trade Plan Target1", Description = "", Order = 1)]
        public SimpleFont FontT1 { get; set; }
		[Range(0.0, 1000)]
		[Display(Name = "Target1 ATRs", GroupName = "Trade Plan Target1", Description = "Size of the first profit target as a multiple of ATR", Order = 10)]
		public double T1size_inATRs  {get;set;}
		[Range(0.0, 10000)]
		[Display(Name = "Target1 Ticks", GroupName = "Trade Plan Target1", Description = "Size of the first profit target in ticks", Order = 12)]
		public double T1size_inTicks  {get;set;}
		[Display(Name = "Target1 label for Longs", GroupName = "Trade Plan Target1", Description = "Enter a '*' for price insertion", Order = 20)]
		public string LongT1Label {get;set;}
		[Display(Name = "Target1 label for Shorts", GroupName = "Trade Plan Target1", Description = "Enter a '*' for price insertion", Order = 30)]
		public string ShortT1Label {get;set;}
		[XmlIgnore]
		[Display(Name = "Target1 color for Longs", GroupName = "Trade Plan Target1", Description = "Color of T1 lines", Order = 40)]
		public Brush LongT1Brush {get;set;}
		[Browsable(false)]
		public string LT1BrushSerialize {get { return Serialize.BrushToString(LongT1Brush); }set { LongT1Brush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Name = "Target1 color for Shorts", GroupName = "Trade Plan Target1", Description = "Color of T1 lines", Order = 50)]
		public Brush ShortT1Brush {get;set;}
		[Browsable(false)]
		public string ST1BrushSerialize {get { return Serialize.BrushToString(ShortT1Brush); }set { ShortT1Brush = Serialize.StringToBrush(value); }}
		[Display(Name = "Target1 line style", GroupName = "Trade Plan Target1", Description = "Style of T1 lines", Order = 60)]
		public DashStyleHelper T1DashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "Target1 line width", GroupName = "Trade Plan Target1", Description = "", Order = 70)]
		public int T1LineWidth {get;set;}
//============================================================================================================
		[Display(Name = "Font", GroupName = "Trade Plan Target2", Description = "", Order = 1)]
        public SimpleFont FontT2 { get; set; }
		[Range(0.0, 1000)]
		[Display(Name = "Target2 ATRs", GroupName = "Trade Plan Target2", Description = "Size of the second profit target as a multiple of ATR", Order = 10)]
		public double T2size_inATRs  {get;set;}
		[Range(0.0, 10000)]
		[Display(Name = "Target2 Ticks", GroupName = "Trade Plan Target2", Description = "Size of the second profit target in ticks", Order = 12)]
		public double T2size_inTicks  {get;set;}
		[Display(Name = "Target2 label for Longs", GroupName = "Trade Plan Target2", Description = "Enter a '*' for price insertion", Order = 20)]
		public string LongT2Label {get;set;}
		[Display(Name = "Target2 label for Shorts", GroupName = "Trade Plan Target2", Description = "Enter a '*' for price insertion", Order = 30)]
		public string ShortT2Label {get;set;}
		[XmlIgnore]
		[Display(Name = "Target2 color for Longs", GroupName = "Trade Plan Target2", Description = "Color of T2 lines", Order = 40)]
		public Brush LongT2Brush {get;set;}
		[Browsable(false)]
		public string LT2BrushSerialize {get { return Serialize.BrushToString(LongT2Brush); }set { LongT2Brush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Name = "Target2 color for Shorts", GroupName = "Trade Plan Target2", Description = "Color of T2 lines", Order = 50)]
		public Brush ShortT2Brush {get;set;}
		[Browsable(false)]
		public string ST2BrushSerialize {get { return Serialize.BrushToString(ShortT2Brush); }set { ShortT2Brush = Serialize.StringToBrush(value); }}
		[Display(Name = "Target2 line style", GroupName = "Trade Plan Target2", Description = "Style of T2 lines", Order = 60)]
		public DashStyleHelper T2DashStyle {get;set;}
		[Range(1, 10)]
		[Display(Name = "Target2 line width", GroupName = "Trade Plan Target2", Description = "", Order = 70)]
		public int T2LineWidth {get;set;}
//============================================================================================================
		#endregion

        #region -- SwingTrend Parameters --

        [Display(Name = "Use Highs/Lows", GroupName = "SwingTrend Parameters", Description = "Use High/Lows or Input", Order = 5)]
        public bool isHLBased { get; set; }

        [Range(1, 300)]
        [Display(Name = "Swing strength", GroupName = "SwingTrend Parameters", Description = "Number of bars used to identify a swing high or low", Order = 10)]
        public int SwingStrength { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Deviation multiplier", GroupName = "SwingTrend Parameters", Description = "Multiplier used to calculate minimum as an ATR multiple", Order = 15)]
        public double MultiplierMD { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Sensitivity double tops/bottoms", GroupName = "SwingTrend Parameters", Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = 20)]
        public double MultiplierDTB { get; set; }

		[Display(Name = "Show Background Color", GroupName = "SwingTrend Parameters", Description = "Colorize the background up/down structure trend zones", Order = 30)]
		public bool ShowStructureBackground {get;set;}

		[XmlIgnore]
        [Display(Name = "Up-trend bkg color", GroupName = "SwingTrend Parameters", Description = "Background color for up-trending structure", Order = 35)]
        public Brush UpTrendColor { get; set; }
        [Browsable(false)]
        public string UpTrendColorSerialize
        {get { return Serialize.BrushToString(UpTrendColor); }
                                        set { UpTrendColor = Serialize.StringToBrush(value); }}
        [Range(0, 100)]
        [Display(Name = "Opacity (up-trend)", GroupName = "SwingTrend Parameters", Description = "Opacity of the up-trend background color", Order = 40)]
        public int OpacityUpTrendBkg { get; set; }

		[XmlIgnore]
        [Display(Name = "Down-trend bkg color", GroupName = "SwingTrend Parameters", Description = "Background color for down-trending structure", Order = 45)]
        public Brush DownTrendColor { get; set; }
        [Browsable(false)]
        public string DownTrendColorSerialize
        {get { return Serialize.BrushToString(DownTrendColor); }
                                        set { DownTrendColor = Serialize.StringToBrush(value); }}
        [Range(0, 100)]
        [Display(Name = "Opacity (down-trend)", GroupName = "SwingTrend Parameters", Description = "Opacity of the down-trend background color", Order = 50)]
        public int OpacityDownTrendBkg { get; set; }

		
        [Display(Name = "Show Lines", GroupName = "SwingTrend Parameters", Description = "Show structure trend lines", Order = 53)]
		public bool ShowStructureLines {get;set;}

		[XmlIgnore]
        [Display(Name = "Up-trend line color", GroupName = "SwingTrend Parameters", Description = "Line color for up-trending structure", Order = 55)]
        public Brush UpLineColor { get; set; }
        [Browsable(false)]
        public string UpLineColorSerialize
        {get { return Serialize.BrushToString(UpLineColor); }
                                        set { UpLineColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
        [Display(Name = "Down-trend line color", GroupName = "SwingTrend Parameters", Description = "Line color for down-trending structure", Order = 60)]
        public Brush DownLineColor { get; set; }
        [Browsable(false)]
        public string DownLineColorSerialize
        {get { return Serialize.BrushToString(DownLineColor); }
                                        set { DownLineColor = Serialize.StringToBrush(value); }}
        [Range(1, 10)]
        [Display(Name = "Line Thickness", GroupName = "SwingTrend Parameters", Description = "Thickness of structure lines", Order = 65)]
		public int LineThickness {get;set;}

        [Display(Name = "Show Labels", GroupName = "SwingTrend Parameters", Description = "Show zigzag labels (e.g. 'HH' or 'LH', etc)", Order = 70)]
		public bool ShowStructureLabels{get;set;}
		#endregion

		#region general Parameters
		[Range(1, int.MaxValue)]
		[Display(Name = "Bar period for minute bars", GroupName = " Parameters", Description = "Bar period for minute bars which are used to calculate the Fibonacci confluence lines", Order = 0)]
		public int BarPeriod { get; set; }

		[Display(Name = "Fibonacci swing timeframe", GroupName = " Parameters", Description = "Timeframes used to identify Fibonacci swings", Order = 1)]
		public ARC_GFSystem_FiblineResolutionA LineDensity { get; set; }

		[Display(Name = "Grid strength", GroupName = " Parameters", Description = "Width of the grid used for summing up Fibonacci lines", Order = 2)]
		public ARC_GFSystem_ConfluenceWidthA ConfluenceZone { get; set; }

		[Range(0.0, double.MaxValue)]
		[Display(Name = "Threshold for confluence lines", GroupName = " Parameters", Description = "The treshold set the minumum statistical weight required for a confluence line. Confluence lines with a weight below the threshold value will not be shown.", Order = 3)]
		public double Threshold { get; set; }

		[Range(30, int.MaxValue)]
		[Display(Name = "Total lookback (days)", GroupName = " Parameters", Description = "Lookback period for data used for calculating Fibonacci lines", Order = 4)]
		public int LookBackMinute { get; set; }

		[Display(Name = "Check data preloading", GroupName = " Parameters", Description = "Checks and displays the range for the preloaded data", Order = 5)]
		public bool ShowMinuteDataPeriod { get; set; }

		[Description("Button text - enter how you want the UI button to be labeled")]
		[Display(Order = 10, Name = "Button Txt",  GroupName = " Parameters", ResourceType = typeof(Custom.Resource))]
		public string pButtonText {get;set;}

		#endregion
		#endregion

		#region -- Plots --
		[XmlIgnore]
		[Display(Name = "Resistance lines", GroupName = "Plots", Description = "Select color for all resistance lines", Order = 0)]
		public Brush ResistanceColor { get; set; }
		[Browsable(false)]
		public string ResistanceColorSerialize
		{
		    get { return Serialize.BrushToString(ResistanceColor); }
		    set { ResistanceColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Support lines", GroupName = "Plots", Description = "Select color for all support lines", Order = 1)]
		public Brush SupportColor { get; set; }
		[Browsable(false)]
		public string SupportColorSerialize
		{
		    get { return Serialize.BrushToString(SupportColor); }
		    set { SupportColor = Serialize.StringToBrush(value); }
		}

		[Range(1, int.MaxValue)]
		[Display(Name = "Line width major lines", GroupName = "Plots", Description = "Width for major lines.", Order = 2)]
		public int LineWidthStrong { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Line width minor lines", GroupName = "Plots", Description = "Width for minor lines.", Order = 3)]
		public int LineWidthWeak { get; set; }

		[Display(Name = "Plot style major lines", GroupName = "Plots", Description = "Plot style for major lines.", Order = 4)]
		public PlotStyle StrongPlotStyle { get; set; }

		[Display(Name = "Plot style minor lines", GroupName = "Plots", Description = "Plot style for minor lines.", Order = 5)]
		public PlotStyle WeakPlotStyle { get; set; }

		[Display(Name = "Dash style major lines", GroupName = "Plots", Description = "Dash style for major lines.", Order = 6)]
		public DashStyleHelper StrongDashStyle { get; set; }

		[Display(Name = "Dash style minor lines", GroupName = "Plots", Description = "Dash style for minor lines.", Order = 7)]
		public DashStyleHelper WeakDashStyle { get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_GFSystem[] cacheARC_GFSystem;
		public ARC.ARC_GFSystem ARC_GFSystem()
		{
			return ARC_GFSystem(Input);
		}

		public ARC.ARC_GFSystem ARC_GFSystem(ISeries<double> input)
		{
			if (cacheARC_GFSystem != null)
				for (int idx = 0; idx < cacheARC_GFSystem.Length; idx++)
					if (cacheARC_GFSystem[idx] != null &&  cacheARC_GFSystem[idx].EqualsInput(input))
						return cacheARC_GFSystem[idx];
			return CacheIndicator<ARC.ARC_GFSystem>(new ARC.ARC_GFSystem(), input, ref cacheARC_GFSystem);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_GFSystem ARC_GFSystem()
		{
			return indicator.ARC_GFSystem(Input);
		}

		public Indicators.ARC.ARC_GFSystem ARC_GFSystem(ISeries<double> input )
		{
			return indicator.ARC_GFSystem(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_GFSystem ARC_GFSystem()
		{
			return indicator.ARC_GFSystem(Input);
		}

		public Indicators.ARC.ARC_GFSystem ARC_GFSystem(ISeries<double> input )
		{
			return indicator.ARC_GFSystem(input);
		}
	}
}

#endregion
